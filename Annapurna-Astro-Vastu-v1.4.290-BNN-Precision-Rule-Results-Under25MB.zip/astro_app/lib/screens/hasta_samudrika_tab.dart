import 'package:flutter/widgets.dart';

/// Navigation tab retained intentionally; the Hasta Samudrika feature,
/// its rules, photo selection and reports have been removed.
class HastaSamudrikaTab extends StatelessWidget {
  const HastaSamudrikaTab({super.key});

  @override
  Widget build(BuildContext context) => const SizedBox.expand();
}
