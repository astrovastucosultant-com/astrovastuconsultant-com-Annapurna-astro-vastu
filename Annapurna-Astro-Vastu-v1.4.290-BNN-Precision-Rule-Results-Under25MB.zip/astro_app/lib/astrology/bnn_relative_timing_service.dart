import 'astro_models.dart';
import 'bnn_master_service.dart';

/// User-specified BNN progression: one natal-Jupiter sign per symbolic year.
/// Each ordinal house produces a nominal [ageStart, ageEnd) window in every
/// 12-year round. It is NOT a real Jupiter transit or an event assertion.
class BnnRelativeTimingWindow {
  final int house;
  final int round;
  final int ageStart;
  final int ageEnd;
  final int calendarStartYear;
  final int calendarEndYear;
  const BnnRelativeTimingWindow({required this.house,
    required this.round, required this.ageStart, required this.ageEnd,
    required this.calendarStartYear, required this.calendarEndYear});

  int get ordinalLifeYear => ageEnd;
  String get summary => 'జీవిత $ordinalLifeYear వ సంవత్సరం • '
      'పూర్తయిన వయస్సు $ageStart–$ageEnd • '
      'సుమారు $calendarStartYear–$calendarEndYear';
}

class BnnRelativeTimingService {
  static int relativeHouse(int referenceSign, int targetSign) =>
      1 + (targetSign - referenceSign + 12) % 12;

  /// BNN-M-046. `birthYear` alone supports a *year-range*, not an exact date.
  static List<BnnRelativeTimingWindow> annualJupiterWindows({
    required int house,
    required int birthYear,
    int maximumAge = 84,
  }) {
    if (house < 1 || house > 12 || maximumAge < 0) {
      throw ArgumentError('Invalid symbolic window');
    }
    final result = <BnnRelativeTimingWindow>[];
    for (var round = 0; round * 12 + house - 1 < maximumAge; round++) {
      final start = round * 12 + house - 1;
      final end = start + 1;
      result.add(BnnRelativeTimingWindow(
          house: house, round: round + 1,
          ageStart: start, ageEnd: end,
          calendarStartYear: birthYear + start,
          calendarEndYear: birthYear + end));
    }
    return result;
  }

  /// Optional age-only summary for a source IF with an explicitly stated
  /// Jupiter-relative planet location; never changes the THEN itself.
  static String? ageWindowsForRule(BnnMasterRule rule,
      AstroChartResult chart, int birthYear) {
    final matcher = RegExp(
        r'గురుకి\s*([0-9]{1,2})లో\s*'
        r'(సూర్యుడు|సూర్య|రవి|చంద్రుడు|చంద్ర|కుజుడు|కుజ|'
        r'బుధుడు|బుధ|శుక్రుడు|శుక్ర|శుకుడు|శని|రాహువు|రాహు|'
        r'కేతువు|కేతు)');
    final match = matcher.firstMatch(rule.condition);
    if (match == null) return null;
    final h = int.tryParse(match.group(1)!);
    if (h == null || h < 1 || h > 12) return null;
    final english = <String, String>{
      'శుకుడు': 'Venus',
    }[match.group(2)!] ??
        BnnMasterAnalysis.teluguPlanetNames[match.group(2)!];
    final jupiter = natalPlanet(chart, 'Jupiter');
    final target = english == null ? null : natalPlanet(chart, english);
    if (jupiter == null || target == null) return null;
    final actualHouse = relativeHouse(jupiter.signIndex, target.signIndex);
    if (actualHouse != h) return null;
    final windows = annualJupiterWindows(house: h, birthYear: birthYear);
    return 'మూల IFలోని గ్రహస్థానం సరిపోయింది: గురువుకు $h వ భావం. '
        'JUPITER_1SIGN_PER_YEAR_APPROX కాల సూచికలు: '
        '${windows.take(7).map((w) => w.summary).join('; ')}. '
        'ఇవి ప్రోగ్రెషన్ సూచికలు మాత్రమే; మూల IFలో ఇతర షరతులు '
        'ఉంటే అవి కూడా గణించాలి. నిజ గోచార తేదీలు వేరు.';
  }

  static PlanetPosition? natalPlanet(AstroChartResult chart, String name) {
    for (final p in chart.planets) {
      if (p.name == name) return p;
    }
    return null;
  }

  /// Only explicit Jupiter-relative source placements are listed.  Rules
  /// with added conditions (e.g., C64 7th lord) remain *conditional* and
  /// must pass the exact IF evaluator before their THEN is treated as matched.
  static List<BnnMasterRule> sourceCandidates(
      List<BnnMasterRule> rules, int house, String planetTelugu) {
    final variants = <String>{planetTelugu};
    const aliases = <String, List<String>>{
      'సూర్యుడు': ['సూర్య', 'రవి'],
      'చంద్రుడు': ['చంద్ర'],
      'కుజుడు': ['కుజ'],
      'బుధుడు': ['బుధ'],
      'శుక్రుడు': ['శుక్ర', 'శుకుడు'],
      'శని': ['శని'],
      'రాహువు': ['రాహు'],
      'కేతువు': ['కేతు'],
    };
    variants.addAll(aliases[planetTelugu] ?? const []);
    final prefix = 'గురుకి $houseలో ';
    return rules.where((r) =>
        variants.any((name) => r.condition.contains('$prefix$name')))
        .toList(growable: false);
  }
}
