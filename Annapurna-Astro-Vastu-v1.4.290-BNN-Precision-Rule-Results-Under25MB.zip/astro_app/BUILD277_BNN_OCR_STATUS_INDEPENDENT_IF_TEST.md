# v1.4.277 — OCR-independent natal IF auto-match experiment

- User request: test removing OCR status as a blocking condition.
- Source catalog retains all 462 rules, original status/source/IF/THEN byte-for-byte.
- `BnnExactIfEngine.check`: source status OCR_REVIEW/FACTS_REQUIRED/REVIEW no longer prevents testing a **complete, parseable, explicit natal IF**.
- No implied conjunction for the BNN N em-dash shorthand, no incomplete clauses, no event predictions generated.
- Added two-house reference-planet syntax e.g. శనికి 2లో చంద్ర + 3లో కేతు. Both clauses required.
- Added per-chart diagnostic foldout reporting total/evaluable/natal-true counts and a tap-through audit for every true IF.
- The status **has not been removed from the actual original 462 rule records**; diagnostic matching is not source validation.
- Still missing: full grammar for all 462 mixed conditions, OCR scan verification, Flutter compile and APK build.
