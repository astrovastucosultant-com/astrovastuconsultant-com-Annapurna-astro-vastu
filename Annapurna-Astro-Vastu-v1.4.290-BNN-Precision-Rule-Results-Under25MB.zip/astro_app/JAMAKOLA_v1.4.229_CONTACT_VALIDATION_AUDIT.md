# v1.4.229 — Jamakola computational contact audit

## Changes
- Added mathematical **Jama ↔ Udayam relative-motion crossing checks**, replacing the previous nearest-angular-marker guess in the Prashna Confirmation list.
- Relative angular rate uses Jama ring `-0.5°/min` and Udayam `+360°/solar-segment`; contact times are computed only within the present sunrise–sunset or sunset–sunrise segment.
- Report separates crossings within preceding 30 minutes from approaching crossings within following 30 minutes; unavailable contacts are reported as `none within window`, not guessed.
- Crossings are **geometric results of the currently implemented model**, not GK-source verified event predictions, and do not activate any IF–THEN rules automatically.
- Preserved separate Kavippu, Chatra, Mandi, Yamaghan semantics. Solar Veedhi anchors and the special Chatra/Mandi algorithms remain pending independently verified formulas.
- Added unit-test fixtures: direction, distance, sunrise/sunset boundary, exact contact.

## Validation limitations
- Flutter/Dart SDK is not installed in this environment; unit tests are authored but NOT executed by Flutter.
- Regression source assets were retained. ZIP CRC validation and source diff performed.
- External GK Astro app has not been executed, and source algorithms are not asserted to match its proprietary implementation.
