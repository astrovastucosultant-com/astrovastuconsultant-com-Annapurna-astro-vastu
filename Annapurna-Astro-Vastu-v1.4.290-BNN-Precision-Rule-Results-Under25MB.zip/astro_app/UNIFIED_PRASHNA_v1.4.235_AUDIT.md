# v1.4.235 — Unified Prashna (Jamakola + KP + Tajik)

## New UI and data flow

Navigation: **జ్యోతిష్య విధానాలు → ప్రశ్న ఫలితం — Jamakola + KP + Tajik**.

1. Enter ONE natural-language question and choose ONE precise event from the
   source-transcribed KP 414-event list. Categories narrow the event menu.
2. Select the LOCAL **question** moment; not the subject's birth time.
   Search/select the actual **question place** or check/enter coordinates,
   time zone. KP Horary 1–249 number is optional.
3. The same frozen question instant and geocoordinates feed three independent
   calculations. KP **Number** first cusp differs from KP **Time** first cusp.
4. The **single result panel** opens KP Time / KP Number / Jamakola / Tajik
   evidence and explicit conflicts. Copy result is available.

## Calculation coverage

- KP Time / Number: existing 12 Placidus cusps and preliminary house-link
  evaluation by the event table. No full KP promise/denial or DBA timing.
- Jamakola: existing solar Udhayam / clock Arudam / 8-clock-Jama grahas.
  Source-tagged 74 JSON rules, and mapped topic cases only. Do not conflate
  preliminary Prasna Marga Chatra transfer with authenticated GK Kavippu.
  No invented Kavippu event outcomes. No guessed Mandi/Yamaghan calculations.
- Tajik Prashna: new **first-stage** Lagnesha vs question-house-lord
  applying (Itthashala) / separating (Ishrafa) detection, using planetary
  longitudes, actual daily speeds including retrogression, sign-aspect check,
  and classical Deeptamsha mean-of-orbs.
  Orb values: Sun 15°, Moon 12°, Mars 8°, Mercury/Venus 7°,
  Jupiter/Saturn 9°. Source: historical Tajika literature and the
  Hayanaratna translation at
  https://www.wisdomlib.org/hinduism/book/hayanaratna-the-jewel-of-annual-astrology/d/doc1500903.html.
  **NOT** complete sixteen yoga, Radda, Sahama, strength, reception,
  parivartana, moon interference or event timing system.

## Honesty / evidence policy

A matched rule or applying aspect is a *provisional* interpretation in a
traditional practice; not an established empirical probability of a future
outcome. A missing or unmatched rule does NOT mean the event will not happen.
The unified screen NEVER issues a verified Yes/No or exact date at v1.4.235.
All predictions show "తుది నిర్ణయం పెండింగ్" until the full systems are
validated and source-reviewed. Disagreements are explicitly displayed.

## QA

- Existing 414 KP and 74 Jamakola JSON records retained unchanged.
- Added pure-service tests:
  `test/tajik_prashna_service_test.dart`,
  `test/unified_prashna_topic_map_test.dart`.
- Flutter/Dart SDK was NOT available in authoring environment; tests and
  APK compilation MUST be run in GitHub Actions before release.

## Source boundaries

- The Tajika Deeptamsa/orb inputs are traditional source facts; 
  the single combined UI decision is **new app workflow**, not a quoted
  classical rule. It deliberately remains provisional.
- An apparently favourable KP Time Chart plus applying Tajik aspect does
  not count as agreement from Jamakola if no validated Jamakola outcome
  exists. The result panel says so explicitly.
- All user-entered place/clock inputs are retained in the report. The
  registered birth time is NOT used as the horary judgement time.
