# Annapurna BNN v1.4.283 — Both natal combination methods

Added two separate, non-predictive natal-combination enumeration methods to **BNN > గ్రహసంబంధాలు**, without changing the 462 source outcomes, 106 master rules, or 48 timing master rules.

1. `LOCAL_DEGREE_TRINE_ASC`: all subsets containing 2..N grahas within each 1–5–9 trine group, ordered by local 0..30° within-sign DMS; ties marked unresolved and retrograde is displayed separately. A pair, trio, quartet and longer chain are separate configurations and never assumed to have identical THEN consequences.
2. `JUPITER_FIRST_RELATIVE_HOUSES`: all natal-Jupiter-anchored subsets containing 2..N grahas, with other planets in forward sign order relative to Jupiter. This is a separate viewpoint, not the absolute-longitude or local-degree ordering.

For a complete nine-graha chart Jupiter-anchored subsets = 255. Local-degree trine subset count depends on how planets are distributed among the four trine groups; the absolute theoretical maximum of one group is 502. A given subset visible in both methods must not be counted twice as an actual event.

The UI summarizes counts by group size, reveals candidate links on tap, and pages in 20 additional combinations on demand. It directs the user to the **ఫలితాలు** tab for source IF matches. This update does **not** increase the count of fully supported IF parsers or verify historical OCR text. Combinatorial coverage must not be described as predictive accuracy.

Tests: `test/bnn_combination_engine_test.dart`. Flutter/Dart SDK unavailable in this environment; release compile remains unverified.
