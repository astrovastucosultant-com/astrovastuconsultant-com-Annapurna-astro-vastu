# BNN v1.4.282 — Chart-matched original THEN as the primary output

## Reported bug

In the six-tab UI, a source rule can evaluate TRUE in the overall 462-rule
scan but disappear under the twelve bhavas. Previously the source was filtered
by the rule catalogue's thematic/positional house assignment AND by a
specific 144-topic keyword. A rule's source placement is not necessarily the
house to which its outcome refers.

## Implementation

- `BnnOutcomeRouter` centrally routes already evaluated TRUE original THEN
  text (or a branch-specific THEN) to relevant bhavas using ONLY the outcome
  text and 144-topic meanings, without using IF-position houses or chapter
  headings. Never fabricate an outcome for a house with no source match.
- Results tab now includes 12 direct house chips with per-house chart IF TRUE
  outcome counts and results-first cards containing full rule/evidence on tap.
- Selected house shows its routed THEN cards first, followed by an optional
  expandable list of the 12 karaka inspections and unparsed source material.
- When a result has an explicitly stated Jupiter-relative house, its detailed
  sheet also shows nominal symbolic progression year bands where applicable.
- A source matched elsewhere is not presented as the chosen house's outcome
  unless its THEN is meaningfully about that house.
- Source catalogue 462, master calculations 106, and timing rules 48 are not
  modified, and OCR_REVIEW provenance is preserved.

## Scope limits

This fixes losing chart-matched THENs in the display/routing pipeline. It does
not magically turn unparsed natal IFs into TRUE and does not promise an event
for every bhava. The 462 catalogue can be browsed, but only correctly
computed IF matches should be shown as chart results. The Flutter/Dart toolchain
is not available in this environment, so compiler and device verification
are pending. Regression test: `test/bnn_outcome_router_test.dart`.
