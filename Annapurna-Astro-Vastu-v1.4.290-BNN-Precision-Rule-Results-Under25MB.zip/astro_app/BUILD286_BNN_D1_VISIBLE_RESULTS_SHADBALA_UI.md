# v1.4.286 — Screenshots review: D1 BNN & Shadbala readability

Source baseline: v1.4.285. **Only UI layout and status copy** changed; no new astrological outcomes, predicates, or event years are asserted.

## BNN D1
- Keep only the matched natal bhava-lord positional IF visually prominent (green); clarify that position TRUE does not verify a life event.
- Collapse the 11 nonmatching alternatives and render their optional inspection as compact rows, not large result cards.
- Collapse the 12 non-predictive topic-reference cards by default; preserve all entries and expandability.
- Preserve First Bhava source notes, 48 conditional modifiers, provenance and timing/remedy distinctions.

## BPHS/Mandi/Shadbala
- Verified Shadbala virupa input fields are now opt-in and constrained to a 64 logical pixel height to avoid oversized/blank input blocks observed in screenshot. All original seven controllers and optional Mandi override remain.

## Validation
- Source/asset structure, ZIP integrity and unchanged rule datasets checked; Flutter SDK not installed here, APK compilation not performed. A new GitHub workflow build is required.
