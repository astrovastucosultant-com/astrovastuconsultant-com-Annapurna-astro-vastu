# Build 258 — BNN results-first screen

- Version `1.4.258+258`; based on complete v1.4.257 source ZIP.
- The 12 colorful bhava tabs and five sub-tabs are preserved.
- Candidate result cards now show **planet combination + authored result sentence**, e.g. `శుక్ర + శని — వివాహం ఆలస్యమవుతుంది.`
- IF, natal positions, inspection details, source citation and remedy appear **only when a result card is tapped**.
- All large per-bhava and yoga/timing source-rule lists are removed from the main panel, now behind a separate searchable 462-rule library sheet.
- Only eligible source `BNN N`, status `FACTS_REQUIRED`, explicitly matched natal same-sign chains appear as result *candidates*. Original 343 OCR_REVIEW and 37 REVIEW items are not auto-matched.
- The visible small note distinguishes a candidate natal placement from a confirmed prediction, event or timing result.
- Existing Jamakola, the 300 Nimitta data and the Hasta tab were not changed.
- New regression test for the Venus–Saturn candidate and the human-readable planet chain.

QA: ZIP/static checks are required. Real Flutter compilation was not performed in the editing runtime (SDK unavailable). This is a source update, not an APK.
