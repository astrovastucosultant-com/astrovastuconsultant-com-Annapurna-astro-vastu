# Annapurna BNN v1.4.280 — Source Rule Visibility + Jupiter-relative Years

- Original 462 source rules retained byte-for-byte at `assets/bnn/bnn_master_462.json`.
- Preserved all 106 BNN master calculations and 48 timing rules unchanged.
- New `BnnAllRulesMatchService` checks old strict IF matches first, then
  specifically constrained rule C64 (Venus 4th of Jupiter plus D1 seventh
  lord), C26 (Ketu 12th) and C33 (OCR variant `శుకుడు`); adds explicitly
  labelled local-degree BNN-N trinal chain evaluation for unambiguous dash
  chains. Text source status is NOT overwritten or represented as verified.
- Source library always shows all 462 THENs and IFs with TRUE/FALSE or
  the precise 'needs source/temporal definition' status, plus status filters.
  No rule disappears from the library simply because it was not matched.
- New `BnnRelativeTimingService` calculates from Jupiter (BNN first house)
  to each natal graha and Jupiter's SYMBOLIC one-sign/year windows:
  if Venus is fourth, years of life 4,16,28,40,52,... correspond to completed
  ages [3,4),[15,16),[27,28),...; calendar YEAR RANGES use birth year.
  This is distinct from REAL sidereal transit and the slow-degree profile.
- Relevant exact source rules are displayed alongside each pair; their extra
  IF clauses are evaluated rather than discarded. C64 is not matched merely
  because Venus is 4th; it also checks the D1 seventh-lord condition.
- The 119 BNN-N sources do not define every dash glyph's semantics explicitly.
  The degree-trine rule uses a clearly named interpretation profile and
  exposes the positions/order to the astrologer for source-method review.
  Ambiguous OCR and calendar-transit-only predicates are *not* auto-asserted.
- Added regression tests for Venus fourth ages, C64 multi-clause checking,
  BNN-N trine order, and original source text immutability.
- Flutter and Dart SDK are not present in the local execution environment;
  unit tests and APK builds were not run here. Static tests and ZIP CRC should
  be rerun in the repository CI.
