# Annapurna Astro Vastu v1.4.253 — BNN 12 Bhava / Five Sub-tabs

This is a source update on v1.4.252, not a compiled APK.

- All 462 source rules stay in `assets/bnn/bnn_master_462.json` unchanged.
- 12 bhava cards. Each bhava has five interactive chips: Results, Yogas, Past, Present, Future (Telugu labels).
- Rule lookup uses outcome/topic text and explicit Jupiter-relative house conditions; one rule may be indexed under multiple relevant houses. **This is a browse/index mechanism, not a full IF-condition match**.
- BNN planetary bhavas use Jupiter's sign as house 1 per source BNN-BOOK-R-A01, not D1 Lagna by default.
- Candidate result matching is strictly limited to BNN N `FACTS_REQUIRED` simple natal planet chains whose listed planets share a sign. Sequence/aspects/timing and every OCR/REVIEW rule remain unverified; source library is distinct.
- Results, Yoga and period tabs have separate sections; unresolved transit/timing is **not labelled as a confirmed past/present/future event**.
- Tapping a result opens full source IF condition, natal planetary position, inspection instructions, evidence status, page and remedy.
- Hasta Samudrika remains unchanged as an empty tab. Other app source files retained.
- Tests added for Jupiter-relative houses, classification, and eligible preliminary matches.

Static packaging checks performed in this environment; Flutter SDK/Dart SDK unavailable, so flutter analyze/test/build APK **not run**. A GitHub Flutter build is required to verify compilation.
