# v1.4.232: KP judgement time chart + Jamakola UI integration audit

## Implemented
- Same selected event and Date of Judgement/Time/Place run through KP 1–249 Number Chart and independent KP Time Chart.
- Both apply the *existing preliminary* KP Cusp Sub-Lord house-evidence matching; result UI shows both, explicitly handles disagreement and missing signification.
- RP remains calculated from the actual judgement time chart, not from the number-defined cusp.
- Jamakola U & ARU bold, U cell double slashes, pink KAV alias for previously labelled Chatra; the underlying Chatra calculation is **not renamed to an independently validated GK Kavippu formula**.
- Eight Jama planet degree list, topic dropdown against the existing 74 sourced rules, labelled unimplemented topics retained as pending.
- Home banner logo displays centered with no crop (contain).

## NOT implemented / source gaps
- Tajik Prashna rule engine and cross-system (Jamakola+KP+Tajik) final deterministic adjudicator remain to be implemented. NO fake agreement score is emitted.
- Complete KP significators / Rahu-Ketu agency / Promise/Denial / Dasa-Bhukti-Antara / Transit event timing remain pending.
- Divya Chakshu Chatra-degree and GK Kavippu equivalence is not independently source-proven. The pink point is a USER-SELECTED DISPLAY ALIAS only.
- KP Time Chart and Horary Number are independent *different cusp geometries*; they are not interchangeable.
- Jamakola source base: 74 stored rules in prior ZIP. Absent topic rules are flagged pending, not invented from generic Bhava associations.
- Flutter SDK not available in this execution environment. This ZIP has NOT passed a real Flutter compile/build or APK device test.

## Validation
- Compare baseline archive file-by-file, preserve existing assets and rule databases.
- ZIP CRC test and count.
- Static checks for expected wiring, guardrails, render aliases, version and source annotations.
