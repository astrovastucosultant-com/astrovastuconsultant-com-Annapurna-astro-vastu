# KP v1.4.224 — Ruling Planets and Time Chart

Source: user's six Astro-secrets & KP books (Parts I–VI), prior structured KP rule notes.
Ruling Planets (judgement moment):
- 5 core factors in classical priority: Lagna Star Lord, Lagna Sign Lord, Moon Star Lord, Moon Sign Lord, Day Lord.
- Day Lord is based on local sunrise computed by Swiss Ephemeris using the selected time and place. If sunrise is unavailable, the day factor is explicitly withheld.
- Lagna Sub-Lord and Moon Sub-Lord are supplementary, not silently counted as extra classical RP votes.
- Nodes Rahu/Ketu are annotated with observed planetary star/sign representation; automatic inclusion as RP awaits specific agency/aspect tests.
- Duplicate core RP planets are counted, not displayed as independent events.

Interface:
- Separate Birth KP, Horary 1–249, Time Chart modes, so forms do not obscure all of the mobile screen.
- Time Chart accepts selected local date, time, UTC offset and question latitude/longitude; calculates independent KP planetary positions, 12 Placidus cusps and Ruling Planets.
- Horary mode actually renders 414-event search, number and OK, calculated Horary planet/cusp chart, preliminary assessment and judgement-time RP (distinct from number-defined first cusp).
- Rotation changes only presentation. Existing 555 Jaimini and 255 Varga data unchanged.

Known limits:
- Full 6-book significator/agency/relevant cusp promise, denial, dasha-bhukti-antara and event timing matching remain pending, so RP display is NOT a final prediction.
- Placidus geometry not supported at extreme latitudes beyond ±66.5° in existing app.
- No Flutter SDK was available in the authoring container: ZIP integrity and code structure checked, but release APK compile must be confirmed in GitHub Actions.
