# BNN v1.4.269 — conservative OCR-book natal IF evaluator

- The exact 462 source IF, THEN, status, and provenance in assets/bnn/bnn_master_462.json are unchanged.
- Newly added bnn_exact_if_engine.dart supports a deliberately strict subset of the 343 OCR_REVIEW predicates: full one-sign clauses, Jupiter-relative houses, two Jupiter-relative houses, explicit pair of signs, conjunction-only, retrograde and classical exaltation/debilitation.
- Entire IF must parse, not simply match a phrase. Transit, nakshatra, timing, conditional qualifiers and OCR ambiguities are unsupported, not guessed.
- Matching natal conditions are listed under a separate collapsed neutral-color section with ID, source warning and a tap-to-read source rule. No confirmed real-world event assertion; no green/pink before source verification and full timing validation.
- Original scanned PDF is not present in supplied ZIP or currently available files. This is a machine-check of the supplied OCR text, NOT a claim of page-by-page source verification.
- Flutter SDK not present here, therefore compile is not claimed.

- Automated strict-pattern inventory from the supplied catalog: 71 of 343 OCR_REVIEW rules syntactically evaluable; 272 await deeper predicates/source verification. Dart regression tests for anchored expressions and false-positive cases are provided.
