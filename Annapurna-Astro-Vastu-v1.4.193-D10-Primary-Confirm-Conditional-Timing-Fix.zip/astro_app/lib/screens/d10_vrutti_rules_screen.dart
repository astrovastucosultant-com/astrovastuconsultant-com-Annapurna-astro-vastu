import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../models/birth_data.dart';
import '../astrology/d10_vrutti_activation_service.dart';
import '../astrology/d10_vrutti_match_engine.dart';
import '../astrology/d10_display_order.dart';
import '../astrology/d10_vrutti_rule_registry.dart';
import '../astrology/d10_profession_registry.dart';
import '../astrology/d10_legacy_rule_link_service.dart';
import '../astrology/d10_career_service.dart';
import '../astrology/varga_service.dart';
import 'd10_legacy_profession_tile.dart';
import 'd10_career_reverse_screen.dart';
import 'd10_percent_visual.dart';
import '../astrology/d10_career_profit_loss_service.dart';
import 'd10_career_profit_loss_screen.dart';

/// D10 → profession IF–THEN evidence screen.  The result tile itself opens
/// the birth-chart assessment, source rule and evidence breakdown.
class D10VruttiRulesScreen extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  const D10VruttiRulesScreen({super.key, required this.chart, required this.birthData});

  @override
  State<D10VruttiRulesScreen> createState() => _D10VruttiRulesScreenState();
}

class _D10VruttiRulesScreenState extends State<D10VruttiRulesScreen> {
  String _category = 'అన్ని రంగాలు';
  // 0 = all 517 entries, 1 = primary-planet confirmed, 2 = IF-THEN, 3 = original 181.
  int _viewMode = 0;
  String _query = '';
  late final List<D10VruttiMatch> _matches =
      D10VruttiMatchEngine.evaluate(widget.chart);
  final Map<String, Future<List<D10VruttiActivation>>> _activationTasks = {};
  final Map<String, Future<List<D10VruttiActivation>>> _historyTasks = {};
  final Map<String, List<D10VruttiActivation>> _activationResults = {};
  bool _loadingRecommended = false;

  late final Map<String, List<D10VruttiMatch>> _linkedLegacy = {
    for (final rule in d10ProfessionRules)
      rule.id: D10LegacyRuleLinkService.matchingRules(rule, _matches),
  };

  Future<List<D10VruttiActivation>> _activationFor(D10VruttiMatch item) {
    if (!item.mayCheckConditionalTiming) {
      return Future.value(const <D10VruttiActivation>[]);
    }
    return _activationTasks.putIfAbsent(item.rule.id, () async {
      final result = await D10VruttiActivationService.findWindows(
        chart: widget.chart,
        birthData: widget.birthData,
        rule: item.rule,
        // Only the MAIN planet is needed to search for conditional timing.
        // The UI must NOT call these windows a full profession prediction.
        professionConfirmed: item.primaryPlanetConfirmed,
      );
      if (mounted) setState(() => _activationResults[item.rule.id] = result);
      return result;
    });
  }

  Future<List<D10VruttiActivation>> _historyFor(D10VruttiMatch item) {
    if (!item.mayCheckConditionalTiming) {
      return Future.value(const <D10VruttiActivation>[]);
    }
    return _historyTasks.putIfAbsent(item.rule.id, () =>
        D10VruttiActivationService.findHistoricalWindows(
          chart: widget.chart,
          birthData: widget.birthData,
          rule: item.rule,
          professionConfirmed: item.primaryPlanetConfirmed,
        ));
  }

  String _monthYear(DateTime value) => '${value.month.toString().padLeft(2, '0')}/${value.year}';

  Widget _windowDetails(List<D10VruttiActivation> windows) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      for (final w in windows)
        Card(child: Padding(
          padding: const EdgeInsets.all(9),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('సుమారు ${w.ageYears} ఏళ్ల వయసు · '
                '${_monthYear(w.month)}${w.supportedMonths > 1 ? ' → ${_monthYear(w.endMonth)}' : ''}'
                ' · ${w.supportedMonths} నెలల కాలమద్దతు',
                style: const TextStyle(fontWeight: FontWeight.w800)),
            Text('మహాదశ ${w.mahadasha} / అంతర్దశ ${w.antardasha}'),
            if (w.supportedMonths > 1)
              const Text('ఈ కాలంలో ప్రతి నెల 15న పరీక్షించారు; దిగువ గ్రహరాశుల వివరాలు '
                  'ప్రారంభ నెల నమూనా మాత్రమే.', style: TextStyle(fontSize: 12)),
            for (final line in w.evidence)
              Text('• $line', style: const TextStyle(fontSize: 12.5)),
          ]),
        )),
    ],
  );

  Future<void> _loadRecommendedAges() async {
    if (_loadingRecommended) return;
    setState(() => _loadingRecommended = true);
    try {
      final candidates = _matches.where((m) => m.confirmed && m.complete).take(8);
      for (final item in candidates) {
        if (!mounted) break;
        await _activationFor(item);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('గోచార గణన అందుబాటులో లేదు: $e'),
        ));
      }
    } finally {
      if (mounted) setState(() => _loadingRecommended = false);
    }
  }


  void _showDetail(D10VruttiMatch item, {D10ProfessionRule? legacy,
      List<D10VruttiMatch> alternatives = const <D10VruttiMatch>[]}) {
    final primary = item.rule.planets.isEmpty ? null : item.rule.planets.first;
    final natalHouse = primary == null ? null :
        D10CareerService.d1House(widget.chart, primary);
    final d10 = VargaService.calculate(widget.chart, 10);
    final vargaHouse = primary == null ? null :
        D10CareerService.vargaHouse(d10, primary);
    final moneyAudit = D10CareerProfitLossService.evaluate(widget.chart, item);
    showModalBottomSheet<void>(
      context: context, isScrollControlled: true,
      builder: (context) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: .80,
          child: ListView(padding: const EdgeInsets.all(18), children: [
            if (legacy != null) ...[
              Text('${legacy.id} · ${legacy.name}',
                  style: Theme.of(context).textTheme.titleLarge),
              Text('ఈ పాత వృత్తితో అనుసంధానమైన మూల IF–THEN: ${item.rule.id}'),
              Text('ప్రధాన గ్రహం: ${primary ?? 'డేటా లేదు'} · '
                  'D1 భావం ${natalHouse ?? '-'} · D10 భావం ${vargaHouse ?? '-'}'),
              const SizedBox(height: 8),
            ],
            Text('${item.rule.id} · ${item.rule.profession}',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Text(item.confirmed
                ? 'జాతక ఆధారాల సరిపోలిక: ${D10PercentVisual.percentLabel(item.confirmed, item.percent)}${item.complete ? '' : ' (పాక్షిక పరీక్ష)'}'
                : 'D1 → D10 Confirm లేదు • అనుకూలత % ఇవ్వలేదు',
                style: TextStyle(fontWeight: FontWeight.bold,
                  color: D10PercentVisual.foreground(item.confirmed))),
            Text(item.confirmationLabel),
            if (item.partialRuleMatched)
              Text('ఉపషరతులు: సరిపోయినవి ${item.passed.length}, '
                  'సరిపోనివి ${item.failed.length}, '
                  'పెండింగ్ ${item.pending.length}. '
                  'ఈ ${item.percent}% పూర్తి వృత్తి నిర్ధారణ కాదు.'),
            const Divider(),
            const Text('వృత్తి లాభం / నష్టం / మధ్యస్థ పరిశీలన',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 6),
            Text(moneyAudit.evaluated
                ? '${moneyAudit.tone.label} · లాభ ఆధారాలు ${moneyAudit.gainSupport} · '
                    'వ్యయ/ప్రమాద ఆధారాలు ${moneyAudit.riskSupport}'
                : 'లాభనష్ట పరీక్షించలేదు (0 కాదు) · ${item.confirmationLabel}',
                style: TextStyle(fontWeight: FontWeight.bold,
                  color: moneyAudit.tone == D10MoneyTone.gain ? Colors.green.shade800
                    : moneyAudit.tone == D10MoneyTone.risk ? Colors.red.shade800
                    : Colors.blueGrey)),
            const Text('వృత్తి అనుకూలత % వేరు; లాభనష్ట ఆధారాలు వేరు.'),
            OutlinedButton.icon(
              icon: const Icon(Icons.account_balance_wallet_outlined),
              label: const Text('లాభం / నష్టం / మధ్యస్థం · సంవత్సరాలవారీగా'),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => D10CareerProfitLossScreen(
                  chart: widget.chart, birthData: widget.birthData, match: item))),
            ),
            const Divider(),
            const Text('వృత్తి యాక్టివేషన్ — గతం / భవిష్యత్తు',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 6),
            const Text('జాతక షరతుల అనుకూలత % మరియు వృత్తి ప్రారంభకాలం రెండు వేర్వేరు పరీక్షలు. '
                'కాలమద్దతు లేకపోయినా 100% చార్ట్-రూల్ సరిపోలిక రావచ్చు.'),
            if (!item.primaryPlanetConfirmed)
              const Text('ప్రధాన గ్రహ D1→D10 Confirm లేదు. ఈ మూల నియమానికి '
                  'వృత్తి కాలమద్దతు లెక్కించరు.'),
            if (item.partialRuleMatched)
              const Text('⚠️ ప్రధాన గ్రహ Confirm ఉంది; కానీ పూర్తి మూల IF–THEN '
                  'సరిపోలలేదు. దిగువ కాలాలు దశ–అంతర్దశ–గోచారంతో కనిపించే '
                  'పాక్షిక కాలమద్దతు మాత్రమే. ఈ వృత్తి ప్రారంభ వయసు కాదు.'),
            if (item.mayCheckConditionalTiming) ...[
              const SizedBox(height: 8),
              Text(item.fullRuleMatched
                  ? 'గత కాలమద్దతు — 16వ వయసు నుంచి ఇప్పటివరకు'
                  : 'గత పాక్షిక కాలమద్దతు — 16వ వయసు నుంచి ఇప్పటివరకు',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              FutureBuilder<List<D10VruttiActivation>>(
                future: _historyFor(item),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Text('గత గోచార గణనలో సమస్య: ${snapshot.error}');
                  }
                  if (!snapshot.hasData) {
                    return const ListTile(
                      leading: CircularProgressIndicator(),
                      title: Text('గత దశ–అంతర్దశ–గోచార కాలాలు పరీక్షిస్తోంది…'),
                    );
                  }
                  if (snapshot.data!.isEmpty) {
                    return const Text('గతకాలంలో నాలుగు ఆధారాలూ కలిసిన నెల గుర్తించలేదు. '
                        'దీనివల్ల ఆ వృత్తి గతంలో జరగలేదని నిర్ధారించలేం.');
                  }
                  return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    _windowDetails(snapshot.data!),
                    const Text('ఇవి గతకాల జ్యోతిష కాలమద్దతు సూచనలు మాత్రమే. '
                        'వాస్తవంగా వృత్తి ప్రారంభమైన తేదీని Career Timelineలో నమోదు చేసి '
                        'BTRలో విడిగా పరిశీలించాలి.',
                        style: TextStyle(fontSize: 12)),
                  ]);
                },
              ),
              const SizedBox(height: 10),
              Text(item.fullRuleMatched
                  ? 'రాబోయే 20 సంవత్సరాల కాలమద్దతు'
                  : 'రాబోయే 20 సంవత్సరాల పాక్షిక కాలమద్దతు',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              FutureBuilder<List<D10VruttiActivation>>(
                future: _activationFor(item),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Text('భవిష్య గోచార గణనలో సమస్య: ${snapshot.error}');
                  }
                  if (!snapshot.hasData) {
                    return const ListTile(
                      leading: CircularProgressIndicator(),
                      title: Text('మహాదశ–అంతర్దశ + గురు–శని గోచారం పరిశీలిస్తోంది…'),
                    );
                  }
                  if (snapshot.data!.isEmpty) {
                    return const Text('రాబోయే 20 సంవత్సరాలలో ఈ కఠినమైన నాలుగు-ఆధారాల '
                        'పరీక్షకు సరిపోయే నెల గుర్తించలేదు. ఇది వృత్తి అవకాశం '
                        'లేదనే తీర్పు కాదు.');
                  }
                  return _windowDetails(snapshot.data!);
                },
              ),
              const Text('గోచారం నెల 15న నమూనా గణన. సూచించిన వయసు/నెల '
                  'ఖచ్చిత నియామక తేదీ కాదు.', style: TextStyle(fontSize: 12)),
            ],
            const Divider(),
            OutlinedButton.icon(
              icon: const Icon(Icons.history),
              label: const Text('నిజంగా జరిగిన వృత్తి సంఘటన నమోదు / పోలిక · BTR'),
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => D10CareerReverseScreen(
                  chart: widget.chart, birthData: widget.birthData,
                  initialOccupation: item.rule.profession,
                  initialRuleId: item.rule.id))),
            ),
            const Divider(),
            const Text('జాతక పరిశీలన',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 6),
            for (final evidence in item.passed)
              ListTile(dense: true, leading: const Icon(Icons.check_circle_outline,
                  color: Colors.green), title: Text(evidence)),
            for (final reason in item.failed)
              ListTile(dense: true, leading: const Icon(Icons.cancel_outlined,
                  color: Colors.redAccent), title: Text(reason)),
            for (final reason in item.pending)
              ListTile(dense: true, leading: const Icon(Icons.info_outline,
                  color: Colors.orange), title: Text(reason)),
            const Divider(),
            const Text('మూల IF–THEN రూల్',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 6),
            SelectableText('IF ${item.rule.condition}\nTHEN ${item.rule.profession}',
                style: const TextStyle(height: 1.5)),
            Text('మూలం: ${item.rule.source} · పేజీ ${item.rule.page}',
                style: const TextStyle(color: Colors.black54)),
            if (alternatives.length > 1) ...[
              const SizedBox(height: 10),
              const Text('అదే పాత వృత్తికి ఇతర మూల IF–THEN సూత్రాలు:',
                  style: TextStyle(fontWeight: FontWeight.w700)),
              for (final other in alternatives)
                if (other.rule.id != item.rule.id)
                  Padding(padding: const EdgeInsets.symmetric(vertical: 5),
                    child: SelectableText(
                      '${other.rule.id} · IF ${other.rule.condition} '
                      'THEN ${other.rule.profession} '
                      '(${other.rule.source}, పేజీ ${other.rule.page}). '
                      '${other.confirmed ? other.complete ? 'పూర్తి షరతులు సరిపోయాయి' : 'పాక్షిక ఆధారాలు' : 'D1→D10 Confirm లేదు'}')),
            ],
            const SizedBox(height: 12),
            const Text('శాతం = అందుబాటులో ఉన్న జ్యోతిష షరతుల సరిపోలిక మాత్రమే. '
                'వృత్తిలో విజయం లేదా నియామకం జరిగే సంభావ్యత కాదు.'),
          ]),
        ),
      ),
    );
  }

  Widget _resultTile(D10VruttiMatch item) =>
      Card(
        color: D10PercentVisual.tierBackground(D10DisplayOrder.tier(item)),
        child: ListTile(
          title: Text.rich(TextSpan(children: [
            TextSpan(text: '${item.rule.profession}  •  '),
            TextSpan(
              text: D10PercentVisual.percentLabel(item.confirmed, item.percent),
              style: TextStyle(color: D10PercentVisual.foreground(item.confirmed),
                fontWeight: FontWeight.w900)),
          ]), style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${item.rule.id} · ${item.rule.category} · '
              '${item.fullRuleMatched ? 'పూర్తి IF–THEN సరిపోయింది' : item.partialRuleMatched ? 'ప్రధాన గ్రహ Confirm · పూర్తి రూల్ పెండింగ్' : D10DisplayOrder.tier(item) == D10EvidenceTier.pink ? 'పాక్షిక సూచనలు · Confirm లేదు' : 'Confirm లేదు'}'
              '${!item.primaryPlanetConfirmed ? ' · వయసు నిర్ధారణ లేదు' : _activationResults.containsKey(item.rule.id) ? (_activationResults[item.rule.id]!.isNotEmpty ? ' · సుమారు ${_activationResults[item.rule.id]!.first.ageYears} ఏళ్ల ${item.fullRuleMatched ? 'కాలమద్దతు' : 'పాక్షిక కాలమద్దతు'}' : ' · కాలమద్దతు కనిపించలేదు') : ' · ${item.fullRuleMatched ? 'వయసు' : 'పాక్షిక కాలమద్దతు'} చూడటానికి టచ్'}'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showDetail(item),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final cats = <String>{'అన్ని రంగాలు',
      ...d10VruttiRulebook.map((r) => r.category),
      ...d10ProfessionRules.map((r) => r.category)}.toList();
    final confirmed = _matches.where((m) => m.confirmed).toList();
    final fullyConfirmed = _matches.where((m) => m.complete && m.confirmed).toList();
    final entries = (_viewMode == 3 ? <D10VruttiMatch>[] :
        _viewMode == 1 ? confirmed : _matches).where((item) {
      return (_category == 'అన్ని రంగాలు' || item.rule.category == _category) &&
          (_query.isEmpty || item.rule.profession.contains(_query) ||
           item.rule.condition.contains(_query));
    }).toList();
    final legacyEntries = (_viewMode == 0 || _viewMode == 3)
        ? d10ProfessionRules.where((r) =>
            (_category == 'అన్ని రంగాలు' || r.category == _category) &&
            (_query.isEmpty || r.name.contains(_query) ||
                r.extra.contains(_query))).toList()
        : <D10ProfessionRule>[];
    // One ordered stream across IF-THEN and older records. Separating the
    // two lists used to bury confirmed green entries below older records.
    final orderedEntries = D10DisplayOrder.sort(<D10DisplayEntry>[
      for (final match in entries) D10DisplayEntry.rule(match),
      for (final old in legacyEntries)
        D10DisplayEntry.old(old, _linkedLegacy[old.id] ?? const <D10VruttiMatch>[]),
    ]);
    final coloredCounts = <D10EvidenceTier, int>{
      D10EvidenceTier.green: 0, D10EvidenceTier.pink: 0,
      D10EvidenceTier.grey: 0,
    };
    for (final item in orderedEntries) {
      coloredCounts[item.tier] = coloredCounts[item.tier]! + 1;
    }
    final cards = <Widget>[];
    D10EvidenceTier? lastTier;
    for (final item in orderedEntries) {
      if (item.tier != lastTier) {
        lastTier = item.tier;
        final label = item.tier == D10EvidenceTier.green
            ? '🟢 గ్రీన్ — Confirm + అనుకూలత % (ఎక్కువ నుంచి తక్కువకు)'
            : item.tier == D10EvidenceTier.pink
                ? '🩷 పింక్ — పాక్షిక ఆధారాలు / మూల నియమం పెండింగ్'
                : '⚪ గ్రే — నిర్ధారణ లేని వృత్తులు';
        cards.add(Padding(
          padding: const EdgeInsets.fromLTRB(4, 14, 4, 8),
          child: Text('$label · ${coloredCounts[item.tier]}',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15,
              color: D10PercentVisual.tierForeground(item.tier))),
        ));
      }
      if (item.ruleMatch != null) {
        cards.add(_resultTile(item.ruleMatch!));
      } else {
        final old = item.legacy!;
        cards.add(D10LegacyProfessionTile(
          rule: old, chart: widget.chart,
          linkedRules: item.linked,
          onOpenMatchedRule: (match) => _showDetail(match,
              legacy: old, alternatives: item.linked),
        ));
      }
    }

    return Scaffold(
      appBar: AppBar(title: const Text('D10 — వృత్తి IF–THEN & అనుకూలత %'),
        actions: [IconButton(tooltip: 'వృత్తి Reverse Search & BTR',
          icon: const Icon(Icons.manage_search),
          onPressed: () => Navigator.push(context, MaterialPageRoute<void>(
            builder: (_) => D10CareerReverseScreen(chart: widget.chart,
              birthData: widget.birthData))),
        )]),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        const Text('ప్రతి వృత్తికి D1 10వ గ్రహం → D10 1/10/10వ అధిపతి confirm, '
            'అంశ దేవత, గ్రహ సంబంధాలు, భావాలు, శని విధానం వేరుగా పరీక్షించబడతాయి.',
            style: TextStyle(height: 1.4)),
        const SizedBox(height: 8),
        Text('IF–THEN ${_matches.length} + పాత D10 ${d10ProfessionRules.length} '
            '= ${_matches.length + d10ProfessionRules.length} మొత్తం నమోదులు · '
            'Confirm ఆధారాలు ఉన్నవి: ${confirmed.length} · పూర్తి షరతులు: ${fullyConfirmed.length}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        Text('పాత నమోదుల్లో IF–THEN లింక్: '
            '${_linkedLegacy.values.where((r) => r.isNotEmpty).length} · '
            'ఇంకా లింక్ లేనివి: ${_linkedLegacy.values.where((r) => r.isEmpty).length}',
            style: const TextStyle(fontSize: 12.5)),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () => Navigator.push(context, MaterialPageRoute<void>(
            builder: (_) => D10CareerReverseScreen(chart: widget.chart,
              birthData: widget.birthData))),
          icon: const Icon(Icons.search),
          label: const Text('ప్రస్తుతం చేస్తున్న వృత్తి వెతకండి · Career Timeline · BTR')),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: fullyConfirmed.isEmpty || _loadingRecommended ? null : _loadRecommendedAges,
          icon: _loadingRecommended
              ? const SizedBox(width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.calendar_month_outlined),
          label: Text(_loadingRecommended
              ? 'మొదటి 8 అనుకూల వృత్తుల వయసు పరిశీలిస్తోంది…'
              : 'అనుకూల వృత్తుల యాక్టివేషన్ వయసు చూడండి'),
        ),
        const SizedBox(height: 8),
        const ExpansionTile(
          title: Text('D10 పది అంశదేవతల క్రమం & గ్రహ పదాల వివరణ'),
          children: [
            ListTile(title: Text('బేసి రాశులు: ఇంద్ర, అగ్ని, యమ, రాక్షస, వరుణ, వాయు, కుబేర, ఈశాన, బ్రహ్మ, అనంత.')),
            ListTile(title: Text('సరి రాశులు: అనంత, బ్రహ్మ, ఈశాన, కుబేర, వాయు, వరుణ, రాక్షస, యమ, అగ్ని, ఇంద్ర.')),
            ListTile(title: Text('మూల PDFలో సూర్య దేవత = సూర్యుడు, శుక్ర దేవత = శుక్రుడు; ఇవి పదకొండో, పన్నెండో అంశదేవతలు కావు.')),
          ],
        ),
        const SizedBox(height: 8),
        Wrap(spacing: 7, runSpacing: 5, children: [
          ChoiceChip(label: Text('అన్ని (${_matches.length + d10ProfessionRules.length})'),
              selected: _viewMode == 0,
              onSelected: (_) => setState(() => _viewMode = 0)),
          ChoiceChip(label: Text('అనుకూల (${confirmed.length})'),
              selected: _viewMode == 1,
              onSelected: (_) => setState(() => _viewMode = 1)),
          ChoiceChip(label: Text('IF–THEN (${_matches.length})'),
              selected: _viewMode == 2,
              onSelected: (_) => setState(() => _viewMode = 2)),
          ChoiceChip(label: Text('పాత వృత్తులు (${d10ProfessionRules.length})'),
              selected: _viewMode == 3,
              onSelected: (_) => setState(() => _viewMode = 3)),
        ]),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _category,
          isExpanded: true,
          decoration: const InputDecoration(
              labelText: 'వృత్తి రంగం', border: OutlineInputBorder()),
          items: cats.map((c) => DropdownMenuItem<String>(
              value: c, child: Text(c, overflow: TextOverflow.ellipsis)))
              .toList(),
          onChanged: (v) => setState(() => _category = v ?? 'అన్ని రంగాలు'),
        ),
        const SizedBox(height: 8),
        TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search),
              hintText: 'వృత్తి పేరు / IF–THEN షరతు వెతకండి',
              border: OutlineInputBorder()),
          onChanged: (v) => setState(() => _query = v.trim()),
        ),
        const SizedBox(height: 8),
        if (_viewMode == 1 && confirmed.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(14),
            child: Text('ప్రధాన గ్రహ Confirm ఉన్న వృత్తి ఇప్పటికి లేదు. '
                'కానీ పాత నియమాలను తొలగించలేదు — అన్ని / పాత వృత్తులు చూడండి.'))),
        ...cards,
        if (entries.isEmpty && legacyEntries.isEmpty &&
            !(_viewMode == 1 && confirmed.isEmpty))
          const Padding(padding: EdgeInsets.all(14),
              child: Text('ఈ ఫిల్టర్‌లో ఏ వృత్తీ లేదు. అన్ని ట్యాబ్‌కు మార్చండి.')),
        const SizedBox(height: 12),
        const Text('వృత్తి అనుకూలత % మరియు కాలనిర్ణయం వేరు. కాలానికి ప్రధాన గ్రహం–వింశోత్తరి '
            'మహాదశ–అంతర్దశ–గురు/శని గోచారం ఒకే నెలలో కలిసినప్పుడు మాత్రమే సుమారు వయసు చూపిస్తాము.'),
        const SizedBox(height: 8),
        const Text('క్రమం: గ్రీన్ — D1→D10 Confirm ఉన్న వృత్తులకు ఎంత % వచ్చినా ముందుగా (ఎక్కువ నుంచి తక్కువకు); '
            'పింక్ — పాక్షిక సూచనలు / పాత మూల IF–THEN పెండింగ్; '
            'గ్రే — నిర్ధారణ లేనివి చివరలో. పింక్, గ్రేలకు కల్పిత % ఇవ్వరు.',
            style: TextStyle(color: D10PercentVisual.green)),
        const SizedBox(height: 6),
        const Text('గమనిక: 100% అంటే నియమాల షరతులు పూర్తిగా సరిపోయాయని మాత్రమే. '
            'ఇది ఉద్యోగం/వ్యాపారం విజయ శాతం కాదు. మూల రూల్‌లోని ఒకే '
            'సూర్యుడు లేదా శుక్రుడు రెండుసార్లు లెక్కించబడరు.',
            style: TextStyle(color: Colors.black54)),
      ]),
    );
  }
}
