ANNAPURNA ASTRO VASTU v1.4.438 — PAST EVENT RANKING PRECISION

Issue discovered from v1.4.437 UI audit:
- 2008 marriage appears but other candidate years compete.
- Child 2010/2011 and first employment 2004 may not rank in the top three.
- Previous scoring aggregated unrelated year-wide contacts, so many aspects across
  January through December could artificially inflate a candidate year.

Fixes:
- Preserve individual month sightings for each (method,mover,target,aspect).
- For EACH year choose its strongest three-month candidate window, including
  window edges crossing adjacent calendar years.
- Deduplicate one target per calculation METHOD for primary/core scoring.
- Require two methods + two targets + >=2 core observations for the stronger
  supporting-evidence label; ranking remains NON-probabilistic.
- Display the localized three-month window, event-specific label, plus a
  disclosure for more candidate years beyond the top five.
- Tapping year for detailed analysis opens the window, not a disconnected
  January-to-December generic search.
- No historical event dates used as inputs or to force specific results.
- Transit toggle and original Placidus tropical-only source engine preserved.

Limitations:
- Monthly 15th day samples can miss short orb windows.
- This improves ranking discrimination, NOT proof of marriage, childbirth,
  first child, or first job. No scored probability can be claimed.
- Exact match against a personal chart needs LIVE Flutter/Swiss Ephemeris run.
- Note when current year is in the past-year UI: a window crossing into a
  future period still requires operator review before interpreting.

Validation: zip integrity and static patch/file checks; Flutter unit tests
and release compile must be run in GitHub Actions.
