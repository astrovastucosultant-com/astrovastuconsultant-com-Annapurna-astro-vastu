ANNAPURNA v1.4.439 — WESTERN PAST EVENT EVIDENCE TIERS

Scope: Retrospective candidate years for marriage/partnership, child/family event, career/work start.

1. Only 1 selected Western method? Show an explicit insufficiency warning. Do NOT silently toggle user preferences.
2. Independent-support tier: >=2 core contacts in same 3-month window, >=2 timing methods and >=2 natal targets.
3. Rank independent-support candidates ahead of single-method years.
4. Separate corroborated candidates from exploratory/single-method contact years; initially show at most 5 / 2 respectively.
5. Keep every candidate expandable to source rule, aspects, method, orb and daily-review action.

No claim of an event that occurred, first child, first job, or statistical confidence.
No backfitting to known birth/marriage/job dates. Original v438 rule source and age filters retained.

Static checks only in current environment. Flutter test and release build to run via GitHub Actions.
