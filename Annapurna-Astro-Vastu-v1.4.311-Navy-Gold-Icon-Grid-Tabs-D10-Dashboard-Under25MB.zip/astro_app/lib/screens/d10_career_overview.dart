import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../models/birth_data.dart';
import '../astrology/ashtakavarga_service.dart';
import '../astrology/ashtakavarga_three_stage_service.dart';
import '../astrology/ashtakavarga_pav_career_service.dart';
import '../astrology/d10_pav_transit_career_service.dart';
import '../astrology/d10_varga_ashtakavarga_service.dart';
import '../astrology/d10_career_comparison_service.dart';
import '../astrology/d10_career_decision_service.dart';
import '../astrology/varga_master_inspection_service.dart';
import '../astrology/d10_career_service.dart';
import '../astrology/d10_career_year_service.dart';
import '../astrology/d10_business_catalog.dart';
import '../astrology/d10_final_profession_engine.dart';
import '../astrology/varga_rule_service.dart';
import '../astrology/varga_service.dart';
import 'astro_icon_dashboard.dart';

/// Build 76: dynamic D1→D10 work-mode flow with transformed profession results.
/// No chart values, professions, or years are fabricated in the UI.
class D10CareerOverview extends StatelessWidget {
  final AstroChartResult chart;
  final DateTime birthDateTime;
  final BirthData birthData;
  final List<VargaRuleHit> rules;
  final ValueChanged<VargaRuleHit> onRuleTap;

  const D10CareerOverview({
    super.key,
    required this.chart,
    required this.birthDateTime,
    required this.birthData,
    required this.rules,
    required this.onRuleTap,
  });

  static bool isYoga(VargaRuleHit hit) =>
      hit.ruleId.startsWith('D10-VRY-') ||
      hit.ruleId.startsWith('D10-R6.') ||
      hit.ruleId == 'D10-RAJAYOGA' ||
      hit.ruleId == 'D10-MAHABHAGYA' ||
      hit.topic.contains('యోగ') ||
      hit.topic.toLowerCase().contains('yoga');

  static const _maroon = Color(0xFF812536);
  static const _ink = Color(0xFF2B2325);

  Widget _panel({
    required Widget child,
    Color color = const Color(0xFFFFFAF0),
  }) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        color: color,
        surfaceTintColor: Colors.transparent,
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), child: child),
      );

  String _labelForState(String value) => switch (value) {
        'GOCHARASHTHA' => 'గోచరిస్తా — వ్యాపారం / స్వయం ఉపాధి',
        'AGOCHARASHTHA' => 'అగోచరిస్తా — ఉద్యోగం / సర్వీస్',
        _ => 'మిశ్రమం / నిర్ధారణ కావాలి',
      };

  String _businessTitle(String source) => switch (source) {
        'Engineering / Technical' => 'ఇంజినీరింగ్ ప్రాజెక్టులు / సర్వీసులు',
        'IT / Software / Data' => 'సాఫ్ట్‌వేర్ / ఐటీ సంస్థ',
        'Manufacturing / Industry / Skilled Technical Work' => 'తయారీ పరిశ్రమ / టెక్నికల్ వర్క్‌షాప్',
        'Banking / Finance' => 'ఆర్థిక సలహా / ఆర్థిక సేవల సంస్థ',
        'Teaching / Education' => 'శిక్షణ సంస్థ / విద్యా సేవలు',
        'Accounting / Audit / Tax' => 'అకౌంటింగ్ / టాక్స్ కన్సల్టెన్సీ',
        'Medicine / Healthcare' => 'ఆరోగ్య సేవల కేంద్రం (అర్హతకు లోబడి)',
        'Agriculture / Environment / Natural Resources' => 'వ్యవసాయ వ్యాపారం / సేవలు',
        'Occult / Astrology / Traditional Studies' => 'జ్యోతిష్య / సంప్రదాయ సలహా సేవలు',
        'Consulting / Advisory' => 'స్వతంత్ర కన్సల్టెన్సీ',
        'Commercial / Business / Entrepreneurship' => 'వర్తకం / స్వంత వ్యాపారం',
        'Government / Administration' => 'పరిపాలనా కన్సల్టెన్సీ / కాంట్రాక్ట్ సేవలు',
        'Law / Judiciary / Compliance' => 'లీగల్ / కంప్లయన్స్ ప్రాక్టీస్ (అర్హతకు లోబడి)',
        _ => '$source — స్వయం ఉపాధి / సంస్థ',
      };

  String _jobTitle(String source) => switch (source) {
        'Engineering / Technical' => 'ఇంజినీర్ / టెక్నికల్ ఉద్యోగం',
        'IT / Software / Data' => 'సాఫ్ట్‌వేర్ / ఐటీ ఉద్యోగం',
        'Manufacturing / Industry / Skilled Technical Work' => 'పరిశ్రమ / టెక్నీషియన్ ఉద్యోగం',
        'Banking / Finance' => 'బ్యాంక్ / ఫైనాన్స్ ఉద్యోగం',
        'Teaching / Education' => 'ఉపాధ్యాయ / విద్యా సంస్థ ఉద్యోగం',
        'Accounting / Audit / Tax' => 'అకౌంట్స్ / ఆడిట్ ఉద్యోగం',
        'Medicine / Healthcare' => 'ఆరోగ్యరంగ ఉద్యోగం (అర్హతకు లోబడి)',
        'Government / Administration' => 'ప్రభుత్వ / పరిపాలనా సర్వీస్',
        'Defence / Police / Security' => 'రక్షణ / పోలీస్ / భద్రతా సర్వీస్',
        'Consulting / Advisory' => 'సలహాదారు / కన్సల్టింగ్ ఉద్యోగం',
        'Occult / Astrology / Traditional Studies' => 'జ్యోతిష్య / సంప్రదాయ అధ్యయన సంస్థలో పని',
        _ => '$source — ఉద్యోగం / సర్వీస్',
      };

  Widget _professionGroup({
    required bool isBusiness,
    required bool active,
    required bool isCurrentD10Mode,
    required String stageLabel,
    required List<D10ProfessionCandidate> candidates,
    required D10FinalProfessionResult engine,
    required List<VargaRuleHit> modeRules,
    required VargaRuleHit? source,
  }) {
    final title = isBusiness
        ? '1. గోచరిస్తా — Business / Self Employment'
        : '2. అగోచరిస్తా — Job / Service';
    final modeState = isBusiness ? 'GOCHARASHTHA' : 'AGOCHARASHTHA';
    return _panel(
      color: active ? const Color(0xFFECF7EF) : const Color(0xFFFFF8EA),
      child: ExpansionTile(
        key: PageStorageKey<String>(isBusiness ? 'd10-business' : 'd10-job'),
        tilePadding: EdgeInsets.zero,
        initiallyExpanded: false,
        leading: Icon(
          isBusiness ? Icons.storefront_outlined : Icons.badge_outlined,
          color: active ? const Color(0xFF1A794A) : const Color(0xFF8C671E),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: _ink)),
        subtitle: Text(active
            ? '$stageLabel${isCurrentD10Mode ? ' • D10 current/final mode' : ''}'
            : 'ఈ chart flowలో ఈ విధానం ప్రస్తుతం ప్రధానంగా match కాలేదు.'),
        children: [
          if (!active)
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text('ఈ విధానం ప్రధానంగా నిర్ధారణ కాలేదు. క్రింది రంగాల జాబితా '
                'D10 10వ అధిపతి–నక్షత్రం–రాశి మూల ఆధారాలపై మాత్రమే; '
                'వ్యాపారం/ఉద్యోగం తప్పక చేయాలనే తీర్పు కాదు.'),
            ),
          if (candidates.isEmpty)
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text('ఇంకా profession family evidence అందుబాటులో లేదు.'),
            ),
          for (final candidate in candidates.take(6))
              ListTile(
                contentPadding: EdgeInsets.zero,
                dense: false,
                leading: const Icon(Icons.chevron_right, size: 22, color: _maroon),
                title: Text(
                  isBusiness ? _businessTitle(candidate.profession) : _jobTitle(candidate.profession),
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
                subtitle: Text(
                  '${candidate.profession} • ${candidate.evidenceMatchPercent}% evidence match\n'
                  'నక్షత్రం: ${engine.nakshatraName} (${engine.nakshatraLord}) • '
                  'అంశ దేవత: ${engine.amshaDevata.deity} • అవస్థ: ${engine.balaadi.state}\n'
                  '${D10FinalProfessionEngine.professionNarrative(result: engine, candidate: candidate, modeState: modeState)}',
                  style: const TextStyle(height: 1.35),
                ),
                onTap: source == null ? null : () => onRuleTap(source),
              ),
          if (isBusiness && candidates.isNotEmpty) ...[
            const Divider(),
            const Align(alignment: Alignment.centerLeft,
              child: Text('అనుకూల వ్యాపారాల ఉదాహరణ జాబితా',
                style: TextStyle(fontWeight: FontWeight.w800, color: _maroon))),
            for (final idea in D10BusinessCatalog.suggest(candidates).take(8))
              ListTile(
                dense: true, contentPadding: EdgeInsets.zero,
                title: Text(idea.nameTe),
                subtitle: Text('${idea.professionFamily} • రంగ ఆధారం మాత్రమే'),
                onTap: source == null ? null : () => onRuleTap(source),
              ),
          ],
          if (isCurrentD10Mode && modeRules.isNotEmpty) ...[
            const Divider(height: 22),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'ఈ D10 విధానంలో కలిసే ఇతర వృత్తి అంశాలు',
                style: TextStyle(fontWeight: FontWeight.w900, color: _maroon),
              ),
            ),
            const SizedBox(height: 4),
            for (final rule in modeRules)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: Icon(
                  rule.tone == VargaRuleTone.caution
                      ? Icons.warning_amber_outlined
                      : Icons.check_circle_outline,
                  color: rule.tone == VargaRuleTone.caution
                      ? const Color(0xFFB3261E)
                      : const Color(0xFF1A794A),
                ),
                title: Text(rule.topic, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(rule.result, maxLines: 4, overflow: TextOverflow.ellipsis),
                trailing: const Text('ఫలితం', style: TextStyle(fontWeight: FontWeight.w800, color: _maroon)),
                onTap: () => onRuleTap(rule),
              ),
          ],
          const Padding(
              padding: EdgeInsets.only(top: 4, bottom: 10),
              child: Text(
                'గమనిక: profession + Nakshatra + Amsha Devata + Balaadi Avastha కలిసి final work-expressionను రూపాంతరం చేస్తాయి. Evidence % probability కాదు.',
                style: TextStyle(fontSize: 12, color: Color(0xFF65585B)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _sourceLinks(List<String> ids, Map<String, VargaRuleHit> byId) {
    final visible = ids.where((id) => byId.containsKey(id)).toSet().toList();
    if (visible.isEmpty) return const SizedBox.shrink();
    return Wrap(spacing: 6, runSpacing: 3, children: [
      for (final id in visible)
        ActionChip(
          label: Text(id, style: const TextStyle(fontSize: 10.5)),
          onPressed: () => onRuleTap(byId[id]!),
        ),
    ]);
  }

  Widget _strengthBar(String title, int? value, Color color) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 12.5,
            fontWeight: FontWeight.w700))),
        Text(value == null ? 'గణన లేదు' : '$value%',
          style: TextStyle(fontWeight: FontWeight.w900, color: color)),
      ]),
      const SizedBox(height: 4),
      LinearProgressIndicator(
        value: value == null ? 0 : value / 100,
        minHeight: 8, borderRadius: BorderRadius.circular(8),
        backgroundColor: const Color(0xFFE9E4E6),
        valueColor: AlwaysStoppedAnimation<Color>(color),
      ),
    ]),
  );

  Widget _modeStrengthCard(D10CareerModeEvidence evidence,
      Map<String, VargaRuleHit> byId) {
    final strong = evidence.mainStage;
    return _panel(
      color: strong ? const Color(0xFFEAF7EF) : const Color(0xFFFFFAF3),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 4),
        initiallyExpanded: false,
        leading: Icon(evidence.key == 'GOCHARASHTHA'
            ? Icons.storefront_outlined : Icons.badge_outlined,
            color: strong ? const Color(0xFF176B39) : _maroon),
        title: Text(evidence.title,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(strong ? 'D10 ప్రధాన వృత్తి విధానం' : evidence.earlyStage
              ? 'D1 మొదటి దశకు ఆధారం ఉంది' : 'ఇప్పటి మూల నియమాల్లో ప్రధాన విధానం కాదు',
              style: const TextStyle(fontSize: 12)),
          _strengthBar('ఎదుగుదల అనుకూల ఆధారాల వాటా',
            evidence.favorableSharePercent, const Color(0xFF176B39)),
          _strengthBar('ఆటంక / నష్ట ప్రమాద ఆధారాల వాటా',
            evidence.obstacleSharePercent, const Color(0xFFAB4166)),
          const SizedBox(height: 6),
          Text('అనుకూల ${evidence.favorableSignals} • '
              'ఆటంక ${evidence.obstacleSignals} • '
              'పరీక్షించిన ఆధారాలు ${evidence.checkedSignals}',
              style: const TextStyle(fontSize: 11.5)),
        ]),
        childrenPadding: const EdgeInsets.fromLTRB(10, 2, 10, 12),
        children: [
          const Divider(),
          const Align(alignment: Alignment.centerLeft,
              child: Text('జాతక పరిశీలన — ఏవి బలాన్ని పెంచాయి / తగ్గించాయి?',
                  style: TextStyle(fontWeight: FontWeight.w800))),
          const SizedBox(height: 6),
          Text(evidence.audit, style: const TextStyle(fontSize: 12.5)),
          const SizedBox(height: 8),
          if (evidence.favorableRuleIds.isNotEmpty) ...[
            const Align(alignment: Alignment.centerLeft,
                child: Text('అనుకూల మూల నియమాలు',
                    style: TextStyle(fontSize: 12.5, color: Color(0xFF176B39)))),
            _sourceLinks(evidence.favorableRuleIds, byId),
          ],
          if (evidence.obstacleRuleIds.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Align(alignment: Alignment.centerLeft,
                child: Text('ఆటంక మూల నియమాలు',
                    style: TextStyle(fontSize: 12.5, color: Color(0xFFAB4166)))),
            _sourceLinks(evidence.obstacleRuleIds, byId),
          ],
          const SizedBox(height: 8),
          const Text('ఇవి జ్యోతిష్య Rule-Evidence సూచికలు మాత్రమే. '
              'వృత్తిలో ఎంత జీతం పెరుగుతుంది లేదా ఎంత డబ్బు పోతుందనే శాతం కాదు.',
              style: TextStyle(fontSize: 11, color: Color(0xFF66585B))),
        ],
      ),
    );
  }

  Widget _lifeStagePanel(AvLifeStageEvidence av, int currentAge) {
    if (!av.valid) {
      return const Padding(padding: EdgeInsets.all(10), child: Text(
        'సర్వాష్టకవర్గ 337 బిందువుల ధృవీకరణ జరగలేదు. '
        'ఈ జీవిత దశల సూచనలు చూపించడం లేదు.'));
    }
    final now = av.atAge(currentAge);
    const labels = ['మొదటి 33 సంవత్సరాలు', 'రెండవ 33 సంవత్సరాలు',
        'మూడవ 33 సంవత్సరాలు'];
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Padding(padding: EdgeInsets.only(bottom: 7), child: Text(
          'సర్వాష్టకవర్గం — జీవిత దశల బల పోలిక',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800))),
      for (final stage in av.stages)
        Card(
          elevation: 0,
          color: stage.index == now?.index ? const Color(0xFFE8F4EC)
              : const Color(0xFFF5F3F6),
          child: Padding(padding: const EdgeInsets.all(9),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('${labels[stage.index]} '
                        '(${stage.approximateAgeLabel})',
                        style: const TextStyle(fontWeight: FontWeight.w700,
                            fontSize: 12))),
                    Text('${stage.fixedBindus} బిందువులు', style: const
                        TextStyle(fontWeight: FontWeight.w800)),
                  ]),
                const SizedBox(height: 3),
                Text(stage.index == av.leadingFixedStage
                    ? 'ఈ మూడు దశల్లో ఎక్కువ SAV బలం' :
                    av.leadingFixedStage == null
                        ? 'ఈ దశల మధ్య స్పష్టమైన ఏకైక ఆధిక్యం లేదు' :
                        'ముఖ్య దశతో పోల్చిన SAV ఆధారం',
                    style: const TextStyle(fontSize: 11.5)),
                if (stage.index > 0) Text(
                    stage.fixedBindus > av.stages[stage.index - 1].fixedBindus
                        ? 'ముందరి దశ కంటే బలం పెరిగింది (+${stage.fixedBindus - av.stages[stage.index - 1].fixedBindus} బిందువులు)'
                        : stage.fixedBindus < av.stages[stage.index - 1].fixedBindus
                          ? 'ముందరి దశ కంటే బలం తగ్గింది (${stage.fixedBindus - av.stages[stage.index - 1].fixedBindus} బిందువులు)'
                          : 'ముందరి దశతో సమాన బలం',
                    style: const TextStyle(fontSize: 11)),
              ]),
          ),
        ),
      const SizedBox(height: 5),
      Text('ప్రస్తుతం పూర్తి వయస్సు: $currentAge • '
          '${now == null ? 'ఈ నమూనా వయస్సు పరిధి బయట' :
          'దశ ${now.index + 1}'}',
          style: const TextStyle(fontSize: 12)),
      Text('ప్రధాన గ్రంథ పద్ధతి: మీనం–మిథునం / కర్కాటకం–తుల / '
          'వృశ్చికం–కుంభం. 33 సంవత్సరాల హద్దులు ప్రదర్శన కోసం; '
          'గ్రంథంలో నిర్దిష్ట వయస్సు ప్రారంభ సంవత్సరాలు ఇవ్వలేదు.',
          style: const TextStyle(fontSize: 11.5)),
      const SizedBox(height: 4),
      ExpansionTile(
        tilePadding: EdgeInsets.zero,
        title: const Text('లగ్నం నుంచి ప్రత్యామ్నాయ పద్ధతి / Source Audit',
          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
        children: [
          for (final stage in av.stages)
            ListTile(dense: true, title: Text('దశ ${stage.index + 1} — '
                '${stage.lagnaBindus} బిందువులు (లగ్నం నుంచి)'),
                subtitle: Text('మూల రాశి పద్ధతి: ${stage.fixedBindus} బిందువులు')),
          Text(av.methodsAgree
              ? 'రెండు పద్ధతులలో బలమైన దశ ఒకటే.'
              : 'రెండు పద్ధతుల ఫలితాలు భిన్నం/సమానం కావచ్చు. '
                'ఇది విరుద్ధ నిర్ణయంగా కాకుండా రెండు మూల పద్ధతుల పరిశీలనగా ఉంచాము.',
              style: const TextStyle(fontSize: 11)),
          const Text('M. S. Mehta, Ashtakvarga: Concept and Application, '
              'printed page 49. ఇది Rising / Downfall ఖచ్చితమైన సమయ గణన కాదు.',
              style: TextStyle(fontSize: 11)),
        ],
      ),
    ]);
  }

  Widget _stageSummary(D10CareerComparison comparison, D10SaturnStream saturn,
      Map<String, VargaRuleHit> byId, AvLifeStageEvidence av) => _panel(
    color: const Color(0xFFF1F6FB),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('3. రెండు విధానాల పోలిక — ప్రధాన వృత్తి',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900,
              color: _maroon)),
      const SizedBox(height: 7),
      Text(comparison.conclusion, style: const TextStyle(fontSize: 14,
          fontWeight: FontWeight.w800)),
      const SizedBox(height: 7),
      Text('మొదట: ${comparison.firstProfession}',
          style: const TextStyle(fontWeight: FontWeight.w700)),
      Text('తరువాత / ప్రధానంగా: ${comparison.laterProfession}',
          style: const TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 6),
      const Text('D1 ప్రారంభ దశకు, D10 ప్రధాన దశకు ఉపయోగించాం. '
          'D9ను మద్దతుగా మాత్రమే చూస్తాం.',
          style: TextStyle(fontSize: 12)),
      const SizedBox(height: 6),
      Text(saturn.reason,
          style: const TextStyle(fontSize: 11.5, color: Color(0xFF66585B))),
      if (av.valid) ...[
        const SizedBox(height: 9),
        Text('అష్టకవర్గ సహాయక ఆధారం (D1 SAV): '
            'బంధు ${av.bandhu} • సేవక ${av.sevaka} బిందువులు',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
        Text(av.modeSupport, style: const TextStyle(fontSize: 12)),
        const Text('మూల నియమం: M. S. Mehta, Ashtakvarga, printed p.48. '
            'ఇది D10 ప్రధాన వృత్తి నిర్ణయాన్ని స్వయంగా మార్చదు.',
            style: TextStyle(fontSize: 10.5)),
      ],
      _sourceLinks(['D10-SEQUENCE', 'D10-JOB-BUSINESS'], byId),
    ]),
  );

  Widget _careerOutcomeCard(D10CareerDecision decision,
      Map<String, VargaRuleHit> byId) {
    final accent = switch (decision.tone) {
      D10DecisionTone.favorable => const Color(0xFF176B39),
      D10DecisionTone.caution => const Color(0xFFAB4166),
      D10DecisionTone.mixed => const Color(0xFF986522),
      D10DecisionTone.unconfirmed => const Color(0xFF687079),
    };
    return _panel(color: const Color(0xFFF7F4F8), child: ExpansionTile(
      tilePadding: EdgeInsets.zero,
      title: Text(decision.title, style: TextStyle(color: accent,
          fontWeight: FontWeight.w800)),
      subtitle: Text(decision.result, style: const TextStyle(fontSize: 12.5)),
      children: [
        Align(alignment: Alignment.centerLeft,
            child: Text(decision.reasoning,
                style: const TextStyle(fontSize: 12.5))),
        const SizedBox(height: 6),
        _sourceLinks(decision.matchedRuleIds, byId),
        const SizedBox(height: 4),
      ],
    ));
  }

  Widget _houseInspection(AstroChartResult chart) {
    final inspection = VargaMasterInspectionService.inspect(chart, 10);
    final houses = [inspection.lagna, ...inspection.subjects];
    return _panel(color: const Color(0xFFF4F7FA), child: ExpansionTile(
      tilePadding: EdgeInsets.zero,
      initiallyExpanded: false,
      title: const Text('లగ్నం, భావాధిపతులు, దృష్టులు, పంచధా మైత్రి',
          style: TextStyle(fontWeight: FontWeight.w800)),
      subtitle: const Text('1, 2, 6, 7, 10, 11 భావాల జాతక పరిశీలన — వివరాలు'),
      children: [for (final h in houses)
        ExpansionTile(
          title: Text('${h.number}వ భావం — ${h.title}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          subtitle: Text('${h.lord} • ${h.lordHouse ?? 'తెలియదు'}వ భావం • '
              '${h.evidenceVerdict}', style: const TextStyle(fontSize: 11)),
          children: [for (final evidence in h.signals)
            ListTile(dense: true,
              title: Text(evidence.title, style: const TextStyle(fontSize: 12,
                  fontWeight: FontWeight.w700)),
              subtitle: Text(evidence.evidence,
                  style: const TextStyle(fontSize: 11.5)),
            )],
        ),
      ],
    ));
  }

  Widget _pavSummaryPanel({
    required AstroChartResult natal,
    required AshtakavargaResult av,
  }) {
    if (!AshtakavargaPavCareerService.audit(av)) {
      return const Padding(padding: EdgeInsets.all(10), child:
          Text('PAV డేటా సమగ్రత తనిఖీ జరగలేదు — గ్రహ బలం చూపించడం లేదు.'));
    }
    final planets = AshtakavargaPavCareerService.natalCareerPlanets(
        chart: natal, av: av);
    return ExpansionTile(
      initiallyExpanded: false,
      title: const Text('PAV — వృత్తి గ్రహాల బలం / బిందు దాతలు',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
      subtitle: const Text('10, 11, 6 భావాలు • సూర్యుడు, శని, వృత్తి/లాభాధిపతులు'),
      children: [
        for (final planet in planets) ListTile(
          dense: true,
          title: Text('${planet.planet} — 10వ భావం ${planet.careerBindus}/8, '
              '11వ భావం ${planet.gainBindus}/8, '
              '6వ భావం ${planet.sixthBindus}/8'),
          subtitle: Text('${planet.careerSignal} • ${planet.gainSignal}\n'
              '10వ భావ బిందు దాతలు: ${planet.careerGivers.join(', ')}'),
        ),
        const Padding(padding: EdgeInsets.all(10), child: Text(
          'ఇవి D1 అష్టకవర్గ బిందు ఆధారాలు; D10 రాజయోగం/దశా ఫలితానికి '
          'ప్రత్యామ్నాయం కాదు. పాపగ్రహం ఇచ్చిన బిందువు కూడా '
          'PAV గణనలో 1 బిందువే — దాన్ని పాపదృష్టిగా తగ్గించరాదు. '
          'బిందువులను లాభనష్టం శాతాలుగా మార్చరాదు.',
          style: TextStyle(fontSize: 11.5))),
      ],
    );
  }

  Widget _pavPeriodEvidence({
    required AstroChartResult natal,
    required AshtakavargaResult av,
    required D10CareerWindow period,
  }) {
    final evidence = AshtakavargaPavCareerService.periodEvidence(
      chart: natal, av: av,
      mahadasha: period.mahadasha,
      antardasha: period.antardasha,
    );
    if (!evidence.valid) return Text(evidence.note);
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      title: const Text('PAV — ఈ దశలో వృత్తి గ్రహబల ఆధారాలు',
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
      childrenPadding: const EdgeInsets.only(left: 7, right: 7, bottom: 7),
      children: [
        for (final planet in evidence.lords)
          ListTile(dense: true, contentPadding: EdgeInsets.zero,
            title: Text('${planet.planet} • 10వ BAV ${planet.careerBindus}/8 '
                '• 11వ BAV ${planet.gainBindus}/8 '
                '• జన్మస్థితి BAV ${planet.natalBindus}/8'),
            subtitle: Text('${planet.careerSignal} • ${planet.gainSignal}\n'
                '10వ భావ బిందు దాతలు: ${planet.careerGivers.join(', ')}\n'
                '11వ భావ బిందు దాతలు: ${planet.gainGivers.join(', ')}'),
          ),
        if (evidence.notCovered.isNotEmpty)
          Text('సాంప్రదాయ ఏడు గ్రహాల PAVలో లేని దశానాథులు: '
              '${evidence.notCovered.join(', ')}',
              style: const TextStyle(fontSize: 12)),
        Text(evidence.note, style: const TextStyle(fontSize: 11)),
      ],
    );
  }

  Widget _yearGroup(BuildContext context, List<D10CareerWindow> windows, D10YearCategory category, AshtakavargaResult av) {
    final years = D10CareerYearService.yearsFor(windows, category);
    final evidencePercent = D10CareerYearService.evidenceSharePercent(windows, category);
    final (title, icon, tint) = switch (category) {
      D10YearCategory.rise => ('ఎదుగుదల — Rise / Promotion', Icons.trending_up, const Color(0xFFEAF6EE)),
      D10YearCategory.fall => ('పతనం — Fall / Job-Loss Caution', Icons.trending_down, const Color(0xFFFFF0EF)),
      D10YearCategory.middle => ('వృత్తి మార్పులు / బదిలీలు — Change', Icons.swap_horiz, const Color(0xFFFFF8E7)),
    };
    return _panel(
      color: tint,
      child: ExpansionTile(
        key: PageStorageKey<String>('d10-years-${category.name}'),
        tilePadding: EdgeInsets.zero,
        leading: Icon(icon, color: _maroon),
        title: Text('$title — $evidencePercent%', style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(years.isEmpty
            ? 'Timing evidence 0% • రూల్‌కు సరిపోయే సంవత్సరం ఈ లెక్కలో లేదు.'
            : 'Timing evidence $evidencePercent% • ${years.length} సంవత్సరాలు • టచ్ చేసి తేదీలు చూడండి'),
        children: [
          if (years.isEmpty)
            const Padding(
              padding: EdgeInsets.all(10),
              child: Text('డేటా లేని సంవత్సరాన్ని అనుకూలం/మధ్యస్థం/ప్రతికూలంగా ఊహించలేదు.'),
            ),
          for (final entry in years.entries)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${entry.key} సంవత్సరం', style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${entry.value.length} దశా సూచనలు • తేదీలు, గ్రహాలు, రూల్స్'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 15, color: _maroon),
              onTap: () => _showYearDetails(context, entry.key, entry.value, title, av),
            ),
        ],
      ),
    );
  }

  void _showYearDetails(BuildContext context, int year, List<D10CareerWindow> windows, String heading, AshtakavargaResult av) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: FractionallySizedBox(
          heightFactor: 0.76,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              Text('$year — $heading', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('ఇవి జ్యోతిష్య నియమాల ఆధారంగా లెక్కించిన దశా కాల సూచనలు; సంఘటన జరిగిందని ధృవీకరణ లేదా భవిష్యత్తు హామీ కాదు.',
                  style: TextStyle(fontSize: 12.5, color: Color(0xFF665B5C))),
              const SizedBox(height: 12),
              _D10PavGocharaPanel(
                natal: chart,
                birthData: birthData,
                av: av,
                year: year,
                windows: windows,
              ),
              const SizedBox(height: 12),
              for (final item in windows) Card(
                color: const Color(0xFFFFFAF5),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('${D10CareerService.formatDate(D10CareerYearService.segmentStart(item, year))} → ${D10CareerService.formatDate(D10CareerYearService.segmentEnd(item, year))}'),
                      Text('మహాదశ / అంతర్దశ: ${item.mahadasha} / ${item.antardasha}'),
                      Text('రూల్స్: ${item.ruleIds.join(' • ')}', style: const TextStyle(color: _maroon)),
                      const SizedBox(height: 6),
                      Text(item.reason),
                      const SizedBox(height: 6),
                      _pavPeriodEvidence(natal: chart, av: av, period: item),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _careerSuitabilityPanel({
    required List<D10ProfessionCandidate> candidates,
    required VargaRuleHit? source,
  }) {
    return _panel(
      color: const Color(0xFFFFF8E8),
      child: ExpansionTile(
        key: const PageStorageKey<String>('d10-career-suitability'),
        initiallyExpanded: true,
        tilePadding: EdgeInsets.zero,
        leading: const Icon(Icons.workspace_premium_outlined, color: _maroon),
        title: const Text('5. ఏ వృత్తి అనుకూలం? / Career Suitability', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(candidates.isEmpty
            ? 'Independent profession evidence match కాలేదు.'
            : 'Top ${candidates.length} profession families • Evidence Match % probability కాదు'),
        children: [
          if (candidates.isEmpty)
            const Padding(
              padding: EdgeInsets.all(10),
              child: Text('10L + Nakshatra + Sign + conjunction evidenceలో profession family match రాలేదు.'),
            ),
          for (var i = 0; i < candidates.length; i++)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                radius: 15,
                backgroundColor: const Color(0xFFF1E4D4),
                child: Text('${i + 1}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: _maroon)),
              ),
              title: Text(candidates[i].profession, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${candidates[i].evidenceMatchPercent}% Evidence Match • ${candidates[i].natureCompatibility}'),
              trailing: const Text('ఫలితం', style: TextStyle(fontWeight: FontWeight.w800, color: _maroon)),
              onTap: source == null ? null : () => onRuleTap(source),
            ),
          const Padding(
            padding: EdgeInsets.only(top: 4, bottom: 8),
            child: Text(
              'Amsha Devata ఈ %ను పెంచదు/తగ్గించదు. అది ఎంపికైన profession యొక్క పని విధానం మాత్రమే modify చేస్తుంది.',
              style: TextStyle(fontSize: 12, color: Color(0xFF66585B)),
            ),
          ),
        ],
      ),
    );
  }

  void _showBusinessList(
    BuildContext context,
    List<D10ProfessionCandidate> candidates,
    D10FinalProfessionResult engine,
    VargaRuleHit? source,
  ) {
    final choices = D10BusinessCatalog.suggest(candidates);
    final mode = D10CareerService.saturnStream(chart).dashamsaState;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: FractionallySizedBox(
          heightFactor: 0.87,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 28),
            children: [
              const Text('ఏ వ్యాపారం చేయవచ్చు? — Business List',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: _maroon)),
              const SizedBox(height: 8),
              const Text('D10లో సరిపోయిన వృత్తిరంగాల ఆధారంగా వ్యాపార ఎంపికలు. '
                  'ఒక్కో వ్యాపారానికి ప్రత్యేకమైన జ్యోతిష్య శాతం లేదా లాభం శాతం లెక్కించలేదు. '
                  'రంగ ఆధారాలను ఆ రంగం వద్ద ఒక్కసారే చూపిస్తున్నాం; '
                  'ఇవి స్వతంత్ర గ్రంథయోగాలు కావు.',
                  style: TextStyle(fontSize: 12.5, height: 1.45)),
              if (mode != 'GOCHARASHTHA')
                const Padding(
                  padding: EdgeInsets.only(top: 6),
                  child: Text('D10లో గోచరిష్ట (వ్యాపారం/స్వయం ఉపాధి) ప్రధానంగా నిర్ధారణ కాలేదు. '
                      'క్రిందివి వృత్తిరంగానికి సంబంధించిన వ్యాపార ఆలోచనలు మాత్రమే; '
                      'ఉద్యోగానికి బదులుగా వ్యాపారమే చేయాలని సూచించడం కాదు.',
                      style: TextStyle(fontWeight: FontWeight.w700, color: _maroon)),
                ),
              const SizedBox(height: 10),
              if (choices.isEmpty)
                const Text('జాతక ఆధారాలతో సంబంధం చూపిన వృత్తిరంగానికి వ్యాపార ఎంపికలు నమోదు కాలేదు.'),
              for (var familyIndex = 0; familyIndex < candidates.length; familyIndex++)
                if (choices.any((idea) => idea.professionFamily == candidates[familyIndex].profession))
                  Card(
                    color: const Color(0xFFFFFAF5),
                    child: ExpansionTile(
                      key: ValueKey<String>('d10-business-family-${candidates[familyIndex].profession}'),
                      initiallyExpanded: familyIndex == 0,
                      title: Text('రంగం: ${candidates[familyIndex].profession}',
                          style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: Text('రంగస్థాయి ఆధారాలు: '
                          '${candidates[familyIndex].matchedEvidence.length}/'
                          '${candidates[familyIndex].availableEvidenceBlocks} • '
                          '${candidates[familyIndex].natureCompatibility} '
                          '(లాభ శాతం కాదు)'),
                      childrenPadding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
                      children: [
                        for (final idea in choices.where((entry) =>
                            entry.professionFamily == candidates[familyIndex].profession))
                          Card(
                            elevation: 0,
                            color: const Color(0xFFF7F0EF),
                            child: ExpansionTile(
                              key: ValueKey<String>('d10-business-choice-${idea.nameTe}'),
                              title: Text(idea.nameTe,
                                  style: const TextStyle(fontWeight: FontWeight.w800)),
                              subtitle: const Text('వ్యాపార ఎంపిక • ప్రత్యేక వ్యాపార స్కోరు లేదు'),
                              childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                              expandedCrossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('జాతక పరిశీలన — ఈ వ్యాపారానికి సంబంధించిన రంగ ఆధారాలు',
                                    style: TextStyle(fontWeight: FontWeight.w900, color: _maroon)),
                                const SizedBox(height: 5),
                                Text('D10 10వ అధిపతి: ${engine.tenthLord} • '
                                    'రాశి: ${engine.tenthLordSignName} • '
                                    'నక్షత్రం: ${engine.nakshatraName}'),
                                Text('వృత్తిరంగ స్వభావం: ${idea.natureCompatibility}'),
                                Text('సరిపోయిన రంగ ఆధారాలు: '
                                    '${idea.matchedEvidence.isEmpty ? 'ప్రత్యేక ఆధారం లేదు' : idea.matchedEvidence.join(' • ')}'),
                                const Padding(
                                  padding: EdgeInsets.only(top: 5, bottom: 5),
                                  child: Text('గమనిక: ఈ ఆధారాలు వృత్తిరంగానికి మాత్రమే వర్తిస్తాయి. '
                                      'ఈ ప్రత్యేక వ్యాపారం విజయవంతమవుతుందనే వ్యక్తిగత నిర్ణయానికి '
                                      'వేరు కాంబినేషన్ లేదా నిర్ధారణ ఇక్కడ లేదు.',
                                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600)),
                                ),
                                Text(idea.caution, style: const TextStyle(fontSize: 12.5)),
                                if (source != null)
                                  TextButton.icon(
                                    onPressed: () {
                                      Navigator.of(sheetContext).pop();
                                      onRuleTap(source);
                                    },
                                    icon: const Icon(Icons.menu_book_outlined),
                                    label: const Text('వృత్తిరంగ రూల్ / మూలాధారం చూడండి'),
                                  ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _natureDevataPanel({
    required BuildContext context,
    required D10FinalProfessionResult engine,
    required List<D10ProfessionCandidate> candidates,
    required VargaRuleHit? source,
    required VargaRuleHit? workflowSource,
    required VargaRuleHit? professionSource,
  }) {
    final top = candidates.take(4).map((x) => x.profession).join(' • ');
    return _panel(
      color: const Color(0xFFECF7EF),
      child: ExpansionTile(
        key: const PageStorageKey<String>('d10-nature-devata'),
        initiallyExpanded: true,
        tilePadding: EdgeInsets.zero,
        leading: const Icon(Icons.route_outlined, color: Color(0xFF1A794A)),
        title: const Text('6. Profession Nature + Amsha Devata', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('${engine.professionNature} • ${engine.amshaDevata.deity} (${engine.amshaDevata.direction})'),
        children: [
          _auditLine('10వ భావాధిపతి', engine.tenthLord),
          _auditLine('10L రాశి', '${engine.tenthLordSignName} • ${engine.professionNature}'),
          _auditLine('Amsha Devata', '${engine.amshaDevata.deity} • ${engine.amshaDevata.direction}'),
          _auditLine('Work Flow Modifier', engine.amshaDevata.workflowModifier),
          _auditLine('Balaadi Avastha', '${engine.balaadi.state} • ${engine.balaadi.expression}'),
          const Divider(height: 18),
          Align(
            alignment: Alignment.centerLeft,
            child: InkWell(
              borderRadius: BorderRadius.circular(8),
              onTap: candidates.isEmpty
                  ? null
                  : () => _showBusinessList(context, candidates, engine, professionSource),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      top.isEmpty
                          ? 'Final Career Interpretation: profession evidence లేకుండా Devata ఒక్కటితో వృత్తి ప్రకటించము.'
                          : 'Final Career Interpretation: $top రంగాలు ${engine.professionNature} natureలో, ${engine.amshaDevata.deity} స్వభావం ప్రకారం ${engine.amshaDevata.workflowModifier} ${engine.balaadi.state} అవస్థ వల్ల ${engine.balaadi.expression}.',
                      style: const TextStyle(fontWeight: FontWeight.w700, height: 1.4),
                    ),
                    if (candidates.isNotEmpty)
                      const Padding(
                        padding: EdgeInsets.only(top: 6),
                        child: Text('Business ఫలితాన్ని టచ్ చేస్తే వ్యాపారాల జాబితా తెరుచుకుంటుంది →',
                            style: TextStyle(fontWeight: FontWeight.w800, color: _maroon)),
                      ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 10),
          if (candidates.isNotEmpty)
            Align(
              alignment: Alignment.centerLeft,
              child: FilledButton.icon(
                onPressed: () => _showBusinessList(context, candidates, engine, professionSource),
                icon: const Icon(Icons.storefront_outlined),
                label: const Text('Business → ఏ వ్యాపారం? జాబితా'),
                style: FilledButton.styleFrom(
                  backgroundColor: _maroon,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              if (workflowSource != null)
                TextButton.icon(
                  onPressed: () => onRuleTap(workflowSource),
                  icon: const Icon(Icons.account_tree_outlined),
                  label: const Text('Career Interpretation Rule'),
                ),
              if (source != null)
                TextButton.icon(
                  onPressed: () => onRuleTap(source),
                  icon: const Icon(Icons.menu_book_outlined),
                  label: const Text('Nature / Devata Source'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _strengthQualityPanel({required D10FinalProfessionResult engine, required VargaRuleHit? source}) {
    return _panel(
      color: const Color(0xFFF3F4F6),
      child: ExpansionTile(
        key: const PageStorageKey<String>('d10-strength-quality'),
        initiallyExpanded: false,
        tilePadding: EdgeInsets.zero,
        leading: const Icon(Icons.menu_book_outlined, color: Color(0xFF53606A)),
        title: const Text('7. Graha Strength / Career Quality', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('Career Suitability % • BPHS Avastha Strength • Brihat Jataka Quality — మూడు వేర్వేరు layers'),
        children: [
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: const Text('BPHS Balaadi Avastha — 10L', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('${engine.tenthLord}: ${engine.balaadi.state} • ${engine.balaadi.expression} • D10 degree ${engine.balaadi.degreeInSign.toStringAsFixed(2)}°'),
          ),
          const ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('మిగతా Graha Avasthas', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('Jagradadi → Deeptadi → Lajjitadi → Shayanadi. Source-supported calculation ఉన్న state మాత్రమే resultగా చూపాలి.'),
          ),
          const ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('Shayanadi', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('Arithmetic engine ఉంది. Exact local sunrise నుంచి Birth Ghati మరియు validated Name Anka లభించినప్పుడు మాత్రమే Main state + Drishti/Cheshta/Vicheshta result ఇవ్వాలి.'),
          ),
          const ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('Brihat Jataka Result Quality', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('Quality layerను Career Evidence %లో arbitrary +/- pointsగా కలపము. Exact source condition match అయిన quality మాత్రమే చూపాలి.'),
          ),
          if (source != null)
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () => onRuleTap(source),
                icon: const Icon(Icons.fact_check_outlined),
                label: const Text('Strength / Quality Rule & Source'),
              ),
            ),
        ],
      ),
    );
  }

  Widget _d10SavPanel(D10VargaAshtakavargaReport av, int natalLagnaSign) {
    const houses = <int>[1, 2, 6, 7, 8, 10, 11, 12];
    const titles = <int, String>{
      1: 'లగ్నం / వృత్తి స్థిరత్వం',
      2: 'వృత్తి ఆదాయం',
      6: 'సేవ / పోటీ / ఉద్యోగం',
      7: 'వ్యాపారం / కస్టమర్లు / 10వ నుంచి 10వది',
      8: 'వృత్తి మార్పులు / ఆటంకాలు',
      10: 'వృత్తి / స్థాయి',
      11: 'లాభాలు / గుర్తింపు',
      12: 'ఖర్చులు / విదేశీ సంబంధం',
    };
    return _panel(
      color: const Color(0xFFF3F7FC),
      child: ExpansionTile(
        key: const PageStorageKey<String>('d10-varga-sav'),
        initiallyExpanded: false,
        tilePadding: EdgeInsets.zero,
        leading: const Icon(Icons.grid_on_outlined, color: Color(0xFF315D83)),
        title: const Text('4A. D10 ప్రత్యేక SAV — వృత్తి భావాల బలం',
            style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('D1 SAV మరియు D10 SAV వేర్వేరుగా గణించబడ్డాయి • '
            'P.V.R. Narasimha Rao, విభాగం 12.5'),
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 4, 4, 8),
            child: Text('బిందువులు వృత్తి యోగాలకు సహాయక ఆధారాలు మాత్రమే. '
                'ఆదాయ వృద్ధి %, ఉద్యోగం వచ్చే సంభావ్యత లేదా పతనం సంవత్సరాన్ని '
                'ఈ బిందువుల ఆధారంగా ఒక్కటే నిర్ణయించకూడదు.'),
          ),
          for (final house in houses)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${house}వ భావం — ${titles[house]}',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('D1 SAV: ${av.natalSav(house, natalLagnaSign)} • '
                  'D10 SAV: ${av.dashamsaSav(house)} • '
                  '${av.evidenceForHouse(house)}'),
            ),
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 4, 4, 10),
            child: Text('Rule: D10-AV-SAV-01 • మూలం: '
                'P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach, '
                'section 12.5 • 7 గ్రహాలు × 8 దాతల PAV. '
                'D1 మొత్తం = 337; D10 మొత్తం = 337. '
                'వేర్వేరు ఆధారాలను ఒకే ఈవెంట్‌కు రెండుసార్లు లెక్కించరాదు.',
                style: TextStyle(fontSize: 12)),
          ),
        ],
      ),
    );
  }

  Widget _auditLine(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 132, child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800))),
            Expanded(child: Text(value)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final saturn = D10CareerService.saturnStream(chart);
    final comparison = D10CareerComparisonService.evaluate(
        saturn: saturn, rules: rules);
    final decisions = D10CareerDecisionService.summarize(
        saturn: saturn, rules: rules);
    final ashtakaResult = AshtakavargaService.calculate(chart);
    final d10Sav = D10VargaAshtakavargaService.calculate(chart);
    final ashtakaStages = AshtakavargaThreeStageService.fromChart(chart);
    final currentAge = AshtakavargaThreeStageService.completedAge(
        birthDateTime, DateTime.now());
    final byId = {for (final r in rules) r.ruleId: r};
    final engine = D10FinalProfessionEngine.evaluate(
        chart: chart, d10: VargaService.calculate(chart, 10));
    final candidates = engine.candidates
        .where((c) => c.natureCompatibility.endsWith('Match'))
        .take(8).toList(growable: false);
    final shortlist = candidates.isNotEmpty
        ? candidates : engine.candidates.take(8).toList(growable: false);
    final timeline = D10CareerService.timingWindows(
        chart: chart, birthDateTime: birthDateTime);
    VargaRuleHit? find(String id) => byId[id];
    final d10ModeRules = <String>[
      'D10-BASE-01', 'D10-BASE-03', 'D10-BASE-05',
      'D10-BASE-06', 'D10-SATURN-REL', 'D10-PP',
    ].map(find).whereType<VargaRuleHit>()
        .where((r) => r.autoEvaluated && r.applicable)
        .toList(growable: false);
    final yogaRules = rules.where((r) => isYoga(r) && r.autoEvaluated &&
        r.applicable).toList(growable: false);
    final auditedYogaCount = rules.where((r) => isYoga(r) &&
        (!r.autoEvaluated || !r.applicable)).length;
    final positiveYogaCount = yogaRules.where((r) =>
        r.tone == VargaRuleTone.favorable).length;
    final cautionYogaCount = yogaRules.where((r) =>
        r.tone == VargaRuleTone.caution).length;

    final businessTarget = GlobalKey();
    final jobTarget = GlobalKey();
    final compareTarget = GlobalKey();
    final savTarget = GlobalKey();
    final careersTarget = GlobalKey();
    final governmentTarget = GlobalKey();
    final timingTarget = GlobalKey();
    final houseTarget = GlobalKey();
    final yogaTarget = GlobalKey();
    void focus(GlobalKey target) {
      final ctx = target.currentContext;
      if (ctx != null) {
        Scrollable.ensureVisible(ctx, duration: const Duration(milliseconds: 350),
          curve: Curves.easeInOut, alignment: 0.05);
      }
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Padding(padding: EdgeInsets.fromLTRB(3, 8, 3, 9),
        child: Text('D10 — వృత్తి నిర్ణయ రిపోర్టు',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900,
            color: _maroon))),
      const Padding(padding: EdgeInsets.fromLTRB(5, 0, 5, 8),
        child: Text('మొదట రెండు వృత్తి విధానాల బలం, తరువాత వృత్తి క్రమం, '
          'అనుకూల వృత్తుల జాబితాలు, సంఘటన సమయం.',
          style: TextStyle(fontSize: 12.5))),

      AstroIconDashboard(title: 'D10 · వృత్తి అంశాలు', items: [
        AstroDashboardItem(title: 'గోచరిష్ట వ్యాపారం', icon: Icons.storefront_outlined,
          color: const Color(0xFF2680BB), onTap: () => focus(businessTarget)),
        AstroDashboardItem(title: 'అగోచరిష్ట ఉద్యోగం', icon: Icons.badge_outlined,
          color: const Color(0xFF31986D), onTap: () => focus(jobTarget)),
        AstroDashboardItem(title: 'వృత్తి పోలిక', icon: Icons.compare_arrows,
          color: const Color(0xFFDE902F), onTap: () => focus(compareTarget)),
        AstroDashboardItem(title: 'అనుకూల వృత్తులు', icon: Icons.business_center_outlined,
          color: const Color(0xFF7C54AD), onTap: () => focus(careersTarget)),
        AstroDashboardItem(title: 'ప్రభుత్వ ఉద్యోగం', icon: Icons.account_balance_outlined,
          color: const Color(0xFF315DA1), onTap: () => focus(governmentTarget)),
        AstroDashboardItem(title: 'ఎదుగుదల / పతనం', icon: Icons.trending_up,
          color: const Color(0xFFC34D6B), onTap: () => focus(timingTarget)),
        AstroDashboardItem(title: 'D10 అష్టకవర్గం', icon: Icons.grid_on,
          color: const Color(0xFF2692A0), onTap: () => focus(savTarget)),
        AstroDashboardItem(title: 'భావ పరిశీలన', icon: Icons.auto_graph,
          color: const Color(0xFFAE7A30), onTap: () => focus(houseTarget)),
        AstroDashboardItem(title: 'వర్తించిన యోగాలు', icon: Icons.fact_check_outlined,
          color: const Color(0xFFB43D7B), onTap: () => focus(yogaTarget)),
      ]),
      const SizedBox(height: 14),
      // Explicit user-defined order: Gocharastha BUSINESS before
      // Agocharastha JOB. Neither source score measures income gains/losses.
      KeyedSubtree(key: businessTarget, child: _modeStrengthCard(comparison.business, byId)),
      KeyedSubtree(key: jobTarget, child: _modeStrengthCard(comparison.job, byId)),
      KeyedSubtree(key: compareTarget, child: _stageSummary(comparison, saturn, byId, ashtakaStages)),
      KeyedSubtree(key: savTarget, child: _d10SavPanel(d10Sav, chart.ascendantSignIndex)),

      KeyedSubtree(key: careersTarget, child: const Padding(padding: EdgeInsets.fromLTRB(5, 8, 5, 6),
        child: Text('4. అనుకూల వృత్తులు / వ్యాపారాల జాబితా',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900,
            color: _maroon)))),
      _professionGroup(
        isBusiness: true,
        active: comparison.business.mainStage || comparison.business.earlyStage,
        isCurrentD10Mode: comparison.business.mainStage,
        stageLabel: comparison.business.mainStage ? 'D10 ప్రధాన విధానం'
            : comparison.business.earlyStage ? 'D1 ప్రారంభ విధానం'
            : 'సహాయక వృత్తి రంగం',
        candidates: shortlist, engine: engine,
        modeRules: comparison.business.mainStage
            ? d10ModeRules : const <VargaRuleHit>[],
        source: find('D10-FINAL-MASTER-PROF'),
      ),
      _professionGroup(
        isBusiness: false,
        active: comparison.job.mainStage || comparison.job.earlyStage,
        isCurrentD10Mode: comparison.job.mainStage,
        stageLabel: comparison.job.mainStage ? 'D10 ప్రధాన విధానం'
            : comparison.job.earlyStage ? 'D1 ప్రారంభ విధానం'
            : 'సహాయక వృత్తి రంగం',
        candidates: shortlist, engine: engine,
        modeRules: comparison.job.mainStage
            ? d10ModeRules : const <VargaRuleHit>[],
        source: find('D10-FINAL-MASTER-PROF'),
      ),

      KeyedSubtree(key: governmentTarget, child: _panel(color: const Color(0xFFFFFAF0), child: ExpansionTile(
        initiallyExpanded: false,
        tilePadding: EdgeInsets.zero,
        title: const Text('5. ప్రభుత్వ ఉద్యోగం / ఉన్నత పదవి',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
        subtitle: const Text('స్వతంత్ర మూల నియమాల నిర్ణయాలు'),
        children: [for (final decision in decisions.where((d) =>
            d.key == 'government' || d.key == 'high-position'))
              _careerOutcomeCard(decision, byId)],
      ))),

      KeyedSubtree(key: timingTarget, child: _panel(color: const Color(0xFFFFFAF0), child: ExpansionTile(
        initiallyExpanded: false,
        tilePadding: EdgeInsets.zero,
        title: const Text('6. ఎదుగుదల / పతనం / మార్పుల సంవత్సరాలు',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
        subtitle: const Text('దశ–అంతర్దశ ఆధారిత కాల సూచనలు • సంవత్సరం టచ్ చేయండి'),
        children: [
          _lifeStagePanel(ashtakaStages, currentAge),
          _pavSummaryPanel(natal: chart, av: ashtakaResult),
          const Divider(),
          const Padding(padding: EdgeInsets.symmetric(vertical: 6), child:
            Text('దశ–అంతర్దశ ఆధారిత వృత్తి సంవత్సరాలు',
              style: TextStyle(fontWeight: FontWeight.w700))),
          _yearGroup(context, timeline, D10YearCategory.rise, ashtakaResult),
          _yearGroup(context, timeline, D10YearCategory.fall, ashtakaResult),
          _yearGroup(context, timeline, D10YearCategory.middle, ashtakaResult),
        ],
      ))),

      KeyedSubtree(key: houseTarget, child: _houseInspection(chart)),
      KeyedSubtree(key: yogaTarget, child: _panel(color: const Color(0xFFF1F6F2), child: ExpansionTile(
        key: const PageStorageKey<String>('d10-all-yogas'),
        initiallyExpanded: false, tilePadding: EdgeInsets.zero,
        title: const Text('7. అన్ని వర్తించిన యోగాలు',
          style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('అనుకూలం $positiveYogaCount • జాగ్రత్త '
          '$cautionYogaCount • మొత్తం ${yogaRules.length} • '
          '$auditedYogaCount source-only'),
        children: [for (final yoga in yogaRules)
          ListTile(dense: true, contentPadding: EdgeInsets.zero,
            title: Text(yoga.topic),
            subtitle: Text('${yoga.ruleId} • ${yoga.result}', maxLines: 2),
            onTap: () => onRuleTap(yoga))],
      ))),
      _panel(color: const Color(0xFFF7F4F1), child: ExpansionTile(
        initiallyExpanded: false, tilePadding: EdgeInsets.zero,
        title: const Text('8. అదనపు వృత్తి పరిశీలనలు',
          style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('వృత్తిరంగ స్కోర్లు • అంశ దేవత • అవస్థ • గ్రహ బలం'),
        children: [
          _careerSuitabilityPanel(
            candidates: shortlist, source: find('D10-FINAL-MASTER-PROF')),
          _natureDevataPanel(context: context, engine: engine,
            candidates: shortlist, source: find('D10-FINAL-MASTER-NATURE'),
            workflowSource: find('D10-FINAL-WORKFLOW'),
            professionSource: find('D10-FINAL-MASTER-PROF')),
          _strengthQualityPanel(engine: engine,
            source: find('D10-FINAL-STRENGTH-QUALITY')),
        ],
      )),
      Padding(padding: const EdgeInsets.fromLTRB(6, 7, 6, 13),
        child: Text(comparison.audit,
          style: const TextStyle(fontSize: 11.5,
            color: Color(0xFF66585B), height: 1.4))),
    ]);
  }
}

/// Exact transit-instant cross-check for a selected D10 Rise/Fall/Middle year.
/// The selected clock is interpreted in the chart timezone, not the phone's.
/// The natal PAV table is immutable; only the 7 transit longitudes change.
class _D10PavGocharaPanel extends StatefulWidget {
  final AstroChartResult natal;
  final BirthData birthData;
  final AshtakavargaResult av;
  final int year;
  final List<D10CareerWindow> windows;
  const _D10PavGocharaPanel({
    required this.natal,
    required this.birthData,
    required this.av,
    required this.year,
    required this.windows,
  });

  @override
  State<_D10PavGocharaPanel> createState() => _D10PavGocharaPanelState();
}

class _D10PavGocharaPanelState extends State<_D10PavGocharaPanel> {
  late DateTime _selectedLocal;
  late Future<D10PavTransitReport> _report;
  D10CareerWindow? _activeWindow;

  @override
  void initState() {
    super.initState();
    if (widget.windows.isNotEmpty) {
      final first = widget.windows.first;
      final start = D10CareerYearService.segmentStart(first, widget.year);
      final end = D10CareerYearService.segmentEnd(first, widget.year);
      _selectedLocal = start.add(Duration(
          microseconds: end.difference(start).inMicroseconds ~/ 2));
    } else {
      _selectedLocal = DateTime(widget.year, 6, 15, 12);
    }
    _refresh();
  }

  void _refresh() {
    _activeWindow = null;
    for (final w in widget.windows) {
      if (!_selectedLocal.isBefore(w.start) && _selectedLocal.isBefore(w.end)) {
        _activeWindow = w;
        break;
      }
    }
    _report = D10PavTransitCareerService.calculate(
      birthData: widget.birthData,
      natal: widget.natal,
      av: widget.av,
      localDateTime: _selectedLocal,
      mahadasha: _activeWindow?.mahadasha,
      antardasha: _activeWindow?.antardasha,
    );
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedLocal,
      firstDate: DateTime(widget.year, 1, 1),
      lastDate: DateTime(widget.year, 12, 31),
    );
    if (!mounted || picked == null) return;
    setState(() {
      _selectedLocal = DateTime(picked.year, picked.month, picked.day,
          _selectedLocal.hour, _selectedLocal.minute);
      _refresh();
    });
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_selectedLocal),
    );
    if (!mounted || picked == null) return;
    setState(() {
      _selectedLocal = DateTime(_selectedLocal.year, _selectedLocal.month,
          _selectedLocal.day, picked.hour, picked.minute);
      _refresh();
    });
  }

  static String _two(int value) => value.toString().padLeft(2, '0');
  static String _localDateTime(DateTime d) =>
      '${_two(d.day)}-${_two(d.month)}-${d.year} '
      '${_two(d.hour)}:${_two(d.minute)}';
  static String _timezone(double h) {
    final offset = (h * 60).round();
    final sign = offset < 0 ? '-' : '+';
    final absOffset = offset.abs();
    return 'UTC$sign${_two(absOffset ~/ 60)}:${_two(absOffset % 60)}';
  }

  Widget _transitLine(D10PavTransitPlanet t) {
    final position = t.position;
    final k = t.kakshya;
    final hasBindu = k.hasBindu;
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 2),
      dense: true,
      leading: Icon(hasBindu ? Icons.check_circle_outline : Icons.info_outline,
          color: hasBindu ? const Color(0xFF167A4C) : const Color(0xFFB16479)),
      title: Text('${position.name}${t.isDashaLord ? ' • దశానాథుడు' : ''} '
          '— రాశి ${position.signIndex + 1} • '
          '${position.degreesInSign.toStringAsFixed(4)}°',
          style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800)),
      subtitle: Text(
          'నిరయణ దీర్ఘాంశం ${position.longitude.toStringAsFixed(4)}° • '
          'జన్మ లగ్నం నుంచి ${t.houseFromNatalLagna}వ భావం • '
          '${position.retrograde ? 'వక్రం' : 'మార్గి'}\n'
          'కక్ష్య ${k.kakshyaIndex}/8: ${k.giver} '
          '(${k.startDegree.toStringAsFixed(2)}°–${k.endDegree.toStringAsFixed(2)}°) '
          '• PAV ${hasBindu ? '1' : '0'} • '
          'BAV ${t.bav}/8 • SAV ${t.sav}\n'
          '${t.signal}',
          style: const TextStyle(fontSize: 11.5, height: 1.36)),
    );
  }

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFFEDF5FB),
    surfaceTintColor: Colors.transparent,
    child: Padding(
      padding: const EdgeInsets.all(11),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('అప్పటి ఖచ్చిత గోచారం • PAV కక్ష్య',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        Text('సమయం: ${_localDateTime(_selectedLocal)} '
            '(${_timezone(widget.birthData.timezoneOffsetHours)})',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(spacing: 6, runSpacing: 4, children: [
          OutlinedButton.icon(
              onPressed: _pickDate,
              icon: const Icon(Icons.calendar_month_outlined, size: 17),
              label: const Text('తేదీ మార్చండి')),
          OutlinedButton.icon(
              onPressed: _pickTime,
              icon: const Icon(Icons.access_time, size: 17),
              label: const Text('సమయం మార్చండి')),
        ]),
        Text(_activeWindow == null
            ? 'ఎంచుకున్న తేదీ ఈ వృత్తి దశా విండోలో లేదు; '
              'గోచార ఆధారాన్ని మాత్రమే చూపిస్తున్నాం.'
            : 'ఆ తేదీ దశ: ${_activeWindow!.mahadasha} / '
              '${_activeWindow!.antardasha} • దశతో PAV క్రాస్-చెక్',
            style: const TextStyle(fontSize: 11.5)),
        const SizedBox(height: 6),
        FutureBuilder<D10PavTransitReport>(
          future: _report,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Row(children: [
                  SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2)),
                  SizedBox(width: 8),
                  Expanded(child: Text('Swiss Ephemeris గోచార డిగ్రీలు గణిస్తోంది…')),
                ]),
              );
            }
            if (snapshot.hasError || !snapshot.hasData) {
              return Text('గోచార గణన సాధ్యం కాలేదు: ${snapshot.error}',
                  style: const TextStyle(color: Color(0xFFAD2444)));
            }
            final data = snapshot.data!;
            final main = data.planets.where((p) =>
                p.position.name == 'Jupiter' || p.position.name == 'Saturn')
                .toList(growable: false);
            final additional = data.planets.where((p) =>
                p.position.name != 'Jupiter' && p.position.name != 'Saturn')
                .toList(growable: false);
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              for (final p in main) _transitLine(p),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                initiallyExpanded: false,
                title: const Text('మిగతా 5 గ్రహాల గోచారం',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
                subtitle: const Text('రవి, చంద్ర, కుజ, బుధ, శుక్ర — ఖచ్చిత డిగ్రీలు'),
                children: [for (final p in additional) _transitLine(p)],
              ),
              if (data.omittedDashaLords.isNotEmpty)
                Text('రాహు/కేతు వంటి దశానాథులకు సంప్రదాయ ఏడు గ్రహాల '
                    'PAVలో ప్రత్యేక స్వీకర్త వరుస లేదు: '
                    '${data.omittedDashaLords.join(', ')}',
                    style: const TextStyle(fontSize: 11.5)),
              Text('Rule: ${data.ruleId} • ${D10PavTransitCareerService.source} • ${data.audit}',
                  style: const TextStyle(fontSize: 11, height: 1.4)),
            ]);
          },
        ),
      ]),
    ),
  );
}
