import 'd10_career_service.dart';
import 'varga_rule_service.dart';

/// Comparison of *astrological source-evidence coverage*, never measured
/// promotion odds, income growth or monetary loss. The main D10 mode and the
/// earlier D1 mode are kept separate; a non-match is not a denial of work.
class D10CareerModeEvidence {
  final String key;
  final String title;
  final bool earlyStage;
  final bool mainStage;
  final int? favorableSharePercent;
  final int? obstacleSharePercent;
  final int? professionFamilyEvidencePercent;
  final int favorableSignals;
  final int obstacleSignals;
  final int checkedSignals;
  final List<String> favorableRuleIds;
  final List<String> obstacleRuleIds;
  final String audit;

  const D10CareerModeEvidence({
    required this.key,
    required this.title,
    required this.earlyStage,
    required this.mainStage,
    required this.favorableSharePercent,
    required this.obstacleSharePercent,
    required this.professionFamilyEvidencePercent,
    required this.favorableSignals,
    required this.obstacleSignals,
    required this.checkedSignals,
    required this.favorableRuleIds,
    required this.obstacleRuleIds,
    required this.audit,
  });
}

class D10CareerComparison {
  final D10CareerModeEvidence business;
  final D10CareerModeEvidence job;
  final String strongerMode;
  final String firstProfession;
  final String laterProfession;
  final String conclusion;
  final String audit;

  const D10CareerComparison({
    required this.business,
    required this.job,
    required this.strongerMode,
    required this.firstProfession,
    required this.laterProfession,
    required this.conclusion,
    required this.audit,
  });
}

class D10CareerComparisonService {
  static const _business = 'GOCHARASHTHA';
  static const _job = 'AGOCHARASHTHA';
  static const _commonRules = [
    'D10-BASE-01', 'D10-BASE-02', 'D10-BASE-03',
    'D10-BASE-04', 'D10-BASE-05', 'D10-BASE-06',
    'D10-RISE-FALL',
  ];

  static String _stage(String state) => switch (state) {
    _business => 'వ్యాపారం / స్వయం ఉపాధి',
    _job => 'ఉద్యోగం / సర్వీస్',
    _ => 'మిశ్రమం — క్రమం నిర్ధారణ కాలేదు',
  };

  static Map<String, int> _professionScores(VargaRuleHit? hit) {
    if (hit == null || !hit.autoEvaluated || !hit.applicable) return {};
    // This is the existing, source-linked D10-JOB-BUSINESS calculation.
    // Never guess a 0 score when the profession evaluator is unavailable.
    final r = RegExp(r'Job\s+(\d+)%\s+vs\s+Business\s+(\d+)%')
        .firstMatch(hit.result);
    if (r == null) return {};
    final job = int.tryParse(r.group(1)!);
    final business = int.tryParse(r.group(2)!);
    if (job == null || business == null || job < 0 || business < 0 ||
        job > 100 || business > 100) return {};
    return {_job: job, _business: business};
  }

  static D10CareerComparison evaluate({
    required D10SaturnStream saturn,
    required List<VargaRuleHit> rules,
  }) {
    final byId = <String, VargaRuleHit>{
      for (final hit in rules)
        if (hit.factor == 10 && hit.autoEvaluated && hit.applicable)
          hit.ruleId: hit,
    };
    final fit = _professionScores(byId['D10-JOB-BUSINESS']);
    final common = [for (final id in _commonRules)
      if (byId.containsKey(id)) byId[id]!];

    D10CareerModeEvidence mode(String key, String title, String modeRuleId) {
      final early = saturn.birthState == key;
      final main = saturn.dashamsaState == key;
      final favorable = <String>[], risks = <String>[];
      // A test is only counted when the stream actually resolves to one of
      // the user's two named modes. A MIXED state is not a failed test.
      final checkedModes = [saturn.birthState, saturn.dashamsaState]
          .where((s) => s == _business || s == _job).length;
      final modeSupport = (early ? 1 : 0) + (main ? 1 : 0);
      if (modeSupport > 0) {
        if (byId.containsKey('D10-SEQUENCE')) favorable.add('D10-SEQUENCE');
        if (byId.containsKey(modeRuleId)) favorable.add(modeRuleId);
      }
      // Business partnership and loss-of-service are separate source checks;
      // never charge a matched job-loss risk to business as well.
      final specific = key == _business ? 'D10-PARTNERSHIP' : 'D10-JOB-LOSS';
      final checkedQuality = [
        ...common,
        if (byId.containsKey(specific)) byId[specific]!,
      ];
      for (final rule in checkedQuality) {
        if (rule.tone == VargaRuleTone.favorable) {
          favorable.add(rule.ruleId);
        } else if (rule.tone == VargaRuleTone.caution) {
          risks.add(rule.ruleId);
        }
      }
      final familyFit = fit[key];
      // Favorable share uses independent checked signals: one D1 work-mode,
      // one D10 work-mode, each existing D10 common rule, and one existing
      // profession-family score when available. A 62% profession score counts
      // as 0.62 of ONE source-evidence unit, not as 62% promotion probability.
      final possible = checkedModes + checkedQuality.length +
          (familyFit == null ? 0 : 1);
      final supportUnits = modeSupport +
          checkedQuality.where((r) => r.tone == VargaRuleTone.favorable).length;
      final value = possible == 0 ? null :
          ((supportUnits + (familyFit ?? 0) / 100) / possible * 100)
              .round().clamp(0, 100).toInt();
      final riskShare = checkedQuality.isEmpty ? null :
          (risks.length / checkedQuality.length * 100)
              .round().clamp(0, 100).toInt();
      if (familyFit != null && familyFit > 0) favorable.add('D10-JOB-BUSINESS');
      return D10CareerModeEvidence(
        key: key, title: title, earlyStage: early, mainStage: main,
        favorableSharePercent: value,
        obstacleSharePercent: riskShare,
        professionFamilyEvidencePercent: familyFit,
        favorableSignals: supportUnits,
        obstacleSignals: risks.length,
        checkedSignals: possible,
        favorableRuleIds: List.unmodifiable(favorable.toSet()),
        obstacleRuleIds: List.unmodifiable(risks.toSet()),
        audit: 'D1 ప్రారంభ శని విధానం: ${saturn.birthState}; '
            'D10 ప్రధాన శని విధానం: ${saturn.dashamsaState}; '
            'D9 మద్దతు: ${saturn.navamsaState}. '
            'పరీక్షించిన ఆధారాలు: $possible; అనుకూల: $supportUnits; '
            'ఆటంక: ${risks.length}. '
            '${familyFit == null ? 'వృత్తిరంగ స్కోరు లభించలేదు.' : 'వృత్తిరంగ ఆధారం: $familyFit%.'}',
      );
    }

    final b = mode(_business, 'గోచరిష్ట — వ్యాపారం / స్వయం ఉపాధి',
        'D10-GOCHARISTA');
    final j = mode(_job, 'అగోచరిష్ట — ఉద్యోగం / సర్వీస్',
        'D10-AGOCHARISTA');
    // The user's sequence source explicitly says D1 is *earlier* and D10 is
    // *later/main*. Prefer it to a generic numerical score if D10 is resolved.
    final strongest = saturn.dashamsaState == _business ? _business :
        saturn.dashamsaState == _job ? _job :
        b.favorableSharePercent != null && j.favorableSharePercent != null &&
            b.favorableSharePercent! > j.favorableSharePercent! ? _business :
        b.favorableSharePercent != null && j.favorableSharePercent != null &&
            j.favorableSharePercent! > b.favorableSharePercent! ? _job : 'MIXED';
    final first = _stage(saturn.birthState);
    final later = _stage(saturn.dashamsaState);
    final conclusion = strongest == _business
        ? 'ప్రధాన వృత్తి ఆధారం వ్యాపారం / స్వయం ఉపాధి వైపు ఉంది.'
        : strongest == _job
            ? 'ప్రధాన వృత్తి ఆధారం ఉద్యోగం / సర్వీస్ వైపు ఉంది.'
            : 'ఉద్యోగం, వ్యాపారం మధ్య స్పష్టమైన ఆధిక్యం ఈ గణనలో లేదు.';
    return D10CareerComparison(
      business: b, job: j, strongerMode: strongest,
      firstProfession: first, laterProfession: later,
      conclusion: conclusion,
      audit: 'ఇది గణించిన మూల నియమాల ఆధారాల వాటా మాత్రమే. '
          'ఎదుగుదల/నష్టం శాతాలు నిజమైన జీతం, వ్యాపార లాభం, '
          'ఆర్థిక నష్టం లేదా సంఘటన సంభావ్యతను కొలవవు. '
          'ఒకే D10 సాధారణ ఆటంక నియమం రెండు విధానాలకూ '
          'వర్తించవచ్చు; రెండుసార్లు నష్టం అని లెక్కించరాదు.',
    );
  }
}
