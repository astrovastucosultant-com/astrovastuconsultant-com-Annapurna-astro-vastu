import 'dart:math' as math;

import 'package:sweph/sweph.dart';

import '../models/birth_data.dart';
import 'astro_calculation_service.dart';
import 'western_timing_settings_v433.dart';

/// Western/TROPICAL, geocentric longitudinal contacts, calculated independently
/// of the sidereal birth-chart display. These are geometrical evidence only;
/// they do not by themselves establish an event, outcome or a BTR correction.
///
/// Secondary progression: 1 mean tropical year of life = 1 ephemeris day.
/// Solar Arc: directed longitude = natal longitude + (progressed Sun - natal Sun).
/// Sampling resolution: one local civil day, at 12:00 local standard time.
class WesternTimingEngineV434 {
  WesternTimingEngineV434._();

  static const double tropicalYearDays = 365.2425;
  static const Map<String, HeavenlyBody> bodies = {
    'Sun': HeavenlyBody.SE_SUN,
    'Moon': HeavenlyBody.SE_MOON,
    'Mercury': HeavenlyBody.SE_MERCURY,
    'Venus': HeavenlyBody.SE_VENUS,
    'Mars': HeavenlyBody.SE_MARS,
    'Jupiter': HeavenlyBody.SE_JUPITER,
    'Saturn': HeavenlyBody.SE_SATURN,
    'Uranus': HeavenlyBody.SE_URANUS,
    'Neptune': HeavenlyBody.SE_NEPTUNE,
    'Pluto': HeavenlyBody.SE_PLUTO,
  };
  static const Map<String, double> aspects = {
    'Conjunction': 0.0,
    'Sextile': 60.0,
    'Square': 90.0,
    'Trine': 120.0,
    'Opposition': 180.0,
  };

  static double normalize(double longitude) => (longitude % 360.0 + 360.0) % 360.0;

  static double separation(double a, double b) {
    final delta = (normalize(a - b)).abs();
    return math.min(delta, 360.0 - delta);
  }

  static double aspectOrb(double a, double b, double angle) =>
      (separation(a, b) - angle).abs();

  static DateTime secondaryDate(DateTime birthUtc, DateTime targetUtc) {
    final b = birthUtc.toUtc();
    final t = targetUtc.toUtc();
    final ageDays = t.difference(b).inMicroseconds /
        Duration.microsecondsPerDay;
    final progressedDays = ageDays / tropicalYearDays;
    return b.add(Duration(
      microseconds: (progressedDays * Duration.microsecondsPerDay).round(),
    ));
  }

  static double solarArc(double natalSun, double progressedSun) =>
      normalize(progressedSun - natalSun);

  static double _julianDay(DateTime input) {
    final utc = input.toUtc();
    final hour = utc.hour + utc.minute / 60.0 + utc.second / 3600.0 +
        utc.millisecond / 3600000.0 + utc.microsecond / 3600000000.0;
    return Sweph.swe_julday(utc.year, utc.month, utc.day, hour,
        CalendarType.SE_GREG_CAL);
  }

  static double _tropicalPosition(double jd, HeavenlyBody body) {
    final p = Sweph.swe_calc_ut(jd, body,
        SwephFlag.SEFLG_MOSEPH | SwephFlag.SEFLG_SPEED);
    if (!p.longitude.isFinite) throw StateError('Invalid ephemeris position');
    return normalize(p.longitude);
  }

  static DateTime _sampleTime(BirthData birth, int year, int month, int day) {
    // Noon in the chart's fixed, explicitly supplied UTC offset. This is a
    // daily scan, NOT an exact ingress time and not daylight-saving aware.
    return DateTime.utc(year, month, day, 12).subtract(Duration(
        minutes: (birth.timezoneOffsetHours * 60).round()));
  }

  /// Computes month-wide daily contact windows. A single window represents
  /// consecutive day-level matches, with its best observed (minimum) orb.
  static Future<WesternTimingReportV434> scanMonth({
    required BirthData birth,
    required int year,
    required int month,
    required WesternTimingSettingsV433 settings,
  }) async {
    if (month < 1 || month > 12 || year < 1800 || year > 2200) {
      throw ArgumentError('Invalid Western Timing month');
    }
    if (!birth.timezoneOffsetHours.isFinite ||
        birth.timezoneOffsetHours.abs() > 14) {
      throw ArgumentError('Birth UTC offset is invalid');
    }
    final firstTarget = _sampleTime(birth, year, month, 1);
    final ageAtFirstDay = firstTarget.difference(birth.utcDateTime).inDays;
    if (ageAtFirstDay < 0 || ageAtFirstDay > 150 * 366) {
      throw ArgumentError('Select a date within 0–150 years after birth');
    }
    await AstroCalculationService.initialize();
    if (!AstroCalculationService.isInitialized) {
      throw StateError('Swiss Ephemeris initialization failed: '
          '${AstroCalculationService.initError}');
    }
    final natalJd = _julianDay(birth.utcDateTime);
    final natal = <String, double>{
      for (final entry in bodies.entries)
        entry.key: _tropicalPosition(natalJd, entry.value),
    };
    final lastDay = DateTime.utc(year, month + 1, 0).day;
    final rawContacts = <WesternTimingContactV434>[];
    final midDay = (lastDay + 1) ~/ 2;
    double? midSolarArc;
    DateTime? midProgressedDate;
    final orbLimit = settings.orbDegrees;

    for (var day = 1; day <= lastDay; day++) {
      final target = _sampleTime(birth, year, month, day);
      final progressedDate = secondaryDate(birth.utcDateTime, target);
      final progressJd = _julianDay(progressedDate);
      final targetJd = _julianDay(target);
      final isMiddle = day == midDay;
      if (isMiddle) midProgressedDate = progressedDate;

      final needArc = settings.solarArcEnabled;
      final progressedSun = needArc
          ? _tropicalPosition(progressJd, HeavenlyBody.SE_SUN)
          : null;
      final arc = progressedSun == null
          ? null
          : solarArc(natal['Sun']!, progressedSun);
      if (isMiddle) midSolarArc = arc;

      void addContacts(String method, String movingBody, double longitude,
          Iterable<String> enabledAspects) {
        for (final natalEntry in natal.entries) {
          for (final aspect in enabledAspects) {
            // Do not let a nearly stationary progressed body dominate the
            // evidence list through its trivial natal self-conjunction.
            if (method == 'secondary' && aspect == 'Conjunction' &&
                movingBody == natalEntry.key) continue;
            final deviation = aspectOrb(
                longitude, natalEntry.value, aspects[aspect]!);
            if (deviation <= orbLimit + 1e-9) {
              rawContacts.add(WesternTimingContactV434(
                method: method,
                movingPlanet: movingBody,
                natalPlanet: natalEntry.key,
                aspect: aspect,
                deviationDegrees: deviation,
                localDate: DateTime.utc(year, month, day),
                movingLongitude: longitude,
                natalLongitude: natalEntry.value,
              ));
            }
          }
        }
      }

      if (settings.secondaryEnabled) {
        for (final entry in bodies.entries) {
          // The progressed Moon has its own independent switch and is never
          // counted twice when Secondary and Progressed Moon are both on.
          if (entry.key == 'Moon') continue;
          addContacts('secondary', entry.key,
              _tropicalPosition(progressJd, entry.value), aspects.keys);
        }
      }
      if (settings.progressedMoonEnabled) {
        addContacts('progressedMoon', 'Moon',
            _tropicalPosition(progressJd, HeavenlyBody.SE_MOON), aspects.keys);
      }
      if (arc != null) {
        for (final entry in natal.entries) {
          addContacts('solarArc', entry.key, normalize(entry.value + arc),
              aspects.keys);
        }
      }
      if (settings.transitsEnabled) {
        for (final name in settings.transitPlanets) {
          final body = bodies[name];
          if (body == null) continue;
          addContacts('transit', name,
              _tropicalPosition(targetJd, body), settings.transitAspects);
        }
      }
    }

    // Merge runs only when the aspect/contact key and civil days are adjacent.
    final grouped = <String, List<WesternTimingContactV434>>{};
    for (final c in rawContacts) {
      (grouped[c.groupKey] ??= []).add(c);
    }
    final windows = <WesternTimingWindowV434>[];
    for (final contacts in grouped.values) {
      contacts.sort((a, b) => a.localDate.compareTo(b.localDate));
      var start = contacts.first.localDate;
      var end = start;
      var best = contacts.first;
      for (final c in contacts.skip(1)) {
        if (c.localDate.difference(end).inDays > 1) {
          windows.add(WesternTimingWindowV434(
              firstDate: start, lastDate: end, best: best));
          start = c.localDate;
          best = c;
        } else if (c.deviationDegrees < best.deviationDegrees) {
          best = c;
        }
        end = c.localDate;
      }
      windows.add(WesternTimingWindowV434(
          firstDate: start, lastDate: end, best: best));
    }
    windows.sort((a, b) {
      final orb = a.best.deviationDegrees.compareTo(b.best.deviationDegrees);
      return orb != 0 ? orb : a.best.localDate.compareTo(b.best.localDate);
    });
    return WesternTimingReportV434(
      year: year,
      month: month,
      birthUtc: birth.utcDateTime,
      natalTropicalLongitudes: Map.unmodifiable(natal),
      midMonthProgressedDateUtc: midProgressedDate!,
      midMonthSolarArcDegrees: midSolarArc,
      windows: List.unmodifiable(windows),
      sampledDays: lastDay,
    );
  }
}

class WesternTimingContactV434 {
  const WesternTimingContactV434({
    required this.method,
    required this.movingPlanet,
    required this.natalPlanet,
    required this.aspect,
    required this.deviationDegrees,
    required this.localDate,
    required this.movingLongitude,
    required this.natalLongitude,
  });
  final String method;
  final String movingPlanet;
  final String natalPlanet;
  final String aspect;
  final double deviationDegrees;
  final DateTime localDate;
  final double movingLongitude;
  final double natalLongitude;

  String get groupKey => '$method/$movingPlanet/$natalPlanet/$aspect';
  String get ruleId => switch (method) {
    'secondary' => 'WEST-SEC-434',
    'solarArc' => 'WEST-SA-434',
    'progressedMoon' => 'WEST-PM-434',
    'transit' => 'WEST-TR-434',
    _ => 'WEST-GEOM-434',
  };
  WesternEvidenceMethod get evidenceMethod => switch (method) {
    'secondary' => WesternEvidenceMethod.secondaryProgression,
    'solarArc' => WesternEvidenceMethod.solarArc,
    'progressedMoon' => WesternEvidenceMethod.progressedMoon,
    'transit' => WesternEvidenceMethod.transit,
    _ => WesternEvidenceMethod.natal,
  };
}

class WesternTimingWindowV434 {
  const WesternTimingWindowV434({
    required this.firstDate,
    required this.lastDate,
    required this.best,
  });
  final DateTime firstDate;
  final DateTime lastDate;
  final WesternTimingContactV434 best;
}

class WesternTimingReportV434 {
  const WesternTimingReportV434({
    required this.year,
    required this.month,
    required this.birthUtc,
    required this.natalTropicalLongitudes,
    required this.midMonthProgressedDateUtc,
    required this.midMonthSolarArcDegrees,
    required this.windows,
    required this.sampledDays,
  });
  final int year;
  final int month;
  final DateTime birthUtc;
  final Map<String, double> natalTropicalLongitudes;
  final DateTime midMonthProgressedDateUtc;
  final double? midMonthSolarArcDegrees;
  final List<WesternTimingWindowV434> windows;
  final int sampledDays;
}
