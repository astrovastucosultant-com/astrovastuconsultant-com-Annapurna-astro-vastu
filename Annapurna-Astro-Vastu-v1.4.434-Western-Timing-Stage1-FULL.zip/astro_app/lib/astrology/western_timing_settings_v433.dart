import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

/// Independent Western configuration. This does not calculate event dates or
/// replace any missing progression / BTR ephemeris implementation.
enum WesternEvidenceMethod {
  natal,
  secondaryProgression,
  solarArc,
  progressedMoon,
  transit,
}

/// Evidence from a future verified engine can be filtered without allowing
/// the Transit layer to influence a progression-only result when switched off.
class WesternTimingEvidence {
  const WesternTimingEvidence({
    required this.method,
    required this.description,
    this.transitingPlanet,
    this.aspect,
    this.orbDegrees,
  });

  final WesternEvidenceMethod method;
  final String description;
  final String? transitingPlanet;
  final String? aspect;
  final double? orbDegrees;
}

class WesternTimingSettingsV433 {
  const WesternTimingSettingsV433({
    this.transitsEnabled = true,
    this.secondaryEnabled = true,
    this.solarArcEnabled = true,
    this.progressedMoonEnabled = true,
    this.orbDegrees = 1.0,
    this.transitPlanets = defaultPlanets,
    this.transitAspects = defaultAspects,
  });

  static const String storageKey = 'western_timing_settings_v433';
  static const List<String> allPlanets = [
    'Sun', 'Moon', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn',
    'Uranus', 'Neptune', 'Pluto',
  ];
  static const List<String> allAspects = [
    'Conjunction', 'Opposition', 'Trine', 'Square', 'Sextile',
  ];
  static const List<String> defaultPlanets = allPlanets;
  static const List<String> defaultAspects = allAspects;

  final bool transitsEnabled;
  final bool secondaryEnabled;
  final bool solarArcEnabled;
  final bool progressedMoonEnabled;
  final double orbDegrees;
  final List<String> transitPlanets;
  final List<String> transitAspects;

  WesternTimingSettingsV433 copyWith({
    bool? transitsEnabled,
    bool? secondaryEnabled,
    bool? solarArcEnabled,
    bool? progressedMoonEnabled,
    double? orbDegrees,
    List<String>? transitPlanets,
    List<String>? transitAspects,
  }) {
    return WesternTimingSettingsV433(
      transitsEnabled: transitsEnabled ?? this.transitsEnabled,
      secondaryEnabled: secondaryEnabled ?? this.secondaryEnabled,
      solarArcEnabled: solarArcEnabled ?? this.solarArcEnabled,
      progressedMoonEnabled: progressedMoonEnabled ?? this.progressedMoonEnabled,
      orbDegrees: orbDegrees ?? this.orbDegrees,
      transitPlanets: List.unmodifiable(transitPlanets ?? this.transitPlanets),
      transitAspects: List.unmodifiable(transitAspects ?? this.transitAspects),
    );
  }

  Map<String, Object> toJson() => {
    'schema': 1,
    'transitsEnabled': transitsEnabled,
    'secondaryEnabled': secondaryEnabled,
    'solarArcEnabled': solarArcEnabled,
    'progressedMoonEnabled': progressedMoonEnabled,
    'orbDegrees': orbDegrees,
    'transitPlanets': transitPlanets,
    'transitAspects': transitAspects,
  };

  String encode() => jsonEncode(toJson());

  static WesternTimingSettingsV433 decode(String? raw) {
    if (raw == null || raw.isEmpty) return const WesternTimingSettingsV433();
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! Map<String, dynamic>) {
        return const WesternTimingSettingsV433();
      }
      final orb = decoded['orbDegrees'];
      final numericOrb = orb is num ? orb.toDouble() : 1.0;
      final validOrb = [0.5, 1.0, 2.0].contains(numericOrb) ? numericOrb : 1.0;
      final planets = _safeSelection(decoded['transitPlanets'], allPlanets);
      final aspects = _safeSelection(decoded['transitAspects'], allAspects);
      return WesternTimingSettingsV433(
        transitsEnabled: decoded['transitsEnabled'] is bool
            ? decoded['transitsEnabled'] as bool : true,
        secondaryEnabled: decoded['secondaryEnabled'] is bool
            ? decoded['secondaryEnabled'] as bool : true,
        solarArcEnabled: decoded['solarArcEnabled'] is bool
            ? decoded['solarArcEnabled'] as bool : true,
        progressedMoonEnabled: decoded['progressedMoonEnabled'] is bool
            ? decoded['progressedMoonEnabled'] as bool : true,
        orbDegrees: validOrb,
        transitPlanets: planets,
        transitAspects: aspects,
      );
    } catch (_) {
      return const WesternTimingSettingsV433();
    }
  }

  static List<String> _safeSelection(dynamic raw, List<String> accepted) {
    if (raw is! List) return List.unmodifiable(accepted);
    final selection = accepted.where((value) => raw.contains(value)).toList();
    return List.unmodifiable(selection.isEmpty ? accepted : selection);
  }

  static Future<WesternTimingSettingsV433> load() async {
    final prefs = await SharedPreferences.getInstance();
    return decode(prefs.getString(storageKey));
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(storageKey, encode());
  }

  static Future<void> reset() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(storageKey);
  }

  bool allows(WesternTimingEvidence event) {
    switch (event.method) {
      case WesternEvidenceMethod.natal:
        return true;
      case WesternEvidenceMethod.secondaryProgression:
        return secondaryEnabled;
      case WesternEvidenceMethod.solarArc:
        return solarArcEnabled;
      case WesternEvidenceMethod.progressedMoon:
        return progressedMoonEnabled;
      case WesternEvidenceMethod.transit:
        if (!transitsEnabled) return false;
        final planet = event.transitingPlanet;
        final aspect = event.aspect;
        final orb = event.orbDegrees;
        // Transit evidence without a documented contact cannot be counted.
        if (planet == null || aspect == null || orb == null ||
            !orb.isFinite || orb < 0) return false;
        return transitPlanets.contains(planet) &&
            transitAspects.contains(aspect) && orb <= orbDegrees;
    }
  }

  List<WesternTimingEvidence> filterEvidence(
    Iterable<WesternTimingEvidence> candidates,
  ) => List.unmodifiable(candidates.where(allows));
}
