import 'astro_models.dart';
import 'astro_calculation_service.dart';
import '../models/birth_data.dart';
import 'package:sweph/sweph.dart';
import 'dasha_service.dart';

class KpStellarPosition {
  final String body;
  final int signIndex;
  final String signLord;
  final int nakshatraIndex;
  final String starLord;
  final String subLord;
  final double longitude;

  const KpStellarPosition({
    required this.body,
    required this.signIndex,
    required this.signLord,
    required this.nakshatraIndex,
    required this.starLord,
    required this.subLord,
    required this.longitude,
  });
}

/// A classical 1–249 KP Prashna number fixes the FIRST cusp only.
/// Other horary cusps and planetary longitudes require the question epoch/place.
class KpHoraryEntry {
  final int number;
  final int signIndex;
  final int nakshatraIndex;
  final String signLord;
  final String starLord;
  final String subLord;
  final double startLongitude;
  final double endLongitude;

  const KpHoraryEntry({
    required this.number,
    required this.signIndex,
    required this.nakshatraIndex,
    required this.signLord,
    required this.starLord,
    required this.subLord,
    required this.startLongitude,
    required this.endLongitude,
  });
}

class KpChartDetails {
  final List<KpStellarPosition> planets;
  final List<KpStellarPosition> cusps;
  final double ayanamsaDegrees;

  const KpChartDetails({
    required this.planets,
    required this.cusps,
    required this.ayanamsaDegrees,
  });
}

class KpEventGroup {
  final String event;
  final List<int> favourableHouses;
  final List<int> contraryHouses;
  final String primaryCusp;

  const KpEventGroup({
    required this.event,
    required this.favourableHouses,
    this.contraryHouses = const [],
    required this.primaryCusp,
  });
}

class KpService {
  /// Independent KP chart: Krishnamurti ayanamsa and sidereal Placidus cusps.
  /// The natal chart's selected ayanamsa is deliberately NOT reused.
  static Future<KpChartDetails> calculateKpChart(BirthData birth) async {
    await AstroCalculationService.initialize();
    if (!AstroCalculationService.isInitialized) {
      throw StateError('Swiss Ephemeris not initialized');
    }
    final utc = birth.utcDateTime;
    final hour = utc.hour + utc.minute / 60.0 + utc.second / 3600.0 +
        utc.millisecond / 3600000.0;
    final jd = Sweph.swe_julday(utc.year, utc.month, utc.day,
        hour, CalendarType.SE_GREG_CAL);
    Sweph.swe_set_sid_mode(SiderealMode.SE_SIDM_KRISHNAMURTI,
        SiderealModeFlag.SE_SIDBIT_NONE, 0.0, 0.0);
    final flags = SwephFlag.SEFLG_MOSEPH | SwephFlag.SEFLG_SIDEREAL |
        SwephFlag.SEFLG_SPEED;
    final bodies = <HeavenlyBody, String>{
      HeavenlyBody.SE_SUN: 'Sun',
      HeavenlyBody.SE_MOON: 'Moon',
      HeavenlyBody.SE_MARS: 'Mars',
      HeavenlyBody.SE_MERCURY: 'Mercury',
      HeavenlyBody.SE_JUPITER: 'Jupiter',
      HeavenlyBody.SE_VENUS: 'Venus',
      HeavenlyBody.SE_SATURN: 'Saturn',
      HeavenlyBody.SE_TRUE_NODE: 'Rahu',
    };
    final planets = <KpStellarPosition>[];
    double? rahuLongitude;
    for (final body in bodies.entries) {
      final longitude = Sweph.swe_calc_ut(jd, body.key, flags).longitude;
      if (!longitude.isFinite) throw StateError('Invalid KP planet longitude');
      if (body.value == 'Rahu') rahuLongitude = longitude;
      planets.add(forLongitude(body.value, longitude));
    }
    if (rahuLongitude == null) throw StateError('Rahu calculation missing');
    planets.add(forLongitude('Ketu', rahuLongitude + 180.0));

    final houses = Sweph.swe_houses_ex(jd, SwephFlag.SEFLG_SIDEREAL,
        birth.latitude, birth.longitude, Hsys.P);
    final values = houses.cusps;
    if (values.length != 12 && values.length != 13) {
      throw StateError('Unexpected number of KP Placidus cusps');
    }
    final cusps = <KpStellarPosition>[];
    for (var house = 1; house <= 12; house++) {
      final longitude = values[values.length == 13 ? house : house - 1];
      if (!longitude.isFinite) throw StateError('Invalid KP cusp longitude');
      cusps.add(forLongitude('Cusp $house', longitude));
    }
    final ayanamsa = Sweph.swe_get_ayanamsa_ut(jd);
    if (!ayanamsa.isFinite) throw StateError('Invalid KP ayanamsa');
    return KpChartDetails(
      planets: List.unmodifiable(planets),
      cusps: List.unmodifiable(cusps),
      ayanamsaDegrees: ayanamsa,
    );
  }
  static const List<String> signLords = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];

  /// KP's 243 stellar subs become 249 when the six subs crossing a
  /// 30-degree sign boundary are split into distinct Sign-Lord entries.
  /// All boundaries are built in integer arcseconds to avoid rounding drift.
  static final List<KpHoraryEntry> horaryTable = _makeHoraryTable();

  static KpHoraryEntry horaryNumber(int number) {
    if (number < 1 || number > 249) {
      throw RangeError.range(number, 1, 249, 'KP horary number');
    }
    return horaryTable[number - 1];
  }

  static List<KpHoraryEntry> _makeHoraryTable() {
    const starSeconds = 48000; // 13 degrees 20 minutes
    const signSeconds = 108000; // 30 degrees
    final result = <KpHoraryEntry>[];
    for (var nak = 0; nak < 27; nak++) {
      var cursor = nak * starSeconds;
      final starIndex = nak % DashaService.lordOrder.length;
      final starLord = DashaService.lordOrder[starIndex];
      for (var sub = 0; sub < 9; sub++) {
        final subLord = DashaService.lordOrder[(starIndex + sub) % 9];
        final end = cursor + 400 * DashaService.years[subLord]!.toInt();
        var partStart = cursor;
        while (partStart < end) {
          final nextSign = (partStart ~/ signSeconds + 1) * signSeconds;
          final partEnd = nextSign < end ? nextSign : end;
          final sign = partStart ~/ signSeconds;
          result.add(KpHoraryEntry(
            number: result.length + 1,
            signIndex: sign,
            nakshatraIndex: nak,
            signLord: signLords[sign],
            starLord: starLord,
            subLord: subLord,
            startLongitude: partStart / 3600.0,
            endLongitude: partEnd / 3600.0,
          ));
          partStart = partEnd;
        }
        cursor = end;
      }
    }
    if (result.length != 249 || result.last.endLongitude != 360.0) {
      throw StateError('Incorrect KP 1–249 sub-boundary mapping');
    }
    return List<KpHoraryEntry>.unmodifiable(result);
  }

  static const List<KpEventGroup> eventGroups = [
    KpEventGroup(
      event: 'Marriage',
      favourableHouses: [2, 7, 11],
      contraryHouses: [1, 6, 10, 12],
      primaryCusp: '7th cusp',
    ),
    KpEventGroup(
      event: 'Employment / Service',
      favourableHouses: [2, 6, 10, 11],
      primaryCusp: '10th cusp',
    ),
    KpEventGroup(
      event: 'Finance / Wealth',
      favourableHouses: [2, 6, 10, 11],
      primaryCusp: '2nd cusp',
    ),
    KpEventGroup(
      event: 'Profit / Fulfilment',
      favourableHouses: [2, 6, 11],
      primaryCusp: '11th cusp',
    ),
    KpEventGroup(
      event: 'Loss',
      favourableHouses: [5, 8, 12],
      primaryCusp: '12th cusp',
    ),
    KpEventGroup(
      event: 'Foreign matters',
      favourableHouses: [3, 9, 12],
      primaryCusp: '9th / 12th cusp',
    ),
    KpEventGroup(
      event: 'Accident',
      favourableHouses: [6, 8, 12],
      primaryCusp: '8th cusp',
    ),
  ];

  static List<KpStellarPosition> planetaryTable(AstroChartResult chart) {
    return chart.planets.map((p) => forLongitude(p.name, p.longitude)).toList(growable: false);
  }

  static KpStellarPosition forLongitude(String body, double longitude) {
    const nakSize = 360.0 / 27.0;
    final normalized = ((longitude % 360.0) + 360.0) % 360.0;
    final sign = (normalized / 30.0).floor() % 12;
    final nak = (normalized / nakSize).floor().clamp(0, 26).toInt();
    final starLordIndex = nak % DashaService.lordOrder.length;
    final starLord = DashaService.lordOrder[starLordIndex];
    final withinStar = normalized - nak * nakSize;
    final subLord = _subLord(starLordIndex, withinStar, nakSize);
    return KpStellarPosition(
      body: body,
      signIndex: sign,
      signLord: signLords[sign],
      nakshatraIndex: nak,
      starLord: starLord,
      subLord: subLord,
      longitude: normalized,
    );
  }

  static String _subLord(int starLordIndex, double withinStar, double nakSize) {
    var cursor = 0.0;
    for (var i = 0; i < DashaService.lordOrder.length; i++) {
      final lord = DashaService.lordOrder[(starLordIndex + i) % DashaService.lordOrder.length];
      final length = nakSize * DashaService.years[lord]! / 120.0;
      if (withinStar < cursor + length || i == DashaService.lordOrder.length - 1) {
        return lord;
      }
      cursor += length;
    }
    // Defensive fallback: the loop above always returns on its final item.
    // Keep an explicit valid value here so release compilation succeeds.
    return DashaService.lordOrder[starLordIndex];
  }
}
