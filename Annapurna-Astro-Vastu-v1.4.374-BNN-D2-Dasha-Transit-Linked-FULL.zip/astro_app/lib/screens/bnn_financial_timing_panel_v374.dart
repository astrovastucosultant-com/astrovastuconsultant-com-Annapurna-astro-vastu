import 'package:flutter/material.dart';

import '../astrology/bnn_financial_evidence_v373.dart';
import '../astrology/bnn_financial_timing_v374.dart';

class BnnFinancialTimingPanelV374 extends StatefulWidget {
  final Future<FinancialTimingResult> Function() load;
  const BnnFinancialTimingPanelV374({super.key, required this.load});
  @override
  State<BnnFinancialTimingPanelV374> createState() => _FinancialTimingState();
}

class _FinancialTimingState extends State<BnnFinancialTimingPanelV374> {
  Future<FinancialTimingResult>? _future;
  int _limit = 10;
  String _filter = 'all';
  static const names = {
    'Sun': 'రవి',
    'Moon': 'చంద్రుడు',
    'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు',
    'Jupiter': 'గురువు',
    'Venus': 'శుక్రుడు',
    'Saturn': 'శని',
    'Rahu': 'రాహువు',
    'Ketu': 'కేతువు',
  };
  static String date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';
  static String label(String p) => names[p] ?? p;
  static String when(FinancialTimingWindow w, DateTime now) =>
      w.periodEnd.isBefore(now)
      ? 'past'
      : w.periodStart.isAfter(now)
      ? 'future'
      : 'present';
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const Text(
        'దశ–అంతర్దశ / గోచార సమయ పరిశీలన',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      const Text(
        'వర్తించిన మూల రూల్‌లోని గ్రహాల దశలకు, వాటి జన్మ రాశులపై గురు–శని '
        'గోచార మద్దతును పరిశీలిస్తాం. ఇది యాప్ సమయ పరిశీలన పద్ధతి; మూల PDFలో తేదీలు ఇవ్వలేదు. '
        '45 రోజుల విరామంతో నమూనా తేదీలు; ఖచ్చిత సంఘటన తేదీలు కావు. '
        'వ్యక్తిగత ఆర్థిక పరిశీలన పరిధి 14–85 ఏళ్లు; ఇది స్క్రీన్ పరిధి మాత్రమే.',
        style: TextStyle(fontSize: 12, height: 1.4),
      ),
      if (_future == null)
        OutlinedButton(
          key: const ValueKey('financial-run-timing'),
          onPressed: () => setState(() => _future = widget.load()),
          child: const Text('దశ–గోచార కాలాలు పరిశీలించండి'),
        ),
      if (_future != null)
        FutureBuilder<FinancialTimingResult>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.hasError)
              return Column(
                children: [
                  const Text(
                    'గోచార గణన పూర్తి కాలేదు; కాల ఫలితం నిర్ధారించలేదు.',
                  ),
                  TextButton(
                    onPressed: () => setState(() => _future = widget.load()),
                    child: const Text('మళ్లీ పరిశీలించండి'),
                  ),
                ],
              );
            if (!snapshot.hasData)
              return const Padding(
                padding: EdgeInsets.all(12),
                child: Row(
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'మూల గ్రహాలు, దశలు, వాస్తవ గోచారం పరిశీలిస్తున్నాం…',
                      ),
                    ),
                  ],
                ),
              );
            final r = snapshot.data!;
            if (r.missingInput != null)
              return Text('గణనకు సమాచారం లేదు: ${r.missingInput}');
            final now = DateTime.now();
            final visible = r.windows
                .where((w) => _filter == 'all' || when(w, now) == _filter)
                .toList();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'పరీక్షించిన దశా కాలాలు: ${r.periodsExamined} • '
                  'గోచార నమూనాలు: ${r.checkpointsExamined} • మద్దతున్న నమూనాలు: ${r.windows.length}',
                  key: const ValueKey('financial-timing-counts'),
                  style: const TextStyle(fontSize: 12),
                ),
                if (r.windows.isEmpty)
                  const Text(
                    'పరీక్షించిన రూల్ గ్రహదశల్లో గురు–శని ఉమ్మడి '
                    'గోచార మద్దతు నమూనా లభించలేదు. సంఘటన జరగదని దీని అర్థం కాదు.',
                  ),
                if (r.rulesWithoutPlanets.isNotEmpty)
                  Text(
                    'సమయ గ్రహ ఎంపిక ఇంకా జతకాలేదు: ${r.rulesWithoutPlanets.join(', ')}',
                  ),
                if (r.windows.isNotEmpty)
                  DropdownButton<String>(
                    value: _filter,
                    isExpanded: true,
                    items: const [
                      DropdownMenuItem(
                        value: 'all',
                        child: Text('అన్ని కాలాలు'),
                      ),
                      DropdownMenuItem(value: 'past', child: Text('గత కాలాలు')),
                      DropdownMenuItem(
                        value: 'present',
                        child: Text('ప్రస్తుత దశా కాలం'),
                      ),
                      DropdownMenuItem(
                        value: 'future',
                        child: Text('భవిష్యత్తు కాలాలు'),
                      ),
                    ],
                    onChanged: (v) {
                      if (v != null)
                        setState(() {
                          _filter = v;
                          _limit = 10;
                        });
                    },
                  ),
                for (final w in visible.take(_limit))
                  Container(
                    key: ValueKey(
                      'financial-window-${w.sampledLocal.toIso8601String()}-${w.links.first.ruleId}',
                    ),
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F4F7),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${label(w.maha)} మహాదశ / ${label(w.antar)} అంతర్దశ',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'పరిశీలించిన దశా పరిధి: ${date(w.periodStart)} నుంచి ${date(w.periodEnd)} వరకు',
                        ),
                        Text(
                          'గోచార మద్దతు నమూనా తేదీ: ${date(w.sampledLocal)}',
                        ),
                        Text(
                          'గురు రాశి: ${w.jupiterSign + 1} • శని రాశి: ${w.saturnSign + 1}',
                          style: const TextStyle(fontSize: 12),
                        ),
                        for (final link in w.links)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(
                              '${link.ruleId} • ${link.tone == BnnFinancialTone.unfavorable
                                  ? 'ప్రతికూల'
                                  : link.tone == BnnFinancialTone.favorable
                                  ? 'అనుకూల'
                                  : 'తటస్థ'} సూచన\n'
                              'మూల గ్రహాలు: ${link.sourcePlanets.map(label).join(', ')}\n'
                              'దశ సంబంధం: ${link.activePlanets.map(label).join(', ')}\n'
                              'గురు–శని ఉమ్మడి మద్దతు: ${link.transitTargets.entries.map((e) => '${label(e.key)} జన్మ రాశి ${e.value + 1}').join(', ')}',
                              style: TextStyle(
                                fontSize: 12,
                                color: link.tone == BnnFinancialTone.unfavorable
                                    ? const Color(0xFF9C2252)
                                    : link.tone == BnnFinancialTone.favorable
                                    ? const Color(0xFF18613A)
                                    : const Color(0xFF455A64),
                              ),
                            ),
                          ),
                        const Text(
                          'ఈ తేదీ సంఘటన జరిగిందని లేదా జరుగుతుందని నిర్ధారణ కాదు.',
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                if (visible.length > _limit)
                  TextButton(
                    onPressed: () => setState(() => _limit += 10),
                    child: const Text('మరిన్ని కాలాలు'),
                  ),
              ],
            );
          },
        ),
    ],
  );
}
