import 'dart:convert';
import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';
import '../utils/astro_format.dart';

/// A source-preserving rule catalog. The supplied 46-page PDF contains Telugu
/// IF/THEN commentary and sutra *references*, not the original sutra text or
/// source-backed remedies. Loading a rule never verifies it against a chart.
class JaiminiCompleteSutraRule {
  final String id;
  final String major;
  final String section;
  final String condition;
  final String result;
  final String source;
  final int page;
  final String sourceKind;

  const JaiminiCompleteSutraRule({
    required this.id,
    required this.major,
    required this.section,
    required this.condition,
    required this.result,
    required this.source,
    required this.page,
    required this.sourceKind,
  });

  factory JaiminiCompleteSutraRule.fromJson(Map<String, dynamic> map) =>
      JaiminiCompleteSutraRule(
        id: map['id'] as String,
        major: map['major'] as String,
        section: map['section'] as String,
        condition: map['condition'] as String,
        result: map['result'] as String,
        source: map['source'] as String,
        page: map['page'] as int,
        sourceKind: map['sourceKind'] as String,
      );
}

class JaiminiRuleCheck {
  /// null = this complete IF/THEN predicate has NOT been implemented.
  /// true/false = the indicated atomic condition has been checked from D9.
  final bool? matched;
  final String evidence;
  const JaiminiRuleCheck(this.matched, this.evidence);
}

class JaiminiCompleteSutraService {
  const JaiminiCompleteSutraService();

  static Future<List<JaiminiCompleteSutraRule>> load() async {
    final raw = await rootBundle.loadString(
      'assets/jaimini/complete_if_then_rules.json',
    );
    final parsed = jsonDecode(raw) as List<dynamic>;
    return parsed
        .map((row) => JaiminiCompleteSutraRule.fromJson(
            Map<String, dynamic>.from(row as Map)))
        .toList(growable: false);
  }

  static JaiminiRuleCheck check({
    required JaiminiCompleteSutraRule rule,
    required AstroChartResult chart,
    required JaiminiResult jaimini,
  }) {
    final ak = jaimini.charaKarakas
        .where((element) => element.code == 'AK')
        .map((element) => element.planet)
        .join(', ');
    final kl = jaimini.karakamsaSignIndex;
    final name = AstroFormat.signNamesTe[kl];
    final intro = 'ఆత్మకారకుడు: $ak; కారకాంశ రాశి: $name. ';
    if (jaimini.hasDegreeTie) {
      return JaiminiRuleCheck(null,
          '${intro}చర కారకాల డిగ్రీలు సమానంగా ఉన్నాయి. కారకాంశం ఆధారంగా తీర్పు పెండింగ్.');
    }

    final id = rule.id;
    final group = id.split('.');
    if (group.length == 2 && group[0] == '3') {
      final n = int.tryParse(group[1]);
      if (n != null && n >= 1 && n <= 12) {
        final ok = kl == n - 1;
        return JaiminiRuleCheck(ok,
          '${intro}ఈ నియమానికి కావాల్సిన AK నవాంశ రాశి: '
          '${AstroFormat.signNamesTe[n - 1]}. '
          'వాస్తవ రాశి: $name. ${ok ? 'రాశి షరతు సరిపోయింది.' : 'రాశి షరతు సరిపోలేదు.'}');
      }
    }
    const supportedOthers = {
      '3.14', '3.15', '3.16', '3.17', '3.18', '3.19',
      '3.20', '3.21', '3.22', '3.36', '3.37',
      '3.38', '3.39', '3.40', '3.41', '3.42', '3.43', '3.44', '3.45',
    };
    if (!supportedOthers.contains(id)) {
      return JaiminiRuleCheck(null,
          '${intro}ఈ నియమంలోని అన్ని IF షరతులకు స్వతంత్ర జాతక గణన ఇంకా '
          'అనుసంధానం కాలేదు. మూల నియమాన్ని చూపుతున్నాం; '
          'వర్తించిందని లేదా వర్తించలేదని ప్రకటించడం లేదు.');
    }
    final d9 = VargaService.calculate(chart, 9);
    final sign2 = (kl + 1) % 12;
    final sign5 = (kl + 4) % 12;
    bool has(int sign, String planet) =>
        d9.planets.any((p) => p.signIndex == sign && p.name == planet);
    bool either(String planet) => has(kl, planet) || has(sign2, planet);
    final names = <String, String>{
      '3.14': 'Sun', '3.16': 'Mars', '3.17': 'Mercury',
      '3.18': 'Jupiter', '3.19': 'Venus', '3.20': 'Saturn',
      '3.21': 'Rahu', '3.22': 'Ketu',
    };
    if (names.containsKey(id)) {
      final planet = names[id]!;
      final matching = either(planet);
      return JaiminiRuleCheck(matching,
          '${intro}నవాంశంలో కారకాంశం ($name) లేదా దాని 2వ రాశి '
          '(${AstroFormat.signNamesTe[sign2]})లో $planet ఉనికి: '
          '${matching ? 'ఉంది' : 'లేదు'}. '
          'ఇది స్థాన పరీక్ష మాత్రమే; అదనపు గ్రహబలం/దృష్టి ఆధారాలు వేరుగా పరిశీలించాలి.');
    }
    if (id == '3.15') {
      final matching = (has(kl, 'Moon') && has(kl, 'Venus')) ||
          (has(sign2, 'Moon') && has(sign2, 'Venus'));
      return JaiminiRuleCheck(null,
          '${intro}కారకాంశం లేదా రెండవ రాశిలో చంద్రుడు + శుక్రుడు కలసి ఉన్నారా: '
          '${matching ? 'అవును' : 'కాదు'}. పూర్ణ చంద్రుడి ప్రత్యేక బల పరీక్ష ఇందులో లేదు; '
          'కాబట్టి పూర్తి షరతు పరిశీలన పెండింగ్.');
    }
    if (id == '3.36') {
      final matching = (has(kl, 'Moon') && has(kl, 'Jupiter')) ||
          (has(sign5, 'Moon') && has(sign5, 'Jupiter'));
      return JaiminiRuleCheck(matching,
          '${intro}కారకాంశం లేదా 5వ రాశిలో చంద్రుడు–గురు యుతి: '
          '${matching ? 'ఉంది' : 'లేదు'}. ఇది యుతి పరీక్ష మాత్రమే; '
          'ఇతర వ్యాఖ్యాన పద్ధతుల్లో రాశి దృష్టి కూడా పరిశీలించాలి.');
    }
    // Section 3C is explicitly described in the uploaded source as
    // the Karakamsa/5th-house education and scholarship indications.
    if (id == '3.37') {
      final matches = [kl, sign5].any((sign) => has(sign, 'Moon') &&
          (has(sign, 'Venus') || has(sign, 'Mercury')));
      return JaiminiRuleCheck(matches,
          '${intro}కారకాంశం లేదా 5వలో చంద్ర–శుక్ర/చంద్ర–బుధ యుతి: '
          '${matches ? 'ఉంది' : 'లేదు'}.');
    }
    final academics = <String, String>{
      '3.38': 'Venus', '3.39': 'Jupiter', '3.40': 'Saturn',
      '3.41': 'Mercury', '3.42': 'Mars', '3.43': 'Moon',
      '3.44': 'Sun', '3.45': 'Ketu',
    };
    if (academics.containsKey(id)) {
      final planet = academics[id]!;
      final matches = has(kl, planet) || has(sign5, planet);
      final onlyPlanet = id == '3.38';
      if (onlyPlanet) {
        return JaiminiRuleCheck(null,
          '${intro}గ్రహం $planet KL/5వలో ${matches ? 'ఉంది' : 'లేదు'}. '
          'కానీ “కేవలం” అనే గ్రంథ షరతుకు ఇతర గ్రహాల దృష్టి/యుతి '
          'పరిశీలన ఇంకా అవసరం.');
      }
      return JaiminiRuleCheck(matches,
          '${intro}విద్యా నియమంలో $planet కారకాంశం లేదా 5వలో: '
          '${matches ? 'ఉంది' : 'లేదు'}. ఇది స్థానానికి సంబంధించిన ప్రాథమిక పరీక్ష మాత్రమే.');
    }
    return JaiminiRuleCheck(null,
        '${intro}ఈ నియమంలోని అన్ని IF షరతులకు స్వతంత్ర జాతక గణన ఇంకా '
        'అనుసంధానం కాలేదు. మూల నియమాన్ని చూపుతున్నాం; '
        'వర్తించిందని లేదా వర్తించలేదని ప్రకటించడం లేదు.');
  }
}
