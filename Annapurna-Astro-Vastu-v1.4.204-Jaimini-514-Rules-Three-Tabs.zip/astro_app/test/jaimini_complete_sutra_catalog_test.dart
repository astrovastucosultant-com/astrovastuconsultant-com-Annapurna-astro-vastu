import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/jaimini_complete_sutra_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('the full supplied Jaimini catalog has 514 traceable rules', () async {
    final records = await JaiminiCompleteSutraService.load();
    expect(records.length, 514);
    expect(records.map((r) => r.id).toSet().length, 514);
    expect(records.map((r) => r.major).toSet().length, 14);
    expect(records.every((r) => r.condition.trim().isNotEmpty &&
        r.result.trim().isNotEmpty && r.source.trim().isNotEmpty &&
        r.page >= 2 && r.page <= 46), isTrue);
  });

  test('a rule with no implemented predicate stays pending', () {
    const sample = JaiminiCompleteSutraRule(
      id: '13.10', major: 'ఆధాన జ్యోతిషం', section: 'కర్మ',
      condition: 'ఆధాన లగ్న పరిశీలన', result: 'నమూనా',
      source: '3.4.10', page: 39, sourceKind: 'PDF',
    );
    const chart = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 0,
      planets: [], engineVersion: 'test',
    );
    const jaimini = JaiminiResult(
      charaKarakas: [JaiminiKaraka(code: 'AK', planet: 'Sun', effectiveDegree: 12)],
      atmakaraka: 'Sun', karakamsaSignIndex: 0,
      rashiDrishti: {}, argalaFromLagna: [], arudhaPadas: [],
      applicableRules: [], hasDegreeTie: false,
    );
    final check = JaiminiCompleteSutraService.check(
      rule: sample, chart: chart, jaimini: jaimini,
    );
    expect(check.matched, isNull);
  });

  test('AK Navamsa sign rule checks a genuine birth-chart datum', () {
    const sample = JaiminiCompleteSutraRule(
      id: '3.1', major: 'కారకాంశం', section: 'AK నవాంశ',
      condition: 'మేషం', result: 'మూల గ్రంథ ఫలితం',
      source: '1.2.2', page: 8, sourceKind: 'PDF',
    );
    const chart = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 0,
      planets: [], engineVersion: 'test',
    );
    const jaimini = JaiminiResult(
      charaKarakas: [JaiminiKaraka(code: 'AK', planet: 'Sun', effectiveDegree: 12)],
      atmakaraka: 'Sun', karakamsaSignIndex: 0,
      rashiDrishti: {}, argalaFromLagna: [], arudhaPadas: [],
      applicableRules: [], hasDegreeTie: false,
    );
    expect(JaiminiCompleteSutraService.check(rule: sample,
      chart: chart, jaimini: jaimini).matched, isTrue);
  });
}
