import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/d24_education_break_engine.dart';

/// Dedicated D24 study-break / recovery interpretation. All historical causes
/// remain hypotheses until a person confirms what actually occurred.
class D24EducationBreakPanel extends StatefulWidget {
  final AstroChartResult chart;
  final DateTime birthDateTime;
  const D24EducationBreakPanel({super.key,required this.chart,required this.birthDateTime});

  @override
  State<D24EducationBreakPanel> createState()=>_D24EducationBreakPanelState();
}

class _D24EducationBreakPanelState extends State<D24EducationBreakPanel> {
  late DateTime _date;
  @override
  void initState(){super.initState();_date=DateTime.now();}

  Future<void> _pickDate() async {
    final today=DateTime.now();
    final first=DateTime(widget.birthDateTime.year,widget.birthDateTime.month,widget.birthDateTime.day);
    final latest=DateTime(today.year+20,12,31);
    final initial=_date.isBefore(first)?first:_date.isAfter(latest)?latest:_date;
    final picked=await showDatePicker(context:context,initialDate:initial,firstDate:first,lastDate:latest,
      helpText:'విద్యా విరామం / పునఃప్రారంభం పరిశీలన తేదీ');
    if(!mounted || picked==null)return;
    setState(()=>_date=picked);
  }

  Widget _line(D24BreakEvidence e) => Padding(
    padding:const EdgeInsets.symmetric(vertical:7),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Icon(e.matched==true?Icons.check_circle_outline:e.matched==false?
            Icons.remove_circle_outline:Icons.hourglass_empty,
          size:20,color:e.matched==true?const Color(0xFF27694D):Colors.blueGrey),
        const SizedBox(width:8),
        Expanded(child:Text(e.title,style:const TextStyle(fontWeight:FontWeight.w700))),
      ]),
      Padding(padding:const EdgeInsets.only(left:28,top:3),child:Text(
        '${e.status}\n${e.explanation}',style:const TextStyle(fontSize:13.2,height:1.48))),
    ]),
  );

  Widget _sheetText(String title,String text)=>SingleChildScrollView(
    padding:const EdgeInsets.all(17),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w800)),
      const SizedBox(height:12),SelectableText(text,style:const TextStyle(fontSize:14.5,height:1.6)),
    ]));

  void _showCause(D24BreakCause cause,D24EducationBreakReport report){
    showModalBottomSheet<void>(context:context,isScrollControlled:true,showDragHandle:true,
      backgroundColor:const Color(0xFFFFFAF7),builder:(ctx)=>SafeArea(top:false,child:SizedBox(
        height:MediaQuery.of(ctx).size.height*.82,
        child:DefaultTabController(length:4,child:Column(children:[
          Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:8),
            child:Text(cause.name,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900))),
          const TabBar(isScrollable:true,tabAlignment:TabAlignment.start,tabs:[
            Tab(text:'ఫలితం'),Tab(text:'IF–THEN రూల్'),Tab(text:'జాతక పరిశీలన'),Tab(text:'పరిహారం')]),
          Expanded(child:TabBarView(children:[
            _sheetText('కారణ సంబంధ పరిశీలన',
              '${report.breakPattern ? cause.verdict : 'విద్యా విరామానికి బలమైన మూల ఆధారాలు ఇంకా లేవు; కారణం పెండింగ్'}\n\n${cause.caveat}\n\n'
              'ఇది కారణాన్ని నిర్ధారించే ఆధారం కాదు. తల్లిదండ్రులు, ఇతర వ్యక్తులపై నింద వేయడానికి ఉపయోగించరాదు. '
              'జరిగిన సంఘటనలతో పోల్చిన తర్వాత మాత్రమే వాస్తవ కారణం చెప్పాలి.'),
            _sheetText('IF–THEN (వ్యాఖ్యాన నియమం)',
              'IF: D1 విద్యాభావం (4/5/9) మరియు D24 విద్యాభావాల ఆటంక సూచనలు ఉంటూ, '
              '${cause.name}కి సంబంధించిన కారకత్వం రెండు చక్రాల్లోనూ ప్రత్యక్షంగా కలిస్తే\n\n'
              'THEN: ${cause.name} సంబంధిత పరిస్థితుల వల్ల విద్యకు అంతరాయం కలిగే సూచనగా పరిగణించాలి.\n\n'
              'ఇది ప్రాచీన గ్రంథంలోని యథాతథ శ్లోకం కాదు. '
              'మూల D24 పత్రం పేజీ 4లో విద్యకు ఆటంకం అనే సాధారణ నియమం మాత్రమే ఉంది.'),
            SingleChildScrollView(padding:const EdgeInsets.all(16),child:Column(
              crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text('${cause.hits} సూచనలు · ${cause.multiLayer?'D1 + D24 రెండింటిలో ఆధారం':'రెండు చక్రాల మద్దతు లేదు'}',
                  style:const TextStyle(fontWeight:FontWeight.w800)),
                ...cause.evidence.map(_line),
                const Divider(),
                Text(report.timingNotes.join('\n'),style:const TextStyle(height:1.5)),
              ])),
            _sheetText('పరిహారం / మూలం',
              'మీరు ఇచ్చిన D24 పత్రంలో ${cause.name} కోసం ప్రత్యేక పరిహారం లేదు. '
              'కాబట్టి ఊహించి పరిహారం ఇవ్వడం లేదు.\n\n'
              'విద్య తిరిగి కొనసాగించేందుకు చదువు సంస్థ, కుటుంబ సభ్యులు, కౌన్సెలర్‌తో వాస్తవ సమస్యను బట్టి ప్రణాళిక అవసరం.\n\n'
              'మూలం: ${D24EducationBreakEngine.docSource}.\n'
              'కారణ నిర్ధారణ: ${D24EducationBreakEngine.interpretive}.'),
          ])),
        ])),
      )));
  }

  @override
  Widget build(BuildContext context){
    final report=D24EducationBreakEngine.evaluate(widget.chart,birthDateTime:widget.birthDateTime,at:_date);
    final ordered=[...report.causes]..sort((a,b){
      final supported=a.supported == b.supported ? 0 : (a.supported ? -1 : 1);
      if(supported!=0)return supported;
      return b.hits.compareTo(a.hits);
    });
    final date='${_date.day.toString().padLeft(2,'0')}-${_date.month.toString().padLeft(2,'0')}-${_date.year}';
    return Card(
      color:const Color(0xFFFFF8F0),surfaceTintColor:Colors.transparent,
      margin:const EdgeInsets.symmetric(vertical:10),
      child:ExpansionTile(
        initiallyExpanded:false,
        leading:const Icon(Icons.school_outlined,color:Color(0xFF78452E)),
        title:const Text('D24 — చదువు మధ్యలో ఆగే యోగం · కారణాలు · పునఃప్రారంభం',
          style:TextStyle(fontWeight:FontWeight.w900)),
        subtitle:const Text('D1 + D24 · విద్యా ఆటంకం · 8 కారణాల పోలిక · దశ–అంతర్దశ'),
        childrenPadding:const EdgeInsets.fromLTRB(12,0,12,14),
        children:[
          Card(color:Colors.white,child:Padding(padding:const EdgeInsets.all(12),child:Column(
            crossAxisAlignment:CrossAxisAlignment.start,children:[
              const Text('విద్య మధ్యలో ఆగే యోగం — సమగ్ర పరిశీలన',
                style:TextStyle(fontWeight:FontWeight.w900,fontSize:16)),
              const SizedBox(height:8),
              Text(report.mainVerdict,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w800,color:Color(0xFF754029))),
              const SizedBox(height:6),
              Text('D1 ఆటంక ఆధారాలు ${report.d1Count} · D24 ఆధారాలు ${report.d24Count} · '
                   'మూల D24 విద్యా ఆటంక IF–THEN: ${report.strongSourceRule?'సరిపోయింది':'సరిపోలలేదు'}',
                style:const TextStyle(fontSize:12.5,height:1.5)),
              const SizedBox(height:8),
              const Text('ఇది నియమాల ఆధారిత జ్యోతిష బలం మాత్రమే; వాస్తవంగా చదువు ఆగిందని, వ్యక్తిగత కారణం ఇదేనని నిర్ధారించదు.',
                style:TextStyle(fontSize:12,height:1.45)),
            ]))),
          OutlinedButton.icon(onPressed:_pickDate,icon:const Icon(Icons.event),
            label:Text('విద్య విరామం/పునఃప్రారంభం తేదీ: $date')),
          Card(color:Colors.white,child:ExpansionTile(initiallyExpanded:true,
            title:const Text('మూల ఆటంక నియమం · D1/D24 చెక్‌లిస్ట్',style:TextStyle(fontWeight:FontWeight.w800)),
            subtitle:Text('${report.primary.where((e)=>e.matched==true).length} ప్రత్యక్ష సూచనలు'),
            children:[
              ...report.primary.map((e)=>Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:_line(e))),
              const Padding(padding:EdgeInsets.all(10),child:Text(
                'మూలపత్రం 4వ పేజీలో D1 4/5 విద్యాధిపతులు D24లో 6/8/12లో పాపగ్రహ యుతిలో ఉంటే చదువుకు ఆటంకం అని ఇచ్చారు. '
                'మిగిలిన విస్తరణ నియమాలు వ్యాఖ్యానాలు; మూలశ్లోకాలుగా చూపడం లేదు.',
                style:TextStyle(fontSize:12,height:1.5))),
            ],
          )),
          Card(color:Colors.white,child:ExpansionTile(initiallyExpanded:true,
            title:const Text('విద్య ఆగడానికి కారణాల వర్గీకరణ (8)',style:TextStyle(fontWeight:FontWeight.w800)),
            subtitle:Text('${report.breakPattern ? ordered.where((c)=>c.supported).length : 0} కారణ వర్గాలకు విరామయోగంతో పాటు రెండు చక్రాల మద్దతు · వ్యక్తిగత కారణం నిర్ధారణ కాదు'),
            children:[
              ...ordered.map((cause)=>ListTile(
                leading:Icon(report.breakPattern && cause.supported?Icons.fact_check_outlined:Icons.manage_search,
                  color:report.breakPattern && cause.supported?const Color(0xFF986025):Colors.blueGrey),
                title:Text(cause.name),
                subtitle:Text('${report.breakPattern ? cause.verdict : 'ప్రధాన విరామ యోగం పెండింగ్'} · ${cause.hits} ఆధారాలు',maxLines:2),
                trailing:const Icon(Icons.chevron_right),
                onTap:()=>_showCause(cause,report),
              )),
            ],
          )),
          Card(color:Colors.white,child:ExpansionTile(initiallyExpanded:true,
            title:const Text('దశ–అంతర్దశ · సంఘటన కాలమద్దతు',style:TextStyle(fontWeight:FontWeight.w800)),
            children:[Padding(padding:const EdgeInsets.all(12),child:Text(report.timingNotes.join('\n\n'),
              style:const TextStyle(height:1.55)))],
          )),
          Card(color:Colors.white,child:ExpansionTile(
            title:const Text('6–35 సంవత్సరాల దశకాల సూచనలు',style:TextStyle(fontWeight:FontWeight.w800)),
            subtitle:const Text('వింశోత్తరి మహాదశ–అంతర్దశల ఆధారాలు మాత్రమే; ఖచ్చిత సంఘటన సమయం కాదు'),
            children:[
              if (report.candidateWindows.isEmpty) const ListTile(title:Text('ఈ పరిధిలో ప్రత్యేక దశసంబంధ కాలం కనిపించలేదు.')),
              ...report.candidateWindows.take(30).map((w)=>ListTile(
                dense:true,
                title:Text('${w.start.month}/${w.start.year} – ${w.end.month}/${w.end.year} · ${w.type}'),
                subtitle:Text('మహాదశ ${w.maha} · అంతర్దశ ${w.antar} · గోచారం/వాస్తవ సంఘటనతో ధృవీకరించాలి.'),
              )),
              const Padding(padding:EdgeInsets.all(8),child:Text(
                'ఈ కాలాలు కేవలం విద్యా భావసంబంధిత దశల సూచనలు. వీటిని చదువు తప్పకుండా ఆగే లేదా మళ్లీ మొదలయ్యే తేదీలుగా భావించకూడదు.',
                style:TextStyle(fontSize:12))),
            ],
          )),
          Card(color:Colors.white,child:ExpansionTile(
            title:const Text('చదువు తిరిగి కొనసాగించే యోగం',style:TextStyle(fontWeight:FontWeight.w800)),
            subtitle:Text(report.recoveryVerdict),
            children:[...report.recovery.map((e)=>Padding(padding:const EdgeInsets.symmetric(horizontal:12),child:_line(e)))],
          )),
          const Padding(padding:EdgeInsets.all(8),child:Text(
            'జాగ్రత్త: తండ్రి, తల్లి, ప్రేమ, ఆరోగ్యం వంటి నిజ జీవిత కారణాలను జాతకం ద్వారా రుజువు చేయలేం. '
            'ఇవన్నీ పరిశీలన కోసం వర్గీకరణలు మాత్రమే. సంఘటనల తేదీలు, వాస్తవ పరిస్థితులను నమోదు చేసి దశలతో పోల్చాలి. '
            'శాస్త్ర మూలం: D24 పత్రంలోని విద్యా ఆటంక నియమం; కారణాల విభజనకు ప్రత్యేక మూలశ్లోకం లేదు.',
            style:TextStyle(fontSize:12,height:1.5,color:Colors.black54))),
        ],
      ),
    );
  }
}
