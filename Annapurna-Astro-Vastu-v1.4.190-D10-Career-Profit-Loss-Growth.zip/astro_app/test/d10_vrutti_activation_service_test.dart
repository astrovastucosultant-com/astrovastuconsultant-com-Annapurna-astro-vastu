import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_vrutti_activation_service.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';

void main() {
  test('DOB age is computed by completed birthdays, not year subtraction', () {
    final born = DateTime(1995, 12, 20);
    expect(D10VruttiActivationService.ageOn(born, DateTime(2026, 12, 19)), 30);
    expect(D10VruttiActivationService.ageOn(born, DateTime(2026, 12, 20)), 31);
  });

  test('historical age bounds use completed birthdays', () {
    final born = DateTime(1990, 8, 28);
    expect(D10VruttiActivationService.ageOn(born, DateTime(2006, 8, 27)), 15);
    expect(D10VruttiActivationService.ageOn(born, DateTime(2006, 8, 28)), 16);
    expect(D10VruttiActivationService.ageOn(born, DateTime(2026, 10, 22)), 36);
  });

  test('consecutive months in one MD/AD remain one window', () {
    bool continues(DateTime previous, DateTime current, String ad) =>
        D10VruttiActivationService.continuesWindow(
          previousMonth: previous, currentMonth: current,
          previousMd: 'Mercury', previousAd: 'Venus',
          currentMd: 'Mercury', currentAd: ad,
        );
    expect(continues(DateTime(2025, 11, 15), DateTime(2025, 12, 15), 'Venus'), true);
    expect(continues(DateTime(2025, 12, 15), DateTime(2026, 1, 15), 'Venus'), true);
    expect(continues(DateTime(2025, 12, 15), DateTime(2026, 2, 15), 'Venus'), false);
    expect(continues(DateTime(2025, 12, 15), DateTime(2026, 1, 15), 'Saturn'), false);
  });

  test('MD and AD must both match; confirmed main planet must be involved', () {
    bool gate(String md, String ad) => D10VruttiActivationService.dashaSupports(
      mainPlanet: 'Mercury', professionPlanets: const ['Mercury','Rahu'],
      d1TenthLord: 'Saturn', d10TenthLord: 'Sun',
      mahadasha: md, antardasha: ad,
    );
    expect(gate('Mercury', 'Saturn'), true);
    expect(gate('Sun', 'Mercury'), true);
    expect(gate('Sun', 'Saturn'), false);
    expect(gate('Mercury', 'Moon'), false);
  });

  test('transit checks conjunction and planet-specific traditional aspects', () {
    expect(D10VruttiActivationService.transitReachesCareerSign(
        'Jupiter', 0, {4}), true);
    expect(D10VruttiActivationService.transitReachesCareerSign(
        'Saturn', 0, {2}), true);
    expect(D10VruttiActivationService.transitReachesCareerSign(
        'Saturn', 0, {4}), false);
  });

  test('unique merged source IDs and original page origins', () {
    expect(d10VruttiRulebook.length, 336);
    expect(d10VruttiRulebook.map((r) => r.id).toSet().length, 336);
    expect(d10VruttiRulebook.where((r) =>
        r.source == 'vrutti-if-then-mottam.pdf').length, 123);
  });
}
