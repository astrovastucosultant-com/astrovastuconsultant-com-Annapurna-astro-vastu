import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';
import 'package:astro_app/astrology/d10_career_profit_loss_service.dart';

void main() {
  const chart = AstroChartResult(
    julianDay: 2451545, ayanamsaDegrees: 23,
    ascendantLongitude: 0, planets: <PlanetPosition>[],
    engineVersion: 'test',
  );
  final rule = d10VruttiRulebook.first;

  test('unconfirmed occupation has NO invented profit, loss or middle verdict', () {
    final m = D10VruttiMatch(rule, false, false, 0, const [], const [], const []);
    final audit = D10CareerProfitLossService.evaluate(chart, m);
    expect(audit.tone, D10MoneyTone.insufficient);
    expect(audit.gainSupport, 0);
    expect(audit.riskSupport, 0);
  });

  test('annual label requires MD+AD+Guru+Saturn conjunction of checks', () {
    const audit = D10MoneyAudit(tone: D10MoneyTone.gain,
      gainSupport: 3, riskSupport: 1, gains: [], risks: [], limitations: []);
    // Aries Lagna. 2nd/11th rulers: Venus and Saturn.
    expect(D10CareerProfitLossService.monthlyTone(
      audit: audit, md: 'Venus', ad: 'Saturn',
      jupiterSign: 1, saturnSign: 1, chart: chart), D10MoneyTone.gain);
    expect(D10CareerProfitLossService.monthlyTone(
      audit: audit, md: 'Venus', ad: 'Mars',
      jupiterSign: 1, saturnSign: 1, chart: chart), D10MoneyTone.insufficient);
    expect(D10CareerProfitLossService.monthlyTone(
      audit: audit, md: 'Venus', ad: 'Saturn',
      jupiterSign: 8, saturnSign: 2, chart: chart), D10MoneyTone.insufficient);
  });

  test('mixed time category needs income AND expense indications', () {
    const audit = D10MoneyAudit(tone: D10MoneyTone.mixed,
      gainSupport: 2, riskSupport: 2, gains: [], risks: [], limitations: []);
    expect(D10CareerProfitLossService.monthlyTone(
      audit: audit, md: 'Venus', ad: 'Mars',
      jupiterSign: 1, saturnSign: 5, chart: chart), D10MoneyTone.mixed);
  });

  test('risk report cannot be produced by a random transit without MD and AD', () {
    const audit = D10MoneyAudit(tone: D10MoneyTone.risk,
      gainSupport: 1, riskSupport: 3, gains: [], risks: [], limitations: []);
    expect(D10CareerProfitLossService.monthlyTone(
      audit: audit, md: 'Venus', ad: 'Saturn',
      jupiterSign: 5, saturnSign: 5, chart: chart),
      D10MoneyTone.insufficient);
    expect(D10CareerProfitLossService.monthlyTone(
      audit: audit, md: 'Mercury', ad: 'Mars',
      jupiterSign: 5, saturnSign: 5, chart: chart), D10MoneyTone.risk);
  });
}
