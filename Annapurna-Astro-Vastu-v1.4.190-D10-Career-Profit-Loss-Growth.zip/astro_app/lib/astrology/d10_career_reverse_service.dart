import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/birth_data.dart';
import 'astro_models.dart';
import 'astro_calculation_service.dart';
import 'd10_career_service.dart';
import 'd10_display_order.dart';
import 'd10_legacy_rule_link_service.dart';
import 'd10_profession_registry.dart';
import 'd10_vrutti_activation_service.dart';
import 'd10_career_profit_loss_service.dart';
import 'd10_vrutti_match_engine.dart';
import 'dasha_service.dart';
import 'varga_service.dart';

/// Historical career facts are supplied by the consulting astrologer/client.
/// They are never converted into a presumed astronomical fact.
class D10CareerEvent {
  final String id;
  final String occupation;
  final String ruleId;
  final DateTime date;
  final String type;
  final String notes;

  const D10CareerEvent({required this.id, required this.occupation,
    required this.ruleId, required this.date, required this.type,
    this.notes = ''});

  Map<String, dynamic> toJson() => {
    'id': id, 'occupation': occupation, 'ruleId': ruleId,
    'date': date.toIso8601String(), 'type': type, 'notes': notes,
  };

  factory D10CareerEvent.fromJson(Map<String, dynamic> json) => D10CareerEvent(
    id: json['id']?.toString() ?? '',
    occupation: json['occupation']?.toString() ?? '',
    ruleId: json['ruleId']?.toString() ?? '',
    date: DateTime.tryParse(json['date']?.toString() ?? '') ?? DateTime(2000),
    type: json['type']?.toString() ?? 'వృత్తి ప్రారంభం',
    notes: json['notes']?.toString() ?? '',
  );
}

class D10CareerEventStore {
  /// This key remains stable while BTR candidates vary the input birth time.
  static String keyFor(BirthData birth) => 'd10_career_events_v185_'
      '${birth.originalBirthDateTime.toIso8601String()}_'
      '${birth.latitude.toStringAsFixed(5)}_${birth.longitude.toStringAsFixed(5)}_'
      '${birth.name.trim().toLowerCase()}';

  static Future<List<D10CareerEvent>> load(BirthData birth) async {
    final p = await SharedPreferences.getInstance();
    final content = p.getString(keyFor(birth));
    if (content == null || content.isEmpty) return <D10CareerEvent>[];
    try {
      final decoded = jsonDecode(content);
      if (decoded is! List) return <D10CareerEvent>[];
      final events = <D10CareerEvent>[];
      for (final row in decoded) {
        if (row is Map) {
          final event = D10CareerEvent.fromJson(Map<String, dynamic>.from(row));
          if (event.id.isNotEmpty && event.occupation.isNotEmpty) events.add(event);
        }
      }
      return events..sort((a, b) => a.date.compareTo(b.date));
    } catch (_) {
      return <D10CareerEvent>[];
    }
  }

  static Future<void> save(BirthData birth, List<D10CareerEvent> events) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(keyFor(birth), jsonEncode(events.map((e) => e.toJson()).toList()));
  }
}

class D10CareerSearchHit {
  final String id;
  final String label;
  final String group;
  final String source;
  final D10VruttiMatch? match;
  final D10ProfessionRule? legacy;
  final int relevance;
  const D10CareerSearchHit({required this.id, required this.label,
    required this.group, required this.source, this.match, this.legacy,
    required this.relevance});
}

/// Searches both the original 181 names and the sourced 336 IF-THEN entries.
/// Search is reverse lookup, NOT a positive astrological verdict.
class D10CareerReverseLookup {
  static String normalize(String text) => text.toLowerCase()
      .replaceAll(RegExp(r'[\u200c\u200d\s]+'), '')
      .replaceAll(RegExp(r'[.,।()\-–]+'), '');

  static int rank(String label, String query) {
    final q = normalize(query);
    if (q.isEmpty) return 0;
    final full = normalize(label);
    if (full == q) return 4;
    if (label.split(RegExp(r'\s*/\s*')).any((p) => normalize(p) == q)) return 3;
    if (full.contains(q)) return 2;
    if (q.contains(full) && full.length >= 3) return 1;
    return 0;
  }

  static List<D10CareerSearchHit> search(String query,
      List<D10VruttiMatch> evaluated, {int limit = 80}) {
    if (normalize(query).isEmpty) return <D10CareerSearchHit>[];
    final results = <D10CareerSearchHit>[];
    for (final match in evaluated) {
      final score = rank(match.rule.profession, query);
      if (score == 0) continue;
      results.add(D10CareerSearchHit(id: match.rule.id,
        label: match.rule.profession, group: match.rule.category,
        source: '${match.rule.source} పేజీ ${match.rule.page}',
        match: match, relevance: score));
    }
    for (final legacy in d10ProfessionRules) {
      final score = rank(legacy.name, query);
      if (score == 0) continue;
      final linked = D10LegacyRuleLinkService.matchingRules(legacy, evaluated);
      results.add(D10CareerSearchHit(id: legacy.id, label: legacy.name,
        group: legacy.category, source: linked.isEmpty
          ? 'పాత D10 రిజిస్ట్రీ — పూర్తి IF–THEN లింక్ లేదు'
          : 'పాత రిజిస్ట్రీ + ${linked.length} మూల IF–THEN లింకులు',
        match: D10DisplayOrder.strongest(linked),
        legacy: legacy, relevance: score));
    }
    // Preserve Green -> Pink -> Grey ordering even inside Reverse Search.
    // Relevance still resolves ties within a color tier.
    results.sort((a, b) => D10DisplayOrder.compareEvidence(a.match, b.match,
        missingRuleA: a.legacy != null && a.match == null,
        missingRuleB: b.legacy != null && b.match == null,
        relevanceA: a.relevance, relevanceB: b.relevance,
        idA: a.id, idB: b.id));
    return results.take(limit).toList(growable: false);
  }

  static List<D10VruttiMatch> rulesForEvent(D10CareerEvent event,
      List<D10VruttiMatch> evaluated) {
    if (event.ruleId.startsWith('VR-')) {
      // Include alternatives for the same occupation without double-scoring.
      final chosen = evaluated.where((m) => m.rule.id == event.ruleId).toList();
      if (chosen.isEmpty) return <D10VruttiMatch>[];
      final title = chosen.first.rule.profession;
      // Source may also name this occupation as one slash-separated alias.
      return evaluated.where((m) => rank(m.rule.profession, title) >= 3 ||
          title.split(RegExp(r'\s*/\s*')).any(
            (alias) => rank(m.rule.profession, alias) >= 3))
          .toList(growable: false);
    }
    if (event.ruleId.startsWith('D10-PRO-')) {
      final legacy = d10ProfessionRules.where((r) => r.id == event.ruleId).toList();
      return legacy.isEmpty ? <D10VruttiMatch>[] :
          D10LegacyRuleLinkService.matchingRules(legacy.first, evaluated);
    }
    // Manually entered occupation: exact label/alias only, not contains.
    return evaluated.where((m) => rank(m.rule.profession, event.occupation) >= 3)
        .toList(growable: false);
  }
}

/// Five distinctly named sources of evidence; a count is NOT BTR accuracy.
class D10CareerEventEvidence {
  final D10CareerEvent event;
  final String? matchedRuleId;
  final bool hasRule;
  final bool natalConfirmed;
  final bool ruleConditions;
  final bool mahadashaSupport;
  final bool antardashaSupport;
  final bool transitSupport;
  final String mahadasha;
  final String antardasha;
  final List<String> reasons;

  const D10CareerEventEvidence({required this.event, required this.matchedRuleId,
    required this.hasRule, required this.natalConfirmed,
    required this.ruleConditions, required this.mahadashaSupport,
    required this.antardashaSupport, required this.transitSupport,
    required this.mahadasha, required this.antardasha,
    required this.reasons});

  int get gatesMatched => (natalConfirmed ? 1 : 0) +
      (ruleConditions ? 1 : 0) + (mahadashaSupport ? 1 : 0) +
      (antardashaSupport ? 1 : 0) + (transitSupport ? 1 : 0);
  bool get allAligned => hasRule && gatesMatched == 5;
}

class D10CareerEvidenceService {
  static Future<D10CareerEventEvidence> evaluateEvent({
    required AstroChartResult chart, required BirthData birth,
    required D10CareerEvent event, List<D10VruttiMatch>? evaluated,
  }) async {
    final matches = evaluated ?? D10VruttiMatchEngine.evaluate(chart);
    final matching = D10CareerReverseLookup.rulesForEvent(event, matches);
    final birthDate = birth.localDateTime;
    if (event.date.isBefore(DateTime(birthDate.year, birthDate.month, birthDate.day))) {
      return D10CareerEventEvidence(event: event, matchedRuleId: null,
        hasRule: false, natalConfirmed: false, ruleConditions: false,
        mahadashaSupport: false, antardashaSupport: false,
        transitSupport: false, mahadasha: '-', antardasha: '-',
        reasons: const ['సంఘటన తేదీ జనన తేదీకంటే ముందు ఉంది. తేదీ సరిచూడండి.']);
    }
    if (matching.isEmpty) {
      return D10CareerEventEvidence(event: event, matchedRuleId: null,
        hasRule: false, natalConfirmed: false, ruleConditions: false,
        mahadashaSupport: false, antardashaSupport: false,
        transitSupport: false, mahadasha: '-', antardasha: '-',
        reasons: const ['ఈ వృత్తికి ధృవీకరించిన IF–THEN లింక్ లేదు. '
          'జరిగిన సంఘటనను సేవ్ చేశాము; BTR స్కోరులో కలపలేదు.']);
    }

    final d10 = VargaService.calculate(chart, 10);
    final d1Lord = D10CareerService.signLord((chart.ascendantSignIndex + 9) % 12);
    final d10Lord = D10CareerService.signLord((d10.ascendantSignIndex + 9) % 12);
    final dasha = DashaService.system(kind: DashaSystemKind.vimshottari,
      chart: chart, birthDateTime: birth.localDateTime);
    // A date is evidence for that historical period, not a future forecast.
    final md = DashaService.periodAt(dasha.mahadashas, event.date);
    final ad = md == null ? null : DashaService.periodAt(
      DashaService.subPeriodsFor(dasha, md), event.date);
    final transit = await D10VruttiActivationService.transitAtMonth(birth, event.date);
    D10CareerEventEvidence? best;
    for (final match in matching) {
      final p = match.rule.planets.isEmpty ? '' : match.rule.planets.first;
      final natalPlanet = chart.planets.where((x) => x.name == p).toList();
      final targets = <int>{
        (chart.ascendantSignIndex + 9) % 12,
        (d10.ascendantSignIndex + 9) % 12,
        if (natalPlanet.isNotEmpty) natalPlanet.first.signIndex,
      };
      final mdOk = md != null && <String>{p, d1Lord, d10Lord,
        ...match.rule.planets}.contains(md.lord);
      final adOk = ad != null && <String>{p, d1Lord, d10Lord,
        ...match.rule.planets}.contains(ad.lord);
      final gate = md != null && ad != null &&
          D10VruttiActivationService.dashaSupports(mainPlanet: p,
          professionPlanets: match.rule.planets, d1TenthLord: d1Lord,
          d10TenthLord: d10Lord, mahadasha: md.lord,
          antardasha: ad.lord);
      // Do not count both dasha gates if the main confirmed planet is absent.
      final guru = D10VruttiActivationService.transitReachesCareerSign(
        'Jupiter', transit.guru, targets);
      final shani = D10VruttiActivationService.transitReachesCareerSign(
        'Saturn', transit.shani, targets);
      final reasons = <String>[
        '${match.rule.id} — IF ${match.rule.condition} THEN ${match.rule.profession}',
        'D1→D10 ప్రధాన గ్రహం ${p.isEmpty ? '-': p}: ${match.confirmed ? 'confirm ఉంది' : 'confirm లేదు'}',
        'మూల గ్రహ–దేవత–భావ షరతులు: ${match.complete ? 'సరిపోయాయి' : 'అసంపూర్తి / సరిపోలలేదు'}',
        'వింశోత్తరి MD ${md?.lord ?? '-'} / AD ${ad?.lord ?? '-'}',
        'MD వృత్తి గ్రహ అనుసంధానం: ${mdOk && gate ? 'ఉంది' : 'లేదు'}; '
            'AD అనుసంధానం: ${adOk && gate ? 'ఉంది' : 'లేదు'}',
        'గురు గోచార మద్దతు: ${guru ? 'ఉంది' : 'లేదు'}; '
            'శని గోచార మద్దతు: ${shani ? 'ఉంది' : 'లేదు'}',
        'గోచారం నెల 15న నమూనా. వృత్తి సంఘటన జరిగిన రోజున ఖచ్చిత దృష్టి అని అర్థం కాదు.',
      ];
      // Career identity rules do not prove a promotion or retirement event.
      final isCareerEntry = event.type == 'వృత్తి ప్రారంభం' ||
          event.type == 'వ్యాపార ప్రారంభం' ||
          event.type == 'ఉద్యోగ మార్పు' || event.type == 'వృత్తి మార్పు';
      const moneyTypes = <String>{'వృత్తి లాభం', 'వృత్తి నష్టం',
        'మధ్యస్థ ఫలితం', 'వృత్తి ఎదుగుదల', 'వృత్తి పతనం', 'పునరుద్ధరణ'};
      final isFinancial = moneyTypes.contains(event.type);
      var financialMatch = false;
      if (isFinancial && md != null && ad != null &&
          match.confirmed && match.complete) {
        final audit = D10CareerProfitLossService.evaluate(chart, match);
        final tone = D10CareerProfitLossService.monthlyTone(
          audit: audit, md: md.lord, ad: ad.lord,
          jupiterSign: transit.guru, saturnSign: transit.shani,
          chart: chart);
        financialMatch = ((event.type == 'వృత్తి లాభం' ||
                event.type == 'వృత్తి ఎదుగుదల') && tone == D10MoneyTone.gain) ||
            ((event.type == 'వృత్తి నష్టం' || event.type == 'వృత్తి పతనం') &&
                tone == D10MoneyTone.risk);
        reasons.add('ఆ సంఘటన నెలలో లాభనష్ట ఆధార దిశ: ${tone.label} · '
          '${financialMatch ? 'సంఘటన రకంతో సరిపోలింది' : 'సరిపోలలేదు / అపరిపూర్ణం'}');
        if (event.type == 'మధ్యస్థ ఫలితం' || event.type == 'పునరుద్ధరణ') {
          reasons.add('మధ్యస్థం/పునరుద్ధరణకు ప్రత్యేక కాలక్రమ ధృవీకరణ కావాలి; '
            'ఇక్కడ BTR స్కోరు ఇవ్వలేదు.');
        }
      }
      if (!isCareerEntry && !isFinancial) {
        reasons.add('ఈ సంఘటన (${event.type}) కోసం ప్రత్యేక పదోన్నతి/విరమణ '
            'IF–THEN మూల నియమం ఇక్కడ లేదు. వృత్తి పేరు ఆధారం మాత్రమే.');
      }
      final result = D10CareerEventEvidence(event: event,
        matchedRuleId: match.rule.id, hasRule: true,
        natalConfirmed: match.confirmed && (!isFinancial || financialMatch),
        ruleConditions: match.complete && (isCareerEntry || financialMatch),
        // A financial observation is one *compound* corroboration. Do not
        // count its MD+AD+transits as three independent BTR gates.
        mahadashaSupport: !isFinancial && mdOk && gate,
        antardashaSupport: !isFinancial && adOk && gate,
        transitSupport: !isFinancial && guru && shani,
        mahadasha: md?.lord ?? '-', antardasha: ad?.lord ?? '-',
        reasons: reasons);
      if (best == null || result.gatesMatched > best.gatesMatched ||
          (result.gatesMatched == best.gatesMatched &&
              match.rule.id.compareTo(best.matchedRuleId ?? '') < 0)) {
        best = result;
      }
    }
    return best!;
  }
}

class D10CareerBtrCandidate {
  final DateTime birthTime;
  final List<D10CareerEventEvidence> eventEvidence;
  final String? error;
  const D10CareerBtrCandidate(this.birthTime, this.eventEvidence, {this.error});
  int get evaluatedEvents => eventEvidence.where((e) => e.hasRule).length;
  int get fullyAlignedEvents => eventEvidence.where((e) => e.allAligned).length;
  int get evidenceGates => eventEvidence.fold(0, (s, e) => s + e.gatesMatched);
}

class D10CareerBtrService {
  /// Fixed-step comparisons are evidence ranking, never definitive rectification.
  static List<DateTime> candidateTimes(DateTime center, {
    int rangeMinutes = 3, int stepMinutes = 1}) {
    if (rangeMinutes < 0 || rangeMinutes > 10 || stepMinutes < 1) {
      throw ArgumentError('Use a range of 0–10 minutes and step ≥ 1 minute');
    }
    return <DateTime>[
      for (var m = -rangeMinutes; m <= rangeMinutes; m += stepMinutes)
        center.add(Duration(minutes: m)),
    ];
  }

  static Future<List<D10CareerBtrCandidate>> compare({
    required BirthData birth, required List<D10CareerEvent> events,
    int rangeMinutes = 3, int stepMinutes = 1,
  }) async {
    if (events.isEmpty) return <D10CareerBtrCandidate>[];
    final results = <D10CareerBtrCandidate>[];
    final center = birth.localDateTime;
    for (final time in candidateTimes(center,
        rangeMinutes: rangeMinutes, stepMinutes: stepMinutes)) {
      try {
        final candidateBirth = birth.copyWith(localDateTime: time);
        final candidateChart = await AstroCalculationService.calculate(candidateBirth);
        final evaluated = D10VruttiMatchEngine.evaluate(candidateChart);
        final evidence = <D10CareerEventEvidence>[];
        for (final event in events) {
          evidence.add(await D10CareerEvidenceService.evaluateEvent(
            chart: candidateChart, birth: candidateBirth, event: event,
            evaluated: evaluated));
        }
        results.add(D10CareerBtrCandidate(time, evidence));
      } catch (e) {
        results.add(D10CareerBtrCandidate(time, const [], error: '$e'));
      }
    }
    results.sort((a, b) {
      final c = b.fullyAlignedEvents.compareTo(a.fullyAlignedEvents);
      if (c != 0) return c;
      final d = b.evidenceGates.compareTo(a.evidenceGates);
      if (d != 0) return d;
      return a.birthTime.compareTo(b.birthTime);
    });
    return results;
  }
}
