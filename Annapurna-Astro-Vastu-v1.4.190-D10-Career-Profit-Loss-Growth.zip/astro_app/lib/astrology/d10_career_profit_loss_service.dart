import '../models/birth_data.dart';
import 'astro_models.dart';
import 'd10_career_service.dart';
import 'd10_vrutti_activation_service.dart';
import 'd10_vrutti_match_engine.dart';
import 'd2_wealth_evaluation_service.dart';
import 'dasha_service.dart';
import 'varga_service.dart';

/// App-defined, auditable career financial *support* indicators. The supplied
/// D10 occupation rulebooks identify professions but do not specify a single
/// canonical profit/loss equation. Accordingly these are auxiliary D1/D2/D10
/// house, dasha and transit checks, NOT financial forecasts/probabilities.
enum D10MoneyTone { gain, risk, mixed, insufficient }

extension D10MoneyToneLabel on D10MoneyTone {
  String get label => switch (this) {
    D10MoneyTone.gain => 'లాభ సూచన',
    D10MoneyTone.risk => 'నష్టం / ఖర్చు ప్రమాద సూచన',
    D10MoneyTone.mixed => 'మధ్యస్థ / మిశ్రమ ఆధారాలు',
    D10MoneyTone.insufficient => 'నిర్ధారణకు ఆధారాలు లేవు',
  };
}

class D10MoneyAudit {
  final D10MoneyTone tone;
  final int gainSupport;
  final int riskSupport;
  final List<String> gains;
  final List<String> risks;
  final List<String> limitations;
  const D10MoneyAudit({required this.tone, required this.gainSupport,
    required this.riskSupport, required this.gains, required this.risks,
    required this.limitations});
}

class D10MoneyWindow {
  final DateTime start;
  final DateTime end;
  final int age;
  final String mahadasha;
  final String antardasha;
  final D10MoneyTone tone;
  final String phase;
  final List<String> evidence;
  const D10MoneyWindow({required this.start, required this.end,
    required this.age, required this.mahadasha, required this.antardasha,
    required this.tone, required this.phase, required this.evidence});
}

class D10CareerProfitLossService {
  static const _supportIds = <String>{
    'D2-IN-001','D2-IN-002','D2-IN-005','D2-IN-007','D2-IN-010',
    'D2-IN-012',
  };
  static const _riskIds = <String>{
    'D2-IN-003','D2-IN-004','D2-IN-006','D2-IN-008',
  };

  static bool _related(AstroChartResult chart, String a, String b) {
    if (a == b) return true;
    if (!chart.planets.any((p) => p.name == a) ||
        !chart.planets.any((p) => p.name == b)) return false;
    return D10CareerService.relatedD1(chart, a, b);
  }

  static bool _vRelated(VargaChartData chart, String a, String b) {
    if (a == b) return true;
    if (!chart.planets.any((p) => p.name == a) ||
        !chart.planets.any((p) => p.name == b)) return false;
    return D10CareerService.relatedVarga(chart, a, b);
  }

  /// Static financial support is intentionally kept SEPARATE from an occupation
  /// match percentage, as well as from a specific year's MD/AD/transit checks.
  static D10MoneyAudit evaluate(AstroChartResult chart, D10VruttiMatch match) {
    const guard = 'D1→D10 ప్రధాన వృత్తి Confirm మరియు మూల IF–THEN పూర్తి సరిపోలిక అవసరం.';
    if (!match.confirmed || !match.complete || match.rule.planets.isEmpty) {
      return const D10MoneyAudit(tone: D10MoneyTone.insufficient,
        gainSupport: 0, riskSupport: 0, gains: [], risks: [],
        limitations: [guard, 'ఈ వృత్తికి లాభం/నష్టం/మధ్యస్థం తీర్పు ఇవ్వలేదు.']);
    }
    final main = match.rule.planets.first;
    if (!chart.planets.any((p) => p.name == main)) {
      return const D10MoneyAudit(tone: D10MoneyTone.insufficient,
        gainSupport: 0, riskSupport: 0, gains: [], risks: [],
        limitations: ['ప్రధాన గ్రహస్థితి డేటా లేదు.']);
    }
    final gains = <String>[];
    final risks = <String>[];
    final d10 = VargaService.calculate(chart, 10);
    final gLords = <String>{};
    final rLords = <String>{};
    for (final h in const [2, 11]) {
      final lord = D10CareerService.signLord(
        (chart.ascendantSignIndex + h - 1) % 12);
      gLords.add(lord);
      if (_related(chart, main, lord)) {
        gains.add('D1 $hవ భావాధిపతి $lord ↔ వృత్తి గ్రహం $main సంబంధం');
      }
    }
    for (final h in const [2, 11]) {
      final lord = D10CareerService.signLord(
        (d10.ascendantSignIndex + h - 1) % 12);
      gLords.add(lord);
      if (_vRelated(d10, main, lord)) {
        gains.add('D10 $hవ లాభ/ధన భావాధిపతి $lord ↔ $main సంబంధం');
      }
    }
    for (final h in const [8, 12]) {
      final lord = D10CareerService.signLord(
        (chart.ascendantSignIndex + h - 1) % 12);
      rLords.add(lord);
      if (_related(chart, main, lord)) {
        risks.add('D1 $hవ మార్పు/వ్యయ భావాధిపతి $lord ↔ $main సంబంధం');
      }
    }
    for (final h in const [8, 12]) {
      final lord = D10CareerService.signLord(
        (d10.ascendantSignIndex + h - 1) % 12);
      rLords.add(lord);
      if (_vRelated(d10, main, lord)) {
        risks.add('D10 $hవ భావాధిపతి $lord ↔ $main సంబంధం — ప్రమాద సూచిక మాత్రమే');
      }
    }
    // D2 matches are chart-wide, never falsely attributed to one business.
    final d2 = D2WealthEvaluationService.evaluate(chart);
    final good = d2.where((e) => _supportIds.contains(e.ruleId) && !e.caution)
        .take(2);
    final bad = d2.where((e) => _riskIds.contains(e.ruleId) && e.caution)
        .take(2);
    for (final d in good) {
      gains.add('D2/ఇందు లగ్నం ${d.ruleId} (సాధారణ ధన మద్దతు): ${d.evidence}');
    }
    for (final d in bad) {
      risks.add('D2/ఇందు లగ్నం ${d.ruleId} (సాధారణ వ్యయ జాగ్రత్త): ${d.evidence}');
    }
    final gain = gains.length;
    final risk = risks.length;
    final tone = gain == 0 && risk == 0 ? D10MoneyTone.insufficient
      : gain >= risk + 2 ? D10MoneyTone.gain
      : risk >= gain + 2 ? D10MoneyTone.risk : D10MoneyTone.mixed;
    return D10MoneyAudit(tone: tone, gainSupport: gain,
      riskSupport: risk, gains: gains, risks: risks,
      limitations: const [
        'ఇది వృత్తి-ప్రత్యేక లాభ హామీ కాదు. D2 ఆధారాలు జాతకం మొత్తానికి వర్తిస్తాయి.',
        '6/8/12 సంబంధం ఒక్కటే నష్ట నిర్ణయం కాదు; విదేశీ, పరిశోధన, సేవా రంగాల్లో వాటికి ఇతర అర్థాలుంటాయి.',
        'మూల వృత్తి PDFల్లో ప్రత్యేక లాభ/నష్ట గణన బరువులు లేవు; ఇక్కడి ఆధారాల లెక్క యాప్ అదనపు పరిశీలన విధానం.',
      ]);
  }

  static Set<String> _lords(AstroChartResult c, List<int> houses) => <String>{
    for (final h in houses)
      D10CareerService.signLord((c.ascendantSignIndex + h - 1) % 12),
  };

  static bool _transitTouches(String planet, int sign, Set<int> targets) =>
    D10VruttiActivationService.transitReachesCareerSign(planet, sign, targets);

  /// Exact one-month sample labels, not daily claims. MD+AD AND at least one
  /// corresponding Jupiter/Saturn contact are required for a directional label.
  static D10MoneyTone monthlyTone({required D10MoneyAudit audit,
      required String md, required String ad, required int jupiterSign,
      required int saturnSign, required AstroChartResult chart}) {
    if (audit.tone == D10MoneyTone.insufficient) return D10MoneyTone.insufficient;
    final goodL = _lords(chart, const [2, 5, 9, 11]);
    final badL = _lords(chart, const [6, 8, 12]);
    final shared = goodL.intersection(badL);
    goodL.removeAll(shared); badL.removeAll(shared);
    final incomeTransit = <int>{for (final h in const [2, 10, 11])
      (chart.ascendantSignIndex + h - 1) % 12};
    final riskTransit = <int>{for (final h in const [6, 8, 12])
      (chart.ascendantSignIndex + h - 1) % 12};
    final gainPeriod = goodL.contains(md) && goodL.contains(ad);
    final riskPeriod = badL.contains(md) && badL.contains(ad);
    final guruIncome = _transitTouches('Jupiter', jupiterSign, incomeTransit);
    final shaniIncome = _transitTouches('Saturn', saturnSign, incomeTransit);
    final guruRisk = _transitTouches('Jupiter', jupiterSign, riskTransit);
    final shaniRisk = _transitTouches('Saturn', saturnSign, riskTransit);
    final gain = audit.gainSupport > 0 && gainPeriod && guruIncome && shaniIncome;
    final risk = audit.riskSupport > 0 && riskPeriod && guruRisk && shaniRisk;
    if (gain && !risk) return D10MoneyTone.gain;
    if (risk && !gain) return D10MoneyTone.risk;
    if (gain && risk) return D10MoneyTone.mixed;
    // Both mixed financial indicators + one income and one expense dasha
    // lord + both real transits reaching the respective houses: middle.
    final mixedDasha = (goodL.contains(md) && badL.contains(ad)) ||
        (badL.contains(md) && goodL.contains(ad));
    final mixedTransits = (guruIncome || guruRisk) &&
        (shaniIncome || shaniRisk) &&
        (guruIncome || shaniIncome) && (guruRisk || shaniRisk);
    if (audit.gainSupport > 0 && audit.riskSupport > 0 &&
        mixedDasha && mixedTransits) return D10MoneyTone.mixed;
    // Neither full MD+AD+Guru+Saturn convergence means *unverified*, not
    // arbitrarily 'middle' or 'loss'.
    return D10MoneyTone.insufficient;
  }

  static String _phase(D10MoneyTone tone, String md, String ad,
      String mainPlanet, bool recovered) {
    if (recovered && tone == D10MoneyTone.gain) return 'పునరుద్ధరణ సూచన';
    if (tone == D10MoneyTone.gain) {
      return md == mainPlanet || ad == mainPlanet
        ? 'ఎదుగుదల + లాభ మద్దతు' : 'లాభ మద్దతు';
    }
    if (tone == D10MoneyTone.risk) {
      return md == mainPlanet || ad == mainPlanet
        ? 'పతన/ఖర్చు ప్రమాద సూచన' : 'వ్యయ ప్రమాద సూచన';
    }
    return tone.label;
  }

  /// By default: previous 12 months + next 36 months. Only compute when the
  /// user opens a particular occupation, never for all 517 list entries.
  static Future<List<D10MoneyWindow>> findMonthlyWindows({
    required AstroChartResult chart,
    required BirthData birthData,
    required D10VruttiMatch match,
    DateTime? referenceDate,
    int monthsBack = 12,
    int monthsAhead = 36,
  }) async {
    if (monthsBack < 0 || monthsAhead < 0) return const [];
    final audit = evaluate(chart, match);
    if (audit.tone == D10MoneyTone.insufficient) return const [];
    final birthday = birthData.localDateTime;
    final system = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart, birthDateTime: birthday);
    final ref = referenceDate ?? DateTime.now();
    final windows = <D10MoneyWindow>[];
    D10MoneyTone? lastTone;
    var pastRisk = false;
    for (var i = -monthsBack; i <= monthsAhead; i++) {
      final sample = DateTime(ref.year, ref.month + i, 15);
      if (sample.isBefore(birthday)) continue;
      final md = DashaService.periodAt(system.mahadashas, sample);
      if (md == null) continue;
      final ad = DashaService.periodAt(
        DashaService.subPeriodsFor(system, md), sample);
      if (ad == null) continue;
      final transit = await D10VruttiActivationService.transitAtMonth(birthData, sample);
      final tone = monthlyTone(audit: audit, md: md.lord, ad: ad.lord,
        jupiterSign: transit.guru, saturnSign: transit.shani, chart: chart);
      if (tone == D10MoneyTone.insufficient) {
        lastTone = null;
        continue;
      }
      final recovered = pastRisk && tone == D10MoneyTone.gain;
      final phase = _phase(tone, md.lord, ad.lord, match.rule.planets.first, recovered);
      final reasons = <String>[
        'వృత్తి: ${match.rule.id} · D1→D10 Confirm + పూర్తి IF–THEN',
        'వింశోత్తరి మహాదశ: ${md.lord}; అంతర్దశ: ${ad.lord}',
        'గురు: రాశి ${transit.guru + 1}, శని: రాశి ${transit.shani + 1} (నెల 15న నమూనా)',
        'స్థిర జాతక ఆధారాలు: లాభ ${audit.gainSupport}, ప్రమాద ${audit.riskSupport}',
        'MD–AD రెండు స్థాయిలు, గురు–శని రెండు గోచార సంబంధాలు కలిసిన నెలలోనే కాల సూచన.',
      ];
      final adjacent = windows.isNotEmpty && lastTone == tone &&
        windows.last.mahadasha == md.lord &&
        windows.last.antardasha == ad.lord &&
        windows.last.end.year * 12 + windows.last.end.month + 1 ==
          sample.year * 12 + sample.month;
      if (adjacent) {
        final previous = windows.removeLast();
        windows.add(D10MoneyWindow(start: previous.start, end: sample,
          age: previous.age, mahadasha: md.lord, antardasha: ad.lord,
          tone: tone, phase: previous.phase, evidence: previous.evidence));
      } else {
        windows.add(D10MoneyWindow(start: sample, end: sample,
          age: D10VruttiActivationService.ageOn(birthday, sample),
          mahadasha: md.lord, antardasha: ad.lord, tone: tone,
          phase: phase, evidence: reasons));
      }
      if (tone == D10MoneyTone.risk) pastRisk = true;
      if (tone == D10MoneyTone.gain) pastRisk = false;
      lastTone = tone;
    }
    return windows;
  }
}
