import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/features/d10_if_then/d10_if_then_engine.dart';
import 'package:astro_app/features/d10_if_then/d10_rules_panel.dart';

void main() {
  testWidgets('Rule → inspection → highlight → remedy order', (tester) async {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: const [
      D10Fact(key: D10FactKeys.d10Agocharishta, chart: 'D10', met: true,
          inspection: 'D10 Saturn in 6th house'),
    ]));
    await tester.pumpWidget(MaterialApp(home: Scaffold(
      body: SingleChildScrollView(child: D10AppliedRulesPanel(report: report)),
    )));
    expect(find.textContaining('D10-IF-SRV-001'), findsOneWidget);
    expect(find.text('జాతక పరిశీలన'), findsNothing);
    await tester.tap(find.text('రూల్ టచ్ → జాతక పరిశీలన'));
    await tester.pumpAndSettle();
    expect(find.text('జాతక పరిశీలన'), findsOneWidget);
    expect(find.textContaining('హైలైట్ ఫలితం:'), findsNothing);
    await tester.ensureVisible(find.text('పరిశీలన టచ్ → హైలైట్ ఫలితం'));
    await tester.tap(find.text('పరిశీలన టచ్ → హైలైట్ ఫలితం'));
    await tester.pumpAndSettle();
    expect(find.textContaining('హైలైట్ ఫలితం:'), findsOneWidget);
    expect(find.text('పరిహారం'), findsNothing);
    await tester.ensureVisible(find.text('ఫలితం టచ్ → పరిహారం'));
    await tester.tap(find.text('ఫలితం టచ్ → పరిహారం'));
    await tester.pumpAndSettle();
    expect(find.text('పరిహారం'), findsOneWidget);
    expect(find.textContaining('ధ్రువీకరించిన పరిహారం'), findsOneWidget);
  });
}
