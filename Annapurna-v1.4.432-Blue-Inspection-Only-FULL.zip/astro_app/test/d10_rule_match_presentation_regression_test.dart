import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

PlanetPosition planet(String name, String code, double degree) => PlanetPosition(
  name: name, shortName: code, longitude: degree, latitude: 0, speed: 1);
AstroChartResult chart() => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 15,
  engineVersion: 'regression-fixture',
  planets: [
    planet('Sun', 'Su', 125), planet('Moon', 'Mo', 42),
    planet('Mars', 'Ma', 95), planet('Mercury', 'Me', 62),
    planet('Jupiter', 'Ju', 245), planet('Venus', 'Ve', 32),
    planet('Saturn', 'Sa', 275), planet('Rahu', 'Ra', 305),
    planet('Ketu', 'Ke', 125),
  ],
);

void main() {
  test('D10 GOV 5L/9L condition status follows actual source-rule match', () {
    final rules = VargaRuleService.allFor(chart: chart(), factor: 10);
    for (final id in ['D10-GOV-01', 'D10-GOV-02']) {
      final rule = rules.singleWhere((r) => r.ruleId == id);
      expect(rule.autoEvaluated, isTrue);
      expect(rule.applicable, rule.tone == VargaRuleTone.favorable);
    }
  });
  test('combined D10 authority and government senior examples are audit-only', () {
    final rules = VargaRuleService.allFor(chart: chart(), factor: 10);
    for (final id in ['D10-GOV-03', 'D10-GOV-04']) {
      final rule = rules.singleWhere((r) => r.ruleId == id);
      expect(rule.autoEvaluated, isFalse);
    }
    expect(rules.singleWhere((r) => r.ruleId == 'D10-GOV-03').tone,
        VargaRuleTone.info);
  });
  test('manual-worker category cannot be auto-matched when exact row misses', () {
    final rules = VargaRuleService.allFor(chart: chart(), factor: 10);
    final worker = rules.singleWhere((r) => r.ruleId == 'D10-PROF-WORKER');
    if (worker.result.contains('confirm కాలేదు') ||
        worker.result.contains('పాక్షికంగా మాత్రమే')) {
      // Other exact skilled-trade rows may still match; therefore verify that
      // no-match/partial daily-worker alone does not make the summary positive.
      expect(worker.tone == VargaRuleTone.favorable, worker.applicable);
    }
  });
}
