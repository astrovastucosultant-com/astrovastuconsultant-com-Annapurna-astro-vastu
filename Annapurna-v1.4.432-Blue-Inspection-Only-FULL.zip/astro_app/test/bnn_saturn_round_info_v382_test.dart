import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_saturn_round_catalog_v382.dart';
import 'package:astro_app/screens/bnn_saturn_round_info_v382.dart';

void main() {
  final catalog = BnnSaturnRounds382.fromJson(
    jsonDecode(
      File('assets/bnn/bnn_saturn_three_rounds_te_v382.json')
          .readAsStringSync(),
    ) as Map<String, dynamic>,
  );
  testWidgets('round2 finance-only review, no template prediction by default', (
    tester,
  ) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: BnnSaturnRoundInfo382(
              catalog: catalog,
              completedAge: 30,
              eventId: 'WEALTH',
            ),
          ),
        ),
      ),
    );
    expect(find.byKey(const ValueKey('saturn-auto-round-2')), findsOneWidget);
    expect(find.text('ఆదాయం లేదా నిల్వలు పెరిగే అవకాశం'), findsNothing);
    await tester.tap(find.text('శని పరిశీలన నమూనాలు (1)'));
    await tester.pumpAndSettle();
    expect(find.text('ధనం'), findsOneWidget);
    expect(find.text('వివాహం / దాంపత్యం'), findsNothing);
    expect(tester.takeException(), isNull);
  });
  testWidgets('age90 and missing age do not create a prediction', (
    tester,
  ) async {
    for (final age in [90, null]) {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: BnnSaturnRoundInfo382(catalog: catalog, completedAge: age),
          ),
        ),
      );
      expect(find.byType(ExpansionTile), findsNothing);
      expect(
        find.textContaining(
          age == null
              ? BnnSaturnRounds382.missing
              : BnnSaturnRounds382.unsupported,
        ),
        findsOneWidget,
      );
    }
  });
}
