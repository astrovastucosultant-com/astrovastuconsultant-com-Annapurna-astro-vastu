import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_shastra_registry.dart';
import 'package:astro_app/astrology/varga_topic_catalog.dart';

void main() {
  test('nineteen distinct vargas include D5 D6 D8 and retain all sixteen', () {
    final factors = VargaService.definitions.map((x) => x.factor).toList();
    expect(factors.length, 19);
    expect(factors.toSet().length, factors.length);
    expect(factors, containsAll(<int>[5, 6, 8, 7, 9, 10, 60]));
    expect(VargaShastraRegistry.coversAllVargas, isTrue);
    expect(VargaTopicCatalog.forFactor(5).length, greaterThan(2));
    expect(VargaTopicCatalog.forFactor(6).length, greaterThan(2));
    expect(VargaTopicCatalog.forFactor(8).length, greaterThan(2));
  });

  test('D5 odd and even Hadda 6 degree boundaries', () {
    expect(VargaService.signForLongitude(0, 5), 0); // Aries 0-6
    expect(VargaService.signForLongitude(5.999, 5), 0);
    expect(VargaService.signForLongitude(6, 5), 10); // Aquarius
    expect(VargaService.signForLongitude(12, 5), 8); // Sagittarius
    expect(VargaService.signForLongitude(18, 5), 2); // Gemini
    expect(VargaService.signForLongitude(24, 5), 6); // Libra
    expect(VargaService.signForLongitude(30, 5), 1); // Taurus even
    expect(VargaService.signForLongitude(36, 5), 5); // Virgo
    expect(VargaService.signForLongitude(54, 5), 9); // Capricorn
  });

  test('D6 odd from Aries, even from Libra; each 5 degrees', () {
    expect(VargaService.signForLongitude(0, 6), 0);
    expect(VargaService.signForLongitude(4.999, 6), 0);
    expect(VargaService.signForLongitude(5, 6), 1);
    expect(VargaService.signForLongitude(25, 6), 5);
    expect(VargaService.signForLongitude(30, 6), 6);
    expect(VargaService.signForLongitude(35, 6), 7);
    expect(VargaService.signForLongitude(55, 6), 11);
  });

  test('D8 movable fixed dual 3 degree 45 minute boundaries', () {
    expect(VargaService.signForLongitude(0, 8), 0);
    expect(VargaService.signForLongitude(3.749999, 8), 0);
    expect(VargaService.signForLongitude(3.75, 8), 1);
    expect(VargaService.signForLongitude(26.25, 8), 7);
    expect(VargaService.signForLongitude(30, 8), 8); // Taurus fixed
    expect(VargaService.signForLongitude(33.75, 8), 9);
    expect(VargaService.signForLongitude(60, 8), 4); // Gemini dual
    expect(VargaService.signForLongitude(63.75, 8), 5);
  });

  test('new varga placements derive from natal sidereal longitudes', () {
    const result = AstroChartResult(
      julianDay: 2441542, ayanamsaDegrees: 23,
      ascendantLongitude: 6,
      engineVersion: 'test',
      planets: [PlanetPosition(name: 'Sun', shortName: 'Su',
          longitude: 33.75, latitude: 0, speed: 1)],
    );
    expect(VargaService.calculate(result, 5).ascendantSignIndex, 10);
    expect(VargaService.calculate(result, 6).ascendantSignIndex, 1);
    expect(VargaService.calculate(result, 8).ascendantSignIndex, 1);
    expect(VargaService.calculate(result, 8).planets.single.signIndex, 9);
    expect(VargaService.extendedVargaDegree(6, 5), closeTo(0, 1e-8));
    expect(VargaService.extendedVargaDegree(8, 5), closeTo(10, 1e-8));
    expect(VargaService.extendedVargaDegree(3.75, 8), closeTo(0, 1e-8));
    expect(VargaService.extendedVargaDegree(5, 8), closeTo(10, 1e-8));
  });
}
