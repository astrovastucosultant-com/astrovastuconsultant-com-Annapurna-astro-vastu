import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:astro_app/settings/app_font_scale.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('saved font size loads, changes, clamps and persists', () async {
    SharedPreferences.setMockInitialValues({
      AnnapurnaFontScale.preferenceKey: 1.3,
    });
    final model = AnnapurnaFontScale.instance;
    await model.load();
    expect(model.value, 1.3);
    await model.setScale(1.4);
    expect(model.value, 1.4);
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getDouble(AnnapurnaFontScale.preferenceKey), 1.4);
    await model.setScale(9.0);
    expect(model.value, 1.5);
    await model.setScale(0.1);
    expect(model.value, 0.9);
    await model.setScale(1.0);
    expect(model.value, 1.0);
  });
}
