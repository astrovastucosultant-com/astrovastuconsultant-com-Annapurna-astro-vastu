import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d10_career_service.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

PlanetPosition _p(String name, String short, double longitude) =>
    PlanetPosition(name: name, shortName: short, longitude: longitude,
      latitude: 0, speed: 1);
AstroChartResult _chart(double asc) => AstroChartResult(
  julianDay: 2451545,
  ayanamsaDegrees: 23,
  ascendantLongitude: asc,
  engineVersion: 'v329-rule-gate',
  planets: [
    _p('Sun', 'Su', 1), _p('Moon', 'Mo', 42),
    _p('Mars', 'Ma', 93), _p('Mercury', 'Me', 64),
    _p('Jupiter', 'Ju', 245), _p('Venus', 'Ve', 126),
    _p('Saturn', 'Sa', 275), _p('Rahu', 'Ra', 305),
    _p('Ketu', 'Ke', 125),
  ],
);

void main() {
  test('Partial OR matches can never become a full foreign promise', () {
    const partial = D10ForeignPromiseEvidence([
      D10ForeignRuleCheck('D1 8L', true),
      D10ForeignRuleCheck('D1 10L', false),
      D10ForeignRuleCheck('D1 3L', false),
      D10ForeignRuleCheck('D10 8L', true),
      D10ForeignRuleCheck('D10 10L', false),
      D10ForeignRuleCheck('D10 3L', false),
      D10ForeignRuleCheck('D10 8L-10L', false),
    ]);
    expect(partial.passedCount, 2);
    expect(partial.fullRuleMatched, isFalse);
    expect(partial.audit, contains('2/7'));
  });

  test('All explicit prerequisites match only when every check succeeds', () {
    const full = D10ForeignPromiseEvidence([
      D10ForeignRuleCheck('a', true), D10ForeignRuleCheck('b', true),
      D10ForeignRuleCheck('c', true), D10ForeignRuleCheck('d', true),
      D10ForeignRuleCheck('e', true), D10ForeignRuleCheck('f', true),
      D10ForeignRuleCheck('g', true),
    ]);
    expect(full.fullRuleMatched, isTrue);
    expect(const D10ForeignPromiseEvidence([]).fullRuleMatched, isFalse);
  });

  test('UI matched row agrees with source-checklist gate for 2 birth charts', () {
    for (final asc in [15.0, 135.0]) {
      final chart = _chart(asc);
      final evidence = D10CareerService.foreignEvidence(chart);
      final row = VargaRuleService.allFor(chart: chart, factor: 10)
          .singleWhere((h) => h.ruleId == 'D10-FOREIGN-JOB');
      expect(evidence.checks.length, 7);
      expect(row.applicable, evidence.fullRuleMatched);
      expect(D10CareerService.foreignPromise(chart), evidence.fullRuleMatched);
      expect(row.inspection, contains('D1 8L'));
      expect(row.inspection, contains('D10 8L'));
      expect(row.result.contains('నిర్ధారించలేదు'), !evidence.fullRuleMatched);
    }
  });
}
