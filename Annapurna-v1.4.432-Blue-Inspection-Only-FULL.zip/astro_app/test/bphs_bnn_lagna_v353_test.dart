import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bphs_lagna_bhava_lord_service.dart';

void main() {
  test('classical sign lords, Gemini lagna', () {
    expect(BphsLagnaBhavaLordService.lordOfNatalHouse(
      ascendantSignIndex:2,house:1),'Mercury');
    expect(BphsLagnaBhavaLordService.lordOfNatalHouse(
      ascendantSignIndex:2,house:4),'Mercury');
    expect(BphsLagnaBhavaLordService.lordOfNatalHouse(
      ascendantSignIndex:2,house:7),'Jupiter');
    expect(BphsLagnaBhavaLordService.lordOfNatalHouse(
      ascendantSignIndex:2,house:10),'Jupiter');
    expect(BphsLagnaBhavaLordService.lordOfNatalHouse(
      ascendantSignIndex:2,house:8),'Saturn');
    expect(BphsLagnaBhavaLordService.lordOfNatalHouse(
      ascendantSignIndex:2,house:9),'Saturn');
  });
  test('whole-sign Lagna house counting has no off-by-one', () {
    expect(BphsLagnaBhavaLordService.wholeSignHouse(lagnaSign:2,planetSign:3),2);
    expect(BphsLagnaBhavaLordService.wholeSignHouse(lagnaSign:2,planetSign:2),1);
    expect(BphsLagnaBhavaLordService.wholeSignHouse(lagnaSign:2,planetSign:1),12);
    expect(BphsLagnaBhavaLordService.wholeSignHouse(lagnaSign:2,planetSign:8),7);
  });
  test('no Ch24 node lord for Rahu/Ketu', () {
    for (var sign=0;sign<12;sign++) {
      expect(BphsLagnaBhavaLordService.signRulers[sign],isNot('Rahu'));
      expect(BphsLagnaBhavaLordService.signRulers[sign],isNot('Ketu'));
    }
  });
}
