import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_sensitive_result_display.dart';

void main() {
  test('traditional mortality caution gets optional homa advice', () {
    const source = 'మరణతుల్య సూచన';
    expect(BnnSensitiveResultDisplay.isMortalityIndicator(source), isTrue);
    expect(BnnSensitiveResultDisplay.publicResult(source),
        BnnSensitiveResultDisplay.mortalityCaution);
    expect(BnnSensitiveResultDisplay.spiritualRemedyFor(source),
        contains('మహామృత్యుంజయ హోమం'));
    expect(BnnSensitiveResultDisplay.spiritualRemedyFor(source),
        contains('వైద్య'));
  });
  test('ordinary health caution does not automatically require homa', () {
    expect(BnnSensitiveResultDisplay.publicResult('ఆరోగ్య సమస్య సూచన'),
        BnnSensitiveResultDisplay.caution);
    expect(BnnSensitiveResultDisplay.spiritualRemedyFor('ఆరోగ్య సమస్య సూచన'),
        isNull);
  });
  test('good health and explicit absence of death risk stay unchanged', () {
    const good = 'ఆరోగ్యం మెరుగుపడుతుంది';
    expect(BnnSensitiveResultDisplay.publicResult(good), good);
    const noRisk = 'మరణ సూచన లేదు';
    expect(BnnSensitiveResultDisplay.publicResult(noRisk), noRisk);
  });
}
