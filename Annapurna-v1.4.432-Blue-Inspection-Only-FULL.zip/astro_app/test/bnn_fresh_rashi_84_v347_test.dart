import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_rashi_rule_service.dart';
import 'package:astro_app/models/birth_data.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('Fresh BNN user catalog has 84 unique, 12 signs x 7 planets', () async {
    final rules = await BnnRashiRuleService.load();
    expect(rules.length, 84);
    expect(rules.map((r) => r.id).toSet().length, 84);
    for (var sign=0; sign<12; sign++) {
      expect(rules.where((r) => r.signIndex == sign).length, 7);
    }
  });

  test('BNN screenshot natal placements match seven exact Rule IDs', () async {
    final rules = await BnnRashiRuleService.load();
    const chart = AstroChartResult(
      julianDay: 2460000, ayanamsaDegrees: 24,
      ascendantLongitude: 60 + 18 + 47/60 + 59/3600,
      engineVersion: 'BNN chart screenshot fixture',
      planets: [
        PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 71.8716666667, latitude: 0, speed: 1),
        PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 54.8869444444, latitude: 0, speed: 0.2),
        PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 116.7655555556, latitude: 0, speed: 1),
        PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108.4094444444, latitude: 0, speed: -0.2),
        PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 125.1633333333, latitude: 0, speed: 0.5),
        PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 160.7786111111, latitude: 0, speed: 12),
        PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 245.25, latitude: 0, speed: -0.1),
        PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 272.34, latitude: 0, speed: -0.1),
        PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 92.34, latitude: 0, speed: -0.1),
      ],
    );
    final results = BnnRashiRuleService.evaluate(
      rules: rules, chart: chart, gender: BirthGender.male);
    final matched = results.where((x) => x.matched).toList();
    expect(matched.length, 7);
    expect(matched.map((x) => x.rule.id).toSet(), {
      'BNN-RASHI-014', 'BNN-RASHI-020', 'BNN-RASHI-022',
      'BNN-RASHI-025', 'BNN-RASHI-031', 'BNN-RASHI-037',
      'BNN-RASHI-061',
    });
    final sourceGenderClause = matched.firstWhere((x) => x.rule.id == 'BNN-RASHI-031');
    expect(sourceGenderClause.displayEffect, contains('స్త్రీ జాతకంలో భర్త'));
    // The original source wording is visible for all saved gender settings.
    final femaleResults = BnnRashiRuleService.evaluate(
      rules: rules, chart: chart, gender: BirthGender.female);
    final unspecifiedResults = BnnRashiRuleService.evaluate(
      rules: rules, chart: chart, gender: BirthGender.unspecified);
    for (final evaluated in [femaleResults, unspecifiedResults]) {
      expect(evaluated.where((x) => x.matched).length, 7);
      expect(evaluated.firstWhere((x) => x.rule.id == 'BNN-RASHI-031')
          .displayEffect, sourceGenderClause.displayEffect);
    }
    final sun = matched.firstWhere((x) => x.rule.id == 'BNN-RASHI-022');
    expect(sun.displayEffect, isNot(contains('తండ్రి కాళ్ల స్థితి')));
    final venus = matched.firstWhere((x) => x.rule.id == 'BNN-RASHI-020');
    expect(venus.house, 1);
    final saturn = matched.firstWhere((x) => x.rule.id == 'BNN-RASHI-014');
    expect(saturn.house, 12);
    expect(results.where((x) => !x.matched).length, 77);
  });

  test('No position is not treated as false natal placement', () async {
    final rules = await BnnRashiRuleService.load();
    const chart = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 60,
      engineVersion: 'incomplete natal fixture', planets: []);
    final findings = BnnRashiRuleService.evaluate(
      rules: rules, chart: chart, gender: BirthGender.unspecified);
    expect(findings.where((f) => f.matched), isEmpty);
    expect(findings.where((f) => f.position == null).length, 84);
  });
}
