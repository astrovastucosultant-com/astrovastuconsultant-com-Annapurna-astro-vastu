import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_cycle_result_service.dart';
import 'package:astro_app/astrology/bnn_jupiter_cycle_service.dart';
import 'package:astro_app/astrology/bnn_planet_combination_service.dart';
import 'package:astro_app/astrology/bnn_special_multi_planet_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  PlanetPosition p(String name,int sign,double degree) => PlanetPosition(
    name:name,shortName:name,longitude:sign*30.0+degree,
    latitude:0,speed:1);
  AstroChartResult chart(List<PlanetPosition> planets) => AstroChartResult(
    julianDay:2460000,ayanamsaDegrees:24,
    ascendantLongitude:78,engineVersion:'bnn-v368',planets:planets);

  test('Jupiter year contacts sorted by degrees; other years have no event', () async {
    final c=chart([p('Jupiter',8,5),p('Ketu',9,24),
      p('Sun',9,26),p('Mercury',9,12),p('Moon',11,3)]);
    final cycles=BnnJupiterCycleService.calculate(chart:c,
      themes:await BnnJupiterCycleService.loadThemes());
    final first=cycles[0].years[1];
    expect(first.progressedSignIndex,9);
    expect(first.natalSignContacts.map((x)=>x.name),
      ['Mercury','Ketu','Sun']);
    expect(first.natalSignContacts.map((x)=>x.degreesInSign),[12,24,26]);
    expect(cycles[0].years[2].natalSignContacts,isEmpty);
    expect(first.calculationId,'BNN-JUP-C01-AGE001');
  });

  test('Age-year Jupiter card is one contextual evidence, not repeated cycle topic', () async {
    final catalog=await BnnCycleResultService.load();
    final out=BnnCycleResultService.forJupiter(cycle:2,ageStart:18,
      natalContacts:[p('Venus',2,11.87),p('Moon',2,4.1)],
      catalog:catalog,roundTopic:'కుటుంబం, వాక్కు, విద్య, ఆర్థిక ప్రారంభం',
      progressedSignIndex:2,relativeSignFromNatalJupiter:7);
    expect(out.length,1);
    expect(out.single.isSourceRule,isFalse);
    expect(out.single.result,contains('వివాహం'));
    expect(out.single.result,contains('తల్లి'));
    expect(out.single.result.contains('ఈ సైకిల్ పరిశీలన అంశం'),isFalse);
    expect(out.single.ifText,contains('7వ రాశి'));
    expect(out.single.id,contains('C02-AGE018'));
    expect(out.single.tone,'neutral');
  });

  test('Unsourced Jupiter predictions cannot be inferred from Saturn rules', () async {
    final catalog=await BnnCycleResultService.load();
    final out=BnnCycleResultService.forJupiter(cycle:1,ageStart:6,
      natalContacts:[p('Rahu',6,15)],catalog:catalog);
    expect(out.length,1);
    expect(out.single.isSourceRule,isFalse);
    expect(out.single.result,contains('ప్రత్యేక మూల IF–THEN నియమం ప్రస్తుతం లేదు'));
    expect(BnnCycleResultService.forJupiter(cycle:1,ageStart:7,
      natalContacts:[],catalog:catalog),isEmpty);
  });

  test('A source rule requires exact cycle AND age AND planet guards', () async {
    final loaded=await BnnCycleResultService.load();
    final original=BnnCycleResultCatalog(contacts:loaded.contacts,
      sourceRules:[
        {'id':'TEST-JUP-1','moving_planet':'Jupiter',
          'natal_planet':'Venus','cycle':2,'age_start':18,
          'natal_sign':2,'relative_sign':7,'progressed_sign':2,
          'then_te':'పరీక్ష కోసం మూల ఫలితం','if_te':'పూర్తి పరీక్ష షరతు',
          'source':'test rule','page':'test','tone':'favorable'},
      ]);
    List<BnnCycleReading> evaluate(int age,int sign,int relative) =>
      BnnCycleResultService.forJupiter(cycle:2,ageStart:age,
        natalContacts:[p('Venus',sign,5)],catalog:original,
        progressedSignIndex:sign,relativeSignFromNatalJupiter:relative);
    expect(evaluate(18,2,7).single.isSourceRule,isTrue);
    expect(evaluate(18,2,6).single.isSourceRule,isFalse);
    expect(evaluate(19,2,7).single.isSourceRule,isFalse);
    expect(evaluate(18,3,7).single.isSourceRule,isFalse);
  });

  test('3/4 planet cases prioritize quad and label partial sign evidence', () async {
    final pairs=await BnnPlanetCombinationService.load();
    final examples=await BnnSpecialMultiPlanetService.load();
    final c=chart([p('Sun',0,4),p('Venus',0,16),
      p('Rahu',0,9),p('Mercury',0,29),p('Ketu',0,2)]);
    final matches=BnnSpecialMultiPlanetService.matchingSourceExamples(
      group:BnnPlanetCombinationService.groups(chart:c,
        readings:BnnPlanetCombinationService.evaluate(chart:c,rules:pairs))
        .firstWhere((g)=>g.sameSignIndex==0),rules:examples);
    expect(matches,isNotEmpty);
    expect(matches.first.rule.planets.length,4);
    expect(matches.first.hasExactSignGuards,isTrue);
    expect(matches.first.hasExtraGroupPlanets,isTrue);
    final partial=matches.firstWhere((x)=>x.rule.id.contains('CH335'));
    expect(partial.hasExactSignGuards,isFalse);
    expect(partial.evidenceLabel,contains('మూలరాశి షరతులు తెలియవు'));
    expect(partial.hasExtraGroupPlanets,isTrue);
  });
}
