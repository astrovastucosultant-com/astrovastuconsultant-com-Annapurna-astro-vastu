import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_unified_evidence_v376.dart';
import 'package:astro_app/screens/bnn_unified_evidence_panel_v376.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 24,
    ascendantLongitude: 2,
    engineVersion: 'fixture',
    planets: [
      for (final e in const {
        'Sun': 4,
        'Moon': 3,
        'Mars': 7,
        'Mercury': 5,
        'Jupiter': 0,
        'Venus': 6,
        'Saturn': 0,
        'Rahu': 2,
        'Ketu': 8,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value * 30.0 + 2,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  const events = [
    UnifiedEvent376(
      id: 'CAREER-ENTRY',
      title: 'ఉద్యోగ ప్రారంభం',
      mainHouse: 10,
      houses: {2, 6, 10, 11},
      ageFrom: 14,
    ),
  ];
  final result = BnnUnifiedEvidenceService376.evaluate(
    chart: chart,
    birth: DateTime(2000),
    completedAge: 5,
    events: events,
    cycleSourceRules: const [
      {
        'id': 'BNN-SAT-R1-RAHU',
        'moving_planet': 'Saturn',
        'natal_planet': 'Rahu',
        'cycle': 1,
        'source': 'Source fixture',
        'page': 'xiii',
        'if_te': 'IF fixture',
        'then_te': 'THEN fixture',
      },
    ],
    context: const UnifiedLifeContext376(role: 'employee', hadFirstJob: true),
  );
  testWidgets(
    'low coverage remains visible and expands source and known history',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: UnifiedEventCard376(evidence: result.single.events.single),
            ),
          ),
        ),
      );
      expect(find.textContaining('శని 0/4 భావసంబంధాలు'), findsOneWidget);
      expect(find.textContaining('గురు 1/4 భావసంబంధాలు'), findsOneWidget);
      expect(
        find.textContaining('BSP మూల గణన అందుబాటులో లేదు'),
        findsOneWidget,
      );
      await tester.tap(find.text('ఉద్యోగ ప్రారంభం'));
      await tester.pumpAndSettle();
      expect(find.textContaining('BNN-SAT-R1-RAHU'), findsOneWidget);
      expect(find.textContaining('మొదటి ఉద్యోగం ఇప్పటికే'), findsOneWidget);
      expect(find.textContaining('D24'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('sensitive review gives caution without age or score', (
    tester,
  ) async {
    const event = UnifiedEvent376(
      id: 'LONGEVITY',
      title: 'ఆయుర్దాయ పరిశీలన',
      mainHouse: 1,
      houses: {1, 8},
      sensitive: true,
    );
    const channel = UnifiedChannel376('test', {1}, {}, []);
    const evidence = UnifiedEventEvidence376(
      event: event,
      saturn: channel,
      jupiter: channel,
      bcp: channel,
      bsp: channel,
      commonHouses: {1},
      sourceRules: [],
      cautions: [],
    );
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(body: UnifiedEventCard376(evidence: evidence)),
      ),
    );
    expect(find.textContaining('జాగ్రత్త అవసరం'), findsOneWidget);
    expect(find.byType(ExpansionTile), findsNothing);
    expect(find.textContaining('%'), findsNothing);
    expect(tester.takeException(), isNull);
  });
}
