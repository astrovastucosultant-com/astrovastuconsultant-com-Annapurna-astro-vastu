import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d2_dhana_asthi_registry.dart';
import 'package:astro_app/astrology/d2_wealth_evaluation_service.dart';
import 'package:astro_app/astrology/d2_rule_conflict_service.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

void main() {
  AstroChartResult sampleChart({bool withMoon = true}) {
    const data = <String, double>{
      'Sun': 1, 'Moon': 7, 'Mars': 45, 'Mercury': 75,
      'Jupiter': 105, 'Venus': 135, 'Saturn': 165,
      'Rahu': 195, 'Ketu': 15,
    };
    return AstroChartResult(
      julianDay: 2460950.5,
      ayanamsaDegrees: 24.0,
      ascendantLongitude: 2.0, // Aries rising
      engineVersion: 'synthetic-test',
      planets: data.entries
          .where((x) => withMoon || x.key != 'Moon')
          .map((x) => PlanetPosition(
                name: x.key,
                shortName: x.key.substring(0, 2),
                longitude: x.value,
                latitude: 0.0,
                speed: 1.0,
              ))
          .toList(),
    );
  }

  test('all 58 original D2 rules remain in the registry exactly once', () {
    final ids = D2DhanaAsthiRegistry.rules.map((x) => x.id).toList();
    expect(ids.length, 58);
    expect(ids.toSet().length, 58);
    expect(D2WealthEvaluationService.pendingReason.length, 11);
    expect(ids.toSet().containsAll(D2WealthEvaluationService.pendingReason.keys), isTrue);
  });

  test('Indu Lagna uses both ninth-house lords and inclusive count', () {
    // Lagna Aries and Moon Aries: ninth is Sagittarius, ruled by Jupiter.
    // Jupiter Kala 10 + Jupiter Kala 10 = 20; remainder 8; Aries+7=Scorpio.
    expect(D2WealthEvaluationService.induLagnaSign(sampleChart()), 7);
  });

  test('source checks do not duplicate the same rule or produce phantom IDs', () {
    final chart = sampleChart();
    final hits = D2WealthEvaluationService.evaluate(chart);
    final sourceIds = D2DhanaAsthiRegistry.rules.map((x) => x.id).toSet();
    expect(hits.map((x) => x.ruleId).toSet().length, hits.length);
    expect(sourceIds.containsAll(hits.map((x) => x.ruleId)), isTrue);
    expect(hits.every((x) => x.percent >= 1 && x.percent <= 100), isTrue);
    expect(hits.any((x) => x.ruleId == 'D2-IN-011'), isTrue);
    expect(hits.any((x) => D2WealthEvaluationService.pendingReason.containsKey(x.ruleId)), isFalse);
  });

  test('D1 conditions can simultaneously match opposite vehicle source rules', () {
    const positions = <String, double>{
      'Sun': 35, 'Moon': 155, // D1 fourth lord Moon in sixth house.
      'Mars': 101, 'Saturn': 110, // Two planets in fourth house.
      'Venus': 75, // Venus in third house: not treated as strong.
      'Mercury': 135, 'Jupiter': 220, 'Rahu': 305, 'Ketu': 125,
    };
    final chart = AstroChartResult(
      julianDay: 2460950.5,
      ayanamsaDegrees: 24,
      ascendantLongitude: 2,
      engineVersion: 'synthetic-contradiction',
      planets: positions.entries.map((x) => PlanetPosition(
        name: x.key,
        shortName: x.key.substring(0, 2),
        longitude: x.value,
        latitude: 0,
        speed: 1,
      )).toList(),
    );
    final matches = D2WealthEvaluationService.evaluate(chart)
        .map((x) => x.ruleId).toSet();
    expect(matches.contains('D2-VH-003'), isTrue);
    expect(matches.contains('D2-VH-006'), isTrue);
    final conflicts = D2RuleConflictService.detect(matches);
    expect(conflicts.any((c) => c.id == 'D2-CONFLICT-VEHICLE'), isTrue);
  });

  test('missing Moon does not create a fictional Indu Lagna match', () {
    expect(D2WealthEvaluationService.evaluate(sampleChart(withMoon: false)), isEmpty);
  });

  test('matched D2 results display source evidence, not misleading 100% labels', () {
    final rows = VargaRuleService.allFor(chart: sampleChart(), factor: 2);
    final matches = rows.where((x) => x.applicable && x.autoEvaluated);
    expect(matches, isNotEmpty);
    for (final row in matches) {
      expect(row.topic.contains('% ఆధార సూచిక'), isFalse,
          reason: '${row.ruleId} must not claim a percentage in its title');
      expect(row.result.contains('ఆధార సూచిక'), isFalse,
          reason: '${row.ruleId} is a matched rule, not event probability');
      expect(row.inspection, contains('మూల షరతు'));
      expect(row.rule, isNotEmpty);
      expect(row.source, contains('page'));
    }
  });

  test('Indu income-route placement is inspection, never a favourable result', () {
    final rows = VargaRuleService.allFor(chart: sampleChart(), factor: 2);
    final route = rows.singleWhere((x) => x.ruleId == 'D2-IN-011');
    expect(route.applicable, isFalse);
    expect(route.autoEvaluated, isFalse);
    expect(route.result, contains('ఈ నియమం ఒక్కటితో నిర్ణయించలేదు'));
    expect(route.inspection, contains('ఇందు లగ్నం'));
    expect(route.source, contains('page 2'));
  });

  test('pending wealth-level rules never present source outcome as natal result', () {
    final rows = VargaRuleService.allFor(chart: sampleChart(), factor: 2);
    final pending = rows.singleWhere((x) => x.ruleId == 'D2-ST-001');
    expect(pending.applicable, isFalse);
    expect(pending.result, contains('ఈ జాతకానికి ఫలితం నిర్ధారించలేదు'));
    expect(pending.result, isNot(contains('మహా కోటీశ్వర')));
    expect(pending.rule, contains('మూల ఫలితం'));
  });

  test('every D2 rule remains available in source audit or matched results', () {
    final list = VargaRuleService.allFor(chart: sampleChart(), factor: 2);
    for (final source in D2DhanaAsthiRegistry.rules) {
      expect(list.where((x) => x.ruleId == source.id).length, 1);
    }
  });
}
