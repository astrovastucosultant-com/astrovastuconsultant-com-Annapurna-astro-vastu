import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/ashtakavarga_service.dart';
import 'package:astro_app/astrology/d10_pav_transit_career_service.dart';

void main() {
  const natal = AstroChartResult(
    julianDay: 2460000.5, ayanamsaDegrees: 24,
    ascendantLongitude: 18, engineVersion: 'unit-test',
    planets: [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 10, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 42, latitude: 0, speed: 12),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 75, latitude: 0, speed: 0.5),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 141, latitude: 0, speed: 0.1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 174, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 207, latitude: 0, speed: -0.1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 240, latitude: 0, speed: -0.05),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 60, latitude: 0, speed: -0.05),
    ],
  );

  final birth = BirthData(
    name: 'Test', localDateTime: DateTime(1981, 12, 15, 15, 50),
    place: 'Guntur', latitude: 16.3, longitude: 80.4,
    timezoneOffsetHours: 5.5, ayanamsa: AyanamsaType.lahiri,
  );

  final values = <String, double>{
    'Jupiter': 3.75, // Exactly second kakshya, ruled by Jupiter.
    'Saturn': 359.999, // Pisces eighth kakshya, Lagna contributor.
    'Sun': 42, 'Moon': 75, 'Mars': 108,
    'Mercury': 141, 'Venus': 174,
  };

  PlanetPosition fake(String name) => PlanetPosition(
    name: name, shortName: name.substring(0, 2),
    longitude: values[name]!, latitude: 0,
    speed: name == 'Saturn' ? -0.05 : 0.1,
  );

  test('real clock conversion uses natal timezone not phone timezone', () {
    final utc = D10PavTransitCareerService.localToUtc(
        birth, DateTime(2026, 11, 3, 15, 30));
    expect(utc, DateTime.utc(2026, 11, 3, 10));
  });

  test('pure transit snapshot uses correct PAV recipient, sign and kakshya', () {
    final av = AshtakavargaService.calculate(natal);
    final result = D10PavTransitCareerService.evaluatePositions(
      birthData: birth, natal: natal, av: av,
      localDateTime: DateTime(2026, 11, 3, 15, 30),
      transitPositions: values.keys.map(fake).toList(),
      mahadasha: 'Jupiter', antardasha: 'Rahu',
    );
    expect(result.planets.length, 7);
    final guru = result.planets.first;
    expect(guru.position.name, 'Jupiter');
    expect(guru.isDashaLord, isTrue);
    expect(guru.kakshya.kakshyaIndex, 2);
    expect(guru.kakshya.giver, 'Jupiter');
    expect(guru.kakshya.signIndex, 0);
    expect(guru.houseFromNatalLagna, 1);
    expect(guru.kakshya.hasBindu,
        av.prastara['Jupiter']!['Jupiter']![0] == 1);
    expect(guru.bav, av.bhinna['Jupiter']![0]);
    expect(guru.sav, av.sarva[0]);
    final shani = result.planets[1];
    expect(shani.position.retrograde, isTrue);
    expect(shani.kakshya.kakshyaIndex, 8);
    expect(shani.kakshya.giver, 'Lagna');
    expect(shani.kakshya.signIndex, 11);
    expect(result.omittedDashaLords, ['Rahu']);
    expect(result.utcDateTime, DateTime.utc(2026, 11, 3, 10));
  });

  test('real transit resolver receives selected sidereal mode and UTC instant', () async {
    final av = AshtakavargaService.calculate(natal);
    final called = <String>[];
    final result = await D10PavTransitCareerService.calculate(
      birthData: birth, natal: natal, av: av,
      localDateTime: DateTime(2026, 11, 3, 15, 30),
      mahadasha: 'Moon', antardasha: 'Saturn',
      resolver: ({required DateTime utc, required String planetName,
          required AyanamsaType ayanamsa}) async {
        expect(utc, DateTime.utc(2026, 11, 3, 10));
        expect(ayanamsa, AyanamsaType.lahiri);
        called.add(planetName);
        return fake(planetName);
      },
    );
    expect(called, D10PavTransitCareerService.planetOrder);
    expect(result.planets.where((p) => p.isDashaLord).length, 2);
    expect(result.omittedDashaLords, isEmpty);
  });

  test('missing or duplicated planets never produce a fabricated transit', () {
    final av = AshtakavargaService.calculate(natal);
    expect(() => D10PavTransitCareerService.evaluatePositions(
      birthData: birth, natal: natal, av: av,
      localDateTime: DateTime(2026),
      transitPositions: [fake('Jupiter')],
    ), throwsStateError);
    expect(() => D10PavTransitCareerService.evaluatePositions(
      birthData: birth, natal: natal, av: av,
      localDateTime: DateTime(2026),
      transitPositions: [...values.keys.map(fake), fake('Jupiter')],
    ), throwsStateError);
  });
}
