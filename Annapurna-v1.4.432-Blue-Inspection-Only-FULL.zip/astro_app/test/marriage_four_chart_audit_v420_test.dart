import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/marriage_chrome_if_then_engine.dart';
import 'package:astro_app/screens/marriage_audit_v420.dart';
import 'package:astro_app/screens/topic_result_card_v391.dart';
import 'package:astro_app/astrology/multi_chart_topic_service.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545.0, ayanamsaDegrees: 24,
    ascendantLongitude: 4, engineVersion: 'v420-fixture',
    planets: const [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 2, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 38, latitude: 0, speed: 1),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 76, latitude: 0, speed: 1),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 122, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 164, latitude: 0, speed: 1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 209, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 240, latitude: 0, speed: 1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 281, latitude: 0, speed: -1),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 101, latitude: 0, speed: -1),
    ],
  );

  test('all audited event mappings use an existing Chrome rule ID', () {
    final ids = MarriageChromeIfThenEngine.rules.map((r) => r.id).toSet();
    expect(ids.length, 43);
    for (final group in MarriageTopics420.groups) {
      for (final id in group.ruleIds) expect(ids, contains(id));
    }
    expect(MarriageTopics420.groups.first.vargas, containsAll([1, 9]));
    expect(MarriageTopics420.groups[6].vargas, containsAll([1, 9, 7, 30]));
    expect(MarriageTopics420.groups[8].ruleIds, isEmpty); // foreign marriage pending
  });

  testWidgets('four chart positions visible above the source audit, including D7 and D30',
      (tester) async {
    tester.view.physicalSize = const Size(390, 970);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(home: Scaffold(
      body: SingleChildScrollView(child: Column(children: [
        MarriageFourCharts420(chart: chart),
        MarriageTopics420(chart: chart),
      ])),
    )));
    expect(find.byKey(const ValueKey('marriage-four-chart-audit-420')), findsOneWidget);
    for (final d in [1, 9, 7, 30]) {
      expect(find.byKey(ValueKey('marriage-chart-open-$d')), findsOneWidget);
    }
    expect(find.textContaining('ప్రేమ / వివాహ అంశాల వారీ'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('marriage result sheet groups rules before optional overview charts',
      (tester) async {
    const summary = MultiChartTopicEvidence(
      name: 'వివాహం', chartOrderSourceId: 'VARGA-CROSS-004',
      note: 'source order D1 D9 D2 D7', stages: [
        TopicStageEvidence(factor: 1, status: TopicStageStatus.insufficientEvidence,
            ruleIds: ['VARGA-CROSS-031'], details: 'audit source'),
      ],
    );
    await tester.pumpWidget(MaterialApp(home: Scaffold(
      body: TopicResultCard391(chart: chart, summary: summary, gender: 'male'),
    )));
    await tester.tap(find.text('వివాహం'));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('marriage-topics-420')), findsOneWidget);
    expect(find.byKey(const ValueKey('marriage-four-chart-audit-420')), findsNothing);
    expect(find.textContaining('ప్రేమ / వివాహ అంశాల వారీ'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
