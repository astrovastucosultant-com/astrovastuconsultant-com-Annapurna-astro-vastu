import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/ashtakavarga_service.dart';
import 'package:astro_app/astrology/d10_varga_ashtakavarga_service.dart';
import 'package:astro_app/astrology/varga_ashtakavarga_service.dart';
import 'package:astro_app/astrology/varga_rule_match_policy.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_topic_catalog.dart';

const _seven = <PlanetPosition>[
  PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 10, latitude: 0, speed: 1),
  PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 44, latitude: 0, speed: 13),
  PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 108, latitude: 0, speed: 0.7),
  PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 152, latitude: 0, speed: 1.1),
  PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 224, latitude: 0, speed: 0.1),
  PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 281, latitude: 0, speed: 1.2),
  PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 334, latitude: 0, speed: 0.04),
];

AstroChartResult sample({List<PlanetPosition> planets = _seven}) =>
    AstroChartResult(julianDay: 2450000.5, ayanamsaDegrees: 23.5,
        ascendantLongitude: 37.5, planets: planets, engineVersion: 'test');

void main() {
  test('19 charts, 176 topics: each house has audited SAV/BAV/PAV', () {
    final factors = VargaService.definitions.map((e) => e.factor).toList();
    expect(factors.length, 19);
    expect(factors.toSet(), VargaRuleMatchPolicy.supportedFactors);
    var topics = 0;
    for (final factor in factors) {
      final report = VargaAshtakavargaService.calculate(sample(), factor);
      expect(report.auditPassed, isTrue, reason: 'D$factor audit failed');
      expect(report.selected.grandTotal, 337);
      expect(report.natal.grandTotal, 337);
      expect(report.houses.length, 12);
      for (final house in report.houses) {
        expect(house.arithmeticValid, isTrue);
        expect(house.bav.length, 7);
        expect(house.pavContributors.length, 7);
        expect(house.sav, report.selected.sarva[house.signIndex]);
        for (final planet in AshtakavargaService.planetOrder) {
          expect(house.pavContributors[planet]!.length, house.bav[planet]);
          expect(house.bav[planet], inInclusiveRange(0, 8));
        }
      }
      for (final topic in VargaTopicCatalog.forFactor(factor)) {
        topics++;
        expect(report.forHouse(topic.house).house, topic.house);
        expect(report.ruleIdForHouse(topic.house), contains('AV-D$factor-H'));
      }
    }
    expect(topics, 176);
  });

  test('D1 row uses the actual natal AV table', () {
    final report = VargaAshtakavargaService.calculate(sample(), 1);
    expect(identical(report.natal, report.selected), isTrue);
    expect(report.houses[0].sav, report.natal.arithmetic.savHouse(1));
  });

  test('D10 generalized AV equals existing specialized D10 result', () {
    final generic = VargaAshtakavargaService.calculate(sample(), 10);
    final old = D10VargaAshtakavargaService.calculate(sample());
    expect(old.auditPassed, isTrue);
    expect(generic.selected.sarva, old.dashamsa.sarva);
    for (final planet in AshtakavargaService.planetOrder) {
      expect(generic.selected.bhinna[planet], old.dashamsa.bhinna[planet]);
      expect(generic.selected.prastara[planet], old.dashamsa.prastara[planet]);
    }
  });

  test('D16 uses selected method with separately audited AV', () {
    for (final method in D16CalculationMethod.values) {
      final result = VargaAshtakavargaService.calculate(sample(), 16,
          d16Method: method);
      expect(result.d16Method, method);
      expect(result.auditPassed, isTrue);
      expect(result.lagnaSignIndex, VargaService.calculate(sample(), 16,
          d16Method: method).ascendantSignIndex);
    }
  });

  test('AV facts are never automatically promoted to a natal IF-THEN outcome', () {
    for (final factor in VargaRuleMatchPolicy.supportedFactors) {
      final id = VargaAshtakavargaService.calculate(sample(), factor)
          .ruleIdForHouse(10);
      expect(VargaRuleMatchPolicy.isCrossVargaEvidence(id), isTrue);
    }
  });

  test('rejects missing or duplicated classical planets', () {
    expect(() => VargaAshtakavargaService.calculate(
        sample(planets: _seven.skip(1).toList()), 9), throwsStateError);
    expect(() => VargaAshtakavargaService.calculate(
        sample(planets: [..._seven, _seven.first]), 9), throwsStateError);
  });

  test('rejects unsupported varga and invalid house', () {
    expect(() => VargaAshtakavargaService.calculate(sample(), 11),
        throwsArgumentError);
    final result = VargaAshtakavargaService.calculate(sample(), 7);
    expect(() => result.forHouse(0), throwsRangeError);
    expect(() => result.forHouse(13), throwsRangeError);
  });
}
