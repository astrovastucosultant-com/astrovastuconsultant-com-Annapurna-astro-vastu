import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d10_career_service.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/features/d10_if_then/d10_if_then_engine.dart';
import 'package:astro_app/features/d10_if_then/d10_live_bridge.dart';

PlanetPosition planet(String n, double lon) => PlanetPosition(
    name: n, shortName: n.substring(0, 2), longitude: lon,
    latitude: 0, speed: 1);
AstroChartResult chart({double saturn = 275, double asc = 15}) =>
    AstroChartResult(julianDay: 0, ayanamsaDegrees: 0,
      ascendantLongitude: asc, engineVersion: 'test', planets: [
        planet('Sun', 125), planet('Moon', 42), planet('Mars', 95),
        planet('Mercury', 62), planet('Jupiter', 245),
        planet('Venus', 32), planet('Saturn', saturn),
        planet('Rahu', 305), planet('Ketu', 125),
      ]);

void main() {
  test('D1/D10 source states exactly match the existing Saturn calculator', () {
    for (final saturn in [15.0, 45.0, 195.0, 275.0, 300.0]) {
      final natal = chart(saturn: saturn);
      final stream = D10CareerService.saturnStream(natal);
      final rows = VargaRuleService.allFor(chart: natal, factor: 10);
      final ctx = D10LiveBridge.context(chart: natal, rules: rows);
      expect(ctx.decidingValue(D10FactKeys.d1Gocharishta),
          stream.birthState == 'GOCHARASHTHA');
      expect(ctx.decidingValue(D10FactKeys.d1Agocharishta),
          stream.birthState == 'AGOCHARASHTHA');
      expect(ctx.decidingValue(D10FactKeys.d10Gocharishta),
          stream.dashamsaState == 'GOCHARASHTHA');
      expect(ctx.decidingValue(D10FactKeys.d10Agocharishta),
          stream.dashamsaState == 'AGOCHARASHTHA');
      final report = D10IfThenEngine().evaluate(ctx);
      if (stream.dashamsaState == 'GOCHARASHTHA') {
        expect(report.appliedRules.any((r) => r.rule.id == 'D10-IF-BUS-001'), isTrue);
      } else if (stream.dashamsaState == 'AGOCHARASHTHA') {
        expect(report.appliedRules.any((r) => r.rule.id == 'D10-IF-SRV-001'), isTrue);
      }
    }
  });

  test('government source fact follows actual GOV-01/02 matches', () {
    final natal = chart();
    final rows = VargaRuleService.allFor(chart: natal, factor: 10);
    final matches = rows.where((r) =>
        (r.ruleId == 'D10-GOV-01' || r.ruleId == 'D10-GOV-02') &&
        r.autoEvaluated && r.applicable &&
        r.tone == VargaRuleTone.favorable).toList();
    final ctx = D10LiveBridge.context(chart: natal, rules: rows);
    expect(ctx.decidingValue(D10FactKeys.d1GovernmentLink), matches.isNotEmpty);
  });

  test('missing gov source rules means UNKNOWN, not false/true', () {
    final ctx = D10LiveBridge.context(chart: chart(), rules: const []);
    expect(ctx.decidingValue(D10FactKeys.d1GovernmentLink), isNull);
    expect(D10IfThenEngine().evaluate(ctx).appliedRules.any(
        (r) => r.rule.id == 'D10-IF-GOV-001'), isFalse);
  });

  test('invalid natal chart cannot trigger any rules', () {
    final invalid = AstroChartResult(julianDay: 0, ayanamsaDegrees: 0,
      ascendantLongitude: 0, planets: const [], engineVersion: 'invalid');
    final ctx = D10LiveBridge.context(chart: invalid, rules: const []);
    expect(D10IfThenEngine().evaluate(ctx).appliedRules, isEmpty);
  });

  test('cross-varga data never changes D10 applied rule IDs', () {
    final natal = chart();
    final rows = VargaRuleService.allFor(chart: natal, factor: 10);
    final base = D10IfThenEngine().evaluate(
        D10LiveBridge.context(chart: natal, rules: rows));
    final withCross = D10IfThenEngine().evaluate(D10LiveBridge.context(
        chart: natal, rules: rows,
        crossVarga: const [VargaCrossObservation(varga: 'D9',
          sourceRuleId: 'VARGA-CROSS-001', inspection: 'support only')]));
    expect(withCross.appliedRules.map((r) => r.rule.id).toList(),
        base.appliedRules.map((r) => r.rule.id).toList());
  });

  test('19 legacy vargas still exist after additive D10 work', () {
    expect(VargaService.definitions.length, 19);
    expect(VargaService.definitions.any((d) => d.factor == 10), isTrue);
    expect(VargaService.definitions.any((d) => d.factor == 60), isTrue);
  });
}
