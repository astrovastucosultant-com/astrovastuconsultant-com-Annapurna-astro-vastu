import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jamakola_special_service.dart';

void main() {
  test('published 2026 November 13 public Vaidyanathan fixture', () {
    // https://www.hindupanchangam.in/en/tools/jamakol-prasannam/
    // Pisces Udayam 3deg57min56sec, Gemini Arudam 20deg24min,
    // Sun Libra => Taurus Veedhi. Kavippu is Aquarius 9deg36min.
    final k=JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:333+57/60+56/3600,
      arudam:80+24/60,
      anchorSignIndex:1);
    expect(k,closeTo(309+36/60,1e-9));
  });

  test('exact degree contact and retrograde next marker are separate', () {
    final contact=JamakolaSpecialService.kavippuJamaTouch(
      kavippuLongitude:159.0,
      jamaGrahas:const [
        JamaRingPosition('Mercury',159.0),
        JamaRingPosition('Moon',158.5),
        JamaRingPosition('Sun',121.0),
      ]);
    expect(contact.touchingNow.map((e)=>e.name),contains('Mercury'));
    expect(contact.nextOnRetrogradeArc?.name,'Moon');
    expect(contact.nextArcDegrees,closeTo(0.5,1e-8));
  });

  test('no exact contact still gives only a directional next marker', () {
    final contact=JamakolaSpecialService.kavippuJamaTouch(
      kavippuLongitude:0.1,
      jamaGrahas:const [
        JamaRingPosition('Moon',0.0),
        JamaRingPosition('Saturn',359.8),
        JamaRingPosition('Sun',20.0),
      ]);
    expect(contact.touchingNow,isEmpty);
    expect(contact.nextOnRetrogradeArc?.name,'Moon');
    expect(contact.nextArcDegrees,closeTo(0.1,1e-8));
  });

  test('geometric threshold does not claim sign-only contact', () {
    final result=JamakolaSpecialService.kavippuJamaTouch(
      kavippuLongitude:150.0,
      jamaGrahas:const [JamaRingPosition('Venus',159.0)],
      toleranceArcMinutes:1);
    expect(result.touchingNow,isEmpty);
  });

  test('nonfinite inputs are rejected', () {
    expect(()=>JamakolaSpecialService.kavippuJamaTouch(
      kavippuLongitude:double.nan,jamaGrahas:const []),throwsArgumentError);
  });
}
