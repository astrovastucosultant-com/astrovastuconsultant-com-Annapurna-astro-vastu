import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/multi_chart_topic_service.dart';
import 'package:astro_app/screens/topic_varga_review_panel.dart';
import 'package:astro_app/screens/unified_rule_result_tile.dart';

const _chart = AstroChartResult(
  julianDay: 2441542.0,
  ayanamsaDegrees: 23.0,
  ascendantLongitude: 75.0,
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 110, latitude: 0, speed: 0.9),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 160, latitude: 0, speed: 13),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 122, latitude: 0, speed: 0.5),
  ],
  engineVersion: 'widget-test',
);

void main() {
  testWidgets('source-selected vargas are available together and open chart evidence',
      (tester) async {
    const summary = MultiChartTopicEvidence(
      name: 'ప్రభుత్వ ఉద్యోగం',
      chartOrderSourceId: 'VARGA-CROSS-001',
      note: 'ఈ పరీక్షలో ఇది నిజజీవిత అంచనా కాదు',
      stages: [
        TopicStageEvidence(factor: 1, status: TopicStageStatus.matched,
          ruleIds: ['USER-GOV-5-9'], details: 'D1 5L/9L మ్యాచ్'),
        TopicStageEvidence(factor: 9, status: TopicStageStatus.insufficientEvidence,
          ruleIds: [], details: 'D9 పూర్తి పరీక్ష లేదు'),
        TopicStageEvidence(factor: 10, status: TopicStageStatus.notMatched,
          ruleIds: ['VARGA-CROSS-020'], details: 'D10 షరతు సరిపోలలేదు'),
      ],
    );
    await tester.pumpWidget(const MaterialApp(home: Scaffold(
      body: SingleChildScrollView(child: TopicVargaReviewPanel(chart: _chart, summary: summary)),
    )));
    expect(find.textContaining('పరిశీలించాల్సిన వర్గచక్రాలు'), findsOneWidget);
    expect(find.text('D1'), findsOneWidget);
    expect(find.text('D9'), findsOneWidget);
    expect(find.text('D10'), findsOneWidget);
    await tester.tap(find.textContaining('D9 — నవాంశ').first);
    await tester.pumpAndSettle();
    expect(find.textContaining('D9 పూర్తి పరీక్ష లేదు'), findsOneWidget);
    expect(find.textContaining('VARGA-CROSS-001'), findsWidgets);
  });

  testWidgets('business keeps optional D2/D7 only as unverified source charts',
      (tester) async {
    const summary = MultiChartTopicEvidence(
      name: 'వ్యాపారం', chartOrderSourceId: 'USER-CAREER-CORE-BUSINESS',
      note: 'D1, D9, D10 main stages only',
      stages: [
        TopicStageEvidence(factor: 1,
          status: TopicStageStatus.insufficientEvidence,
          ruleIds: [], details: 'No full matching conditions'),
        TopicStageEvidence(factor: 9,
          status: TopicStageStatus.insufficientEvidence,
          ruleIds: [], details: 'No full matching conditions'),
        TopicStageEvidence(factor: 10,
          status: TopicStageStatus.insufficientEvidence,
          ruleIds: [], details: 'No full matching conditions'),
      ],
    );
    expect(summary.totalStages, 3);
    expect(summary.matchedStages, 0);
    await tester.pumpWidget(const MaterialApp(home: Scaffold(
      body: SingleChildScrollView(child: TopicVargaReviewPanel(
        chart: _chart, summary: summary)),
    )));
    expect(find.textContaining('అదనపు మూల చక్రాలు'), findsOneWidget);
    await tester.ensureVisible(find.textContaining('అదనపు మూల చక్రాలు'));
    await tester.tap(find.textContaining('అదనపు మూల చక్రాలు'));
    await tester.pumpAndSettle();
    expect(find.textContaining('D2 — ధనార్జన'), findsOneWidget);
    expect(find.textContaining('D7 — ప్రత్యేక సందర్భాలు'), findsOneWidget);
    expect(find.textContaining('V.P. Goel'), findsOneWidget);
    expect(summary.matchedStages, 0);
  });

  testWidgets('unsupported source-only D6 is not shown as computed chart', (tester) async {
    const summary = MultiChartTopicEvidence(
      name: 'ఆరోగ్యం', chartOrderSourceId: 'VARGA-CROSS-007', note: '',
      stages: [TopicStageEvidence(factor: 6,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: [], details: 'D6 source stage pending')],
    );
    await tester.pumpWidget(const MaterialApp(home: Scaffold(
      body: TopicVargaReviewPanel(chart: _chart, summary: summary),
    )));
    expect(find.textContaining('D6 — చక్రం అందుబాటులో లేదు'), findsOneWidget);
    expect(find.textContaining('ఈ వర్గ గణన ఇంకా లేదు'), findsOneWidget);
  });

  testWidgets('source rule comes before examination and highlighted result', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Scaffold(
      body: SingleChildScrollView(child: UnifiedRuleResultTile(
        initiallyExpanded: true,
        data: RuleResultData(topic: 'ఆస్తి', result: 'శుభ సూచన',
          verdict: RuleVerdict.favourable, examination: 'D1/D4 ఆధారాలు',
          rule: '4L ...', source: 'Book page 10', ruleMatched: true),
      )),
    )));
    final first = tester.getTopLeft(find.text('రూల్ / మూల నియమం')).dy;
    final second = tester.getTopLeft(find.text('జాతక పరిశీలన')).dy;
    final third = tester.getTopLeft(find.text('ఫలితం')).dy;
    expect(first < second && second < third, true);
    expect(find.text('శుభ సూచన'), findsOneWidget);
  });
}
