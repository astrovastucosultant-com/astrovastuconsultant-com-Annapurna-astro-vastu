import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_topic_catalog.dart';

void main() {
  test('Every available varga has a nonempty categorized topic list', () {
    final factors = VargaService.definitions.map((x) => x.factor).toSet();
    expect(factors.length, 19);
    for (final factor in factors) {
      final topics = VargaTopicCatalog.forFactor(factor);
      expect(topics.length, greaterThanOrEqualTo(5),
          reason: 'D$factor should have a practical index');
      expect(topics.map((x) => x.title).toSet().length, topics.length,
          reason: 'D$factor cannot repeat a topic title');
      for (final topic in topics) {
        expect(topic.house, inInclusiveRange(1, 12));
        expect(topic.matchWords, isNotEmpty);
        expect(topic.matchWords.every((w) => w.trim().isNotEmpty), isTrue);
      }
    }
  });

  test('D10 has all career decision sections inside one topic catalog', () {
    final names = VargaTopicCatalog.forFactor(10).map((x) => x.title).join(' ');
    for (final required in ['గోచరిష్ట', 'అగోచరిష్ట', 'ప్రభుత్వ',
        'ఉన్నత పదవి', 'ఎదుగుదల', 'పతనం', 'బదిలీ',
        'విదేశీ', 'భాగస్వామ్య', 'పదవీ విరమణ', 'PAV']) {
      expect(names, contains(required));
    }
  });

  test('D5, D6, D8 remain present as additional vargas', () {
    for (final f in [5, 6, 8]) {
      expect(VargaTopicCatalog.forFactor(f), isNotEmpty);
      expect(VargaTopicCatalog.topicSource(f), contains('విషయసూచిక'));
    }
  });
}
