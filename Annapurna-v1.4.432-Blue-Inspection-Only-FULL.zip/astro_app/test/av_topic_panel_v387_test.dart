import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/ashtakavarga_service.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/screens/av_topic_panel_v387.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 3,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 10.0,
        'Moon': 42.0,
        'Mars': 75.0,
        'Mercury': 108.0,
        'Jupiter': 141.0,
        'Venus': 174.0,
        'Saturn': 207.0,
        'Rahu': 240.0,
        'Ketu': 60.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final birth = BirthData(
    name: 'fixture',
    localDateTime: DateTime(2000, 1, 1),
    place: 'fixture',
    latitude: 16,
    longitude: 80,
    timezoneOffsetHours: 5.5,
    ayanamsa: AyanamsaType.lahiri,
  );
  final av = AshtakavargaService.calculate(chart);
  Future<void> show(
    WidgetTester tester,
    Future<AstroChartResult> Function(BirthData) loader,
  ) => tester.pumpWidget(
    MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: AvTopicPanel387(
            chart: chart,
            av: av,
            birth: birth,
            transitLoader: loader,
            asOf: DateTime(2026, 11, 13),
          ),
        ),
      ),
    ),
  );

  testWidgets('one selected result, exact source and no pending verdict', (
    tester,
  ) async {
    final pending = Completer<AstroChartResult>();
    await show(tester, (_) => pending.future);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('av-result-wealth')), findsOneWidget);
    expect(find.textContaining('నిర్ధారించలేదు'), findsNothing);
    await tester.tap(find.byKey(const ValueKey('av-result-wealth')));
    await tester.pumpAndSettle();
    expect(find.textContaining('PD-24-37'), findsWidgets);
    expect(find.text('సంపద యోగం — PD-24-38'), findsOneWidget);
    expect(find.text('పరిహారం'), findsOneWidget);
    await tester.ensureVisible(
      find.byKey(const ValueKey('av-topic-picker-387')),
    );
    await tester.tap(find.byKey(const ValueKey('av-topic-picker-387')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('విద్య / ఉన్నత విద్య').last);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('av-result-wealth')), findsNothing);
    expect(find.byKey(const ValueKey('av-result-education')), findsOneWidget);
    expect(find.text('సంపద యోగం — PD-24-38'), findsNothing);
    pending.complete(chart);
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('failed transit does not hide result and can retry', (
    tester,
  ) async {
    var calls = 0;
    Future<AstroChartResult> loader(BirthData _) async {
      calls++;
      if (calls == 1) throw StateError('fixture-offline');
      return chart;
    }

    await show(tester, loader);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('av-result-wealth')), findsOneWidget);
    final tile = find.byKey(const ValueKey('av-transit-wealth'));
    await tester.ensureVisible(tile);
    await tester.tap(tile);
    await tester.pumpAndSettle();
    expect(find.text('గోచార గణన అందుబాటులో లేదు.'), findsOneWidget);
    final retry = find.byKey(const ValueKey('av-transit-retry-387'));
    await tester.ensureVisible(retry);
    await tester.pumpAndSettle();
    expect(retry.hitTestable(), findsOneWidget);
    await tester.tap(retry);
    await tester.pumpAndSettle();
    await tester.pumpAndSettle();
    expect(calls, 2);
    expect(find.text('గోచార గణన అందుబాటులో లేదు.'), findsNothing);
    expect(find.textContaining('కక్ష్య'), findsWidgets);
    expect(tester.takeException(), isNull);
  });
}
