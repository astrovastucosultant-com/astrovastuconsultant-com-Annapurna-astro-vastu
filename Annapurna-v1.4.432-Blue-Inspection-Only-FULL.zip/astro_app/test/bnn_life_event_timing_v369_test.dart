import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_cycle_result_service.dart';
import 'package:astro_app/astrology/bnn_jupiter_cycle_service.dart';
import 'package:astro_app/astrology/bnn_saturn_cycle_service.dart';
import 'package:astro_app/astrology/bnn_life_event_timing_service.dart';

void main(){
  TestWidgetsFlutterBinding.ensureInitialized();
  PlanetPosition planet(String name,int sign,double degree)=>PlanetPosition(
    name:name,shortName:name,longitude:sign*30.0+degree,
    latitude:0,speed:1,
  );
  AstroChartResult chart(List<PlanetPosition> list)=>AstroChartResult(
    julianDay:2460000,ayanamsaDegrees:24,
    ascendantLongitude:78.5,planets:list,engineVersion:'v369-test',
  );

  test('all life event IDs unique; review metadata is not a rule claim',() async {
    final items=await BnnLifeEventTimingService.loadCatalog();
    expect(items.length,29);
    expect(items.map((e)=>e.id).toSet().length,29);
    expect(items.every((e)=>e.sourceStatus=='METHOD_ONLY'),isTrue);
    expect(items.where((e)=>e.reviewOnly).length,5);
    expect(items.any((e)=>e.id=='CHILD-EDU'),isTrue);
    expect(items.any((e)=>e.id=='MARRIAGE'),isTrue);
    expect(items.any((e)=>e.id=='GRANDPARENTS'),isTrue);
    expect(items.any((e)=>e.id=='FOREIGN-JOB'),isTrue);
  });

  test('Jupiter/Saturn candidate intersection is an age interval, not event',() async {
    final c=chart([planet('Jupiter',0,1),planet('Saturn',0,8),
      planet('Rahu',0,12),planet('Mercury',0,17),planet('Sun',0,3)]);
    final reviews=await BnnLifeEventTimingService.build(chart:c,maximumAge:60);
    final career=reviews.firstWhere((r)=>r.event.id=='CAREER-ENTRY');
    expect(career.candidates,isNotEmpty);
    final example=career.candidates.firstWhere((c)=>
      c.jupiterCalculationId=='BNN-JUP-C01-AGE000' &&
      c.saturnCalculationId=='BNN-SAT-C01-S01');
    expect(example.ageFrom,0);
    expect(example.ageTo,1);
    expect(example.jupiterContacts,contains('Rahu'));
    expect(example.saturnContacts,contains('Rahu'));
    expect(example.sourceRuleIds,contains('BNN-SAT-R1-RAHU'));
    expect(career.hasVerifiedIndividualEventTiming,isFalse);
    final marriage=reviews.firstWhere((r)=>r.event.id=='MARRIAGE');
    expect(marriage.candidates.every((x)=>x.sourceRuleIds.isEmpty),isTrue);
  });

  test('sensitive domains withhold age candidates, even with natal contacts',() async {
    final c=chart([planet('Jupiter',0,2),planet('Saturn',0,8),
      planet('Moon',0,9),planet('Mars',0,11),planet('Sun',0,13)]);
    final reviews=await BnnLifeEventTimingService.build(chart:c);
    for(final name in ['LONGEVITY','ACCIDENT','RELATIVE-BEREAVEMENT','HEALTH-ADULT']){
      final r=reviews.singleWhere((r)=>r.event.id==name);
      expect(r.datesWithheldForSafety,isTrue);
      expect(r.candidates,isEmpty);
    }
  });

  test('no natal Jupiter or Saturn means no invented timing candidate',() async {
    final c=chart([planet('Sun',1,3),planet('Venus',2,12)]);
    final reviews=await BnnLifeEventTimingService.build(chart:c);
    expect(reviews.every((r)=>r.candidates.isEmpty),isTrue);
  });

  test('source guard requires matched Saturn first round and Rahu',() async {
    final items=await BnnLifeEventTimingService.loadCatalog();
    final source=await BnnCycleResultService.load();
    final emptyJ=await BnnJupiterCycleService.loadThemes();
    final emptyS=await BnnSaturnCycleService.loadThemes();
    final c=chart([planet('Jupiter',0,1),planet('Saturn',0,2),
      planet('Rahu',0,3)]);
    final result=BnnLifeEventTimingService.evaluate(chart:c,events:items,
      jupiterCycles:BnnJupiterCycleService.calculate(chart:c,themes:emptyJ),
      saturnCycles:BnnSaturnCycleService.calculate(chart:c,themes:emptyS),
      sourceCatalog:BnnCycleResultCatalog(contacts:source.contacts,sourceRules:[]),
      maximumAge:50);
    expect(result.firstWhere((r)=>r.event.id=='CAREER-ENTRY').candidates
      .every((x)=>x.sourceRuleIds.isEmpty),isTrue);
  });
}
