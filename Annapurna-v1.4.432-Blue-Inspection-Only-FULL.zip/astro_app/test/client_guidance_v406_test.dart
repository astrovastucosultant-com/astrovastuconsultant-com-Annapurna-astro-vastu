import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/screens/topic_result_card_v398.dart';
import '../lib/screens/topic_varga_review_panel.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 63,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.4,
        'Moon': 115.1,
        'Mars': 156.2,
        'Mercury': 242.6,
        'Jupiter': 189.8,
        'Venus': 280.3,
        'Saturn': 176.7,
        'Rahu': 75.5,
        'Ketu': 255.5,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final topics = MultiChartTopicService.summarize(
    chart: chart,
    evaluatedRules: [],
  );
  for (final id in ['VARGA-CROSS-007', 'VARGA-CROSS-005']) {
    final summary = topics.singleWhere((s) => s.chartOrderSourceId == id);
    testWidgets(
      '$id priority guidance precedes original result and opens trace',
      (tester) async {
        tester.view.physicalSize = const Size(900, 1800);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: SingleChildScrollView(
                child: TopicVargaReviewPanel(chart: chart, summary: summary),
              ),
            ),
          ),
        );
        expect(summary.supplement!.clientGuidance, isNotNull);
        final guide = find.byKey(ValueKey('client-guidance-406-$id'));
        expect(guide, findsOneWidget);
        final conclusion = find.text(summary.supplement!.conclusion);
        expect(
          tester.getTopLeft(guide).dy,
          lessThan(tester.getTopLeft(conclusion).dy),
        );
        expect(summary.stages.every((s) => s.deitySummary.isNotEmpty), isTrue);
        await tester.tap(find.byKey(ValueKey('topic-result-398-$id')));
        await tester.pumpAndSettle();
        expect(find.text('వర్తించిన నియమాలు / జాతక పరిశీలన'), findsOneWidget);
        expect(find.text('మూలాలు'), findsOneWidget);
        expect(tester.takeException(), isNull);
      },
    );
    testWidgets('$id large Telugu text wraps at mobile width', (tester) async {
      tester.view.physicalSize = const Size(320, 1800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(
        MaterialApp(
          home: MediaQuery(
            data: const MediaQueryData(textScaler: TextScaler.linear(1.8)),
            child: Scaffold(
              body: SingleChildScrollView(
                child: TopicResultCard398(report: summary.supplement!),
              ),
            ),
          ),
        ),
      );
      expect(find.textContaining('ప్రధాన ఆరాధనా సూచన:'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }
}
