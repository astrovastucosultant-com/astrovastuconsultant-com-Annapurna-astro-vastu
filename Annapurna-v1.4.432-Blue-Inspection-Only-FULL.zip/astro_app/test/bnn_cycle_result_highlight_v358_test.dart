import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_cycle_result_service.dart';
import 'package:astro_app/screens/bnn_cycle_result_card.dart';

void main() {
  BnnCycleReading reading({required String tone,required bool source}) =>
    BnnCycleReading(id:'TEST-001',label:'గ్రహం',result:'వృత్తిలో అభివృద్ధి',
      ifText:'గ్రహం ఒక రాశిని తాకితే',source:'మూల గ్రంథం',page:'పేజీ 1',
      isSourceRule:source,tone:tone);

  test('Favorable source rule is green, negative source is red',() {
    final positive=BnnCycleResultCard.toneFor(
      reading(tone:'favorable',source:true));
    final negative=BnnCycleResultCard.toneFor(
      reading(tone:'unfavorable',source:true));
    expect(positive,BnnCycleResultTone.favorable);
    expect(negative,BnnCycleResultTone.unfavorable);
    expect(BnnCycleResultCard.backgroundFor(positive),const Color(0xFFDFF4E5));
    expect(BnnCycleResultCard.backgroundFor(negative),const Color(0xFFFDE8E8));
  });

  test('Karakatwa topic never becomes a green or red event claim',() {
    for (final tone in ['favorable','unfavorable','neutral','unknown']) {
      expect(BnnCycleResultCard.toneFor(reading(tone:tone,source:false)),
        BnnCycleResultTone.neutral);
    }
    expect(BnnCycleResultCard.toneFor(
      reading(tone:'unspecified',source:true)),BnnCycleResultTone.neutral);
  });

  testWidgets('Result first, tap shows IF, chart inspection and source',(tester) async {
    await tester.pumpWidget(MaterialApp(home:Scaffold(body:ListView(children:[
      BnnCycleResultCard(reading:reading(tone:'favorable',source:true),
        inspection:'గురు 1వ సైకిల్ • వయస్సు 10–11'),
    ]))));
    expect(find.text('వృత్తిలో అభివృద్ధి'),findsOneWidget);
    await tester.tap(find.text('వృత్తిలో అభివృద్ధి'));
    await tester.pumpAndSettle();
    expect(find.text('1. రూల్ — TEST-001'),findsOneWidget);
    expect(find.textContaining('గురు 1వ సైకిల్'),findsOneWidget);
    expect(find.textContaining('మూల గ్రంథం'),findsOneWidget);
  });
}
