import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_jupiter_cycle_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const chart=AstroChartResult(
    julianDay:2460000,ayanamsaDegrees:24,ascendantLongitude:78.8,
    engineVersion:'bnn-cycle-v355',planets:[
      PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245.25,latitude:0,speed:-1), // Sagittarius
      PlanetPosition(name:'Saturn',shortName:'Sa',longitude:54.89,latitude:0,speed:1), // Taurus
      PlanetPosition(name:'Venus',shortName:'Ve',longitude:71.87,latitude:0,speed:1), // Gemini
      PlanetPosition(name:'Rahu',shortName:'Ra',longitude:272.3,latitude:0,speed:-1), // Capricorn
      PlanetPosition(name:'Moon',shortName:'Mo',longitude:160.78,latitude:0,speed:1), // Virgo
    ]);

  test('12 rounds * 12 years = 144 unique calculation rows', () async {
    final themes=await BnnJupiterCycleService.loadThemes();
    final rounds=BnnJupiterCycleService.calculate(chart:chart,themes:themes);
    expect(themes.length,12);
    expect(rounds.length,12);
    expect(rounds.expand((x)=>x.years).length,144);
    expect(rounds.first.years.first.ageStart,0);
    expect(rounds.last.years.last.ageStart,143);
    expect(rounds.first.years.first.progressedSignIndex,8); // natal Sagittarius
    expect(rounds[1].years.first.progressedSignIndex,8); // repeats next cycle
    expect(rounds[1].years.first.ageStart,12);
    expect(rounds.expand((x)=>x.years).map((x)=>x.calculationId).toSet().length,144);
  });
  test('Venus seventh sign from natal Jupiter contacted once per round',() async {
    final themes=await BnnJupiterCycleService.loadThemes();
    final cycles=BnnJupiterCycleService.calculate(chart:chart,themes:themes);
    final venusStarts=[for (final cycle in cycles)
      for (final year in cycle.years)
        if (year.natalSignContacts.any((p)=>p.name=='Venus')) year.ageStart];
    expect(venusStarts,[6,18,30,42,54,66,78,90,102,114,126,138]);
  });
  test('Saturn sixth sign relative to natal Jupiter contact repeats every 12',() async {
    final cycles=BnnJupiterCycleService.calculate(chart:chart,
      themes:await BnnJupiterCycleService.loadThemes());
    final ages=[for (final cycle in cycles)
      for (final year in cycle.years)
        if (year.natalSignContacts.any((p)=>p.name=='Saturn')) year.ageStart];
    expect(ages,[5,17,29,41,53,65,77,89,101,113,125,137]);
  });
  test('Theoretical 7-12 rounds have no fabricated topic results',() async {
    final themes=await BnnJupiterCycleService.loadThemes();
    expect(themes.take(6).every((x)=>x.traditionalFocus!=null),isTrue);
    expect(themes.skip(6).every((x)=>x.traditionalFocus==null),isTrue);
  });
  test('Missing natal Jupiter produces no timeline and no fabricated output',() async {
    const missing=AstroChartResult(julianDay:2460000,ayanamsaDegrees:24,
      ascendantLongitude:78.8,engineVersion:'missing',planets:[
        PlanetPosition(name:'Mars',shortName:'Ma',longitude:123,latitude:0,speed:1)]);
    final cycles=BnnJupiterCycleService.calculate(chart:missing,
      themes:await BnnJupiterCycleService.loadThemes());
    expect(cycles,isEmpty);
  });
}
