import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_house_relation_service.dart';

void main() {
  test('all 9 BNN grahas receive Lagna/Jupiter whole-sign positions', () {
    const chart=AstroChartResult(
      julianDay:2460000,ayanamsaDegrees:24,
      ascendantLongitude:60, engineVersion:'BNN-house-test',
      planets:[
        PlanetPosition(name:'Sun',shortName:'Su',longitude:116,latitude:0,speed:1),
        PlanetPosition(name:'Moon',shortName:'Mo',longitude:160,latitude:0,speed:1),
        PlanetPosition(name:'Mars',shortName:'Ma',longitude:125,latitude:0,speed:1),
        PlanetPosition(name:'Mercury',shortName:'Me',longitude:115,latitude:0,speed:-1),
        PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245,latitude:0,speed:-1),
        PlanetPosition(name:'Venus',shortName:'Ve',longitude:71,latitude:0,speed:1),
        PlanetPosition(name:'Saturn',shortName:'Sa',longitude:55,latitude:0,speed:1),
        PlanetPosition(name:'Rahu',shortName:'Ra',longitude:275,latitude:0,speed:-1),
        PlanetPosition(name:'Ketu',shortName:'Ke',longitude:95,latitude:0,speed:-1),
      ],
    );
    final positions=BnnHouseRelationService.positions(chart);
    expect(positions.length,9);
    final sat=positions.firstWhere((p)=>p.name=='Saturn');
    expect(sat.lagnaHouse,12);
    expect(sat.jupiterHouse,6);
    final ju=positions.firstWhere((p)=>p.name=='Jupiter');
    expect(ju.lagnaHouse,7);
    expect(ju.jupiterHouse,1);
    final rahu=positions.firstWhere((p)=>p.name=='Rahu');
    expect(rahu.lagnaHouse,8);
    expect(rahu.jupiterHouse,2);
    expect(BnnHouseRelationService.houseFrom(originSign:11,targetSign:0),2);
  });

  test('source-verified Jupiter-relative rules match exclusively by house', () {
    const chart=AstroChartResult(
      julianDay:2460000,ayanamsaDegrees:24,
      ascendantLongitude:0,engineVersion:'BNN-relative-test',
      planets:[
        PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:0,latitude:0,speed:0.2),
        PlanetPosition(name:'Mercury',shortName:'Me',longitude:30,latitude:0,speed:1),
        PlanetPosition(name:'Venus',shortName:'Ve',longitude:30,latitude:0,speed:1),
        PlanetPosition(name:'Moon',shortName:'Mo',longitude:180,latitude:0,speed:1),
        PlanetPosition(name:'Mars',shortName:'Ma',longitude:330,latitude:0,speed:1),
        PlanetPosition(name:'Ketu',shortName:'Ke',longitude:330,latitude:0,speed:-1),
        PlanetPosition(name:'Rahu',shortName:'Ra',longitude:60,latitude:0,speed:-1),
      ],
    );
    final rules=[
      const BnnJupiterRelativeRule(id:'C17',sourceId:'C17',target:'Mercury',
        jupiterHouse:2,originalIf:'IF',originalThen:'తెలివి',tone:'favorable',
        sourceFile:'source.pdf',pdfPage:3),
      const BnnJupiterRelativeRule(id:'C09',sourceId:'C09',target:'Mars',
        jupiterHouse:12,originalIf:'IF',originalThen:'ఒక అన్న',tone:'neutral',
        sourceFile:'source.pdf',pdfPage:3),
      const BnnJupiterRelativeRule(id:'FALSE',sourceId:'FALSE',target:'Saturn',
        jupiterHouse:5,originalIf:'IF',originalThen:'None',tone:'neutral',
        sourceFile:'source.pdf',pdfPage:3),
    ];
    final matches=BnnHouseRelationService.evaluateVerifiedJupiterRules(
      chart:chart,rules:rules);
    expect(matches.map((v)=>v.rule.id).toList(),['C17','C09']);
    expect(matches.first.rule.originalThen,'తెలివి');
  });
}
