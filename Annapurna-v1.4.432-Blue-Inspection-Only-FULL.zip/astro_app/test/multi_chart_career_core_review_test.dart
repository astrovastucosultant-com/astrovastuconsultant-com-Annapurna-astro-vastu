import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/multi_chart_topic_service.dart';

AstroChartResult _chart({bool withSaturn = true}) => AstroChartResult(
  julianDay: 2450000,
  ayanamsaDegrees: 24,
  ascendantLongitude: 5,
  engineVersion: 'career-test',
  planets: [
    const PlanetPosition(name: 'Sun', shortName: 'Su',
      longitude: 245, latitude: 0, speed: 0.8),
    const PlanetPosition(name: 'Jupiter', shortName: 'Ju',
      longitude: 45, latitude: 0, speed: 0.1),
    if (withSaturn)
      const PlanetPosition(name: 'Saturn', shortName: 'Sa',
        longitude: 300, latitude: 0, speed: 0.05),
    const PlanetPosition(name: 'Rahu', shortName: 'Ra',
      longitude: 10, latitude: 0, speed: -0.1),
    const PlanetPosition(name: 'Ketu', shortName: 'Ke',
      longitude: 190, latitude: 0, speed: -0.1),
  ],
);

void main() {
  test('both business and job use D1-D9-D10, not D2/D7 in the primary panel', () {
    final topics = MultiChartTopicService.summarize(
      chart: _chart(), evaluatedRules: const []);
    expect(topics.length, 17);
    expect(topics[0].name, 'వ్యాపారం');
    expect(topics[1].name, contains('ఉద్యోగం'));
    for (final topic in topics.take(2)) {
      expect(topic.stages.map((s) => s.factor).toList(), [1, 9, 10]);
      expect(topic.chartOrderSourceId, startsWith('USER-CAREER-CORE'));
      expect(topic.stages.map((s) => s.ruleText)
          .every((s) => s.contains('శని')), isTrue);
      expect(topic.stages.map((s) => s.source)
          .every((s) => s.contains('D10 special.pdf')), isTrue);
    }
    expect(topics[0].note, contains('VARGA-CROSS-003'));
    expect(topics[0].note, contains('D7'));
    expect(topics[2].stages.map((s) => s.factor).toList(), [1, 9, 10]);
    expect(topics.firstWhere((t) => t.name == 'సంతానం')
        .stages.map((s) => s.factor).toList(), [1, 7, 9]);
  });

  test('no Saturn means pending for all career stages, never a false conclusion', () {
    final topics = MultiChartTopicService.summarize(
      chart: _chart(withSaturn: false), evaluatedRules: const []);
    for (final topic in topics.take(2)) {
      expect(topic.stages.every((s) =>
          s.status == TopicStageStatus.insufficientEvidence), isTrue);
      expect(topic.stages.every((s) => s.result.isEmpty), isTrue);
      expect(topic.confirmationPercent, isNull);
    }
  });

  test('career mode stage is evidence only, not an employment guarantee', () {
    final topics = MultiChartTopicService.summarize(
      chart: _chart(), evaluatedRules: const []);
    for (final topic in topics.take(2)) {
      for (final stage in topic.stages) {
        if (stage.status == TopicStageStatus.matched) {
          expect(stage.result, contains('మద్దతు'));
          expect(stage.ruleIds.any((id) => id.startsWith('D10-')), isTrue);
        } else {
          expect(stage.result, isEmpty);
        }
      }
    }
  });

  test('government support IF and its own result are not discarded', () {
    final topics = MultiChartTopicService.summarize(
      chart: _chart(), evaluatedRules: const []);
    final gov = topics.firstWhere((t) => t.name == 'ప్రభుత్వ ఉద్యోగం');
    final d1 = gov.stages.first;
    expect(d1.ruleText, contains('USER-GOV-5-9'));
    if (d1.status == TopicStageStatus.matched) {
      expect(d1.result, contains('సపోర్ట్ చెక్ మ్యాచ్'));
    }
  });
}
