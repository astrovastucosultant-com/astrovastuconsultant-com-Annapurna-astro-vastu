import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/screens/unified_rule_result_tile.dart';

void main() {
  testWidgets('D2–D60 IF–THEN tiles show rule, examination, result, remedy status',
      (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: SingleChildScrollView(child: UnifiedRuleResultTile(
        data: RuleResultData(
          topic: 'సంతాన యోగం',
          ruleId: 'D7-PROVEN-001',
          verdict: RuleVerdict.favourable,
          ruleMatched: true,
          rule: 'IF జాతక మూల షరతులు పూర్తిగా సరిపోతే',
          examination: 'D7 జాతక పరిశీలన',
          result: 'సంతాన సహాయక సూచన',
          source: 'పరీక్ష మూలం',
        ),
        showRemedyStatus: true,
      ))),
    ));
    await tester.tap(find.text('సంతాన యోగం'));
    await tester.pumpAndSettle();
    for (final heading in ['రూల్ / మూల నియమం', 'జాతక పరిశీలన', 'ఫలితం',
        'మూలాధారిత పరిహారం']) {
      expect(find.text(heading), findsOneWidget, reason: heading);
    }
    expect(find.text('సంతాన సహాయక సూచన'), findsOneWidget);
    expect(find.textContaining('పరిహారం కల్పించలేదు'), findsOneWidget);
  });

  testWidgets('pending evidence cannot become green/pink final outcome',
      (tester) async {
    await tester.pumpWidget(const MaterialApp(home: Scaffold(
      body: SingleChildScrollView(child: UnifiedRuleResultTile(
        data: RuleResultData(
          topic: 'D24 విద్యా అంశం',
          verdict: RuleVerdict.favourable,
          ruleMatched: null,
          rule: 'IF మూల పరిశీలనలో పూర్తి ఆధారాలు ఉన్నప్పుడు',
          examination: 'మూలం పెండింగ్',
          result: 'ఈ ఫలితం నిజంగా నిర్ధారించబడలేదు',
        ),
        showRemedyStatus: true,
      )),
    )));
    await tester.tap(find.text('D24 విద్యా అంశం'));
    await tester.pumpAndSettle();
    expect(find.text('ఈ ఫలితం నిజంగా నిర్ధారించబడలేదు'), findsNothing);
    expect(find.textContaining('ఫలితం నిర్ధారించలేదు'), findsOneWidget);
  });
}
