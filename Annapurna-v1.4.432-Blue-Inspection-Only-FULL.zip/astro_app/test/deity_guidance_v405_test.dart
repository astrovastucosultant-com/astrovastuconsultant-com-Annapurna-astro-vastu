import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/screens/topic_varga_review_panel.dart';
import '../lib/screens/deity_summary_v405.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 63,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.4,
        'Moon': 115.1,
        'Mars': 156.2,
        'Mercury': 242.6,
        'Jupiter': 189.8,
        'Venus': 280.3,
        'Saturn': 176.7,
        'Rahu': 75.5,
        'Ketu': 255.5,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  testWidgets(
    'four chart deity summaries display with source-inspection cards',
    (tester) async {
      tester.view.physicalSize = const Size(900, 1800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final summary = MultiChartTopicService.summarize(
        chart: chart,
        evaluatedRules: [],
      ).singleWhere((t) => t.chartOrderSourceId == 'VARGA-CROSS-013');
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: summary),
            ),
          ),
        ),
      );
      for (final f in [1, 9, 20, 24]) {
        expect(find.byKey(ValueKey('deity-summary-405-$f')), findsOneWidget);
      }
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('deity names wrap on narrow large-text mobile', (tester) async {
    tester.view.physicalSize = const Size(320, 1800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      const MaterialApp(
        home: MediaQuery(
          data: MediaQueryData(textScaler: TextScaler.linear(1.8)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: DeitySummary405(
                factor: 20,
                text:
                    'సాధన / ఉపాసన కోసం దేవత సూచన: హయగ్రీవుడు / విష్ణువు / పరమేశ్వరుడు / దత్తాత్రేయుడు / గురు స్వరూపం. ఆధారం: D20 లగ్నాధిపతి Jupiter.',
              ),
            ),
          ),
        ),
      ),
    );
    expect(find.textContaining('దత్తాత్రేయుడు'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
