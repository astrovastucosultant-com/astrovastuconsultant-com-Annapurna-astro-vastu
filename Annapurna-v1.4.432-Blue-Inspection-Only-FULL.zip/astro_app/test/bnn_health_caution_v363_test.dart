import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_sensitive_result_display.dart';

void main() {
  test('sensitive risk is shown only as a caution', () {
    expect(BnnSensitiveResultDisplay.publicResult('మరణ సూచన'),
      BnnSensitiveResultDisplay.mortalityCaution);
    expect(BnnSensitiveResultDisplay.publicResult('తీవ్ర అనారోగ్యం'),
      BnnSensitiveResultDisplay.caution);
    expect(BnnSensitiveResultDisplay.publicResult('ఆరోగ్య సమస్య సూచన'),
      BnnSensitiveResultDisplay.caution);
    expect(BnnSensitiveResultDisplay.publicResult('health risk'),
      BnnSensitiveResultDisplay.caution);
  });
  test('ordinary favorable indications are preserved', () {
    const good='ఆరోగ్యం మెరుగుపడే సూచన';
    expect(BnnSensitiveResultDisplay.publicResult(good),good);
    const profession='వృత్తి అభివృద్ధి';
    expect(BnnSensitiveResultDisplay.publicResult(profession),profession);
  });
}
