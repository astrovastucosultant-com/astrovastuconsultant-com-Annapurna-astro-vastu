import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/astrology/education_result_v395.dart';
import '../lib/screens/topic_varga_review_panel.dart';
import '../lib/screens/topic_result_card_v391.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 63,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.0,
        'Moon': 115.1369,
        'Mars': 156.1172,
        'Mercury': 242.4142,
        'Jupiter': 189.8097,
        'Venus': 280.4494,
        'Saturn': 176.7767,
        'Rahu': 75.0,
        'Ketu': 255.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final summaries = MultiChartTopicService.summarize(
    chart: chart,
    evaluatedRules: [],
  );
  final education = summaries.singleWhere((s) => s.name == 'విద్య');
  test('education returns real assessments, not source workflow pending', () {
    expect(education.education, isNotNull);
    expect(education.stages.map((s) => s.factor), [1, 4, 24, 9]);
    expect(
      education.stages.every((s) => s.status == TopicStageStatus.matched),
      isTrue,
    );
    expect(
      education.stages.every((s) => s.result.startsWith('విద్య — ')),
      isTrue,
    );
    expect(
      education.stages.every(
        (s) => s.ruleText.isNotEmpty && s.source.isNotEmpty,
      ),
      isTrue,
    );
    expect(
      education.confirmationPercent,
      isNull,
      reason: 'an assessment is never 100% source/event confirmation',
    );
    expect(education.displayCoverage.contains('పెండింగ్'), isFalse);
    expect(
      education.stages.singleWhere((s) => s.factor == 24).ruleIds,
      contains('D24-VIDYA-CORE-05'),
    );
    expect(
      education.stages.singleWhere((s) => s.factor == 9).ruleIds,
      contains('EDU-D9-PK-SUPPORT'),
    );
    expect(summaries.singleWhere((s) => s.name == 'సంతానం').education, isNull);
    expect(
      summaries.singleWhere((s) => s.name == 'ఉద్యోగం / సర్వీస్').education,
      isNull,
    );
  });
  testWidgets('education result and rule inspection work on mobile', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(390, 844));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: TopicVargaReviewPanel(chart: chart, summary: education),
          ),
        ),
      ),
    );
    expect(find.byKey(const ValueKey('education-result-v395')), findsOneWidget);
    expect(
      find.text('పూర్తి రూల్ ధృవీకరణ లేదు — ఫలితం ప్రకటించలేదు.'),
      findsNothing,
    );
    await tester.tap(find.byKey(const ValueKey('education-inspect-v395')));
    await tester.pumpAndSettle();
    expect(find.text('విద్యా దశలు — మీ మాస్టర్ క్రమం'), findsOneWidget);
    final sheetList = find
        .descendant(
          of: find.byType(BottomSheet),
          matching: find.byType(ListView),
        )
        .first;
    await tester.drag(sheetList, const Offset(0, -500));
    await tester.pumpAndSettle();
    expect(find.text('సమగ్ర ఫలితం ఎలా ఇచ్చాం'), findsOneWidget);
    expect(
      find.textContaining('EDU-D24-018 / USER-EDU-FIELD-395'),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
  testWidgets('root result tap opens education assessment', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: TopicResultCard391(chart: chart, summary: education),
        ),
      ),
    );
    expect(
      find.textContaining('విద్య — ${education.education!.grade.label}'),
      findsOneWidget,
    );
    await tester.tap(
      find.byKey(const ValueKey('topic-result-VARGA-CROSS-006')),
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('education-result-v395')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('large Telugu text remains scrollable', (tester) async {
    await tester.binding.setSurfaceSize(const Size(360, 800));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(1.8)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: education),
            ),
          ),
        ),
      ),
    );
    expect(tester.takeException(), isNull);
  });
}
