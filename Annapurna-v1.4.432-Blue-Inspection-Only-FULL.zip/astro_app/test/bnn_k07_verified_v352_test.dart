import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_house_relation_service.dart';

const _chart=AstroChartResult(
  julianDay:2460000,ayanamsaDegrees:24,
  ascendantLongitude:78.7997,engineVersion:'BNN-v352-fixture',
  planets:[
    PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245.25,latitude:0,speed:-1),
    PlanetPosition(name:'Rahu',shortName:'Ra',longitude:272.34,latitude:0,speed:-1),
    PlanetPosition(name:'Ketu',shortName:'Ke',longitude:92.34,latitude:0,speed:-1),
    PlanetPosition(name:'Sun',shortName:'Su',longitude:116.7655,latitude:0,speed:1),
  ],
);
void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('source-checked K07 Jupiter-Rahu 2nd triggers on actual match',() async {
    final rules=await BnnHouseRelationService.loadVerifiedJupiterRules();
    expect(rules.length,9);
    final k07=rules.singleWhere((r)=>r.sourceId=='K07');
    expect(k07.target,'Rahu');
    expect(k07.jupiterHouse,2);
    expect(k07.pdfPage,16);
    final matches=BnnHouseRelationService.evaluateVerifiedJupiterRules(
      chart:_chart,rules:rules);
    expect(matches.map((m)=>m.rule.sourceId),contains('K07'));
    expect(matches.any((m)=>m.rule.sourceId=='C22'),false);
  });
  test('a different Rahu position must not trigger K07',() async {
    final rules=await BnnHouseRelationService.loadVerifiedJupiterRules();
    const chart=AstroChartResult(
      julianDay:2460000,ayanamsaDegrees:24,ascendantLongitude:78.7997,
      engineVersion:'BNN-v352-negative',planets:[
        PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245.25,latitude:0,speed:-1),
        PlanetPosition(name:'Rahu',shortName:'Ra',longitude:301.0,latitude:0,speed:-1),
      ]);
    final matches=BnnHouseRelationService.evaluateVerifiedJupiterRules(
      chart:chart,rules:rules);
    expect(matches.any((m)=>m.rule.sourceId=='K07'),false);
  });
}
