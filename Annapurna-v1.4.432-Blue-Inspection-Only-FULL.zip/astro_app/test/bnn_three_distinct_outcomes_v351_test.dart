import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_house_relation_service.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/screens/bnn_master_panel.dart';

const _chart=AstroChartResult(
  julianDay:2460000,ayanamsaDegrees:24,
  ascendantLongitude:78.7997,engineVersion:'BNN-v351-fixture',
  planets:[
    PlanetPosition(name:'Sun',shortName:'Su',longitude:116.7655,latitude:0,speed:1),
    PlanetPosition(name:'Moon',shortName:'Mo',longitude:160.7786,latitude:0,speed:1),
    PlanetPosition(name:'Mars',shortName:'Ma',longitude:125.1633,latitude:0,speed:1),
    PlanetPosition(name:'Mercury',shortName:'Me',longitude:108.4094,latitude:0,speed:-1),
    PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245.25,latitude:0,speed:-1),
    PlanetPosition(name:'Venus',shortName:'Ve',longitude:71.8717,latitude:0,speed:1),
    PlanetPosition(name:'Saturn',shortName:'Sa',longitude:54.8869,latitude:0,speed:1),
    PlanetPosition(name:'Rahu',shortName:'Ra',longitude:272.34,latitude:0,speed:-1),
    PlanetPosition(name:'Ketu',shortName:'Ke',longitude:92.34,latitude:0,speed:-1),
  ],
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('all nine planets get distinct Rashi/Lagna/Jupiter position channels',() {
    final pos=BnnHouseRelationService.positions(_chart);
    expect(pos.length,9);
    final mars=pos.singleWhere((p)=>p.name=='Mars');
    expect(mars.lagnaHouse,3);
    expect(mars.jupiterHouse,9);
    final saturn=pos.singleWhere((p)=>p.name=='Saturn');
    expect(saturn.lagnaHouse,12);
    expect(saturn.jupiterHouse,6);
    final venus=pos.singleWhere((p)=>p.name=='Venus');
    expect(venus.lagnaHouse,1);
    expect(venus.jupiterHouse,7);
  });

  test('no Lagna-bhava predictions generated from an empty verified catalog',() async {
    final rules=await BnnHouseRelationService.loadVerifiedLagnaRules();
    expect(rules, isEmpty);
    expect(BnnHouseRelationService.evaluateVerifiedLagnaRules(
      chart:_chart,rules:rules),isEmpty);
  });

  test('source-backed Lagna IF matches only its exact house',() {
    const rule=BnnLagnaRelativeRule(
      id:'LAG-TEST',sourceId:'SOURCE-TEST',target:'Sun',lagnaHouse:2,
      originalIf:'IF సూర్యుడు 2వ భావంలో ఉంటే',
      originalThen:'మూల పరీక్ష ఫలితం',tone:'neutral',
      sourceFile:'test.pdf',pdfPage:7);
    expect(BnnHouseRelationService.evaluateVerifiedLagnaRules(
      chart:_chart,rules:[rule]).length,1);
    const wrong=BnnLagnaRelativeRule(
      id:'LAG-WRONG',sourceId:'SOURCE-TEST',target:'Sun',lagnaHouse:4,
      originalIf:'IF సూర్యుడు 4వ భావంలో ఉంటే',
      originalThen:'తప్పుడు ఫలితం',tone:'neutral',
      sourceFile:'test.pdf',pdfPage:7);
    expect(BnnHouseRelationService.evaluateVerifiedLagnaRules(
      chart:_chart,rules:[wrong]),isEmpty);
  });

  testWidgets('BNN shows all nine triple channels and result tap opens rule',(tester) async {
    final birth=BirthData(name:'BNN example',
      localDateTime:DateTime(2000,1,1,12),place:'Guntur',
      latitude:16.3,longitude:80.4,timezoneOffsetHours:5.5,
      ayanamsa:AyanamsaType.lahiri);
    await tester.pumpWidget(MaterialApp(home:Scaffold(
      body:SingleChildScrollView(
        child:BnnMasterPanel(chart:_chart,birthData:birth)))));
    await tester.pumpAndSettle();

    for (final planet in BnnHouseRelationService.planets) {
      expect(find.byKey(ValueKey('bnn-three-results-$planet')),findsOneWidget);
    }
    expect(find.text('2. లగ్నం నుంచి 12వ భావం'), findsOneWidget);
    expect(find.text('3. గురువు నుంచి 6వ స్థానం'), findsOneWidget);
    expect(find.byKey(const ValueKey('bnn-triple-rashi-Saturn')),findsOneWidget);
    // Lagna has no source-backed predictions yet: do not mislabel house topics.
    expect(find.text('మూల పరీక్ష ఫలితం'),findsNothing);
    expect(find.byKey(const ValueKey('bnn-lagna-LAG-TEST')),findsNothing);

    const effect='ఆర్థిక ప్రగతి. విలాస వస్తువులు లేదా ఆర్థిక సంస్థలలో వృత్తి.';
    expect(find.text(effect),findsOneWidget);
    await tester.ensureVisible(find.text(effect));
    await tester.tap(find.text(effect));
    await tester.pumpAndSettle();
    expect(find.textContaining('1. రూల్ — BNN-RASHI-014'),findsOneWidget);
  });
}
