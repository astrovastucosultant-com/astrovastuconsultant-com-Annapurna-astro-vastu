import 'dart:io';
import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('standalone Jamakola uses only JA source rules', () {
    final p=File('lib/screens/jamakola_rule_panel.dart').readAsStringSync();
    expect(p, contains("r.id.startsWith('JA-')"));
    expect(p, contains('jamakola-custom-topic-selector-v429'));
    expect(p, contains('FilterChip('));
    expect(p, contains('_selectedJamaModules'));
    expect(p, contains('_jamaTopicSelected(r.module)'));
    expect(p, isNot(contains("import '../astrology/kp_event_judgement_service.dart';")));
    expect(p, isNot(contains("import '../astrology/tajik_prashna_service.dart';")));
    final json=jsonDecode(File('assets/jamakola/rules.json').readAsStringSync())
      as Map<String,dynamic>;
    final rules=json['rules'] as List;
    expect(rules, isNotEmpty);
    expect(rules.every((r)=>(r as Map)['id'].toString().startsWith('JA-')),
      isTrue);
  });
  test('combined tab is isolated and topics can be customized', () {
    final chart=File('lib/screens/chart_screen.dart').readAsStringSync();
    final unified=File('lib/screens/unified_prashna_screen.dart').readAsStringSync();
    final service=File('lib/astrology/unified_prashna_service.dart').readAsStringSync();
    expect(chart, contains('UnifiedPrashnaScreen(birthData:birthData)'));
    expect(chart, contains('JamakolaRulePanel(birthData: birthData)'));
    expect(unified, contains('unified-prashna-custom-topics-v429'));
    expect(unified, contains('FilterChip('));
    expect(unified, contains('_chosenCategories'));
    expect(service, contains("r.id.startsWith('JA-')"));
    expect(service, contains('TajikPrashnaService.evaluate'));
    expect(service, contains('KpHoraryEventService.judgeTimeChart'));
  });
}
