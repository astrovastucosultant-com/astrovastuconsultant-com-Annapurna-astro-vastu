import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/astrology/varga_unified_rule_service.dart';
import '../lib/astrology/topic_results_v398.dart';
import '../lib/screens/topic_result_card_v398.dart';
import '../lib/screens/topic_result_card_v391.dart';
import '../lib/screens/topic_varga_review_panel.dart';
import '../lib/screens/unified_rule_result_tile.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 63,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.0,
        'Moon': 115.1369,
        'Mars': 156.1172,
        'Mercury': 242.4142,
        'Jupiter': 189.8097,
        'Venus': 280.4494,
        'Saturn': 176.7767,
        'Rahu': 75.0,
        'Ketu': 255.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final topics = MultiChartTopicService.summarize(
    chart: chart,
    evaluatedRules: [],
  );
  for (final id in ['VARGA-CROSS-005', 'VARGA-CROSS-011', 'VARGA-CROSS-012']) {
    final summary = topics.singleWhere((s) => s.chartOrderSourceId == id);
    test(
      '$id results carry trace, preserve chart order and suppress probability',
      () {
        expect(summary.supplement, isNotNull);
        expect(summary.confirmationPercent, isNull);
        expect(
          summary.stages.every(
            (s) => s.result.isNotEmpty && s.source.isNotEmpty,
          ),
          isTrue,
        );
        expect(
          summary.displayCoverage,
          contains(summary.supplement!.grade.label),
        );
      },
    );
    testWidgets('$id result appears below every chart and opens sources', (
      tester,
    ) async {
      await tester.binding.setSurfaceSize(const Size(400, 1800));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: summary),
            ),
          ),
        ),
      );
      for (final s in summary.stages) {
        final result = find.byKey(
          ValueKey('topic-result-under-chart-$id-${s.factor}'),
        );
        final grid = find.byKey(ValueKey('topic-chart-$id-${s.factor}'));
        expect(result, findsOneWidget);
        expect(
          tester.getTopLeft(result).dy,
          greaterThan(tester.getBottomLeft(grid).dy),
        );
      }
      await tester.tap(find.byKey(ValueKey('topic-result-398-$id')));
      await tester.pumpAndSettle();
      // The inspection uses a lazy ListView. Its footer is created after
      // scrolling; absence before scrolling is not a missing tap/result.
      final inspection = find.byKey(
        ValueKey('topic-inspection-scroll-398-$id'),
      );
      expect(inspection, findsOneWidget);
      expect(find.textContaining(summary.supplement!.conclusion), findsWidgets);
      await tester.scrollUntilVisible(
        find.text('సమగ్ర నిర్ణయ విధానం / పరిహారం'),
        500,
        // SelectableText also creates nested Scrollables. The first vertical
        // Scrollable beneath this keyed ListView is the outer inspection list;
        // passing every descendant to scrollUntilVisible requires .single and
        // throws "Too many elements" before any scrolling can happen.
        scrollable: find.descendant(
          of: inspection,
          matching: find.byWidgetPredicate(
            (widget) => widget is Scrollable &&
                widget.axisDirection == AxisDirection.down,
          ),
        ).first,
        maxScrolls: 60,
      );
      await tester.pumpAndSettle();
      expect(find.text('సమగ్ర నిర్ణయ విధానం / పరిహారం'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
    testWidgets('$id root result opens its own inspection', (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: TopicResultCard391(chart: chart, summary: summary),
          ),
        ),
      );
      await tester.tap(find.byKey(ValueKey('topic-result-$id')));
      await tester.pumpAndSettle();
      expect(find.byKey(ValueKey('topic-result-398-$id')), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
    testWidgets('$id large Telugu type fits narrow mobile', (tester) async {
      await tester.binding.setSurfaceSize(const Size(320, 800));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      await tester.pumpWidget(
        MaterialApp(
          home: MediaQuery(
            data: const MediaQueryData(textScaler: TextScaler.linear(1.8)),
            child: Scaffold(
              body: SingleChildScrollView(
                child: TopicResultCard398(report: summary.supplement!),
              ),
            ),
          ),
        ),
      );
      expect(tester.takeException(), isNull);
    });
  }
  test(
    'historical D7 sex clauses are reference-only, full strength is not fabricated',
    () async {
      final rows = await VargaUnifiedRuleService.evaluate(chart);
      for (final id in ['VARGA-D7-002', 'VARGA-D7-003']) {
        final row = rows.singleWhere((r) => r.id == id);
        expect(row.status, UnifiedVargaRuleStatus.method);
        expect(row.evidence, contains('లింగ ఫలితంగా ఉపయోగించలేదు'));
      }
      final strength = rows.singleWhere((r) => r.id == 'VARGA-D7-001');
      expect(strength.status, UnifiedVargaRuleStatus.pending);
      for (final f in [1, 2, 3, 9, 12, 30])
        expect(strength.evidence, contains('D$f'));
      expect(
        rows.singleWhere((r) => r.id == 'VARGA-D7-006').status,
        UnifiedVargaRuleStatus.pending,
      );
    },
  );
  testWidgets('reference row is visibly distinct from missing data', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: UnifiedRuleResultTile(
            data: RuleResultData(
              topic: 'సంతానం లక్షణాలు',
              result: '',
              verdict: RuleVerdict.unverified,
              examination: 'చారిత్రక సూచన',
              rule: 'రూల్',
              referenceOnly: true,
            ),
          ),
        ),
      ),
    );
    expect(
      find.text('మూల సూచన మాత్రమే • లింగ ఫలితంగా వాడలేదు'),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
}
