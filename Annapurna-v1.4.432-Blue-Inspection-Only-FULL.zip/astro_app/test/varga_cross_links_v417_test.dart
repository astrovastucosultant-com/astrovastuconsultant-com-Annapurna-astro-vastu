import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/multi_chart_topic_service.dart';
import 'package:astro_app/astrology/varga_unified_rule_service.dart';
import 'package:astro_app/screens/varga_cross_links_v417.dart';

const _chart = AstroChartResult(
  julianDay: 2441542.0,
  ayanamsaDegrees: 23.0,
  ascendantLongitude: 75.0,
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 110, latitude: 0, speed: 0.9),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 160, latitude: 0, speed: 13),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 122, latitude: 0, speed: 0.5),
  ],
  engineVersion: 'test',
);

void main() {
  test('cross-topic links only select source-bound chart stages', () {
    const examples = [
      MultiChartTopicEvidence(
        name: 'వ్యాపారం',
        chartOrderSourceId: 'USER-CAREER-CORE-BUSINESS',
        note: '',
        stages: [
          TopicStageEvidence(factor: 1, status: TopicStageStatus.insufficientEvidence, ruleIds: [], details: ''),
          TopicStageEvidence(factor: 9, status: TopicStageStatus.insufficientEvidence, ruleIds: [], details: ''),
          TopicStageEvidence(factor: 10, status: TopicStageStatus.insufficientEvidence, ruleIds: [], details: ''),
        ],
      ),
      MultiChartTopicEvidence(
        name: 'సంతానం', chartOrderSourceId: 'VARGA-CROSS-005', note: '',
        stages: [TopicStageEvidence(factor: 7, status: TopicStageStatus.insufficientEvidence, ruleIds: [], details: '')],
      ),
    ];
    expect(VargaCrossLinks417.forFactor(10, examples).single.name, 'వ్యాపారం');
    expect(VargaCrossLinks417.forFactor(7, examples).single.name, 'సంతానం');
    expect(VargaCrossLinks417.forFactor(40, examples), isEmpty);
  });

  testWidgets('all varga tabs get a tappable cross-chart navigation entry', (tester) async {
    for (final factor in <int>[1, 2, 7, 9, 10, 24, 40, 45, 60]) {
      await tester.pumpWidget(MaterialApp(home: Scaffold(body: SingleChildScrollView(
        child: VargaCrossLinks417(
          chart: _chart,
          factor: factor,
          evaluatedRules: Future<List<UnifiedVargaRule>>.value([]),
        ),
      ))));
      expect(find.byKey(ValueKey('varga-cross-links-$factor')), findsOneWidget);
      expect(find.byKey(ValueKey('varga-cross-open-$factor')), findsOneWidget);
    }
  });
}
