import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/marriage_material_registry.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';
import 'package:astro_app/astrology/varga_service.dart';

const natal = AstroChartResult(
  julianDay: 2441542.0,
  ayanamsaDegrees: 23.0,
  ascendantLongitude: 75.0,
  engineVersion: 'd9-handwritten-regression',
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 110, latitude: 0, speed: 0.9),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 160, latitude: 0, speed: 13),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 122, latitude: 0, speed: 0.5),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108, latitude: 0, speed: 0.2),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 245, latitude: 0, speed: -0.1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 71, latitude: 0, speed: 0.2),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 58, latitude: 0, speed: 0.1),
    PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 272, latitude: 0, speed: -0.1),
    PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 92, latitude: 0, speed: -0.1),
  ],
);

void main() {
  test('D9 hides handwritten MM-R duplicates while retaining historical archive', () {
    expect(MarriageMaterialRegistry.totalRuleCount, 69);
    expect(MarriageMaterialRegistry.entries.where((e) =>
        e.id.startsWith('MM-R') && e.factors.contains(9)).length, 42);
    final d9 = MarriageMaterialRegistry.individualForFactor(9);
    expect(d9.where((e) => e.id.startsWith('MM-R')), isEmpty);
    expect(MarriageMaterialRegistry.forFactor(9)
        .where((e) => e.id.startsWith('MM-R')), isEmpty);
    expect(d9.map((e) => e.id), contains('MM-D7-DIV-35'));
    expect(MarriageMaterialRegistry.entries.map((e) => e.id),
        contains('MM-R08'));
  });

  test('printed two-chart matching source tables continue unchanged', () {
    final printed = MarriageMaterialRegistry.matchingRules();
    expect(printed.length, 10);
    expect(printed.map((e) => e.id), contains('MM-P04-S07'));
    expect(printed.map((e) => e.id), contains('MM-P04-S08'));
    expect(printed.every((e) => e.requiresTwoCharts), isTrue);
  });

  test('D1 and D7 historical source routing stays unchanged', () {
    expect(MarriageMaterialRegistry.individualForFactor(1)
        .any((e) => e.id == 'MM-R07'), isTrue);
    expect(MarriageMaterialRegistry.individualForFactor(7)
        .any((e) => e.id == 'MM-R13'), isTrue);
  });

  test('D9 actual VargaRuleService results have no MM-R duplicate cards', () {
    final ids = VargaRuleService.allFor(chart: natal, factor: 9)
        .map((e) => e.ruleId).toList();
    expect(ids.where((id) => id.startsWith('MM-R')), isEmpty);
    expect(ids, contains('MM-D7-DIV-35'));
  });

  test('19 source varga definitions remain available', () {
    expect(VargaService.definitions.length, 19);
  });
}
