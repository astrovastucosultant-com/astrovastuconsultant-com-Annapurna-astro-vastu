import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_ashtakavarga_service.dart';
import 'package:astro_app/screens/varga_ashtakavarga_panel.dart';

final chart = AstroChartResult(
  julianDay: 2450000.5, ayanamsaDegrees: 23.5,
  ascendantLongitude: 40,
  planets: const [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 10, latitude: 0, speed: 1),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 44, latitude: 0, speed: 13),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 108, latitude: 0, speed: 0.7),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 152, latitude: 0, speed: 1.1),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 224, latitude: 0, speed: 0.1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 281, latitude: 0, speed: 1.2),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 334, latitude: 0, speed: 0.04),
  ],
  engineVersion: 'test',
);

void main() {
  testWidgets('all-house SAV and individual house BAV/PAV open without outcomes',
      (tester) async {
    final report = VargaAshtakavargaService.calculate(chart, 24);
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: ListView(children: [
      VargaAshtakavargaPanel(report: report),
      VargaAvHouseEvidenceTile(report: report, house: 9),
    ]))));
    expect(find.textContaining('D24 అష్టకవర్గం'), findsOneWidget);
    expect(find.textContaining('PAV→BAV→SAV audit PASS'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('varga-av-house-24-9')));
    await tester.pumpAndSettle();
    expect(find.textContaining('PAV బిందు దాతలు'), findsWidgets);
    expect(find.textContaining('సంఘటన'), findsWidgets);
  });
}
