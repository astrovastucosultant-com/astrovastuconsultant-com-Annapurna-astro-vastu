import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_life_event_convergence_v371.dart';

void main() {
  test('only five non-sensitive, event-specific families are enabled', () {
    expect(BnnEventConvergenceServiceV371.priorityIds,
      ['EDU-HIGHER','CAREER-ENTRY','MARRIAGE','CHILDREN','HOUSE']);
    expect(BnnEventConvergenceServiceV371.priorityIds,
      isNot(contains('LONGEVITY')));
    expect(BnnEventConvergenceServiceV371.priorityIds,
      isNot(contains('RELATIVE-BEREAVEMENT')));
  });

  test('D1/Dn house ruler is derived from chart ascendant, not an age filter', () {
    expect(BnnEventConvergenceServiceV371.houseLord(0, 9), 'Jupiter');
    expect(BnnEventConvergenceServiceV371.houseLord(3, 7), 'Saturn');
    expect(BnnEventConvergenceServiceV371.houseLord(0, 10), 'Saturn');
  });

  test('dasha requires a house lord and relevant second lord or karaka', () {
    expect(BnnEventConvergenceServiceV371.supportsDashaPair(
      maha:'Venus',antar:'Jupiter',eventHouseLords:{'Jupiter'},
      eventKarakas:{'Venus'}),isTrue);
    expect(BnnEventConvergenceServiceV371.supportsDashaPair(
      maha:'Saturn',antar:'Rahu',eventHouseLords:{'Jupiter'},
      eventKarakas:{'Venus'}),isFalse);
  });

  test('transits require both Jupiter and Saturn sign-level support', () {
    expect(BnnEventConvergenceServiceV371.supportsTransitSnapshot(
      jupiterSign:0,saturnSign:0,targetSign:0),isTrue);
    expect(BnnEventConvergenceServiceV371.supportsTransitSnapshot(
      jupiterSign:0,saturnSign:1,targetSign:0),isFalse);
  });

  test('source-only state cannot be presented as predicted age', () {
    const unverified=BnnEventTimingAssessmentV371(
      eventId:'MARRIAGE',factor:9,sourceRuleId:null,
      sourceCitation:null,sourceRuleText:null,matchedInspection:null,
      natalInspection:null,windows:[],dashaCandidatesExamined:0);
    expect(unverified.hasEventSpecificRule,isFalse);
    expect(unverified.hasScreenedWindow,isFalse);
  });

  test('a checkpoint is evidence, never a whole-transit or death window', () {
    final sample=BnnEventTimingWindowV371(
      sampledLocal:DateTime(2030,5,2),ageAtSample:28.4,
      mahaLord:'Jupiter',antarLord:'Venus',
      d1Lord:'Jupiter',vargaLord:'Venus',
      jupiterTransit:'Jupiter sign check',
      saturnTransit:'Saturn sign check');
    expect(sample.ageAtSample,28.4);
    expect(sample.sampledLocal.year,2030);
  });
}
