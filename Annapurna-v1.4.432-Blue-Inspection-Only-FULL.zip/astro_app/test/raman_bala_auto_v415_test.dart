import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/raman_bala_v415.dart';
import '../lib/screens/gem_bala_summary_v414.dart';
import '../lib/models/birth_data.dart';
import '../tool/verify_raman_bala_v415.dart' show ramanFixture415;
import '../tool/verify_wealth_topic_v409.dart' show fixture409;
import 'gem_bala_summary_v414_test.dart' show MemoryBalaStorage;

void main() {
  final chart = fixture409(4, [235, 115, 156, 242, 189, 280, 176, 75, 255]);
  final birth = BirthData(
    name: 'Auto strength',
    localDateTime: DateTime(1981, 12, 15, 15, 50),
    place: 'Guntur',
    latitude: 16.5,
    longitude: 80.5,
    timezoneOffsetHours: 5.5,
    ayanamsa: AyanamsaType.lahiri,
  );
  final expected = RamanBala415.calculate(ramanFixture415());
  Widget page({
    BirthData? b,
    Future<RamanBalaResult415?> Function()? calculate,
  }) => MaterialApp(
    home: Scaffold(
      body: SingleChildScrollView(
        child: GemBalaSummary414(
          chart: chart,
          birth: b ?? birth,
          storage: MemoryBalaStorage(),
          autoCalculator: (_, __) =>
              calculate?.call() ?? Future.value(expected),
        ),
      ),
    ),
  );
  testWidgets(
    'opening Gem Bala fills 7 grahas and 12 houses without entering values',
    (tester) async {
      await tester.pumpWidget(page());
      await tester.pumpAndSettle();
      final sun = find.byKey(const ValueKey('bala-bar-shadbala-Sun-414'));
      expect(
        find.descendant(of: sun, matching: find.text('7.08')),
        findsOneWidget,
      );
      expect(
        find.descendant(of: sun, matching: find.text('141.7%')),
        findsOneWidget,
      );
      final house8 = find.byKey(const ValueKey('bala-bar-bhava-8-414'));
      expect(
        find.descendant(
          of: house8,
          matching: find.text(expected.houses[7].rupas.toStringAsFixed(2)),
        ),
        findsNWidgets(2),
      );
      expect(
        find.text('గణనకు సమాచారం లేదు — ధృవీకరించిన రూపాలు నమోదు చేయండి'),
        findsNothing,
      );
      await tester.ensureVisible(sun);
      await tester.tap(sun);
      await tester.pumpAndSettle();
      expect(
        find.byWidgetPredicate(
          (w) =>
              w is SelectableText &&
              (w.data ?? '').contains('ఆరు బలాలు (విరూపాలు)'),
        ),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('late auto response for old chart never replaces current chart', (
    tester,
  ) async {
    final pending = Completer<RamanBalaResult415?>();
    await tester.pumpWidget(page(calculate: () => pending.future));
    await tester.pump();
    final other = BirthData(
      name: 'Other',
      localDateTime: birth.localDateTime,
      place: 'Other',
      latitude: 17.5,
      longitude: 80.5,
      timezoneOffsetHours: 5.5,
      ayanamsa: AyanamsaType.lahiri,
    );
    final different = RamanBalaResult415([
      PlanetBala415('Sun', {'స్థాన': 600}, {}),
      ...expected.planets.skip(1),
    ], expected.houses);
    await tester.pumpWidget(page(b: other, calculate: () async => different));
    await tester.pumpAndSettle();
    pending.complete(expected);
    await tester.pumpAndSettle();
    final sun = find.byKey(const ValueKey('bala-bar-shadbala-Sun-414'));
    expect(
      find.descendant(of: sun, matching: find.text('10.00')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
}
