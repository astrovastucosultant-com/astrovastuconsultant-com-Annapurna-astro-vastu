import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('Fresh BNN catalogue is blank and not published', () async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_fresh_v2.json');
    final json = jsonDecode(raw) as Map<String, dynamic>;
    expect(json['schema_version'], 'ANNAPURNA-BNN-NEW-1.0');
    expect(json['published'], false);
    expect(json['rules'], isEmpty);
    expect(json['expected_rule_count'], 0);
    expect((json['policy'] as Map)['no_legacy_imports'], true);
  });
}
