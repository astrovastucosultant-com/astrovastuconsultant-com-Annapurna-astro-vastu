import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/user_html_if_then_service.dart';
import 'package:astro_app/astrology/varga_service.dart';

PlanetPosition pos(String name, double longitude) => PlanetPosition(
  name: name,
  shortName: name,
  longitude: longitude,
  latitude: 0,
  speed: 1,
);

AstroChartResult natal(double asc, List<PlanetPosition> planets) =>
    AstroChartResult(
      julianDay: 2450000,
      ayanamsaDegrees: 23.5,
      ascendantLongitude: asc,
      planets: planets,
      engineVersion: 'fixture',
    );

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Future<UserHtmlIfThenRow> rule(String id) async =>
      (await UserHtmlIfThenService.load()).firstWhere((r) => r.id == id);

  test('HTML catalog has exactly 60 unique source-preserved IDs', () async {
    final rules = await UserHtmlIfThenService.load();
    expect(rules.length, 60);
    expect(rules.map((r) => r.engineId).toSet().length, 60);
    expect(rules.map((r) => r.varga).toSet().length, 19);
    expect(rules.where((r) => r.factor == 11).length, 2);
    // New HTML does NOT populate reset BNN release.
    expect(rules.any((r) => r.varga == 'BNN'), isFalse);
  });

  test('D2 solar/lunar hora uses D2 birth ascendant not Sun', () async {
    final chart = natal(5.0, [pos('Sun', 191.0)]);
    final solar = UserHtmlIfThenService.evaluate(await rule('D2-01'), chart);
    final lunar = UserHtmlIfThenService.evaluate(await rule('D2-02'), chart);
    expect(solar.matched, isTrue);
    expect(lunar.matched, isFalse);
  });

  test('D3 exalted Mars and tenth house both required', () async {
    final r = await rule('D3-02');
    expect(UserHtmlIfThenService.evaluate(r,
        natal(0.0, [pos('Mars', 270.0)])).matched, isTrue);
    expect(UserHtmlIfThenService.evaluate(r,
        natal(0.0, [pos('Mars', 180.0)])).matched, isFalse);
  });

  test('D10 agocharastha unknown when unimplemented clauses remain', () async {
    final r = await rule('D10-02');
    expect(UserHtmlIfThenService.evaluate(r,
        natal(0, [pos('Saturn', 0)])).matched, isTrue);
    final other = UserHtmlIfThenService.evaluate(r,
        natal(0, [pos('Saturn', 270)]));
    expect(other.matched, isNull); // never a false self-employment claim
  });

  test('D12 OR predicate unknown without aspect implementation', () async {
    final r = await rule('D12-10');
    expect(UserHtmlIfThenService.evaluate(r,
        natal(0, [pos('Sun', 210.0)])).matched, isTrue);
    expect(UserHtmlIfThenService.evaluate(r,
        natal(0, [pos('Sun', 0.0)])).matched, isNull);
  });

  test('No pseudo predicate executes and unsupported D11 is audit only', () async {
    final chart = natal(0, [pos('Jupiter', 210.0)]);
    expect(UserHtmlIfThenService.evaluate(await rule('D7-04'), chart).matched,
        isNull);
    expect(UserHtmlIfThenService.evaluate(await rule('D11-01'), chart).matched,
        isNull);
  });

  test('D16 calculation selector does not mutate the BNN tab', () async {
    final r = await rule('D16-01');
    final ch = natal(0, [pos('Venus', 5.0)]);
    for (final m in D16CalculationMethod.values) {
      expect(UserHtmlIfThenService.evaluate(r, ch, d16Method: m).matched,
          isNull);
    }
  });
}
