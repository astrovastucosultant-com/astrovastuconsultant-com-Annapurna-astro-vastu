import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_source_safalya_v379.dart';
import 'package:astro_app/astrology/bnn_auto_source_v381.dart';
import 'package:astro_app/astrology/bnn_unified_evidence_v376.dart';
import 'package:astro_app/screens/bnn_source_safalya_panel_v379.dart';

void main() {
  final catalog = jsonDecode(
    File('assets/bnn/bnn_auto_source_links_v381.json').readAsStringSync(),
  ) as Map<String, dynamic>;
  final rules = BnnSafalyaRules379.fromJson(
    jsonDecode(
      File('assets/bnn/bnn_safalya_source_v379.json').readAsStringSync(),
    ) as Map<String, dynamic>,
  );
  const chart = AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 24,
    ascendantLongitude: 120,
    planets: [
      PlanetPosition(
        name: 'Venus',
        shortName: 'Ve',
        longitude: 1,
        latitude: 0,
        speed: 1,
      ),
    ],
    engineVersion: 'fixture',
  );
  const event = UnifiedEvent376(
    id: 'HOUSE',
    title: 'ఇల్లు',
    mainHouse: 4,
    houses: {4},
    ageFrom: 18,
  );
  const finding = BnnAutoFinding381(
    'BNN-RASHI-006',
    'Venus',
    'వివాహం తర్వాత స్వంత ఇల్లు',
    'source p6',
    'IF Venus in Aries',
  );
  testWidgets(
    'matches source and computes separate transit scores without manual input',
    (tester) async {
      var calls = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: BnnSourceSafalyaPanel379(
                chart: chart,
                start: DateTime(2026, 1),
                end: DateTime(2026, 2),
                event: event,
                age: 30,
                married: true,
                findings: Future.value([finding]),
                catalog: Future.value(catalog),
                safalyaRules: Future.value(rules),
                loadTransits: (_) async {
                  calls++;
                  return const [
                    PlanetPosition(
                      name: 'Saturn',
                      shortName: 'Sa',
                      longitude: 331,
                      latitude: 0,
                      speed: -0.1,
                    ),
                    PlanetPosition(
                      name: 'Jupiter',
                      shortName: 'Ju',
                      longitude: 31,
                      latitude: 0,
                      speed: 0.1,
                    ),
                  ];
                },
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(calls, 1);
      expect(find.byType(TextFormField), findsNothing);
      expect(find.byType(DropdownButtonFormField<String>), findsNothing);
      expect(find.byType(CheckboxListTile), findsNothing);
      expect(find.textContaining('శని: 25%'), findsOneWidget);
      expect(find.textContaining('గురు: 75%'), findsOneWidget);
      expect(find.text('వివాహం తర్వాత స్వంత ఇల్లు'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('missing context retains source and does not request ephemeris', (
    tester,
  ) async {
    var calls = 0;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: BnnSourceSafalyaPanel379(
              chart: chart,
              start: DateTime(2026, 1),
              end: DateTime(2026, 2),
              event: event,
              age: 30,
              findings: Future.value([finding]),
              catalog: Future.value(catalog),
              safalyaRules: Future.value(rules),
              loadTransits: (_) async {
                calls++;
                throw StateError('must not be called');
              },
            ),
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(calls, 0);
    expect(find.textContaining('జీవితస్థితి తెలియదు'), findsOneWidget);
    expect(find.text('వివాహం తర్వాత స్వంత ఇల్లు'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
