import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/screens/birth_details_screen.dart';
import 'package:astro_app/screens/chart_screen.dart';
import 'package:astro_app/models/birth_data.dart';

void main() {
  testWidgets('home header has two separate, tappable quick-system tabs',
      (tester) async {
    tester.view.physicalSize = const Size(355, 780);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    var kpTaps = 0;
    var jamaTaps = 0;
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: Padding(
      padding: const EdgeInsets.all(12),
      child: HomePrashnaShortcutBar(
        onKpTimeChart: () => kpTaps++,
        onJamakola: () => jamaTaps++,
      ),
    ))));
    expect(find.text('KP Time\nChart'), findsOneWidget);
    expect(find.text('జామకోళ\nJamakola'), findsOneWidget);
    expect(find.byKey(const ValueKey('birth-kp-time-quick-tab')), findsOneWidget);
    expect(find.byKey(const ValueKey('birth-jamakola-quick-tab')), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('birth-kp-time-quick-tab')));
    await tester.pump();
    expect(kpTaps, 1);
    expect(jamaTaps, 0);
    await tester.tap(find.byKey(const ValueKey('birth-jamakola-quick-tab')));
    await tester.pump();
    expect(jamaTaps, 1);
    expect(kpTaps, 1);
    expect(tester.takeException(), isNull);
  });

  test('question shortcuts target explicit independent system modes', () {
    final data = BirthData(
      name: 'KP ప్రశ్న సమయ చక్రం',
      localDateTime: DateTime(2026, 11, 16, 10, 0),
      place: 'Guntur, Andhra Pradesh, India',
      latitude: 16.3067,
      longitude: 80.4365,
      timezoneOffsetHours: 5.5,
      ayanamsa: AyanamsaType.krishnamurti,
    );
    final kp = ChartScreen(
      birthData: data, quickSystem: ChartQuickSystem.kpTimeChart,
    );
    final jama = ChartScreen(
      birthData: data.copyWith(ayanamsa: AyanamsaType.lahiri),
      quickSystem: ChartQuickSystem.jamakola,
    );
    expect(kp.quickSystem, ChartQuickSystem.kpTimeChart);
    expect(jama.quickSystem, ChartQuickSystem.jamakola);
    expect(kp.birthData.ayanamsa, AyanamsaType.krishnamurti);
    expect(jama.birthData.ayanamsa, AyanamsaType.lahiri);
  });
}
