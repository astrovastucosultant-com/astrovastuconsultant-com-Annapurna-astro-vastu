import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/screens/topic_varga_review_panel.dart';
import '../lib/screens/topic_result_card_v391.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 63,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.0,
        'Moon': 115.1369,
        'Mars': 156.1172,
        'Mercury': 242.4142,
        'Jupiter': 189.8097,
        'Venus': 280.4494,
        'Saturn': 176.7767,
        'Rahu': 75.0,
        'Ketu': 255.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final summaries = MultiChartTopicService.summarize(
    chart: chart,
    evaluatedRules: [],
  );
  final property = summaries.singleWhere((s) => s.name == 'ఆస్తి / వారసత్వం');
  test('property has real source results for the correct charts', () {
    expect(property.property, isNotNull);
    expect(property.stages.map((s) => s.factor), [1, 4, 12]);
    expect(
      property.stages.every((s) => s.status == TopicStageStatus.matched),
      isTrue,
    );
    expect(
      property.stages.every((s) => s.result.startsWith('ఆస్తి పరిశీలన — ')),
      isTrue,
    );
    expect(property.confirmationPercent, isNull);
    expect(property.displayCoverage.contains('పెండింగ్'), isFalse);
    expect(property.stages.first.ruleIds, contains('D2-PR-002'));
    expect(property.stages[1].ruleIds, contains('D2-PR-007'));
    expect(property.stages.last.ruleIds, contains('D12-KL-EST-04'));
    expect(property.stages.last.result, contains('KL పద్ధతికి లోబడి'));
    expect(summaries.singleWhere((s) => s.name == 'విద్య').property, isNull);
  });
  testWidgets('property summary fits beside D12 and opens source inspection', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(400, 2200));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: TopicVargaReviewPanel(chart: chart, summary: property),
          ),
        ),
      ),
    );
    final card = find.byKey(const ValueKey('property-result-v396'));
    final chart12 = find.byKey(
      const ValueKey('topic-chart-VARGA-CROSS-009-12'),
    );
    expect(card, findsOneWidget);
    expect(
      tester.getTopLeft(card).dx,
      greaterThan(tester.getTopLeft(chart12).dx),
    );
    expect(tester.getTopLeft(card).dy, lessThan(tester.getTopLeft(chart12).dy));
    for (final factor in [1, 4, 12])
      expect(
        find.byKey(
          ValueKey('topic-result-under-chart-VARGA-CROSS-009-$factor'),
        ),
        findsOneWidget,
      );
    await tester.ensureVisible(
      find.byKey(const ValueKey('property-inspect-v396')),
    );
    await tester.tap(find.byKey(const ValueKey('property-inspect-v396')));
    await tester.pumpAndSettle();
    expect(find.text('నిర్ణయ విధానం / మూల పరిమితులు'), findsOneWidget);
    expect(find.textContaining('D2-PR-002 —'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('root result tap includes the asset assessment', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: TopicResultCard391(chart: chart, summary: property),
        ),
      ),
    );
    await tester.tap(
      find.byKey(const ValueKey('topic-result-VARGA-CROSS-009')),
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('property-result-v396')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('large Telugu text fits the narrow mobile columns', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(360, 800));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(1.8)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: property),
            ),
          ),
        ),
      ),
    );
    expect(tester.takeException(), isNull);
  });
}
