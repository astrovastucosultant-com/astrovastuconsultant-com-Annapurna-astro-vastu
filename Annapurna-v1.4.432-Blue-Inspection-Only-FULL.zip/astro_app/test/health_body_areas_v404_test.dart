import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/health_body_areas_v404.dart';
import '../lib/screens/health_body_area_list_v404.dart';

void main() {
  testWidgets(
    'each chart renders complete body trace at narrow large Telugu text',
    (tester) async {
      tester.view.physicalSize = const Size(320, 1800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      for (final factor in [1, 6, 27, 12, 30]) {
        await tester.pumpWidget(
          MaterialApp(
            home: MediaQuery(
              data: const MediaQueryData(textScaler: TextScaler.linear(1.8)),
              child: Scaffold(
                body: SingleChildScrollView(
                  child: HealthBodyAreaList404(
                    data: ChartBodyAreas404(factor, const [
                      BodyArea404(9, ['Saturn: రాశి 10, 8వ భావం; లగ్నాధిపతి']),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        );
        expect(
          find.byKey(ValueKey('health-body-areas-404-$factor')),
          findsOneWidget,
        );
        expect(find.text('• మోకాళ్లు'), findsOneWidget);
        expect(find.textContaining('Saturn:'), findsOneWidget);
        if (factor == 12)
          expect(
            find.textContaining('వారసత్వ వ్యాధి సూచన కాదు'),
            findsOneWidget,
          );
        expect(tester.takeException(), isNull);
      }
    },
  );
  testWidgets('empty area list never says healthy', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: HealthBodyAreaList404(data: ChartBodyAreas404(1, [])),
        ),
      ),
    );
    expect(
      find.textContaining('వైద్య సమస్య లేదనే నిర్ధారణ కాదు'),
      findsOneWidget,
    );
  });
}
