import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/varga_rule_match_policy.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

VargaRuleHit _hit(String id, {
  bool applicable = true,
  VargaRuleTone tone = VargaRuleTone.favorable,
}) => VargaRuleHit(
  factor: 7,
  ruleId: id,
  topic: 'Evidence summary',
  rule: 'Aggregate support blocks',
  result: 'Summary only',
  inspection: '0/5',
  remedy: '',
  source: 'source audit',
  tone: tone,
  applicable: applicable,
  autoEvaluated: true,
);

void main() {
  test('non-predictive multi-block summaries never count as source hits', () {
    for (final id in <String>[
      'D3-SUMMARY-EVIDENCE',
      'D4-PROPERTY-EVIDENCE',
      'D7-SANTANA-001',
      'D16-VEHICLE-EVIDENCE',
      'D16-LUXURY-COMFORT',
      'D16-VEHICLE-DELAY',
      'D16-VEHICLE-CAUTION',
    ]) {
      expect(VargaRuleMatchPolicy.isEvidenceSummaryRule(id), isTrue);
      expect(VargaRuleMatchPolicy.calculatedMatch(_hit(id)), isNull,
          reason: '$id must remain audit-only even when legacy applicable=true');
    }
  });

  test('normal fully calculated independent source rule still matches', () {
    expect(VargaRuleMatchPolicy.calculatedMatch(_hit('SOURCE-EXACT-001')),
        isTrue);
    expect(VargaRuleMatchPolicy.calculatedMatch(
        _hit('SOURCE-EXACT-001', applicable: false)), isFalse);
  });

  test('cross-varga and SAV/PAV arithmetic are never event results', () {
    for (final id in ['AV-D7-H5-SAV-BAV-PAV', 'VARGA-CROSS-999']) {
      expect(VargaRuleMatchPolicy.calculatedMatch(_hit(id)), isNull);
    }
  });
}
