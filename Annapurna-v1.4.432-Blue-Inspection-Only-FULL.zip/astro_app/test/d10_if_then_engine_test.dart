import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/features/d10_if_then/d10_if_then_engine.dart';

D10Fact f(String key, String chart, bool? value) =>
    D10Fact(key: key, chart: chart, met: value,
        inspection: 'calculated $key');

Set<String> ids(D10MatchReport result) =>
    result.appliedRules.map((e) => e.rule.id).toSet();

void main() {
  test('D10 gocharishta alone matches work MODE, not hiring/profit', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: [
      f(D10FactKeys.d1Agocharishta, 'D1', true),
      f(D10FactKeys.d10Gocharishta, 'D10', true),
    ]));
    expect(ids(report), contains('D10-IF-BUS-001'));
    expect(ids(report), contains('D10-IF-MIX-002'));
    expect(ids(report), isNot(contains('D10-IF-SRV-001')));
    expect(ids(report), isNot(contains('D10-IF-BUS-002')));
  });

  test('D10 agocharishta matches service mode without requiring same D1', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: [
      f(D10FactKeys.d1Gocharishta, 'D1', true),
      f(D10FactKeys.d10Agocharishta, 'D10', true),
    ]));
    expect(ids(report), containsAll(['D10-IF-SRV-001', 'D10-IF-MIX-001']));
    expect(ids(report), isNot(contains('D10-IF-SRV-002')));
  });

  test('Government needs source GOV promise, D10 job and authority, ALL 3', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: [
      f(D10FactKeys.d1GovernmentLink, 'D1', true),
      f(D10FactKeys.d10Agocharishta, 'D10', true),
      f(D10FactKeys.d10SunAuthorityLink, 'D10', true),
    ]));
    expect(ids(report), contains('D10-IF-GOV-001'));
    expect(report.appliedRules.first.rule.highlightResult,
        contains('నియామకం'));
  });

  test('Government promise alone is not enough', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: [
      f(D10FactKeys.d1GovernmentLink, 'D1', true),
      f(D10FactKeys.d10Agocharishta, 'D10', false),
      f(D10FactKeys.d10SunAuthorityLink, 'D10', true),
    ]));
    expect(ids(report), isNot(contains('D10-IF-GOV-001')));
    expect(report.checks.first.status, D10CheckStatus.contradicted);
  });

  test('government D10 authority missing cannot be auto-matched', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: [
      f(D10FactKeys.d1GovernmentLink, 'D1', true),
      f(D10FactKeys.d10Agocharishta, 'D10', true),
    ]));
    expect(ids(report), isNot(contains('D10-IF-GOV-001')));
    expect(report.checks.first.status, D10CheckStatus.insufficientEvidence);
  });

  test('independent PP support is a second source-backed business gate', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: [
      f(D10FactKeys.d10Gocharishta, 'D10', true),
      f(D10FactKeys.d1IndependentPP, 'D1', true),
    ]));
    expect(ids(report), containsAll(['D10-IF-BUS-001', 'D10-IF-BUS-002']));
  });

  test('same-mode D1 and D10 produces continuation rule', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: [
      f(D10FactKeys.d1Agocharishta, 'D1', true),
      f(D10FactKeys.d10Agocharishta, 'D10', true),
    ]));
    expect(ids(report), containsAll(['D10-IF-SRV-001', 'D10-IF-SRV-002']));
  });

  test('cross-varga status cannot create a result', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(
      facts: [f(D10FactKeys.d10Gocharishta, 'D9', true)],
      crossVarga: const [
        VargaCrossObservation(varga: 'CROSS', sourceRuleId: 'VARGA-CROSS-028',
            inspection: 'matched but evidence only'),
      ],
    ));
    expect(report.appliedRules, isEmpty);
    expect(report.crossVarga, hasLength(1));
  });

  test('missing state is not a negative verdict or a match', () {
    final report = D10IfThenEngine().evaluate(D10EvidenceContext(facts: [
      f(D10FactKeys.d1Gocharishta, 'D1', true),
    ]));
    expect(ids(report), isEmpty);
    expect(report.checks.first.status, D10CheckStatus.insufficientEvidence);
  });

  test('duplicate facts rejected', () {
    expect(() => D10EvidenceContext(facts: [
      f(D10FactKeys.d1Gocharishta, 'D1', true),
      f(D10FactKeys.d1Gocharishta, 'D1', false),
    ]), throwsArgumentError);
  });

  test('contradictory D1 work modes rejected', () {
    expect(() => D10EvidenceContext(facts: [
      f(D10FactKeys.d1Gocharishta, 'D1', true),
      f(D10FactKeys.d1Agocharishta, 'D1', true),
    ]), throwsArgumentError);
  });

  test('custom remedy without original page is rejected', () {
    expect(() => D10IfThenEngine(definitions: const [
      D10RuleDefinition(id: 'invalid', title: 'invalid',
        careerKind: D10CareerKind.business,
        clauses: [[D10FactKeys.d10Gocharishta]],
        highlightResult: 'no', verifiedRemedy: 'unverified'),
    ]), throwsArgumentError);
  });

  test('every new IF rule keeps unique ID and has no invented remedy', () {
    final all = D10IfThenEngine.defaultRules;
    expect(all.map((r) => r.id).toSet().length, all.length);
    for (final rule in all) {
      expect(rule.verifiedRemedy, isNull);
      expect(rule.sourceName, isNotEmpty);
    }
  });
}
