import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

/// A source-level UI regression guard. Live sidereal chart calculations are
/// integration-tested separately, whereas this checks the visibility contract.
void main() {
  test('Jamakola prioritises a brief rules result and hides technical audits', () {
    final source = File('lib/screens/jamakola_rule_panel.dart').readAsStringSync();
    final start = source.indexOf('Widget _selectedChart(');
    final end = source.indexOf('// On phones the planetary data', start);
    expect(start, greaterThan(0));
    expect(end, greaterThan(start));
    final view = source.substring(start, end);
    expect(view, contains('_nowQuestionSummary(chart,special,chatraSign,ch,ar)'));
    expect(view, contains('_rulesPanel(chart,special)'));
    expect(view, contains('if(_showFullReview) ...['));
    expect(view.indexOf('_rulesPanel(chart,special)'),
        lessThan(view.indexOf('if(_showFullReview) ...[')));
    expect(view.indexOf('_JamakkolSouthChart('),
        lessThan(view.indexOf('_rulesPanel(chart,special)')));
    expect(view.indexOf('_planetPositionView(rows)'),
        greaterThan(view.indexOf('if(_showFullReview) ...[')));
    expect(view.indexOf('_confirmation(chart,special)'),
        greaterThan(view.indexOf('if(_showFullReview) ...[')));
    expect(source, contains('jamakola-verdict-summary-v428'));
    expect(source, contains('jamakola-location-advanced-v428'));
    expect(source, contains('jamakola-toggle-full-review-v428'));
    expect(source, contains('initiallyExpanded:false'));
    expect(source, contains('పూర్తి పరిశీలన · నియమాలు · ఇన్నర్ గ్రహాలు · డిగ్రీలు'));
  });
}
