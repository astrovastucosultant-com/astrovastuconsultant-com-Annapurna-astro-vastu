import 'dart:io';
import 'package:flutter_test/flutter_test.dart';

/// Source-level contract: live UI and position calculations still require
/// on-device verification using a real saved question place.
void main() {
  test('Jama chart is visible first; four facts precede the result', () {
    final source = File('lib/screens/jamakola_rule_panel.dart').readAsStringSync();
    final start = source.indexOf('Widget _selectedChart(');
    final end = source.indexOf('// On phones the planetary data', start);
    expect(start, greaterThan(0));
    expect(end, greaterThan(start));
    final view = source.substring(start, end);
    final chart = view.indexOf('_JamakkolSouthChart(');
    final facts = view.indexOf('_decisionFacts(chart,special,ar,chatraSign,ch)');
    final verdict = view.indexOf('_rulesPanel(chart,special)');
    final review = view.indexOf('if(_showFullReview) ...[');
    expect(chart, greaterThan(0));
    expect(facts, greaterThan(chart));
    expect(verdict, greaterThan(facts));
    expect(review, greaterThan(verdict));
    expect(view.indexOf('_nowQuestionSummary('), greaterThan(review));
    expect(view.indexOf('_planetPositionView(rows)'), greaterThan(review));
  });

  test('Kavippu contact uses the auto mirrored degree or manual exact override', () {
    final source = File('lib/screens/jamakola_rule_panel.dart').readAsStringSync();
    expect(source, contains('JamakolaSpecialService.kavippuJamaTouch('));
    expect(source, contains('final effectiveKav = ch ?? (_kavipuSign==null ? kav : null);'));
    expect(source, contains('ప్రస్తుత డిగ్రీ స్పర్శ'));
    expect(source, contains('అపసవ్య దిశలో తరువాత ఎదురయ్యే జామ గ్రహం'));
    expect(source, contains('కవిప్పు తాకిన జామ గ్రహం'));
    expect(source, contains('6. తుది ఫలితం — జామకోళ ప్రశ్న'));
    expect(source, contains('if(_showFullReview) ExpansionTile('));
  });

}
