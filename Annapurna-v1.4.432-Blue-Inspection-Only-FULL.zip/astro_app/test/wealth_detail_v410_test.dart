import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/wealth_topic_v409.dart';
import '../lib/astrology/wealth_detail_v410.dart';
import '../lib/screens/wealth_review_panel_v409.dart';
import '../lib/screens/wealth_detail_panel_v410.dart';
import '../tool/verify_wealth_topic_v409.dart' show fixture409;

void main() {
  final chart = fixture409(4, [235, 115, 156, 242, 189, 280, 176, 75, 255]);
  final report = WealthTopic409.evaluate(chart);
  final data = report.detail!;
  Widget page({double scale = 1}) => MaterialApp(
    home: Scaffold(
      body: MediaQuery(
        data: MediaQueryData(textScaler: TextScaler.linear(scale)),
        child: SingleChildScrollView(
          child: WealthReviewPanel409(report: report),
        ),
      ),
    ),
  );
  test('original levels not replaced by single mixed grade', () {
    expect(
      data.sections.singleWhere((s) => s.key == 'levels').checks.length,
      4,
    );
    expect(
      data.sections.map((s) => s.key),
      containsAll([
        'levels',
        'yogas',
        'forms',
        'people',
        'loss',
        'periods',
        'goelhora',
        'goellabha',
        'activation',
        'mahavastu',
      ]),
    );
    expect(data.provenance, WealthAnalysis410.provenance);
  });
  testWidgets('all detailed wealth sections open source and examination', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(700, 1400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    for (final s in data.sections) {
      await tester.pumpWidget(page());
      await tester.pumpAndSettle();
      final title = find.descendant(
        of: find.byKey(ValueKey('wealth-section-open-410-${s.key}')),
        matching: find.text(s.title),
      );
      await tester.ensureVisible(title);
      await tester.pumpAndSettle();
      await tester.tap(title);
      await tester.pumpAndSettle();
      expect(
        find.byKey(ValueKey('wealth-section-detail-410-${s.key}')),
        findsOneWidget,
      );
      final row = find.byKey(
        ValueKey('wealth-source-row-410-${s.key}-${s.checks.first.id}'),
      );
      final outer = find
          .descendant(
            of: find.byKey(ValueKey('wealth-section-detail-410-${s.key}')),
            matching: find.byWidgetPredicate(
              (w) => w is Scrollable && w.axisDirection == AxisDirection.down,
            ),
          )
          .first;
      await tester.scrollUntilVisible(
        row,
        350,
        scrollable: outer,
        maxScrolls: 70,
      );
      expect(
        find.descendant(
          of: row,
          matching: find.text('రూల్: ${s.checks.first.condition}'),
        ),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: row,
          matching: find.text('మూలం: ${s.checks.first.source}'),
        ),
        findsOneWidget,
      );
      expect(
        find.descendant(
          of: row,
          matching: find.text(
            '${s.checks.first.id} — ${s.statusFor(s.checks.first)}',
          ),
        ),
        findsOneWidget,
      );
      if (s.sourceOnly) {
        expect(
          find.descendant(
            of: row,
            matching: find.text('జాతక పరిశీలన: ${s.checks.first.evidence}'),
          ),
          findsNothing,
        );
        expect(
          find.descendant(
            of: row,
            matching: find.text('మూల వివరణ: ${s.checks.first.evidence}'),
          ),
          findsOneWidget,
        );
      }
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
    }
  });
  testWidgets('320px Telugu large text wealth summary wraps', (tester) async {
    tester.view.physicalSize = const Size(320, 1400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(page(scale: 1.8));
    await tester.pumpAndSettle();
    expect(find.byType(WealthDetailPanel410), findsOneWidget);
    expect(find.byKey(const ValueKey('wealth-counts-410')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
