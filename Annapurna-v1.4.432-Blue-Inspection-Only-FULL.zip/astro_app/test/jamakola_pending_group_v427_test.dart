import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jamakola_rule_engine.dart';

void main() {
  test('Eight Gowri alternatives are one missing evidence group', () {
    const periods = [
      'Uthiyogam', 'Amirtham', 'Rogam', 'Laabam',
      'Dhanam', 'Shubam', 'Choram', 'Visham',
    ];
    final rules = <JamakolaRule>[
      for (var i = 0; i < periods.length; i++)
        JamakolaRule('JA-GOWRI-${(i + 1).toString().padLeft(2, '0')}',
            'gowri', 'Additional evidence', 'source', '1',
            {'gowri_period': periods[i]}),
    ];

    final groups = JamakolaRuleEngine.groupPendingByMissingFacts(rules, {});
    expect(groups.length, 1);
    expect(groups['gowri_period']?.length, 8);
    expect(JamakolaRuleEngine.matching(rules, {}, module: 'gowri'), isEmpty);

    const manualFact = {'gowri_period': 'Shubam'};
    expect(JamakolaRuleEngine.matching(rules, manualFact).length, 1);
    expect(JamakolaRuleEngine.matching(rules, manualFact).single.id,
        'JA-GOWRI-06');
    expect(JamakolaRuleEngine.groupPendingByMissingFacts(rules, manualFact),
        isEmpty);
  });

  test('Distinct missing evidence types remain separate groups', () {
    const rules = <JamakolaRule>[
      JamakolaRule('A', 'career_business', 'A', 'source', '1',
          {'saturn_dignity': 'exalted'}),
      JamakolaRule('B', 'career_business', 'B', 'source', '1',
          {'approaching_udhayam': 'Moon'}),
    ];
    final groups = JamakolaRuleEngine.groupPendingByMissingFacts(rules, {});
    expect(groups.keys, containsAll(['saturn_dignity', 'approaching_udhayam']));
    expect(groups.length, 2);
  });

  test('Known neutral Saturn does not create a missing fact warning', () {
    const rules = <JamakolaRule>[
      JamakolaRule('JA-CAREER-01', 'career_business', 'A', 'source', '1',
          {'saturn_dignity': 'debilitated'}),
      JamakolaRule('JA-CAREER-02', 'career_business', 'B', 'source', '1',
          {'saturn_dignity': 'exalted'}),
    ];
    const knownNeutralSaturn = {'saturn_dignity': 'neutral'};
    expect(JamakolaRuleEngine.groupPendingByMissingFacts(rules, knownNeutralSaturn),
        isEmpty);
    expect(JamakolaRuleEngine.matching(rules, knownNeutralSaturn), isEmpty);
  });
}
