import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/bala_summary_v414.dart';
import '../lib/models/birth_data.dart';
import '../lib/screens/gem_bala_summary_v414.dart';
import '../tool/verify_wealth_topic_v409.dart' show fixture409;

class MemoryBalaStorage implements BalaStorage414 {
  final values = <String, String>{};
  @override
  Future<String?> read(String key) async => values[key];
  @override
  Future<void> write(String key, String value) async {
    values[key] = value;
  }
}

void main() {
  final chart = fixture409(4, [235, 115, 156, 242, 189, 280, 176, 75, 255]);
  final birth = BirthData(
    name: 'Bala UI',
    localDateTime: DateTime(1981, 12, 15, 15, 50),
    place: 'Dachepalle',
    latitude: 16.593221,
    longitude: 79.736383,
    timezoneOffsetHours: 5.5,
    ayanamsa: AyanamsaType.lahiri,
  );
  Widget page(MemoryBalaStorage store, {double scale = 1}) => MaterialApp(
    home: Scaffold(
      body: MediaQuery(
        data: MediaQueryData(textScaler: TextScaler.linear(scale)),
        child: SingleChildScrollView(
          child: GemBalaSummary414(
            chart: chart,
            birth: birth,
            storage: store,
            autoCalculator: (_, __) async => null,
          ),
        ),
      ),
    ),
  );
  testWidgets(
    'three groups have correct domains, missing shadbala stays unknown',
    (tester) async {
      final store = MemoryBalaStorage();
      await tester.pumpWidget(page(store));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('bala-bar-vimsopaka-Rahu-414')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('bala-bar-shadbala-Rahu-414')),
        findsNothing,
      );
      expect(
        find.byKey(const ValueKey('bala-bar-bhava-12-414')),
        findsOneWidget,
      );
      expect(
        find.text('గణనకు సమాచారం లేదు — ధృవీకరించిన రూపాలు నమోదు చేయండి'),
        findsNWidgets(2),
      );
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'verified totals load with correct ratios and persist across remount',
    (tester) async {
      final store = MemoryBalaStorage();
      store.values[BalaSummary414.chartKey(chart, birth)] = const BalaInput414(
        shadbala: {'Sun': 6.37, 'Moon': 9.48},
        bhava: {11: 10.81},
        source: 'Test report',
      ).encode();
      await tester.pumpWidget(page(store));
      await tester.pumpAndSettle();
      final bar = find.byKey(const ValueKey('bala-bar-shadbala-Moon-414'));
      expect(
        find.descendant(of: bar, matching: find.text('158.0%')),
        findsOneWidget,
      );
      await tester.pumpWidget(const SizedBox());
      await tester.pumpWidget(page(store));
      await tester.pumpAndSettle();
      expect(
        find.descendant(of: bar, matching: find.text('158.0%')),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('320px large Telugu type does not overflow', (tester) async {
    tester.view.physicalSize = const Size(320, 1400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(page(MemoryBalaStorage(), scale: 1.8));
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('gem-bala-summary-414')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('entered rupas save with source for the current chart', (
    tester,
  ) async {
    final store = MemoryBalaStorage();
    await tester.pumpWidget(page(store));
    await tester.pumpAndSettle();
    final expand = find.text('షడ్బలం / భావబలం విలువలు నమోదు');
    await tester.ensureVisible(expand);
    await tester.tap(expand);
    await tester.pumpAndSettle();
    final source = find.byKey(const ValueKey('bala-source-414'));
    await tester.ensureVisible(source);
    await tester.enterText(source, 'Verified test report');
    final sun = find.byKey(const ValueKey('bala-shad-Sun-414'));
    await tester.ensureVisible(sun);
    await tester.enterText(sun, '6.37');
    final save = find.byKey(const ValueKey('bala-save-414'));
    await tester.ensureVisible(save);
    await tester.tap(save);
    await tester.pumpAndSettle();
    final saved = BalaInput414.decode(
      store.values[BalaSummary414.chartKey(chart, birth)],
    );
    expect(saved.shadbala['Sun'], 6.37);
    expect(saved.source, 'Verified test report');
    expect(saved.bhava, isEmpty);
    expect(tester.takeException(), isNull);
  });
}
