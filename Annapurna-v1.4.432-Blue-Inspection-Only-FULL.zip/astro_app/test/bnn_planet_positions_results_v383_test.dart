import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/screens/bnn_master_panel.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final birth = BirthData(
    name: 'planet-results-fixture',
    localDateTime: DateTime(1981, 12, 15, 15, 50),
    place: 'fixture',
    latitude: 16.593221,
    longitude: 79.736383,
    timezoneOffsetHours: 5.5,
    ayanamsa: AyanamsaType.lahiri,
  );
  AstroChartResult chart({double moon = 115.1369}) => AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 4,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.0,
        'Moon': moon,
        'Mars': 156.1172,
        'Mercury': 242.4142,
        'Jupiter': 189.8097,
        'Venus': 280.4494,
        'Saturn': 176.7767,
        'Rahu': 75.0,
        'Ketu': 255.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: e.key == 'Rahu' || e.key == 'Ketu' ? -0.1 : 1,
        ),
    ],
  );
  Future<void> show(WidgetTester tester, AstroChartResult value) async {
    // Start platform asset/isolate work in the real async zone. Wait for the
    // output under test, rather than global animation idleness: other panels
    // can have an indeterminate progress indicator while their assets load.
    await tester.runAsync(() async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: BnnMasterPanel(chart: value, birthData: birth),
            ),
          ),
        ),
      );
      final moonRule =
          value.planets.firstWhere((p) => p.name == 'Moon').longitude < 60
          ? '009'
          : '023';
      final expected = find.byKey(
        ValueKey('bnn-result-highlight-BNN-RASHI-$moonRule'),
      );
      for (var attempt = 0; attempt < 250; attempt++) {
        await Future<void>.delayed(const Duration(milliseconds: 20));
        await tester.pump(const Duration(milliseconds: 20));
        if (expected.evaluate().length == 1 &&
            find
                    .byKey(const ValueKey('bnn-three-results-Ketu'))
                    .evaluate()
                    .length ==
                1) {
          return;
        }
      }
      fail(
        'Nine-planet results did not finish loading within five seconds; '
        'expected Moon source rule $moonRule.',
      );
    });
    await tester.pump(const Duration(milliseconds: 300));
  }

  testWidgets(
    'position panel contains actual source results, not a detached duplicate',
    (tester) async {
      await show(tester, chart());
      final section = find.byKey(
        const ValueKey('bnn-nine-planet-house-positions'),
      );
      expect(section, findsOneWidget);
      expect(find.text('అన్ని 9 గ్రహాలు — స్థానాలు & ఫలితాలు'), findsOneWidget);
      for (final entry in {
        'Moon': '023',
        'Mars': '038',
        'Mercury': '060',
        'Jupiter': '047',
        'Venus': '069',
      }.entries) {
        final planet = find.byKey(ValueKey('bnn-three-results-${entry.key}'));
        expect(planet, findsOneWidget);
        expect(find.descendant(of: section, matching: planet), findsOneWidget);
        expect(
          find.descendant(
            of: planet,
            matching: find.byKey(
              ValueKey('bnn-result-highlight-BNN-RASHI-${entry.value}'),
            ),
          ),
          findsOneWidget,
        );
      }
      final moon = find.byKey(
        const ValueKey('bnn-result-highlight-BNN-RASHI-023'),
      );
      await tester.ensureVisible(moon);
      await tester.tap(moon);
      await tester.pump(const Duration(milliseconds: 300));
      expect(find.text('1. రూల్ — BNN-RASHI-023'), findsOneWidget);
      expect(find.text('పరిహారం'), findsWidgets);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'changing Moon sign replaces the matched result in the same card',
    (tester) async {
      await show(tester, chart());
      expect(
        find.byKey(const ValueKey('bnn-result-highlight-BNN-RASHI-023')),
        findsOneWidget,
      );
      await show(tester, chart(moon: 35));
      final section = find.byKey(
        const ValueKey('bnn-nine-planet-house-positions'),
      );
      expect(
        find.descendant(
          of: section,
          matching: find.byKey(
            const ValueKey('bnn-result-highlight-BNN-RASHI-023'),
          ),
        ),
        findsNothing,
      );
      expect(
        find.descendant(
          of: section,
          matching: find.byKey(
            const ValueKey('bnn-result-highlight-BNN-RASHI-009'),
          ),
        ),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    },
  );
}
