import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_master_inspection_service.dart';
import 'package:astro_app/astrology/varga_service.dart';

PlanetPosition p(String name, double longitude) => PlanetPosition(
  name: name, shortName: name.substring(0, 2),
  longitude: longitude, latitude: 0, speed: 1,
);
AstroChartResult sample() => AstroChartResult(
  julianDay: 2450000, ayanamsaDegrees: 24,
  ascendantLongitude: 15,
  engineVersion: 'test',
  planets: [
    p('Sun', 125), p('Moon', 42), p('Mars', 95),
    p('Mercury', 62), p('Jupiter', 245),
    p('Venus', 32), p('Saturn', 275),
    p('Rahu', 305), p('Ketu', 125),
  ],
);

void main() {
  test('all sixteen vargas have their own lagna and relevant subject audit', () {
    for (final definition in VargaService.definitions) {
      final audit = VargaMasterInspectionService.inspect(sample(), definition.factor);
      expect(audit.chart.definition.factor, definition.factor);
      expect(audit.lagna.number, 1);
      expect(audit.lagna.signals, isNotEmpty);
      expect(audit.subjects, isNotEmpty);
      expect(audit.subjects.every((s) => s.number != 1), isTrue);
    }
  });

  test('D2 checks income and retention as distinct 2H/11H/12H questions', () {
    final audit = VargaMasterInspectionService.inspect(sample(), 2);
    expect(audit.subjects.map((s) => s.number).toList(), [2, 11, 12]);
  });

  test('D10 audits work, service, partnership, income and gains separately', () {
    final audit = VargaMasterInspectionService.inspect(sample(), 10);
    expect(audit.subjects.map((s) => s.number).toList(),
        [10, 6, 7, 2, 11]);
    expect(audit.overallEvidenceVerdict, isNot(contains('ఉద్యోగం వస్తుంది')));
    expect(audit.overallSupports, greaterThanOrEqualTo(0));
    expect(audit.overallChallenges, greaterThanOrEqualTo(0));
  });

  test('overall verdict is mixed when separate houses conflict', () {
    final audit = VargaMasterInspection(
      chart: VargaMasterInspectionService.inspect(sample(), 10).chart,
      lagna: VargaHouseInspection(number: 1, title: 'లగ్నం', lord: 'Moon',
          lordHouse: 10, signals: const [
            VargaInspectionSignal('TEST-POSITIVE', 'అనుకూలం', 'test',
                VargaInspectionTone.supportive),
          ]),
      subjects: [VargaHouseInspection(number: 6, title: 'సేవ',
          lord: 'Jupiter', lordHouse: 8, signals: const [
            VargaInspectionSignal('TEST-NEGATIVE', 'ఆటంకం', 'test',
                VargaInspectionTone.challenging),
          ])],
      warning: 'test',
    );
    expect(audit.overallEvidenceVerdict, contains('రెండూ ఉన్నాయి'));
    expect(audit.overallSupports, 1);
    expect(audit.overallChallenges, 1);
  });

  test('D24 uses four educational level houses', () {
    final audit = VargaMasterInspectionService.inspect(sample(), 24);
    expect(audit.subjects.map((s) => s.number).toList(), [4, 9, 2, 7]);
  });

  test('Parashari drishti: Mars 4/7/8, Jupiter 5/7/9, Saturn 3/7/10', () {
    expect(VargaMasterInspectionService.grahaAspects('Mars', 0, 3), isTrue);
    expect(VargaMasterInspectionService.grahaAspects('Jupiter', 0, 8), isTrue);
    expect(VargaMasterInspectionService.grahaAspects('Saturn', 0, 9), isTrue);
    expect(VargaMasterInspectionService.grahaAspects('Sun', 0, 6), isTrue);
    expect(VargaMasterInspectionService.grahaAspects('Rahu', 0, 6), isFalse);
    expect(VargaMasterInspectionService.grahaAspects('Mars', 0, 2), isFalse);
  });

  test('sources are user-defined, not invented book pages or definitive denial', () {
    final audit = VargaMasterInspectionService.inspect(sample(), 1);
    expect(audit.warning, contains('కోరిక లేదని తేల్చకూడదు'));
    expect(audit.lagna.signals.every((s) => s.id.startsWith('USER-VARGA-')), isTrue);
    expect(audit.lagna.evidenceVerdict, isNot(contains('ఖచ్చితంగా')));
  });

  test('experimental points are not fabricated if no base yoga is detected', () {
    final sampleChart = sample();
    final noBase = VargaHouseInspection(
      number: 2, title: 'ధనం', lord: 'Venus', lordHouse: 8,
      signals: [const VargaInspectionSignal('USER-VARGA-DUSTHANA-2',
          '6/8/12', 'Test', VargaInspectionTone.challenging, planet: 'Venus')],
    );
    expect(noBase.experimentalIndex, isNull);
    expect(sampleChart.planets, hasLength(9));
  });

  test('same graha counted once, mixed influence cancels in experimental index', () {
    final inspection = VargaHouseInspection(number: 2, title: 'ధనం',
      lord: 'Venus', lordHouse: 9,
      signals: const [
        VargaInspectionSignal('USER-VARGA-WEALTH-2L', 'ధనం', 'test',
            VargaInspectionTone.supportive, planet: 'Venus'),
        VargaInspectionSignal('USER-VARGA-MAITRI-2', 'మైత్రి', 'test',
            VargaInspectionTone.supportive, planet: 'Venus'),
        VargaInspectionSignal('USER-VARGA-DRISHTI-2-Saturn', 'దృష్టి', 'test',
            VargaInspectionTone.challenging, planet: 'Saturn'),
        VargaInspectionSignal('USER-VARGA-LORD-DRISHTI-2-Saturn', 'దృష్టి', 'test',
            VargaInspectionTone.challenging, planet: 'Saturn'),
      ]);
    expect(inspection.experimentalIndex, 100);
  });

  test('one planet with favorable and challenging links counts as mixed once', () {
    final inspection = VargaHouseInspection(number: 1, title: 'లగ్నం',
      lord: 'Jupiter', lordHouse: 2, signals: const [
        VargaInspectionSignal('P1', 'Venus nature', 'test',
            VargaInspectionTone.supportive, planet: 'Venus'),
        VargaInspectionSignal('P2', 'Venus lordship', 'test',
            VargaInspectionTone.challenging, planet: 'Venus'),
        VargaInspectionSignal('P3', 'Venus duplicate support', 'test',
            VargaInspectionTone.supportive, planet: 'Venus'),
        VargaInspectionSignal('P4', 'Mars', 'test',
            VargaInspectionTone.challenging, planet: 'Mars'),
      ]);
    expect(inspection.mixedCount, 1);
    expect(inspection.supports, 0);
    expect(inspection.challenges, 1);
    expect(inspection.mixed, isTrue);
    expect(inspection.evidenceVerdict, contains('రెండూ ఉన్నాయి'));
  });

  test('Sagittarius ascendant: Venus lordships show 6 AND 11', () {
    final src = sample();
    final chart = AstroChartResult(
      julianDay: src.julianDay,
      ayanamsaDegrees: src.ayanamsaDegrees,
      ascendantLongitude: 254,
      engineVersion: 'test',
      planets: [
        p('Sun', 125), p('Moon', 42), p('Mars', 95),
        p('Mercury', 62), p('Jupiter', 275),
        p('Venus', 252), p('Saturn', 275),
        p('Rahu', 305), p('Ketu', 125),
      ],
    );
    final audit = VargaMasterInspectionService.inspect(chart, 1);
    final venus = audit.lagna.signals.where(
        (s) => s.id == 'USER-VARGA-FUNCTIONAL-1-Venus');
    expect(venus, hasLength(1));
    expect(venus.first.evidence, contains('6, 11'));
    expect(audit.lagna.mixedCount, greaterThanOrEqualTo(1));
  });

  test('different D16 methods change panel calculations without changing source', () {
    final p = VargaMasterInspectionService.inspect(sample(), 16,
        d16Method: D16CalculationMethod.phaladeepika);
    final q = VargaMasterInspectionService.inspect(sample(), 16,
        d16Method: D16CalculationMethod.parashara);
    expect(p.chart.definition.factor, 16);
    expect(q.chart.definition.factor, 16);
  });
}
