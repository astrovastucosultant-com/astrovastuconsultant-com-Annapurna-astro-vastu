import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/goel_transit_support_v375.dart';
import 'package:astro_app/screens/bnn_financial_timing_panel_v374.dart';

void main() {
  testWidgets(
    'score tap reveals source, whole-rule status and inspection without Material errors',
    (tester) async {
      const support = GoelTransitSupport(2, [
        GoelTransitCheck(
          id: 'GOEL-85',
          title: 'సంఘటన సంబంధం',
          pdfPage: 1,
          adverse: false,
          state: GoelTransitState.matched,
          inspection: 'fixture source OR inspection',
        ),
        GoelTransitCheck(
          id: 'GOEL-86',
          title: 'ప్రతికూల సూచన',
          pdfPage: 5,
          adverse: true,
          state: GoelTransitState.unmatched,
          inspection: 'fixture adverse inspection',
        ),
      ]);
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: GoelTransitSupportCardV375(support: support),
            ),
          ),
        ),
      );
      expect(find.text('శని సంఘటన సంబంధం: 100%'), findsOneWidget);
      expect(find.text('శని ప్రతికూల సూచన: 0%'), findsOneWidget);
      await tester.tap(find.text('శని సంఘటన సంబంధం: 100%'));
      await tester.pumpAndSettle();
      expect(find.textContaining('GOEL-85 • వర్తించింది'), findsOneWidget);
      expect(find.textContaining('PDF పేజీ 1'), findsOneWidget);
      expect(
        find.textContaining('fixture source OR inspection'),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('missing source input displays no fabricated zero percent', (
    tester,
  ) async {
    const support = GoelTransitSupport(2, [
      GoelTransitCheck(
        id: 'GOEL-85',
        title: 'సంఘటన సంబంధం',
        pdfPage: 1,
        adverse: false,
        state: GoelTransitState.missing,
        inspection: 'missing lord',
      ),
    ]);
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(body: GoelTransitSupportCardV375(support: support)),
      ),
    );
    expect(find.text('శని సంఘటన సంబంధం: సమాచారం లేదు'), findsOneWidget);
    expect(find.textContaining('0%'), findsNothing);
    expect(tester.takeException(), isNull);
  });
}
