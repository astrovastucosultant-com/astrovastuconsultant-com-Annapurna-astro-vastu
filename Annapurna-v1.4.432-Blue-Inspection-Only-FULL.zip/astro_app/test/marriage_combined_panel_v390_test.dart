import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/ashtakavarga_service.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/screens/av_topic_panel_v387.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 273.36484915140517,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 242.66941561584002,
        'Moon': 212.8451659325558,
        'Mars': 81.92133071214553,
        'Mercury': 111.69508954541985,
        'Jupiter': 326.9409425503614,
        'Venus': 323.8766700256278,
        'Saturn': 352.9762879641361,
        'Rahu': 139.0797836412466,
        'Ketu': 319.0797836412466,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final birth = BirthData(
    name: 'fixture',
    localDateTime: DateTime(1981, 12, 15),
    place: 'fixture',
    latitude: 16,
    longitude: 80,
    timezoneOffsetHours: 5.5,
    ayanamsa: AyanamsaType.lahiri,
    gender: BirthGender.male,
  );
  final tr = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 0,
    engineVersion: 'fixture',
    planets: [
      for (final name in ['Jupiter', 'Saturn'])
        PlanetPosition(
          name: name,
          shortName: name,
          longitude: 91,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  Future<void> select(WidgetTester t, Finder field, String text) async {
    await t.ensureVisible(field);
    await t.pumpAndSettle();
    await t.tap(field);
    await t.pumpAndSettle();
    await t.tap(find.text(text).last);
    await t.pumpAndSettle();
  }

  testWidgets(
    'AV marriage choice uses joined source/dasha/transit, not SAV verdict',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: AvTopicPanel387(
                chart: chart,
                birth: birth,
                av: AshtakavargaService.calculate(chart),
                asOf: DateTime(2026, 11, 13),
                transitLoader: (_) => Future.value(tr),
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await select(
        tester,
        find.byKey(const ValueKey('av-topic-picker-387')),
        'వివాహం / భాగస్వామ్యం',
      );
      expect(find.byKey(const ValueKey('av-result-marriage')), findsNothing);
      await select(
        tester,
        find.byKey(const ValueKey('marriage-context-390')),
        'అవివాహిత',
      );
      expect(find.text('వివాహ కాల అనుకూలత — మంచి'), findsOneWidget);
      final result = find.byKey(
        const ValueKey('marriage-combined-result-opportunity'),
      );
      await tester.ensureVisible(result);
      await tester.pumpAndSettle();
      await tester.tap(result);
      await tester.pumpAndSettle();
      expect(find.textContaining('C02-02'), findsWidgets);
      expect(find.textContaining('దశ + గోచార సంబంధం ఉంది'), findsWidgets);
      expect(
        find.textContaining('ఈ సంఖ్య ఒక్కటే పై తీర్పును నిర్ణయించదు'),
        findsOneWidget,
      );
      await select(
        tester,
        find.byKey(const ValueKey('marriage-context-390')),
        'వివాహిత',
      );
      expect(
        find.byKey(const ValueKey('marriage-combined-result-quality')),
        findsOneWidget,
      );
      expect(find.text('వివాహ కాల అనుకూలత — మంచి'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
}
