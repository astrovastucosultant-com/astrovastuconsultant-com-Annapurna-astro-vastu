import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_life_event_timing_service.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/screens/bnn_life_events_panel.dart';
import 'package:flutter/material.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  PlanetPosition planet(String n, int sign, double d) => PlanetPosition(
    name: n,
    shortName: n,
    longitude: sign * 30.0 + d,
    latitude: 0,
    speed: 1,
  );
  AstroChartResult chart() => AstroChartResult(
    julianDay: 2460000,
    ayanamsaDegrees: 24,
    ascendantLongitude: 78.5,
    planets: [
      planet('Jupiter', 0, 1),
      planet('Saturn', 0, 8),
      planet('Rahu', 0, 12),
      planet('Mercury', 0, 17),
      planet('Sun', 0, 3),
    ],
    engineVersion: 'v370-test',
  );

  test('29 events remain review metadata with no fabricated timing', () async {
    final definitions = await BnnLifeEventTimingService.loadCatalog();
    expect(definitions.length, 29);
    expect(definitions.every((e) => e.sourceStatus == 'METHOD_ONLY'), isTrue);
    final reviews = await BnnLifeEventTimingService.build(
      chart: chart(),
      maximumAge: 100,
    );
    expect(
      reviews.every((r) => r.hasVerifiedIndividualEventTiming == false),
      isTrue,
    );
    expect(reviews.every((r) => r.hasConfirmedEventAge == false), isTrue);
    expect(
      reviews.every((r) => r.evidenceGate.readyForTimingReview == false),
      isTrue,
    );
  });

  test('editorial age focus excludes infant higher education and very late career change', () async {
    final reviews = await BnnLifeEventTimingService.build(
      chart: chart(),
      maximumAge: 100,
    );
    final higher = reviews.firstWhere((r) => r.event.id == 'EDU-HIGHER');
    expect(higher.event.reviewAgeFrom, 12);
    expect(higher.displayReviewContacts.every((x) => x.ageTo > 12), isTrue);
    expect(higher.candidates.any((x) => x.ageFrom == 0), isTrue);
    final career = reviews.firstWhere((r) => r.event.id == 'CAREER-CHANGE');
    expect(career.event.reviewAgeTo, 85);
    expect(career.displayReviewContacts.every((x) => x.ageFrom < 85), isTrue);
  });

  test('missing independent rule / varga / dasha / transit prevents event timing review', () {
    const pending = BnnLifeEventEvidenceGate.pending(eventId: 'EDU-HIGHER');
    expect(
      pending.missingChecks,
      containsAll([
        'EVENT_SOURCE_RULE',
        'NATAL_VARGA_MATCH',
        'DASHA_MATCH',
        'REAL_TRANSIT_MATCH',
      ]),
    );
    expect(pending.readyForTimingReview, isFalse);
    const partial = BnnLifeEventEvidenceGate(
      eventId: 'CAREER-ENTRY',
      sourceRuleId: 'a',
      natalAndVargaMatchId: 'b',
      dashaMatchId: 'c',
    );
    expect(partial.readyForTimingReview, isFalse);
    const all = BnnLifeEventEvidenceGate(
      eventId: 'CAREER-ENTRY',
      sourceRuleId: 'a',
      natalAndVargaMatchId: 'b',
      dashaMatchId: 'c',
      actualTransitMatchId: 'd',
    );
    expect(
      all.readyForTimingReview,
      isTrue,
    ); // review only, NOT certain outcome
    const sensitive = BnnLifeEventEvidenceGate(
      eventId: 'LONGEVITY',
      isSensitive: true,
      sourceRuleId: 'a',
      natalAndVargaMatchId: 'b',
      dashaMatchId: 'c',
      actualTransitMatchId: 'd',
    );
    expect(sensitive.readyForTimingReview, isFalse);
  });

  testWidgets(
    'event ages are not shown as a final result; raw contact ages are collapsed',
    (tester) async {
      // Complete asset IO outside the fake animation clock before asserting UI.
      final loadedReviews = await tester.runAsync(
        () => BnnLifeEventTimingService.build(chart: chart()),
      );
      expect(loadedReviews, isNotNull);
      final screen = BnnLifeEventsPanel(chart: chart(),
        reviewFuture: Future<List<BnnLifeEventReview>>.value(loadedReviews!));
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(body: SingleChildScrollView(child: screen)),
        ),
      );
      await tester.tap(find.text('జీవిత సంఘటనలు • వయస్సుల పరిశీలన'));
      await tester.pumpAndSettle();
      expect(find.byType(CircularProgressIndicator), findsNothing);
      expect(find.textContaining('గ్రహస్పర్శ వయస్సు'), findsNothing);
      // The top-level engine does not claim a confirmed event time.
      expect(find.textContaining('సంఘటన సమయం పెండింగ్'), findsWidgets);
      expect(find.textContaining('సంఘటన సమయం: 0–1'), findsNothing);
    },
  );
}
