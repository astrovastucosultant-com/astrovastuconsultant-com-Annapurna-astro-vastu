import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_financial_evidence_v373.dart';
import 'package:astro_app/astrology/bnn_financial_timing_v374.dart';
import 'package:astro_app/screens/bnn_financial_timing_panel_v374.dart';

void main() {
  FinancialTimingResult result() => FinancialTimingResult(
    eventId: 'WEALTH',
    periodsExamined: 2,
    checkpointsExamined: 3,
    rulesWithoutPlanets: const {},
    windows: [
      FinancialTimingWindow(
        periodStart: DateTime(2020),
        periodEnd: DateTime(2021),
        sampledLocal: DateTime(2020, 2, 15),
        maha: 'Sun',
        antar: 'Mercury',
        jupiterSign: 4,
        saturnSign: 4,
        links: const [
          FinancialRuleTimingLink(
            ruleId: 'D2-IN-007',
            tone: BnnFinancialTone.favorable,
            sourcePlanets: {'Sun', 'Mercury', 'Ketu'},
            activePlanets: {'Sun', 'Mercury'},
            transitTargets: {'Sun': 4},
          ),
        ],
      ),
    ],
  );
  testWidgets(
    'timing loads on demand and shows source dasha and true checkpoint label',
    (tester) async {
      var calls = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: BnnFinancialTimingPanelV374(
                load: () async {
                  calls++;
                  return result();
                },
              ),
            ),
          ),
        ),
      );
      expect(calls, 0);
      await tester.tap(find.byKey(const ValueKey('financial-run-timing')));
      await tester.pumpAndSettle();
      expect(calls, 1);
      expect(find.text('రవి మహాదశ / బుధుడు అంతర్దశ'), findsOneWidget);
      expect(find.text('గోచార మద్దతు నమూనా తేదీ: 15-02-2020'), findsOneWidget);
      expect(find.textContaining('D2-IN-007'), findsOneWidget);
      expect(find.textContaining('ఖచ్చిత సంఘటన తేదీలు కావు'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('failed calculation can retry without caching the failure', (
    tester,
  ) async {
    var calls = 0;
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: BnnFinancialTimingPanelV374(
              load: () async {
                if (++calls == 1) throw StateError('mock unavailable');
                return result();
              },
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.byKey(const ValueKey('financial-run-timing')));
    await tester.pumpAndSettle();
    expect(find.textContaining('గోచార గణన పూర్తి కాలేదు'), findsOneWidget);
    await tester.tap(find.text('మళ్లీ పరిశీలించండి'));
    await tester.pumpAndSettle();
    expect(calls, 2);
    expect(
      find.byKey(const ValueKey('financial-timing-counts')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
}
