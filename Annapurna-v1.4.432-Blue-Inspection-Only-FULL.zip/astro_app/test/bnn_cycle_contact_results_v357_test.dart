import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_cycle_result_service.dart';
import 'package:astro_app/astrology/bnn_jupiter_cycle_service.dart';
import 'package:astro_app/astrology/bnn_saturn_cycle_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const chart=AstroChartResult(
    julianDay:2460000,ayanamsaDegrees:24,ascendantLongitude:78.8,
    engineVersion:'cycle-reading-test', planets:[
      PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245.25,latitude:0,speed:-1),
      PlanetPosition(name:'Saturn',shortName:'Sa',longitude:54.89,latitude:0,speed:1),
      PlanetPosition(name:'Venus',shortName:'Ve',longitude:71.87,latitude:0,speed:1),
      PlanetPosition(name:'Rahu',shortName:'Ra',longitude:272.3,latitude:0,speed:-1),
      PlanetPosition(name:'Mercury',shortName:'Me',longitude:108.4,latitude:0,speed:1),
    ]);

  test('BNN cycle catalog has nine unique graha mappings',() async {
    final catalog=await BnnCycleResultService.load();
    expect(catalog.contacts.length,9);
    expect(catalog.contacts['Venus']!['topics_te'],contains('వివాహం'));
  });

  test('Jupiter cycle 2 age 18 Venus has interpretation, not a classical rule',() async {
    final catalog=await BnnCycleResultService.load();
    final cycles=BnnJupiterCycleService.calculate(chart:chart,
      themes:await BnnJupiterCycleService.loadThemes());
    final year=cycles[1].years[6];
    expect(year.ageStart,18);
    expect(year.natalSignContacts.map((p)=>p.name),contains('Venus'));
    final out=BnnCycleResultService.forJupiter(cycle:year.cycle,
      ageStart:year.ageStart,natalContacts:year.natalSignContacts,
      catalog:catalog,roundTopic:cycles[1].theme.traditionalFocus);
    expect(out.any((x)=>x.result.contains('వివాహం')),isTrue);
    expect(out.every((x)=>!x.isSourceRule),isTrue);
    expect(out.any((x)=>x.id.contains('C02-AGE018')),isTrue);
  });

  test('Jupiter cycle 8 yields topic only without fictional round result',() async {
    final catalog=await BnnCycleResultService.load();
    final cycles=BnnJupiterCycleService.calculate(chart:chart,
      themes:await BnnJupiterCycleService.loadThemes());
    expect(cycles[7].theme.traditionalFocus,isNull);
    final y=cycles[7].years[6];
    final out=BnnCycleResultService.forJupiter(cycle:y.cycle,ageStart:y.ageStart,
      natalContacts:y.natalSignContacts,catalog:catalog);
    expect(out.every((x)=>!x.isSourceRule),isTrue);
    expect(out.first.result,contains('వివాహం'));
    expect(out.first.result.contains('సైకిల్ పరిశీలన అంశం'),isFalse);
  });

  test('Saturn round 1 Rahu contact shows exact rule; round 2 does not',() async {
    final catalog=await BnnCycleResultService.load();
    final cycles=BnnSaturnCycleService.calculate(chart:chart,
      themes:await BnnSaturnCycleService.loadThemes());
    final first=cycles[0].windows.firstWhere(
      (w)=>w.natalContacts.any((p)=>p.name=='Rahu'));
    final second=cycles[1].windows.firstWhere(
      (w)=>w.natalContacts.any((p)=>p.name=='Rahu'));
    final r1=BnnCycleResultService.forSaturn(cycle:1,ageStart:first.ageStart,
      natalContacts:first.natalContacts,catalog:catalog);
    final r2=BnnCycleResultService.forSaturn(cycle:2,ageStart:second.ageStart,
      natalContacts:second.natalContacts,catalog:catalog);
    expect(r1.any((r)=>r.id=='BNN-SAT-R1-RAHU' && r.isSourceRule),isTrue);
    expect(r2.any((r)=>r.id=='BNN-SAT-R1-RAHU'),isFalse);
    expect(r2.every((r)=>!r.isSourceRule),isTrue);
  });

  test('No planet contact means no inferred events',() async {
    final catalog=await BnnCycleResultService.load();
    expect(BnnCycleResultService.forJupiter(cycle:1,ageStart:1,
      natalContacts:const [],catalog:catalog),isEmpty);
    expect(BnnCycleResultService.forSaturn(cycle:1,ageStart:1,
      natalContacts:const [],catalog:catalog),isEmpty);
  });
}
