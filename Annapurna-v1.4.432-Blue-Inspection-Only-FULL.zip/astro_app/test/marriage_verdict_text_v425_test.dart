import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/marriage_verdict_text_v425.dart';

void main() {
  test('rule-level outcomes are favourable, adverse, or undetermined', () {
    expect(MarriageVerdictText425.rule(true), contains('కలిసింది బాగుంది'));
    expect(MarriageVerdictText425.rule(false), contains('అనుకూలము కాదు'));
    expect(MarriageVerdictText425.rule(null), contains('నిర్ణయించలేం'));
  });

  test('overall matching does not invent positive or negative from missing evidence', () {
    expect(MarriageVerdictText425.summary(favourable: 2, adverse: 0), contains('కలిసింది బాగుంది'));
    expect(MarriageVerdictText425.summary(favourable: 0, adverse: 2), contains('అనుకూలము కాదు'));
    expect(MarriageVerdictText425.summary(favourable: 1, adverse: 1), contains('మిశ్రమ ఫలితం'));
    expect(MarriageVerdictText425.summary(favourable: 0, adverse: 0), contains('సరిపోలేదు'));
  });

  test('full PDF report no longer reprints twelve signs for every chart', () {
    final code = File('lib/screens/chart_screen.dart').readAsStringSync();
    expect(code, isNot(contains('MarriageMatchingCharts424.signDetails(pair.first)')));
    expect(code, isNot(contains('MarriageMatchingCharts424.signDetails(pair.second)')));
    expect(code, contains('4. D1, D7, D9, చంద్రలగ్నం — ఇద్దరి జాతక చక్రాలు'));
    final service = File('lib/services/marriage_pdf_report_service.dart').readAsStringSync();
    expect(service, contains('await _renderMatchingCharts(chunk, pageNo)'));
  });
}
