import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/marriage_matching_charts_v424.dart';
import 'package:astro_app/screens/marriage_matching_comparison_v424.dart';
import 'package:astro_app/services/marriage_pdf_report_service.dart';

AstroChartResult _sample(double asc, double moon) => AstroChartResult(
  julianDay: 2451545,
  ayanamsaDegrees: 23,
  ascendantLongitude: asc,
  engineVersion: 'v424-test',
  planets: [
    const PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 16, latitude: 0, speed: 1),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: moon, latitude: 0, speed: 1),
    const PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 95, latitude: 0, speed: 1),
    const PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 184, latitude: 0, speed: 1),
    const PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 250, latitude: 0, speed: -1),
  ],
);

void main() {
  final first = _sample(280, 64); // Moon in Gemini (index 2)
  final second = _sample(80, 192); // Moon in Libra (index 6)

  test('matching shows four distinct systems for both charts', () {
    final rows = MarriageMatchingCharts424.compare(
      firstName: 'వరుడు', first: first,
      secondName: 'వధువు', second: second,
    );
    expect(rows.map((p) => p.code).toList(),
        ['D1', 'D7', 'D9', 'CHANDRA']);
    expect(rows.length * 2, 8);
    for (final factor in [1, 7, 9]) {
      final pair = rows.firstWhere((r) => r.code == 'D$factor');
      expect(pair.first.ascendantSignIndex,
          VargaService.calculate(first, factor).ascendantSignIndex);
      expect(pair.second.ascendantSignIndex,
          VargaService.calculate(second, factor).ascendantSignIndex);
    }
    final chandra = rows.last;
    expect(chandra.first.ascendantSignIndex, 2);
    expect(chandra.second.ascendantSignIndex, 6);
    expect(chandra.first.planets.map((p) => p.signIndex).toList(),
        rows.first.first.planets.map((p) => p.signIndex).toList());
    expect(chandra.second.planets.map((p) => p.signIndex).toList(),
        rows.first.second.planets.map((p) => p.signIndex).toList());
    expect(MarriageMatchingCharts424.signDetails(chandra.first),
        contains('Lg'));
  });

  test('missing Moon never silently invents Chandra ascendant', () {
    final noMoon = AstroChartResult(
      julianDay: 2451545, ayanamsaDegrees: 23,
      ascendantLongitude: 280, engineVersion: 'fixture',
      planets: const [PlanetPosition(name: 'Sun', shortName: 'Su',
          longitude: 16, latitude: 0, speed: 1)],
    );
    expect(MarriageMatchingCharts424.moonLagna(noMoon), isNull);
    expect(MarriageMatchingCharts424.compare(
      firstName: 'A', first: noMoon, secondName: 'B', second: second,
    ).map((r) => r.code), isNot(contains('CHANDRA')));
  });

  testWidgets('matching view renders both people for all four charts', (tester) async {
    tester.view.physicalSize = const Size(390, 1600);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: SingleChildScrollView(
      child: MarriageMatchingComparison424(
        firstName: 'వరుడు', first: first, secondName: 'వధువు', second: second,
      ),
    ))));
    for (final code in ['D1', 'D7', 'D9', 'CHANDRA']) {
      expect(find.byKey(ValueKey('matching-v424-heading-$code')), findsOneWidget);
      expect(find.byKey(ValueKey('matching-v424-$code-first')), findsOneWidget);
      expect(find.byKey(ValueKey('matching-v424-$code-second')), findsOneWidget);
    }
    expect(tester.takeException(), isNull);
  });

  test('PDF includes real chart pages rather than only sign lists', () async {
    final rows = MarriageMatchingCharts424.compare(
      firstName: 'A', first: first, secondName: 'B', second: second,
    );
    final bytes = await MarriagePdfReportService.create(
      'ANNAPURNA ASTRO VASTU\n1. రెండు జాతకాలు\n'
      '3. అష్టకూట పరిశీలన\n4. D1, D7, D9, చంద్రలగ్నం — రెండు చక్రాలు\n'
      '5. మూల నియమ పరిశీలన',
      chartPairs: rows,
    );
    expect(bytes.length, greaterThan(3000));
    expect(String.fromCharCodes(bytes.take(4)), '%PDF');
  });
}
