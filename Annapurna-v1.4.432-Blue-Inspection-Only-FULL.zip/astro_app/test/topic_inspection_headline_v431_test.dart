import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/multi_chart_topic_service.dart';
import 'package:astro_app/screens/topic_inspection_headline_v431.dart';
import 'package:astro_app/screens/topic_result_card_v391.dart';

void main() {
  test('career decisions use D10 primary, never 33% as a job probability', () {
    const business = MultiChartTopicEvidence(
      name: 'వ్యాపారం',
      chartOrderSourceId: 'USER-CAREER-CORE-BUSINESS',
      note: 'D1 D9 support, D10 primary',
      stages: [
        TopicStageEvidence(factor: 1, status: TopicStageStatus.matched,
          ruleIds: ['D10-GOCHARISTA'], polarity: TopicPolarity.supportive),
        TopicStageEvidence(factor: 9, status: TopicStageStatus.notMatched,
          ruleIds: ['D10-GOCHARISTA']),
        TopicStageEvidence(factor: 10,
          status: TopicStageStatus.insufficientEvidence,
          ruleIds: ['D10-GOCHARISTA']),
      ],
    );
    final headline = TopicInspectionHeadline431.from(business);
    expect(headline.title, contains('D10'));
    expect(headline.tone, TopicHeadlineTone431.pending);
    expect(headline.detail, contains('ధృవీకరణ'));
    expect(headline.title, isNot(contains('33%')));
  });

  test('unverified stages never manufacture adverse conclusions', () {
    const topic = MultiChartTopicEvidence(
      name: 'వివాహం', chartOrderSourceId: 'VARGA-CROSS-004', note: '',
      stages: [
        TopicStageEvidence(factor: 9,
          status: TopicStageStatus.insufficientEvidence, ruleIds: []),
        TopicStageEvidence(factor: 7,
          status: TopicStageStatus.notMatched, ruleIds: ['RULE-A']),
      ],
    );
    expect(TopicInspectionHeadline431.from(topic).tone,
      TopicHeadlineTone431.pending);
    expect(TopicInspectionHeadline431.from(topic).detail,
      contains('ప్రతికూలమనే తీర్పు కాదు'));
  });

  test('supportive and adverse fully matched stages are a mixed review', () {
    const topic = MultiChartTopicEvidence(
      name: 'పరీక్ష', chartOrderSourceId: 'fixture-mixed', note: '',
      stages: [
        TopicStageEvidence(factor: 1, status: TopicStageStatus.matched,
          ruleIds: ['A'], polarity: TopicPolarity.supportive),
        TopicStageEvidence(factor: 9, status: TopicStageStatus.matched,
          ruleIds: ['B'], polarity: TopicPolarity.adverse),
      ],
    );
    expect(TopicInspectionHeadline431.from(topic).tone,
      TopicHeadlineTone431.mixed);
  });

  testWidgets('shared source condition is shown once when explicitly opened',
      (tester) async {
    const topic = MultiChartTopicEvidence(
      name: 'వ్యాపారం', chartOrderSourceId: 'USER-CAREER-CORE-BUSINESS',
      note: 'audit', stages: [
        TopicStageEvidence(factor: 1, status: TopicStageStatus.matched,
          ruleIds: ['D10-GOCHARISTA'], polarity: TopicPolarity.supportive,
          ruleText: 'SHARED SOURCE RULE', details: 'D1 inspection',
          result: 'D1 supporting evidence'),
        TopicStageEvidence(factor: 9, status: TopicStageStatus.notMatched,
          ruleIds: ['D10-GOCHARISTA'],
          ruleText: 'SHARED SOURCE RULE', details: 'D9 independent inspection'),
        TopicStageEvidence(factor: 10,
          status: TopicStageStatus.insufficientEvidence,
          ruleIds: ['D10-GOCHARISTA'], ruleText: 'SHARED SOURCE RULE',
          details: 'D10 not verified'),
      ],
    );
    const chart = AstroChartResult(
      julianDay: 2451545, ayanamsaDegrees: 24, ascendantLongitude: 4,
      engineVersion: 'fixture', planets: [
        PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 20,
          latitude: 0, speed: 1),
      ],
    );
    await tester.pumpWidget(const MaterialApp(home: Scaffold(
      body: TopicResultCard391(chart: chart, summary: topic),
    )));
    await tester.tap(find.byKey(const ValueKey('topic-result-USER-CAREER-CORE-BUSINESS')));
    await tester.pumpAndSettle();
    expect(find.text('SHARED SOURCE RULE'), findsNothing);
    final d1 = find.byKey(const ValueKey(
        'topic-stage-v431-USER-CAREER-CORE-BUSINESS-1-0'));
    await tester.ensureVisible(d1);
    await tester.tap(d1);
    await tester.pumpAndSettle();
    expect(find.text('D1 inspection'), findsOneWidget);
    expect(find.text('SHARED SOURCE RULE'), findsNothing);
    final shared = find.byKey(const ValueKey(
        'topic-shared-rules-v431-USER-CAREER-CORE-BUSINESS'));
    await tester.ensureVisible(shared);
    await tester.tap(shared);
    await tester.pumpAndSettle();
    expect(find.text('SHARED SOURCE RULE'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
