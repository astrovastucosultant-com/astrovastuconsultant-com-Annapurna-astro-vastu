import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/screens/bnn_master_panel.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('BNN result-first card reveals source on tap', (tester) async {
    final birth = BirthData(
      name: 'BNN demo',
      localDateTime: DateTime(2000, 1, 1, 12),
      place: 'Guntur',
      latitude: 16.3,
      longitude: 80.4,
      timezoneOffsetHours: 5.5,
      ayanamsa: AyanamsaType.lahiri,
      gender: BirthGender.female,
    );
    const chart = AstroChartResult(
      julianDay: 2460000,
      ayanamsaDegrees: 24,
      ascendantLongitude: 60 + 18 + 47 / 60 + 59 / 3600,
      engineVersion: 'BNN result-first widget fixture',
      planets: [
        PlanetPosition(
          name: 'Saturn', shortName: 'Sa',
          longitude: 54.8869444444, latitude: 0, speed: 0.2,
        ),
      ],
    );

    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: BnnMasterPanel(chart: chart, birthData: birth),
        ),
      ),
    ));
    await tester.pumpAndSettle();

    const effect = 'ఆర్థిక ప్రగతి. విలాస వస్తువులు లేదా ఆర్థిక సంస్థలలో వృత్తి.';
    expect(find.text(effect), findsOneWidget);
    expect(find.text('శని వృషభంలో 24°53′13″ వద్ద ఉన్నందున'), findsOneWidget);
    final highlightFinder = find.byKey(
      const ValueKey('bnn-result-highlight-BNN-RASHI-014'));
    expect(highlightFinder, findsOneWidget);
    final highlighted = tester.widget<Container>(highlightFinder);
    final decoration = highlighted.decoration! as BoxDecoration;
    expect(decoration.color, const Color(0xFFD9F3E0));
    // Rule IDs and the natal calculation are initially hidden.
    expect(find.textContaining('1. రూల్ — BNN-RASHI-014'), findsNothing);
    expect(find.textContaining('జన్మలగ్నం నుంచి 12వ భావం.'), findsNothing);

    await tester.tap(find.text(effect));
    await tester.pumpAndSettle();
    expect(find.textContaining('1. రూల్ — BNN-RASHI-014'), findsOneWidget);
    expect(find.textContaining('జన్మలగ్నం నుంచి 12వ భావం.'), findsOneWidget);
    expect(find.textContaining('BNN మూల స్కాన్: PDF పేజీ 8'), findsOneWidget);
    expect(find.textContaining('శని వృషభ రాశిలో ఉన్నాడు'), findsWidgets);
  });
}
