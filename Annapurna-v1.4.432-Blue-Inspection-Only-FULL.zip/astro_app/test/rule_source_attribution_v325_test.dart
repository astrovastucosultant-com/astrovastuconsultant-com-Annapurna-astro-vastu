import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/rule_source_attribution.dart';

void main() {
  test('collector is not inferred as author from Mallikarjuna PDF', () {
    const info = RuleSourceAttribution(
      suppliedSource: 'Mallikarjuna PDF · పేజీ 11',
    );
    expect(info.verifiedOriginal, isFalse);
    expect(info.originalLine, RuleSourceAttribution.originalPending);
    expect(info.contributorLine, contains('సేకరించి అందించినవారు'));
    expect(info.contributorLine, contains('సిద్ధాంతి మల్లికార్జున'));
    expect(info.sourceLine, contains('పేజీ 11'));
  });

  test('Goel author is not inferred merely from freeform source text', () {
    const info = RuleSourceAttribution(
      suppliedSource: 'V. P. Goel D10 special.pdf • Chapter 2',
    );
    expect(info.verifiedOriginal, isFalse);
    expect(info.originalLine, RuleSourceAttribution.originalPending);
  });

  test('explicitly audited original author book and page can be displayed', () {
    const info = RuleSourceAttribution(
      suppliedSource: 'supplied D10 PDF, internal p. 58',
      verifiedAuthor: 'V. P. Goel',
      verifiedBook: 'Predict with Dashamsha',
      verifiedPrintedPage: '11',
    );
    expect(info.verifiedOriginal, isTrue);
    expect(info.originalLine, contains('V. P. Goel'));
    expect(info.originalLine, contains('ముద్రిత పేజీ: 11'));
  });

  test('missing printed page never auto-verifies authorship', () {
    const info = RuleSourceAttribution(
      verifiedAuthor: 'V. P. Goel',
      verifiedBook: 'Predict with Dashamsha',
    );
    expect(info.verifiedOriginal, isFalse);
  });

  test('self-authorship requires explicit declaration', () {
    const info = RuleSourceAttribution(explicitlyUserAuthored: true);
    expect(info.originalLine, contains('స్వయంగా రచించిన నియమం'));
  });

  test('SOURCE_PENDING is not presented as verified source', () {
    const info = RuleSourceAttribution(suppliedSource: 'SOURCE_PENDING');
    expect(info.hasSuppliedSource, isFalse);
    expect(info.sourceLine, contains('లభించలేదు'));
  });
}
