import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/screens/topic_varga_review_panel.dart';
import '../lib/screens/topic_result_card_v391.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 63,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.0,
        'Moon': 115.1369,
        'Mars': 156.1172,
        'Mercury': 242.4142,
        'Jupiter': 189.8097,
        'Venus': 280.4494,
        'Saturn': 176.7767,
        'Rahu': 75.0,
        'Ketu': 255.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final topics = MultiChartTopicService.summarize(
    chart: chart,
    evaluatedRules: [],
  );
  final summary = topics.singleWhere(
    (s) => s.chartOrderSourceId == 'VARGA-CROSS-010',
  );
  test('marital chart review connects source clauses without probability', () {
    expect(summary.stability, isNotNull);
    expect(summary.stages.map((s) => s.factor), [1, 9, 30]);
    expect(
      summary.stages.every((s) => s.status == TopicStageStatus.matched),
      isTrue,
    );
    expect(summary.confirmationPercent, isNull);
    expect(summary.displayCoverage, contains('దాంపత్య స్థిరత్వం'));
    expect(summary.stages[1].ruleIds, contains('C16-01'));
    expect(summary.stages[2].ruleIds, contains('C12-01'));
    expect(
      summary.stability!.additional
          .singleWhere((c) => c.id == 'C06-01')
          .contextual,
      isTrue,
    );
    expect(topics.singleWhere((s) => s.name == 'విద్య').stability, isNull);
    expect(
      topics.singleWhere((s) => s.name == 'ఆస్తి / వారసత్వం').stability,
      isNull,
    );
  });
  testWidgets(
    'stability result occupies fourth cell and opens source details',
    (tester) async {
      await tester.binding.setSurfaceSize(const Size(400, 2200));
      addTearDown(() => tester.binding.setSurfaceSize(null));
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: summary),
            ),
          ),
        ),
      );
      final card = find.byKey(const ValueKey('marital-stability-v397'));
      final chart30 = find.byKey(
        const ValueKey('topic-chart-VARGA-CROSS-010-30'),
      );
      expect(card, findsOneWidget);
      expect(
        tester.getTopLeft(card).dx,
        greaterThan(tester.getTopLeft(chart30).dx),
      );
      expect(
        tester.getTopLeft(card).dy,
        lessThan(tester.getTopLeft(chart30).dy),
      );
      for (final factor in [1, 9, 30])
        expect(
          find.byKey(
            ValueKey('topic-result-under-chart-VARGA-CROSS-010-$factor'),
          ),
          findsOneWidget,
        );
      await tester.ensureVisible(
        find.byKey(const ValueKey('marital-stability-inspect-v397')),
      );
      await tester.tap(
        find.byKey(const ValueKey('marital-stability-inspect-v397')),
      );
      await tester.pumpAndSettle();
      expect(find.text('సమగ్ర నిర్ణయం ఎలా ఇచ్చాం'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('root result tap shows stability summary', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: TopicResultCard391(chart: chart, summary: summary),
        ),
      ),
    );
    await tester.tap(
      find.byKey(const ValueKey('topic-result-VARGA-CROSS-010')),
    );
    await tester.pumpAndSettle();
    expect(
      find.byKey(const ValueKey('marital-stability-v397')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
  testWidgets('mobile large Telugu text has no overflow', (tester) async {
    await tester.binding.setSurfaceSize(const Size(360, 800));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(1.8)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: summary),
            ),
          ),
        ),
      ),
    );
    expect(tester.takeException(), isNull);
  });
}
