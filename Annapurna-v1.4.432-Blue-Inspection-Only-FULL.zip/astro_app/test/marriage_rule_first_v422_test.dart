import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/screens/marriage_audit_v420.dart';
import 'package:astro_app/astrology/marriage_chrome_if_then_engine.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545.0, ayanamsaDegrees: 24,
    ascendantLongitude: 4, engineVersion: 'v422-fixture',
    planets: const [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 2, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 38, latitude: 0, speed: 1),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 76, latitude: 0, speed: 1),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 122, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 164, latitude: 0, speed: 1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 209, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 240, latitude: 0, speed: 1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 281, latitude: 0, speed: -1),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 101, latitude: 0, speed: -1),
    ],
  );

  test('rule-specific varga routing retains exact source scopes', () {
    MarriageChromeRule lookup(String id) =>
        MarriageChromeIfThenEngine.rules.firstWhere((r) => r.id == id);
    expect(MarriageTopics420.chartFactorsForRule(lookup('C03-02')), [1, 9]);
    expect(MarriageTopics420.chartFactorsForRule(lookup('C02-02')), [7]);
    expect(MarriageTopics420.chartFactorsForRule(lookup('C12-02')), [1, 30]);
    expect(MarriageTopics420.chartFactorsForRule(lookup('C17-05')), [9]);
    expect(MarriageTopics420.chartFactorsForRule(lookup('C06-01')), [7]);
  });

  testWidgets('expanding one marriage rule shows only its charts before IF and examination',
      (tester) async {
    tester.view.physicalSize = const Size(420, 950);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(home: Scaffold(body:
        SingleChildScrollView(child: MarriageTopics420(chart: chart, gender: 'male')))));
    await tester.tap(find.byKey(const ValueKey('marriage-topic-420-0')));
    await tester.pumpAndSettle();
    final rule = find.byKey(const ValueKey('marriage-rule-420-C03-02'));
    await tester.ensureVisible(rule);
    await tester.tap(rule);
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('marriage-rule-chart-C03-02-1')), findsOneWidget);
    expect(find.byKey(const ValueKey('marriage-rule-chart-C03-02-9')), findsOneWidget);
    expect(find.byKey(const ValueKey('marriage-rule-chart-C03-02-7')), findsNothing);
    expect(find.textContaining('1. మూల IF:'), findsWidgets);
    expect(find.textContaining('2. జాతక పరిశీలన:'), findsWidgets);
    expect(tester.takeException(), isNull);
  });
}
