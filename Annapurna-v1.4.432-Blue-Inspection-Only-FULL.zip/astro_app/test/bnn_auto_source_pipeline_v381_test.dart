import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_rashi_rule_service.dart';
import 'package:astro_app/astrology/bnn_unified_evidence_v376.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/screens/bnn_unified_evidence_panel_v376.dart';

void main() {
  final raw = jsonDecode(
    File('assets/bnn/bnn_rashi_84_fresh.json').readAsStringSync(),
  );
  final rule = BnnRashiRule.fromJson(
    (raw['rules'] as List).singleWhere((r) => r['id'] == 'BNN-RASHI-046'),
  );
  final birth = BirthData(
    name: 'pipeline',
    localDateTime: DateTime(1981, 12, 15),
    place: 'fixture',
    latitude: 16,
    longitude: 80,
    timezoneOffsetHours: 5.5,
    ayanamsa: AyanamsaType.lahiri,
  );
  const house = UnifiedEvent376(
    id: 'HOUSE',
    title: 'ఇల్లు',
    mainHouse: 4,
    houses: {4},
    ageFrom: 18,
  );
  AstroChartResult chart(int mercurySign) => AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 24,
    ascendantLongitude: 0,
    engineVersion: 'fixture',
    planets: [
      for (final entry in {
        'Sun': 0,
        'Moon': 3,
        'Mars': 7,
        'Mercury': mercurySign,
        'Jupiter': 0,
        'Venus': 1,
        'Saturn': 2,
        'Rahu': 4,
        'Ketu': 10,
      }.entries)
        PlanetPosition(
          name: entry.key,
          shortName: entry.key,
          longitude: entry.value * 30.0 + 1,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  for (final sign in [6, 5]) {
    testWidgets('full source predicate sign $sign controls automatic result', (
      tester,
    ) async {
      var calls = 0;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: BnnUnifiedEvidencePanel376(
                chart: chart(sign),
                birth: birth,
                catalog: Future.value(const UnifiedCatalog376([house], [])),
                natalRules: Future.value([rule]),
                transitLoader: (_) async {
                  calls++;
                  return const [
                    PlanetPosition(
                      name: 'Saturn',
                      shortName: 'Sa',
                      longitude: 181,
                      latitude: 0,
                      speed: 1,
                    ),
                    PlanetPosition(
                      name: 'Jupiter',
                      shortName: 'Ju',
                      longitude: 211,
                      latitude: 0,
                      speed: 1,
                    ),
                  ];
                },
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.text('BNN — అంశం ఎంచుకొని సూచనలు చూడండి'));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byKey(const ValueKey('bnn-topic-search')),
        'ఇల్లు',
      );
      await tester.pumpAndSettle();
      expect(
        find.textContaining('ఆటో సరిపోలిక • మూల గ్రహం: బుధుడు'),
        sign == 6 ? findsWidgets : findsNothing,
      );
      if (sign == 6)
        expect(calls, greaterThan(0));
      else
        expect(calls, 0);
      expect(find.byType(CheckboxListTile), findsNothing);
      expect(tester.takeException(), isNull);
    });
  }
}
