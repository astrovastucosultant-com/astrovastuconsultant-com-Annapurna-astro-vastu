import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_house_relation_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const chart = AstroChartResult(
    julianDay:2460000, ayanamsaDegrees:24, ascendantLongitude:78.7997,
    engineVersion:'bnn-rg-rao-source-v354', planets:[
      PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245.25,latitude:0,speed:-1),
      PlanetPosition(name:'Venus',shortName:'Ve',longitude:71.87,latitude:0,speed:1),
      PlanetPosition(name:'Saturn',shortName:'Sa',longitude:54.89,latitude:0,speed:1),
    ]);
  test('R.G. Rao Venus seventh relationship matches and retains source', () async {
    final rules=await BnnHouseRelationService.loadVerifiedJupiterRules();
    expect(rules.length,9);
    final venus=rules.singleWhere((x)=>x.id=='BNN-RAO-ESS-P258-JUP-VEN7');
    expect(venus.printedPage,247);
    expect(venus.sourceScope,'case_example');
    expect(venus.sourceUrl,startsWith('https://'));
    final matched=BnnHouseRelationService.evaluateVerifiedJupiterRules(chart:chart,rules:rules);
    expect(matched.map((x)=>x.rule.id),contains('BNN-RAO-ESS-P258-JUP-VEN7'));
    expect(matched.map((x)=>x.rule.id),isNot(contains('BNN-RAO-ESS-P147-JUP-SAT7')));
  });
  test('R.G. Rao Venus case example is not triggered for eighth position', () async {
    final rules=await BnnHouseRelationService.loadVerifiedJupiterRules();
    const alternate=AstroChartResult(julianDay:2460000,ayanamsaDegrees:24,
      ascendantLongitude:78.7997,engineVersion:'bnn-negative-v354',planets:[
        PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245,latitude:0,speed:0.1),
        PlanetPosition(name:'Venus',shortName:'Ve',longitude:95,latitude:0,speed:1),
      ]);
    final matched=BnnHouseRelationService.evaluateVerifiedJupiterRules(chart:alternate,rules:rules);
    expect(matched.map((x)=>x.rule.id),isNot(contains('BNN-RAO-ESS-P258-JUP-VEN7')));
  });
}
