import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/panchanga_natal_phala_service.dart';
import 'package:astro_app/astrology/sunrise_vara_service.dart';
import 'package:astro_app/models/birth_data.dart';

void main() {
  PlanetPosition p(String n,double d)=>PlanetPosition(
    name:n,shortName:n,longitude:d,latitude:0,speed:1);
  BirthData birth({DateTime? local})=>BirthData(name:'test',
    localDateTime:local??DateTime(2026,11,2,5,30),place:'Guntur',
    latitude:16.3,longitude:80.4,timezoneOffsetHours:5.5,
    ayanamsa:AyanamsaType.lahiri);
  AstroChartResult chart(double sun,double moon)=>AstroChartResult(
    julianDay:2460000,ayanamsaDegrees:24,
    ascendantLongitude:0,planets:[
      p('Sun',sun),p('Moon',moon),p('Mars',270),
      p('Mercury',180),p('Jupiter',120),p('Venus',150),
      p('Saturn',90),p('Rahu',240),p('Ketu',60)],
    engineVersion:'test');
  SunriseVaraResult sundayFromMonday()=>SunriseVaraService.resolve(
    birth(),DateTime.utc(2026,11,2,0,30));

  test('Five REAL birth-phala angas, each with classical JP verse',() {
    final a=PanchangaNatalPhalaService.evaluate(chart(0,3),birth(),
      solarWeekday:sundayFromMonday());
    expect(a.length,5);
    expect(a.map((x)=>x.ruleId).toSet().length,5);
    for(final x in a) {
      expect(x.result,contains('జన్మఫల'));
      expect(x.source,contains('Jātaka Pārijāta'));
      expect(x.source,contains('అధ్యాయం 9'));
      expect(x.source,contains('https://'));
      expect(x.evidence,isNotEmpty);
    }
    expect(a[0].ruleId,'JP-9-34-T01');
    expect(a[0].result,contains('కృషిశీలత'));
    expect(a[1].label,contains('ఆదివారం'));
    expect(a[1].evidence,contains('గతరోజు')); 
  });

  test('No sunrise does not pretend civil weekday is the natal weekday', () {
    final a=PanchangaNatalPhalaService.evaluate(chart(0,3),birth());
    expect(a.length,5);
    expect(a[1].ruleId,'JP-9-VARA-UNVERIFIED');
    expect(a[1].label,contains('పెండింగ్'));
    expect(a[1].result,contains('నిర్ధారించలేదు'));
  });

  test('Purnima and Amavasya have different actual birth meanings', () {
    final a=PanchangaNatalPhalaService.evaluate(chart(0,179.9),birth());
    final b=PanchangaNatalPhalaService.evaluate(chart(0,359.9),birth());
    expect(a[0].label,contains('పౌర్ణమి'));
    expect(b[0].label,contains('అమావాస్య'));
    expect(a[0].result,isNot(b[0].result));
    expect(a[0].ruleId,'JP-9-37-T15');
    expect(b[0].ruleId,'JP-9-37-T30');
  });

  test('Each of 27 stars and 27 yogas matches an indexed natal rule', () {
    final stars=<String>{};
    final yogas=<String>{};
    for(var i=0;i<27;i++) {
      final starMoon=(i+.5)*360/27;
      final a=PanchangaNatalPhalaService.evaluate(chart(0,starMoon),birth());
      stars.add(a[2].ruleId);
      yogas.add(a[3].ruleId);
      expect(a[2].result,isNotEmpty);
      expect(a[3].result,isNotEmpty);
    }
    expect(stars.length,27);
    expect(yogas.length,27);
    expect(PanchangaNatalPhalaService.starBirthPhala.length,27);
    expect(PanchangaNatalPhalaService.yogaBirthPhala.length,27);
  });

  test('All 60 half tithis map to the 11 correctly sourced karanas', () {
    final names=<String>{};
    for(var i=0;i<60;i++) {
      final result=PanchangaNatalPhalaService.evaluate(
        chart(0,(i+.5)*6),birth());
      final r=result[4];
      names.add(r.label);
      expect(r.ruleId,contains('K${(i+1).toString().padLeft(2,'0')}'));
      expect(r.source,contains('శ్లోకం'));
    }
    expect(names.length,11);
    expect(PanchangaNatalPhalaService.karanaBirthPhala.length,11);
  });

  test('Tithi, weekday, yoga and nakshatra source-verse boundaries', () {
    expect(PanchangaNatalPhalaService.tithiBirthPhala.length,16);
    expect(PanchangaNatalPhalaService.weekdayBirthPhala.length,7);
    expect(PanchangaNatalPhalaService.tithiVerse(0),34);
    expect(PanchangaNatalPhalaService.tithiVerse(4),35);
    expect(PanchangaNatalPhalaService.tithiVerse(8),36);
    expect(PanchangaNatalPhalaService.tithiVerse(12),37);
    expect(PanchangaNatalPhalaService.tithiVerse(29),37);
    expect(PanchangaNatalPhalaService.nakshatraVerse(0),84);
    expect(PanchangaNatalPhalaService.nakshatraVerse(26),90);
    expect(PanchangaNatalPhalaService.yogaVerse(7),97);
    expect(PanchangaNatalPhalaService.yogaVerse(8),98);
    expect(PanchangaNatalPhalaService.yogaVerse(16),98);
    expect(PanchangaNatalPhalaService.yogaVerse(17),99);
    expect(PanchangaNatalPhalaService.yogaVerse(22),99);
    expect(PanchangaNatalPhalaService.yogaVerse(23),100);
    expect(PanchangaNatalPhalaService.yogaVerse(26),100);
  });
}
