import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/multi_chart_topic_service.dart';
import 'package:astro_app/screens/topic_varga_review_panel.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 4,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.0,
        'Moon': 115.1369,
        'Mars': 156.1172,
        'Mercury': 242.4142,
        'Jupiter': 189.8097,
        'Venus': 280.4494,
        'Saturn': 176.7767,
        'Rahu': 75.0,
        'Ketu': 255.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  Future<void> show(WidgetTester tester, MultiChartTopicEvidence summary) =>
      tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: summary),
            ),
          ),
        ),
      );
  testWidgets('matched result is below its chart and opens its own rule', (
    tester,
  ) async {
    const summary = MultiChartTopicEvidence(
      name: 'fixture event',
      chartOrderSourceId: 'fixture',
      note: '',
      stages: [
        TopicStageEvidence(
          factor: 1,
          status: TopicStageStatus.matched,
          ruleIds: ['fixture-1'],
          ruleText: 'IF first source',
          details: 'first inspection',
          result: 'first favorable result',
          source: 'first book',
          polarity: TopicPolarity.supportive,
        ),
        TopicStageEvidence(
          factor: 9,
          status: TopicStageStatus.matched,
          ruleIds: ['fixture-9'],
          ruleText: 'IF ninth source',
          details: 'ninth inspection',
          result: 'ninth caution result',
          source: 'ninth book',
          polarity: TopicPolarity.adverse,
        ),
        TopicStageEvidence(
          factor: 10,
          status: TopicStageStatus.insufficientEvidence,
          ruleIds: [],
          details: 'incomplete source inspection',
          result: 'MUST NOT LEAK',
        ),
      ],
    );
    await show(tester, summary);
    for (final factor in [1, 9]) {
      final image = find.byKey(ValueKey('topic-chart-fixture-$factor'));
      final result = find.byKey(
        ValueKey('topic-result-under-chart-fixture-$factor'),
      );
      expect(result, findsOneWidget);
      expect(
        tester.getTopLeft(result).dy,
        greaterThan(tester.getBottomLeft(image).dy),
      );
    }
    expect(find.text('ఫలితం: first favorable result'), findsOneWidget);
    expect(find.text('ఫలితం: ninth caution result'), findsOneWidget);
    expect(find.textContaining('MUST NOT LEAK'), findsNothing);
    final action = find.byKey(const ValueKey('topic-inspect-fixture-9'));
    await tester.ensureVisible(action);
    await tester.pumpAndSettle();
    expect(action.hitTestable(), findsOneWidget);
    await tester.tap(action);
    await tester.pumpAndSettle();
    expect(find.text('IF ninth source'), findsOneWidget);
    expect(find.text('Rule IDలు: fixture-9'), findsOneWidget);
    expect(find.text('IF first source'), findsNothing);
    expect(tester.takeException(), isNull);
  });
  testWidgets(
    'every event exposes an inspection action for every selected chart',
    (tester) async {
      final topics = MultiChartTopicService.summarize(
        chart: chart,
        evaluatedRules: [],
      );
      expect(topics.length, 17);
      for (final topic in topics) {
        await show(tester, topic);
        await tester.pump();
        for (final stage in topic.stages) {
          expect(
            find.byKey(
              ValueKey(
                'topic-inspect-${topic.chartOrderSourceId}-${stage.factor}',
              ),
            ),
            findsOneWidget,
            reason: '${topic.name} D${stage.factor}',
          );
          final result = find.byKey(
            ValueKey(
              'topic-result-under-chart-${topic.chartOrderSourceId}-${stage.factor}',
            ),
          );
          expect(
            result,
            stage.status == TopicStageStatus.matched && stage.result.isNotEmpty
                ? findsOneWidget
                : findsNothing,
          );
        }
        expect(tester.takeException(), isNull);
      }
    },
  );
}
