import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/kalasarpa_service.dart';

AstroChartResult chart(List<double> degrees) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 0, engineVersion: 'test',
  planets: [
    for (var i=0; i<9; i++) PlanetPosition(
      name: [...KalasarpaService.requiredPlanets, 'Rahu', 'Ketu'][i],
      shortName: '', longitude: degrees[i], latitude: 0, speed: 0),
  ],
);
void main() {
  test('seven planets on same semicircle', () {
    final r = KalasarpaService.evaluate(chart([20,40,60,80,100,120,140,0,180]));
    expect(r.ruleId, 'KS-01');
    expect(r.status, contains('పూర్ణ'));
  });
  test('planet on other semicircle rejects full classification', () {
    final r = KalasarpaService.evaluate(chart([20,40,60,80,100,120,220,0,180]));
    expect(r.ruleId, isNull);
    expect(r.name, 'అనంత'); // name is Rahu's house, not proof of yoga
    expect(r.status, 'పూర్ణ కాలసర్ప స్థితి లేదు');
  });
  test('all twelve Rahu houses yield a named type even if formation is absent', () {
    for (var house = 1; house <= 12; house++) {
      final rahu = ((house - 1) * 30 + 2).toDouble();
      final ketu = (rahu + 180) % 360;
      final planets = <double>[for (var j = 0; j < 6; j++) (rahu + 20 + 12*j) % 360,
        (rahu + 205) % 360]; // intentionally outside the Rahu-Ketu half
      final r = KalasarpaService.evaluate(chart([...planets, rahu, ketu]));
      expect(r.rahuHouse, house);
      expect(r.name, KalasarpaService.names[house - 1]);
      expect(r.ruleId, isNull);
      expect(r.status, 'పూర్ణ కాలసర్ప స్థితి లేదు');
    }
  });
  test('boundary planet with other planets split still means no full yoga', () {
    final r = KalasarpaService.evaluate(chart([0,40,60,80,100,120,220,0,180]));
    expect(r.name, 'అనంత');
    expect(r.status, 'పూర్ణ కాలసర్ప స్థితి లేదు');
    expect(r.ruleId, isNull);
  });
  test('node boundary is not classified as unambiguous', () {
    final r = KalasarpaService.evaluate(chart([0,40,60,80,100,120,140,0,180]));
    expect(r.status, 'సంధి పరిశీలన అవసరం');
  });
}
