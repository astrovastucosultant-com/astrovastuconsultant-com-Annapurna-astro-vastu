import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/marriage_rules_ok_registry.dart';
import 'package:astro_app/astrology/marriage_chart_evidence_service.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/screens/marriage_reviewed_sources_screen.dart';

void main() {
  test('legacy topic metadata remains distinct from the current six-page PDF', () {
    expect(MarriageRulesOkRegistry.topics.length, 62);
    final seen = <String>{};
    for (final topic in MarriageRulesOkRegistry.topics) {
      expect(seen.add(topic.id), isTrue, reason: topic.id);
      expect(topic.title.trim(), isNotEmpty);
      expect(topic.page, inInclusiveRange(1, 39));
      expect(topic.page, greaterThanOrEqualTo(1));
    }
    expect(MarriageRulesOkRegistry.forMatching(), isNotEmpty);
    expect(MarriageRulesOkRegistry.forIndividual(), isNotEmpty);
    expect(MarriageRulesOkRegistry.forMatching().length +
        MarriageRulesOkRegistry.forIndividual().length, 62);
  });

  test('D9 chart evidence computes placements without claiming a verdict', () {
    const chart = AstroChartResult(
      julianDay: 2461000,
      ayanamsaDegrees: 24,
      ascendantLongitude: 22,
      engineVersion: 'test',
      planets: [
        PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 67,
            latitude: 0, speed: 1),
        PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 108,
            latitude: 0, speed: 1),
        PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 216,
            latitude: 0, speed: 1),
        PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 260,
            latitude: 0, speed: 1),
      ],
    );
    final evidence = MarriageChartEvidenceService.forFactors(chart, [1, 9]);
    expect(evidence, contains('D1 లగ్నం'));
    expect(evidence, contains('D9 లగ్నం'));
    expect(evidence, contains('7వ అధిపతి'));
    expect(evidence, contains('సూత్రం ధృవీకరించకుండా'));
    expect(MarriageChartEvidenceService.forFactors(null, [9]),
        contains('Generate'));
  });
}
