import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/dasha_service.dart';
import 'package:astro_app/astrology/bnn_life_event_convergence_v371.dart';

void main() {
  test('v372 scans across a two-year antardasha, not just three dates', () {
    final period = DashaPeriod(
      lord:'Jupiter', start:DateTime(2028,1,1),
      end:DateTime(2030,1,1), years:2.0,
    );
    final points=BnnEventConvergenceServiceV371.transitCheckpoints(period);
    expect(points.length, greaterThan(12));
    expect(points.first, period.start);
    expect(points.last.isBefore(period.end),isTrue);
    for(var i=1;i<points.length;i++){
      expect(points[i].isAfter(points[i-1]),isTrue);
    }
  });
}
