import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/screens/jaimini_chart_v386.dart';

void main() {
  for (final scale in [1.3, 2.0]) {
    testWidgets('dense cell keeps every label visible at scale $scale', (
      tester,
    ) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = const Size(320, 900);
      addTearDown(tester.view.resetDevicePixelRatio);
      addTearDown(tester.view.resetPhysicalSize);
      final labels = [
        'Ju 9.7° MK',
        'Sa 2.5° DK',
        'Ke 28.0°',
        'P2',
        'P6',
        'P12',
      ];
      String? tapped;
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: MediaQuery(
              data: MediaQueryData(textScaler: TextScaler.linear(scale)),
              child: SingleChildScrollView(
                child: SizedBox(
                  width: 320,
                  child: JaiminiChart386(
                    ascendantSignIndex: 9,
                    occupants: {
                      9: labels,
                      3: ['Ra 28.0°'],
                      2: ['Mo 6.5° GK', 'P10'],
                    },
                    onOccupantTap: (label) => tapped = label,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
      await tester.pump();
      final cell = tester.getRect(find.byKey(const ValueKey('jaimini-sign-9')));
      for (final label in labels) {
        final found = find.text(label);
        expect(found, findsOneWidget);
        final rect = tester.getRect(found);
        expect(rect.top, greaterThanOrEqualTo(cell.top));
        expect(rect.bottom, lessThanOrEqualTo(cell.bottom));
        expect(rect.right, lessThanOrEqualTo(cell.right));
      }
      // Fixed signs keep the same topology regardless of ascendant.
      expect(
        tester.getTopLeft(find.byKey(const ValueKey('jaimini-sign-11'))).dy,
        lessThan(
          tester.getTopLeft(find.byKey(const ValueKey('jaimini-sign-9'))).dy,
        ),
      );
      await tester.ensureVisible(find.text('Sa 2.5° DK'));
      await tester.tap(find.text('Sa 2.5° DK'));
      expect(tapped, 'Sa 2.5° DK');
      expect(tester.takeException(), isNull);
    });
  }
}
