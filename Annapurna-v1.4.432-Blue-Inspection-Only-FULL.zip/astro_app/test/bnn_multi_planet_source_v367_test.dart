import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_planet_combination_service.dart';
import 'package:astro_app/astrology/bnn_special_multi_planet_service.dart';
import 'package:astro_app/screens/bnn_planet_combinations_panel.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late List<BnnSpecialSourceExample> sourced;
  late List<BnnCombinationMeaning> pairs;
  setUpAll(() async {
    sourced=await BnnSpecialMultiPlanetService.load();
    pairs=await BnnPlanetCombinationService.load();
  });
  PlanetPosition p(String name,int sign,double degree)=> PlanetPosition(
    name:name,shortName:name,longitude:30*sign+degree,latitude:0,speed:1);
  AstroChartResult chart(List<PlanetPosition> planets)=> AstroChartResult(
    julianDay:0,ayanamsaDegrees:24,ascendantLongitude:35,
    engineVersion:'sample',planets:planets);
  List<BnnCombinationGroup> groups(AstroChartResult c) =>
    BnnPlanetCombinationService.groups(chart:c,
      readings:BnnPlanetCombinationService.evaluate(chart:c,rules:pairs));

  test('Source catalog has seven unique 3/4 planet source examples', () {
    expect(sourced.length,7);
    expect(sourced.map((r)=>r.id).toSet().length,7);
    expect(sourced.any((r)=>r.planets.length==4),isTrue);
    expect(sourced.any((r)=>r.planets.length==3),isTrue);
    expect(sourced.every((r)=>r.source.isNotEmpty&&
      r.sourceUrl.startsWith('https://')&&r.qualifier.isNotEmpty),isTrue);
  });

  test('Four planets contain four trios, one quad and six pairs', () {
    expect(BnnSpecialMultiPlanetService.countSubgroups(4,2),6);
    expect(BnnSpecialMultiPlanetService.countSubgroups(4,3),4);
    expect(BnnSpecialMultiPlanetService.countSubgroups(4,4),1);
    expect(BnnSpecialMultiPlanetService.countSubgroups(3,3),1);
    final list=[p('Sun',0,1),p('Moon',0,2),p('Mars',0,3),p('Mercury',0,4)];
    expect(BnnSpecialMultiPlanetService.subsets(list,3).length,4);
    expect(BnnSpecialMultiPlanetService.subsets(list,4).length,1);
    expect(BnnSpecialMultiPlanetService.subsets(list,5),isEmpty);
  });

  test('Mercury + Sun + Ketu source case matches but does not assert events', () {
    final c=chart([p('Sun',3,26.76),p('Mercury',3,18.41),p('Ketu',3,2.34)]);
    final group=groups(c).firstWhere((g)=>g.sameSignIndex==3);
    final matches=BnnSpecialMultiPlanetService.matchingSourceExamples(
      group:group,rules:sourced);
    expect(matches.map((m)=>m.rule.id),contains('BNN-RG-CH335-SUN-MERCURY-KETU'));
    expect(matches.first.rule.evidenceKind,'primary_book_case');
    expect(matches.first.rule.qualifier,contains('ఉదాహరణ'));
    expect(matches.first.hasExtraGroupPlanets,isFalse);
  });

  test('Exact 4 planet Aries case matches R G Rao Chart 327', () {
    final c=chart([p('Sun',0,7),p('Venus',0,19),
      p('Rahu',0,12),p('Mercury',0,3)]);
    final g=groups(c).firstWhere((g)=>g.sameSignIndex==0);
    expect(g.planets.length,4);
    final matches=BnnSpecialMultiPlanetService.matchingSourceExamples(
      group:g,rules:sourced);
    expect(matches.any((m)=>m.rule.id==
      'BNN-RG-CH327-SUN-VENUS-RAHU-MERCURY'),isTrue);
    expect(matches.every((m)=>!m.hasExtraGroupPlanets),isTrue);
  });

  test('R G Rao Chart 327 exact sign guard blocks false positive', () {
    final c=chart([p('Sun',3,7),p('Venus',3,19),
      p('Rahu',3,12),p('Mercury',3,3)]);
    final g=groups(c).firstWhere((g)=>g.sameSignIndex==3);
    final matches=BnnSpecialMultiPlanetService.matchingSourceExamples(
      group:g,rules:sourced);
    expect(matches.where((m)=>m.rule.id.contains('CH327')),isEmpty);
  });

  test('Secondary directional trine matches only its exact three signs', () {
    final c=chart([p('Jupiter',0,3),p('Sun',4,8),p('Moon',8,24)]);
    final g=groups(c).firstWhere((g)=>g.sameSignIndex==null);
    final matches=BnnSpecialMultiPlanetService.matchingSourceExamples(
      group:g,rules:sourced);
    expect(matches.map((m)=>m.rule.id),
      contains('BNN-SECONDARY-JUPITER-SUN-MOON-FIRE'));
    expect(matches.first.rule.evidenceKind,'secondary_author_example');
    final wrong=chart([p('Jupiter',4,3),p('Sun',0,8),p('Moon',8,24)]);
    final g2=groups(wrong).firstWhere((g)=>g.sameSignIndex==null);
    expect(BnnSpecialMultiPlanetService.matchingSourceExamples(
      group:g2,rules:sourced),isEmpty);
  });

  test('A 4 planet group labels its three-planet examples as subset only', () {
    final c=chart([p('Sun',3,26),p('Mercury',3,18),p('Ketu',3,2),
      p('Venus',3,8)]);
    final g=groups(c).firstWhere((g)=>g.sameSignIndex==3);
    final matches=BnnSpecialMultiPlanetService.matchingSourceExamples(
      group:g,rules:sourced);
    expect(matches.where((m)=>m.rule.id.contains('CH335')).single
      .hasExtraGroupPlanets,isTrue);
  });

  test('Shortest angle is not a misleading 343.93 degree sign difference', () {
    final c=chart([p('Mercury',3,18.4094),p('Ketu',3,2.3369)]);
    final x=BnnPlanetCombinationService.evaluate(chart:c,rules:pairs)
      .firstWhere((x)=>x.meaning.id=='BNN-KARAKA-MERCURY-KETU');
    expect(x.forwardDegrees,greaterThan(340));
    expect(x.shortestSeparationDegrees,closeTo(16.0725,0.01));
  });

  testWidgets('Named 3 planet book case appears ahead of pair boxes', (tester) async {
    final c=chart([p('Sun',3,26),p('Mercury',3,18),p('Ketu',3,2)]);
    await tester.pumpWidget(MaterialApp(home:Scaffold(body:ListView(children:[
      BnnPlanetCombinationsPanel(chart:c,initialCatalog:pairs,
        initialSourceExamples:sourced),
    ]))));
    await tester.pump();
    await tester.pump(const Duration(milliseconds:350));
    final container=find.byKey(
      const ValueKey('bnn-special-BNN-RG-CH335-SUN-MERCURY-KETU'));
    expect(container,findsOneWidget);
    expect(find.byKey(const ValueKey('bnn-group-positive-sign-3')),findsOneWidget);
    expect(find.byKey(const ValueKey('bnn-group-negative-sign-3')),findsOneWidget);
  });

  testWidgets('Named 4 planet case renders a separate badge', (tester) async {
    final c=chart([p('Sun',0,7),p('Venus',0,19),
      p('Rahu',0,12),p('Mercury',0,3)]);
    await tester.pumpWidget(MaterialApp(home:Scaffold(body:ListView(children:[
      BnnPlanetCombinationsPanel(chart:c,initialCatalog:pairs,
        initialSourceExamples:sourced),
    ]))));
    await tester.pump();
    await tester.pump(const Duration(milliseconds:350));
    expect(find.byKey(const ValueKey(
      'bnn-special-BNN-RG-CH327-SUN-VENUS-RAHU-MERCURY')),findsOneWidget);
    expect(find.textContaining('4 గ్రహాల ఉపసమూహాలు: 1'),findsWidgets);
  });
}
