import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:astro_app/screens/question_place_picker.dart';
import 'package:astro_app/services/place_search_service.dart';
import 'package:astro_app/services/place_storage_service.dart';
import 'package:astro_app/services/question_place_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('uses latest saved village when no question village chosen', () async {
    expect(await QuestionPlaceService.preferred(), isNull);
    await PlaceStorageService.save(const PlaceResult(
      displayName: 'Guntur, Andhra Pradesh, India',
      latitude: 16.3067, longitude: 80.4365,
    ));
    final p = await QuestionPlaceService.preferred();
    expect(p?.name, contains('Guntur'));
    expect(p?.utcOffset, 5.5);
    expect(p?.latitude, closeTo(16.3067, 0.000001));
  });

  test('remembers manually selected question village without birth name', () async {
    const place = QuestionPlace(name: 'Dachepalle',
      latitude: 16.593221, longitude: 79.736383, utcOffset: 5.5);
    await QuestionPlaceService.remember(place);
    final next = await QuestionPlaceService.preferred();
    expect(next?.name, 'Dachepalle');
    expect(next?.longitude, closeTo(79.736383, 0.000001));
    expect(next!.valid(forKp: true), isTrue);
  });

  test('rejects missing coordinates and out-of-range latitude', () {
    const missing = QuestionPlace(name: '', latitude: 0,
      longitude: 0, utcOffset: 5.5);
    const polar = QuestionPlace(name: 'Polar test', latitude: 80,
      longitude: 50, utcOffset: 2);
    expect(missing.valid(), isFalse);
    expect(polar.valid(), isTrue);
    expect(polar.valid(forKp: true), isFalse);
  });

  testWidgets('change place sheet uses default and does not ask birth name',
      (tester) async {
    const initial = QuestionPlace(name: 'Guntur',
      latitude: 16.3067, longitude: 80.4365, utcOffset: 5.5);
    QuestionPlace? chosen;
    await tester.pumpWidget(MaterialApp(home: Scaffold(
      body: Builder(builder: (context) => ElevatedButton(
        onPressed: () async {
          chosen = await QuestionPlacePicker.choose(context,
            initial: initial, forKp: true);
        }, child: const Text('Open place change'))),
    )));
    await tester.tap(find.text('Open place change'));
    await tester.pumpAndSettle();
    expect(find.text('ప్రశ్న స్థలం మార్చండి'), findsOneWidget);
    expect(find.textContaining('జనన పేరు/తేదీ అవసరం లేదు.'), findsOneWidget);
    await tester.tap(find.text('ఈ ఊరుతో ప్రశ్న చక్రం తెరవండి'));
    await tester.pumpAndSettle();
    expect(chosen?.name, 'Guntur');
  });
}
