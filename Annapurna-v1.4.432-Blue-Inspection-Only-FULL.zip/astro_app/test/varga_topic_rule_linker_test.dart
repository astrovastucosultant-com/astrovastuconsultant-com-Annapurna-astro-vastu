import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_topic_catalog.dart';
import 'package:astro_app/astrology/varga_topic_rule_linker.dart';
import 'package:astro_app/astrology/varga_unified_rule_service.dart';

const _natal = AstroChartResult(
  julianDay: 2441542.0,
  ayanamsaDegrees: 23.0,
  ascendantLongitude: 75.0,
  engineVersion: 'rule-binding-regression',
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 110,
        latitude: 0, speed: 0.9),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 160,
        latitude: 0, speed: 13),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 122,
        latitude: 0, speed: 0.5),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108,
        latitude: 0, speed: 0.2),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 245,
        latitude: 0, speed: -0.1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 71,
        latitude: 0, speed: 0.2),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 58,
        latitude: 0, speed: 0.1),
    PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 272,
        latitude: 0, speed: -0.1),
    PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 92,
        latitude: 0, speed: -0.1),
  ],
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('176 subjects across 19 vargas still exist', () {
    expect(VargaService.definitions.length, 19);
    final total = VargaService.definitions
        .map((d) => VargaTopicCatalog.forFactor(d.factor).length)
        .reduce((a, b) => a + b);
    expect(total, 176);
  });

  test('source IDs link to actual subject, not to a random keyword hit', () {
    expect(VargaTopicRuleLinker.sourceIndex(6, 'VARGA-D6-002', 7), 4);
    expect(VargaTopicRuleLinker.sourceIndex(8, 'VARGA-D8-003', 6), 0);
    expect(VargaTopicRuleLinker.sourceIndex(10, 'VARGA-D10-006', 33), 10);
    expect(VargaTopicRuleLinker.sourceIndex(9, 'VARGA-D10-006', 11), isNull);
    expect(VargaTopicRuleLinker.sourceIndex(6, 'VARGA-D6-006', 7), isNull);
    expect(VargaTopicRuleLinker.crossIndex(10, 'VARGA-CROSS-021', 33), 7);
    expect(VargaTopicRuleLinker.crossIndex(1, 'VARGA-CROSS-016', 13), 10);
  });

  test('all 255 original IDs are preserved and mapped chart IDs stay in bounds', () async {
    final raw = jsonDecode(await rootBundle.loadString(
        VargaUnifiedRuleService.asset)) as Map<String, dynamic>;
    final rows = raw['rules'] as List<dynamic>;
    expect(rows.length, 255);
    expect(rows.map((r) => (r as Map<String, dynamic>)['id']).toSet().length, 255);
    var direct = 0;
    var linked = 0;
    for (final row in rows) {
      final rule = row as Map<String, dynamic>;
      for (final def in VargaService.definitions) {
        final factor = def.factor;
        final size = VargaTopicCatalog.forFactor(factor).length;
        if (rule['group'] == 'D$factor') {
          direct++;
          final index = VargaTopicRuleLinker.sourceIndex(factor,
              rule['id'] as String, size);
          if (index != null) {
            linked++;
            expect(index, inInclusiveRange(0, size - 1));
          }
        }
      }
    }
    expect(direct, 97);
    expect(linked, 84);
  });

  test('fully computable D5 D6 D8 IFs report tested status, not pending', () async {
    final rules = await VargaUnifiedRuleService.evaluate(_natal);
    for (final id in ['VARGA-D5-003', 'VARGA-D6-002',
        'VARGA-D6-003', 'VARGA-D6-006',
        'VARGA-D8-003', 'VARGA-D8-004']) {
      final rule = rules.firstWhere((x) => x.id == id);
      expect(rule.status, anyOf(UnifiedVargaRuleStatus.matched,
          UnifiedVargaRuleStatus.notMatched), reason: id);
      expect(rule.source, contains('Mallikarjuna PDF'));
    }
  });
}
