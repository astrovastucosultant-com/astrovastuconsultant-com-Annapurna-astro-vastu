import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/screens/unified_rule_result_tile.dart';

void main() {
  testWidgets('matched adverse rule has a negative icon and polarity label',
      (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: UnifiedRuleResultTile(
          data: RuleResultData(
            topic: 'వాహనం లేకపోవటం',
            result: 'ప్రతికూల సూచన',
            verdict: RuleVerdict.adverse,
            examination: 'D1 4వ అధిపతి 6లో',
            rule: '4L dusthana and Venus weak',
            ruleMatched: true,
          ),
        ),
      ),
    ));
    expect(find.byIcon(Icons.cancel_outlined), findsOneWidget);
    expect(find.textContaining('ఫలిత స్వభావం: ప్రతికూలం'), findsOneWidget);
  });
}
