import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/varga_rule_match_policy.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_topic_catalog.dart';
import 'package:astro_app/astrology/varga_unified_rule_service.dart';

const _ifText = 'IF D7 సప్తాంశ లగ్నం శుభగ్రహ సంబంధం కలిగి ఉంటే';
const _thenText = 'THEN సంతానానికి శుభ సహాయక సూచన';

UnifiedVargaRule sourceRule({
  String id = 'VARGA-D7-004',
  UnifiedVargaRuleStatus status = UnifiedVargaRuleStatus.matched,
  String condition = _ifText,
  String outcome = _thenText,
}) => UnifiedVargaRule(
  id: id,
  group: 'D7',
  groupTitle: 'సప్తాంశ',
  topic: 'సంతాన యోగం',
  condition: condition,
  outcome: outcome,
  source: 'User-provided rules, page 8',
  evidence: 'పరిశీలన: గ్రహ స్థితి',
  status: status,
  tone: UnifiedVargaRuleTone.favorable,
);

VargaRuleHit calculatedRule({
  String id = 'D7-SOURCE-1',
  bool applicable = true,
  bool autoEvaluated = true,
  VargaRuleTone tone = VargaRuleTone.favorable,
  String result = _thenText,
  String rule = _ifText,
}) => VargaRuleHit(
  factor: 7,
  ruleId: id,
  topic: 'సంతాన యోగం',
  result: result,
  rule: rule,
  inspection: 'D7 గ్రహస్థితి పరిశీలన',
  remedy: '',
  source: 'User-provided source',
  tone: tone,
  applicable: applicable,
  autoEvaluated: autoEvaluated,
);

void main() {
  test('all 19 charts and their 176 subject tabs remain present', () {
    final factors = VargaService.definitions.map((v) => v.factor).toSet();
    expect(factors, VargaRuleMatchPolicy.supportedFactors);
    expect(factors.length, 19);
    final topics = VargaService.definitions
        .map((v) => VargaTopicCatalog.forFactor(v.factor).length)
        .reduce((a, b) => a + b);
    expect(topics, 176);
  });

  test('D2–D60 direct source rules use matching IF AND THEN', () {
    for (final factor in VargaRuleMatchPolicy.supportedFactors) {
      expect(VargaRuleMatchPolicy.sourceMatch(sourceRule(), factor: factor,
          d16Method: D16CalculationMethod.parashara), isTrue);
      expect(VargaRuleMatchPolicy.sourceMatch(
          sourceRule(status: UnifiedVargaRuleStatus.notMatched),
          factor: factor, d16Method: D16CalculationMethod.parashara), isFalse);
      expect(VargaRuleMatchPolicy.sourceMatch(
          sourceRule(status: UnifiedVargaRuleStatus.pending),
          factor: factor, d16Method: D16CalculationMethod.parashara), isNull);
      expect(VargaRuleMatchPolicy.sourceMatch(
          sourceRule(status: UnifiedVargaRuleStatus.method),
          factor: factor, d16Method: D16CalculationMethod.parashara), isNull);
    }
  });

  test('a computed condition without source IF or THEN is not a prediction', () {
    expect(VargaRuleMatchPolicy.sourceMatch(sourceRule(outcome: ''),
        factor: 7, d16Method: D16CalculationMethod.parashara), isNull);
    expect(VargaRuleMatchPolicy.sourceMatch(sourceRule(condition: ''),
        factor: 7, d16Method: D16CalculationMethod.parashara), isNull);
  });

  test('all 19 vargas use the same positive/rejected/pending computed policy', () {
    expect(VargaRuleMatchPolicy.calculatedMatch(calculatedRule()), isTrue);
    expect(VargaRuleMatchPolicy.calculatedMatch(
        calculatedRule(applicable: false)), isFalse);
    expect(VargaRuleMatchPolicy.calculatedMatch(
        calculatedRule(autoEvaluated: false)), isNull);
    expect(VargaRuleMatchPolicy.calculatedMatch(
        calculatedRule(tone: VargaRuleTone.info)), isNull);
    expect(VargaRuleMatchPolicy.calculatedMatch(
        calculatedRule(result: '')), isNull);
    expect(VargaRuleMatchPolicy.calculatedMatch(
        calculatedRule(rule: '')), isNull);
  });

  test('VARGA-CROSS never becomes a final result even when verified true', () {
    expect(VargaRuleMatchPolicy.isCrossVargaEvidence('VARGA-CROSS-028'), isTrue);
    expect(VargaRuleMatchPolicy.sourceMatch(
        sourceRule(id: 'VARGA-CROSS-028'),
        factor: 10, d16Method: D16CalculationMethod.parashara), isNull);
    expect(VargaRuleMatchPolicy.calculatedMatch(
        calculatedRule(id: 'VARGA-CROSS-028')), isNull);
  });

  test('SAV and Vargottama evidence stay audit-only for all vargas', () {
    for (final id in [
      'VARGA-PROTOCOL-010/D10/H10',
      'VARGA-PROTOCOL-011/D1/H4',
      'VARGA-GENERAL-004/D9',
    ]) {
      expect(VargaRuleMatchPolicy.isCrossVargaEvidence(id), isTrue);
      expect(VargaRuleMatchPolicy.sourceMatch(sourceRule(id: id),
          factor: 9, d16Method: D16CalculationMethod.parashara), isNull);
    }
  });

  test('alternate D16 method does not promote Parashara-only rows', () {
    expect(VargaRuleMatchPolicy.sourceMatch(sourceRule(),
        factor: 16, d16Method: D16CalculationMethod.phaladeepika), isNull);
    expect(VargaRuleMatchPolicy.sourceMatch(sourceRule(),
        factor: 16, d16Method: D16CalculationMethod.parashara), isTrue);
  });

  test('matched count cannot include false or pending statuses', () {
    final result = <bool?>[true, false, null, true, false, null];
    expect(VargaRuleMatchPolicy.countMatched(result), 2);
    expect(VargaRuleMatchPolicy.countRejected(result), 2);
    expect(VargaRuleMatchPolicy.countPending(result), 2);
    expect(result.map(VargaRuleMatchPolicy.priority).toList(),
        <int>[0, 1, 2, 0, 1, 2]);
  });
}
