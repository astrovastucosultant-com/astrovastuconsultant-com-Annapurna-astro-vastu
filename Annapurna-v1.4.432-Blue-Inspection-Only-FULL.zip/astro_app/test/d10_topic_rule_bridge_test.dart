import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_topic_rule_bridge.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';

D10VruttiMatch sample(String name, {bool complete = true}) => D10VruttiMatch(
  D10VruttiRule(id: 'TEST-$name', category: 'పరీక్ష', page: 1,
      condition: 'నియమం', profession: name, planets: const ['Sun'],
      deity: null, houses: const [], mode: null, uncertain: const []),
  true, complete, complete ? 100 : 35,
  const ['D1/D10 verified'], const [], const [],
);

void main() {
  test('Banking topic shows only complete finance matches', () {
    final matches = D10TopicRuleBridge.forTopic('బ్యాంకింగ్ / ఫైనాన్స్', [
      sample('బ్యాంక్ మేనేజర్'),
      sample('సివిల్ ఇంజినీర్'),
      sample('గోల్డ్ లోన్', complete: false),
    ]);
    expect(matches.map((m) => m.rule.profession), ['బ్యాంక్ మేనేజర్']);
  });
  test('Engineering topic does not show unrelated finance matches', () {
    final matches = D10TopicRuleBridge.forTopic('టెక్నికల్ / ఇంజినీరింగ్', [
      sample('సివిల్ ఇంజినీర్'), sample('బ్యాంక్ మేనేజర్'),
    ]);
    expect(matches.length, 1);
    expect(matches.single.rule.profession, 'సివిల్ ఇంజినీర్');
  });
  test('Profit/loss and life stages have no invented rule outcomes', () {
    for (final topic in ['వృత్తిలో పెట్టుబడి / నష్టం',
        'వృత్తి జీవితంలో మూడు దశలు']) {
      expect(D10TopicRuleBridge.forTopic(topic, [sample('గోల్డ్ లోన్')]),
          isEmpty);
    }
  });
  test('Only fully matched source rules surface, never partials', () {
    expect(D10TopicRuleBridge.forTopic('టెక్నికల్ / ఇంజినీరింగ్', [
      sample('సివిల్ ఇంజినీర్', complete: false),
    ]), isEmpty);
  });
}
