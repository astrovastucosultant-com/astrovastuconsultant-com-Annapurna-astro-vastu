import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/screens/topic_varga_review_panel.dart';
import '../lib/screens/career_options_card_v394.dart';
import '../lib/astrology/career_options_v394.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 4,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.0,
        'Moon': 115.1369,
        'Mars': 156.1172,
        'Mercury': 242.4142,
        'Jupiter': 189.8097,
        'Venus': 280.4494,
        'Saturn': 176.7767,
        'Rahu': 75.0,
        'Ketu': 255.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  testWidgets('occupation card occupies the right slot next to D10', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(400, 2200));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final summary = MultiChartTopicService.summarize(
      chart: chart,
      evaluatedRules: [],
    ).singleWhere((s) => s.name == 'ఉద్యోగం / సర్వీస్');
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: TopicVargaReviewPanel(chart: chart, summary: summary),
          ),
        ),
      ),
    );
    final d10 = find.byKey(
      const ValueKey('topic-chart-USER-CAREER-CORE-JOB-10'),
    );
    final card = find.byKey(const ValueKey('career-options-card-v394'));
    expect(card, findsOneWidget);
    expect(tester.getTopLeft(card).dx, greaterThan(tester.getTopLeft(d10).dx));
    // Preview is inset in its stage card, so its top is below the row top.
    expect(tester.getTopLeft(card).dy, lessThan(tester.getTopLeft(d10).dy));
    expect(find.text('జాతకునికి అనుకూల వృత్తులు'), findsOneWidget);
    await tester.ensureVisible(
      find.byKey(const ValueKey('career-options-inspect-v394')),
    );
    await tester.tap(find.byKey(const ValueKey('career-options-inspect-v394')));
    await tester.pumpAndSettle();
    expect(find.text('వృత్తులు — రూల్ పరిశీలన'), findsOneWidget);
    expect(find.text('Rule ID: D10-FINAL-MASTER-PROF'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('all evidence-backed career families and percentages are inline', (tester) async {
    await tester.binding.setSurfaceSize(const Size(400, 2600));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    final data = CareerOptions394.forChart(chart);
    expect(data.options.length, greaterThan(4));
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(body: SingleChildScrollView(child: CareerOptionsCard394(chart: chart))),
    ));
    // The last family is deliberately outside the old 4-family preview.
    final last = data.options.last.candidate;
    expect(find.byKey(ValueKey('career-option-${last.profession}')), findsOneWidget);
    expect(find.byKey(ValueKey('career-percent-${last.profession}')), findsOneWidget);
    expect(find.textContaining('ఆధారాల సరిపోలిక మాత్రమే'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  testWidgets('narrow card and large Telugu text do not overflow', (
    tester,
  ) async {
    await tester.binding.setSurfaceSize(const Size(360, 700));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    for (final scale in [1.0, 1.6, 2.0]) {
      await tester.pumpWidget(
        MaterialApp(
          home: MediaQuery(
            data: MediaQueryData(textScaler: TextScaler.linear(scale)),
            child: Scaffold(
              body: SingleChildScrollView(
                child: Align(
                  alignment: Alignment.topLeft,
                  child: SizedBox(
                    width: 158,
                    child: CareerOptionsCard394(chart: chart),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
      expect(tester.takeException(), isNull);
    }
  });
  testWidgets('non career event has no career recommendation', (tester) async {
    final summary = MultiChartTopicService.summarize(
      chart: chart,
      evaluatedRules: [],
    ).singleWhere((s) => s.name == 'సంతానం');
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: TopicVargaReviewPanel(chart: chart, summary: summary),
          ),
        ),
      ),
    );
    expect(find.byType(CareerOptionsCard394), findsNothing);
    expect(tester.takeException(), isNull);
  });
}
