import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/varga_rule_match_policy.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

VargaRuleHit hit(String id, {bool matched = true, bool auto = true}) =>
    VargaRuleHit(
      factor: 3,
      ruleId: id,
      topic: 'కర్మఫలం',
      result: 'జాతక పరిశీలన ఆధారితం',
      rule: 'IF పరీక్షించిన గ్రహస్థితి',
      inspection: 'D3 ప్రత్యక్ష పరిశీలన',
      remedy: '',
      source: 'Sarala 7 source',
      tone: id.endsWith('CAUTION')
          ? VargaRuleTone.caution
          : VargaRuleTone.favorable,
      applicable: matched,
      autoEvaluated: auto,
    );

void main() {
  test('D3 strength and caution both true -> mixed evidence', () {
    expect(VargaRuleMatchPolicy.d3KarmaHasMixedEvidence([
      hit('SJ7-D3-02'),
      hit('SJ7-D3-02-CAUTION'),
    ]), true);
  });
  test('only one D3 condition matched -> no forced mixed result', () {
    expect(VargaRuleMatchPolicy.d3KarmaHasMixedEvidence([
      hit('SJ7-D3-02'),
      hit('SJ7-D3-02-CAUTION', matched: false),
    ]), false);
    expect(VargaRuleMatchPolicy.d3KarmaHasMixedEvidence([
      hit('SJ7-D3-02', matched: false),
      hit('SJ7-D3-02-CAUTION'),
    ]), false);
  });
  test('incomplete source checks cannot be promoted to mixed result', () {
    expect(VargaRuleMatchPolicy.d3KarmaHasMixedEvidence([
      hit('SJ7-D3-02', auto: false),
      hit('SJ7-D3-02-CAUTION'),
    ]), false);
  });
}
