import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/astrology/varga_unified_rule_service.dart';
import '../lib/screens/topic_result_card_v398.dart';
import '../lib/screens/topic_varga_review_panel.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 63,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.4,
        'Moon': 115.1,
        'Mars': 156.2,
        'Mercury': 242.6,
        'Jupiter': 189.8,
        'Venus': 280.3,
        'Saturn': 176.7,
        'Rahu': 75.5,
        'Ketu': 255.5,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final summary = MultiChartTopicService.summarize(
    chart: chart,
    evaluatedRules: [],
  ).singleWhere((s) => s.chartOrderSourceId == 'VARGA-CROSS-015');
  test(
    'vehicle catalog and topic source005 share truth and adverse tone',
    () async {
      final rules = await VargaUnifiedRuleService.evaluate(chart);
      final old = rules.singleWhere((r) => r.id == 'VARGA-D16-005');
      final current = summary.supplement!.stages.last.checks.singleWhere(
        (r) => r.id == old.id,
      );
      expect(
        old.status,
        current.matched == true
            ? UnifiedVargaRuleStatus.matched
            : UnifiedVargaRuleStatus.notMatched,
      );
      expect(old.tone, UnifiedVargaRuleTone.adverse);
      expect(summary.stages.map((s) => s.factor), [1, 4, 16]);
      expect(summary.confirmationPercent, isNull);
      expect(
        summary.stages.every((s) => s.status == TopicStageStatus.matched),
        isTrue,
      );
    },
  );
  testWidgets(
    'vehicle priority guidance and three chart results open source inspection',
    (tester) async {
      tester.view.physicalSize = const Size(900, 1800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: summary),
            ),
          ),
        ),
      );
      expect(
        find.byKey(const ValueKey('client-guidance-406-VARGA-CROSS-015')),
        findsOneWidget,
      );
      for (final f in [1, 4, 16])
        expect(
          find.byKey(ValueKey('topic-chart-VARGA-CROSS-015-$f')),
          findsOneWidget,
        );
      expect(find.text(summary.supplement!.conclusion), findsOneWidget);
      await tester.tap(
        find.byKey(const ValueKey('topic-result-398-VARGA-CROSS-015')),
      );
      await tester.pumpAndSettle();
      expect(find.text('మూలాలు'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('vehicle guide wraps with large Telugu text on narrow mobile', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(320, 1800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(1.8)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: TopicResultCard398(report: summary.supplement!),
            ),
          ),
        ),
      ),
    );
    expect(find.textContaining('నిర్వహణ / అదనపు శ్రద్ధ:'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
