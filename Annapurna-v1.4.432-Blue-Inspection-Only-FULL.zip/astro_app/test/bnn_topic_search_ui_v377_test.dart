import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_unified_evidence_v376.dart';
import 'package:astro_app/astrology/bnn_rashi_rule_service.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/screens/bnn_unified_evidence_panel_v376.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 24,
    ascendantLongitude: 2,
    engineVersion: 'test',
    planets: [
      for (final e in const {
        'Sun': 0,
        'Moon': 3,
        'Mars': 7,
        'Mercury': 5,
        'Jupiter': 0,
        'Venus': 6,
        'Saturn': 0,
        'Rahu': 2,
        'Ketu': 8,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value * 30.0 + 2,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final birth = BirthData(
    name: 'fixture',
    localDateTime: DateTime(2000),
    place: 'fixture',
    latitude: 16,
    longitude: 80,
    timezoneOffsetHours: 5.5,
    ayanamsa: AyanamsaType.lahiri,
  );
  const catalog = UnifiedCatalog376([
    UnifiedEvent376(
      id: 'EDU-HIGHER',
      title: 'ఉన్నత విద్య',
      mainHouse: 9,
      houses: {4, 5, 9},
    ),
    UnifiedEvent376(
      id: 'CAREER-ENTRY',
      title: 'ఉద్యోగ ప్రారంభం',
      mainHouse: 10,
      houses: {2, 6, 10, 11},
    ),
  ], []);
  const rule = BnnRashiRule(
    id: 'fixture-Sun',
    title: 'సూర్యుడు మేషంలో',
    planet: 'Sun',
    signIndex: 0,
    originalIf: 'సూర్యుడు మేషంలో',
    originalThen: 'విద్యలో ఆసక్తి. ఉద్యోగ అవకాశం.',
    transcriptionFile: 'fixture-source',
    pdfPage: 1,
    printedPage: 1,
    reviewFlags: [],
    reviewNote: '',
  );
  Future<void> open(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: SingleChildScrollView(
            child: BnnUnifiedEvidencePanel376(
              chart: chart,
              birth: birth,
              catalog: Future.value(catalog),
              natalRules: Future.value([rule]),
            ),
          ),
        ),
      ),
    );
    await tester.tap(find.text('BNN — అంశం ఎంచుకొని సూచనలు చూడండి'));
    await tester.pumpAndSettle();
  }

  testWidgets(
    'search shows related topic and matched natal sentence before technical detail',
    (tester) async {
      await open(tester);
      expect(
        find.byKey(const ValueKey('topic-results-EDU-HIGHER')),
        findsNothing,
      );
      await tester.enterText(
        find.byKey(const ValueKey('bnn-topic-search')),
        'విద్య',
      );
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('topic-results-EDU-HIGHER')),
        findsOneWidget,
      );
      expect(
        find.byKey(const ValueKey('topic-results-CAREER-ENTRY')),
        findsNothing,
      );
      expect(find.text('విద్యలో ఆసక్తి'), findsOneWidget);
      expect(find.text('ఉద్యోగ అవకాశం'), findsNothing);
      expect(find.textContaining('assets/bnn'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    '1-50 is accepted and invalid range never shows stale old results',
    (tester) async {
      await open(tester);
      await tester.enterText(
        find.byKey(const ValueKey('bnn-topic-search')),
        'education',
      );
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byKey(const ValueKey('bnn-age-range')),
        '1-50',
      );
      await tester.pump();
      expect(find.byKey(const ValueKey('bnn-result-scope')), findsNothing);
      await tester.ensureVisible(find.text('సూచనలు చూపించండి'));
      await tester.tap(find.text('సూచనలు చూపించండి'));
      await tester.pumpAndSettle();
      expect(
        find.textContaining('ఎంచుకున్న పూర్తి వయస్సులు: 1–50'),
        findsOneWidget,
      );
      expect(find.textContaining('ఉదా: 25 లేదా 1-50 ఇవ్వండి'), findsNothing);
      await tester.ensureVisible(find.byKey(const ValueKey('bnn-age-range')));
      await tester.enterText(
        find.byKey(const ValueKey('bnn-age-range')),
        '50-1',
      );
      await tester.ensureVisible(find.text('సూచనలు చూపించండి'));
      await tester.tap(find.text('సూచనలు చూపించండి'));
      await tester.pumpAndSettle();
      expect(find.textContaining('ఉదా: 25 లేదా 1-50 ఇవ్వండి'), findsOneWidget);
      expect(find.byKey(const ValueKey('bnn-result-scope')), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
}
