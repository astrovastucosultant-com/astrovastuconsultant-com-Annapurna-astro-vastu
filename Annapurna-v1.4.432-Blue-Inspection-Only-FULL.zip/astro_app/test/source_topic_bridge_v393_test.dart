import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/astrology/marriage_chrome_if_then_engine.dart';
import '../lib/astrology/astro_models.dart';

void main() {
  test('source clauses reach the matching event and chart only', () {
    void check(bool value, String why) => expect(value, isTrue, reason: why);
    final sample = AstroChartResult(
      julianDay: 2451545,
      ayanamsaDegrees: 24,
      ascendantLongitude: 4,
      engineVersion: 'fixture',
      planets: [
        for (final e in {
          'Sun': 235.0,
          'Moon': 115.1369,
          'Mars': 156.1172,
          'Mercury': 242.4142,
          'Jupiter': 189.8097,
          'Venus': 280.4494,
          'Saturn': 176.7767,
          'Rahu': 75.0,
          'Ketu': 255.0,
        }.entries)
          PlanetPosition(
            name: e.key,
            shortName: e.key,
            longitude: e.value,
            latitude: 0,
            speed: 1,
          ),
      ],
    );
    final summaries = MultiChartTopicService.summarize(
      chart: sample,
      evaluatedRules: [],
    );
    final marriage = summaries.singleWhere((s) => s.name == 'వివాహం');
    final children = summaries.singleWhere((s) => s.name == 'సంతానం');
    check(
      marriage.stages.map((s) => s.factor).join(',') == '1,9,2,7',
      'source marriage chart order unchanged',
    );
    check(
      children.stages.map((s) => s.factor).join(',') == '1,7,9',
      'source children chart order unchanged',
    );
    check(
      marriage.stages[1].ruleIds.contains('C01-03'),
      'existing 43-source engine actually connected',
    );
    check(
      children.stages[0].ruleIds.contains('SAP-P01-5L'),
      'D1 original chapter rules connected',
    );
    check(
      children.stages[1].ruleIds.contains('SAP-P15-5L-TRIKA'),
      'D7 separate PDF connected',
    );
    check(
      children.supplement != null &&
          children.supplement!.stages.last.checks.every(
            (c) => c.contextual && c.id.startsWith('APP-'),
          ),
      'D9 has explicit contextual dignity audit, no invented child source predicates',
    );
    check(
      marriage.stages[2].status == TopicStageStatus.insufficientEvidence,
      'D2 chart existence does not match',
    );
    for (final stage in marriage.stages.where(
      (s) => s.factor == 1 || s.factor == 9,
    )) {
      for (final id in stage.ruleIds.where((id) => id.startsWith('C'))) {
        final rule = MarriageChromeIfThenEngine.rules.singleWhere(
          (r) => r.id == id,
        );
        final evaluation = MarriageChromeIfThenEngine.evaluate(rule, sample);
        check(
          stage.details.contains(evaluation.examination),
          'reuse source evidence',
        );
        check(
          stage.result.contains(rule.thenText) == evaluation.matches,
          'unmatched THEN never presented as result',
        );
      }
    }
  });
}
