import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_ashtakavarga_service.dart';
import 'package:astro_app/screens/varga_ashtakavarga_panel.dart';

void main() {
  testWidgets('PAV is disclosed in one expandable table, not repeated below',
      (tester) async {
    const planets = <PlanetPosition>[
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 10, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 44, latitude: 0, speed: 13),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 108, latitude: 0, speed: 0.7),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 152, latitude: 0, speed: 1.1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 224, latitude: 0, speed: 0.1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 281, latitude: 0, speed: 1.2),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 334, latitude: 0, speed: 0.04),
    ];
    final chart = AstroChartResult(
      julianDay: 2450000.5, ayanamsaDegrees: 23.5,
      ascendantLongitude: 40, planets: planets, engineVersion: 'test',
    );
    final report = VargaAshtakavargaService.calculate(chart, 7);
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: ListView(
      children: [VargaAvHouseEvidenceTile(report: report, house: 5)],
    ))));
    expect(find.textContaining('గణన ID'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('varga-av-house-7-5')));
    await tester.pumpAndSettle();
    expect(find.textContaining('BAV'), findsWidgets);
    expect(find.textContaining('మొత్తం తనిఖీ'), findsOneWidget);
    expect(find.textContaining('జాతక పరిశీలన:'), findsNothing);
  });
}
