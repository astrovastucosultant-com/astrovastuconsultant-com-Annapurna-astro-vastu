import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/multi_chart_topic_service.dart';

AstroChartResult makeChart({required double sun, required double jupiter,
    bool includeJupiter = true}) => AstroChartResult(
  julianDay: 2450000,
  ayanamsaDegrees: 24,
  ascendantLongitude: 5,
  engineVersion: 'test',
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: sun,
        latitude: 0, speed: 1),
    if (includeJupiter)
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: jupiter,
          latitude: 0, speed: 1),
  ],
);

void main() {
  test('D1 5L in 9th verifies the user-declared OR rule', () {
    final stage = MultiChartTopicService.evaluateFiveNine(
      makeChart(sun: 245, jupiter: 45), 1);
    expect(stage.status, TopicStageStatus.matched);
    expect(stage.details, contains('5L 9వ భావంలో'));
  });

  test('D1 without any six alternatives does not match', () {
    final stage = MultiChartTopicService.evaluateFiveNine(
      makeChart(sun: 45, jupiter: 285), 1);
    expect(stage.status, TopicStageStatus.notMatched);
  });

  test('missing planet position is insufficient, never negative', () {
    final stage = MultiChartTopicService.evaluateFiveNine(
      makeChart(sun: 45, jupiter: 285, includeJupiter: false), 1);
    expect(stage.status, TopicStageStatus.insufficientEvidence);
  });

  test('17 topic chart reviews include user D1-D9-D10 career core without invented hits', () {
    final summaries = MultiChartTopicService.summarize(
      chart: makeChart(sun: 45, jupiter: 285), evaluatedRules: const []);
    expect(summaries.length, 17);
    expect(summaries.first.stages.map((s) => s.factor).toList(), [1, 9, 10]);
    expect(summaries.first.chartOrderSourceId, 'USER-CAREER-CORE-BUSINESS');
    expect(summaries.first.totalStages, 3);
    expect(summaries[1].name, 'ఉద్యోగం / సర్వీస్');
    expect(summaries[1].stages.map((s) => s.factor).toList(), [1, 9, 10]);
    expect(summaries.firstWhere((t) => t.name == 'సంతానం').stages.map((s) => s.factor).toList(), [1, 7, 9]);
    expect(summaries.firstWhere((t) => t.name == 'ఆరోగ్యం').confirmationPercent, isNull);
    expect(summaries.firstWhere((t) => t.name == 'ప్రభుత్వ ఉద్యోగం').stages.first.status, TopicStageStatus.notMatched);
  });
}
