import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/astro_models.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/screens/topic_result_card_v398.dart';
import '../lib/screens/topic_varga_review_panel.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 63,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.4,
        'Moon': 115.1,
        'Mars': 156.2,
        'Mercury': 242.6,
        'Jupiter': 189.8,
        'Venus': 280.3,
        'Saturn': 176.7,
        'Rahu': 75.5,
        'Ketu': 255.5,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  final summary = MultiChartTopicService.summarize(
    chart: chart,
    evaluatedRules: [],
  ).singleWhere((s) => s.chartOrderSourceId == 'VARGA-CROSS-014');
  test(
    'fame bypasses source-only pending and keeps complete chart evaluations',
    () {
      expect(summary.name, 'కీర్తి / అపకీర్తి');
      expect(summary.supplement, isNotNull);
      expect(summary.confirmationPercent, isNull);
      expect(summary.stages.map((s) => s.factor), [1, 10, 9]);
      expect(
        summary.stages.every((s) => s.status == TopicStageStatus.matched),
        isTrue,
      );
      expect(
        summary.supplement!.conclusion,
        contains('అపకీర్తి / ప్రతిష్ఠ జాగ్రత్తలు:'),
      );
    },
  );
  testWidgets(
    'both reputation outcomes and chart source inspection are visible',
    (tester) async {
      tester.view.physicalSize = const Size(900, 1800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: TopicVargaReviewPanel(chart: chart, summary: summary),
            ),
          ),
        ),
      );
      expect(
        find.byKey(const ValueKey('client-guidance-406-VARGA-CROSS-014')),
        findsOneWidget,
      );
      expect(find.text(summary.supplement!.conclusion), findsOneWidget);
      for (final f in [1, 10, 9])
        expect(
          find.byKey(ValueKey('topic-chart-VARGA-CROSS-014-$f')),
          findsOneWidget,
        );
      await tester.tap(
        find.byKey(const ValueKey('topic-result-398-VARGA-CROSS-014')),
      );
      await tester.pumpAndSettle();
      expect(find.text('మూలాలు'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets('fame guidance wraps in narrow large Telugu view', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(320, 1800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(
      MaterialApp(
        home: MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(1.8)),
          child: Scaffold(
            body: SingleChildScrollView(
              child: TopicResultCard398(report: summary.supplement!),
            ),
          ),
        ),
      ),
    );
    expect(
      find.textContaining('అపకీర్తి / ప్రతిష్ఠ జాగ్రత్తలు:'),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);
  });
}
