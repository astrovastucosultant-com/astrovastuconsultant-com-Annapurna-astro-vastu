import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:astro_app/settings/app_font_scale.dart';
import 'package:astro_app/settings/app_font_size_controls.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('BNN has text-size controls, buttons resize and reset', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await AnnapurnaFontScale.instance.load();
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(body: AnnapurnaFontSizeControls()),
    ));
    expect(find.text('100%'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('annapurna-font-increase')));
    await tester.pump();
    expect(find.text('110%'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('annapurna-font-reset')));
    await tester.pump();
    expect(find.text('100%'), findsOneWidget);
  });
}
