import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

PlanetPosition _planet(String name, String code, double longitude) =>
    PlanetPosition(name: name, shortName: code, longitude: longitude,
        latitude: 0, speed: 1);

AstroChartResult _example() => AstroChartResult(
  julianDay: 2451545,
  ayanamsaDegrees: 23,
  ascendantLongitude: 0,
  engineVersion: 'v328-regression',
  planets: [
    _planet('Sun', 'Su', 1), _planet('Moon', 'Mo', 2),
    _planet('Mars', 'Ma', 3), _planet('Mercury', 'Me', 4),
    _planet('Jupiter', 'Ju', 5), _planet('Venus', 'Ve', 6),
    _planet('Saturn', 'Sa', 7), _planet('Rahu', 'Ra', 8),
    _planet('Ketu', 'Ke', 9),
  ],
);

void main() {
  test('D10 exact names must never be matched when birth 10th is empty', () {
    final rows = VargaRuleService.allFor(chart: _example(), factor: 10);
    for (final id in <String>[
      'D10-EXACT-PROF-SUMMARY',
      'D10-EXACT-PROF-LIST',
      'D10-PROF-ASTROLOGER',
      'D10-PROF-CONSULTANT',
    ]) {
      final row = rows.singleWhere((r) => r.ruleId == id);
      expect(row.autoEvaluated && row.applicable, isFalse,
          reason: '$id cannot claim an exact profession without full IF–THEN');
    }
  });

  test('supporting broad fields and devata remain audit only', () {
    final rows = VargaRuleService.allFor(chart: _example(), factor: 10);
    for (final id in <String>[
      'D10-PROF-LIST',
      'D10-PRIMARY-PROF',
      'D10-DEVATA-PROF',
    ]) {
      final row = rows.singleWhere((r) => r.ruleId == id);
      expect(row.autoEvaluated && row.applicable, isFalse,
          reason: '$id is supporting evidence, not an exact result');
      expect(row.result, isNotEmpty);
    }
  });

  test('all D10 source rules remain present after display gating', () {
    final rows = VargaRuleService.allFor(chart: _example(), factor: 10);
    final ids = rows.map((r) => r.ruleId).toSet();
    expect(ids, containsAll(<String>{
      'D10-PROF-MODE-SOURCE',
      'D10-EXACT-PROF-SUMMARY',
      'D10-EXACT-PROF-LIST',
      'D10-PROF-LIST',
      'D10-PROF-ASTROLOGER',
    }));
  });
}
