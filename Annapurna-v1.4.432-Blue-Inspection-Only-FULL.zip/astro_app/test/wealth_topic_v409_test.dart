import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/multi_chart_topic_service.dart';
import '../lib/astrology/topic_results_v398.dart';
import '../lib/astrology/wealth_topic_v409.dart';
import '../lib/screens/topic_varga_review_panel.dart';
import '../lib/screens/wealth_review_panel_v409.dart';
import '../lib/screens/topic_result_card_v391.dart';
import '../tool/verify_wealth_topic_v409.dart' show fixture409;

void main() {
  final chart = fixture409(4, [235, 115, 156, 242, 189, 280, 176, 75, 255]);
  final all = MultiChartTopicService.summarize(
    chart: chart,
    evaluatedRules: [],
  );
  final summary = all.singleWhere(
    (s) => s.chartOrderSourceId == WealthTopic409.id,
  );
  testWidgets('wealth event card opens its dedicated report', (tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: TopicResultCard391(chart: chart, summary: summary),
        ),
      ),
    );
    await tester.tap(
      find.byKey(const ValueKey('topic-result-USER-WEALTH-409')),
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const ValueKey('wealth-panel-409')), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
  test(
    'wealth integrates as 17th topic without fake factors or chart percentages',
    () {
      expect(all.length, 17);
      expect(summary.wealth, isNotNull);
      expect(summary.stages, isEmpty);
      expect(summary.confirmationPercent, isNull);
      expect(summary.displayCoverage, contains('ధనం'));
      final missing = MultiChartTopicService.summarize(
        chart: fixture409(0, [1, 2]),
        evaluatedRules: [],
      ).last;
      expect(missing.wealth!.grade, TopicGrade398.missing);
      expect(missing.confirmationPercent, isNull);
    },
  );
  Widget page({double scale = 1}) => MaterialApp(
    home: Scaffold(
      body: MediaQuery(
        data: MediaQueryData(textScaler: TextScaler.linear(scale)),
        child: SingleChildScrollView(
          child: TopicVargaReviewPanel(chart: chart, summary: summary),
        ),
      ),
    ),
  );
  testWidgets('D1 once plus three views and each source inspection opens', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(900, 1800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    for (final key in ['d1', 'd2', 'labha', 'indu']) {
      await tester.pumpWidget(page());
      await tester.pumpAndSettle();
      for (final k in ['d1', 'd2', 'labha', 'indu'])
        expect(find.byKey(ValueKey('wealth-view-409-$k')), findsOneWidget);
      final view = key == 'd1'
          ? summary.wealth!.foundation!
          : summary.wealth!.views.singleWhere((v) => v.key == key);
      final title = find.descendant(
        of: find.byKey(ValueKey('wealth-open-409-$key')),
        matching: find.text(view.title),
      );
      await tester.ensureVisible(title);
      await tester.pumpAndSettle();
      await tester.tap(title);
      await tester.pumpAndSettle();
      expect(
        find.byKey(ValueKey('wealth-detail-scroll-409-$key')),
        findsOneWidget,
      );
      expect(find.text('${view.title} — రూల్ / జాతక పరిశీలన'), findsOneWidget);
      expect(tester.takeException(), isNull);
      // Remove the page and its Navigator before the next independent tap.
      await tester.pumpWidget(const SizedBox());
      await tester.pumpAndSettle();
    }
  });
  testWidgets('320px large text chart labels remain bounded', (tester) async {
    tester.view.physicalSize = const Size(320, 1400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(page(scale: 1.8));
    await tester.pumpAndSettle();
    expect(find.byType(WealthChart409), findsNWidgets(4));
    expect(tester.takeException(), isNull);
  });
}
