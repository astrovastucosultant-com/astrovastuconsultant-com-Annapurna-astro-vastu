import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_saturn_cycle_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const chart=AstroChartResult(julianDay:2460000,
    ayanamsaDegrees:24,ascendantLongitude:78.8,engineVersion:'cycle-356',
    planets:[
      PlanetPosition(name:'Saturn',shortName:'Sa',longitude:54.89,latitude:0,speed:1),
      PlanetPosition(name:'Rahu',shortName:'Ra',longitude:272.3,latitude:0,speed:-1),
      PlanetPosition(name:'Venus',shortName:'Ve',longitude:71.87,latitude:0,speed:1),
      PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:245.25,latitude:0,speed:1),
    ]);

  test('four Saturn cycles yield 48 ordered 2.5-year windows',() async {
    final themes=await BnnSaturnCycleService.loadThemes();
    final cycles=BnnSaturnCycleService.calculate(chart:chart,themes:themes);
    final rows=cycles.expand((c)=>c.windows).toList();
    expect(cycles.length,4);
    expect(rows.length,48);
    expect(rows.first.ageStart,0);
    expect(rows.first.ageEnd,2.5);
    expect(rows.last.ageStart,117.5);
    expect(rows.last.ageEnd,120);
    expect(rows.map((e)=>e.calculationId).toSet().length,48);
    expect(cycles.map((c)=>c.windows.first.signIndex).toList(),[1,1,1,1]);
  });
  test('first-round Saturn to Rahu source heuristic only in first round',() async {
    final cycles=BnnSaturnCycleService.calculate(chart:chart,
      themes:await BnnSaturnCycleService.loadThemes());
    final first=cycles[0].windows.singleWhere((v)=>v.firstRoundRahuProfessionIndicator);
    expect(first.ageStart,20);
    expect(first.ageEnd,22.5);
    expect(cycles.skip(1).expand((c)=>c.windows)
      .any((v)=>v.firstRoundRahuProfessionIndicator),isFalse);
  });
  test('fourth Saturn round has no invented general prediction',() async {
    final themes=await BnnSaturnCycleService.loadThemes();
    expect(themes[3].focus,isNull);
  });
  test('no Saturn => no Saturn cycles',() async {
    const empty=AstroChartResult(julianDay:2460000,ayanamsaDegrees:24,
      ascendantLongitude:78.8,engineVersion:'missing',planets:[]);
    expect(BnnSaturnCycleService.calculate(chart:empty,
      themes:await BnnSaturnCycleService.loadThemes()),isEmpty);
  });
}
