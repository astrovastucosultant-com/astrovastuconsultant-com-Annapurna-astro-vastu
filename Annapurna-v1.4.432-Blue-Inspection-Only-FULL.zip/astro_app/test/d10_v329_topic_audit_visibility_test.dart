import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_topic_rule_bridge.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';

D10VruttiMatch _m(String profession, {bool complete = false}) =>
    D10VruttiMatch(D10VruttiRule(
      id: 'TEST-$profession', category: 'source', page: 1,
      condition: 'IF X THEN Y', profession: profession,
      planets: const ['Sun'], deity: null, houses: const [],
      mode: null, uncertain: const [],
    ), true, complete, complete ? 100 : 50,
    const ['condition X'], const ['condition Y failed'],
    const ['timing pending']);

void main() {
  test('Finance incomplete matches remain auditable but not predictive', () {
    final items = [_m('బ్యాంక్ మేనేజర్'), _m('గోల్డ్ లోన్'),
      _m('సివిల్ ఇంజినీర్')];
    expect(D10TopicRuleBridge.forTopic('బ్యాంకింగ్ / ఫైనాన్స్', items), isEmpty);
    expect(D10TopicRuleBridge.auditForTopic('బ్యాంకింగ్ / ఫైనాన్స్', items)
        .map((m) => m.rule.profession),
      ['బ్యాంక్ మేనేజర్', 'గోల్డ్ లోన్']);
  });
  test('Engineering full match is not duplicated in audit', () {
    final items = [_m('సివిల్ ఇంజినీర్', complete: true),
      _m('మెకానికల్ ఇంజినీర్')];
    expect(D10TopicRuleBridge.forTopic('టెక్నికల్ / ఇంజినీరింగ్', items)
        .length, 1);
    expect(D10TopicRuleBridge.auditForTopic('టెక్నికల్ / ఇంజినీరింగ్', items)
        .length, 1);
  });
  test('No invented profit/loss or career stages', () {
    expect(D10TopicRuleBridge.auditForTopic('వృత్తిలో పెట్టుబడి / నష్టం',
        [_m('బ్యాంక్ మేనేజర్')]), isEmpty);
  });
}
