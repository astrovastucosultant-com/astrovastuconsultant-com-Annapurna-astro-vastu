import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/sunrise_vara_service.dart';
import 'package:astro_app/models/birth_data.dart';

void main(){
  BirthData data(DateTime local)=>BirthData(name:'test',
    localDateTime:local,place:'Guntur',latitude:16.3,longitude:80.4,
    timezoneOffsetHours:5.5,ayanamsa:AyanamsaType.lahiri);
  final sunrise=DateTime.utc(2026,11,2,0,30); // Monday 06:00 IST
  test('Monday before 06:00 sunrise is Sunday',(){
    final r=SunriseVaraService.resolve(data(DateTime(2026,11,2,5,59)),sunrise);
    expect(r.beforeSunrise,true);
    expect(r.civilWeekday,DateTime.monday);
    expect(r.solarWeekday,DateTime.sunday);
  });
  test('Exact sunrise is Monday; no off-by-one',(){
    final r=SunriseVaraService.resolve(data(DateTime(2026,11,2,6,0)),sunrise);
    expect(r.beforeSunrise,false);
    expect(r.solarWeekday,DateTime.monday);
  });
  test('Late Monday stays Monday',(){
    final r=SunriseVaraService.resolve(data(DateTime(2026,11,2,23,59)),sunrise);
    expect(r.solarWeekday,DateTime.monday);
  });
  test('Sunrise must belong to the same civil date at birthplace',(){
    expect(()=>SunriseVaraService.resolve(
      data(DateTime(2026,11,2,5,0)),DateTime.utc(2026,11,1,0,30)),
      throwsArgumentError);
  });
  test('UTC midnight maps correctly for +5:30 offset',(){
    final m=SunriseVaraService.midnightUtc(data(DateTime(2026,11,2,5,0)));
    expect(m,DateTime.utc(2026,11,1,18,30));
  });
}
