import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d2_rule_conflict_service.dart';

void main() {
  test('contradictory vehicle matches produce one mixed result with both IDs', () {
    final found = D2RuleConflictService.detect({'D2-VH-003', 'D2-VH-006'});
    expect(found.length, 1);
    expect(found.single.id, 'D2-CONFLICT-VEHICLE');
    expect(found.single.matchedRuleIds, {'D2-VH-003', 'D2-VH-006'});
  });

  test('a matched adverse rule alone is adverse, not conflict', () {
    expect(D2RuleConflictService.detect({'D2-VH-006'}), isEmpty);
    expect(D2RuleConflictService.detect({'D2-VH-003'}), isEmpty);
  });

  test('opposed property rules are independently detected', () {
    final found = D2RuleConflictService.detect({'D2-PR-002', 'D2-PR-005'});
    expect(found.map((c) => c.id), ['D2-CONFLICT-PROPERTY']);
  });

  test('different topics and delayed vehicle do not create fake conflict', () {
    expect(D2RuleConflictService.detect({'D2-VH-003', 'D2-VH-007', 'D2-IH-005'}), isEmpty);
  });
}
