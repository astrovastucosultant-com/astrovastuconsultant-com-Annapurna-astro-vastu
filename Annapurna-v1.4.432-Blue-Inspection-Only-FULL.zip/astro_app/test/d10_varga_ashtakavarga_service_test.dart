import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/d10_varga_ashtakavarga_service.dart';

void main() {
  const positions = <PlanetPosition>[
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 10.1, latitude: 0, speed: 1),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 42.2, latitude: 0, speed: 12),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 75.3, latitude: 0, speed: 0.5),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108.4, latitude: 0, speed: 1),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 141.5, latitude: 0, speed: 0.1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 174.6, latitude: 0, speed: 1),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 207.7, latitude: 0, speed: -0.1),
    PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 240, latitude: 0, speed: -0.05),
    PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 60, latitude: 0, speed: -0.05),
  ];
  const chart = AstroChartResult(
    julianDay: 2460000.5, ayanamsaDegrees: 24,
    ascendantLongitude: 18, planets: positions, engineVersion: 'test',
  );

  test('Both natal and D10 have separately audited 337 point SAV', () {
    final x = D10VargaAshtakavargaService.calculate(chart);
    expect(x.auditPassed, isTrue);
    expect(x.natal.grandTotal, 337);
    expect(x.dashamsa.grandTotal, 337);
    for (final h in [1, 2, 6, 7, 8, 10, 11, 12]) {
      expect(x.dashamsaSav(h), inInclusiveRange(0, 56));
      expect(x.evidenceForHouse(h), isNotEmpty);
    }
  });

  test('D10 sign positions follow the same varga service used in chart', () {
    final x = D10VargaAshtakavargaService.calculate(chart);
    final d10 = VargaService.calculate(chart, 10);
    expect(x.dashamsaLagnaSign, d10.ascendantSignIndex);
    for (final p in positions) {
      final mappedSign = VargaService.d10LongitudeForLongitude(p.longitude) ~/ 30;
      expect(mappedSign, d10.planets.firstWhere((d) => d.name == p.name).signIndex);
    }
  });

  test('D10 SAV changes independently of D1 SAV for within-sign movement', () {
    final other = AstroChartResult(
      julianDay: chart.julianDay,
      ayanamsaDegrees: chart.ayanamsaDegrees,
      ascendantLongitude: chart.ascendantLongitude,
      planets: [
        for (final p in positions)
          if (p.name == 'Sun')
            const PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 11.1, latitude: 0, speed: 1)
          else p,
      ],
      engineVersion: chart.engineVersion,
    );
    final a = D10VargaAshtakavargaService.calculate(chart);
    final b = D10VargaAshtakavargaService.calculate(other);
    expect(a.natal.sarva, b.natal.sarva);
    // Both longitudes are within the 9°–12° dasamsa; D10 SAV stays fixed.
    expect(a.dashamsa.sarva, b.dashamsa.sarva);

    // Moving the Sun to 12°+ leaves its D1 sign unchanged, but moves it to
    // the next D10 sign. D1 SAV remains fixed while D10 SAV changes.
    final crossing = AstroChartResult(
      julianDay: chart.julianDay,
      ayanamsaDegrees: chart.ayanamsaDegrees,
      ascendantLongitude: chart.ascendantLongitude,
      planets: [
        for (final p in positions)
          if (p.name == 'Sun')
            const PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 12.1, latitude: 0, speed: 1)
          else p,
      ],
      engineVersion: chart.engineVersion,
    );
    final c = D10VargaAshtakavargaService.calculate(crossing);
    expect(a.natal.sarva, c.natal.sarva);
    expect(a.dashamsa.sarva, isNot(c.dashamsa.sarva));
  });
}
