import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_financial_evidence_v373.dart';
import 'package:astro_app/astrology/d2_wealth_evaluation_service.dart';
import 'package:astro_app/screens/bnn_financial_card_v373.dart';

void main() {
  testWidgets(
    'profit and loss cards never display cycle ages or a dated outcome',
    (tester) async {
      final data = BnnFinancialEvidenceServiceV373.fromMatches(const [
        D2WealthMatch(
          ruleId: 'D2-OT-002',
          percent: 100,
          evidence: 'gain inspection',
        ),
        D2WealthMatch(
          ruleId: 'D2-OT-003',
          percent: 100,
          evidence: 'loss inspection',
          caution: true,
        ),
      ]);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: Column(
                children: [
                  BnnFinancialCardV373(assessment: data['PROFIT']!),
                  BnnFinancialCardV373(assessment: data['LOSS']!),
                ],
              ),
            ),
          ),
        ),
      );
      await tester.tap(find.byKey(const ValueKey('bnn-life-PROFIT')));
      await tester.pumpAndSettle();
      expect(
        find.byKey(const ValueKey('bnn-finance-PROFIT-D2-OT-002')),
        findsOneWidget,
      );
      expect(find.textContaining('100%'), findsNothing);
      expect(find.textContaining('గ్రహస్పర్శ వయస్సు 2'), findsNothing);
      expect(find.textContaining('సంఘటన సమయం: నిర్ణయించలేదు'), findsOneWidget);
      await tester.tap(find.textContaining('1. రూల్: D2-OT-002'));
      await tester.pumpAndSettle();
      expect(
        find.textContaining('Dhana_Aasthi_Rules.pdf • page 6'),
        findsOneWidget,
      );
      expect(find.textContaining('2. జాతక పరిశీలన'), findsOneWidget);
      await tester.tap(find.text('2. జాతక పరిశీలన'));
      await tester.pumpAndSettle();
      expect(find.text('gain inspection'), findsOneWidget);
      expect(find.text('3. హైలైట్ ఫలితం'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
}
