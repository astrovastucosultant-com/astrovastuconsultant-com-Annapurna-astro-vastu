import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_unified_rule_service.dart';

const sample = AstroChartResult(
  julianDay: 2441542.0,
  ayanamsaDegrees: 23,
  ascendantLongitude: 75,
  engineVersion: 'v324-source-regression',
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 110,
        latitude: 0, speed: 0.9),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 160,
        latitude: 0, speed: 13),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 122,
        latitude: 0, speed: 0.5),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108,
        latitude: 0, speed: 0.2),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 245,
        latitude: 0, speed: -0.1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 71,
        latitude: 0, speed: 0.2),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 58,
        latitude: 0, speed: 0.1),
    PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 272,
        latitude: 0, speed: -0.1),
    PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 92,
        latitude: 0, speed: -0.1),
  ],
);

AstroChartResult withLagna(double lagna) => AstroChartResult(
  julianDay: sample.julianDay,
  ayanamsaDegrees: sample.ayanamsaDegrees,
  ascendantLongitude: lagna,
  engineVersion: sample.engineVersion,
  planets: sample.planets,
);

UnifiedVargaRule byId(List<UnifiedVargaRule> all, String id) =>
    all.firstWhere((r) => r.id == id);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('D9 D10 and D45 calculable conditions are tested, not source-only', () async {
    final rules = await VargaUnifiedRuleService.evaluate(sample);
    for (final id in <String>[
      'VARGA-D9-002', 'VARGA-D10-001', 'VARGA-D10-002',
      'VARGA-D45-002', 'VARGA-CROSS-028',
    ]) {
      final rule = byId(rules, id);
      expect(rule.status, isNot(UnifiedVargaRuleStatus.pending), reason: id);
      expect(rule.source, contains('Mallikarjuna PDF'));
      expect(rule.source, contains('పేజీ'));
      expect(rule.evidence, isNotEmpty);
    }
    for (final id in <String>['VARGA-D10-008', 'VARGA-D24-002']) {
      expect(byId(rules, id).evidence, isNotEmpty, reason: id);
    }
  });

  test('10th lord Mercury must not be self-conjunct to Mercury', () async {
    const lords = <String>[
      'Mars','Venus','Mercury','Moon','Sun','Mercury',
      'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
    ];
    AstroChartResult? found;
    for (var degree = 0; degree < 360; degree++) {
      final trial = withLagna(degree + 0.1);
      final c = VargaService.calculate(trial, 10);
      if (lords[(c.ascendantSignIndex + 9) % 12] == 'Mercury') {
        found = trial;
        break;
      }
    }
    expect(found, isNotNull);
    final data = await VargaUnifiedRuleService.evaluate(found!);
    expect(byId(data, 'VARGA-D10-001').status,
        UnifiedVargaRuleStatus.notMatched);
  });

  test('business sign/yuti source rule includes a definite false or true', () async {
    final results = await VargaUnifiedRuleService.evaluate(sample);
    final business = byId(results, 'VARGA-CROSS-028');
    expect(business.status, anyOf(UnifiedVargaRuleStatus.matched,
        UnifiedVargaRuleStatus.notMatched));
    expect(business.evidence, contains('D10 10L'));
  });

  test('D12 two-clause result never asserts match on just one support', () async {
    final results = await VargaUnifiedRuleService.evaluate(sample);
    for (final id in <String>['VARGA-D12-006', 'VARGA-D12-007']) {
      final r = byId(results, id);
      expect(r.evidence, contains('రెండు షరతులూ అవసరం'));
    }
    final saturn = byId(results, 'VARGA-D12-012');
    expect(saturn.evidence, contains('రాహు ప్రత్యేక దృష్టి'));
  });
}
