import 'astro_models.dart';
import 'bnn_master_service.dart';

/// Checks ONLY entire, unambiguous natal clauses from the user's 462-rule
/// IF–THEN catalog. An OCR source can have an observable natal predicate
/// without its wording having been independently verified against the scan.
/// No transit/timing, implied aspect, inferred conjunction, or partial-clause
/// matching is permitted here.
class BnnExactIfResult {
  final bool evaluable;
  final bool matched;
  final String reason;
  const BnnExactIfResult(this.evaluable, this.matched, this.reason);
  static const unsupported = BnnExactIfResult(false, false,
      'మొత్తం IF షరతును ఆటోమేటిక్‌గా గణించే విధానం ఇంకా లేదు.');
}

class BnnExactIfEngine {
  static const _p = r'(?:సూర్యుడు|సూర్య|రవి|చంద్రుడు|చంద్ర|కుజుడు|కుజ|బుధుడు|బుధ|గురుడు|గురు|శుక్రుడు|శుక్ర|శని|రాహువు|రాహు|కేతువు|కేతు)';
  static const _s = r'(?:మేషం|వృషభం|మిథునం|మిథున|కర్కాటకం|సింహం|కన్య|తుల|వృశ్చికం|ధనుస్సు|మకరం|కుంభం|మీనం)';

  static PlanetPosition? _planet(String name, AstroChartResult chart) {
    final english = BnnMasterAnalysis.teluguPlanetNames[name];
    if (english == null) return null;
    for (final planet in chart.planets) {
      if (planet.name == english) return planet;
    }
    return null;
  }

  static int? _sign(String name) {
    if (name == 'మిథున') return 2;
    final i = BnnMasterAnalysis.signNames.indexOf(name);
    return i < 0 ? null : i;
  }

  static BnnExactIfResult _checkPlanets(
      AstroChartResult chart, List<String> names,
      bool Function(List<PlanetPosition>) predicate, String explanation) {
    final found = <PlanetPosition>[];
    for (final name in names) {
      final p = _planet(name, chart);
      if (p == null) return const BnnExactIfResult(true, false,
          'IFలో పేర్కొన్న గ్రహస్థితి ఈ జాతకంలో అందుబాటులో లేదు.');
      found.add(p);
    }
    final ok = predicate(found);
    final positions = found.map((p) =>
        '${p.name}: ${BnnMasterAnalysis.signNames[p.signIndex]} '
        '${p.degreesInSign.toStringAsFixed(2)}°').join(' • ');
    return BnnExactIfResult(true, ok,
      '$explanation • $positions • ${ok ? 'జన్మస్థితి సరిపోయింది' : 'జన్మస్థితి సరిపోలలేదు'}');
  }

  static BnnExactIfResult check(BnnMasterRule rule, AstroChartResult chart) {
    // Do not silently promote BNN N shorthand: this evaluator is specifically
    // for the supplied book's strictly parseable natal statements.
    if (rule.status != 'OCR_REVIEW' ||
        rule.source != 'Brighu_Naadi_Purnna_Rulebook.pdf') {
      return BnnExactIfResult.unsupported;
    }
    final text = rule.condition.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (text.isEmpty) return BnnExactIfResult.unsupported;
    RegExpMatch? m;

    // Exact planet in one named sign, optionally one of two named signs.
    m = RegExp('^($_p) ($_s)(?:\\/($_s))?\$').firstMatch(text);
    if (m != null) {
      final one = _sign(m.group(2)!);
      final two = m.group(3) == null ? null : _sign(m.group(3)!);
      if (one == null) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!],
        (ps) => ps[0].signIndex == one ||
            (two != null && ps[0].signIndex == two), 'నిర్దిష్ట రాశి IF');
    }

    // Fully specified single natal placement relative to Jupiter.
    m = RegExp('^గురుకి (\\d{1,2})లో ($_p)\$').firstMatch(text);
    if (m != null) {
      final house = int.tryParse(m.group(1)!);
      if (house == null || house < 1 || house > 12) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, [m.group(2)!],
          (ps) => BnnMasterAnalysis.houseOfPlanet(ps[0], chart) == house,
          'గురు రాశి నుంచి $house వ భావస్థానం');
    }
    // House number may be after planet in the source notation.
    m = RegExp('^($_p) గురుకి (\\d{1,2})(?:లో)?\$').firstMatch(text);
    if (m != null) {
      final house = int.tryParse(m.group(2)!);
      if (house == null || house < 1 || house > 12) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, [m.group(1)!],
          (ps) => BnnMasterAnalysis.houseOfPlanet(ps[0], chart) == house,
          'గురు రాశి నుంచి $house వ భావస్థానం');
    }
    // Two planets at separately specified Jupiter-relative places. Both
    // positions are mandatory; checking only the first is never sufficient.
    m = RegExp('^గురుకి (\\d{1,2})లో ($_p) \\+ (\\d{1,2})లో ($_p)\$')
        .firstMatch(text);
    if (m != null) {
      final h1 = int.tryParse(m.group(1)!);
      final h2 = int.tryParse(m.group(3)!);
      if (h1 == null || h2 == null || h1 < 1 || h1 > 12 ||
          h2 < 1 || h2 > 12) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(2)!, m.group(4)!],
        (ps) => BnnMasterAnalysis.houseOfPlanet(ps[0], chart) == h1 &&
                BnnMasterAnalysis.houseOfPlanet(ps[1], chart) == h2,
        'రెండు గురు-ఆధార భావస్థానాలూ పరిశీలించబడ్డాయి');
    }
    // Exact named-sign pair. Any explicit seventh-from-Jupiter qualifier
    // is also checked, not discarded.
    m = RegExp('^($_p) ($_s) \\+ ($_p) ($_s)(?: \\(గురుకి (\\d{1,2})\\))?\$')
        .firstMatch(text);
    if (m != null) {
      final s1 = _sign(m.group(2)!);
      final s2 = _sign(m.group(4)!);
      final h = m.group(5) == null ? null : int.tryParse(m.group(5)!);
      if (s1 == null || s2 == null || (h != null && (h < 1 || h > 12))) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, [m.group(1)!, m.group(3)!],
        (ps) => ps[0].signIndex == s1 && ps[1].signIndex == s2 &&
          (h == null || BnnMasterAnalysis.houseOfPlanet(ps[1], chart) == h),
        'రెండు నిర్దిష్ట రాశులు; అదనపు భావ షరతు ఉంటే దానినీ పరిశీలించాం');
    }

    // Explicit conjunction shorthand with no other unchecked IF component.
    m = RegExp('^($_p)(?:\\+($_p)){1,3}(?: ఒకే ఇల్లు)?\$')
        .firstMatch(text);
    if (m != null) {
      final names = text.replaceAll(' ఒకే ఇల్లు', '').split('+');
      if (names.toSet().length != names.length) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, names,
        (ps) => ps.every((p) => p.signIndex == ps.first.signIndex),
        'మూల IFలోని + చిహ్నాన్ని ఒకే రాశి సహస్థితిగా మాత్రమే పరిశీలించాం');
    }

    // Single retrograde or classical exaltation/debilitation sign.
    m = RegExp('^($_p) (వక్రం|ఉచ్చం|నీచం)\$').firstMatch(text);
    if (m != null) {
      const exalt = <String, int>{'Sun': 0, 'Moon': 1, 'Mars': 9,
        'Mercury': 5, 'Jupiter': 3, 'Venus': 11, 'Saturn': 6};
      const debil = <String, int>{'Sun': 6, 'Moon': 7, 'Mars': 3,
        'Mercury': 11, 'Jupiter': 9, 'Venus': 5, 'Saturn': 0};
      final quality = m.group(2)!;
      final name = BnnMasterAnalysis.teluguPlanetNames[m.group(1)!];
      if (name == null || (quality != 'వక్రం' && !exalt.containsKey(name))) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, [m.group(1)!], (ps) {
        if (quality == 'వక్రం') return ps[0].speed < 0;
        return ps[0].signIndex ==
            (quality == 'ఉచ్చం' ? exalt[name] : debil[name]);
      }, quality == 'వక్రం' ? 'జన్మ వేగం (వక్ర స్థితి)' : 'సాంప్రదాయ $quality రాశి');
    }
    return BnnExactIfResult.unsupported;
  }
}
