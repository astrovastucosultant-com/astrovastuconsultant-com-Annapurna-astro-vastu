# BNN v1.4.266 Build Version Fix

Source code: exactly v1.4.265 BNN Relations update.
Change: astro_app/pubspec.yaml version 1.4.264+264 -> 1.4.266+266.
Cause: both v1.4.264 and v1.4.265 archives declared version 1.4.264+264; GitHub auto-selection fails on tie.
Result: GitHub highest-app-version ZIP selection is unambiguous if repository has no other ZIP reporting version >= 1.4.266+266.

This ZIP is Flutter source, NOT an APK. Compile/analyze/test on GitHub Actions.
