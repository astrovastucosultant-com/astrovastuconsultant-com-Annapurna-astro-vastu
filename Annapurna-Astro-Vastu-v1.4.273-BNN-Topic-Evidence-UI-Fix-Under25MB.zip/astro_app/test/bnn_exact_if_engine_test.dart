import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_exact_if_engine.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';

BnnMasterRule rule(String condition, {String status = 'OCR_REVIEW',
    String source = 'Brighu_Naadi_Purnna_Rulebook.pdf'}) => BnnMasterRule(
  id: 'BNN-BOOK-TEST', source: source, sourcePage: 3,
  topic: 'నమూనా', condition: condition, result: 'మూల THEN నమూనా',
  inspection: 'పూర్తి మూలగ్రంథ నిర్ధారణ అవసరం', remedy: '', status: status,
);

AstroChartResult chart({double guru = 41, double kuja = 19,
    double sun = 91, double saturn = 61, double venus = 42,
    double mercury = 43, double jSpeed = .1}) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 3,
  planets: [
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: guru,
        latitude: 0, speed: jSpeed),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: kuja,
        latitude: 0, speed: .1),
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: sun,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: saturn,
        latitude: 0, speed: .1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: venus,
        latitude: 0, speed: .1),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: mercury,
        latitude: 0, speed: .1),
  ], engineVersion: 'test',
);

void main() {
  test('All conditions of double Jupiter-relative IF are mandatory', () {
    final r = rule('గురుకి 3లో శని + 4లో సూర్యుడు');
    expect(BnnExactIfEngine.check(r, chart(guru: 2)).matched, isTrue);
    expect(BnnExactIfEngine.check(r, chart(guru: 2, sun: 121)).matched, isFalse);
    expect(BnnExactIfEngine.check(r, chart(guru: 2)).evaluable, isTrue);
  });

  test('Position relative to Jupiter, not lagna', () {
    final r = rule('గురుకి 12లో కుజుడు');
    expect(BnnExactIfEngine.check(r, chart(guru: 42)).matched, isTrue);
    expect(BnnExactIfEngine.check(r, chart(guru: 2)).matched, isFalse);
  });

  test('All conjunction planets must share the SAME sign', () {
    final r = rule('గురు+శుక్ర+బుధ');
    expect(BnnExactIfEngine.check(r, chart()).matched, isTrue);
    expect(BnnExactIfEngine.check(r, chart(mercury: 133)).matched, isFalse);
  });

  test('Two named signs AND explicit house qualification checked', () {
    final r = rule('గురు కుంభం + సూర్యుడు సింహం (గురుకి 7)');
    expect(BnnExactIfEngine.check(r, chart(guru: 309, sun: 140)).matched, isTrue);
    expect(BnnExactIfEngine.check(r, chart(guru: 309, sun: 95)).matched, isFalse);
  });

  test('Retrograde is computed from actual negative speed', () {
    final r = rule('గురు వక్రం');
    expect(BnnExactIfEngine.check(r, chart(jSpeed: -.2)).matched, isTrue);
    expect(BnnExactIfEngine.check(r, chart(jSpeed: .2)).matched, isFalse);
  });

  test('Transit, partial compound, and source status never promoted', () {
    expect(BnnExactIfEngine.check(
      rule('గురు రెండవ రౌండ్‌లో శుక్ర తాకితే'), chart()).evaluable, isFalse);
    expect(BnnExactIfEngine.check(
      rule('గురు+శుక్ర + శని దృష్టి'), chart()).evaluable, isFalse);
    expect(BnnExactIfEngine.check(
      rule('గురు+శుక్ర', status: 'REVIEW'), chart()).evaluable, isFalse);
    expect(BnnExactIfEngine.check(
      rule('గురు+శుక్ర', source: 'BNN N'), chart()).evaluable, isFalse);
  });

  test('Source catalog remains 462; strict OCR clauses are subset only', () async {
    final catalog = await BnnMasterCatalog.load();
    expect(catalog.length, 462);
    final ocr = catalog.where((r) => r.status == 'OCR_REVIEW').toList();
    expect(ocr.length, 343);
    final computable = ocr.where((r) =>
        BnnExactIfEngine.check(r, chart()).evaluable).toList();
    expect(computable.length, 71);
  });
}
