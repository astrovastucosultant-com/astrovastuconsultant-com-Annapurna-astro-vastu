/// Navigational subject index, NOT a predictive rulebook.  The author/edition
/// citations identify chapter scope only; a listed topic must not be treated as
/// a verified V.P. Goel IF–THEN rule until the complete page is checked.
class VargaTopic {
  final String title;
  final int house;
  final List<String> matchWords;
  const VargaTopic(this.title, this.house, this.matchWords);
}

class VargaTopicCatalog {
  static const Map<int, List<VargaTopic>> _items = {
    1: [VargaTopic('లగ్నం / స్వభావం', 1, ['లగ్నం']), VargaTopic('ధనం / కుటుంబం', 2, ['ధనం']), VargaTopic('విద్య / సంతానం', 5, ['విద్య', 'సంతానం']), VargaTopic('వృత్తి / స్థాయి', 10, ['వృత్తి']), VargaTopic('వివాహం', 7, ['వివాహం'])],
    2: [VargaTopic('ధనార్జన', 2, ['ఆదాయం', 'సంపాదన', 'ధన']), VargaTopic('ధననిల్వ', 2, ['నిల్వ', 'సంపద']), VargaTopic('ఆస్తి / వాహనాల ఆర్థిక అంశం', 4, ['ఆస్తి', 'వాహన'])],
    3: [VargaTopic('సోదరులు', 3, ['సోదర']), VargaTopic('ధైర్యం / స్వప్రయత్నం', 3, ['ధైర్యం', 'స్వప్రయత్నం']), VargaTopic('22వ ద్రేక్కాణ పరిశీలన', 8, ['22వ', 'ద్రేక్కాణ'])],
    4: [VargaTopic('ఇల్లు / భూమి', 4, ['ఇల్లు', 'భూమి', 'స్థిరాస్తి']), VargaTopic('ఆస్తి కొనుగోలు', 4, ['కొనుగోలు']), VargaTopic('భాగ్యం', 9, ['భాగ్యం']), VargaTopic('విదేశీ స్థిరనివాసం', 12, ['విదేశ', 'నివాస'])],
    5: [VargaTopic('కీర్తి / గుర్తింపు', 10, ['కీర్తి', 'గుర్తింపు']), VargaTopic('అధికారం / శక్తి', 10, ['అధికారం', 'శక్తి']), VargaTopic('పంచమాంశ భావాలు', 1, ['పంచమాంశ']), VargaTopic('ఆరాధన దేవత (మూల పరిశీలన)', 9, ['దేవత', 'ఆరాధన'])],
    6: [VargaTopic('ఆరోగ్య ఆటంకాల సంప్రదాయ సూచనలు', 6, ['ఆరోగ్య', 'రోగ']), VargaTopic('6వ భావం / అధిపతి', 6, ['షష్ఠ', '6వ']), VargaTopic('అనారోగ్య సమస్యల కాల ఆధారాలు', 8, ['కాలం', 'ఆటంక']), VargaTopic('షష్ఠాంశ భావాలు', 1, ['షష్ఠాంశ'])],
    7: [VargaTopic('సంతానం', 5, ['సంతాన']), VargaTopic('బీజ/క్షేత్ర స్ఫుటం', 5, ['బీజ', 'క్షేత్ర']), VargaTopic('కవలలు / దత్తత', 5, ['కవల', 'దత్తత']), VargaTopic('సుఖభోగాలు / సృజనాత్మకత', 5, ['సుఖభోగ', 'సృజనాత్మక'])],
    8: [VargaTopic('ఆకస్మిక ఆటంకాలు', 8, ['ఆకస్మిక', 'ఆటంక']), VargaTopic('వివాదాలు / వ్యాజ్యాలు', 6, ['వివాద', 'వ్యాజ్య']), VargaTopic('అష్టమ భావ పరిశీలన', 8, ['అష్టమ']), VargaTopic('అనుకోని మార్పుల సూచనలు', 12, ['మార్పు'])],
    9: [VargaTopic('వివాహం / భాగస్వామి', 7, ['వివాహ', 'భార్య', 'భర్త']), VargaTopic('నవాంశ గ్రహబలం', 1, ['గ్రహబలం', 'బలం']), VargaTopic('ధర్మం / నైతిక దిశ', 9, ['ధర్మం']), VargaTopic('వివాహ సమయం', 7, ['వివాహ సమయం'])],
    10: [VargaTopic('గోచరిష్ట — వ్యాపారం', 7, ['వ్యాపారం', 'Self-employment']), VargaTopic('అగోచరిష్ట — ఉద్యోగం', 6, ['ఉద్యోగం', 'Service']), VargaTopic('వృత్తి స్థాయి / పదవి', 10, ['స్థాయి', 'Position']), VargaTopic('ప్రభుత్వ ఉద్యోగం', 10, ['ప్రభుత్వ', 'Government']), VargaTopic('ఎదుగుదల / పతనం', 10, ['ఎదుగుదల', 'పతనం']), VargaTopic('వృత్తి యోగాలు', 10, ['యోగం', 'Yoga'])],
    12: [VargaTopic('తండ్రి / పితృవంశం', 9, ['తండ్రి', 'పితృ']), VargaTopic('తల్లి / మాతృవంశం', 4, ['తల్లి', 'మాతృ']), VargaTopic('వంశ ఋణానుబంధం', 12, ['ఋణ', 'వంశ'])],
    16: [VargaTopic('వాహన సౌఖ్యం', 4, ['వాహన']), VargaTopic('సుఖ / అసౌఖ్యం', 4, ['సుఖం']), VargaTopic('షోడశాంశ దేవతలు', 1, ['దేవత'])],
    20: [VargaTopic('ఉపాసన / మంత్రసిద్ధి', 5, ['ఉపాసన', 'మంత్ర']), VargaTopic('ఆధ్యాత్మిక ఆసక్తి', 9, ['ఆధ్యాత్మిక']), VargaTopic('ఇష్టదేవత పరిశీలన', 5, ['ఇష్టదేవత'])],
    24: [VargaTopic('చదువు / విద్యా స్థాయి', 9, ['విద్య', 'చదువు']), VargaTopic('టెక్నికల్ / ఇతర విద్య', 5, ['టెక్నికల్']), VargaTopic('విద్య విరామం / విదేశం', 12, ['విరామం', 'విదేశ'])],
    27: [VargaTopic('శారీరక బలం', 1, ['బలం']), VargaTopic('శరీర అవయవాలు', 6, ['అవయవ']), VargaTopic('గ్రహ బలహీనతలు', 8, ['బలహీన'])],
    30: [VargaTopic('దురదృష్ట / అరిష్ట సూచనలు', 8, ['అరిష్ట', 'కష్ట']), VargaTopic('కష్టాల పరిశీలన', 6, ['కష్ట']), VargaTopic('గ్రహ పీడ', 8, ['పీడ'])],
    40: [VargaTopic('మాతృ వంశ ప్రభావం', 4, ['మాతృ']), VargaTopic('శుభ/అశుభ ప్రభావాలు', 1, ['శుభ'])],
    45: [VargaTopic('పితృ వంశ ప్రభావం', 9, ['పితృ']), VargaTopic('స్వభావం / సూక్ష్మ బలం', 1, ['స్వభావ'])],
    60: [VargaTopic('సూక్ష్మ కర్మఫల సూచనలు', 8, ['కర్మ']), VargaTopic('షష్ట్యంశ దేవత', 9, ['దేవత']), VargaTopic('వంశ సంబంధ సంకేతాలు', 12, ['వంశ'])],
  };
  static List<VargaTopic> forFactor(int factor) => _items[factor] ?? const <VargaTopic>[];
  static String topicSource(int factor) => switch (factor) {
    5 => 'V.P. Goel, Comprehensive Prediction by Divisional Charts, D5 అధ్యాయం పేజీలు 305–316 (విషయసూచిక మాత్రమే)',
    6 => 'V.P. Goel, Comprehensive Prediction by Divisional Charts, D6 అధ్యాయం పేజీలు 317–323 (విషయసూచిక మాత్రమే)',
    8 => 'V.P. Goel, Comprehensive Prediction by Divisional Charts, D8 అధ్యాయం పేజీలు 324–333 (విషయసూచిక మాత్రమే)',
    _ => 'ఈ అంశానికి సరిపోయిన అసలు IF–THEN గ్రంథం/పేజీ వేరు ధృవీకరించాలి',
  };
}
