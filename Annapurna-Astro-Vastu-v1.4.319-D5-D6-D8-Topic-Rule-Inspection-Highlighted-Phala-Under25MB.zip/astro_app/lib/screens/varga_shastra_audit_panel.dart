import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../astrology/varga_shastra_registry.dart';
import '../astrology/varga_service.dart';

/// One auditable, tap-to-expand calculation source for each of 16 vargas.
/// This deliberately does not certify all historical predictive rules/remedies.
class VargaShastraAuditPanel extends StatelessWidget {
  final int factor;
  final D16CalculationMethod d16Method;
  const VargaShastraAuditPanel({
    super.key,
    required this.factor,
    required this.d16Method,
  });

  @override
  Widget build(BuildContext context) {
    final record = VargaShastraRegistry.forFactor(factor);
    final alternativeD16 = factor == 16 &&
        d16Method == D16CalculationMethod.phaladeepika;
    return Card(
      color: const Color(0xFFF4F7FB),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        initiallyExpanded: factor == 3,
        leading: const Icon(Icons.menu_book_outlined, color: Color(0xFF315A87)),
        title: Text('D$factor — శాస్త్ర ప్రమాణం / Source Audit',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(alternativeD16
            ? 'ప్రత్యామ్నాయ గణన మూల ధృవీకరణ పెండింగ్'
            : VargaShastraRegistry.isExtended(factor)
                ? 'అదనపు వర్గం • గణన మూలం ${record.verse}'
                : 'గణనకు మూల శ్లోకం ${record.verse} · ఫలిత నియమాలకు వేరు ఆడిట్',
            style: const TextStyle(fontSize: 12)),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(VargaShastraRegistry.bookFor(factor),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text('గణన మూల విభాగం: ${record.verse} · రకం: గణన శాస్త్ర ప్రమాణం'),
              const SizedBox(height: 8),
              Text(record.construction),
              const SizedBox(height: 10),
              if (alternativeD16)
                const Text('ఈ జాతకంలో ఎంపిక చేసిన D16 ప్రత్యామ్నాయ పద్ధతిని పరాశరీ 6.16గా ధృవీకరించడం లేదు.',
                    style: TextStyle(fontWeight: FontWeight.w700)),
              Text(record.reviewNote,
                  style: const TextStyle(fontSize: 12, height: 1.5)),
              const SizedBox(height: 6),
              const Text('మూల శ్లోకం చూపడం వల్ల పాత యాప్‌లోని అన్ని ఫలిత నియమాలు '
                'స్వయంచాలకంగా గ్రంథ నిర్ధారితమయ్యాయని అర్థం కాదు.',
                style: TextStyle(fontSize: 11.5)),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () {
                  Clipboard.setData(const ClipboardData(
                    text: VargaShastraRegistry.urlFor(factor),
                  ));
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('మూలగ్రంథ URL కాపీ అయింది')),
                  );
                },
                icon: const Icon(Icons.copy_outlined, size: 17),
                label: const Text('మూలగ్రంథం లింక్ కాపీ'),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
