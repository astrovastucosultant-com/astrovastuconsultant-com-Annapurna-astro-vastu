import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/varga_service.dart';
import '../astrology/varga_topic_catalog.dart';
import '../astrology/varga_rule_service.dart';
import '../astrology/varga_shastra_registry.dart';
import 'unified_rule_result_tile.dart';

/// All chart-specific subject titles in one compact list. A source table of
/// contents is NOT an IF–THEN match. Verified hits alone highlight conclusions.
class VargaTopicsPanel extends StatelessWidget {
  const VargaTopicsPanel({
    super.key,
    required this.natal,
    required this.factor,
    required this.d16Method,
  });
  final AstroChartResult natal;
  final int factor;
  final D16CalculationMethod d16Method;

  static const _signs = <String>[
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];

  static bool matchesTopic(String text, VargaTopic topic) {
    final folded = text.toLowerCase();
    return topic.matchWords.any((w) => folded.contains(w.toLowerCase()));
  }

  static RuleVerdict verdict(VargaRuleHit rule) => switch (rule.tone) {
    VargaRuleTone.favorable => RuleVerdict.favourable,
    VargaRuleTone.caution => RuleVerdict.adverse,
    VargaRuleTone.neutral => RuleVerdict.mixed,
    VargaRuleTone.info => RuleVerdict.unverified,
  };

  String _inspection(VargaChartData data, VargaTopic topic) {
    final lagna = data.ascendantSignIndex;
    final targetSign = (lagna + topic.house - 1) % 12;
    final relevant = data.planets.where((p) => p.signIndex == targetSign)
        .map((p) => p.name).toList();
    final all = data.planets.map((p) =>
        '${p.shortName}: ${_signs[p.signIndex]}').join(' • ');
    return 'D$factor లగ్నం: ${_signs[lagna]}. '
        '${topic.house}వ భావం: ${_signs[targetSign]}. '
        'అక్కడి గ్రహాలు: ${relevant.isEmpty ? "లేవు" : relevant.join(", ")}.\n'
        'వర్గ గ్రహ రాశులు: $all.\n'
        'ఇవి గ్రహస్థితులు మాత్రమే; దృష్టి, అధిపత్యం, మూల నియమం '
        'పూర్తిగా సరిపోయినంతవరకు సంఘటన నిర్ధారణ కాదు.';
  }

  RuleResultData _sourceOnly(VargaChartData chart, VargaTopic topic) {
    final extended = VargaShastraRegistry.isExtended(factor);
    return RuleResultData(
      topic: topic.title,
      ruleId: null,
      verdict: RuleVerdict.unverified,
      ruleMatched: null,
      rule: extended
          ? 'ఈ అంశం గ్రంథ విషయసూచికలో ఉంది. పూర్తి Goel IF–THEN షరతు '
              'ధృవీకరించలేదు; P.V.R. గణన పద్ధతిని Goel ఫల నియమంగా కలపలేదు.'
          : 'ఈ అంశానికి వర్తించిన పూర్తి, ధృవీకృత IF–THEN నియమం '
              'ప్రస్తుత స్వయంచాలక ఫలితాల్లో గుర్తించబడలేదు.',
      examination: _inspection(chart, topic),
      result: '',
      source: VargaTopicCatalog.topicSource(factor),
      remedy: null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final topics = VargaTopicCatalog.forFactor(factor);
    if (topics.isEmpty) return const SizedBox.shrink();
    final data = VargaService.calculate(natal, factor, d16Method: d16Method);
    final hits = VargaRuleService.allFor(
        chart: natal, factor: factor, d16Method: d16Method);
    // No duplicate display of a matched Rule ID across related topics.
    final used = <String>{};
    final groups = <({VargaTopic topic, List<VargaRuleHit> rules})>[];
    for (final topic in topics) {
      final group = hits.where((h) => h.autoEvaluated && h.applicable &&
          h.source.trim().isNotEmpty &&
          !h.source.toUpperCase().contains('SOURCE_PENDING') &&
          !h.source.contains('పెండింగ్') &&
          matchesTopic(h.topic, topic) && !used.contains(h.ruleId))
          .take(15).toList(growable: false);
      used.addAll(group.map((h) => h.ruleId));
      groups.add((topic: topic, rules: group));
    }
    final remaining = hits.where((h) => h.autoEvaluated && h.applicable &&
        h.source.trim().isNotEmpty &&
        !h.source.toUpperCase().contains('SOURCE_PENDING') &&
        !h.source.contains('పెండింగ్') &&
        !used.contains(h.ruleId)).take(25).toList(growable: false);

    RuleResultData fromHit(VargaRuleHit h) => RuleResultData(
      topic: h.topic,
      ruleId: h.ruleId,
      verdict: verdict(h),
      ruleMatched: true,
      rule: h.rule,
      examination: h.inspection,
      result: h.result,
      source: h.source,
      // The caller's generic remedy selector is supportive, but not a
      // demonstrated exact verse-to-remedy link. Avoid falsely certifying it.
      remedy: null,
    );

    Widget item(String title, List<VargaRuleHit> rules, String fallback,
        {VargaTopic? topic}) => Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      color: const Color(0xFFFFF7E8),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        key: ValueKey('varga-topic-$factor-$title'),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(rules.isEmpty
          ? 'మూల ఫల నియమం మ్యాచ్ నిర్ధారణ లేదు'
          : 'పూర్తిగా మ్యాచ్ అయిన నియమాలు: ${rules.length}',
          style: const TextStyle(fontSize: 12)),
        childrenPadding: const EdgeInsets.only(bottom: 8),
        children: [
          if (rules.isEmpty && topic != null)
            UnifiedRuleResultTile(key: ValueKey('topic-source-$factor-$title'),
              initiallyExpanded: true, showRemedyStatus: true,
              data: _sourceOnly(data, topic)),
          for (final h in rules)
            UnifiedRuleResultTile(
              key: ValueKey('topic-matched-$factor-${h.ruleId}'),
              initiallyExpanded: true, showRemedyStatus: true,
              data: fromHit(h)),
          if (rules.isEmpty && topic == null)
            Padding(padding: const EdgeInsets.all(12), child: Text(fallback)),
        ],
      ),
    );

    return Card(
      color: const Color(0xFFF1F5FB),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 12, 10, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('అంశాల జాబితా — టచ్ చేసి పరిశీలించండి',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900,
              color: Color(0xFF12315E))),
          const SizedBox(height: 5),
          const Text('అంశం → 1. రూల్ → 2. జాతక పరిశీలన → '
              '3. హైలైట్ ఫలితం → 4. మూల పరిహారం (ఉంటే). '
              'మూల విషయసూచికలో అంశం ఉండటం ఫల నియమం మ్యాచ్ అయినట్లు కాదు.',
            style: TextStyle(fontSize: 12, height: 1.45)),
          const SizedBox(height: 7),
          for (final group in groups)
            item(group.topic.title, group.rules, '', topic: group.topic),
          if (remaining.isNotEmpty)
            item('ఇతర వర్తించిన మూల నియమాలు', remaining, ''),
          if (const {5, 6, 8}.contains(factor))
            const Padding(
              padding: EdgeInsets.all(8),
              child: Text('D5/D6/D8ను ప్రధాన 16 షోడశవర్గాల్లో లేదా '
                'వింశోపక స్కోరులో కలపలేదు. Goel Cyclical/Raman/Hadda '
                'ప్రత్యామ్నాయ విధానాల గణన పూర్తి మూలపాఠంతో ధృవీకరించాల్సి ఉంది.',
                style: TextStyle(color: Color(0xFF8C5A1F), fontSize: 12)),
            ),
        ]),
      ),
    );
  }
}

