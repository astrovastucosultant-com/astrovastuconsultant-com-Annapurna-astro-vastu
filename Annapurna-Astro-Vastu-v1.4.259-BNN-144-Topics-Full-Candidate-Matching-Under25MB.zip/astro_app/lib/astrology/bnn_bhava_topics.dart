import 'astro_models.dart';
import 'bnn_master_service.dart';

/// 144 navigation topics. These are NOT 144 chart predictions or extra
/// source rules. Each item exposes the person's actual natal placements.
class BnnBhavaTopic {
  final int house;
  final String name;
  final String karaka;
  const BnnBhavaTopic(this.house, this.name, this.karaka);
}

class BnnBhavaTopicService {
  static const List<List<BnnBhavaTopic>> byHouse = <List<BnnBhavaTopic>>[
    <BnnBhavaTopic>[
      BnnBhavaTopic(1, 'జీవన దిశ', 'Jupiter'),
      BnnBhavaTopic(1, 'శరీర స్వభావం', 'Sun'),
      BnnBhavaTopic(1, 'ఆత్మవిశ్వాసం', 'Sun'),
      BnnBhavaTopic(1, 'మనోస్థితి', 'Moon'),
      BnnBhavaTopic(1, 'ధైర్యం', 'Mars'),
      BnnBhavaTopic(1, 'జ్ఞానాసక్తి', 'Mercury'),
      BnnBhavaTopic(1, 'నాయకత్వం', 'Sun'),
      BnnBhavaTopic(1, 'క్రమశిక్షణ', 'Saturn'),
      BnnBhavaTopic(1, 'దైవచింతన', 'Ketu'),
      BnnBhavaTopic(1, 'సామాజిక ప్రవర్తన', 'Venus'),
      BnnBhavaTopic(1, 'స్వయంకృషి', 'Mars'),
      BnnBhavaTopic(1, 'జీవశక్తి', 'Jupiter'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(2, 'ఆదాయ మార్గాలు', 'Saturn'),
      BnnBhavaTopic(2, 'ధన నిల్వ', 'Venus'),
      BnnBhavaTopic(2, 'కుటుంబ బాధ్యత', 'Sun'),
      BnnBhavaTopic(2, 'వాక్చాతుర్యం', 'Mercury'),
      BnnBhavaTopic(2, 'ఆర్థిక ప్రణాళిక', 'Mercury'),
      BnnBhavaTopic(2, 'సంపాదన విధానం', 'Saturn'),
      BnnBhavaTopic(2, 'ధన వినియోగం', 'Venus'),
      BnnBhavaTopic(2, 'భోజన అలవాట్లు', 'Moon'),
      BnnBhavaTopic(2, 'కుటుంబ విలువలు', 'Jupiter'),
      BnnBhavaTopic(2, 'బంధువుల సహకారం', 'Moon'),
      BnnBhavaTopic(2, 'సేవింగ్స్', 'Mercury'),
      BnnBhavaTopic(2, 'వారసత్వ సంపద', 'Sun'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(3, 'సోదరులు', 'Mars'),
      BnnBhavaTopic(3, 'సోదరీమణులు', 'Venus'),
      BnnBhavaTopic(3, 'ధైర్యం', 'Mars'),
      BnnBhavaTopic(3, 'స్వల్ప ప్రయాణాలు', 'Moon'),
      BnnBhavaTopic(3, 'సందేశాలు', 'Mercury'),
      BnnBhavaTopic(3, 'రచనా శక్తి', 'Mercury'),
      BnnBhavaTopic(3, 'నూతన ప్రయత్నాలు', 'Mars'),
      BnnBhavaTopic(3, 'వ్యాపార నైపుణ్యం', 'Mercury'),
      BnnBhavaTopic(3, 'పొరుగు సంబంధాలు', 'Moon'),
      BnnBhavaTopic(3, 'సాంకేతిక నైపుణ్యం', 'Mars'),
      BnnBhavaTopic(3, 'సంకల్ప బలం', 'Sun'),
      BnnBhavaTopic(3, 'సంబంధిత సహకారం', 'Jupiter'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(4, 'గృహసుఖం', 'Moon'),
      BnnBhavaTopic(4, 'తల్లి', 'Moon'),
      BnnBhavaTopic(4, 'స్థిరాస్తి', 'Mars'),
      BnnBhavaTopic(4, 'భూమి', 'Mars'),
      BnnBhavaTopic(4, 'వాహనాలు', 'Venus'),
      BnnBhavaTopic(4, 'నివాస మార్పు', 'Moon'),
      BnnBhavaTopic(4, 'గృహ నిర్మాణం', 'Mars'),
      BnnBhavaTopic(4, 'పారంపర్య ఆస్తి', 'Sun'),
      BnnBhavaTopic(4, 'కుటుంబ ప్రశాంతత', 'Moon'),
      BnnBhavaTopic(4, 'సౌకర్యాలు', 'Venus'),
      BnnBhavaTopic(4, 'వ్యవసాయం', 'Saturn'),
      BnnBhavaTopic(4, 'విద్యా వాతావరణం', 'Mercury'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(5, 'సంతాన అంశాలు', 'Jupiter'),
      BnnBhavaTopic(5, 'విద్యాభ్యాసం', 'Mercury'),
      BnnBhavaTopic(5, 'బుద్ధి', 'Mercury'),
      BnnBhavaTopic(5, 'మంత్రోపాసన', 'Ketu'),
      BnnBhavaTopic(5, 'సృజనాత్మకత', 'Venus'),
      BnnBhavaTopic(5, 'పరీక్షలు', 'Mercury'),
      BnnBhavaTopic(5, 'ప్రేమ సంబంధాలు', 'Venus'),
      BnnBhavaTopic(5, 'సంతాన బాధ్యత', 'Saturn'),
      BnnBhavaTopic(5, 'ఆధ్యాత్మిక విద్య', 'Jupiter'),
      BnnBhavaTopic(5, 'కళలు', 'Venus'),
      BnnBhavaTopic(5, 'అభ్యాస నైపుణ్యం', 'Mercury'),
      BnnBhavaTopic(5, 'పూర్వపుణ్య భావన', 'Jupiter'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(6, 'ఆరోగ్య అంశాలు', 'Sun'),
      BnnBhavaTopic(6, 'ఋణాలు', 'Saturn'),
      BnnBhavaTopic(6, 'పోటీలు', 'Mars'),
      BnnBhavaTopic(6, 'శత్రు సంబంధాలు', 'Mars'),
      BnnBhavaTopic(6, 'ఉద్యోగ సేవ', 'Saturn'),
      BnnBhavaTopic(6, 'క్రమమైన శ్రమ', 'Saturn'),
      BnnBhavaTopic(6, 'న్యాయ వివాదాలు', 'Sun'),
      BnnBhavaTopic(6, 'శారీరక శ్రమ', 'Mars'),
      BnnBhavaTopic(6, 'జీవన అలవాట్లు', 'Moon'),
      BnnBhavaTopic(6, 'చికిత్స అంశాలు', 'Mercury'),
      BnnBhavaTopic(6, 'అడ్డంకులు', 'Rahu'),
      BnnBhavaTopic(6, 'బాధ్యతలు', 'Saturn'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(7, 'వివాహ అంశాలు', 'Venus'),
      BnnBhavaTopic(7, 'జీవిత భాగస్వామి', 'Venus'),
      BnnBhavaTopic(7, 'వైవాహిక ఆలస్యం', 'Saturn'),
      BnnBhavaTopic(7, 'భాగస్వామ్య వ్యాపారం', 'Mercury'),
      BnnBhavaTopic(7, 'ఒప్పందాలు', 'Mercury'),
      BnnBhavaTopic(7, 'పరస్పర సహకారం', 'Jupiter'),
      BnnBhavaTopic(7, 'సంబంధ సంభాషణ', 'Mercury'),
      BnnBhavaTopic(7, 'వివాహ అనుకూలత', 'Venus'),
      BnnBhavaTopic(7, 'దాంపత్య బాధ్యతలు', 'Saturn'),
      BnnBhavaTopic(7, 'సామాజిక సంబంధాలు', 'Moon'),
      BnnBhavaTopic(7, 'వ్యాపార కలయిక', 'Venus'),
      BnnBhavaTopic(7, 'సహజీవనం', 'Moon'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(8, 'పరివర్తనలు', 'Ketu'),
      BnnBhavaTopic(8, 'ఆకస్మిక మార్పులు', 'Rahu'),
      BnnBhavaTopic(8, 'దీర్ఘకాల భద్రత', 'Saturn'),
      BnnBhavaTopic(8, 'బీమా అంశాలు', 'Saturn'),
      BnnBhavaTopic(8, 'వారసత్వ వివాదాలు', 'Mars'),
      BnnBhavaTopic(8, 'రహస్య విషయాలు', 'Ketu'),
      BnnBhavaTopic(8, 'పరిశోధన', 'Mercury'),
      BnnBhavaTopic(8, 'కష్టాలను ఎదుర్కోవడం', 'Mars'),
      BnnBhavaTopic(8, 'విధి మార్పు భావన', 'Jupiter'),
      BnnBhavaTopic(8, 'దాచిన వనరులు', 'Venus'),
      BnnBhavaTopic(8, 'మానసిక భయాలు', 'Moon'),
      BnnBhavaTopic(8, 'జీవన స్థిరత్వం', 'Saturn'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(9, 'భాగ్యం', 'Jupiter'),
      BnnBhavaTopic(9, 'తండ్రి', 'Sun'),
      BnnBhavaTopic(9, 'గురువులు', 'Jupiter'),
      BnnBhavaTopic(9, 'ధర్మం', 'Jupiter'),
      BnnBhavaTopic(9, 'తీర్థయాత్ర', 'Ketu'),
      BnnBhavaTopic(9, 'ఉన్నత విద్య', 'Mercury'),
      BnnBhavaTopic(9, 'ఆధ్యాత్మిక ఆసక్తి', 'Ketu'),
      BnnBhavaTopic(9, 'శాస్త్ర అధ్యయనం', 'Jupiter'),
      BnnBhavaTopic(9, 'దీర్ఘ ప్రయాణాలు', 'Moon'),
      BnnBhavaTopic(9, 'పారంపర్య విలువలు', 'Sun'),
      BnnBhavaTopic(9, 'దాన ధర్మం', 'Jupiter'),
      BnnBhavaTopic(9, 'జీవన సిద్ధాంతం', 'Jupiter'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(10, 'ఉద్యోగం', 'Saturn'),
      BnnBhavaTopic(10, 'వృత్తి మార్గం', 'Saturn'),
      BnnBhavaTopic(10, 'వ్యాపారం', 'Mercury'),
      BnnBhavaTopic(10, 'స్వయం ఉపాధి', 'Mars'),
      BnnBhavaTopic(10, 'అధికార సంబంధాలు', 'Sun'),
      BnnBhavaTopic(10, 'పదోన్నతి అంశాలు', 'Sun'),
      BnnBhavaTopic(10, 'పని క్రమశిక్షణ', 'Saturn'),
      BnnBhavaTopic(10, 'సాంకేతిక వృత్తి', 'Mars'),
      BnnBhavaTopic(10, 'ఆర్థిక వృత్తి', 'Venus'),
      BnnBhavaTopic(10, 'పబ్లిక్ ఇమేజ్', 'Sun'),
      BnnBhavaTopic(10, 'వృత్తి మార్పు', 'Rahu'),
      BnnBhavaTopic(10, 'పని స్థిరత్వం', 'Saturn'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(11, 'లాభం', 'Jupiter'),
      BnnBhavaTopic(11, 'జీత వృద్ధి', 'Saturn'),
      BnnBhavaTopic(11, 'మిత్రులు', 'Mercury'),
      BnnBhavaTopic(11, 'పెద్ద సోదరులు', 'Mars'),
      BnnBhavaTopic(11, 'ఆశయ సాధన', 'Jupiter'),
      BnnBhavaTopic(11, 'వ్యాపార లాభం', 'Mercury'),
      BnnBhavaTopic(11, 'సామాజిక వలయం', 'Venus'),
      BnnBhavaTopic(11, 'ఆర్థిక అవకాశాలు', 'Venus'),
      BnnBhavaTopic(11, 'పరిచయాల సహాయం', 'Moon'),
      BnnBhavaTopic(11, 'పేరుప్రతిష్ఠ', 'Sun'),
      BnnBhavaTopic(11, 'సహకార ప్రయత్నాలు', 'Mercury'),
      BnnBhavaTopic(11, 'దీర్ఘకాల ఆదాయం', 'Saturn'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(12, 'వ్యయాలు', 'Venus'),
      BnnBhavaTopic(12, 'విదేశ ప్రయాణం', 'Rahu'),
      BnnBhavaTopic(12, 'విదేశ నివాసం', 'Rahu'),
      BnnBhavaTopic(12, 'నిద్ర', 'Moon'),
      BnnBhavaTopic(12, 'ఏకాంతం', 'Ketu'),
      BnnBhavaTopic(12, 'ధ్యాన ఆసక్తి', 'Ketu'),
      BnnBhavaTopic(12, 'దాతృత్వం', 'Jupiter'),
      BnnBhavaTopic(12, 'ఆరోగ్య ఖర్చులు', 'Saturn'),
      BnnBhavaTopic(12, 'దీర్ఘ ప్రయాణ వ్యయాలు', 'Moon'),
      BnnBhavaTopic(12, 'దాచిన ఖర్చులు', 'Mercury'),
      BnnBhavaTopic(12, 'విరక్తి', 'Ketu'),
      BnnBhavaTopic(12, 'విడుదల భావన', 'Ketu'),
    ],
  ];

  static List<BnnBhavaTopic> forHouse(int house) =>
      (house >= 1 && house <= 12) ? byHouse[house - 1] : const [];

  static String describe(BnnBhavaTopic topic, AstroChartResult chart) {
    final found = chart.planets.where((p) => p.name == topic.karaka);
    if (found.isEmpty) return 'కారక గ్రహస్థానం అందుబాటులో లేదు.';
    final planet = found.first;
    final house = BnnMasterAnalysis.houseOfPlanet(planet, chart);
    final inHouse = BnnMasterAnalysis.planetsInHouse(chart, topic.house);
    final fellow = inHouse.isEmpty
        ? 'ఈ భావంలో ప్రత్యక్ష గ్రహాలు లేవు'
        : 'ఈ భావంలో ${inHouse.map((p) => p.name).join(', ')}';
    final sign = BnnMasterAnalysis.signNames[planet.signIndex];
    final jupiter = chart.planets.where((p) => p.name == 'Jupiter');
    final contact = jupiter.isEmpty || topic.karaka == 'Jupiter'
        ? 'గురు ఆధార రాశి పరిశీలన'
        : (BnnMasterAnalysis.planetaryLink(jupiter.first, planet) ??
            'గురుతో ప్రత్యక్ష నాడీ రాశి సంబంధం గుర్తించలేదు');
    return '$sign ${planet.degreesInSign.toStringAsFixed(2)}° • '
        'కారక గ్రహం ${topic.karaka}: గురు నుంచి $house వ భావం • '
        '$contact • $fellow. ఇది పరిశీలన మాత్రమే; సంఘటన ఫలితం కాదు.';
  }
}
