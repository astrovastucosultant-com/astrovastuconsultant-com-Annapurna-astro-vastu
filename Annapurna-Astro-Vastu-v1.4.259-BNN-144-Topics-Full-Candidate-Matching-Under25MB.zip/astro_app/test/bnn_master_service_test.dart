import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_bhava_topics.dart';

BnnMasterRule _rule(String condition, {String status = 'FACTS_REQUIRED',
    String source = 'BNN N'}) => BnnMasterRule(
  id: 'BNNN-P034-R002',
  source: source,
  sourcePage: 34,
  topic: 'వివాహం / సంబంధాలు',
  condition: condition,
  result: 'చిన్నవయస్సులోనే వివాహము.',
  inspection: 'మూలం జాతకంతో ధృవీకరించాలి',
  remedy: 'మూలంలో నిర్ధారించబడలేదు',
  status: status,
);

AstroChartResult _chart(double jupiter, double venus) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 24,
  ascendantLongitude: 17,
  planets: [
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: jupiter,
        latitude: 0, speed: 0.1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: venus,
        latitude: 0, speed: 0.1),
  ],
  engineVersion: 'test',
);

void main() {
  test('Same-sign facts lead to a tentative natal placement only', () {
    final evidence = BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 47));
    expect(evidence, isNotNull);
    expect(evidence!.placement, contains('ప్రారంభ పరిశీలన మాత్రమే'));
  });

  test('Unlinked signs do not produce a placement hit', () {
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 135)), isNull);
  });

  test('Unverified OCR rules can never be auto-matched', () {
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు', status: 'OCR_REVIEW',
            source: 'Brighu_Naadi_Purnna_Rulebook.pdf'),
        _chart(42, 47)), isNull);
  });

  test('Ambiguous multi-part and REVIEW rules cannot auto-match', () {
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('గురు దృష్టి ఉంటే'), _chart(42, 47)), isNull);
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు', status: 'REVIEW'),
        _chart(42, 47)), isNull);
  });

  test('Period topics are age-band study markers, not events', () {
    final history = BnnMasterAnalysis.jupiterStudyBands(0, 25);
    expect(history.map((x) => x.round).toList(), [1, 2, 3]);
    final future = BnnMasterAnalysis.jupiterStudyBands(35, 43);
    expect(future.map((x) => x.round).toList(), [3, 4]);
    expect(BnnMasterAnalysis.jupiterStudyBands(0, -1), isEmpty);
  });

  test('Age bands honor birth month and day', () {
    expect(BnnMasterAnalysis.completedAge(
        DateTime(2000, 11, 7), DateTime(2026, 10, 26)), 25);
    expect(BnnMasterAnalysis.completedAge(
        DateTime(2000, 11, 7), DateTime(2026, 11, 7)), 26);
  });

  test('BNN first bhava is Jupiter sign, not ascendant sign', () {
    final chart = _chart(42, 47); // ascendant Aries; Jupiter Taurus
    expect(BnnMasterAnalysis.bnnReferenceSignIndex(chart), 1);
    expect(BnnMasterAnalysis.houseOfPlanet(chart.planets[0], chart), 1);
    expect(BnnMasterAnalysis.houseOfPlanet(chart.planets[1], chart), 1);
  });

  test('Marriage topics index to seventh bhava', () {
    final house = BnnMasterAnalysis.housesForRule(_rule('శుక్రుడు—గురుడు'));
    expect(house.contains(7), isTrue);
  });

  test('Only source-eligible natal-chain matches become candidate results', () {
    final rule = _rule('శుక్రుడు—గురుడు');
    expect(BnnMasterAnalysis.tentativeHouseMatch(rule, _chart(42, 47), 7),
        isNotNull);
    expect(BnnMasterAnalysis.tentativeHouseMatch(rule, _chart(42, 135), 7),
        isNull);
    expect(BnnMasterAnalysis.tentativeHouseMatch(
      _rule('శుక్రుడు—గురుడు', status: 'OCR_REVIEW'), _chart(42, 47), 7),
        isNull);
    expect(BnnMasterAnalysis.tentativeHouseMatch(
      _rule('శుక్రుడు—గురుడు', status: 'REVIEW'), _chart(42, 47), 7),
        isNull);
  });

  test('General source principles do not masquerade as 1st-house results', () {
    final generic = BnnMasterRule(
      id: 'BNN-BOOK-R-A03', source: 'book', sourcePage: 2,
      topic: 'మూల పద్ధతి', condition: 'గురు రౌండ్లు',
      result: 'ఒక చక్రం', inspection: '', remedy: '', status: 'OCR_REVIEW',
    );
    expect(BnnMasterAnalysis.housesForRule(generic), isEmpty);
    expect(BnnMasterAnalysis.primaryHouseForRule(generic), 0);
    expect(BnnMasterAnalysis.tentativeHouseMatch(generic, _chart(42, 47), 1), isNull);
  });

  test('Venus and Saturn show a readable first-pass candidate only when linked', () {
    const rule = BnnMasterRule(
      id: 'BNNN-P034-R003', source: 'BNN N', sourcePage: 34,
      topic: 'వివాహం / సంబంధాలు', condition: 'శుక్రుడు—శని',
      result: 'వివాహం ఆలస్యమవుతుంది.', inspection: 'పూర్తి నాడీ పరిశీలన',
      remedy: 'మూలంలో నిర్ధారించబడలేదు', status: 'FACTS_REQUIRED',
    );
    expect(BnnMasterAnalysis.shortPlanetChain(rule.condition), 'శుక్ర + శని');
    AstroChartResult chart(double venus, double saturn) => AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 0,
      planets: [
        PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 40,
            latitude: 0, speed: 0.1),
        PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: venus,
            latitude: 0, speed: 0.1),
        PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: saturn,
            latitude: 0, speed: 0.1),
      ], engineVersion: 'test',
    );
    expect(BnnMasterAnalysis.tentativeHouseMatch(rule, chart(69, 71), 7),
        isNotNull);
    expect(BnnMasterAnalysis.tentativeHouseMatch(rule, chart(69, 160), 7),
        isNull);
  });

  test('BNN links trines, next/previous signs, and opposition', () {
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 162)), isNotNull);
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 75)), isNotNull);
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 222)), isNotNull);
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 15)), isNotNull);
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 135)), isNull);
  });

  test('Two different charts do not produce the same candidate outcome', () {
    final r = _rule('శుక్రుడు—గురుడు');
    final linked = BnnMasterAnalysis.tentativeNatalPlacement(r, _chart(42, 162));
    final unlinked = BnnMasterAnalysis.tentativeNatalPlacement(r, _chart(42, 135));
    expect(linked, isNotNull);
    expect(unlinked, isNull);
  });

  test('Every bhava exposes 12 distinct review topics, 144 total', () {
    expect(BnnBhavaTopicService.byHouse.length, 12);
    expect(BnnBhavaTopicService.byHouse.expand((x) => x).length, 144);
    for (var h = 1; h <= 12; h++) {
      final items = BnnBhavaTopicService.forHouse(h);
      expect(items.length, 12);
      expect(items.map((x) => x.name).toSet().length, 12);
      expect(items.every((x) => x.house == h), isTrue);
    }
  });

  test('The source index accepts all twelve bhavas', () {
    for (var i = 1; i <= 12; i++) {
      expect(BnnMasterAnalysis.houseLabel(i), contains('$i'));
      expect(BnnMasterAnalysis.houseTheme(i).isNotEmpty, isTrue);
    }
  });

}
