import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_rashi_rule_service.dart';
import '../models/birth_data.dart';

/// Fresh BNN rashi rules: source IF -> natal test -> source THEN.
/// The old 462 registry and former aliases are not imported.
class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnRashiRule>> _rules = BnnRashiRuleService.load();
  bool _showAll = false;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BnnRashiRule>>(
      future: _rules,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Card(child: Padding(padding: const EdgeInsets.all(18),
            child: Text('BNN రాశి నియమాల డేటా చదవడంలో సమస్య: ${snapshot.error}')));
        }
        if (!snapshot.hasData) {
          return const Card(child: Padding(padding: EdgeInsets.all(18),
            child: Center(child: CircularProgressIndicator())));
        }
        final findings = BnnRashiRuleService.evaluate(
          rules: snapshot.data!, chart: widget.chart,
          gender: widget.birthData.gender,
        );
        final matching = findings.where((f) => f.matched).toList();
        final results = matching.where((f) => f.canDisplayEffect).toList();
        final unclear = matching.where((f) => !f.canDisplayEffect).toList();
        final unmatched = findings.where((f) => !f.matched).toList();
        final missing = unmatched.where((f) => f.position == null).length;
        final display = _showAll ? [...matching, ...unmatched] : matching;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              color: const Color(0xFFF2F7F4),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('BNN — రాశి నియమాల జాతక పరిశీలన',
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text('84 మూల నియమాలు • రాశి IF సరిపోయినవి ${matching.length} • '
                      'ఫలిత పాఠ్యం చూపినవి ${results.length}'),
                    if (unclear.isNotEmpty)
                      Text('మూలపాఠ్యం స్పష్టత అవసరమైనవి: ${unclear.length}',
                        style: const TextStyle(color: Color(0xFF8A4D2E))),
                    if (missing > 0)
                      Text('గణనకు గ్రహస్థితులు లేనివి: $missing',
                        style: const TextStyle(color: Color(0xFF8A4D2E))),
                    const SizedBox(height: 9),
                    const Text('ఇక్కడ TRUE అంటే గ్రహం ఆ రాశిలో ఉన్నట్లు మాత్రమే. '
                      'THEN వాక్యాలు మీరు ఇచ్చిన మూల ప్రతిలిపిలోని సంప్రదాయ సూచనలు; '
                      'జీవిత సంఘటనలు నిర్ధారణ అయినట్లు కాదు. ',
                      style: TextStyle(fontSize: 12.5, height: 1.5)),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: () => setState(() => _showAll = !_showAll),
                      icon: Icon(_showAll ? Icons.visibility_off : Icons.list_alt),
                      label: Text(_showAll ? 'వర్తించిన నియమాలు మాత్రమే' : 'మొత్తం 84 నియమాలు చూడండి'),
                    ),
                  ],
                ),
              ),
            ),
            if (display.isEmpty)
              const Padding(padding: EdgeInsets.all(16),
                child: Text('ఈ జన్మ జాతకానికి గ్రహ–రాశి నియమం సరిపోలలేదు.')),
            for (final finding in display)
              _RuleCard(key: ValueKey(finding.rule.id), finding: finding),
          ],
        );
      },
    );
  }
}

class _RuleCard extends StatelessWidget {
  final BnnRashiFinding finding;
  const _RuleCard({super.key, required this.finding});

  @override
  Widget build(BuildContext context) {
    final rule = finding.rule;
    final p = finding.position;
    final matched = finding.matched;
    final status = p == null ? 'గణనకు సమాచారం లేదు' : matched ? 'IF TRUE — రాశి స్థానం సరిపోయింది' : 'వర్తించలేదు';
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      color: matched ? const Color(0xFFF2F8F6) : null,
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 12),
        title: Text('${rule.id} • ${rule.title}',
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        subtitle: Text(status, style: TextStyle(fontSize: 12.5,
          color: matched ? const Color(0xFF086D51) : const Color(0xFF666C72))),
        childrenPadding: const EdgeInsets.fromLTRB(15, 0, 15, 15),
        children: [
          _section('1. రూల్', rule.originalIf),
          const SizedBox(height: 10),
          _section('2. జాతక పరిశీలన', p == null
            ? 'ఈ గ్రహానికి జన్మస్ఫుటం అందలేదు.'
            : '${rule.planet}: ${BnnRashiRuleService.signs[p.signIndex]} '
              '${BnnRashiRuleService.dms(p.longitude)}'
              '${p.retrograde ? ' (వక్రం)' : ''} • '
              '${matched ? 'IF TRUE — గ్రహం చెప్పిన రాశిలో ఉంది' : 'IF FALSE — ఈ రాశిలో లేదు'}.'),
          if (matched && finding.house != null)
            Padding(padding: const EdgeInsets.only(top: 3),
              child: Align(alignment: Alignment.centerLeft,
                child: Text('జన్మలగ్నం నుంచి ${finding.house}వ భావం.',
                  style: const TextStyle(color: Color(0xFF086D51), fontSize: 13)))),
          if (matched) ...[
            const SizedBox(height: 10),
            _section('3. ఫలితం', finding.canDisplayEffect
              ? finding.displayEffect!
              : 'మూల వాక్యంలో విరుద్ధం లేదా అస్పష్టమైన OCR ఉంది; దీని ఆధారంగా ఫలితం ప్రకటించలేదు.'),
            if (finding.annotation != null && finding.annotation!.isNotEmpty)
              Padding(padding: const EdgeInsets.only(top: 8),
                child: Align(alignment: Alignment.centerLeft,
                  child: Text(finding.annotation!,
                    style: const TextStyle(fontSize: 12.5, color: Color(0xFF8A4D2E))))),
          ],
          const SizedBox(height: 10),
          _section('4. మూలాధారం',
            '${rule.transcriptionFile}\nBNN మూల స్కాన్: PDF పేజీ ${rule.pdfPage}, ముద్రిత పేజీ ${rule.printedPage}. '
            'పేజీలో రాశి పట్టిక ఉన్న స్థానం పరిశీలించారు; THEN వాక్యం అక్షరాలవారీ మూల ధృవీకరణ ఇంకా జరగలేదు.'),
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: const Text('అందించిన అసలు THEN ప్రతిలిపి',
              style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
            children: [Align(alignment: Alignment.centerLeft,
              child: Text(rule.originalThen, style: const TextStyle(fontSize: 13, height: 1.4)))],
          ),
        ],
      ),
    );
  }

  Widget _section(String title, String body) => Align(
    alignment: Alignment.centerLeft,
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      Text(body, style: const TextStyle(height: 1.45)),
    ]),
  );
}
