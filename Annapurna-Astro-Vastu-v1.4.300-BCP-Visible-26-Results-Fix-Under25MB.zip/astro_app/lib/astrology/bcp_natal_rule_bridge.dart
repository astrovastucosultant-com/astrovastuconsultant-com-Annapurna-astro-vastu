import 'astro_models.dart';
import 'bcp_master_engine.dart';
import 'bnn_all_rules_match_service.dart';
import 'bnn_master_service.dart';
import 'd2_dhana_asthi_registry.dart';
import 'd2_wealth_evaluation_service.dart';
import 'd10_vrutti_match_engine.dart';
import 'd24_vidya_source_engine.dart';
import 'marriage_verified_sutra_engine.dart';

/// A matched *complete* natal IF is not the same as a predicted life event.
/// In particular, a source review flag or a matched sub-condition never
/// receives the 30-point BCP independent natal-rule contribution.
class BcpNatalRuleHit {
  final String id;
  final String source;
  final String page;
  final String condition;
  final String inspection;
  final String result;
  final bool verifiedFull;
  final String scope;

  const BcpNatalRuleHit({
    required this.id,
    required this.source,
    required this.page,
    required this.condition,
    required this.inspection,
    required this.result,
    required this.verifiedFull,
    required this.scope,
  });
}

class BcpNatalAssessment {
  final List<BcpNatalRuleHit> verified;
  final List<BcpNatalRuleHit> supportingOnly;

  const BcpNatalAssessment({
    this.verified = const [],
    this.supportingOnly = const [],
  });

  /// The natal promise is the result of a separately computed *complete*
  /// source IF. Do not infer it merely from the event's BCP topic mapping.
  BcpEventEvidence get evidence {
    if (verified.isEmpty) return const BcpEventEvidence();
    final rule = verified.first;
    return BcpEventEvidence(
      natalPromise: true,
      natalRuleVerified: true,
      natalRuleId: rule.id,
      natalSourceName: rule.source,
      natalSourcePage: rule.page,
    );
  }
}

class BcpNatalRuleBridge {
  // Strict event -> matched source IF ID lookup; no generic tag/keyword proof.
  // Cautionary, unfinished or method-only Indu/D2 results are not positive
  // event promises and are excluded from the 30-point gate.
  static const Map<BcpEventKind, Set<String>> _verifiedD2Rules = {
    BcpEventKind.wealth: {
      'D2-IN-001', 'D2-IN-005', 'D2-IN-010',
      'D2-DY-001', 'D2-DY-002', 'D2-CS-001', 'D2-CS-002',
    },
    BcpEventKind.property: {
      'D2-PR-001', 'D2-PR-002', 'D2-PR-003',
      'D2-PR-007', 'D2-PR-008', 'D2-IH-003', 'D2-IH-005',
    },
    BcpEventKind.vehicle: {
      'D2-VH-001', 'D2-VH-003', 'D2-VH-004',
    },
  };

  /// Review-only: these may refer to the event but do not constitute a
  /// checked promise of that event (e.g., business *initiative* != success).
  static const Map<BcpEventKind, Set<String>> _partialD2Rules = {
    BcpEventKind.business: {'D2-OT-001'},
    BcpEventKind.partnership: {'D2-OT-001'},
    BcpEventKind.wealth: {'D2-IN-007', 'D2-IN-009', 'D2-IN-011'},
    BcpEventKind.property: {'D2-IH-001', 'D2-PR-004'},
    BcpEventKind.foreignTravel: {'D2-OT-004'},
  };

  static const Map<BcpEventKind, List<String>> _reviewBnnResultTerms = {
    BcpEventKind.marriage: ['వివాహం', 'వివాహ', 'భార్య', 'భర్త'],
    BcpEventKind.childbirth: ['సంతానం', 'పుత్ర'],
    BcpEventKind.service: ['ఉద్యోగ', 'జీతం', 'సేవకుడు'],
    BcpEventKind.business: ['వ్యాపార', 'స్వయం ఉపాధి'],
    BcpEventKind.promotion: ['పదోన్నతి', 'ప్రమోషన్'],
    BcpEventKind.wealth: ['ధనయోగ', 'ధనవంత', 'ధన లాభ'],
    BcpEventKind.property: ['స్థిరాస్తి', 'ఇల్లు', 'భూమి'],
    BcpEventKind.education: ['విద్యాభ్యాస', 'చదువు', 'విద్య'],
    BcpEventKind.foreignTravel: ['విదేశ ప్రయాణ'],
    BcpEventKind.healthReview: ['ఆరోగ్య', 'రోగ'],
    BcpEventKind.spirituality: ['ఆధ్యాత్మిక', 'తీర్థయాత్ర'],
    BcpEventKind.siblings: ['సోదర', 'తమ్ముడు', 'అన్న'],
    BcpEventKind.recognition: ['గౌరవ', 'ప్రతిష్ఠ'],
  };

  /// Optional BNN source catalogue is externally loaded as an asset.
  /// Its source statuses currently require review; matched geometry is shown
  /// but DOES NOT pass the independent VERIFIED natal-rule gate.
  static Map<BcpEventKind, BcpNatalAssessment> assess(
    AstroChartResult chart, {List<BnnMasterRule> bnnCatalog = const []}
  ) {
    final full = <BcpEventKind, List<BcpNatalRuleHit>>{};
    final partial = <BcpEventKind, List<BcpNatalRuleHit>>{};

    void add(BcpEventKind event, BcpNatalRuleHit item) {
      final target = item.verifiedFull ? full : partial;
      final list = target.putIfAbsent(event, () => []);
      if (!list.any((m) => m.id == item.id)) list.add(item);
    }

    final byId = {for (final rule in D2DhanaAsthiRegistry.rules) rule.id: rule};
    for (final match in D2WealthEvaluationService.evaluate(chart)) {
      final definition = byId[match.ruleId];
      if (definition == null) continue;
      // A matched predicate is necessary; caution/pending/less-than-complete
      // conditions are never promoted into a positive event promise.
      for (final entry in _verifiedD2Rules.entries) {
        if (match.caution || !entry.value.contains(match.ruleId)) continue;
        add(entry.key, BcpNatalRuleHit(
          id: definition.id,
          source: D2DhanaAsthiRegistry.sourceFilename,
          page: '${definition.sourcePage}',
          condition: definition.condition,
          inspection: match.evidence,
          result: definition.result,
          verifiedFull: true,
          scope: 'D1/Indu/D4/D16 మూల IFలో పూర్తి గణించిన షరతు; సంఘటన కాల నిర్ధారణ కాదు.',
        ));
      }
      for (final entry in _partialD2Rules.entries) {
        if (!entry.value.contains(match.ruleId)) continue;
        add(entry.key, BcpNatalRuleHit(
          id: definition.id, source: D2DhanaAsthiRegistry.sourceFilename,
          page: '${definition.sourcePage}', condition: definition.condition,
          inspection: match.evidence, result: definition.result,
          verifiedFull: false,
          scope: 'మూల గ్రహసంబంధ సూచన మాత్రమే; ఈ BCP సంఘటనకు పూర్తి IF కాదు.',
        ));
      }
    }

    // Verified PDF subconditions are not equivalent to the whole marriage IF.
    for (final sutra in MarriageVerifiedSutraEngine.sutras) {
      final evaluation = MarriageVerifiedSutraEngine.evaluate(sutra.id, chart);
      if (!evaluation.matched) continue;
      add(BcpEventKind.marriage, BcpNatalRuleHit(
        id: sutra.id, source: MarriageVerifiedSutraEngine.sourceName,
        page: '${sutra.page}', condition: sutra.sourceCondition,
        inspection: evaluation.evidence, result: evaluation.result,
        verifiedFull: false,
        scope: 'వివాహ మూల సూత్రంలో ఒక ఉపషరతు మాత్రమే; స్వతంత్ర వివాహ నిర్ధారణ కాదు.',
      ));
    }

    // D10 is a profession *category* rule, not proof of job acquisition,
    // promotion, transfer or business start in the current BCP year.
    final career = D10VruttiMatchEngine.evaluate(chart);
    for (final match in career.where((m) => m.fullRuleMatched)) {
      final profession = match.rule.profession;
      final category = match.rule.category;
      final explicitBusiness = category.contains('వ్యాపార') ||
          category.contains('దుకాణ') ||
          category.contains('హోటల్') ||
          profession.contains('ఓనర్') || profession.contains('ఫ్రీలాన్సర్') ||
          profession.contains('హోల్‌సేల్') || profession.contains('వ్యాపార');
      final event = match.rule.mode == 'AGOCHARASHTHA'
          ? BcpEventKind.service
          : match.rule.mode == 'GOCHARASHTHA' && explicitBusiness
              ? BcpEventKind.business
              : null;
      if (event == null) continue;
      if ((partial[event]?.where((e) => e.source == match.rule.source).length ?? 0) >= 3) continue;
      add(event, BcpNatalRuleHit(
        id: match.rule.id, source: match.rule.source,
        page: '${match.rule.page}', condition: match.rule.condition,
        inspection: match.passed.join(' • '),
        result: 'D10 వృత్తి వర్గ సూచన: ${match.rule.profession}',
        verifiedFull: false,
        scope: 'వృత్తి వర్గ IF మాత్రమే; ఉద్యోగం/వ్యాపారం ప్రారంభ సంఘటనకు పూర్తి జన్మ నియమం కాదు.',
      ));
    }

    // D24 audits explicitly declare pending subconditions: no 30 natal points.
    for (final audit in D24VidyaSourceEngine.evaluate(chart)) {
      if (!audit.hasSupportingEvidence || audit.missingMainConditions.isNotEmpty) continue;
      add(BcpEventKind.education, BcpNatalRuleHit(
        id: audit.source.id, source: 'Education.pdf / D24 rulebook',
        page: audit.source.sourcePage, condition: audit.source.condition,
        inspection: audit.checkReport, result: audit.source.result,
        verifiedFull: false,
        scope: 'D24 పాక్షిక IF మద్దతు; ప్రవేశం/ఉత్తీర్ణత నిర్ధారణ కాదు.',
      ));
      if ((partial[BcpEventKind.education]?.length ?? 0) >= 3) break;
    }

    // All 462 BNN entries currently carry OCR_REVIEW / FACTS_REQUIRED /
    // REVIEW status. Their matches are retained for source audit ONLY.
    if (bnnCatalog.isNotEmpty) {
      for (final rule in bnnCatalog) {
        if (rule.status != 'VERIFIED') {
          final events = _reviewBnnResultTerms.entries.where((entry) =>
              entry.value.any((term) => rule.result.contains(term))).toList();
          if (events.isEmpty || events.every((entry) =>
              (partial[entry.key]?.where((r) => r.source == 'BNN 462').length ?? 0) >= 2)) {
            continue;
          }
          final checked = BnnAllRulesMatchService.check(rule, chart);
          if (!checked.evaluable || !checked.matched) continue;
          for (final entry in events) {
            if ((partial[entry.key]?.where((r) => r.source == 'BNN 462').length ?? 0) >= 2) continue;
            add(entry.key, BcpNatalRuleHit(
              id: rule.id, source: 'BNN 462', page: '${rule.sourcePage}',
              condition: rule.condition, inspection: checked.reason,
              result: checked.matchedThen ?? rule.result,
              verifiedFull: false,
              scope: 'BNN మూల స్థితి ${rule.status}; స్థాన IF సరిపోయినా మూల పాఠ ధృవీకరణ పెండింగ్.',
            ));
          }
        }
      }
    }

    return {
      for (final event in BcpEventKind.values)
        event: BcpNatalAssessment(
          verified: List.unmodifiable(full[event] ?? const []),
          supportingOnly: List.unmodifiable(partial[event] ?? const []),
        ),
    };
  }
}
