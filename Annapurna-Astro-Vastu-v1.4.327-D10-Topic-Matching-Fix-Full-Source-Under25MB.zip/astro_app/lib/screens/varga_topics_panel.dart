import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/d10_topic_rule_bridge.dart';
import '../astrology/d10_vrutti_match_engine.dart';
import '../astrology/varga_service.dart';
import '../astrology/varga_topic_catalog.dart';
import '../astrology/varga_topic_rule_linker.dart';
import '../astrology/varga_rule_service.dart';
import '../astrology/varga_unified_rule_service.dart';
import '../astrology/varga_source_stub_live_support.dart';
import '../astrology/varga_shastra_registry.dart';
import 'unified_rule_result_tile.dart';

/// All chart-specific subject titles in one compact list. A source table of
/// contents is NOT an IF–THEN match. Verified hits alone highlight conclusions.
class VargaTopicsPanel extends StatefulWidget {
  const VargaTopicsPanel({
    super.key,
    required this.natal,
    required this.factor,
    required this.d16Method,
  });
  final AstroChartResult natal;
  final int factor;
  final D16CalculationMethod d16Method;

  static const _signs = <String>[
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];

  // The title index is not the source evidence. Verified rule hits are still
  // produced only by the original calculation engines.
  static bool matchesTopic(String text, VargaTopic topic) {
    final folded = text.toLowerCase();
    return topic.matchWords.any((w) => folded.contains(w.toLowerCase()));
  }

  static RuleVerdict verdict(VargaRuleHit rule) => switch (rule.tone) {
    VargaRuleTone.favorable => RuleVerdict.favourable,
    VargaRuleTone.caution => RuleVerdict.adverse,
    VargaRuleTone.neutral => RuleVerdict.mixed,
    VargaRuleTone.info => RuleVerdict.unverified,
  };

  @override
  State<VargaTopicsPanel> createState() => _VargaTopicsPanelState();
}

class _VargaTopicsPanelState extends State<VargaTopicsPanel> {
  static const _signs = VargaTopicsPanel._signs;
  late Future<List<UnifiedVargaRule>> _sourceRulesFuture;
  int get factor => widget.factor;
  AstroChartResult get natal => widget.natal;
  D16CalculationMethod get d16Method => widget.d16Method;

  @override
  void initState() {
    super.initState();
    _sourceRulesFuture = VargaUnifiedRuleService.evaluate(widget.natal);
  }

  @override
  void didUpdateWidget(covariant VargaTopicsPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.natal, widget.natal)) {
      _sourceRulesFuture = VargaUnifiedRuleService.evaluate(widget.natal);
    }
  }

  bool matchesTopic(String text, VargaTopic topic) =>
      VargaTopicsPanel.matchesTopic(text, topic);
  RuleVerdict verdict(VargaRuleHit rule) =>
      VargaTopicsPanel.verdict(rule);

  String _inspection(VargaChartData data, VargaTopic topic) {
    final lagna = data.ascendantSignIndex;
    final targetSign = (lagna + topic.house - 1) % 12;
    final relevant = data.planets.where((p) => p.signIndex == targetSign)
        .map((p) => p.name).toList();
    final all = data.planets.map((p) =>
        '${p.shortName}: ${_signs[p.signIndex]}').join(' • ');
    return 'D$factor లగ్నం: ${_signs[lagna]}. '
        '${topic.house}వ భావం: ${_signs[targetSign]}. '
        'అక్కడి గ్రహాలు: ${relevant.isEmpty ? "లేవు" : relevant.join(", ")}.\n'
        'వర్గ గ్రహ రాశులు: $all.\n'
        'ఇవి గ్రహస్థితులు మాత్రమే; దృష్టి, అధిపత్యం, మూల నియమం '
        'పూర్తిగా సరిపోయినంతవరకు సంఘటన నిర్ధారణ కాదు.';
  }

  RuleResultData _sourceOnly(VargaChartData chart, VargaTopic topic) {
    final extended = VargaShastraRegistry.isExtended(factor);
    return RuleResultData(
      topic: topic.title,
      ruleId: null,
      verdict: RuleVerdict.unverified,
      ruleMatched: null,
      rule: extended
          ? 'ఈ అంశం గ్రంథ విషయసూచికలో ఉంది. పూర్తి Goel IF–THEN షరతు '
              'ధృవీకరించలేదు; P.V.R. గణన పద్ధతిని Goel ఫల నియమంగా కలపలేదు.'
          : 'ఈ అంశానికి వర్తించిన పూర్తి, ధృవీకృత IF–THEN నియమం '
              'ప్రస్తుత స్వయంచాలక ఫలితాల్లో గుర్తించబడలేదు.',
      examination: _inspection(chart, topic),
      result: '',
      source: VargaTopicCatalog.topicSource(factor),
      remedy: null,
    );
  }

  /// The unified catalog is evaluated once per horoscope, then routed into
  /// topic cards. Source catalog matches and computed engine hits share the
  /// SAME item rather than being parked in a separate bottom audit.
  RuleResultData _sourceRow(UnifiedVargaRule r) {
    // Supplemental D16 evidence is calculated with the SELECTED D16 method.
    // Source rows from the Parashara-only 255 catalog remain gated when the
    // alternate method is selected; do not discard correctly remapped support.
    final selectedMethodSupport = r.id.startsWith('VARGA-GENERAL-004/D16') ||
        r.id.startsWith('USER-STUB-') ||
        r.id.startsWith('VARGA-PROTOCOL-');
    final alternateD16 = factor == 16 &&
        d16Method != D16CalculationMethod.parashara && !selectedMethodSupport;
    // Cross-Varga observations are inspection evidence, NEVER standalone
    // career/event verdicts even if the source catalog marks them matched.
    final crossAuditOnly = r.id.startsWith('VARGA-CROSS-');
    final matched = (alternateD16 || crossAuditOnly) ? null : switch (r.status) {
      UnifiedVargaRuleStatus.matched => true,
      UnifiedVargaRuleStatus.notMatched => false,
      _ => null,
    };
    return RuleResultData(
      topic: r.topic,
      ruleId: r.id,
      verdict: switch (r.tone) {
        UnifiedVargaRuleTone.favorable => RuleVerdict.favourable,
        UnifiedVargaRuleTone.adverse => RuleVerdict.adverse,
        UnifiedVargaRuleTone.neutral => RuleVerdict.mixed,
      },
      ruleMatched: matched,
      rule: r.condition,
      examination: crossAuditOnly
          ? 'VARGA-CROSS పరిశీలన మాత్రమే; ఈ నియమం స్వతంత్రంగా తుది ఫలితాన్ని నిర్ణయించదు. ${r.evidence}'
          : alternateD16
          ? 'ప్రామాణిక D16 పద్ధతితో పరీక్షించిన మూల నియమం ఇది. '
              'మీరు ఎంచుకున్న ప్రత్యామ్నాయ D16 పద్ధతికి ఫలితం '
              'మళ్లీ ధృవీకరించాలి. ${r.evidence}'
          : r.evidence,
      result: r.outcome,
      source: r.source,
      remedy: null,
    );
  }

  RuleResultData _evaluatedRow(VargaRuleHit hit) {
    // Bibliographic/source-authorship verification is independent from the
    // actual IF–THEN chart-condition calculation. A computed rule is NOT
    // discarded because its original printed source page is still pending.
    // Source-only or informational rows remain unverified predictions.
    final bool? matched = !hit.autoEvaluated ||
        hit.tone == VargaRuleTone.info || hit.result.trim().isEmpty
        ? null : hit.applicable;
    return RuleResultData(
      topic: hit.topic,
      ruleId: hit.ruleId,
      verdict: verdict(hit),
      ruleMatched: matched,
      rule: hit.rule,
      examination: hit.inspection,
      result: hit.result,
      source: hit.source,
      // Exact source-to-remedy matching must be demonstrated separately.
      remedy: null,
    );
  }

  RuleResultData _vruttiRow(D10VruttiMatch match) {
    final source = match.rule;
    return RuleResultData(
      topic: source.profession,
      ruleId: source.id,
      verdict: RuleVerdict.mixed,
      ruleMatched: match.fullRuleMatched,
      rule: source.condition,
      examination: match.passed.join('\n'),
      result: 'ఈ జాతకంలో ${source.profession} రంగానికి సంబంధించిన '
          'మూల IF–THEN షరతులు సరిపోయాయి. ఇది వృత్తి సూచన మాత్రమే; '
          'నియామకం, లాభం, కాలం నిర్ధారణ కాదు.',
      source: '${source.source} • ముద్రిత పుట ${source.page}',
      evidencePercent: match.percent.toDouble(),
    );
  }

  Widget _item({
    required String title,
    required List<VargaRuleHit> calculated,
    required List<UnifiedVargaRule> sources,
    required VargaChartData chart,
    VargaTopic? topic,
    List<D10VruttiMatch> vruttiMatched = const [],
  }) {
    final validCalculated = calculated.where((h) =>
        _evaluatedRow(h).ruleMatched == true).toList();
    final validSource = sources.where((r) =>
        _sourceRow(r).ruleMatched == true).toList();
    final count = validCalculated.length + validSource.length + vruttiMatched.length;
    final total = calculated.length + sources.length + vruttiMatched.length;
    final sourceOrder = [...sources]..sort((a, b) {
      int priority(UnifiedVargaRule r) => switch (_sourceRow(r).ruleMatched) {
        true => 0,
        false => 1,
        _ => 2,
      };
      return priority(a).compareTo(priority(b));
    });
    final calcOrder = [...calculated]..sort((a, b) {
      int priority(VargaRuleHit r) => switch (_evaluatedRow(r).ruleMatched) {
        true => 0,
        false => 1,
        _ => 2,
      };
      return priority(a).compareTo(priority(b));
    });
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      color: const Color(0xFFFFF7E8),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        key: ValueKey('varga-topic-$factor-$title'),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('వర్తించిన నియమాలు: $count • మొత్తం అనుసంధానించినవి: $total'
            '${total == 0 ? ' • పూర్తి మూల నియమం ఇంకా లేదు' : ''}',
            style: const TextStyle(fontSize: 12)),
        childrenPadding: const EdgeInsets.only(bottom: 8),
        children: [
          if (count == 0 && total > 0)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              child: Text('ఈ అంశంలో పరీక్షించిన షరతులు పూర్తిగా సరిపోలలేదు '
                  'లేదా గణన పెండింగ్. మూల ఫలితాన్ని జాతక ఫలితంగా చూపలేదు.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF6A6470))),
            ),
          // Applied source-backed rules first. Category placeholders are
          // never displayed as if they were evaluated IF–THEN predictions.
          for (final m in vruttiMatched)
            UnifiedRuleResultTile(
              key: ValueKey('topic-d10-vrutti-$factor-${m.rule.id}'),
              data: _vruttiRow(m),
            ),
          for (final h in calcOrder.where((h) =>
              factor != 10 || _evaluatedRow(h).ruleMatched == true))
            UnifiedRuleResultTile(
              key: ValueKey('topic-engine-$factor-${h.ruleId}'),
              data: _evaluatedRow(h),
            ),
          for (final r in sourceOrder.where((r) =>
              factor != 10 || _sourceRow(r).ruleMatched == true))
            UnifiedRuleResultTile(
              key: ValueKey('topic-source-rule-$factor-${r.id}'),
              data: _sourceRow(r),
            ),
          if (total == 0 && factor == 10)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 15),
              child: Text(factor == 10
                  ? 'ఈ అంశానికి జాతకంతో పూర్తిగా సరిపోయిన ప్రత్యేక '
                    'IF–THEN మూల నియమం అందుబాటులో లేదు. '
                    'గ్రహస్థితులు మాత్రమే చూసి ఫలితం ప్రకటించలేదు.'
                  : 'ఈ అంశానికి పరీక్షించగల మూల IF–THEN నియమం '
                    'అందుబాటులో లేదు. ఫలితం ప్రకటించలేదు.',
                  style: const TextStyle(color: Color(0xFF656C76),
                      fontSize: 12)),
            ),
          if (factor != 10 && total == 0 && topic != null)
            UnifiedRuleResultTile(
              key: ValueKey('topic-observation-$factor-$title'),
              data: _sourceOnly(chart, topic),
              initiallyExpanded: false,
              showRemedyStatus: false,
            ),
          if (factor == 10 && calculated.length + sources.length >
              validCalculated.length + validSource.length)
            ExpansionTile(
              initiallyExpanded: false,
              title: const Text('వర్తించని / పెండింగ్ మూల నియమాల పరిశీలన',
                  style: TextStyle(fontSize: 12,
                      color: Color(0xFF657080))),
              children: [
                for (final h in calcOrder.where((h) =>
                    _evaluatedRow(h).ruleMatched != true))
                  UnifiedRuleResultTile(
                    key: ValueKey('topic-engine-audit-$factor-${h.ruleId}'),
                    data: _evaluatedRow(h),
                  ),
                for (final r in sourceOrder.where((r) =>
                    _sourceRow(r).ruleMatched != true))
                  UnifiedRuleResultTile(
                    key: ValueKey('topic-source-audit-$factor-${r.id}'),
                    data: _sourceRow(r),
                  ),
              ],
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final topics = VargaTopicCatalog.forFactor(factor);
    if (topics.isEmpty) return const SizedBox.shrink();
    final data = VargaService.calculate(natal, factor, d16Method: d16Method);
    final sav = VargaSourceStubLiveSupport.natalSavIfAvailable(natal);
    final allCalculated = VargaRuleService.allFor(
        chart: natal, factor: factor, d16Method: d16Method);
    // Reuse the existing 174+ source profession predicates. Only full
    // condition matches may appear as results in corresponding D10 topics.
    final d10SourceMatches = factor == 10
        ? D10VruttiMatchEngine.evaluate(natal).where((m) => m.fullRuleMatched)
            .toList(growable: false)
        : <D10VruttiMatch>[];
    // Stable ID -> one *primary* topic. A rule is not counted repeatedly
    // merely because several Telugu title words overlap.
    final calcGroups = List.generate(topics.length, (_) => <VargaRuleHit>[]);
    final calcOther = <VargaRuleHit>[];
    final seenCalculated = <String>{};
    for (final h in allCalculated) {
      if (!seenCalculated.add(h.ruleId)) continue;
      final destination = VargaTopicRuleLinker.computedIndex(
          factor, h.ruleId, h.topic, topics);
      if (destination == null) {
        calcOther.add(h);
      } else {
        calcGroups[destination].add(h);
      }
    }
    return FutureBuilder<List<UnifiedVargaRule>>(
      future: _sourceRulesFuture,
      builder: (context, snapshot) {
        final sourceGroups = List.generate(
            topics.length, (_) => <UnifiedVargaRule>[]);
        final sourceOther = <UnifiedVargaRule>[];
        // Safe live connections from the user-supplied 39-function file:
        // source-page SAV rules and Vargottama can highlight; unlocated
        // supplementary predicates remain an auditable observation only.
        for (var i = 0; i < topics.length; i++) {
          sourceGroups[i].addAll(VargaSourceStubLiveSupport.natalSavForTopic(
              natal, topics[i], sav, factor: factor));
        }
        final vargottama = VargaSourceStubLiveSupport.vargottama(natal, data);
        if (vargottama != null) sourceOther.add(vargottama);
        sourceOther.addAll(VargaSourceStubLiveSupport.supplementaryObservations(
            natal, data));
        if (snapshot.hasData) {
          for (final r in snapshot.data!) {
            // Explicit D-factor sources + cross-chart rules with a verified
            // navigation binding. Unrelated 255-rule groups are not silently
            // presented as chart-specific event predictions.
            final isDirect = r.group == 'D$factor';
            final crossIdx = VargaTopicRuleLinker.crossIndex(
                factor, r.id, topics.length);
            if (!isDirect && crossIdx == null) continue;
            final destination = isDirect
                ? VargaTopicRuleLinker.sourceIndex(
                    factor, r.id, topics.length)
                : crossIdx;
            if (destination == null) {
              sourceOther.add(r);
            } else {
              sourceGroups[destination].add(r);
            }
          }
        }
        final sourceMatched = [
          for (final group in sourceGroups)
            ...group.where((r) => _sourceRow(r).ruleMatched == true),
          ...sourceOther.where((r) => _sourceRow(r).ruleMatched == true),
        ].length;
        final computedMatched = allCalculated.where((h) =>
            _evaluatedRow(h).ruleMatched == true).length;
        return Card(
          color: const Color(0xFFF1F5FB),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(10, 12, 10, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('D$factor — మొత్తం ${topics.length} అంశాలు • అనుసంధానిత నియమాలు',
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900,
                    color: Color(0xFF12315E))),
              const SizedBox(height: 5),
              const Text('అంశం తెరిస్తే 1. మూల రూల్ → 2. గ్రహ/భావ పరిశీలన → '
                  '3. ధృవీకరించిన ఫలితం హైలైట్ → 4. మూల పరిహారం (ఉంటే). '
                  'సరిపోని/పెండింగ్ రూల్స్ ఫలితాలు కావు.',
                  style: TextStyle(fontSize: 12, height: 1.45)),
              const SizedBox(height: 5),
              Text('ఈ జాతకానికి పరీక్షించి సరిపోయినవి: '
                  '${computedMatched + sourceMatched + (factor == 10 ? d10SourceMatches.length : 0)} • '
                  'ఇంజన్ ఆధారాలు $computedMatched • '
                  'మూలపట్టిక + అనుబంధ గణన $sourceMatched. '
                  '${factor == 10 ? 'పూర్తి D10 వృత్తి మూల మ్యాచ్‌లు ${d10SourceMatches.length}. ' : ''}'
                  'ఇవి Rule Match సంఖ్యలు; సంఘటనల హామీ కాదు.',
                  style: const TextStyle(fontSize: 12, color: Color(0xFF415269))),
              if (!snapshot.hasData)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: snapshot.hasError
                      ? const Text('మూల 255 నియమాల జాబితా తెరవడంలో సమస్య. '
                          'ఇంజన్ ఆధారాలు మాత్రమే చూపుతున్నాం.',
                          style: TextStyle(color: Color(0xFFAA3355)))
                      : const LinearProgressIndicator(),
                ),
              const SizedBox(height: 7),
              for (var i = 0; i < topics.length; i++)
                _item(title: topics[i].title, calculated: calcGroups[i],
                    sources: sourceGroups[i], chart: data, topic: topics[i],
                    vruttiMatched: factor == 10
                        ? D10TopicRuleBridge.forTopic(
                            topics[i].title, d10SourceMatches)
                        : const <D10VruttiMatch>[]),
              if (calcOther.isNotEmpty || sourceOther.isNotEmpty)
                _item(title: 'ఇతర మూల నియమాలు • ప్రత్యేక అంశాలు',
                    calculated: calcOther, sources: sourceOther, chart: data),
              if (const {5, 6, 8}.contains(factor))
                const Padding(
                  padding: EdgeInsets.all(8),
                  child: Text('D5/D6/D8లో మూల IF పూర్తిగా గణించగలిగిన '
                    'నియమాలనే మ్యాచ్ చేస్తాం. Goel గారి ప్రత్యామ్నాయ '
                    'వర్గ పద్ధతులు పూర్తిగా ధృవీకరించేవరకు వాటి ఫలితాలు '
                    'ఈ లెక్కలో చేర్చం.',
                    style: TextStyle(color: Color(0xFF8C5A1F), fontSize: 12))),
            ]),
          ),
        );
      },
    );
  }
}
