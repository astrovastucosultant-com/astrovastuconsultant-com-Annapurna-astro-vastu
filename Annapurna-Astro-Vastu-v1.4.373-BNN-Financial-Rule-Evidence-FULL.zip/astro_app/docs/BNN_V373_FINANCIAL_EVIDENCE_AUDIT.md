# v1.4.373 — Financial source evidence

Base: verified v368 archive SHA-256 0690cc2fa74430fb8c90c104ab33d2934f4d9bb7ba6affaffc58fe0cefd6ad44 plus the exact v372 workflow overlay.

Four separate cards: WEALTH, PROFIT, LOSS and new SAVINGS. Existing D2 rule registry and evaluator are reused without changing their astrological conditions. Rule IDs are mapped by financial meaning, never by a generic planet contact. House, vehicle and inheritance rules are not substituted as earnings. Both favorable and unfavorable reserve indicators remain visible, with green/pink/neutral ordering. Ordinary wealth/effort rule IN-003 is neutral rather than a loss assertion.

Every matched row shows the original IF–THEN, PDF page, required chart layer, actual inspection, source result, and remedy status. No source remedy is invented. Manduka methods remain missing-input items. Source-only and observation-only rules are never promoted to matches. No monetary probability or amount is derived from the evaluator percent field.

Financial cards omit raw progression ages. A natal match is not a dated event: financial dasha/transit convergence remains unimplemented and is explicitly shown as undetermined. The existing five-event timing service is retained. Catalog grows from 28 to 29 topics; catalog metadata alone still asserts no match or event time.

Validation in this session: 25 executable Dart checks PASS; Dart analyzer reports no issues for the new service and standalone verification tool; new/changed Dart files parse with dart format; base archive and embedded overlay digests verified. Flutter SDK is not installed in this workspace, so Flutter widget/regression tests and APK compilation were not executed locally. The workflow runs the standalone check, new financial widget test, original D2 evaluator/conflict tests, and preserved BNN regressions before building an APK. No APK is included in this source delivery.

## UI build fix after GitHub run 42928488363

GitHub run: standalone 25 rule checks passed; Flutter regression run passed 69 tests and failed two widget tests. Financial rows used a colored DecoratedBox above nested ListTiles, triggering Flutter's ink/background assertion. Replaced that decorated Container with Padding + a rounded, clipped Material so all nested ListTiles paint on the correct surface. The life-event widget test now preloads real assets in runAsync and settles animations, replacing fixed fake-clock waits. No rule conditions or expected outcomes were removed, and no Flutter exception is ignored. Flutter widget tests/APK compilation must be rerun on GitHub; they were not run locally for this fix.
