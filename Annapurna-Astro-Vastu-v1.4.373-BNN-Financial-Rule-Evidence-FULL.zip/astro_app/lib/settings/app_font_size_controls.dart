import 'package:flutter/material.dart';
import 'app_font_scale.dart';

/// Accessible font-size actions for BNN. The setting also applies to other tabs.
/// Uses wrapping controls to avoid horizontal overflow on narrow phones.
class AnnapurnaFontSizeControls extends StatelessWidget {
  const AnnapurnaFontSizeControls({super.key});

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<double>(
    valueListenable: AnnapurnaFontScale.instance,
    builder: (context, scale, _) => Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        child: Wrap(
          spacing: 8,
          runSpacing: 6,
          crossAxisAlignment: WrapCrossAlignment.center,
          children: [
            const Text('అక్షరాల సైజు',
              style: TextStyle(fontWeight: FontWeight.w600)),
            IconButton.outlined(
              key: const ValueKey('annapurna-font-decrease'),
              tooltip: 'అక్షరాల సైజు తగ్గించు',
              icon: const Icon(Icons.text_decrease),
              onPressed: scale <= AnnapurnaFontScale.minimum
                ? null : () => AnnapurnaFontScale.instance.setScale(scale-0.1),
            ),
            Text('${(scale*100).round()}%',
              style: const TextStyle(fontWeight: FontWeight.bold)),
            IconButton.outlined(
              key: const ValueKey('annapurna-font-increase'),
              tooltip: 'అక్షరాల సైజు పెంచు',
              icon: const Icon(Icons.text_increase),
              onPressed: scale >= AnnapurnaFontScale.maximum
                ? null : () => AnnapurnaFontScale.instance.setScale(scale+0.1),
            ),
            TextButton(
              key: const ValueKey('annapurna-font-reset'),
              onPressed: () => AnnapurnaFontScale.instance.setScale(1.0),
              child: const Text('సాధారణ సైజు'),
            ),
          ],
        ),
      ),
    ),
  );
}
