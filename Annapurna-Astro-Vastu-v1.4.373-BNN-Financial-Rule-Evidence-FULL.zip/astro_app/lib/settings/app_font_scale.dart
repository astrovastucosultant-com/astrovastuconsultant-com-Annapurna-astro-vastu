import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A persisted, user-controlled text-size multiplier for the whole app.
/// This multiplies (rather than overrides) Android accessibility text scaling.
class AnnapurnaFontScale extends ValueNotifier<double> {
  AnnapurnaFontScale._() : super(1.0);

  static final AnnapurnaFontScale instance = AnnapurnaFontScale._();
  static const String preferenceKey = 'annapurna_font_scale';
  static const double minimum = 0.9;
  static const double maximum = 1.5;
  static const double step = 0.1;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    value = _normalize(prefs.getDouble(preferenceKey) ?? 1.0);
  }

  static double _normalize(double requested) {
    if (!requested.isFinite) return 1.0;
    final clamped = requested.clamp(minimum, maximum).toDouble();
    return (clamped * 10).round() / 10.0;
  }

  Future<void> setScale(double requested) async {
    value = _normalize(requested);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(preferenceKey, value);
  }
}
