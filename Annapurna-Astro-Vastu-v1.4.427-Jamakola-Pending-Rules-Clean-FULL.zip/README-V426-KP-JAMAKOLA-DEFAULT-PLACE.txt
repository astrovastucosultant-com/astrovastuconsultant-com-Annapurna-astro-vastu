Annapurna Astro Vastu v1.4.426
Source baseline: v1.4.425 FULL ZIP from ChatGPT Library.
Changes:
1. KP Time Chart and Jamakola quick actions no longer ask for client's name or birth date.
2. Prefer the currently selected village/coordinates; otherwise last used question place, otherwise the latest Saved Place. No invented GPS coordinates.
3. If no valid place is available, show a searchable/Saved Places/manual question-place picker instead of a blocking snackbar.
4. 'Change question place' action inside the KP/Jamakola page; persists the choice for future question charts without changing natal charts.
5. KP Time Chart begins chart calculation on direct open, using the judgement moment in the selected place time zone.
6. Prevent previously selected coordinates being silently reused when a different village name is manually typed.
Tests: question_place_default_v426_test.dart, home_kp_jamakola_v423_test.dart, place_storage_service_test.dart.
Flutter compile/tests have NOT been executed locally; GitHub Actions must confirm build.
