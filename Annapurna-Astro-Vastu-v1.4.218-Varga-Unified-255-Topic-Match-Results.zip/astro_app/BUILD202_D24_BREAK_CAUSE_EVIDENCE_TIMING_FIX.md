# Build 202 — D24 Education Break Cause Audit and Date-Specific Timing

Version: 1.4.202+202 (from v1.4.201)

## Corrections
- For each of the 8 inferred cause classes, store explicit D1/D24 role-house lords, signs, house positions, adverse conditions and direct linkage to education house lords (4/5).
- Keep the original D24-VIDYA-CORE-05 complete conjunction criterion separate from derived explanatory models.
- Finance case requires BOTH adverse money-lord conditions AND explicit links to education lords in both D1 and D24; display failed conditions instead of declaring finance as certain.
- Evaluate supportive money indications separately as opposing evidence, never as support for a financial problem.
- Dasha match for a named cause uses trigger planets recorded in matched cause evidence. It is distinct from general education stress dasha.
- No chart screen silently uses today's date as the historical education-break event; the user must explicitly select the event date. Clearing selection is supported.
- Preserve existing 56 D24 imported rules, 517 D10 career entries, and Timing/BTR implementations. Only the D24 break engine/panel and build version are changed, plus regression tests and this document.

## Validation limits
- Dart/Flutter SDK not installed in the editing environment. The new tests are included but were not executed here. GitHub Actions APK compilation is required to validate Dart syntax and runtime behavior.
- Interpretation of parent, love, money, health, job or other named social causes is NOT proof of a real-world cause. Only the narrower education interruption rule is directly supported in the supplied D24 document (page 4, section 2.2). See labels on screen.
- Jupiter/Saturn transit verification and historical school records are still not supplied and must not be presented as confirmed.
