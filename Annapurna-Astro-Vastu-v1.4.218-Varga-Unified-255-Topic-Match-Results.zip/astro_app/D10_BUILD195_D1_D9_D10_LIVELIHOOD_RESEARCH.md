# Annapurna Astro Vastu — v1.4.195
## D1 → D9 → D10 career-livelihood cross-verification

### Classical sources independently checked

1. **Phaladeepika**, Chapter 5, verse 1: compare the 10th lord from Lagna,
   Moon, and Sun; profession is associated with the lord of the **Navamsha
   occupied by that tenth lord**. The traditional instruction refers to
   whichever of the reference points is strongest.
   https://www.siva.sh/phaladeepika/5/1
2. **Phaladeepika**, Chapter 5, verses 2–8: livelihood families according to
   the Navamsha sign lord, among the seven classical grahas.
   https://www.siva.sh/phaladeepika/5
   https://www.siva.sh/phaladeepika/5/6-10
3. **Phaladeepika**, Chapter 5, verse 9: a strong versus weak Navamsha ruler
   affects the result; **NOT** a prescription for an arbitrary 100-point score.
   https://www.siva.sh/phaladeepika/5/9
4. **Brihat Jataka**, Chapter 10 (Karmajiva), verses 1–3: a corroborating
   10th-lord/Navamsha-lord livelihood scheme.
   https://www.astroneemo.net/index.php/2016-08-07-05-21-50/2016-09-26-02-29-18/52-english/704-brihat-jataka.html?showall=&start=9
5. **Brihat Parashara Hora Shastra**, Chapter 6, verses 13–14: Dashamsha
   sign mapping and the ten divisional deities, odd forward/even reverse.
   https://vedicpupil.in/library/books/brihat-parashara-hora-shastra/chapter-6

### Important distinctions

- "Tenth lord in Navamsha" = the **D1 reference tenth house's rashi lord**
  placed in D9, then the **rashi lord of that D9 sign**. Not the D9 tenth
  house lord. Not the deity of the D10 tenth house.
- The three Lagna/Moon/Sun analyses are **candidate references**. This app's
  `AstroChartResult` has no complete calibrated Shadbala / Bhava Bala; we
  deliberately do **not claim to know which reference is strongest**.
- `D10CareerService.relatedVarga` checks classical sign conjunction and
  graha aspects; it is a limited relationship flag, not a verified exact
  profession or evidence of causal certainty.
- The older D10 IF–THEN rules are **user-supplied** and are not represented
  as verses from the above texts. The source-rule's own principal-planet
  confirmation remains the hard gate for personal profession names.
- The three classical channels can reuse a tenth lord and thus should not
  count as three independent confirmations. No cross-confirmation boost to
  existing rule match percentages, occupational ranking, future timing, or BTR.
- A correspondence is deliberately **strict exact planet-name identity**:
  the D9 livelihood sign lord occurs in the profession's source rule planets.
  It does not grant automatic full-rule matching, a new verified profession,
  level (small/middle/large), degree of wealth, or outcome probability.
- Aspects/conditions/professional nomenclature in older 517 source entries
  are retained, including previous D10 Main-planet Confirm semantics.
- If Sun/Moon or a required tenth lord lacks ephemeris placement, the channel
  is absent; never silently synthesize a placement.
- **Warning:** Traditional astrology is interpretive and not a scientifically
  validated method for predicting a person's precise job or career outcome.

### Implementation

- `lib/astrology/d10_livelihood_crosscheck_service.dart`: immutable three
  channels, chart computation, rule-specific exact-planet correspondence and
  repetition signal.
- `lib/screens/d10_livelihood_crosscheck_panel.dart`: expandable bilingual
  audit of D1 tenth lord → D9 placement/lord → D10 career-axis connection;
  explanatory notices and eligible-for-individual-verdict gate.
- `lib/screens/d10_vrutti_rules_screen.dart`: global audit (collapsed) and
  per-profession details audit (expanded), reusing one cached computation.
- `test/d10_livelihood_crosscheck_service_test.dart`: deterministic fixture,
  all three references, no false confirmation, missing sources, 517 intact.

### Tests still required on GitHub Actions / Flutter

`flutter test test/d10_livelihood_crosscheck_service_test.dart`

`flutter test test/d10_vrutti_match_engine_test.dart test/d10_devata_audit_service_test.dart`

`flutter build apk --release`

The current execution environment does not include Flutter/Dart SDK;
ZIP integrity and static file assertions are not substitutes for compilation.

### Read-only top-five career shortlist

The D10 profession screen now displays up to five **primary-planet-confirmed**
source rules (no automatic titles for unconfirmed planets). Ordering within
this shortlist is: full original D10 rule match first, then exact source-planet
correspondence to the three classical D9 channels, then existing IF–THEN
condition coverage. This is a display suggestion, NOT an empirical probability
or a replacement for Green → Pink → Grey ordering in the complete 517 entries.
Tapping any shortlist row opens its original source IF–THEN + D1/D9/D10 audit.
