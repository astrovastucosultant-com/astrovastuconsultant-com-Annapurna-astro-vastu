# Jaimini status clarity and calculated sutras — v1.4.205

- 514 source rules retained unchanged.
- Distinguishes: directly matched atomic condition, nonmatching atomic condition, computed formula, unevaluated rule.
- Five Upagraha longitudes (Dhuma, Vyatipata, Parivesha, Indrachapa, Upaketu) computed using Sun's D1 sidereal longitude; no prediction status assigned.
- Jaimini 7-charakaraka list and A7/UL locations shown as computations; rule-specific interpretation still requires source verification.
- Per-chart cache avoids repeated D9 calculation when scrolling through 514 entries.
- Remedies are unchanged; unverified remedies aren't fabricated.
- Dart/Flutter SDK is not installed in this environment; compilation still requires GitHub Actions.
