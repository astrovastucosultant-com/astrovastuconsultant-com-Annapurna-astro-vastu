# Jaimini v1.4.213 — Rule result/list audit and review checklist

## Source comparison
- Reference: user-supplied 50-page Telugu IF–THEN PDF, dated 23 Oct 2026.
- Previous JSON: 514 distinct IDs (1.* through 14.*).
- New section 15.*: 41 distinct entries from PDF pages 47-50, classified 15A/15B/15C/15D.
- Current JSON: 555 unique IDs, all IF/THEN and source fields present.
- Added section 15 rules are reference-only; their predicates have **not** been implemented. They remain pending, and are not marked as chart-confirmed.

## UI
- Explicit status grouping and order: preliminary matched (green), preliminary not matched (pink), calculated quantity (blue), pending evaluation (grey).
- Result tab: only output from checked preliminary predicate, computed quantity, or an explicit not-confirmed message. The source PDF IF and THEN remain in Inspection tab.
- Rule list checkbox means **reviewed / read**, not "rule matched" or "event verified".
- Review checkboxes persist locally via SharedPreferences, scoped to the chart's JD and ascendant.
- Review completion percent = reviewed unique rule IDs / all rule IDs. This is **not** likelihood/confidence of an astrological event.
- Optional filter: show unchecked rules only. Search, category and status filters retained.
- PDF origin labels now refer to 50 pages, with newly-added source markers per rule.

## QA performed without a Dart/Flutter SDK
- JSON parsed, 555 unique rule IDs, all required fields nonempty, pages 1-50, new 15.1-15.41 contiguous.
- ZIP integrity should be checked after packaging.
- Flutter compilation, APK install and device visual inspection remain pending; do not mark as build-success before a GitHub Actions run succeeds on this ZIP.
