# Jaimini 46-page complete IF–THEN source catalog — v1.4.204

**Source:** User-supplied *జైమిని సూత్రాలు — అంశాలవారీ సంపూర్ణ IF–THEN నియమాలు.pdf*, 46 pages, 2026-10-23.

- 514 unique numbered rules, source PDF pages 2–46, 14 major sections.
- All 514: source IF, THEN, sutra reference, section, page number.
- UI: Systems → జైమిని System → 514 జైమిని IF–THEN నియమాలు.
- Search, 14-topic filter, directly matched-only filter.
- Each rule: **ఫలితం → పరిశీలన → పరిహారం** (three tabs).
- Previously calculated Jaimini rule hits also have three tabs (replaces stacked details).
- Automatic chart *atomic condition* evaluation is limited to selected direct AK Karakamsa sign, D9 KL/2nd planet occupancy, and some KL/5th combinations. A matched atomic condition does not verify an entire prediction or original Sanskrit verse.
- All remaining complex predicates remain **pending**; result language is printed from source for reference only. It is explicitly NOT a chart hit and never gets a false green check.
- Source PDF does not supply specific rule-linked remedies; the new catalog has a remedy tab clearly saying no verified source, without generating one.
- Existing Chara Dasha, arudha, five-level display and other app modules preserved without changing computations.
- Existing user-authored source contains historical and sometimes sensitive medical/death descriptions. Display as historical source conditions only, not clinical diagnosis, proof, or guaranteed future event.

## Source coverage and distinction

The source PDF is a **compiled Telugu IF–THEN rulebook with indicated sutra numbers and commentarial expansions**, *not an independently checked Sanskrit verse-by-verse transcription*. Its 514 records are registered as PDF-derived source entries. SourceKind explicitly distinguishes records that indicate వ్యాఖ్యానం from the rest. No new remedies were invented.

## Build status

Source/asset JSON and ZIP consistency validated. **Flutter compilation, widget tests, and Android APK build have NOT been executed in the offline environment.** Verify them using GitHub Actions before installing the APK.
