# Annapurna Astro Vastu v1.4.208 — Jaimini additional calculations

Source: supplied 46-page Telugu Jaimini IF–THEN compilation, 514 unique entries. The PDF itself states that some entries are commentary or chart examples, not simply independent original sutras.

## Implementation in this release

- **37 additional catalog IDs** have source-specific computation or conditional evidence: `1.11, 1.12, 1.17, 1.26–1.30, 1.34–1.36, 5.14–5.23, 5.25, 6.12, 6.16, 6.17, 6.19, 6.20, 7.1–7.5, 7.7–7.11` (only IDs that exist in the source).
- Prior v1.4.207: 159 rules with formula or predicate. Current total: **196/514 have some executed formula, source-scoped comparison, or predicate**. This is NOT 196 fully-validated predictions.
- Remaining **318** have unimplemented dependencies (complex conditional 81; special sensitive methods 124; conception chart 63; special-reference charts 21; dashas 19; sunrise/ghatika 10).
- Rule 5.25 can test *the literal distinct-lords-in-one-rashi conjunction* as a boolean. When lagna lord and fifth lord are the same planet, the single planet is NOT wrongly counted as two planets in conjunction.
- Rule 5.14 examines six Lagna/seventh-sign aspects on D1, D3, and D9, keeping the result as calculated evidence, not a direct kingship prediction.
- `1.26–1.30`: compare all 66 sign pairs using occupancy, dignity (exaltation/own-sign), and modality, leaving unresolved comparisons pending friendship/lord-strength tie-breakers.
- `1.11/1.12`: Argala/Virodha counts are displayed, not promoted to a final strength comparison. Ketu's reversal interpretation is explicitly left pending.
- UL/A7, sensitive health and child-related rules display relevant geometric relationships **without** definitive claims about health, children's sex, fertility, death, or other life events.
- Original 514 source rules and the existing 3-tab **Result · Jataka Examination · Remedy** layout are preserved. No remedies have been fabricated.

## Evidence and verification

- Regression test source `test/jaimini_additional_rule_engine_test.dart` includes conjunction positive/negative, calculated-vs-confirmed safeguards, sensitive child-family cautions, conception chart gate, and 514-catalog preservation.
- `docs/jaimini_514_execution_audit_v208.json` gives status for all 514 rules.
- ZIP content/integrity and relative imports can be validated offline.
- **Dart/Flutter SDK is not installed in this environment.** `flutter analyze`, `flutter test`, and `flutter build apk --release` have NOT been executed. Successful APK build must be verified via GitHub Actions using `source_zip`.

## Remaining next phases

1. Validate complex conditional predicates one-by-one, especially Argala strength and Rashi Bala exceptions, with controlled test charts.
2. Add sunrise/location-aware Hora, Bhava, Ghatika and Varnada Lagnas; do not infer sunrise from birth longitude alone.
3. Implement dasha methods with explicit school/variant controls; avoid conflating Chara, Sthira and other systems.
4. Add conception-chart-specific data or keep those rules pending.
5. Independent check of the original primary sutra citations, commentary extensions and source-based remedies.
