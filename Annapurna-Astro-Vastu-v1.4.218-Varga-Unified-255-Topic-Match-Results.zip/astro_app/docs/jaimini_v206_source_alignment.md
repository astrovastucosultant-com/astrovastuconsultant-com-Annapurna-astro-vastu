# v1.4.206 Jaimini source-alignment audit

## Scope

- Existing source: 46-page Jaimini IF–THEN PDF supplied by user. All 514 catalogue records are preserved.
- The older legacy `J1Q*` applied-rule dashboard is distinct from the 514 catalog. This patch corrects two mismatches without claiming the full catalogue is now evaluated.

## Corrected rules

- PDF rule **3.51**, page **11**, sutras **1.2.44–47**: Karakamsa fourth house **Saturn + Rahu** (both) for stone, **Mars + Ketu** (both) for brick, Jupiter for wooden house, Sun for thatched dwelling. Previous dashboard incorrectly treated pairs as either/or.
- PDF rule **5.11**, page **17**, sutras **1.3.18–19**: **AL–A7** kendra/trikona is a *wealth* indication; 6/8/12 is a *wealth* caution. The former dashboard incorrectly labeled these as marriage compatibility/instability, and included 6th as an Upachaya favorable case while also adverse.
- UI result now includes each applied rule's ID and source; analysis sections distinguish the IF condition and actual matched evidence.

## No inference

- Construction-material predictions are historical textual indications, not demonstrated material reality, ownership, or purchase timing.
- No remedy invented; existing remedies remain "source not supplied".
- The 514-rule JSON, Chara Dasha, D10, D24, BTR services are unchanged.
- Flutter/Dart compile not run in this environment; execute existing GitHub Actions build for compile verification.
