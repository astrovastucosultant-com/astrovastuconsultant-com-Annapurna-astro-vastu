# Jaimini v1.4.209 — Source formula, verified sunrise & dasha-method audit

Scope: supplied **46-page Jaimini IF–THEN PDF** (514 source rule IDs). No source rule, source wording, or previously matched predicate was deleted.

## Newly addressed source rules (24 IDs)

- **Six Jaimini foundational entries:** 1.15, 1.18, 1.18a, 1.19, 1.20, 1.21. Display AK/DK/UL/A7, seven- versus eight-karaka caveats, and fixed karaka / strength commentary. No independent eight-karaka engine is claimed.
- **Six sunrise-dependent formula entries:** 2.8, 2.9, 2.10, 2.11, 2.12, 2.15. Their computations REQUIRE caller-verified elapsed minutes from the actual **local** sunrise preceding birth. The chart object does not contain that value. Without it, entries remain `pending`. Inputs are opt-in from the catalog screen. This is not an astronomical sunrise calculator or BTR tool.
- **Three method/reference entries:** 2.13, 2.15a, 2.15b. Varnada cannot be fully calculated without sunrise and convention; text audit only.
- **Nine dasha/method entries:** 12.1–12.6, 12.17–12.19. Relative Chara durations reuse the existing CharaDashaService's exact lord/duration routine, WITHOUT fake or estimated birth dates. Other entries show the source formula or method gap. None silently modifies existing Chara Timing/BTR predictions.

## Known method differences: do not silently reconcile

- PDF **12.3** assigns the Chara sequence direction from the **ninth sign from birth Lagna**. The existing `JaiminiCharaDashaService` Method B uses an orientation based on Lagna. Both directions are calculated and labeled; a conflict is displayed, not hidden.
- PDF **12.4** uses AK's Vishama/Sama status for Antardasha direction. The existing CharaDashaService calculates Antardasha direction separately by major-period sign. Those are not assumed equivalent.
- PDF **12.6** states Sthira signs 7/8/9 years; start sign requires a separate Brahma determination.
- PDF **12.5** is the PDF's stated Navamsha Dasha start (odd Lagna vs seventh from even Lagna), but complete Navamsha periods are not established by this evidence alone.

## Invariants

- An arithmetic/source-method calculation sets `calculated=true`, `matched=null`. It never causes a green personal event result.
- Only the existing predicate engines may mark `matched=true/false` for directly tested conditions.
- All 514 entries and remedy tabs remain. The source PDF lacks unique, source-backed remedies for these entries; invented remedies stay disabled.
- Only the six sunrise entries can change from pending to arithmetic evidence with input, and inputs must be within `[0,1440)` minutes.
- Previously implemented 196 source entries are unchanged. v1.4.209 adds 18 non-sunrise method/formula evidence entries; up to 6 additional optional sunrise computations can be made with verified input. This is NOT 220 verified event predictions.

## Build/test limitations

The generated ZIP is statically checked and zip integrity verified. Dart/Flutter SDK is unavailable in the current container; `flutter analyze`, `flutter test`, `flutter build apk` require the existing GitHub workflow. New regression tests are in `test/jaimini_next_batch_rule_engine_test.dart`.
