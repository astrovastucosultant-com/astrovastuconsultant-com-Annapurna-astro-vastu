# Annapurna Astro Vastu v1.4.211 — Jaimini 514 screen audit fixes

Changes from v1.4.210 (which GitHub Actions Build #259 successfully compiled):

- The visible 514/514 is a catalog count, **not** 514 verified personal outcomes.
- Added mutually exclusive status filters (all, atomic match, atomic nonmatch, computed evidence, pending) with each status count.
- The Result tab now first shows the actual chart evidence, then identifies PDF IF and THEN as *source statements* rather than confirmed outcomes.
- Removed 2-line ellipsis from the list title and 3-line ellipsis from the subtitle.
- JAI-1.8 now displays its reference-sign/third-house observations as calculated evidence, not a false universal negative based on the natal ascendant alone. The fixed natural-malefic subset and unresolved malefic-classification variants are explicitly disclosed.
- Existing source catalog (514 records), three tabs, chart details, and verified-remedy safeguard are preserved.

No new life outcome is asserted merely because a reference-sign calculation is available.
The Dart/Flutter SDK is not installed locally. This file passed ZIP integrity and offline structural audits only. GitHub Actions APK compile of v1.4.211 remains to be verified after uploading this ZIP.
