# Annapurna Astro Vastu v1.4.212 — targeted Jaimini rule audit

Source: v1.4.211 (Build #260 successful on GitHub).

- JAI-3.63 through 3.67: display actual D9 planet sign and KL seventh sign; avoid English `false` and missing-planet negatives.
- JAI-3.72 through 3.74: refuse a Ketu-only assertion unless all nine natal planet placements are available; separate branches of KL twelfth and AmK-navamsa twelfth; distinguish Rahu and Ketu-only and Ketu conjunction alternatives; do not turn a group into one unqualified result. AmK absent => pending alternative.
- JAI-8.5: expose the three necessary reference pairs and the agreement/scale table as missing evidence rather than guessing longevity.
- Cleaned limited proven OCR tails in source entries, with original wording saved as `extractedTextBeforeCorrection`.
- All 514 source IDs remain present; this is not 514 complete personal verdicts.

Verification: ZIP integrity and offline source-level checks. Local Flutter/Dart binaries are unavailable, so v1.4.212 APK compilation and device testing require GitHub Actions. Do not say successful build until its action passes.
