# v1.4.197 — Business Investment Timing (D1/D2/D10 with D4/D16 routing)

## Scope and navigation

Chart → D2 / D4 / D10 / D16 → **Business Investment Timing · పెట్టుబడి కాలం**.
Choose **general business, property, transport vehicles, factory machinery,
financial investments**. D4 is considered only for property/plant foundation,
D16 only for vehicle/machinery contexts. Passive stocks/financial investing does
not inherit an unwarranted D10 occupation confirmation.

## What this update actually calculates

- Reuses the natal chart (D1), existing D2/Indu Lagna/Dhana Asthi *matched*
  rules, D10 occupational house inspection, and actual D4/D16 placements when
  appropriate. It also displays D2 Hora placements as **neutral** background;
  they are not mislabeled as a verified wealth prediction.
- Source-backed rules preserve their **original Rule IDs, conditions and PDF
  source page**, e.g., D2-OT-002, D2-OT-003; the app-created D1/D4/D10/D16
  supplementary house conditions are explicitly labeled an **interpretive
  combination**, not a verified single classical investment formula.
- Monthly **Vimshottari MD + AD and actual sidereal Jupiter/Saturn transits**
  from the established services; samples at the 15th of each month. Each
  time window requires compatible dasha lords, both transits, and at least two
  distinct interpretive evidence categories. Adjacent matches with the same
  MD/AD/status are combined. No support => **unverified**, not a loss verdict.
- Separates past and present/future periods, with evidence and caveats.
- D2-PR-011 on property: 4th, 9th, or 11th-house dasha lord is examined
  alongside the general conservative two-dasha gate.

## Non-goals / audit boundaries

- Does **not** replace the 517 D10 occupation registrations, existing D10
  profit-loss evaluations, D3-J, D9, Timing of Event, or BTR.
- Rule counts are **not percentages**, guaranteed return, or real-world
  investment predictions.
- Existing D2 source PDF rules sometimes use D1 or Indu Lagna rather than
  D2 Hora. The screen identifies the actual calculation source instead of
  claiming that all rules were calculated from D2.
- Source-to-shloka validation for every user-supplied investment rule has not
  yet been performed. Classically defined varga domains are separate from
  this new app-designed month-sampling / rule-convergence heuristic.
- Flutter compilation and the Dart/Flutter tests require running the GitHub
  workflow or a local Flutter installation; not asserted by ZIP integrity.

## Modified and added source files

Modified:
- `pubspec.yaml` (version 1.4.197+197)
- `lib/screens/chart_screen.dart` (navigation buttons)

Added:
- `lib/astrology/business_investment_timing_service.dart`
- `lib/screens/business_investment_timing_screen.dart`
- `test/business_investment_timing_service_test.dart`
- This audit file
