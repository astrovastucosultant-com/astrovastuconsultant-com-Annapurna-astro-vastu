# v1.4.210 — GitHub Build #258 Dart Compile fixes

This update is based on the complete v1.4.209 source ZIP. Only the two Dart
sources, a regression test and the app version were altered. The 514-rule
catalog and all existing app screens remain unchanged.

GitHub Build #258 errors addressed:

1. lib/astrology/jaimini_additional_rule_engine.dart:200
   Bad split interpolation in Jaimini rule 5.16 (Mars/Venus mutual aspect).
   FIX: Compute `mutualAspect` as a typed boolean, then interpolate it.

2. lib/astrology/jaimini_next_batch_rule_engine.dart:160
   `auditDurations(...)` returns a record with `periods`, NOT `mahadashas`.
   FIX: Read `dasha.periods` and keep `dasha.sequenceForward` unchanged.

3. test/jaimini_additional_rule_engine_test.dart
   Added regression cases for true and false Mars/Venus mutual sign aspects;
   the rules remain evidence only, never automatic outcome confirmation.

4. pubspec.yaml
   Bumped the app version to 1.4.210+210.

Validation scope: ZIP CRC/integrity, all unchanged entries preserved byte-wise,
514 distinct IF-THEN rule IDs, YAML parsing, source references and regression
test presence. These checks cannot prove Flutter compilation. Flutter SDK was
not available in the execution environment and network access was unavailable.

Next: GitHub Actions should run flutter test / flutter build apk --release.
If another compiler error appears, use its first Dart file:line message.
