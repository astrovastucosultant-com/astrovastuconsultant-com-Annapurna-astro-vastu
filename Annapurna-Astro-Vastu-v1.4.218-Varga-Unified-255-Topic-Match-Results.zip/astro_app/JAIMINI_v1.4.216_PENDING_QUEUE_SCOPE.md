# v1.4.216 — Pending Rule Evaluation Queue

Source baseline: v1.4.215, 555 unique catalog rule IDs in `assets/jaimini/complete_if_then_rules.json`.

## Change summary
- New `lib/astrology/jaimini_pending_review_engine.dart`: explicit D1/D9/Arudha predicates for source IDs 4.1–4.6 (except 4.7), 4.8–4.10, 4.13, 15.8, 15.12, 15.31, 15.38. Outcomes remain **tested conditions**, not proven events. Underlying source variations are disclosed.
- Additional computed evidence (no blanket true/false) for 3.75a, 15.9, 15.11, 15.13, 15.17, 15.21, 15.23, 15.30.
- Pending rules now show natal Lagna, KL, AL, UL, A7 and the original IF and blockers in the detail view instead of generic text alone. These values are *context*, not a claim that the entire IF condition was checked.
- Compact screen has a one-tap pending queue shortcut. Pending cards show the IF clause, not the book's THEN prediction. User review ticks remain separate from astrological matches.

## Remaining limitations
- 342 was the previous chart's *dynamic* pending count; the new count varies by chart and supported predicates. Pending rules have not been assigned fictitious green/pink outcomes.
- Rules needing conception chart, exact sunrise, verified dasha implementation, secondary chart, comprehensive exceptions, or divergent source validation remain pending.
- Checklist percent is percent manually reviewed, NOT match probability and NOT predictive probability.
- PDF 15th section's variant readings are not collapsed into blanket event assertions.
- This update has not been compiled in a Flutter SDK in the authoring environment. A GitHub Actions build and on-device evaluation is still required.
