# Build 200 — D24 Education Break, Causes & Return to Study

## Purpose

Adds **D24 Education Break & Recovery** as a separate, expandable rule-audit panel before the existing 56-rule D24 education catalogue. Leaves D10, Timing of Event, BTR, D24 education registry and existing scores untouched.

## Source provenance / scope

- **Directly supplied rule:** `D24-VIDYA-CORE-05` from `విద్యా జ్యోతిష నియమాలు – D24.docx`, p. 4, §2.2: D1 4th/5th lords located in 6th/8th/12th in D24, with malefic conjunction -> interruption/change/break.
- **Derived interpretive tests:** D1/D24 4th/5th/9th lords under strain; parental home, family, relationships, finance, studies, health, relocation, and work responsibilities. These cause classifications have **not** been verified as verbatim scriptural verses and may not identify a historical cause. Source tag is included per check.
- **Dasha:** Uses existing Vimshottari MA/AD from natal Moon with user-selected event date; optional AD windows for ages 6–35. No precise life-event prediction is claimed. Jupiter/Saturn transits and actual events remain to be cross-checked.
- **Recovery:** D1 and D24 supportive education lords and Jupiter conditions; original score computation is unchanged. No unprovided remedies are synthesized.

## User flow

`Vargas -> D24 -> D24 — చదువు మధ్యలో ఆగే యోగం · కారణాలు · పునఃప్రారంభం`

Sections: summary, event date picker, exact source audit, eight cause categories (tap -> Result / IF–THEN / Natal Evidence / Remedy+Source), MD+AD evidence, educational age windows, support for resuming.

## Why assertions are gated

- Severe interruption signals only when both D1 and D24 stress evidence exists, and the D24 side is sufficiently supported. A selected date's adverse MD/AD adds timing support; it never independently proves a past event.
- A possible *cause* requires chart-specific signals in BOTH D1 and D24 **and** a general break pattern before it gets prominence. It cannot establish which person or event caused a school interruption.
- Percentages are intentionally not assigned to the causes: there is no calibrated certainty scale for this evidence.
- D24 ascendant / subdivision boundaries depend on birth-time accuracy. BTR may be needed.

## Tests / quality gates

Automated test source: `test/d24_education_break_engine_test.dart` (4 regression cases covering source rule, 8 categories, no certain allegations, and date-dependent dasha). Existing 56-rule tests are retained.

The ZIP package may pass integrity verification without Flutter compiling. GitHub Actions APK build and `flutter test` must still run before calling the update build-verified.
