# Build 198 — D24 విద్యా జ్యోతిష నియమాలు (user-provided DOCX)

## Original source
`docs/d24_uploaded_sources/D24_Vidya_Jyotisha_Niyamalu_2026-10-22.docx` — nine pages as supplied by user on 2026-10-22. Machine-readable verbatim IF/THEN and catalogs in `docs/d24_uploaded_sources/d24_vidya_rules_2026-10-22.json`.

## Registered source rules
- 6 general education conditions
- 26 education-field combinations
- 6 competition/exam conditions
- 14 selective-institution admission conditions
- 4 education timing conditions
- 64 curricula/international/traditional/occult/exam/institution catalog rows (not horoscope rules)

## Calculation and UI
- D24 devata: one of 24 divisions, 1°15' per division, twelve names repeated; odd zodiac signs start Skanda; even signs start Bhima in reverse order.
- Input is original sidereal D1 longitude (including natal ascendant), NOT remapped D24 longitude.
- App D24 view now includes `D24VidyaSourcePanel`, with a collapsible 56-rule audit, source page IDs, 64 catalog items, and separate Result / IF–THEN / Jataka Inspection tabs.
- Computable partial evidence: named planetary devata involvement, D24 house association, conjunction in D24; **not** a complete match to all source requirements.
- Full Shadbala, aspects, admission rank, scholarship, timings, and general guarantee of course/seat are NOT automatically inferred from incomplete inputs. Mark as pending.
- No generic remedies are invented when source has none.
- Existing 517 D10 occupation records, D24 old `Education.pdf` rules, user-defined technical/semi/nontechnical sign mapping, charts, and BTR modules are untouched.

## Test status
- `test/d24_vidya_source_engine_test.dart`: check all 56 rule categories; 64 catalog rows; deity boundaries and odd/even reversal; partial-audit messaging; preserved education sign classification.
- Run `flutter test test/d24_vidya_source_engine_test.dart` and `flutter build apk --release` in GitHub Actions. Flutter SDK unavailable in local packaging environment, so these have not been executed here.
