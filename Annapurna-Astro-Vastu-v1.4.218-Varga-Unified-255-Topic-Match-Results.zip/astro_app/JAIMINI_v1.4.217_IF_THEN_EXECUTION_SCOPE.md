# Annapurna Astro Vastu — Jaimini IF–THEN execution audit (v1.4.217)

Reference: user-supplied Telugu IF–THEN PDF, 50 pages, dated 2026-10-23.

## What changed

- Added explicit `JaiminiSourceRuleBatchEngine` with **154** catalog IDs, of which **153** were not separately referenced by the preceding Dart engines.
- Integration order: existing reviewed computation engines → v1.216 checks → new source-rule batch → source-preserving fallback.
- Added 555-row source reference/coverage JSON under `docs/jaimini_555_coverage_audit_v217.json`.
- Kept 555 original rule records, names, conditions, outcomes and PDF page numbers untouched.
- Preserved green (matched), pink (unmatched), blue (calculations/evidence), gray (pending), and manual checklist state.
- Direct-IF tests are allowed to return matched only with chart positions and all the tested conjuncts. Multi-branch and missing-data rules return calculation/evidence with `matched == null`.

## Key limitations — do not claim all 342 rules were fully resolved

- Newly covered source IDs are **NOT** equivalent to 153 complete personal predictions. Many expose only reproducible evidence and remain blue.
- A source rule can require a separate *adhana/conception chart*, *first-menses chart*, **hora/varnada lagna** based on actual local sunrise, a validated selected dasha, or a second person's chart. The natal D1 cannot safely stand in for those missing charts.
- Sections 8–11 and parts of 14–15 have medical/death/behavior assertions in the PDF. Planet positions may be shown as historical source evidence, but the app does not assert they are verified medical facts or inevitable events.
- The coverage JSON `coverage` field indicates code ID routing, **not** a test success count or a validated personal result. The real status totals depend on chart and must be computed at runtime.
- No original PDF rules were deleted. No astrological probability / outcome certainty percentage was fabricated.

## Verification before release

1. `flutter pub get`
2. `flutter test test/jaimini_source_rule_batch_engine_test.dart`
3. `flutter build apk --release`
4. Open Jaimini with a saved chart, ensure status counts sum to 555, filtered colors/order, each rule evidence and checkbox persist correctly.
5. Audit notable interpretive differences (15.*) with the user's Telugu source before converting multi-outcome branches to matched/pink.
