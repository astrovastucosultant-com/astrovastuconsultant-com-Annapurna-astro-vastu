import 'astro_models.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';
import '../utils/astro_format.dart';

/// Additional checks reviewed against the user's 50-page Telugu IF–THEN PDF.
/// The rule's condition is the authority.  A chart-position test is never a
/// diagnosis, a prediction of death, or an assertion about a person's conduct.
/// Multi-branch rules return *calculated* with each branch's evidence instead
/// of manufacturing a single matched/not-matched outcome.
class JaiminiSourceRuleBatchResult {
  final bool? matched;
  final bool calculated;
  final String evidence;
  const JaiminiSourceRuleBatchResult(this.matched, this.evidence,
      {this.calculated = false});
}

class JaiminiSourceRuleBatchEngine {
  const JaiminiSourceRuleBatchEngine._();

  static const supportedIds = <String>{
    '3.13', '3.23', '3.46a', '3.75', '3.77',
    '4.14', '4.15', '4.16', '4.17', '4.18', '4.19',
    '4.24', '4.25', '4.26', '4.27', '4.28', '4.29', '4.30',
    '4.31', '4.32', '4.33', '4.34', '4.35', '4.36', '4.37',
    '5.10', '5.13', '5.14', '5.26', '5.27', '5.28', '5.29',
    '5.30', '5.31', '5.32', '5.33', '5.34', '5.35', '5.36',
    '5.37', '5.41', '5.42', '5.43', '5.44', '5.45',
    '7.12', '7.13', '7.14', '7.15', '7.16', '7.17',
    '7.18', '7.19', '7.20', '7.21', '7.22',
    '8.1', '8.2', '8.3', '8.4', '8.6', '8.7', '8.8',
    '8.9', '8.10', '8.11', '8.12', '8.13', '8.14', '8.15',
    '8.16', '8.17', '8.18', '8.19', '8.20', '8.21',
    '8.22', '8.23', '8.24', '8.25', '8.26',
    '9.1', '9.2', '9.3', '9.4', '9.5', '9.6', '9.7',
    '9.8', '9.9', '9.10', '9.11', '9.12', '9.13',
    '10.29', '10.30', '10.31', '10.32', '10.33', '10.34',
    '11.12', '11.13', '11.14',
    '14.1', '14.2', '14.3', '14.4', '14.5', '14.6',
    '14.7', '14.8', '14.9', '14.10', '14.11', '14.12',
    '14.13', '14.14', '14.22', '14.23', '14.27',
    '14.28', '14.29', '14.30', '14.31',
    '15.1', '15.2', '15.3', '15.4', '15.5', '15.6',
    '15.7', '15.10', '15.14', '15.15', '15.16',
    '15.18', '15.19', '15.20', '15.22', '15.24',
    '15.25', '15.26', '15.27', '15.28', '15.29',
    '15.32', '15.33', '15.34', '15.35', '15.36',
    '15.37', '15.39', '15.40', '15.41',
  };

  static JaiminiSourceRuleBatchResult? check(String id,
      AstroChartResult chart, JaiminiResult jm) {
    if (!supportedIds.contains(id) || chart.planets.isEmpty) return null;
    final d1 = <String, int>{for (final p in chart.planets) p.name: p.signIndex};
    const essential = <String>{'Sun','Moon','Mars','Mercury','Jupiter',
      'Venus','Saturn','Rahu','Ketu'};
    if (!essential.every(d1.containsKey)) return null;
    final d9 = VargaService.calculate(chart, 9);
    final nav = <String, int>{for (final p in d9.planets) p.name: p.signIndex};
    if (!essential.every(nav.containsKey)) return null;
    final asc = chart.ascendantSignIndex;
    final kl = jm.karakamsaSignIndex;
    final ak = jm.atmakaraka;
    final akSign = d1[ak];
    if ((id.startsWith('3.') || id.startsWith('4.') ||
        id.startsWith('8.') || id.startsWith('15.')) &&
        jm.hasDegreeTie) return null;
    int mod(int value) => (value % 12 + 12) % 12;
    int house(int origin, int number) => mod(origin + number - 1);
    int position(int origin, int target) => mod(target - origin) + 1;
    String sign(int index) => AstroFormat.signNamesTe[mod(index)];
    const lords = <String>[
      'Mars','Venus','Mercury','Moon','Sun','Mercury',
      'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'
    ];
    const benefics = <String>{'Jupiter','Venus','Mercury','Moon'};
    const malefics = <String>{'Sun','Mars','Saturn','Rahu'};
    const exalt = <String,int>{'Sun':0,'Moon':1,'Mars':9,
      'Mercury':5,'Jupiter':3,'Venus':11,'Saturn':6};
    bool at(Map<String,int> ps, String planet, int s) => ps[planet] == mod(s);
    List<String> occupants(Map<String,int> ps, int s) =>
        ps.keys.where((p) => at(ps,p,s)).toList();
    List<String> fromSet(Map<String,int> ps, int s, Set<String> set) =>
        set.where((p) => at(ps,p,s)).toList();
    String names(Iterable<String> ps) => ps.isEmpty ? 'లేవు' : ps.join(', ');
    bool looks(int planetSign, int target) =>
      (jm.rashiDrishti[mod(planetSign)] ?? const <int>[]).contains(mod(target));
    bool influence(Map<String,int> ps, String p, int s) =>
      ps[p] != null && (at(ps,p,s) || looks(ps[p]!,s));
    List<String> influencing(Map<String,int> ps, int s,
        Set<String> planets) =>
      planets.where((p)=>influence(ps,p,s)).toList();
    int? pada(int no) {
      for (final p in jm.arudhaPadas) {
        if (p.padaNumber == no) return p.padaSignIndex;
      }
      return null;
    }
    final al=pada(1), ul=pada(12), a7=pada(7);
    JaiminiSourceRuleBatchResult yes(bool result, String why) =>
      JaiminiSourceRuleBatchResult(result,
        '${result ? 'మూల IF లోని పరీక్షించిన షరతు సరిపోయింది' : 'మూల IF లోని పరీక్షించిన షరతు సరిపోలేదు'}: '
        '$why. ఇది జాతక గ్రహస్థాన పరీక్ష మాత్రమే; మూల THEN అనేది సంఘటన '
        'జరిగిందని/జరుగుతుందని ధృవీకరణ కాదు.');
    JaiminiSourceRuleBatchResult calc(String evidence) =>
      JaiminiSourceRuleBatchResult(null,
        '$evidence. ఈ నియమంలో పూర్తి శాఖలు/బలం/అపవాదాలు ఇంకా '
        'ప్రత్యేకంగా ధృవీకరించాలి; గ్రీన్/పింక్ తుది తీర్పు లేదు.',
        calculated:true);
    String located(Map<String,int> ps, String p) =>
        ps[p] == null ? 'స్థానం అందుబాటులో లేదు' : sign(ps[p]!);
    final k4=house(kl,4), k5=house(kl,5), k7=house(kl,7);

    switch (id) {
      // Source PDF pp. 8, 9, 11, 13: KL subconditions.
      case '3.13':
        final akNav = nav[ak];
        if (akNav == null) return null;
        return calc('AK $ak D9 ${sign(akNav)}; నవాంశంలో యుతి గ్రహాలు '
            '${names(occupants(nav,akNav).where((p)=>p!=ak))}; '
            'ఆ రాశి ఉచ్చ గ్రహాలు: ${names(exalt.keys.where((p)=>nav[p]==exalt[p]))}');
      case '3.23':
        final k2=house(kl,2);
        final rahu=at(nav,'Rahu',k2);
        final good=influencing(nav,k2,benefics),
          bad=influencing(nav,k2,malefics.difference({'Rahu'}));
        return calc('KL 2వది ${sign(k2)}; రాహువు అక్కడ: $rahu; '
          'శుభ దృష్టి/యుతి ${names(good)}, పాప సంబంధం ${names(bad)}; '
          'కేవలం శుభ సంబంధం అనే షరతుకు చంద్ర పక్షబలం, బుధ శుభత్వం అవసరం');
      case '3.46a':
        final second=house(kl,2),third=house(kl,3);
        return calc('KL 2వది ${sign(second)}: ${names(occupants(nav,second))}; '
          'వ్యాఖ్యాన 3వది ${sign(third)}: ${names(occupants(nav,third))}; '
          'PDF పేజీ 11లో 3.36–3.45కు అనుబంధ శాఖ మాత్రమే, స్వతంత్ర ఫలితం కాదు');
      case '3.75':
        final twelfth=house(kl,12);
        return calc('KL 12వది ${sign(twelfth)}; శని అక్కడ ${at(nav,'Saturn',twelfth)}, '
          'శుక్రుడు ${at(nav,'Venus',twelfth)}; రాశి పాపస్వభావ నిర్వచనం '
          'మూల వ్యాఖ్యానం బట్టి ఇంకా ఎంచుకోవాలి');
      case '3.77':
        return calc('చర కారక క్రమం: '
          '${jm.charaKarakas.map((p)=>'${p.code}=${p.planet}').join('; ')}; '
          'AmK తరువాతి కారకుని శుభత్వం, బలం, నీచ స్థానం వేర్వేరుగా పరిశీలించాలి');
      // Source PDF pp. 14–15: 5-degree Kaulaka segments and D1 pairs.
      case '4.14': case '4.15': case '4.16':
      case '4.17': case '4.18': case '4.19':
        final degrees=chart.planets.where((p)=>p.name==ak);
        if (degrees.isEmpty) return null;
        final section=(degrees.first.longitude % 30 / 5).floor()+1;
        final requested=int.parse(id.split('.').last)-13;
        return calc('AK $ak ${located(d1,ak)} రాశిలో '
          '${(degrees.first.longitude % 30).toStringAsFixed(3)}°; '
          '5° విభాగం $section, ఈ సూత్రపు కౌలకం $requested; '
          'కౌలకం బాధితమైందా అనే అదనపు షరతు పరీక్షించలేదు');
      case '4.24': case '4.25': case '4.26': case '4.27':
        final s=house(d1['Sun']!,2), sat=house(d1['Saturn']!,2);
        final ketu=d1['Ketu']!;
        return calc('రవి నుంచి 2వది ${sign(s)}, శని నుంచి 2వది ${sign(sat)}; '
          'కేతువు ${sign(ketu)}; కేతువుకు పాప రాశి దృష్టి '
          '${names(influencing(d1,ketu,malefics))}. '
          'సూత్ర 4.24–4.27లో దృష్టి/విషమపద గణన శాఖలు వేరు');
      case '4.28': case '4.29': case '4.30': case '4.31':
      case '4.32': case '4.33': case '4.34': case '4.35':
      case '4.36': case '4.37':
        final sixth=house(asc,6),eighth=house(asc,8);
        return calc('PDF వ్యాఖ్యాన నియమానికి D1: లగ్నం ${sign(asc)}, '
          '6వది ${sign(sixth)} [${names(occupants(d1,sixth))}], '
          '8వది ${sign(eighth)} [${names(occupants(d1,eighth))}]; '
          'కుజ ${located(d1,'Mars')}, శని ${located(d1,'Saturn')}, '
          'రాహు ${located(d1,'Rahu')}, గురు ${located(d1,'Jupiter')}; '
          'బహుళ గ్రహ/వర్గ బాధలు పూర్తి పరీక్షించలేదు. '
          'ఇవి వైద్య వ్యాధి నిర్ధారణలుగా వాడరాదు');
      // Source PDF pp. 19–22: multiple rajayoga branches.
      case '5.10':
        if(al==null)return null;
        return calc('AL ${sign(al)} మరియు దాని 7వది ${sign(house(al,7))}; '
          'అర్గళ, విరోధ స్థానాల సంఖ్యలు/బలాలు ద్వంద్వంగా తూకం వేయాలి');
      case '5.13':
        return calc('జన్మలగ్నం ${sign(asc)}; హోరా, ఘటికా లగ్నాలకు '
          'స్థానిక సూర్యోదయ సమయం అవసరం. మూడింటిపై ఒకే గ్రహ దృష్టిని '
          'ఇప్పుడే Confirm చేయలేము');
      case '5.14':
        final d3=VargaService.calculate(chart,3);
        final d9Asc=(chart.ascendantLongitude % 30 / (30/9)).floor();
        final d3Asc=(chart.ascendantLongitude % 30 / 10).floor();
        return calc('జన్మలగ్నం ${sign(asc)}; D3 గ్రహాలు '
          '${d3.planets.length}, D9 గ్రహాలు ${d9.planets.length}; '
          'నవాంశ/ద్రేక్కాణ లగ్నాలకు వర్తించే ప్రత్యేక గణనపద్ధతి '
          'బట్టి ఆరు స్థానాల ఒకే రాశిదృష్టి పూర్తి పరీక్ష ఇంకా అవసరం '
          '(నవాంశ ఖండం $d9Asc, ద్రేక్కాణ ఖండం $d3Asc)');
      case '5.26':
        final lagnaLord=lords[asc],fifthLord=lords[house(asc,5)];
        return calc('లగ్నాధిపతి $lagnaLord D9 ${located(nav,lagnaLord)}, '
          'పంచమాధిపతి $fifthLord D9 ${located(nav,fifthLord)}; '
          '5వ ${sign(house(asc,5))}పై శుభ సంబంధం '
          '${names(influencing(d1,house(asc,5),benefics))}; '
          'ఉచ్చ/స్వనవాంశ/వర్గోత్తమ సమ్మిళిత షరతు ఇంకా పరీక్షించాలి');
      case '5.27':
        final l1=lords[asc],l5=lords[house(asc,5)],l7=lords[house(asc,7)];
        final a=d1[l5]==d1[l7],b=d1[l1]==d1[l7];
        return calc('5వ అధిపతి $l5 ${located(d1,l5)}, '
          '7వ అధిపతి $l7 ${located(d1,l7)}, '
          'లగ్నాధిపతి $l1 ${located(d1,l1)}; '
          '5+7 యుతి $a, 1+7 యుతి $b; వయసు/విదేశ ఫలితాల '
          'ప్రత్యామ్నాయ శాఖలు ఒక్కటిగా ప్రకటించలేదు');
      case '5.28':
        final second=house(asc,2);
        final venMoon=at(d1,'Venus',second)&&at(d1,'Moon',second);
        final satKetu=at(d1,'Saturn',second)&&at(d1,'Ketu',second);
        return calc('జన్మలగ్నం నుంచి 2వది ${sign(second)}; '
          'శుక్ర–చంద్ర యుతి $venMoon, శని–కేతు యుతి $satKetu; '
          'ఇవి మూలంలోని రెండు వేర్వేరు శాఖలు');
      case '5.29':
        if(akSign==null)return null;
        final venusSame=d1['Venus']==akSign, mars=at(d1,'Mars',house(akSign,4)),
          ketu=at(d1,'Ketu',house(akSign,2));
        return yes(venusSame&&mars&&ketu,
          'AK $ak ${sign(akSign)}, శుక్రుడు AKతో $venusSame, '
          'AK నుంచి 4వ కుజుడు $mars, 2వ కేతువు $ketu');
      case '5.30':
        return calc('లగ్నం ${sign(asc)}, 7వ ${sign(house(asc,7))}, '
          '9వ ${sign(house(asc,9))}; ఈ మూడింటి సంపూర్ణ రాశిబలం '
          'తూకం వేయకుండా రాజయోగాన్ని Confirm చేయరు');
      case '5.31':
        final p1=occupants(d1,asc).length,p7=occupants(d1,house(asc,7)).length;
        final p2=occupants(d1,house(asc,2)).length,p4=occupants(d1,house(asc,4)).length;
        return calc('లగ్నం/7వ గ్రహ సంఖ్యలు $p1/$p7; '
          '2వ/4వ గ్రహ సంఖ్యలు $p2/$p4; '
          '4వ స్థాన ఉచ్చ గ్రహాలు ${names(occupants(d1,house(asc,4)).where((p)=>exalt[p]==house(asc,4)))}; '
          'రెండు వేర్వేరు వయస్సు ఫలిత శాఖలు');
      case '5.32':
        return calc('గురు ${located(d1,'Jupiter')}, చంద్రుడు ${located(d1,'Moon')}, '
          'బుధుడు ${located(d1,'Mercury')}; లగ్న 1/11 లేదా 1/7 '
          'స్థానాల శాఖలకు శుభ దృష్టి అదనపు ధృవీకరణ అవసరం');
      case '5.33':
        final first=occupants(d1,asc),seventh=occupants(d1,house(asc,7));
        return calc('లగ్నం ${sign(asc)}: ${names(first)}, '
          '7వ ${sign(house(asc,7))}: ${names(seventh)}; '
          'ఉచ్చ, నీచ సమ్మిళిత నియమానికి గ్రహ బలం, ప్రత్యామ్నాయాలు అవసరం');
      case '5.34':
        if (akSign==null)return null;
        final klLord=lords[kl];
        return calc('AK జన్మరాశి ${sign(akSign)}, KL అధిపతి $klLord '
          '${located(d1,klLord)}; చంద్ర/శుక్ర సంబంధాలు: '
          'AK ${names(influencing(d1,akSign,{'Moon','Venus'}))}; '
          'KL అధిపతి ఉన్న రాశి '
          '${names(influencing(d1,d1[klLord]!,{'Moon','Venus'}))}');
      case '5.35':
        return calc('గురు ${located(d1,'Jupiter')}, '
          'చంద్రుడు ${located(d1,'Moon')}; లగ్నం నుంచి 4,10,11 స్థానాలు '
          '${sign(house(asc,4))}, ${sign(house(asc,10))}, '
          '${sign(house(asc,11))}. వేరువేరు రాజయోగ శాఖలు');
      case '5.36': case '5.37':
        final s7=house(asc,7);
        return calc('లగ్నం ${sign(asc)} శుభగ్రహాలు '
          '${names(fromSet(d1,asc,benefics))}; 7వ ${sign(s7)} '
          '${names(fromSet(d1,s7,benefics))}; 7వపై శుభదృష్టులు '
          '${names(influencing(d1,s7,benefics))}; శుభ/పాప మినహాయింపులు');
      case '5.41': case '5.42':
        final pairs=<List<int>>[[2,12],[5,9],[12,6],[3,11],[4,10]];
        final observations=<String>[];
        for (final origin in <int>[asc,kl]) {
          for (final pair in pairs) {
            observations.add('${sign(origin)} ${pair[0]}/${pair[1]}: '
              '${occupants(d1,house(origin,pair[0])).length}/'
              '${occupants(d1,house(origin,pair[1])).length}');
          }
        }
        return calc('గ్రంథంలోని సమసంఖ్య జతలు: ${observations.join('; ')}. '
          'పాప, శుభ దృష్టి మరియు సమాన బలం విడిగా కావాలి');
      case '5.43':
        return calc('ద్వార/బాహ్య రాశుల ఫలితానికి ప్రస్తుతం నడుస్తున్న '
          'స్పష్టమైన దశా రాశి, దశా పద్ధతి అవసరం');
      case '5.44':
        return calc('లగ్నం నుంచి 11వ ${sign(house(asc,11))}; '
          'ఆ రాశి 6వ నుంచి 6వది. ఇది దండహర స్థానం అనే నిర్వచనం మాత్రమే');
      case '5.45':
        return calc('తారాలగ్నానికి జన్మ నక్షత్ర దశాధిపతి, '
          'శేష దశ, దశా విధానం కావాలి; తారాలగ్నం ఊహించలేదు');
      // Childbirth predicates: do not infer actual fertility or fetal outcomes.
      case '7.12': case '7.13': case '7.14': case '7.15':
        final centers=<int>{1,4,7,10}.map((h)=>house(asc,h));
        final trines=<int>{1,5,9}.map((h)=>house(asc,h));
        return calc('లగ్న కేంద్రాల్లో శుభులు: '
          '${names(benefics.where((p)=>centers.contains(d1[p])))}; '
          'త్రికోణాల్లో శుభులు: '
          '${names(benefics.where((p)=>trines.contains(d1[p])))}; '
          '7వ రాశి ${sign(house(asc,7))}పై గ్రహ సంబంధం '
          '${names(influencing(d1,house(asc,7),essential))}; '
          'జంట జాతకాలు, వర్గబలం, చంద్ర కారకాలు అవసరం');
      case '7.16':
        final second=house(d1['Moon']!,2);
        return calc('చంద్ర రాశి ${located(d1,'Moon')}; 2వది ${sign(second)}, '
          'రాశి అధిపతి ${lords[second]}, D9లో '
          '${located(nav,lords[second])}; గురువర్గ నిర్వచనం ధృవీకరణ పెండింగ్');
      case '7.17':
        if(akSign==null)return null;
        final akLord=lords[akSign], marsLord=lords[d1['Mars']!];
        return yes(nav[akLord]==11 && nav[marsLord]==11,
          'AK ${sign(akSign)} అధిపతి $akLord D9 ${located(nav,akLord)}, '
          'కుజ రాశి ${located(d1,'Mars')} అధిపతి $marsLord D9 '
          '${located(nav,marsLord)}; ఇద్దరూ మీన నవాంశలో ఉన్నారా అనే IF మాత్రమే');
      case '7.18':
        return calc('చంద్రుడు ${located(d1,'Moon')}, రాహు '
          '${located(d1,'Rahu')}, కుజుడు ${located(d1,'Mars')}; '
          'పూర్ణ చంద్ర తిథి/పక్ష బలం, “రాహు–కుజ మధ్య” నిర్వచనం కావాలి');
      case '7.19':
        return calc('చంద్ర నవాంశం ${located(nav,'Moon')}, శుభ దృష్టి '
          '${names(influencing(nav,nav['Moon']!,benefics.difference({'Moon'})))}; '
          'శుభ వర్గాల సమగ్ర బలం, చంద్రపక్షం కావాలి');
      case '7.20':
        final moonGood=<int>{3,7}.contains(nav['Moon']);
        final akGood=akSign!=null && <int>{3,7}.contains(nav[ak]);
        final fourth=akSign!=null && at(d1,'Moon',house(akSign,4));
        final eighth=akSign!=null && at(d1,'Moon',house(akSign,8));
        return calc('AK D9 ${located(nav,ak)}, చంద్ర D9 ${located(nav,'Moon')}; '
          'కర్కాటక/వృశ్చిక సూచికలు AK=$akGood, చంద్ర=$moonGood; '
          'AK నుంచి 4వలో చంద్రుడు=$fourth, 8వలో=$eighth. '
          'ఇవి ప్రత్యామ్నాయ సంకేతాలు; సంతానం వైద్య నిర్ధారణ కాదు');
      case '7.21':
        return calc('చంద్రుడికి శుభ సంబంధం '
          '${names(influencing(d1,d1['Moon']!,benefics.difference({'Moon'})))}; '
          'AK $ak కి శుభ సంబంధం '
          '${akSign==null ? 'AK రాశి లేదు' : names(influencing(d1,akSign,benefics))}; '
          'ప్రసవ స్పృహపై గ్రహస్థానాలనుంచి వైద్య తీర్పు ఇవ్వము');
      case '7.22':
        return calc('PDFలో సంతాన స్థిర/చర కారక జాబితా; '
          'జన్మ 5వ ${sign(house(asc,5))}, 9వ ${sign(house(asc,9))}, '
          'KL ${sign(kl)}, UL ${ul==null ? 'లెక్కలేదు' : sign(ul)}. '
          'ఈ నియమం స్వతంత్ర సంఘటన IF కాదు');
      // Longevity, mortality and death-related records are evidence ONLY.
      case '8.1': case '8.2': case '8.3': case '8.4':
      case '8.6': case '8.7': case '8.8': case '8.9':
      case '8.10': case '8.11': case '8.12': case '8.13':
      case '8.14': case '8.15': case '8.16': case '8.17':
      case '8.18': case '8.19': case '8.20': case '8.21':
      case '8.22': case '8.23': case '8.24': case '8.25': case '8.26':
        final eighth=house(asc,8),eighthLord=lords[eighth];
        final moonHouse=position(asc,d1['Moon']!);
        final akHouse=akSign == null ? null : position(asc,akSign);
        return calc('ఆయుర్దాయ మూల గణనాధారాలు: లగ్నం ${sign(asc)}, '
          '8వ ${sign(eighth)}, అధిపతి $eighthLord '
          '${located(d1,eighthLord)}, చంద్రుడు ${located(d1,'Moon')} '
          '(లగ్నం నుంచి $moonHouse), AK $ak '
          '${akSign == null ? 'లెక్కలేదు' : sign(akSign)} '
          '(లగ్నం నుంచి ${akHouse ?? 'లెక్కలేదు'}), '
          'శని ${located(d1,'Saturn')}; ఆయుష్కక్ష్య/మినహాయింపులు '
          'మూడు జతల మరియు దశల తుది ఏకీభావం లేకుండా ప్రకటించము');
      case '9.1': case '9.2': case '9.3': case '9.4':
      case '9.5': case '9.6': case '9.7': case '9.8':
      case '9.9': case '9.10': case '9.11': case '9.12': case '9.13':
        return calc('మరణకాల మూల నియమం; ద్వార రాశి నడుస్తున్న దశా రాశి '
          'నుంచి మాత్రమే లెక్కించాలి. ఇక్కడ దశా పద్ధతి/జనన తేదీ '
          'నుంచి ఎంపిక చేసిన యథార్థ దశ రాశి లేదు. '
          'జన్మలగ్నం ${sign(asc)}, AL '
          '${al==null?'లభించలేదు':sign(al)}, '
          '8వ రాశి ${sign(house(asc,8))}; మరణతేదీ/సంఘటనగా ప్రకటించము');
      case '10.29': case '10.30': case '10.31':
      case '10.32': case '10.33': case '10.34':
        return calc('PDF 10వ విభాగం: అసహజ/సహజ మరణ వర్గీకరణ. '
          'లగ్నం నుంచి 8వ ${sign(house(asc,8))}లో '
          '${names(occupants(d1,house(asc,8)))}; '
          'AK నుంచి 8వ ${akSign==null?'లభించలేదు':sign(house(akSign,8))}. '
          'గ్రహస్థానాలను మరణ కారణం/ప్రమాదంగా నిర్ధారించలేదు');
      case '11.12': case '11.13': case '11.14':
        return calc('లగ్నం ${sign(asc)}, 7వ ${sign(house(asc,7))}లో '
          '${names(occupants(d1,house(asc,7)))}; '
          'శని ${located(d1,'Saturn')}, రాహువు '
          '${located(d1,'Rahu')}, కేతువు ${located(d1,'Ketu')}; '
          'ఇతర వ్యక్తుల మరణం/అంత్యక్రియలకు నిర్ధారణ కాదు');
      // PDF pp. 43–45: interpretive and sensitive behavioural rules.
      case '14.1': case '14.2': case '14.3': case '14.4':
      case '14.5': case '14.6': case '14.7': case '14.8':
      case '14.9': case '14.10': case '14.11': case '14.12':
      case '14.13': case '14.14':
        return calc('ఈ స్త్రీజాతక మూలానికి అవసరమైన హోరా లగ్నం '
          'లేదా ఆధాన/ప్రథమరజస్సు వంటి వేరు చక్రం ఇక్కడ లేదు. '
          'D1 కుజుడు ${located(d1,'Mars')}, '
          'కేతువు ${located(d1,'Ketu')}, '
          'శని ${located(d1,'Saturn')}; సంబంధం/వైధవ్యంపై '
          'నైతిక తీర్పు లేదా సంభవించిన సంఘటన ప్రకటించము');
      case '14.22': case '14.23': case '14.27':
      case '14.28': case '14.29': case '14.30': case '14.31':
        return calc('స్త్రీజాతక వ్యాఖ్యాన మూలం: లగ్నం ${sign(asc)}, '
          '4వ ${sign(house(asc,4))}, 7వ ${sign(house(asc,7))}; '
          'వర్ణద, నవాంశ, త్రింశాంశ, దశా శాఖలు పూర్తి అవసరం. '
          'శీలం, ఆరోగ్యం లేదా జీవన సంఘటనపై తీర్పు ఇవ్వలేదు');
      // PDF pp. 47–50: appended Nilakantha Telugu interpretation variants.
      case '15.1':
        return calc('PDF 15.1లో కేవలం KL రాశికి వృత్తి నియమాలు; '
          'KL ${sign(kl)}, గ్రహాలు ${names(occupants(nav,kl))}; '
          '3Bలో ఉన్న KL/2వది సంప్రదాయంతో ఈ ప్రత్యామ్నాయాన్ని కలపలేదు');
      case '15.2':
        return yes(at(nav,'Mars',kl),
          'KL ${sign(kl)}; కుజ D9 ${located(nav,'Mars')}; '
          'KLలో కుజుడున్నాడా అనే PDF 15.2 ప్రత్యక్ష IF');
      case '15.3':
        if(akSign==null)return null;
        final navSign=nav[ak];
        if(navSign==null)return null;
        final kendras=<int>{1,4,7,10}.map((h)=>house(navSign,h));
        return calc('AK $ak D1 ${sign(akSign)}, D9 ${sign(navSign)}, '
          'D9 కేంద్రాల్లో శుభగ్రహాలు '
          '${names(benefics.where((p)=>kendras.contains(nav[p])))}; '
          'శుభ రాశి/శుభ నవాంశ నిర్వచనాన్ని గ్రంథ బలం ప్రకారం పూర్తి చేయాలి');
      case '15.4':
        return calc('15.3లోని AK–శుభనవాంశ యోగం, KL 12వ ఉపగ్రహం, '
          'ఉచ్చ/స్వ/శుభ వర్గం, పాప దృష్టి మినహాయింపులు '
          'పూర్తి అమలు కానంతవరకు మోక్ష ఫలితం ప్రకటించము');
      case '15.5':
        return calc('AK $ak నవాంశం ${located(nav,ak)}; చంద్ర/శుక్ర/కుజ '
          'నవాంశాధిపత్య భేదాలు మూలం ప్రకారం విడిగా పరీక్షించాలి. '
          'వ్యక్తి శీలంపై తీర్పు ఇవ్వలేదు');
      case '15.6':
        return calc('గుళిక నవాంశాన్ని లెక్కించేందుకు స్థానిక పగలు/రాత్రి '
          'వ్యవధులు, వారాధిపత్య భాగం కావాలి; AK నవాంశం '
          '${located(nav,ak)} మాత్రమే ఇప్పుడు లభించింది');
      case '15.7':
        final twelfth=house(kl,12);
        final beneficKL=fromSet(nav,kl,benefics);
        final first=<int>{0,8}.contains(kl)&&beneficKL.isNotEmpty;
        final second=<int>{0,8}.contains(twelfth)&&at(nav,'Ketu',twelfth);
        return calc('తెలుగు PDF ప్రత్యామ్నాయం: KL ${sign(kl)}, '
          'KLలో శుభులు ${names(beneficKL)}, '
          'KL మేషం/ధనుస్సు + శుభుడు = $first; '
          'KL 12వది ${sign(twelfth)} కేతువు = $second. '
          'PDFలోని ఆంగ్లపద్ధతితో రాశి-భేదం కలపలేదు');
      case '15.10':
        if(al==null)return null;
        final eleventh=house(al,11), twelfth=house(al,12);
        return calc('AL ${sign(al)} నుంచి 11వది ${sign(eleventh)}: '
          '${names(occupants(d1,eleventh))}; 12వది ${sign(twelfth)}: '
          '${names(occupants(d1,twelfth))}; '
          'ఉచ్చ/అర్గళ/లగ్న–భాగ్యాధిపతుల దృష్టి స్వతంత్ర శాఖలు');
      case '15.14':
        if(al==null)return null;
        return calc('AL ${sign(al)} నుంచి అర్గళ స్థానాలు 2/4/11: '
          '${names(occupants(d1,house(al,2)))}, '
          '${names(occupants(d1,house(al,4)))}, '
          '${names(occupants(d1,house(al,11)))}; '
          'అడ్డుపడే స్థానాలు 12/10/3 కూడా తూకం వేయాలి');
      case '15.15':
        return calc('ఉచ్చగ్రహాల D1 జాబితా: '
          '${names(exalt.keys.where((p)=>d1[p]==exalt[p]))}; '
          'రాజయోగ దృష్టి, దుష్ట అర్గళ లేమి, అనేక గ్రహాల '
          'భిన్న శాఖలు ఇంకా నిర్ధారించాలి');
      case '15.16':
        return calc('±2 ఘటికలు = ±48 నిమిషాలు; మధ్యాహ్నం/అర్ధరాత్రి '
          'సూర్య-నిజ సమయాల పరిధి ప్రకారం స్థానిక జనన సమయం పరీక్షించాలి. '
          'జన్మ సమయాన్ని 12:00గా ఊహించలేదు');
      case '15.18':
        final lagnaLord=lords[asc],seventhLord=lords[house(asc,7)];
        final views=<String>[];
        for(final lord in {lagnaLord,seventhLord}) {
          final origin=d1[lord]!;
          views.add('$lord ${sign(origin)}: 5వ ${sign(house(origin,5))}లో '
            '${names(fromSet(d1,house(origin,5),{'Jupiter','Venus','Moon'}))}; '
            '3వ/6వ పాపులు ${names(fromSet(d1,house(origin,3),malefics))}/'
            '${names(fromSet(d1,house(origin,6),malefics))}');
        }
        return calc('PDF తెలుగు మూల లగ్న/సప్తమాధిపతి శాఖలు: '
          '${views.join('; ')}; AK-ఆధార ఆంగ్ల భేదాన్ని కలపలేదు');
      case '15.19':
        final lord=lords[asc],klLord=lords[kl],twelveLord=lords[house(asc,12)];
        return calc('లగ్నాధిపతి $lord ${located(d1,lord)}, '
          'KL అధిపతి $klLord ${located(nav,klLord)}, '
          '12వ అధిపతి $twelveLord ${located(d1,twelveLord)}; '
          'లగ్నం/కారకాంశానికి వారి స్వరాశి దృష్టులు '
          'వేర్వేరు వర్గాల్లో ధృవీకరించాలి');
      case '15.20':
        return calc('బంధన యోగ జతలు PDF 5.41/5.42లో ఉన్నాయి; '
          'శుభ సంబంధం ఉంటే వేరే శాఖ. మొదట యోగజతల సమాన బలాన్ని '
          'పరీక్షించకుండా గృహనిర్బంధం నిర్ధారించరాదు');
      case '15.22':
        if(ul==null)return null;
        final second=house(ul,2);
        return calc('UL ${sign(ul)} నుంచి 2వ ${sign(second)}; '
          'శుభ గ్రహాల యుతి ${names(fromSet(d1,second,benefics))}; '
          'మూల “పాప రాశి” నిర్వచనం/దృష్టులు పూర్తి కాక '
          'వ్యక్తిగత స్వభావంపై ఆరోపణ చేయరాదు');
      case '15.24':
        if(ul==null)return null;
        final second=house(ul,2);
        final type=<int>{2,5,0,7}.contains(second);
        final j=at(d1,'Jupiter',second), r=at(d1,'Rahu',second);
        return yes(type&&j&&r,
          'UL ${sign(ul)} నుంచి 2వది ${sign(second)}; '
          'బుధ/కుజ అధిపత్య రాశి $type; గురువు అక్కడ $j, రాహువు అక్కడ $r. '
          'ఇది దంత వైద్య సమస్య నిర్ధారణ కాదు');
      case '15.25':
        if(ul==null)return null;
        final target=house(ul,7);
        return calc('UL ${sign(ul)}, 7వది ${sign(target)}; '
          'అక్కడ ${names(occupants(d1,target))}; '
          '7వ భావ నవాంశం నుంచి 5వకు సంబంధించిన అన్ని '
          'పరస్పర ప్రత్యామ్నాయ శాఖలను వేరు ఉంచాలి');
      case '15.26':
        return calc('AK $ak, KL నుంచి 8వ ${sign(house(kl,8))}లో '
          'పాపులు ${names(fromSet(nav,house(kl,8),malefics))}; '
          'తెలుగు/ఆంగ్ల వ్యాఖ్యాన భేదం వల్ల ఒకే తీర్పు ఇవ్వలేదు');
      case '15.27': case '15.28': case '15.29':
        return calc('ఈ ఆయుర్దాయ/శూలదశ శాఖకు వర్ణద/హోరా '
          'లగ్నం, స్వతంత్ర దశా పద్ధతి, బలగణన అవసరం. '
          'జన్మలగ్నం ${sign(asc)} మాత్రమే తెలిసినప్పుడు '
          'ఏ వ్యక్తి ఆయుర్దాయం/గండం ప్రకటించరాదు');
      case '15.32': case '15.33': case '15.34':
      case '15.35': case '15.37': case '15.41':
        return calc('PDF మరణ/శూలదశ వ్యాఖ్యాన శాఖకు ఎంచుకున్న '
          'దశా రాశి, దాని బాహ్య/పాక భోగం, రుద్రు బలం/శూలదశ '
          'అవసరం; వ్యక్తి మరణం/వయసు ఊహించలేదు');
      case '15.36':
        return calc('లగ్నం ${sign(asc)}; తెలుగు పాఠంలోని మేష '
          'ప్రత్యామ్నాయ సూచిక: ${asc == 0}; ఆంగ్ల వ్యాఖ్యానంలో '
          'మీనం. రుద్ర దశ/మరణం నిర్ధారించలేదు');
      case '15.39':
        final moon = d1['Moon']!, sun = d1['Sun']!;
        return calc('తల్లిదండ్రుల కారక సూచనలు రవి ${sign(sun)}, '
          'చంద్రుడు ${sign(moon)}; గురు/శుక్ర రాశి దృష్టులు '
          'రవి ${names(influencing(d1,sun,{'Jupiter','Venus'}))}, '
          'చంద్ర ${names(influencing(d1,moon,{'Jupiter','Venus'}))}; '
          'చిన్నారి మరణాన్ని నిర్ధారించే నియమం కాదు');
      case '15.40':
        final sat=d1['Saturn']!,rahu=d1['Rahu']!,ketu=d1['Ketu']!;
        return calc('శని ${sign(sat)}, రాహు ${sign(rahu)}, '
          'కేతు ${sign(ketu)}; లగ్న/12వ రాశి అర్ధభాగం '
          'మరియు యుతి శాఖలను పూర్తిగా ధృవీకరించకుండా '
          'తల్లిదండ్రుల అంత్యక్రియల గురించి తీర్పు ఇవ్వము');
    }
    return null;
  }
}
