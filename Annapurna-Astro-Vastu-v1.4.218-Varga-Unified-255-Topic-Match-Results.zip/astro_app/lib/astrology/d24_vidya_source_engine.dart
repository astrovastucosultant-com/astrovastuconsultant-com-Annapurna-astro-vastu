import 'astro_models.dart';
import 'varga_service.dart';
import 'd24_vidya_source_registry.dart';

/// Source-audited D24 observations. A match is evidence for *part* of the
/// source IF; it is never a verified course, rank or admission prediction.
enum D24CheckStatus { matched, notObserved, pending }

class D24VidyaConditionCheck {
  final String title;
  final String detail;
  final D24CheckStatus status;
  const D24VidyaConditionCheck(this.title, this.detail, this.status);

  String get marker => switch (status) {
    D24CheckStatus.matched => '✓',
    D24CheckStatus.notObserved => '✕',
    D24CheckStatus.pending => '◌',
  };

  String get stateText => switch (status) {
    D24CheckStatus.matched => 'ఆధారం ఉంది',
    D24CheckStatus.notObserved => 'ప్రత్యక్ష ఆధారం కనిపించలేదు',
    D24CheckStatus.pending => 'పరిశీలన మిగిలి ఉంది',
  };
}

/// Each 1°15′ part is based on the original D1 sidereal longitude.
/// Never subdivide a D24-remapped longitude for its devata.
class D24VidyaDevata {
  final int part;
  final String name;
  final bool oddSign;
  final double natalDegreesInSign;
  const D24VidyaDevata(this.part, this.name, this.oddSign, this.natalDegreesInSign);
}

class D24VidyaRuleAudit {
  final D24VidyaSourceRule source;
  final bool devataSupport;
  final bool relevantHouseSupport;
  final bool planetRelationSupport;
  final List<D24VidyaConditionCheck> checks;
  final String explanation;
  const D24VidyaRuleAudit({
    required this.source,
    required this.devataSupport,
    required this.relevantHouseSupport,
    required this.planetRelationSupport,
    required this.checks,
    required this.explanation,
  });

  int get matchedCount => checks.where((c) => c.status == D24CheckStatus.matched).length;
  int get notObservedCount => checks.where((c) => c.status == D24CheckStatus.notObserved).length;
  int get pendingCount => checks.where((c) => c.status == D24CheckStatus.pending).length;
  bool get hasSupportingEvidence => matchedCount > 0;

  // These are indispensable SOURCE IF components, not independent bonus
  // scores.  A relationship between ONE pair of multiple karaka planets
  // is still just partial supporting evidence, never a complete yoga.
  static const _mainSourceConditions = <String>{
    'కారక గ్రహాల D24 కలయిక/పరాశరీ గ్రహదృష్టి',
    'కారక గ్రహానికి నిర్దేశించిన అంశదేవత',
    'D24 భావ సంబంధం (ప్రత్యక్ష)',
  };
  List<D24VidyaConditionCheck> get missingMainConditions =>
      checks.where((c) =>
        _mainSourceConditions.contains(c.title) &&
        c.status == D24CheckStatus.notObserved).toList(growable:false);

  // Never claim a full IF-THEN match from partial checks. Shadbala,
  // untested aspects, dashas and exam eligibility can still be pending.
  String get ruleVerdict {
    if (missingMainConditions.isNotEmpty) {
      return hasSupportingEvidence
          ? 'పాక్షిక మద్దతు మాత్రమే · ముఖ్యమైన IF షరతులు కనిపించలేదు'
          : 'ప్రధాన IF షరతులకు ప్రత్యక్ష మద్దతు కనిపించలేదు';
    }
    if (hasSupportingEvidence) {
      return 'పాక్షిక ఆధారాలు ఉన్నాయి · మిగిలిన షరతులు పరిశీలించాలి';
    }
    return 'పూర్తి నియమ పరిశీలన పెండింగ్';
  }

  String get label => '$ruleVerdict · తుది నిర్ధారణ కాదు';

  String get checkReport => checks.map((c) =>
    '${c.marker} ${c.title} — ${c.stateText}\n${c.detail}').join('\n\n');
}

class D24VidyaSourceEngine {
  static const signNames = <String>[
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];
  static const _signLords = <String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  static const _exaltation = <String,int>{
    'Sun':0,'Moon':1,'Mars':9,'Mercury':5,
    'Jupiter':3,'Venus':11,'Saturn':6,
  };
  static const _teluguNames = <String,String>{
    'Sun':'సూర్యుడు','Moon':'చంద్రుడు','Mars':'కుజుడు',
    'Mercury':'బుధుడు','Jupiter':'గురువు','Venus':'శుక్రుడు',
    'Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు',
  };
  static const _malefics = <String>['Mars','Saturn','Rahu','Ketu'];
  static const _kendraTrikona = <int>[1,4,5,7,9,10];

  static D24VidyaDevata devataForLongitude(double longitude) {
    final normalized = (longitude % 360.0 + 360.0) % 360.0;
    final sign = (normalized / 30.0).floor();
    final degree = normalized % 30.0;
    final part = (degree / 1.25).floor().clamp(0,23).toInt();
    final isOddSign = sign.isEven; // Aries=0, Taurus=1.
    final deityIndex = isOddSign ? (part % 12) : (11 - (part % 12));
    return D24VidyaDevata(part+1,
        D24VidyaSourceRegistry.oddDevatas[deityIndex], isOddSign, degree);
  }

  static String signLord(int sign) => _signLords[((sign%12)+12)%12];
  static String teluguPlanet(String name) => _teluguNames[name] ?? name;

  static Map<String,D24VidyaDevata> allDevatas(AstroChartResult chart) => {
    'లగ్నం': devataForLongitude(chart.ascendantLongitude),
    for (final planet in chart.planets)
      planet.name: devataForLongitude(planet.longitude),
  };

  static List<D24VidyaRuleAudit> evaluate(AstroChartResult chart) {
    final context = _AuditContext(chart);
    return D24VidyaSourceRegistry.rules.map(context.analyze).toList(growable:false);
  }
}

class _AuditContext {
  final AstroChartResult chart;
  late final VargaChartData d24;
  late final Map<String,VargaPlacement> placements;
  late final Map<String,D24VidyaDevata> devatas;

  _AuditContext(this.chart) {
    d24 = VargaService.calculate(chart,24);
    placements = {for (final p in d24.planets) p.name:p};
    devatas = D24VidyaSourceEngine.allDevatas(chart);
  }

  int? house(String name) {
    final p = placements[name];
    if (p == null) return null;
    return ((p.signIndex-d24.ascendantSignIndex+12)%12)+1;
  }

  String houseLord(int h, {bool d1=false}) => D24VidyaSourceEngine.signLord(
    ((d1 ? chart.ascendantSignIndex : d24.ascendantSignIndex) +h-1)%12);

  String placementText(String name) {
    final p = placements[name];
    if (p==null) return '${D24VidyaSourceEngine.teluguPlanet(name)}: గ్రహస్థానం లభించలేదు';
    final sign = D24VidyaSourceEngine.signNames[p.signIndex];
    return '${D24VidyaSourceEngine.teluguPlanet(name)}: D24 $sign · ${house(name)}వ భావం · '
        'అంశదేవత ${devatas[name]?.name ?? 'లభించలేదు'} '
        '(జనన ${devatas[name]?.part ?? '-'}వ భాగం)';
  }

  bool strongByOwnOrExalt(String name) {
    final p=placements[name];
    if (p==null) return false;
    return D24VidyaSourceEngine.signLord(p.signIndex)==name ||
      D24VidyaSourceEngine._exaltation[name]==p.signIndex;
  }

  bool sameSign(String a,String b) => placements[a]!=null && placements[b]!=null &&
      placements[a]!.signIndex==placements[b]!.signIndex;

  /// Classical Parashari planetary aspects for the seven visible planets.
  /// Node aspects vary by tradition and are NOT presumed here.
  bool aspects(String a, String b) {
    final x=placements[a],y=placements[b];
    if (x==null || y==null || !(const <String>[
      'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn',
    ]).contains(a)) return false;
    final distance = ((y.signIndex-x.signIndex+12)%12)+1;
    if (distance==7) return true;
    if (a=='Mars' && (distance==4 || distance==8)) return true;
    if (a=='Jupiter' && (distance==5 || distance==9)) return true;
    if (a=='Saturn' && (distance==3 || distance==10)) return true;
    return false;
  }

  bool relationship(String a,String b) =>
      sameSign(a,b) || aspects(a,b) || aspects(b,a);

  String relationshipText(String a,String b) {
    final first=D24VidyaSourceEngine.teluguPlanet(a);
    final second=D24VidyaSourceEngine.teluguPlanet(b);
    if (sameSign(a,b)) return '$first–$second: D24లో ఒకే రాశి కలయిక ఉంది';
    if (aspects(a,b)||aspects(b,a)) return '$first–$second: పరాశరీ గ్రహదృష్టి ఉంది';
    return '$first–$second: ప్రత్యక్ష కలయిక/పరిశీలించిన గ్రహదృష్టి కనిపించలేదు';
  }

  D24VidyaConditionCheck _check(String title,String detail,bool? value) =>
      D24VidyaConditionCheck(title,detail,value==null ? D24CheckStatus.pending :
        value ? D24CheckStatus.matched : D24CheckStatus.notObserved);

  void _baseSpecial(D24VidyaSourceRule rule,List<D24VidyaConditionCheck> out) {
    final id=rule.id;
    if (id=='D24-VIDYA-CORE-01') {
      final lord=houseLord(1);
      out.add(_check('D24 లగ్నాధిపతి కేంద్రం/త్రికోణం',
          '$lord (${D24VidyaSourceEngine.teluguPlanet(lord)}) · ${placementText(lord)}',
          house(lord)!=null && D24VidyaSourceEngine._kendraTrikona.contains(house(lord))));
      out.add(_check('పూర్తి గ్రహబలం','షడ్బలం, దృష్టి, అవస్థ ఇంకా గణించాలి.',null));
    } else if (const [
      'D24-VIDYA-CORE-02','D24-VIDYA-CORE-03','D24-VIDYA-CORE-04',
    ].contains(id)) {
      final number = id.endsWith('02')?4:id.endsWith('03')?5:9;
      final lord=houseLord(number);
      out.add(_check('D24 $numberవ భావాధిపతి స్వస్థితి/ఉచ్చ సూచన',
          '$numberవ అధిపతి: ${placementText(lord)}. ఇది పూర్తి బలం కాదు.',
          strongByOwnOrExalt(lord)));
      out.add(_check('భావం, దృష్టులు, సంపూర్ణ బలం',
          'భావబలం/శుభపాప దృష్టులు, ఇతర బలాలు ఇంకా పరిశీలించాలి.',null));
    } else if (id=='D24-VIDYA-CORE-05' || id=='D24-VIDYA-EXAM-06') {
      for (final number in [4,5]) {
        final lord=houseLord(number,d1:id=='D24-VIDYA-CORE-05');
        final h=house(lord);
        final malefic=D24VidyaSourceEngine._malefics.any((x)=>x!=lord && sameSign(x,lord));
        out.add(_check('${id.contains('CORE')?'D1':'D24'} $numberవ అధిపతి 6/8/12లో',
            '${placementText(lord)}',h==null?null:const [6,8,12].contains(h)));
        out.add(_check('$numberవ అధిపతితో పాపగ్రహ కలయిక',
            '${D24VidyaSourceEngine.teluguPlanet(lord)} ఉన్న రాశిలో కుజ/శని/రాహు/కేతువుల కలయిక: ${malefic?'ఉంది':'కనిపించలేదు'}',
            h==null?null:malefic));
      }
      out.add(_check('దృష్టి/అస్తంగతం/నీచం సమగ్ర పరిశీలన',
          'ఈ నియమంలోని మిగిలిన బలహీనతలు, శుభదృష్టి/అస్తంగత వివరాలకు పూర్తి పరీక్ష అవసరం.',null));
    } else if (id=='D24-VIDYA-CORE-06') {
      for (final planet in ['Jupiter','Mercury']) {
        final name=D24VidyaSourceEngine.teluguPlanet(planet);
        out.add(_check('$name — స్వరాశి/ఉచ్చ స్థితి',
            '${placementText(planet)}. స్వరాశి/ఉచ్చం ఒక్కటే సంపూర్ణ గ్రహబలం కాదు.',
            placements.containsKey(planet)?strongByOwnOrExalt(planet):null));
      }
      out.add(_check('శుభ అంశదేవత వర్గీకరణ',
          'మూలపత్రంలో 12 దేవతల్లో ఏవి శుభ దేవతాంశాలనేది స్థిరపరచలేదు. గురు, బుధుల అంశదేవతలు పైన చూపించాం.',null));
      out.add(_check('గ్రహబలం/దృష్టి పూర్తి పరీక్ష',
          'ఉచ్చ/స్వరాశితో పాటు పూర్తి బలం, శుభదృష్టులు ఇంకా పరీక్షించాలి.',null));
    } else if (id=='D24-VIDYA-EXAM-01') {
      for (final factor in [1,24]) {
        final lord = factor==1 ? houseLord(6,d1:true):houseLord(6);
        out.add(_check('D$factor 6వ అధిపతికి 3/6/10/11 సంబంధం',
            '${placementText(lord)} (D24 స్థానం ఆధారమే); D$factor భావబలం విడిగా అవసరం.',
            factor==24 && house(lord)!=null ? const [3,6,10,11].contains(house(lord)) : null));
      }
    } else if (id=='D24-VIDYA-EXAM-02') {
      final lord=houseLord(3);
      out.add(_check('D24 3వ భావాధిపతి స్థితి',
          '${placementText(lord)} · స్వరాశి/ఉచ్చ సూచన',strongByOwnOrExalt(lord)));
      for (final p in ['Mars','Saturn']) {
        out.add(_check('${D24VidyaSourceEngine.teluguPlanet(p)} D24 స్వరాశి/ఉచ్చ సూచన',
            placementText(p),strongByOwnOrExalt(p)));
      }
      out.add(_check('3వ భావ సంపూర్ణ బలం','భావబలం, దృష్టి ఇంకా పరిశీలించాలి.',null));
    } else if (id=='D24-VIDYA-EXAM-03') {
      final lord11=houseLord(11);
      for (final number in [4,5,9]) {
        final l=houseLord(number);
        out.add(_check('11వ–$numberవ అధిపతుల సంబంధం',
            relationshipText(lord11,l),relationship(lord11,l)));
      }
    } else if (id=='D24-VIDYA-EXAM-04') {
      final l5=houseLord(5),l9=houseLord(9);
      for(final name in [l5,l9]) {
        out.add(_check('${D24VidyaSourceEngine.teluguPlanet(name)} కేంద్ర/త్రికోణం',
            placementText(name),D24VidyaSourceEngine._kendraTrikona.contains(house(name))));
      }
      out.add(_check('5వ–9వ అధిపతి ఒకే రాశిలో',
          relationshipText(l5,l9),sameSign(l5,l9)));
    } else if (id=='D24-VIDYA-EXAM-05') {
      final lord=houseLord(1);
      out.add(_check('D1/D24 లగ్నం ఒకే రాశి',
          'D1: ${D24VidyaSourceEngine.signNames[chart.ascendantSignIndex]}, D24: ${D24VidyaSourceEngine.signNames[d24.ascendantSignIndex]}',
          chart.ascendantSignIndex==d24.ascendantSignIndex));
      out.add(_check('D24 లగ్నాధిపతి ఉచ్చ స్థితి',placementText(lord),
          D24VidyaSourceEngine._exaltation[lord]==placements[lord]?.signIndex));
    }
  }

  D24VidyaRuleAudit analyze(D24VidyaSourceRule rule) {
    final checks=<D24VidyaConditionCheck>[];
    _baseSpecial(rule,checks);
    final present=rule.planets.where(placements.containsKey).toList();

    if (rule.planets.isNotEmpty) {
      // Planetary availability isn't counted as an astrological match: every
      // natal chart contains Mercury/Rahu and many such rules use '+' broadly.
      final missing=rule.planets.where((p)=>!placements.containsKey(p)).toList();
      if (missing.isNotEmpty) {
        checks.add(_check('కారక గ్రహ డేటా',
            '${missing.map(D24VidyaSourceEngine.teluguPlanet).join(', ')} స్థానం లభించలేదు.',false));
      }
      if (rule.planets.length>=2) {
        final found=<String>[];
        for (var i=0;i<present.length;i++) {
          for (var j=i+1;j<present.length;j++) {
            if (relationship(present[i],present[j])) {
              found.add(relationshipText(present[i],present[j]));
            }
          }
        }
        checks.add(_check('కారక గ్రహాల D24 కలయిక/పరాశరీ గ్రహదృష్టి',
            found.isNotEmpty ? found.join('; ') :
                '${present.map(D24VidyaSourceEngine.teluguPlanet).join(', ')} మధ్య ప్రత్యక్ష కలయిక/పరీక్షించిన దృష్టి కనిపించలేదు. రాహు–కేతు ఇతర దృష్టి విధానాలు చేర్చలేదు.',
            present.length!=rule.planets.length?null:found.isNotEmpty));
        checks.add(_check('ఇతర గ్రహ సంబంధం/బలం',
            'మూలంలోని + సంకేతం కేవలం యుతి మాత్రమే అని గ్రంథం చెప్పలేదు. ఇతర సంబంధాలు, గ్రహబలం ఇంకా పరిశీలించాలి.',null));
      }
    }

    bool deityEvidence=false;
    if (rule.devatas.isNotEmpty) {
      final linked=present.where((p)=>rule.devatas.contains(devatas[p]?.name)).toList();
      deityEvidence=linked.isNotEmpty;
      checks.add(_check('కారక గ్రహానికి నిర్దేశించిన అంశదేవత',
          linked.isEmpty ?
            'కావలసిన దేవతలు: ${rule.devatas.join(' / ')}. '
            'గ్రహాల అంశదేవతలు: ${present.map((p)=>'${D24VidyaSourceEngine.teluguPlanet(p)}–${devatas[p]?.name ?? '-'}').join(', ')}.' :
            'సరిపోయినవి: ${linked.map((p)=>'${D24VidyaSourceEngine.teluguPlanet(p)}–${devatas[p]?.name}').join(', ')}.',
          present.isEmpty?null:deityEvidence));
    }

    bool houseEvidence=false;
    if (rule.houses.isNotEmpty) {
      final links=<String>[];
      for (final number in rule.houses) {
        final lord=houseLord(number);
        for (final p in present) {
          if (house(p)==number || p==lord) {
            links.add('${D24VidyaSourceEngine.teluguPlanet(p)} → $numberవ భావం/అధిపతి');
          }
        }
      }
      houseEvidence=links.isNotEmpty;
      checks.add(_check('D24 భావ సంబంధం (ప్రత్యక్ష)',
          links.isEmpty ? 'మూల భావాలు: ${rule.houses.join(', ')}. ప్రత్యక్ష భావ ఆక్రమణ/అధిపత్యం కనిపించలేదు; దృష్టులు, ఇతర సంబంధాలు మిగిలి ఉన్నాయి.' :
          links.join('; '),present.isEmpty?null:houseEvidence));
      checks.add(_check('భావబలం/ఇతర దృష్టులు',
          'భావ సంబంధం ఒక్కటే బలం కాదు; షడ్బలం, శుభ–పాప దృష్టులు, అవస్థ ఇంకా పరిశీలించాలి.',null));
    }

    if (rule.category=='TIMING') {
      checks.add(_check('పరీక్ష తేదీ + దశ–అంతర్దశ + గోచారం',
          'ఈ స్క్రీన్‌కు పరీక్ష/ప్రవేశ తేదీ ఇవ్వలేదు. కాలనియమాన్ని జనన చక్రంతో మాత్రమే Confirm చేయలేం.',null));
    }
    if (rule.category=='ADMISSION') {
      checks.add(_check('వాస్తవ పరీక్ష/అర్హత/ర్యాంక్',
          'సీటు, స్కాలర్‌షిప్‌కు నిజమైన పరీక్ష ర్యాంక్, అర్హత, కౌన్సెలింగ్, సీట్లు అవసరం.',null));
    }
    if (checks.isEmpty) {
      checks.add(_check('మూల నియమం కోసం అవసరమైన పూర్తి గణన',
          'నియమంలోని షరతులకు ఉపయోగపడే పూర్తి గ్రహబలం, దృష్టులు, కాలపరిశీలన ఇంకా అనుసంధానం కాలేదు.',null));
    }

    final description=<String>[
      'D1 లగ్నం: ${D24VidyaSourceEngine.signNames[chart.ascendantSignIndex]} · '
      'D24 లగ్నం: ${D24VidyaSourceEngine.signNames[d24.ascendantSignIndex]}',
      if (rule.planets.isNotEmpty) ...rule.planets.map(placementText),
      'మూల IF: ${rule.condition}',
      'మూల THEN: ${rule.result}',
      'నియమాల పరిశీలన:\n${checks.map((c)=>'${c.marker} ${c.title}: ${c.stateText} — ${c.detail}').join('\n')}',
      'మూలం: ${D24VidyaSourceRegistry.sourceName} · పేజీ ${rule.sourcePage}.',
      'గమనిక: ప్రత్యక్ష ఆధారం కనిపించినంత మాత్రాన పూర్తి నియమం లేదా విద్యాసంస్థ ప్రవేశం నిర్ధారణ కాదు.',
    ];
    return D24VidyaRuleAudit(
      source:rule,
      devataSupport:deityEvidence,
      relevantHouseSupport:houseEvidence,
      planetRelationSupport:checks.any((c)=>
        c.title=='కారక గ్రహాల D24 కలయిక/పరాశరీ గ్రహదృష్టి' &&
        c.status==D24CheckStatus.matched),
      checks:List.unmodifiable(checks),
      explanation:description.join('\n\n'),
    );
  }
}
