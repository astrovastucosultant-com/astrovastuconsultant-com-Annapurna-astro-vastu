import 'dart:convert';

import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'varga_service.dart';

/// Status reflects rule-condition verification, not certainty of an event.
enum UnifiedVargaRuleStatus { matched, notMatched, pending, method }

class UnifiedVargaRule {
  final String id;
  final String group;
  final String groupTitle;
  final String topic;
  final String condition;
  final String outcome;
  final String source;
  final String evidence;
  final UnifiedVargaRuleStatus status;

  const UnifiedVargaRule({
    required this.id,
    required this.group,
    required this.groupTitle,
    required this.topic,
    required this.condition,
    required this.outcome,
    required this.source,
    required this.evidence,
    required this.status,
  });
}

/// User-provided 42-page varga IF–THEN catalog (247 source rules + 8 strength
/// rules). Only reproducible conditions are marked matched. Qualitative,
/// incomplete and cross-chart rules remain pending/method, without fake green.
class VargaUnifiedRuleService {
  static const asset = 'assets/varga/mallikarjuna_255_rules.json';
  static const _benefics = <String>{'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = <String>{'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};
  static const _lords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];
  static const _exaltSigns = <String, int>{
    'Sun': 0, 'Moon': 1, 'Mars': 9, 'Mercury': 5,
    'Jupiter': 3, 'Venus': 11, 'Saturn': 6,
  };
  static const _names = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  static Future<List<UnifiedVargaRule>> evaluate(AstroChartResult chart) async {
    final data = jsonDecode(await rootBundle.loadString(asset))
        as Map<String, dynamic>;
    final rawRules = data['rules'] as List<dynamic>;
    final charts = <int, VargaChartData>{};
    for (final def in VargaService.definitions) {
      charts[def.factor] = VargaService.calculate(chart, def.factor);
    }
    final output = <UnifiedVargaRule>[];
    for (final item in rawRules) {
      final row = item as Map<String, dynamic>;
      final id = row['id'] as String;
      final group = row['group'] as String;
      final mode = row['mode'] as String? ?? '';
      final sourceInfo = row['source'] as Map<String, dynamic>?;
      final pages = (sourceInfo?['pages'] as List<dynamic>?)
              ?.map((p) => p.toString()).join(', ') ?? '—';
      final check = _verify(id, charts, chart);
      final status = (group == 'STRENGTH' ||
              (mode == 'workflow' && check.$1 == null))
          ? UnifiedVargaRuleStatus.method
          : check.$1 == true
              ? UnifiedVargaRuleStatus.matched
              : check.$1 == false
                  ? UnifiedVargaRuleStatus.notMatched
                  : UnifiedVargaRuleStatus.pending;
      output.add(UnifiedVargaRule(
        id: id,
        group: group,
        groupTitle: (row['group_title'] as String?) ?? group,
        topic: (row['topic'] as String?) ?? group,
        condition: _stripPrefix((row['IF'] as String?) ?? '', 'IF'),
        outcome: _stripPrefix((row['THEN'] as String?) ?? '', 'THEN'),
        source: '$pages · Mallikarjuna PDF',
        evidence: check.$2,
        status: status,
      ));
    }
    return output;
  }

  static String _stripPrefix(String value, String prefix) =>
      value.replaceFirst(RegExp('^$prefix\\s*:?\\s*'), '').trim();

  static bool _isSupport(Map<int, VargaChartData> charts, int factor) =>
      charts.containsKey(factor);

  /// Returns (condition verified yes/no/unknown, chart evidence).
  /// Unknown is deliberately NOT equivalent to false.
  static (bool?, String) _verify(
    String id,
    Map<int, VargaChartData> charts,
    AstroChartResult natal,
  ) {
    if (id == 'VARGA-STRENGTH-001') {
      final planetCount = natal.planets
          .where((p) => p.longitude.isFinite && p.degreesInSign >= 0 && p.degreesInSign < 30)
          .length;
      if (planetCount == 0) return (null, 'జన్మగ్రహ డిగ్రీలు అందుబాటులో లేవు.');
      return (true,
          'గ్రహాల రాశి-అంతర్గత డిగ్రీలు లభించాయి: $planetCount. '
          'కస్టమ్ సూచిక = (30 − రాశిలోని డిగ్రీ) / 30 × 100. '
          'ఇది సాపేక్ష పోలిక మాత్రమే; సంఘటన సంభావ్యత కాదు.');
    }
    if (id == 'VARGA-STRENGTH-002') {
      if (natal.planets.length < 2) return (null, 'రెండు గ్రహాల డిగ్రీలు కావాలి.');
      final ordered = [...natal.planets]..sort((a, b) =>
          a.degreesInSign.compareTo(b.degreesInSign));
      return (true,
          'తక్కువ డిగ్రీ: ${ordered.first.name} ${ordered.first.degreesInSign.toStringAsFixed(2)}°; '
          'ఎక్కువ డిగ్రీ: ${ordered.last.name} ${ordered.last.degreesInSign.toStringAsFixed(2)}°. '
          'ఇది వినియోగదారు నిర్దేశించిన డిగ్రీ-బల పోలిక మాత్రమే.');
    }

    final pieces = id.split('-');
    if (pieces.length < 3) return (null, 'మూల నియమం ఉంది; ఆటోమేటిక్ పరీక్ష నిర్వచించలేదు.');
    final factor = int.tryParse(pieces[1].replaceFirst('D', ''));
    if (factor == null) {
      return (null,
          'ఈ నియమం బహువర్గ/దశ/గోచార/షడ్వర్గ సమగ్ర పరిశీలన. '
          'అన్ని IF ఉపషరతులకు స్వతంత్ర గణనలు అందుబాటులో లేవు.');
    }
    if (!_isSupport(charts, factor)) {
      return (null,
          'D$factor గణన ప్రస్తుత VargaServiceలో లేదు. '
          'నియమం PDFలో భద్రపరచబడింది; చార్ట్‌ను ఊహించి గ్రీన్ చూపడం లేదు.');
    }
    final chart = charts[factor]!;
    final asc = chart.ascendantSignIndex;
    final placements = <String, int>{for (final p in chart.planets) p.name: p.signIndex};
    int? at(String name) => placements[name];
    int house(int sign) => (sign - asc + 12) % 12 + 1;
    int? houseOf(String name) {
      final sign = at(name);
      return sign == null ? null : house(sign);
    }
    String signName(int sign) => _names[sign % 12];
    String houseText(String name) {
      final s = at(name);
      return s == null ? '$name స్థానం లేదు' : '$name ${signName(s)} (${house(s)}వ భావం)';
    }
    int signOfHouse(int n) => (asc + n - 1) % 12;
    String lord(int h) => _lords[signOfHouse(h)];
    int? lordHouse(int h) => houseOf(lord(h));
    bool occupant(String name, int h) => houseOf(name) == h;
    bool hasAny(int h, Set<String> names) =>
        names.any((name) => occupant(name, h));
    bool sameSign(String p, String q) =>
        at(p) != null && at(p) == at(q);
    bool kendraTrikona(int? h) => h != null &&
        const <int>{1, 4, 5, 7, 9, 10}.contains(h);
    bool dusthana(int? h) => h != null &&
        const <int>{6, 8, 12}.contains(h);
    bool grahaAspects(String p, int? targetSign) {
      if (targetSign == null) return false;
      final s = at(p);
      // The classical Parashari planet-specific graha-drishthi option. This
      // is not a Jaimini sign aspect; unspecified node aspects remain unknown.
      if (s == null || p == 'Rahu' || p == 'Ketu') return false;
      final offset = (targetSign - s + 12) % 12 + 1;
      if (offset == 7) return true;
      if (p == 'Mars' && (offset == 4 || offset == 8)) return true;
      if (p == 'Jupiter' && (offset == 5 || offset == 9)) return true;
      if (p == 'Saturn' && (offset == 3 || offset == 10)) return true;
      return false;
    }
    bool relation(String p, String q) =>
        sameSign(p, q) || grahaAspects(p, at(q)) || grahaAspects(q, at(p));
    bool receivesFrom(String target, Set<String> senders) =>
        at(target) != null && senders.any((p) => grahaAspects(p, at(target)));
    (bool?, String) checked(bool predicate, String evidence) => (predicate, evidence);
    (bool?, String) possible(bool predicate, String evidence) => predicate
        ? (true, evidence)
        : (null, '$evidence ఇతర ప్రత్యామ్నాయ సంబంధాలు/బల పరీక్షలు ఇంకా పూర్తికాలేదు.');

    switch (id) {
      case 'VARGA-D2-001':
        return checked(asc == 4, 'D2 లగ్నం: ${signName(asc)}. సూర్యహోర సింహం.');
      case 'VARGA-D2-002':
        return checked(asc == 3, 'D2 లగ్నం: ${signName(asc)}. చంద్రహోర కర్కాటకం.');
      case 'VARGA-D2-003':
        return checked(placements.entries.any((p) => p.value == 4 && _benefics.contains(p.key)),
            'సూర్యహోరలో శుభగ్రహాలు: ${placements.entries.where((p) => p.value == 4 && _benefics.contains(p.key)).map((p) => p.key).join(', ')}.');
      case 'VARGA-D2-004':
        return checked(kendraTrikona(lordHouse(2)) && kendraTrikona(lordHouse(11)),
            'D2 2వ అధిపతి ${lord(2)}: ${lordHouse(2)}వ భావం; 11వ అధిపతి ${lord(11)}: ${lordHouse(11)}వ భావం.');
      case 'VARGA-D2-005':
        return checked(hasAny(2, _malefics) || hasAny(11, _malefics),
            'D2 2/11 భావాల్లో పాపగ్రహాలు: ${placements.entries.where((e) => _malefics.contains(e.key) && (house(e.value) == 2 || house(e.value) == 11)).map((e) => e.key).join(', ')}.');
      case 'VARGA-D2-006':
        return checked(dusthana(lordHouse(2)) || dusthana(lordHouse(11)),
            'D2 2వ అధిపతి ${lord(2)}: ${lordHouse(2)}వ భావం; 11వ అధిపతి ${lord(11)}: ${lordHouse(11)}వ భావం.');
      case 'VARGA-D3-003':
        return checked(receivesFrom(lord(3), _benefics),
            'D3 3వ అధిపతి ${lord(3)}: ${lordHouse(3)}వ భావం. శుభగ్రహ దృష్టి (పరాశరి).');
      case 'VARGA-D7-004':
        return checked(receivesFrom('Jupiter', _benefics.difference({'Jupiter'})),
            'D7 ${houseText('Jupiter')}; గురువుపై శుభగ్రహ దృష్టి (పరాశరి).');
      case 'VARGA-D7-005':
        return possible(receivesFrom('Jupiter', _malefics),
            'D7 ${houseText('Jupiter')}; పాపగ్రహ దృష్టి (రాహు/కేతు ప్రత్యేక దృష్టి ధృవీకరించలేదు).');
      case 'VARGA-D7-007':
        return possible(occupant(lord(5), 12) || relation(lord(5), lord(12)),
            'D7 5వ అధిపతి ${lord(5)} (${lordHouse(5)}వ భావం); 12వ అధిపతి ${lord(12)}.');
      case 'VARGA-D9-001':
        return checked(const <int>{5, 7, 11}.contains(houseOf('Venus')) &&
            placements.keys.any((p) => p != 'Venus' && sameSign('Venus', p)),
            'D9 ${houseText('Venus')}; శుక్ర యుతి: ${placements.keys.where((p) => p != 'Venus' && sameSign('Venus', p)).join(', ')}.');
      case 'VARGA-D9-002':
        return possible(relation(lord(7), 'Sun') || relation(lord(7), 'Moon'),
            'D9 7వ అధిపతి ${lord(7)} (${lordHouse(7)}వ భావం); ${houseText('Sun')}; ${houseText('Moon')}.');
      case 'VARGA-D9-004':
        return possible(occupant(lord(7), 12) || occupant('Venus', 12) ||
            relation(lord(7), 'Rahu') || relation('Venus', 'Rahu'),
            'D9 7వ అధిపతి ${lord(7)} (${lordHouse(7)}వ భావం); ${houseText('Venus')}; ${houseText('Rahu')}.');
      case 'VARGA-D10-001':
        return possible(relation(lord(10), 'Mercury'),
            'D10 10వ అధిపతి ${lord(10)} (${lordHouse(10)}వ భావం); ${houseText('Mercury')}.');
      case 'VARGA-D10-002':
        return possible(relation(lord(10), 'Mars'),
            'D10 10వ అధిపతి ${lord(10)} (${lordHouse(10)}వ భావం); ${houseText('Mars')}.');
      case 'VARGA-D10-006':
        return checked(kendraTrikona(lordHouse(10)) &&
            _exaltSigns[lord(10)] == at(lord(10)),
            'D10 10వ అధిపతి ${lord(10)}: ${lordHouse(10)}వ భావం, రాశి ${at(lord(10)) == null ? '—' : signName(at(lord(10))!)}; ఉచ్చ రాశి పరీక్ష.');
      case 'VARGA-D12-005':
        return checked(receivesFrom('Sun', _benefics) || receivesFrom('Moon', _benefics),
            'D12 ${houseText('Sun')}; ${houseText('Moon')}; శుభగ్రహ దృష్టి పరీక్ష.');
      case 'VARGA-D12-006':
        return possible(hasAny(4, _benefics) || _benefics.any((p) => relation(lord(4), p)),
            'D12 4వ భావాధిపతి ${lord(4)}; 4వ భావం & శుభగ్రహ యుతి/సంబంధం.');
      case 'VARGA-D12-007':
        return possible(hasAny(9, _benefics) || _benefics.any((p) => relation(lord(9), p)),
            'D12 9వ భావాధిపతి ${lord(9)}; 9వ భావం & శుభగ్రహ యుతి/సంబంధం.');
      case 'VARGA-D12-008':
        return possible(hasAny(4, _malefics) || hasAny(9, _malefics) ||
            _malefics.any((p) => relation(lord(4), p) || relation(lord(9), p)),
            'D12 4/9 భావాలు, వాటి అధిపతులపై పాప ప్రభావం పరిశీలన.');
      case 'VARGA-D12-012':
        return possible(receivesFrom('Sun', {'Saturn'}) || receivesFrom('Moon', {'Saturn'}) ||
            sameSign('Sun', 'Rahu') || sameSign('Moon', 'Rahu'),
            'D12 రవి, చంద్రులకు శని దృష్టి/రాహు యుతి పరీక్ష; రాహు ప్రత్యేక దృష్టి ఇంకా పెండింగ్.');
      case 'VARGA-D16-005':
        final fourth = placements.entries.where((p) => house(p.value) == 4).map((p) => p.key).toSet();
        return checked(fourth.any((p) => p == 'Mars' || p == 'Rahu') &&
            fourth.intersection(_malefics).length >= 2,
            'D16 నాలుగో భావంలోని గ్రహాలు: ${fourth.join(', ')}; పాపగ్రహ యుతి అవసరం.');
      case 'VARGA-D20-003':
        return possible(occupant('Ketu', 1) || occupant('Ketu', 12),
            'D20 ${houseText('Ketu')}. ఇతర కేతు దృష్టి/ప్రభావాలు పూర్తి కావాలి.');
      case 'VARGA-D24-002':
        return possible(occupant(lord(4), 12) || occupant(lord(9), 12) ||
            relation(lord(4), 'Rahu') || relation(lord(9), 'Rahu'),
            'D24 4వ అధిపతి ${lord(4)} ${lordHouse(4)}వ భావం; 9వ అధిపతి ${lord(9)} ${lordHouse(9)}వ భావం.');
      case 'VARGA-D27-002':
        return checked(occupant('Jupiter', 1) && occupant('Mars', 1),
            'D27 ${houseText('Jupiter')}; ${houseText('Mars')}.');
      case 'VARGA-D30-003':
        return possible(sameSign('Saturn', 'Rahu') &&
            (occupant('Saturn', 6) || grahaAspects('Saturn', signOfHouse(6))),
            'D30 శని–రాహు యుతి, 6వ భావ సంబంధం పరిశీలన.');
      case 'VARGA-D45-002':
        return possible(occupant('Jupiter', 1) || grahaAspects('Jupiter', asc),
            'D45 ${houseText('Jupiter')}; లగ్నానికి గురు దృష్టి/యుతి.');
      default:
        return (null, 'మూల IF–THEN భద్రంగా ఉంది; పూర్తి గ్రహబలం, షడ్వర్గ, '
            'దశ/గోచార లేదా ఇతర ఉపషరతుల గణన ఇంకా అమలు చేయాలి.');
    }
  }
}
