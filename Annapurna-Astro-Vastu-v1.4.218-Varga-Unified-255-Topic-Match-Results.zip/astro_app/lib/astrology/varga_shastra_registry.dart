import 'varga_service.dart';

/// Citations for the *computational construction* of the sixteen vargas.
/// These are NOT claims that existing predictive rules, scores and remedies
/// have been checked against the same chapter. Commentary and user-supplied
/// inference must be identified separately from scripture.
class VargaShastraEntry {
  final int factor;
  final String verse;
  final String construction;
  final String reviewNote;

  const VargaShastraEntry({
    required this.factor,
    required this.verse,
    required this.construction,
    this.reviewNote = 'ఫలిత నియమాలు, శాతాలు, పరిహారాలకు వేర్వేరు మూల పరిశీలన అవసరం.',
  });
}

class VargaShastraRegistry {
  static const book = 'బృహత్ పరాశర హోరాశాస్త్రం — 6వ అధ్యాయం (షోడశవర్గాధ్యాయం)';
  static const chapterUrl =
      'https://divyachadhava.com/en/sanatan-sahitya/bphs-chapter-6-the-sixteen-divisions-of-a-r-i';

  static const entries = <VargaShastraEntry>[
    VargaShastraEntry(factor: 1, verse: '2–6', construction: 'రాశి: జనన రాశి, నిరయణ గ్రహస్థానాల ఆధారం.'),
    VargaShastraEntry(factor: 2, verse: '5–6', construction: 'హోరా: ఒక్కో రాశి రెండు 15° భాగాలు; బేసి/సరి క్రమం.'),
    VargaShastraEntry(factor: 3, verse: '7–8', construction: 'పరాశరీ D3: మూడు 10° భాగాలు; వరుసగా 1, 5, 9 రాశులు.',
      reviewNote: 'పరాశరీ D3ను D3-Jగా మార్చవద్దు. జగన్నాథ D3-J కర్మఫల వ్యాఖ్యానం ప్రత్యేక మూలంతో దిగువన ఉంది.'),
    VargaShastraEntry(factor: 4, verse: '9', construction: 'చతుర్థాంశ: 7°30′ భాగాలు; 1, 4, 7, 10 క్రమం.'),
    VargaShastraEntry(factor: 7, verse: '10–11', construction: 'సప్తాంశ: 30°/7; బేసి రాశిలో స్వరాశి, సరిలో 7వ రాశి నుంచి.'),
    VargaShastraEntry(factor: 9, verse: '12', construction: 'నవాంశ: చర/స్థిర/ద్విస్వభావ రాశులకు 1/9/5 ప్రారంభాలు.'),
    VargaShastraEntry(factor: 10, verse: '13–14', construction: 'దశాంశ: ప్రతి 3° ఒక అంశం; బేసి/సరి రాశుల దేవత క్రమం వేరు.'),
    VargaShastraEntry(factor: 12, verse: '15', construction: 'ద్వాదశాంశ: 2°30′ భాగాలు, స్వరాశి నుంచి.'),
    VargaShastraEntry(factor: 16, verse: '16', construction: 'షోడశాంశ: చర/స్థిర/ద్విస్వభావ రాశులకు మేష/సింహ/ధనుస్సు మొదలు.',
      reviewNote: 'వేరే D16 calculation option ఎంచుకుంటే దానికి ఈ పరాశరీ శ్లోకాన్ని నేరుగా ప్రమాణంగా చూపకూడదు.'),
    VargaShastraEntry(factor: 20, verse: '17–21', construction: 'వింశాంశ: చర/స్థిర/ద్విస్వభావ రాశులకు మేష/ధనుస్సు/సింహం మొదలు.'),
    VargaShastraEntry(factor: 24, verse: '22–23', construction: 'చతుర్వింశాంశ: బేసి రాశులకు సింహం, సరి రాశులకు కర్కాటకం మొదలు.'),
    VargaShastraEntry(factor: 27, verse: '24–26', construction: 'భాంశ: 27 భాగాలు, నక్షత్రాంశ దేవతల క్రమం.'),
    VargaShastraEntry(factor: 30, verse: '27–28', construction: 'త్రింశాంశ: సమానం కాని విభాగాలు; బేసి/సరి రాశుల అధిపతులు వేరు.'),
    VargaShastraEntry(factor: 40, verse: '29–30', construction: 'ఖవేదాంశ: 40 భాగాలు; మేషం/తుల నుంచి గణన.'),
    VargaShastraEntry(factor: 45, verse: '31–32', construction: 'అక్షవేదాంశ: 45 భాగాలు; చర/స్థిర/ద్విస్వభావ ప్రారంభాలు వేరు.'),
    VargaShastraEntry(factor: 60, verse: '33–41', construction: 'షష్ట్యాంశ: ఒక్కో భాగం 0°30′; దేవతల పేర్లు బేసి/సరిలో వ్యతిరేక క్రమంలో.',
      reviewNote: 'D60 అంశరాశి గణన, దేవత క్రమం, జనన సమయ సున్నితత్వం విడిగా ఆడిట్ చేయాలి. ఖచ్చిత కర్మఫల తీర్పు ఆటోగా ఇవ్వవద్దు.'),
  ];

  static VargaShastraEntry forFactor(int factor) =>
      entries.firstWhere((entry) => entry.factor == factor);

  static bool get coversAllVargas => VargaService.definitions.every(
      (definition) => entries.any((entry) => entry.factor == definition.factor));
}
