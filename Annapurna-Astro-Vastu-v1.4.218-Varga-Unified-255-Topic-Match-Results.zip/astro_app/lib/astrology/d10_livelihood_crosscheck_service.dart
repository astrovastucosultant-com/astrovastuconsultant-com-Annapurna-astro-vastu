import 'astro_models.dart';
import 'd10_career_service.dart';
import 'd10_vrutti_rule_registry.dart';
import 'varga_service.dart';

/// Chapter 5.1 of Phaladeepika / Brihat Jataka chapter 10:
/// Examine the lord of the navamsha occupied by the 10th lord reckoned
/// separately from Lagna, Moon and Sun, preferring the strongest reference.
///
/// IMPORTANT: The existing chart does not contain complete reference strength
/// (Bhava Bala, Shadbala etc.). Thus no "strongest" source is fabricated.
/// All three candidate channels are reported independently, unweighted.
/// Their sector descriptions are traditional livelihood *families*, NOT a
/// specific job, a modern credential, or a statistically validated prediction.
class D10LivelihoodChannel {
  final String reference;
  final String referencePlanet;
  final int referenceSign;
  final int tenthSign;
  final String natalTenthLord;
  final int natalTenthLordHouse;
  final int navamsaSign;
  final String navamsaLord;
  final int navamsaTenthLordHouse;
  final int dashamsaTenthLordHouse;
  final bool dashamsaCareerAxisLinked;
  final String livelihoodFields;

  const D10LivelihoodChannel({
    required this.reference,
    required this.referencePlanet,
    required this.referenceSign,
    required this.tenthSign,
    required this.natalTenthLord,
    required this.natalTenthLordHouse,
    required this.navamsaSign,
    required this.navamsaLord,
    required this.navamsaTenthLordHouse,
    required this.dashamsaTenthLordHouse,
    required this.dashamsaCareerAxisLinked,
    required this.livelihoodFields,
  });
}

class D10LivelihoodRuleComparison {
  /// A classical D9 livelihood lord appears explicitly among source-rule
  /// planets. This is independent *additional* correspondence, not proof of
  /// the exact occupation; it cannot override a missing D1->D10 confirm.
  final List<String> linkedReferences;
  final List<String> independentReferences;
  final bool eligibleForIndividualVerdict;
  final bool fullD10RuleMatched;

  const D10LivelihoodRuleComparison({
    required this.linkedReferences,
    required this.independentReferences,
    required this.eligibleForIndividualVerdict,
    required this.fullD10RuleMatched,
  });

  bool get hasDirectPlanetCorrespondence => linkedReferences.isNotEmpty;
}

class D10LivelihoodCrossCheck {
  final List<D10LivelihoodChannel> channels;
  final String d10TenthLord;
  final int d10TenthSign;

  const D10LivelihoodCrossCheck({
    required this.channels,
    required this.d10TenthLord,
    required this.d10TenthSign,
  });

  /// Counts repetition of a classical livelihood *ruler*, never the number
  /// of distinct independent birth facts: the three reference channels can
  /// reuse the same tenth lord, and are NOT three independent confirmations.
  List<String> get recurringNavamsaLords {
    final counts = <String, int>{};
    for (final ch in channels) {
      counts[ch.navamsaLord] = (counts[ch.navamsaLord] ?? 0) + 1;
    }
    return List.unmodifiable(counts.keys.where((key) => counts[key]! > 1));
  }

  /// Exact source-planet identity match only. Never treat an entire broad
  /// profession category as verified just because its label sounds similar.
  D10LivelihoodRuleComparison compare({
    required D10VruttiRule rule,
    required bool primaryPlanetConfirmed,
    required bool fullRuleMatched,
  }) {
    final linked = <String>[];
    final independent = <String>[];
    for (final ch in channels) {
      if (rule.planets.contains(ch.navamsaLord)) {
        linked.add(ch.reference);
      } else {
        independent.add(ch.reference);
      }
    }
    return D10LivelihoodRuleComparison(
      linkedReferences: List.unmodifiable(linked),
      independentReferences: List.unmodifiable(independent),
      eligibleForIndividualVerdict: primaryPlanetConfirmed,
      fullD10RuleMatched: fullRuleMatched,
    );
  }
}

class D10LivelihoodCrossCheckService {
  static const teluguPlanet = <String, String>{
    'Sun': 'సూర్యుడు', 'Moon': 'చంద్రుడు', 'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు', 'Jupiter': 'గురువు', 'Venus': 'శుక్రుడు',
    'Saturn': 'శని', 'Rahu': 'రాహువు', 'Ketu': 'కేతువు',
  };
  static const teluguSign = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  /// Classical occupational examples paraphrased from Phaladeepika 5.2-8
  /// and Brihat Jataka 10.2-3. These are not a strict 1-to-1 career catalog.
  static const livelihoodFamilies = <String, String>{
    'Sun': 'పండ్లు/వృక్షాలు, బంగారం/లోహాలు, ఔషధాలు, రాజసేవ',
    'Moon': 'వ్యవసాయం, నీటి ఉత్పత్తులు, పశుపోషణ, వస్త్రాలు',
    'Mars': 'లోహాలు, భూమి, అగ్ని, ఆయుధాలు, సాహస సంబంధ పనులు',
    'Mercury': 'రచన, లెక్కలు, గణితం, అధ్యయనం, కళాత్మక నైపుణ్యాలు',
    'Jupiter': 'శాస్త్రాలు, పురాణాలు, ధర్మబోధ, రాజాశ్రయం, ధనరుణం',
    'Venus': 'వెండి, ఆభరణాలు, సంగీతం, సువాసనలు, పాల ఉత్పత్తులు, కవిత్వం',
    'Saturn': 'శ్రమ, భారాలు మోయడం, కలప, శిల్పం, మూలఫలాల వ్యాపారం',
  };

  static D10LivelihoodCrossCheck evaluate(AstroChartResult chart) {
    final d9 = VargaService.calculate(chart, 9);
    final d10 = VargaService.calculate(chart, 10);
    final d10TenthSign = (d10.ascendantSignIndex + 9) % 12;
    final d10TenthLord = D10CareerService.signLord(d10TenthSign);

    final channelInputs = <(String, String?, int)>[
      ('లగ్నం', null, chart.ascendantSignIndex),
      for (final body in ['Moon', 'Sun'])
        if (chart.planets.any((p) => p.name == body))
          (body == 'Moon' ? 'చంద్రుడు' : 'సూర్యుడు', body,
           chart.planets.firstWhere((p) => p.name == body).signIndex),
    ];

    final channels = <D10LivelihoodChannel>[];
    for (final (reference, referencePlanet, referenceSign) in channelInputs) {
      final tenthSign = (referenceSign + 9) % 12;
      final tenthLord = D10CareerService.signLord(tenthSign);
      if (!chart.planets.any((p) => p.name == tenthLord) ||
          !d9.planets.any((p) => p.name == tenthLord) ||
          !d10.planets.any((p) => p.name == tenthLord)) {
        continue; // Missing ephemeris data must never be invented.
      }
      final d9Placement = d9.planets.firstWhere((p) => p.name == tenthLord);
      final navamsaLord = D10CareerService.signLord(d9Placement.signIndex);
      final d10House = D10CareerService.vargaHouse(d10, tenthLord);
      final careerAxis = d10House == 1 || d10House == 10 ||
          tenthLord == d10TenthLord ||
          (d10.planets.any((p) => p.name == d10TenthLord) &&
              D10CareerService.relatedVarga(d10, tenthLord, d10TenthLord));
      final natalSign = chart.planets.firstWhere((p) => p.name == tenthLord).signIndex;
      final natalHouse = (natalSign - chart.ascendantSignIndex + 12) % 12 + 1;
      channels.add(D10LivelihoodChannel(
        reference: reference,
        referencePlanet: referencePlanet ?? 'Ascendant',
        referenceSign: referenceSign,
        tenthSign: tenthSign,
        natalTenthLord: tenthLord,
        natalTenthLordHouse: natalHouse,
        navamsaSign: d9Placement.signIndex,
        navamsaLord: navamsaLord,
        navamsaTenthLordHouse: D10CareerService.vargaHouse(d9, tenthLord),
        dashamsaTenthLordHouse: d10House,
        dashamsaCareerAxisLinked: careerAxis,
        livelihoodFields: livelihoodFamilies[navamsaLord] ?? 'మూలాధారం అందుబాటులో లేదు',
      ));
    }
    return D10LivelihoodCrossCheck(
      channels: List.unmodifiable(channels),
      d10TenthLord: d10TenthLord,
      d10TenthSign: d10TenthSign,
    );
  }
}
