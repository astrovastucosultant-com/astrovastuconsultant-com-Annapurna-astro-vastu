/// Imported verbatim from the user-provided 9-page D24 education rulebook.
/// A source rule is NOT by itself a confirmed admission or a guaranteed course.
class D24VidyaSourceRule {
  final String id;
  final String category;
  final String topic;
  final String condition;
  final String result;
  final String sourcePage;
  final List<String> planets;
  final List<String> devatas;
  final List<int> houses;
  const D24VidyaSourceRule({required this.id, required this.category, required this.topic, required this.condition, required this.result, required this.sourcePage, this.planets = const [], this.devatas = const [], this.houses = const []});
}
class D24VidyaCatalogRow {
  final String section;
  final String title;
  final String details;
  final String sourcePage;
  const D24VidyaCatalogRow(this.section, this.title, this.details, this.sourcePage);
}
class D24VidyaSourceRegistry {
  static const sourceName = 'విద్యా జ్యోతిష నియమాలు – D24.docx';
  static const oddDevatas = <String>['స్కంద','పరశుధర','అనల','విశ్వకర్మ','భగ','మిత్ర','మయ','అంతక','వృషధ్వజ','గోవింద','మదన','భీమ'];
  static const rules = <D24VidyaSourceRule>[
    D24VidyaSourceRule(id: "D24-VIDYA-CORE-01", category: "CORE", topic: "D24 లగ్నం", condition: "D24 లగ్నాధిపతి కేంద్ర/కోణంలో బలంగా ఉంటే", result: "విద్యలో స్థిరత్వం, పూర్తి చేసే సామర్థ్యం", sourcePage: "4", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-CORE-02", category: "CORE", topic: "4వ భావం", condition: "D24 4వ భావం/అధిపతి బలంగా ఉంటే", result: "ప్రాథమిక, పాఠశాల విద్య బాగుంటుంది", sourcePage: "4", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-CORE-03", category: "CORE", topic: "5వ భావం", condition: "D24 5వ భావం బలంగా ఉంటే", result: "బుద్ధి, డిగ్రీ స్థాయి విద్య బాగుంటుంది", sourcePage: "4", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-CORE-04", category: "CORE", topic: "9వ భావం", condition: "D24 9వ భావం/అధిపతి బలంగా ఉంటే", result: "పీజీ, పరిశోధన, గురుకృప", sourcePage: "4", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-CORE-05", category: "CORE", topic: "ఆటంకం", condition: "D1 4వ/5వ అధిపతి D24లో 6/8/12లో పాపులతో ఉంటే", result: "విద్యలో ఆటంకం, మార్పు లేదా విరామం", sourcePage: "4", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-CORE-06", category: "CORE", topic: "శుభ కారకులు", condition: "D24లో గురు/బుధులు బలంగా, శుభ దేవతాంశలో ఉంటే", result: "ఉన్నత విద్యా యోగం", sourcePage: "4", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-01", category: "FIELD", topic: "కామర్స్", condition: "బుధుడు + 5వ భావ సంబంధం + మిత్ర/భగ అంశ", result: "కామర్స్, CA, అకౌంట్స్, బ్యాంకింగ్", sourcePage: "5", planets: <String>["Mercury"], devatas: <String>["మిత్ర","భగ"], houses: <int>[5]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-02", category: "FIELD", topic: "కంప్యూటర్ / IT", condition: "బుధుడు + రాహువు + విశ్వకర్మ/మయ అంశ", result: "కంప్యూటర్ సైన్స్, IT, AI, సాఫ్ట్‌వేర్", sourcePage: "5", planets: <String>["Mercury","Rahu"], devatas: <String>["విశ్వకర్మ","మయ"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-03", category: "FIELD", topic: "సివిల్/మెకానికల్", condition: "కుజుడు + శని + విశ్వకర్మ అంశ", result: "సివిల్/మెకానికల్ ఇంజనీరింగ్, ఆర్కిటెక్చర్", sourcePage: "5", planets: <String>["Mars","Saturn"], devatas: <String>["విశ్వకర్మ"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-04", category: "FIELD", topic: "ఎలక్ట్రికల్/కెమికల్", condition: "కుజుడు + రాహువు + అనల అంశ", result: "ఎలక్ట్రికల్, కెమికల్, మెటలర్జీ", sourcePage: "5", planets: <String>["Mars","Rahu"], devatas: <String>["అనల"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-05", category: "FIELD", topic: "వైద్యం", condition: "సూర్యుడు + కుజుడు + స్కంద/అంతక అంశ + 6వ భావ సంబంధం", result: "MBBS", sourcePage: "5", planets: <String>["Sun","Mars"], devatas: <String>["స్కంద","అంతక"], houses: <int>[6]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-06", category: "FIELD", topic: "సర్జరీ/డెంటల్", condition: "కుజుడు + కేతువు + పరశుధర అంశ", result: "సర్జరీ, డెంటల్", sourcePage: "5", planets: <String>["Mars","Ketu"], devatas: <String>["పరశుధర"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-07", category: "FIELD", topic: "ఆయుర్వేదం/నర్సింగ్", condition: "చంద్రుడు + గురుడు + గోవింద అంశ", result: "ఆయుర్వేదం, నర్సింగ్, ఫార్మసీ", sourcePage: "5", planets: <String>["Moon","Jupiter"], devatas: <String>["గోవింద"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-08", category: "FIELD", topic: "వ్యవసాయం", condition: "చంద్రుడు + శుక్రుడు + గోవింద అంశ + 4వ భావం", result: "వ్యవసాయం, డెయిరీ, పశువైద్యం", sourcePage: "5", planets: <String>["Moon","Venus"], devatas: <String>["గోవింద"], houses: <int>[4]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-09", category: "FIELD", topic: "న్యాయం", condition: "గురుడు + శని + మిత్ర/పరశుధర అంశ + 9వ భావం", result: "LLB, LLM", sourcePage: "5", planets: <String>["Jupiter","Saturn"], devatas: <String>["మిత్ర","పరశుధర"], houses: <int>[9]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-10", category: "FIELD", topic: "పరిపాలన", condition: "సూర్యుడు + గురుడు + స్కంద అంశ + 10వ భావ సంబంధం", result: "సివిల్ సర్వీసెస్, రాజనీతి", sourcePage: "5", planets: <String>["Sun","Jupiter"], devatas: <String>["స్కంద"], houses: <int>[10]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-11", category: "FIELD", topic: "డిఫెన్స్", condition: "కుజుడు + సూర్యుడు + స్కంద/భీమ అంశ", result: "డిఫెన్స్, పోలీస్, మిలిటరీ శిక్షణ", sourcePage: "5", planets: <String>["Mars","Sun"], devatas: <String>["స్కంద","భీమ"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-12", category: "FIELD", topic: "క్రీడలు", condition: "కుజుడు + భీమ అంశ + 3వ భావ బలం", result: "ఫిజికల్ ఎడ్యుకేషన్, క్రీడలు", sourcePage: "5", planets: <String>["Mars"], devatas: <String>["భీమ"], houses: <int>[3]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-13", category: "FIELD", topic: "ఫైన్ ఆర్ట్స్", condition: "శుక్రుడు + మదన అంశ", result: "ఫైన్ ఆర్ట్స్, ఫ్యాషన్, డిజైన్, బ్యూటీ", sourcePage: "5", planets: <String>["Venus"], devatas: <String>["మదన"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-14", category: "FIELD", topic: "సినిమా/మీడియా", condition: "శుక్రుడు + రాహువు + మయ అంశ", result: "సినిమా, యానిమేషన్, మీడియా, ఫోటోగ్రఫీ", sourcePage: "5", planets: <String>["Venus","Rahu"], devatas: <String>["మయ"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-15", category: "FIELD", topic: "సంగీతం/నృత్యం", condition: "శుక్రుడు + చంద్రుడు + వృషధ్వజ/గోవింద అంశ", result: "కర్ణాటక సంగీతం, కూచిపూడి, భరతనాట్యం", sourcePage: "5", planets: <String>["Venus","Moon"], devatas: <String>["వృషధ్వజ","గోవింద"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-16", category: "FIELD", topic: "భాషలు", condition: "బుధుడు + గురుడు + 2వ భావం + గోవింద అంశ", result: "భాషలు, సాహిత్యం, జర్నలిజం", sourcePage: "5", planets: <String>["Mercury","Jupiter"], devatas: <String>["గోవింద"], houses: <int>[2]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-17", category: "FIELD", topic: "టీచింగ్", condition: "గురుడు + 5వ/9వ బలం + గోవింద/స్కంద అంశ", result: "B.Ed, ప్రొఫెసర్‌షిప్, PhD", sourcePage: "5", planets: <String>["Jupiter"], devatas: <String>["గోవింద","స్కంద"], houses: <int>[5,9]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-18", category: "FIELD", topic: "మేనేజ్‌మెంట్", condition: "గురుడు + బుధుడు + భగ/మిత్ర అంశ", result: "MBA, మేనేజ్‌మెంట్, ఫైనాన్స్", sourcePage: "5", planets: <String>["Jupiter","Mercury"], devatas: <String>["భగ","మిత్ర"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-19", category: "FIELD", topic: "హోటల్", condition: "చంద్రుడు + శుక్రుడు + అనల అంశ", result: "హోటల్ మేనేజ్‌మెంట్, ఫుడ్ టెక్నాలజీ", sourcePage: "6", planets: <String>["Moon","Venus"], devatas: <String>["అనల"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-20", category: "FIELD", topic: "విదేశీ విద్య", condition: "రాహువు + 9వ/12వ భావ సంబంధం + బలమైన అంశ", result: "విదేశీ విద్య", sourcePage: "6", planets: <String>["Rahu"], devatas: <String>[], houses: <int>[9,12]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-21", category: "FIELD", topic: "పరిశోధన", condition: "శని + కేతువు + అంతక అంశ + 8వ భావం", result: "పరిశోధన, ఫోరెన్సిక్స్, పురావస్తు, మైనింగ్", sourcePage: "6", planets: <String>["Saturn","Ketu"], devatas: <String>["అంతక"], houses: <int>[8]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-22", category: "FIELD", topic: "వేద విద్య", condition: "గురుడు + కేతువు + వృషధ్వజ అంశ + 9వ భావం", result: "వేదాలు, సంస్కృతం, వేదాంతం, ఆగమాలు", sourcePage: "6", planets: <String>["Jupiter","Ketu"], devatas: <String>["వృషధ్వజ"], houses: <int>[9]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-23", category: "FIELD", topic: "జ్యోతిషం", condition: "గురుడు + బుధుడు + కేతువు + 8వ భావం + వృషధ్వజ/అంతక అంశ", result: "జ్యోతిషం, మంత్ర–తంత్ర శాస్త్రం", sourcePage: "6", planets: <String>["Jupiter","Mercury","Ketu"], devatas: <String>["వృషధ్వజ","అంతక"], houses: <int>[8]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-24", category: "FIELD", topic: "రత్నశాస్త్రం", condition: "శుక్రుడు + కేతువు + భగ అంశ", result: "జెమాలజీ", sourcePage: "6", planets: <String>["Venus","Ketu"], devatas: <String>["భగ"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-25", category: "FIELD", topic: "వాస్తు/శిల్పం", condition: "కుజుడు + శని + విశ్వకర్మ అంశ + 4వ భావం", result: "వాస్తు, ఆలయ శిల్పం", sourcePage: "6", planets: <String>["Mars","Saturn"], devatas: <String>["విశ్వకర్మ"], houses: <int>[4]),
    D24VidyaSourceRule(id: "D24-VIDYA-FIELD-26", category: "FIELD", topic: "ఇతర గూఢ విద్యలు", condition: "కేతువు + రాహువు + మయ అంశ", result: "టారో, న్యూమరాలజీ, ఇతర గూఢ విద్యలు", sourcePage: "6", planets: <String>["Ketu","Rahu"], devatas: <String>["మయ"], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-EXAM-01", category: "EXAM", topic: "6వ భావం", condition: "D1, D24లో 6వ భావం బలంగా, 6వ అధిపతి 3/6/10/11లో", result: "పోటీలో ప్రత్యర్థులను అధిగమించడం", sourcePage: "7–8", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-EXAM-02", category: "EXAM", topic: "3వ భావం", condition: "3వ భావం బలం, కుజ/శనులు శుభ స్థితి", result: "దీర్ఘకాల కృషి, కోచింగ్ సహనం", sourcePage: "7–8", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-EXAM-03", category: "EXAM", topic: "11వ భావం", condition: "11వ అధిపతికి 4/5/9 అధిపతులతో సంబంధం", result: "అనుకూల ఫలితం, ర్యాంక్", sourcePage: "7–8", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-EXAM-04", category: "EXAM", topic: "ధర్మ–బుద్ధి యోగం", condition: "5వ + 9వ అధిపతులు D24లో కేంద్ర/కోణంలో కలయిక", result: "అగ్రశ్రేణి సంస్థలో సీటు", sourcePage: "7–8", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-EXAM-05", category: "EXAM", topic: "D24 లగ్నం", condition: "D24 లగ్నం/లగ్నాధిపతి వర్గోత్తమం లేదా ఉచ్చ", result: "జాతీయ స్థాయి గుర్తింపు ఉన్న విద్య", sourcePage: "7–8", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-EXAM-06", category: "EXAM", topic: "ఆటంకం", condition: "4వ/5వ అధిపతి నీచ/అస్తంగత/6-8-12లో, శుభదృష్టి లేదు", result: "సీటు రాకపోవడం, డ్రాప్/రిపీట్", sourcePage: "7–8", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-01", category: "ADMISSION", topic: "IIT / IISc", condition: "కుజ + బుధ + సూర్యులు బలం, 5వ/9వ సంబంధం, విశ్వకర్మ/స్కంద అంశ, 6వ బలం", result: "IIT/IISc ప్రవేశం (JEE Advanced)", sourcePage: "8", planets: <String>["Mars","Mercury","Sun"], devatas: <String>["విశ్వకర్మ","స్కంద"], houses: <int>[5,9,6]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-02", category: "ADMISSION", topic: "NIT / IIIT / BITS", condition: "బుధ + కుజ + రాహువు, 5వ సంబంధం, మయ/విశ్వకర్మ అంశ", result: "NIT/IIIT (IIIT ముఖ్యంగా కంప్యూటర్ రంగం)", sourcePage: "8", planets: <String>["Mercury","Mars","Rahu"], devatas: <String>["మయ","విశ్వకర్మ"], houses: <int>[5]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-03", category: "ADMISSION", topic: "AIIMS / JIPMER", condition: "సూర్య + కుజ + గురువు బలం, 6వ/8వ సంబంధం, స్కంద/అంతక అంశ, 11వ అధిపతి బలం", result: "NEET టాప్ ర్యాంక్, ఉన్నత వైద్య సంస్థ", sourcePage: "8", planets: <String>["Sun","Mars","Jupiter"], devatas: <String>["స్కంద","అంతక"], houses: <int>[6,8,11]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-04", category: "ADMISSION", topic: "ప్రభుత్వ మెడికల్ కాలేజీ", condition: "సూర్య + కుజులు + 6వ బలం, 11వ అధిపతి మధ్యస్థం", result: "రాష్ట్ర ప్రభుత్వ మెడికల్ కాలేజీ", sourcePage: "8", planets: <String>["Sun","Mars"], devatas: <String>[], houses: <int>[6,11]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-05", category: "ADMISSION", topic: "IIM / ISB", condition: "గురు + బుధ + సూర్యులు, 10వ/11వ సంబంధం, మిత్ర/భగ/గోవింద అంశ", result: "IIM/ISB (CAT విజయం)", sourcePage: "8", planets: <String>["Jupiter","Mercury","Sun"], devatas: <String>["మిత్ర","భగ","గోవింద"], houses: <int>[10,11]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-06", category: "ADMISSION", topic: "NLU", condition: "గురు + శని + బుధులు, 9వ బలం, మిత్ర/పరశుధర అంశ", result: "NLU ప్రవేశం (CLAT)", sourcePage: "8", planets: <String>["Jupiter","Saturn","Mercury"], devatas: <String>["మిత్ర","పరశుధర"], houses: <int>[9]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-07", category: "ADMISSION", topic: "IISER / TIFR", condition: "గురు + కేతు + బుధులు, 8వ/9వ సంబంధం, స్కంద/అంతక అంశ", result: "పరిశోధనా సంస్థ, PhD, ఫెలోషిప్", sourcePage: "8", planets: <String>["Jupiter","Ketu","Mercury"], devatas: <String>["స్కంద","అంతక"], houses: <int>[8,9]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-08", category: "ADMISSION", topic: "NID / NIFT / SPA", condition: "శుక్ర + బుధులు, 5వ భావం, మదన/విశ్వకర్మ అంశ", result: "డిజైన్, ఫ్యాషన్, ఆర్కిటెక్చర్ సంస్థ", sourcePage: "8", planets: <String>["Venus","Mercury"], devatas: <String>["మదన","విశ్వకర్మ"], houses: <int>[5]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-09", category: "ADMISSION", topic: "FTII / IIMC", condition: "శుక్ర + రాహు + బుధులు, 3వ బలం, మయ/మదన అంశ", result: "సినిమా, మీడియా సంస్థ", sourcePage: "8", planets: <String>["Venus","Rahu","Mercury"], devatas: <String>["మయ","మదన"], houses: <int>[3]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-10", category: "ADMISSION", topic: "NDA / IMA", condition: "కుజ + సూర్యులు ఉచ్చ/స్వక్షేత్రం, 3/6/10 బలం, స్కంద/భీమ అంశ", result: "డిఫెన్స్ అకాడమీ ప్రవేశం", sourcePage: "8", planets: <String>["Mars","Sun"], devatas: <String>["స్కంద","భీమ"], houses: <int>[3,6,10]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-11", category: "ADMISSION", topic: "నవోదయ / సైనిక్", condition: "D24 4వ భావం + చంద్రుడు బలం + గురుదృష్టి, బాల్యంలో శుభ దశ", result: "ప్రతిష్ఠాత్మక పాఠశాల సీటు", sourcePage: "8", planets: <String>["Moon"], devatas: <String>[], houses: <int>[4]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-12", category: "ADMISSION", topic: "సంస్కృత / వేద విశ్వవిద్యాలయం", condition: "గురు + కేతువు, 9వ భావం, వృషధ్వజ/గోవింద అంశ", result: "సంప్రదాయ విద్యా సంస్థ, గురుకులం", sourcePage: "8", planets: <String>["Jupiter","Ketu"], devatas: <String>["వృషధ్వజ","గోవింద"], houses: <int>[9]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-13", category: "ADMISSION", topic: "విదేశీ అగ్రశ్రేణి విశ్వవిద్యాలయం", condition: "రాహు + గురువు, 9వ/12వ సంబంధం, D24 9వ అధిపతి ఉచ్చ/కేంద్రం", result: "విదేశీ ఉన్నత విశ్వవిద్యాలయం, స్కాలర్‌షిప్", sourcePage: "8", planets: <String>["Rahu","Jupiter"], devatas: <String>[], houses: <int>[9,12]),
    D24VidyaSourceRule(id: "D24-VIDYA-ADMISSION-14", category: "ADMISSION", topic: "స్కాలర్‌షిప్ / ఫెలోషిప్", condition: "11వ + 9వ అధిపతుల సంబంధం, గురువు బలం, భగ అంశ", result: "ఫీజు మినహాయింపు, స్కాలర్‌షిప్, JRF", sourcePage: "9", planets: <String>["Jupiter"], devatas: <String>["భగ"], houses: <int>[9,11]),
    D24VidyaSourceRule(id: "D24-VIDYA-TIMING-01", category: "TIMING", topic: "దశ", condition: "పరీక్ష సమయంలో 4/5/9/11 అధిపతుల దశ/అంతర్దశ", result: "ఆ ఏడాది విజయం", sourcePage: "9", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-TIMING-02", category: "TIMING", topic: "6వ అంతర్దశ", condition: "అదే సమయంలో 6వ అధిపతి అంతర్దశ శుభంగా", result: "పోటీలో మంచి ర్యాంక్", sourcePage: "9", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-TIMING-03", category: "TIMING", topic: "గోచార గురువు", condition: "గోచార గురువు జన్మ 5/9/11 భావం లేదా చంద్రుడిని చూస్తుంటే", result: "ఫలితం అనుకూలం", sourcePage: "9", planets: <String>[], devatas: <String>[], houses: <int>[]),
    D24VidyaSourceRule(id: "D24-VIDYA-TIMING-04", category: "TIMING", topic: "గోచార శని", condition: "గోచార శని 4వ/5వ భావంపై + 8వ/12వ దశ", result: "ఆలస్యం, రిపీట్ ప్రయత్నం", sourcePage: "9", planets: <String>[], devatas: <String>[], houses: <int>[]),
  ];
  static const catalogs = <D24VidyaCatalogRow>[
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "పూర్వ ప్రాథమిక", "నర్సరీ, LKG, UKG, అంగన్‌వాడీ", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "ప్రాథమిక", "1–5 తరగతులు", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "ప్రాథమికోన్నత", "6–8 తరగతులు", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "మాధ్యమిక", "9–10 (SSC / CBSE / ICSE)", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "ఇంటర్మీడియట్", "MPC, BiPC, MEC, CEC, HEC, వొకేషనల్", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "10వ తర్వాత వృత్తి", "ITI (ఎలక్ట్రీషియన్, ఫిట్టర్, వెల్డర్), పాలిటెక్నిక్ (సివిల్, మెకానికల్, EEE, ECE, CSE), D.Pharm, ANM, GNM, DMLT", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "UG – ఇంజనీరింగ్", "B.Tech/BE: CSE, AI&ML, Data Science, ECE, EEE, Mechanical, Civil, Chemical, Aeronautical, Biotech, Mining", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "UG – వైద్యం", "MBBS, BDS, BAMS, BHMS, BUMS, BSMS, BNYS, B.Pharm, B.Sc Nursing, BPT, BVSc", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "UG – సైన్స్/ఆర్ట్స్/కామర్స్", "B.Sc, BA, B.Com, BBA, BCA", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "UG – ఇతరాలు", "LLB, BA LLB, B.Arch, B.Des, BFA, BJMC, B.Sc Agriculture, హోటల్ మేనేజ్‌మెంట్, ఫిషరీస్, ఫారెస్ట్రీ, డెయిరీ టెక్నాలజీ", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "ఉపాధ్యాయ శిక్షణ", "D.El.Ed, B.Ed, B.P.Ed", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "వృత్తి కోర్సులు", "CA, CS, CMA, యాక్చూరియల్ సైన్స్", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "PG", "M.Tech/ME, MD/MS, MDS, M.Pharm, M.Sc, MA, M.Com, MBA/PGDM, MCA, LLM, M.Ed, M.Arch, MFA, MSW, MPH", "1"),
    D24VidyaCatalogRow("భారతీయ ఆధునిక విద్య", "PG తర్వాత", "DM/M.Ch, M.Phil, PhD, పోస్ట్-డాక్టరేట్", "1"),
    D24VidyaCatalogRow("విదేశీ విద్య", "అంతర్జాతీయ బోర్డులు", "IB, Cambridge (IGCSE, A-Levels)", "2"),
    D24VidyaCatalogRow("విదేశీ విద్య", "అమెరికా", "K-12 → Associate (2 ఏళ్లు) → Bachelor's (4 ఏళ్లు) → MS/MBA → PhD", "2"),
    D24VidyaCatalogRow("విదేశీ విద్య", "బ్రిటన్", "GCSE → A-Levels → Bachelor's (3 ఏళ్లు) → Master's (1 ఏడాది) → PhD", "2"),
    D24VidyaCatalogRow("విదేశీ విద్య", "కెనడా / ఆస్ట్రేలియా", "Diploma, Bachelor's, PG Diploma, Master's", "2"),
    D24VidyaCatalogRow("విదేశీ విద్య", "జర్మనీ", "Ausbildung (వృత్తి శిక్షణ), Bachelor, Master", "2"),
    D24VidyaCatalogRow("విదేశీ విద్య", "విదేశీ MBBS", "రష్యా, జార్జియా, ఫిలిప్పీన్స్ మొదలైనవి; భారత్‌లో ప్రాక్టీస్‌కు FMGE/NExT అవసరం", "2"),
    D24VidyaCatalogRow("విదేశీ విద్య", "ప్రవేశ/భాషా పరీక్షలు", "SAT, GRE, GMAT, IELTS, TOEFL, PTE, USMLE, PLAB", "2"),
    D24VidyaCatalogRow("విదేశీ విద్య", "విదేశీ భాషలు", "జర్మన్, ఫ్రెంచ్, జపనీస్, స్పానిష్, చైనీస్", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "వేదాలు", "ఋగ్, యజుర్, సామ, అథర్వణ", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "వేదాంగాలు", "శిక్ష, వ్యాకరణం, ఛందస్సు, నిరుక్తం, జ్యోతిషం, కల్పం", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "ఉపవేదాలు", "ఆయుర్వేదం, ధనుర్వేదం, గాంధర్వవేదం, స్థాపత్యవేదం", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "షడ్దర్శనాలు", "న్యాయ, వైశేషిక, సాంఖ్య, యోగ, పూర్వమీమాంస, వేదాంతం", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "సంస్కృత స్థాయిలు", "ప్రథమ → మధ్యమ → శాస్త్రి (UG) → ఆచార్య (PG) → విద్యావారిధి (PhD)", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "ఓరియంటల్", "భాషాప్రవీణ, విద్వాన్, తెలుగు పండిత శిక్షణ", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "ఆగమ/అర్చకత్వం", "వైఖానస, పాంచరాత్ర, శైవాగమాలు, పౌరోహిత్యం", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "కళలు", "కర్ణాటక సంగీతం, కూచిపూడి, భరతనాట్యం, ఆలయ శిల్పం, చిత్రకళ", "2"),
    D24VidyaCatalogRow("సంప్రదాయ విద్య", "ఇతరాలు", "యోగశాస్త్రం, గురుకుల విద్య, 64 కళలు", "2"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "జ్యోతిషం", "పరాశర, జైమిని, KP, నాడీ, ప్రశ్న, తాజిక, ముహూర్తం, లాల్ కితాబ్, వైద్య జ్యోతిషం", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "పాశ్చాత్య జ్యోతిషం", "Western Astrology, Horary", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "సంఖ్యా శాస్త్రం", "Chaldean, Pythagorean న్యూమరాలజీ", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "సాముద్రికం", "హస్తరేఖ, ముఖ లక్షణ శాస్త్రం", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "వాస్తు", "వాస్తు శాస్త్రం, ఫెంగ్ షుయి", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "రత్నశాస్త్రం", "జెమాలజీ (GIA, IGI కోర్సులు)", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "మంత్ర శాస్త్రాలు", "మంత్ర, తంత్ర, యంత్ర", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "శకునం/స్వరం", "శకున శాస్త్రం, స్వరశాస్త్రం, అంగవిద్య", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "భవిష్య పద్ధతులు", "టారో, I Ching, కబ్బాలా, గ్రాఫాలజీ", "3"),
    D24VidyaCatalogRow("అకల్ట్ / గూఢ విద్య", "శక్తి చికిత్సలు", "రేకీ, ప్రాణిక్ హీలింగ్, క్రిస్టల్ హీలింగ్", "3"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "పాఠశాల / ప్రతిష్ఠాత్మక పాఠశాలలు", "JNVST (నవోదయ), AISSEE (సైనిక్), NTSE, ఒలింపియాడ్‌లు", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "UG / ఇంజనీరింగ్", "JEE Main (NIT, IIIT), JEE Advanced (IIT), EAPCET, BITSAT", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "UG / వైద్యం", "NEET-UG", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "UG / సెంట్రల్ యూనివర్సిటీలు", "CUET-UG", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "UG / న్యాయం", "CLAT, AILET", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "UG / ఇతరాలు", "NATA, NID/UCEED, NCHM JEE, IISER Aptitude Test, NDA", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "PG / ఇంజనీరింగ్", "GATE", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "PG / వైద్యం", "NEET-PG, NEET-SS", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "PG / మేనేజ్‌మెంట్", "CAT (IIM), XAT, MAT, ICET", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "PG / సైన్స్", "IIT JAM, CUET-PG", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "PG / న్యాయం", "CLAT-PG", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "పరిశోధన / PhD/JRF", "UGC-NET, CSIR-NET", "6–7"),
    D24VidyaCatalogRow("ప్రవేశ పరీక్షల జాబితా", "ఉపాధ్యాయ / B.Ed/టీచర్", "EdCET, TET", "6–7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "ఇంజనీరింగ్", "IIT, NIT, IIIT, IISc, BITS", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "సైన్స్ పరిశోధన", "IISER, NISER, TIFR", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "వైద్యం", "AIIMS, JIPMER, PGIMER, NIMHANS", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "మేనేజ్‌మెంట్", "IIM, ISB, XLRI", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "న్యాయం", "NLU", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "డిజైన్/ఫ్యాషన్/ఆర్కిటెక్చర్", "NID, NIFT, SPA", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "హోటల్/మీడియా/సినిమా", "IHM, IIMC, FTII", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "వ్యవసాయం", "ICAR సంస్థలు, వ్యవసాయ విశ్వవిద్యాలయాలు", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "సంప్రదాయ విద్య", "జాతీయ సంస్కృత విశ్వవిద్యాలయం (తిరుపతి), AIIA, తెలుగు విశ్వవిద్యాలయం", "7"),
    D24VidyaCatalogRow("ప్రముఖ విద్యాసంస్థలు", "డిఫెన్స్", "NDA, IMA, నేవల్ & ఎయిర్‌ఫోర్స్ అకాడమీలు", "7"),
  ];
}
