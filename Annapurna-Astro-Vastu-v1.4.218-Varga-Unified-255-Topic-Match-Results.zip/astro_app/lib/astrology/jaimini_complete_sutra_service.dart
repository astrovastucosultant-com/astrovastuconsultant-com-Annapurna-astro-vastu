import 'dart:convert';
import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'jaimini_service.dart';
import 'jaimini_extended_rule_engine.dart';
import 'jaimini_additional_rule_engine.dart';
import 'jaimini_next_batch_rule_engine.dart';
import 'jaimini_pending_review_engine.dart';
import 'jaimini_source_rule_batch_engine.dart';
import 'varga_service.dart';
import '../utils/astro_format.dart';

/// A source-preserving rule catalog. The supplied 50-page PDF contains Telugu
/// IF/THEN commentary and sutra *references*, not the original sutra text or
/// source-backed remedies. Loading a rule never verifies it against a chart.
class JaiminiCompleteSutraRule {
  final String id;
  final String major;
  final String section;
  final String condition;
  final String result;
  final String source;
  final int page;
  final String sourceKind;

  const JaiminiCompleteSutraRule({
    required this.id,
    required this.major,
    required this.section,
    required this.condition,
    required this.result,
    required this.source,
    required this.page,
    required this.sourceKind,
  });

  factory JaiminiCompleteSutraRule.fromJson(Map<String, dynamic> map) =>
      JaiminiCompleteSutraRule(
        id: map['id'] as String,
        major: map['major'] as String,
        section: map['section'] as String,
        condition: map['condition'] as String,
        result: map['result'] as String,
        source: map['source'] as String,
        page: map['page'] as int,
        sourceKind: map['sourceKind'] as String,
      );
}

class JaiminiRuleCheck {
  /// null = this complete IF/THEN predicate has NOT been implemented.
  /// true/false = the indicated atomic condition has been checked from D9.
  final bool? matched;
  final String evidence;
  /// A computed quantity (e.g. Upagraha longitude), not a prediction match.
  final bool calculated;
  const JaiminiRuleCheck(this.matched, this.evidence,
      {this.calculated = false});
}

class JaiminiCompleteSutraService {
  const JaiminiCompleteSutraService();

  static Future<List<JaiminiCompleteSutraRule>> load() async {
    final raw = await rootBundle.loadString(
      'assets/jaimini/complete_if_then_rules.json',
    );
    final parsed = jsonDecode(raw) as List<dynamic>;
    return parsed
        .map((row) => JaiminiCompleteSutraRule.fromJson(
            Map<String, dynamic>.from(row as Map)))
        .toList(growable: false);
  }

  static String _missingRequirements(JaiminiCompleteSutraRule rule) {
    final n = int.tryParse(rule.id.split('.').first) ?? 0;
    if (n == 13) {
      return 'ఆధాన/గర్భధారణ సమయపు స్వతంత్ర చక్రం అందుబాటులో లేదు. '
          'జనన D1ను ఆధాన లగ్నంగా ఊహించి పరీక్షించరాదు. పరీక్ష పెండింగ్.';
    }
    if (rule.id == '8.5') {
      return 'కక్ష్య నిర్ణయానికి మూడు స్వతంత్ర జతలు కావాలి: '
          '(1) లగ్నాధిపతి–8వ అధిపతి రాశుల స్వభావం, '
          '(2) లగ్న రాశి–చంద్ర రాశి, '
          '(3) లగ్న రాశి–హోరా లగ్నం. '
          'ప్రతి జత ఇచ్చే దీర్ఘ/మధ్య/అల్ప కక్ష్య, '
          'రెండు లేదా మూడు జతల ఏకీభావం, వాటికి వర్తించే '
          '96/64/32, 108/72/36, 120/80/40 అనే మూల పట్టికను '
          'ప్రత్యేకంగా పరిశీలించాలి. హోరా లగ్నం గణన, '
          'సమ్మతి నియమాలు, అపవాదాలు పూర్తి ధృవీకరణ కాలేదు. '
          'పట్టికలోని సంఖ్యలను వ్యక్తి ఆయుర్దాయంగా ప్రకటించము.';
    }
    if (n == 8 || n == 9 || n == 10 || n == 11) {
      return 'ఆయుర్దాయం/మరణ స్వభావం/కుటుంబ సంబంధిత సంక్లిష్ట మూల షరతులు, '
          'కక్ష్య/దశ/ఇతర జాతక సహాయక ఆధారాలు ఇంకా ధృవీకరించలేదు. '
          'జీవిత సంఘటనగా నిర్ధారించరాదు.';
    }
    if (n == 12) {
      return 'ఈ ప్రత్యేక దశా పద్ధతికి ప్రారంభ రాశి, దశా దిశ, బలం, '
          'అంతర్దశ లెక్కల సమన్వయం అవసరం. పద్ధతిని ఎంచుకోకుండా తుది కాలం ఇవ్వము.';
    }
    if (n == 15) {
      return 'తెలుగు నీలకంఠ సుబోధిని మూలగ్రంథం నుంచి కొత్తగా నమోదైన '
          'అంశం/వ్యాఖ్యాన భేదం. పూర్తి గ్రహ/భావ/దశ షరతులు ఇంకా '
          'కోడ్‌లో అనుసంధానించలేదు. మూల ఫలితం మాత్రమే నమోదు అయింది; '
          'వ్యక్తిగతంగా నిర్ధారించబడలేదు.';
    }
    if (n == 14) {
      return 'ఈ స్త్రీజాతక నియమానికి అవసరమైన హోరా/ఆధాన/వర్ణద/నవాంశ '
          'సంబంధాలు విడిగా పూర్తి ధృవీకరణ చేయాలి.';
    }
    if (n == 2) {
      return 'ప్రత్యేక లగ్నం, సూర్యోదయం నుంచి ఘటికలు, లేదా వ్యాఖ్యాన భేదం '
          'అవసరమయ్యే గణన ఇంకా అనుసంధానం కాలేదు.';
    }
    return 'ఈ నియమానికి యుతి/రాశిదృష్టి/అర్గళ/బలం/బహుళ ప్రత్యామ్నాయ '
        'షరతులు పూర్తిగా పరీక్షించలేదు.';
  }

  static JaiminiRuleCheck check({
    required JaiminiCompleteSutraRule rule,
    required AstroChartResult chart,
    required JaiminiResult jaimini,
    double? minutesSinceLocalSunrise,
  }) {
    final ak = jaimini.charaKarakas
        .where((element) => element.code == 'AK')
        .map((element) => element.planet)
        .join(', ');
    final kl = jaimini.karakamsaSignIndex;
    final name = AstroFormat.signNamesTe[kl];
    final intro = 'ఆత్మకారకుడు: $ak; కారకాంశ రాశి: $name. ';
    final id = rule.id;
    // Formula/reference records must not masquerade as predictions.
    // These computations use the natal sidereal longitude (D1), not D9.
    if (id == '1.14' || id == '1.16') {
      final ranked = jaimini.charaKarakas
          .map((c) => '${c.code} = ${c.planet} '
              '(${c.effectiveDegree.toStringAsFixed(3)}°)')
          .join('; ');
      return JaiminiRuleCheck(null,
          'ఈ జాతకంలో ఉపయోగించిన చర కారక గణన: $ranked. '
          'ప్రస్తుతం యాప్ 7-కారక విధానాన్ని అమలు చేస్తోంది. '
          'రాహువుతో 8-కారక విధానం, సమాన డిగ్రీల భేదాలకు '
          'స్వతంత్ర ధృవీకరణ అవసరం.', calculated: true);
    }
    if (id == '2.5' || id == '2.6') {
      final number = id == '2.5' ? 12 : 7;
      final padas = jaimini.arudhaPadas.where(
          (p) => p.padaNumber == number).toList();
      if (padas.isEmpty) {
        return JaiminiRuleCheck(null,
            'ఈ జాతకానికి A$number ఆరూఢ గణన అందుబాటులో లేదు.');
      }
      final pada = padas.first;
      return JaiminiRuleCheck(null,
          '${number == 12 ? 'ఉపపదం (UL)' : 'దారపదం (A7)'}: '
          '${AstroFormat.signNamesTe[pada.padaSignIndex]}. '
          'మూల రాశి ${AstroFormat.signNamesTe[pada.sourceSignIndex]}, '
          'అధిపతి ${pada.lord} '
          '(${AstroFormat.signNamesTe[pada.lordSignIndex]}), '
          'గణన దూరం ${pada.distance}. '
          'ఇది ఆరూఢ గణన మాత్రమే; దాంపత్య ఫలితానికి ఇతర షరతులు అవసరం.',
          calculated: true);
    }
    if (const {'2.16', '2.17', '2.18', '2.19', '2.20'}
        .contains(id)) {
      final suns = chart.planets.where((p) => p.name == 'Sun').toList();
      if (suns.isEmpty) {
        return const JaiminiRuleCheck(null,
            'రవి నిరయణ రేఖాంశం అందుబాటులో లేదు; ఉపగ్రహ గణన పెండింగ్.');
      }
      double normalize(double d) => (d % 360 + 360) % 360;
      final sun = normalize(suns.first.longitude);
      final dhuma = normalize(sun + 133 + 20 / 60);
      final vyatipata = normalize(360 - dhuma);
      final parivesha = normalize(vyatipata + 180);
      final indrachapa = normalize(360 - parivesha);
      final upaketu = normalize(indrachapa + 16 + 40 / 60);
      final points = <String, (String, double)>{
        '2.16': ('ధూమం', dhuma),
        '2.17': ('వ్యతీపాతం', vyatipata),
        '2.18': ('పరివేషం', parivesha),
        '2.19': ('ఇంద్రచాపం', indrachapa),
        '2.20': ('ఉపకేతు', upaketu),
      };
      final point = points[id]!;
      final sign = (point.$2 / 30).floor() % 12;
      final degree = point.$2 % 30;
      return JaiminiRuleCheck(null,
          'రవి నిరయణ రేఖాంశం: ${sun.toStringAsFixed(4)}°. '
          '${point.$1}: ${AstroFormat.signNamesTe[sign]} '
          '${degree.toStringAsFixed(4)}° '
          '(మొత్తం ${point.$2.toStringAsFixed(4)}°). '
          'మూల IF సూత్రంలోని గణన అమలైంది. '
          'ఇది శుభ/అశుభ యోగ Confirm కాదు.',
          calculated: true);
    }
    if (jaimini.hasDegreeTie && (id.startsWith('3.') || id == '6.25')) {
      return JaiminiRuleCheck(null,
          '${intro}చర కారకాల డిగ్రీలు సమానంగా ఉన్నాయి. కారకాంశం ఆధారంగా తీర్పు పెండింగ్.');
    }

    // Source-preserving special lagnas, karaka evidence and dasha-method audit.
    final nextBatch = JaiminiNextBatchRuleEngine.check(
      id, chart, jaimini, minutesSinceLocalSunrise: minutesSinceLocalSunrise);
    if (nextBatch != null) {
      return JaiminiRuleCheck(nextBatch.matched, nextBatch.evidence,
        calculated: nextBatch.calculated);
    }

    // Extended source-reviewed predicates take priority over basic fallbacks.
    // A null return denotes a condition which cannot be checked from D1/D9.
    // Newly source-reviewed, explicit predicates and evidentiary calculations.
    final additional = JaiminiAdditionalRuleEngine.check(id, chart, jaimini);
    if (additional != null) {
      return JaiminiRuleCheck(additional.matched, additional.evidence,
          calculated: additional.calculated);
    }
    final extended = JaiminiExtendedRuleEngine.check(id, chart, jaimini);
    if (extended != null) {
      return JaiminiRuleCheck(extended.matched, extended.evidence,
          calculated: extended.calculated);
    }

    // Additional source-scoped tests: move eligible pending rules into the
    // matched/not-matched/calculated lanes without inventing event claims.
    final pendingBatch = JaiminiPendingReviewEngine.check(id, chart, jaimini);
    if (pendingBatch != null) {
      return JaiminiRuleCheck(pendingBatch.matched, pendingBatch.evidence,
          calculated: pendingBatch.calculated);
    }

    // Explicit additional PDF-derived tests and source-specific evidence.
    final sourceBatch = JaiminiSourceRuleBatchEngine.check(id, chart, jaimini);
    if (sourceBatch != null) {
      return JaiminiRuleCheck(sourceBatch.matched, sourceBatch.evidence,
          calculated: sourceBatch.calculated);
    }

    final group = id.split('.');
    if (group.length == 2 && group[0] == '3') {
      final n = int.tryParse(group[1]);
      if (n != null && n >= 1 && n <= 12) {
        final ok = kl == n - 1;
        return JaiminiRuleCheck(ok,
          '${intro}ఈ నియమానికి కావాల్సిన AK నవాంశ రాశి: '
          '${AstroFormat.signNamesTe[n - 1]}. '
          'వాస్తవ రాశి: $name. ${ok ? 'రాశి షరతు సరిపోయింది.' : 'రాశి షరతు సరిపోలేదు.'}');
      }
    }
    const supportedOthers = {
      '3.14', '3.15', '3.16', '3.17', '3.18', '3.19',
      '3.20', '3.21', '3.22', '3.36', '3.37',
      '3.38', '3.39', '3.40', '3.41', '3.42', '3.43', '3.44', '3.45',
    };
    if (!supportedOthers.contains(id)) {
      return JaiminiRuleCheck(null,
          '${intro}${_missingRequirements(rule)} మూల నియమం మాత్రమే చూపిస్తున్నాం; '
          'వర్తించిందని లేదా వర్తించలేదని ప్రకటించడం లేదు.');
    }
    final d9 = VargaService.calculate(chart, 9);
    final sign2 = (kl + 1) % 12;
    final sign5 = (kl + 4) % 12;
    bool has(int sign, String planet) =>
        d9.planets.any((p) => p.signIndex == sign && p.name == planet);
    bool either(String planet) => has(kl, planet) || has(sign2, planet);
    final names = <String, String>{
      '3.14': 'Sun', '3.16': 'Mars', '3.17': 'Mercury',
      '3.18': 'Jupiter', '3.19': 'Venus', '3.20': 'Saturn',
      '3.21': 'Rahu', '3.22': 'Ketu',
    };
    if (names.containsKey(id)) {
      final planet = names[id]!;
      final matching = either(planet);
      return JaiminiRuleCheck(matching,
          '${intro}నవాంశంలో కారకాంశం ($name) లేదా దాని 2వ రాశి '
          '(${AstroFormat.signNamesTe[sign2]})లో $planet ఉనికి: '
          '${matching ? 'ఉంది' : 'లేదు'}. '
          'ఇది స్థాన పరీక్ష మాత్రమే; అదనపు గ్రహబలం/దృష్టి ఆధారాలు వేరుగా పరిశీలించాలి.');
    }
    if (id == '3.15') {
      final matching = (has(kl, 'Moon') && has(kl, 'Venus')) ||
          (has(sign2, 'Moon') && has(sign2, 'Venus'));
      return JaiminiRuleCheck(null,
          '${intro}కారకాంశం లేదా రెండవ రాశిలో చంద్రుడు + శుక్రుడు కలసి ఉన్నారా: '
          '${matching ? 'అవును' : 'కాదు'}. పూర్ణ చంద్రుడి ప్రత్యేక బల పరీక్ష ఇందులో లేదు; '
          'కాబట్టి పూర్తి షరతు పరిశీలన పెండింగ్.');
    }
    if (id == '3.36') {
      final matching = (has(kl, 'Moon') && has(kl, 'Jupiter')) ||
          (has(sign5, 'Moon') && has(sign5, 'Jupiter'));
      return JaiminiRuleCheck(matching,
          '${intro}కారకాంశం లేదా 5వ రాశిలో చంద్రుడు–గురు యుతి: '
          '${matching ? 'ఉంది' : 'లేదు'}. ఇది యుతి పరీక్ష మాత్రమే; '
          'ఇతర వ్యాఖ్యాన పద్ధతుల్లో రాశి దృష్టి కూడా పరిశీలించాలి.');
    }
    // Section 3C is explicitly described in the uploaded source as
    // the Karakamsa/5th-house education and scholarship indications.
    if (id == '3.37') {
      final matches = [kl, sign5].any((sign) => has(sign, 'Moon') &&
          (has(sign, 'Venus') || has(sign, 'Mercury')));
      return JaiminiRuleCheck(matches,
          '${intro}కారకాంశం లేదా 5వలో చంద్ర–శుక్ర/చంద్ర–బుధ యుతి: '
          '${matches ? 'ఉంది' : 'లేదు'}.');
    }
    final academics = <String, String>{
      '3.38': 'Venus', '3.39': 'Jupiter', '3.40': 'Saturn',
      '3.41': 'Mercury', '3.42': 'Mars', '3.43': 'Moon',
      '3.44': 'Sun', '3.45': 'Ketu',
    };
    if (academics.containsKey(id)) {
      final planet = academics[id]!;
      final matches = has(kl, planet) || has(sign5, planet);
      final onlyPlanet = id == '3.38';
      if (onlyPlanet) {
        return JaiminiRuleCheck(null,
          '${intro}గ్రహం $planet KL/5వలో ${matches ? 'ఉంది' : 'లేదు'}. '
          'కానీ “కేవలం” అనే గ్రంథ షరతుకు ఇతర గ్రహాల దృష్టి/యుతి '
          'పరిశీలన ఇంకా అవసరం.');
      }
      return JaiminiRuleCheck(matches,
          '${intro}విద్యా నియమంలో $planet కారకాంశం లేదా 5వలో: '
          '${matches ? 'ఉంది' : 'లేదు'}. ఇది స్థానానికి సంబంధించిన ప్రాథమిక పరీక్ష మాత్రమే.');
    }
    final alRows = jaimini.arudhaPadas.where((p) => p.padaNumber == 1);
    final ulRows = jaimini.arudhaPadas.where((p) => p.padaNumber == 12);
    final a7Rows = jaimini.arudhaPadas.where((p) => p.padaNumber == 7);
    final lagna = AstroFormat.signNamesTe[chart.ascendantSignIndex];
    final al = alRows.isEmpty ? 'గణన లేదు' :
        AstroFormat.signNamesTe[alRows.first.padaSignIndex];
    final ul = ulRows.isEmpty ? 'గణన లేదు' :
        AstroFormat.signNamesTe[ulRows.first.padaSignIndex];
    final a7 = a7Rows.isEmpty ? 'గణన లేదు' :
        AstroFormat.signNamesTe[a7Rows.first.padaSignIndex];
    return JaiminiRuleCheck(null,
        '${intro}అందుబాటులో ఉన్న జాతక ఆధారాలు: '
        'D1 లగ్నం $lagna; AL $al; UL $ul; A7 $a7. '
        'మూల IF: ${rule.condition}. '
        'పూర్తి పరీక్షకు కావాల్సినవి: ${_missingRequirements(rule)} '
        'ఈ నమోదు 342 పెండింగ్ నియమాల పరిశీలన వరుసలో ఉంది; '
        'వర్తించిందని/వర్తించలేదని తప్పుడు తీర్పు ఇవ్వము.');
  }
}
