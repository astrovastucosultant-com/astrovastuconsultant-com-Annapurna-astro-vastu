import 'astro_models.dart';
import 'varga_service.dart';

/// Jagannatha drekkana (D3-J), distinct from the standard Parasari D3.
///
/// A sidereal natal sign is split into 3 x 10-degree sections. Its three
/// trines are reordered movable -> fixed -> dual, independently of the source
/// sign's modality. Movable source: 1/5/9; fixed: 9/1/5; dual: 5/9/1.
///
/// Source for this distinct computation: Chandrakala Nadi 5751-5752, as
/// transcribed/commented on by Sanjay Rath, PJC Year-2 (not a direct claim
/// that BPHS 6:7-8 defines the karma-phala interpretation).
/// https://pjc2.parasarahora.in/varga/drekka%E1%B9%87a-d3/jagannath-drekka%E1%B9%87a/
class D3JagannathaService {
  static const sourceUrl =
      'https://pjc2.parasarahora.in/varga/drekka%E1%B9%87a-d3/jagannath-drekka%E1%B9%87a/';

  static int partForLongitude(double longitude) {
    if (!longitude.isFinite) {
      throw ArgumentError.value(longitude, 'longitude', 'Must be finite');
    }
    final normalized = ((longitude % 360.0) + 360.0) % 360.0;
    return ((normalized % 30.0) / 10.0).floor().clamp(0, 2).toInt() + 1;
  }

  static int signForLongitude(double longitude) {
    if (!longitude.isFinite) {
      throw ArgumentError.value(longitude, 'longitude', 'Must be finite');
    }
    final normalized = ((longitude % 360.0) + 360.0) % 360.0;
    final natalSign = (normalized / 30.0).floor() % 12;
    final part = partForLongitude(normalized) - 1;
    // Zero-based zodiacal index: 0=movable, 1=fixed, 2=dual.
    final first = switch (natalSign % 3) {
      0 => natalSign,      // movable -> own sign
      1 => natalSign + 8,  // fixed -> ninth from own sign
      _ => natalSign + 4,  // dual -> fifth from own sign
    };
    return (first + 4 * part) % 12;
  }

  /// Traceable chart positions for karma-phala *inspection*, not automatic
  /// verdicts. House references are whole-sign from the D3-J ascendant.
  static D3JKarmaAudit audit(AstroChartResult chart) {
    final d3j = calculate(chart);
    final tenthSign = (d3j.ascendantSignIndex + 9) % 12;
    final thirdSign = (d3j.ascendantSignIndex + 2) % 12;
    final ninthSign = (d3j.ascendantSignIndex + 8) % 12;
    final natalTenthSign = (chart.ascendantSignIndex + 9) % 12;
    const owners = <String>[
      'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
      'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
    ];
    final tenthLord = owners[tenthSign];
    final natalTenthLord = owners[natalTenthSign];
    final tenthLordMatches = d3j.planets
        .where((p) => p.name == tenthLord).toList(growable: false);
    final natalLordMatches = d3j.planets
        .where((p) => p.name == natalTenthLord).toList(growable: false);
    return D3JKarmaAudit(
      ascendantSign: d3j.ascendantSignIndex,
      thirdSign: thirdSign,
      ninthSign: ninthSign,
      tenthSign: tenthSign,
      tenthLord: tenthLord,
      tenthLordHouse: tenthLordMatches.isEmpty ? null :
          ((tenthLordMatches.first.signIndex - d3j.ascendantSignIndex + 12) % 12) + 1,
      natalTenthLord: natalTenthLord,
      natalTenthLordHouse: natalLordMatches.isEmpty ? null :
          ((natalLordMatches.first.signIndex - d3j.ascendantSignIndex + 12) % 12) + 1,
      occupantsOfTenth: d3j.planets.where((p) => p.signIndex == tenthSign)
          .map((p) => p.name).toList(growable: false),
    );
  }

  static VargaChartData calculate(AstroChartResult chart) {
    return VargaChartData(
      definition: VargaService.definitionFor(3),
      ascendantSignIndex: signForLongitude(chart.ascendantLongitude),
      planets: chart.planets.map((p) => VargaPlacement(
        name: p.name,
        shortName: p.shortName,
        signIndex: signForLongitude(p.longitude),
        retrograde: p.retrograde,
      )).toList(growable: false),
    );
  }
}

class D3JKarmaAudit {
  final int ascendantSign;
  final int thirdSign;
  final int ninthSign;
  final int tenthSign;
  final String tenthLord;
  final int? tenthLordHouse;
  final String natalTenthLord;
  final int? natalTenthLordHouse;
  final List<String> occupantsOfTenth;

  const D3JKarmaAudit({
    required this.ascendantSign,
    required this.thirdSign,
    required this.ninthSign,
    required this.tenthSign,
    required this.tenthLord,
    required this.tenthLordHouse,
    required this.natalTenthLord,
    required this.natalTenthLordHouse,
    required this.occupantsOfTenth,
  });
}
