import 'astro_models.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';
import '../utils/astro_format.dart';

/// Source-scoped, explicitly enumerated additions. An evaluated atomic
/// condition is not a verified future event. No generic keyword=>prediction
/// mapping is made for the remaining pending IF-THEN source records.
class JaiminiPendingReviewResult {
  final bool? matched;
  final String evidence;
  final bool calculated;
  const JaiminiPendingReviewResult(this.matched, this.evidence,
      {this.calculated = false});
}

class JaiminiPendingReviewEngine {
  const JaiminiPendingReviewEngine._();

  static JaiminiPendingReviewResult? check(
      String id, AstroChartResult chart, JaiminiResult jm) {
    const supported = <String>{
      '3.75a', '4.1', '4.2', '4.3', '4.4', '4.5', '4.6',
      '4.8', '4.9', '4.10', '4.13', '15.8', '15.9',
      '15.11', '15.12', '15.13', '15.17', '15.21',
      '15.23', '15.30', '15.31', '15.38',
    };
    if (!supported.contains(id) || chart.planets.isEmpty) return null;
    if (jm.hasDegreeTie &&
        (id.startsWith('3.') || id.startsWith('4.') ||
         const <String>{'15.8', '15.17', '15.31'}.contains(id))) return null;
    final d9 = VargaService.calculate(chart, 9);
    final d1Signs = <String, int>{for (final p in chart.planets) p.name: p.signIndex};
    final d9Signs = <String, int>{for (final p in d9.planets) p.name: p.signIndex};
    final kl = jm.karakamsaSignIndex;
    final lagna = chart.ascendantSignIndex;
    int mod(int n) => (n % 12 + 12) % 12;
    int from(int s, int house) => mod(s + house - 1);
    String sign(int n) => AstroFormat.signNamesTe[mod(n)];
    bool d1At(String p, int s) => d1Signs[p] == mod(s);
    bool d9At(String p, int s) => d9Signs[p] == mod(s);
    bool d9Aspects(String p, int target) {
      final s = d9Signs[p];
      return s != null &&
          (jm.rashiDrishti[mod(s)] ?? <int>[]).contains(mod(target));
    }
    bool d1Aspects(String p, int target) {
      final s = d1Signs[p];
      return s != null &&
          (jm.rashiDrishti[mod(s)] ?? <int>[]).contains(mod(target));
    }
    String signOf(Map<String, int> positions, String p) =>
        positions[p] == null ? 'లభించలేదు' : sign(positions[p]!);
    int? pada(int n) {
      final values = jm.arudhaPadas.where((p) => p.padaNumber == n);
      return values.isEmpty ? null : values.first.padaSignIndex;
    }
    const benefics = <String>{'Jupiter', 'Venus', 'Mercury', 'Moon'};
    const exalts = <String, int>{
      'Sun': 0, 'Moon': 1, 'Mars': 9, 'Mercury': 5,
      'Jupiter': 3, 'Venus': 11, 'Saturn': 6,
    };
    const lords = <String>[
      'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
      'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
    ];
    JaiminiPendingReviewResult checked(bool ok, String evidence) =>
        JaiminiPendingReviewResult(ok,
          '${ok ? 'ప్రాథమిక IF షరతు సరిపోయింది' : 'ప్రాథమిక IF షరతు సరిపోలేదు'}: '
          '$evidence. ఇది గ్రంథ షరతు పరీక్ష మాత్రమే; సంఘటన లేదా '
          'వ్యక్తిగత జీవిత ఫలితం జరిగినట్లు నిర్ధారణ కాదు.');
    JaiminiPendingReviewResult measured(String evidence) =>
        JaiminiPendingReviewResult(null,
          '$evidence. బహుళ ప్రత్యామ్నాయ ఫలితాలను ఒకే గ్రీన్/పింక్ '
          'తీర్పుగా కలపలేదు.', calculated: true);
    String namesOf(Iterable<String> names) =>
        names.isEmpty ? 'లేవు' : names.join(', ');
    final al = pada(1);
    final ul = pada(12);

    switch (id) {
      case '3.75a':
        final amk = jm.charaKarakas.where((p) => p.code == 'AmK');
        if (amk.isEmpty || d9Signs[amk.first.planet] == null) return null;
        final a = d9Signs[amk.first.planet]!;
        final sixth = from(a, 6);
        final ps = d9Signs.keys.where((p) => d9At(p, sixth));
        return measured('AmK ${amk.first.planet} నవాంశం ${sign(a)}; '
            'అక్కడి నుంచి 6వ రాశి ${sign(sixth)}; '
            'ఆ రాశిలో గ్రహాలు: ${namesOf(ps)}; ఉపాస్యదేవత నిర్ణయానికి '
            'వేరువేరు గ్రహ/కేతు శాఖల పరిశీలన కావాలి');
      case '4.1': case '4.2': case '4.3':
        final fourth = from(kl, 4);
        final p = id == '4.1' ? 'Venus' : id == '4.2' ? 'Mars' : 'Ketu';
        final moon = d9At('Moon', fourth);
        final link = d9Aspects(p, fourth);
        return checked(moon && link,
            'KL ${sign(kl)}; 4వ రాశి ${sign(fourth)}; '
            'చంద్రుడు అక్కడ: $moon; $p రాశిదృష్టి: $link; '
            '$p నవాంశ స్థానం ${signOf(d9Signs,p)}');
      case '4.4':
        final fourth = from(kl, 4), fifth = from(kl, 5);
        final ok = <int>[fourth, fifth].any((s) => d9At('Mars', s) && d9At('Rahu', s));
        return checked(ok, 'KL 4/5 స్థానాలు ${sign(fourth)}, ${sign(fifth)}; '
            'కుజుడు ${signOf(d9Signs, 'Mars')}; '
            'రాహువు ${signOf(d9Signs, 'Rahu')}');
      case '4.5': case '4.6':
        final p = id == '4.5' ? 'Mars' : 'Ketu';
        final fourth = from(kl, 4), fifth = from(kl, 5);
        final ok = d9At(p, fourth) || d9At(p, fifth);
        return checked(ok, 'KL 4వ ${sign(fourth)}, 5వ ${sign(fifth)}; '
            '$p నవాంశ స్థానం ${signOf(d9Signs,p)}');
      case '4.8': case '4.9': case '4.10':
        if (al == null) return null;
        final target = from(al, id == '4.8' ? 7 : id == '4.9' ? 2 : 5);
        final ok = id == '4.8' ? d1At('Rahu', target) || d1At('Ketu', target)
            : id == '4.9' ? d1At('Ketu', target)
            : d1At('Rahu', target) && d1Aspects('Sun', target);
        return checked(ok, 'AL ${sign(al)}, పరీక్షించిన రాశి ${sign(target)}; '
            'రాహువు ${signOf(d1Signs,'Rahu')}, '
            'కేతువు ${signOf(d1Signs,'Ketu')}, '
            'రవి ${signOf(d1Signs,'Sun')}; '
            'రవి రాశిదృష్టి ${d1Aspects('Sun', target)}');
      case '4.13':
        final ok = kl == 6 || kl == 9;
        return checked(ok, 'AK నవాంశ రాశి (KL) ${sign(kl)}; '
            'మూల షరతు తుల/మకరం');
      case '15.8':
        final target = from(kl, 7);
        final ok = target == 8 && d9At('Moon', target);
        return checked(ok, 'KL ${sign(kl)}; 7వ ${sign(target)}; '
            'అక్కడ చంద్రుడు ${d9At('Moon', target)}. '
            'ఈ శాఖ PDFలో వ్యాఖ్యాన భేదంగా పేర్కొనబడింది');
      case '15.9':
        if (al == null) return null;
        final reports = <String>[];
        for (final origin in <int>[lagna, al]) {
          final second = from(origin, 2), eighth = from(origin, 8);
          final a = benefics.where((p) => d1At(p, second));
          final b = benefics.where((p) => d1At(p, eighth));
          reports.add('${sign(origin)} నుంచి 2వ ${sign(second)} '
              '(${namesOf(a)}) vs 8వ ${sign(eighth)} (${namesOf(b)})');
        }
        return measured('జన్మలగ్నం/AL నుంచి 2వ,8వ శుభగ్రహ స్థితి: '
            '${reports.join('; ')}. ఇది PDFలోని వ్యాఖ్యాన భేదం');
      case '15.11':
        if (al == null) return null;
        final target = from(al, 2);
        final ps = d1Signs.keys.where((p) => d1At(p, target));
        return measured('AL ${sign(al)} నుంచి 2వ ${sign(target)}; '
            'గ్రహాలు: ${namesOf(ps)}. పాపి/శుభుడు/గురు/శుక్ర '
            'ప్రత్యామ్నాయ ఫలితాలను విడిగా తూకం వేయాలి');
      case '15.12':
        if (al == null) return null;
        final target = from(al, 2);
        final exalted = exalts.keys.where((p) =>
            d1At(p, target) && exalts[p] == target).toList();
        if (exalted.isEmpty &&
            (d1At('Rahu', target) || d1At('Ketu', target))) {
          return measured('AL ${sign(al)}, 2వ ${sign(target)}; '
              'రాహు/కేతు ఉన్నారు. ఈ గ్రంథంలో నోడ్ల ఉచ్చ పద్ధతికి '
              'వివరణ భేదాలు ఉన్నాయి; నెగటివ్ తీర్పు ఇవ్వలేదు');
        }
        return checked(exalted.isNotEmpty,
            'AL ${sign(al)}, 2వ ${sign(target)}; '
            'అక్కడ ఉచ్చ గ్రహాలు: ${namesOf(exalted)}; '
            'రాహు/కేతు ఉచ్చ భేదాలు స్వతంత్ర ధృవీకరణ పెండింగ్');
      case '15.13':
        if (al == null || pada(5) == null || pada(9) == null) return null;
        final a5 = pada(5)!, a9 = pada(9)!;
        return measured('AL ${sign(al)}; పుత్ర ఆరూఢ A5 ${sign(a5)} '
            '(AL నుంచి ${mod(a5-al)+1}వ స్థానం); '
            'పితృ ఆరూఢ A9 ${sign(a9)} '
            '(AL నుంచి ${mod(a9-al)+1}వ స్థానం). '
            'వ్యక్తుల మధ్య స్నేహ/వైర తీర్పుకు రెండవ వ్యక్తి జాతకం కావాలి');
      case '15.17':
        final ak = d1Signs[jm.atmakaraka];
        if (ak == null) return null;
        final text = <String>[];
        for (final house in <int>[2, 4, 5]) {
          final target = from(ak, house);
          text.add('$house: ${sign(target)} '
              '(${namesOf(benefics.where((p) => d1At(p, target)))})');
        }
        return measured('AK ${jm.atmakaraka} ${sign(ak)} నుంచి '
            'శుభ గ్రహాల 2/4/5 స్థానాలు ${text.join('; ')}; '
            'బంధువుల స్వతంత్ర కారక బలం, దశలు వేరుగా పరిశీలించాలి');
      case '15.21':
        final origins = <int>[lagna, if (al != null) al];
        final rows = origins.map((o) {
          final t = from(o, 5);
          return '${sign(o)} నుంచి 5వ ${sign(t)}: '
              'రాహువు ${d1At('Rahu', t)}, రవి దృష్టి ${d1Aspects('Sun', t)}';
        });
        return measured('లగ్నం/AL వ్యాఖ్యాన భేదం: ${rows.join('; ')}. '
            'ఇది వైద్య నిర్ధారణ కాదు');
      case '15.23':
        if (ul == null) return null;
        final target = from(ul, 2);
        final lord = lords[target];
        final lordAt = d1Signs[lord];
        if (lordAt == null) return null;
        return measured('UL ${sign(ul)}, 2వ ${sign(target)}, '
            'అధిపతి $lord (${sign(lordAt)}), '
            'ఉచ్చ ${exalts[lord] == lordAt}, '
            'నీచ ${exalts[lord] != null && mod(exalts[lord]! + 6) == lordAt}; '
            'మూల ఫలితంలో సామాజిక వర్గ వ్యాఖ్యానం ఉంది; '
            'దాన్ని వ్యక్తి లక్షణం/గౌరవానికి తీర్పుగా ఉపయోగించము');
      case '15.30':
        final eighth = from(lagna, 8);
        final lord = lords[eighth];
        final p = d1Signs[lord];
        if (p == null) return null;
        return measured('లగ్నం ${sign(lagna)}, 8వ ${sign(eighth)}, '
            'అధిపతి $lord ${sign(p)}, '
            'ఉచ్చ ${exalts[lord] == p}, '
            'నీచ ${exalts[lord] != null && mod(exalts[lord]! + 6) == p}; '
            'జీవితకాల సంఖ్య లేదా మరణ కాలం ప్రకటించడం లేదు');
      case '15.31':
        final p = d1Signs[jm.atmakaraka];
        if (p == null) return null;
        return checked(p == from(lagna, 7) || p == from(lagna, 9),
            'AK ${jm.atmakaraka} ${sign(p)}; లగ్నం ${sign(lagna)}; '
            '7వ ${sign(from(lagna, 7))}, 9వ ${sign(from(lagna, 9))}. '
            'మూల ఆయుర్దాయ మినహాయింపుల పూర్తి ధృవీకరణ ఇంకా అవసరం');
      case '15.38':
        final p = d1Signs['Sun'];
        final q = d1Signs['Mercury'];
        final ok = lagna == 0 && p != null && q == p &&
            const <int>{2, 4, 5}.contains(p);
        return checked(ok, 'లగ్నం ${sign(lagna)}, రవి '
            '${signOf(d1Signs,'Sun')}, బుధుడు '
            '${signOf(d1Signs,'Mercury')}. '
            'ఇది 15.38 వ్యాఖ్యానభేదంలోని గ్రహస్థాన పరీక్ష మాత్రమే; '
            'తండ్రి మరణం లేదా మరణకాలం నిర్ధారణ కాదు');
    }
    return null;
  }
}
