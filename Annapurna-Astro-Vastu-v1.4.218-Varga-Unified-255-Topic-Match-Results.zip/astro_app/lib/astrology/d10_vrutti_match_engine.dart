import 'astro_models.dart';
import 'd10_career_service.dart';
import 'd10_vrutti_rule_registry.dart';
import 'varga_service.dart';

/// Evidence coverage is a rule-matching index, NOT the probability that a
/// profession will occur. Unconfirmed occupations are never recommended.
class D10VruttiMatch {
  final D10VruttiRule rule;
  final bool confirmed;
  final bool complete;
  final int percent;
  final List<String> passed;
  final List<String> failed;
  final List<String> pending;
  const D10VruttiMatch(this.rule, this.confirmed, this.complete, this.percent,
      this.passed, this.failed, this.pending);

  /// 'confirmed' is ONLY the occupation's primary-planet D1→D10 link.
  /// A full source IF–THEN match additionally needs every other predicate.
  bool get primaryPlanetConfirmed => confirmed;
  bool get fullRuleMatched => confirmed && complete;
  bool get partialRuleMatched => confirmed && !complete;
  bool get mayCheckConditionalTiming => confirmed && rule.planets.isNotEmpty;

  String get confirmationLabel => !primaryPlanetConfirmed
      ? 'D1→D10 ప్రధాన గ్రహ Confirm లేదు'
      : fullRuleMatched
          ? 'D1→D10 ప్రధాన గ్రహ Confirm ఉంది · పూర్తి IF–THEN సరిపోయింది'
          : 'D1→D10 ప్రధాన గ్రహ Confirm ఉంది · పూర్తి IF–THEN పెండింగ్/సరిపోలలేదు';
}

class D10VruttiMatchEngine {
  static const Map<String, String> teluguPlanet = {
    'Sun':'సూర్యుడు', 'Moon':'చంద్రుడు','Mars':'కుజుడు',
    'Mercury':'బుధుడు','Jupiter':'గురువు','Venus':'శుక్రుడు',
    'Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు',
  };
  static const Map<String,String> teluguDevata = {
    'Indra':'ఇంద్రుడు','Agni':'అగ్ని','Yama':'యముడు',
    'Rakshash':'రాక్షసుడు','Varuna':'వరుణుడు','Vayu':'వాయువు',
    'Kubera':'కుబేరుడు','Ishana':'ఈశానుడు','Brahma':'బ్రహ్మ',
    'Ananta':'అనంతుడు',
  };

  static bool _influence(VargaChartData d10, String planet, String lord) {
    if (!d10.planets.any((p) => p.name == planet)) return false;
    final house = D10CareerService.vargaHouse(d10, planet);
    // D10 ascendant, career house and its lord are explicit channels.
    return house == 1 || house == 10 || planet == lord ||
        D10CareerService.relatedVarga(d10, planet, lord);
  }

  static List<String> _confirmedD1Tenth(AstroChartResult chart,
      VargaChartData d10, String d10TenthLord) {
    return chart.planets.where((p) {
      if (D10CareerService.d1House(chart, p.name) != 10) return false;
      return _influence(d10, p.name, d10TenthLord);
    }).map((p) => p.name).toList(growable: false);
  }

  static List<D10VruttiMatch> evaluate(AstroChartResult chart) {
    final d10 = VargaService.calculate(chart, 10);
    final d9 = VargaService.calculate(chart, 9);
    final tenthSign = (d10.ascendantSignIndex + 9) % 12;
    final tenthLord = D10CareerService.signLord(tenthSign);
    final confirmed = _confirmedD1Tenth(chart, d10, tenthLord);
    final state = D10CareerService.saturnStream(chart).dashamsaState;
    final matches = <D10VruttiMatch>[];

    for (final rule in d10VruttiRulebook) {
      final passed = <String>[];
      final failed = <String>[];
      final pending = <String>[];
      final primary = rule.planets.isEmpty ? null : rule.planets.first;
      final isConfirmed = primary != null && confirmed.contains(primary);
      if (isConfirmed) {
        passed.add('ఈ నియమ ప్రధాన గ్రహం ${teluguPlanet[primary] ?? primary} జనన D1 10వ భావం నుంచి D10 లగ్నం/10వ భావం/10వ అధిపతితో అనుసంధానం ఉంది.');
      } else {
        failed.add('ఈ వృత్తి ప్రధాన గ్రహం ${primary == null ? 'తెలియదు' : (teluguPlanet[primary] ?? primary)} కు D1 10వ భావం → D10 confirm లేదు. ఇతర గ్రహం confirm ఈ నియమానికి సరిపోదు.');
      }

      int activePlanets = 0;
      for (final planet in rule.planets) {
        if (_influence(d10, planet, tenthLord)) {
          activePlanets++;
          passed.add('${teluguPlanet[planet] ?? planet}: D10 లగ్నం/10వ భావం/10వ అధిపతితో సంబంధం ఉంది.');
        } else {
          failed.add('${teluguPlanet[planet] ?? planet}: D10 వృత్తి సంబంధం నిర్ధారణ కాలేదు.');
        }
      }

      bool deityOk = false;
      if (rule.deity != null) {
        // Each D1 planet longitude is divided into 3° D10 segments. A source
        // deity applies only to a required, professionally active planet.
        for (final name in rule.planets) {
          if (!_influence(d10, name, tenthLord)) continue;
          final found = chart.planets.where((p) => p.name == name);
          if (found.isEmpty) continue;
          final deity = D10CareerService.devataForLongitude(found.first.longitude).deity;
          if (deity == rule.deity) {
            deityOk = true;
            passed.add('${teluguPlanet[name] ?? name} అంశదేవత ${teluguDevata[deity] ?? deity} — మూల రూల్‌తో సరిపోయింది.');
            break;
          }
        }
        if (!deityOk) failed.add('మూల అంశదేవత ${teluguDevata[rule.deity] ?? rule.deity} సంబంధం గుర్తించలేదు.');
      }

      int matchedHouses = 0;
      if (rule.houses.isNotEmpty) {
        // A hyphenated source list denotes related houses; it is evaluated as
        // evidence across the listed houses, not invented simultaneous occupancy.
        for (final house in rule.houses) {
          final houseLord = D10CareerService.signLord(
              (d10.ascendantSignIndex + house - 1) % 12);
          if (rule.planets.any((planet) =>
              D10CareerService.vargaHouse(d10, planet) == house ||
              planet == houseLord ||
              D10CareerService.relatedVarga(d10, planet, houseLord))) {
            matchedHouses++;
            passed.add('D10 $houseవ భావం/భావాధిపతికి అవసరమైన గ్రహ సంబంధం గుర్తించబడింది.');
          }
        }
        if (matchedHouses < rule.houses.length) failed.add('D10 ${rule.houses.join('/')} భావ ఆధారాల్లో ${rule.houses.length-matchedHouses} సంబంధాలు సరిపోలలేదు.');
      }

      final housesOk = rule.houses.isEmpty || matchedHouses == rule.houses.length;
      final modeOk = rule.mode == null || state == rule.mode;
      if (rule.mode != null) {
        final text = rule.mode == 'GOCHARASHTHA'
            ? 'గోచరిష్ట — వ్యాపారం / స్వయం ఉపాధి'
            : 'అగోచరిష్ట — ఉద్యోగం / సర్వీస్';
        if (modeOk) {
          passed.add('శని D10 స్థితి: $text.');
        } else if (state == 'MIXED') {
          pending.add('శని D10 స్థితి మిశ్రమం — $text నిర్ణయం పెండింగ్.');
        } else {
          failed.add('శని D10 స్థితి $textతో సరిపోలలేదు.');
        }
      }
      // This is explicit source data, not a guessed Navamsha predicate.
      if (rule.uncertain.isNotEmpty) {
        pending.add('మూలంలో అదనపు షరతు: ${rule.uncertain.join(', ')} — స్వతంత్ర ధృవీకరణ అవసరం.');
      }
      // Keep D9 evidence in the detail view without counting it towards D10.
      final d9House = D10CareerService.vargaHouse(d9, tenthLord);
      pending.add('సహాయక D9 ఆధారం: D10 10వ అధిపతి ${teluguPlanet[tenthLord] ?? tenthLord} D9లో $d9Houseవ భావం; అనుకూలత %లో ప్రత్యేక మార్కు కాదు.');

      // Weights: natal D1→D10 confirmation=35; required planets=35;
      // D10 deity=15; relevant houses=10; Saturn mode=5.
      // When a block does not exist in the source, its weight is excluded.
      final total = 35 + (rule.planets.isEmpty ? 0 : 35) +
          (rule.deity == null ? 0 : 15) +
          (rule.houses.isEmpty ? 0 : 10) + (rule.mode == null ? 0 : 5);
      final covered = (isConfirmed ? 35 : 0) +
          (rule.planets.isEmpty ? 0 : (35 * activePlanets / rule.planets.length).round()) +
          (rule.deity != null && deityOk ? 15 : 0) +
          (rule.houses.isEmpty ? 0 : (10 * matchedHouses / rule.houses.length).round()) +
          (rule.mode != null && modeOk ? 5 : 0);
      final score = isConfirmed ? (100 * covered / total).round().clamp(0, 100).toInt() : 0;
      final complete = isConfirmed && activePlanets == rule.planets.length &&
          (rule.deity == null || deityOk) && housesOk && modeOk &&
          rule.uncertain.isEmpty && (rule.mode == null || state != 'MIXED');
      matches.add(D10VruttiMatch(rule, isConfirmed, complete, score,
          passed, failed, pending));
    }
    matches.sort((a, b) {
      final c = (b.complete ? 1 : 0).compareTo(a.complete ? 1 : 0);
      return c != 0 ? c : b.percent.compareTo(a.percent);
    });
    return matches;
  }
}
