import 'astro_models.dart';
import 'd10_career_service.dart';
import 'varga_service.dart';

/// D10 deity evidence for *three distinct planets*.
///
/// The Dashamsha deity belongs to a 3-degree slice of a natal sidereal
/// longitude. A whole-sign D10 tenth house has no unique 3-degree longitude;
/// never fabricate a separate "tenth house deity" from its sign index.
///
/// This is an explanatory audit only: it MUST NOT raise a profession-match
/// score, override a D1->D10 confirmation, or manufacture timing evidence.
class D10PlanetDevataEvidence {
  final String planet;
  final String deity;
  final int natalSignIndex;
  final int division; // 1..10, counted inside the natal sign
  final double degreesInNatalSign;
  final int d1House;
  final int d10House;

  const D10PlanetDevataEvidence({
    required this.planet,
    required this.deity,
    required this.natalSignIndex,
    required this.division,
    required this.degreesInNatalSign,
    required this.d1House,
    required this.d10House,
  });
}

class D10DevataAudit {
  final String lagnaLord;
  final String tenthLord;
  final int d10AscSign;
  final int d10TenthSign;
  final D10PlanetDevataEvidence? principal;
  final D10PlanetDevataEvidence? lagnaLordEvidence;
  final D10PlanetDevataEvidence? tenthLordEvidence;
  final List<D10PlanetDevataEvidence> allPlanets;

  const D10DevataAudit({
    required this.lagnaLord,
    required this.tenthLord,
    required this.d10AscSign,
    required this.d10TenthSign,
    required this.principal,
    required this.lagnaLordEvidence,
    required this.tenthLordEvidence,
    required this.allPlanets,
  });
}

class D10DevataAuditService {
  static D10DevataAudit evaluate(AstroChartResult chart, {String? primaryPlanet}) {
    final d10 = VargaService.calculate(chart, 10);
    final lagnaLord = D10CareerService.signLord(d10.ascendantSignIndex);
    final tenthSign = (d10.ascendantSignIndex + 9) % 12;
    final tenthLord = D10CareerService.signLord(tenthSign);
    final all = <D10PlanetDevataEvidence>[];
    for (final p in chart.planets) {
      if (!d10.planets.any((x) => x.name == p.name)) continue;
      final normalized = ((p.longitude % 360.0) + 360.0) % 360.0;
      final inSign = normalized % 30.0;
      final profile = D10CareerService.devataForLongitude(normalized);
      all.add(D10PlanetDevataEvidence(
        planet: p.name,
        deity: profile.deity,
        natalSignIndex: (normalized / 30.0).floor(),
        division: (inSign / 3.0).floor().clamp(0, 9).toInt() + 1,
        degreesInNatalSign: inSign,
        d1House: D10CareerService.d1House(chart, p.name),
        d10House: D10CareerService.vargaHouse(d10, p.name),
      ));
    }
    D10PlanetDevataEvidence? lookup(String? planet) {
      for (final p in all) {
        if (p.planet == planet) return p;
      }
      return null;
    }
    return D10DevataAudit(
      lagnaLord: lagnaLord,
      tenthLord: tenthLord,
      d10AscSign: d10.ascendantSignIndex,
      d10TenthSign: tenthSign,
      principal: lookup(primaryPlanet),
      lagnaLordEvidence: lookup(lagnaLord),
      tenthLordEvidence: lookup(tenthLord),
      allPlanets: List.unmodifiable(all),
    );
  }
}
