import 'astro_models.dart';
import 'jaimini_extended_rule_engine.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';
import '../utils/astro_format.dart';

/// Source-scoped computational evidence for the next batch of Jaimini rules.
///
/// The PDF contains grouped, alternative, and commentary-derived outcomes.
/// In those cases [matched] remains null and [calculated] is true: this module
/// displays reproducible positions and conditions WITHOUT claiming that all
/// branches have been fulfilled, or making medical/family event predictions.
class JaiminiAdditionalRuleEngine {
  const JaiminiAdditionalRuleEngine._();

  static const supportedIds = <String>{
    '1.11', '1.12', '1.17', '1.26', '1.27', '1.28', '1.29', '1.30',
    '1.34', '1.35', '1.36',
    '5.14', '5.15', '5.16', '5.17', '5.18', '5.19', '5.20',
    '5.21', '5.22', '5.23', '5.25',
    '6.12', '6.16', '6.17', '6.19', '6.20',
    '7.1', '7.2', '7.3', '7.4', '7.5', '7.7', '7.8', '7.9',
    '7.10', '7.11',
  };

  static JaiminiExtendedRuleCheck? check(
      String id, AstroChartResult chart, JaiminiResult jm) {
    if (!supportedIds.contains(id) || chart.planets.isEmpty) return null;
    final d9 = VargaService.calculate(chart, 9);
    final lagna = chart.ascendantSignIndex;
    final kl = jm.karakamsaSignIndex;
    final signs = AstroFormat.signNamesTe;
    int norm(int sign) => (sign % 12 + 12) % 12;
    int house(int origin, int number) => norm(origin + number - 1);
    String label(int sign) => signs[norm(sign)];
    final natal = <String, int>{for (final p in chart.planets) p.name: p.signIndex};
    final nav = <String, int>{for (final p in d9.planets) p.name: p.signIndex};
    const benefics = <String>{'Jupiter', 'Venus', 'Mercury', 'Moon'};
    const malefics = <String>{'Sun', 'Mars', 'Saturn', 'Rahu'};
    const lords = <String>[
      'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
      'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
    ];
    const exalts = <String, int>{
      'Sun': 0, 'Moon': 1, 'Mars': 9, 'Mercury': 5,
      'Jupiter': 3, 'Venus': 11, 'Saturn': 6,
    };
    bool has(Map<String, int> planets, String p, int sign) =>
        planets[p] == norm(sign);
    List<String> located(Map<String, int> planets, int sign) => planets.keys
        .where((p) => planets[p] == norm(sign)).toList(growable: false);
    List<String> nat(int sign) => located(natal, sign);
    List<String> navAt(int sign) => located(nav, sign);
    bool sees(int from, int to) =>
        (jm.rashiDrishti[norm(from)] ?? const <int>[]).contains(norm(to));
    bool affects(Map<String, int> planets, String p, int sign) =>
        planets[p] != null && (has(planets, p, sign) || sees(planets[p]!, sign));
    String planetsText(Iterable<String> planets) =>
        planets.isEmpty ? 'లేవు' : planets.join(', ');
    JaiminiExtendedRuleCheck computed(String text) => JaiminiExtendedRuleCheck(
        null, '$text. ఇది పరిశీలించిన గ్రహ/రాశి ఆధారం మాత్రమే; '
        'సంపూర్ణ IF శాఖ లేదా ఖచ్చిత జీవిత సంఘటన నిర్ధారణ కాదు.',
        calculated: true);
    JaiminiExtendedRuleCheck direct(bool condition, String text) =>
        JaiminiExtendedRuleCheck(condition,
            '${condition ? 'ప్రత్యక్ష షరతు సరిపోయింది' : 'ప్రత్యక్ష షరతు సరిపోలేదు'}: '
            '$text. ఇది ఒక నియమం యొక్క జాతక పరీక్ష మాత్రమే; మొత్తం ఫలితానికి హామీ కాదు.');
    int occupied(int sign) => nat(sign).length;
    int dignified(int sign) => nat(sign).where((p) =>
      exalts[p] == norm(sign) || lords[norm(sign)] == p).length;
    int typeRank(int sign) => <int>{2, 5, 8, 11}.contains(norm(sign))
      ? 3 : <int>{1, 4, 7, 10}.contains(norm(sign)) ? 2 : 1;
    String positions(Map<String, int> planets, Iterable<String> ps) =>
      ps.map((p) => '$p: ${planets[p] == null ? 'తెలియదు' : label(planets[p]!)}').join('; ');
    String atPlanets(Map<String, int> planets, int origin, int offset) =>
        '${offset}వ ${label(house(origin,offset))}: '
        '${planetsText(located(planets,house(origin,offset)))}';
    int? pada(int number) {
      final rows = jm.arudhaPadas.where((p) => p.padaNumber == number);
      return rows.isEmpty ? null : rows.first.padaSignIndex;
    }
    final al = pada(1), a7 = pada(7), ul = pada(12);
    final ak = natal[jm.atmakaraka];
    if (jm.hasDegreeTie && const <String>{
      '1.17', '5.17', '5.18', '5.19', '5.20', '5.21', '5.22', '5.23',
    }.contains(id)) {
      return computed('చర కారకాల డిగ్రీ సమత్వం ఉంది; AK మరియు సంబంధిత '
          'కారక నిర్ణయం ముందుగా ధృవీకరించాలి');
    }

    // 1B Argala and Virodha: occupancy counts are an audit of the first
    // comparison; sign strength, Ketu reversal and favorable status are NOT
    // silently inferred from headcount alone.
    if (id == '1.11' || id == '1.12') {
      const active = <int>[4, 2, 11, 5];
      const blockers = <int>[10, 12, 3, 9];
      final reference = id == '1.12' ? natal['Ketu'] : lagna;
      if (reference == null) return null;
      final rows = <String>[];
      for (var i = 0; i < active.length; i++) {
        final a = occupied(house(reference, active[i]));
        final b = occupied(house(reference, blockers[i]));
        rows.add('${active[i]}/${blockers[i]}: $a/$b '
            '${a > b ? '(అర్గళ సంఖ్య ఎక్కువ)' : a < b ? '(విరోధ సంఖ్య ఎక్కువ)' : '(సమానం)'}');
      }
      return computed('${id == '1.12' ? 'కేతు రాశి' : 'లగ్నం'} '
          '${label(reference)} ఆధారంగా అర్గళ/విరోధ గణనలు: '
          '${rows.join('; ')}; కేతు అపసవ్య మినహాయింపు, గ్రహబలం '
          'తుది తూకం ఇంకా అవసరం');
    }
    if (id == '1.17') {
      if (ak == null) return null;
      final good = benefics.where((p) => affects(natal,p,ak)).toList();
      final adverse = malefics.where((p) => affects(natal,p,ak)).toList();
      final akName = jm.atmakaraka;
      return computed('AK $akName: ${label(ak)}, ఉచ్చం '
          '${exalts[akName] == ak}, స్వక్షేత్రం '
          '${lords[ak] == akName}; శుభ సంబంధం ${planetsText(good)}, '
          'పాప సంబంధం ${planetsText(adverse)}; మోక్షం/బంధనం తుది తీర్పు ఇవ్వలేదు');
    }
    if (const <String>{'1.26','1.27','1.28','1.29','1.30'}.contains(id)) {
      final comparisonRows = <String>[];
      final unclear = <String>[];
      for (var a = 0; a < 12; a++) {
        for (var b = a+1; b < 12; b++) {
          final ca = occupied(a), cb = occupied(b);
          // Preserve the ordered tie-break hierarchy. Stop before an
          // unverified friendship or lord-strength calculation.
          String? stronger;
          if (ca != cb) {
            stronger = label(ca > cb ? a : b);
          } else if (ca > 0 && dignified(a) != dignified(b)) {
            stronger = label(dignified(a) > dignified(b) ? a : b);
          } else if (ca > 0 && typeRank(a) != typeRank(b)) {
            stronger = label(typeRank(a) > typeRank(b) ? a : b);
          }
          if (stronger == null) {
            unclear.add('${label(a)}/${label(b)}');
          }
          comparisonRows.add('${label(a)}/${label(b)} → '
              '${stronger ?? 'బల తూకం పెండింగ్'}');
        }
      }
      return computed('12 రాశుల మధ్య 66 జంటల ప్రాథమిక బలతూకం. '
          'జంటల ఫలితాలు: ${comparisonRows.join('; ')}. '
          'పూర్తి నిర్ణయం పెండింగ్ జంటలు: ${unclear.length}. '
          'మిత్రక్షేత్ర/అధిపతి బలం/డిగ్రీ మినహాయింపులు '
          'అన్ని అమలుకాలేదు');
    }
    if (const <String>{'1.34','1.35','1.36'}.contains(id)) {
      final rows = <String>[];
      for (var sign = 0; sign < 12; sign++) {
        final blessed = benefics.where((p) => affects(natal,p,sign));
        if (blessed.isNotEmpty) rows.add('${label(sign)}: ${planetsText(blessed)}');
      }
      return computed('జన్మరాశులపై శుభ యుతి/రాశిదృష్టి: '
          '${rows.isEmpty ? 'లేవు' : rows.join('; ')}. '
          '¾ బలం లేదా తుది గ్రహబలం ఇంకా స్వతంత్ర ధృవీకరణ అవసరం');
    }

    if (id == '5.14') {
      final d3 = VargaService.calculate(chart, 3);
      final targetSigns = <int>[
        lagna, house(lagna,7), d3.ascendantSignIndex,
        house(d3.ascendantSignIndex,7), d9.ascendantSignIndex,
        house(d9.ascendantSignIndex,7),
      ];
      final rows = <String>[];
      for (final p in natal.keys) {
        final d1 = natal[p];
        final d3Sign = d3.planets.where((q) => q.name == p);
        final d9Sign = nav[p];
        if (d1 == null || d3Sign.isEmpty || d9Sign == null) continue;
        // Each chart uses that planet's sign in the *same* varga.
        final counts = <bool>[
          sees(d1,targetSigns[0]), sees(d1,targetSigns[1]),
          sees(d3Sign.first.signIndex,targetSigns[2]),
          sees(d3Sign.first.signIndex,targetSigns[3]),
          sees(d9Sign,targetSigns[4]), sees(d9Sign,targetSigns[5]),
        ];
        rows.add('$p ${counts.where((v)=>v).length}/6');
      }
      return computed('D1/D3/D9 లగ్న–సప్తమాల ఆరు స్థానాలపై '
          'ఒకే గ్రహ రాశిదృష్టి తనిఖీ: ${rows.join('; ')}. '
          '6/6, 5/6 భేదాలకు మూల వ్యాఖ్యానం వర్తింప చేయాలి');
    }
    if (id == '5.15') {
      if (natal['Moon']==null || natal['Venus']==null) return null;
      final moon = natal['Moon']!, venus = natal['Venus']!;
      final rel = (venus - moon + 12) % 12 + 1;
      return computed('చంద్రుడు ${label(moon)}, శుక్రుడు ${label(venus)}; '
        'పరస్పర రాశిదృష్టి ${sees(moon,venus) && sees(venus,moon)}, '
        'చంద్రుని నుంచి శుక్రుడు $rel వ రాశి; '
        'లగ్నం ${label(lagna)} / AL ${al==null?'లభించలేదు':label(al)}');
    }
    if (id == '5.16') {
      final ps = <String>['Mars', 'Venus', 'Ketu'];
      final marsSign = natal['Mars'];
      final venusSign = natal['Venus'];
      // Evaluate the complete boolean before interpolating a result string.
      // The earlier quoted expression split a Dart ${...} expression across
      // adjacent string literals and prevented the whole APK from compiling.
      final mutualAspect = marsSign != null && venusSign != null &&
          sees(marsSign, venusSign) && sees(venusSign, marsSign);
      return computed('కుజ–శుక్ర–కేతు రాశులు: ${positions(natal, ps)}. '
        'జంటల పరస్పర రాశిదృష్టి: $mutualAspect '
        '(కుజ–శుక్ర); త్రిగ్రహ ప్రత్యామ్నాయ శాఖ పూర్తిగా నిర్ధారించలేదు');
    }
    if (const <String>{'5.17','5.18','5.19','5.20','5.21',
        '5.22','5.23'}.contains(id)) {
      if (ak == null) return null;
      final k1=lords[lagna], k7=lords[house(lagna,7)],
          k5=lords[house(lagna,5)];
      final focal=<int>[ak, natal[k1]??lagna,natal[k7]??house(lagna,7)];
      final rows = <String>[];
      for (var i=0;i<focal.length;i++) {
        final s=focal[i];
        rows.add('${i==0?'AK':i==1?'లగ్నాధిపతి':'సప్తమాధిపతి'} '
          '${label(s)}: ${[2,3,4,5,6,8].map((h)=>atPlanets(natal,s,h)).join('; ')}');
      }
      return computed('AK=${jm.atmakaraka}, లగ్నాధిపతి=$k1, '
          'సప్తమాధిపతి=$k7, పంచమాధిపతి=$k5; '
          '${rows.join(' | ')}; అధిపత్యాలు/బలాలు/దృష్టుల '
          'సంయుక్త IF షరతులకు తుది పరిశీలన అవసరం');
    }
    if (id=='5.25') {
      final lord1=lords[lagna], lord5=lords[house(lagna,5)];
      if (natal[lord1]==null || natal[lord5]==null) return null;
      if (lord1 == lord5) {
        return computed('లగ్నం, 5వ భావాలకు ఒకే అధిపతి $lord1 '
            '(${label(natal[lord1]!)}). ఇది రెండు వేరు గ్రహాల యుతి కాదు; '
            'ఉమ్మడి అధిపత్యం శాఖగా ప్రత్యేకంగా పరిశీలించాలి');
      }
      return direct(natal[lord1]==natal[lord5],
          'లగ్నాధిపతి $lord1 ${label(natal[lord1]!)}, '
          '5వ అధిపతి $lord5 ${label(natal[lord5]!)}; '
          'ఒకే రాశిలో యుతి షరతు');
    }
    if (id=='6.12') {
      if (a7==null) return null;
      final viewers=natal.keys.where((p)=>affects(natal,p,a7)).toList();
      return computed('దారపదం A7=${label(a7)}, యుతి/రాశిదృష్టి '
          '${planetsText(viewers)}; భాగస్వామి ప్రవర్తనను ఒక్క యోగంతో నిర్ధారించలేము');
    }
    if (const <String>{'6.16','6.17','6.19','6.20'}.contains(id)) {
      if (ul==null) return null;
      final ul2=house(ul,2);
      final rows=<String>[];
      for(final sign in <int>[ul,ul2]) {
        final isMeOrMarsSign = <int>{0,2,5,7}.contains(sign);
        final isSaturnRahuSign = <int>{10,11}.contains(sign);
        final saturn=affects(natal,'Saturn',sign),
            mars=affects(natal,'Mars',sign),
            rahu=affects(natal,'Rahu',sign),
            jupiter=affects(natal,'Jupiter',sign);
        final mitigation=benefics.where((p)=>affects(natal,p,sign));
        final examined = switch(id) {
          '6.16' => isMeOrMarsSign && saturn && mars,
          '6.17' => isMeOrMarsSign && jupiter && saturn,
          '6.19' => isSaturnRahuSign && saturn && rahu,
          _ => mitigation.isNotEmpty,
        };
        rows.add('${label(sign)} (UL${sign==ul?'':'2'}): '
          'బుధ/కుజ రాశి $isMeOrMarsSign, '
          'కుంభ/మీన రాశి $isSaturnRahuSign; '
          'శని $saturn, కుజ $mars, రాహు $rahu, గురు $jupiter; '
          'శుభ ప్రభావం ${planetsText(mitigation)}; '
          '${id} ప్రాథమిక స్థానం/సంబంధ షరతు $examined');
      }
      return computed('${rows.join('; ')}. ప్రత్యామ్నాయ వ్యాఖ్యాన రాశులు, '
          'పూర్తి యుతి/దృష్టి భేదాలు ఇంకా ధృవీకరించాలి; వ్యాధి నిర్ధారణ కాదు');
    }
    if (const <String>{'7.1','7.2','7.3','7.4','7.5','7.7','7.8',
        '7.9','7.10','7.11'}.contains(id)) {
      final origins=<String,int>{'D9 లగ్నం': d9.ascendantSignIndex,
        if(!jm.hasDegreeTie) 'కారకాంశం':kl,
        if(ul!=null) 'ఉపపదం':ul, 'D1 లగ్నం':lagna};
      final rows=<String>[];
      for(final e in origins.entries) {
        final varga = e.key == 'D9 లగ్నం' || e.key == 'కారకాంశం'
            ? nav : natal;
        final ninth=house(e.value,9), fifth=house(e.value,5),
            seventh=house(e.value,7);
        final clue = switch(id) {
          '7.1' => '7వ ${label(seventh)}పై బుధ/శని/శుక్ర: '
              '${planetsText(<String>['Mercury','Saturn','Venus'].where((p)=>affects(varga,p,seventh)))}',
          '7.2' => '9వ ${label(ninth)}పై రవి/గురు/రాహు: '
              '${planetsText(<String>['Sun','Jupiter','Rahu'].where((p)=>affects(varga,p,ninth)))}',
          '7.3' => '9వ ${label(ninth)}లో చంద్రుడు: '
              '${has(varga,'Moon',ninth)}',
          '7.4' => '9వ ${label(ninth)}పై శుభాలు '
              '${planetsText(benefics.where((p)=>affects(varga,p,ninth)))} '
              'మరియు పాపాలు '
              '${planetsText(malefics.where((p)=>affects(varga,p,ninth)))}',
          '7.5' => '9వ ${label(ninth)}లో కుజ+శని: '
              '${has(varga,'Mars',ninth)&&has(varga,'Saturn',ninth)}',
          '7.7' => '5వ ${label(fifth)}: ${planetsText(located(varga,fifth))}, '
              '9వ ${label(ninth)}: ${planetsText(located(varga,ninth))}',
          '7.8' => '5వ ${label(fifth)}పై కుజ ప్రభావం '
              '${affects(varga,'Mars',fifth)}, '
              '9వ ${label(ninth)}పై కుజ ప్రభావం '
              '${affects(varga,'Mars',ninth)}',
          '7.9' => '3వ అధిపతి ${lords[house(e.value,3)]}, '
              '10వ అధిపతి ${lords[house(e.value,10)]}; '
              'ఈ గ్రహాల యుతి/దృష్టి ప్రత్యేకంగా పరిశీలించాలి',
          '7.10' => '9వ ${label(ninth)}పై కుజ '
              '${affects(varga,'Mars',ninth)}, శని '
              '${affects(varga,'Saturn',ninth)}, రవి '
              '${affects(varga,'Sun',ninth)}',
          _ => '9వ ${label(ninth)}పై పాప సంబంధం: '
              '${planetsText(malefics.where((p)=>affects(varga,p,ninth)))}',
        };
        rows.add('${e.key} ${label(e.value)}: $clue');
      }
      return computed('సంతాన అంశంలో ${id} నియమానికి జాతక సంబంధాల గణన — '
          '${rows.join(' | ')}. మూలంలోని గ్రహబలం, అధిపత్యం, '
          'అదనపు ధృవీకరణలు లేకుండా సంతానం/ఆరోగ్యం/లింగం/మరణం '
          'ఖచ్చితంగా నిర్ణయించరాదు');
    }
    return null;
  }
}
