import 'astro_models.dart';
import 'jaimini_chara_dasha_service.dart';
import 'jaimini_extended_rule_engine.dart';
import 'jaimini_service.dart';
import '../utils/astro_format.dart';

/// Jaimini source-level calculations with no inferred event predictions.
/// 2.8–2.12 and 2.15 require the ACTUAL elapsed time after local sunrise.
/// The natal chart alone has no sunrise/location; never infer it from JD.
class JaiminiNextBatchRuleEngine {
  const JaiminiNextBatchRuleEngine._();

  static const supportedIds = <String>{
    '1.15', '1.18', '1.18a', '1.19', '1.20', '1.21',
    '2.8', '2.9', '2.10', '2.11', '2.12', '2.13', '2.15',
    '2.15a', '2.15b',
    '12.1', '12.2', '12.3', '12.4', '12.5', '12.6',
    '12.17', '12.18', '12.19',
  };

  static double normalized(double degrees) => (degrees % 360 + 360) % 360;

  /// Based *exactly* on the formulae transcribed in the supplied IF-THEN PDF,
  /// page 6. This is an arithmetic output, not a confirmed special chart.
  static Map<String, double> sunrisePointLongitudes({
    required double sunSiderealLongitude,
    required double minutesSinceLocalSunrise,
  }) {
    if (!minutesSinceLocalSunrise.isFinite || minutesSinceLocalSunrise < 0 ||
        minutesSinceLocalSunrise >= 1440) {
      throw ArgumentError.value(minutesSinceLocalSunrise,
          'minutesSinceLocalSunrise', 'Provide 0–1439.999 minutes');
    }
    final sun = normalized(sunSiderealLongitude);
    final ghati = minutesSinceLocalSunrise / 24.0;
    final vighati = ghati * 60.0;
    final sunSign = (sun / 30).floor();
    final offset = <int>{0, 3, 6, 9}.contains(sunSign) ? 0.0 :
        <int>{1, 4, 7, 10}.contains(sunSign) ? 240.0 : 120.0;
    return <String, double>{
      '2.8': normalized(sun + (ghati / 2.5) * 30.0),
      '2.9': normalized(sun + (ghati / 5.0) * 30.0),
      '2.10': normalized(sun + ghati * 30.0),
      '2.11': normalized(sun + (vighati / 5.0) * 30.0),
      '2.12': normalized(sun + vighati * 2.0 + offset),
    };
  }

  static JaiminiExtendedRuleCheck? check(String id, AstroChartResult chart,
      JaiminiResult jm, {double? minutesSinceLocalSunrise}) {
    if (!supportedIds.contains(id)) return null;
    final lagna = chart.ascendantSignIndex;
    final signs = AstroFormat.signNamesTe;
    int norm(int sign) => (sign % 12 + 12) % 12;
    String signName(int sign) => signs[norm(sign)];
    int from(int sign, int count) => norm(sign + count - 1);
    JaiminiExtendedRuleCheck formula(String evidence) =>
        JaiminiExtendedRuleCheck(null, '$evidence. ఇది గణన/ప్రమాణ పరిశీలన మాత్రమే; '
            'దీని వల్ల వ్యక్తిగత సంఘటన ఖచ్చితంగా జరుగుతుందని చెప్పలేము.',
            calculated: true);
    final planetSigns = <String, int>{
      for (final planet in chart.planets) planet.name: planet.signIndex,
    };
    int? pada(int number) {
      for (final p in jm.arudhaPadas) {
        if (p.padaNumber == number) return p.padaSignIndex;
      }
      return null;
    }
    final ak = jm.charaKarakas.where((k) => k.code == 'AK');
    final amk = jm.charaKarakas.where((k) => k.code == 'AmK');
    final dk = jm.charaKarakas.where((k) => k.code == 'DK');

    switch (id) {
      case '1.15':
        final ties = <String>[];
        final ordered = jm.charaKarakas;
        for (var i = 1; i < ordered.length; i++) {
          if ((ordered[i - 1].effectiveDegree - ordered[i].effectiveDegree).abs() < 1e-8) {
            ties.add('${ordered[i - 1].planet}/${ordered[i].planet}');
          }
        }
        return formula('ఏడు చర కారకాల మధ్య డిగ్రీ సమత్వం: '
            '${ties.isEmpty ? 'లేదు' : ties.join(', ')}; '
            'రాహువుతో ఎనిమిది కారకాల ప్రత్యామ్నాయ గణన ఇంకా అనుసంధానం కాలేదు');
      case '1.18':
        return formula('దారకారకుడు (DK): ${dk.isEmpty ? 'తెలియదు' : dk.first.planet}; '
            'శుక్రుడు: ${planetSigns['Venus'] == null ? 'తెలియదు' : signName(planetSigns['Venus']!)}; '
            'ఉపపదం (UL): ${pada(12) == null ? 'పెండింగ్' : signName(pada(12)!)}; '
            'దారపదం (A7): ${pada(7) == null ? 'పెండింగ్' : signName(pada(7)!)}');
      case '1.18a':
        return formula('జైమిని PDFలో 7 కారకాల వ్యవస్థ; '
            'పితృకారకుడితో కూడిన 8-కారక పద్ధతి వేరు. '
            'ఈ యాప్‌లో ప్రస్తుత AK=${ak.isEmpty ? 'తెలియదు' : ak.first.planet}; '
            'రెండు పద్ధతులను కలిపి ఒకే కారక తీర్పు ఇవ్వడం లేదు');
      case '1.19':
        return formula('స్థిర కారకాలు గ్రహాధారిత స్థిర సూచికలు; '
            'చర కారకాలు జాతక గ్రహ డిగ్రీలను బట్టి మారతాయి. '
            'ఈ జాతక చర కారకాలు: '
            '${jm.charaKarakas.map((k) => '${k.code}=${k.planet}').join(', ')}');
      case '1.20':
        return formula('PDF వ్యాఖ్యానం ప్రకారం నైసర్గిక బల క్రమం: '
            'శని < కుజ < బుధ < గురు < శుక్ర < చంద్ర < రవి < రాహు. '
            'దీనిని గ్రహాల షడ్బలం లేదా పూర్తి రాశిబలంగా భావించవద్దు');
      case '1.21':
        return formula('PDFలో రాహు/కేతు స్వక్షేత్రం–ఉచ్చానికి '
            'ప్రత్యేక వ్యాఖ్యాన భేదాలు ఉన్నాయి. '
            'ఈ జాతకంలో రాహు=${planetSigns['Rahu'] == null ? 'తెలియదు' : signName(planetSigns['Rahu']!)}, '
            'కేతు=${planetSigns['Ketu'] == null ? 'తెలియదు' : signName(planetSigns['Ketu']!)}; '
            'ఈ వ్యాఖ్యానాన్ని యాప్ అన్ని బలగణనల్లో ఆటోమేటిక్‌గా మార్చలేదు');
      case '2.8': case '2.9': case '2.10': case '2.11': case '2.12':
      case '2.15':
        final sun = chart.planets.where((p) => p.name == 'Sun');
        if (sun.isEmpty || minutesSinceLocalSunrise == null ||
            !minutesSinceLocalSunrise.isFinite ||
            minutesSinceLocalSunrise < 0 || minutesSinceLocalSunrise >= 1440) {
          return null; // Never substitute chart time or invented local sunrise.
        }
        final points = sunrisePointLongitudes(
          sunSiderealLongitude: sun.first.longitude,
          minutesSinceLocalSunrise: minutesSinceLocalSunrise);
        final key = id == '2.15' ? '2.12' : id;
        final longitude = points[key]!;
        final pointSign = (longitude / 30).floor();
        final ghati = minutesSinceLocalSunrise / 24.0;
        final pointNames = <String, String>{
          '2.8': 'హోరా లగ్నం', '2.9': 'భావ లగ్నం',
          '2.10': 'ఘటికా లగ్నం', '2.11': 'విఘటికా లగ్నం',
          '2.12': 'ప్రాణపదం', '2.15': 'ప్రాణపద సంబంధం',
        };
        final place = (pointSign - lagna + 12) % 12 + 1;
        return formula('స్థానిక సూర్యోదయం నుంచి $minutesSinceLocalSunrise నిమిషాలు '
            '(${ghati.toStringAsFixed(4)} ఘటికలు). '
            '${pointNames[id]}: ${signName(pointSign)} '
            '${(longitude % 30).toStringAsFixed(4)}° '
            '(మొత్తం ${longitude.toStringAsFixed(4)}°); '
            'జన్మ లగ్నం నుంచి ${place}వ స్థానం. '
            '${id == '2.15' ? 'PDFలో చెప్పిన 2/4/5/9/10/11 స్థానాల్లో ఉందా: ${<int>{2,4,5,9,10,11}.contains(place)}. ' : ''}'
            'సూర్యోదయం సమయం బాహ్యంగా ధృవీకరించి ఇచ్చినప్పుడే ఈ గణన');
      case '2.13':
        return formula('వర్ణద లగ్నానికి జన్మ లగ్నం ${signName(lagna)}, '
            'హోరా లగ్నం రెండూ అవసరం. స్థానిక సూర్యోదయం నుంచి ఖచ్చిత సమయం '
            'మరియు సవ్య/అపసవ్య మినహాయింపులు ధృవీకరించిన తరువాతే గణన; '
            'తప్పుడు వర్ణద రాశి చూపలేదు');
      case '2.15a':
        return formula('కటపయాది అక్షర సంఖ్యల గురించి ఈ PDFలో ఇచ్చిన '
            'అర్థవ్యాఖ్యానం మాత్రమే; ఇది గ్రహ స్థానం ఆధారిత యోగం కాదు');
      case '2.15b':
        return formula('PDFలో వర్గ గణనలకు పూర్వ పద్ధతుల భేదం ఉందని '
            'సూచించారు. యాప్‌లో అమలైన వర్గాల గణనకు ఒకే మూలపద్ధతిని '
            'వాడాలి; భేదాలను కలిపి యోగం ప్రకటించలేదు');
      case '12.1': case '12.2': case '12.3': case '12.4':
        if (!<String>{'Sun','Moon','Mars','Mercury','Jupiter',
            'Venus','Saturn','Rahu','Ketu'}.every(planetSigns.containsKey)) {
          return null; // Existing co-lord engine needs complete planet positions.
        }
        final dasha = JaiminiCharaDashaService.auditDurations(
          chart: chart,
          config: const JaiminiCharaConfig(method: JaiminiCharaMethod.methodB));
        final years = dasha.periods.map((p) =>
          '${signName(p.signIndex)} ${p.years.toStringAsFixed(0)}సం.'
          '(అధిపతి ${p.selectedLord}, ${p.countForward ? 'సవ్య' : 'అపసవ్య'})').join('; ');
        final ninth = from(lagna, 9);
        const vishama = <int>{0, 1, 2, 6, 7, 8};
        final sourceForward = vishama.contains(ninth);
        final currentForward = dasha.sequenceForward;
        final specific = switch (id) {
          '12.1' => 'ప్రతి రాశి నుంచి ఎంచుకున్న రాశ్యధిపతి వరకు సంవత్సరాలు, '
              'స్వక్షేత్ర కాలం మరియు ఉచ్చ/నీచ మార్పులు గణించబడ్డాయి. ',
          '12.2' => 'వృశ్చికానికి కుజ/కేతు, కుంభానికి శని/రాహు '
              'సహాధిపత్య ఎంపిక ప్రస్తుతం Method B నియమంతో జరిగింది. ',
          '12.3' => 'PDF 12.3: లగ్నం నుంచి 9వ రాశి ${signName(ninth)}; '
              'విషమపదం=$sourceForward. PDF దిశ '
              '${sourceForward ? 'సవ్య' : 'అపసవ్య'}; ప్రస్తుతం Method B దిశ '
              '${currentForward ? 'సవ్య' : 'అపసవ్య'}. '
              '${sourceForward == currentForward ? 'ఈ లగ్నానికి దిశ సరిపోతుంది.' : 'ఈ లగ్నానికి దిశ భేదం ఉంది; ఆటోమేటిక్ సమన్వయం చేయలేదు.'} ',
          '12.4' => 'PDF ప్రకారం అంతర్దశ దిశ AK విషమ/సమపదం ఆధారంగా; '
              'ప్రస్తుత CharaDashaServiceలో దశ రాశి ఆధారంగా ఉంటుంది. '
              'ఈ భేదాన్ని పూర్తి దశా పద్ధతి నిర్ధారణకు గుర్తించాలి. ',
          _ => '',
        };
        return formula('$specific Method B దశ సంవత్సరాల ఆడిట్: $years. '
            'ఈ ఆడిట్‌లో ఊహించిన జనన తేదీ ఉపయోగించలేదు; '
            'జనన కాలముద్ర, పద్ధతి ఎంపిక లేకుండా తుది సంఘటన తేదీలు ఇవ్వలేదు');
      case '12.5':
        final start = lagna.isEven ? lagna : from(lagna, 7);
        return formula('నవాంశ దశ PDF పద్ధతి: జన్మ లగ్నం '
            '${signName(lagna)} నుంచి ప్రారంభ రాశి ${signName(start)}; '
            'ప్రతి రాశి 9 సంవత్సరాలు, మొత్తం 12 రాశులు 108 సంవత్సరాలు. '
            'పూర్తి దశా క్రమం/అంతర్దశ పద్ధతి విడిగా నిర్ధారించాలి');
      case '12.6':
        return formula('స్థిర దశలో చర రాశి 7సం., స్థిర రాశి 8సం., '
            'ద్విస్వభావ రాశి 9సం. (మొత్తం 96సం.). '
            'బ్రహ్మ రాశి ఎంపిక, ఆరంభ దశ ఇంకా గణించలేదు');
      case '12.17':
        return formula('PDFలో వింశోత్తరి గ్రహ సంవత్సరాలు: '
            'రవి 6, చంద్ర 10, కుజ 7, రాహు 18, గురు 16, శని 19, '
            'బుధ 17, కేతు 7, శుక్ర 20 — మొత్తం 120. '
            'ఈ సూత్రం స్వయంగా జైమిని ప్రత్యేక దశను గణించదు');
      case '12.18':
        return formula('PDFలో ఫలిత సంబంధ సూచిక: లగ్నం/AK — జాతకుడు; '
            '3వ భావం/కారకుడు — సోదరులు; 7వ/కారకుడు — భాగస్వామి; '
            '9వ/కారకుడు — తండ్రి. ప్రస్తుత AK: '
            '${ak.isEmpty ? 'తెలియదు' : ak.first.planet}, '
            'AmK: ${amk.isEmpty ? 'తెలియదు' : amk.first.planet}');
      case '12.19':
        final akSign = planetSigns[jm.atmakaraka];
        if (akSign == null) return null;
        const vishama = <int>{0, 1, 2, 6, 7, 8};
        return formula('AK ${jm.atmakaraka} రాశి ${signName(akSign)}; '
            'PDF విషమ/సమపద దిశ: '
            '${vishama.contains(akSign) ? 'సవ్య' : 'అపసవ్య'}. '
            'అంతర్/ప్రత్యంతర్ ప్రారంభం, కాలపరిమాణం పూర్తి దశా '
            'పద్ధతిని ఎంచుకున్న తరువాత మాత్రమే నిర్ణయించాలి');
    }
    return null;
  }
}
