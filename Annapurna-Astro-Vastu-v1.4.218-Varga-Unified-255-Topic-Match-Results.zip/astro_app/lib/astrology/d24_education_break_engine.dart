import 'astro_models.dart';
import 'dasha_service.dart';
import 'varga_service.dart';

/// D24 education interruption / return-to-study evidence (interpretive rules).
/// A chart pattern is NOT proof of a historical interruption or of its social
/// cause. The supplied D24 document page 4 directly supports only the narrower
/// 'D1 4th/5th lords in D24 6/8/12 with malefics' interruption condition.
/// Other cause patterns are transparently tagged as derived interpretations.
class D24BreakEvidence {
  final String id;
  final String title;
  final String explanation;
  final bool? matched;
  final String source;
  /// Prevent two house roles sharing one lord from being double-counted.
  final String groupKey;
  /// The actual planet used for a causal test; not all linked planets are independent evidence.
  final List<String> triggerPlanets;
  /// Positive counter-evidence must not be counted as adverse evidence.
  final bool contrary;
  const D24BreakEvidence(this.id,this.title,this.explanation,this.matched,this.source,
    {this.groupKey='',this.triggerPlanets=const <String>[],this.contrary=false});

  String get status => matched == null ? 'పరీక్ష మిగిలింది' :
    matched! ? (contrary ? 'శుభ / వ్యతిరేక ఆధారం ఉంది' : 'ఆధారం ఉంది') :
    (contrary ? 'శుభ / వ్యతిరేక ఆధారం కనిపించలేదు' : 'ఆధారం కనిపించలేదు');
}

class D24BreakCause {
  final String id;
  final String name;
  final String caveat;
  final List<D24BreakEvidence> evidence;
  const D24BreakCause(this.id,this.name,this.caveat,this.evidence);
  int get hits => evidence.where((e)=>e.matched==true && !e.contrary).length;
  int get counterHits => evidence.where((e)=>e.matched==true && e.contrary).length;
  Set<String> get triggerPlanets => evidence.where((e)=>e.matched==true && !e.contrary)
      .expand((e)=>e.triggerPlanets).toSet();
  bool get multiLayer => evidence.any((e)=>e.id.startsWith('D1-') && e.matched==true && !e.contrary) &&
      evidence.any((e)=>e.id.startsWith('D24-') && e.matched==true && !e.contrary);
  bool get supported => multiLayer && hits>=2;
  String get verdict => supported ?
      (counterHits>0?'D1+D24 కారణ సంబంధం ఉంది; శుభ/వ్యతిరేక ఆధారం కూడా ఉంది':'D1+D24 రెండింటిలో కారణ సంబంధ సూచనలు') :
      hits > 0 ? 'కొన్ని సూచనలు · కారణం నిర్ధారణ కాలేదు' : 'ప్రత్యక్ష కారణసంబంధ మద్దతు లేదు';
}


/// A dasha-only window, NOT a verified dropout/passing date. Transits and
/// actual educational history must be reviewed before labeling an event.
class D24EducationDashaWindow {
  final DateTime start;
  final DateTime end;
  final String maha;
  final String antar;
  final String type;
  const D24EducationDashaWindow(this.start,this.end,this.maha,this.antar,this.type);
}

class D24EducationBreakReport {
  final List<D24BreakEvidence> primary;
  final List<D24BreakEvidence> recovery;
  final List<D24BreakCause> causes;
  final String mahaLord;
  final String antarLord;
  final DateTime at;
  final bool timingStress;
  final bool timingRecovery;
  final List<String> timingNotes;
  final bool uncertainTime;
  /// The date is explicitly chosen as a study interruption or restart event.
  final bool eventDateSelected;
  final List<D24EducationDashaWindow> candidateWindows;
  const D24EducationBreakReport({
    required this.primary, required this.recovery, required this.causes,
    required this.mahaLord, required this.antarLord, required this.at,
    required this.timingStress, required this.timingRecovery,
    required this.timingNotes, required this.uncertainTime,
    required this.eventDateSelected, required this.candidateWindows,
  });
  int get d1Count => primary.where((e)=>e.id.startsWith('D1-') && e.matched==true)
      .map((e)=>e.groupKey.isEmpty?e.id:e.groupKey).toSet().length;
  int get d24Count => primary.where((e)=>e.id.startsWith('D24-') && e.matched==true)
      .map((e)=>e.groupKey.isEmpty?e.id:e.groupKey).toSet().length;
  bool get crossConfirmed => d1Count>0 && d24Count>0;
  bool get strongSourceRule => primary.any((e)=>e.id=='SOURCE-D24-CORE-05' && e.matched==true);
  bool get breakPattern => crossConfirmed && (strongSourceRule || d24Count>=2) && (d1Count+d24Count+(strongSourceRule?1:0)>=3);
  String get mainVerdict {
    if (breakPattern && timingStress) return 'విద్యలో తీవ్రమైన ఆటంకం/విరామానికి బలమైన జ్యోతిష సూచనలు';
    if (breakPattern) return 'విద్యా విరామానికి బహుళ చక్రాల మద్దతు · కాలనిర్ధారణ మిగిలింది';
    if (crossConfirmed) return 'విద్యలో ఆటంక సూచనలు · పూర్తి విరామ యోగం నిర్ధారణ కాదు';
    return 'విద్య మధ్యలో ఆగిపోతుందని చెప్పడానికి తగిన ఆధారాలు లేవు';
  }
  /// Timing for the alleged cause is different from generic education dasha timing.
  bool causeHasDashaSupport(D24BreakCause cause) => eventDateSelected &&
      cause.supported && cause.triggerPlanets.isNotEmpty &&
      (cause.triggerPlanets.contains(mahaLord) || cause.triggerPlanets.contains(antarLord));
  String causeTimingStatus(D24BreakCause cause) {
    if (!eventDateSelected) return 'సంఘటన తేదీ ఎంచుకోలేదు · కారణానికి దశా పరీక్ష పెండింగ్';
    if (!cause.supported) return 'D1+D24 కారణ సంబంధం అసంపూర్తి · దశ ఆధారంతో పూర్తి నిర్ధారణ కాదు';
    if (causeHasDashaSupport(cause)) return 'ఎంచుకున్న తేదీ దశకు కారణ సంబంధిత గ్రహ మద్దతు ఉంది';
    return 'ఈ తేదీ దశలో కారణ గ్రహ మద్దతు కనిపించలేదు';
  }
  String get recoveryVerdict {
    final hits=recovery.where((e)=>e.matched==true).length;
    if (hits>=2 && timingRecovery) return 'చదువు తిరిగి కొనసాగడానికి పునరుద్ధరణ ఆధారాలు, దశమద్దతు ఉన్నాయి';
    if (hits>=2) return 'చదువు తిరిగి కొనసాగే అవకాశానికి జాతక ఆధారాలు ఉన్నాయి';
    return 'పునఃప్రారంభం నిర్ధారణకు మరిన్ని ఆధారాలు అవసరం';
  }
}

class D24EducationBreakEngine {
  static const String docSource='విద్యా జ్యోతిష నియమాలు – D24.docx, పేజీ 4, 2.2, ఆటంకం (D24-VIDYA-CORE-05)';
  static const String interpretive='D1/D24 భావకారకత్వాల ఆధారంగా ఈ యాప్ కోసం రూపొందించిన వ్యాఖ్యాన నియమం; ప్రత్యేక శ్లోక ఆధారం నిర్ధారించలేదు';
  static const String timingSource='వింశోత్తరి మహాదశ–అంతర్దశ కాలసరిపోలిక; సంఘటనకు స్వతంత్ర సాక్ష్యం కాదు';
  static const _rulers=<String>['Mars','Venus','Mercury','Moon','Sun','Mercury','Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'];
  static const _exaltation=<String,int>{'Sun':0,'Moon':1,'Mars':9,'Mercury':5,'Jupiter':3,'Venus':11,'Saturn':6};
  static const _hard=<String>['Mars','Saturn','Rahu','Ketu'];

  static D24EducationBreakReport evaluate(AstroChartResult chart,{
    required DateTime birthDateTime,required DateTime at,
    bool eventDateSelected=true,
  }) {
    final d1=_ChartHouses(chart.ascendantSignIndex, {
      for(final p in chart.planets) p.name:p.signIndex,
    });
    final varga=VargaService.calculate(chart,24);
    final d24=_ChartHouses(varga.ascendantSignIndex, {
      for(final p in varga.planets) p.name:p.signIndex,
    });
    final primary=<D24BreakEvidence>[];
    for (final h in [4,5,9]) {
      final lord=d1.lord(h);
      primary.add(D24BreakEvidence('D1-EDU-$h',
        'D1 $hవ విద్యాభావాధిపతి బలహీన సంబంధం',
        d1.describePlanetStress(lord),
        d1.stressed(lord), interpretive,groupKey:'D1:$lord',triggerPlanets:[lord]));
    }
    for (final h in [4,5,9]) {
      final lord=d24.lord(h);
      primary.add(D24BreakEvidence('D24-EDU-$h',
        'D24 $hవ విద్యాభావాధిపతి బలహీన సంబంధం',
        d24.describePlanetStress(lord),
        d24.stressed(lord), interpretive,groupKey:'D24:$lord',triggerPlanets:[lord]));
    }
    final sourceHits=<String>[];
    for (final h in [4,5]) {
      final lord=d1.lord(h);
      if (d24.isDusthana(lord) && d24.withMalefic(lord)) sourceHits.add('$hవ D1 అధిపతి ${_tel(lord)} D24 ${d24.house(lord)}వ భావంలో పాపగ్రహంతో');
    }
    primary.add(D24BreakEvidence('SOURCE-D24-CORE-05',
      'మూల D24-VIDYA-CORE-05: D1 విద్యాధిపతి D24లో 6/8/12 + పాపయుతి',
      sourceHits.isEmpty?'4వ/5వ D1 అధిపతులకు ఈ పూర్తి యుక్త షరతు కనిపించలేదు.':sourceHits.join('; '),
      sourceHits.isNotEmpty,docSource,triggerPlanets:[for (final h in [4,5]) if(d24.isDusthana(d1.lord(h)) && d24.withMalefic(d1.lord(h))) d1.lord(h)]));
    primary.add(D24BreakEvidence('D1-MERCURY',
      'D1 బుధుడి విద్యా అవరోధ సంబంధం',
      d1.describePlanetStress('Mercury'),
      d1.stressed('Mercury'),interpretive,groupKey:'D1:Mercury',triggerPlanets:const ['Mercury']));
    primary.add(D24BreakEvidence('D24-MERCURY',
      'D24 బుధుడి విద్యా అవరోధ సంబంధం',
      d24.describePlanetStress('Mercury'),
      d24.stressed('Mercury'),interpretive,groupKey:'D24:Mercury',triggerPlanets:const ['Mercury']));

    // A cause cannot be inferred from a house alone. Each check records the
    // actual planetary lord, stress condition AND explicit educational link.
    D24BreakEvidence audited(String id,String title,_ChartHouses houses,
        List<int> roleHouses,{String? planet,int? additionalHouse}) {
      final audit=planet==null ? houses.auditHouseLink(roleHouses) :
          houses.auditPlanetLink(planet,additionalHouse:additionalHouse);
      return D24BreakEvidence(id,title,audit.details,audit.matched,interpretive,
          triggerPlanets:audit.triggerPlanets);
    }
    D24BreakCause cause(String id,String title,String caveat,List<D24BreakEvidence> checks) =>
      D24BreakCause(id,title,caveat,checks);
    final financeD1=d1.auditHouseLink(const [2,11]);
    final financeD24=d24.auditHouseLink(const [2,11]);
    final causes=<D24BreakCause>[
      cause('FATHER','తండ్రి సంబంధిత కుటుంబ పరిస్థితులు',
        '9వ భావం లేదా సూర్య సంబంధం తండ్రి చర్యకు రుజువు కాదు; నిజ జీవిత సంఘటనతో మాత్రమే పోల్చాలి.',[
        audited('D1-FATHER','D1 9వ అధిపతి–విద్యా అవరోధ సంబంధం',d1,const [9]),
        audited('D24-FATHER','D24 9వ అధిపతి–విద్యా అవరోధ సంబంధం',d24,const [9]),
        audited('CHECK-FATHER-SUN','సూర్యుడి విద్యా సంబంధం (సహాయక ఆధారం)',d1,const [],planet:'Sun'),
      ]),
      cause('MOTHER','తల్లి / గృహ పరిస్థితుల వల్ల అంతరాయం',
        'చంద్రుడు/4వ భావ సమస్య వల్ల తల్లి కారణమని చెప్పరాదు.',[
        audited('D1-MOTHER','D1 చంద్రుడు–విద్యా అవరోధ సంబంధం',d1,const [],planet:'Moon'),
        audited('D24-MOTHER','D24 చంద్రుడు–విద్యా అవరోధ సంబంధం',d24,const [],planet:'Moon'),
      ]),
      cause('LOVE','ప్రేమ / సంబంధాల వల్ల చదువు విరామం',
        '5/7 భావం, శుక్రుడు మాత్రమే ప్రేమ సంఘటనను ధృవీకరించరు.',[
        audited('D1-LOVE','D1 శుక్రుడు–7వ భావం–విద్యా అవరోధం',d1,const [],planet:'Venus',additionalHouse:7),
        audited('D24-LOVE','D24 శుక్రుడు–7వ భావం–విద్యా అవరోధం',d24,const [],planet:'Venus',additionalHouse:7),
      ]),
      cause('FINANCE','ఆర్థిక ఇబ్బందులు / ఫీజు సమస్యలు',
        'ధనాభావం, విద్యాభావ సంబంధం కలిసినా ఫీజు చెల్లించలేదని జాతకం ద్వారా రుజువు చేయలేం.',[
        D24BreakEvidence('D1-FINANCE','D1 ధనాధిపతి ఒత్తిడి + విద్యతో ప్రత్యక్ష సంబంధం',
          financeD1.details,financeD1.matched,interpretive,triggerPlanets:financeD1.triggerPlanets),
        D24BreakEvidence('D24-FINANCE','D24 ధనాధిపతి ఒత్తిడి + విద్యతో ప్రత్యక్ష సంబంధం',
          financeD24.details,financeD24.matched,interpretive,triggerPlanets:financeD24.triggerPlanets),
        D24BreakEvidence('D1-FINANCE-PROTECTION','D1 ధనాధిపతి శుభబలం (వ్యతిరేక ఆధారం)',
          d1.describeSupportiveMoney(),d1.hasSupportiveMoney(),interpretive,contrary:true),
        D24BreakEvidence('D24-FINANCE-PROTECTION','D24 ధనాధిపతి శుభబలం (వ్యతిరేక ఆధారం)',
          d24.describeSupportiveMoney(),d24.hasSupportiveMoney(),interpretive,contrary:true),
      ]),
      cause('STUDY','అభ్యసనం / పరీక్షలలో పునరావృత ఇబ్బంది',
        'జ్యోతిష సూచన విద్యార్థి సామర్థ్యానికి తీర్పు కాదు; వాస్తవ మార్కులు, సహాయం పరిశీలించాలి.',[
        audited('D1-STUDY','D1 బుధుడు–విద్యా అవరోధ సంబంధం',d1,const [],planet:'Mercury'),
        audited('D24-STUDY','D24 బుధుడు–విద్యా అవరోధ సంబంధం',d24,const [],planet:'Mercury'),
        audited('CHECK-STUDY-JUPITER','D24 గురువు–విద్యా సంబంధం (సహాయక ఆధారం)',d24,const [],planet:'Jupiter'),
      ]),
      cause('HEALTH','ఆరోగ్యం / ఒత్తిడి వల్ల అంతరాయం',
        '6/8 సంబంధం వైద్య నిర్ధారణ కాదు; ఆరోగ్యం గురించి వాస్తవ ఆధారం అవసరం.',[
        audited('D1-HEALTH','D1 6/8 అధిపతి–విద్యా సంబంధం',d1,const [6,8]),
        audited('D24-HEALTH','D24 6/8 అధిపతి–విద్యా సంబంధం',d24,const [6,8]),
      ]),
      cause('MOVE','ఇల్లు / పాఠశాల మార్పు వల్ల అంతరాయం',
        '3/12 భావ సంబంధం నిజంగా ఊరు/పాఠశాల మారారని నిర్ధారించదు.',[
        audited('D1-MOVE','D1 3/12 అధిపతి–విద్యా అవరోధం',d1,const [3,12]),
        audited('D24-MOVE','D24 3/12 అధిపతి–విద్యా అవరోధం',d24,const [3,12]),
      ]),
      cause('WORK','ఉద్యోగం / కుటుంబ బాధ్యతల ఒత్తిడి',
        '10వ భావ సంబంధం వల్ల ఉద్యోగానికి వెళ్లారని లేదా చదువు మానేశారని నిర్ధారించరు.',[
        audited('D1-WORK','D1 10వ అధిపతి–విద్యా అవరోధం',d1,const [10]),
        audited('D24-WORK','D24 10వ అధిపతి–విద్యా అవరోధం',d24,const [10]),
      ]),
    ];

    final recovery=<D24BreakEvidence>[];
    for (final h in [4,5,9]) {
      final lord=d24.lord(h);
      recovery.add(D24BreakEvidence('D24-RECOVERY-$h',
        'D24 $hవ విద్యాధిపతి పునరుద్ధరణ మద్దతు',
        '${_tel(lord)} D24 ${d24.house(lord)??'-'}వ భావం; స్వ/ఉచ్చ లేదా కేంద్ర/త్రికోణంలో శుభ సంబంధ సూచన.',
        d24.supportive(lord),interpretive));
    }
    recovery.add(D24BreakEvidence('D1-RECOVERY-5',
      'D1 విద్యా 5వ అధిపతి మద్దతు',
      'D1 5వ అధిపతి స్వ/ఉచ్చ లేదా అనుకూల స్థానం.',
      d1.supportive(d1.lord(5)),interpretive));
    recovery.add(D24BreakEvidence('D24-JUPITER','D24 గురువు విద్యా సహకారం',
      'గురువు అనుకూల D24 స్థానం/బలం; పూర్తి షడ్బల సూచన కాదు.',
      d24.supportive('Jupiter'),interpretive));

    final times=<String>[];
    final windows=<D24EducationDashaWindow>[];
    String mdName='తెలియదు', adName='తెలియదు';
    bool stress=false,recover=false;
    try {
      final vim=DashaService.vimshottari(chart:chart,birthDateTime:birthDateTime);
      final md=eventDateSelected ? DashaService.periodAt(vim.mahadashas,at) : null;
      final ad=md==null ? null : DashaService.periodAt(DashaService.subPeriods(md),at);
      if (md!=null) mdName=md.lord;
      if (ad!=null) adName=ad.lord;
      final stressLords=<String>{d1.lord(4),d1.lord(5),d24.lord(4),d24.lord(5)};
      final favorable=<String>{d1.lord(4),d1.lord(5),d1.lord(9),d24.lord(4),d24.lord(5),d24.lord(9),'Mercury','Jupiter'};
      bool adverseLord(String lord) => (stressLords.contains(lord) && (d1.stressed(lord)||d24.stressed(lord)));
      bool favorableLord(String lord) => favorable.contains(lord) &&
          (d1.supportive(lord)||d24.supportive(lord));
      stress=(md!=null && adverseLord(md.lord)) || (ad!=null && adverseLord(ad.lord));
      recover=(md!=null && favorableLord(md.lord)) || (ad!=null && favorableLord(ad.lord));
      if(eventDateSelected) {
        times.add('మీరు ఎంచుకున్న విద్యా సంఘటన తేదీ ${at.day}-${at.month}-${at.year}: ${_tel(mdName)} మహాదశ · ${_tel(adName)} అంతర్దశ.');
        times.add(stress?'విద్యా అవరోధ భావాధిపతితో దశా సంబంధం కనిపించింది.':'ఈ తేదీ దశలో ప్రత్యేక విద్యా అవరోధ అధిపతి మద్దతు కనిపించలేదు.');
        times.add(recover?'విద్యా పునరుద్ధరణ కారక దశమద్దతు కూడా కనిపించింది.':'ఈ తేదీకి అదనపు పునరుద్ధరణ దశమద్దతు గుర్తించలేదు.');
        if (md==null||ad==null) times.add('ఈ తేదీకి పూర్తిస్థాయి మహాదశ–అంతర్దశ పరిధి లభించలేదు.');
        for(final c in causes){
          if(c.supported) {
            final planetDasha=c.triggerPlanets.contains(mdName)||c.triggerPlanets.contains(adName);
            times.add('${c.name}: ${planetDasha?'సంఘటన తేదీ దశకు సంబంధించిన కారణ గ్రహం కనిపించింది':'సంఘటన తేదీ దశకు ప్రత్యేక కారణ గ్రహ సంబంధం కనిపించలేదు'}.');
          }
        }
      } else {
        times.add('విద్య ఆగిన లేదా మళ్లీ ప్రారంభమైన తేదీ ఇంకా ఎంపిక కాలేదు. నేటి దశను విద్యా విరామ తేదీగా చూపడం లేదు.');
      }
      // Candidate windows at conventional school / higher education ages.
      // These are explicitly limited to Vimshottari timing evidence; not a
      // claim that an interruption occurred or that education must stop.
      final from=DateTime(birthDateTime.year+6,birthDateTime.month,birthDateTime.day);
      final until=DateTime(birthDateTime.year+36,birthDateTime.month,birthDateTime.day);
      for (final maha in vim.mahadashas) {
        if (!maha.end.isAfter(from) || !maha.start.isBefore(until)) continue;
        for (final antar in DashaService.subPeriods(maha)) {
          if (!antar.end.isAfter(from) || !antar.start.isBefore(until)) continue;
          final stressed=adverseLord(maha.lord)||adverseLord(antar.lord);
          final supported=favorableLord(maha.lord)||favorableLord(antar.lord);
          if (!stressed && !supported) continue;
          final a=antar.start.isBefore(from)?from:antar.start;
          final b=antar.end.isAfter(until)?until:antar.end;
          windows.add(D24EducationDashaWindow(a,b,maha.lord,antar.lord,
            stressed&&supported?'మిశ్రమ దశ':stressed?'విద్యా అవరోధ దశమద్దతు':'చదువు పునఃప్రారంభ దశమద్దతు'));
        }
      }
    } catch (_) {times.add('దశ గణనకు చంద్రస్థానం లేదా జనన తేదీ సమాచారం సరిపోలేదు.');}
    times.add('గోచార గురు/శని పూర్తి ధృవీకరణ, వాస్తవ సంఘటన తేదీ పోలిక వేరుగా అవసరం.');
    return D24EducationBreakReport(
      primary:List.unmodifiable(primary),recovery:List.unmodifiable(recovery),
      causes:List.unmodifiable(causes),mahaLord:mdName,antarLord:adName,
      at:at,timingStress:stress,timingRecovery:recover,
      timingNotes:List.unmodifiable(times),uncertainTime:false,eventDateSelected:eventDateSelected,
      candidateWindows:List.unmodifiable(windows),
    );
  }
  static String _tel(String lord) => const <String,String>{
    'Sun':'సూర్యుడు','Moon':'చంద్రుడు','Mars':'కుజుడు','Mercury':'బుధుడు',
    'Jupiter':'గురువు','Venus':'శుక్రుడు','Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు',
  }[lord]??lord;
}

class _CauseAudit {
  final bool matched;
  final String details;
  final List<String> triggerPlanets;
  const _CauseAudit(this.matched,this.details,this.triggerPlanets);
}

class _ChartHouses {
  final int asc;
  final Map<String,int> signs;
  const _ChartHouses(this.asc,this.signs);
  String lord(int house)=>D24EducationBreakEngine._rulers[(asc+house-1)%12];
  int? house(String planet) {final sign=signs[planet];return sign==null?null:((sign-asc+12)%12)+1;}
  bool isDusthana(String planet)=>const [6,8,12].contains(house(planet));
  bool joined(String a,String b)=>signs[a]!=null&&signs[a]==signs[b];
  bool aspects(String a,String b){
    final x=signs[a],y=signs[b]; if(x==null||y==null||!const <String>['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'].contains(a))return false;
    final dist=(y-x+12)%12+1;
    return dist==7 || (a=='Mars'&&(dist==4||dist==8)) || (a=='Jupiter'&&(dist==5||dist==9)) || (a=='Saturn'&&(dist==3||dist==10));
  }
  bool related(String a,String b)=>a==b||joined(a,b)||aspects(a,b)||aspects(b,a);
  bool withMalefic(String p)=>D24EducationBreakEngine._hard.any((m)=>m!=p&&joined(p,m));
  bool stressed(String p)=>signs[p]!=null&&(isDusthana(p)||withMalefic(p)||const <String,int>{'Sun':6,'Moon':7,'Mars':3,'Mercury':11,'Jupiter':9,'Venus':5,'Saturn':0}[p]==signs[p]);
  bool strong(String p)=>signs[p]!=null&&(D24EducationBreakEngine._rulers[signs[p]!]==p||D24EducationBreakEngine._exaltation[p]==signs[p]);
  bool supportive(String p)=>signs[p]!=null && !stressed(p) &&
      (strong(p)||const [1,4,5,7,9,10].contains(house(p))) &&
      (aspects('Jupiter',p)||joined('Jupiter',p)||strong(p));
  bool linkToEdu(String p)=>related(p,lord(4))||related(p,lord(5));
  bool loveStress()=>signs['Venus']!=null&&stressed('Venus') &&
      (related('Venus',lord(5))||related('Venus',lord(7))) &&
      (stressed(lord(4))||stressed(lord(5)));
  bool moneyStress()=>[2,11].any((h)=>stressed(lord(h))&&linkToEdu(lord(h)));
  bool healthEduLink()=>[6,8].any((h)=>stressed(lord(h))&&linkToEdu(lord(h)));
  bool travelEduLink()=>[3,12].any((h)=>stressed(lord(h))&&linkToEdu(lord(h)));

  static const _signTel=<String>['మేషం','వృషభం','మిథునం','కర్కాటకం',
    'సింహం','కన్య','తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం'];

  String describePlanet(String p) {
    final sign=signs[p], h=house(p);
    if(sign==null || h==null) return '${D24EducationBreakEngine._tel(p)} స్థానం అందుబాటులో లేదు';
    return '${D24EducationBreakEngine._tel(p)} (${_signTel[sign]}, $hవ భావం)';
  }
  List<String> stressReasons(String p) {
    if(signs[p]==null) return const [];
    final reasons=<String>[];
    final h=house(p);
    if(const [6,8,12].contains(h)) reasons.add('$hవ దుష్ఠాన స్థానం');
    final joinedMalefics=<String>[
      for(final m in D24EducationBreakEngine._hard)
        if(m!=p && joined(p,m)) D24EducationBreakEngine._tel(m),
    ];
    if(joinedMalefics.isNotEmpty) reasons.add('${joinedMalefics.join(', ')}తో యుతి');
    if(const <String,int>{'Sun':6,'Moon':7,'Mars':3,'Mercury':11,
       'Jupiter':9,'Venus':5,'Saturn':0}[p]==signs[p]) reasons.add('నీచరాశి');
    return reasons;
  }
  String describePlanetStress(String p) {
    final r=stressReasons(p);
    return '${describePlanet(p)}; ఆటంక పరీక్ష: ${r.isEmpty?'6/8/12, పాపయుతి లేదా నీచస్థితి కనిపించలేదు':r.join(' + ')}.';
  }
  List<String> educationLinks(String p,{List<int> educationHouses=const [4,5]}) {
    final lines=<String>[];
    for(final h in educationHouses) {
      final q=lord(h);
      String? why;
      if(p==q) {why='విద్యా $hవ భావానికి ఇదే అధిపతి (ఒకే గ్రహం; స్వతంత్ర రెండవ ఆధారం కాదు)';}
      else if(joined(p,q)) {why='విద్యా $hవ అధిపతి ${D24EducationBreakEngine._tel(q)}తో యుతి';}
      else if(aspects(p,q)) {why='విద్యా $hవ అధిపతి ${D24EducationBreakEngine._tel(q)}పై దృష్టి';}
      else if(aspects(q,p)) {why='విద్యా $hవ అధిపతి ${D24EducationBreakEngine._tel(q)} దృష్టి';}
      if(why!=null && !lines.contains(why)) lines.add(why);
    }
    return lines;
  }
  _CauseAudit auditHouseLink(List<int> roleHouses) {
    final candidates=<String>[];
    final active=<String>[];
    final seen=<String>{};
    for(final h in roleHouses) {
      final p=lord(h), stress=stressReasons(p), links=educationLinks(p);
      final match=stress.isNotEmpty && links.isNotEmpty;
      if(match && seen.add(p)) active.add(p);
      candidates.add('$hవ భావాధిపతి ${describePlanet(p)}; '
        'ఆటంకం: ${stress.isEmpty?'లేదు':stress.join(', ')}; '
        'విద్య 4/5 సంబంధం: ${links.isEmpty?'లేదు':links.join('; ')}; '
        '${match?'రెండు షరతులు సరిపోయాయి':'రెండు షరతులు కలిపి సరిపోలలేదు'}');
    }
    return _CauseAudit(active.isNotEmpty,candidates.join('\n'),active);
  }
  _CauseAudit auditPlanetLink(String planet,{int? additionalHouse}) {
    final stress=stressReasons(planet), links=educationLinks(planet);
    final extra=additionalHouse==null ? const <String>['అదనపు భావ పరీక్ష అవసరం లేదు'] :
       educationLinks(planet,educationHouses:[additionalHouse]);
    final extraMatched=additionalHouse==null || extra.isNotEmpty;
    final match=stress.isNotEmpty && links.isNotEmpty && extraMatched;
    final extraText=additionalHouse==null ? '' :
        '$additionalHouseవ భావ సంబంధం: ${extra.isEmpty?'లేదు':extra.join('; ')}; ';
    return _CauseAudit(match,
      '${describePlanet(planet)}; ఆటంకం: ${stress.isEmpty?'లేదు':stress.join(', ')}; '
      'విద్య 4/5 సంబంధం: ${links.isEmpty?'లేదు':links.join('; ')}; '
      '$extraText'
      '${match?'అవసరమైన షరతులు సరిపోయాయి':'అన్ని షరతులు సరిపోలలేదు'}',
      match?[planet]:const <String>[]);
  }
  bool hasSupportiveMoney()=>[2,11].any((h)=>supportive(lord(h)));
  String describeSupportiveMoney()=>[for(final h in [2,11])
    '$hవ ధనాధిపతి ${describePlanet(lord(h))}; ${supportive(lord(h))?'స్వ/ఉచ్చ/శుభ స్థానానికి ప్రాథమిక మద్దతు ఉంది':'ప్రాథమిక శుభబలం కనిపించలేదు'}'
  ].join('\n');
}
