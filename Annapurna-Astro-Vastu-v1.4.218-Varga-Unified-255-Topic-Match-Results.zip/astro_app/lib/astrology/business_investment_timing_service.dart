import '../models/birth_data.dart';
import 'astro_models.dart';
import 'd10_career_service.dart';
import 'd10_vrutti_activation_service.dart';
import 'd2_wealth_evaluation_service.dart';
import 'd2_dhana_asthi_registry.dart';
import 'dasha_service.dart';
import 'varga_service.dart';

/// The asset type changes only the *supporting* divisional charts.
/// D16 does not decide the timing of general business investments.
enum BusinessInvestmentType {
  general('సాధారణ వ్యాపార పెట్టుబడి', 'D1 · D2 · D10'),
  property('భూమి / భవనాలు', 'D1 · D2 · D10 + D4'),
  vehicles('వాహనాలు / రవాణా', 'D1 · D2 · D10 + D16'),
  machinery('ఫ్యాక్టరీ / యంత్రాలు', 'D1 · D2 · D10 + D4 / D16'),
  financial('షేర్లు / ఆర్థిక పెట్టుబడి', 'D1 · D2 (వృత్తి అయితే D10)');

  const BusinessInvestmentType(this.telugu, this.chartScope);
  final String telugu;
  final String chartScope;
}

enum InvestmentEvidenceStatus { supportive, caution, neutral }

enum InvestmentTimeStatus { support, caution, mixed }

class InvestmentEvidence {
  final String id;
  final String sourceChart;
  final String condition;
  final String observation;
  final String source;
  final InvestmentEvidenceStatus status;

  const InvestmentEvidence({
    required this.id,
    required this.sourceChart,
    required this.condition,
    required this.observation,
    required this.source,
    required this.status,
  });
}

class BusinessInvestmentAudit {
  final BusinessInvestmentType type;
  final List<InvestmentEvidence> evidence;
  final List<String> limitations;
  final bool evaluated;

  const BusinessInvestmentAudit({
    required this.type,
    required this.evidence,
    required this.limitations,
    required this.evaluated,
  });

  int get supportCount => evidence.where(
    (e) => e.status == InvestmentEvidenceStatus.supportive).length;
  int get cautionCount => evidence.where(
    (e) => e.status == InvestmentEvidenceStatus.caution).length;
  Set<String> get supportingCharts => evidence.where(
    (e) => e.status == InvestmentEvidenceStatus.supportive)
    .map((e) => e.sourceChart).toSet();
  bool get hasNatalSupport => evaluated && supportingCharts.length >= 2;
  String get summary {
    if (!evaluated) return 'జాతక డేటా అసంపూర్తి — పరిశీలన జరగలేదు';
    if (!hasNatalSupport) return 'కాలనిర్ణయానికి స్వతంత్ర ఆధారాలు సరిపోలలేదు';
    if (cautionCount > 0) return 'అనుకూల, జాగ్రత్త ఆధారాలు రెండూ ఉన్నాయి';
    return 'జాతక ఆధారాలు ఉన్నాయి — దశ–గోచార పరిశీలన అవసరం';
  }
}

class BusinessInvestmentWindow {
  final DateTime start;
  final DateTime end;
  final String mahadasha;
  final String antardasha;
  final InvestmentTimeStatus status;
  final List<String> evidence;

  const BusinessInvestmentWindow({
    required this.start,
    required this.end,
    required this.mahadasha,
    required this.antardasha,
    required this.status,
    required this.evidence,
  });

  int get months =>
      (end.year - start.year) * 12 + end.month - start.month + 1;
  BusinessInvestmentWindow through(DateTime to) => BusinessInvestmentWindow(
    start: start, end: to, mahadasha: mahadasha,
    antardasha: antardasha, status: status, evidence: evidence,
  );
}

/// Auditable *astrological evidence* for choosing an investment review period.
/// The BPHS varga domain, user-supplied D2 source rules, and this app's
/// interpretive timing conjunction are kept separate. No ROI/profit percentage
/// or claim of an exact transaction date is generated.
class BusinessInvestmentTimingService {
  static const _sourceInterpretive =
      'యాప్ సమన్వయ పరిశీలన (ఒకే మూలశ్లోకంలోని పెట్టుబడి సూత్రం కాదు)';

  static int houseOf(int asc, int sign) => (sign - asc + 12) % 12 + 1;

  static int? _position(AstroChartResult chart, String planet) {
    for (final p in chart.planets) {
      if (p.name == planet) return p.signIndex;
    }
    return null;
  }

  static int? _vPosition(VargaChartData chart, String planet) {
    for (final p in chart.planets) {
      if (p.name == planet) return p.signIndex;
    }
    return null;
  }

  static String _lord(int asc, int house) =>
      D10CareerService.signLord((asc + house - 1) % 12);

  static BusinessInvestmentAudit evaluate(
      AstroChartResult chart, BusinessInvestmentType type) {
    final have = {for (final p in chart.planets) p.name};
    // Moon is also required for Vimshottari and the existing D2 Indu Lagna.
    if (!{'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'}
        .every(have.contains)) {
      return BusinessInvestmentAudit(type: type, evaluated: false,
        evidence: const [], limitations: const [
          'సప్తగ్రహాల జనన స్థానాలు అందుబాటులో లేవు; 0 ఆధారాలని భావించవద్దు.',
        ]);
    }

    final result = <InvestmentEvidence>[];
    void add(String id, String sourceChart, String condition,
        String observation, InvestmentEvidenceStatus status,
        {String source = _sourceInterpretive}) {
      result.add(InvestmentEvidence(id: id, sourceChart: sourceChart,
          condition: condition, observation: observation,
          source: source, status: status));
    }

    final asc = chart.ascendantSignIndex;
    final fifth = _lord(asc, 5);
    final fifthSign = _position(chart, fifth);
    if (fifthSign != null) {
      final h = houseOf(asc, fifthSign);
      if (h == 11) {
        add('INV-D1-01', 'D1', '5వ అధిపతి 11వ భావంలో',
          '$fifth (5వ అధిపతి) 11వ భావంలో ఉన్నాడు; D2 మూల నియమం బలం కూడా కోరుతుంది.',
          InvestmentEvidenceStatus.supportive);
      } else if (h == 8 || h == 12) {
        add('INV-D1-02', 'D1', '5వ అధిపతి 8/12వ భావంలో',
          '$fifth 5వ అధిపతి $hవ భావంలో ఉన్నాడు; ఇది జాగ్రత్త సూచిక మాత్రమే. '
          'పాపదృష్టి లేకుండా D2-OT-003 నష్ట రూల్ Confirm కాదు.',
          InvestmentEvidenceStatus.caution);
      }
    }

    final eleventh = _lord(asc, 11);
    final eleventhSign = _position(chart, eleventh);
    if (eleventhSign != null) {
      final h = houseOf(asc, eleventhSign);
      if (const {1, 2, 5, 9, 10, 11}.contains(h)) {
        add('INV-D1-03', 'D1', '11వ అధిపతి ఆదాయ/ధర్మ/కేంద్ర భావాల్లో',
          '$eleventh (11వ అధిపతి) $hవ భావంలో ఉన్నాడు — ఆదాయ సంబంధ పరిశీలన.',
          InvestmentEvidenceStatus.supportive);
      } else if (h == 12) {
        add('INV-D1-04', 'D1', '11వ అధిపతి 12వ భావంలో',
          '$eleventh 11వ అధిపతి 12వ భావంలో — ఖర్చు/విదేశీ అంశాల పరిశీలన.',
          InvestmentEvidenceStatus.caution);
      }
    }

    final d2 = D2WealthEvaluationService.evaluate(chart);
    const included = {
      'D2-OT-001', 'D2-OT-002', 'D2-OT-003',
      'D2-IN-001', 'D2-IN-002', 'D2-IN-003', 'D2-IN-004',
      'D2-IN-005', 'D2-IN-006', 'D2-IN-007', 'D2-IN-008',
      'D2-CS-001', 'D2-CS-003',
    };
    final categoryRules = switch (type) {
      BusinessInvestmentType.property => const {
        'D2-PR-001', 'D2-PR-003', 'D2-PR-005', 'D2-PR-006',
        'D2-PR-007', 'D2-PR-008', 'D2-PR-010',
      },
      BusinessInvestmentType.vehicles => const {
        'D2-VH-001', 'D2-VH-003', 'D2-VH-006', 'D2-VH-007',
      },
      BusinessInvestmentType.machinery => const {
        'D2-PR-003', 'D2-PR-007', 'D2-VH-007',
      },
      _ => const <String>{},
    };
    for (final match in d2.where((e) =>
        included.contains(e.ruleId) || categoryRules.contains(e.ruleId))) {
      final original = D2DhanaAsthiRegistry.rules.firstWhere(
        (rule) => rule.id == match.ruleId);
      final family = original.sourceChart.contains('ఇందు')
        ? 'ఇందు లగ్నం'
        : original.sourceChart.contains('D4') ? 'D4'
        : original.sourceChart.contains('D16') ? 'D16'
        : original.sourceChart.contains('D2') ? 'D2' : 'D1';
      add(match.ruleId, family, original.condition, match.evidence,
        match.caution ? InvestmentEvidenceStatus.caution
                      : InvestmentEvidenceStatus.supportive,
        source: 'వినియోగదారు అందించిన ధన–ఆస్తి Rulebook, '
          'పేజీ ${original.sourcePage} · ${original.name}');
    }

    // Actual D2 chart placements are displayed as calculated observations,
    // without inventing a strength threshold absent from the supplied Hora
    // source. The app's D2 Rulebook also uses D1 and Indu Lagna rules; those
    // are labelled with their REAL source chart above, not disguised as D2.
    final hora = VargaService.calculate(chart, 2);
    final secondLord = _lord(asc, 2);
    final eleventhLord = _lord(asc, 11);
    final horaSecond = _vPosition(hora, secondLord);
    final horaEleventh = _vPosition(hora, eleventhLord);
    if (horaSecond != null && horaEleventh != null) {
      add('INV-D2-HORA', 'D2', 'D2 హోరాలో D1 ధన/లాభాధిపతుల స్థానం',
        '$secondLord (D1 2L) హోరా రాశి ${horaSecond + 1}; '
        '$eleventhLord (D1 11L) హోరా రాశి ${horaEleventh + 1}; '
        'D2 లగ్న రాశి ${hora.ascendantSignIndex + 1}. '
        'ఈ స్థానాలకే పెట్టుబడి లాభం అని ప్రకటించము.',
        InvestmentEvidenceStatus.neutral);
    }

    // D10 is a profession corroboration, not the profession-name Confirm gate.
    // For a *passive* financial investment D10 must not be forced into the
    // outcome; users still see its background separately as supplementary.
    if (type != BusinessInvestmentType.financial) {
      final d10 = VargaService.calculate(chart, 10);
      final d1Tenth = _lord(asc, 10);
      final d10Tenth = _lord(d10.ascendantSignIndex, 10);
      final d1TenthInD10 = _vPosition(d10, d1Tenth);
      if (d1TenthInD10 != null) {
        final h = houseOf(d10.ascendantSignIndex, d1TenthInD10);
        if (const {1, 2, 7, 10, 11}.contains(h)) {
          add('INV-D10-01', 'D10', 'D1 దశమాధిపతి D10లో వృత్తి/ధన సంబంధ భావం',
            '$d1Tenth D10లో $hవ భావంలో; D10 దశమాధిపతి $d10Tenth.',
            InvestmentEvidenceStatus.supportive);
        } else if (const {6, 8, 12}.contains(h)) {
          add('INV-D10-02', 'D10', 'D1 దశమాధిపతి D10లో 6/8/12',
            '$d1Tenth D10లో $hవ భావంలో — వృత్తి నిర్వహణ జాగ్రత్త మాత్రమే.',
            InvestmentEvidenceStatus.caution);
        } else {
          add('INV-D10-03', 'D10', 'D1 దశమాధిపతి D10లో ఇతర భావం',
            '$d1Tenth D10లో $hవ భావంలో — వృత్తి అనుకూల/ప్రతికూల '
            'తీర్పుకు అదనపు ఆధారాలు అవసరం.', InvestmentEvidenceStatus.neutral);
        }
      }
    }

    if (type == BusinessInvestmentType.property ||
        type == BusinessInvestmentType.machinery) {
      final d4 = VargaService.calculate(chart, 4);
      final fourth = _lord(d4.ascendantSignIndex, 4);
      final sign = _vPosition(d4, fourth);
      if (sign != null) {
        final h = houseOf(d4.ascendantSignIndex, sign);
        if (const {1, 4, 5, 7, 9, 10}.contains(h)) {
          add('INV-D4-01', 'D4', 'D4 చతుర్థాధిపతి కేంద్రం/త్రికోణం',
            '$fourth D4లో $hవ భావంలో — స్థిరాస్తి/పునాది పరిశీలన.',
            InvestmentEvidenceStatus.supportive);
        } else if (const {6, 8, 12}.contains(h)) {
          add('INV-D4-02', 'D4', 'D4 చతుర్థాధిపతి 6/8/12',
            '$fourth D4లో $hవ భావంలో — ఆస్తి సంబంధ జాగ్రత్త.',
            InvestmentEvidenceStatus.caution);
        } else {
          add('INV-D4-03', 'D4', 'D4 చతుర్థాధిపతి ఇతర భావంలో',
            '$fourth D4లో $hవ భావంలో — ఈ సాధారణ స్థానం ఆధారంగా '
            'అనుకూల/ప్రతికూల తీర్పు ఇవ్వలేదు.',
            InvestmentEvidenceStatus.neutral);
        }
      }
    }
    if (type == BusinessInvestmentType.vehicles ||
        type == BusinessInvestmentType.machinery) {
      final d16 = VargaService.calculate(chart, 16);
      final venusSign = _vPosition(d16, 'Venus');
      if (venusSign != null) {
        final h = houseOf(d16.ascendantSignIndex, venusSign);
        if (const {1, 4, 5, 7, 9, 10}.contains(h)) {
          add('INV-D16-01', 'D16', 'D16లో శుక్రుడు కేంద్రం/త్రికోణం',
            'శుక్రుడు D16లో $hవ భావంలో — వాహన సౌఖ్యానికి సహాయక ఆధారం.',
            InvestmentEvidenceStatus.supportive);
        } else if (const {6, 8, 12}.contains(h)) {
          add('INV-D16-02', 'D16', 'D16లో శుక్రుడు 6/8/12',
            'శుక్రుడు D16లో $hవ భావంలో — వాహన పెట్టుబడి విషయంలో జాగ్రత్త.',
            InvestmentEvidenceStatus.caution);
        } else {
          add('INV-D16-03', 'D16', 'D16లో శుక్రుడు ఇతర భావంలో',
            'శుక్రుడు D16లో $hవ భావంలో — వాహన పెట్టుబడికి '
            'వేరే ధృవీకరణ అవసరం.', InvestmentEvidenceStatus.neutral);
        }
      }
    }

    return BusinessInvestmentAudit(type: type, evidence: List.unmodifiable(result),
      evaluated: true, limitations: const [
        'దశాంశం D10 వృత్తి/నిర్వహణ ఆధారం; షోడశాంశం D16 వాహన/సౌఖ్య ఆధారం. '
        'D16తో సాధారణ వ్యాపార పెట్టుబడి లాభాన్ని నిర్ణయించరు.',
        'D1 భావాధిపతి సంబంధాలు, గురు–శని నెలవారీ కలయిక యాప్ రూపొందించిన '
        'విశ్లేషణ పద్ధతి; ఏ ఒక్క శ్లోకంలోని తుది పెట్టుబడి తీర్పు కాదు.',
        'ఇందు లగ్నం D1/చంద్ర స్థానాల నుంచే గణించబడుతుంది; '
        'దాన్ని స్వతంత్ర శాస్త్రీయ డేటా ధృవీకరణగా భావించకూడదు.',
        'సరిపోయిన నియమాల సంఖ్య వాస్తవ లాభ శాతం, విజయావకాశం, ROI కాదు.',
        'పెట్టుబడి నిర్ణయంలో నగదు ప్రవాహం, రుణభారం, లావాదేవీ ధర, నష్టాన్ని '
        'తట్టుకునే సామర్థ్యం విడిగా పరిశీలించాలి.',
      ]);
  }

  static Set<String> _lords(AstroChartResult chart, Set<int> houses) =>
      {for (final h in houses) _lord(chart.ascendantSignIndex, h)};

  /// A month is marked only when BOTH dasha levels and BOTH observed Jupiter
  /// and Saturn positions corroborate the SAME direction. These are month-15
  /// samples, not predictions that transactions occur on the 15th.
  static InvestmentTimeStatus? classifySample({
    required BusinessInvestmentAudit audit,
    required AstroChartResult chart,
    required String md,
    required String ad,
    required int guruSign,
    required int shaniSign,
  }) {
    if (!audit.evaluated || !audit.hasNatalSupport) return null;
    final goodHouses = switch (audit.type) {
      BusinessInvestmentType.property => <int>{2, 4, 9, 11},
      BusinessInvestmentType.vehicles => <int>{2, 4, 10, 11},
      BusinessInvestmentType.machinery => <int>{2, 4, 10, 11},
      BusinessInvestmentType.financial => <int>{2, 5, 9, 11},
      _ => <int>{2, 5, 9, 10, 11},
    };
    final good = _lords(chart, goodHouses);
    final bad = _lords(chart, {6, 8, 12});
    final overlap = good.intersection(bad);
    good.removeAll(overlap);
    bad.removeAll(overlap);
    final gTargets = <int>{for (final h in goodHouses)
      (chart.ascendantSignIndex + h - 1) % 12};
    final rTargets = <int>{for (final h in [6, 8, 12])
      (chart.ascendantSignIndex + h - 1) % 12};
    final propertySpecificDasha = audit.type != BusinessInvestmentType.property ||
      _lords(chart, {4, 9, 11}).contains(md) ||
      _lords(chart, {4, 9, 11}).contains(ad);
    final goodDasha = good.contains(md) && good.contains(ad) &&
      propertySpecificDasha;
    final badDasha = bad.contains(md) && bad.contains(ad);
    final goodTransit = D10VruttiActivationService.transitReachesCareerSign(
      'Jupiter', guruSign, gTargets) &&
      D10VruttiActivationService.transitReachesCareerSign(
        'Saturn', shaniSign, gTargets);
    final badTransit = D10VruttiActivationService.transitReachesCareerSign(
      'Jupiter', guruSign, rTargets) &&
      D10VruttiActivationService.transitReachesCareerSign(
        'Saturn', shaniSign, rTargets);
    final gain = goodDasha && goodTransit && audit.supportCount > 0;
    final risk = badDasha && badTransit && audit.cautionCount > 0;
    if (gain && risk) return InvestmentTimeStatus.mixed;
    if (gain) return audit.cautionCount > 0
        ? InvestmentTimeStatus.mixed : InvestmentTimeStatus.support;
    if (risk) return InvestmentTimeStatus.caution;
    return null;
  }

  static bool adjacent(BusinessInvestmentWindow previous, DateTime current,
      String md, String ad, InvestmentTimeStatus status) =>
      previous.end.year * 12 + previous.end.month + 1 ==
        current.year * 12 + current.month &&
      previous.mahadasha == md && previous.antardasha == ad &&
      previous.status == status;

  static Future<List<BusinessInvestmentWindow>> findWindows({
    required AstroChartResult chart,
    required BirthData birthData,
    required BusinessInvestmentType type,
    DateTime? referenceDate,
    int monthsBack = 12,
    int monthsAhead = 36,
  }) async {
    if (monthsBack < 0 || monthsAhead < 0 || monthsBack + monthsAhead > 180) {
      return const [];
    }
    final audit = evaluate(chart, type);
    if (!audit.hasNatalSupport) return const [];
    final dasha = DashaService.system(kind: DashaSystemKind.vimshottari,
      chart: chart, birthDateTime: birthData.localDateTime);
    final ref = referenceDate ?? DateTime.now();
    final output = <BusinessInvestmentWindow>[];
    for (var i = -monthsBack; i <= monthsAhead; i++) {
      final sample = DateTime(ref.year, ref.month + i, 15);
      if (sample.isBefore(birthData.localDateTime)) continue;
      final md = DashaService.periodAt(dasha.mahadashas, sample);
      if (md == null) continue;
      final ad = DashaService.periodAt(DashaService.subPeriodsFor(dasha, md), sample);
      if (ad == null) continue;
      final transit = await D10VruttiActivationService.transitAtMonth(
          birthData, sample);
      final status = classifySample(audit: audit, chart: chart,
          md: md.lord, ad: ad.lord, guruSign: transit.guru,
          shaniSign: transit.shani);
      if (status == null) continue;
      if (output.isNotEmpty && adjacent(output.last, sample,
          md.lord, ad.lord, status)) {
        output[output.length - 1] = output.last.through(sample);
      } else {
        output.add(BusinessInvestmentWindow(
          start: sample, end: sample, mahadasha: md.lord,
          antardasha: ad.lord, status: status, evidence: [
            'వింశోత్తరి: ${md.lord} మహాదశ / ${ad.lord} అంతర్దశ',
            'గురు రాశి ${transit.guru + 1}; శని రాశి ${transit.shani + 1}',
            'D1 + D2 / D10 / అవసరమైన D4 / D16 స్థిర ఆధారాల పరిశీలన',
            if (type == BusinessInvestmentType.property)
              'D2-PR-011: 4/9/11 భావాధిపతి దశా సంబంధం కూడా పరిశీలించాం '
              '(ధన–ఆస్తి మూల Rulebook, పేజీ 4).',
            'నెల 15న నమూనా మాత్రమే; నిజమైన కొనుగోలు తేదీ కాదు.',
          ],
        ));
      }
    }
    return List.unmodifiable(output);
  }
}
