import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'screens/birth_details_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AnnapurnaAstroVastuApp());
}

class _DesktopTabletScrollBehavior extends MaterialScrollBehavior {
  const _DesktopTabletScrollBehavior();

  @override
  Set<PointerDeviceKind> get dragDevices => const {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.stylus,
        PointerDeviceKind.invertedStylus,
        PointerDeviceKind.trackpad,
      };
}

class AnnapurnaAstroVastuApp extends StatelessWidget {
  const AnnapurnaAstroVastuApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF7B1E2B);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'అన్నపూర్ణ ఆస్ట్రో వాస్తు',
      scrollBehavior: const _DesktopTabletScrollBehavior(),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFFFFAF7),
        cardColor: Colors.white,
        canvasColor: Colors.white,
        dividerColor: const Color(0xFFE4D7D9),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          labelStyle: TextStyle(color: Color(0xFF6F3A43)),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF7B1E2B),
          foregroundColor: Colors.white,
        ),
      ),
      builder: (context, child) => _TraditionNotice(child: child ?? const SizedBox.shrink()),
      home: const BirthDetailsScreen(),
    );
  }
}

/// App-wide attribution and a single, dismissible interpretation notice.
/// Rule provenance and actual evidence remain the responsibility of each engine.
class _TraditionNotice extends StatefulWidget {
  const _TraditionNotice({required this.child});
  final Widget child;
  @override
  State<_TraditionNotice> createState() => _TraditionNoticeState();
}

class _TraditionNoticeState extends State<_TraditionNotice> {
  bool visible = true;
  bool _noticeLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadNotice();
  }

  Future<void> _loadNotice() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      visible = !(prefs.getBool('annapurna_notice_dismissed') ?? false);
      _noticeLoaded = true;
    });
  }

  Future<void> _dismissNotice() async {
    setState(() => visible = false);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('annapurna_notice_dismissed', true);
  }

  void _showNotice() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('జ్యోతిష్య వ్యాఖ్యాన సూచన'),
        content: const Text('సిద్ధాంతి మల్లికార్జున — జ్యోతిష్య నియమాల విశ్లేషణ. '
          'ఇవి సంప్రదాయ వ్యాఖ్యానాలు; శాస్త్రీయంగా నిరూపితమైన సంఘటన అంచనాలు కావు.'),
        actions: [TextButton(
          onPressed: () => Navigator.of(dialogContext).pop(),
          child: const Text('సరే'),
        )],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Column(children: [
    if (_noticeLoaded && visible)
      Material(
        color: const Color(0xFFFFF1D6),
        child: SafeArea(
          bottom: false,
          child: Row(children: [
            Expanded(child: InkWell(
              onTap: _showNotice,
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                child: Row(children: [
                  Icon(Icons.info_outline, size: 15, color: Color(0xFF60440D)),
                  SizedBox(width: 5),
                  Expanded(child: Text('జ్యోతిష్య సూచన · పూర్తి వివరాలు',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 11, color: Color(0xFF60440D)))),
                ]),
              ),
            )),
            IconButton(
              tooltip: 'సూచన మూసివేయండి',
              icon: const Icon(Icons.close, size: 17),
              constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
              padding: EdgeInsets.zero,
              onPressed: _dismissNotice,
            ),
          ]),
        ),
      ),
    Expanded(child: widget.child),
  ]);
}
