import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/d10_devata_audit_service.dart';
import '../astrology/d10_vrutti_match_engine.dart';

/// Separate explanatory evidence, without modifying rule-match percentages.
class D10DevataAuditPanel extends StatelessWidget {
  final AstroChartResult chart;
  final String? primaryPlanet;
  final bool primaryConfirmed;

  const D10DevataAuditPanel({
    super.key,
    required this.chart,
    this.primaryPlanet,
    this.primaryConfirmed = false,
  });

  static const _signs = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  String _planet(String name) =>
      D10VruttiMatchEngine.teluguPlanet[name] ?? name;
  String _devata(String name) =>
      D10VruttiMatchEngine.teluguDevata[name] ?? name;

  Widget _evidence(String title, D10PlanetDevataEvidence? item,
      {String? contextLabel}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      if (item == null)
        const Text('గ్రహ జనన రేఖాంశం అందుబాటులో లేదు — పరీక్ష పెండింగ్')
      else ...[
        Text('${_planet(item.planet)} → ${_devata(item.deity)}'
            ' · D1 ${item.d1House}వ భావం · D10 ${item.d10House}వ భావం'),
        Text('జనన రాశి ${_signs[item.natalSignIndex]} · '
            '${item.degreesInNatalSign.toStringAsFixed(2)}° · '
            '${item.division}వ దశాంశ భాగం',
            style: const TextStyle(fontSize: 12, color: Colors.black54)),
      ],
      if (contextLabel != null)
        Text(contextLabel, style: const TextStyle(fontSize: 12,
            color: Colors.black54)),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    final audit = D10DevataAuditService.evaluate(chart,
        primaryPlanet: primaryPlanet);
    return ExpansionTile(
      initiallyExpanded: primaryPlanet != null,
      tilePadding: EdgeInsets.zero,
      title: const Text('D10 అంశదేవతల జాతక పరిశీలన',
          style: TextStyle(fontWeight: FontWeight.w800)),
      subtitle: Text('D10 లగ్నం: ${_signs[audit.d10AscSign]} · '
          '10వ భావ రాశి: ${_signs[audit.d10TenthSign]}'),
      childrenPadding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
      children: [
        if (primaryPlanet != null)
          _evidence('1. వృత్తి ప్రధాన గ్రహం అంశదేవత', audit.principal,
              contextLabel: primaryConfirmed
                  ? 'ప్రధాన గ్రహ D1→D10 Confirm ఉంది. అంశదేవత ప్రత్యేక ఆధారం.'
                  : 'ప్రధాన గ్రహ D1→D10 Confirm లేదు; అంశదేవత వృత్తి నిర్ధారణ కాదు.'),
        _evidence('2. D10 లగ్నాధిపతి అంశదేవత', audit.lagnaLordEvidence,
            contextLabel: 'లగ్నాధిపతి: ${_planet(audit.lagnaLord)}'),
        _evidence('3. D10 10వ అధిపతి అంశదేవత', audit.tenthLordEvidence,
            contextLabel: 'దశమాధిపతి: ${_planet(audit.tenthLord)}'),
        const Divider(),
        const Text('పద్ధతి: జనన నిరయణ గ్రహరేఖాంశాన్ని రాశిలోని 3° '
            'భాగాలుగా విభజించి అంశదేవతను లెక్కిస్తాం. బేసి రాశులకు '
            'ముందుకు, సరి రాశులకు వెనుకకు దేవతల క్రమం. D10 10వ భావం '
            'ఒక రాశి మాత్రమే; దానికి ప్రత్యేక 3° దేవతను ఊహించము.',
            style: TextStyle(fontSize: 12)),
        const Text('ఈ మూడు ఆధారాలు వేర్వేరు. ఇవి ప్రస్తుత వృత్తి %ను, '
            'Confirmను, కాలనిర్ణయాన్ని స్వయంగా మార్చవు.',
            style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
        ExpansionTile(
          tilePadding: EdgeInsets.zero,
          title: const Text('అన్ని గ్రహాల అంశదేవతల వివరాలు'),
          children: [
            for (final p in audit.allPlanets)
              ListTile(dense: true,
                title: Text('${_planet(p.planet)} — ${_devata(p.deity)}'),
                subtitle: Text('D1 ${p.d1House} · D10 ${p.d10House} · '
                    '${p.division}వ దశాంశ భాగం'),
              ),
          ],
        ),
      ],
    );
  }
}
