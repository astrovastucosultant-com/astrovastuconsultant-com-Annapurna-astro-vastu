import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/business_investment_timing_service.dart';
import '../models/birth_data.dart';

class BusinessInvestmentTimingScreen extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  final BusinessInvestmentType initialType;

  const BusinessInvestmentTimingScreen({
    super.key,
    required this.chart,
    required this.birthData,
    this.initialType = BusinessInvestmentType.general,
  });

  @override
  State<BusinessInvestmentTimingScreen> createState() =>
      _BusinessInvestmentTimingScreenState();
}

class _BusinessInvestmentTimingScreenState
    extends State<BusinessInvestmentTimingScreen> {
  late BusinessInvestmentType selected = widget.initialType;
  late Future<List<BusinessInvestmentWindow>> future = _find();

  Future<List<BusinessInvestmentWindow>> _find() =>
      BusinessInvestmentTimingService.findWindows(
        chart: widget.chart, birthData: widget.birthData, type: selected);

  String _date(DateTime date) => '${date.month}/${date.year}';

  Color _evidenceColor(InvestmentEvidenceStatus status) => switch (status) {
    InvestmentEvidenceStatus.supportive => Colors.green.shade800,
    InvestmentEvidenceStatus.caution => Colors.deepOrange.shade800,
    InvestmentEvidenceStatus.neutral => Colors.blueGrey.shade700,
  };

  Color _windowColor(InvestmentTimeStatus status) => switch (status) {
    InvestmentTimeStatus.support => Colors.green.shade800,
    InvestmentTimeStatus.caution => Colors.deepOrange.shade800,
    InvestmentTimeStatus.mixed => Colors.blueGrey.shade700,
  };

  String _windowLabel(InvestmentTimeStatus status) => switch (status) {
    InvestmentTimeStatus.support => 'పెట్టుబడి కాలమద్దతు సూచన',
    InvestmentTimeStatus.caution => 'వ్యయ/ప్రమాద జాగ్రత్త సూచన',
    InvestmentTimeStatus.mixed => 'మిశ్రమ ఆధారాలు — ప్రత్యేక జాగ్రత్త',
  };

  @override
  Widget build(BuildContext context) {
    final audit = BusinessInvestmentTimingService.evaluate(
      widget.chart, selected);
    return Scaffold(
      appBar: AppBar(title: const Text('వ్యాపార పెట్టుబడి · కాల పరిశీలన')),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        const Text('Business Investment Timing',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        DropdownButtonFormField<BusinessInvestmentType>(
          value: selected,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'పెట్టుబడి రకం',
            border: OutlineInputBorder()),
          items: [for (final type in BusinessInvestmentType.values)
            DropdownMenuItem(value: type, child: Text(type.telugu))],
          onChanged: (value) {
            if (value == null || value == selected) return;
            setState(() {
              selected = value;
              future = _find();
            });
          },
        ),
        const SizedBox(height: 9),
        Text('పరిశీలన చక్రాలు: ${selected.chartScope}',
          style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Card(child: Padding(padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(audit.summary, style: const TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text(audit.evaluated
              ? 'అనుకూల నియమ ఆధారాలు ${audit.supportCount} · '
                'జాగ్రత్త నియమాలు ${audit.cautionCount} · '
                'అనుకూల ఆధారాల వర్గాలు ${audit.supportingCharts.length}'
              : 'ఆధారాలు పరీక్షించలేదు — 0 అని అర్థం కాదు'),
            const SizedBox(height: 6),
            const Text('సంఖ్యలు జ్యోతిష నియమాల సరిపోలికలు మాత్రమే; '
              'లాభ శాతం లేదా పెట్టుబడి తిరిగి వచ్చే మొత్తం కాదు.',
              style: TextStyle(fontSize: 12.5)),
          ]))),
        ExpansionTile(initiallyExpanded: true,
          title: const Text('ఫలితం టచ్ → జాతక పరిశీలన → నియమం → మూలం'),
          subtitle: const Text('D1, D2, D10; రకాన్ని బట్టి D4 / D16'),
          children: audit.evidence.isEmpty
            ? [const ListTile(title: Text('పరీక్షకు తగిన ఆధారాలు ఇంకా లేవు'))]
            : [for (final item in audit.evidence)
              ExpansionTile(
                leading: Icon(item.status == InvestmentEvidenceStatus.supportive
                  ? Icons.check_circle_outline
                  : Icons.warning_amber_rounded,
                  color: _evidenceColor(item.status)),
                title: Text('${item.sourceChart} · ${item.id}'),
                subtitle: Text(item.observation),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                children: [
                  Align(alignment: Alignment.centerLeft,
                    child: Text('IF ${item.condition}\nTHEN ${item.observation}\n'
                      'మూలం: ${item.source}')),
                ],
              )]),
        const SizedBox(height: 12),
        const Text('దశ–అంతర్దశ–గోచార కాలాలు',
          style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const Text('గత 12 నెలలు + రాబోయే 36 నెలలు. ప్రతి నెల 15న '
          'వింశోత్తరి మహాదశ, అంతర్దశ, గురు–శని నిరయణ గోచారాల నమూనా. '
          'జాతకంలో రెండు వేర్వేరు పరిశీలన మార్గాల మద్దతు, దశ, రెండు గోచారాలు '
          'కలిసినప్పుడు మాత్రమే కాల సూచన కనిపిస్తుంది.',
          style: TextStyle(height: 1.45)),
        if (!audit.hasNatalSupport)
          const Card(child: Padding(padding: EdgeInsets.all(12),
            child: Text('కాలనిర్ణయం ప్రకటించలేదు. ఇది అనుకూలం కాదని లేదా '
              'నష్టం ఖాయమని అర్థం కాదు; ఆధారాలు సరిపోలలేదు.')))
        else FutureBuilder<List<BusinessInvestmentWindow>>(
          key: ValueKey(selected), future: future,
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Text('కాల గణనలో సమస్య: ${snapshot.error}');
            }
            if (!snapshot.hasData) {
              return const ListTile(leading: CircularProgressIndicator(),
                title: Text('కాలమద్దతు పరిశీలిస్తోంది…'));
            }
            if (snapshot.data!.isEmpty) {
              return const Card(child: Padding(padding: EdgeInsets.all(12),
                child: Text('ఈ కాలపరిధిలో దశ–అంతర్దశ–గురు–శని కలయిక '
                  'మద్దతు గుర్తించలేదు. ఇది అననుకూల కాలం అని కాదు.')));
            }
            final now = DateTime.now();
            final past = snapshot.data!.where((w) =>
              w.end.year * 12 + w.end.month < now.year * 12 + now.month);
            final future = snapshot.data!.where((w) =>
              w.end.year * 12 + w.end.month >= now.year * 12 + now.month);
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (past.isNotEmpty) const Padding(
                padding: EdgeInsets.only(top: 12),
                child: Text('గత కాలమద్దతు (వాస్తవ సంఘటన Confirm కాదు)',
                  style: TextStyle(fontWeight: FontWeight.bold))),
              for (final window in past) _windowCard(window),
              if (future.isNotEmpty) const Padding(
                padding: EdgeInsets.only(top: 12),
                child: Text('ప్రస్తుత / రాబోయే పరిశీలన కాలాలు',
                  style: TextStyle(fontWeight: FontWeight.bold))),
              for (final window in future) _windowCard(window),
            ]);
          },
        ),
        const Divider(),
        const Text('శాస్త్ర ప్రమాణం మరియు పరిమితులు',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
        const Text('బృహత్ పరాశర హోరాశాస్త్రం 6వ అధ్యాయం: '
          'D2 (ధనం), D4 (స్థిరాస్తి), D10 (వృత్తి), D16 (వాహనం/సౌఖ్యం) '
          'వర్గాల గణన. ఈ పూర్తి Investment Timing ఫార్ములా '
          'మూలగ్రంథం నుంచి నేరుగా తీసుకున్న ఏకైక శ్లోకం కాదు.',
          style: TextStyle(height: 1.45)),
        for (final note in audit.limitations)
          Padding(padding: const EdgeInsets.symmetric(vertical: 5),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.info_outline, size: 18, color: Colors.blueGrey),
              const SizedBox(width: 6),
              Expanded(child: Text(note)),
            ])),
        const SizedBox(height: 20),
      ]),
    );
  }

  Widget _windowCard(BusinessInvestmentWindow window) =>
      Card(child: ExpansionTile(
        leading: Icon(Icons.calendar_month,
          color: _windowColor(window.status)),
        title: Text(_windowLabel(window.status),
          style: TextStyle(fontWeight: FontWeight.w700,
            color: _windowColor(window.status))),
        subtitle: Text('${_date(window.start)} – ${_date(window.end)} '
          '· ${window.months} నెలలు · ${window.mahadasha}/${window.antardasha}'),
        children: [for (final evidence in window.evidence)
          Padding(padding: const EdgeInsets.fromLTRB(12, 3, 12, 7),
            child: Align(alignment: Alignment.centerLeft,
              child: Text('• $evidence')))],
      ));
}
