import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../astrology/astro_models.dart';
import '../astrology/jaimini_service.dart';
import '../astrology/jaimini_complete_sutra_service.dart';

/// Dedicated, searchable 50-page Jaimini IF/THEN reference catalog.
/// All rules are visible; only explicitly implemented predicates may show a
/// chart match. Other source rules remain pending, never false confirmations.
class JaiminiCompleteSutraScreen extends StatefulWidget {
  final AstroChartResult chart;
  final JaiminiResult jaimini;

  const JaiminiCompleteSutraScreen({
    super.key,
    required this.chart,
    required this.jaimini,
  });

  @override
  State<JaiminiCompleteSutraScreen> createState() =>
      _JaiminiCompleteSutraScreenState();
}

class _JaiminiCompleteSutraScreenState extends State<JaiminiCompleteSutraScreen> {
  late final Future<List<JaiminiCompleteSutraRule>> _future;
  String _query = '';
  String _category = 'అన్ని అంశాలు';
  String _statusFilter = 'all';
  double? _minutesSinceLocalSunrise;
  final Map<String, JaiminiRuleCheck> _cachedChecks = {};
  final Set<String> _reviewedRuleIds = <String>{};
  bool _onlyUnchecked = false;
  bool _showAdvanced = false;
  bool _showChecklistDetails = false;
  bool _reviewReady = false;

  String get _reviewStorageKey => 'jaimini_review_v213_'
      '${widget.chart.julianDay.toStringAsFixed(6)}_'
      '${widget.chart.ascendantLongitude.toStringAsFixed(3)}';

  Future<void> _loadReviewChecklist() async {
    final key = _reviewStorageKey;
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList(key) ?? <String>[];
    if (!mounted || key != _reviewStorageKey) return;
    setState(() {
      _reviewedRuleIds
        ..clear()
        ..addAll(saved);
      _reviewReady = true;
    });
  }

  Future<void> _setRuleReviewed(String id, bool reviewed) async {
    setState(() {
      if (reviewed) {
        _reviewedRuleIds.add(id);
      } else {
        _reviewedRuleIds.remove(id);
      }
    });
    final key = _reviewStorageKey;
    final snapshot = _reviewedRuleIds.toList()..sort();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(key, snapshot);
  }


  @override
  void initState() {
    super.initState();
    _future = JaiminiCompleteSutraService.load();
    _loadReviewChecklist();
  }

  JaiminiRuleCheck _check(JaiminiCompleteSutraRule rule) =>
      _cachedChecks.putIfAbsent(rule.id, () =>
          JaiminiCompleteSutraService.check(
            rule: rule,
            chart: widget.chart,
            jaimini: widget.jaimini,
            minutesSinceLocalSunrise: _minutesSinceLocalSunrise,
          ));

  @override
  void didUpdateWidget(covariant JaiminiCompleteSutraScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.chart != widget.chart ||
        oldWidget.jaimini != widget.jaimini) {
      _cachedChecks.clear();
      _reviewedRuleIds.clear();
      _reviewReady = false;
      _loadReviewChecklist();
    }
  }

  void _showRule(JaiminiCompleteSutraRule rule, JaiminiRuleCheck audit) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (context) => DefaultTabController(
        length: 3,
        child: SafeArea(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.85,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 12),
                Center(child: Container(
                  height: 4, width: 44,
                  decoration: BoxDecoration(
                    color: const Color(0xFF806F73),
                    borderRadius: BorderRadius.circular(4),
                  ),
                )),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 4),
                  child: Text('JAI-${rule.id} · ${rule.section}',
                    maxLines: 3, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                ),
                const TabBar(
                  labelColor: Color(0xFF832E46),
                  tabs: [
                    Tab(text: 'ఫలితం'),
                    Tab(text: 'పరిశీలన'),
                    Tab(text: 'పరిహారం'),
                  ],
                ),
                Expanded(child: TabBarView(children: [
                  ListView(padding: const EdgeInsets.all(20), children: [
                    Text(_statusText(audit),
                      style: TextStyle(fontWeight: FontWeight.w800,
                        color: _statusColor(audit), fontSize: 16)),
                    const SizedBox(height: 18),
                    if (audit.matched == true && !audit.calculated) ...[
                      const Text('ప్రాథమిక షరతుకు సంబంధించిన సాధ్యమైన ఫలితం',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 8),
                      Text(rule.result, style: const TextStyle(height: 1.55, fontSize: 17)),
                      const SizedBox(height: 12),
                      const Text('ఇది ప్రాథమిక షరతు సరిపోలిక మాత్రమే. ఇతర సూచికలు, దృష్టి, '
                          'బలం, దశలు పరిశీలించకుండా ఖచ్చితంగా జరిగే ఫలితంగా చెప్పరాదు.',
                        style: TextStyle(color: Color(0xFF226847), height: 1.45)),
                    ] else if (audit.calculated) ...[
                      const Text('జాతకం నుంచి లభించిన గణన',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 8),
                      Text(audit.evidence, style: const TextStyle(height: 1.55)),
                      const SizedBox(height: 12),
                      const Text('గణన లభించింది; ఇది సంఘటన లేదా శుభ/అశుభ ఫలిత నిర్ధారణ కాదు.',
                        style: TextStyle(color: Color(0xFF316D87))),
                    ] else if (audit.matched == false) ...[
                      const Text('పరీక్షించిన షరతు ఈ జాతకానికి సరిపోలలేదు.',
                        style: TextStyle(color: Color(0xFF92505C),
                          fontWeight: FontWeight.w700, height: 1.5)),
                      const SizedBox(height: 8),
                      const Text('కాబట్టి మూలగ్రంథంలోని THEN ఫలితాన్ని జాతక ఫలితంగా చూపించడం లేదు. '
                          'ఇతర ప్రత్యామ్నాయ శాఖలు పూర్తిగా పరీక్షించకపోతే ఇంకా నిర్ణయం పెండింగ్ ఉండవచ్చు.',
                        style: TextStyle(height: 1.5)),
                    ] else ...[
                      const Text('వ్యక్తిగత ఫలితాన్ని ఇంకా గణించలేదు.',
                        style: TextStyle(fontWeight: FontWeight.bold, height: 1.5)),
                      const SizedBox(height: 8),
                      const Text('పరిశీలన ట్యాబ్‌లో ఆ జాతకానికి లభించిన ప్రాథమిక ఆధారాలు, '
                          'మూల IF, ఇంకా కావలసిన పరీక్షలు చూడండి. '
                          'పెండింగ్ నియమానికి గ్రీన్/పింక్ లేదా కల్పిత % ఇవ్వము.',
                        style: TextStyle(height: 1.5)),
                    ],
                  ]),
                  ListView(padding: const EdgeInsets.all(20), children: [
                    const Text('జాతక పరిశీలన',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                    const SizedBox(height: 10),
                    Text(audit.evidence, style: const TextStyle(height: 1.55)),
                    const SizedBox(height: 18),
                    const Text('PDFలోని మూల IF–THEN నియమం',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text('IF: ${rule.condition}',
                      style: const TextStyle(height: 1.5)),
                    const SizedBox(height: 10),
                    Text('THEN (గ్రంథంలోని ఫలితం): ${rule.result}',
                      style: const TextStyle(height: 1.5)),
                    const SizedBox(height: 10),
                    const Text('గ్రంథంలోని THEN అంటే ఈ జాతకంలో అది తప్పకుండా సంభవించిందని కాదు.',
                      style: TextStyle(color: Color(0xFF855E21), height: 1.45)),
                    const SizedBox(height: 20),
                    const Text('మూల ప్రమాణం',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text('అధ్యాయం.పాదం.సూత్రం (PDF సూచిక): ${rule.source}'),
                    Text('అంశం: ${rule.major}'),
                    Text('విభాగం: ${rule.section}'),
                    Text('అందించిన PDF పేజీ: ${rule.page} / 50'),
                    Text('వర్గం: ${rule.sourceKind}'),
                    const SizedBox(height: 14),
                    const Text('ఈ PDF తెలుగు IF–THEN సమాహారం. అసలు సంస్కృత '
                        'శ్లోకం, వ్యాఖ్యాన భేదాల స్వతంత్ర ధృవీకరణ ఇంకా పెండింగ్.',
                        style: TextStyle(color: Color(0xFF7B5A35))),
                  ]),
                  ListView(padding: const EdgeInsets.all(20), children: const [
                    Text('పరిహారం / మూలం',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                    SizedBox(height: 10),
                    Text('మీరు ఇచ్చిన 50 పేజీల జైమిని IF–THEN PDFలో '
                         'ఈ నియమానికి ప్రత్యేకంగా ధృవీకరించిన పరిహారం ఇవ్వలేదు. '
                         'అందువల్ల కల్పిత మంత్రం, పూజ లేదా రత్న పరిహారం ఇవ్వడం లేదు.',
                         style: TextStyle(height: 1.5)),
                    SizedBox(height: 12),
                    Text('ప్రత్యేక పరిహార మూలగ్రంథం అనుసంధానించినప్పుడు '
                         'మూలం, షరతు, పరిహార విధానం చూపించవచ్చు.',
                         style: TextStyle(height: 1.5)),
                  ]),
                ])),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _statusText(JaiminiRuleCheck check) =>
      check.calculated ? 'గణన / ఆధార పరిశీలన మాత్రమే · తుది ఫలితం కాదు' :
      check.matched == null ? 'పూర్తి షరతుల పరిశీలన పెండింగ్' :
      check.matched! ? 'పరీక్షించిన ప్రాథమిక షరతు సరిపోయింది · తుది ఫలితం కాదు' :
      'పరీక్షించిన షరతు సరిపోలేదు · ఇతర సూచికలు వేరుగా పరిశీలించాలి';

  Color _statusColor(JaiminiRuleCheck check) =>
      check.calculated ? const Color(0xFF316D87) :
      check.matched == null ? const Color(0xFF806356) :
      check.matched! ? const Color(0xFF117349) :
      const Color(0xFF92505C);

  String _shortStatus(JaiminiRuleCheck check) =>
      check.calculated ? 'గణన మాత్రమే' :
      check.matched == true ? 'ప్రాథమిక షరతు సరిపోయింది' :
      check.matched == false ? 'పరీక్షించిన షరతు సరిపోలలేదు' :
      'పూర్తి పరిశీలన పెండింగ్';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('జైమిని సంపూర్ణ నియమాలు')),
      body: FutureBuilder<List<JaiminiCompleteSutraRule>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text(
            'నియమాల జాబితాను తెరవలేకపోయాం: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final all = snapshot.data!;
          final categories = ['అన్ని అంశాలు',
            ...{for (final rule in all) rule.major}];
          final q = _query.trim().toLowerCase();
          final filtered = all.where((rule) {
            if (_category != 'అన్ని అంశాలు' && rule.major != _category) return false;
            if (q.isNotEmpty && !('${rule.id} ${rule.major} '
                 '${rule.section} ${rule.condition} ${rule.result} ${rule.source}')
                   .toLowerCase().contains(q)) return false;
            final check = _check(rule);
            if (_onlyUnchecked && _reviewedRuleIds.contains(rule.id)) return false;
            switch (_statusFilter) {
              case 'matched':
                if (check.calculated || check.matched != true) return false;
                break;
              case 'notMatched':
                if (check.calculated || check.matched != false) return false;
                break;
              case 'calculated':
                if (!check.calculated) return false;
                break;
              case 'pending':
                if (check.calculated || check.matched != null) return false;
                break;
            }
            return true;
          }).toList(growable: false);
          int displayRank(JaiminiRuleCheck c) {
            if (c.matched == true && !c.calculated) return 0; // green first
            if (c.matched == false && !c.calculated) return 1; // pink next
            if (c.calculated) return 2; // calculations
            return 3; // pending
          }
          filtered.sort((a, b) {
            final first = displayRank(_check(a)).compareTo(displayRank(_check(b)));
            if (first != 0) return first;
            final aKey = a.id.split('.').map((n) => int.tryParse(n) ?? 0).toList();
            final bKey = b.id.split('.').map((n) => int.tryParse(n) ?? 0).toList();
            for (var i = 0; i < aKey.length && i < bKey.length; i++) {
              final d = aKey[i].compareTo(bKey[i]);
              if (d != 0) return d;
            }
            return a.id.compareTo(b.id);
          });
          final checks = {for (final r in all) r.id: _check(r)};
          final matchedCount = checks.values.where((c) => c.matched == true && !c.calculated).length;
          final notMatchedCount = checks.values.where((c) => c.matched == false && !c.calculated).length;
          final calculatedCount = checks.values.where((c) => c.calculated).length;
          final pendingCount = all.length - matchedCount - notMatchedCount - calculatedCount;
          final reviewedCount = all.where((r) => _reviewedRuleIds.contains(r.id)).length;
          final reviewPercent = all.isEmpty ? 0 : (reviewedCount * 100 / all.length).round();
          final reviewedMatches = all.where((r) =>
            _reviewedRuleIds.contains(r.id) && _check(r).matched == true && !_check(r).calculated).length;
          final reviewedNonMatches = all.where((r) =>
            _reviewedRuleIds.contains(r.id) && _check(r).matched == false && !_check(r).calculated).length;
          // Compact layout: the results list receives the remaining viewport.
          // Filters and long explanations are deliberately hidden until requested.
          Widget statusChip(String status, String text, Color color) {
            final selected = _statusFilter == status;
            return Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ChoiceChip(
                label: Text(text, style: TextStyle(
                  fontSize: 12, fontWeight: FontWeight.w700,
                  color: selected ? color : const Color(0xFF514448),
                )),
                selected: selected,
                showCheckmark: false,
                visualDensity: VisualDensity.compact,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                side: BorderSide(color: selected ? color : const Color(0xFFE0DADB)),
                selectedColor: color.withAlpha(30),
                backgroundColor: Colors.white,
                onSelected: (_) => setState(() => _statusFilter = status),
              ),
            );
          }

          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 0),
              child: Row(children: [
                Expanded(child: SizedBox(
                  height: 46,
                  child: TextField(
                    onChanged: (text) => setState(() => _query = text),
                    decoration: const InputDecoration(
                      isDense: true,
                      contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 6),
                      prefixIcon: Icon(Icons.search, size: 21),
                      hintText: 'అంశం / గ్రహం / ఫలితం వెతకండి',
                      hintStyle: TextStyle(fontSize: 13),
                      border: OutlineInputBorder(),
                    ),
                  ),
                )),
                IconButton(
                  tooltip: _showAdvanced ? 'అదనపు ఫిల్టర్లు మూసివేయండి' : 'అంశాలు / సూర్యోదయ ఫిల్టర్లు',
                  icon: Icon(_showAdvanced ? Icons.tune : Icons.filter_list),
                  onPressed: () => setState(() => _showAdvanced = !_showAdvanced),
                ),
              ]),
            ),
            // Horizontal status filters always take ONE row, even on small phones.
            SizedBox(
              height: 43,
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                scrollDirection: Axis.horizontal,
                children: [
                  statusChip('all', 'అన్ని ${all.length}', const Color(0xFF713C48)),
                  statusChip('matched', '✓ గ్రీన్ $matchedCount', const Color(0xFF117349)),
                  statusChip('notMatched', '× పింక్ $notMatchedCount', const Color(0xFFAA4866)),
                  statusChip('calculated', 'గణన $calculatedCount', const Color(0xFF316D87)),
                  statusChip('pending', 'పెండింగ్ $pendingCount', const Color(0xFF806356)),
                ],
              ),
            ),
            if (_showAdvanced)
              ConstrainedBox(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.sizeOf(context).height * 0.34,
                ),
                child: SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
                    child: Column(children: [
                      DropdownButtonFormField<String>(
                        value: _category,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'అంశాలవారీ విభాగం',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                        items: categories.map((name) => DropdownMenuItem(
                          value: name,
                          child: Text(name, overflow: TextOverflow.ellipsis),
                        )).toList(),
                        onChanged: (v) => setState(() => _category = v ?? 'అన్ని అంశాలు'),
                      ),
                      SwitchListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        title: const Text('చెక్ చేయనివి మాత్రమే చూపించు',
                          style: TextStyle(fontSize: 13)),
                        value: _onlyUnchecked,
                        onChanged: (value) => setState(() => _onlyUnchecked = value),
                      ),
                      TextField(
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'సూర్యోదయం తర్వాత నిమిషాలు (ఐచ్ఛికం)',
                          hintText: 'ఉదా: 180',
                          isDense: true,
                        ),
                        onChanged: (raw) {
                          final parsed = double.tryParse(raw.trim());
                          final valid = parsed != null && parsed.isFinite &&
                            parsed >= 0 && parsed < 1440 ? parsed : null;
                          setState(() {
                            _minutesSinceLocalSunrise = valid;
                            _cachedChecks.clear();
                          });
                        },
                      ),
                      const SizedBox(height: 8),
                      const Text('సూర్యోదయ నిమిషాలు జన్మస్థలానికి వర్తించాలి; ఊహించి ఇవ్వవద్దు. '
                        'అవి లేకపోతే కొన్ని ప్రత్యేక లగ్నాల గణనలు పెండింగ్‌లో ఉంటాయి.',
                        style: TextStyle(fontSize: 11, height: 1.3)),
                    ]),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 2, 10, 3),
              child: Material(
                color: const Color(0xFFF8F0F1),
                borderRadius: BorderRadius.circular(8),
                child: InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => setState(() =>
                    _showChecklistDetails = !_showChecklistDetails),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        const Icon(Icons.fact_check_outlined, size: 18,
                          color: Color(0xFF803F50)),
                        const SizedBox(width: 7),
                        Expanded(child: Text(
                          'చెక్‌లిస్ట్ $reviewedCount/${all.length} · $reviewPercent%   |   చూపిస్తున్నవి ${filtered.length}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
                        )),
                        TextButton(
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(horizontal: 5),
                            minimumSize: const Size(0, 28),
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                          onPressed: () => setState(() =>
                              _statusFilter = _statusFilter == 'pending' ? 'all' : 'pending'),
                          child: Text('పెండింగ్ $pendingCount',
                            style: const TextStyle(fontSize: 11,
                              fontWeight: FontWeight.w800, color: Color(0xFF714E39))),
                        ),
                        Icon(_showChecklistDetails ? Icons.expand_less : Icons.expand_more,
                          size: 20, color: const Color(0xFF803F50)),
                      ]),
                      const SizedBox(height: 4),
                      LinearProgressIndicator(
                        value: all.isEmpty ? 0 : reviewedCount / all.length,
                        minHeight: 3,
                        backgroundColor: const Color(0xFFE7E0E1),
                        color: const Color(0xFF237349),
                      ),
                      if (_showChecklistDetails) ...[
                        const SizedBox(height: 8),
                        Text('ఆకుపచ్చ: $reviewedMatches/$matchedCount పరిశీలించారు · '
                          'పింక్: $reviewedNonMatches/$notMatchedCount పరిశీలించారు · '
                          'పెండింగ్: ${all.where((r) =>
                            _reviewedRuleIds.contains(r.id) &&
                            _check(r).matched == null && !_check(r).calculated).length}/$pendingCount',
                          style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 5),
                        const Text('పెండింగ్ సంఖ్యను నొక్కితే షరతులు పూర్తిగా పరీక్షించాల్సిన '
                            'నియమాల పని వరుస తెరుచుకుంటుంది. టిక్ పెట్టడం = చదివినట్లు; '
                            'వర్తించినట్లు కాదు.', style: TextStyle(fontSize: 11)),
                        const SizedBox(height: 5),
                        const Text('ఈ శాతం చదివి చెక్ పెట్టిన నియమాల పురోగతి మాత్రమే. '
                          'జాతక ఫలితం సంభవించే సంభావ్యత కాదు. '
                          '✓/× గుర్తులు ప్రాథమిక షరతు పరీక్షకు మాత్రమే.',
                          style: TextStyle(fontSize: 11, height: 1.4)),
                      ],
                    ]),
                  ),
                ),
              ),
            ),
            // Initial viewport now displays the actual rule cards immediately.
            Expanded(child: ListView.builder(
              padding: const EdgeInsets.only(bottom: 16),
              itemCount: filtered.length,
              itemBuilder: (context, index) {
                final rule = filtered[index];
                final check = _check(rule);
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                  decoration: BoxDecoration(
                    color: check.calculated ? const Color(0xFFF1F6F8) :
                      check.matched == true ? const Color(0xFFE9F7EE) :
                      check.matched == false ? const Color(0xFFFCECF2) :
                      const Color(0xFFF5F4F2),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: ListTile(
                    dense: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2),
                    leading: Icon(
                      check.calculated ? Icons.calculate_outlined :
                      check.matched == true ? Icons.check_circle_outline :
                      check.matched == false ? Icons.cancel_outlined : Icons.menu_book_outlined,
                      color: _statusColor(check),
                    ),
                    title: Text('JAI-${rule.id} · ${rule.section}',
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                    subtitle: Text(
                      check.matched == null && !check.calculated
                        ? 'IF: ${rule.condition}\nపరిశీలనలో ఉంది · PDF ${rule.page}'
                        : '${check.matched == false ? 'IF: ${rule.condition}' : rule.result}\n'
                          '${_shortStatus(check)} · PDF ${rule.page}',
                      maxLines: 3, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, height: 1.35)),
                    isThreeLine: true,
                    trailing: Tooltip(
                      message: 'నియమాన్ని చదివినట్లు చెక్ చేయండి',
                      child: Checkbox(
                        value: _reviewedRuleIds.contains(rule.id),
                        onChanged: !_reviewReady ? null : (value) {
                          _setRuleReviewed(rule.id, value ?? false);
                        },
                      ),
                    ),
                    onTap: () => _showRule(rule, check),
                  ),
                );
              },
            )),
          ]);
        },
      ),
    );
  }
}
