import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/d10_career_profit_loss_service.dart';
import '../astrology/d10_vrutti_match_engine.dart';
import '../models/birth_data.dart';

class D10CareerProfitLossScreen extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  final D10VruttiMatch match;
  const D10CareerProfitLossScreen({super.key, required this.chart,
    required this.birthData, required this.match});

  @override
  State<D10CareerProfitLossScreen> createState() =>
      _D10CareerProfitLossScreenState();
}

class _D10CareerProfitLossScreenState extends State<D10CareerProfitLossScreen> {
  late final D10MoneyAudit audit = D10CareerProfitLossService.evaluate(
      widget.chart, widget.match);
  late final Future<List<D10MoneyWindow>> timeline =
      D10CareerProfitLossService.findMonthlyWindows(
        chart: widget.chart, birthData: widget.birthData, match: widget.match);

  Color _toneColor(D10MoneyTone tone) => switch (tone) {
    D10MoneyTone.gain => Colors.green.shade800,
    D10MoneyTone.risk => Colors.red.shade800,
    D10MoneyTone.mixed => Colors.deepOrange.shade800,
    D10MoneyTone.insufficient => Colors.blueGrey.shade700,
  };

  String _date(DateTime date) => '${date.month}/${date.year}';

  Widget _auditRow(String text, IconData icon, Color color) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color, size: 21),
      const SizedBox(width: 9),
      Expanded(child: Text(text, style: const TextStyle(height: 1.45))),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    return Scaffold(
      appBar: AppBar(title: const Text('D10 · వృత్తి లాభనష్ట పరిశీలన')),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        Text('${widget.match.rule.id} · ${widget.match.rule.profession}',
          style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        Card(child: Padding(padding: const EdgeInsets.all(14), child:
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.match.confirmationLabel,
              style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(audit.tone.label,
              style: TextStyle(color: _toneColor(audit.tone),
                fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            if (audit.evaluated)
              Text('లాభ ఆధారాలు ${audit.gainSupport} · వ్యయ/నష్ట ప్రమాద ఆధారాలు ${audit.riskSupport}')
            else
              const Text('లాభ / నష్ట ఆధారాలు: పరీక్షించలేదు (0 కాదు)',
                style: TextStyle(fontWeight: FontWeight.w700)),
            const Text('ఈ సంఖ్యలు మూల సంబంధాల లెక్క మాత్రమే; వృత్తి అనుకూలత % లేదా నిజమైన ఆదాయ అంచనా కాదు.',
              style: TextStyle(fontSize: 12.5)),
          ]))),
        ExpansionTile(initiallyExpanded: true,
          title: const Text('లాభానికి సంబంధించిన జాతక పరిశీలన'),
          children: audit.gains.isEmpty
            ? [ListTile(title: Text(audit.evaluated
                ? 'పరీక్షించగా ప్రత్యేక లాభ ఆధారం గుర్తించలేదు'
                : 'వృత్తి Confirm పూర్తి కాలేదు — లాభ పరీక్ష ఇంకా నిర్వహించలేదు'))]
            : [for (final e in audit.gains)
              _auditRow(e, Icons.trending_up, Colors.green.shade800)]),
        ExpansionTile(initiallyExpanded: true,
          title: const Text('వ్యయ / నష్ట ప్రమాద సూచనల పరిశీలన'),
          children: audit.risks.isEmpty
            ? [ListTile(title: Text(audit.evaluated
                ? 'పరీక్షించగా ప్రత్యేక వ్యయ/నష్ట ఆధారం గుర్తించలేదు'
                : 'వృత్తి Confirm పూర్తి కాలేదు — నష్ట పరీక్ష ఇంకా నిర్వహించలేదు'))]
            : [for (final e in audit.risks)
              _auditRow(e, Icons.warning_amber_rounded, Colors.deepOrange)]),
        if (!audit.evaluated) Card(
          child: Padding(padding: const EdgeInsets.all(12), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('వృత్తి IF–THEN పరిశీలన సారాంశం',
                style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Text('సరిపోయిన ఉపషరతులు ${widget.match.passed.length} · '
                'సరిపోనివి ${widget.match.failed.length} · '
                'పెండింగ్ ${widget.match.pending.length}'),
              const Text('కొన్ని ఉపషరతులు సరిపోవడం మాత్రమే వృత్తి Confirm కాదు.',
                style: TextStyle(fontSize: 12.5)),
            ],
          )),
        ),
        const Divider(),
        const Text('దశ–అంతర్దశ–గోచారం: నెలవారీ కాల ఆధారాలు',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('గత 12 నెలలు + రాబోయే 36 నెలలు. ప్రతి నెల 15న గురు, శని రాశులను పరిశీలిస్తాం. '
            'దశ, అంతర్దశ మరియు రెండు గోచార సంబంధాలు కలిసిన నెలలకే దిశాసూచన; '
            'మిగిలిన నెలలకు తీర్పు లేదు.',
            style: TextStyle(height: 1.45)),
        if (audit.tone == D10MoneyTone.insufficient)
          Card(child: Padding(padding: const EdgeInsets.all(12),
            child: Text(audit.evaluated
              ? 'లాభ/నష్ట సంబంధాలను పరీక్షించాం. కానీ ఫలితానికి సరిపడే ఆధారాలు గుర్తించలేదు. కాలఫలితం ప్రకటించము.'
              : 'ప్రధాన గ్రహ Confirm ఉన్నా పూర్తి IF–THEN సరిపోలకపోవచ్చు. '
                  'అందువల్ల ఈ వృత్తి-ప్రత్యేక లాభనష్ట గణన ప్రారంభం కాలేదు. '
                  'ఇది 0% లాభం లేదా నష్టం అని అర్థం కాదు.')))
        else FutureBuilder<List<D10MoneyWindow>>(
          future: timeline,
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Padding(padding: const EdgeInsets.all(12),
                child: Text('కాల గణనలో సమస్య: ${snapshot.error}'));
            }
            if (!snapshot.hasData) {
              return const ListTile(leading: CircularProgressIndicator(),
                title: Text('దశ–అంతర్దశ మరియు గురు–శని గోచారం గణిస్తోంది…'));
            }
            final windows = snapshot.data!;
            final years = <int>[for (var year = now.year - 1;
              year <= now.year + 3; year++) year];
            return Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [for (final year in years) ...[
                Padding(padding: const EdgeInsets.fromLTRB(2, 18, 2, 7),
                  child: Text('$year · కాల విభాగాలు',
                    style: const TextStyle(fontSize: 16,
                      fontWeight: FontWeight.bold))),
                if (!windows.any((w) => w.start.year <= year && w.end.year >= year))
                  const Card(child: ListTile(
                    leading: Icon(Icons.info_outline, color: Colors.blueGrey),
                    title: Text('ఆ సంవత్సరానికి మూడు కాల ఆధారాలు కలిసిన నెల గుర్తించలేదు'),
                    subtitle: Text('దీనిని లాభం/నష్టం/మధ్యస్థ ఫలితంగా పరిగణించవద్దు.'))),
                for (final w in windows.where((w) =>
                    w.start.year <= year && w.end.year >= year))
                  Card(child: ExpansionTile(
                    leading: Icon(w.tone == D10MoneyTone.gain
                        ? Icons.trending_up
                        : w.tone == D10MoneyTone.risk
                            ? Icons.trending_down : Icons.compare_arrows,
                      color: _toneColor(w.tone)),
                    title: Text('${w.phase} · వయసు సుమారు ${w.age}',
                      style: TextStyle(color: _toneColor(w.tone),
                        fontWeight: FontWeight.w700)),
                    subtitle: Text('${_date(w.start)} – ${_date(w.end)} · '
                        '${w.mahadasha}/${w.antardasha}'),
                    children: [for (final line in w.evidence)
                      Padding(padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 5), child: Text('• $line'))],
                  )),
              ]]);
          },
        ),
        const Divider(),
        const Text('IF–THEN మూల వృత్తి నియమం',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        SelectableText('IF ${widget.match.rule.condition}\n'
            'THEN ${widget.match.rule.profession}\n'
            '${widget.match.rule.source} · పేజీ ${widget.match.rule.page}'),
        const SizedBox(height: 8),
        for (final note in audit.limitations)
          _auditRow(note, Icons.info_outline, Colors.blueGrey),
        const Text('ఇది మూల D10 వృత్తి నియమాలపై అదనంగా అమర్చిన జ్యోతిష ఆధార-పరిశీలన నమూనా. '
            'వాస్తవ లాభనష్టం అంచనా, ఆర్థిక సలహా లేదా శాస్త్రీయంగా నిర్ధారిత సంభావ్యత కాదు.',
          style: TextStyle(fontSize: 12.5)),
        const SizedBox(height: 24),
      ]),
    );
  }
}
