import 'package:flutter/material.dart';
import '../astrology/d10_livelihood_crosscheck_service.dart';
import '../astrology/d10_vrutti_match_engine.dart';

/// An explanatory D1->D9->D10 audit, not a replacement for the existing
/// 517 occupation rules, confirmation %, or timing engine.
class D10LivelihoodCrossCheckPanel extends StatelessWidget {
  final D10LivelihoodCrossCheck audit;
  final D10VruttiMatch? match;
  const D10LivelihoodCrossCheckPanel({super.key, required this.audit, this.match});

  String _planet(String value) =>
      D10LivelihoodCrossCheckService.teluguPlanet[value] ?? value;
  String _sign(int value) => D10LivelihoodCrossCheckService.teluguSign[value % 12];

  @override
  Widget build(BuildContext context) {
    final comparison = match == null ? null : audit.compare(
      rule: match!.rule,
      primaryPlanetConfirmed: match!.primaryPlanetConfirmed,
      fullRuleMatched: match!.fullRuleMatched,
    );
    return Card(
      child: ExpansionTile(
        initiallyExpanded: match != null,
        title: const Text('D1 → D9 → D10 · వృత్తి మూలాధారాల పరిశీలన',
          style: TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('ఫలదీపిక 5.1 / బృహజ్జాతకం 10 · ${audit.channels.length} ఆధారాలు · స్వతంత్ర Cross-check'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 4, 12, 14),
        children: [
          const Text('లగ్నం, చంద్రుడు, సూర్యుడు నుంచి పదో రాశి అధిపతి → '
              'అతను D9లో ఉన్న రాశి → ఆ నవాంశ రాశి అధిపతి ద్వారా జీవనోపాధి రంగం.',
              style: TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 7),
          for (final channel in audit.channels) ...[
            Container(
              width: double.infinity,
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerLow,
                borderRadius: BorderRadius.circular(9),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${channel.reference} నుంచి 10వ రాశి: ${_sign(channel.tenthSign)}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                Text('D1 దశమాధిపతి: ${_planet(channel.natalTenthLord)} '
                    '(D1 ${channel.natalTenthLordHouse}వ భావం)'),
                Text('ఆ దశమాధిపతి D9లో: ${_sign(channel.navamsaSign)} '
                    '(D9 ${channel.navamsaTenthLordHouse}వ భావం)'),
                Text('D9 నవాంశ రాశి అధిపతి: ${_planet(channel.navamsaLord)}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                Text('గ్రంథంలోని జీవనోపాధి రంగాలు: ${channel.livelihoodFields}'),
                Text('ఆ D1 దశమాధిపతి D10లో: ${channel.dashamsaTenthLordHouse}వ భావం '
                    '· D10 1/10/10వ అధిపతి సంబంధం: '
                    '${channel.dashamsaCareerAxisLinked ? 'ఉంది' : 'గుర్తించలేదు'}',
                    style: const TextStyle(fontSize: 12)),
              ]),
            ),
          ],
          if (audit.recurringNavamsaLords.isNotEmpty)
            Text('ఒకటికంటే ఎక్కువ మార్గాల్లో అదే నవాంశాధిపతి: '
                '${audit.recurringNavamsaLords.map(_planet).join(', ')}. '
                'ఇది ఒకే గ్రహం నుంచి పునరావృతమైతే స్వతంత్ర ఆధారాల సంఖ్య పెరగదు.',
                style: const TextStyle(fontWeight: FontWeight.w600)),
          if (audit.channels.isEmpty)
            const Text('గ్రహ రేఖాంశాలు అందుబాటులో లేవు. వృత్తి రంగాన్ని ఊహించలేదు.'),
          if (comparison != null) ...[
            const Divider(),
            Text('ఈ IF–THEN రూల్‌తో స్వతంత్ర D9 పరిశీలన',
                style: Theme.of(context).textTheme.titleSmall),
            Text(!comparison.eligibleForIndividualVerdict
                ? 'D1→D10 ప్రధాన గ్రహ Confirm లేదు — వృత్తి పేరు వ్యక్తిగత తీర్పుగా ఇవ్వవద్దు.'
                : comparison.fullD10RuleMatched
                    ? 'D10 పూర్తి IF–THEN సరిపోయింది; D9 ఆధారం విడిగా చూపిస్తున్నాం.'
                    : 'D10 ప్రధాన గ్రహ Confirm ఉంది; పూర్తి IF–THEN ఇంకా అసంపూర్తి.'),
            Text(comparison.hasDirectPlanetCorrespondence
                ? 'D9 నవాంశాధిపతి మూల రూల్ గ్రహాలతో నేరుగా సరిపోయిన ఆధారాలు: '
                    '${comparison.linkedReferences.join(', ')}'
                : 'D9 నవాంశాధిపతి మూల రూల్ గ్రహాలతో నేరుగా ఒకటి కాలేదు. '
                    'దీనిని వ్యతిరేక తీర్పుగా పరిగణించవద్దు.'),
            if (comparison.independentReferences.isNotEmpty)
              Text('స్వతంత్రంగా పరిశీలించాల్సినవి: '
                  '${comparison.independentReferences.join(', ')}',
                  style: const TextStyle(fontSize: 12)),
          ],
          const Divider(),
          const Text('గమనిక: లగ్నం/చంద్రుడు/సూర్యుడిలో అత్యంత బలమైనది ఏదో '
              'పూర్తి బలగణన లేకుండా ఎంపిక చేయలేదు. ఈ మూడు ఫలితాలకు సమాన '
              'వెయిట్లు/శాతాలు ఇవ్వలేదు. D9 నవాంశాధిపతి మరియు D10 Confirm '
              'గ్రహం ఒకటే కావాల్సిన అవసరం లేదు. ఆధునిక ఉద్యోగం/స్థాయి, '
              'నియామక తేదీని ఈ గ్రంథ సూత్రం ఒక్కటితో ప్రకటించలేం.',
              style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}
