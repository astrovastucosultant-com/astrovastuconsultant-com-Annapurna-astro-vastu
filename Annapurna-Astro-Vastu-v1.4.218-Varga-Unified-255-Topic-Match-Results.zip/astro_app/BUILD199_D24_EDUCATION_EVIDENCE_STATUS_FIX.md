# v1.4.199 — D24 Education Rule Evidence & Result Tab Fix

Source: v1.4.198 user-uploaded Flutter project ZIP.

## Screenshot-specific regressions
- D24-VIDYA-CORE-06: previously lacked coded Jupiter/Mercury checks because the registry entry had empty planet fields; now evaluate direct D24 own/exalt dignity and show both grahas and devatas with pending Shadbala / undefined auspicious devata mapping.
- D24-VIDYA-FIELD-02: now distinguish D24 Mercury/Rahu conjunction or classical graha aspect from matching Vishwakarma/Maya devata, with explicit negative/pending states.
- Every imported IF–THEN: original THEN output is separated from the chart-derived observations; matched, not observed, and pending conditions shown independently.
- Four tabs: Result / IF–THEN / Chart audit / Remedies. No invented remedies if source has none.
- Additional direct observations for D24 core educational houses and standard competitive exam yogas; no unverified school admission claims.

## Compatibility
- 56 uploaded D24 rule registrations and 64 catalogs preserved.
- Previous education grading/sign-nature rules and their scores untouched.
- D10 517 careers, investment timing, BTR and other screens untouched.
- Parent source: `docs/d24_uploaded_sources/D24_Vidya_Jyotisha_Niyamalu_2026-10-22.docx`.

## Verification scope
- ZIP integrity and source parity checked.
- Flutter SDK and Dart compiler unavailable in this working environment; compile and widget tests must be verified through GitHub Actions.
- These are evidence checks, not a statistically calibrated prediction or a guaranteed university seat.
