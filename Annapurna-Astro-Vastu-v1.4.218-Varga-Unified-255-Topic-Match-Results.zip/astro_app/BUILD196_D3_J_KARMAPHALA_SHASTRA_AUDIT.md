# Build 196 — D3-J Karma-phala & Shastra Citation Registry

## Scope
- Version 1.4.196+196, based directly on v1.4.195 source archive.
- No modifications to existing D3/D10 rule evaluators, D1-D9-D10 career cross-confirmation,
  517 D10 registrations, birth time/BTR, or the GitHub build workflow.
- All sixteen current vargas get a tappable **calculation provenance** panel with BPHS
  Ch. 6 references (per-varga verse ranges) and copyable source URL.
- The *presence of a source reference does not mean all prediction, strength,
  cure, percent or remedy rules in a varga have been verified against that verse*.
  Those rule types need independent source and worked examples before certification.
- The separately computed **D3-J Jagannatha Drekkana** displays its own ascendant,
  planet positions and comparison with Parasari D3. It never overwrites the existing
  standard D3 for siblings, Sarala-7, Shadvarga strength, etc.
- D3-J traceability includes D3-J 3rd/9th/10th signs, D3-J 10th lord and its house,
  natal D1 10th lord and its D3-J house, and planets in the D3-J 10th.
  These are calculated *positions*, not a hard-coded karmaphala verdict.

## Scriptural / interpreted source separation
1. Classical source: **Brihat Parashara Hora Shastra, Chapter 6, verses 7–8**,
   10-degree standard Drekkana and 1/5/9 sign mapping.
   https://divyachadhava.com/en/sanatan-sahitya/bphs-chapter-6-the-sixteen-divisions-of-a-r-i
2. Traditional source *as cited by a modern interpreter*:
   **Chandrakala Nadi 5751–5752**. Sanjay Rath's **Jagannath Drekkana**
   commentary gives the movable/fixed/dual reordered trines and uses D3-J
   for karma-phala. The source/page is not misattributed to BPHS 6:7–8.
   https://pjc2.parasarahora.in/varga/drekka%E1%B9%87a-d3/jagannath-drekka%E1%B9%87a/
3. Interpretations: e.g. a named event in a previous life, auspicious/inauspicious
   karma percentage or remedy cannot be inferred simply from this mapping.
   Do not generate them until exact source-based IF–THEN conditions are verified.

## Validation
- Automated tests added to `test/d3_jagannatha_shastra_test.dart` for 36 sign/part
  mappings; moving/fixed/dual; exact 10/20 degree boundaries; distinction from
  Parasari D3; sampled chart audit; and 16 unique source registry entries.
- Flutter analyze/test/Android APK are GitHub Actions build-time checks, **not**
  claimed to have executed locally without an installed Flutter SDK.
- Prior matching/status/percentage engines are intentionally unchanged.

## Deferred audits (do not claim implemented)
- **D60** original code's mapping against BPHS Ch 6, 33–41 needs a separate
  edge-by-edge parity review. D60 ascendant requires birth-time sensitivity audit.
- **D27** source-specific varga starting-sign choice and deity mapping also
  need a separately reviewed source-concordance test.
- All historical application rule catalogs require a per-rule source-to-condition
  audit; this patch adds calculation provenance, not bulk auto-certification.
- The particular D3-J karma-phala predictive IF–THEN rules and exact event timing
  are not added without a vetted textual source and replicable examples.
