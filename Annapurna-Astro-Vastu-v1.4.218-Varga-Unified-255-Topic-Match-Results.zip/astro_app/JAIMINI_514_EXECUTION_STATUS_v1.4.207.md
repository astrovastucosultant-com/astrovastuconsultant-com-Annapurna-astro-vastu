# Annapurna Astro Vastu 1.4.207 — Jaimini 514 Execution Audit

## Scope and honesty

- The 46-page user-provided Telugu Jaimini IF–THEN PDF remains the authoritative *supplied catalog* (514 uniquely identified source rows).
- **159** entries have source-scoped positional predicate checks or formula calculations in the Flutter app. This figure **does not mean 159 independently verified life predictions**: many are foundational calculations or alternative branches with no overall match assertion.
- **355** entries remain without complete standalone chart predicates. A separate JSON audit has a row for *every* one of the 514 rules with implementation status, PDF page, sutra reference, and missing evidence.
- Do not mark pending or formula-only entries as `confirmed`; retain `matched == null` and use `calculated == true` for formulas and multi-branch checks.
- The app still displays all 514 rules in **ఫలితం · పరిశీలన · పరిహారం** tabs. If no remedy is cited by the supplied PDF, the remedy tab explicitly says that no verified remedy is provided.
- D1/D9 rashi aspects, AL/A7/UL, Karakamsa, individual planets and D1 ephemeris longitudes can be used, but a natal D1 chart **must not** be silently substituted for an Adhana/conception chart.

## Coverage

| Status | Number | Meaning |
|---|---:|---|
| Predicate or formula implemented | 159 | Explicit code, may be Boolean or calculated/partial |
| Complex conditional not yet fully implemented | 118 | Multiple disjunctions, argala, strengths, conditional branches |
| Requires sensitive specialized method | 124 | Longevity, maraka, death and family cross-charts |
| Requires Adhana / conception chart | 63 | Not derivable from the birth chart alone |
| Requires special reference chart | 21 | Hora / Varnada / menstruation / other specialized reference |
| Needs specific dasha method | 19 | Choose dasha variants, timings and branch logic |
| Requires sunrise / special lagna calculation | 10 | Exact sunrise, ghatis, calculation conventions |
| **Total** | **514** | All source records are preserved |

## Newly implemented checks in this update

1. **Foundation:** D1 rashi drishti, argala house position evidence, chara dasha direction, Arudha Padas (as computed by the existing Jaimini service), and the AL ninth-house Upagraha relation.
2. **Karakamsa:** D9 reference signs and relevant occupations (Sun/Venus/Mercury/Jupiter aspects and positions), profession branch mapping, KL fourth house (Sun/Jupiter, Saturn+Rahu, Mars+Ketu), KL seventh spouse-condition positions, KL ninth associations, KL twelfth references and their special combinations.
3. **Financial & Upapada:** AL second/eleventh/twelfth influences, some sources of income and expense, AL–A7 relative position, and UL second-house malefic/benefic, exaltation/debilitation and ownership checks.
4. **Ninth / siblings:** Some reference-sign evidence where the source gives multiple possible outcomes. A single Boolean result is deliberately withheld when alternatives differ.
5. **D9 trines:** Navamsa ascendant trines for specific source entries, recorded as source evidence only.

## Source limitations

- The user's PDF is an annotated Telugu rule compilation, not a full Unicode edition of Sanskrit sutras. Sutra references are preserved but do not by themselves establish independently verified original-text fidelity.
- Certain source conditions use ambiguous terms ('strong', 'benefic', 'complete Moon', 'only', 'aspected by') or explicitly enumerate mutually exclusive alternative consequences. Those require branch-by-branch review rather than blindly forcing a yes/no check.
- Serious medical and death predictions, pregnancy outcomes and family allegations should not be treated as confirmed by one combinational yoga.
- Birth-time-dependent D60, Adhana and specialized dashas require separate input validation.
- **Actual Flutter compilation / flutter test / APK build has NOT run in this execution environment.** GitHub Actions is required for verification.

## Files changed vs 1.4.206

- `lib/astrology/jaimini_extended_rule_engine.dart` (new)
- `lib/astrology/jaimini_complete_sutra_service.dart` (wired to extended rules, non-checkable groups disclosed)
- `test/jaimini_514_extended_predicates_test.dart` (new regression test source)
- `docs/jaimini_514_execution_audit_v207.json` (new, one record for each of 514)
- `pubspec.yaml` (version 1.4.207+207)

This is an interim implementation, **not a claim that 514 out of 514 automatic outcome judgments are complete**.
