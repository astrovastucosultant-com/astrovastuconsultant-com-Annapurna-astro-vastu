# v1.4.194 — D10 మూడు అంశదేవతల జాతక పరిశీలన

## Added
- `lib/astrology/d10_devata_audit_service.dart`: D1 natal sidereal longitude / 3° subdivision for the confirmed principal profession planet, D10 Lagna lord, and D10 10th lord, separately.
- `lib/screens/d10_devata_audit_panel.dart`: Telugu evidence panel; all available planetary deities with D1 and D10 house positions.
- `test/d10_devata_audit_service_test.dart`: separate roles, odd/even signs, missing primary, no effect on profession match percentage.

## Integrated
- D10 profession rule detail → expandable three-deity evidence panel.
- D10 reverse career search detail → same panel.
- D10 main page → general Lagna lord/10th lord and all-planet audit panel.

## Important calculation boundary
- A D10 whole-sign 10th *house* does **not** have an individual natal 3-degree subdivision. Hence the app explicitly labels the *D10 10th lord's deity*, not an invented '10th house deity'.
- Planet/deity associations remain independent; the existing 336 IF–THEN / 181 legacy matching, percentage, color priority, transit timing, and BTR are unchanged.
- Existing `D10CareerService.devataForLongitude` is reused unchanged. BPHS (chapter 6, verses 13–14): odd signs forward, even signs reversed.
- Validation here is static checks and ZIP integrity. Flutter SDK is not present in the current environment, so `flutter test` / APK build require GitHub Actions verification.
