import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/jaimini_complete_sutra_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('the full supplied Jaimini catalog has 555 traceable rules', () async {
    final records = await JaiminiCompleteSutraService.load();
    expect(records.length, 555);
    expect(records.map((r) => r.id).toSet().length, 555);
    expect(records.map((r) => r.major).toSet().length, 15);
    expect(records.every((r) => r.condition.trim().isNotEmpty &&
        r.result.trim().isNotEmpty && r.source.trim().isNotEmpty &&
        r.page >= 2 && r.page <= 50), isTrue);
  });

  test('a rule with no implemented predicate stays pending', () {
    const sample = JaiminiCompleteSutraRule(
      id: '13.10', major: 'ఆధాన జ్యోతిషం', section: 'కర్మ',
      condition: 'ఆధాన లగ్న పరిశీలన', result: 'నమూనా',
      source: '3.4.10', page: 39, sourceKind: 'PDF',
    );
    const chart = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 0,
      planets: [], engineVersion: 'test',
    );
    const jaimini = JaiminiResult(
      charaKarakas: [JaiminiKaraka(code: 'AK', planet: 'Sun', effectiveDegree: 12)],
      atmakaraka: 'Sun', karakamsaSignIndex: 0,
      rashiDrishti: {}, argalaFromLagna: [], arudhaPadas: [],
      applicableRules: [], hasDegreeTie: false,
    );
    final check = JaiminiCompleteSutraService.check(
      rule: sample, chart: chart, jaimini: jaimini,
    );
    expect(check.matched, isNull);
  });

  test('AK Navamsa sign rule checks a genuine birth-chart datum', () {
    const sample = JaiminiCompleteSutraRule(
      id: '3.1', major: 'కారకాంశం', section: 'AK నవాంశ',
      condition: 'మేషం', result: 'మూల గ్రంథ ఫలితం',
      source: '1.2.2', page: 8, sourceKind: 'PDF',
    );
    const chart = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 0,
      planets: [], engineVersion: 'test',
    );
    const jaimini = JaiminiResult(
      charaKarakas: [JaiminiKaraka(code: 'AK', planet: 'Sun', effectiveDegree: 12)],
      atmakaraka: 'Sun', karakamsaSignIndex: 0,
      rashiDrishti: {}, argalaFromLagna: [], arudhaPadas: [],
      applicableRules: [], hasDegreeTie: false,
    );
    expect(JaiminiCompleteSutraService.check(rule: sample,
      chart: chart, jaimini: jaimini).matched, isTrue);
  });

  test('five upagraha sutras calculate, without claiming a prediction', () {
    const chart = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 0,
      planets: [PlanetPosition(name: 'Sun', shortName: 'Su',
        longitude: 10, latitude: 0, speed: 1)], engineVersion: 'test',
    );
    const jaimini = JaiminiResult(
      charaKarakas: [JaiminiKaraka(code: 'AK', planet: 'Sun', effectiveDegree: 10)],
      atmakaraka: 'Sun', karakamsaSignIndex: 0,
      rashiDrishti: {}, argalaFromLagna: [], arudhaPadas: [],
      applicableRules: [], hasDegreeTie: false,
    );
    for (final id in ['2.16', '2.17', '2.18', '2.19', '2.20']) {
      final rule = JaiminiCompleteSutraRule(id: id, major: 'గణన',
        section: 'ఉపగ్రహాలు', condition: 'ఉపగ్రహ రేఖాంశం',
        result: 'గణన', source: '3.4.2', page: 7, sourceKind: 'PDF');
      final check = JaiminiCompleteSutraService.check(
          rule: rule, chart: chart, jaimini: jaimini);
      expect(check.calculated, isTrue);
      expect(check.matched, isNull);
      expect(check.evidence, contains('మొత్తం'));
    }
  });

}
