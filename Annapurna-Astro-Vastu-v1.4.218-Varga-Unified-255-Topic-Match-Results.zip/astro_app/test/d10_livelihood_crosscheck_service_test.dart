import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d10_livelihood_crosscheck_service.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';
import 'package:astro_app/astrology/d10_profession_registry.dart';
import 'package:astro_app/astrology/varga_service.dart';

const chart = AstroChartResult(
  julianDay: 2451545,
  ayanamsaDegrees: 23,
  ascendantLongitude: 0,
  engineVersion: 'crosscheck-test',
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 120,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 75,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 7,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 35,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 95,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 145,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 285,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 205,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 25,
        latitude: 0, speed: 1),
  ],
);

void main() {
  test('lagna, Moon and Sun each select own tenth lord then its D9 sign lord', () {
    final check = D10LivelihoodCrossCheckService.evaluate(chart);
    expect(check.channels.length, 3);
    final lagna = check.channels[0];
    expect(lagna.reference, 'లగ్నం');
    expect(lagna.tenthSign, 9); // Capricorn
    expect(lagna.natalTenthLord, 'Saturn');
    expect(lagna.navamsaSign, VargaService.signForLongitude(285, 9));
    expect(lagna.navamsaLord, 'Venus'); // Saturn in Taurus Navamsha

    final moon = check.channels[1];
    expect(moon.tenthSign, 11); // Gemini -> Pisces
    expect(moon.natalTenthLord, 'Jupiter');
    expect(moon.navamsaLord, 'Sun'); // Jupiter in Leo Navamsha

    final sun = check.channels[2];
    expect(sun.tenthSign, 1); // Leo -> Taurus
    expect(sun.natalTenthLord, 'Venus');
    expect(sun.navamsaLord, 'Mars'); // Venus in Scorpio Navamsha
  });

  test('channel comparison cannot override D10 gate or rule registry', () {
    final before = D10VruttiMatchEngine.evaluate(chart);
    final check = D10LivelihoodCrossCheckService.evaluate(chart);
    final first = d10VruttiRulebook.first;
    final blocked = check.compare(
      rule: first, primaryPlanetConfirmed: false, fullRuleMatched: false);
    expect(blocked.eligibleForIndividualVerdict, false);
    expect(blocked.fullD10RuleMatched, false);
    expect(blocked.linkedReferences, isNotNull);
    final after = D10VruttiMatchEngine.evaluate(chart);
    expect(before.map((e) => e.percent).toList(),
        after.map((e) => e.percent).toList());
    expect(d10VruttiRulebook.length + d10ProfessionRules.length, 517);
  });

  test('missing Sun and Moon do not create imaginary reference channels', () {
    const sparse = AstroChartResult(
      julianDay: 2451545, ayanamsaDegrees: 23,
      ascendantLongitude: 0, engineVersion: 'sparse',
      planets: [PlanetPosition(name: 'Saturn', shortName: 'Sa',
          longitude: 285, latitude: 0, speed: 1)],
    );
    final check = D10LivelihoodCrossCheckService.evaluate(sparse);
    expect(check.channels.length, 1);
    expect(check.channels.single.reference, 'లగ్నం');
  });

  test('only matching planet identities count as linkage, not similar sectors', () {
    final check = D10LivelihoodCrossCheckService.evaluate(chart);
    final venusRule = d10VruttiRulebook.firstWhere(
        (rule) => rule.planets.contains('Venus'));
    final result = check.compare(rule: venusRule,
        primaryPlanetConfirmed: true, fullRuleMatched: false);
    expect(result.linkedReferences, contains('లగ్నం'));
    expect(result.fullD10RuleMatched, false);
  });
}
