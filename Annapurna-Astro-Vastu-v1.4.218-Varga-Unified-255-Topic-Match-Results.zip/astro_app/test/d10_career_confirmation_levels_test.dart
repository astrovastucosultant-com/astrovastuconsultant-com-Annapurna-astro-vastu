import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';

void main() {
  final functionHall = d10VruttiRulebook.firstWhere((r) => r.id == 'VR-089');

  test('VR-089 can have primary-planet evidence without full rule', () {
    final partial = D10VruttiMatch(functionHall, true, false, 95,
        const ['Venus is linked'], const ['fourth/seventh not matched'],
        const ['D9 auxiliary info']);
    expect(partial.primaryPlanetConfirmed, isTrue);
    expect(partial.fullRuleMatched, isFalse);
    expect(partial.partialRuleMatched, isTrue);
    expect(partial.mayCheckConditionalTiming, isTrue);
    expect(partial.confirmationLabel, contains('పూర్తి IF–THEN'));
  });

  test('full source match and missing primary evidence are distinct', () {
    final full = D10VruttiMatch(functionHall, true, true, 100,
        const [], const [], const []);
    expect(full.fullRuleMatched, isTrue);
    expect(full.partialRuleMatched, isFalse);
    final missing = D10VruttiMatch(functionHall, false, false, 0,
        const [], const [], const []);
    expect(missing.mayCheckConditionalTiming, isFalse);
    expect(missing.primaryPlanetConfirmed, isFalse);
    expect(missing.fullRuleMatched, isFalse);
  });
}
