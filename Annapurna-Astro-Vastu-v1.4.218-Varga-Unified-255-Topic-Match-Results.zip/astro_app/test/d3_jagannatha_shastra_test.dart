import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d3_jagannatha_service.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_shastra_registry.dart';

void main() {
  test('Jagannatha drekkana follows movable-fixed-dual order in each triplicity', () {
    // Source signs: Aries movable; Taurus fixed; Gemini dual.
    expect([0.0, 10.0, 20.0]
        .map(D3JagannathaService.signForLongitude).toList(), [0, 4, 8]);
    expect([30.0, 40.0, 50.0]
        .map(D3JagannathaService.signForLongitude).toList(), [9, 1, 5]);
    expect([60.0, 70.0, 80.0]
        .map(D3JagannathaService.signForLongitude).toList(), [6, 10, 2]);
  });

  test('D3-J differs from standard D3 for fixed and dual source signs', () {
    expect(VargaService.signForLongitude(30.0, 3), 1); // Taurus
    expect(D3JagannathaService.signForLongitude(30.0), 9); // Capricorn
    expect(VargaService.signForLongitude(60.0, 3), 2); // Gemini
    expect(D3JagannathaService.signForLongitude(60.0), 6); // Libra
  });

  test('all 36 Jagannatha placements are trines in expected modalities', () {
    for (var natalSign = 0; natalSign < 12; natalSign++) {
      for (var part = 0; part < 3; part++) {
        final lon = natalSign * 30.0 + part * 10.0 + 2.5;
        final d3j = D3JagannathaService.signForLongitude(lon);
        expect(d3j % 3, part, reason: 'Target modalities movable/fixed/dual');
        expect((d3j - natalSign + 12) % 4, 0,
            reason: 'Must stay within the natal sign trine');
        expect(D3JagannathaService.partForLongitude(lon), part + 1);
      }
    }
  });

  test('boundaries and wraparound are stable; invalid longitude is rejected', () {
    expect(D3JagannathaService.partForLongitude(9.999999), 1);
    expect(D3JagannathaService.partForLongitude(10), 2);
    expect(D3JagannathaService.partForLongitude(19.999999), 2);
    expect(D3JagannathaService.partForLongitude(20), 3);
    expect(D3JagannathaService.signForLongitude(360), 0);
    expect(D3JagannathaService.signForLongitude(-360), 0);
    expect(() => D3JagannathaService.signForLongitude(double.nan), throwsArgumentError);
  });

  test('D3-J audit returns chart-based evidence and does not predict karma', () {
    const chart = AstroChartResult(
      julianDay: 2450000,
      ayanamsaDegrees: 24,
      ascendantLongitude: 35, // Taurus -> D3-J Capricorn lagna
      engineVersion: 'test',
      planets: [
        PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 5, latitude: 0, speed: 1),
        PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 17, latitude: 0, speed: 1),
        PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 36, latitude: 0, speed: 1),
      ],
    );
    final out = D3JagannathaService.calculate(chart);
    final audit = D3JagannathaService.audit(chart);
    expect(out.ascendantSignIndex, 9); // Capricorn
    expect(audit.tenthSign, 6); // Libra
    expect(audit.tenthLord, 'Venus');
    expect(audit.tenthLordHouse, 8); // Venus D3-J Leo, from Capricorn = 8
    expect(audit.natalTenthLord, 'Saturn'); // Taurus natal 10th = Aquarius
    expect(audit.natalTenthLordHouse, 1); // Saturn D3-J Capricorn
  });

  test('each classical varga has distinct traceable calculation citation', () {
    expect(VargaShastraRegistry.coversAllVargas, isTrue);
    expect(VargaShastraRegistry.entries.length, 16);
    expect(VargaShastraRegistry.entries.map((e) => e.factor).toSet().length, 16);
    expect(VargaShastraRegistry.forFactor(3).verse, '7–8');
    expect(VargaShastraRegistry.forFactor(10).verse, '13–14');
    expect(VargaShastraRegistry.forFactor(60).verse, '33–41');
  });
}
