import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d24_vidya_source_engine.dart';
import 'package:astro_app/astrology/d24_vidya_source_registry.dart';
import 'package:astro_app/astrology/d24_education_registry.dart';

const _chart = AstroChartResult(
  julianDay: 2451545, ayanamsaDegrees: 23,
  ascendantLongitude: 0.5, engineVersion: 'd24-upload-test',
  planets: [
    PlanetPosition(name:'Sun',shortName:'Su',longitude:27.5,latitude:0,speed:1),
    PlanetPosition(name:'Moon',shortName:'Mo',longitude:30.1,latitude:0,speed:1),
    PlanetPosition(name:'Mars',shortName:'Ma',longitude:2.5,latitude:0,speed:1),
    PlanetPosition(name:'Mercury',shortName:'Me',longitude:6.2,latitude:0,speed:1),
    PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:9.9,latitude:0,speed:1),
    PlanetPosition(name:'Venus',shortName:'Ve',longitude:31.3,latitude:0,speed:1),
    PlanetPosition(name:'Saturn',shortName:'Sa',longitude:38.9,latitude:0,speed:1),
    PlanetPosition(name:'Rahu',shortName:'Ra',longitude:65.1,latitude:0,speed:-1),
    PlanetPosition(name:'Ketu',shortName:'Ke',longitude:245.1,latitude:0,speed:-1),
  ],
);

void main(){
  test('24 subdivisions use 1 degree 15 minutes and 12 devatas repeat',(){
    expect(D24VidyaSourceEngine.devataForLongitude(0).name,'స్కంద');
    expect(D24VidyaSourceEngine.devataForLongitude(1.25).name,'పరశుధర');
    expect(D24VidyaSourceEngine.devataForLongitude(15).name,'స్కంద');
    expect(D24VidyaSourceEngine.devataForLongitude(29.999).name,'భీమ');
    expect(D24VidyaSourceEngine.devataForLongitude(30).name,'భీమ');
    expect(D24VidyaSourceEngine.devataForLongitude(31.25).name,'మదన');
    expect(D24VidyaSourceEngine.devataForLongitude(45).name,'భీమ');
    expect(D24VidyaSourceEngine.devataForLongitude(59.999).name,'స్కంద');
    expect(D24VidyaSourceEngine.devataForLongitude(0).part,1);
    expect(D24VidyaSourceEngine.devataForLongitude(29.99).part,24);
  });
  test('all source content and 26 education / 14 admission rules retained',(){
    expect(D24VidyaSourceRegistry.rules.length,56);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='CORE').length,6);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='FIELD').length,26);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='EXAM').length,6);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='ADMISSION').length,14);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='TIMING').length,4);
    expect(D24VidyaSourceRegistry.catalogs.length,64);
    expect(D24VidyaSourceRegistry.rules.map((r)=>r.id).toSet().length,56);
  });
  screenshotRegressions();
  test('chart-specific audit does not assert exact admissions or overwrite old sign natures',(){
    final items=D24VidyaSourceEngine.evaluate(_chart);
    expect(items.length,56);
    expect(items.every((e)=>e.label.contains('తుది నిర్ధారణ కాదు') || e.label.contains('పెండింగ్')),isTrue);
    expect(items.first.source.category,'CORE');
    expect(D24VidyaSourceEngine.allDevatas(_chart).length,10);
    expect(D24EducationRegistry.natureForSign(0),'Technical');
    expect(D24EducationRegistry.natureForSign(3),'Non-technical');
  });
}

// Screenshot regression: field-02 previously showed only the PDF THEN and
// "pending"; CORE-06 previously had zero evaluable conditions.
void screenshotRegressions() {
  test('D24 CORE-06 audits Jupiter / Mercury individually', () {
    final items=D24VidyaSourceEngine.evaluate(_chart);
    final core=items.firstWhere((x)=>x.source.id=='D24-VIDYA-CORE-06');
    expect(core.checks.any((x)=>x.title.contains('గురువు')),isTrue);
    expect(core.checks.any((x)=>x.title.contains('బుధుడు')),isTrue);
    expect(core.checks.any((x)=>x.title.contains('శుభ అంశదేవత')),isTrue);
    expect(core.pendingCount,greaterThan(0));
    expect(core.explanation.contains('D24 లగ్నం'),isTrue);
  });
  test('FIELD-02 shows Mercury-Rahu conjunction and devata condition separately', () {
    final audit=D24VidyaSourceEngine.evaluate(_chart)
        .firstWhere((x)=>x.source.id=='D24-VIDYA-FIELD-02');
    expect(audit.checks.any((x)=>x.title.contains('గ్రహాల D24')),isTrue);
    expect(audit.checks.any((x)=>x.title.contains('అంశదేవత')),isTrue);
    expect(audit.checkReport.contains('రాహువు'),isTrue);
    expect(audit.pendingCount,greaterThan(0));
    expect(audit.label.contains('తుది నిర్ధారణ కాదు'),isTrue);
    expect(audit.ruleVerdict,isNotEmpty);
    expect(audit.missingMainConditions.every((c)=>
      c.status==D24CheckStatus.notObserved),isTrue);
  });
  test('one supporting karaka link cannot override missing required devata', () {
    final audit=D24VidyaRuleAudit(
      source:D24VidyaSourceRegistry.rules.firstWhere(
        (r)=>r.id=='D24-VIDYA-FIELD-19'),
      devataSupport:false,
      relevantHouseSupport:false,
      planetRelationSupport:true,
      explanation:'test',
      checks:const [
        D24VidyaConditionCheck(
          'కారక గ్రహాల D24 కలయిక/పరాశరీ గ్రహదృష్టి',
          'Moon–Venus conjunction',D24CheckStatus.matched),
        D24VidyaConditionCheck(
          'కారక గ్రహానికి నిర్దేశించిన అంశదేవత',
          'అనల కనిపించలేదు',D24CheckStatus.notObserved),
        D24VidyaConditionCheck(
          'ఇతర గ్రహ సంబంధం/బలం',
          'ఇంకా పరిశీలించాలి',D24CheckStatus.pending),
      ],
    );
    expect(audit.matchedCount,1);
    expect(audit.missingMainConditions.length,1);
    expect(audit.ruleVerdict.contains('పాక్షిక మద్దతు'),isTrue);
    expect(audit.label.contains('తుది నిర్ధారణ కాదు'),isTrue);
  });
  test('admission and course labels never declare a complete IF match', () {
    final audits=D24VidyaSourceEngine.evaluate(_chart);
    for (final audit in audits.where((x)=>
        x.source.category=='ADMISSION' || x.source.category=='FIELD')) {
      expect(audit.label.contains('తుది నిర్ధారణ కాదు'),isTrue);
      if(audit.missingMainConditions.isNotEmpty){
        expect(audit.ruleVerdict.contains('ప్రధాన') ||
            audit.ruleVerdict.contains('ముఖ్యమైన'),isTrue);
      }
    }
  });
  test('timing rules never claim an exam year from natal chart alone', () {
    final audit=D24VidyaSourceEngine.evaluate(_chart)
        .firstWhere((x)=>x.source.id=='D24-VIDYA-TIMING-01');
    expect(audit.hasSupportingEvidence,isFalse);
    expect(audit.checks.any((x)=>x.status==D24CheckStatus.pending),isTrue);
  });
}
