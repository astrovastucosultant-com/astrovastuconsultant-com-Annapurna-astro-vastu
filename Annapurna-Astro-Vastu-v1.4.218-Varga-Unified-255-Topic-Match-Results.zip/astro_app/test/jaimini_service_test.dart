import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';

PlanetPosition _p(String name, String shortName, double longitude) {
  return PlanetPosition(
    name: name,
    shortName: shortName,
    longitude: longitude,
    latitude: 0,
    speed: 1,
  );
}

AstroChartResult _chart({required double marsLongitude}) {
  return AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 0,
    ascendantLongitude: 5, // Aries Lagna for simple Pada verification.
    engineVersion: 'test',
    planets: [
      _p('Sun', 'Su', 120),
      _p('Moon', 'Mo', 90),
      _p('Mars', 'Ma', marsLongitude),
      _p('Mercury', 'Me', 60),
      _p('Jupiter', 'Ju', 240),
      _p('Venus', 'Ve', 30),
      _p('Saturn', 'Sa', 270),
      _p('Rahu', 'Ra', 300),
      _p('Ketu', 'Ke', 120),
    ],
  );
}

void main() {
  test('P1: lord in 4th gives 4th from lord (Aries -> Cancer -> Libra)', () {
    final result = JaiminiService.calculate(_chart(marsLongitude: 95));
    final p1 = result.arudhaPadas.first;

    expect(p1.sourceSignIndex, 0); // Aries
    expect(p1.lord, 'Mars');
    expect(p1.lordSignIndex, 3); // Cancer
    expect(p1.distance, 4);
    expect(p1.padaSignIndex, 6); // Libra
  });

  test('P1: lord in same sign keeps P1 in same sign', () {
    final result = JaiminiService.calculate(_chart(marsLongitude: 5));
    final p1 = result.arudhaPadas.first;

    expect(p1.distance, 1);
    expect(p1.padaSignIndex, 0); // Aries
  });

  test('P1: lord in 7th returns Pada to source sign', () {
    final result = JaiminiService.calculate(_chart(marsLongitude: 185));
    final p1 = result.arudhaPadas.first;

    expect(p1.lordSignIndex, 6); // Libra
    expect(p1.distance, 7);
    expect(p1.padaSignIndex, 0); // Aries
  });

  test('Stone-house rule requires BOTH Saturn and Rahu in KL fourth', () {
    final pair = JaiminiService.calculate(_karakamsaHouseChart(saturn: 358.5, rahu: 358.7));
    expect(pair.karakamsaSignIndex, 8); // Sagittarius -> fourth Pisces.
    expect(pair.applicableRules.any((r) => r.ruleId == 'J1Q1-C15'), isTrue);
    final single = JaiminiService.calculate(_karakamsaHouseChart(saturn: 358.5, rahu: 310.0));
    expect(single.applicableRules.any((r) => r.ruleId == 'J1Q1-C15'), isFalse);
  });

  test('Brick-house rule requires BOTH Mars and Ketu in KL fourth', () {
    final pair = JaiminiService.calculate(_karakamsaHouseChart(
      saturn: 275.0, rahu: 310.0, mars: 359.0, ketu: 358.8));
    expect(pair.applicableRules.any((r) => r.ruleId == 'J1Q1-C17'), isTrue);
    final single = JaiminiService.calculate(_karakamsaHouseChart(
      saturn: 275.0, rahu: 310.0, mars: 359.0));
    expect(single.applicableRules.any((r) => r.ruleId == 'J1Q1-C17'), isFalse);
  });

  test('AL-A7 is wealth evidence, not a marriage confirmation', () {
    final result = JaiminiService.calculate(_karakamsaHouseChart(saturn: 358.5, rahu: 310.0));
    expect(result.applicableRules.any((r) => r.ruleId == 'J1Q3-15'), isFalse);
    for (final rule in result.applicableRules.where((r) => r.ruleId == 'J1Q3-13' || r.ruleId == 'J1Q3-16')) {
      expect(rule.topic, contains('ధనం'));
    }
  });
}

// Regression: Source rule 3.51 (page 11) requires the *pair* of planets,
// not an OR between Saturn/Rahu or between Mars/Ketu.
AstroChartResult _karakamsaHouseChart({
  required double saturn,
  required double rahu,
  double mars = 63.0,
  double ketu = 182.0,
}) {
  return AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 0,
    ascendantLongitude: 5.0,
    engineVersion: 'source-test',
    planets: [
      _p('Sun', 'Su', 29.1), // AK; Aries part 9 -> D9 Sagittarius.
      _p('Moon', 'Mo', 35.0),
      _p('Mars', 'Ma', mars),
      _p('Mercury', 'Me', 94.0),
      _p('Jupiter', 'Ju', 125.0),
      _p('Venus', 'Ve', 156.0),
      _p('Saturn', 'Sa', saturn),
      _p('Rahu', 'Ra', rahu),
      _p('Ketu', 'Ke', ketu),
    ],
  );
}

// These expectations are invoked from the same flutter_test runner via main().
