import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/jaimini_next_batch_rule_engine.dart';

PlanetPosition _p(String name, double longitude) => PlanetPosition(
  name: name, shortName: name.substring(0,2),
  longitude: longitude, latitude: 0, speed: 1,
);

final _planets = <PlanetPosition>[
  _p('Sun', 10), _p('Moon', 44), _p('Mars', 77),
  _p('Mercury', 104), _p('Jupiter', 139), _p('Venus', 169),
  _p('Saturn', 213), _p('Rahu', 249), _p('Ketu', 69),
];

AstroChartResult _chart({double asc = 0}) => AstroChartResult(
  julianDay: 2460000, ayanamsaDegrees: 24, ascendantLongitude: asc,
  engineVersion: 'test', planets: _planets,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('sunrise formulae: ghati = 24 minutes, offsets and degrees wrap', () {
    final points = JaiminiNextBatchRuleEngine.sunrisePointLongitudes(
      sunSiderealLongitude: 10, minutesSinceLocalSunrise: 24,
    );
    expect(points['2.8'], closeTo(22, 0.00001));
    expect(points['2.9'], closeTo(16, 0.00001));
    expect(points['2.10'], closeTo(40, 0.00001));
    expect(points['2.11'], closeTo(10, 0.00001));
    expect(points['2.12'], closeTo(130, 0.00001));
    // Sun in Taurus is a fixed sign, so Pranapada uses +240°.
    final evenPoint = JaiminiNextBatchRuleEngine.sunrisePointLongitudes(
      sunSiderealLongitude: 40, minutesSinceLocalSunrise: 0,
    );
    expect(evenPoint['2.12'], closeTo(280, 0.00001));
    expect(() => JaiminiNextBatchRuleEngine.sunrisePointLongitudes(
      sunSiderealLongitude: 10, minutesSinceLocalSunrise: -2,
    ), throwsArgumentError);
  });

  test('sunrise-dependent rules do not fabricate birth time', () {
    final c = _chart();
    final jm = JaiminiService.calculate(c);
    for (final id in ['2.8','2.9','2.10','2.11','2.12','2.15']) {
      expect(JaiminiNextBatchRuleEngine.check(id,c,jm),isNull);
      final result = JaiminiNextBatchRuleEngine.check(id,c,jm,
          minutesSinceLocalSunrise: 180);
      expect(result, isNotNull);
      expect(result!.calculated, isTrue);
      expect(result.matched,isNull);
    }
  });

  test('new dasha audits show method choice without event date inference', () {
    final c = _chart();
    final jm = JaiminiService.calculate(c);
    for (final id in ['12.1','12.2','12.3','12.4','12.5','12.6','12.17','12.18','12.19']) {
      final r=JaiminiNextBatchRuleEngine.check(id,c,jm);
      expect(r,isNotNull,reason:'missing $id');
      expect(r!.matched,isNull,reason:id);
      expect(r.calculated,isTrue);
    }
    final d=JaiminiNextBatchRuleEngine.check('12.3',c,jm)!.evidence;
    expect(d,contains('PDF 12.3'));
    expect(d,contains('Method B'));
    expect(d,contains('ఊహించిన జనన తేదీ ఉపయోగించలేదు'));
  });

  test('foundation evidence is separate from claimed life events', () {
    final c=_chart();
    final jm=JaiminiService.calculate(c);
    for (final id in ['1.15','1.18','1.18a','1.19','1.20','1.21',
      '2.13','2.15a','2.15b']) {
      final r=JaiminiNextBatchRuleEngine.check(id,c,jm);
      expect(r,isNotNull,reason:id);
      expect(r!.matched,isNull);
      expect(r.calculated,isTrue);
    }
  });
}
