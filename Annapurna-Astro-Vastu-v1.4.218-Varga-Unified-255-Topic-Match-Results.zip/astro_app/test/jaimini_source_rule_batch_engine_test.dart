import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/jaimini_source_rule_batch_engine.dart';

void main() {
  const sample = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 23,
    ascendantLongitude: 0,
    engineVersion: 'source-rule-test',
    planets: [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 10,
          latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 45,
          latitude: 0, speed: 1),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 0,
          latitude: 0, speed: 1),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 75,
          latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 105,
          latitude: 0, speed: 1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 135,
          latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 165,
          latitude: 0, speed: 1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 195,
          latitude: 0, speed: -1),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 15,
          latitude: 0, speed: -1),
    ],
  );
  const jm = JaiminiResult(
    atmakaraka: 'Sun',
    charaKarakas: [
      JaiminiKaraka(code: 'AK', planet: 'Sun', effectiveDegree: 10),
    ],
    karakamsaSignIndex: 0,
    rashiDrishti: {},
    argalaFromLagna: [],
    arudhaPadas: [],
    applicableRules: [],
    hasDegreeTie: false,
  );

  test('specific KL Mars IF is checked from D9, not invented result', () {
    final actual = JaiminiSourceRuleBatchEngine.check('15.2', sample, jm);
    expect(actual, isNotNull);
    expect(actual!.calculated, isFalse);
    expect(actual.matched, isTrue); // Mars 0° -> D9 Aries = KL Aries
  });

  test('independent branch alternatives remain measured, not asserted', () {
    for (final id in ['5.27', '5.28', '15.7', '7.20']) {
      final actual = JaiminiSourceRuleBatchEngine.check(id, sample, jm);
      expect(actual, isNotNull, reason: id);
      expect(actual!.calculated, isTrue, reason: id);
      expect(actual.matched, isNull, reason: id);
    }
  });

  test('sensitive longevity/mortality notes never make life predictions', () {
    for (final id in ['8.9', '9.1', '10.29', '11.12', '15.36']) {
      final actual = JaiminiSourceRuleBatchEngine.check(id, sample, jm);
      expect(actual, isNotNull, reason: id);
      expect(actual!.matched, isNull, reason: id);
      expect(actual.calculated, isTrue, reason: id);
    }
  });

  test('absent chart inputs never become false statuses', () {
    const incomplete = AstroChartResult(
      julianDay: 2451545, ayanamsaDegrees: 23,
      ascendantLongitude: 0, engineVersion: 'test',
      planets: [PlanetPosition(name:'Sun',shortName:'Su',
          longitude:10,latitude:0,speed:1)],
    );
    expect(JaiminiSourceRuleBatchEngine.check('15.2', incomplete, jm), isNull);
    expect(JaiminiSourceRuleBatchEngine.check('2.14', sample, jm), isNull);
  });
}
