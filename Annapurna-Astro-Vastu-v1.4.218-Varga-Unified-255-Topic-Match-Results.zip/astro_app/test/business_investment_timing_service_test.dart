import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/business_investment_timing_service.dart';

void main() {
  const emptyChart = AstroChartResult(
    julianDay: 2451545, ayanamsaDegrees: 23.8, ascendantLongitude: 0,
    planets: <PlanetPosition>[], engineVersion: 'test',
  );
  const populated = AstroChartResult(
    julianDay: 2451545, ayanamsaDegrees: 23.8, ascendantLongitude: 0,
    engineVersion: 'test', planets: <PlanetPosition>[
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 303,
        latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 38,
        latitude: 0, speed: 1),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 175,
        latitude: 0, speed: 1),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 311,
        latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 92,
        latitude: 0, speed: 1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 165,
        latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 305,
        latitude: 0, speed: 1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 234,
        latitude: 0, speed: -1),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 54,
        latitude: 0, speed: -1),
    ],
  );

  test('missing planetary positions are NOT a zero investment score', () {
    final audit = BusinessInvestmentTimingService.evaluate(
      emptyChart, BusinessInvestmentType.general);
    expect(audit.evaluated, false);
    expect(audit.hasNatalSupport, false);
    expect(audit.summary, contains('అసంపూర్తి'));
  });

  test('D16 is omitted for general and financial investments', () {
    final general = BusinessInvestmentTimingService.evaluate(
      populated, BusinessInvestmentType.general);
    final financial = BusinessInvestmentTimingService.evaluate(
      populated, BusinessInvestmentType.financial);
    expect(general.evidence.any((e) => e.id.startsWith('INV-D16')), false);
    expect(financial.evidence.any((e) => e.id.startsWith('INV-D16')), false);
    expect(financial.evidence.any((e) => e.id.startsWith('INV-D10')), false);
    final vehicle = BusinessInvestmentTimingService.evaluate(
      populated, BusinessInvestmentType.vehicles);
    expect(vehicle.evidence.any((e) => e.id.startsWith('INV-D4')), false);
    expect(vehicle.evidence.any((e) => e.id.startsWith('INV-D16')), true);
  });

  test('D2 rules are linked to original condition and actual page', () {
    final audit = BusinessInvestmentTimingService.evaluate(
      populated, BusinessInvestmentType.general);
    for (final evidence in audit.evidence.where((e) => e.id.startsWith('D2-'))) {
      expect(evidence.condition.isNotEmpty, true);
      expect(evidence.source, contains('పేజీ'));
      expect(evidence.source, isNot(contains('పేజీ 0')));
    }
    final hora = audit.evidence.firstWhere((e) => e.id == 'INV-D2-HORA');
    expect(hora.status, InvestmentEvidenceStatus.neutral);
  });

  test('dasha + BOTH observed transits required for period support', () {
    const audit = BusinessInvestmentAudit(
      type: BusinessInvestmentType.general,
      evaluated: true,
      limitations: [],
      evidence: [
        InvestmentEvidence(id: 'a', sourceChart: 'D1', condition: '',
          observation: '', source: '',
          status: InvestmentEvidenceStatus.supportive),
        InvestmentEvidence(id: 'b', sourceChart: 'D10', condition: '',
          observation: '', source: '',
          status: InvestmentEvidenceStatus.supportive),
      ],
    );
    expect(BusinessInvestmentTimingService.classifySample(
      audit: audit, chart: populated, md: 'Venus', ad: 'Saturn',
      guruSign: 1, shaniSign: 1), InvestmentTimeStatus.support);
    expect(BusinessInvestmentTimingService.classifySample(
      audit: audit, chart: populated, md: 'Venus', ad: 'Mars',
      guruSign: 1, shaniSign: 1), isNull);
    expect(BusinessInvestmentTimingService.classifySample(
      audit: audit, chart: populated, md: 'Venus', ad: 'Saturn',
      guruSign: 2, shaniSign: 5), isNull);
  });

  test('same month-support windows merge only if adjacent MD AD and status', () {
    final previous = BusinessInvestmentWindow(
      start: DateTime(2026, 9, 15), end: DateTime(2026, 10, 15),
      mahadasha: 'Venus', antardasha: 'Saturn',
      status: InvestmentTimeStatus.support, evidence: const []);
    expect(BusinessInvestmentTimingService.adjacent(
      previous, DateTime(2026, 11, 15),
      'Venus', 'Saturn', InvestmentTimeStatus.support), true);
    expect(BusinessInvestmentTimingService.adjacent(
      previous, DateTime(2026, 12, 15),
      'Venus', 'Saturn', InvestmentTimeStatus.support), false);
    expect(BusinessInvestmentTimingService.adjacent(
      previous, DateTime(2026, 11, 15),
      'Venus', 'Mercury', InvestmentTimeStatus.support), false);
    expect(previous.through(DateTime(2026, 11, 15)).months, 3);
  });
}
