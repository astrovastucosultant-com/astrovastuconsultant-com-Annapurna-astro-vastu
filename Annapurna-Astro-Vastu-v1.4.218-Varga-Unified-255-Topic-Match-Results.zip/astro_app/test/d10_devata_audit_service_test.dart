import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d10_devata_audit_service.dart';
import 'package:astro_app/astrology/d10_career_service.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';

const chart = AstroChartResult(
  julianDay: 2451545,
  ayanamsaDegrees: 23,
  ascendantLongitude: 0,
  engineVersion: 'devata-unit-test',
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 22,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 31,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 1,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 2,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 3,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 4,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 31,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 6,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 7,
        latitude: 0, speed: 1),
  ],
);

void main() {
  test('three D10 deity audit roles are distinct and source-longitude based', () {
    final audit = D10DevataAuditService.evaluate(chart, primaryPlanet: 'Sun');
    expect(audit.lagnaLord, 'Mars'); // D10 ascendant Aries for 0 degrees
    expect(audit.tenthLord, 'Saturn'); // D10 tenth house Capricorn
    expect(audit.principal!.planet, 'Sun');
    expect(audit.principal!.deity, 'Ishana'); // Aries part 8 (21-24 deg)
    expect(audit.lagnaLordEvidence!.deity, 'Indra'); // Aries part 1
    expect(audit.tenthLordEvidence!.deity, 'Ananta'); // Taurus part 1 reversed
    expect(audit.allPlanets.length, 9);
    expect(audit.principal!.division, 8);
    expect(audit.tenthLordEvidence!.division, 1);
  });

  test('missing primary planet cannot manufacture an audit confirmation', () {
    final audit = D10DevataAuditService.evaluate(chart, primaryPlanet: 'Pluto');
    expect(audit.principal, isNull);
    expect(audit.lagnaLordEvidence, isNotNull);
    expect(audit.tenthLordEvidence, isNotNull);
  });

  test('independent devata audit leaves the 336 profession rules unchanged', () {
    final before = D10VruttiMatchEngine.evaluate(chart);
    D10DevataAuditService.evaluate(chart, primaryPlanet: 'Sun');
    final after = D10VruttiMatchEngine.evaluate(chart);
    expect(after.length, 336);
    expect(after.map((m) => m.percent).toList(),
        before.map((m) => m.percent).toList());
    expect(D10CareerService.devataForLongitude(31).deity, 'Ananta');
  });
}
