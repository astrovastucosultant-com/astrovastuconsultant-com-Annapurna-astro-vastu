import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/jaimini_pending_review_engine.dart';

void main() {
  const jm = JaiminiResult(
    atmakaraka: 'Sun',
    charaKarakas: [JaiminiKaraka(code: 'AK', planet: 'Sun', effectiveDegree: 5)],
    karakamsaSignIndex: 0,
    rashiDrishti: {}, argalaFromLagna: [], arudhaPadas: [],
    applicableRules: [], hasDegreeTie: false,
  );
  const chart = AstroChartResult(
    julianDay: 2451545, ayanamsaDegrees: 23,
    ascendantLongitude: 0,
    planets: [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 185,
        latitude: 0, speed: 1),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 45,
        latitude: 0, speed: 1),
    ], engineVersion: 'test',
  );
  test('source 15.31 inspects AK position, not asserted lifespan', () {
    final evaluation = JaiminiPendingReviewEngine.check('15.31', chart, jm);
    expect(evaluation, isNotNull);
    expect(evaluation!.matched, isTrue); // AK in natal seventh.
    expect(evaluation.calculated, isFalse);
    expect(evaluation.evidence, contains('గ్రంథ షరతు పరీక్ష'));
  });
  test('missing prerequisite remains pending, not a fabricated match', () {
    expect(JaiminiPendingReviewEngine.check('15.13', chart, jm), isNull);
    expect(JaiminiPendingReviewEngine.check('13.40', chart, jm), isNull);
  });
  test('AK sign dependent rules refuse degree-tied karakas', () {
    const tied = JaiminiResult(
      atmakaraka: 'Sun',
      charaKarakas: [JaiminiKaraka(code: 'AK', planet: 'Sun', effectiveDegree: 5)],
      karakamsaSignIndex: 0, rashiDrishti: {}, argalaFromLagna: [],
      arudhaPadas: [], applicableRules: [], hasDegreeTie: true,
    );
    expect(JaiminiPendingReviewEngine.check('4.13', chart, tied), isNull);
  });
}
