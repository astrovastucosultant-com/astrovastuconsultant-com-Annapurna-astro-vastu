import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_rashi_rule_service.dart';
import '../astrology/bnn_house_relation_service.dart';
import '../models/birth_data.dart';

/// BNN only: Result first, tap for rule + Lagna/Jupiter house checks + source.
/// Does not restore the retired 462 registry.
class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  const BnnMasterPanel({
    super.key, required this.chart, required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

enum _BnnTone { green, pink, neutral }

class _BnnToneStyle {
  final Color background;
  final Color border;
  final Color text;
  const _BnnToneStyle(this.background,this.border,this.text);
}

_BnnToneStyle _toneStyle(_BnnTone tone) {
  switch (tone) {
    case _BnnTone.green:
      return const _BnnToneStyle(Color(0xFFD9F3E0),Color(0xFF68AA7A),Color(0xFF176A36));
    case _BnnTone.pink:
      return const _BnnToneStyle(Color(0xFFFBE6ED),Color(0xFFD48AA0),Color(0xFF9F3458));
    case _BnnTone.neutral:
      return const _BnnToneStyle(Color(0xFFF0F3F5),Color(0xFFBDC5CE),Color(0xFF344655));
  }
}

// Only explicitly reviewed single-direction texts are color-coded.
// Mixed, ambiguous and OCR-sensitive texts stay neutral — never guessed.
const _greenRashiIds = <String>{
 '001','004','006','008','011','013','014','015','018','019','020',
 '021','032','034','035','036','037','039','040','042','046','049',
 '063','075','078',
};
const _pinkRashiIds = <String>{'051','052'};
_BnnTone _toneForRashi(String id) {
  final suffix = id.substring(id.length-3);
  if (_greenRashiIds.contains(suffix)) return _BnnTone.green;
  if (_pinkRashiIds.contains(suffix)) return _BnnTone.pink;
  return _BnnTone.neutral;
}
_BnnTone _toneForSource(String tone) {
  if (tone == 'favorable') return _BnnTone.green;
  if (tone == 'unfavorable') return _BnnTone.pink;
  return _BnnTone.neutral;
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnRashiRule>> _rashiRules = BnnRashiRuleService.load();
  late final Future<List<BnnJupiterRelativeRule>> _jupiterRules =
      BnnHouseRelationService.loadVerifiedJupiterRules();
  bool _showAll = false;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BnnRashiRule>>(
      future: _rashiRules,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Card(child: Padding(padding: const EdgeInsets.all(18),
            child: Text('BNN రాశి నియమాల డేటా చదవడంలో సమస్య: ${snapshot.error}')));
        }
        if (!snapshot.hasData) {
          return const Card(child: Padding(padding: EdgeInsets.all(18),
            child: Center(child: CircularProgressIndicator())));
        }
        final findings = BnnRashiRuleService.evaluate(
          rules: snapshot.data!, chart: widget.chart,
          gender: widget.birthData.gender,
        );
        final matching = findings.where((f) => f.matched).toList();
        final results = matching.where((f) => f.canDisplayEffect).toList()
          ..sort((a,b) => _toneForRashi(a.rule.id).index
              .compareTo(_toneForRashi(b.rule.id).index));
        final other = findings.where((f) => !f.canDisplayEffect).toList();
        final display = _showAll ? [...results, ...other] : results;
        final locations = BnnHouseRelationService.positions(widget.chart);

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              color: const Color(0xFFF2F7F4),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('BNN — అన్ని గ్రహాలు: ఫలితం → రూల్',
                      style: TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text('84 రాశి మూల నియమాలు • IF TRUE ${matching.length} • '
                         'ప్రదర్శించగల ఫలితాలు ${results.length}'),
                    const SizedBox(height: 8),
                    const Text('Green: అనుకూల సూచన • Pink: ప్రతికూల సూచన • '
                      'Neutral: మిశ్రమం/అస్పష్టత. IF TRUE అనేది గ్రహస్థానం సరిపోయిందనే అర్థం మాత్రమే.',
                      style: TextStyle(fontSize:12.5,height:1.45)),
                    const SizedBox(height: 9),
                    OutlinedButton.icon(
                      onPressed: () => setState(() => _showAll = !_showAll),
                      icon: Icon(_showAll ? Icons.visibility_off : Icons.list_alt),
                      label: Text(_showAll ? 'వర్తించిన ఫలితాలు మాత్రమే' : 'మొత్తం 84 రాశి మూల నియమాలు'),
                    ),
                  ],
                ),
              ),
            ),
            _HousePositionsCard(locations:locations),
            if (display.isEmpty)
              const Padding(padding:EdgeInsets.all(16),
                child:Text('ఈ జాతకానికి రాశి ఫలితాలు లేవు. గ్రహాల స్థానగణన పైన చూడవచ్చు.')),
            for (final finding in display)
              _RashiResultCard(key:ValueKey(finding.rule.id),
                finding:finding,chart:widget.chart),
            FutureBuilder<List<BnnJupiterRelativeRule>>(
              future: _jupiterRules,
              builder: (context, snap) {
                if (snap.hasError) {
                  return Card(child:Padding(padding:const EdgeInsets.all(12),
                    child:Text('గురు సంబంధ మూల నియమాలు చదవడంలో సమస్య: ${snap.error}')));
                }
                if (!snap.hasData) return const SizedBox.shrink();
                final matched = BnnHouseRelationService.evaluateVerifiedJupiterRules(
                  chart:widget.chart,rules:snap.data!);
                if (matched.isEmpty) return const SizedBox.shrink();
                final sorted = [...matched]..sort((a,b) => _toneForSource(a.rule.tone).index
                    .compareTo(_toneForSource(b.rule.tone).index));
                return Column(
                  crossAxisAlignment:CrossAxisAlignment.stretch,
                  children:[
                    const Padding(padding:EdgeInsets.fromLTRB(8,18,8,5),
                      child:Text('గురువు నుంచి స్థానం — మూల BNN ఫలితాలు',
                        style:TextStyle(fontSize:17,fontWeight:FontWeight.bold))),
                    for (final f in sorted)
                      _JupiterResultCard(key:ValueKey(f.rule.id),finding:f,chart:widget.chart),
                  ],
                );
              },
            ),
          ],
        );
      },
    );
  }
}

class _HousePositionsCard extends StatelessWidget {
  final List<BnnHousePosition> locations;
  const _HousePositionsCard({required this.locations});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFF6F7FA),
      child:ExpansionTile(
        key:const ValueKey('bnn-nine-planet-house-positions'),
        initiallyExpanded: false,
        title:const Text('అన్ని 9 గ్రహాలు — లగ్నం & గురు నుంచి స్థానాలు',
          style:TextStyle(fontWeight:FontWeight.bold,fontSize:16)),
        subtitle:const Text('టచ్ చేసి రాశి, డిగ్రీలు, 1–12 స్థానాలు చూడండి'),
        childrenPadding:const EdgeInsets.fromLTRB(12,0,12,12),
        children:[
          const Text('స్థానం మొత్తం రాశుల ఆధారంగా గణించబడింది. '
            'భావ విషయాలు సూచిక మాత్రమే; అవి స్వతంత్ర ఫలితాలు కావు.',
            style:TextStyle(fontSize:12.5,color:Color(0xFF59616B))),
          for (final location in locations)
            Padding(padding:const EdgeInsets.symmetric(vertical:6),
              child:Container(
                width:double.infinity,
                padding:const EdgeInsets.all(10),
                decoration:BoxDecoration(color:Colors.white,
                  borderRadius:BorderRadius.circular(10)),
                child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                  Text('${BnnHouseRelationService.planetLabels[location.name] ?? location.name} • '
                    '${BnnRashiRuleService.signs[location.position.signIndex]} '
                    '${BnnRashiRuleService.dms(location.position.longitude)}'
                    '${location.position.retrograde ? ' (వక్రం)' : ''}',
                    style:const TextStyle(fontWeight:FontWeight.bold)),
                  const SizedBox(height:4),
                  Text('లగ్నం నుంచి ${location.lagnaHouse}వ భావం — '
                       '${BnnHouseRelationService.houseTopics[location.lagnaHouse-1]}'),
                  Text(location.jupiterHouse == null
                     ? 'గురువు నుంచి స్థానం: గణనకు గురుగ్రహం స్థితి లేదు'
                     : 'గురువు నుంచి ${location.jupiterHouse}వ స్థానం'),
                ]),
              ),
            ),
        ],
      ),
    );
  }
}

class _RashiResultCard extends StatelessWidget {
  final BnnRashiFinding finding;
  final AstroChartResult chart;
  const _RashiResultCard({super.key,required this.finding,required this.chart});

  @override
  Widget build(BuildContext context) {
    final rule=finding.rule;
    final p=finding.position;
    final matched=finding.matched;
    final showResult=finding.canDisplayEffect;
    final tone=_toneForRashi(rule.id);
    final style=_toneStyle(tone);
    final jupiterList=chart.planets.where((p)=>p.name=='Jupiter');
    final jupiter=jupiterList.isNotEmpty ? jupiterList.first : null;
    final int? fromJupiter=p==null || jupiter==null ? null :
        BnnHouseRelationService.houseFrom(
          originSign:jupiter.signIndex,targetSign:p.signIndex);
    final label=BnnHouseRelationService.planetLabels[rule.planet] ?? rule.planet;
    final relationLine = finding.house == null ? '' :
        'లగ్నం నుంచి ${finding.house}వ భావం • '
        '${fromJupiter == null ? 'గురు స్థానం లేదు' : 'గురు నుంచి ${fromJupiter}వ స్థానం'}';
    final Text resultTitle=Text(
      showResult ? finding.displayEffect! : '${rule.id} • ${rule.title}',
      softWrap:true,style:TextStyle(fontWeight:FontWeight.bold,fontSize:16,
        height:1.5,color:showResult ? style.text : null));
    return Card(
      margin:const EdgeInsets.symmetric(vertical:6),
      color:const Color(0xFFF2F8F6),
      child:ExpansionTile(
        key:ValueKey('bnn-outcome-${rule.id}'),
        tilePadding:const EdgeInsets.symmetric(horizontal:12,vertical:6),
        title:showResult && p!=null ? Column(
          crossAxisAlignment:CrossAxisAlignment.start,
          children:[
            Text('$label ${BnnRashiRuleService.signs[p.signIndex]}లో '
              '${BnnRashiRuleService.dms(p.longitude)} వద్ద ఉన్నందున',
              style:TextStyle(fontWeight:FontWeight.w600,color:style.text,
                fontSize:14.5,height:1.45)),
            const SizedBox(height:8),
            Container(
              key:ValueKey('bnn-result-highlight-${rule.id}'),
              padding:const EdgeInsets.symmetric(horizontal:12,vertical:13),
              width:double.infinity,
              decoration:BoxDecoration(color:style.background,
                border:Border.all(color:style.border,width:1.2),
                borderRadius:BorderRadius.circular(12)),
              child:resultTitle,
            ),
          ],
        ) : resultTitle,
        subtitle:Padding(padding:const EdgeInsets.only(top:7),
          child:Text(showResult
             ? '$relationLine • ఫలితం టచ్ చేస్తే రూల్ / పరిశీలన / మూలపేజీ'
             : (p==null ? 'గణనకు సమాచారం లేదు' :
               matched ? 'మూల వాక్య పరిశీలన' : 'వర్తించలేదు'),
            style:TextStyle(fontSize:12.5,color:showResult?style.text:const Color(0xFF64707C)))),
        childrenPadding:const EdgeInsets.fromLTRB(15,0,15,15),
        children:[
          _BnnInfoSection('1. రూల్ — ${rule.id}',rule.originalIf),
          const SizedBox(height:9),
          _BnnInfoSection('2. జాతక పరిశీలన',p==null
            ? 'ఈ గ్రహానికి జన్మస్ఫుటం అందలేదు.'
            : '$label: ${BnnRashiRuleService.signs[p.signIndex]} '
                '${BnnRashiRuleService.dms(p.longitude)}'
                '${p.retrograde ? ' (వక్రం)' : ''}. '
                '${matched ? 'IF TRUE — గ్రహం చెప్పిన రాశిలో ఉంది' : 'IF FALSE — ఆ రాశిలో లేదు'}.'),
          if (matched && finding.house!=null) ...[
            const SizedBox(height:6),
            _BnnInfoSection('లగ్నం ఆధారంగా',
              'జన్మలగ్నం నుంచి ${finding.house}వ భావం. '
              '${BnnHouseRelationService.houseTopics[finding.house!-1]} '
              '(భావ సూచిక; స్వతంత్ర ఫలితం కాదు).'),
          ],
          if (p!=null) ...[
            const SizedBox(height:6),
            _BnnInfoSection('గురు ఆధారంగా',fromJupiter==null
              ? 'గురుగ్రహ స్థితి లేక స్థానాన్ని గణించలేకపోయాం.'
              : 'గురువు నుంచి ${fromJupiter}వ స్థానం. '
                'ఈ రాశి ఫలితం గురువు నుంచి వచ్చిన నియమఫలితం కాదు.'),
          ],
          if (matched) ...[
            const SizedBox(height:9),
            _BnnInfoSection('3. మూలంలోని పూర్తి THEN వాక్యం',rule.originalThen),
            if (finding.annotation!=null && finding.annotation!.isNotEmpty)
              Padding(padding:const EdgeInsets.only(top:6),
                child:Align(alignment:Alignment.centerLeft,
                  child:Text(finding.annotation!,
                    style:const TextStyle(fontSize:12.5,color:Color(0xFF8A4D2E))))),
          ],
          const SizedBox(height:9),
          _BnnInfoSection('4. మూలాధారం',
            '${rule.transcriptionFile}\n'
            'BNN మూల స్కాన్: PDF పేజీ ${rule.pdfPage}, '
            'ముద్రిత పేజీ ${rule.printedPage}. '
            'పేజీలో రాశి పట్టిక ఉన్న స్థానం పరిశీలించారు; '
            'THEN వాక్యం అక్షరాలవారీ ధృవీకరణ ఇంకా జరగలేదు.'),
        ],
      ),
    );
  }
}

class _JupiterResultCard extends StatelessWidget {
  final BnnJupiterRelativeFinding finding;
  final AstroChartResult chart;
  const _JupiterResultCard({super.key,required this.finding,required this.chart});

  @override
  Widget build(BuildContext context) {
    final rule=finding.rule;
    final p=finding.targetPosition;
    final tone=_toneForSource(rule.tone);
    final style=_toneStyle(tone);
    final int lagnaHouse=BnnHouseRelationService.houseFrom(
        originSign:chart.ascendantSignIndex,targetSign:p.signIndex);
    return Card(
      margin:const EdgeInsets.symmetric(vertical:6),
      child:ExpansionTile(
        key:ValueKey('bnn-relative-${rule.id}'),
        tilePadding:const EdgeInsets.symmetric(horizontal:12,vertical:6),
        title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('గురువు నుంచి ${rule.jupiterHouse}వ స్థానంలో '
            '${BnnHouseRelationService.planetLabels[rule.target] ?? rule.target} '
            '${BnnRashiRuleService.dms(p.longitude)} వద్ద ఉన్నందున',
            style:TextStyle(fontSize:14.5,fontWeight:FontWeight.w600,color:style.text)),
          const SizedBox(height:8),
          Container(padding:const EdgeInsets.all(12),
            width:double.infinity,
            decoration:BoxDecoration(color:style.background,
              border:Border.all(color:style.border),
              borderRadius:BorderRadius.circular(10)),
            child:Text(rule.originalThen,
              style:TextStyle(fontSize:16,fontWeight:FontWeight.bold,color:style.text))),
        ]),
        subtitle:const Padding(padding:EdgeInsets.only(top:7),
          child:Text('ఫలితాన్ని టచ్ చేస్తే రూల్ • పరిశీలన • పేజీ',
            style:TextStyle(fontSize:12.5))),
        childrenPadding:const EdgeInsets.fromLTRB(14,0,14,14),
        children:[
          _BnnInfoSection('1. రూల్ — ${rule.id} (మూల ${rule.sourceId})',rule.originalIf),
          const SizedBox(height:8),
          _BnnInfoSection('2. జాతక పరిశీలన',
            '${BnnHouseRelationService.planetLabels[rule.target]} '
            '${BnnRashiRuleService.signs[p.signIndex]} '
            '${BnnRashiRuleService.dms(p.longitude)}. '
            'గురుడు ${BnnRashiRuleService.signs[finding.jupiterPosition.signIndex]}. '
            'గురువు నుంచి ${rule.jupiterHouse}వ స్థానం — IF TRUE. '
            'లగ్నం నుంచి ${lagnaHouse}వ భావం.'),
          const SizedBox(height:8),
          _BnnInfoSection('3. మూలంలోని THEN వాక్యం',rule.originalThen),
          const SizedBox(height:8),
          _BnnInfoSection('4. మూలాధారం',
            '${rule.sourceFile} • PDF పేజీ ${rule.pdfPage} • మూల రూల్ ${rule.sourceId}. '
            'మూలగ్రంథంలోని సంప్రదాయ సూచన మాత్రమే.'),
        ],
      ),
    );
  }
}

class _BnnInfoSection extends StatelessWidget {
  final String title;
  final String body;
  const _BnnInfoSection(this.title,this.body);
  @override
  Widget build(BuildContext context) => Align(
    alignment:Alignment.centerLeft,
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,style:const TextStyle(fontSize:14,fontWeight:FontWeight.bold)),
      const SizedBox(height:4),
      Text(body,style:const TextStyle(height:1.45)),
    ]),
  );
}
