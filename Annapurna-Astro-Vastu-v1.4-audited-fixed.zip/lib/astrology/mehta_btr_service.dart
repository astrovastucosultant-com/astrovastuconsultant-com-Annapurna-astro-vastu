import '../models/birth_data.dart';
import 'astro_calculation_service.dart';
import 'btr_macro_context_service.dart';
import 'astro_models.dart';
import 'dasha_service.dart';
import 'sk_mehta_service.dart';
import 'btr_mehta_rule_bridge.dart';

/// An observed historical event. [occurredAt] is a local civil date/time.
/// A date-only event uses noon for an exploratory period comparison; it does
/// not imply that the event took place at noon.
class MehtaBtrEvent {
  final String ruleId;
  final DateTime occurredAt;
  final bool timeKnown;
  final String? note;
  /// Optional source text rule chosen by the practitioner for this event.
  final String? sourceRuleId;

  const MehtaBtrEvent({
    required this.ruleId,
    required this.occurredAt,
    this.timeKnown = false,
    this.note,
    this.sourceRuleId,
  });
}

class MehtaBtrEventEvidence {
  final MehtaBtrEvent event;
  final BtrMacroContext? macroContext;
  final String ruleName;
  final double vimshottariShare;
  final double tribhagiShare;
  final double combinedShare;
  /// Daily uncertainty interval for events without a documented clock time.
  final double minimumShare;
  final double maximumShare;
  final int sampledInstants;
  final String vimshottariLords;
  final String tribhagiLords;
  final List<String> expectedAsc;
  final List<String> expectedMoonAsc;
  final BtrMehtaSourceCheck sourceCheck;
  /// Event-specific blended comparison index, never a birth-time probability.
  final double rankingShare;

  const MehtaBtrEventEvidence({
    required this.event,
    this.macroContext,
    required this.ruleName,
    required this.vimshottariShare,
    required this.tribhagiShare,
    required this.combinedShare,
    required this.minimumShare,
    required this.maximumShare,
    required this.sampledInstants,
    required this.vimshottariLords,
    required this.tribhagiLords,
    required this.expectedAsc,
    required this.expectedMoonAsc,
    required this.sourceCheck,
    required this.rankingShare,
  });
}

class MehtaBtrCandidate {
  final DateTime birthTime;
  final double evidenceShare;
  final List<MehtaBtrEventEvidence> evidence;

  const MehtaBtrCandidate({
    required this.birthTime,
    required this.evidenceShare,
    required this.evidence,
  });
}

class MehtaBtrResult {
  final DateTime originalBirthTime;
  final int testedTimes;
  final List<MehtaBtrCandidate> candidates;
  final DateTime? rangeStart;
  final DateTime? rangeEnd;
  final bool distinguishable;

  const MehtaBtrResult({
    required this.originalBirthTime,
    required this.testedTimes,
    required this.candidates,
    required this.rangeStart,
    required this.rangeEnd,
    required this.distinguishable,
  });

  MehtaBtrCandidate? get best => candidates.isEmpty ? null : candidates.first;
}

/// Mehta primary AD/PD/Sukshma matching for a dated, observed event.
/// This is an exploratory ranking, NOT a validated birth-time rectification
/// formula, event probability, or proof of an exact second of birth.
class MehtaBtrService {
  static const int minimumEvents = 3;
  static const int recommendedEvents = 5;
  static const int maxEvents = 30;

  static final List<SkMehtaEventRule> supportedEvents =
      SkMehtaService.events.where((rule) => !{'M10', 'M15', 'M16'}.contains(rule.id))
          .toList(growable: false);

  static SkMehtaEventRule ruleFor(String id) =>
      supportedEvents.firstWhere((rule) => rule.id == id);

  static String? validateEvents(List<MehtaBtrEvent> events, DateTime birthTime) {
    if (events.length < minimumEvents) {
      return 'కనీసం 3 గత సంఘటనల తేదీలు ఇవ్వండి. 5–10 ఉంటే పోలిక మెరుగ్గా ఉంటుంది.';
    }
    if (events.length > maxEvents) return 'ఒకసారి గరిష్ఠంగా 30 సంఘటనలు మాత్రమే.';
    if (events.map((e) => e.ruleId).toSet().length < 2) {
      return 'కనీసం రెండు వేర్వేరు రకాల సంఘటనలు నమోదు చేయండి.';
    }
    final now = DateTime.now();
    for (final event in events) {
      if (!supportedEvents.any((r) => r.id == event.ruleId)) {
        return 'ఈ సంఘటనకు Mehta timing rule అందుబాటులో లేదు.';
      }
      // A date-only record is not a claimed 12:00 event. Compare calendar
      // dates to avoid rejecting a same-day record merely because noon is
      // still in the future. Do not accept birth-day date-only events whose
      // order relative to the recorded birth instant cannot be established.
      final eventDay = DateTime(event.occurredAt.year,
          event.occurredAt.month, event.occurredAt.day);
      final birthDay = DateTime(birthTime.year, birthTime.month, birthTime.day);
      final today = DateTime(now.year, now.month, now.day);
      if (eventDay.isBefore(birthDay) || eventDay.isAfter(today) ||
          (event.timeKnown &&
              (event.occurredAt.isBefore(birthTime) ||
                  event.occurredAt.isAfter(now))) ||
          (!event.timeKnown && eventDay.isAtSameMomentAs(birthDay))) {
        return 'సంఘటన తేదీ జనన తేదీ తర్వాత, ఈ రోజు లేదా అంతకు ముందు ఉండాలి.';
      }
    }
    final uniqueDays = events.map((e) =>
        '${e.occurredAt.year}-${e.occurredAt.month}-${e.occurredAt.day}').toSet();
    if (uniqueDays.length < minimumEvents) {
      return '3 వేర్వేరు తేదీల్లో జరిగిన సంఘటనలు ఇవ్వండి.';
    }
    return null;
  }

  static List<String> expectedLords(int ascSignIndex, SkMehtaEventRule rule,
      {bool moon = false}) {
    final houses = moon && rule.moonAscHouses.isNotEmpty
        ? rule.moonAscHouses : rule.ascHouses;
    return <String>{
      for (final house in houses)
        SkMehtaService.houseLordFromAsc(ascSignIndex, house),
      ...rule.fixedPlanets,
    }.toList(growable: false);
  }

  static double lordEvidenceShare(List<String> required, List<String> active) {
    if (required.isEmpty || active.isEmpty) return 0;
    final hit = required.toSet().intersection(active.toSet()).length;
    return hit / required.toSet().length;
  }

  /// Evidence coverage is NOT a probability. Require adequate support in the
  /// 2nd–4th dasha positions before assigning a full-match score. Merely
  /// naming both expected distinct lords in two of three positions cannot
  /// satisfy a Mehta rule that requires all three primary places.
  static double primaryEvidenceShare(
      List<String> required, List<String> active, int requiredPlaces) {
    if (required.isEmpty || active.isEmpty) return 0;
    final allowed = required.toSet();
    final matches = active.where(allowed.contains).length;
    final threshold = requiredPlaces.clamp(1, 3).toInt();
    final coverage = (matches / threshold).clamp(0.0, 1.0).toDouble();
    return lordEvidenceShare(required, active) * coverage;
  }

  static List<String> primaryPlaces(DashaPath? path) => path == null
      ? <String>[]
      : <String>[
          path.antardasha.lord,
          path.pratyantardasha.lord,
          path.sukshma.lord,
        ];

  static String formatPlaces(List<String> lords) =>
      lords.isEmpty ? '—' : lords.join(' → ');

  static MehtaBtrEventEvidence checkEvent({
    required AstroChartResult chart,
    required MehtaBtrEvent event,
    required DateTime birthDateTime,
    required DashaSystemResult vim,
    required DashaSystemResult trib,
    BtrMehtaSourceCheck? sourceCheck,
  }) {
    final rule = ruleFor(event.ruleId);
    final ascExpected = expectedLords(chart.ascendantSignIndex, rule);
    final moonSign = chart.planets.firstWhere((p) => p.name == 'Moon').signIndex;
    final moonExpected = rule.moonAscCheck
        ? expectedLords(moonSign, rule, moon: true) : <String>[];

    double check(List<String> observed) {
      final ascShare = primaryEvidenceShare(
          ascExpected, observed, rule.requiredPrimaryMatches);
      if (!rule.moonAscCheck || moonExpected.isEmpty) return ascShare;
      // ASC is the primary evidence. Moon ASC is separately supported.
      // The 75/25 blend is an app-designed comparison index, not a Mehta
      // formula or empirically calibrated probability.
      return 0.75 * ascShare +
          0.25 * primaryEvidenceShare(
              moonExpected, observed, rule.requiredPrimaryMatches);
    }

    // If no time was documented, scan early / middle / late on the actual
    // calendar day. Averaging avoids silently declaring noon to be the real
    // event instant or cherry-picking the most favourable of three times.
    final instants = event.timeKnown
        ? <DateTime>[event.occurredAt]
        : <DateTime>[
            DateTime(event.occurredAt.year, event.occurredAt.month,
                event.occurredAt.day, 0, 0, 0),
            DateTime(event.occurredAt.year, event.occurredAt.month,
                event.occurredAt.day, 12, 0, 0),
            DateTime(event.occurredAt.year, event.occurredAt.month,
                event.occurredAt.day, 23, 59, 59),
          ];
    final vims = <double>[];
    final tribs = <double>[];
    final details = <double>[];
    var vimPlaces = <String>[];
    var tribPlaces = <String>[];
    for (final instant in instants) {
      final v = primaryPlaces(DashaService.pathAt(vim, instant));
      final t = primaryPlaces(DashaService.pathAt(trib, instant));
      if (instant.hour == 12 || event.timeKnown) {
        vimPlaces = v;
        tribPlaces = t;
      }
      final vScore = check(v);
      final tScore = check(t);
      vims.add(vScore);
      tribs.add(tScore);
      details.add(0.5 * vScore + 0.5 * tScore);
    }
    double average(List<double> values) =>
        values.reduce((a, b) => a + b) / values.length;
    final vimScore = average(vims);
    final tribScore = average(tribs);
    final dashaShare = average(details);
    final selectedCheck = sourceCheck ?? const BtrMehtaSourceCheck(
        evaluated:false, matched:false, explanation:'మూల రూల్‌ను పరిశీలించలేదు');
    // Fixed app-designed weighting ONLY for a practitioner-selected,
    // automatically checked source condition. All other rules are manual.
    // This measures comparative rule agreement, never scientific certainty.
    final rankingShare = selectedCheck.evaluated
        ? 0.75 * dashaShare + 0.25 * (selectedCheck.matched ? 1.0 : 0.0)
        : dashaShare;
    return MehtaBtrEventEvidence(
      event: event,
      macroContext: chart.planets.any((p) => p.name == 'Jupiter')
          ? BtrMacroContextService.compute(
              natalChart: chart,
              birthDate: birthDateTime,
              eventDate: event.occurredAt,
            ) : null,
      ruleName: rule.event,
      vimshottariShare: vimScore,
      tribhagiShare: tribScore,
      combinedShare: dashaShare,
      minimumShare: details.reduce((a, b) => a < b ? a : b),
      maximumShare: details.reduce((a, b) => a > b ? a : b),
      sampledInstants: instants.length,
      vimshottariLords: formatPlaces(vimPlaces),
      tribhagiLords: formatPlaces(tribPlaces),
      expectedAsc: ascExpected,
      expectedMoonAsc: moonExpected,
      sourceCheck: selectedCheck,
      rankingShare: rankingShare,
    );
  }

  static Future<MehtaBtrCandidate> scoreCandidate({
    required BirthData natal,
    required DateTime candidateBirthTime,
    required List<MehtaBtrEvent> events,
    Future<AstroChartResult> Function(BirthData)? chartCalculator,
  }) async {
    final data = natal.copyWith(localDateTime: candidateBirthTime);
    final chart = await (chartCalculator ?? AstroCalculationService.calculate)(data);
    final vim = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: candidateBirthTime,
    );
    final trib = DashaService.system(
      kind: DashaSystemKind.tribhagi,
      chart: chart,
      birthDateTime: candidateBirthTime,
    );
    final automaticSourceChecks = events.any((e) =>
      BtrMehtaRuleBridge.ruleNumber(e.sourceRuleId) != null)
        ? BtrMehtaRuleBridge.evaluatedBookRules(chart)
        : null;
    final details = <MehtaBtrEventEvidence>[
      for (final event in events)
        checkEvent(chart: chart, event: event,
          birthDateTime: candidateBirthTime, vim: vim, trib: trib,
          sourceCheck: BtrMehtaRuleBridge.inspect(event.sourceRuleId,
            automaticSourceChecks ?? {})),
    ];
    // Each observed event has equal importance; do not count a repeated planet
    // twice as two independent events.
    final mean = details.map((r) => r.rankingShare).reduce((a, b) => a + b) /
        details.length;
    return MehtaBtrCandidate(
      birthTime: candidateBirthTime,
      evidenceShare: mean,
      evidence: List.unmodifiable(details),
    );
  }

  static Future<MehtaBtrResult> search({
    required BirthData natal,
    required List<MehtaBtrEvent> events,
    int plusMinusMinutes = 60,
    Future<AstroChartResult> Function(BirthData)? chartCalculator,
    void Function(int done, int total)? onProgress,
  }) async {
    final issue = validateEvents(events, natal.originalBirthDateTime);
    if (issue != null) throw ArgumentError(issue);
    if (![30, 60, 120, 360, 720].contains(plusMinusMinutes)) {
      throw ArgumentError('జనన సమయ Search పరిధి సరైనది కాదు.');
    }
    final origin = natal.originalBirthDateTime;
    final coarseStep = switch (plusMinusMinutes) {
      720 => 30,
      360 => 15,
      120 => 5,
      _ => 2,
    };
    final offsets = <int>[
      for (var minute = -plusMinusMinutes;
          minute <= plusMinusMinutes;
          minute += coarseStep)
        minute * 60,
    ];
    final evaluated = <int, MehtaBtrCandidate>{};
    var done = 0;
    var total = offsets.length;

    Future<void> runOne(int seconds) async {
      if (evaluated.containsKey(seconds)) return;
      final candidate = await scoreCandidate(
        natal: natal,
        candidateBirthTime: origin.add(Duration(seconds: seconds)),
        events: events,
        chartCalculator: chartCalculator,
      );
      evaluated[seconds] = candidate;
      done++;
      onProgress?.call(done, total);
      if (done % 5 == 0) await Future<void>.delayed(Duration.zero);
    }

    for (final offset in offsets) {
      await runOne(offset);
    }
    final preliminary = evaluated.entries.toList()
      ..sort((a, b) => b.value.evidenceShare.compareTo(a.value.evidenceShare));
    // Refine close to the three strongest coarse candidates. The 30-second
    // refinement resolution does not mean the result has 30-second accuracy.
    final refineOffsets = <int>{};
    for (final anchor in preliminary.take(3)) {
      for (var s = -4 * 60; s <= 4 * 60; s += 30) {
        final offset = anchor.key + s;
        if (offset.abs() <= plusMinusMinutes * 60 &&
            !evaluated.containsKey(offset)) {
          refineOffsets.add(offset);
        }
      }
    }
    total += refineOffsets.length;
    for (final offset in refineOffsets.toList()..sort()) {
      await runOne(offset);
    }

    final ranked = evaluated.values.toList()
      ..sort((a, b) {
        final byScore = b.evidenceShare.compareTo(a.evidenceShare);
        if (byScore != 0) return byScore;
        // Tie-break is display ordering only; it never confers uniqueness.
        return a.birthTime.difference(origin).abs().compareTo(
              b.birthTime.difference(origin).abs(),
            );
      });
    if (ranked.isEmpty) {
      throw StateError('BTR సమయాల పరిశీలనలో ఉపయోగపడే ఫలితం రాలేదు.');
    }
    final maxScore = ranked.first.evidenceShare;
    final competitive = ranked.where(
        (r) => r.evidenceShare >= maxScore - 0.025).toList();
    final starts = competitive.map((c) => c.birthTime).toList()..sort();
    final breadth = starts.last.difference(starts.first).inSeconds.abs();
    // A unique, exact birth second cannot be established from merely matching
    // a few natal dasha lord names. Avoid claiming precise BTR if tied.
    final supportedEventsCount = ranked.first.evidence
        .where((entry) => entry.combinedShare >= 0.5).length;
    final distinguishable = breadth <= 120 &&
        competitive.length <= 5 && maxScore >= 0.55 &&
        supportedEventsCount >= minimumEvents;
    return MehtaBtrResult(
      originalBirthTime: origin,
      testedTimes: evaluated.length,
      candidates: List.unmodifiable(ranked.take(8)),
      rangeStart: starts.first,
      rangeEnd: starts.last,
      distinguishable: distinguishable,
    );
  }
}
