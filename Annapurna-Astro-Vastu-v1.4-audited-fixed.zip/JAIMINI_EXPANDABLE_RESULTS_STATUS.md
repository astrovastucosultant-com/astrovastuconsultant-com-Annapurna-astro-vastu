# Jaimini expandable audit UI patch
- Added expandable Telugu cards for finance, long-distance travel, and father's health review in MD/AD sheet.
- Cards show live sign-activation evidence from JaiminiActivationAudit, with an explicit pending source verification label.
- These are audit prompts, not event predictions. No invented classical rule IDs, dates, or diagnoses.
- Full primary-source verified predictions, PD/Prana and daily integration remain pending.
- Flutter SDK is not installed in this environment; no flutter analyze or APK build was run.
