from pathlib import Path
p=Path('/mnt/data/work154/astro_app/lib/screens/chart_screen.dart')
s=p.read_text()
s=s.replace("import 'hasta_samudrika_tab.dart';", "import 'unified_rule_result_tile.dart';\nimport 'hasta_samudrika_tab.dart';",1)
needle='  void _showResult(BuildContext rootContext, VargaRuleHit item) {'
helper='''  // Shared presentation layer; underlying rule-engine results are never mutated.
  RuleResultData _unifiedData(VargaRuleHit item) {
    final verdict = !item.autoEvaluated || !item.applicable
        ? RuleVerdict.unverified
        : item.tone == VargaRuleTone.favorable
            ? RuleVerdict.favourable
            : item.tone == VargaRuleTone.caution
                ? RuleVerdict.adverse
                : RuleVerdict.mixed;
    return RuleResultData(
      topic: item.topic,
      result: item.autoEvaluated && item.applicable
          ? item.result
          : item.autoEvaluated
              ? 'ఈ జాతకంలో ఈ నియమం వర్తించలేదు — ఇది ప్రతికూల ఫలితం కాదు.'
              : 'మూల నియమం నమోదు; ఆటోమేటిక్ పరిశీలన ఇంకా ధృవీకరించలేదు.',
      verdict: verdict,
      examination: item.inspection,
      rule: item.rule,
      ruleId: item.ruleId,
      source: item.source,
      remedy: item.remedy.isNotEmpty ? item.remedy : null,
    );
  }

'''
assert needle in s
s=s.replace(needle,helper+needle,1)
start=s.index('        else\n          ...displayed.map(\n')
end=s.index('        if (factor == 16 && d16AuditOnly.isNotEmpty)',start)
s=s[:start]+'''        else
          ...displayed.map((item) => UnifiedRuleResultTile(
                key: ValueKey('varga-${factor}-${item.ruleId}'),
                data: _unifiedData(item),
              )),
'''+s[end:]
# D3 source-only use shared tile, preserve dedicated audit drawer and no red for unmatched.
start=s.index('              children: d3SourceOnly.map((item) => ListTile(')
end=s.index('            ),\n          ),\n        if (factor == 16)',start)
s=s[:start]+'''              children: d3SourceOnly.map((item) => UnifiedRuleResultTile(
                key: ValueKey('d3-audit-${item.ruleId}'),
                data: _unifiedData(item),
              )).toList(growable: false),
'''+s[end:]
# D16 video matches use shared tile
start=s.index('                  ...d16GuruMatched.map((item) => Card(')
end=s.index('                  ExpansionTile(',start)
s=s[:start]+'''                  ...d16GuruMatched.map((item) => UnifiedRuleResultTile(
                    key: ValueKey('d16-guru-${item.ruleId}'),
                    data: _unifiedData(item),
                  )),
'''+s[end:]
p.write_text(s)
pub=Path('/mnt/data/work154/astro_app/pubspec.yaml');x=pub.read_text();assert 'version: 1.4.153+153' in x;pub.write_text(x.replace('version: 1.4.153+153','version: 1.4.154+154'))
