# D24 Build 56 — Education.pdf Source Specification

## Master order
1. Jaimini/Navamsha: PK and AK-relative education houses.
2. Parashari fifth-cusp/nakshatra-lord Navamsha stream method.
3. Chaturvimshamsha: Lagna desire, Lagna lord fulfilment, Sun dedication, Moon mind.
4. Education levels: 2H sanskar, 4H schooling, 5H graduation, 9H higher study, 8H research, 12H hostel/away.
5. Rahu/Ketu interruption/end and 9H+12H foreign-study cross-check.

## App sign category (user-configured; not substituted for PDF cusp method)
- Technical: Aries, Scorpio, Capricorn, Aquarius.
- Semi-technical: Gemini, Leo, Virgo.
- Non-technical: Taurus, Cancer, Libra, Sagittarius, Pisces.

## Safeguards
- Aspect/papakartari/cusp rules remain source-only until exact arithmetic is available.
- A single Rahu/Ketu trigger is a caution, not a guaranteed end.
- Subject shortlist is supporting evidence, not a certainty.
- Birth-time correction requires D24 recalculation.
