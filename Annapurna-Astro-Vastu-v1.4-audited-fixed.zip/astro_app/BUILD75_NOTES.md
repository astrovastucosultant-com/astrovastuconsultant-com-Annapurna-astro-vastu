# Build 75 — D10 Final Client Layout + Devata Work-Flow (09 Oct 2026)

Base: Build74 v1.4.74. Chart mathematics and existing source-rule registries are preserved.

## D10 client result order

1. Gocharastha — Business / Self Employment
2. Agocharastha — Job / Service
3. Year-wise career results — Rise / Fall / Middle(Change/Transfer), with year tap → MD/AD dates + rule IDs
4. All matched yogas in one place
5. Career Suitability — profession families + Evidence Match % only
6. Profession Nature + Amsha Devata — Devata modifies work-flow/style of already selected professions
7. Graha Strength / Career Quality — BPHS Avastha and Brihat Jataka are kept separate from Career Suitability %
8. Rule / Inspection Details — applied/final source-linked D10 audit; unmatched/source-only rules remain in the separate audit drawer

## Amsha Devata lock

- Devata does not create a profession.
- Devata does not change Evidence Match %.
- Devata does not re-rank profession families.
- Devata contributes a source-grounded work-flow modifier (authority/action/discipline/mobility/communication/resources/guidance/creation/expansion, according to the mapped Devata nature).
- Final Career Interpretation = selected profession families + sign nature + Devata work-flow modifier.

## Source discipline

- No synthetic year or profession is inserted.
- Shayanadi main/sub-state is not fabricated when exact local-sunrise Birth Ghati or validated Name Anka is unavailable.
- Brihat Jataka quality is not converted to invented +/- percentage points.
- Evidence Match % remains evidence coverage, not probability.

## Verification

Flutter/Dart SDK is not available in the runtime container. APK compilation must be verified by the existing GitHub Actions workflow. ZIP structure/integrity is checked before handoff.
