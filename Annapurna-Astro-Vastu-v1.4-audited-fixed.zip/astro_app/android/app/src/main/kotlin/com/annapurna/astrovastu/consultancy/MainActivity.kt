package com.annapurna.astrovastu.consultancy

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
