package com.annapurna.astrovastu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
