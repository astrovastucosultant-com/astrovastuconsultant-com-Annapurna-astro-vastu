package com.annapurna.astrovastu.build11

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
