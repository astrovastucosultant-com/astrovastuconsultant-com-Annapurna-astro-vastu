# Build132 — SK Mehta + BTR rulebook navigation and status fix

**Version:** 1.4.132+132

## Verified issue
The rulebook screen printed `స్థితి: జాతక గణన చేయలేదు / Insufficient Data` for every entry unconditionally, even when source browsing was the intended action. It was **not** a real horoscope evaluator response. A BTR launch button was present only when the rulebook was reached from the chart panel; when opened from within the BTR event form it did not have a callback and showed no navigation action.

## Changes
- A rulebook-only status that does NOT imply a failed or attempted calculation.
- From the chart-level rulebook: keep the existing `BTR — గత సంఘటనల నమోదు / Final Search` action.
- From both rulebook entry points in the BTR event form (the full catalog button and source rule detail links): show `BTR గత సంఘటనలకు తిరిగి వెళ్లండి` to return to the original event form (no duplicate BTR form and no loss of in-memory typed event details).
- When a rulebook instance has no birth-data route, explain to open a chart before starting BTR; never fabricate a chart evaluation.
- Existing BTR candidate evaluation, event persistence, Mehta rule catalog data, percentages, rule IDs, KP context, and chart apply callback remain unchanged.

## Boundaries
- This is a user-interface and navigation correction; it does **not** complete the 46 BTR rule algorithms or supply second-accurate rectification.
- ZIP structure/integrity and static source checks pass; compile/APK/device execution require GitHub Actions.
- GitHub build workflow expects replacing the repository-root binary `Annapurna-Astro-Vastu-v1.4-audited-fixed.zip` with the full archive as ONE ZIP file, not extracting its source on GitHub.
