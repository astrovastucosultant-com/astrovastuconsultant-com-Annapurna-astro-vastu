# Build105 — Annapurna Astro Vastu v1.4.105+105

## Why
Build87 user screenshot showed `శరీర ఆకృతి / స్వభావం — 5వ సప్తాంశం` as grey Audit. The calculation had a source table with 42/84 rows, covering Aries–Virgo but no sign-specific text for Libra–Pisces. The fallback was intentionally non-autoevaluated.

## Changes
- Completed remaining 42 D1 ascendant sign × 1–7 saptamsha body/nature rows (Libra–Pisces) using Saptamsha_Santana_Niyamalu.pdf pages 12–15.
- All 84 combinations are represented with page-specific citations; the single chart-specific matching row becomes a Result -> Rule -> Source entry instead of the previous missing-row audit card.
- Clarified in UI: 84/84 **body/nature** coverage is distinct from the other 25 D7 source-only/sensitive/exact-arithmetic pending rules.
- Existing D7 child, twins, adoption, Rinanubandha, comfort, legacy D4/D10 etc. code not removed.
- Expanded `test/d7_build104_body_rows_test.dart` to exercise all 12 signs × 7 amsha = 84 inputs.
- Traditional book descriptions, **not** scientific/medical diagnosis and not proof of character.

## Audit caveats
- The remaining 25 advanced D7 audit-only entries were **not** converted to matched results by this patch.
- Existing remedies still require source-specific matches.
- Flutter SDK/emulator absent in working environment. ZIP/structural tests are not an Android build. A GitHub Actions run is required for new APK.

## GitHub deployment
Replace ONLY `Annapurna-Astro-Vastu-v1.4-audited-fixed.zip` at repository root; the existing workflow unpacks `astro_app` and compiles APK.
