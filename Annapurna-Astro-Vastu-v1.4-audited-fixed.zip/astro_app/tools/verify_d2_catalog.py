"""Static D2 rule coverage check (stdlib only; run before Flutter compile)."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
rules=(root/'lib/astrology/d2_dhana_asthi_registry.dart').read_text()
engine=(root/'lib/astrology/d2_wealth_evaluation_service.dart').read_text()
rule_ids=re.findall(r"id:'(D2-[A-Z]+-\d{3})'",rules)
auto_ids=re.findall(r"hit\('(D2-[A-Z]+-\d{3})'",engine)
pending_ids=re.findall(r"'(D2-[A-Z]+-\d{3})':",engine)
assert len(rule_ids)==58, f'Expected 58 rule IDs, found {len(rule_ids)}'
assert len(rule_ids)==len(set(rule_ids)), 'Duplicate rule IDs'
assert len(auto_ids)==len(set(auto_ids)), 'Duplicate checks for rule ID'
assert not (set(pending_ids) & set(auto_ids)), 'Rule both auto and pending'
assert set(rule_ids)==set(auto_ids)|set(pending_ids), 'Unaccounted source ID'
print(f'PASS: source=58, auto-condition code={len(auto_ids)}, pending={len(pending_ids)}, duplicates=0')
