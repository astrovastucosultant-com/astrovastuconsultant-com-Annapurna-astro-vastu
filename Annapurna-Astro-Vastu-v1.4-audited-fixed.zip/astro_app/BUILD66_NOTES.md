# Build 66 — D24 Sign Education + Sign-Lord Career Guidance

Version: 1.4.66+66

## D24 client guidance update
- Keeps matched-only Education.pdf rule engine and Result tap audit.
- Adds a broad education-options guidance row/card for the D24 5th-house sign.
- Adds the D24 5th-house sign lord and its broad profession fields.
- Profession fields are cross-referenced from the app's existing source-backed D10 profession catalog (D10.pdf pp.42–47).
- Education-by-sign options are explicitly labelled advisory/app guidance, not a universal Education.pdf exact-course rule.
- Exact course still requires 5H/5L/cusp/nakshatra + matched subject rules.
- Exact profession still requires D10 exact-profession validation.
