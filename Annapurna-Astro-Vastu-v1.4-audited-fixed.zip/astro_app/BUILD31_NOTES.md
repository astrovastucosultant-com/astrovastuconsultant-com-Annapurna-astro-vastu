# Build 31 — Consultation Timing Polish

Version: 2.17.0+31

## Consultation bottom-sheet readability
- Added Android system-navigation safe-area padding to event consultation sheets so the last Jaimini/timing lines can be scrolled fully above the navigation bar.

## Peak evidence presentation
- Peak evidence now has a separate highlighted block with exact start/end date-time.
- When the strongest source-backed interval is the full Strong Confluence window, the UI states that explicitly instead of inventing an artificial middle-date peak.

## Jaimini confirmation clarity
- Best-overlap card now shows favorable/caution hit counts plus the actual source rule IDs when available.
- The client-facing sentence now includes the peak evidence window and Jaimini confirmation counts.

## Source boundary
- No new astrological arithmetic was fabricated. This build only improves presentation of calculations already produced by the Build 30 engine.
