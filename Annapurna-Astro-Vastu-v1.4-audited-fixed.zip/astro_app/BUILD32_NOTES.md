# Build 32 — Source Varga Rules + Rule→Remedy flow

- Consultation timing polish: Best Window highlight, duplicate best removed from other windows, Tribhagi no-support text, concise Jaimini summary, larger Android bottom safe area.
- Added source-linked Varga Rule Engine under each varga chart.
- Applied results show only conditions that the current engine can reproduce without guessing.
- Flow: Result → Rule → Remedy.
- Added source rule catalogs for D1/D3/D4/D7/D9/D10/D12/D16/D20/D24/D27/D30/D40/D45/D60.
- Sources used: supplied 108 Gems rule-based PDF, D10 guide, Saptamsha rules, Saral3 compilation, Sarala VII, plus the existing supplied Gemstone Remedy rule-engine safety boundary.
- Rules requiring unimplemented source-specific aspects/strength/karaka arithmetic remain source-only instead of fabricated auto-results.
