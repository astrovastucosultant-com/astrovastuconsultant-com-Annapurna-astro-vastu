# Build96 — D4 Timing + Result Hierarchy Polish

- Preserves all Build95 D4 full-rule engine rules.
- Main timing card now prioritizes Current/Future Vimshottari candidate windows and includes age ranges.
- Past property timing windows moved to Source Rules / Audit only.
- D4 Rule Coverage percentage moved out of main horoscope results into Audit because it is a registry coverage metric, not a prediction.
- Matched D4 result cards now include a compact matched-evidence breakdown on the card.
- Evidence percentages remain evidence coverage, not probability or guarantee.
- Version 1.4.96+96.
