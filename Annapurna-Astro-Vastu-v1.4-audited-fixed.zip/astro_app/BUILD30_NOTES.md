# Build 30 — Saved Charts + Consultation Timing Detail + Tablet/Windows readiness

Version: 2.16.0+30

## Saved Charts
- Added persistent **Saved Charts** storage using the original birth inputs (name, DOB/TOB, place, latitude/longitude, timezone, ayanamsa).
- Chart AppBar now has **Save Chart**.
- Home bookmark opens **Saved Charts & Reports** with two tabs.
- Tapping a saved chart reopens and recalculates the complete chart with the current engine/rules, so future engine improvements are inherited automatically.
- Duplicate save of the same birth inputs refreshes that saved chart instead of creating endless copies.
- Up to 100 saved charts are retained locally on the device/system profile.

## Consultation timing
- Best overlap now shows the exact supporting **Vimshottari MD/AD/PD names**.
- Best overlap now shows the exact supporting **Tribhagi MD/AD/PD names**.
- Jaimini favorable/caution rule confirmation is visible beside the timing evidence.
- A **Peak evidence window** is shown only when a source-backed Strong Confluence interval exists. No artificial middle-date or percentage peak is fabricated.
- Supporting windows also show the actual dasha chains, not only Vim/Tribhagi checkmarks.

## Tablet / desktop usability
- Main birth-entry screen is width constrained for tablet/desktop instead of stretching edge-to-edge.
- Chart/system pages are centered with a desktop/tablet max content width while remaining full-width on phones.
- Planet detail bottom sheet is capped for wide displays.
- Mouse, trackpad, stylus and touch scrolling are enabled app-wide.
- Added a **Windows build workflow** producing `Annapurna-Astro-Vastu-Windows.zip`.
- The same Android APK remains usable on Android tablets; UI now scales more cleanly on wider screens.

## Source boundary
- Jaimini Chara Dasha calendar dates are still not fabricated where supplied source arithmetic is incomplete. Jaimini remains an independent source-rule confirmation layer until the full special-case duration/direction arithmetic is explicit.
- Timing windows remain astrological support windows, not guarantees or probability percentages.
