# Build 88 — Master Remedy Engine

- Preserves Build87 D2 Indu Lagna / Manduka outer layer / D16 vehicle confirmation.
- Adds source-bound `RemedyRuleService` from user supplied `remidi.pdf` (150 pages).
- Every VargaRuleHit now carries source-backed remedy support; existing practical/source-specific guidance is preserved and the Compendium support is appended.
- Bhava + Bhava lord + occupant + Karaka is the main remedy selection principle.
- Includes safe Bhava 1–12, Graha Adhi/Pratyadhi Devata, Dosha, D10/D12/D16/D20/D24/D27/D30, Rahu-Ketu/Sarpa, Pitru/Matru, wealth/property/vehicle contextual layers.
- Gemstones are never auto-prescribed; separate Gem Remedy eligibility remains mandatory.
- Medical issues retain doctor/treatment requirement; spiritual remedies are support only.
- Hazardous ritual details are not reproduced; Homa/temple rites are shown only as qualified priest/temple-supervised options.
