# Build 87 — D2 Wealth Analysis Layers

- Preserves all Build86 D2 source rules and all prior app features.
- Adds calculated Indu Lagna sign on the D2 analysis screen using the source kala values and the supplied algorithm.
- Adds a Manduka Hora outer-layer placeholder linked to the LB rules, without inventing a construction algorithm absent from the supplied PDF.
- Adds explicit D16 Shodashamsha vehicle-confirmation guidance while keeping D4 for property/house/land.
- Keeps Result -> Rule Inspection -> Remedy Status flow.
- Version 1.4.87+87.
