# Build 28 — Client Consultation Mode

Version: `2.14.0+28`

## Added

- New **క్లైంట్ / Client Consultation Mode** tab directly after the Jataka tab.
- Consultation speaking order: current dasha → strong areas → mixed areas → caution areas → timing → advice/remedy.
- Current Vimshottari + Tribhagi MD/AD/PD summary.
- Event cards for career, education, wealth, property, siblings/effort, marriage/partnership and children using the existing Ashtakavarga + dasha + current-transit evidence engine.
- One-tap **క్లైంట్కు చెప్పండి** script, practical advice, evidence expansion and rule IDs.
- 30-second opening summary showing strong and caution areas.
- Jaimini applicable source-verified combinations as supporting evidence.
- KP consultation status note; Star/Sub remains active through planet detail, while full 12-cusp promise/denial is not overstated.
- Planet quick speaking notes using current Vimsopaka/Vargaja strength, Star Lord, Sub Lord and D60 Amsa Devata.
- Planet detail sheet now includes a **క్లైంట్కు చెప్పండి** card with copy action.
- Copy / Save / Share full consultation summary.

## Safety / audit behaviour

- Green / Amber / Red are app evidence labels, not probability percentages.
- Single-rule or single-varga deterministic predictions are avoided.
- D60 is kept as secondary evidence.
- Practical advice is shown before remedies; remedies are not fabricated.
