# Build95 — D4 Full Property Rule Engine

- Preserves all previous modules and Build94 D20 polish.
- D4 main result now exposes matched source-backed property/inheritance rules separately instead of only one generic percentage.
- Uses audited Dhana_Aasthi source rules for: fixed property, own house, land, old house/delay, no-property caution, D4 confirmation, property-derived money, leaving property, house disputes, maternal property, paternal property, inheritance wealth/home, foreign house.
- D2-PR-011 purchase-period rule is now surfaced as Vimshottari MD/AD candidate year windows using D1 4L/9L/11L with D4 confirmation. These are candidate windows, not guaranteed dates.
- Adds D4 Full Rule Coverage summary and D4 Source Rules / Audit drawer for unmatched/source-only items.
- Evidence percentages are coverage scores, not probabilities.
