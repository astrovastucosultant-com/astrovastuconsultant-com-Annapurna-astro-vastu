# D12 Build106 — Source Coverage / నియమ మూలాల పరిశీలన

**మూలం:** యూజర్ అందించిన `D12.pdf`, 51 scanned pages, *Saral Jyotish Part VII*, Chapter 9 "Dwadashamsha D12".
**యాప్ వెర్షన్:** `1.4.106+106` (అదే v1.4 series).
**Registry:** `lib/astrology/d12_source_rule_service.dart`.
**Source catalog:** 49 explicit doctrinal/example-derived analysis rows + 20 biographical case-study references = **69 IDs**.

## ఏ విధంగా చూపిస్తున్నాం?

- **Matched:** D12లో మళ్లీ లెక్కించగల నిర్దిష్ట భావ/గ్రహ/సంయోగ/Parashari graha-drishti షరతులకు మాత్రమే `applicable=true`; main resultలో ఫలితం → Rule → Actual Inspection → `D12.pdf` పేజీ → Remedy.
- **Unmatched:** condition జాతకంలో లేదు; source/auditలో reason కనిపిస్తుంది.
- **Pending source audit:** KL / Cyclical D12కి ఖచ్చిత నిర్మాణ సూత్రం ఈ PDF excerptలో పూర్తి స్థాయిలో పేర్కొనలేదు; దాన్ని Parashari D12గా ఊహించలేదు. బలం, రాజయోగ definition, వ్యక్తుల bio-example inference కూడా auditలో.
- **Sensitive:** తల్లిదండ్రుల ఆయుర్దాయం పేజీలు పూర్తి source catalogగా ఉన్నాయి; వ్యక్తిగత మరణ తేదీ/ఎన్ని సంవత్సరాలు అనే అంచనాలు ఆటోమేటిక్‌గా ఉత్పత్తి చేయవు.
- **Remedy:** D12.pdfలో నిర్దిష్ట పరిహార prescription లేదు. `remidi.pdf` exact rule–remedy pairing నిర్ధారణ లేకుంటే కొత్త పరిహారాలు ఊహించి పెట్టము.
- **Important original-source distinction:** D12.pdf p.18 labels father **PK**, whereas p.25 labels father **BK** for the parent-care application. Both descriptions preserved with their respective page citations, not silently reconciled.

## పేజీ వారీ ఆడిట్ (PDF page number)

| PDF పేజీ | అసలు విషయం | Index/Rule |
|---:|---|---|
| 1 | అధ్యాయం పరిచయం; ఏడు అంశాల జాబితా | D12 section list |
| 2 | Ancestor blessings: 5 general source rules | ANC-01…05 |
| 3 | Ramakrishna D1, D12, 11L–9L example | ANC-06 / CASE-01 |
| 4 | Ramakrishna D12 with KL as lagna, AK/AmK examples | CASE-01 / ANC-03,05 |
| 5 | Vivekananda D1, D12, 11L–2L example | ANC-07 / CASE-02 |
| 6 | Vivekananda KL; AmK/PK/DK/AK, yogas, Jupiter dasha | CASE-02 |
| 7 | Modi D1, D12, 2L–5L Dhana yoga | ANC-08 / CASE-03 |
| 8 | Modi KL / 9L–10L, GK, nodes, other associations | ANC-09 / CASE-03 |
| 9 | Childhood conditions: 2H/2L and 4H/4L affliction; Parashar vs KL | CHILD-01…05 |
| 10 | Oprah 2H, 2L, 4H example | CHILD-06 / CASE-04 |
| 11 | Oprah KL with 2H/4H case analysis | CASE-04 |
| 12 | 1945 birth example, 2H/2L and Moon | CASE-05 |
| 13 | 1945 KL example, 2H/4H and yoga | CASE-05 |
| 14 | 1973 birth example, AK/2H and 4H | CASE-06 |
| 15 | Duplicate scan of prior p.13 material, retained in page audit | CASE-05 |
| 16 | Duplicate/alternate scan of p.14 material, retained | CHILD-07 / CASE-06 |
| 17 | 1973 example continuation: 2H/4H, KL | CASE-06 |
| 18 | Parent–child relation, Sun/Moon, 9H/4H, PK/MK/AK and dominance | REL-01…06 |
| 19 | 1975 August 14 charts and Sun/Moon aspect evidence | REL-07 / CASE-07 |
| 20 | 1975 example KL; PK/AK and MK/AK | REL-08…09 / CASE-07 |
| 21 | 1984 August 9 relation charts, lagna influence | CASE-08 |
| 22 | 1984 KL: Sun/Moon nodes and parental feelings | CASE-08 |
| 23 | 1995 January 4 relation charts | CASE-09 |
| 24 | 1995 KL: Karaka relationships, father/mother contrast | CASE-09 |
| 25 | Helpful to parents: 6 numbered rules, BK vs PK source variation | CARE-01…06 |
| 26 | 1972 September 28 source charts | CASE-10 |
| 27 | 1972 KL chart, AK/MK/BK and family example | CASE-10 |
| 28 | 1967 March 31 source charts | CASE-11 |
| 29 | 1967 KL/AK Moon/Venus/Jupiter example | CARE-07 / CASE-11 |
| 30 | 1975 August 14 caring for parents case | CASE-12 |
| 31 | 1975 KL continuation, AK/BK/MK | CASE-12 |
| 32 | 1977 November 21 source charts | CASE-13 |
| 33 | 1977 KL, PK/MK/GK examples | CASE-13 |
| 34 | Inheritance/legacy definitions; 5 numbered rules | EST-01…04, EST-07 |
| 35 | Inheritance rule 5 continued, 1917 example | EST-07 / CASE-14 |
| 36 | 1917 KL inheritance example | CASE-14 |
| 37 | Cyclical D12 and KL inheritance example | EST-08 / CASE-14 |
| 38 | 1960 inheritance case, 8L–11L, KL | EST-09 / CASE-15 |
| 39 | 1960 KL/Cyclical D12 and PK/GK influence | CASE-15 |
| 40 | 1960 example continuation, 1962 new case | CASE-15 / CASE-16 |
| 41 | 1962 KL 8L second, planet association | EST-05…06 / CASE-16 |
| 42 | 1962 cyclic KL, 8L GK, legacy case | CASE-16 |
| 43 | Longevity: 6 numbered rules; KL 4th/9th, derived 8th, DK/AmK | LONG-01…06 |
| 44 | 1917 mother short-life birth chart source | CASE-17 |
| 45 | 1917 KL/dasha example | PER-01 / CASE-17 |
| 46 | 1950 mother long-life birth chart source | CASE-18 |
| 47 | 1950 KL and Vimshottari/Chara dasha | PER-02 / CASE-18 |
| 48 | 1944 father medium-life birth chart source | CASE-19 |
| 49 | 1944 KL/dasha example | CASE-19 |
| 50 | 1942 both parents long-life birth chart | CASE-20 |
| 51 | 1942 KL analysis, Vimshottari + Chara dasha example | CASE-20 |

## స్వతంత్ర QA

- 69 rule IDs unique; all 8 sections represented.
- Source references always include document title and PDF page.
- Main result shows only exactly matched rules; source audit retains the rest.
- Deprecated `D12-MOTHER-EVIDENCE` / `D12-FATHER-EVIDENCE` percentage pseudo-predictions removed.
- Existing v1.4 D1/D2/D4/D7/D9/D10 features unchanged in this patch.
- Archive ZIP integrity can be tested; Flutter compilation and on-device interaction require GitHub Actions/Android validation.
