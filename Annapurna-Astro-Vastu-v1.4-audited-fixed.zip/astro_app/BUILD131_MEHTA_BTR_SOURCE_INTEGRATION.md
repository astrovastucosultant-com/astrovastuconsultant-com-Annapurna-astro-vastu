# Build131 — SK Mehta source-rule checks connected to BTR candidates

Base: Build130 v1.4.130 source, no original Mehta source paragraphs changed.

## Implementation
- Past-event form loads BOTH original SK Mehta 206 and 85 rule catalogs and event-to-topic IDs for context. Shows an optional source-rule dropdown for each event, with direct link to complete original catalog entry.
- When a practitioner selects an R001–R085 rule AND the current app has a non-sensitive `book:<N>` evaluator with `autoEvaluated=true`, the candidate natal chart is inspected by the existing MehtaCombinationService. Show ✅ matched, ❌ not matched. No other conditions get fictitious automated status.
- ND rules and unsupported R rules stay MANUAL REVIEW and never affect rankings. No shortcut attempts to derive results from Telugu prose.
- For an explicitly selected, supported evaluated source rule, compare 75% dasha event match + 25% source chart structural check. This is an APP-DESIGNED rule match index, not the author’s BTR formula, not probability, not seconds-level validation. If no eligible rule selected, original 100% dasha match ranking is retained. Note that a source structural condition alone cannot prove an event occurred; the practitioner must select a relevant rule. Ineligible/sensitive rules are excluded from the ranking.
- Retains original date-only day spread, distinct-event validation, 30-second candidate refinement and ambiguity/range reporting. No independent KP cusp-second discriminator added.
- Per-event candidate report includes source condition status, original dasha comparison, blended index and link back to complete book rule. Saved event rows persist chosen rule IDs.
- Backwards-compatible: existing saved rows and clients with no selected source rule use previous behavior.

## Limitations
- 206 New Dimensions and 85 New Rules are browsable, NOT all 291 numerically evaluated; only preexisting source-specific evaluators get a green/red status. 46 macro/BCP/BPD guidance rules remain in their separate context layer.
- Full BTR to a guaranteed exact second, Varga/cusp sub-lord independent evidence, and 291/291 executable-rule coverage have NOT been implemented.
- Flutter/Dart SDK not present here: local Dart compilation and running APK not verified. Upload ZIP to GitHub by replacing root archive `Annapurna-Astro-Vastu-v1.4-audited-fixed.zip` (repository workflow extracts it) and verify Actions before using an APK.
