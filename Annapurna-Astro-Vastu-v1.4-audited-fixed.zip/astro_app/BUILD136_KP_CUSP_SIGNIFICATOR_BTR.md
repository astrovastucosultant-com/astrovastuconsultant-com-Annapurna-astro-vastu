# Build136 — KP Cusp / Significator → BTR integration

Version: `1.4.136+136` (source change; no compiled APK asserted).

## Scope

- Retains the original BNN/BCP, BPD Vaani/Nādi profiles, SK Mehta sources, dasha scoring and 1-second BTR candidate search. No additional KP/BPD score weighting was introduced.
- Stores the 12 **sidereal Placidus** house cusp longitudes from Swiss Ephemeris on `AstroChartResult.houseCuspLongitudes` (0-based array of houses 1–12). Handles the sweph's 13-item vs 12-item return array without fabricating cusps.
- Calculates a **separate Krishnamurti ayanamsa chart for KP**, independent of the natal ayanamsa selected for SK Mehta/other methods.
- Computes each cusp's Sign, Star, Sub and Sub-Sub Lord via the existing `KpService.forLongitude` implementation.
- For each of the nine planets: assigns actual Placidus occupied house from ordered cusps and exposes four distinct signification levels: (A) Star Lord occupied house, (B) planet occupied house, (C) Star Lord owned cuspal-sign houses, (D) planet owned cuspal-sign houses. Actual cusp-sign ownership is used instead of whole-sign houses.
- For each observed BTR event with an explicit KP mapping, shows **event KP primary cusp**, that cusp's Sub Lord's signified houses, matching and contrary event-house links, and indicative significator planet names. A mixed result is **qualified/context only**, never a proven YES/NO event promise.
- The integrated BTR report and copied report display the per-event KP findings in their own section. KP and BPD remain independent.
- Adds all 12 cusp stellar chains to the non-scoring fingerprint for locating nearby time-sensitive boundaries. This does **not** modify the candidate's ranking/evidenceShare.
- Invalid, missing or noncyclic cusps **do not** cause equal-house fallback or false rules: the finding stays unavailable.

## Source / limitations

- The user's *KP_Rule_Based_AstroSecrets_Part1.html* and *Astro_Secrets_KP_Part5_Rule_Based_Master.html* support `Cusp → Star → Sub → Signification → period confirmation`, occupational and ownership components, and the need to account for node representation and retrograde rules.
- Event ID → KP event/house mapping is an **app-specific crosswalk** between two separate traditions. A KP house combination is not relabeled as a Mehta source rule.
- Swiss Ephemeris Placidus KP uses `Hsys.P`, `swe_houses_ex`, and `SEFLG_SIDEREAL` with `SE_SIDM_KRISHNAMURTI`.
- Rahu/Ketu representative agents, conjunction/aspects, retrograde and ruling planets are **not** implemented as complete source-verified event-promise algorithms. Full KP event confirmation and professional accuracy testing remain pending.
- Historic event comparisons are interpretive astrology and do not empirically establish a birth second.

## Tests

- Added `test/kp_cusp_significator_service_test.dart`: 12 cusps, four levels, wrap/boundary house selection, unavailable invalid cusps, Mehta vs KP event-house separation, score independence.
- Flutter and Dart are not installed in the local execution environment. Tests need to run in the Android GitHub Actions build; ZIP and static checks alone are not compiler evidence.
