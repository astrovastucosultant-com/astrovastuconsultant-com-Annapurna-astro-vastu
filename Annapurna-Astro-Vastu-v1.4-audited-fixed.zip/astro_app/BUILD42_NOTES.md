# Build 42 — BSP Year-wise Source Engine

- Added `BspService` from the supplied 27-page **B S P** source only.
- Registered all 31 Appendix-1 year/planet/implementation entries (uploaded pp.23–24).
- Added BSP 37 Moon–Mars conjunction/opposition activation for 32nd/33rd years (uploaded pp.15–21).
- BSP years are shown in ascending order. Nth year uses the source example convention: `(N−1)th birthday → Nth birthday`.
- Year tap expands: source rule(s), natal planet house/sign, implementation house/sign, lordship themes, clear chart-specific result lines, and source audit.
- Appendix OR/optional conditions are displayed as candidates rather than silently collapsed.
- Year 35 Jupiter secondary notation is visibly unclear in the supplied scan, so only the verified natal-position part is auto-calculated; the unclear part is flagged instead of guessed.
- Version: `2.28.0+42`.
