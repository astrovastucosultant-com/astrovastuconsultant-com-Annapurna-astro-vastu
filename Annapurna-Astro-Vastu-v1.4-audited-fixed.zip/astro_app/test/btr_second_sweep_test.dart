import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/kp_service.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';
import 'package:astro_app/models/birth_data.dart';

void main() {
  final birth = BirthData(
    name: 'BTR fixture', localDateTime: DateTime(1986, 4, 3, 9, 15, 0),
    place: 'Guntur', latitude: 16.3, longitude: 80.44,
    timezoneOffsetHours: 5.5, ayanamsa: AyanamsaType.lahiri,
  );
  List<MehtaBtrEvent> events() => [
    MehtaBtrEvent(ruleId:'M01', occurredAt:DateTime(2009,6,3),
      reliability:'verified'),
    MehtaBtrEvent(ruleId:'M06', occurredAt:DateTime(2012,1,6),
      reliability:'verified'),
    MehtaBtrEvent(ruleId:'M11', occurredAt:DateTime(2016,7,8),
      reliability:'verified'),
  ];
  const fake = AstroChartResult(
    julianDay:2450000, ayanamsaDegrees:23,
    ascendantLongitude:12.1, engineVersion:'test',
    planets:[
      PlanetPosition(name:'Moon',shortName:'Mo',
        longitude:45,latitude:0,speed:13),
      PlanetPosition(name:'Jupiter',shortName:'Ju',
        longitude:10,latitude:0,speed:0.1),
    ],
  );

  test('full ±1 minute explores all 121 exact second timestamps', () async {
    final seen=<String>{};
    final report=await MehtaBtrService.search(
      natal:birth,events:events(),plusMinusMinutes:1,
      chartCalculator:(data) async {
        seen.add(data.localDateTime.toIso8601String());
        return fake;
      },
    );
    expect(report.testedTimes,121);
    expect(report.oneSecondSamples,121);
    expect(seen.length,121);
    expect(report.exhaustiveAcrossRequestedRange,isTrue);
    expect(report.distinguishable,isFalse);
    expect(report.discriminatingEvents,0);
    expect(report.secondWindows,isNotEmpty);
    expect(report.originalBirthTime,birth.originalBirthDateTime);
  });

  test('a user-selected fine-search center is respected', () async {
    final center=birth.originalBirthDateTime.add(const Duration(minutes:8));
    final report=await MehtaBtrService.search(
      natal:birth,events:events(),plusMinusMinutes:1,
      searchCenter:center,chartCalculator:(_) async => fake,
    );
    expect(report.testedTimes,121);
    expect(report.rangeStart,center.subtract(const Duration(minutes:1)));
    expect(report.rangeEnd,center.add(const Duration(minutes:1)));
    expect(report.originalBirthTime,birth.originalBirthDateTime);
  });

  test('KP asc and varga fingerprint identify a sign boundary', () {
    const before=AstroChartResult(
      julianDay:2450000,ayanamsaDegrees:23,ascendantLongitude:29.999,
      engineVersion:'test',planets:[]);
    const after=AstroChartResult(
      julianDay:2450000,ayanamsaDegrees:23,ascendantLongitude:30.001,
      engineVersion:'test',planets:[]);
    expect(KpService.forLongitude('Asc',29.999).signIndex,0);
    expect(KpService.forLongitude('Asc',30.001).signIndex,1);
    expect(KpService.forLongitude('Asc',30.001).subSubLord,isNotEmpty);
    expect(MehtaBtrService.timeSignature(before,events()),
      isNot(MehtaBtrService.timeSignature(after,events())));
  });

  test('multiple records from one underlying event do not meet gate', () {
    final sharedGroup = [
      MehtaBtrEvent(ruleId:'M01',occurredAt:DateTime(2008,1,1),
        correlationGroup:'SAME'),
      MehtaBtrEvent(ruleId:'M06',occurredAt:DateTime(2009,1,1),
        correlationGroup:'SAME'),
      MehtaBtrEvent(ruleId:'M11',occurredAt:DateTime(2010,1,1),
        correlationGroup:'SAME'),
    ];
    expect(MehtaBtrService.validateEvents(sharedGroup,
      birth.originalBirthDateTime),isNotNull);
    expect(MehtaBtrService.validateEvents(events(),
      birth.originalBirthDateTime),isNull);
    expect(MehtaBtrService.eventWeight(events().first),1.0);
  });
}
