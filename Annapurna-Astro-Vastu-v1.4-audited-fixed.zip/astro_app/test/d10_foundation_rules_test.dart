import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

PlanetPosition _p(String name, String shortName, double longitude) {
  return PlanetPosition(
    name: name,
    shortName: shortName,
    longitude: longitude,
    latitude: 0,
    speed: 1,
  );
}

AstroChartResult _chart() => AstroChartResult(
      julianDay: 0,
      ayanamsaDegrees: 0,
      ascendantLongitude: 15,
      engineVersion: 'test',
      planets: [
        _p('Sun', 'Su', 125),
        _p('Moon', 'Mo', 42),
        _p('Mars', 'Ma', 95),
        _p('Mercury', 'Me', 62),
        _p('Jupiter', 'Ju', 245),
        _p('Venus', 'Ve', 32),
        _p('Saturn', 'Sa', 275),
        _p('Rahu', 'Ra', 305),
        _p('Ketu', 'Ke', 125),
      ],
    );

void main() {
  test('D10 foundation result layer is present', () {
    final rules = VargaRuleService.allFor(
      chart: _chart(),
      factor: 10,
      birthDateTime: DateTime(1984, 12, 15, 10, 30),
    );
    final ids = rules.map((x) => x.ruleId).toSet();
    expect(ids, containsAll(<String>{
      'D10-BASE-01',
      'D10-BASE-02',
      'D10-BASE-03',
      'D10-BASE-04',
      'D10-BASE-05',
      'D10-BASE-06',
    }));
  });
}
