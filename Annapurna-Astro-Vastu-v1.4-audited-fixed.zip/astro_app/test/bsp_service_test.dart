import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bsp_service.dart';

PlanetPosition _p(String name, String shortName, double longitude) => PlanetPosition(
      name: name,
      shortName: shortName,
      longitude: longitude,
      latitude: 0,
      speed: 1,
    );

AstroChartResult _chart({double moon = 35, double mars = 35}) => AstroChartResult(
      julianDay: 0,
      ayanamsaDegrees: 0,
      ascendantLongitude: 5, // Aries
      engineVersion: 'test',
      planets: [
        _p('Sun', 'Su', 125),
        _p('Moon', 'Mo', moon),
        _p('Mars', 'Ma', mars),
        _p('Mercury', 'Me', 65),
        _p('Jupiter', 'Ju', 245),
        _p('Venus', 'Ve', 35),
        _p('Saturn', 'Sa', 305),
        _p('Rahu', 'Ra', 185),
        _p('Ketu', 'Ke', 5),
      ],
    );

void main() {
  test('BSP appendix registry contains 31 source entries', () {
    expect(BspService.rules.length, 31);
    expect(BspService.sourceYearOrder.first, 10);
    expect(BspService.sourceYearOrder.last, 69);
  });

  test('10th year runs from ninth to tenth birth anniversary', () {
    final r = BspService.evaluateYear(
      chart: _chart(),
      birthDateTime: DateTime(1948, 2, 9, 12, 30),
      year: 10,
    );
    expect(r.start, DateTime(1957, 2, 9, 12, 30));
    expect(r.end, DateTime(1958, 2, 9, 12, 30));
    expect(r.activations.single.rule.id, 'BSP23-Y10');
  });

  test('BSP 37 activates for Moon-Mars conjunction in 32/33 years', () {
    final r = BspService.evaluateYear(
      chart: _chart(moon: 35, mars: 35),
      birthDateTime: DateTime(2000, 1, 1),
      year: 32,
    );
    expect(r.bsp37, isNotNull);
    expect(r.bsp37!.matched, isTrue);
    expect(r.bsp37!.relation, 'Conjunction');
  });

  test('BSP 37 does not fire without conjunction/opposition', () {
    final r = BspService.evaluateYear(
      chart: _chart(moon: 35, mars: 95),
      birthDateTime: DateTime(2000, 1, 1),
      year: 33,
    );
    expect(r.bsp37, isNotNull);
    expect(r.bsp37!.matched, isFalse);
  });
}
