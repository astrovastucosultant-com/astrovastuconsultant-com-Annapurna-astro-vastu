import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d2_dhana_asthi_registry.dart';
import 'package:astro_app/astrology/d2_wealth_evaluation_service.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

void main() {
  AstroChartResult sampleChart({bool withMoon = true}) {
    const data = <String, double>{
      'Sun': 1, 'Moon': 7, 'Mars': 45, 'Mercury': 75,
      'Jupiter': 105, 'Venus': 135, 'Saturn': 165,
      'Rahu': 195, 'Ketu': 15,
    };
    return AstroChartResult(
      julianDay: 2460950.5,
      ayanamsaDegrees: 24.0,
      ascendantLongitude: 2.0, // Aries rising
      engineVersion: 'synthetic-test',
      planets: data.entries
          .where((x) => withMoon || x.key != 'Moon')
          .map((x) => PlanetPosition(
                name: x.key,
                shortName: x.key.substring(0, 2),
                longitude: x.value,
                latitude: 0.0,
                speed: 1.0,
              ))
          .toList(),
    );
  }

  test('all 58 original D2 rules remain in the registry exactly once', () {
    final ids = D2DhanaAsthiRegistry.rules.map((x) => x.id).toList();
    expect(ids.length, 58);
    expect(ids.toSet().length, 58);
    expect(D2WealthEvaluationService.pendingReason.length, 11);
    expect(ids.toSet().containsAll(D2WealthEvaluationService.pendingReason.keys), isTrue);
  });

  test('Indu Lagna uses both ninth-house lords and inclusive count', () {
    // Lagna Aries and Moon Aries: ninth is Sagittarius, ruled by Jupiter.
    // Jupiter Kala 10 + Jupiter Kala 10 = 20; remainder 8; Aries+7=Scorpio.
    expect(D2WealthEvaluationService.induLagnaSign(sampleChart()), 7);
  });

  test('source checks do not duplicate the same rule or produce phantom IDs', () {
    final chart = sampleChart();
    final hits = D2WealthEvaluationService.evaluate(chart);
    final sourceIds = D2DhanaAsthiRegistry.rules.map((x) => x.id).toSet();
    expect(hits.map((x) => x.ruleId).toSet().length, hits.length);
    expect(sourceIds.containsAll(hits.map((x) => x.ruleId)), isTrue);
    expect(hits.every((x) => x.percent >= 1 && x.percent <= 100), isTrue);
    expect(hits.any((x) => x.ruleId == 'D2-IN-011'), isTrue);
    expect(hits.any((x) => D2WealthEvaluationService.pendingReason.containsKey(x.ruleId)), isFalse);
  });

  test('missing Moon does not create a fictional Indu Lagna match', () {
    expect(D2WealthEvaluationService.evaluate(sampleChart(withMoon: false)), isEmpty);
  });

  test('every D2 rule remains available in source audit or matched results', () {
    final list = VargaRuleService.allFor(chart: sampleChart(), factor: 2);
    for (final source in D2DhanaAsthiRegistry.rules) {
      expect(list.where((x) => x.ruleId == source.id).length, 1);
    }
  });
}
