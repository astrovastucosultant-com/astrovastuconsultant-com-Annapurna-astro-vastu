import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/utils/chart_rotation.dart';

void main() {
  test('all four quarter turns are bijections on the twelve chart cells', () {
    final positions = <(int, int)>[
      for (var r = 0; r < 4; r++)
        for (var c = 0; c < 4; c++)
          if (r == 0 || r == 3 || c == 0 || c == 3) (r,c),
    ];
    expect(positions.length, 12);
    for (var k = 0; k < 4; k++) {
      final rotated = positions.map((p) => ChartRotation.cell(p.$1, p.$2, k)).toSet();
      expect(rotated.length, 12);
      expect(rotated, containsAll(positions));
    }
  });
  test('clockwise rotation, reset and full rotation preserve position', () {
    expect(ChartRotation.cell(0, 0, 1), (0, 3));
    expect(ChartRotation.cell(0, 0, 2), (3, 3));
    expect(ChartRotation.cell(0, 0, 4), (0, 0));
    expect(ChartRotation.cell(0, 0, 0), (0, 0));
  });
}
