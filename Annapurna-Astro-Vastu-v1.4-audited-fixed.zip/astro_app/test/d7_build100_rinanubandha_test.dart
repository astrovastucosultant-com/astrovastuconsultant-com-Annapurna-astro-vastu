import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

void main() {
  test('Rinanubandha uses chart evidence but does not assert unverified yoga', () {
    final positions = <String, double>{
      'Sun': 12.0, 'Moon': 48.0, 'Mars': 98.0,
      'Mercury': 111.0, 'Jupiter': 170.0, 'Venus': 199.0,
      'Saturn': 245.0, 'Rahu': 289.0, 'Ketu': 109.0,
    };
    final chart = AstroChartResult(
      julianDay: 2451545.0,
      ayanamsaDegrees: 23.8,
      ascendantLongitude: 15.0,
      planets: positions.entries.map((e) => PlanetPosition(
        name: e.key, shortName: e.key.substring(0, 2),
        longitude: e.value, latitude: 0.0, speed: 1.0,
      )).toList(),
      engineVersion: 'test',
    );
    final records = VargaRuleService.allFor(chart: chart, factor: 7)
        .where((r) => r.ruleId.startsWith('D7-RUNA-')).toList();
    expect(records.map((r) => r.ruleId).toSet(),
        {'D7-RUNA-001', 'D7-RUNA-002', 'D7-RUNA-003', 'D7-RUNA-004', 'D7-RUNA-005'});
    expect(records.where((r) => ['D7-RUNA-001', 'D7-RUNA-002'].contains(r.ruleId))
        .every((r) => !r.applicable && !r.autoEvaluated), isTrue);
    expect(records.first.inspection, contains('D7 2H'));
    expect(records.firstWhere((r) => r.ruleId == 'D7-RUNA-002')
        .inspection, contains('D12 4H'));
    expect(records.every((r) => r.remedy.contains('నిర్దిష్ట పరిహారం')), isTrue);
  });
}
