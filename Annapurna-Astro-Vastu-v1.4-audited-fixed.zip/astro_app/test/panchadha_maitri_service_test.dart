import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/panchadha_maitri_service.dart';

void main() {
  const signs = <String, int>{
    'Moon': 0, // Aries
    'Mars': 5, // Virgo
    'Jupiter': 6, // Libra
    'Saturn': 6, // Libra
    'Sun': 8, // Sagittarius
    'Mercury': 8, // Sagittarius
    'Venus': 9, // Capricorn
  };

  test('user example: Sun sees Mars as Adhimitra', () {
    final r = PanchadhaMaitriService.pairFromSigns(signs, 'Sun', 'Mars');
    expect(r.naturalRelation, 'Friend');
    expect(r.temporaryRelation, 'Friend');
    expect(r.finalRelation, PanchadhaRelation.adhimitra);
  });

  test('directional asymmetry: Mercury sees Moon Adhishatru, Moon sees Mercury Sama', () {
    final a = PanchadhaMaitriService.pairFromSigns(signs, 'Mercury', 'Moon');
    final b = PanchadhaMaitriService.pairFromSigns(signs, 'Moon', 'Mercury');
    expect(a.finalRelation, PanchadhaRelation.adhishatru);
    expect(b.finalRelation, PanchadhaRelation.sama);
  });

  test('user example: Venus and Saturn are mutual Adhimitra', () {
    expect(
      PanchadhaMaitriService.pairFromSigns(signs, 'Venus', 'Saturn').finalRelation,
      PanchadhaRelation.adhimitra,
    );
    expect(
      PanchadhaMaitriService.pairFromSigns(signs, 'Saturn', 'Venus').finalRelation,
      PanchadhaRelation.adhimitra,
    );
  });

  test('strength table matches approved values', () {
    expect(PanchadhaMaitriService.strengthValues[PanchadhaRelation.adhimitra], 22.5);
    expect(PanchadhaMaitriService.strengthValues[PanchadhaRelation.mitra], 15.0);
    expect(PanchadhaMaitriService.strengthValues[PanchadhaRelation.sama], 7.5);
    expect(PanchadhaMaitriService.strengthValues[PanchadhaRelation.shatru], 3.75);
    expect(PanchadhaMaitriService.strengthValues[PanchadhaRelation.adhishatru], 1.875);
  });
}
