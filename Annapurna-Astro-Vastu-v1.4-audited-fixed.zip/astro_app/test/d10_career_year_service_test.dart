import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_career_service.dart';
import 'package:astro_app/astrology/d10_career_year_service.dart';

D10CareerWindow window(String key, DateTime start, DateTime end) => D10CareerWindow(
  eventKey: key,
  title: key,
  start: start,
  end: end,
  mahadasha: 'Venus',
  antardasha: 'Sun',
  score: 10,
  tone: key == 'job_loss' ? D10CareerTone.caution : D10CareerTone.favorable,
  reason: 'test source window',
  ruleIds: const ['TEST'],
);

void main() {
  test('A January 1 exclusive end does not spill into next year', () {
    final rise = window('rise', DateTime(2026, 6, 1), DateTime(2027, 1, 1));
    final result = D10CareerYearService.yearsFor([rise], D10YearCategory.rise);
    expect(result.keys, [2026]);
  });

  test('Rise and job-loss use independent source event classifications', () {
    final rise = window('promotion', DateTime(2027, 2, 1), DateTime(2027, 8, 1));
    final loss = window('job_loss', DateTime(2027, 9, 1), DateTime(2028, 3, 1));
    expect(D10CareerYearService.yearsFor([rise, loss], D10YearCategory.rise).keys, [2027]);
    expect(D10CareerYearService.yearsFor([rise, loss], D10YearCategory.fall).keys, [2027, 2028]);
    expect(D10CareerYearService.yearsFor([rise, loss], D10YearCategory.middle), isEmpty);
  });

  test('Only a calculated change or transfer is shown under middle', () {
    final transfer = window('transfer', DateTime(2028, 4, 1), DateTime(2028, 6, 1));
    final retirement = window('retirement', DateTime(2028, 6, 1), DateTime(2029, 1, 1));
    final result = D10CareerYearService.yearsFor([transfer, retirement], D10YearCategory.middle);
    expect(result.keys, [2028]);
    expect(result[2028]?.single.eventKey, 'transfer');
  });

  test('No guessed middle years when no source windows are present', () {
    expect(D10CareerYearService.yearsFor([], D10YearCategory.middle), isEmpty);
  });
}
