import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

void main() {
  test('D7 extended topics are present and have source/evidence', () {
    final pos = <String, double>{
      'Sun': 12.0, 'Moon': 48.0, 'Mars': 98.0,
      'Mercury': 111.0, 'Jupiter': 170.0, 'Venus': 199.0,
      'Saturn': 245.0, 'Rahu': 289.0, 'Ketu': 109.0,
    };
    final chart = AstroChartResult(
      julianDay: 2451545.0, ayanamsaDegrees: 23.8,
      ascendantLongitude: 15.0,
      planets: pos.entries.map((e) => PlanetPosition(name: e.key,
        shortName: e.key.substring(0, 2), longitude: e.value,
        latitude: 0.0, speed: 1.0)).toList(),
      engineVersion: 'test',
    );
    final all = VargaRuleService.allFor(chart: chart, factor: 7);
    for (final prefix in ['D7-RUNA-', 'D7-KAKA-', 'D7-ADOPT-',
      'D7-TWINS-', 'D7-LUX-', 'D7-FORM-']) {
      final group = all.where((r) => r.ruleId.startsWith(prefix));
      expect(group, isNotEmpty, reason: prefix);
      expect(group.every((r) => r.source.isNotEmpty &&
        r.inspection.isNotEmpty && r.rule.isNotEmpty), isTrue);
    }
    final kaka = all.firstWhere((r) => r.ruleId == 'D7-KAKA-001');
    expect(kaka.applicable, isFalse);
    expect(kaka.autoEvaluated, isFalse);
    expect(all.where((r) => r.ruleId.startsWith('D7-ADOPT-') && r.applicable)
      .every((r) => r.autoEvaluated), isTrue);
  });
}
