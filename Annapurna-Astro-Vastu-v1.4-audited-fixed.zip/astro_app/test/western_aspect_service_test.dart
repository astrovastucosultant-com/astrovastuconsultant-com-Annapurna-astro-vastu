import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/western_aspect_service.dart';

PlanetPosition planet(String name, double longitude) => PlanetPosition(
  name: name, shortName: name.substring(0, 2), longitude: longitude,
  latitude: 0, speed: 0,
);

void main() {
  test('all five principal Western aspects calculate from exact angles', () {
    for (final d in WesternAspectService.definitions.take(5)) {
      final hits = WesternAspectService.calculate([
        planet('Sun', 0), planet('Moon', d.exactAngle),
      ]);
      expect(hits.length, 1, reason: d.name);
      expect(hits.single.aspect.id, d.id);
      expect(hits.single.deviation, closeTo(0, 1e-9));
    }
  });
  test('shortest angular separation works around zodiac crossing', () {
    expect(WesternAspectService.separation(359, 1), 2);
    expect(WesternAspectService.separation(10, 190), 180);
  });
  test('aspect separations are invariant under a common ayanamsa shift', () {
    final normal = WesternAspectService.separation(45.3, 134.9);
    final shifted = WesternAspectService.separation(45.3 - 24, 134.9 - 24);
    expect(shifted, closeTo(normal, 1e-9));
  });
  test('minor aspects and nodes disabled until explicitly enabled', () {
    final pair = [planet('Sun', 0), planet('Moon', 150)];
    expect(WesternAspectService.calculate(pair), isEmpty);
    expect(WesternAspectService.calculate(pair, includeMinor: true).single.aspect.id, 'QUIN');
    expect(WesternAspectService.calculate([planet('Sun', 0), planet('Rahu', 90)]), isEmpty);
    expect(WesternAspectService.calculate([planet('Sun', 0), planet('Rahu', 90)],includeNodes:true).length, 1);
  });
  test('each pair is counted at most once even when wide orbs overlap', () {
    final hits = WesternAspectService.calculate([
      planet('Sun', 0), planet('Moon', 75),
    ], orbMultiplier: 4);
    expect(hits.length, 1);
  });
}
