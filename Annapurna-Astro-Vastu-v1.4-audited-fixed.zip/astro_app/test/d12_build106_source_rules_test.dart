import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d12_source_rule_service.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

void main() {
  final planets = <PlanetPosition>[
    const PlanetPosition(name:'Sun',shortName:'Su',longitude:25,latitude:0,speed:1),
    const PlanetPosition(name:'Moon',shortName:'Mo',longitude:35,latitude:0,speed:13),
    const PlanetPosition(name:'Mars',shortName:'Ma',longitude:65,latitude:0,speed:0.5),
    const PlanetPosition(name:'Mercury',shortName:'Me',longitude:95,latitude:0,speed:1),
    const PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:125,latitude:0,speed:0.1),
    const PlanetPosition(name:'Venus',shortName:'Ve',longitude:155,latitude:0,speed:1),
    const PlanetPosition(name:'Saturn',shortName:'Sa',longitude:185,latitude:0,speed:0.05),
    const PlanetPosition(name:'Rahu',shortName:'Ra',longitude:215,latitude:0,speed:-0.05),
    const PlanetPosition(name:'Ketu',shortName:'Ke',longitude:35,latitude:0,speed:-0.05),
  ];
  final chart = AstroChartResult(julianDay:2451545.0,
      ayanamsaDegrees:23.0, ascendantLongitude:10.0,
      planets:planets,engineVersion:'test');

  test('Source chapter registry: 69 distinct rules/cases and seven domains', () {
    final result=D12SourceRuleService.evaluate(chart,VargaService.calculate(chart,12));
    expect(result.length,69);
    expect(result.map((r)=>r.id).toSet().length,69);
    for(final prefix in <String>['D12-ANC-','D12-CHILD-','D12-REL-',
       'D12-CARE-','D12-EST-','D12-LONG-','D12-PER-','D12-CASE-']) {
      expect(result.any((r)=>r.id.startsWith(prefix)),true);
    }
    for(final item in result){
      expect(item.source.contains('D12.pdf'),true);
      expect(item.source.contains('PDF page'),true);
      expect(item.condition.trim().isNotEmpty,true);
      expect(item.sourceResult.trim().isNotEmpty,true);
    }
  });

  test('No fake 33 / 67 evidence card; KL and case studies audit only', () {
    final result=VargaRuleService.allFor(chart:chart,factor:12);
    expect(result.where((r)=>r.ruleId.startsWith('D12-')).length,69);
    expect(result.where((r)=>r.ruleId=='D12-MOTHER-EVIDENCE'),isEmpty);
    expect(result.where((r)=>r.ruleId=='D12-FATHER-EVIDENCE'),isEmpty);
    expect(result.where((r)=>r.ruleId.startsWith('D12-CASE-') && r.applicable),isEmpty);
    expect(result.where((r)=>r.ruleId.startsWith('D12-LONG-') && r.applicable),isEmpty);
    expect(result.every((r)=>!r.applicable || r.autoEvaluated),true);
  });

  test('Remedies without exact PDF match are not fabricated', () {
    final result=VargaRuleService.allFor(chart:chart,factor:12);
    expect(result.every((r)=>r.remedy.contains('D12.pdf')),true);
  });
}
