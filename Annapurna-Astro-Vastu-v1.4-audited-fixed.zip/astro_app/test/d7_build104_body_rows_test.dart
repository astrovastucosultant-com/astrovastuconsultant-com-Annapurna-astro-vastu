import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

void main() {
  test('D7 body table uses exact D1 ascendant sign and amsha index', () {
    final pos = <String, double>{
      'Sun': 12, 'Moon': 48, 'Mars': 98, 'Mercury': 111,
      'Jupiter': 170, 'Venus': 199, 'Saturn': 245,
      'Rahu': 289, 'Ketu': 109,
    };
    for (var sign = 0; sign < 6; sign++) {
      for (var part = 1; part <= 7; part++) {
        final asc = sign * 30.0 + (part - 0.5) * 30 / 7;
        final chart = AstroChartResult(
          julianDay: 2451545, ayanamsaDegrees: 23.8,
          ascendantLongitude: asc,
          planets: pos.entries.map((e) => PlanetPosition(
            name: e.key, shortName: e.key.substring(0, 2),
            longitude: e.value, latitude: 0, speed: 1,
          )).toList(), engineVersion: 'test',
        );
        final rules = VargaRuleService.allFor(chart: chart, factor: 7);
        final id = 'D7-FORM-${(sign + 1).toString().padLeft(2, '0')}-${part.toString().padLeft(2, '0')}';
        final hits = rules.where((r) => r.ruleId == id).toList();
        expect(hits.length, 1, reason: id);
        expect(hits.single.applicable, isTrue, reason: id);
        expect(hits.single.autoEvaluated, isTrue, reason: id);
        expect(hits.single.source, contains('Saptamsha_Santana_Niyamalu.pdf'));
        expect(hits.single.inspection, contains('D7 amsha=$part'));
      }
    }
  });
}
