import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_chara_dasha_service.dart';
import 'package:astro_app/astrology/jaimini_service.dart';

PlanetPosition _p(String name, String shortName, double longitude) => PlanetPosition(
      name: name,
      shortName: shortName,
      longitude: longitude,
      latitude: 0,
      speed: 1,
    );

AstroChartResult _chart({double mars = 275, double saturn = 305}) => AstroChartResult(
      julianDay: 0,
      ayanamsaDegrees: 0,
      ascendantLongitude: 5, // Aries
      engineVersion: 'test',
      planets: [
        _p('Sun', 'Su', 125),
        _p('Moon', 'Mo', 95),
        _p('Mars', 'Ma', mars),
        _p('Mercury', 'Me', 65),
        _p('Jupiter', 'Ju', 245),
        _p('Venus', 'Ve', 35),
        _p('Saturn', 'Sa', saturn),
        _p('Rahu', 'Ra', 185),
        _p('Ketu', 'Ke', 5),
      ],
    );

void main() {
  test('Method A Aries with Mars exalted in Capricorn gives 10-year Aries MD', () {
    final result = JaiminiCharaDashaService.calculate(
      chart: _chart(mars: 275), // Capricorn, Mars exalted
      birthDateTime: DateTime(2000, 1, 1),
      config: const JaiminiCharaConfig(method: JaiminiCharaMethod.methodA),
    );
    final first = result.mahadashas.first;
    expect(first.signIndex, 0);
    expect(first.selectedLord, 'Mars');
    expect(first.years, 10); // 9 sign-steps + 1 exaltation
    expect(first.antardashas.length, 12);
    expect(first.antardashas.first.signIndex, 0);
  });

  test('Own-sign duration uses configurable 12-year default', () {
    final result = JaiminiCharaDashaService.calculate(
      chart: _chart(mars: 5), // Mars in Aries
      birthDateTime: DateTime(2000, 1, 1),
      config: const JaiminiCharaConfig(method: JaiminiCharaMethod.methodA),
    );
    expect(result.mahadashas.first.years, 12);
  });

  test('Event score has fixed 100-point component maximum', () {
    final chart = _chart();
    final jai = JaiminiService.calculate(chart);
    final dasha = JaiminiCharaDashaService.calculate(
      chart: chart,
      birthDateTime: DateTime(2000, 1, 1),
    );
    final score = JaiminiCharaDashaService.scoreEvent(
      eventKey: 'marriage',
      at: DateTime(2001, 1, 1),
      chart: chart,
      jaimini: jai,
      dasha: dasha,
    );
    expect(score.components.fold<int>(0, (s, c) => s + c.maxScore), 100);
    expect(score.score, inInclusiveRange(0, 100));
  });
}
