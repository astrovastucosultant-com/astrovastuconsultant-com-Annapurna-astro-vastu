import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/btr_macro_context_service.dart';

void main() {
  const chart = AstroChartResult(
    julianDay: 2450000, ayanamsaDegrees: 23.4,
    ascendantLongitude: 23.0, engineVersion: 'test',
    planets: [PlanetPosition(name: 'Jupiter', shortName: 'Ju',
      longitude: 15, latitude: 0, speed: 0.1)],
  );
  final birth = DateTime(2000, 6, 15, 10, 23, 10);

  test('Jupiter macro and minor progress independently at 12 and 26', () {
    final a = BtrMacroContextService.compute(
      natalChart: chart, birthDate: birth, eventDate: DateTime(2012, 6, 15));
    expect(a.completedAge, 12);
    expect(a.jupiterMajorSignIndex, 1); // Taurus
    expect(a.jupiterMinorSignIndex, 0); // Aries, 12-year annual cycle
    expect(a.bcpHouse, 1);
    final b = BtrMacroContextService.compute(
      natalChart: chart, birthDate: birth, eventDate: DateTime(2026, 6, 15));
    expect(b.completedAge, 26);
    expect(b.jupiterMajorSignIndex, 2); // Gemini
    expect(b.jupiterMinorSignIndex, 2); // Gemini
    expect(b.bcpHouse, 3);
  });

  test('birthday boundary matters, not event clock time', () {
    final before = BtrMacroContextService.compute(
      natalChart: chart, birthDate: birth, eventDate: DateTime(2012, 6, 14, 23));
    final on = BtrMacroContextService.compute(
      natalChart: chart, birthDate: birth, eventDate: DateTime(2012, 6, 15, 0));
    expect(before.completedAge, 11);
    expect(on.completedAge, 12);
    expect(before.jupiterMajorSignIndex, 0);
    expect(on.jupiterMajorSignIndex, 1);
  });

  test('event earlier than birth does not become a valid progression', () {
    expect(() => BtrMacroContextService.compute(
      natalChart: chart, birthDate: birth, eventDate: DateTime(1999, 6, 15)),
      throwsArgumentError);
  });
}
