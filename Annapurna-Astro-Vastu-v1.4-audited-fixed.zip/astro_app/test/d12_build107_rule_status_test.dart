import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d12_source_rule_service.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

void main() {
  const chart = AstroChartResult(
    julianDay: 2451545, ayanamsaDegrees: 23,
    ascendantLongitude: 10, engineVersion: 'test',
    planets: <PlanetPosition>[
      PlanetPosition(name:'Sun',shortName:'Su',longitude:25,latitude:0,speed:1),
      PlanetPosition(name:'Moon',shortName:'Mo',longitude:35,latitude:0,speed:13),
      PlanetPosition(name:'Mars',shortName:'Ma',longitude:65,latitude:0,speed:0.5),
      PlanetPosition(name:'Mercury',shortName:'Me',longitude:95,latitude:0,speed:1),
      PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:125,latitude:0,speed:0.1),
      PlanetPosition(name:'Venus',shortName:'Ve',longitude:155,latitude:0,speed:1),
      PlanetPosition(name:'Saturn',shortName:'Sa',longitude:185,latitude:0,speed:0.05),
      PlanetPosition(name:'Rahu',shortName:'Ra',longitude:215,latitude:0,speed:-0.05),
      PlanetPosition(name:'Ketu',shortName:'Ke',longitude:35,latitude:0,speed:-0.05),
    ],
  );

  test('69 D12 entries retained with source, and 20 cases stay source-only', () {
    final catalog = D12SourceRuleService.evaluate(chart, VargaService.calculate(chart,12));
    expect(catalog.length,69);
    expect(catalog.map((e)=>e.id).toSet().length,69);
    final cases = catalog.where((e)=>e.id.startsWith('D12-CASE-')).toList();
    expect(cases.length,20);
    expect(cases.every((e)=>e.matched==null),isTrue);
  });

  test('Incomplete historical combinations do not fire as universal rules', () {
    final catalog = D12SourceRuleService.evaluate(chart,VargaService.calculate(chart,12));
    const check = <String>{
      'D12-CHILD-06','D12-CHILD-07','D12-REL-07','D12-REL-08',
      'D12-REL-09','D12-CARE-07','D12-EST-05','D12-EST-06',
    };
    for (final item in catalog.where((e)=>check.contains(e.id))) {
      expect(item.matched,isNull, reason:'${item.id} is not a complete universal source rule');
    }
    expect(catalog.where((e)=>check.contains(e.id)).length,check.length);
  });

  test('Adverse matched D12 rule is caution, with actual inspection', () {
    final matches = VargaRuleService.allFor(chart:chart,factor:12)
        .where((e)=>e.applicable).toList();
    for (final item in matches) {
      expect(item.autoEvaluated,isTrue);
      expect(item.result.contains('జాతకంలో సరిపోలిన D12 ఆధారం:'),isTrue);
      if (item.ruleId.startsWith('D12-CHILD-') ||
          item.ruleId == 'D12-REL-03' || item.ruleId == 'D12-REL-04' ||
          item.ruleId.startsWith('D12-CARE-') || item.ruleId=='D12-EST-07') {
        expect(item.tone,VargaRuleTone.caution);
      }
    }
  });

  test('Every D12 item has a provenance and safe remedy placeholder', () {
    final all = VargaRuleService.allFor(chart:chart,factor:12);
    expect(all.length,69);
    expect(all.every((e)=>e.source.contains('D12.pdf • PDF page')),isTrue);
    expect(all.every((e)=>e.remedy.contains('D12.pdf')),isTrue);
    expect(all.where((e)=>e.ruleId.startsWith('D12-CASE-')&&e.applicable),isEmpty);
    expect(all.where((e)=>e.ruleId.startsWith('D12-LONG-')&&e.applicable),isEmpty);
  });
}
