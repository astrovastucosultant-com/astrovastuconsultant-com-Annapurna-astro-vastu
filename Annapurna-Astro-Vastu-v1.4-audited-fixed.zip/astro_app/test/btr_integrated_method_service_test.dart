import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/btr_integrated_method_service.dart';
import 'package:astro_app/astrology/btr_macro_context_service.dart';
import 'package:astro_app/astrology/bpd_pada_dasa_service.dart';
import 'package:astro_app/astrology/btr_mehta_rule_bridge.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';

void main() {
  const macro = BtrMacroContext(
    completedAge: 26, jupiterNatalSignIndex: 0,
    natalAscSignIndex: 0, jupiterMajorSignIndex: 2,
    jupiterMinorSignIndex: 2, bcpHouse: 3);

  test('BNN and BCP distinguish contextual links from source matches', () {
    final bnn = BtrIntegratedMethodService.bnn(macro, [3, 7]);
    expect(bnn.status, BtrAuditStatus.contextAligned);
    expect(bnn.isSourceRuleMatched, isFalse);
    expect(BtrIntegratedMethodService.bcp(macro,[3]).status,
        BtrAuditStatus.contextAligned);
    expect(BtrIntegratedMethodService.bcp(macro,[7]).status,
        BtrAuditStatus.contextNotAligned);
    expect(BtrIntegratedMethodService.bnn(null,[3]).status,
        BtrAuditStatus.needsVerification);
  });

  test('BPD compares only event-linked padas, never counts general dictums', () {
    const ctx = BpdEventContext(
      profile: BpdProfile.vaaniSeven,
      natalAscSignIndex: 0, elapsedYears: 21,
      arudhaSigns: {7: 6},
      progressions: [BpdPlanetStep(planet: 'Venus', natalSign: 1,
          progressedSign: 6, cycle: 1, signPosition: 4, totalYears: 27)],
      observations: [], notes: []);
    final match = BtrIntegratedMethodService.bpd(ctx,[7]);
    expect(match.status, BtrAuditStatus.contextAligned);
    expect(match.isSourceRuleMatched, isFalse);
    final unmatched = BtrIntegratedMethodService.bpd(ctx,[5]);
    expect(unmatched.status, BtrAuditStatus.needsVerification);
    expect(BtrIntegratedMethodService.bpd(null,[7]).status,
        BtrAuditStatus.needsVerification);
  });

  test('SK Mehta negative is about selected rule, KP needs actual cusp test', () {
    MehtaBtrEventEvidence row(BtrMehtaSourceCheck check) => MehtaBtrEventEvidence(
      event: MehtaBtrEvent(ruleId: 'M01',occurredAt: DateTime(2012,1,1)),
      ruleName: 'Marriage', vimshottariShare: 0.5, tribhagiShare: 0.3,
      combinedShare: 0.4, minimumShare: 0.3, maximumShare: 0.5,
      sampledInstants: 3, vimshottariLords: 'Venus',
      tribhagiLords: 'Venus', expectedAsc: ['Venus'], expectedMoonAsc: [],
      sourceCheck: check, rankingShare: 0.4);
    final accepted = BtrIntegratedMethodService.mehta(row(
        const BtrMehtaSourceCheck(ruleId:'R001',evaluated:true,
            matched:true,explanation:'test')));
    expect(accepted.status,BtrAuditStatus.sourceRuleMatched);
    expect(accepted.isSourceRuleMatched,isTrue);
    final rejected = BtrIntegratedMethodService.mehta(row(
        const BtrMehtaSourceCheck(ruleId:'R001',evaluated:true,
            matched:false,explanation:'test')));
    expect(rejected.status,BtrAuditStatus.sourceRuleNotMet);
    expect(BtrIntegratedMethodService.mehta(row(
        const BtrMehtaSourceCheck(ruleId:'ND-001',evaluated:false,
            matched:false,explanation:'manual'))).status,
        BtrAuditStatus.needsVerification);
    expect(BtrIntegratedMethodService.kp('KP:0/1/Sun/Moon/Mars').status,
        BtrAuditStatus.needsVerification);
  });
}
