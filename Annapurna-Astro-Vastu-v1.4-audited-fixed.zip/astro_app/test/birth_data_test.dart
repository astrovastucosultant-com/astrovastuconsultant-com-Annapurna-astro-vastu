import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/models/birth_data.dart';

void main() {
  test('India local time converts to UTC correctly', () {
    final data = BirthData(
      name: 'Test',
      localDateTime: DateTime(2026, 9, 30, 15, 45, 30),
      place: 'Guntur',
      latitude: 16.3067,
      longitude: 80.4365,
      timezoneOffsetHours: 5.5,
      ayanamsa: AyanamsaType.lahiri,
    );

    expect(data.utcDateTime, DateTime.utc(2026, 9, 30, 10, 15, 30));
  });
}
