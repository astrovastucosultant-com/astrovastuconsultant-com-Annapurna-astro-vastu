import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/models/birth_data.dart';

void main() {
  test('India local time converts to UTC correctly', () {
    final data = BirthData(
      name: 'Test',
      localDateTime: DateTime(2026, 9, 30, 15, 45, 30),
      place: 'Guntur',
      latitude: 16.3067,
      longitude: 80.4365,
      timezoneOffsetHours: 5.5,
      ayanamsa: AyanamsaType.lahiri,
    );

    expect(data.utcDateTime, DateTime.utc(2026, 9, 30, 10, 15, 30));
  });

  test('rectified birth time preserves original time through JSON', () {
    final original = DateTime(1981, 12, 15, 15, 50, 0);
    final rectified = DateTime(1981, 12, 15, 15, 52, 30);
    final data = BirthData(
      name: 'Mallikarjuna',
      localDateTime: rectified,
      originalLocalDateTime: original,
      place: 'Guntur',
      latitude: 16.593221,
      longitude: 79.736383,
      timezoneOffsetHours: 5.5,
      ayanamsa: AyanamsaType.lahiri,
    );

    final restored = BirthData.fromJson(data.toJson());
    expect(restored.localDateTime, rectified);
    expect(restored.originalBirthDateTime, original);
    expect(restored.hasRectifiedTime, isTrue);
  });

  test('old saved chart JSON migrates without original birth time', () {
    final restored = BirthData.fromJson({
      'name': 'Old',
      'localDateTime': '2000-01-01T12:00:00.000',
      'place': 'Guntur',
      'latitude': 16.3,
      'longitude': 80.4,
      'timezoneOffsetHours': 5.5,
      'ayanamsa': 'lahiri',
    });
    expect(restored.originalBirthDateTime, restored.localDateTime);
    expect(restored.hasRectifiedTime, isFalse);
  });

}
