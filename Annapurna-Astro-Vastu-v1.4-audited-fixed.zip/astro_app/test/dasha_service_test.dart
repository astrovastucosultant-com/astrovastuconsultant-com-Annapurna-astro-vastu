import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/dasha_service.dart';

PlanetPosition _p(String name, String shortName, double longitude) {
  return PlanetPosition(
    name: name,
    shortName: shortName,
    longitude: longitude,
    latitude: 0,
    speed: 1,
  );
}

AstroChartResult _chart(double moonLongitude) {
  return AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 0,
    ascendantLongitude: 35,
    engineVersion: 'test',
    planets: [
      _p('Sun', 'Su', 120),
      _p('Moon', 'Mo', moonLongitude),
      _p('Mars', 'Ma', 95),
      _p('Mercury', 'Me', 60),
      _p('Jupiter', 'Ju', 240),
      _p('Venus', 'Ve', 30),
      _p('Saturn', 'Sa', 270),
      _p('Rahu', 'Ra', 300),
      _p('Ketu', 'Ke', 120),
    ],
  );
}

double _sum(Iterable<double> values) =>
    values.fold<double>(0, (total, value) => total + value);

void main() {
  final birth = DateTime(1981, 12, 15, 15, 45);
  // Moon near the beginning of the first nakshatra keeps the test simple.
  final chart = _chart(1.0);

  test('Vimshottari family cycle totals are 120 / 80 / 40 years', () {
    final vim = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birth,
    );
    final tri = DashaService.system(
      kind: DashaSystemKind.tribhagi,
      chart: chart,
      birthDateTime: birth,
    );
    final khanda = DashaService.system(
      kind: DashaSystemKind.khanda,
      chart: chart,
      birthDateTime: birth,
    );

    expect(_sum(vim.weights.values), closeTo(120, 1e-9));
    expect(_sum(tri.weights.values), closeTo(80, 1e-9));
    expect(_sum(khanda.weights.values), closeTo(40, 1e-9));
    expect(tri.weights['Venus'], closeTo(20 * 2 / 3, 1e-9));
    expect(khanda.weights['Saturn'], closeTo(19 / 3, 1e-9));
  });

  test('Yogini cycle totals 36 years', () {
    final yogini = DashaService.system(
      kind: DashaSystemKind.yogini,
      chart: chart,
      birthDateTime: birth,
    );
    expect(_sum(yogini.weights.values), closeTo(36, 1e-9));
    expect(yogini.sequence.length, 8);
  });

  test('sub-periods exactly preserve parent duration in proportional years', () {
    for (final kind in DashaSystemKind.values) {
      final system = DashaService.system(
        kind: kind,
        chart: chart,
        birthDateTime: birth,
      );
      final parent = DashaService.periodAt(system.mahadashas, birth)!;
      final children = DashaService.subPeriodsFor(system, parent);
      expect(_sum(children.map((p) => p.years)), closeTo(parent.years, 1e-9));
    }
  });

  test('all active dasha systems resolve five nested levels for a date', () {
    final probe = DateTime(2026, 10, 3, 12);
    for (final kind in DashaSystemKind.values) {
      final system = DashaService.system(
        kind: kind,
        chart: chart,
        birthDateTime: birth,
      );
      final path = DashaService.pathAt(system, probe);
      expect(path, isNotNull, reason: '$kind should cover the probe date');
      expect(path!.levels.length, 5);
      for (final period in path.levels) {
        expect(period.contains(probe), isTrue);
      }
    }
  });

  test('Mehta source Y-M-D formatter uses 360-day year', () {
    expect(DashaService.sourceYmd360(1), '1-0-0');
    expect(DashaService.sourceYmd360(2 / 3), '0-8-0');
  });
}
