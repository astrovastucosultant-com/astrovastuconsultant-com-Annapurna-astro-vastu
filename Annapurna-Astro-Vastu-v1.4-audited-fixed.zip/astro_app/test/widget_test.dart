import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/main.dart';

void main() {
  testWidgets('Birth details screen is shown', (WidgetTester tester) async {
    await tester.pumpWidget(const AnnapurnaAstroVastuApp());
    expect(find.text('జనన వివరాలు'), findsOneWidget);
    expect(find.text('జాతకం తయారు చేయండి'), findsOneWidget);
  });
}
