import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_service.dart';
import 'package:flutter_test/flutter_test.dart';

PlanetPosition p(String name, String short, int sign) => PlanetPosition(
      name: name,
      shortName: short,
      longitude: sign * 30.0 + 5.0,
      latitude: 0,
      speed: 1,
    );

void main() {
  test('BNN source registry indexes all supplied rule series', () {
    final total = BnnService.sourceSections
        .fold<int>(0, (sum, section) => sum + section.count);
    expect(total, 343);
    expect(BnnService.pageForRule('R-A01'), 2);
    expect(BnnService.pageForRule('C36'), 3);
    expect(BnnService.pageForRule('C37'), 4);
    expect(BnnService.pageForRule('E74'), 9);
    expect(BnnService.pageForRule('K14'), 16);
  });

  test('BNN uses Jupiter sign as first house', () {
    final chart = AstroChartResult(
      julianDay: 0,
      ayanamsaDegrees: 0,
      ascendantLongitude: 90,
      engineVersion: 'test',
      planets: [
        p('Sun', 'Su', 4),
        p('Moon', 'Mo', 6),
        p('Mars', 'Ma', 8),
        p('Mercury', 'Me', 1),
        p('Jupiter', 'Ju', 0),
        p('Venus', 'Ve', 1),
        p('Saturn', 'Sa', 2),
        p('Rahu', 'Ra', 10),
        p('Ketu', 'Ke', 4),
      ],
    );

    final result = BnnService.analyze(chart);
    expect(result.jupiterSignIndex, 0);
    final venus = result.planets.firstWhere((x) => x.name == 'Venus');
    expect(venus.houseFromJupiter, 2);
    final marriage = result.ageIndications
        .firstWhere((x) => x.id == 'BNN-AGE-MARRIAGE');
    expect(marriage.relativeHouse, 2);
    expect(marriage.ages, [24, 25]);
  });
}
