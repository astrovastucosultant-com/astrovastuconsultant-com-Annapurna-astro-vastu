import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d10_career_service.dart';

PlanetPosition _p(String name, String shortName, double longitude) {
  return PlanetPosition(
    name: name,
    shortName: shortName,
    longitude: longitude,
    latitude: 0,
    speed: 1,
  );
}

AstroChartResult _chart() => AstroChartResult(
      julianDay: 0,
      ayanamsaDegrees: 0,
      ascendantLongitude: 15,
      engineVersion: 'test',
      planets: [
        _p('Sun', 'Su', 125),
        _p('Moon', 'Mo', 42),
        _p('Mars', 'Ma', 95),
        _p('Mercury', 'Me', 62),
        _p('Jupiter', 'Ju', 245),
        _p('Venus', 'Ve', 32),
        _p('Saturn', 'Sa', 275),
        _p('Rahu', 'Ra', 305),
        _p('Ketu', 'Ke', 125),
      ],
    );

void main() {
  test('Dashamsha devata degree mapping reverses for even rasi', () {
    expect(D10CareerService.devataForLongitude(1).deity, 'Indra');
    expect(D10CareerService.devataForLongitude(31).deity, 'Ananta');
  });

  test('Ishana devata exposes consultant and astrology profession support', () {
    final ish = D10CareerService.devataForLongitude(22);
    expect(ish.deity, 'Ishana');
    expect(ish.professionGroups, contains('Consultant / Advisor'));
    expect(ish.professionGroups, contains('Astrologer / Jyotisha Practitioner'));
  });

  test('D10 career timing engine produces deterministic window list', () {
    final windows = D10CareerService.timingWindows(
      chart: _chart(),
      birthDateTime: DateTime(1984, 12, 15, 10, 30),
    );
    expect(windows, isA<List<D10CareerWindow>>());
    for (final w in windows) {
      expect(w.end.isAfter(w.start), isTrue);
      expect(w.ruleIds, isNotEmpty);
    }
  });

  test('Saturn stream always returns source state labels', () {
    final result = D10CareerService.saturnStream(_chart());
    expect(result.birthState, isNotEmpty);
    expect(result.navamsaState, isNotEmpty);
    expect(result.dashamsaState, isNotEmpty);
  });
}
