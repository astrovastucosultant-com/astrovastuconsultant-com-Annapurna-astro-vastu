import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d24_education_registry.dart';

void main() {
  test('D24 education registry includes source master rules', () {
    expect(D24EducationRegistry.rules.length, greaterThanOrEqualTo(25));
    expect(D24EducationRegistry.rules.any((r) => r.id == 'EDU-PAR-01'), isTrue);
    expect(D24EducationRegistry.rules.any((r) => r.id == 'EDU-D24-20'), isTrue);
    expect(D24EducationRegistry.rules.any((r) => r.id == 'EDU-JAI-08'), isTrue);
  });

  test('user-configured education sign classification stays fixed', () {
    for (final s in [0, 7, 9, 10]) {
      expect(D24EducationRegistry.userConfiguredNatureForSign(s), 'Technical');
    }
    for (final s in [2, 4, 5]) {
      expect(D24EducationRegistry.userConfiguredNatureForSign(s), 'Semi-technical');
    }
    for (final s in [1, 3, 6, 8, 11]) {
      expect(D24EducationRegistry.userConfiguredNatureForSign(s), 'Non-technical');
    }
  });
}
