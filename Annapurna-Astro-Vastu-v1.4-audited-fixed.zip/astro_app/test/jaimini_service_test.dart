import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';

PlanetPosition _p(String name, String shortName, double longitude) {
  return PlanetPosition(
    name: name,
    shortName: shortName,
    longitude: longitude,
    latitude: 0,
    speed: 1,
  );
}

AstroChartResult _chart({required double marsLongitude}) {
  return AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 0,
    ascendantLongitude: 5, // Aries Lagna for simple Pada verification.
    engineVersion: 'test',
    planets: [
      _p('Sun', 'Su', 120),
      _p('Moon', 'Mo', 90),
      _p('Mars', 'Ma', marsLongitude),
      _p('Mercury', 'Me', 60),
      _p('Jupiter', 'Ju', 240),
      _p('Venus', 'Ve', 30),
      _p('Saturn', 'Sa', 270),
      _p('Rahu', 'Ra', 300),
      _p('Ketu', 'Ke', 120),
    ],
  );
}

void main() {
  test('P1: lord in 4th gives 4th from lord (Aries -> Cancer -> Libra)', () {
    final result = JaiminiService.calculate(_chart(marsLongitude: 95));
    final p1 = result.arudhaPadas.first;

    expect(p1.sourceSignIndex, 0); // Aries
    expect(p1.lord, 'Mars');
    expect(p1.lordSignIndex, 3); // Cancer
    expect(p1.distance, 4);
    expect(p1.padaSignIndex, 6); // Libra
  });

  test('P1: lord in same sign keeps P1 in same sign', () {
    final result = JaiminiService.calculate(_chart(marsLongitude: 5));
    final p1 = result.arudhaPadas.first;

    expect(p1.distance, 1);
    expect(p1.padaSignIndex, 0); // Aries
  });

  test('P1: lord in 7th returns Pada to source sign', () {
    final result = JaiminiService.calculate(_chart(marsLongitude: 185));
    final p1 = result.arudhaPadas.first;

    expect(p1.lordSignIndex, 6); // Libra
    expect(p1.distance, 7);
    expect(p1.padaSignIndex, 0); // Aries
  });
}
