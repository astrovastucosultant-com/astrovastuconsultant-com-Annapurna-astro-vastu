import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/marriage_material_registry.dart';

void main() {
  test('marriage material registry indexes all distinct supplied rules', () {
    expect(MarriageMaterialRegistry.totalRuleCount, 68);
    final ids = MarriageMaterialRegistry.entries.map((e) => e.id).toList();
    expect(ids.toSet().length, ids.length);
    expect(MarriageMaterialRegistry.forFactor(9).isNotEmpty, isTrue);
    expect(MarriageMaterialRegistry.forFactor(7).isNotEmpty, isTrue);
    expect(MarriageMaterialRegistry.forFactor(30).isNotEmpty, isTrue);
  });
}
