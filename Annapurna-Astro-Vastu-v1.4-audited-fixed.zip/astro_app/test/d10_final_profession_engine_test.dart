import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/d10_final_profession_engine.dart';
import 'package:astro_app/astrology/d10_career_service.dart';

void main() {
  test('user-locked D10 sign nature classification is preserved', () {
    expect(D10FinalProfessionEngine.signNature(0), 'Technical'); // Aries
    expect(D10FinalProfessionEngine.signNature(7), 'Technical'); // Scorpio
    expect(D10FinalProfessionEngine.signNature(9), 'Technical'); // Capricorn
    expect(D10FinalProfessionEngine.signNature(10), 'Technical'); // Aquarius
    expect(D10FinalProfessionEngine.signNature(2), 'Semi-Technical'); // Gemini
    expect(D10FinalProfessionEngine.signNature(4), 'Semi-Technical'); // Leo
    expect(D10FinalProfessionEngine.signNature(5), 'Semi-Technical'); // Virgo
    expect(D10FinalProfessionEngine.signNature(3), 'Non-Technical'); // Cancer
  });

  test('27 nakshatra profession profiles are loaded', () {
    expect(D10FinalProfessionEngine.nakshatraProfiles.length, 27);
    expect(D10FinalProfessionEngine.nakshatraProfiles.first.nameTe, 'అశ్విని');
    expect(D10FinalProfessionEngine.nakshatraProfiles.last.nameTe, 'రేవతి');
  });

  test('Amsha Devata provides work-flow modifier', () {
    // 3°-6° in an odd sign maps to the Agni Dashamsha segment.
    final agni = D10CareerService.devataForLongitude(4.0);
    expect(agni.deity, 'Agni');
    expect(agni.workFlowModifier, contains('active execution'));
  });

  test('BPHS Shayanadi validation example gives Netrapani Vicheshta', () {
    // Source validation example: Sun in 3rd nakshatra, 3rd navamsa,
    // Janma nakshatra 3, running ghati 31, Scorpio lagna=8, name anka=4.
    // Use longitude 26°40' (Krittika, 9th navamsa in Aries) would not match
    // the example's N=3, so choose an equivalent longitude where N=3 and
    // nakshatra serial is 3: 36°40' is Krittika and 3rd navamsa of Taurus.
    final r = D10FinalProfessionEngine.shayanadi(
      planet: 'Sun',
      siderealLongitude: 36 + 40 / 60,
      janmaNakshatraNumber: 3,
      birthGhati: 31,
      lagnaSignNumber: 8,
      nameAnka: 4,
    );
    expect(r.state, 'Netrapani');
    expect(r.subState, 'Vicheshta');
    expect(r.expression, 'Negligible');
  });
}
