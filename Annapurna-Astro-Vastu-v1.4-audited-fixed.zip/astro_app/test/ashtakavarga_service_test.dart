import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/ashtakavarga_service.dart';
import 'package:astro_app/astrology/astro_models.dart';

void main() {
  const planets = <PlanetPosition>[
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 10, latitude: 0, speed: 1),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 42, latitude: 0, speed: 12),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 75, latitude: 0, speed: 0.5),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108, latitude: 0, speed: 1),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 141, latitude: 0, speed: 0.1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 174, latitude: 0, speed: 1),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 207, latitude: 0, speed: -0.1),
    PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 240, latitude: 0, speed: -0.05),
    PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 60, latitude: 0, speed: -0.05),
  ];

  const chart = AstroChartResult(
    julianDay: 2460000.5,
    ayanamsaDegrees: 24,
    ascendantLongitude: 18,
    planets: planets,
    engineVersion: 'test',
  );

  test('BAV fixed totals and SAV grand total remain invariant', () {
    final result = AshtakavargaService.calculate(chart);

    expect(result.totalsValid, isTrue);
    expect(result.grandTotal, 337);
    expect(result.totalFor('Sun'), 48);
    expect(result.totalFor('Moon'), 49);
    expect(result.totalFor('Mars'), 39);
    expect(result.totalFor('Mercury'), 54);
    expect(result.totalFor('Jupiter'), 56);
    expect(result.totalFor('Venus'), 52);
    expect(result.totalFor('Saturn'), 39);
  });

  test('Prastara rows reproduce each selected BAV row', () {
    final result = AshtakavargaService.calculate(chart);
    for (final target in AshtakavargaService.planetOrder) {
      final rows = result.prastara[target]!;
      final rebuilt = List<int>.filled(12, 0);
      for (final row in rows.values) {
        for (var i = 0; i < 12; i++) {
          rebuilt[i] += row[i];
        }
      }
      expect(rebuilt, result.bhinna[target]);
    }
  });
}
