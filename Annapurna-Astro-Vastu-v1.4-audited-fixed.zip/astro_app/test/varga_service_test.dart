import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/varga_service.dart';

void main() {
  test('classical varga mappings hit expected starting signs', () {
    expect(VargaService.signForLongitude(0.0, 9), 0); // Aries D9 -> Aries
    expect(VargaService.signForLongitude(30.0, 9), 9); // Taurus D9 -> Capricorn
    expect(VargaService.signForLongitude(30.0, 40), 6); // even sign -> Libra
    expect(VargaService.signForLongitude(60.0, 45), 8); // dual sign -> Sagittarius
    expect(VargaService.signForLongitude(30.0, 60), 1); // D60 starts from own sign
  });

  test('trimshamsha uses classical unequal divisions', () {
    expect(VargaService.signForLongitude(2.0, 30), 0); // odd sign Mars
    expect(VargaService.signForLongitude(7.0, 30), 10); // odd sign Saturn
    expect(VargaService.signForLongitude(32.0, 30), 1); // even sign Venus
    expect(VargaService.signForLongitude(36.0, 30), 5); // even sign Mercury
  });

  test('all 16 supported vargas return zodiac sign indexes', () {
    for (final definition in VargaService.definitions) {
      final sign = VargaService.signForLongitude(123.456789, definition.factor);
      expect(sign, inInclusiveRange(0, 11));
    }
  });
}
