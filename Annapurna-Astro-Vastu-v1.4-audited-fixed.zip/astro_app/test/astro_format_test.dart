import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/utils/astro_format.dart';

void main() {
  test('longitude rounding carries into the next sign', () {
    expect(
      AstroFormat.longitudeDms(29.999999),
      'వృషభ  00° 00′ 00″',
    );
  });

  test('negative longitude normalizes correctly', () {
    expect(
      AstroFormat.longitudeDms(-0.5),
      'మీన  29° 30′ 00″',
    );
  });

  test('timezone formats fractional offsets as hh:mm', () {
    expect(AstroFormat.timezoneOffset(5.5), 'UTC+05:30');
    expect(AstroFormat.timezoneOffset(-3.5), 'UTC-03:30');
    expect(AstroFormat.timezoneOffset(5.75), 'UTC+05:45');
  });
}
