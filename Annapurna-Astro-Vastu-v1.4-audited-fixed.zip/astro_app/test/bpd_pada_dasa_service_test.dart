import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bpd_pada_dasa_service.dart';

void main() {
  const chart = AstroChartResult(
    julianDay: 2450000,
    ayanamsaDegrees: 23,
    ascendantLongitude: 5,
    engineVersion: 'fixture',
    planets: [
      PlanetPosition(name:'Sun', shortName:'Su', longitude:120, latitude:0, speed:1),
      PlanetPosition(name:'Moon', shortName:'Mo', longitude:92, latitude:0, speed:13),
      PlanetPosition(name:'Mars', shortName:'Ma', longitude:5, latitude:0, speed:0.3),
      PlanetPosition(name:'Mercury', shortName:'Me', longitude:156, latitude:0, speed:0.6),
      PlanetPosition(name:'Jupiter', shortName:'Ju', longitude:277, latitude:0, speed:0.2),
      PlanetPosition(name:'Venus', shortName:'Ve', longitude:185, latitude:0, speed:0.8),
      PlanetPosition(name:'Saturn', shortName:'Sa', longitude:301, latitude:0, speed:0.1),
      PlanetPosition(name:'Rahu', shortName:'Ra', longitude:75, latitude:0, speed:-0.01),
    ],
  );

  test('Dr Vaani and Nadi Praveshika keep distinct Saturn cycle durations', () {
    expect(BpdPadaDasaService.vaaniCycles['Saturn'],30);
    expect(BpdPadaDasaService.nadiCycles['Saturn'],29);
    expect(BpdPadaDasaService.vaaniCycles.containsKey('Rahu'),isFalse);
    expect(BpdPadaDasaService.nadiCycles['Rahu'],93);
    final va = BpdPadaDasaService.progression(planet:'Saturn',
      natalSign:0,elapsedYears:29.2,profile:BpdProfile.vaaniSeven);
    final np = BpdPadaDasaService.progression(planet:'Saturn',
      natalSign:0,elapsedYears:29.2,profile:BpdProfile.nadiPraveshikaEight);
    expect(va.cycle,1);
    expect(np.cycle,2);
    expect(va.progressedSign,isNot(np.progressedSign));
  });

  test('Vaani standard Arudha exception differs from Nadi no-exception', () {
    // Aries bhava, its lord Mars placed in Aries: raw P1=Aries.
    expect(BpdPadaDasaService.arudha(0,0,BpdProfile.nadiPraveshikaEight),0);
    expect(BpdPadaDasaService.arudha(0,0,BpdProfile.vaaniSeven),9);
    // Lord 4th from house: raw pada is 7th, then 10th from raw.
    expect(BpdPadaDasaService.arudha(0,3,BpdProfile.nadiPraveshikaEight),6);
    expect(BpdPadaDasaService.arudha(0,3,BpdProfile.vaaniSeven),3);
  });

  test('whole first sign, 12 sign periods, periodic cycle boundary', () {
    for(final profile in BpdProfile.values) {
      final initial=BpdPadaDasaService.progression(planet:'Jupiter',
        natalSign:2,elapsedYears:0,profile:profile);
      expect(initial.progressedSign,2);
      expect(initial.signPosition,1);
      final second=BpdPadaDasaService.progression(planet:'Jupiter',
        natalSign:2,elapsedYears:83/12+0.01,profile:profile);
      expect(second.progressedSign,3);
      final restart=BpdPadaDasaService.progression(planet:'Jupiter',
        natalSign:2,elapsedYears:83,profile:profile);
      expect(restart.cycle,2);
      expect(restart.progressedSign,2);
    }
  });

  test('Nadi Jupiter subdivisions divide selected sign period into twelve', () {
    final start=BpdPadaDasaService.progression(planet:'Jupiter',
      natalSign:0,elapsedYears:0,profile:BpdProfile.nadiPraveshikaEight);
    final half=BpdPadaDasaService.progression(planet:'Jupiter',
      natalSign:0,elapsedYears:83/24,profile:BpdProfile.nadiPraveshikaEight);
    expect(start.antardashaPosition,1);
    expect(half.antardashaPosition,7);
    expect(BpdPadaDasaService.progression(planet:'Jupiter',
      natalSign:0,elapsedYears:0,profile:BpdProfile.vaaniSeven)
      .antardashaPosition,isNull);
  });

  test('23 Nadi dictums tracked without treating manual ones as tested', () {
    expect(BpdPadaDasaService.nadiDictums.length,23);
    expect(BpdPadaDasaService.nadiDictums.map((e)=>e.id).toSet().length,23);
    final birth=DateTime(1980,1,1,12);
    final event=DateTime(2023,1,1,12);
    final result=BpdPadaDasaService.compute(chart:chart,
      birthDate:birth,eventDate:event,
      profile:BpdProfile.nadiPraveshikaEight,eventHouses:[1,7]);
    expect(result.progressions.length,8);
    expect(result.observations.length,23);
    expect(result.observations.firstWhere((r)=>r.ruleId=='NP-BPD-23').matched,isNull);
    expect(result.arudhaSigns.length,12);
    final v=BpdPadaDasaService.compute(chart:chart,
      birthDate:birth,eventDate:event,
      profile:BpdProfile.vaaniSeven,eventHouses:[1,7]);
    expect(v.progressions.length,7);
    expect(v.observations,isEmpty);
    expect(v.arudhaSigns[1],isNot(result.arudhaSigns[1]));
  });
}
