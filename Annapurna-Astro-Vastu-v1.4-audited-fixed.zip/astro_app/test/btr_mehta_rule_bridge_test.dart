import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/btr_mehta_rule_bridge.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';
import 'package:astro_app/models/birth_data.dart';

void main() {
  const positive = AstroChartResult(
    julianDay: 2450000, ayanamsaDegrees: 23,
    ascendantLongitude: 11, engineVersion: 'unit-test',
    planets: [
      PlanetPosition(name:'Moon', shortName:'Mo',
        longitude:42,latitude:0,speed:13),
      PlanetPosition(name:'Mars',shortName:'Ma',
        longitude:100,latitude:0,speed:0.5),
      PlanetPosition(name:'Venus',shortName:'Ve',
        longitude:135,latitude:0,speed:1),
      PlanetPosition(name:'Jupiter',shortName:'Ju',
        longitude:12,latitude:0,speed:0.1),
    ],
  );
  const negative = AstroChartResult(
    julianDay: 2450000, ayanamsaDegrees: 23,
    ascendantLongitude: 11, engineVersion: 'unit-test',
    planets: [
      PlanetPosition(name:'Moon',shortName:'Mo',
        longitude:42,latitude:0,speed:13),
      PlanetPosition(name:'Mars',shortName:'Ma',
        longitude:11,latitude:0,speed:0.5),
      PlanetPosition(name:'Venus',shortName:'Ve',
        longitude:15,latitude:0,speed:1),
      PlanetPosition(name:'Jupiter',shortName:'Ju',
        longitude:12,latitude:0,speed:0.1),
    ],
  );
  final natal = BirthData(
    name:'Example', localDateTime:DateTime(1985,7,22,10),
    place:'Guntur',latitude:16.3,longitude:80.44,
    timezoneOffsetHours:5.5,ayanamsa:AyanamsaType.lahiri,
  );

  test('R084 matches only when a pre-existing book evaluator matches', () {
    final yes = BtrMehtaRuleBridge.inspect(
      'R084', BtrMehtaRuleBridge.evaluatedBookRules(positive));
    final no = BtrMehtaRuleBridge.inspect(
      'R084', BtrMehtaRuleBridge.evaluatedBookRules(negative));
    expect(yes.evaluated,isTrue);
    expect(yes.matched,isTrue);
    expect(no.evaluated,isTrue);
    expect(no.matched,isFalse);
  });

  test('ND entries and absent book evaluators never receive false green ticks', () {
    final available = BtrMehtaRuleBridge.evaluatedBookRules(positive);
    expect(BtrMehtaRuleBridge.inspect('ND-075',available).evaluated,isFalse);
    expect(BtrMehtaRuleBridge.inspect('R085',available).evaluated,isFalse);
    expect(BtrMehtaRuleBridge.inspect(null,available).evaluated,isFalse);
    expect(BtrMehtaRuleBridge.ruleNumber('ND-075'),isNull);
    expect(BtrMehtaRuleBridge.ruleNumber('R084'),84);
    expect(BtrMehtaRuleBridge.topicForEvent('M06'),'child');
    expect(BtrMehtaRuleBridge.topicForEvent('M11'),'promotion');
  });

  test('a manually reviewed rule cannot affect BTR candidate score', () async {
    final eventDate = DateTime(2015,5,10);
    final baseline = await MehtaBtrService.scoreCandidate(
      natal:natal,candidateBirthTime:natal.localDateTime,
      events:[MehtaBtrEvent(ruleId:'M11',occurredAt:eventDate)],
      chartCalculator: (_) async => positive,
    );
    final manual = await MehtaBtrService.scoreCandidate(
      natal:natal,candidateBirthTime:natal.localDateTime,
      events:[MehtaBtrEvent(ruleId:'M11',occurredAt:eventDate,
        sourceRuleId:'ND-075')],
      chartCalculator: (_) async => positive,
    );
    expect(manual.evidenceShare,baseline.evidenceShare);
    expect(manual.evidence.single.sourceCheck.evaluated,isFalse);
    expect(manual.evidence.single.sourceCheck.ruleId,'ND-075');
  });

  test('selected eligible R084 condition contributes bounded 25 percent', () async {
    final date = DateTime(2015,5,10);
    Future<MehtaBtrCandidate> score(AstroChartResult chart) =>
      MehtaBtrService.scoreCandidate(
        natal:natal,candidateBirthTime:natal.localDateTime,
        events:[MehtaBtrEvent(ruleId:'M11', occurredAt:date,
          sourceRuleId:'R084')],
        chartCalculator: (_) async => chart,
      );
    final yes=await score(positive);
    final no=await score(negative);
    expect(yes.evidence.single.sourceCheck.matched,isTrue);
    expect(no.evidence.single.sourceCheck.matched,isFalse);
    for(final c in [yes,no]) {
      expect(c.evidence.single.rankingShare,inInclusiveRange(0,1));
      expect(c.evidenceShare,closeTo(c.evidence.single.rankingShare,0.001));
    }
  });
}
