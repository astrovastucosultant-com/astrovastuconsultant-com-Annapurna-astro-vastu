import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

void main() {
  test('D7 calculation includes actual BS/KS, Lagna lord and 12 house rows', () {
    final positions = <String, double>{
      'Sun': 12.0, 'Moon': 48.0, 'Mars': 98.0,
      'Mercury': 111.0, 'Jupiter': 170.0, 'Venus': 199.0,
      'Saturn': 245.0, 'Rahu': 289.0, 'Ketu': 109.0,
    };
    final chart = AstroChartResult(
      julianDay: 2451545.0,
      ayanamsaDegrees: 23.8,
      ascendantLongitude: 15.0,
      planets: positions.entries.map((e) => PlanetPosition(
        name: e.key, shortName: e.key.substring(0, 2),
        longitude: e.value, latitude: 0.0, speed: 1.0,
      )).toList(),
      engineVersion: 'test',
    );
    final rules = VargaRuleService.allFor(chart: chart, factor: 7);
    for (final id in [
      'D7-SANTANA-017', 'D7-SANTANA-018',
      'D7-SANTANA-019', 'D7-SANTANA-020',
    ]) {
      expect(rules.where((r) => r.ruleId == id).length, 1, reason: id);
    }
    expect(rules.where((r) => r.ruleId.startsWith('D7-HOUSE-')).length, 12);
    expect(rules.firstWhere((r) => r.ruleId == 'D7-SANTANA-017')
        .inspection, contains('BS ='));
    expect(rules.firstWhere((r) => r.ruleId == 'D7-SANTANA-018')
        .inspection, contains('KS ='));
    expect(rules.where((r) => r.ruleId.startsWith('D7-HOUSE-') && r.applicable)
        .every((r) => r.autoEvaluated), isTrue);
  });
}
