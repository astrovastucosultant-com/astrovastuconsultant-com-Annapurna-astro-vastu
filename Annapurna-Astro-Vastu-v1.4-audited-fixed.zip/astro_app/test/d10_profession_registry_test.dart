import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/d10_profession_registry.dart';
import 'package:astro_app/astrology/d10_career_service.dart';

void main() {
  test('D10 exact profession registry contains all supplied rows', () {
    expect(d10ProfessionRules.length, 181);
    expect(d10ProfessionRules.any((r) => r.name == 'జ్యోతిషం'), isTrue);
    expect(d10ProfessionRules.any((r) => r.name == 'వాస్తు సలహా'), isTrue);
    expect(d10ProfessionRules.any((r) => r.name == 'కూలీ, శ్రమ'), isTrue);
    expect(d10ProfessionRules.any((r) => r.name == 'కన్సల్టెంట్'), isTrue);
    expect(d10ProfessionRules.any((r) => r.name == 'రియల్ ఎస్టేట్'), isTrue);
  });

  test('every exact profession row has source metadata', () {
    for (final rule in d10ProfessionRules) {
      expect(rule.id, isNotEmpty);
      expect(rule.category, isNotEmpty);
      expect(rule.name, isNotEmpty);
      expect(rule.planet, isNotEmpty);
      expect(rule.devata, isNotEmpty);
      expect(rule.sourcePage, inInclusiveRange(1, 6));
    }
  });


  test('Ishana is supporting Devata, not standalone Astrologer verdict', () {
    final profile = D10CareerService.devataForLongitude(22.0);
    expect(profile.deity, 'Ishana');
    expect(profile.professionGroups, contains('Consultant / Advisor'));
    expect(profile.professionGroups, isNot(contains('Astrologer / Jyotisha Practitioner')));
    expect(profile.professionGroups, isNot(contains('Astrology / Traditional Studies')));
  });
}
