import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/kp_cusp_significator_service.dart';
import 'package:astro_app/astrology/btr_integrated_method_service.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';

void main() {
  AstroChartResult sample({bool includeCusps = true}) => AstroChartResult(
    julianDay: 2460000,
    ayanamsaDegrees: 23.5,
    ascendantLongitude: 0,
    engineVersion: 'fixture',
    houseCuspLongitudes: includeCusps
      ? [for (var i = 0; i < 12; i++) i * 30.0]
      : const [],
    planets: const [
      PlanetPosition(name:'Sun', shortName:'Su', longitude: 15,latitude:0,speed:1),
      PlanetPosition(name:'Moon',shortName:'Mo',longitude: 42,latitude:0,speed:1),
      PlanetPosition(name:'Mars',shortName:'Ma',longitude: 82,latitude:0,speed:1),
      PlanetPosition(name:'Mercury',shortName:'Me',longitude: 115,latitude:0,speed:1),
      PlanetPosition(name:'Jupiter',shortName:'Ju',longitude: 143,latitude:0,speed:1),
      PlanetPosition(name:'Venus',shortName:'Ve',longitude: 187,latitude:0,speed:1),
      PlanetPosition(name:'Saturn',shortName:'Sa',longitude: 217,latitude:0,speed:1),
      PlanetPosition(name:'Rahu',shortName:'Ra',longitude: 248,latitude:0,speed:-0.1),
      PlanetPosition(name:'Ketu',shortName:'Ke',longitude: 68,latitude:0,speed:-0.1),
    ],
  );

  test('KP 12 actual cusps, distinct 4-level significator houses', () {
    final audit = KpCuspSignificatorService.compute(sample());
    expect(audit.available, true);
    expect(audit.cusps, hasLength(12));
    expect(audit.cusps.first.house, 1);
    expect(audit.planets['Sun']!.occupiedHouse, 1);
    expect(audit.planets['Venus']!.occupiedHouse, 7);
    expect(audit.planets['Rahu']!.isNode, true);
    expect(audit.planets['Sun']!.starLordOccupied, isNotEmpty);
    expect(audit.planets['Sun']!.owned, isNotEmpty);
    expect(audit.signature.split('|'),hasLength(12));
  });
  test('wrap-around arcs and boundary go to the new cusp house', () {
    final chart = AstroChartResult(
      julianDay: 1, ayanamsaDegrees: 0, ascendantLongitude: 345,
      engineVersion: 'fixture',
      houseCuspLongitudes: [for(var h=0;h<12;h++) (345+h*30)%360],
      planets: const [
        PlanetPosition(name:'Sun',shortName:'Su',longitude:345,latitude:0,speed:1),
        PlanetPosition(name:'Moon',shortName:'Mo',longitude:14,latitude:0,speed:1),
      ]);
    final result = KpCuspSignificatorService.compute(chart);
    expect(result.available, true);
    expect(result.planets['Sun']!.occupiedHouse, 1);
    expect(result.planets['Moon']!.occupiedHouse, 1);
  });
  test('missing or invalid cusps never silently creates equal houses', () {
    final noCusps=KpCuspSignificatorService.compute(sample(includeCusps:false));
    expect(noCusps.available, false);
    expect(noCusps.forEvent('M01'), isNull);
    final invalid=AstroChartResult(
      julianDay: 1, ayanamsaDegrees: 0, ascendantLongitude: 0,
      engineVersion: 'fixture',
      houseCuspLongitudes: List<double>.filled(12,0),planets: const []);
    expect(KpCuspSignificatorService.compute(invalid).available,false);
  });
  test('event-specific KP marriage houses differ from SK Mehta houses', () {
    final audit=KpCuspSignificatorService.compute(sample());
    final marriage=audit.forEvent('M01')!;
    expect(marriage.primaryHouse,7);
    expect(marriage.favourableHouses,[2,7,11]);
    expect(marriage.contraryHouses,[1,6,10,12]);
    expect(audit.forEvent('M06')!.primaryHouse,5);
    expect(audit.forEvent('unknown'),isNull);
    final result=BtrIntegratedMethodService.kp('KP:test',audit:marriage);
    expect(result.method,'KP');
    expect(result.isSourceRuleMatched,false);
    expect(result.details,contains('Sub Lord'));
  });
  test('KP does not alter BTR rankings or BPD event context', () {
    final old=MehtaBtrCandidate(
      birthTime: DateTime.utc(2000,1,1),
      evidenceShare:0.5,evidence:[],timeSignature:'KP:previous');
    expect(old.evidenceShare,0.5);
    expect(old.kpChartAudit,isNull);
    expect(BtrIntegratedMethodService.kp('KP:previous').isSourceRuleMatched,false);
  });
}
