import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_family_house_service.dart';
import 'package:astro_app/astrology/mehta_family_interpretation_service.dart';

void main() {
  MehtaFamilyRelation relation(String id) =>
      MehtaFamilyHouseService.relations.firstWhere((r) => r.id == id);
  MehtaFamilyTopic topic(String id) =>
      MehtaFamilyHouseService.topics.firstWhere((t) => t.id == id);
  PlanetPosition planet(String name, int sign, {double degree = 10}) =>
      PlanetPosition(name: name, shortName: name.substring(0, 2),
          longitude: sign * 30.0 + degree, latitude: 0, speed: 1);
  AstroChartResult chart(int asc, List<PlanetPosition> planets) =>
      AstroChartResult(julianDay: 2451545, ayanamsaDegrees: 24,
          ascendantLongitude: asc * 30.0 + 4,
          planets: planets, engineVersion: 'test');

  test('all 27 family relations × 12 topics have audit evaluations', () {
    final c = chart(0, [planet('Saturn', 9), planet('Venus', 7),
      planet('Mars', 5), planet('Moon', 3), planet('Jupiter', 4)]);
    for (final r in MehtaFamilyHouseService.relations) {
      final reports = MehtaFamilyInterpretationService.allTopics(c, r);
      expect(reports.length, 12);
      for (final report in reports) {
        expect(report.targetHouse, inInclusiveRange(1, 12));
        expect(report.relationHouse, inInclusiveRange(1, 12));
        expect(report.checks.length, 10);
        expect(report.result.isNotEmpty, isTrue);
        expect(report.lord.isNotEmpty, isTrue);
      }
    }
  });

  test('father reference is 10th and career from father is natal 7th', () {
    final r = relation('father');
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Saturn', 9)]), r, topic('profession'));
    expect(result.relationHouse, 10);
    expect(result.targetHouse, 7);
  });

  test('debilitated Saturn aspects own Capricorn: evidence is mixed', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Saturn', 0)]), relation('father'), topic('self'));
    expect(result.targetHouse, 10);
    expect(result.lord, 'Saturn');
    expect(result.checks.firstWhere((c) => c.id == 'MF-02').matched, isTrue);
    expect(result.checks.firstWhere((c) => c.id == 'MF-08').matched, isTrue);
    expect(result.checks.firstWhere((c) => c.id == 'MF-10').matched, isTrue);
    expect(result.type, MehtaFamilyFindingType.mixed);
  });

  test('exalted Sun in Aries is strength evidence, not certain event', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Sun', 0)]), relation('self'), topic('self'));
    expect(result.checks.firstWhere((c) => c.id == 'MF-03').matched, isTrue);
    expect(result.type, MehtaFamilyFindingType.supporting);
    expect(result.result.contains('నిర్ధారణ కాదు'), isTrue);
  });

  test('lord in relative sixth is a caution from derived house', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Mars', 5)]), relation('self'), topic('self'));
    expect(result.lordRelativeHouse, 6);
    expect(result.checks.firstWhere((c) => c.id == 'MF-07').matched, isTrue);
    expect(result.type, MehtaFamilyFindingType.cautionary);
  });

  test('planetary exchange is an explicit Mehta relationship', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, [planet('Mars', 1), planet('Venus', 0)]),
        relation('self'), topic('self'));
    expect(result.checks.firstWhere((c) => c.id == 'MF-05').matched, isTrue);
    expect(result.relationships.any((s) => s.contains('పరివర్తన')), isTrue);
  });

  test('missing planets does not become a favorable or adverse prediction', () {
    final result = MehtaFamilyInterpretationService.inspect(
        chart(0, []), relation('father'), topic('self'));
    expect(result.type, MehtaFamilyFindingType.undetermined);
    expect(result.lordRelativeHouse, isNull);
    expect(result.unfavorable, isEmpty);
    expect(result.favorable, isEmpty);
  });

  test('Mercury source-specific exaltation is Aquarius, not Virgo', () {
    expect(MehtaFamilyInterpretationService.exalted['Mercury'], [10]);
    expect(MehtaFamilyInterpretationService.fallen['Mercury'], [4]);
  });
}
