import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/screens/mehta_btr_rulebook_screen.dart';

void main() {
  testWidgets('rulebook BTR action is available when route callback exists',
      (tester) async {
    var opened = 0;
    await tester.pumpWidget(MaterialApp(home: MehtaBtrRulebookScreen(
      onOpenBtr: () { opened++; },
      btrButtonLabel: 'BTR గత సంఘటనలకు తిరిగి వెళ్లండి',
    )));
    await tester.pumpAndSettle();
    final button = find.text('BTR గత సంఘటనలకు తిరిగి వెళ్లండి');
    expect(button, findsOneWidget);
    await tester.tap(button);
    expect(opened, 1);
  });
}
