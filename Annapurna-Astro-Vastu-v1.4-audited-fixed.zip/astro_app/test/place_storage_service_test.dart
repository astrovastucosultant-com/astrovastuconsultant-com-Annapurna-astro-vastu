import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:astro_app/services/place_search_service.dart';
import 'package:astro_app/services/place_storage_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  test('saved custom places persist and deduplicate by coordinates', () async {
    const place = PlaceResult(
      displayName: 'Guntur',
      latitude: 16.3067,
      longitude: 80.4365,
    );

    await PlaceStorageService.save(place);
    await PlaceStorageService.save(place);

    final loaded = await PlaceStorageService.load();
    expect(loaded, hasLength(1));
    expect(loaded.first.displayName, 'Guntur');
    expect(loaded.first.latitude, closeTo(16.3067, 0.000001));
    expect(loaded.first.longitude, closeTo(80.4365, 0.000001));

    await PlaceStorageService.delete(place);
    expect(await PlaceStorageService.load(), isEmpty);
  });
}
