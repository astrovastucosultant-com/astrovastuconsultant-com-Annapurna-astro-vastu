import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/vedic_calculation_service.dart';

void main() {
  test('nakshatra and pada boundaries are stable', () {
    final first = VedicCalculationService.nakshatra(0);
    expect(first.index, 0);
    expect(first.pada, 1);

    final end = VedicCalculationService.nakshatra(359.999);
    expect(end.index, 26);
    expect(end.pada, 4);
  });

  test('panchanga returns tithi, nakshatra, yoga and karana', () {
    const chart = AstroChartResult(
      julianDay: 2460000.5,
      ayanamsaDegrees: 24,
      ascendantLongitude: 0,
      engineVersion: 'test',
      planets: [
        PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 0, latitude: 0, speed: 1),
        PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 6, latitude: 0, speed: 12),
      ],
    );

    final p = VedicCalculationService.panchanga(chart);
    expect(p.paksha, 'శుక్ల పక్షం');
    expect(p.tithi, 'పాడ్యమి');
    expect(p.karana, 'బవ');
    expect(p.nakshatra, isNotEmpty);
    expect(p.yoga, isNotEmpty);
  });
}
