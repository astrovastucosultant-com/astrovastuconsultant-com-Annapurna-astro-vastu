import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/ashtakavarga_event_year_service.dart';
import 'package:astro_app/astrology/ashtakavarga_service.dart';
import 'package:astro_app/astrology/astro_models.dart';

void main() {
  const chart = AstroChartResult(
    julianDay: 2460000.5,
    ayanamsaDegrees: 24,
    ascendantLongitude: 18, // sign 1
    planets: [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 100, latitude: 0, speed: 1), // sign 4
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 42, latitude: 0, speed: 12),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 75, latitude: 0, speed: 0.5),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 141, latitude: 0, speed: 0.1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 174, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 207, latitude: 0, speed: -0.1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 240, latitude: 0, speed: -0.05),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 60, latitude: 0, speed: -0.05),
    ],
    engineVersion: 'test',
  );

  test('AV-008 trace exposes both Lagna-to-planet and return source-input paths', () {
    final av = AshtakavargaService.calculate(chart);
    final traces = AshtakavargaEventYearService.evaluate(chart: chart, av: av);
    expect(traces.length, 7);
    final sun = traces.firstWhere((x) => x.planet == 'Sun');
    expect(sun.lagnaSignNumber, 1);
    expect(sun.planetSignNumber, 4);
    expect(sun.lagnaToPlanet.map((x) => x.signNumber).toList(), [1, 2, 3, 4]);
    expect(sun.planetToLagna.map((x) => x.signNumber).toList(), [4, 5, 6, 7, 8, 9, 10, 11, 12, 1]);
    expect(sun.lagnaToPlanet.every((x) => x.planetBav >= 0 && x.sav >= 0), isTrue);
  });
}
