import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/widgets/mandatory_result_flow.dart';

void main() {
  const entry = MandatoryResultEntry(
    module: 'D12',
    title: 'తల్లిదండ్రుల సంబంధం',
    result: 'పరీక్షా ఫలితం',
    ruleId: 'D12-TEST-01',
    rule: 'IF: గ్రహ సంబంధం',
    inspection: 'జాతకంలో 4వ భావానికి దృష్టి',
    source: 'D12.pdf • p.307',
  );

  testWidgets('Mandatory order: result → rule → inspection → remedy', (tester) async {
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: Builder(
      builder: (context) => ElevatedButton(
        onPressed: () => MandatoryResultFlow.open(context, entry),
        child: const Text('Open'),
      ),
    ))));
    await tester.tap(find.text('Open'));
    await tester.pumpAndSettle();
    expect(find.text('పరీక్షా ఫలితం'), findsOneWidget);
    expect(find.text('జాతకంలో 4వ భావానికి దృష్టి'), findsNothing);
    await tester.tap(find.byKey(const Key('mandatory-flow-next')));
    await tester.pumpAndSettle();
    expect(find.text('IF: గ్రహ సంబంధం'), findsOneWidget);
    await tester.tap(find.byKey(const Key('mandatory-flow-next')));
    await tester.pumpAndSettle();
    expect(find.text('జాతకంలో 4వ భావానికి దృష్టి'), findsOneWidget);
    await tester.tap(find.byKey(const Key('mandatory-flow-next')));
    await tester.pumpAndSettle();
    expect(find.text(MandatoryResultFlow.noRemedy), findsOneWidget);
  });

  testWidgets('Unverified source rule never becomes verified chart result', (tester) async {
    const unverified = MandatoryResultEntry(
      module: 'D12 source',
      title: 'Rule',
      result: 'సాంప్రదాయ గ్రంథ వాక్యం',
      ruleId: 'SOURCE-01',
      rule: 'IF: source',
      inspection: '',
      source: 'Printed p.300',
      verifiedForChart: false,
    );
    await tester.pumpWidget(MaterialApp(home: Scaffold(body: Builder(
      builder: (context) => ElevatedButton(
        onPressed: () => MandatoryResultFlow.open(context, unverified),
        child: const Text('Open'),
      ),
    ))));
    await tester.tap(find.text('Open'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Source-only / ధృవీకరణ పెండింగ్'), findsWidgets);
    await tester.tap(find.byKey(const Key('mandatory-flow-next')));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('mandatory-flow-next')));
    await tester.pumpAndSettle();
    expect(find.text(MandatoryResultFlow.noInspection), findsOneWidget);
  });
}
