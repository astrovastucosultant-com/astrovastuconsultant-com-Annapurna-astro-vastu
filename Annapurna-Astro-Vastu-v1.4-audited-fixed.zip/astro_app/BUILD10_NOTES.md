# Build 10

- New permanent Android application ID: `com.annapurna.astrovastu.consultancy` to avoid conflicts with older Build 7/8/9 packages.
- Stable development signing key bundled for sideload updates from Build 10 onward. This is for private/development distribution, not a Play Store production signing strategy.
- Updated home logo/banner using Annapurna branding, Telugu + English consultancy title, and feature line.
- South Indian fixed-sign 4x4 chart remains enabled for D1, Shodashavarga, and Ashtakavarga views.
- Version 1.8.0+10.
