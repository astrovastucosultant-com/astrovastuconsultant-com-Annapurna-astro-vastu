# Annapurna Astro Vastu — Build103 (v1.4.103+103)

## Purpose
Fix D7 client-screen issues visible in the Build85 APK screenshots.

## Changes
- Remove repetitive book/medical disclaimer from every matched D7 special-rule result. Show an accurate, single D7 disclosure above special groups: green tick = conditional book-rule match, not a confirmed medical or life outcome.
- Twins BS/KS D7-4: calculate dual-sign condition separately across D1, D9 and D7, matching the book p.26. Actual chart details are available on result -> rule. Source specifies additional Rahu/Ketu conditions, not all implemented.
- Add reproducible D7-3 twins condition: dual D7 lagna AND D7 lagna lord also in dual sign (p.26).
- Source p.19 comfort condition tests BS *or* KS in kendra/trikona, rather than requiring both.
- Make matched condition descriptions clear as traditional source indications, not generic “supporting factor” fillers.
- Special matched categories (Rinanubandha, adoption, twins, luxury, body/nature) are displayed in their own expanders only, not duplicated at top of D7 page. Unmatched and unverified rules remain gray audit.
- Preserve other modules, matching policy, result -> source rule/actual match -> remedy flow. All D7 remedies continue to require source-backed remidi.pdf references.

## Limitations
- Child birth, adoption, twins, karmic origin and body shape are traditional astrological interpretations, not fact-based diagnoses.
- The full body/nature 84-row transcription and Kaka-vandhya exact yogas remain audit-only; no invented results.
- Flutter SDK unavailable locally. ZIP integrity/static assertions passed; APK build must be validated in GitHub Actions.
