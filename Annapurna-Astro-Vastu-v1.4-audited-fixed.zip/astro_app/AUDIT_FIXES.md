# Annapurna Astro Vastu — Audit & Fix Summary

## Source audited

The repair started from the supplied `Annapurna-current.zip`.

## Problems found in the supplied ZIP

1. `AndroidManifest.xml` did not include the main-app INTERNET permission even though village search uses HTTPS.
2. Latitude and longitude were read-only and there was no reliable persistent "New Place" workflow.
3. Birth time only kept hours/minutes; seconds were not available.
4. Timezone offset was not represented, so UTC conversion for ephemeris calculations was incomplete.
5. `chart_screen.dart` only displayed entered values; it did not calculate planets or Lagna.
6. The README described Swiss Ephemeris/Jaimini modules that were not actually present in the supplied archive.
7. The widget test still expected Flutter's default counter app.
8. The archive contained machine-specific Gradle/cache/local-SDK files and backup Dart files.

## Fixes carried forward from v1.2

- Added Android INTERNET permission.
- Reworked village/place search with timeout, India fallback query, duplicate filtering and clearer errors.
- Added manual New Place entry with editable latitude/longitude.
- Added seconds, timezone and ayanamsa inputs.
- Added Swiss Ephemeris calculation through `sweph` in sidereal + Moshier mode.
- Added Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu and Ketu positions.
- Added sidereal Lagna / Ascendant calculation.
- Added Rasi display and readable calculation report.
- Added Event Timing Start/End window with exact duration and boundary calculations.
- Added local report Save, Saved Reports, Copy and Share.
- Replaced default `com.example` app identifiers with `com.annapurna.astrovastu.consultancy`.
- Added a GitHub Actions APK build workflow for Flutter 3.47.5 / Dart 3.13.4.
- Cleaned machine-specific cache/local files and obsolete backups from the distributable ZIP.

## v1.3 fixes

- **New Place now persists locally** instead of being only a temporary form entry.
- Added **Saved Places** picker on Birth Details.
- Added delete support for saved custom places.
- Added place search directly inside Event Timing.
- Added Saved Places picker inside Event Timing.
- Pinned direct package versions in `pubspec.yaml` for a more reproducible build.
- Added UTC conversion unit test.
- Added Saved Places persistence/deduplication test.
- GitHub Actions now runs `flutter test` before building the APK.
- App version bumped to **1.3.0+4**.

## Source-rule boundary

The supplied ZIP does **not** contain a verified event-rule database for Jaimini / Parashara / S.K. Mehta / KP timing. Therefore favorable percentages are intentionally not fabricated. The app calculates astronomical data and exact timing boundaries; rule-derived percentages should only be activated after the verified rule modules are added.

## Build validation status

The project has been statically audited and its third-party API usage checked against the current package APIs. The local execution environment used for this repair does not contain the Flutter SDK, so a local `flutter build apk` was not run here. The included GitHub Actions workflow performs dependency resolution, analysis, tests and release APK build when the repository connection/service is available.

## v1.4 audit fixes

- Removed Swiss Ephemeris initialization from the app-start critical path. The UI opens first and calculation initializes Sweph only when required.
- Added an initialization guard to avoid duplicate concurrent `Sweph.init()` calls.
- Fixed zodiac DMS formatting at sign boundaries (for example values rounding from 29°59′59.5″ to the next sign).
- Added canonical `UTC±HH:MM` timezone formatting.
- Added Event Timing **New Place** workflow, using the same persistent Saved Places store.
- Added Event Timing report Copy / Save / Share actions.
- Added unit tests for longitude-boundary formatting and fractional timezone offsets.
- App version bumped to **1.4.0+5**.
