# Build70 — D10 Final Profession Master Engine

Version: `1.4.70+70`

## Added
- User-final D10 profession formula as an independent master engine:
  - D10 10th-lord planet professions
  - D10 10th-lord D10-nakshatra professions
  - D10 10th-lord D10-sign professions
  - planets conjoined the D10 10th lord
  - profession-family merge
  - independent evidence coverage % (not probability)
- User-locked profession nature classification:
  - Technical: Aries, Scorpio, Capricorn, Aquarius
  - Semi-Technical: Gemini, Leo, Virgo
  - Non-Technical: Taurus, Cancer, Libra, Sagittarius, Pisces
- 27 Nakshatra profession support registry (source-derived from uploaded Dr. Arjun Pai handbook).
- Dashamsha Amsha Devata kept as modifier/support, not a stand-alone profession creator.
- Exact D10 longitude helper so the 10th lord's D10 nakshatra can be determined reproducibly.
- BPHS Shayanadi pure calculation engine:
  - `T=(S×P×N)+J+G+L -> mod 12`
  - optional Drishti/Cheshta/Vicheshta sub-state with Name Anka.
  - calculator never guesses missing Birth Ghati or Name Anka.
- D10 UI adds three FINAL audit cards before the older detailed D10 rule set:
  - Career Suitability
  - Nature + Amsha Devata
  - Graha Strength / Result Quality architecture

## Important boundaries
- Technical/Semi/Non-Technical is a filter/mode and is not counted again as a percentage source.
- Amsha Devata is a modifier unless an explicit source rule maps it to a profession.
- BPHS Avastha and Brihat Jataka quality remain separate from Career Suitability %.
- Existing exact profession source-gate rules remain intact for audit/confirmation.
