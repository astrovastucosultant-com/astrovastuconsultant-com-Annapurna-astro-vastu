# Build 25 — Ashtakavarga Decision Engine Upgrade

## Added

- Swiss Ephemeris calendar-window mapper for the top 3 BAV/SAV transit support indices.
- Per-planet `Calendar windows` action with year navigation, ingress/egress date-time, BAV/SAV and entry Kakshya.
- Event Evidence cards that automatically combine:
  - relevant SAV house strength,
  - Vimshottari + Tribhagi MD/AD/PD relevance,
  - current transit BAV/SAV.
- Event cards for career, education, wealth, property, siblings, marriage and children.
- Life Mirror summary for Dhana, Education, Career, Upachaya, Kendra, Kona and group comparisons.
- Prastara “Why this score?” drill-down showing which reference planets/Lagna contribute each bindu.
- Single-planet Swiss Ephemeris transit calculation API to avoid recalculating the full natal chart during year-window scans.

## Source discipline

- AV-007 and AV-022/023 are used for cross-evidence; bindus are not converted directly into a classical probability percentage.
- Calendar windows only map existing source support indices to real ephemeris dates; they do not create a new predictive rule.
- AV-008/009 Event-Year arithmetic remains source-pending because the currently supplied rule summary identifies the method but does not contain a complete worked algorithm. No guessed age/year is emitted.

## Version

- 2.11.0+25
