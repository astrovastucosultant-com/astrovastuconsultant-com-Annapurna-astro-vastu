# Build 29 — Consultation timing confluence

Version: 2.15.0+29

## Added
- On-demand **దశ + గోచారం ఎప్పుడు కలుస్తాయి?** finder inside every Client Consultation event card.
- Exact overlap windows between:
  - Vimshottari MD/AD/PD relevance,
  - S.K. Mehta Tribhagi MD/AD/PD relevance,
  - Swiss-Ephemeris transit through favorable BAV/SAV signs,
  - Kakshya-at-entry context.
- Strong Confluence when both Vimshottari and Tribhagi support the same favorable AV transit interval; Supportive Window when one dasha system supports it.
- Ready client sentence with actual start/end dates.
- Jaimini event-rule confirmation counts and Rule IDs shown as a separate evidence layer.

## Deliberate source boundary
Jaimini Chara Dasha calendar dates are **not** merged into the final overlap yet. The supplied Jaimini source confirms the framework (odd/even direction, special direction cases, lord-distance duration, own-sign/exaltation/debilitation/co-lord rules, Antardasha sequence), but several special-case arithmetic details are still recorded as “source defined” rather than fully explicit. Build 29 therefore uses Jaimini source-rule hits as independent confirmation and does not fabricate Chara-Dasha dates.

## Safety / interpretation
- Windows are comparative astrological support windows, not event guarantees or probability percentages.
- If no overlap is found in the next 12 months, the app says so without interpreting that as denial of the event.
- Rasi numbers are not displayed in the client-facing timing result.
