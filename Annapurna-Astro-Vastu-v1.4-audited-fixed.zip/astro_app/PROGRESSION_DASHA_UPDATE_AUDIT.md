# Progression + Dasha: source-audited update
Reference: user-provided Jataka_Samaya_Nirdharana.pdf (7 pages).
Pages 1-2: retrospective events and alternate birth times (15:21 / 16:00).
Pages 3-5: Vimshottari maha/antar periods.
Pages 5-6: progressed contacts compared with running dasha.
Pages 6-7: stated methodological limitations.
Implemented: per-contact drilldown Result → rule reference → dasha review → remedy status.
NOT implemented: BTR scoring, automatic D1/D9/D10 qualification, Naibod validation,
full event predictions, medical or mortality prediction.
No source-based assertion of prediction accuracy.
