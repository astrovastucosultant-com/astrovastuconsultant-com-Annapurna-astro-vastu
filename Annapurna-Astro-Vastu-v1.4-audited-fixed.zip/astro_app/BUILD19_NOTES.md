# Build 19 — Jaimini Topic Result Engine

- Source base: supplied Jaimini master study book/rules only.
- Adds applicable Jaimini combinations/yogas before the chart.
- Each result shows topic + combination + result.
- Favorable = green check; adverse = red cancel; descriptive = neutral info.
- Tapping the result opens: Result, Jataka analysis, Remedy, Rule ID/Source.
- No fabricated remedies: when the supplied Jaimini source has no remedy, the app explicitly says so.
- Added source-verifiable rules across Karakamsa, education/profession, property, dharma, Arudha wealth/loss, marriage/Upapada, Rajayoga, children and siblings.
- Sensitive health/children statements are labeled as source indications, not certainty.
- Death/self-harm and degrading appearance predictions are intentionally not automated.
- Existing P1–P12, Chara Karakas, Rashi Drishti and Argala display retained.
- Version 2.5.0+19.
