# Build 18 — Jaimini Pada Chart

- Added source-verified P1–P12 Arudha/Pada arithmetic.
- For each house: count inclusively from source sign to its lord, then count the same inclusive distance from the lord.
- Verified examples: source Aries + lord Cancer (4th) -> Libra; same-sign lord -> same sign; 7th lord -> original sign.
- Added South Indian Jaimini chart showing planet degree, Chara Karaka code, and P1–P12 placements.
- Added P1–P12 calculation trace under the chart for auditability.
- Rasi names remain hidden; sign numbers only.
- Existing D1/D-varga, Ashtakavarga, Dasha, KP, systems menu, branding and signing are preserved.
