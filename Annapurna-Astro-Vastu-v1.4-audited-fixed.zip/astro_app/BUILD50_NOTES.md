# Build 50 — D10 Exact Profession Registry

Version: 2.35.0+50

- Integrated all 181 rows from `vrutti-graha-devata.pdf` into a dedicated D10 profession registry.
- Exact-name gate: natal 10th-house profession planet + D10 Lagna/10H/10L confirmation + 10th Dashamsha Devata.
- D1+D10 both = confirmed; one layer = half-support; no exact name is invented when the source gate fails.
- Explicit Saturn Gocharastha/Agocharastha row conditions are checked against D10 Saturn mode.
- Added source-mode presentation: Owner/Self-employed vs Authority vs Job/Service.
- Corrected Saturn state logic so 6/8/12 relation does not create an artificial ADMIN state; authority is a separate Sun/Indra layer.
- Added individual profession rule cards so Result → Rule → Source works for the top source-matched occupations.
- Broad profession-group ranking remains as fallback when no strict exact source name is confirmed.
- Special `Sun Deity` / `Venus Deity` rows remain source-only until a dedicated evaluator is available; they are not silently remapped.
