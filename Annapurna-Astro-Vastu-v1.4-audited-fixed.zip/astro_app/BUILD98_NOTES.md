# Build98 — D7 Saptamsha Full Rule Engine

- Source basis: user-supplied `Saptamsha_Santana_Niyamalu.pdf` (29 scanned pages).
- Main client screen shows only actually matched D7 rules.
- Every matched D7 card is rendered green as requested.
- Result tap -> full Result -> Rule/Actual Match/Source -> Rule tap -> Remedy.
- Remedy layer uses existing `RemedyRuleService` sourced to user-supplied `remidi.pdf`; no invented gemstone prescription.
- Added D7 source/audit catalog for exact-arithmetic and sensitive rows: Beeja/Kshetra Sphuta, count/order, planet-amsha tables, gender-specific rows, deterministic denial/longevity, BAV.
- Added current/future child-birth candidate windows with age + MD/AD; past windows stay audit-only.
- Added D4/D7 auto-expand/no-ellipsis cards.
- Version 1.4.98+98.
