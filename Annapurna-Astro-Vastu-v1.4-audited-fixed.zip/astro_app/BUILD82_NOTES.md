# Build82 — Health Master Flow + Khara Risk + Remedies

- D1 = primary afflicted sign/planet and organ promise.
- D3/Drekkana = body-part refinement and first 5° Internal / second 5° External.
- D1 + D3 = organ/disease evidence list with astrology evidence %.
- D27 = severity/strength confirmation using 6/8 relation, malefic conjunction and Papakartari support.
- 22nd Drekkana lord = Khara support layer.
- 64th Navamsa lord from Moon = adverse-health support layer.
- Khara layers are confirmation/risk modifiers, never standalone medical diagnosis.
- Chapter 9 source-backed planet remedies and MD–AD pair remedies now display in D27.
- Permanent safety wording: medical treatment is necessary; puja/mantra/dana/devata worship are supportive only.
- Existing Gender, Panchadha Maitri, Bhamsa Devata, body visual and age/timing evidence are preserved.
