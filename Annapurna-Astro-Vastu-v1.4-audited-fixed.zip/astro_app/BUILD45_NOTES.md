# Build 45 — BNN Full Source Integration

Source basis: `Brighu_Naadi_Purnna_Rulebook.pdf` (21 pages, user supplied).

## Added
- BNN is now an active system tab instead of a placeholder.
- Jupiter-sign reference frame: Jupiter sign is treated as BNN house 1, separate from natal Ascendant house numbering.
- 343 indexed source rules linked by original source IDs:
  - R-A01–R-A15
  - C01–C65
  - E01–E74
  - F01–F28
  - G01–G38
  - H01–H41
  - I01–I42
  - J01–J26
  - K01–K14
- Rule ID → source page audit flow.
- Source page viewer for the supplied rulebook (sensitive health/safety pages are not rendered as personal predictions).
- Planet-by-planet house mapping from Jupiter with trine/kendra/trika/middle classification.
- Source-linked non-sensitive age tables for career/change, marriage, financial growth, name/fame, and relocation.
- Jupiter-sign-lord life-turning-point table when the source row is non-sensitive.
- Application-order panel from the supplied BNN source.
- Added unit tests for the BNN registry and Jupiter-reference calculation.

## Source guardrail
Rules whose exact source condition is not safely machine-readable are indexed and linked to the original source page but are not auto-fired. No missing condition is guessed.
