# Build 52 — D10 Profession Layer Separation

Version: 2.37.0+52

- Separates D10 profession presentation into Mode → Exact Profession → Supporting Dashamsha Devata.
- Exact profession rows now require all machine-readable source conditions (house/conjunction/Saturn mode) to match before Confirmed/Supported.
- Ishana Devata no longer implies Astrologer by itself; exact Jyotisha requires the source row Ketu + Ishana + Jupiter + 8/9/12.
- Lagna Devata is treated as desire/inclination only and removed from profession ranking.
- Daily-wage/manual worker is Confirmed only through D10-PRO-178 (Saturn + Agni + 6H); broad percentage no longer promotes it to an exact profession.
- Broad career fields exclude mode labels and exact worker/consultant titles.
- Existing Build 51 foundation results and all earlier D10 timing/career modules remain.
