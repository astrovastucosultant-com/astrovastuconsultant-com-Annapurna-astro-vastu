# Build 86 — D2 Dhana & Asthi Source Rule Browser

- Added user-supplied `Dhana_Aasthi_Rules.pdf` transcription as a 58-rule D2 source registry.
- Preserved all Build85 Health/Problem→Rule→Remedy behavior; nothing removed.
- D2 rule browser now exposes 10 groups: wealth level, Indu Lagna, D1 wealth yogas, Manduka Hora gains, cash/storage, gold/silver/jewellery, property/house/land, inheritance, vehicles, and other wealth/property indicators.
- Rules remain source-only unless exact chart-specific arithmetic is implemented. No fabricated percentages or precise wealth claims.
- Added Indu Lagna kala values and algorithm caveat; Rahu/Ketu have no kala values in this supplied source.
- Remedy behavior: the source has no individual remedies, so the app explicitly says so instead of inventing one.
- Version: 1.4.86+86.
