# Build 12 – South Indian Chart + Contrast Fix

- Replaced the previous table/placeholder rendering with explicit-position South Indian fixed-sign chart cells.
- D1, all varga charts, SAV and BAV use the same chart component.
- Added Rasi number + name, Lagna marker and planet text inside each sign.
- Removed Build 9 / Build 11 testing labels from the UI.
- Improved tab contrast and white card/input surfaces.
- Retained Build 11 applicationId and signing keystore so Build 12 updates Build 11 in place.
- Version 1.9.0+12.
