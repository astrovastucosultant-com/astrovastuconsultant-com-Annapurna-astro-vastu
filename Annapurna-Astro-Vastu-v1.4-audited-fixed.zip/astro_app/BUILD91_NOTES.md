# Build91 — Varga Completion Pass

- D7: child promise evidence + candidate childbirth year windows using Vimshottari MD/AD, D1 2/5/11 and D7 confirmation.
- D12: mother/maternal and father/paternal evidence cards.
- D16: vehicle opportunity evidence %, D1 4H/Venus + D16 + 5th from Venus, plus caution evidence.
- D20: Ishta/Upasana framework + clearly labeled modern Mahavidya correspondence and current 5L/9L deity guidance.
- D30: Lagna + 6/8/12 affliction evidence layer.
- Existing D2/D4/D9/D10/D24/D27/D40/D45/D60 rules preserved.
- Percentages are evidence coverage, never probability or guarantee.
- Formal Tantric Mahavidya sadhana is not prescribed; only simple devotional support is shown, with guru guidance required for initiation-based practice.
