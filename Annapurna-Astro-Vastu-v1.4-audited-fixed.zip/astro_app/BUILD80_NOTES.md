# Build80 — D27 Locate Disease Full-Body Visual Guide

Version: 1.4.80+80

## User-approved update
- Preserved Build79 D27 Health/Gender/Evidence% rules and calculations.
- Added a large, clear full-body Locate Disease infographic inside the D27 Health summary.
- Tapping the infographic opens a zoomable InteractiveViewer so body parts can be inspected clearly on mobile/tablet.
- The visual guide is illustrative only; actual D27 result still comes only from the source-backed D27/D3 rule engine.
- Existing body-region result image, Internal/External, Panchadha Maitri, Bhamsa Devata, age/timing %, and remedy boundary are unchanged.

## Safety/source boundary
The visual guide must not be treated as a medical diagnosis. Source-backed D27/D3 calculations remain authoritative for the app's astrology output, and medical symptoms require qualified clinical care.
