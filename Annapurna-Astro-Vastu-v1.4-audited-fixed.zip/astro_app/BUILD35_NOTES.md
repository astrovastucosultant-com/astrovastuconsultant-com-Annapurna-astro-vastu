# Build 35 — Marriage Material Rule Registry

- Added all 68 distinct rule/table entries from the supplied `marriage my meterial.pdf` to the app rule registry.
- Mapped source entries to D1 / D7 / D9 / D30 according to chart labels visible in the supplied source.
- Printed matching tables that require bride + groom charts are marked as two-chart rules and never fire from a single chart.
- Handwritten formulas are source-linked by exact page/rule ID. The app does not guess unreadable arithmetic or exceptions; only machine-validated conditions may become applied results.
- D9 result view shows a compact status card confirming that the marriage-material registry is loaded, while unmatched individual source rows stay hidden.
- Existing Result → Rule → Remedy flow is unchanged.
- Version: 2.21.0+35.
