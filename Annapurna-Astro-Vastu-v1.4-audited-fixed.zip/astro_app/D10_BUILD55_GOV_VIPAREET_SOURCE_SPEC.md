# D10 Build55 — Government Service + Vipareet Raja Yoga Source Spec

## Government Service (gov job.pdf)

### D10-GOV-01
Birth-chart 5th lord obtains a Navamsha sign that is the 5th or 9th sign from the birth ascendant -> Government-service promise.

### D10-GOV-02
Birth-chart 9th lord obtains a Navamsha sign that is the 5th or 9th sign from the birth ascendant -> Government-service / Government-support promise.

### D10-GOV-03
The source explicitly says the above is not the final decider and Dashamsha should be referred to. The app therefore cross-checks the promise with existing source-backed D10 authority evidence (Sun, 10H/10L, Indra) but labels it supporting confirmation rather than a new classical formula.

### D10-GOV-04
Presentation layer distinguishes direct Government/service form from Government-linked consultant/advisor/contractor form, because the source itself allows Government livelihood without direct employment.

## Vipareet Raja Yoga (vipareet raja yoga.pdf)

### D10-VRY-01 Harsha
6L in 8H/12H is the structural Harsha-type placement. Phaladeepika malefic relation is shown separately; benefic relation makes the result mixed/qualified.

### D10-VRY-02 Sarala
8L in 6H/12H is the structural Sarala-type placement. Relation rules are handled as above.

### D10-VRY-03 Vimala
12L in 6H/8H is the structural Vimala-type placement. Relation rules are handled as above.

### D10-VRY-04 Super Strong Vipareet
Source conditions used in the audit:
1. 3L/6L/8L/12L lies in another 3/6/8/12 house as listed by the source.
2. The placement is also 6/8/12 from its source house.
3. Placement sign is enemy or debilitation.
4. Relation is only malefic.

The supplied pages do not provide a friendship table, so the app does not silently import enemy-sign rules from outside. Full auto-confirmation is limited to the explicit debilitation branch; enemy-sign remains source-only/manual.

### D10-VRY-05 Career effect
The source states that a divisional chart indicates a specific life area and SSVY promotes that chart's significations, generally after problems/adversity. D10 therefore presents this as a career/status supportive layer, not as a guaranteed outcome. Dasha timing is to be cross-checked separately.
