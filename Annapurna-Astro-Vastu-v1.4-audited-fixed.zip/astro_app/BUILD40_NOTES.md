# Build 40

- Completed source-controlled Jaimini Chara Dasha engine CD-01–CD-07.
- Added Method A (ordinary odd/even), Method B (supplied Vishama/Sama + special-direction variant), and Custom controls.
- Added configurable Scorpio Mars/Ketu and Aquarius Saturn/Rahu co-lord handling.
- Added sign-to-lord Dasa-year calculation, configurable own-sign duration (default 12), +1 exaltation and -1 debilitation adjustment.
- Added actual Chara Mahadasha + 12 Antardasha calendar dates.
- Added event analysis for Marriage, Career, Children, Property, Wealth, Education, and Foreign travel/residence.
- Added 100-point app decision-support score: MD sign 20, AD 15, relevant Karaka 15, Arudha/UL 15, Rashi Drishti 10, sign-lord strength 10, Varga confirmation 10, repeated confirmation 5.
- Score bands: 0–29 Weak, 30–49 Possible, 50–69 Moderate, 70–84 Strong, 85–100 Very Strong.
- Added Rule ID → Input condition → Matched/Not Matched → Score → Reason → Source audit trail.
- Result tap opens full score/rule audit; rule tap opens condition/reason/source/remedy note.
- Consultation Timing now requires Jaimini Chara MD/AD overlap plus Vimshottari/Tribhagi and favorable Transit BAV/SAV.
- Source guardrail preserved: unresolved co-lord strength ties do not use invented hidden coefficients; manual override remains available.
- Jaimini remedies remain source-only; no invented remedy is added when the supplied source has none.
