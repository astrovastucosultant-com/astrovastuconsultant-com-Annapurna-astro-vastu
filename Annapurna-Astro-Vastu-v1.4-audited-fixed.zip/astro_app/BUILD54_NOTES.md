# Build 54 — Saved Charts + Birth-Time Rectification

- Save / Update Chart uses a stable saved-chart ID.
- Save as New creates a separate saved record.
- Saved Charts supports name / date / place search.
- Saved charts reopen with their saved ID so edits update the same record.
- Birth Time can be edited from any open chart.
- Original birth time is preserved separately from the active/rectified time.
- Apply & Recalculate rebuilds D1, Bhava, Vargas, Dashas and all dependent modules with the active time.
- Use Original & Recalculate restores the original birth time.
- Old saved-chart JSON without originalLocalDateTime remains readable.
