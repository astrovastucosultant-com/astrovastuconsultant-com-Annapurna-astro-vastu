# Build94 — D20 UI Polish

- D20 first card renamed to Summary and de-duplicated.
- Second D20 card renamed Why this deity? and focused on actual 5L/9L/Lagna reasoning.
- D20 result tap now shows Rule ID, actual match, source status and simple devotional guidance inline.
- Mahavidya later-tradition / non-BPHS status remains visible.
- Existing modules/rules preserved.
- Version 1.4.94+94.
