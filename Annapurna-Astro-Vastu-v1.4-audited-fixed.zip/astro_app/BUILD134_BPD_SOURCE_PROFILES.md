# Build 134 — BPD source profiles in Mehta BTR

Version: `1.4.134+134`

## The two schemes must stay separate

| Profile | Planets | Saturn full cycle | Rahu full cycle | Arudha exceptions |
|---|---:|---:|---:|---|
| Dr K.P. Vaani / Saptarishis | 7 | 30 years | not used | 10th-from-preliminary-pada Kendra adjustment |
| Nādi Praveshikā | 8 | 29 years | 93 years | none |

Other cycles: Sun 19, Moon 45, Mars 14, Mercury 46, Jupiter 83, Venus 27 years.

The source assigns a full first sign-period starting at birth. The code does not manufacture a degree-based balance. The program uses elapsed days / 365.2425 as an approximation of the texts' calendar years/months; inspect events near sign-period boundaries manually. Nādi Praveshikā subdivides Jupiter/Rahu long sign periods into 12 equal nominal antardashas. Rahu's backward zodiac progression is flagged for appendix verification.

## BTR integration

- Profile chosen on BTR screen and persisted separately from saved historical events.
- During candidate search, each source-profile run computes P1–P12, planet progressions, event-house/pada ties, and Nādi's 23 dictums if the Nādi profile was selected.
- Dictums requiring complete aspects, tropical/sidereal double charts, PAC, combustion, retrospective Vimshottari periods, precise nakshatra progression, retrograde at progression, or argala report **manual**, not matched.
- Positional tests marked MATCH/NOT_TRIGGERED are only flags for further interpretation, not predictions.
- BPD inputs are a **separate contextual family**. Do not count them as independent votes in seconds-level BTR candidate scores. The existing Mehta score and KP signature are unchanged.
- The source glossary is `assets/btr/bpd_nadi_praveshika_23.json` with immutable IDs `NP-BPD-01` through `NP-BPD-23`.

## Sources used

1. Dr K.P. Vaani, *Bhrigu Pada Dasa System — A Leaf of Bhrigu Maharishi*, Saptarishis Astrology vol 7, pp. 753–761: https://saptarishisastrology.com/wp-content/uploads/2023/01/SA-Vol-7-Part-8.pdf
2. *Nādi Praveshikā*, Bhrigu Pada Dasha chapter pp. 214–221 (web preview): https://www.scribd.com/document/979059916/Bhrigu-Pada-Dasha-Dictums-Charts
3. Publisher's listing of *Nādi Praveshikā*: https://academic.icasindia.org/BookStore/Detail/7

## Tests

`flutter test test/bpd_pada_dasa_service_test.dart`

`flutter test test/btr_second_sweep_test.dart`

`flutter build apk --release`

Above Flutter commands **have not been executed in this environment**. Static checks and ZIP CRC were run. A green GitHub APK build is necessary before claiming the Android package is compiled. Astrological BTR seconds are not scientifically validated.
