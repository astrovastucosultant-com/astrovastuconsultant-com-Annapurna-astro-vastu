# Build 46 — Hasta Samudrika Photo Workflow

Source basis: user-supplied `hasta సాముద్రికం.pdf` (68 pages).

## Added
- New top-level `హస్త సాముద్రికం` tab.
- Gallery browse/select workflow for up to 5 palm/hand photographs.
- Recommended photo roles:
  1. Right palm full photo
  2. Left palm full photo
  3. Fingers/nails close-up
  4. Thumb/side angle
  5. Special line/sign close-up
- Full-screen zoomable photo viewer.
- Per-photo role selector and remove/reset controls.
- Source-based guided evidence registry with:
  - Seven main hand-shape classes from supplied pages 31–37.
  - Line/mark visual vocabulary from supplied pages 18–21.
  - Thumb-angle evidence entries from supplied pages 63–64.
- Result → Rule → Evidence → Source-page bottom-sheet flow.
- Modular rule registry so later user-supplied palmistry rules can be appended without changing the photo workflow.

## Guardrail / implementation note
- This build does not pretend to perform automatic computer-vision palm-line recognition. Photos are displayed in-app and the consultant/user confirms the visible source feature before its rule fires.
- Entries whose supplied page only defines the visual mark (without a complete location-specific result) are stored as evidence-only and are not treated as final predictions.
- Palmistry output is labelled as a traditional interpretation, not medical, psychological, or scientific diagnosis.

## Version
- `2.31.0+46`
