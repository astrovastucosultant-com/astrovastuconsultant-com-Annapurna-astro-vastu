# Build 60 — Saved Chart Reopen UX

- Added explicit **Save Chart — Reopen Later** action in Jataka and Consultation report sections.
- Save Chart uses ChartStorageService and appears in **Saved Charts** for later Open / Edit.
- Renamed report-only save action to **Save Report** and clarified that it stores text under Reports.
- Preserved existing app-bar Save Chart and Save as New behavior.
- Version: 1.4.60+60.
