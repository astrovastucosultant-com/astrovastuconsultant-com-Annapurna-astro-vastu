# Build 9

- Visible B9 marker on home and chart screens.
- D1, all Shodashavarga charts, and Ashtakavarga use traditional South Indian fixed-sign 4x4 layout with merged centre.
- Version 1.7.0+9.
- Android launcher label: Annapurna Astro Vastu B9.
