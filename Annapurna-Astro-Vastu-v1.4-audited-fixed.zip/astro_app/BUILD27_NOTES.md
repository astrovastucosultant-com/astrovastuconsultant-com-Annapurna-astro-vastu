# Build 27 — Planet Tap Details + Hidden Rasi Numbers

## Added

- South Indian chart visual Rasi numbers are hidden; only the fixed chart layout and `Lg` marker remain.
- Planet labels inside D1, Varga and Jaimini charts are tappable.
- Planet list rows are tappable and show exact within-sign degree.
- Planet tap sheet now shows:
  - exact degree,
  - Nakshatra/Pada,
  - Star Lord,
  - Sub Lord,
  - D60/Shashtiamsa Amsa Devata,
  - effective D60 part and source nature,
  - Saptavargaja,
  - Shadvargaja,
  - Dashavargaja,
  - Shodashavargaja,
  - Vimshopaka Bala,
  - expandable detailed varga support and all four Vimsopaka scores.

## Calculation discipline

- Star/Sub Lord uses the app's existing KP unequal Vimshottari subdivision arithmetic.
- D60 Amsa Devata follows the supplied BPHS-based project rulebook: 0°30′ parts; odd signs forward, even signs reverse.
- Vargaja/Vimsopaka arithmetic follows the standard/JHora-compatible four varga schemes and 20-point weighting model. No probability percentage is generated.

## Version

- 2.13.0+27
