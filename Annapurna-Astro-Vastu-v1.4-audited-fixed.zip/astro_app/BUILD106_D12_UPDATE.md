# Annapurna Astro Vastu v1.4.106+106 — D12 Chapter 9

Based on user-supplied 51-page scanned D12.pdf: 49 analytical rule entries + 20 annotated source case references = 69.

- New D12 source-rule service and tests; source page index in docs/D12_BUILD106_SOURCE_COVERAGE.md.
- Parashari D12 houses, lords, conjunction and explicit aspects, Jaimini Karaka roles; only reproducible source conditions are flagged matched.
- Previously inaccurate D12 mother/father 33/67% evidence widgets removed; source audit and grouped page references added.
- Retained source's PK-vs-BK father-role difference rather than inventing a reconciliation.
- KL and Cyclical D12 calculations remain source-audit pending; old D1/D4/D7 etc untouched.
- Parents' longevity texts retained only in rule reference; no predicted personal death date.
- No invented automatic remedial measures for D12.
- Test: test/d12_build106_source_rules_test.dart (requires Flutter SDK).

Do not upload the 18MB scanned D12.pdf into the primary GitHub replacement zip; that would exceed its lightweight, mobile-uploadable design. Source references cite user-supplied file/page.
