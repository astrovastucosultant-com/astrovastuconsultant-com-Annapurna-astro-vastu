# Annapurna Astro Vastu — Swiss Ephemeris licensing notice

This project uses the `sweph` Flutter package, which bundles/binds Swiss Ephemeris.

For the open-source route, Swiss Ephemeris and `sweph` are distributed under GNU AGPL-3.0-only unless the distributor holds an applicable Swiss Ephemeris Professional License from Astrodienst AG.

Before distributing binaries, review the current licensing terms at:
- https://www.astro.com/swisseph/
- https://github.com/aloistr/swisseph
- https://pub.dev/packages/sweph

This file is informational and is not legal advice.
