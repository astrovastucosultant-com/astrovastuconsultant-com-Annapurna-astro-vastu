# Build104 — v1.4.104+104 (D7 partial source-table completion)

- Kept the existing v1.4 app, all earlier modules and matched Result -> Rule -> Source -> Remedy flow.
- Rechecked scanned Saptamsha_Santana_Niyamalu.pdf p.9–12.
- Corrected previous overly-generic Aries/Taurus body/nature descriptions to align better with their source table, avoiding false unrelated descriptions.
- Expanded D7 source-based body/nature interpretations to 42/84 sign-amsha rows (Aries–Virgo, all 7 segments). The other 42 stay unverified in Audit.
- Corrected per-row book page citations across page boundaries.
- Added Dart flutter_test cases covering all 42 supported sign+amsha combinations.
- These are traditional source interpretations, not scientific/medical diagnoses.

## Validation
- ZIP CRC and source structural validations run locally.
- Flutter SDK is not installed in this environment; no APK build or emulator test claimed.
- **GitHub must replace the exact filename `Annapurna-Astro-Vastu-v1.4-audited-fixed.zip` and run Actions to get the APK.**
