# Build 14 — Build 13 compile fix

- Fixes release compile error in `lib/astrology/kp_service.dart` where `_subLord()` referenced an out-of-scope `starLord` fallback.
- Keeps Build 13 systems work intact: Vimshottari, Jaimini core, KP stellar table, Jamakola/Tajik source-pending slots.
- Keeps Build 12 working D1/varga/ashtakavarga chart UI unchanged.
- Version: 2.0.1+14.
