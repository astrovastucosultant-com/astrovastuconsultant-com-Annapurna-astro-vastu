# Build 38 — Sensitive S.K. Mehta source analysis + Traditional Remedy

- Restored M10 Accident source-risk analysis, M15 father-related death-event source analysis, and M16 mother-related death-event source analysis in the S.K. Mehta tab.
- Sensitive entries are explicitly labelled source/risk analysis only; no certainty or personal death-date prediction is produced.
- M10 includes source fixed planets Rahu + Ketu plus the 4th-lord combination in synchronization evidence.
- Added a separate Traditional Remedy panel: Maha Mrityunjaya Japa / Homam. This is labelled as a traditional spiritual remedy, not an S.K. Mehta source rule, and no prevention guarantee is made.
- Accident-related screens also remind users to follow ordinary safety measures and seek needed medical help.
