# Build 20 — Full Dasha Engine

This build extends the working Build 19 base without changing D1–D60, Ashtakavarga, Jaimini P1–P12, KP, logo/banner or signing setup.

## Active dasha systems

1. **Tribhagi 80 — S.K. Mehta**
   - Corresponding Vimshottari duration × 2/3.
   - Birth balance calculated from Moon nakshatra remainder.
   - 5 levels: Mahadasha → Antardasha → Pratyantardasha → Sukshma → Prana.
   - Mehta timing emphasis is displayed on levels 2–5 rather than treating Mahadasha alone as the event trigger.
2. **Vimshottari 120**
   - Full birth balance and five nested levels.
3. **Khanda 40**
   - Corresponding Vimshottari duration × 1/3.
   - Full five nested levels.
4. **Yogini 36**
   - Mangala 1, Pingala 2, Dhanya 3, Bhramari 4, Bhadrika 5, Ulka 6, Siddha 7, Sankata 8.
   - Full five nested levels using proportional 36-year subdivisions.

## UI

- Dasha page opens on Tribhagi by default.
- Four system chips switch calculations instantly.
- Date picker can calculate the exact 5-level dasha path for a selected date.
- Each level shows start/end date-time and duration.
- Expandable tables show Mahadasha, AD, PD, Sukshma and Prana sequences for the selected path.
- Birth balance also shows a 360-day-year / 30-day-month reference Y-M-D value so the source-table convention is visible rather than silently mixed with civil-date mapping.

## Source guardrails

- S.K. Mehta Tribhagi timing logic uses only the supplied Mehta project sources.
- The supplied period-table workbook states Tribhagi = 2/3 of the corresponding Vimshottari duration and uses the same nested proportional division rule.
- The Mehta timing command table prioritizes levels 2–4, with deeper levels used for micro-synchronization; the app exposes 2–5 clearly.
- Jaimini Chara Dasha is **not** falsely marked as fully active here because the supplied Jaimini source contains tradition-specific direction/co-lord exceptions that must be resolved before enabling exact arithmetic.

Version: **2.6.0+20**
