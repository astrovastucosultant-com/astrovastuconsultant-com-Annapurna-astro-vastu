# Build 47 — D10 Career Dashboard

Version: 2.32.0+47

## Added to D10
- Profession shortlist from supplied D10 profession source layers.
- Job vs Business tendency and a separate source-only Job→Business / Business→Job sequence item.
- High position / management support.
- Saturn relation across D1/D9/D10 (same-sign association auto-check only).
- PP planets, five-planets concentration, 3rd house/lord, status, rise/fall, inter-relation, partnership.
- Foreign job, job-loss caution, transfer support.
- Promotion cross-reference to supplied KP rule.
- Requested Rajayoga, Mahabhagya, Career Graph, Retirement, Gocharista/Agocharista, Nakshatra professions and Dashamsha Devata professions are visible as source-only until exact supplied rules/tables are available.
- D10 screen shows all requested topics with favorable/caution/mixed/source-only presentation.
- Result sheet now has direct Rule and Remedy/Guidance buttons.

## Source boundary
No missing Nakshatra/Devata/Gocharista/Agocharista/retirement timing formula was invented.
