# Build 39

- Added full Shadvarga strength table (D1/D2/D3/D9/D12/D30) for all planets.
- Added 1–12 house Bhava strength table using the app's transparent SAV strength input, with rashi, lord, points, rank and app status.
- Strength tables are available in Gem Remedy and S.K. Mehta tabs.
- Preserved source guardrail: SAV-based house strength is not labeled as the full classical Bhava Bala component calculation.
