# Build137 — KP Tab, Western Aspects, Chart Rotation

App Version: `1.4.137+137`

## Implemented
- Visible `KP` main tab; 12 Placidus cusp longitudes with sign, star, sub and sub-sub lords from the existing KP service; four-level significator audit and event-specific cusp linkage.
- The existing KP system drawer entry opens the new KP detail instead of a stale planet-only placeholder.
- KP uses the currently selected natal ayanamsa. If it is not KP/Krishnamurti, the UI explicitly prompts the user to choose it and recalculate; no silent ayanamsa change.
- Separate `Western Aspects` main tab showing major geometric ecliptic aspects: 0, 60, 90, 120, 180 degrees, with per-aspect orb and user-controlled multiplier; optionally 30 and 150 degrees and lunar nodes. Angular distance is shortest separation 0–180 degrees.
- Each South Indian chart has independent 90-degree Rotate Left/Right and Reset controls. The view positions rotate; sign index, ascendant, planet longitude, chart calculation and label orientation do not change.
- KP, BPD, BNN, BCP and Western Aspects remain separate engines.

## Limitations / Verification
- Flutter SDK is unavailable in the authoring container: flutter analyze, flutter test and Android APK compile have **not** run. Dart unit tests were authored and need to run in CI.
- KP ruling planets, node representation, full dasha-based promise/denial are not claimed complete.
- Western angular geometry is not a traditional KP/BPD prediction or birth-second proof.
- Rotation is UI display rotation, not changing the natal chart reference lagna or actual planetary positions.
