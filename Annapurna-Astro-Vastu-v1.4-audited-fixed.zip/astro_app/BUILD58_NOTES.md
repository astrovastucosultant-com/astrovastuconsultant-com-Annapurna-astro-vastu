# Build 58 — Stable-base D24 Education Update

This update is deliberately based on the last known successful Build55 source used for the successful APK line.

Changes only:
- D24 Education rule registry added.
- D24 Education evaluation integrated into varga rule service.
- D24 UI shows the complete education rule engine and source-only items.
- User education sign classification retained:
  - Technical: Aries, Scorpio, Capricorn, Aquarius
  - Semi-technical: Gemini, Leo, Virgo
  - Non-technical: Taurus, Cancer, Libra, Sagittarius, Pisces
- Birth-time edit/recalculation path from the stable base is retained.
- D10 Government Service + Vipareet Raja Yoga, Save/Reopen and prior stable features are retained from the Build55 base.
- Android applicationId and signing configuration are unchanged from the stable base.
- App version: 1.4.58+58.

Repository workflow file is NOT included or changed by this source ZIP. Upload this ZIP using the same repository-root filename expected by the existing successful workflow:
`Annapurna-Astro-Vastu-v1.4-audited-fixed.zip`.
