# Build107 — v1.4.107 D12 rule-status/display update

Based exclusively on the user's `D12.pdf` (51 pages; Saral Jyotish Part VII, chapter 9). This patch builds on Build106 and preserves the rest of the Flutter project.

## Issues observed in Build89 screenshot

- `4 matched / 65 Source-Audit` conflated **unmatched tested rules** with **pending KL/Cyclical computations** and **20 biographical examples**. The 69-entry catalog is not 69 event predictions.
- All matched D12 cards were forced **green**, even when the matched book condition described an adverse/malefic influence (e.g. childhood house affliction).
- Result descriptions often read as generic interpretations, with actual matched planet/house details available only after tapping.
- Some partial conditions extracted from historical charts were auto-fired even though the example's full KL/source conditions had not been tested.

## Changes

1. Separate screen tallies: chart condition matched; condition tested but not matched; Source/KL-Cyclical/strength pending; and 20 example charts. Totals sum to 69.
2. Use rule tone (green favorable, pale red caution, neutral/source grey) instead of making every matched D12 result green.
3. Append actual matched D12 sign/house/aspect evidence to result card; tapping still shows rule, complete inspection, PDF page and non-invented remedy.
4. Historical case-only/partial KL rows `D12-CHILD-06/07`, `D12-REL-07/08/09`, `D12-CARE-07`, `D12-EST-05/06` remain readable but no longer auto-fire from incomplete subsets.
5. Restrict p.25 birth-lagna-lord affliction `D12-CARE-02` to GK/node association instead of arbitrary classical malefic company.
6. Keep all 69 IDs, 20 case references, 51-page source index, and original D12 book chapter headings.
7. Add deterministic Flutter test source `test/d12_build107_rule_status_test.dart`.

## Source handling / limitations

- *Saral Jyotish* D12 Chapter 9, uploaded PDF pp.2,9,18,25,34–35 and example charts pp.10–17,19–20,29,41.
- KL as lagna / Cyclical D12 mapping and subjective Raja/Dhana yoga strength must not be substituted by a different chart. Their source records remain available but cannot be fully auto-applied.
- Astrology interpretations are source-specific assertions, not medical, behavioral, or longevity proofs.
- `remidi.pdf` exact pairing not established for D12; never invent prescribed spiritual remedies.
- Archive integrity and code-based/static checks can be performed here. Flutter executable compilation and actual touch/Android device validation must still be run through GitHub Actions.
