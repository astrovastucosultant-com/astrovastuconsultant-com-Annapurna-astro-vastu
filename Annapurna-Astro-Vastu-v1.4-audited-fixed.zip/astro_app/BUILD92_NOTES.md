# Build92 — Varga Missing Results Fix

- D3 always shows an evidence-summary result instead of falling through to “no auto rule”.
- D4 adds consolidated property/house/land Evidence % summary.
- D7 childbirth timing now ranks Vimshottari MD/AD candidate windows and shows top candidate years even when none crosses the strong threshold; labels remain candidate/evidence only.
- D16 adds vehicle comfort/luxury and delay/trouble Evidence % cards in addition to vehicle-opportunity result.
- D20 adds an explicit “who to worship” Primary/Secondary devotional card and retains the full ten-Mahavidya correspondence, clearly labelled as later supportive tradition.
- Existing rules/modules preserved.
