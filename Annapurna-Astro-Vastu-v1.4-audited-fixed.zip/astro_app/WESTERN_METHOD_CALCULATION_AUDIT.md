Western method calculation audit — 2026-10-16
Implemented in isolated calculation screen:
Secondary (1 ephemeris day / life year)
Tertiary-I (1 ephemeris day / sidereal life month)
Minor (1 sidereal ephemeris month / life year)
Solar Arc (true secondary solar arc)
Naibod (mean arc, RAMC-directed angles)
One Degree (symbolic longitude direction)
Converse Secondary (backward 1 day/year)
Annual whole-sign Profection (completed birthdays)

NOT implemented: FULL PRIMARY DIRECTIONS. This requires mundane positions,
semi-arcs and documented key conventions. Not faked as 1-degree directions.
No event-rule qualification or validated BTR scoring added in this release.
Orb contacts are diagnostic only. No scientific predictive accuracy claim.
No Flutter SDK available in current container; compile/build not tested.
