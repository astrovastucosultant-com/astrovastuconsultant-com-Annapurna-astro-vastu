# Build 56 — D24 Education Rule Engine

Source: user-supplied `Education.pdf` (Astrology of Education, 72 uploaded pages).

Added to D24:
- Jaimini/Navamsha PK intelligence layer.
- AK-relative 2/4/5/8/9/12 education levels.
- D24 Lagna desire, Lagna-lord fulfilment, Sun dedication, Moon mental inclination.
- 2H sanskar, 4H schooling, 5H graduation, 9H higher studies, 8H research, 12H hostel/away.
- Rahu/Ketu interruption/end warnings by education level.
- 9H/12H foreign-study/hostel cross-check.
- Subject shortlist support from Mercury/Mars/Saturn/Jupiter/Sun/Moon/Venus.
- User-configured education sign classification kept separate from source method:
  Technical = Aries/Scorpio/Capricorn/Aquarius;
  Semi-technical = Gemini/Leo/Virgo;
  Non-technical = Taurus/Cancer/Libra/Sagittarius/Pisces.
- Source-only fifth-cusp nakshatra-lord method retained without inventing cusp arithmetic.
- Birth-time sensitivity note retained; D24 must recalculate after rectified birth time.

UI remains Result → Rule → Source/Guidance through the existing varga rule cards.
