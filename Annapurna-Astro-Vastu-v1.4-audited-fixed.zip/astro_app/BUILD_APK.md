# Build Android APK

This project is pinned for Flutter **3.47.5 / Dart 3.13.4**. App version: **1.4.0+5**.

## GitHub Actions (recommended)

1. Put this project in the repository root.
2. Open **Actions** in GitHub.
3. Select **Build Android APK**.
4. Choose **Run workflow**.
5. After the job finishes, open the run and download the artifact named **Annapurna-Astro-Vastu-APK**.

The artifact contains `app-release.apk`.

## Local build

```bash
flutter pub get
flutter analyze --no-fatal-infos
flutter test
flutter build apk --release
```

APK output:

`build/app/outputs/flutter-apk/app-release.apk`

## Notes

- The current release build uses the Flutter project's debug signing configuration, so it is suitable for direct personal testing/installing. Before publishing to an app store, configure a private release keystore.
- Swiss Ephemeris integration uses the `sweph` package and Moshier calculation mode for the displayed planetary positions.
