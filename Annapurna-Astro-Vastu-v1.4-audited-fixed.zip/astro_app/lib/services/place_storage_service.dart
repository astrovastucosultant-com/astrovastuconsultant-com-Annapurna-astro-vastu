import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import 'place_search_service.dart';

class PlaceStorageService {
  static const _key = 'annapurna_saved_places_v1';

  static Future<List<PlaceResult>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? const <String>[];
    final results = <PlaceResult>[];

    for (final item in raw) {
      try {
        final decoded = jsonDecode(item);
        if (decoded is! Map) continue;
        final name = decoded['name']?.toString().trim() ?? '';
        final lat = double.tryParse(decoded['lat']?.toString() ?? '');
        final lon = double.tryParse(decoded['lon']?.toString() ?? '');
        if (name.isEmpty || lat == null || lon == null) continue;
        if (lat < -90 || lat > 90 || lon < -180 || lon > 180) continue;
        results.add(
          PlaceResult(
            displayName: name,
            latitude: lat,
            longitude: lon,
          ),
        );
      } catch (_) {
        // Ignore damaged old entries rather than breaking the saved list.
      }
    }

    return _dedupe(results);
  }

  static Future<void> save(PlaceResult place) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await load();
    final merged = <PlaceResult>[place, ...current];
    final unique = _dedupe(merged).take(50).toList();

    await prefs.setStringList(
      _key,
      unique
          .map(
            (item) => jsonEncode({
              'name': item.displayName,
              'lat': item.latitude,
              'lon': item.longitude,
            }),
          )
          .toList(),
    );
  }

  static Future<void> delete(PlaceResult place) async {
    final prefs = await SharedPreferences.getInstance();
    final current = await load();
    current.removeWhere((item) => _sameCoordinates(item, place));
    await prefs.setStringList(
      _key,
      current
          .map(
            (item) => jsonEncode({
              'name': item.displayName,
              'lat': item.latitude,
              'lon': item.longitude,
            }),
          )
          .toList(),
    );
  }

  static List<PlaceResult> _dedupe(List<PlaceResult> input) {
    final seen = <String>{};
    final output = <PlaceResult>[];
    for (final item in input) {
      final key = _coordinateKey(item);
      if (seen.add(key)) output.add(item);
    }
    return output;
  }

  static bool _sameCoordinates(PlaceResult a, PlaceResult b) =>
      _coordinateKey(a) == _coordinateKey(b);

  static String _coordinateKey(PlaceResult place) =>
      '${place.latitude.toStringAsFixed(6)},${place.longitude.toStringAsFixed(6)}';
}
