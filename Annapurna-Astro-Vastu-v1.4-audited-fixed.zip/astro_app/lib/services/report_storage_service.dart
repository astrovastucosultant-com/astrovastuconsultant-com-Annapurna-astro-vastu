import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class SavedReport {
  final String id;
  final String title;
  final String body;
  final DateTime savedAt;

  const SavedReport({
    required this.id,
    required this.title,
    required this.body,
    required this.savedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'savedAt': savedAt.toIso8601String(),
      };

  factory SavedReport.fromJson(Map<String, dynamic> json) {
    return SavedReport(
      id: json['id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Saved report',
      body: json['body']?.toString() ?? '',
      savedAt: DateTime.tryParse(json['savedAt']?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}

class ReportStorageService {
  static const _key = 'annapurna_saved_reports_v1';

  static Future<List<SavedReport>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? const <String>[];
    final reports = <SavedReport>[];
    for (final item in raw) {
      try {
        final json = jsonDecode(item);
        if (json is Map<String, dynamic>) {
          reports.add(SavedReport.fromJson(json));
        } else if (json is Map) {
          reports.add(
            SavedReport.fromJson(
              json.map((key, value) => MapEntry(key.toString(), value)),
            ),
          );
        }
      } catch (_) {
        // Ignore a damaged old entry instead of breaking the saved list.
      }
    }
    reports.sort((a, b) => b.savedAt.compareTo(a.savedAt));
    return reports;
  }

  static Future<void> save({
    required String title,
    required String body,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final reports = await load();
    final now = DateTime.now();
    reports.insert(
      0,
      SavedReport(
        id: now.microsecondsSinceEpoch.toString(),
        title: title,
        body: body,
        savedAt: now,
      ),
    );

    final trimmed = reports.take(50).map((r) => jsonEncode(r.toJson())).toList();
    await prefs.setStringList(_key, trimmed);
  }

  static Future<void> delete(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final reports = await load();
    reports.removeWhere((r) => r.id == id);
    await prefs.setStringList(
      _key,
      reports.map((r) => jsonEncode(r.toJson())).toList(),
    );
  }
}
