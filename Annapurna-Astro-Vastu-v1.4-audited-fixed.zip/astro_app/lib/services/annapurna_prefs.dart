import 'package:shared_preferences/shared_preferences.dart';
import 'package:shared_preferences_android/shared_preferences_android.dart';

/// Async API avoids legacy getAll() which fails on mismatched Android Pigeon code.
/// Explicitly uses the original Android SharedPreferences file, so previously
/// saved charts and BTR events remain readable after upgrading the app.
class AnnapurnaPrefs {
  static const instance = AnnapurnaPrefs._();
  const AnnapurnaPrefs._();
  static final SharedPreferencesAsync _prefs = SharedPreferencesAsync(
    options: const SharedPreferencesAsyncAndroidOptions(
      backend: SharedPreferencesAndroidBackendLibrary.SharedPreferences,
      originalSharedPreferencesOptions: AndroidSharedPreferencesStoreOptions(
        fileName: 'FlutterSharedPreferences',
      ),
    ),
  );

  static Future<String?> getString(String key) => _prefs.getString(key);
  static Future<List<String>?> getStringList(String key) => _prefs.getStringList(key);
  static Future<bool> setString(String key, String value) async {
    await _prefs.setString(key, value);
    return true;
  }
  static Future<bool> setStringList(String key, List<String> value) async {
    await _prefs.setStringList(key, value);
    return true;
  }
  static Future<void> reload() async { /* Async reads are uncached. */ }
}
