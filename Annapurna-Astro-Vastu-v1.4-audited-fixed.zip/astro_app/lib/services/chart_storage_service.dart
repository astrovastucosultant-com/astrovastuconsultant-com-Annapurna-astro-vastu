import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/birth_data.dart';

class SavedChart {
  final String id;
  final BirthData birthData;
  final DateTime savedAt;

  const SavedChart({
    required this.id,
    required this.birthData,
    required this.savedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'birthData': birthData.toJson(),
        'savedAt': savedAt.toIso8601String(),
      };

  factory SavedChart.fromJson(Map<String, dynamic> json) {
    final rawBirth = json['birthData'];
    final birth = rawBirth is Map<String, dynamic>
        ? rawBirth
        : rawBirth is Map
            ? rawBirth.map((k, v) => MapEntry(k.toString(), v))
            : <String, dynamic>{};
    return SavedChart(
      id: json['id']?.toString() ?? '',
      birthData: BirthData.fromJson(birth),
      savedAt: DateTime.tryParse(json['savedAt']?.toString() ?? '') ??
          DateTime.fromMillisecondsSinceEpoch(0),
    );
  }
}

class ChartStorageService {
  static const _key = 'annapurna_saved_charts_v1';

  static String _stableId(BirthData b) => [
        b.name.trim().toLowerCase(),
        b.localDateTime.toIso8601String(),
        b.latitude.toStringAsFixed(6),
        b.longitude.toStringAsFixed(6),
        b.ayanamsa.name,
      ].join('|');

  static Future<List<SavedChart>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList(_key) ?? const <String>[];
    final charts = <SavedChart>[];
    for (final item in raw) {
      try {
        final decoded = jsonDecode(item);
        if (decoded is Map<String, dynamic>) {
          charts.add(SavedChart.fromJson(decoded));
        } else if (decoded is Map) {
          charts.add(
            SavedChart.fromJson(
              decoded.map((k, v) => MapEntry(k.toString(), v)),
            ),
          );
        }
      } catch (_) {
        // Keep one damaged old entry from breaking all saved charts.
      }
    }
    charts.sort((a, b) => b.savedAt.compareTo(a.savedAt));
    return charts;
  }

  /// Saves or refreshes an existing chart with the same birth inputs.
  static Future<void> save(BirthData birthData) async {
    final prefs = await SharedPreferences.getInstance();
    final charts = await load();
    final id = _stableId(birthData);
    charts.removeWhere((item) => item.id == id);
    charts.insert(
      0,
      SavedChart(
        id: id,
        birthData: birthData,
        savedAt: DateTime.now(),
      ),
    );
    await prefs.setStringList(
      _key,
      charts.take(100).map((item) => jsonEncode(item.toJson())).toList(),
    );
  }

  static Future<void> delete(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final charts = await load();
    charts.removeWhere((item) => item.id == id);
    await prefs.setStringList(
      _key,
      charts.map((item) => jsonEncode(item.toJson())).toList(),
    );
  }
}
