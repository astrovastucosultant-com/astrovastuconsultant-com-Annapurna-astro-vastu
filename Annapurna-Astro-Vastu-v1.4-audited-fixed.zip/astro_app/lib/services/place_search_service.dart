import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

class PlaceResult {
  final String displayName;
  final double latitude;
  final double longitude;

  const PlaceResult({
    required this.displayName,
    required this.latitude,
    required this.longitude,
  });
}

class PlaceSearchException implements Exception {
  final String message;
  const PlaceSearchException(this.message);

  @override
  String toString() => message;
}

class PlaceSearchService {
  static const _host = 'nominatim.openstreetmap.org';

  static Future<List<PlaceResult>> search(String query) async {
    final text = query.trim();
    if (text.length < 2) return [];

    try {
      var results = await _request(text);
      if (results.isEmpty && !text.toLowerCase().contains('india')) {
        results = await _request('$text, India');
      }
      return _dedupe(results);
    } on TimeoutException {
      throw const PlaceSearchException(
        'Place search timeout. Internet connection చెక్ చేసి మళ్లీ ప్రయత్నించండి.',
      );
    } on PlaceSearchException {
      rethrow;
    } catch (e) {
      throw PlaceSearchException('Place search error: $e');
    }
  }

  static Future<List<PlaceResult>> _request(String query) async {
    final uri = Uri.https(_host, '/search', {
      'q': query,
      'format': 'jsonv2',
      'limit': '10',
      'addressdetails': '1',
      'countrycodes': 'in',
    });

    final response = await http.get(
      uri,
      headers: const {
        'User-Agent': 'AnnapurnaAstroVastu/1.1 (personal-use astrology app)',
        'Accept-Language': 'te,en-IN,en',
        'Accept': 'application/json',
      },
    ).timeout(const Duration(seconds: 12));

    if (response.statusCode != 200) {
      throw PlaceSearchException(
        'Place search server error (${response.statusCode}).',
      );
    }

    final decoded = jsonDecode(response.body);
    if (decoded is! List) return [];

    final results = <PlaceResult>[];
    for (final item in decoded) {
      if (item is! Map) continue;
      final lat = double.tryParse(item['lat']?.toString() ?? '');
      final lon = double.tryParse(item['lon']?.toString() ?? '');
      if (lat == null || lon == null) continue;
      results.add(
        PlaceResult(
          displayName: item['display_name']?.toString() ?? query,
          latitude: lat,
          longitude: lon,
        ),
      );
    }
    return results;
  }

  static List<PlaceResult> _dedupe(List<PlaceResult> input) {
    final seen = <String>{};
    final output = <PlaceResult>[];
    for (final item in input) {
      final key = '${item.latitude.toStringAsFixed(5)},${item.longitude.toStringAsFixed(5)}';
      if (seen.add(key)) output.add(item);
    }
    return output;
  }
}
