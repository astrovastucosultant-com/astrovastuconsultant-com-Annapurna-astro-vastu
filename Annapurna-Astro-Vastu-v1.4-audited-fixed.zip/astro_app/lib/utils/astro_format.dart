class AstroFormat {
  static const List<String> signNamesTe = [
    'మేష',
    'వృషభ',
    'మిథున',
    'కర్కాటక',
    'సింహ',
    'కన్య',
    'తుల',
    'వృశ్చిక',
    'ధనుస్సు',
    'మకర',
    'కుంభ',
    'మీన',
  ];

  static String two(int value) => value.toString().padLeft(2, '0');

  static String dateTime(DateTime dt) {
    return '${two(dt.day)}-${two(dt.month)}-${dt.year}  '
        '${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
  }

  /// Formats a zodiac longitude with correct carry across 29°59'59.5".
  static String longitudeDms(double longitude) {
    final normalized = ((longitude % 360.0) + 360.0) % 360.0;
    final totalArcSeconds = (normalized * 3600.0).round() % (360 * 3600);
    final sign = totalArcSeconds ~/ (30 * 3600);
    final withinSign = totalArcSeconds % (30 * 3600);
    final degree = withinSign ~/ 3600;
    final minute = (withinSign % 3600) ~/ 60;
    final second = withinSign % 60;

    return '${signNamesTe[sign]}  '
        '${two(degree)}° ${two(minute)}′ ${two(second)}″';
  }


  /// Formats a degree value within one sign without printing the Rasi name/number.
  static String degreeDms(double degreeWithinSign) {
    var normalized = degreeWithinSign % 30.0;
    if (normalized < 0) normalized += 30.0;
    final totalArcSeconds = (normalized * 3600.0).round() % (30 * 3600);
    final degree = totalArcSeconds ~/ 3600;
    final minute = (totalArcSeconds % 3600) ~/ 60;
    final second = totalArcSeconds % 60;
    return '${two(degree)}° ${two(minute)}′ ${two(second)}″';
  }

  static String timezoneOffset(double offsetHours) {
    final totalMinutes = (offsetHours * 60.0).round();
    final sign = totalMinutes < 0 ? '-' : '+';
    final absMinutes = totalMinutes.abs();
    final hours = absMinutes ~/ 60;
    final minutes = absMinutes % 60;
    return 'UTC$sign${two(hours)}:${two(minutes)}';
  }
}
