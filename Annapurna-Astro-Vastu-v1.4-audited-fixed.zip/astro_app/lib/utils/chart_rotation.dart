/// Rotate the visual positions of a 4x4 South Indian chart, clockwise.
/// Does not change the sign index, ascendant, or planetary calculations.
class ChartRotation {
  static (int, int) cell(int row, int column, int quarterTurns) {
    if (row < 0 || row > 3 || column < 0 || column > 3) {
      throw RangeError('Chart grid index must be 0..3');
    }
    var r = row;
    var c = column;
    for (var i = 0; i < (quarterTurns % 4 + 4) % 4; i++) {
      final nextRow = c;
      final nextColumn = 3 - r;
      r = nextRow;
      c = nextColumn;
    }
    return (r, c);
  }
}
