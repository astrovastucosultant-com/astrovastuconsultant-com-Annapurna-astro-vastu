enum AyanamsaType {
  lahiri('Lahiri', 1),
  raman('Raman', 3),
  krishnamurti('KP / Krishnamurti', 5);

  const AyanamsaType(this.label, this.swissId);
  final String label;
  final int swissId;
}

class BirthData {
  final String name;
  final DateTime localDateTime;
  final String place;
  final double latitude;
  final double longitude;
  final double timezoneOffsetHours;
  final AyanamsaType ayanamsa;

  const BirthData({
    required this.name,
    required this.localDateTime,
    required this.place,
    required this.latitude,
    required this.longitude,
    required this.timezoneOffsetHours,
    required this.ayanamsa,
  });

  DateTime get utcDateTime {
    final localAsUtc = DateTime.utc(
      localDateTime.year,
      localDateTime.month,
      localDateTime.day,
      localDateTime.hour,
      localDateTime.minute,
      localDateTime.second,
    );
    final offsetMinutes = (timezoneOffsetHours * 60).round();
    return localAsUtc.subtract(Duration(minutes: offsetMinutes));
  }
}
