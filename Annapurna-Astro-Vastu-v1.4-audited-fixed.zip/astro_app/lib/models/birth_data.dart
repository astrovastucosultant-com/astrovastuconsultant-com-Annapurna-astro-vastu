enum AyanamsaType {
  lahiri('Lahiri', 1),
  raman('Raman', 3),
  krishnamurti('KP / Krishnamurti', 5);

  const AyanamsaType(this.label, this.swissId);
  final String label;
  final int swissId;
}

class BirthData {
  final String name;
  final DateTime localDateTime;
  final String place;
  final double latitude;
  final double longitude;
  final double timezoneOffsetHours;
  final AyanamsaType ayanamsa;

  const BirthData({
    required this.name,
    required this.localDateTime,
    required this.place,
    required this.latitude,
    required this.longitude,
    required this.timezoneOffsetHours,
    required this.ayanamsa,
  });

  DateTime get utcDateTime {
    final localAsUtc = DateTime.utc(
      localDateTime.year,
      localDateTime.month,
      localDateTime.day,
      localDateTime.hour,
      localDateTime.minute,
      localDateTime.second,
    );
    final offsetMinutes = (timezoneOffsetHours * 60).round();
    return localAsUtc.subtract(Duration(minutes: offsetMinutes));
  }

  /// Portable chart input payload used by Saved Charts.
  ///
  /// We intentionally store the birth inputs rather than calculated output so
  /// a reopened chart always runs through the current calculation engine and
  /// receives future rule/engine improvements automatically.
  Map<String, dynamic> toJson() => {
        'name': name,
        'localDateTime': localDateTime.toIso8601String(),
        'place': place,
        'latitude': latitude,
        'longitude': longitude,
        'timezoneOffsetHours': timezoneOffsetHours,
        'ayanamsa': ayanamsa.name,
      };

  factory BirthData.fromJson(Map<String, dynamic> json) {
    final rawAyanamsa = json['ayanamsa']?.toString() ?? '';
    final ayanamsa = AyanamsaType.values.firstWhere(
      (item) => item.name == rawAyanamsa || item.label == rawAyanamsa,
      orElse: () => AyanamsaType.lahiri,
    );
    return BirthData(
      name: json['name']?.toString() ?? 'జాతకుడు',
      localDateTime: DateTime.tryParse(
            json['localDateTime']?.toString() ?? '',
          ) ??
          DateTime(2000, 1, 1, 12),
      place: json['place']?.toString() ?? '',
      latitude: (json['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (json['longitude'] as num?)?.toDouble() ?? 0.0,
      timezoneOffsetHours:
          (json['timezoneOffsetHours'] as num?)?.toDouble() ?? 5.5,
      ayanamsa: ayanamsa,
    );
  }
}
