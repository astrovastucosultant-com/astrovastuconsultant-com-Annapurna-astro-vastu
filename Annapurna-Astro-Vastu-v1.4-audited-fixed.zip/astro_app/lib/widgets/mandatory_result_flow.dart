import 'package:flutter/material.dart';

/// Shared presentation policy for chart-derived findings.
/// Every result advances in this fixed order:
/// Result -> Rule -> Chart inspection -> Source-backed remedy/status.
/// This widget NEVER performs astrology calculations or invents remedies.
@immutable
class MandatoryResultEntry {
  final String module;
  final String title;
  final String result;
  final String ruleId;
  final String rule;
  final String inspection;
  final String remedy;
  final String source;
  final String status;
  final bool verifiedForChart;
  final List<String> sourceImageAssets;

  const MandatoryResultEntry({
    required this.module,
    required this.title,
    required this.result,
    required this.ruleId,
    required this.rule,
    required this.inspection,
    required this.source,
    this.remedy = '',
    this.status = '',
    this.verifiedForChart = true,
    this.sourceImageAssets = const [],
  });
}

class MandatoryResultFlow {
  const MandatoryResultFlow._();

  static const labels = <String>['ఫలితం', 'రూల్', 'జాతక పరిశీలన', 'పరిహారం'];
  static const noRemedy =
      'ఈ నియమానికి అందించిన మూలగ్రంథంలో నిర్ధారిత పరిహారం అందుబాటులో లేదు. ఊహించి పరిహారం సూచించము.';
  static const noInspection =
      'ఈ జాతకానికి వర్తింపజేయడానికి అవసరమైన గణన / గ్రహస్థితి ఆధారం ఇంకా అందుబాటులో లేదు.';

  static Future<void> open(BuildContext context, MandatoryResultEntry entry) =>
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        backgroundColor: const Color(0xFFFFFAF7),
        builder: (_) => _MandatoryResultSheet(entry: entry),
      );
}

class _MandatoryResultSheet extends StatefulWidget {
  final MandatoryResultEntry entry;
  const _MandatoryResultSheet({required this.entry});

  @override
  State<_MandatoryResultSheet> createState() => _MandatoryResultSheetState();
}

class _MandatoryResultSheetState extends State<_MandatoryResultSheet> {
  int _step = 0;

  String _content(MandatoryResultEntry e) => switch (_step) {
        0 => e.verifiedForChart
            ? (e.result.trim().isEmpty ? 'ఫలిత సమాచారం అందుబాటులో లేదు.' : e.result)
            : 'మూల నియమం మాత్రమే. ఈ జాతకానికి సరిపోలిన ఫలితంగా ఇంకా నిర్ధారించలేదు.\n${e.result}',
        1 => e.rule.trim().isEmpty
            ? 'ఈ Rule IDకి పూర్తి IF–THEN నియమం మూలంలో అందుబాటులో లేదు.'
            : e.rule,
        2 => e.inspection.trim().isEmpty
            ? MandatoryResultFlow.noInspection
            : e.inspection,
        _ => e.remedy.trim().isEmpty
            ? MandatoryResultFlow.noRemedy
            : e.remedy,
      };

  @override
  Widget build(BuildContext context) {
    final e = widget.entry;
    final color = e.verifiedForChart ? const Color(0xFF196B3A) : const Color(0xFF815D31);
    return SafeArea(
      top: false,
      child: FractionallySizedBox(
        heightFactor: .79,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(e.module, style: const TextStyle(color: Color(0xFF812536), fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text(e.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
              const SizedBox(height: 9),
              Text('Rule ID: ${e.ruleId.isEmpty ? 'మూలంలో లేదు' : e.ruleId}',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              const SizedBox(height: 8),
              Semantics(
                label: 'నాలుగు దశల తప్పనిసరి క్రమం',
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: List<Widget>.generate(MandatoryResultFlow.labels.length, (i) =>
                      Chip(
                        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        label: Text('${i + 1}. ${MandatoryResultFlow.labels[i]}',
                            style: TextStyle(fontSize: 11,
                                fontWeight: i == _step ? FontWeight.w900 : FontWeight.w500)),
                        backgroundColor: i == _step ? const Color(0xFFF5E6E9) : const Color(0xFFF4F1EF),
                      )),
                ),
              ),
              const Divider(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  key: Key('mandatory-flow-content-$_step'),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        Icon(e.verifiedForChart ? Icons.check_circle_outline : Icons.pending_outlined, color: color),
                        const SizedBox(width: 8),
                        Expanded(child: Text(
                          e.status.isNotEmpty ? e.status :
                              (e.verifiedForChart ? 'జాతక ఆధారిత పరిశీలన' : 'Source-only / ధృవీకరణ పెండింగ్'),
                          style: TextStyle(color: color, fontWeight: FontWeight.w800),
                        )),
                      ]),
                      const SizedBox(height: 16),
                      Text(MandatoryResultFlow.labels[_step],
                          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                      const SizedBox(height: 12),
                      InkWell(
                        key: Key('mandatory-flow-tappable-$_step'),
                        borderRadius: BorderRadius.circular(12),
                        onTap: _step < 3 ? () => setState(() => _step++) : null,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(15),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF8F0ED),
                            border: Border.all(color: const Color(0xFFE5C9D0)),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(_content(e), style: const TextStyle(fontSize: 16, height: 1.55)),
                        ),
                      ),
                      if (_step == 1 || _step == 2 || _step == 3) ...[
                        const SizedBox(height: 16),
                        const Text('గ్రంథ మూలం / Source',
                            style: TextStyle(fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        SelectableText(e.source.trim().isEmpty ? 'మూల ఆధారం అందుబాటులో లేదు.' : e.source),
                      ],
                      if ((_step == 1 || _step == 2) && e.sourceImageAssets.isNotEmpty)
                        ExpansionTile(
                          title: const Text('అసలు గ్రంథ పేజీల చిత్రాలు', style: TextStyle(fontWeight: FontWeight.w800)),
                          children: e.sourceImageAssets.map((asset) => ListTile(
                            dense: true,
                            leading: const Icon(Icons.image_outlined),
                            title: Text(asset.split('/').last),
                            onTap: () => showDialog<void>(
                              context: context,
                              builder: (ctx) => Dialog(
                                child: Column(children: [
                                  Row(children: [
                                    const Expanded(child: Padding(
                                      padding: EdgeInsets.all(12),
                                      child: Text('మూలగ్రంథం పేజీ చిత్రం'),
                                    )),
                                    IconButton(
                                      onPressed: () => Navigator.pop(ctx),
                                      icon: const Icon(Icons.close),
                                    ),
                                  ]),
                                  Expanded(child: InteractiveViewer(
                                    minScale: .7,
                                    maxScale: 5,
                                    child: Image.asset(asset, fit: BoxFit.contain),
                                  )),
                                ]),
                              ),
                            ),
                          )).toList(),
                        ),
                      if (_step == 3) ...[
                        const SizedBox(height: 12),
                        const Text('పరిహారం అనేది నిర్ధారిత మూలం ఉన్నప్పుడే. రత్నం, వైద్యం లేదా హోమం ఫలితానికి హామీ కాదు.',
                            style: TextStyle(fontSize: 12, color: Color(0xFF75646A))),
                      ],
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(children: [
                if (_step > 0)
                  OutlinedButton.icon(
                    key: const Key('mandatory-flow-back'),
                    onPressed: () => setState(() => _step--),
                    icon: const Icon(Icons.arrow_back),
                    label: const Text('వెనుకకు'),
                  ),
                const Spacer(),
                FilledButton.icon(
                  key: const Key('mandatory-flow-next'),
                  onPressed: _step < 3
                      ? () => setState(() => _step++)
                      : () => Navigator.of(context).pop(),
                  icon: Icon(_step < 3 ? Icons.arrow_forward : Icons.check),
                  label: Text(_step < 3
                      ? 'టచ్ → ${MandatoryResultFlow.labels[_step + 1]}'
                      : 'పూర్తి'),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
