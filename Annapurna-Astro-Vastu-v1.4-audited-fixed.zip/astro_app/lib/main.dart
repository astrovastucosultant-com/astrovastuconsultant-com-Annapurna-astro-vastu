import 'package:flutter/material.dart';

import 'screens/birth_details_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AnnapurnaAstroVastuApp());
}

class AnnapurnaAstroVastuApp extends StatelessWidget {
  const AnnapurnaAstroVastuApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF7B1E2B);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'అన్నపూర్ణ ఆస్ట్రో వాస్తు',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFFFFBF6),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF7B1E2B),
          foregroundColor: Colors.white,
        ),
      ),
      home: const BirthDetailsScreen(),
    );
  }
}
