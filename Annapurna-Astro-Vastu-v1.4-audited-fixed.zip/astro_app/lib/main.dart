import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'screens/birth_details_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AnnapurnaAstroVastuApp());
}

class _DesktopTabletScrollBehavior extends MaterialScrollBehavior {
  const _DesktopTabletScrollBehavior();

  @override
  Set<PointerDeviceKind> get dragDevices => const {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.stylus,
        PointerDeviceKind.invertedStylus,
        PointerDeviceKind.trackpad,
      };
}

class AnnapurnaAstroVastuApp extends StatelessWidget {
  const AnnapurnaAstroVastuApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF7B1E2B);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'అన్నపూర్ణ ఆస్ట్రో వాస్తు',
      scrollBehavior: const _DesktopTabletScrollBehavior(),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFFFFAF7),
        cardColor: Colors.white,
        canvasColor: Colors.white,
        dividerColor: const Color(0xFFE4D7D9),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          labelStyle: TextStyle(color: Color(0xFF6F3A43)),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF7B1E2B),
          foregroundColor: Colors.white,
        ),
      ),
      home: const BirthDetailsScreen(),
    );
  }
}
