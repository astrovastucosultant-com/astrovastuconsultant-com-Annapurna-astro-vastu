import 'package:flutter/material.dart';
import '../models/birth_data.dart';
import '../astrology/western_progression_service.dart';

/// Retrospective Western aspect alignment only, NOT verified birth-time
/// rectification. No Vedic dasha or other systems are used here.
class WesternBtrComparisonScreen extends StatefulWidget {
  const WesternBtrComparisonScreen({super.key, required this.birthData});
  final BirthData birthData;
  @override
  State<WesternBtrComparisonScreen> createState() => _WesternBtrComparisonScreenState();
}
class _WesternBtrComparisonScreenState extends State<WesternBtrComparisonScreen> {
  final dates = <DateTime>[];
  final eventKinds = <String>[];
  static const kinds = <String>[
    'వివాహం', 'సంతానం', 'ఉద్యోగం', 'ప్రమోషన్', 'ఉద్యోగ మార్పు',
    'ఆస్తి', 'విద్య', 'విదేశీ ప్రయాణం', 'కుటుంబ సంఘటన', 'ఇతర సంఘటన',
  ];
  String selectedKind = kinds.first;
  final offsets = <int>[-30, -15, -5, 0, 5, 15, 30];
  bool busy = false;
  String? error;
  List<_Candidate> results = [];
  Future<void> addDate() async {
    final selected = await showDatePicker(
      context: context, initialDate: DateTime.now(),
      firstDate: DateTime(1900), lastDate: DateTime.now());
    if (selected != null) setState(() { dates.add(selected); eventKinds.add(selectedKind); results = []; });
  }
  Future<void> compare() async {
    if (dates.isEmpty) {
      setState(() => error = 'కనీసం ఒక గత సంఘటన తేదీ ఇవ్వండి');
      return;
    }
    setState(() { busy = true; error = null; results = []; });
    try {
      final candidates = <_Candidate>[];
      for (final offset in offsets) {
        final adjusted = widget.birthData.copyWith(
          localDateTime: widget.birthData.localDateTime.add(Duration(minutes: offset)));
        var matched = 0;
        final evidence = <String>[];
        for (final date in dates) {
          final contacts = await WesternProgressionService.exactContacts(
            adjusted, date, windowDays: 15, maxResults: 12);
          matched += contacts.length;
          evidence.add('${eventKinds[dates.indexOf(date)]} · ${date.day}-${date.month}-${date.year}: ${contacts.length} contacts');
        }
        candidates.add(_Candidate(offset, matched, evidence));
        if (!mounted) return;
      }
      candidates.sort((a,b) => b.matches.compareTo(a.matches));
      setState(() => results = candidates);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Western BTR — Aspect Comparison')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('గత సంఘటనల తేదీలు నమోదు చేసి జనన సమయాన్ని ±30 నిమిషాల్లో పోల్చండి.',
        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('ఈ స్కోరు ±15 రోజుల పరిధిలోని Exact Contacts సంఖ్య మాత్రమే. '
        'అత్యధిక స్కోరు వచ్చిన సమయమే నిజమైన జనన సమయం అని అర్థం కాదు. '
        'సంఘటనల రకానికి సంబంధించిన Rule Matching ఇంకా జోడించలేదు.'),
      const SizedBox(height: 12),
      for (var i=0; i<dates.length; i++)
        ListTile(
          title: Text('${eventKinds[i]} · ${dates[i].day}-${dates[i].month}-${dates[i].year}'),
          trailing: IconButton(icon: const Icon(Icons.delete_outline),
            onPressed: busy ? null : () => setState(() { dates.removeAt(i); eventKinds.removeAt(i); results=[]; })),
        ),
      DropdownButtonFormField<String>(
        value: selectedKind,
        decoration: const InputDecoration(labelText: 'గత సంఘటన రకం'),
        items: kinds.map((k) => DropdownMenuItem(value: k, child: Text(k))).toList(),
        onChanged: busy ? null : (v) { if (v != null) setState(() => selectedKind = v); },
      ),
      OutlinedButton.icon(onPressed: busy ? null : addDate,
        icon: const Icon(Icons.add), label: const Text('గత సంఘటన తేదీ జోడించండి')),
      FilledButton.icon(onPressed: busy ? null : compare,
        icon: const Icon(Icons.search), label: const Text('BTR సమయ పోలిక')),
      if (busy) const LinearProgressIndicator(),
      if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
      if (results.isNotEmpty) ...[
        const SizedBox(height: 14),
        const Text('జనన సమయ అభ్యర్థుల పోలిక',
          style: TextStyle(fontWeight: FontWeight.bold)),
        for (final item in results)
          Card(child: ExpansionTile(
            title: Text('${item.offset >= 0 ? '+' : ''}${item.offset} నిమిషాలు'),
            subtitle: Text('${item.matches} Aspect contacts (సంఖ్య మాత్రమే)'),
            children: [
              for (final line in item.evidence)
                ListTile(dense: true, title: Text(line)),
            ],
          )),
      ],
      const SizedBox(height: 16),
      const Text('పరిశీలన కోసం మాత్రమే. BTR నిర్ణయం, భవిష్యత్తు సంఘటనల నిర్ధారణ లేదా '
        'మరణ కాల అంచనాకు ఈ సంఖ్యలను ఉపయోగించరాదు.'),
    ]),
  );
}
class _Candidate {
  final int offset;
  final int matches;
  final List<String> evidence;
  const _Candidate(this.offset, this.matches, this.evidence);
}
