import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../services/report_storage_service.dart';

class SavedReportsScreen extends StatefulWidget {
  const SavedReportsScreen({super.key});

  @override
  State<SavedReportsScreen> createState() => _SavedReportsScreenState();
}

class _SavedReportsScreenState extends State<SavedReportsScreen> {
  late Future<List<SavedReport>> _future;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() {
    _future = ReportStorageService.load();
  }

  Future<void> _delete(SavedReport report) async {
    await ReportStorageService.delete(report.id);
    if (!mounted) return;
    setState(_reload);
  }

  String _stamp(DateTime dt) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(dt.day)}-${two(dt.month)}-${dt.year} '
        '${two(dt.hour)}:${two(dt.minute)}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Saved Reports')),
      body: FutureBuilder<List<SavedReport>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final reports = snapshot.data ?? const <SavedReport>[];
          if (reports.isEmpty) {
            return const Center(child: Text('Saved reports ఇంకా లేవు'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(12),
            itemCount: reports.length,
            separatorBuilder: (_, __) => const SizedBox(height: 6),
            itemBuilder: (context, index) {
              final report = reports[index];
              return Card(
                child: ListTile(
                  title: Text(report.title),
                  subtitle: Text(_stamp(report.savedAt)),
                  onTap: () => _showReport(report),
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) async {
                      if (value == 'copy') {
                        await Clipboard.setData(ClipboardData(text: report.body));
                      } else if (value == 'share') {
                        await SharePlus.instance.share(
                          ShareParams(text: report.body, title: report.title),
                        );
                      } else if (value == 'delete') {
                        await _delete(report);
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'copy', child: Text('Copy')),
                      PopupMenuItem(value: 'share', child: Text('Share')),
                      PopupMenuItem(value: 'delete', child: Text('Delete')),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _showReport(SavedReport report) async {
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(report.title),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(child: SelectableText(report.body)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
