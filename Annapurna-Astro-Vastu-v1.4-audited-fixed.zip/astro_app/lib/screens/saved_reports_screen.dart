import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../services/chart_storage_service.dart';
import '../services/report_storage_service.dart';
import 'chart_screen.dart';

class SavedReportsScreen extends StatefulWidget {
  const SavedReportsScreen({super.key});

  @override
  State<SavedReportsScreen> createState() => _SavedReportsScreenState();
}

class _SavedReportsScreenState extends State<SavedReportsScreen> {
  late Future<List<SavedChart>> _chartsFuture;
  late Future<List<SavedReport>> _reportsFuture;
  String _chartQuery = '';
  final TextEditingController _chartSearchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _chartSearchController.dispose();
    super.dispose();
  }

  void _reload() {
    _chartsFuture = ChartStorageService.load();
    _reportsFuture = ReportStorageService.load();
  }

  void _refresh() => setState(_reload);

  Future<void> _deleteChart(SavedChart chart) async {
    await ChartStorageService.delete(chart.id);
    if (!mounted) return;
    _refresh();
  }

  Future<void> _deleteReport(SavedReport report) async {
    await ReportStorageService.delete(report.id);
    if (!mounted) return;
    _refresh();
  }

  String _stamp(DateTime dt) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(dt.day)}-${two(dt.month)}-${dt.year} '
        '${two(dt.hour)}:${two(dt.minute)}';
  }

  String _birthStamp(DateTime dt) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(dt.day)}-${two(dt.month)}-${dt.year} '
        '${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Saved Charts & Reports'),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.auto_stories_outlined), text: 'Saved Charts'),
              Tab(icon: Icon(Icons.description_outlined), text: 'Reports'),
            ],
          ),
        ),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1000),
            child: TabBarView(
              children: [
                _savedChartsTab(),
                _savedReportsTab(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _savedChartsTab() {
    return FutureBuilder<List<SavedChart>>(
      future: _chartsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        final allCharts = snapshot.data ?? const <SavedChart>[];
        if (allCharts.isEmpty) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Saved charts ఇంకా లేవు.\nజాతక చక్రం తెరిచి పై Save Chart బటన్ నొక్కండి.',
                textAlign: TextAlign.center,
              ),
            ),
          );
        }

        final q = _chartQuery.trim().toLowerCase();
        final charts = q.isEmpty
            ? allCharts
            : allCharts.where((chart) {
                final b = chart.birthData;
                final haystack = [
                  b.name,
                  b.place,
                  _birthStamp(b.localDateTime),
                  b.localDateTime.toIso8601String(),
                  b.ayanamsa.label,
                ].join(' ').toLowerCase();
                return haystack.contains(q);
              }).toList();

        return Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
              child: TextField(
                controller: _chartSearchController,
                onChanged: (value) => setState(() => _chartQuery = value),
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: 'పేరు / తేదీ / ప్రదేశం search',
                  suffixIcon: _chartQuery.isEmpty
                      ? null
                      : IconButton(
                          tooltip: 'Clear search',
                          onPressed: () {
                            _chartSearchController.clear();
                            setState(() => _chartQuery = '');
                          },
                          icon: const Icon(Icons.clear),
                        ),
                  border: const OutlineInputBorder(),
                ),
              ),
            ),
            if (charts.isEmpty)
              const Expanded(
                child: Center(child: Text('ఈ searchకి Saved Chart దొరకలేదు')),
              )
            else
              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: charts.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 6),
                  itemBuilder: (context, index) {
                    final chart = charts[index];
                    final b = chart.birthData;
                    final rectifiedText = b.hasRectifiedTime
                        ? '\nOriginal: ${_birthStamp(b.originalBirthDateTime)}'
                        : '';
                    return Card(
                      child: ListTile(
                        leading: const CircleAvatar(
                          child: Icon(Icons.auto_stories_outlined),
                        ),
                        title: Text(
                          b.name,
                          style: const TextStyle(fontWeight: FontWeight.w800),
                        ),
                        subtitle: Text(
                          '${_birthStamp(b.localDateTime)}$rectifiedText\n'
                          '${b.place.isEmpty ? 'స్థలం లేదు' : b.place} • ${b.ayanamsa.label}\n'
                          'Saved: ${_stamp(chart.savedAt)}',
                        ),
                        isThreeLine: true,
                        onTap: () async {
                          await Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => ChartScreen(
                                birthData: b,
                                savedChartId: chart.id,
                              ),
                            ),
                          );
                          if (mounted) _refresh();
                        },
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) async {
                            if (value == 'open') {
                              if (!mounted) return;
                              await Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => ChartScreen(
                                    birthData: b,
                                    savedChartId: chart.id,
                                  ),
                                ),
                              );
                              if (mounted) _refresh();
                            } else if (value == 'delete') {
                              await _deleteChart(chart);
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'open', child: Text('Open / Edit')),
                            PopupMenuItem(value: 'delete', child: Text('Delete')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _savedReportsTab() {
    return FutureBuilder<List<SavedReport>>(
      future: _reportsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        final reports = snapshot.data ?? const <SavedReport>[];
        if (reports.isEmpty) {
          return const Center(child: Text('Saved reports ఇంకా లేవు'));
        }
        return ListView.separated(
          padding: const EdgeInsets.all(12),
          itemCount: reports.length,
          separatorBuilder: (_, __) => const SizedBox(height: 6),
          itemBuilder: (context, index) {
            final report = reports[index];
            return Card(
              child: ListTile(
                title: Text(report.title),
                subtitle: Text(_stamp(report.savedAt)),
                onTap: () => _showReport(report),
                trailing: PopupMenuButton<String>(
                  onSelected: (value) async {
                    if (value == 'copy') {
                      await Clipboard.setData(ClipboardData(text: report.body));
                    } else if (value == 'share') {
                      await SharePlus.instance.share(
                        ShareParams(text: report.body, title: report.title),
                      );
                    } else if (value == 'delete') {
                      await _deleteReport(report);
                    }
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'copy', child: Text('Copy')),
                    PopupMenuItem(value: 'share', child: Text('Share')),
                    PopupMenuItem(value: 'delete', child: Text('Delete')),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _showReport(SavedReport report) async {
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(report.title),
        content: SizedBox(
          width: 760,
          child: SingleChildScrollView(child: SelectableText(report.body)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}
