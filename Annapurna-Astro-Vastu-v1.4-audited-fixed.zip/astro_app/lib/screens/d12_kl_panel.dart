import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/d12_kl_service.dart';
import '../astrology/varga_service.dart';

/// Compact D12 KL reference analysis. All displayed percentages are
/// accountable rule-check ratios, not predictions or likelihoods.
class D12KlPanel extends StatelessWidget {
  final AstroChartResult chart;
  final VargaChartData d12;
  const D12KlPanel({super.key, required this.chart, required this.d12});

  Widget _ratio(BuildContext context, String heading, String value, String detail) {
    return Expanded(child: Card(
      color: const Color(0xFFF4F7FC),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(9),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(heading, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: Color(0xFF1D456B))),
          Text(detail, style: const TextStyle(fontSize: 10.5, height: 1.25)),
        ]),
      ),
    ));
  }

  void _detail(BuildContext context, D12KlCheck check, D12KlAnalysis a) {
    showModalBottomSheet<void>(
      context: context, isScrollControlled: true, showDragHandle: true,
      builder: (ctx) => SafeArea(child: FractionallySizedBox(
        heightFactor: 0.84,
        child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 28), children: [
          Text(check.ruleId, style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF7C263C))),
          const SizedBox(height: 9),
          Text(check.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
          const SizedBox(height: 8),
          Text('ఆధారం: ${check.fromKl ? 'KL (AK D9)' : 'D12'}; KL ${D12KlService.signNames[a.klSign]}', style: const TextStyle(fontWeight: FontWeight.w700)),
          const Divider(height: 22),
          const Text('IF — నియమం', style: TextStyle(fontWeight: FontWeight.w900)),
          Text(check.condition, style: const TextStyle(height: 1.55)),
          const SizedBox(height: 13),
          const Text('ఈ జాతకంలో పరీక్ష', style: TextStyle(fontWeight: FontWeight.w900)),
          Text(check.evidence, style: const TextStyle(height: 1.55)),
          const SizedBox(height: 13),
          const Text('THEN — గ్రంథ సూచన', style: TextStyle(fontWeight: FontWeight.w900)),
          Text(check.sourceResult, style: const TextStyle(height: 1.55)),
          const SizedBox(height: 13),
          Text('మూల గ్రంథం: Saral Jyotish Part VII, Chapter 9, పేజీ ${check.printedPage}', style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 10),
          const Text('పరిహారం: ఈ D12 అధ్యాయంలో ప్రత్యేక పరిహారం ఇవ్వలేదు.', style: TextStyle(fontWeight: FontWeight.w600)),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    final a = D12KlService.analyze(chart,d12);
    final grouped = <String,List<D12KlCheck>>{};
    for (final check in a.checks) {
      (grouped[check.category] ??= <D12KlCheck>[]).add(check);
    }
    return Card(
      color: const Color(0xFFFFFCF6),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start,children: [
          const Text('D12 — కారకాంశ లగ్నం (KL) & రూల్ %',style: TextStyle(fontSize: 18,fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Text('D12 లగ్నం: ${D12KlService.signNames[a.d12Sign]}  •  KL: ${D12KlService.signNames[a.klSign]}',style: const TextStyle(fontWeight: FontWeight.w800)),
          Text('AK: ${a.atmakaraka}  •  KL అధిపతి: ${a.klLord}'),
          const SizedBox(height: 8),
          const Text('KL పద్ధతి: ఆత్మకారకుని D9 రాశిని D12లో reference lagnaగా తీసుకున్నాం. గ్రంథం KL చక్రాన్ని చూపింది; ఈ అధ్యాయంలో KL గణన సూత్రాన్ని స్వతంత్రంగా వివరించలేదు. అందువల్ల ఇది స్పష్టంగా ప్రకటించిన యాప్ అమరిక.', style: TextStyle(fontSize: 12,height: 1.45)),
          if (a.degreeTie) const Padding(padding: EdgeInsets.only(top: 6), child: Text('AK డిగ్రీ టై ఉంది: KL రూల్స్‌ను ఆటోగా నిర్ధారించలేదు.',style: TextStyle(color: Colors.red,fontWeight: FontWeight.w800))),
          const SizedBox(height: 10),
          Row(crossAxisAlignment: CrossAxisAlignment.start,children: [
            _ratio(context,'పరీక్ష పూర్తయింది','${a.evaluatedPercent}%','${a.tested} / ${a.allChecks} నియమ తనిఖీలు'),
            _ratio(context,'రూల్ మ్యాచ్','${a.tested == 0 ? '—' : '${a.matchPercent}%'}','${a.matched} / ${a.tested} పరీక్షించినవి'),
            _ratio(context,'అనుకూల వాటా',a.favorableSharePercent == null ? '—' : '${a.favorableSharePercent}%','${a.favorableMatched} శుభ / ${a.cautionMatched} జాగ్రత్త'),
          ]),
          const Text('ఈ %లు కేవలం అమలు చేసిన నియమాల లెక్కలు; భవిష్యత్తు సంఘటనల అవకాశం, గ్రంథ ఫలితాల ఖచ్చితత్వం లేదా ఆయుర్దాయం కాదు. Pending నియమాలను బలవంతంగా మ్యాచ్ చేయము.',style: TextStyle(fontSize: 11.5,height: 1.5,color: Color(0xFF5A5053))),
          const SizedBox(height: 12),
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: const Text('KL నుంచి 1–12 భావాలు, గ్రహస్థితులు',style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: const Text('టచ్ చేసి ప్రతి భావం — రాశి, అధిపతి, గ్రహాలు చూడండి'),
            children: [
              for (int h=1;h<=12;h++)
                Padding(padding: const EdgeInsets.symmetric(vertical: 5),child: Row(crossAxisAlignment: CrossAxisAlignment.start,children: [
                  SizedBox(width: 42,child: Text('H$h',style: const TextStyle(fontWeight: FontWeight.w800))),
                  Expanded(child: Text('${D12KlService.signNames[a.signForHouse(h)]}  •  ${D12KlService.signLord(a.signForHouse(h))}\n${(a.occupantsFromKl[h] ?? []).isEmpty ? 'గ్రహాలు లేవు' : a.occupantsFromKl[h]!.join(', ')}',style: const TextStyle(height: 1.35))),
                ])),
            ],
          ),
          const SizedBox(height: 4),
          const Text('రూల్ తనిఖీలు — ఫలితం టచ్ చేస్తే IF → ఆధారం → THEN → మూల పేజీ',style: TextStyle(fontSize: 12,fontWeight: FontWeight.w800)),
          for(final section in grouped.entries)
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: Text(section.key,style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${section.value.where((x)=>x.matched==true).length} సరిపోలినవి • ${section.value.where((x)=>x.matched==null).length} పెండింగ్'),
              children: [for(final hit in section.value)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense:true,
                  leading: Icon(hit.matched == null || a.degreeTie ? Icons.hourglass_empty : hit.matched! ? Icons.check_circle_outline : Icons.radio_button_unchecked,
                    color: hit.matched == null || a.degreeTie ? Colors.grey : hit.matched! ? const Color(0xFF217D43) : Colors.blueGrey),
                  title: Text('${hit.caution && hit.matched == true ? '⚠ ' : ''}${hit.title}',style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${hit.ruleId} • ${hit.matched == null || a.degreeTie ? 'పెండింగ్' : hit.matched! ? 'నియమం వర్తించింది' : 'ఈ జాతకానికి వర్తించలేదు'}'),
                  trailing: const Icon(Icons.chevron_right,size: 18),
                  onTap: () => _detail(context,hit,a),
                ),
              ]],
            ),
          const SizedBox(height: 6),
          const Text('తల్లిదండ్రుల ఆయుర్దాయం: KL నుంచి తల్లి 4వ/11వ, తండ్రి 9వ/4వ భావాలను చూపుతాం; మరణ తేదీ లేదా ఆయుర్ % నిర్ణయించము.',style: TextStyle(fontSize: 11.5,fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }
}
