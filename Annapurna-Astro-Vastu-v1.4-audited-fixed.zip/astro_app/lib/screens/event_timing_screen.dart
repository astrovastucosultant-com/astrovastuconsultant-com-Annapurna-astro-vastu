import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../models/birth_data.dart';
import '../services/place_search_service.dart';
import '../services/place_storage_service.dart';
import '../services/report_storage_service.dart';
import '../utils/astro_format.dart';

class EventTimingScreen extends StatefulWidget {
  final String initialPlace;
  final double? initialLatitude;
  final double? initialLongitude;
  final double initialTimezone;
  final AyanamsaType initialAyanamsa;

  const EventTimingScreen({
    super.key,
    this.initialPlace = '',
    this.initialLatitude,
    this.initialLongitude,
    this.initialTimezone = 5.5,
    this.initialAyanamsa = AyanamsaType.lahiri,
  });

  @override
  State<EventTimingScreen> createState() => _EventTimingScreenState();
}

class _EventTimingScreenState extends State<EventTimingScreen> {
  late final TextEditingController placeController;
  late final TextEditingController latitudeController;
  late final TextEditingController longitudeController;
  late final TextEditingController timezoneController;
  final startSecondsController = TextEditingController(text: '00');
  final endSecondsController = TextEditingController(text: '00');

  late DateTime startDate;
  late DateTime endDate;
  late TimeOfDay startTime;
  late TimeOfDay endTime;
  late AyanamsaType ayanamsa;

  bool loading = false;
  bool isSearching = false;
  String? error;
  AstroChartResult? startResult;
  AstroChartResult? endResult;
  Duration? duration;


  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    startDate = DateTime(now.year, now.month, now.day);
    startTime = TimeOfDay(hour: now.hour, minute: now.minute);
    final later = now.add(const Duration(hours: 1));
    endDate = DateTime(later.year, later.month, later.day);
    endTime = TimeOfDay(hour: later.hour, minute: later.minute);
    ayanamsa = widget.initialAyanamsa;
    placeController = TextEditingController(text: widget.initialPlace);
    latitudeController = TextEditingController(
      text: widget.initialLatitude?.toStringAsFixed(6) ?? '',
    );
    longitudeController = TextEditingController(
      text: widget.initialLongitude?.toStringAsFixed(6) ?? '',
    );
    timezoneController = TextEditingController(
      text: widget.initialTimezone.toString(),
    );
  }

  @override
  void dispose() {
    placeController.dispose();
    latitudeController.dispose();
    longitudeController.dispose();
    timezoneController.dispose();
    startSecondsController.dispose();
    endSecondsController.dispose();
    super.dispose();
  }

  Future<DateTime?> _pickDate(DateTime initial) => showDatePicker(
        context: context,
        initialDate: initial,
        firstDate: DateTime(1900),
        lastDate: DateTime(2100),
      );

  Future<TimeOfDay?> _pickTime(TimeOfDay initial) => showTimePicker(
        context: context,
        initialTime: initial,
      );

  void _applyPlace(PlaceResult place) {
    setState(() {
      placeController.text = place.displayName;
      latitudeController.text = place.latitude.toStringAsFixed(6);
      longitudeController.text = place.longitude.toStringAsFixed(6);
    });
  }

  Future<void> _searchPlace() async {
    final query = placeController.text.trim();
    if (query.isEmpty) {
      _setError('Place / Village పేరు నమోదు చేయండి');
      return;
    }

    setState(() {
      isSearching = true;
      error = null;
    });

    try {
      final results = await PlaceSearchService.search(query);
      if (!mounted) return;
      if (results.isEmpty) {
        _setError('స్థలం కనబడలేదు. Saved Place లేదా coordinates manually ఇవ్వండి.');
        return;
      }

      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (sheetContext) {
          return SafeArea(
            child: SizedBox(
              height: MediaQuery.of(sheetContext).size.height * 0.65,
              child: Column(
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Text(
                      'స్థలం ఎంచుకోండి',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Expanded(
                    child: ListView.separated(
                      itemCount: results.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (context, index) {
                        final place = results[index];
                        return ListTile(
                          leading: const Icon(Icons.location_on_outlined),
                          title: Text(place.displayName),
                          subtitle: Text(
                            'Lat ${place.latitude.toStringAsFixed(6)}  •  '
                            'Lon ${place.longitude.toStringAsFixed(6)}',
                          ),
                          onTap: () {
                            _applyPlace(place);
                            Navigator.pop(sheetContext);
                          },
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    } catch (e) {
      if (mounted) _setError(e.toString());
    } finally {
      if (mounted) setState(() => isSearching = false);
    }
  }

  Future<void> _showSavedPlaces() async {
    final places = await PlaceStorageService.load();
    if (!mounted) return;

    if (places.isEmpty) {
      _setError('Saved Places ఇంకా లేవు. Birth Detailsలో New Place add చేయండి.');
      return;
    }

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(sheetContext).size.height * 0.65,
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'Saved Places',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    itemCount: places.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final place = places[index];
                      return ListTile(
                        leading: const Icon(Icons.bookmark_outline),
                        title: Text(place.displayName),
                        subtitle: Text(
                          'Lat ${place.latitude.toStringAsFixed(6)}  •  '
                          'Lon ${place.longitude.toStringAsFixed(6)}',
                        ),
                        onTap: () {
                          _applyPlace(place);
                          Navigator.pop(sheetContext);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _addNewPlace() async {
    final place = TextEditingController(text: placeController.text);
    final lat = TextEditingController(text: latitudeController.text);
    final lon = TextEditingController(text: longitudeController.text);

    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('New Place / కొత్త స్థలం'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: place,
                decoration: const InputDecoration(
                  labelText: 'Village / Place name',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: lat,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                  signed: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Latitude',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: lon,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                  signed: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Longitude',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final latitude = double.tryParse(lat.text.trim());
              final longitude = double.tryParse(lon.text.trim());
              if (place.text.trim().isEmpty ||
                  latitude == null ||
                  longitude == null ||
                  latitude < -90 ||
                  latitude > 90 ||
                  longitude < -180 ||
                  longitude > 180) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Place, Latitude, Longitude సరిగా ఇవ్వండి'),
                  ),
                );
                return;
              }
              Navigator.pop(dialogContext, true);
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );

    if (accepted == true && mounted) {
      final savedPlace = PlaceResult(
        displayName: place.text.trim(),
        latitude: double.parse(lat.text.trim()),
        longitude: double.parse(lon.text.trim()),
      );
      _applyPlace(savedPlace);
      await PlaceStorageService.save(savedPlace);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('New Place save అయింది')),
        );
      }
    }

    place.dispose();
    lat.dispose();
    lon.dispose();
  }

  Future<void> _calculate() async {
    final lat = double.tryParse(latitudeController.text.trim());
    final lon = double.tryParse(longitudeController.text.trim());
    final tz = double.tryParse(timezoneController.text.trim());
    final startSec = int.tryParse(startSecondsController.text.trim());
    final endSec = int.tryParse(endSecondsController.text.trim());

    if (lat == null || lat < -90 || lat > 90 ||
        lon == null || lon < -180 || lon > 180) {
      _setError('Latitude / Longitude సరిగా ఇవ్వండి');
      return;
    }
    if (tz == null || tz < -14 || tz > 14) {
      _setError('Timezone సరిగా ఇవ్వండి');
      return;
    }
    if (startSec == null || startSec < 0 || startSec > 59 ||
        endSec == null || endSec < 0 || endSec > 59) {
      _setError('Seconds 0–59 మధ్య ఉండాలి');
      return;
    }

    final start = DateTime(
      startDate.year, startDate.month, startDate.day,
      startTime.hour, startTime.minute, startSec,
    );
    final end = DateTime(
      endDate.year, endDate.month, endDate.day,
      endTime.hour, endTime.minute, endSec,
    );
    if (!end.isAfter(start)) {
      _setError('End time, Start time కంటే తర్వాత ఉండాలి');
      return;
    }

    setState(() {
      loading = true;
      error = null;
      startResult = null;
      endResult = null;
      duration = end.difference(start);
    });

    try {
      final common = (
        place: placeController.text.trim().isEmpty
            ? 'Event Place'
            : placeController.text.trim(),
        lat: lat,
        lon: lon,
        tz: tz,
      );
      final startData = BirthData(
        name: 'Event Start',
        localDateTime: start,
        place: common.place,
        latitude: common.lat,
        longitude: common.lon,
        timezoneOffsetHours: common.tz,
        ayanamsa: ayanamsa,
      );
      final endData = BirthData(
        name: 'Event End',
        localDateTime: end,
        place: common.place,
        latitude: common.lat,
        longitude: common.lon,
        timezoneOffsetHours: common.tz,
        ayanamsa: ayanamsa,
      );
      final a = await AstroCalculationService.calculate(startData);
      final b = await AstroCalculationService.calculate(endData);
      if (!mounted) return;
      setState(() {
        startResult = a;
        endResult = b;
      });
    } catch (e) {
      if (mounted) _setError(e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  void _setError(String text) {
    setState(() => error = text);
  }

  String _two(int v) => v.toString().padLeft(2, '0');

  String _durationText(Duration d) {
    final days = d.inDays;
    final hours = d.inHours.remainder(24);
    final minutes = d.inMinutes.remainder(60);
    final seconds = d.inSeconds.remainder(60);
    final dayText = days > 0 ? '$days days  ' : '';
    return '$dayText${_two(hours)} గంటలు : ${_two(minutes)} నిమిషాలు : ${_two(seconds)} సెకండ్లు';
  }

  String _lagna(AstroChartResult r) {
    final lon = r.ascendantLongitude;
    final sign = (lon / 30).floor() % 12;
    return '${sign + 1} ${(lon % 30).toStringAsFixed(3)}°';
  }

  String _moon(AstroChartResult r) {
    final p = r.planets.firstWhere((p) => p.name == 'Moon');
    final sign = p.signIndex;
    return '${sign + 1} ${p.degreesInSign.toStringAsFixed(3)}°';
  }

  DateTime _startDateTime() {
    final sec = int.tryParse(startSecondsController.text.trim()) ?? 0;
    return DateTime(
      startDate.year,
      startDate.month,
      startDate.day,
      startTime.hour,
      startTime.minute,
      sec,
    );
  }

  DateTime _endDateTime() {
    final sec = int.tryParse(endSecondsController.text.trim()) ?? 0;
    return DateTime(
      endDate.year,
      endDate.month,
      endDate.day,
      endTime.hour,
      endTime.minute,
      sec,
    );
  }

  String _eventReportText() {
    final start = startResult;
    final end = endResult;
    final d = duration;
    if (start == null || end == null || d == null) return '';

    final place = placeController.text.trim().isEmpty
        ? 'Event Place'
        : placeController.text.trim();
    final tz = double.tryParse(timezoneController.text.trim()) ?? 5.5;

    return (StringBuffer()
      ..writeln('అన్నపూర్ణ ఆస్ట్రో వాస్తు - Event Timing')
      ..writeln('Place: $place')
      ..writeln('Latitude: ${latitudeController.text.trim()}')
      ..writeln('Longitude: ${longitudeController.text.trim()}')
      ..writeln('Timezone: ${AstroFormat.timezoneOffset(tz)}')
      ..writeln('Ayanamsa: ${ayanamsa.label}')
      ..writeln('Start: ${AstroFormat.dateTime(_startDateTime())}')
      ..writeln('End: ${AstroFormat.dateTime(_endDateTime())}')
      ..writeln('Exact duration: ${_durationText(d)}')
      ..writeln('Start Lagna: ${_lagna(start)}')
      ..writeln('Start Moon: ${_moon(start)}')
      ..writeln('End Lagna: ${_lagna(end)}')
      ..writeln('End Moon: ${_moon(end)}')
      ..writeln('Favorable %: unavailable until verified event-rule data is added.'))
        .toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Event Timing')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Event time range',
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: placeController,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _searchPlace(),
            decoration: InputDecoration(
              labelText: 'Place / Village',
              border: const OutlineInputBorder(),
              suffixIcon: isSearching
                  ? const Padding(
                      padding: EdgeInsets.all(14),
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    )
                  : IconButton(
                      tooltip: 'Search Place',
                      onPressed: _searchPlace,
                      icon: const Icon(Icons.search),
                    ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              OutlinedButton.icon(
                onPressed: _showSavedPlaces,
                icon: const Icon(Icons.bookmarks_outlined),
                label: const Text('Saved Places'),
              ),
              const SizedBox(width: 8),
              OutlinedButton.icon(
                onPressed: _addNewPlace,
                icon: const Icon(Icons.add_location_alt_outlined),
                label: const Text('New Place'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: latitudeController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                  decoration: const InputDecoration(labelText: 'Latitude', border: OutlineInputBorder()),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: longitudeController,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                  decoration: const InputDecoration(labelText: 'Longitude', border: OutlineInputBorder()),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: timezoneController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
            decoration: const InputDecoration(
              labelText: 'Timezone offset',
              helperText: 'India: +5.5',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<AyanamsaType>(
            initialValue: ayanamsa,
            decoration: const InputDecoration(labelText: 'Ayanamsa', border: OutlineInputBorder()),
            items: AyanamsaType.values
                .map((a) => DropdownMenuItem(value: a, child: Text(a.label)))
                .toList(),
            onChanged: (value) {
              if (value != null) setState(() => ayanamsa = value);
            },
          ),
          const SizedBox(height: 18),
          _TimeBlock(
            title: 'Start',
            date: startDate,
            time: startTime,
            secondsController: startSecondsController,
            onDate: () async {
              final value = await _pickDate(startDate);
              if (value != null) setState(() => startDate = value);
            },
            onTime: () async {
              final value = await _pickTime(startTime);
              if (value != null) setState(() => startTime = value);
            },
          ),
          const SizedBox(height: 10),
          _TimeBlock(
            title: 'End',
            date: endDate,
            time: endTime,
            secondsController: endSecondsController,
            onDate: () async {
              final value = await _pickDate(endDate);
              if (value != null) setState(() => endDate = value);
            },
            onTime: () async {
              final value = await _pickTime(endTime);
              if (value != null) setState(() => endTime = value);
            },
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: loading ? null : _calculate,
            icon: loading
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.schedule),
            label: const Text('Calculate Window'),
          ),
          if (error != null) ...[
            const SizedBox(height: 12),
            Text(error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          if (duration != null) ...[
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Exact duration', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    const SizedBox(height: 6),
                    Text(_durationText(duration!)),
                  ],
                ),
              ),
            ),
          ],
          if (startResult != null && endResult != null) ...[
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Boundary calculations', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                    const SizedBox(height: 8),
                    Text('Start Lagna: ${_lagna(startResult!)}'),
                    Text('Start Moon: ${_moon(startResult!)}'),
                    const SizedBox(height: 8),
                    Text('End Lagna: ${_lagna(endResult!)}'),
                    Text('End Moon: ${_moon(endResult!)}'),
                    const SizedBox(height: 12),
                    const Text(
                      'Favorable %: verified event-rule database ఈ ZIPలో లేకపోవడంతో percentage ఊహించి చూపించడం లేదు.',
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Text(
                      'Event Report',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () async {
                              await Clipboard.setData(
                                ClipboardData(text: _eventReportText()),
                              );
                              if (!context.mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Event report copy అయింది'),
                                ),
                              );
                            },
                            icon: const Icon(Icons.copy_all_outlined),
                            label: const Text('Copy'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () async {
                              final title = placeController.text.trim().isEmpty
                                  ? 'Event Timing'
                                  : 'Event Timing - ${placeController.text.trim()}';
                              await ReportStorageService.save(
                                title: title,
                                body: _eventReportText(),
                              );
                              if (!context.mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Event report save అయింది'),
                                ),
                              );
                            },
                            icon: const Icon(Icons.save_outlined),
                            label: const Text('Save'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: () async {
                        await SharePlus.instance.share(
                          ShareParams(
                            text: _eventReportText(),
                            title: 'Annapurna Astro Vastu - Event Timing',
                          ),
                        );
                      },
                      icon: const Icon(Icons.share_outlined),
                      label: const Text('Share Event Report'),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}

class _TimeBlock extends StatelessWidget {
  final String title;
  final DateTime date;
  final TimeOfDay time;
  final TextEditingController secondsController;
  final VoidCallback onDate;
  final VoidCallback onTime;

  const _TimeBlock({
    required this.title,
    required this.date,
    required this.time,
    required this.secondsController,
    required this.onDate,
    required this.onTime,
  });

  String _two(int v) => v.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onDate,
                    icon: const Icon(Icons.calendar_month),
                    label: Text('${_two(date.day)}-${_two(date.month)}-${date.year}'),
                  ),
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onTime,
                    icon: const Icon(Icons.access_time),
                    label: Text('${_two(time.hour)}:${_two(time.minute)}'),
                  ),
                ),
                const SizedBox(width: 6),
                SizedBox(
                  width: 80,
                  child: TextField(
                    controller: secondsController,
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(2)],
                    decoration: const InputDecoration(labelText: 'Sec', border: OutlineInputBorder()),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
