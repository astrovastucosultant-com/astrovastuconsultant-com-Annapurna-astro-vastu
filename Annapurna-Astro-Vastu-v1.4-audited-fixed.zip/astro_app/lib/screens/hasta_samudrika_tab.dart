import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../astrology/hasta_samudrika_service.dart';

class HastaSamudrikaTab extends StatefulWidget {
  const HastaSamudrikaTab({super.key});

  @override
  State<HastaSamudrikaTab> createState() => _HastaSamudrikaTabState();
}

class _HastaPhoto {
  final String name;
  final Uint8List bytes;
  String role;

  _HastaPhoto({required this.name, required this.bytes, required this.role});
}

class _HastaSamudrikaTabState extends State<HastaSamudrikaTab> {
  static const _roles = <String>[
    'కుడి అరచేతి — పూర్తి ఫోటో',
    'ఎడమ అరచేతి — పూర్తి ఫోటో',
    'వేళ్లు / గోర్లు — close-up',
    'బొటనవేలు / side angle',
    'ప్రత్యేక రేఖ / గుర్తు — close-up',
  ];

  final _picker = ImagePicker();
  final List<_HastaPhoto> _photos = [];
  final Set<String> _selectedRules = <String>{};
  String _category = HastaSamudrikaService.categories.first;
  bool _showResults = false;
  bool _picking = false;

  Future<void> _browsePhotos() async {
    if (_picking) return;
    setState(() => _picking = true);
    try {
      final picked = await _picker.pickMultiImage(
        imageQuality: 92,
      );
      if (!mounted || picked.isEmpty) return;
      final remaining = 5 - _photos.length;
      if (remaining <= 0) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('గరిష్ఠంగా 5 ఫోటోలు మాత్రమే ఉంచవచ్చు.')),
        );
        return;
      }
      final take = picked.take(remaining).toList(growable: false);
      final loaded = <_HastaPhoto>[];
      for (var i = 0; i < take.length; i++) {
        final x = take[i];
        final bytes = await x.readAsBytes();
        final roleIndex = (_photos.length + i).clamp(0, _roles.length - 1).toInt();
        loaded.add(_HastaPhoto(
          name: x.name,
          bytes: bytes,
          role: _roles[roleIndex],
        ));
      }
      if (!mounted) return;
      setState(() => _photos.addAll(loaded));
      if (picked.length > remaining) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('మొదటి 5 ఫోటోలు మాత్రమే తీసుకున్నాం.')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('ఫోటోలు ఎంచుకోవడం సాధ్యపడలేదు: $e')),
      );
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  void _openPhoto(_HastaPhoto photo) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 6, 6),
              child: Row(
                children: [
                  Expanded(
                    child: Text(photo.role, style: const TextStyle(fontWeight: FontWeight.w800)),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            Flexible(
              child: InteractiveViewer(
                minScale: 0.8,
                maxScale: 5,
                child: Image.memory(photo.bytes, fit: BoxFit.contain),
              ),
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  void _showRule(HastaSamudrikaRule rule) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.of(sheetContext).viewPadding.bottom + 36,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(rule.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('Rule ID: ${rule.id}', style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF7B1E2B))),
              const SizedBox(height: 12),
              const Text('ఫోటోలో చూడవలసిన లక్షణం', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(rule.evidence, style: const TextStyle(height: 1.45)),
              const SizedBox(height: 14),
              const Text('సాంప్రదాయ ఫలితం / సూచన', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(rule.interpretation, style: const TextStyle(height: 1.45)),
              const SizedBox(height: 14),
              Text('${HastaSamudrikaService.sourceBook} • ${rule.source}', style: const TextStyle(fontSize: 12.5, color: Color(0xFF65585A))),
              if (!rule.finalResultReady) ...[
                const SizedBox(height: 12),
                const Card(
                  color: Color(0xFFFFF4DB),
                  surfaceTintColor: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Text(
                      'ఈ entry sourceలో ఆకారాన్ని/గుర్తును గుర్తించడానికి ఉపయోగపడుతుంది. దీని పూర్తి ఫలితం location-specific లేదా line-specific rule వచ్చినప్పుడు మాత్రమే finalగా చూపాలి.',
                      style: TextStyle(height: 1.45),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final categoryRules = HastaSamudrikaService.rules
        .where((r) => r.category == _category)
        .toList(growable: false);
    final selected = HastaSamudrikaService.selected(_selectedRules);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('హస్త సాముద్రికం', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text(
          '4–5 స్పష్టమైన ఫోటోలు పెట్టడం ఉత్తమం. ప్రస్తుతం source-based guided analysis ఉంది; ఫోటోలో కనిపించిన లక్షణాలను mark చేస్తే Result → Rule → Source flowలో చూపుతుంది.',
          style: TextStyle(height: 1.45),
        ),
        const SizedBox(height: 12),
        const Card(
          color: Color(0xFFFFF4DB),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.all(13),
            child: Text(
              'గమనిక: ఇది సంప్రదాయ హస్తసాముద్రిక వ్యాఖ్యానం మాత్రమే. వైద్య, మానసిక లేదా శాస్త్రీయ నిర్ధారణ కాదు. Automatic palm-line AI recognition ఇంకా ఈ buildలో connect చేయలేదు; అందువల్ల కనిపించిన లక్షణాన్ని consultant/user confirm చేసిన తరువాతే rule fire అవుతుంది.',
              style: TextStyle(height: 1.45),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _photos.length >= 5 || _picking ? null : _browsePhotos,
                icon: _picking
                    ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.photo_library_outlined),
                label: Text(_photos.isEmpty ? 'ఫోటోలు Browse చేయండి (గరిష్ఠం 5)' : 'మరిన్ని ఫోటోలు (${_photos.length}/5)'),
              ),
            ),
            if (_photos.isNotEmpty) ...[
              const SizedBox(width: 8),
              IconButton.filledTonal(
                tooltip: 'అన్ని ఫోటోలు తొలగించండి',
                onPressed: () => setState(() => _photos.clear()),
                icon: const Icon(Icons.delete_outline),
              ),
            ],
          ],
        ),
        if (_photos.length < 4) ...[
          const SizedBox(height: 8),
          Text(
            'సిఫార్సు: ఇంకా ${4 - _photos.length} ఫోటో${4 - _photos.length == 1 ? '' : 'లు'} జోడిస్తే పూర్తి పరిశీలనకు మంచిది.',
            style: const TextStyle(fontSize: 12.5, color: Color(0xFF765A21)),
          ),
        ],
        if (_photos.isNotEmpty) ...[
          const SizedBox(height: 14),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 0.80,
            ),
            itemCount: _photos.length,
            itemBuilder: (context, index) {
              final photo = _photos[index];
              return Card(
                clipBehavior: Clip.antiAlias,
                color: Colors.white,
                surfaceTintColor: Colors.transparent,
                child: Column(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () => _openPhoto(photo),
                        child: SizedBox.expand(child: Image.memory(photo.bytes, fit: BoxFit.cover)),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 6, 8, 2),
                      child: DropdownButtonFormField<String>(
                        value: photo.role,
                        isDense: true,
                        decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Photo type'),
                        items: _roles.map((r) => DropdownMenuItem(value: r, child: Text(r, overflow: TextOverflow.ellipsis))).toList(),
                        onChanged: (v) {
                          if (v == null) return;
                          setState(() => photo.role = v);
                        },
                      ),
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: IconButton(
                        tooltip: 'ఈ ఫోటో తొలగించండి',
                        onPressed: () => setState(() => _photos.removeAt(index)),
                        icon: const Icon(Icons.close),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
        const SizedBox(height: 18),
        const Divider(),
        const SizedBox(height: 10),
        const Text('ఫోటోలో కనిపించిన లక్షణాలు', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('ముందుగా category ఎంచుకుని, ఫోటోలో నిజంగా కనిపించిన లక్షణాలను మాత్రమే mark చేయండి.'),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: HastaSamudrikaService.categories.map((c) {
            return ChoiceChip(
              label: Text(c),
              selected: c == _category,
              onSelected: (_) => setState(() => _category = c),
            );
          }).toList(),
        ),
        const SizedBox(height: 12),
        ...categoryRules.map(
          (rule) => Card(
            color: Colors.white,
            surfaceTintColor: Colors.transparent,
            child: CheckboxListTile(
              value: _selectedRules.contains(rule.id),
              controlAffinity: ListTileControlAffinity.leading,
              title: Text(rule.title, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${rule.id} • ${rule.source}'),
              secondary: IconButton(
                tooltip: 'Rule / Source',
                onPressed: () => _showRule(rule),
                icon: const Icon(Icons.menu_book_outlined),
              ),
              onChanged: (v) {
                setState(() {
                  if (v == true) {
                    _selectedRules.add(rule.id);
                  } else {
                    _selectedRules.remove(rule.id);
                  }
                  _showResults = false;
                });
              },
            ),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: _selectedRules.isEmpty ? null : () => setState(() => _showResults = true),
          icon: const Icon(Icons.auto_awesome_outlined),
          label: Text('ఫలితాలు చూపండి (${_selectedRules.length})'),
        ),
        if (_showResults) ...[
          const SizedBox(height: 18),
          const Text('జాతకునికి / చేతికి గుర్తించిన ఫలితాలు', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          ...selected.map(
            (rule) => Card(
              color: rule.finalResultReady ? const Color(0xFFEFF8F1) : const Color(0xFFFFF4DB),
              surfaceTintColor: Colors.transparent,
              child: ListTile(
                onTap: () => _showRule(rule),
                leading: Icon(rule.finalResultReady ? Icons.check_circle_outline : Icons.info_outline),
                title: Text(rule.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text(rule.interpretation, maxLines: 4, overflow: TextOverflow.ellipsis),
                trailing: const Text('Rule', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF7B1E2B))),
              ),
            ),
          ),
        ],
        const SizedBox(height: 30),
      ],
    );
  }
}
