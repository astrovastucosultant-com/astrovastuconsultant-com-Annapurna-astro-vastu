import '../models/birth_data.dart';
import '../astrology/western_progression_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Western progression chart analysis on Android.
/// Event contacts are interpretive evidence; not a birth-time rectification.
class ProgressionAnalysisScreen extends StatelessWidget {
  const ProgressionAnalysisScreen({super.key, required this.birthData});
  final BirthData birthData;

  static const methods = <_ProgressionMethod>[
    _ProgressionMethod('BNN / BPD — గ్రహ చక్రాల పరిశీలన',
      'BTR సందర్భ ఆధారాలు: BNN గురు చక్రం, BPD గ్రహ చక్రాలు. ఇవి ఒక్కటే జనన సెకన్లను నిర్ణయించవు.',
      'Flutter BTR సేవలలో సందర్భ పరిశీలన ఉంది; ఈ ట్యాబ్‌లో ప్రత్యక్ష కొత్త గణన లేదు.'),
    _ProgressionMethod('Western Secondary Progression',
      'Secondary progressionలో సాంప్రదాయంగా జననం తర్వాత ఒక రోజు = జీవితంలో ఒక సంవత్సరం అనే కాల ప్రమాణాన్ని ఉపయోగిస్తారు.',
      'ఫోన్‌లో Swiss Ephemeris ఆధారంగా Secondary contacts గణన అందుబాటులో ఉంది.'),
    _ProgressionMethod('Solar Arc Directions',
      'Solar Arc పద్ధతిలో గ్రహాలకు సూర్యుని ప్రోగ్రెస్‌డ్ ఆర్క్ ఆధారంగా దిశా మార్పు పరిశీలిస్తారు.',
      'ఫోన్‌లో Swiss Ephemeris ఆధారంగా Solar Arc contacts గణన అందుబాటులో ఉంది.'),
    _ProgressionMethod('Naibod Directions',
      'Naibod ఆధారిత దిశా పద్ధతిని ప్రత్యేకంగా పరిశీలించి సంఘటన తేదీలతో పోల్చాలి.',
      'Naibod axes Flutterలో ఇంకా అమలు కాలేదు.'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('BTR — Progression Analysis')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      WesternLiveCalculation(birthData: birthData),
      const Text('Progression పద్ధతుల పరిశీలన',
        style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Secondary Progression + Solar Arc లైవ్ గణనలు; 1 రోజు = 1 సంవత్సరం, Tropical. Naibod / Tertiary ఇంకా అమలు కాలేదు.'),
      const SizedBox(height: 14),
      Card(child: ListTile(leading: const Icon(Icons.event_available), title: const Text('Timing of Event — సంఘటన సమయం'), subtitle: const Text('సంఘటన ఎంచుకుని Search చేయండి; గణన స్థితిని చూడండి'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TimingOfEventScreen())))),
      const SizedBox(height: 14),
      for (final method in methods) Card(
        child: ExpansionTile(
          title: Text(method.title, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: const Text('పద్ధతి వివరాలు — పైన ప్రత్యక్ష గణన చూడండి'),
          childrenPadding: const EdgeInsets.all(16),
          children: [
            Align(alignment: Alignment.centerLeft, child: SelectableText(method.description)),
            const SizedBox(height: 10),
            Align(alignment: Alignment.centerLeft, child: SelectableText(method.status)),
            const SizedBox(height: 10),
            Align(alignment: Alignment.centerRight, child: TextButton.icon(
              icon: const Icon(Icons.copy), label: const Text('వివరాలు కాపీ'),
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text:
                  '${method.title}\n${method.description}\n${method.status}'));
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('వివరాలు కాపీ అయ్యాయి')));
              },
            )),
          ],
        ),
      ),
      const SizedBox(height: 12),
      const Text('గత సంఘటనలతో పద్ధతుల ఫలితాలు సరిపోల్చే పూర్తి Flutter calculation, source-rule verification, holdout testing ఇంకా అవసరం. ఏ స్కోరునూ ఖచ్చితత్వ శాతంగా పరిగణించవద్దు.'),
    ]),
  );
}

class _ProgressionMethod {
  final String title;
  final String description;
  final String status;
  const _ProgressionMethod(this.title, this.description, this.status);
}


/// Honest event-search interface. No speculative dates are generated.
class TimingOfEventScreen extends StatefulWidget {
  const TimingOfEventScreen({super.key});
  @override
  State<TimingOfEventScreen> createState() => _TimingOfEventScreenState();
}
class _TimingOfEventScreenState extends State<TimingOfEventScreen> {
  static const events = <String>[
    'వివాహం', 'ప్రేమ వివాహం', 'నిశ్చితార్థం', 'ఉద్యోగం', 'ప్రభుత్వ ఉద్యోగం',
    'ప్రమోషన్', 'ఉద్యోగ మార్పు', 'వ్యాపారం / స్వయం ఉపాధి', 'సంతానం',
    'గర్భధారణ', 'విద్య', 'పరీక్షలో విజయం', 'విదేశీ ప్రయాణం',
    'ఆస్తి కొనుగోలు', 'ఇంటి నిర్మాణం', 'వాహనం', 'ధనలాభం',
    'రుణ విముక్తి', 'ఆరోగ్యం', 'కోర్టు వ్యవహారం', 'బదిలీ', 'పదవీ విరమణ',
  ];
  String selected = events.first;
  DateTime start = DateTime.now();
  DateTime end = DateTime.now().add(const Duration(days: 365));
  bool searched = false;
  Future<void> pickDate(bool isStart) async {
    final initial = isStart ? start : end;
    final value = await showDatePicker(context: context, initialDate: initial,
      firstDate: DateTime(1900), lastDate: DateTime(2100));
    if (value != null && mounted) setState(() {
      if (isStart) { start = value; if (end.isBefore(start)) end = start; }
      else { end = value; if (start.isAfter(end)) start = end; }
      searched = false;
    });
  }
  String date(DateTime d) => '${d.day.toString().padLeft(2,'0')}-${d.month.toString().padLeft(2,'0')}-${d.year}';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Timing of Event — సంఘటన సమయం')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('సంఘటన ఎంపిక → Search', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: selected, isExpanded: true,
        decoration: const InputDecoration(labelText: 'కావాల్సిన సంఘటన', border: OutlineInputBorder()),
        items: [for (final event in events) DropdownMenuItem(value: event, child: Text(event, overflow: TextOverflow.ellipsis))],
        onChanged: (v) { if (v != null) setState(() {selected = v; searched = false;}); }),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: OutlinedButton(onPressed: () => pickDate(true), child: Text('నుంచి: ${date(start)}'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton(onPressed: () => pickDate(false), child: Text('వరకు: ${date(end)}'))),
      ]),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => setState(() => searched = true),
        icon: const Icon(Icons.search), label: const Text('Search — అనుకూల సమయం పరిశీలన')),
      if (searched) ...[
        const SizedBox(height: 20),
        Text('ఎంచుకున్న సంఘటన: $selected', style: const TextStyle(fontWeight: FontWeight.bold)),
        Text('కాలపరిమితి: ${date(start)} — ${date(end)}'),
        const SizedBox(height: 12),
        const Card(child: Padding(padding: EdgeInsets.all(16), child: Text(
          'గణన ఇంకా అందుబాటులో లేదు. జనన వివరాలు, ధృవీకరించిన గ్రహస్థితులు, సంఘటన-ఆధారిత నియమాలు మరియు Timing engine ను Flutterకు అనుసంధానించిన తర్వాత మాత్రమే సంవత్సరం / నెల / తేదీ ఫలితాలు ఇవ్వగలం. ఊహాత్మక తేదీలను చూపించడం లేదు.'))),
      ],
      const SizedBox(height: 20),
      const Text('ఈ స్క్రీన్ సంఘటన ఎంపిక మరియు Search UI మాత్రమే. Python పరిశోధన ఫలితాలు ప్రత్యక్ష Android ఫలితాలు కావు. జ్యోతిష్య సమయ సూచనలు శాస్త్రీయంగా నిర్ధారిత భవిష్యవాణులు కావు.'),
    ]),
  );
}

/// Live tropical Swiss Ephemeris calculations on Android; no Python runtime.
class WesternLiveCalculation extends StatefulWidget {
  const WesternLiveCalculation({super.key, required this.birthData});
  final BirthData birthData;
  @override
  State<WesternLiveCalculation> createState() => _WesternLiveCalculationState();
}

class _WesternLiveCalculationState extends State<WesternLiveCalculation> {
  DateTime eventDate = DateTime.now();
  double orb = 0.5;
  String eventCategory = 'వివాహం';
  WesternProgressionResult? result;
  List<WesternExactContact>? exactDates;
  String? error;
  bool loading = false;
  bool findingDates = false;

  String formatDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-${d.year}';

  Future<void> calculate() async {
    setState(() {
      loading = true;
      result = null;
      exactDates = null;
      error = null;
    });
    try {
      final value = await WesternProgressionService.calculate(
        widget.birthData, eventDate, orb: orb,
      );
      if (mounted) setState(() { result = value; loading = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); loading = false; });
    }
  }

  Future<void> findExactDates() async {
    setState(() { findingDates = true; exactDates = null; error = null; });
    try {
      final dates = await WesternProgressionService.exactContacts(
        widget.birthData, eventDate,
      );
      if (mounted) setState(() { exactDates = dates; findingDates = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); findingDates = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Western Progression — ప్రత్యక్ష గణన',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Swiss Ephemeris • Tropical • Moshier • Placidus జన్మ ASC/MC'),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: eventCategory,
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'గత సంఘటన రకం (పరిశీలన కోసం)',
            border: OutlineInputBorder(),
          ),
          items: [
            for (final label in const <String>[
              'వివాహం', 'ఉద్యోగం', 'వ్యాపారం', 'సంతానం',
              'విదేశీ ప్రయాణం', 'ఆస్తి', 'ఇతర సంఘటన',
            ]) DropdownMenuItem(value: label, child: Text(label)),
          ],
          onChanged: (value) {
            if (value != null) setState(() => eventCategory = value);
          },
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          icon: const Icon(Icons.calendar_month),
          label: Text('సంఘటన తేదీ: ${formatDate(eventDate)}'),
          onPressed: () async {
            final selected = await showDatePicker(
              context: context, initialDate: eventDate,
              firstDate: DateTime(1900), lastDate: DateTime(2100),
            );
            if (selected != null && mounted) {
              setState(() {
                eventDate = selected;
                result = null;
                exactDates = null;
              });
            }
          },
        ),
        Row(children: [
          const Text('Aspect Orb:'),
          const SizedBox(width: 12),
          DropdownButton<double>(
            value: orb,
            items: const <DropdownMenuItem<double>>[
              DropdownMenuItem(value: 0.25, child: Text('0.25°')),
              DropdownMenuItem(value: 0.5, child: Text('0.5°')),
              DropdownMenuItem(value: 1.0, child: Text('1°')),
              DropdownMenuItem(value: 2.0, child: Text('2°')),
            ],
            onChanged: (value) {
              if (value != null) setState(() {
                orb = value;
                result = null;
              });
            },
          ),
        ]),
        FilledButton.icon(
          onPressed: loading || findingDates ? null : calculate,
          icon: const Icon(Icons.calculate),
          label: const Text('Secondary + Solar Arc గణించండి'),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: loading || findingDates ? null : findExactDates,
          icon: const Icon(Icons.event_available),
          label: const Text('సమీప Exact Aspect Dates చూడండి'),
        ),
        if (loading || findingDates) const LinearProgressIndicator(),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
        if (result != null) ...[
          const Divider(),
          Text('పరిశీలిస్తున్న సంఘటన: $eventCategory'),
          Text('వయస్సు: ${result!.ageYears.toStringAsFixed(3)} సంవత్సరాలు'),
          Text('Solar Arc: ${result!.solarArc.toStringAsFixed(4)}°'),
          Text('Progressed Moon (Tropical): '
              '${result!.progressedMoon.toStringAsFixed(4)}°'),
          const Divider(),
          const Text('Secondary → Natal contacts',
              style: TextStyle(fontWeight: FontWeight.bold)),
          for (final contact in result!.secondaryContacts) Text('• $contact'),
          if (result!.secondaryContacts.isEmpty)
            const Text('ఎంచుకున్న Orbలో Secondary contacts లేవు'),
          const Divider(),
          const Text('Solar Arc → Natal contacts',
              style: TextStyle(fontWeight: FontWeight.bold)),
          for (final contact in result!.solarArcContacts) Text('• $contact'),
          if (result!.solarArcContacts.isEmpty)
            const Text('ఎంచుకున్న Orbలో Solar Arc contacts లేవు'),
        ],
        if (exactDates != null) ...[
          const Divider(),
          Text('సంఘటన తేదీకి ±180 రోజుల్లో Exact Aspects '
              '(${exactDates!.length} వరకు చూపిస్తున్నాం)',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          for (final entry in exactDates!) ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('${entry.source} → ${entry.target}: '
                '${entry.aspect}'),
            subtitle: Text('${entry.method} • ${formatDate(entry.date)} '
                '(UTC)'),
          ),
          if (exactDates!.isEmpty)
            const Text('ఈ పరిధిలో ఖచ్చితమైన Aspect crossing కనబడలేదు'),
        ],
        const Divider(),
        const Text('Exact Aspect Date అనేది గ్రహకోణం ఖచ్చితమయ్యే తేదీ; '
            'సంఘటన తప్పనిసరిగా జరిగే తేదీ కాదు. BTR జనన సెకన్లను '
            'ఈ లెక్కతో మార్చము. Naibod, Tertiary ఇంకా అమలు కాలేదు.'),
      ]),
    ),
  );
}
