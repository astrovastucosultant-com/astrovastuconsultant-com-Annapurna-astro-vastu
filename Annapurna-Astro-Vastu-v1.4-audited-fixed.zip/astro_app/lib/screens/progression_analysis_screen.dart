import '../models/birth_data.dart';
import 'western_btr_comparison_screen.dart';
import 'western_eight_methods_screen.dart';
import '../astrology/western_progression_service.dart';
import '../astrology/naibod_axes.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Western progression chart analysis on Android.
/// Event contacts are interpretive evidence; not a birth-time rectification.
class ProgressionAnalysisScreen extends StatelessWidget {
  const ProgressionAnalysisScreen({super.key, required this.birthData});
  final BirthData birthData;

  static const methods = <_ProgressionMethod>[
    _ProgressionMethod('Western Secondary Progression',
      'Secondary progressionలో సాంప్రదాయంగా జననం తర్వాత ఒక రోజు = జీవితంలో ఒక సంవత్సరం అనే కాల ప్రమాణాన్ని ఉపయోగిస్తారు.',
      'ఫోన్‌లో Swiss Ephemeris ఆధారంగా Secondary contacts గణన అందుబాటులో ఉంది.'),
    _ProgressionMethod('Solar Arc Directions',
      'Solar Arc పద్ధతిలో గ్రహాలకు సూర్యుని ప్రోగ్రెస్‌డ్ ఆర్క్ ఆధారంగా దిశా మార్పు పరిశీలిస్తారు.',
      'ఫోన్‌లో Swiss Ephemeris ఆధారంగా Solar Arc contacts గణన అందుబాటులో ఉంది.'),
    _ProgressionMethod('Naibod Directions',
      'Naibod ఆధారిత దిశా పద్ధతిని ప్రత్యేకంగా పరిశీలించి సంఘటన తేదీలతో పోల్చాలి.',
      'Naibod ASC / MC / DSC / IC గణన ఇప్పుడు ప్రత్యక్షంగా అందుబాటులో ఉంది.'),
    _ProgressionMethod('Tertiary Progression',
      'జననం తర్వాత ఒక రోజు = జీవితంలో ఒక సైడీరియల్ చంద్ర మాసం (సుమారు 27.32 రోజులు).',
      'గణన ఇంజిన్ ఇంకా లేదు; ఫలితాల్లో ఉపయోగించబడదు.'),
    _ProgressionMethod('Minor Progression',
      'జననం తర్వాత ఒక చంద్ర మాసం = జీవితంలో ఒక సంవత్సరం; lunar-month convention నిర్దేశించాలి.',
      'గణన ఇంజిన్ ఇంకా లేదు; ఫలితాల్లో ఉపయోగించబడదు.'),
    _ProgressionMethod('One-Degree Direction',
      'ప్రతి జీవిత సంవత్సరానికి 1° symbolic arc; Naibod mean solar arcతో సమానం కాదు.',
      'ప్రత్యేక 1° గణన ఇంజిన్ ఇంకా లేదు.'),
    _ProgressionMethod('Primary Directions',
      'భూమి భ్రమణం, right ascension, declination, semi-arcs ఆధారిత గణన.',
      'పూర్తి primary direction ఇంజిన్ ఇంకా లేదు.'),
    _ProgressionMethod('Converse Progression',
      'జననానికి ముందు రోజుల గ్రహస్థితుల ఆధారంగా converse progression.',
      'ప్రత్యేక converse ఇంజిన్ ఇంకా లేదు.'),
    _ProgressionMethod('Annual Profection',
      'ప్రతి జన్మదినానికి లగ్నం నుంచి ఒక రాశి; 12 సంవత్సరాలకు చక్రం.',
      'వార్షిక profection time lord గణన ఇంకా లేదు.')
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Western Progression — Independent')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      WesternLiveCalculation(birthData: birthData),
      Card(child: ListTile(
        leading: const Icon(Icons.calculate_outlined),
        title: const Text('Western Method Calculations'),
        subtitle: const Text('Secondary, Tertiary, Minor, Solar Arc, Naibod, 1°, Converse, Profection'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => WesternEightMethodsScreen(birthData: birthData))),
      )),
      Card(child: ListTile(
        leading: const Icon(Icons.fact_check_outlined),
        title: const Text('Western BTR — గత సంఘటనల పోలిక'),
        subtitle: const Text('జనన సమయ అభ్యర్థులను గత సంఘటనలతో పోల్చండి'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => WesternBtrComparisonScreen(birthData: birthData))),
      )),
      const Text('స్వతంత్ర Western Progression పరిశీలన',
        style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Secondary Progression + Solar Arc లైవ్ గణనలు; 1 రోజు = 1 సంవత్సరం, Tropical. Tertiary ఇంకా అమలు కాలేదు; Naibod Axes అందుబాటులో ఉన్నాయి.'),
      const SizedBox(height: 14),
      Card(child: ListTile(leading: const Icon(Icons.event_available), title: const Text('Timing of Event — సంఘటన సమయం'), subtitle: const Text('సంఘటన ఎంచుకుని Search చేయండి; గణన స్థితిని చూడండి'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TimingOfEventScreen(birthData: birthData))))),
      const SizedBox(height: 14),
      for (final method in methods) Card(
        child: ExpansionTile(
          title: Text(method.title, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: const Text('పద్ధతి వివరాలు — పైన ప్రత్యక్ష గణన చూడండి'),
          childrenPadding: const EdgeInsets.all(16),
          children: [
            Align(alignment: Alignment.centerLeft, child: SelectableText(method.description)),
            const SizedBox(height: 10),
            Align(alignment: Alignment.centerLeft, child: SelectableText(method.status)),
            const SizedBox(height: 10),
            Align(alignment: Alignment.centerRight, child: TextButton.icon(
              icon: const Icon(Icons.copy), label: const Text('వివరాలు కాపీ'),
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text:
                  '${method.title}\n${method.description}\n${method.status}'));
                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('వివరాలు కాపీ అయ్యాయి')));
              },
            )),
          ],
        ),
      ),
      const SizedBox(height: 12),
      const Text('ఈ స్క్రీన్ Western Progression గణనకు మాత్రమే. ఇతర జ్యోతిష్య పద్ధతులు ఈ ఫలితాన్ని మార్చవు. Exact contacts సంఘటన నిర్ధారణ కాదు.'),
    ]),
  );
}

class _ProgressionMethod {
  final String title;
  final String description;
  final String status;
  const _ProgressionMethod(this.title, this.description, this.status);
}


/// Event-specific on-device timing evidence, with natal chart inputs
/// forwarded explicitly from the current saved horoscope. This is NOT an
/// event prediction or a proof of birth-time rectification.
class TimingOfEventScreen extends StatefulWidget {
  const TimingOfEventScreen({super.key, required this.birthData});
  final BirthData birthData;

  @override
  State<TimingOfEventScreen> createState() => _TimingOfEventScreenState();
}

class _TimingOfEventScreenState extends State<TimingOfEventScreen> {
  static const events = <String>[
    'వివాహం', 'ప్రేమ వివాహం', 'నిశ్చితార్థం', 'ఉద్యోగం', 'ప్రభుత్వ ఉద్యోగం',
    'ప్రమోషన్', 'ఉద్యోగ మార్పు', 'వ్యాపారం / స్వయం ఉపాధి', 'సంతానం',
    'గర్భధారణ', 'విద్య', 'పరీక్షలో విజయం', 'విదేశీ ప్రయాణం',
    'ఆస్తి కొనుగోలు', 'ఇంటి నిర్మాణం', 'వాహనం', 'ధనలాభం',
    'రుణ విముక్తి', 'ఆరోగ్యం', 'కోర్టు వ్యవహారం', 'బదిలీ', 'పదవీ విరమణ',
    'బాల్యం', 'కుటుంబ మార్పులు', 'ఉన్నత విద్య', 'ఆర్థిక మార్పులు', 'జీవిత మార్పులు',
  ];

  String selected = events.first;
  DateTime start = DateTime.now();
  DateTime end = DateTime.now().add(const Duration(days: 365));
  bool lifeMode = false;
  bool customRange = false;
  int lifeYears = 80;
  bool searching = false;
  bool searched = false;
  String? error;
  List<WesternExactContact>? contacts;

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-${d.year}';

  String _localDate(DateTime utcDate) {
    final local = utcDate.toUtc().add(Duration(
      minutes: (widget.birthData.timezoneOffsetHours * 60).round(),
    ));
    return '${_date(local)} '
        '${local.hour.toString().padLeft(2, '0')}:'
        '${local.minute.toString().padLeft(2, '0')}';
  }

  DateTime _localTime(DateTime utcDate) {
    final wallTime = utcDate.toUtc().add(Duration(
      minutes: (widget.birthData.timezoneOffsetHours * 60).round(),
    ));
    // DashaService periods use birth.localDateTime (local wall-clock).
    return DateTime(wallTime.year, wallTime.month, wallTime.day,
        wallTime.hour, wallTime.minute, wallTime.second);
  }

  Future<void> pickDate(bool isStart) async {
    final initial = isStart ? start : end;
    final value = await showDatePicker(
      context: context, initialDate: initial,
      firstDate: DateTime(1900), lastDate: DateTime(2100),
    );
    if (value != null && mounted) {
      setState(() {
        if (isStart) {
          start = value;
          if (end.isBefore(start)) end = start;
        } else {
          end = value;
          if (start.isAfter(end)) start = end;
        }
        searched = false;
        contacts = null;
      });
    }
  }

  Future<void> _search() async {
    setState(() {
      searching = true;
      searched = false;
      contacts = null;
      error = null;
    });
    try {
      // Calculates actual ephemeris aspect crossings for the selected dates.
      final List<WesternExactContact> found = [];
      if (lifeMode || customRange) {
        final birth = widget.birthData.localDateTime;
        final limit = lifeMode
            ? DateTime(birth.year + lifeYears, birth.month, birth.day)
            : end;
        var cursor = lifeMode
            ? DateTime(birth.year, birth.month, birth.day)
            : start;
        while (cursor.isBefore(limit)) {
          final next = DateTime(cursor.year + 1, cursor.month, cursor.day);
          final stop = next.isAfter(limit) ? limit : next;
          final batch = await WesternProgressionService.contactsInEventRange(
            widget.birthData, selected, cursor, stop, maxResults: 40,
          );
          found.addAll(batch);
          cursor = stop;
          if (!mounted) return;
          await Future<void>.delayed(Duration.zero);
        }
        found.sort((a, b) => a.date.compareTo(b.date));
        // Adjacent scan windows may both include a boundary crossing.
        final seen = <String>{};
        found.removeWhere((c) => !seen.add(
          '${c.date.toUtc().millisecondsSinceEpoch}:${c.toString()}'));
      } else {
        found.addAll(await WesternProgressionService.contactsInEventRange(
          widget.birthData, selected, start, end,
        ));
      }
      if (!mounted) return;
      setState(() {
        contacts = found;
        searched = true;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = 'Search పూర్తికాలేదు: $e'; });
    } finally {
      if (mounted) setState(() => searching = false);
    }
  }

  // Interpretive Western-only classification; never assert an actual event.
  static const Map<String, List<String>> _eventBodies = {
    'వివాహం': ['Venus', 'Moon', 'DESC'],
    'ప్రేమ వివాహం': ['Venus', 'Moon', 'DESC'],
    'నిశ్చితార్థం': ['Venus', 'DESC'],
    'సంతానం': ['Moon', 'Jupiter', 'IC'],
    'గర్భధారణ': ['Moon', 'Jupiter', 'IC'],
    'ఉద్యోగం': ['Sun', 'Saturn', 'MC'],
    'ప్రభుత్వ ఉద్యోగం': ['Sun', 'Saturn', 'MC'],
    'ప్రమోషన్': ['Sun', 'Jupiter', 'MC'],
    'ఉద్యోగ మార్పు': ['Sun', 'Uranus', 'MC'],
    'వ్యాపారం / స్వయం ఉపాధి': ['Sun', 'Jupiter', 'MC'],
    'విద్య': ['Mercury', 'Jupiter'],
    'ఉన్నత విద్య': ['Mercury', 'Jupiter'],
    'ఆస్తి కొనుగోలు': ['Moon', 'Saturn', 'IC'],
    'ఇంటి నిర్మాణం': ['Moon', 'Saturn', 'IC'],
    'వాహనం': ['Mercury', 'Venus', 'IC'],
    'ధనలాభం': ['Venus', 'Jupiter'],
    'ఆర్థిక మార్పులు': ['Venus', 'Jupiter', 'Saturn'],
    'విదేశీ ప్రయాణం': ['Mercury', 'Jupiter'],
    'ఆరోగ్యం': ['Sun', 'Moon', 'ASC'],
    'జీవిత మార్పులు': ['Sun', 'Moon', 'ASC', 'MC'],
  };

  List<String> _themes(WesternExactContact item) {
    final involved = <String>{item.source, item.target};
    return _eventBodies.entries
        .where((e) => e.value.any(involved.contains))
        .map((e) => e.key).toList();
  }

  String _tone(WesternExactContact item) {
    switch (item.aspect) {
      case 'Trine':
      case 'Sextile':
        return 'సాంప్రదాయ వ్యాఖ్యానం: సులభ ప్రవాహం / అనుకూల సూచన';
      case 'Square':
      case 'Opposition':
        return 'సాంప్రదాయ వ్యాఖ్యానం: ఒత్తిడి / మార్పు సూచన';
      case 'Conjunction':
        return 'సాంప్రదాయ వ్యాఖ్యానం: తీవ్రత / కొత్త దశ; శుభాశుభం నిర్ణయించలేం';
      default:
        return 'శుభాశుభం నిర్ణయించడానికి ఆధారం సరిపోదు';
    }
  }

  String _eventRelevance(WesternExactContact item) {
    final selectedBodies = _eventBodies[selected];
    if (selectedBodies == null) return 'ఈ సంఘటనకు ప్రత్యేక Western గ్రహ-అక్ష నియమం ఇంకా లేదు.';
    if (selectedBodies.contains(item.source) || selectedBodies.contains(item.target)) {
      return 'ఎంచుకున్న అంశానికి సంబంధిత గ్రహం/అక్షం ఉంది; సంఘటన నిర్ధారణ కాదు.';
    }
    return 'ఎంచుకున్న సంఘటనకు ప్రత్యక్ష గ్రహ-అక్ష సంబంధం కనిపించలేదు.';
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Western Progression — Independent')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Western Progression → Search',
        style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text('జాతకుడు: ${widget.birthData.name} • '
          'జననం: ${_date(widget.birthData.localDateTime)} • '
          '${widget.birthData.place}'),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(
        value: selected, isExpanded: true,
        decoration: const InputDecoration(
          labelText: 'కావాల్సిన సంఘటన', border: OutlineInputBorder()),
        items: [for (final event in events) DropdownMenuItem(
          value: event, child: Text(event, overflow: TextOverflow.ellipsis))],
        onChanged: searching ? null : (v) {
          if (v != null) setState(() {
            selected = v;
            contacts = null;
            searched = false;
          });
        },
      ),
      const SizedBox(height: 12),
      SwitchListTile(
        title: const Text('జననం నుంచి జీవితకాల పరిశీలన'),
        subtitle: const Text('ఎంచుకున్న సంఘటనకు దీర్ఘకాల గ్రహకోణ పరిశీలన'),
        value: lifeMode,
        onChanged: searching ? null : (v) => setState(() {
          lifeMode = v; searched = false; contacts = null;
        }),
      ),
      if (lifeMode) DropdownButtonFormField<int>(
        value: lifeYears,
        decoration: const InputDecoration(labelText: 'పరిశీలన వయస్సు వరకు', border: OutlineInputBorder()),
        items: [40, 60, 80, 100].map((n) =>
          DropdownMenuItem(value: n, child: Text('$n సంవత్సరాలు'))).toList(),
        onChanged: searching ? null : (v) {
          if (v != null) setState(() { lifeYears = v; searched = false; });
        },
      ),
      const SizedBox(height: 12),
      if (!lifeMode) SwitchListTile(
        title: const Text('Custom Date Range — సంవత్సరాల మధ్య పరిశీలన'),
        subtitle: const Text('ప్రారంభ తేదీ నుంచి ముగింపు తేదీ వరకు; రెండు సంవత్సరాలకు మించి కూడా'),
        value: customRange,
        onChanged: searching ? null : (v) => setState(() {
          customRange = v; searched = false; contacts = null;
        }),
      ),
      if (!lifeMode) Row(children: [
        Expanded(child: OutlinedButton(
          onPressed: searching ? null : () => pickDate(true),
          child: Text('నుంచి: ${_date(start)}'))),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton(
          onPressed: searching ? null : () => pickDate(false),
          child: Text('వరకు: ${_date(end)}'))),
      ]),
      const SizedBox(height: 12),
      FilledButton.icon(
        onPressed: searching ? null : _search,
        icon: const Icon(Icons.search),
        label: const Text('Search — సంఘటన సంబంధిత గ్రహకోణాలు'),
      ),
      if (searching) ...[
        const SizedBox(height: 10),
        const LinearProgressIndicator(),
        const Text('Swiss Ephemeris ద్వారా గణన జరుగుతోంది…'),
      ],
      if (error != null) ...[
        const SizedBox(height: 10),
        Text(error!, style: const TextStyle(color: Colors.red)),
      ],
      if (searched) ...[
        const SizedBox(height: 20),
        Text('ఎంచుకున్న సంఘటన: $selected',
          style: const TextStyle(fontWeight: FontWeight.bold)),
        Text(lifeMode ? 'జననం నుంచి $lifeYears సంవత్సరాలు' : 'కాలపరిమితి: ${_date(start)} — ${_date(end)}'),
        const SizedBox(height: 8),
        Card(child: Padding(padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('పరిశోధన కోసం అంశం — గ్రహకోణ సూచనలు: '
                '${contacts!.length}'),
              const SizedBox(height: 6),
              const Text('Independent Western mode: దశలు, KP, జైమిని, Mehta, BNN/BSP/BCP ఫలితాలు ఈ Searchలో ఉపయోగించబడవు.'),
            ]))),
        if (!lifeMode && contacts!.length >= 80)
          const Text('మొదటి 80 గ్రహకోణ తేదీలు మాత్రమే చూపిస్తున్నాం; '
              'మిగిలిన తేదీల కోసం Search పరిధిని తగ్గించండి.'),
        if (contacts!.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(16), child: Text(
            'ఈ కాలపరిధిలో ఎంపికైన గ్రహ సంబంధాలకు ఖచ్చితమైన '
            'Western Aspect Crossing కనిపించలేదు. దీనర్థం సంఘటన '
            'జరగదని కాదు. తేదీలను మార్చి మళ్లీ పరిశీలించవచ్చు.'))),
        const Text('ఇవి గ్రహకోణ పరిశీలన తేదీలు మాత్రమే; సంఘటనలు లేదా మరణాన్ని నిర్ధారించవు.'),
        if (contacts!.isNotEmpty) ...[
          const SizedBox(height: 8),
          const Text('సంవత్సరం / నెల / తేదీ — Exact Aspect Crossings',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          for (final item in contacts!) Card(
            child: ExpansionTile(
              title: Text(_localDate(item.date),
                style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text('${item.method}: ${item.source} → '
                '${item.target} (${item.aspect})'),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
              children: [
                const Divider(),
                ExpansionTile(
                  title: const Text('ఫలితం — సంఘటన & స్వభావం'),
                  children: [
                    ListTile(title: Text('సంబంధిత అంశాలు: ${_themes(item).isEmpty ? 'ప్రత్యేక వర్గీకరణ లేదు' : _themes(item).join(', ')}'),
                      subtitle: Text('${_tone(item)}\n${_eventRelevance(item)}')),
                    const ListTile(subtitle: Text('ఇది సంప్రదాయ Western వ్యాఖ్యానం మాత్రమే; వివాహం, సంతానం, ఆరోగ్యం, మరణం వంటి సంఘటనలు నిర్ధారణ కావు.')),
                  ],
                ),
                ExpansionTile(
                  title: const Text('Western Rule — గ్రహకోణ ఆధారం'),
                  children: [
                    ListTile(title: Text('${item.method}: ${item.source} → ${item.target}'),
                      subtitle: Text('Aspect: ${item.aspect}; Exact crossing: ${_localDate(item.date)}')),
                    const ListTile(subtitle: Text('Secondary: 1 రోజు = 1 సంవత్సరం; Solar Arc: progressed Sun arc. Natal-to-progressed angular contact మాత్రమే.')),
                  ],
                ),
                const ExpansionTile(
                  title: Text('జాతక పరిశీలన — Western మాత్రమే'),
                  children: [ListTile(subtitle: Text(
                    'Natal/Progressed స్థానాలు, Orb, applying/separating, sign ingress, Naibod validation ఇంకా ఈ కార్డులో సమగ్రంగా అమలు కాలేదు. ఇతర దశలు ఈ నిర్ణయంలో ఉపయోగించబడవు.'))],
                ),
                const ExpansionTile(
                  title: Text('పరిహారం'),
                  children: [ListTile(subtitle: Text(
                    'ఈ Western Aspectకు ధృవీకరించిన సంప్రదాయ పరిహార నియమం లేదు.'))],
                ),
              ],
            ),
          ),
        ],
      ],
      const SizedBox(height: 20),
      const Text('ఈ Searchలో గణించిన తేదీలు గ్రహకోణాలు '
          'ఖచ్చితమయ్యే తేదీలు మాత్రమే. వివాహం/ఉద్యోగం వంటి సంఘటనలు '
          'తప్పకుండా జరిగే తేదీలు కావు. ఇతర దశలు, వర్గచక్రాలు, '
          'BTR ఈ స్వతంత్ర గణనలో కలపబడవు.'),
    ]),
  );
}

/// Live tropical Swiss Ephemeris calculations on Android; no Python runtime.
class WesternLiveCalculation extends StatefulWidget {
  const WesternLiveCalculation({super.key, required this.birthData});
  final BirthData birthData;
  @override
  State<WesternLiveCalculation> createState() => _WesternLiveCalculationState();
}

class _WesternLiveCalculationState extends State<WesternLiveCalculation> {
  DateTime eventDate = DateTime.now();
  double orb = 0.5;
  String eventCategory = 'వివాహం';
  WesternProgressionResult? result;
  NaibodAxes? naibod;
  List<WesternExactContact>? exactDates;
  String? error;
  bool loading = false;
  bool findingDates = false;

  String formatDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-${d.year}';

  Future<void> calculate() async {
    setState(() {
      loading = true;
      result = null;
      naibod = null;
      exactDates = null;
      error = null;
    });
    try {
      final value = await WesternProgressionService.calculate(
        widget.birthData, eventDate, orb: orb,
      );
      final axes = await WesternProgressionService.naibodAxes(widget.birthData, eventDate);
      if (mounted) setState(() { result = value; naibod = axes; loading = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); loading = false; });
    }
  }

  Future<void> findExactDates() async {
    setState(() { findingDates = true; exactDates = null; error = null; });
    try {
      final dates = await WesternProgressionService.exactContacts(
        widget.birthData, eventDate,
      );
      if (mounted) setState(() { exactDates = dates; findingDates = false; });
    } catch (e) {
      if (mounted) setState(() { error = e.toString(); findingDates = false; });
    }
  }

  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Western Progression — ప్రత్యక్ష గణన',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        const Text('Swiss Ephemeris • Tropical • Moshier • Placidus జన్మ ASC/MC'),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: eventCategory,
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'గత సంఘటన రకం (పరిశీలన కోసం)',
            border: OutlineInputBorder(),
          ),
          items: [
            for (final label in const <String>[
              'వివాహం', 'ఉద్యోగం', 'వ్యాపారం', 'సంతానం',
              'విదేశీ ప్రయాణం', 'ఆస్తి', 'ఇతర సంఘటన',
            ]) DropdownMenuItem(value: label, child: Text(label)),
          ],
          onChanged: (value) {
            if (value != null) setState(() => eventCategory = value);
          },
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          icon: const Icon(Icons.calendar_month),
          label: Text('సంఘటన తేదీ: ${formatDate(eventDate)}'),
          onPressed: () async {
            final selected = await showDatePicker(
              context: context, initialDate: eventDate,
              firstDate: DateTime(1900), lastDate: DateTime(2100),
            );
            if (selected != null && mounted) {
              setState(() {
                eventDate = selected;
                result = null;
                exactDates = null;
              });
            }
          },
        ),
        Row(children: [
          const Text('Aspect Orb:'),
          const SizedBox(width: 12),
          DropdownButton<double>(
            value: orb,
            items: const <DropdownMenuItem<double>>[
              DropdownMenuItem(value: 0.25, child: Text('0.25°')),
              DropdownMenuItem(value: 0.5, child: Text('0.5°')),
              DropdownMenuItem(value: 1.0, child: Text('1°')),
              DropdownMenuItem(value: 2.0, child: Text('2°')),
            ],
            onChanged: (value) {
              if (value != null) setState(() {
                orb = value;
                result = null;
              });
            },
          ),
        ]),
        FilledButton.icon(
          onPressed: loading || findingDates ? null : calculate,
          icon: const Icon(Icons.calculate),
          label: const Text('Secondary + Solar Arc + Naibod గణించండి'),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: loading || findingDates ? null : findExactDates,
          icon: const Icon(Icons.event_available),
          label: const Text('సమీప Exact Aspect Dates చూడండి'),
        ),
        if (loading || findingDates) const LinearProgressIndicator(),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
        if (result != null) ...[
          const Divider(),
          Text('పరిశీలిస్తున్న సంఘటన: $eventCategory'),
          Text('వయస్సు: ${result!.ageYears.toStringAsFixed(3)} సంవత్సరాలు'),
          Text('Solar Arc: ${result!.solarArc.toStringAsFixed(4)}°'),
          Text('Progressed Moon (Tropical): '
              '${result!.progressedMoon.toStringAsFixed(4)}°'),
          if (naibod != null) ...[
            const Divider(),
            const Text('Naibod Progressed Axes (Tropical)',
              style: TextStyle(fontWeight: FontWeight.bold)),
            Text('Naibod Arc: ${naibod!.arc.toStringAsFixed(4)}°'),
            Text('ASC: ${naibod!.asc.toStringAsFixed(4)}° | DSC: ${naibod!.dsc.toStringAsFixed(4)}°'),
            Text('MC: ${naibod!.mc.toStringAsFixed(4)}° | IC: ${naibod!.ic.toStringAsFixed(4)}°'),
            const Text('సింబాలిక్ దిశా గణన మాత్రమే; సంఘటన నిర్ధారణ కాదు.'),
          ],
          const Divider(),
          const Text('Secondary → Natal contacts',
              style: TextStyle(fontWeight: FontWeight.bold)),
          for (final contact in result!.secondaryContacts) Text('• $contact'),
          if (result!.secondaryContacts.isEmpty)
            const Text('ఎంచుకున్న Orbలో Secondary contacts లేవు'),
          const Divider(),
          const Text('Solar Arc → Natal contacts',
              style: TextStyle(fontWeight: FontWeight.bold)),
          for (final contact in result!.solarArcContacts) Text('• $contact'),
          if (result!.solarArcContacts.isEmpty)
            const Text('ఎంచుకున్న Orbలో Solar Arc contacts లేవు'),
        ],
        if (exactDates != null) ...[
          const Divider(),
          Text('సంఘటన తేదీకి ±180 రోజుల్లో Exact Aspects '
              '(${exactDates!.length} వరకు చూపిస్తున్నాం)',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          for (final entry in exactDates!) ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('${entry.source} → ${entry.target}: '
                '${entry.aspect}'),
            subtitle: Text('${entry.method} • ${formatDate(entry.date)} '
                '(UTC)'),
          ),
          if (exactDates!.isEmpty)
            const Text('ఈ పరిధిలో ఖచ్చితమైన Aspect crossing కనబడలేదు'),
        ],
        const Divider(),
        const Text('Exact Aspect Date అనేది గ్రహకోణం ఖచ్చితమయ్యే తేదీ; '
            'సంఘటన తప్పనిసరిగా జరిగే తేదీ కాదు. BTR జనన సెకన్లను '
            'ఈ లెక్కతో మార్చము. Tertiary ఇంకా అమలు కాలేదు; Naibod Axes గణన అందుబాటులో ఉంది.'),
      ]),
    ),
  );
}
