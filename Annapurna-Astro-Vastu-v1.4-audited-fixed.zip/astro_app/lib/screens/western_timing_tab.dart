import 'package:flutter/material.dart';

import '../astrology/western_timing_engine.dart';
import '../astrology/western_ephemeris_service.dart';
import '../models/birth_data.dart';

/// A separate Western timing workspace: it intentionally does NOT use the
/// S.K. Mehta / Vedic period results as Western timing evidence.
class WesternTimingTab extends StatefulWidget {
  final BirthData birthData;
  const WesternTimingTab({super.key, required this.birthData});

  @override
  State<WesternTimingTab> createState() => _WesternTimingTabState();
}

class _WesternTimingTabState extends State<WesternTimingTab> {
  DateTime? _eventDate;
  double _orb = 1.0;
  Future<WesternCalculation>? _calculation;

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

  Future<void> _pickEventDate() async {
    final birth = widget.birthData.localDateTime;
    final now = DateTime.now();
    final first = DateTime(birth.year, birth.month, birth.day);
    final last = DateTime(2100, 12, 31);
    final initial = _eventDate ?? (now.isBefore(first) ? first : now);
    final selected = await showDatePicker(
      context: context, initialDate: initial.isAfter(last) ? last : initial,
      firstDate: first, lastDate: last,
    );
    if (!mounted || selected == null) return;
    setState(() {
      _eventDate = selected;
      _calculation = WesternEphemerisService.calculate(widget.birthData,
        DateTime.utc(selected.year, selected.month, selected.day, 12), maxOrb:_orb);
    });
  }

  Widget _statusCard(WesternMethodStatus m) {
    final ready = m.method != WesternMethod.primaryDirections;
    return Card(
      child: ExpansionTile(
        leading: Icon(ready ? Icons.info_outline : Icons.schedule,
            color: ready ? Colors.blueGrey : Colors.deepOrange),
        title: Text(m.methodName, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(ready ? 'ప్రాథమిక గణన భాగం మాత్రమే' : 'పూర్తి గణన ఇంకా లేదు'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        children: [
          Align(alignment: Alignment.centerLeft, child: Text(m.status)),
          const SizedBox(height: 4),
          Align(alignment: Alignment.centerLeft, child: Text(m.constraint)),
        ],
      ),
    );
  }

  Widget _result(String title, String value, String details) =>
      Card(child: ListTile(title: Text(title), subtitle: Text(details),
          trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.w700))));

  @override
  Widget build(BuildContext context) {
    final birth = widget.birthData.utcDateTime;
    final date = _eventDate;
    final event = date == null ? null : DateTime.utc(date.year, date.month, date.day, 12);
    final age = event == null ? null : WesternTimingEngine.ageYears(birth, event);
    final progressed = event == null ? null : WesternTimingEngine.secondaryDate(birth, event);
    final converse = event == null ? null : WesternTimingEngine.secondaryDate(birth, event, converse: true);
    final tertiary = event == null ? null : WesternTimingEngine.tertiaryDate(birth, event);
    final minor = event == null ? null : WesternTimingEngine.minorDate(birth, event);
    final yearsCompleted = date == null ? null : date.year - widget.birthData.localDateTime.year -
        ((date.month < widget.birthData.localDateTime.month ||
          (date.month == widget.birthData.localDateTime.month &&
            date.day < widget.birthData.localDateTime.day)) ? 1 : 0);

    return ListView(padding: const EdgeInsets.all(12), children: [
      const Text('Western Timing & BTR', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('ఇది S.K. Mehta / భారతీయ దశల నుంచి పూర్తిగా వేరుగా పనిచేసే పరిశీలన విభాగం.'),
      const SizedBox(height: 12),
      Card(color: const Color(0xFFFFF3E5), child: const Padding(
        padding: EdgeInsets.all(12),
        child: Text('స్థితి: 8 పద్ధతుల పూర్తి Event Timing/BTR ఇంకా సిద్ధం కాలేదు. కింద చూపే తేదీలు progression mapping మాత్రమే; సంఘటన జరుగుతుందని చెప్పే తేదీలు కావు. Primary Directionsకు పూర్తి ఖగోళ గణన అవసరం.'),
      )),
      const SizedBox(height: 12),
      Text('జననం: ${_date(widget.birthData.localDateTime)} • ${widget.birthData.place}'),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: _pickEventDate,
          icon: const Icon(Icons.event), label: Text(date == null ? 'పరిశీలించాల్సిన సంఘటన తేదీ' : 'సంఘటన తేదీ: ${_date(date)}')),
      if (event != null && age != null && yearsCompleted != null) ...[
        const SizedBox(height: 12),
        const Text('తేదీ ఆధారిత ప్రాథమిక గణనలు', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        _result('Secondary Progression',_date(progressed!), 'Day-for-year; జననానంతర ephemeris తేదీ (UTC).'),
        _result('Tertiary-I',_date(tertiary!), 'Synodic lunar month = one lived month; ephemeris తేదీ.'),
        _result('Minor Progression',_date(minor!), 'Sidereal lunar month per life year; ephemeris తేదీ.'),
        _result('Converse Secondary',_date(converse!), 'జననానికి ముందు ephemeris తేదీ.'),
        _result('1° Symbolic Arc','${age.toStringAsFixed(3)}°', 'ఇది symbolic arc మాత్రమే; natal longitudes/aspects ఇంకా లేవు.'),
        _result('Naibod Symbolic Arc','${(age * WesternTimingEngine.naibodDegreesPerYear).toStringAsFixed(3)}°', '1° arcతో సమానం కాదు.'),
        _result('Annual Profection', '${yearsCompleted % 12} signs', 'జన్మలగ్న రాశి నుంచి పూర్తి సంవత్సరాలు; పూర్తి annual-lord విశ్లేషణ ఇంకా లేదు.'),
        const Card(child: ListTile(title: Text('Solar Arc'),subtitle: Text('నిజమైన natal Sun, progressed Sun స్థానాలు అందిన తరువాతే arc గణించాలి.'))),
        const Card(child: ListTile(title: Text('Primary Directions'),subtitle: Text('RA, declination, geographical latitude, direction key తదితర గణనలు పెండింగ్.'))),
      ],
      const SizedBox(height: 14),
      if (_calculation != null) ...[
        const Text('Tropical planetary calculations / Aspects',
          style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),
        const Text('గ్రహ దీర్ఘాంశాలు Tropical. ASC/MC వేరే progressed తేదీకి జన్మస్థలాన్ని ఉపయోగించి గణించిన సూచికలు మాత్రమే; పూర్తి progressed angles లేదా Primary Directions కావు.'),
        Row(children:[const Text('Aspect orb'),Expanded(child:Slider(
          value:_orb,min:0.25,max:3.0,divisions:11,
          label:'${_orb.toStringAsFixed(2)}°',
          onChanged:(v)=>setState(() {
            _orb=v;
            final d=_eventDate!;
            _calculation=WesternEphemerisService.calculate(widget.birthData,
              DateTime.utc(d.year,d.month,d.day,12),maxOrb:v);
          }))) ,Text('${_orb.toStringAsFixed(2)}°')]),
        FutureBuilder<WesternCalculation>(future:_calculation,builder:(context,snapshot){
          if(snapshot.hasError) return Text('Ephemeris లోపం: ${snapshot.error}',
            style:const TextStyle(color:Colors.red));
          if(!snapshot.hasData) return const Center(child:CircularProgressIndicator());
          final result=snapshot.data!;
          return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            _result('Solar Arc','${result.solarArc.toStringAsFixed(4)}°',
              'Natal Sun → progressed Sun; natal positions + same arc'),
            _result('Annual Profection',
              'Sign ${result.profectedSign+1} • ${result.profectionLord}',
              'Whole-sign annual ruler; sign numbers 1=Aries .. 12=Pisces'),
            for(final entry in result.charts.entries) Card(child:ExpansionTile(
              title:Text('${entry.key} — Positions'),
              subtitle:Text(entry.key=='Natal'?'Tropical natal ephemeris':
                  '${result.contacts[entry.key]?.length ?? 0} natal contacts ≤ ${_orb.toStringAsFixed(2)}°'),
              childrenPadding:const EdgeInsets.all(12),children:[
                for(final p in entry.value.planets.entries)
                  Text('${p.key}: ${p.value.toStringAsFixed(4)}°'),
                Text('ASC: ${entry.value.asc.toStringAsFixed(4)}°; MC: ${entry.value.mc.toStringAsFixed(4)}°'),
                if(entry.key!='Natal') ...[
                  const Divider(),
                  for(final c in (result.contacts[entry.key] ?? <WesternContact>[]).take(30))
                    Text('${c.moving} → natal ${c.natal}  ${c.aspect}°  orb ${c.orb.toStringAsFixed(3)}°'),
                  if(result.contacts[entry.key]!.isEmpty)
                    const Text('ఈ orbలో natal contact లేదు'),
                ],
              ])),
            const Card(child:Padding(padding:EdgeInsets.all(12),child:Text(
              'Primary Directions, పూర్తి progressed angles, Event-specific rule matching, Multi-Event BTR ఇంకా అమలు కాలేదు. Contact సంఖ్య సంఘటన సంభావ్యత కాదు.'))),
          ]);
        }),
      ],
      const SizedBox(height: 14),
      const Text('8 పద్ధతుల స్థితి', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      for (final method in westernMethodCoverage) _statusCard(method),
      const SizedBox(height: 12),
      Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: const [
          Text('Western Multi-Event BTR', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('ఇంకా అమలు కాలేదు: అనేక గత సంఘటనలు, candidate birth-time scan, angles/aspects, event rules, uncertainty ranges, held-out validation అవసరం.'),
          SizedBox(height: 8),
          Text('ఇక్కడ S.K. Mehta BTR ఫలితాలను Western BTRగా చూపించడం లేదు.'),
        ],
      ))),
    ]);
  }
}
