import 'package:flutter/material.dart';

import '../astrology/western_timing_engine.dart';
import '../astrology/western_ephemeris_service.dart';
import '../astrology/western_event_btr.dart';
import '../astrology/western_event_rules.dart';
import '../astrology/western_primary_directions.dart';
import '../models/birth_data.dart';

/// A separate Western timing workspace: it intentionally does NOT use the
/// S.K. Mehta / Vedic period results as Western timing evidence.
class WesternTimingTab extends StatefulWidget {
  final BirthData birthData;
  const WesternTimingTab({super.key, required this.birthData});

  @override
  State<WesternTimingTab> createState() => _WesternTimingTabState();
}

class _WesternTimingTabState extends State<WesternTimingTab> {
  DateTime? _eventDate;
  double _orb = 1.0;
  Future<WesternCalculation>? _calculation;
  final List<WesternPastEvent> _pastEvents = [];
  Future<List<WesternBtrCandidate>>? _btrSearch;
  Future<List<WesternBtrCandidate>>? _secondsSearch;
  int _searchMinutes=10;
  String _pastType='Marriage';
  String _timingType='వివాహం';
  DateTime? _rangeStart;
  DateTime? _rangeEnd;
  int _stepDays=30;
  Future<List<_WesternTimingHit>>? _timingSearch;
  int? _timingCount;
  bool _yearWise = true;
  static const _eventOptions=<String>[
    'వివాహం','ప్రేమ / నిశ్చితార్థం','మొదటి సంతానం','రెండవ సంతానం',
    'తదుపరి సంతానం','గర్భధారణ','విద్య / పరీక్ష','ఉన్నత విద్య',
    'ఉద్యోగం','మొదటి ఉద్యోగం','ప్రమోషన్','ఉద్యోగ మార్పు',
    'ఉద్యోగ నష్టం','ఉద్యోగ విరమణ','వ్యాపార ప్రారంభం','వ్యాపార వృద్ధి',
    'ధనలాభం','అప్పు / ఋణం','ఆస్తి కొనుగోలు','ఇంటి నిర్మాణం',
    'భూమి కొనుగోలు','వాహనం కొనుగోలు','విదేశీ ప్రయాణం','విదేశీ స్థిరనివాసం',
    'స్థాన మార్పు','కుటుంబ సంఘటన','ఆరోగ్య సంబంధ సంఘటన',
    'శస్త్రచికిత్స','ప్రమాదం / వాహన నష్టం','వివాదం / న్యాయ వ్యవహారం',
    'గుర్తింపు / అవార్డు','ఆధ్యాత్మిక కార్యక్రమం','ఇతర సంఘటన'
  ];

  final _types=<String>['Marriage','First child','Second child','Career','Property','Education','Relocation','Health'];

  Future<void> _pickRange(bool start) async {
    final birth=widget.birthData.localDateTime;
    final first=DateTime(birth.year,birth.month,birth.day);
    final last=DateTime(2200,12,31);
    var initial=(start?_rangeStart:_rangeEnd) ?? (start?DateTime.now():DateTime.now().add(const Duration(days:365)));
    if(initial.isBefore(first)) initial=first;
    if(initial.isAfter(last)) initial=last;
    final chosen=await showDatePicker(context:context,initialDate:initial,
      firstDate:first,lastDate:last);
    if(!mounted || chosen==null) return;
    setState(() {
      if(start){_rangeStart=chosen;}else{_rangeEnd=chosen;}
      _timingSearch=null;
      _timingCount=null;
    });
  }

  Future<List<_WesternTimingHit>> _computeTiming(DateTime from,DateTime to,
      int stepDays,double orb) async {
    final hits=<_WesternTimingHit>[];
    final profile=WesternEventLookup.profileForTelugu(_timingType);
    if(profile==null) return hits;
    var current=from;
    while(!current.isAfter(to)) {
      final event=DateTime.utc(current.year,current.month,current.day,12);
      final result=await WesternEphemerisService.calculate(widget.birthData,event,maxOrb:orb);
      final matches=<WesternContact>[];
      final profile=WesternEventLookup.profileForTelugu(_timingType);
      
      for(final key in const ['Secondary','Solar Arc','Tertiary-I','Minor',
          'Naibod','1° Symbolic','Converse Secondary']) {
        final list=result.contacts[key] ?? <WesternContact>[];
        // Avoid claiming a specific life event from a raw astronomical contact.
        matches.addAll(list.where((c)=>c.moving!=c.natal &&
            WesternEventRuleBook.isRelevant(eventType:profile,
              moving:c.moving,natal:c.natal)));
      }
      matches.sort((a,b)=>a.orb.compareTo(b.orb));
      if(matches.isNotEmpty) hits.add(_WesternTimingHit(event,matches.take(3).toList()));
      current=current.add(Duration(days:stepDays));
    }
    // Rank by strongest orb first, then keep the same top 40 contacts.
    // Display ordering is a separate UI concern; it must not change selection.
    hits.sort((a,b)=>a.contacts.first.orb.compareTo(b.contacts.first.orb));
    return hits.take(40).toList();
  }

  void _runTimingSearch() {
    final from=_rangeStart, to=_rangeEnd;
    if(from==null || to==null || to.isBefore(from)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content:Text('సరైన ప్రారంభ తేదీ, ముగింపు తేదీ ఎంచుకోండి')));
      return;
    }
    final count=to.difference(from).inDays ~/_stepDays+1;
    if(count>400) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(
        '$count గణనలు అవసరం. Step పెంచండి లేదా కాలపరిధిని తగ్గించండి (గరిష్ఠం 400).')));
      return;
    }
    setState(() {
      _timingCount=count;
      _timingSearch=_computeTiming(from,to,_stepDays,_orb);
    });
  }

  Widget _timingSearchPanel() => Card(child:Padding(
    padding:const EdgeInsets.all(14),child:Column(
    crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    const Text('Western Event Timing Search',
      style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),
    const Text('సంఘటన ఎంచుకుని From–To తేదీలను మీరే నిర్ణయించండి. కాలపరిధి రోజులు లేదా సంవత్సరాలు ఏదైనా కావచ్చు. కిందివి తేదీల వారీ గ్రహ సంబంధాలు మాత్రమే; ఎంచుకున్న సంఘటన జరుగుతుందని నిర్ధారణ కాదు.'),
    const SizedBox(height:10),
    DropdownButtonFormField<String>(initialValue:_timingType,isExpanded:true,
      decoration:const InputDecoration(labelText:'సంఘటన రకం',border:OutlineInputBorder()),
      items:_eventOptions.map((v)=>DropdownMenuItem(value:v,child:Text(v,overflow:TextOverflow.ellipsis))).toList(),
      onChanged:(v)=>setState((){_timingType=v??_timingType;_timingSearch=null;})),
    const SizedBox(height:8),
    OutlinedButton.icon(onPressed:()=>_pickRange(true),icon:const Icon(Icons.date_range),
      label:Text('ఏ తేదీ నుంచి: ${_rangeStart==null ? "ఎంచుకోండి" : _date(_rangeStart!)}')),
    OutlinedButton.icon(onPressed:()=>_pickRange(false),icon:const Icon(Icons.event),
      label:Text('ఏ తేదీ వరకు: ${_rangeEnd==null ? "ఎంచుకోండి" : _date(_rangeEnd!)}')),
    const SizedBox(height:8),
    DropdownButtonFormField<int>(initialValue:_stepDays,
      decoration:const InputDecoration(labelText:'ఎన్ని రోజులకొకసారి పరిశీలించాలి',border:OutlineInputBorder()),
      items:const [1,3,7,15,30,90,180,365].map((v)=>DropdownMenuItem(
        value:v,child:Text('ప్రతి $v రోజులకు'))).toList(),
      onChanged:(v)=>setState((){_stepDays=v??30;_timingSearch=null;})),
    const SizedBox(height:8),
    if(_rangeStart!=null && _rangeEnd!=null && !_rangeEnd!.isBefore(_rangeStart!))
      Text('కాలపరిధి: ${_rangeEnd!.difference(_rangeStart!).inDays+1} రోజులు • గణన నమూనాలు: ${_rangeEnd!.difference(_rangeStart!).inDays~/_stepDays+1}'),
    const SizedBox(height:8),
    const SizedBox(height:8),
    SegmentedButton<bool>(
      segments:const [
        ButtonSegment<bool>(value:true,label:Text('Year-wise')),
        ButtonSegment<bool>(value:false,label:Text('Strongest Match')),
      ],
      selected:{_yearWise},
      onSelectionChanged:(values)=>setState(()=>_yearWise=values.first),
    ),
    const Text('Year-wise: తేదీల క్రమం. Strongest Match: తక్కువ Orb ముందు. రెండింటిలోనూ ఉత్తమ 40 నమూనాలే చూపిస్తాము.'),
    FilledButton.icon(onPressed:_runTimingSearch,icon:const Icon(Icons.search),
      label:const Text('Event Timing Search')),
    if(_timingSearch!=null) FutureBuilder<List<_WesternTimingHit>>(
      future:_timingSearch,builder:(context,snapshot) {
        if(snapshot.hasError) return Text('గణన లోపం: ${snapshot.error}',style:const TextStyle(color:Colors.red));
        if(!snapshot.hasData) return const Padding(padding:EdgeInsets.all(12),child:LinearProgressIndicator());
        final hits=List<_WesternTimingHit>.of(snapshot.data!);
        if(_yearWise) hits.sort((a,b)=>a.date.compareTo(b.date));
        return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          const SizedBox(height:8),
          Text('$_timingType • పరిశీలించిన $_timingCount తేదీలు • Contacts ఉన్న ${hits.length} నమూనాలు (గరిష్ఠం 40 చూపిస్తాము)',
            style:const TextStyle(fontWeight:FontWeight.bold)),
          const Text('సంఘటన గ్రహ-కారక ప్రొఫైల్ ఆధారిత ప్రాథమిక Rule Filter అమల్లో ఉంది. ఇది ఖచ్చిత సంఘటన నిర్ణయం కాదు; భావాధిపతులు, పూర్తి Primary Directions, మధ్యలోని తేదీల పరిశీలన ఇంకా అవసరం.'),
          for(final hit in hits) Card(child:ExpansionTile(
            title:Text(_date(hit.date)),
            subtitle:Text('Event-filtered closest orb ${hit.contacts.first.orb.toStringAsFixed(3)}°'),
            children:[for(final c in hit.contacts) ListTile(
              dense:true,title:Text('${c.moving} → ${c.natal} ${c.aspect}°'),
              subtitle:Text('Orb: ${c.orb.toStringAsFixed(3)}°'))])),
          if(hits.isEmpty) const Text('ఈ నమూనా తేదీలలో ఈ సంఘటనకు సంబంధించిన contact లేదు; సంఘటన జరగదని అర్థం కాదు.'),
        ]);
      }),
  ])));

  Future<void> _addPastEvent() async {
    final b=widget.birthData.localDateTime;
    final first=DateTime(b.year,b.month,b.day);
    final last=DateTime(2100,12,31);
    final now=DateTime.now();
    final initial=now.isBefore(first)?first:(now.isAfter(last)?last:now);
    final date=await showDatePicker(context:context,firstDate:first,
      lastDate:last, initialDate:initial);
    if(date==null || !mounted) return;
    setState(() {
      _pastEvents.add(WesternPastEvent(_pastType,DateTime.utc(date.year,date.month,date.day,12)));
      _btrSearch=null;
      _secondsSearch=null;
    });
  }
  void _runBtr(){
    if(_pastEvents.length<3 || _pastEvents.map((e)=>_date(e.time)).toSet().length<3){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('కనీసం 3 వేర్వేరు తేదీల సంఘటనలు నమోదు చేయండి')));
      return;
    }
    setState(() {
      _secondsSearch=null;
      _btrSearch=WesternEventBtr.search(widget.birthData,
      List.of(_pastEvents),halfWindowMinutes:_searchMinutes,stepMinutes:1);
    });
  }

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

  Future<void> _pickEventDate() async {
    final birth = widget.birthData.localDateTime;
    final now = DateTime.now();
    final first = DateTime(birth.year, birth.month, birth.day);
    final last = DateTime(2100, 12, 31);
    final initial = _eventDate ?? (now.isBefore(first) ? first : now);
    final selected = await showDatePicker(
      context: context, initialDate: initial.isAfter(last) ? last : initial,
      firstDate: first, lastDate: last,
    );
    if (!mounted || selected == null) return;
    setState(() {
      _eventDate = selected;
      _calculation = WesternEphemerisService.calculate(widget.birthData,
        DateTime.utc(selected.year, selected.month, selected.day, 12), maxOrb:_orb);
    });
  }

  Widget _statusCard(WesternMethodStatus m) {
    final ready = m.method != WesternMethod.primaryDirections;
    return Card(
      child: ExpansionTile(
        leading: Icon(ready ? Icons.info_outline : Icons.schedule,
            color: ready ? Colors.blueGrey : Colors.deepOrange),
        title: Text(m.methodName, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(ready ? 'ప్రాథమిక గణన భాగం మాత్రమే' : 'పూర్తి గణన ఇంకా లేదు'),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        children: [
          Align(alignment: Alignment.centerLeft, child: Text(m.status)),
          const SizedBox(height: 4),
          Align(alignment: Alignment.centerLeft, child: Text(m.constraint)),
        ],
      ),
    );
  }

  Widget _result(String title, String value, String details) =>
      Card(child: ListTile(title: Text(title), subtitle: Text(details),
          trailing: Text(value, style: const TextStyle(fontWeight: FontWeight.w700))));

  @override
  Widget build(BuildContext context) {
    final birth = widget.birthData.utcDateTime;
    final date = _eventDate;
    final event = date == null ? null : DateTime.utc(date.year, date.month, date.day, 12);
    final age = event == null ? null : WesternTimingEngine.ageYears(birth, event);
    final progressed = event == null ? null : WesternTimingEngine.secondaryDate(birth, event);
    final converse = event == null ? null : WesternTimingEngine.secondaryDate(birth, event, converse: true);
    final tertiary = event == null ? null : WesternTimingEngine.tertiaryDate(birth, event);
    final minor = event == null ? null : WesternTimingEngine.minorDate(birth, event);
    final yearsCompleted = date == null ? null : date.year - widget.birthData.localDateTime.year -
        ((date.month < widget.birthData.localDateTime.month ||
          (date.month == widget.birthData.localDateTime.month &&
            date.day < widget.birthData.localDateTime.day)) ? 1 : 0);

    return ListView(padding: const EdgeInsets.all(12), children: [
      const Text('Western Timing & BTR', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('ఇది S.K. Mehta / భారతీయ దశల నుంచి పూర్తిగా వేరుగా పనిచేసే పరిశీలన విభాగం.'),
      const SizedBox(height: 12),
      Card(color: const Color(0xFFFFF3E5), child: const Padding(
        padding: EdgeInsets.all(12),
        child: Text('స్థితి: 8 పద్ధతుల పూర్తి Event Timing/BTR ఇంకా సిద్ధం కాలేదు. కింద చూపే తేదీలు progression mapping మాత్రమే; సంఘటన జరుగుతుందని చెప్పే తేదీలు కావు. Primary Directionsకు పూర్తి ఖగోళ గణన అవసరం.'),
      )),
      const SizedBox(height: 12),
      Text('జననం: ${_date(widget.birthData.localDateTime)} • ${widget.birthData.place}'),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: _pickEventDate,
          icon: const Icon(Icons.event), label: Text(date == null ? 'పరిశీలించాల్సిన సంఘటన తేదీ' : 'సంఘటన తేదీ: ${_date(date)}')),
      if (event != null && age != null && yearsCompleted != null) ...[
        const SizedBox(height: 12),
        const Text('తేదీ ఆధారిత ప్రాథమిక గణనలు', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        _result('Secondary Progression',_date(progressed!), 'Day-for-year; జననానంతర ephemeris తేదీ (UTC).'),
        _result('Tertiary-I',_date(tertiary!), 'Synodic lunar month = one lived month; ephemeris తేదీ.'),
        _result('Minor Progression',_date(minor!), 'Sidereal lunar month per life year; ephemeris తేదీ.'),
        _result('Converse Secondary',_date(converse!), 'జననానికి ముందు ephemeris తేదీ.'),
        _result('1° Symbolic Arc','${age.toStringAsFixed(3)}°', 'ఇది symbolic arc మాత్రమే; natal longitudes/aspects ఇంకా లేవు.'),
        _result('Naibod Symbolic Arc','${(age * WesternTimingEngine.naibodDegreesPerYear).toStringAsFixed(3)}°', '1° arcతో సమానం కాదు.'),
        _result('Annual Profection', '${yearsCompleted % 12} signs', 'జన్మలగ్న రాశి నుంచి పూర్తి సంవత్సరాలు; పూర్తి annual-lord విశ్లేషణ ఇంకా లేదు.'),
        const Card(child: ListTile(title: Text('Solar Arc'),subtitle: Text('నిజమైన natal Sun, progressed Sun స్థానాలు అందిన తరువాతే arc గణించాలి.'))),
        const Card(child: ListTile(title: Text('Primary Directions'),subtitle: Text('RA, declination, geographical latitude, direction key తదితర గణనలు పెండింగ్.'))),
      ],
      const SizedBox(height: 14),
      _timingSearchPanel(),
      const SizedBox(height: 14),
      if (_calculation != null) ...[
        const Text('Tropical planetary calculations / Aspects',
          style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),
        const Text('గ్రహ దీర్ఘాంశాలు Tropical. ASC/MC వేరే progressed తేదీకి జన్మస్థలాన్ని ఉపయోగించి గణించిన సూచికలు మాత్రమే; పూర్తి progressed angles లేదా Primary Directions కావు.'),
        Row(children:[const Text('Aspect orb'),Expanded(child:Slider(
          value:_orb,min:0.25,max:3.0,divisions:11,
          label:'${_orb.toStringAsFixed(2)}°',
          onChanged:(v)=>setState(() {
            _orb=v;
            final d=_eventDate!;
            _calculation=WesternEphemerisService.calculate(widget.birthData,
              DateTime.utc(d.year,d.month,d.day,12),maxOrb:v);
          }))) ,Text('${_orb.toStringAsFixed(2)}°')]),
        FutureBuilder<WesternCalculation>(future:_calculation,builder:(context,snapshot){
          if(snapshot.hasError) return Text('Ephemeris లోపం: ${snapshot.error}',
            style:const TextStyle(color:Colors.red));
          if(!snapshot.hasData) return const Center(child:CircularProgressIndicator());
          final result=snapshot.data!;
          return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            _result('Solar Arc','${result.solarArc.toStringAsFixed(4)}°',
              'Natal Sun → progressed Sun; natal positions + same arc'),
            _result('Annual Profection',
              'Sign ${result.profectedSign+1} • ${result.profectionLord}',
              'Whole-sign annual ruler; sign numbers 1=Aries .. 12=Pisces'),
            for(final entry in result.charts.entries) Card(child:ExpansionTile(
              title:Text('${entry.key} — Positions'),
              subtitle:Text(entry.key=='Natal'?'Tropical natal ephemeris':
                  '${result.contacts[entry.key]?.length ?? 0} natal contacts ≤ ${_orb.toStringAsFixed(2)}°'),
              childrenPadding:const EdgeInsets.all(12),children:[
                for(final p in entry.value.planets.entries)
                  Text('${p.key}: ${p.value.toStringAsFixed(4)}°'),
                Text('ASC: ${entry.value.asc.toStringAsFixed(4)}°; MC: ${entry.value.mc.toStringAsFixed(4)}°'),
                if(entry.key!='Natal') ...[
                  const Divider(),
                  for(final c in (result.contacts[entry.key] ?? <WesternContact>[]).take(30))
                    Text('${c.moving} → natal ${c.natal}  ${c.aspect}°  orb ${c.orb.toStringAsFixed(3)}°'),
                  if(result.contacts[entry.key]!.isEmpty)
                    const Text('ఈ orbలో natal contact లేదు'),
                ],
              ])),
            const Card(child:Padding(padding:EdgeInsets.all(12),child:Text(
              'Event-specific planetary filtering అమల్లో ఉంది. పూర్తి house-lord matching, Primary Directions, progressed angles, multi-method BTR ఇంకా అమలు కాలేదు. Contact సంఖ్య సంఘటన సంభావ్యత కాదు.'))),
          ]);
        }),
      ],
      const SizedBox(height: 14),
      const Text('8 పద్ధతుల స్థితి', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      for (final method in westernMethodCoverage) _statusCard(method),
      const SizedBox(height: 12),
      Card(child:ExpansionTile(title:const Text('Primary Directions — Equatorial Geometry'),
       subtitle:const Text('RA / Declination / OA మరియు semi-arc geometry; పూర్తి Primary Directions ఇంకా పెండింగ్'),
       childrenPadding:const EdgeInsets.all(12),children:[
        const Text('ఈ గణన భౌగోళిక అక్షాంశంతో oblique ascensionని చూపిస్తుంది. పూర్తి semi-arc, promissor/significator, pole calculations ఇంకా చేయాలి.'),
        if(_calculation!=null) FutureBuilder<WesternCalculation>(future:_calculation,
          builder:(ctx,snap){
           if(!snap.hasData) return const Text('Natal positions కోసం తేదీ ఎంచుకోండి');
           final sky=snap.data!.charts['Natal']!;
           return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            for(final p in sky.planets.entries)
             Builder(builder:(context){final q=WesternPrimaryDirections.fromEcliptic(
               longitude:p.value,latitude:0,obliquity:23.4393,
               geographicLatitude:widget.birthData.latitude);
               return Text('${p.key}: RA ${q.rightAscension.toStringAsFixed(3)}°, Dec ${q.declination.toStringAsFixed(3)}°, OA ${q.obliqueAscension?.toStringAsFixed(3) ?? "N/A"}° (ecliptic latitude=0 approximation)');
             }),
           ]);
          }),
       ])),
      Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
         const Text('Western Multi-Event BTR — Experimental',
           style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
         const Text('S.K. Mehta BTR నుంచి పూర్తిగా వేరు. కనీసం మూడు సంఘటనలు నమోదు చేయండి. తెలియని సమయాన్ని మధ్యాహ్నంగా తీసుకునే తాత్కాలిక తేదీ నమూనా మాత్రమే; ఖచ్చిత సమయ ఫలితం కాదు.'),
         DropdownButton<String>(value:_pastType,isExpanded:true,
           items:_types.map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),
           onChanged:(v)=>setState(()=>_pastType=v??'Marriage')),
         OutlinedButton.icon(onPressed:_addPastEvent,icon:const Icon(Icons.add),
           label:const Text('గత సంఘటన తేదీ చేర్చండి')),
         for(var i=0;i<_pastEvents.length;i++) ListTile(
           title:Text('${_pastEvents[i].type} — ${_date(_pastEvents[i].time)}'),
           trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){
            setState((){_pastEvents.removeAt(i);_btrSearch=null;_secondsSearch=null;});
           })),
         Text('Search పరిధి: ±$_searchMinutes నిమిషాలు; 1 నిమిషం అడుగు'),
         Slider(value:_searchMinutes.toDouble(),min:5,max:30,divisions:5,
          onChanged:(v)=>setState((){_searchMinutes=v.round();_btrSearch=null;_secondsSearch=null;})),
         FilledButton(onPressed:_runBtr,child:const Text('Western Final BTR Search — Experimental')),
         const SizedBox(height:8),
         OutlinedButton.icon(
           onPressed:_pastEvents.length<3 || _pastEvents.map((e)=>_date(e.time)).toSet().length<3 ? null : () {
             setState(() {
               _secondsSearch=WesternEventBtr.refineSeconds(
                 widget.birthData,List<WesternPastEvent>.of(_pastEvents),
                 halfWindowMinutes:_searchMinutes,topCandidates:3,
                 halfWindowSeconds:60,stepSeconds:10);
             });
           },
           icon:const Icon(Icons.manage_search),
           label:const Text('Seconds Refinement (10 sec step) — Experimental'),
         ),
         if(_secondsSearch!=null) FutureBuilder<List<WesternBtrCandidate>>(
           future:_secondsSearch,builder:(context,snapshot) {
             if(snapshot.hasError) return Text('Seconds search లోపం: ${snapshot.error}',
               style:const TextStyle(color:Colors.red));
             if(!snapshot.hasData) return const LinearProgressIndicator();
             return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
               const Text('Seconds search గ్రిడ్ మాత్రమే; ఖచ్చిత జనన సమయం నిర్ధారణ కాదు.'),
               for(final c in snapshot.data!.take(5)) ListTile(
                 title:Text('${_date(c.birthTime)} '
                   '${c.birthTime.hour.toString().padLeft(2,'0')}:'
                   '${c.birthTime.minute.toString().padLeft(2,'0')}:'
                   '${c.birthTime.second.toString().padLeft(2,'0')}'),
                 subtitle:Text('Relative contact score '
                   '${(c.evidenceScore*100).toStringAsFixed(1)}% | '
                   'సంఘటనలు ${c.supportedEventCount}/${c.eventScores.length}'),
               ),
             ]);
           },
         ),

         if(_btrSearch!=null) FutureBuilder<List<WesternBtrCandidate>>(
           future:_btrSearch,builder:(ctx,snap){
            if(snap.hasError) return Text('Search లోపం: ${snap.error}',style:const TextStyle(color:Colors.red));
            if(!snap.hasData) return const LinearProgressIndicator();
            return Column(children:[
             const Text('ఈ సంఖ్యలు బహుళ పద్ధతుల Contact ఆధారిత ప్రయోగాత్మక ర్యాంకింగ్ మాత్రమే. ఒకే మూల గణనతో వచ్చిన పద్ధతులు స్వతంత్ర సాక్ష్యాలు కావు; ఇది జనన సమయ ఖచ్చితత్వం లేదా సంఘటన సంభావ్యత కాదు.'),
             for(final c in snap.data!.take(5)) ListTile(
               title:Text('${_date(c.birthTime)} ${c.birthTime.hour.toString().padLeft(2,'0')}:${c.birthTime.minute.toString().padLeft(2,'0')}'),
               subtitle:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                 Text('Relative contact score ${(c.evidenceScore*100).toStringAsFixed(1)}% | సరిపోలిన సంఘటనలు ${c.supportedEventCount}/${c.eventScores.length}'),
                 for(var i=0;i<c.methodScores.length;i++) Text('సంఘటన ${i+1}: ${c.methodScores[i].entries.where((e)=>e.value>0).map((e)=>e.key).join(', ').isEmpty ? 'ఆధారాలు లేవు' : c.methodScores[i].entries.where((e)=>e.value>0).map((e)=>e.key).join(', ')}',style:const TextStyle(fontSize:12)),
               ])),
            ]);
           }),
         const Text('పూర్తి Primary Directions, event-specific validated rules, ఖచ్చిత BTR seconds మరియు held-out validation ఇంకా పెండింగ్.'),
        ]))),
    ]);
  }
}

class _WesternTimingHit {
  final DateTime date;
  final List<WesternContact> contacts;
  const _WesternTimingHit(this.date,this.contacts);
}
