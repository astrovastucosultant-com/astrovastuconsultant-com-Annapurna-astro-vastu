import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/mehta_career_options_service.dart';

/// Only the S.K. Mehta house/planet portfolios are used in this view.
/// The names are modern practical examples, not new natal prediction rules.
class MehtaCareerOptionsPanel extends StatelessWidget {
  final AstroChartResult chart;
  const MehtaCareerOptionsPanel({super.key, required this.chart});

  static void open(BuildContext context, AstroChartResult chart,
      MehtaCareerMode mode) {
    final list = MehtaCareerOptionsService.evaluate(chart, mode);
    final heading = mode == MehtaCareerMode.business
        ? 'వ్యాపారం — అనుకూల పరిశీలన జాబితా'
        : 'సర్వీస్ — అనుకూల ఉద్యోగాల జాబితా';
    var selectedIndex = -1;
    var stage = 0;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF8),
      builder: (context) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          top: false,
          child: FractionallySizedBox(
            heightFactor: 0.85,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
                  child: Row(
                    children: [
                      if (stage > 0)
                        IconButton(
                          tooltip: 'వెనక్కి',
                          icon: const Icon(Icons.arrow_back),
                          onPressed: () => setSheetState(() => stage--),
                        ),
                      Expanded(child: Text(
                        stage == 0 ? heading : stage == 1
                            ? 'జాతక పరిశీలన' : 'రూల్ / మూలగ్రంథం',
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                      )),
                      IconButton(
                        tooltip: 'మూసివేయండి',
                        icon: const Icon(Icons.close),
                        onPressed: () => Navigator.of(context).pop(),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView(
                    key: ValueKey('$stage-$selectedIndex'),
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                    children: [
                      if (stage == 0) ...[
                        const Text(
                          'క్రింది ఎంపికలు 7వ/6వ, 10వ, 2వ, 11వ భావాలకు సంబంధించిన గ్రహ పోర్ట్‌ఫోలియో ఆధారంగా పరిశీలించదగిన రంగాలు. '
                          'ఇవి ఖచ్చితమైన లాభం, ఉద్యోగం లేదా విజయ శాతం కాదు.',
                          style: TextStyle(height: 1.5),
                        ),
                        const SizedBox(height: 12),
                        ...List.generate(list.length, (index) {
                          final option = list[index];
                          return Card(
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              title: Text(option.name,
                                  style: const TextStyle(fontWeight: FontWeight.w800)),
                              subtitle: Text(
                                '${MehtaCareerOptionsService.planetTelugu(option.planet)} • '
                                '${option.houseReasons.join(' / ')}',
                                style: const TextStyle(height: 1.4),
                              ),
                              trailing: const Icon(Icons.chevron_right),
                              onTap: () => setSheetState(() {
                                selectedIndex = index;
                                stage = 1;
                              }),
                            ),
                          );
                        }),
                      ] else if (selectedIndex >= 0 && selectedIndex < list.length) ...[
                        _detailCard(list[selectedIndex], stage),
                        const SizedBox(height: 14),
                        if (stage == 1)
                          FilledButton.icon(
                            onPressed: () => setSheetState(() => stage = 2),
                            icon: const Icon(Icons.menu_book_outlined),
                            label: const Text('జాతక పరిశీలన → రూల్ చూడండి'),
                          )
                        else
                          OutlinedButton.icon(
                            onPressed: () => setSheetState(() => stage = 1),
                            icon: const Icon(Icons.arrow_back),
                            label: const Text('జాతక పరిశీలనకు తిరిగి'),
                          ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  static Widget _detailCard(MehtaCareerOption option, int stage) {
    return Card(
      color: const Color(0xFFF4F1EA),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(option.name,
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            if (stage == 1) ...[
              const Text('జాతక ఆధారాలు',
                  style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('సంబంధిత గ్రహం: ${MehtaCareerOptionsService.planetTelugu(option.planet)}'),
              ...option.houseReasons.map((reason) => Padding(
                padding: const EdgeInsets.only(top: 7),
                child: Text('• $reason'),
              )),
              const SizedBox(height: 10),
              Text('గ్రహ పోర్ట్‌ఫోలియో: ${option.planetaryReason}',
                  style: const TextStyle(height: 1.5)),
              const SizedBox(height: 12),
              const Text('ఈ ఎంపిక చేయడానికి వ్యక్తి విద్య, నైపుణ్యాలు, ఉద్యోగ అర్హతలు, '
                  'అందుబాటులోని పెట్టుబడి, మార్కెట్ పరిస్థితులు తప్పనిసరిగా పరిశీలించాలి.',
                  style: TextStyle(height: 1.5)),
            ] else ...[
              const Text('రూల్ — S.K. Mehta House / Planet Portfolio',
                  style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text('ఈ గ్రహం ${option.houseReasons.join(' / ')} ద్వారా వృత్తి అంశంతో '
                  'సంబంధపడుతుంది. ${option.planetaryReason} అనే పోర్ట్‌ఫోలియో నుంచి '
                  'ఈ ఆధునిక వృత్తి ఎంపికను ఉదాహరణగా చూపిస్తున్నాం.',
                  style: const TextStyle(height: 1.5)),
              const SizedBox(height: 12),
              Text('మూలగ్రంథం: ${option.source}',
                  style: const TextStyle(fontWeight: FontWeight.w700, height: 1.5)),
              const SizedBox(height: 10),
              const Text(
                'ఈ నిర్దిష్ట వ్యాపారం/ఉద్యోగ పేరు రచయిత ఇచ్చిన ప్రత్యేక సంఖ్యా కాంబినేషన్ కాదు; '
                'ఆయన గ్రహ–భావ పోర్ట్‌ఫోలియో నుంచి చేసిన ఆధునిక ఉదాహరణ. '
                'ఇతర రచయితల నియమాలు, D10 గణన లేదా కల్పిత విజయ శాతం ఉపయోగించలేదు.',
                style: TextStyle(height: 1.5),
              ),
              const SizedBox(height: 10),
              const Text('పరిహారం: ఈ ఎంపికకు మూలగ్రంథంలో ప్రత్యేక పరిహారం నిర్ధారించబడలేదు.'),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFFEFF6EF),
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('S.K. Mehta — వ్యాపారం / సర్వీస్ మార్గదర్శకం',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          const Text('వ్యాపారం లేదా సర్వీస్ టచ్ చేసి జాతక సంబంధిత వృత్తుల జాబితా చూడండి.',
              style: TextStyle(height: 1.4)),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => open(context, chart, MehtaCareerMode.business),
              icon: const Icon(Icons.storefront_outlined),
              label: const Text('వ్యాపారం → అనుకూల వ్యాపారాల జాబితా'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () => open(context, chart, MehtaCareerMode.service),
              icon: const Icon(Icons.work_outline),
              label: const Text('సర్వీస్ → అనుకూల ఉద్యోగాల జాబితా'),
            ),
          ),
          const SizedBox(height: 8),
          const Text('ఈ Mehta విభాగానికి మాత్రమే ఈ జాబితాలు. D10 వృత్తి విశ్లేషణ వేరుగా కొనసాగుతుంది.',
              style: TextStyle(fontSize: 12, height: 1.4)),
        ],
      ),
    ),
  );
}
