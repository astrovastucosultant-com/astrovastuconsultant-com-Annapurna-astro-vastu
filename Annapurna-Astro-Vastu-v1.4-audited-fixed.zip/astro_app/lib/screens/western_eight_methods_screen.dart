import 'package:flutter/material.dart';
import '../models/birth_data.dart';
import '../astrology/western_eight_method_engine.dart';

class WesternEightMethodsScreen extends StatefulWidget {
  final BirthData birthData;
  const WesternEightMethodsScreen({super.key, required this.birthData});
  @override
  State<WesternEightMethodsScreen> createState()=>_WesternEightMethodsScreenState();
}
class _WesternEightMethodsScreenState extends State<WesternEightMethodsScreen> {
  DateTime date=DateTime.now();
  bool busy=false;
  String? error;
  List<WesternMethodSnapshot> snapshots=[];
  Future<void> run() async {
    setState(() {busy=true;error=null;});
    try {
      final values=await WesternEightMethodEngine.allMethods(widget.birthData,date);
      if(mounted) setState(()=>snapshots=values);
    } catch(e) {if(mounted)setState(()=>error='$e');}
    finally {if(mounted)setState(()=>busy=false);}
  }
  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Western — Method Calculations')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Western స్వతంత్ర గణనలు — ఇతర దశా పద్ధతులతో సంబంధం లేదు.'),
      ListTile(title:Text('${date.day}-${date.month}-${date.year}'),
        trailing:const Icon(Icons.calendar_month),
        onTap:()async{final d=await showDatePicker(context:context,
          initialDate:date,firstDate:DateTime(1900),lastDate:DateTime(2150));
          if(d!=null)setState(()=>date=d);}),
      FilledButton(onPressed:busy?null:run,child:const Text('Calculate methods')),
      if(busy)const LinearProgressIndicator(),
      if(error!=null)Text(error!,style:const TextStyle(color:Colors.red)),
      for(final s in snapshots)Card(child:ExpansionTile(
        title:Text(s.method.name),
        subtitle:Text(s.implemented?'${s.aspects.length} angular contacts':'Not implemented'),
        children:[
          ListTile(title:Text(s.note)),
          for(final p in s.positions.entries)
            ListTile(dense:true,title:Text(p.key),trailing:Text(p.value.toStringAsFixed(4))),
          for(final a in s.aspects.take(30))ListTile(dense:true,title:Text(a)),
        ])),
      const Text('Aspect contacts are not confirmed life events. '
        'Primary Directions remain unimplemented; no fabricated values.'),
    ]),
  );
}
