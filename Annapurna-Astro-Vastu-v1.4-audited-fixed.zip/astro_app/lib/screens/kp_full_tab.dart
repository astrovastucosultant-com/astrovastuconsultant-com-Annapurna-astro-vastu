import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/kp_cusp_significator_service.dart';
import '../astrology/kp_service.dart';
import '../models/birth_data.dart';

/// Standalone KP view: independently calculated Cusp/Significator details,
/// intentionally separate from BPD, BNN and BCP timing methods.
class KpFullTab extends StatefulWidget {
  final AstroChartResult chart;
  final AyanamsaType ayanamsa;
  const KpFullTab({super.key, required this.chart, required this.ayanamsa});

  @override
  State<KpFullTab> createState() => _KpFullTabState();
}

class _KpFullTabState extends State<KpFullTab> {
  String _eventId = 'M01';

  @override
  Widget build(BuildContext context) {
    final data = KpCuspSignificatorService.compute(widget.chart);
    final stellar = KpService.planetaryTable(widget.chart);
    final audit = data.forEvent(_eventId);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('KP — కృష్ణమూర్తి పద్ధతి',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Text('Selected ayanamsa: ${widget.ayanamsa.label}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        if (widget.ayanamsa != AyanamsaType.krishnamurti)
          const Card(
            child: Padding(
              padding: EdgeInsets.all(12),
              child: Text('KP పరిశీలన కోసం Birth Detailsలో KP / Krishnamurti అయనాంశం ఎంచుకుని '
                  'చార్ట్ తిరిగి గణించండి. ప్రస్తుతం చూపిస్తున్న Cusps మీ ఎంపిక చేసిన అయనాంశంతో గణించబడ్డాయి.'),
            ),
          ),
        const SizedBox(height: 12),
        const Text('12 Placidus Cusps • Sign / Star / Sub / Sub-Sub',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        const SizedBox(height: 6),
        if (!data.available)
          Card(child: Padding(padding: const EdgeInsets.all(16),
              child: Text(data.warning ?? 'KP Cusps అందుబాటులో లేవు.')))
        else
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: const [
                DataColumn(label: Text('Cusp')),
                DataColumn(label: Text('Longitude')),
                DataColumn(label: Text('Sign Lord')),
                DataColumn(label: Text('Star Lord')),
                DataColumn(label: Text('Sub Lord')),
                DataColumn(label: Text('Sub-Sub')),
              ],
              rows: [for (final c in data.cusps) DataRow(cells: [
                DataCell(Text('${c.house}')),
                DataCell(Text('${c.stellar.longitude.toStringAsFixed(5)}°')),
                DataCell(Text(c.stellar.signLord)),
                DataCell(Text(c.stellar.starLord)),
                DataCell(Text(c.stellar.subLord)),
                DataCell(Text(c.stellar.subSubLord)),
              ])],
            ),
          ),
        const SizedBox(height: 14),
        const Text('గ్రహాలు • KP నక్షత్ర–సబ్ వివరాలు',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        for (final p in stellar)
          ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: Text(p.body, style: const TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('Star ${p.starLord} • Sub ${p.subLord} • Sub-Sub ${p.subSubLord}'),
            children: [ListTile(
              title: Text('Sign Lord: ${p.signLord} • ${p.longitude.toStringAsFixed(5)}°'),
              subtitle: Text(data.planets[p.body]?.fourLevels ?? 'Significator సమాచారం అందుబాటులో లేదు'),
            )],
          ),
        const SizedBox(height: 14),
        const Text('సంఘటన కస్పు / Significator పరిశీలన',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _eventId,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'KP Event', border: OutlineInputBorder()),
          items: [for (final e in KpCuspSignificatorService.eventMap.entries)
            DropdownMenuItem(value: e.key, child: Text('${e.key} • ${e.value.$1}'))],
          onChanged: (v) => setState(() => _eventId = v ?? _eventId),
        ),
        const SizedBox(height: 10),
        Card(
          color: const Color(0xFFF6F2F0),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Text(audit?.detail ?? 'ఈ సంఘటన కోసం పూర్తి KP డేటా లేదు. ఊహించి Promise ఇవ్వము.'),
          ),
        ),
        const Text('KP రూల్స్‌ను BPD/BNN/BCPతో కలపలేదు. '
            'కస్పు సంబంధం కనిపించడం సంఘటన నిర్ధారణ కాదు; Nodes representation, '
            'Ruling Planets, పూర్తి Dasha Promise/Denial తదుపరి మూల పరిశీలనకు లోబడి ఉంటాయి.',
            style: TextStyle(fontSize: 12)),
      ],
    );
  }
}
