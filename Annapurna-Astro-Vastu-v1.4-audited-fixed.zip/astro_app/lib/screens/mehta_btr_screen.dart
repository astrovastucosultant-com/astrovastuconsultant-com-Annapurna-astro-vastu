import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../astrology/mehta_btr_service.dart';
import '../astrology/sk_mehta_service.dart';
import '../models/birth_data.dart';

class _EventEntry {
  String ruleId;
  final TextEditingController date = TextEditingController();
  final TextEditingController time = TextEditingController();
  final TextEditingController note = TextEditingController();

  _EventEntry(this.ruleId);

  void dispose() {
    date.dispose();
    time.dispose();
    note.dispose();
  }
}

class MehtaBtrScreen extends StatefulWidget {
  final BirthData birthData;

  const MehtaBtrScreen({super.key, required this.birthData});

  @override
  State<MehtaBtrScreen> createState() => _MehtaBtrScreenState();
}

class _MehtaBtrScreenState extends State<MehtaBtrScreen> {
  final List<_EventEntry> _inputs = <_EventEntry>[];
  int _rangeMinutes = 60;
  MehtaBtrResult? _result;
  String? _error;
  bool _searching = false;
  int _completed = 0;
  int _total = 0;

  String get _prefKey =>
      'mehta_btr_events_${widget.birthData.originalBirthDateTime.toIso8601String()}_${widget.birthData.latitude}_${widget.birthData.longitude}';

  @override
  void initState() {
    super.initState();
    const initial = <String>['M01', 'M06', 'M11', 'M07', 'M14'];
    for (final key in initial) {
      _inputs.add(_EventEntry(key));
    }
    _restore();
  }

  @override
  void dispose() {
    for (final input in _inputs) {
      input.dispose();
    }
    super.dispose();
  }

  static String _two(int value) => value.toString().padLeft(2, '0');

  static String _date(DateTime date) =>
      '${_two(date.day)}-${_two(date.month)}-${date.year}';

  static String _time(DateTime date) =>
      '${_two(date.hour)}:${_two(date.minute)}:${_two(date.second)}';

  String _stamp(DateTime date) => '${_date(date)} ${_time(date)}';

  String _correction(DateTime proposed, DateTime original) {
    final seconds = proposed.difference(original).inSeconds;
    final sign = seconds < 0 ? '−' : '+';
    final absolute = seconds.abs();
    final hours = absolute ~/ 3600;
    final minutes = (absolute % 3600) ~/ 60;
    final remaining = absolute % 60;
    return '$sign$hours గంటలు $minutes నిమిషాలు $remaining సెకన్లు';
  }

  DateTime? _readDate(String raw) {
    final match = RegExp(r'^(\d{2})-(\d{2})-(\d{4})$').firstMatch(raw.trim());
    if (match == null) return null;
    final day = int.parse(match.group(1)!);
    final month = int.parse(match.group(2)!);
    final year = int.parse(match.group(3)!);
    if (year < 1900 || year > 2100) return null;
    final value = DateTime(year, month, day);
    if (value.year != year || value.month != month || value.day != day) {
      return null;
    }
    return value;
  }

  (int, int, int)? _readTime(String raw) {
    if (raw.trim().isEmpty) return (12, 0, 0);
    final match = RegExp(r'^(\d{1,2}):(\d{2})(?::(\d{2}))?$')
        .firstMatch(raw.trim());
    if (match == null) return null;
    final hour = int.parse(match.group(1)!);
    final minute = int.parse(match.group(2)!);
    final second = int.tryParse(match.group(3) ?? '0') ?? 0;
    if (hour > 23 || minute > 59 || second > 59) return null;
    return (hour, minute, second);
  }

  Future<void> _restore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_prefKey);
      if (raw == null || !mounted) return;
      final rows = jsonDecode(raw) as List<dynamic>;
      if (rows.isEmpty || rows.length > MehtaBtrService.maxEvents) return;
      final restored = <_EventEntry>[];
      for (final object in rows) {
        if (object is! Map) continue;
        final id = object['id']?.toString() ?? '';
        if (!MehtaBtrService.supportedEvents.any((r) => r.id == id)) continue;
        final item = _EventEntry(id);
        item.date.text = object['date']?.toString() ?? '';
        item.time.text = object['time']?.toString() ?? '';
        item.note.text = object['note']?.toString() ?? '';
        restored.add(item);
      }
      if (restored.length < 3) {
        for (final item in restored) { item.dispose(); }
        return;
      }
      setState(() {
        for (final item in _inputs) { item.dispose(); }
        _inputs.clear();
        _inputs.addAll(restored);
      });
    } catch (_) {
      // Failed restoration must not prevent manual BTR event entry.
    }
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_prefKey, jsonEncode([
      for (final item in _inputs)
        {'id': item.ruleId, 'date': item.date.text.trim(),
          'time': item.time.text.trim(), 'note': item.note.text.trim()},
    ]));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('గత సంఘటనలు ఈ పరికరంలో సేవ్ అయ్యాయి')),
      );
    }
  }

  Future<void> _chooseDate(_EventEntry entry) async {
    final current = _readDate(entry.date.text) ?? DateTime.now();
    final firstDate = DateTime(widget.birthData.originalBirthDateTime.year);
    final selected = await showDatePicker(
      context: context,
      initialDate: current.isBefore(firstDate)
          ? firstDate
          : (current.isAfter(DateTime.now()) ? DateTime.now() : current),
      firstDate: firstDate,
      lastDate: DateTime.now(),
    );
    if (selected == null) return;
    setState(() {
      entry.date.text = _date(selected);
      _result = null;
    });
  }

  Future<void> _chooseTime(_EventEntry entry) async {
    final parsed = _readTime(entry.time.text) ?? (12, 0, 0);
    final value = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: parsed.$1, minute: parsed.$2),
    );
    if (value == null) return;
    setState(() {
      entry.time.text = '${_two(value.hour)}:${_two(value.minute)}:00';
      _result = null;
    });
  }

  List<MehtaBtrEvent>? _gather() {
    final observed = <MehtaBtrEvent>[];
    for (var i = 0; i < _inputs.length; i++) {
      final item = _inputs[i];
      final raw = item.date.text.trim();
      if (raw.isEmpty && item.time.text.trim().isEmpty &&
          item.note.text.trim().isEmpty) continue;
      final date = _readDate(raw);
      if (date == null) {
        _setError('${i + 1}వ సంఘటన తేదీ DD-MM-YYYY రూపంలో ఇవ్వండి.');
        return null;
      }
      final time = _readTime(item.time.text);
      if (time == null) {
        _setError('${i + 1}వ సంఘటన సమయం HH:MM:SS రూపంలో ఇవ్వండి.');
        return null;
      }
      observed.add(MehtaBtrEvent(
        ruleId: item.ruleId,
        occurredAt: DateTime(date.year, date.month, date.day,
            time.$1, time.$2, time.$3),
        timeKnown: item.time.text.trim().isNotEmpty,
        note: item.note.text.trim(),
      ));
    }
    final issue = MehtaBtrService.validateEvents(
        observed, widget.birthData.originalBirthDateTime);
    if (issue != null) {
      _setError(issue);
      return null;
    }
    return observed;
  }

  void _setError(String value) => setState(() { _error = value; _result = null; });

  Future<void> _search() async {
    if (_searching) return;
    final events = _gather();
    if (events == null) return;
    try {
      await _save();
    } catch (_) {
      // Searching still works when local-device persistence is unavailable.
    }
    setState(() {
      _error = null;
      _result = null;
      _searching = true;
      _completed = 0;
      _total = 1;
    });
    try {
      final result = await MehtaBtrService.search(
        natal: widget.birthData,
        events: events,
        plusMinusMinutes: _rangeMinutes,
        onProgress: (done, total) {
          if (!mounted) return;
          if (done == total || done % 5 == 0) {
            setState(() { _completed = done; _total = total; });
          }
        },
      );
      if (mounted) setState(() => _result = result);
    } catch (error) {
      if (mounted) _setError('BTR Search పూర్తి కాలేదు: $error');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _useCandidate(MehtaBtrCandidate candidate) async {
    if (_result?.distinguishable != true) return;
    final decision = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('BTR సమయం వర్తింపజేయాలా?'),
        content: Text('ప్రతిపాదిత సమయం: ${_stamp(candidate.birthTime)}\n'
            'ఈ సమయం గ్రహదశ సరిపోలికల ఆధారంగా మాత్రమే.\n'
            'మూల జనన సమయం భద్రంగా ఉంటుంది; Save చేసేముందు తనిఖీ చేయండి.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('రద్దు')),
          FilledButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('Apply & Recalculate')),
        ],
      ),
    );
    if (decision == true && mounted) {
      Navigator.of(context).pop(candidate.birthTime);
    }
  }

  Widget _eventRow(int index, _EventEntry row) {
    return Card(
      surfaceTintColor: Colors.transparent,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text('సంఘటన ${index + 1}',
                style: const TextStyle(fontWeight: FontWeight.bold))),
            if (_inputs.length > 3) IconButton(
              tooltip: 'తొలగించండి', icon: const Icon(Icons.delete_outline),
              onPressed: _searching ? null : () => setState(() {
                _inputs.removeAt(index).dispose();
                _result = null;
              }),
            ),
          ]),
          DropdownButtonFormField<String>(
            value: row.ruleId,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'గత సంఘటన రకం',
                border: OutlineInputBorder()),
            items: [for (final rule in MehtaBtrService.supportedEvents)
              DropdownMenuItem(value: rule.id,
                  child: Text('${rule.id} · ${_eventLabel(rule)}',
                      overflow: TextOverflow.ellipsis))],
            onChanged: _searching ? null : (id) {
              if (id != null) setState(() { row.ruleId = id; _result = null; });
            },
          ),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TextField(
              controller: row.date,
              onChanged: (_) => setState(() => _result = null),
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: 'తేదీ * (DD-MM-YYYY)',
                suffixIcon: IconButton(icon: const Icon(Icons.calendar_month),
                    onPressed: _searching ? null : () => _chooseDate(row)),
              ),
              keyboardType: TextInputType.datetime,
            )),
          ]),
          const SizedBox(height: 10),
          TextField(
            controller: row.time,
            onChanged: (_) => setState(() => _result = null),
            keyboardType: TextInputType.datetime,
            decoration: InputDecoration(
              border: const OutlineInputBorder(),
              labelText: 'సమయం (HH:MM:SS) — తెలిస్తే మాత్రమే',
              hintText: 'ఉదా: 10:30:00',
              suffixIcon: IconButton(icon: const Icon(Icons.access_time),
                  onPressed: _searching ? null : () => _chooseTime(row)),
            ),
          ),
          const SizedBox(height: 8),
          TextField(controller: row.note,
            onChanged: (_) => setState(() => _result = null),
            decoration: const InputDecoration(labelText: 'గమనిక / ఆధారం (ఐచ్ఛికం)',
                border: OutlineInputBorder()),
          ),
        ]),
      ),
    );
  }

  String _eventLabel(SkMehtaEventRule rule) => switch (rule.id) {
    'M01' => 'వివాహం',
    'M02' => 'తల్లిదండ్రుల వివాహం',
    'M03' => 'ధనలాభం',
    'M04' || 'M05' => 'విదేశీ ప్రయాణం',
    'M06' => 'సంతానం జననం',
    'M07' => 'స్థిరాస్తి / ఇల్లు కొనుగోలు',
    'M08' => 'వాహనం కొనుగోలు',
    'M11' => 'ప్రభుత్వ ఉద్యోగం / ప్రమోషన్',
    'M12' => 'ప్రైవేట్ ఉద్యోగం / మార్పు',
    'M13' => 'కొత్త ఉద్యోగ నియామకం',
    'M14' => 'వ్యాపార ప్రారంభం',
    _ => rule.event,
  };

  Widget _resultCard(MehtaBtrResult report) {
    final best = report.best;
    if (best == null) return const SizedBox.shrink();
    final data = StringBuffer('Mehta BTR — Past event verification\n')
      ..writeln('Original: ${_stamp(report.originalBirthTime)}')
      ..writeln('Tested times: ${report.testedTimes}')
      ..writeln('Best evidence: ${(best.evidenceShare * 100).toStringAsFixed(1)}%')
      ..writeln('Leading candidate: ${_stamp(best.birthTime)}')
      ..writeln('Correction: ${_correction(best.birthTime, report.originalBirthTime)}')
      ..writeln('Ambiguous: ${!report.distinguishable}');
    for (final row in best.evidence) {
      data.writeln('${row.ruleName} ${_date(row.event.occurredAt)} : '
          '${(row.combinedShare * 100).toStringAsFixed(1)}%');
    }
    return Card(
      color: const Color(0xFFF1F4FC),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('BTR Search ఫలితాలు',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text('పరీక్షించిన జనన సమయాలు: ${report.testedTimes}'),
          Text('అసలు జనన సమయం: ${_stamp(report.originalBirthTime)}'),
          Text('పరిశీలించిన గత సంఘటనలు: ${best.evidence.length}'),
          if (best.evidence.length < MehtaBtrService.recommendedEvents)
            const Text('5–10 స్వతంత్ర సంఘటనలు ఇస్తే పోలిక మరింత ప్రయోజనకరంగా ఉంటుంది.',
                style: TextStyle(color: Color(0xFF8B3A43))),
          Text('సూచించిన సమయ మార్పు: ${_correction(best.birthTime, report.originalBirthTime)}'),
          const SizedBox(height: 12),
          Text(report.distinguishable
            ? 'పోలికలో ముందున్న ప్రతిపాదిత జనన సమయం: ${_stamp(best.birthTime)}'
            : 'ఒకే ఖచ్చితమైన BTR సమయం నిర్ణయించలేకపోయాం.',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          Text('ఉత్తమ ఆధార సరిపోలిక సూచిక: '
              '${(best.evidenceShare * 100).toStringAsFixed(1)}% '
              '(సంభవించే అవకాశం కాదు)'),
          if (report.rangeStart != null && report.rangeEnd != null)
            Text('సమాన బలంతో ఉన్న పరిధి: '
                '${_stamp(report.rangeStart!)} – ${_stamp(report.rangeEnd!)}'),
          const SizedBox(height: 8),
          const Text('ఇది Mehta AD–PD–Sukshma సరిపోలిక ఆధారిత ప్రయోగాత్మక ర్యాంకింగ్. '
              'పుస్తకంలో ధృవీకరించిన పూర్తి BTR సూత్రం కాదు. '
              'దశా ఫలితాల ఆధారంగా సెకన్ల ఖచ్చితత్వం నిర్ధారించబడదు.',
              style: TextStyle(fontSize: 12.5, height: 1.5)),
          const SizedBox(height: 12),
          ...best.evidence.asMap().entries.map((entry) {
            final e = entry.value;
            return ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: Text('${_eventLabel(MehtaBtrService.ruleFor(e.event.ruleId))} '
                  '• ${_date(e.event.occurredAt)} '
                  '• ${e.event.timeKnown ? _time(e.event.occurredAt) : 'సమయం నమోదు చేయలేదు'}'),
              subtitle: Text('ఆధార సరిపోలిక '
                  '${(e.combinedShare * 100).toStringAsFixed(1)}%'),
              children: [
                ListTile(title: const Text('వింశోత్తరి — AD → PD → సూక్ష్మ'),
                    subtitle: Text('${e.vimshottariLords}\n'
                        'Match: ${(e.vimshottariShare * 100).toStringAsFixed(1)}%')),
                ListTile(title: const Text('త్రిభాగి — AD → PD → సూక్ష్మ'),
                    subtitle: Text('${e.tribhagiLords}\n'
                        'Match: ${(e.tribhagiShare * 100).toStringAsFixed(1)}%')),
                ListTile(title: const Text('Mehta Rule / భావాధిపతులు'),
                    subtitle: Text('Rule ${e.event.ruleId} — ${e.ruleName}\n'
                        'లగ్నం: ${e.expectedAsc.join(', ')}\n'
                        'చంద్రలగ్నం: ${e.expectedMoonAsc.join(', ')}\n'
                        'దశా మ్యాచ్ మాత్రమే; గ్రహబలం, మూలగ్రంథ పట్టికను అదనంగా పరిశీలించాలి.')),
              ],
            );
          }),
          const Divider(),
          const Text('మొదటి 3 సమయాల పోలిక',
              style: TextStyle(fontWeight: FontWeight.bold)),
          ...report.candidates.take(3).map((candidate) => ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(_stamp(candidate.birthTime)),
              trailing: Text('${(candidate.evidenceShare * 100).toStringAsFixed(1)}%'))),
          const SizedBox(height: 12),
          if (report.distinguishable)
            FilledButton.icon(
              onPressed: () => _useCandidate(best),
              icon: const Icon(Icons.check),
              label: const Text('BTR Time వర్తింపజేసి చక్రం మళ్లీ లెక్కించండి'),
            )
          else
            const Text('ప్రస్తుతం ఏ సమయాన్నీ ఆటోమేటిక్‌గా Save / Apply చేయడం లేదు. '
                'సంఘటనల తేదీలు, పుట్టిన సమయ పరిధిని ధృవీకరించి మళ్లీ పరీక్షించండి.',
                style: TextStyle(color: Color(0xFF8B3A43))),
          OutlinedButton.icon(
            icon: const Icon(Icons.copy), label: const Text('BTR Report Copy'),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: data.toString()));
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('BTR నివేదిక కాపీ అయింది')));
            },
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('S.K. Mehta — BTR / గత సంఘటనలు')),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(14), children: [
      const Text('Birth Time Rectification — గత సంఘటనల ఆధారంగా పరిశీలన',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text('మూల జనన సమయం: ${_stamp(widget.birthData.originalBirthDateTime)}'),
      Text('జనన స్థలం: ${widget.birthData.place}'),
      const SizedBox(height: 8),
      const Text('కనీసం 3 వేర్వేరు సంఘటనలు తప్పనిసరి; 5–10 సంఘటనలు ఉత్తమం. '
          'గరిష్ఠంగా 30 నమోదు చేయవచ్చు. సంఘటన తేదీ తప్పనిసరి, సమయం తెలిసినప్పుడే ఇవ్వండి. '
          'తెలియని సమయానికి 12:00ను లెక్కింపు నమూనాగా తీసుకుంటాం; అది సంఘటన సమయం కాదు.',
          style: TextStyle(height: 1.5)),
      const SizedBox(height: 12),
      ..._inputs.asMap().entries.map((entry) => _eventRow(entry.key, entry.value)),
      OutlinedButton.icon(
        icon: const Icon(Icons.add),
        label: Text('మరో సంఘటన చేర్చండి (${_inputs.length}/${MehtaBtrService.maxEvents})'),
        onPressed: _searching || _inputs.length >= MehtaBtrService.maxEvents
            ? null : () => setState(() {
                _inputs.add(_EventEntry('M01'));
                _result = null;
              }),
      ),
      const SizedBox(height: 12),
      DropdownButtonFormField<int>(
        value: _rangeMinutes,
        isExpanded: true,
        decoration: const InputDecoration(
          labelText: 'తెలిసిన జనన సమయం చుట్టూ Search పరిధి',
          border: OutlineInputBorder(),
        ),
        items: const [
          DropdownMenuItem(value: 30, child: Text('±30 నిమిషాలు')),
          DropdownMenuItem(value: 60, child: Text('±60 నిమిషాలు')),
          DropdownMenuItem(value: 120, child: Text('±120 నిమిషాలు')),
          DropdownMenuItem(value: 360, child: Text('±6 గంటలు (అంచనా సమయానికి)')),
          DropdownMenuItem(value: 720, child: Text('±12 గంటలు (సమయం తెలియకపోతే)')),
        ],
        onChanged: _searching ? null : (value) {
          if (value != null) setState(() { _rangeMinutes = value; _result = null; });
        },
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: _searching ? null : _save,
            icon: const Icon(Icons.save_outlined), child: const Text('సంఘటనలు Save'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.icon(onPressed: _searching ? null : _search,
            icon: const Icon(Icons.search), child: const Text('Final BTR Search'))),
      ]),
      if (_searching) ...[
        const SizedBox(height: 12),
        LinearProgressIndicator(value: _total == 0 ? null :
            (_completed / _total).clamp(0.0, 1.0).toDouble()),
        Text('సమయాలు పరిశీలిస్తున్నాం: $_completed / $_total'),
      ],
      if (_error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 12),
        child: Text(_error!, style: const TextStyle(color: Colors.red))),
      if (_result != null) _resultCard(_result!),
      const SizedBox(height: 14),
      const Text('నియమ మూలం: S.K. Mehta — Synchronization of Period / '
          'New Dimensions. గణన: యాప్‌లో అమర్చిన exploratory candidate search. '
          'ఈ పద్ధతితో అసలు పుట్టిన సమయం సెకన్ల స్థాయిలో నిర్ధారణ అవుతుందని చెప్పలేం.',
          style: TextStyle(fontSize: 12.5, height: 1.5)),
    ])),
  );
}
