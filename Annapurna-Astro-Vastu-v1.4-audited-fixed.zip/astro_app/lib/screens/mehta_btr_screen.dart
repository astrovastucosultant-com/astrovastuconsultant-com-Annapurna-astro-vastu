import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../astrology/mehta_btr_service.dart';
import '../astrology/btr_integrated_method_service.dart';
import '../astrology/bpd_pada_dasa_service.dart';
import '../astrology/sk_mehta_service.dart';
import '../astrology/btr_mehta_rule_bridge.dart';
import 'mehta_btr_rulebook_screen.dart';
import '../models/birth_data.dart';

class _EventEntry {
  String ruleId;
  String? sourceRuleId;
  String reliability = 'reported';
  final TextEditingController correlationGroup = TextEditingController();
  final TextEditingController date = TextEditingController();
  final TextEditingController time = TextEditingController();
  final TextEditingController note = TextEditingController();

  _EventEntry(this.ruleId);

  void dispose() {
    date.dispose();
    time.dispose();
    note.dispose();
    correlationGroup.dispose();
  }
}

class MehtaBtrScreen extends StatefulWidget {
  final BirthData birthData;

  const MehtaBtrScreen({super.key, required this.birthData});

  @override
  State<MehtaBtrScreen> createState() => _MehtaBtrScreenState();
}

class _MehtaBtrScreenState extends State<MehtaBtrScreen> {
  final List<_EventEntry> _inputs = <_EventEntry>[];
  int _rangeMinutes = 60;
  BpdProfile _bpdProfile = BpdProfile.vaaniSeven;
  DateTime? _fineCenter;
  MehtaBtrResult? _result;
  String? _error;
  bool _searching = false;
  bool _userEdited = false;
  int _completed = 0;
  int _total = 0;
  Map<String, dynamic> _linkedCatalog = {};
  Map<String, dynamic> _linkedTopics = {};
  String? _linkLoadError;

  String get _prefKey =>
      'mehta_btr_events_${widget.birthData.originalBirthDateTime.toIso8601String()}_${widget.birthData.latitude}_${widget.birthData.longitude}';

  @override
  void initState() {
    super.initState();
    const initial = <String>['M01', 'M06', 'M11', 'M07', 'M14'];
    for (final key in initial) {
      _inputs.add(_EventEntry(key));
    }
    _restore();
    _loadLinkedRules();
  }

  Future<void> _loadLinkedRules() async {
    try {
      final paths = <String>[
        'assets/btr/event_to_mehta_topic_links.json',
        'assets/btr/sk_mehta_new_dimensions_206.json',
        'assets/btr/sk_mehta_new_rules_85.json',
      ];
      final raw = await Future.wait(paths.map(rootBundle.loadString));
      final meta = jsonDecode(raw[0]) as Map<String,dynamic>;
      final docs = <String,dynamic>{};
      for (final source in raw.skip(1)) {
        final parsed = jsonDecode(source) as Map<String,dynamic>;
        for (final item in parsed['rules'] as List<dynamic>) {
          final row = Map<String,dynamic>.from(item as Map);
          docs[row['id'].toString()] = row;
        }
      }
      if (mounted) setState(() {
        _linkedTopics = Map<String,dynamic>.from(meta['event_types'] as Map);
        _linkedCatalog = docs;
      });
    } catch (e) {
      if (mounted) setState(() => _linkLoadError = e.toString());
    }
  }

  List<String> _availableSourceRules(String eventId) {
    final topic = BtrMehtaRuleBridge.topicForEvent(eventId);
    final category = _linkedTopics[topic];
    if (category is! Map) return [];
    return <String>[
      for (final key in ['nd_rule_ids','r85_rule_ids'])
        ...((category[key] as List<dynamic>?) ?? []).map((id) => id.toString()),
    ].where(_linkedCatalog.containsKey).toList();
  }

  String _sourceTitle(String id) {
    final raw = _linkedCatalog[id];
    if (raw is Map) return raw['title']?.toString() ?? id;
    return id;
  }

  void _openRule(String id) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => MehtaBtrRulebookScreen(
        initialRuleId: id,
        onOpenBtr: () => Navigator.of(context).pop(),
        btrButtonLabel: 'BTR గత సంఘటనలకు తిరిగి వెళ్లండి',
      ),
    ));
  }

  @override
  void dispose() {
    for (final input in _inputs) {
      input.dispose();
    }
    super.dispose();
  }

  static String _two(int value) => value.toString().padLeft(2, '0');

  static String _date(DateTime date) =>
      '${_two(date.day)}-${_two(date.month)}-${date.year}';

  static String _time(DateTime date) =>
      '${_two(date.hour)}:${_two(date.minute)}:${_two(date.second)}';

  String _stamp(DateTime date) => '${_date(date)} ${_time(date)}';

  String _correction(DateTime proposed, DateTime original) {
    final seconds = proposed.difference(original).inSeconds;
    final sign = seconds < 0 ? '−' : '+';
    final absolute = seconds.abs();
    final hours = absolute ~/ 3600;
    final minutes = (absolute % 3600) ~/ 60;
    final remaining = absolute % 60;
    return '$sign$hours గంటలు $minutes నిమిషాలు $remaining సెకన్లు';
  }

  DateTime? _readDate(String raw) {
    final match = RegExp(r'^(\d{2})-(\d{2})-(\d{4})$').firstMatch(raw.trim());
    if (match == null) return null;
    final day = int.parse(match.group(1)!);
    final month = int.parse(match.group(2)!);
    final year = int.parse(match.group(3)!);
    if (year < 1900 || year > 2100) return null;
    final value = DateTime(year, month, day);
    if (value.year != year || value.month != month || value.day != day) {
      return null;
    }
    return value;
  }

  (int, int, int)? _readTime(String raw) {
    if (raw.trim().isEmpty) return (12, 0, 0);
    final match = RegExp(r'^(\d{1,2}):(\d{2})(?::(\d{2}))?$')
        .firstMatch(raw.trim());
    if (match == null) return null;
    final hour = int.parse(match.group(1)!);
    final minute = int.parse(match.group(2)!);
    final second = int.tryParse(match.group(3) ?? '0') ?? 0;
    if (hour > 23 || minute > 59 || second > 59) return null;
    return (hour, minute, second);
  }

  Future<void> _restore() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedProfile = prefs.getString('${_prefKey}_bpd_profile');
      if (savedProfile != null && mounted && !_userEdited) {
        final selected = BpdProfile.values.where((p) => p.name == savedProfile);
        if (selected.isNotEmpty) setState(() => _bpdProfile = selected.first);
      }
      final raw = prefs.getString(_prefKey);
      if (raw == null || !mounted || _userEdited || _searching) return;
      final rows = jsonDecode(raw) as List<dynamic>;
      if (rows.isEmpty || rows.length > MehtaBtrService.maxEvents) return;
      final restored = <_EventEntry>[];
      for (final object in rows) {
        if (object is! Map) continue;
        final id = object['id']?.toString() ?? '';
        if (!MehtaBtrService.supportedEvents.any((r) => r.id == id)) continue;
        final item = _EventEntry(id);
        item.sourceRuleId = object['sourceRuleId']?.toString();
        final status = object['reliability']?.toString();
        if (['verified','reported','uncertain'].contains(status)) {
          item.reliability = status!;
        }
        item.correlationGroup.text = object['correlationGroup']?.toString() ?? '';
        item.date.text = object['date']?.toString() ?? '';
        item.time.text = object['time']?.toString() ?? '';
        item.note.text = object['note']?.toString() ?? '';
        restored.add(item);
      }
      if (restored.length < 3) {
        for (final item in restored) { item.dispose(); }
        return;
      }
      if (!mounted || _userEdited || _searching) {
        for (final item in restored) { item.dispose(); }
        return;
      }
      setState(() {
        for (final item in _inputs) { item.dispose(); }
        _inputs.clear();
        _inputs.addAll(restored);
      });
    } catch (_) {
      // Failed restoration must not prevent manual BTR event entry.
    }
  }

  Future<void> _save({bool silent = false}) async {
    // Suppress a pending async restore from overwriting the entries.
    _userEdited = true;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('${_prefKey}_bpd_profile', _bpdProfile.name);
    await prefs.setString(_prefKey, jsonEncode([
      for (final item in _inputs)
        {'id': item.ruleId, 'sourceRuleId': item.sourceRuleId,
          'date': item.date.text.trim(),
          'time': item.time.text.trim(), 'note': item.note.text.trim(),
          'reliability': item.reliability,
          'correlationGroup': item.correlationGroup.text.trim()},
    ]));
    if (mounted && !silent) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('గత సంఘటనలు ఈ పరికరంలో సేవ్ అయ్యాయి')),
      );
    }
  }

  Future<void> _chooseDate(_EventEntry entry) async {
    if (_searching) return;
    final current = _readDate(entry.date.text) ?? DateTime.now();
    final firstDate = DateTime(widget.birthData.originalBirthDateTime.year);
    final selected = await showDatePicker(
      context: context,
      initialDate: current.isBefore(firstDate)
          ? firstDate
          : (current.isAfter(DateTime.now()) ? DateTime.now() : current),
      firstDate: firstDate,
      lastDate: DateTime.now(),
    );
    if (selected == null || !mounted || _searching) return;
    setState(() {
      _userEdited = true;
      entry.date.text = _date(selected);
      _result = null;
    });
  }

  Future<void> _chooseTime(_EventEntry entry) async {
    if (_searching) return;
    final parsed = _readTime(entry.time.text) ?? (12, 0, 0);
    final value = await showTimePicker(
      context: context,
      initialTime: TimeOfDay(hour: parsed.$1, minute: parsed.$2),
    );
    if (value == null || !mounted || _searching) return;
    setState(() {
      _userEdited = true;
      entry.time.text = '${_two(value.hour)}:${_two(value.minute)}:00';
      _result = null;
    });
  }

  List<MehtaBtrEvent>? _gather() {
    final observed = <MehtaBtrEvent>[];
    for (var i = 0; i < _inputs.length; i++) {
      final item = _inputs[i];
      final raw = item.date.text.trim();
      if (raw.isEmpty && item.time.text.trim().isEmpty &&
          item.note.text.trim().isEmpty) continue;
      final date = _readDate(raw);
      if (date == null) {
        _setError('${i + 1}వ సంఘటన తేదీ DD-MM-YYYY రూపంలో ఇవ్వండి.');
        return null;
      }
      final time = _readTime(item.time.text);
      if (time == null) {
        _setError('${i + 1}వ సంఘటన సమయం HH:MM:SS రూపంలో ఇవ్వండి.');
        return null;
      }
      observed.add(MehtaBtrEvent(
        ruleId: item.ruleId,
        occurredAt: DateTime(date.year, date.month, date.day,
            time.$1, time.$2, time.$3),
        timeKnown: item.time.text.trim().isNotEmpty,
        note: item.note.text.trim(),
        reliability: item.reliability,
        correlationGroup: item.correlationGroup.text.trim(),
        sourceRuleId: _availableSourceRules(item.ruleId).contains(item.sourceRuleId)
            ? item.sourceRuleId : null,
      ));
    }
    final issue = MehtaBtrService.validateEvents(
        observed, widget.birthData.originalBirthDateTime);
    if (issue != null) {
      _setError(issue);
      return null;
    }
    return observed;
  }

  void _setError(String value) => setState(() { _error = value; _result = null; });

  Future<void> _search() async {
    if (_searching) return;
    final events = _gather();
    if (events == null) return;
    if (_linkedCatalog.isEmpty && _inputs.any((r) => r.sourceRuleId != null)) {
      _setError('మూలగ్రంథ రూల్స్ లోడ్ అయ్యేవరకు వేచి ఉండండి.');
      return;
    }
    // Mark searching before awaiting storage, so a second click cannot start
    // another search and editable rows cannot change during calculation.
    setState(() {
      _error = null;
      _result = null;
      _searching = true;
      _completed = 0;
      _total = 1;
    });
    try {
      await _save(silent: true);
    } catch (_) {
      // Searching still works when local-device persistence is unavailable.
    }
    if (!mounted) return;
    try {
      final result = await MehtaBtrService.search(
        natal: widget.birthData,
        events: events,
        plusMinusMinutes: _rangeMinutes,
        bpdProfile: _bpdProfile,
        searchCenter: _fineCenter,
        onProgress: (done, total) {
          if (!mounted) return;
          if (done == total || done % 5 == 0) {
            setState(() { _completed = done; _total = total; });
          }
        },
      );
      if (mounted) setState(() => _result = result);
    } catch (error) {
      if (mounted) _setError('BTR Search పూర్తి కాలేదు: $error');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  Future<void> _useCandidate(MehtaBtrCandidate candidate, {bool manual = false}) async {
    if (!manual && _result?.distinguishable != true) return;
    final decision = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(manual ? 'అభ్యర్థి సమయాన్ని స్వయంగా వర్తింపజేయాలా?'
          : 'BTR సమయం వర్తింపజేయాలా?'),
        content: Text('ప్రతిపాదిత సమయం: ${_stamp(candidate.birthTime)}\n'
            'ఈ సమయం గత సంఘటనల రూల్ సరిపోలిక ఆధారంగా ప్రతిపాదన మాత్రమే.\n'
            '${manual ? 'ఇది నిర్ధారించిన జనన సెకను కాదు.\n' : ''}'
            'మూల జనన సమయం భద్రంగా ఉంటుంది; Save చేసేముందు తనిఖీ చేయండి.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false),
              child: const Text('రద్దు')),
          FilledButton(onPressed: () => Navigator.pop(context, true),
              child: const Text('Apply & Recalculate')),
        ],
      ),
    );
    if (decision == true && mounted) {
      Navigator.of(context).pop(candidate.birthTime);
    }
  }

  Widget _eventRow(int index, _EventEntry row) {
    return Card(
      surfaceTintColor: Colors.transparent,
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text('సంఘటన ${index + 1}',
                style: const TextStyle(fontWeight: FontWeight.bold))),
            if (_inputs.length > 3) IconButton(
              tooltip: 'తొలగించండి', icon: const Icon(Icons.delete_outline),
              onPressed: _searching ? null : () => setState(() {
                _userEdited = true;
                _inputs.removeAt(index).dispose();
                _result = null;
              }),
            ),
          ]),
          DropdownButtonFormField<String>(
            value: row.ruleId,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'గత సంఘటన రకం',
                border: OutlineInputBorder()),
            items: [for (final rule in MehtaBtrService.supportedEvents)
              DropdownMenuItem(value: rule.id,
                  child: Text('${rule.id} · ${_eventLabel(rule)}',
                      overflow: TextOverflow.ellipsis))],
            onChanged: _searching ? null : (id) {
              if (id != null) setState(() {
                _userEdited = true; row.ruleId = id; row.sourceRuleId = null; _result = null;
              });
            },
          ),
          const SizedBox(height: 10),
          if (_linkedCatalog.isNotEmpty) ...[
            DropdownButtonFormField<String>(
              value: _availableSourceRules(row.ruleId).contains(row.sourceRuleId)
                  ? row.sourceRuleId : null,
              isExpanded:true,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: 'సంబంధిత SK Mehta మూల రూల్ (ఐచ్ఛికం)'),
              hint: const Text('ఎంచుకోలేదు — దశా పరీక్ష మాత్రమే'),
              items: [
                for (final id in _availableSourceRules(row.ruleId))
                  DropdownMenuItem(value:id,
                    child: Text('$id • ${_sourceTitle(id)}',
                      maxLines:1, overflow:TextOverflow.ellipsis)),
              ],
              onChanged: _searching ? null : (id) => setState(() {
                _userEdited = true; row.sourceRuleId = id; _result = null;
              }),
            ),
            if (row.sourceRuleId != null) ...[
              TextButton.icon(onPressed: _searching ? null : () => _openRule(row.sourceRuleId!),
                icon: const Icon(Icons.menu_book),
                label: Text('రూల్ ${row.sourceRuleId} పూర్తి వివరాలు')),
              Text(BtrMehtaRuleBridge.ruleNumber(row.sourceRuleId) != null
                  ? 'R రూల్: యాప్‌లో గణన ఉంటేనే పరీక్షిస్తాం; లేదంటే మాన్యువల్‌గా చూపిస్తాం.'
                  : 'ND రూల్: కాంబినేషన్ స్వయంచాలక పరిశీలన ఇంకా అందుబాటులో లేదు.',
                  style: const TextStyle(fontSize:12, color:Colors.deepOrange)),
              TextButton.icon(
                onPressed: _searching ? null : () => setState(() {
                  _userEdited = true; row.sourceRuleId = null; _result = null;
                }),
                icon: const Icon(Icons.clear),
                label: const Text('ఎంచుకున్న రూల్ తొలగించండి'),
              ),
            ],
            const SizedBox(height:10),
          ] else if (_linkLoadError != null)
            Text('గ్రంథ లింకులు లోడ్ కాలేదు: $_linkLoadError'),
          Row(children: [
            Expanded(child: TextField(
              controller: row.date,
              enabled: !_searching,
              onChanged: (_) => setState(() {
                _userEdited = true; _result = null;
              }),
              decoration: InputDecoration(
                border: const OutlineInputBorder(),
                labelText: 'తేదీ * (DD-MM-YYYY)',
                suffixIcon: IconButton(icon: const Icon(Icons.calendar_month),
                    onPressed: _searching ? null : () => _chooseDate(row)),
              ),
              keyboardType: TextInputType.datetime,
            )),
          ]),
          const SizedBox(height: 10),
          TextField(
            controller: row.time,
            enabled: !_searching,
            onChanged: (_) => setState(() {
              _userEdited = true; _result = null;
            }),
            keyboardType: TextInputType.datetime,
            decoration: InputDecoration(
              border: const OutlineInputBorder(),
              labelText: 'సమయం (HH:MM:SS) — తెలిస్తే మాత్రమే',
              hintText: 'ఉదా: 10:30:00',
              suffixIcon: IconButton(icon: const Icon(Icons.access_time),
                  onPressed: _searching ? null : () => _chooseTime(row)),
            ),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: row.reliability,
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'సంఘటన ఆధారం / Reliability',
              border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value:'verified',
                child:Text('ఆధారపూర్వక తేదీ — Verified')),
              DropdownMenuItem(value:'reported',
                child:Text('గుర్తున్న తేదీ — Reported')),
              DropdownMenuItem(value:'uncertain',
                child:Text('సందేహాస్పదం — Uncertain')),
            ],
            onChanged: _searching ? null : (value) {
              if (value != null) setState(() {
                _userEdited = true; row.reliability = value; _result = null;
              });
            },
          ),
          const SizedBox(height: 8),
          TextField(
            controller: row.correlationGroup,
            enabled: !_searching,
            onChanged: (_) => setState(() {
              _userEdited = true; _result = null;
            }),
            decoration: const InputDecoration(
              labelText: 'ఒకే సంఘటన గ్రూప్ ID (ఐచ్ఛికం)',
              hintText: 'ఉదా: JOB-2020',
              helperText: 'అదే కారణంతో జరిగిన రెండు సంఘటనలకు ఒకే ID ఇవ్వండి',
              border: OutlineInputBorder()),
          ),
          const SizedBox(height: 8),
          TextField(controller: row.note,
            enabled: !_searching,
            onChanged: (_) => setState(() {
              _userEdited = true; _result = null;
            }),
            decoration: const InputDecoration(labelText: 'గమనిక / ఆధారం (ఐచ్ఛికం)',
                border: OutlineInputBorder()),
          ),
        ]),
      ),
    );
  }

  String _eventLabel(SkMehtaEventRule rule) => switch (rule.id) {
    'M01' => 'వివాహం',
    'M02' => 'తల్లిదండ్రుల వివాహం',
    'M03' => 'ధనలాభం',
    'M04' || 'M05' => 'విదేశీ ప్రయాణం',
    'M06' => 'సంతానం జననం',
    'M07' => 'స్థిరాస్తి / ఇల్లు కొనుగోలు',
    'M08' => 'వాహనం కొనుగోలు',
    'M11' => 'ప్రభుత్వ ఉద్యోగం / ప్రమోషన్',
    'M12' => 'ప్రైవేట్ ఉద్యోగం / మార్పు',
    'M13' => 'కొత్త ఉద్యోగ నియామకం',
    'M14' => 'వ్యాపార ప్రారంభం',
    _ => rule.event,
  };

  Widget _resultCard(MehtaBtrResult report) {
    final best = report.best;
    if (best == null) return const SizedBox.shrink();
    final data = StringBuffer('Mehta BTR — Past event verification\n')
      ..writeln('Original: ${_stamp(report.originalBirthTime)}')
      ..writeln('Tested times: ${report.testedTimes}')
      ..writeln('1-second sampled candidates: ${report.oneSecondSamples}')
      ..writeln('Global exhaustive seconds: ${report.exhaustiveAcrossRequestedRange}')
      ..writeln('Discriminating observed events: ${report.discriminatingEvents}/${best.evidence.length}')
      ..writeln('Independent event groups: ${report.independentGroups}')
      ..writeln('Resolution: ${report.resolutionNote}')
      ..writeln('BPD source profile: ${_bpdProfile.label}')
      ..writeln('KP ascendant / varga fingerprint: ${best.timeSignature}')
      ..writeln('Best Rule Match Index (not probability): ${(best.evidenceShare * 100).toStringAsFixed(1)}%')
      ..writeln('Leading candidate: ${_stamp(best.birthTime)}')
      ..writeln('Correction: ${_correction(best.birthTime, report.originalBirthTime)}')
      ..writeln('Ambiguous: ${!report.distinguishable}')
      ..writeln('Lagna rule-match: ${(best.ascDashaShare*100).toStringAsFixed(1)}%')
      ..writeln('Moon lagna rule-match: ${best.moonDashaShare == null ? 'not evaluated' : '${(best.moonDashaShare!*100).toStringAsFixed(1)}%'}');
    for (final window in report.secondWindows) {
      data.writeln('Fine window: ${_stamp(window.start)} – ${_stamp(window.end)}');
    }
    for (final row in best.evidence) {
      final rule = MehtaBtrService.ruleFor(row.event.ruleId);
      data.writeln('${row.ruleName} ${_date(row.event.occurredAt)}'
          '${row.event.timeKnown ? ' ${_time(row.event.occurredAt)}' : ' (date only)'} : '
          '${(row.combinedShare * 100).toStringAsFixed(1)}%');
      if (row.sampledInstants > 1) {
        data.writeln('Daily spread: '
            '${(row.minimumShare * 100).toStringAsFixed(1)}% – '
            '${(row.maximumShare * 100).toStringAsFixed(1)}%');
      }
      data.writeln('Vimshottari AD/PD/Sukshma: ${row.vimshottariLords}');
      data.writeln('Tribhagi AD/PD/Sukshma: ${row.tribhagiLords}');
      data.writeln('Asc lords: ${row.expectedAsc.join(', ')}');
      data.writeln('Moon-asc lords: ${row.expectedMoonAsc.join(', ')}');
      data.writeln('Rule: ${rule.id}; source: ${rule.source}');
      data.writeln('Event quality: ${row.event.reliability}; correlation group: ${row.event.correlationGroup}');
      data.writeln('Lagna match: ${(row.ascDashaShare*100).toStringAsFixed(1)}%');
      data.writeln('Moon match: ${row.moonDashaShare == null ? 'not evaluated' : '${(row.moonDashaShare!*100).toStringAsFixed(1)}%'}');
      data.writeln('Selected source: ${row.sourceCheck.ruleId ?? 'none'} • ' 
          '${row.sourceCheck.evaluated ? (row.sourceCheck.matched ? 'matched' : 'not matched') : 'manual review'}');
      data.writeln('Source check: ${row.sourceCheck.explanation}');
      data.writeln('Candidate combined rule index: ${(row.rankingShare * 100).toStringAsFixed(1)}%');
      data.writeln('N12/BCP context (not second evidence): ${row.macroContext?.display ?? 'గురు స్థానం అందుబాటులో లేదు'}');
      data.writeln('BPD: ${row.bpdContext?.shortDisplay ?? '—'}');
      for (final p in row.bpdContext?.progressions ?? <BpdPlanetStep>[]) {
        data.writeln('BPD ${p.planet} cycle ${p.cycle} sign-period ${p.signPosition}/12: '
          '${BpdPadaDasaService.signs[p.natalSign]} → ${BpdPadaDasaService.signs[p.progressedSign]}'
          '${p.antardashaSign == null ? '' : ' • Antardasha ${p.antardashaPosition}/12 ${BpdPadaDasaService.signs[p.antardashaSign!]}'}');
      }
      final padas = row.bpdContext?.arudhaSigns ?? <int,int>{};
      data.writeln('BPD Padas: ${[for(var h=1;h<=12;h++) if(padas[h]!=null) 'P$h ${BpdPadaDasaService.signs[padas[h]!]}'].join(' • ')}');
      for (final indicator in row.bpdContext?.observations ?? <BpdObservation>[]) {
        data.writeln('${indicator.ruleId}: ${indicator.matched == null ? 'MANUAL' : (indicator.matched! ? 'MATCH' : 'NOT_TRIGGERED')} • ${indicator.details}');
      }
      for (final note in row.bpdContext?.notes ?? <String>[]) {
        data.writeln('BPD note: $note');
      }
    }
    data.writeln('\n===== సమగ్ర BTR పరిశీలన — BNN / BPD / BCP / SK Mehta / KP =====');
    data.writeln(BtrIntegratedMethodService.disclaimer);
    for (final summary in BtrIntegratedMethodService.overview(best.evidence, best.timeSignature)) {
      data.writeln(summary);
    }
    for (final e in best.evidence) {
      data.writeln('\n${e.ruleName} — ${_date(e.event.occurredAt)}');
      for (final f in BtrIntegratedMethodService.forEvent(e, best.timeSignature)) {
        data.writeln('[${f.method}] ${f.status.label} • ${f.sourceRule}');
        data.writeln(f.details);
      }
    }
    data.writeln('\nఈ 5 పద్ధతులకు శాతం ఓట్లు లెక్కించలేదు; BTR రెండుసార్లు స్కోర్ చేయలేదు.');
    return Card(
      color: const Color(0xFFF1F4FC),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('BPD ప్రొఫైల్: ${_bpdProfile.label}',
              style: const TextStyle(fontWeight: FontWeight.w700)),
          const Text('BTR Search ఫలితాలు',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text('పరీక్షించిన జనన సమయాలు: ${report.testedTimes}'),
          Text('1-సెకను స్థాయిలో పరీక్షించినవి: ${report.oneSecondSamples}'),
          Text('సమయాలను వేరు చేస్తున్న సంఘటనలు: ${report.discriminatingEvents}/${best.evidence.length} • '
              'స్వతంత్ర సంఘటనలు: ${report.independentGroups}'),
          if (report.discriminatingEvents == 0)
            const Text('ఈ సంఘటనలతో సమీప జనన సమయాలను వేరు చేయలేకపోయాం. '
              'అభ్యర్థి సమయం కంటే అనుకూల సమయ పరిధిని పరిశీలించండి.',
              style: TextStyle(color: Color(0xFF8B3A43))),
          Text(report.resolutionNote, style: const TextStyle(fontSize: 12.5)),
          ExpansionTile(title: const Text('KP లగ్న స్టార్ / సబ్ / సబ్-సబ్ మరియు వర్గలగ్నాలు'),
              children:[ListTile(subtitle: Text(best.timeSignature))]),
          ExpansionTile(
            initiallyExpanded: true,
            title: const Text('సమగ్ర BTR నివేదిక • BNN / BPD / BCP / SK Mehta / KP',
                style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('ప్రతి సంఘటనకు పద్ధతి–వారీ స్థితి • రూల్ ID • ఆధార వివరాలు'),
            children: [
              const ListTile(
                title: Text('5 పద్ధతులను కలిపి తప్పుడు శాతం ఇవ్వడం లేదు'),
                subtitle: Text(BtrIntegratedMethodService.disclaimer),
              ),
              for (final summary in BtrIntegratedMethodService.overview(
                  best.evidence, best.timeSignature))
                ListTile(dense: true, title: Text(summary)),

              for (final eventEvidence in best.evidence)
                ExpansionTile(
                  title: Text('${_eventLabel(MehtaBtrService.ruleFor(eventEvidence.event.ruleId))} '
                    '• ${_date(eventEvidence.event.occurredAt)}'),
                  subtitle: Text('సంఘటన ఆధారం: ${eventEvidence.event.reliability}'),
                  children: [
                    for (final finding in BtrIntegratedMethodService.forEvent(
                        eventEvidence, best.timeSignature))
                      ListTile(
                        dense: true,
                        title: Text('${finding.method} • ${finding.status.label}'),
                        subtitle: Text('${finding.sourceRule}\n${finding.details}'),
                      ),
                  ],
                ),
            ],
          ),
          Text('లగ్నం రూల్ మ్యాచ్: ${(best.ascDashaShare*100).toStringAsFixed(1)}% • '
              'చంద్రలగ్నం: ${best.moonDashaShare == null ? 'పరీక్షించలేదు' : '${(best.moonDashaShare!*100).toStringAsFixed(1)}%'} '
              '(బలం లేదా నిజ సమయ సంభావ్యత కాదు)'),
          Text('అసలు జనన సమయం: ${_stamp(report.originalBirthTime)}'),
          Text('పరిశీలించిన గత సంఘటనలు: ${best.evidence.length}'),
          if (best.evidence.length < MehtaBtrService.recommendedEvents)
            const Text('5–10 స్వతంత్ర సంఘటనలు ఇస్తే పోలిక మరింత ప్రయోజనకరంగా ఉంటుంది.',
                style: TextStyle(color: Color(0xFF8B3A43))),
          Text('సూచించిన సమయ మార్పు: ${_correction(best.birthTime, report.originalBirthTime)}'),
          const SizedBox(height: 12),
          Text(report.distinguishable
            ? 'పోలికలో ముందున్న ప్రతిపాదిత జనన సమయం: ${_stamp(best.birthTime)}'
            : 'ఒకే ఖచ్చితమైన BTR సమయం నిర్ణయించలేకపోయాం.',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          Text('ఉత్తమ ఆధార సరిపోలిక సూచిక: '
              '${(best.evidenceShare * 100).toStringAsFixed(1)}% '
              '(సంభవించే అవకాశం కాదు)'),
          if (report.rangeStart != null && report.rangeEnd != null)
            Text('సమాన బలంతో ఉన్న పరిధి: '
                '${_stamp(report.rangeStart!)} – ${_stamp(report.rangeEnd!)}'),
          const SizedBox(height: 8),
          if (!report.exhaustiveAcrossRequestedRange) ...[
            OutlinedButton.icon(
              onPressed: _searching ? null : () async {
                setState(() {
                  _fineCenter = best.birthTime;
                  _rangeMinutes = 5;
                  _result = null;
                });
                await _search();
              },
              icon: const Icon(Icons.saved_search),
              label: const Text('ఈ అభ్యర్థి చుట్టూ ±5 ని. Full 1-Second Search'),
            ),
          ],
          if (report.secondWindows.isNotEmpty) ...[
            const Text('1-సెకను స్థాయిలో పరిశీలించిన అనుకూల సమయ భాగాలు:',
                style: TextStyle(fontWeight: FontWeight.bold)),
            ...report.secondWindows.take(12).map((w) => Text(
                '${_stamp(w.start)} – ${_stamp(w.end)} '
                '• ${(w.ruleMatchIndex*100).toStringAsFixed(1)}%')),
            if (report.secondWindows.length > 12)
              Text('ఇంకా ${report.secondWindows.length-12} సమయ భాగాలు; పూర్తి వివరాలు కాపీ నివేదికలో చూడండి.'),
          ],
          const SizedBox(height: 8),
          const Text('ఇది Mehta AD–PD–Sukshma మరియు ఎంచుకున్న, గణించగల మూల రూల్స్ ఆధారిత ప్రయోగాత్మక ర్యాంకింగ్. '
              'పుస్తకంలో ధృవీకరించిన పూర్తి BTR సూత్రం కాదు. '
              'దశా ఫలితాల ఆధారంగా సెకన్ల ఖచ్చితత్వం నిర్ధారించబడదు.',
              style: TextStyle(fontSize: 12.5, height: 1.5)),
          const SizedBox(height: 12),
          ...best.evidence.asMap().entries.map((entry) {
            final e = entry.value;
            return ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: Text('${_eventLabel(MehtaBtrService.ruleFor(e.event.ruleId))} '
                  '• ${_date(e.event.occurredAt)} '
                  '• ${e.event.timeKnown ? _time(e.event.occurredAt) : 'సమయం నమోదు చేయలేదు'}'),
              subtitle: Text('ఆధారం: ${e.event.reliability} • రూల్ సరిపోలిక '
                  '${(e.combinedShare * 100).toStringAsFixed(1)}%'
                  '${e.sampledInstants > 1 ? ' • సమయం తెలియదు; రోజులో 3 పరిశీలనలు' : ''}'),
              children: [
                if (e.sampledInstants > 1)
                  ListTile(title: const Text('తేదీ మాత్రమే తెలిసింది'),
                    subtitle: Text('ఆ రోజు 00:00, 12:00, 23:59 సమయాల్లో '
                        'ఆధారాలను పరీక్షించి సగటు తీసుకున్నాం. సూచిక పరిధి: '
                        '${(e.minimumShare * 100).toStringAsFixed(1)}% – '
                        '${(e.maximumShare * 100).toStringAsFixed(1)}%. '
                        'మధ్యాహ్నం 12 గంటలకు సంఘటన జరిగిందని అర్థం కాదు.')),
                ExpansionTile(
                  title: const Text('BPD గ్రహ ప్రోగ్రెషన్ / అరూఢ / 23 నియమాలు'),
                  subtitle: Text(e.bpdContext?.profile.label ?? 'డేటా అందుబాటులో లేదు'),
                  children: [
                    ListTile(title: const Text('గ్రహాల రాశి చక్రం'),
                      subtitle: Text(e.bpdContext?.shortDisplay ?? '—')),
                    ...?e.bpdContext?.progressions.map((p) => ListTile(
                      dense:true,
                      title: Text('${p.planet} • చక్రం ${p.cycle} • రాశి కాలం ${p.signPosition}/12'),
                      subtitle: Text('జన్మ: ${BpdPadaDasaService.signs[p.natalSign]} → '
                        'ప్రోగ్రెషన్: ${BpdPadaDasaService.signs[p.progressedSign]}'
                        '${p.antardashaSign == null ? '' : ' • అంతర్దశ ${p.antardashaPosition}/12: ${BpdPadaDasaService.signs[p.antardashaSign!]}'}'),
                    )),
                    if(e.bpdContext!=null) ListTile(
                      title: const Text('P1–P12 అరూఢ పాద రాశులు'),
                      subtitle: Text([
                        for(var h=1;h<=12;h++)
                          if(e.bpdContext!.arudhaSigns.containsKey(h))
                            'P$h: ${BpdPadaDasaService.signs[e.bpdContext!.arudhaSigns[h]!]}',
                      ].join(' • ')),
                    ),
                    ...?e.bpdContext?.notes.map((note) => ListTile(
                        dense:true, subtitle:Text(note))),
                    ...?e.bpdContext?.observations.map((obs) => ListTile(
                      dense:true,
                      title:Text(obs.ruleId),
                      subtitle:Text('${obs.matched == null ? '⚪ మాన్యువల్' : (obs.matched! ? '🟢 షరతు వర్తించింది' : '⚪ షరతు కనిపించలేదు')} • ${obs.details}'),
                    )),
                    const ListTile(title: Text('ముఖ్య గమనిక'),
                      subtitle: Text('BPD గ్రహ చక్రాలు BTR సెకను ఎంపికకు అదనపు స్కోరు ఇవ్వవు. ' 
                        'మూలాల్లో భేదాలు ఉండటంతో Profile ఎంపికను విడిగా ఉంచాం.')),
                  ],
                ),
                ListTile(title: const Text('గురు 12-సంవత్సర / వార్షిక / BCP సందర్భం'),
                    subtitle: Text('${e.macroContext?.display ?? 'గురు స్థానం అందుబాటులో లేదు'}\n'
                      'ఈ నియమాలు సమీప జనన సెకన్లను గుర్తించే స్వతంత్ర ఆధారాలు కావు.')),
                ListTile(title: const Text('వింశోత్తరి — AD → PD → సూక్ష్మ'),
                    subtitle: Text('${e.vimshottariLords}\n'
                        'Match: ${(e.vimshottariShare * 100).toStringAsFixed(1)}%')),
                ListTile(title: const Text('త్రిభాగి — AD → PD → సూక్ష్మ'),
                    subtitle: Text('${e.tribhagiLords}\n'
                        'Match: ${(e.tribhagiShare * 100).toStringAsFixed(1)}%')),
                if (e.sourceCheck.ruleId != null) ListTile(
                    title: Text('ఎంపిక చేసిన మూల రూల్ ${e.sourceCheck.ruleId}'),
                    subtitle: Text(
                      '${e.sourceCheck.evaluated ? (e.sourceCheck.matched ? '✅ కాంబినేషన్ సరిపోయింది' : '❌ కాంబినేషన్ సరిపోలలేదు') : '⚪ మాన్యువల్ పరిశీలన అవసరం'}\n'
                      '${e.sourceCheck.explanation}\n'
                      'Dasha ${(e.combinedShare * 100).toStringAsFixed(1)}% • కలిపిన రూల్ సూచిక ${(e.rankingShare * 100).toStringAsFixed(1)}%'),
                    trailing: const Icon(Icons.menu_book_outlined),
                    onTap: () => _openRule(e.sourceCheck.ruleId!),
                ),
                ListTile(title: const Text('Mehta Rule / భావాధిపతులు'),
                    subtitle: Text('Rule ${e.event.ruleId} — ${e.ruleName}\n'
                        'లగ్నం: ${e.expectedAsc.join(', ')}\n'
                        'చంద్రలగ్నం: ${e.expectedMoonAsc.join(', ')}\n'
                        'మూలం: ${MehtaBtrService.ruleFor(e.event.ruleId).source}\n'
                        'దశా మ్యాచ్ మాత్రమే; గ్రహబలం, మూలగ్రంథ పట్టికను అదనంగా పరిశీలించాలి.')),
              ],
            );
          }),
          const Divider(),
          const Text('వేర్వేరు సమయ ప్రాంతాల్లో ఉన్న ప్రధాన అభ్యర్థులు',
              style: TextStyle(fontWeight: FontWeight.bold)),
          ...report.candidates.map((candidate) => ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(_stamp(candidate.birthTime)),
              subtitle: Text('Rule Match Index: '
                  '${(candidate.evidenceShare * 100).toStringAsFixed(1)}%'),
              trailing: !report.exhaustiveAcrossRequestedRange
                ? IconButton(
                    tooltip:'ఈ సమయం చుట్టూ పూర్తి 1s search',
                    icon:const Icon(Icons.saved_search),
                    onPressed: _searching ? null : () async {
                      setState(() {
                        _fineCenter = candidate.birthTime;
                        _rangeMinutes = 5;
                        _result = null;
                      });
                      await _search();
                    },
                  )
                : null)),
          const SizedBox(height: 12),
          if (report.distinguishable)
            FilledButton.icon(
              onPressed: () => _useCandidate(best),
              icon: const Icon(Icons.check),
              label: const Text('BTR Time వర్తింపజేసి చక్రం మళ్లీ లెక్కించండి'),
            )
          else
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('జనన సెకను స్వయంచాలకంగా నిర్ధారించలేకపోయాం. '
                'సంఘటనల ఆధారాలు ధృవీకరించండి లేదా బలమైన అభ్యర్థిని మాన్యువల్‌గా మాత్రమే వర్తింపజేయండి.',
                style: TextStyle(color: Color(0xFF8B3A43))),
              TextButton.icon(
                onPressed: () => _useCandidate(best, manual:true),
                icon: const Icon(Icons.edit_calendar),
                label: const Text('అభ్యర్థి సమయాన్ని Manual Apply / Recalculate'),
              ),
            ]),
          OutlinedButton.icon(
            icon: const Icon(Icons.copy), label: const Text('BTR Report Copy'),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: data.toString()));
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('BTR నివేదిక కాపీ అయింది')));
            },
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('S.K. Mehta — BTR / గత సంఘటనలు')),
    body: SafeArea(child: ListView(padding: const EdgeInsets.all(14), children: [
      const Text('Birth Time Rectification — గత సంఘటనల ఆధారంగా పరిశీలన',
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text('మూల జనన సమయం: ${_stamp(widget.birthData.originalBirthDateTime)}'),
      Text('జనన స్థలం: ${widget.birthData.place}'),
      Text('జనన టైమ్‌జోన్: UTC${widget.birthData.timezoneOffsetHours >= 0 ? '+' : ''}${widget.birthData.timezoneOffsetHours} • సంఘటన స్థాన టైమ్‌జోన్ వేరైతే సమయాన్ని నిర్ధారించండి.'),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => MehtaBtrRulebookScreen(
            onOpenBtr: () => Navigator.of(context).pop(),
            btrButtonLabel: 'BTR గత సంఘటనలకు తిరిగి వెళ్లండి',
          ))),
        icon: const Icon(Icons.menu_book_outlined),
        label: const Text('BNN / BCP / BPD / KP — BTR రూల్‌బుక్'),
      ),
      const SizedBox(height: 8),
      DropdownButtonFormField<BpdProfile>(
        value: _bpdProfile,
        isExpanded: true,
        decoration: const InputDecoration(labelText: 'BPD మూలగ్రంథ పద్ధతి',
          border: OutlineInputBorder()),
        items: [for (final p in BpdProfile.values)
          DropdownMenuItem(value:p,child:Text(p.label, maxLines:2))],
        onChanged: _searching ? null : (value) {
          if(value!=null) setState(() {
            _userEdited=true;_bpdProfile=value;_result=null;_fineCenter=null;
          });
        },
      ),
      const SizedBox(height: 8),
      const Text('BPD పాదాలు/గ్రహాల ప్రోగ్రెషన్, 23 నియమాల స్థితి గత సంఘటనలతో చూపిస్తాం. ' 
        'బృహత్ BTRలో ఇవి సందర్భ ఆధారాలు మాత్రమే; జనన సెకన్ల నిర్ధారణ కాదు.'),
      const SizedBox(height: 8),
      const Text('ప్రతి సంఘటనకు SK Mehta మూలగ్రంథ రూల్ ఎంచుకోవచ్చు. ' 
          'ధృవీకరించగలిగిన R-రూల్ షరతు మాత్రమే జనన సమయాల పోలికలో 25% భాగం; ' 
          'దశా పోలిక 75%. ఇది యాప్ డిజైన్ సూచిక, జనన సమయ ఖచ్చితత్వానికి ఆధారం కాదు. ' 
          'ND రూల్స్ మరియు పరీక్షించలేని రూల్స్ మాన్యువల్‌గా మాత్రమే చూపిస్తాం.'),
      const SizedBox(height:8),
      const Text('కనీసం 3 వేర్వేరు సంఘటనలు తప్పనిసరి; 5–10 సంఘటనలు ఉత్తమం. '
          'గరిష్ఠంగా 30 నమోదు చేయవచ్చు. సంఘటన తేదీ తప్పనిసరి, సమయం తెలిసినప్పుడే ఇవ్వండి. '
          'తెలియని సమయానికి 12:00ను లెక్కింపు నమూనాగా తీసుకుంటాం; అది సంఘటన సమయం కాదు.',
          style: TextStyle(height: 1.5)),
      const SizedBox(height: 12),
      ..._inputs.asMap().entries.map((entry) => _eventRow(entry.key, entry.value)),
      OutlinedButton.icon(
        icon: const Icon(Icons.add),
        label: Text('మరో సంఘటన చేర్చండి (${_inputs.length}/${MehtaBtrService.maxEvents})'),
        onPressed: _searching || _inputs.length >= MehtaBtrService.maxEvents
            ? null : () => setState(() {
                _userEdited = true;
                _inputs.add(_EventEntry('M01'));
                _result = null;
              }),
      ),
      const SizedBox(height: 12),
      if (_fineCenter != null)
        Text('1-సెకను శోధన కేంద్రం: ${_stamp(_fineCenter!)}'),
      DropdownButtonFormField<int>(
        value: _rangeMinutes,
        isExpanded: true,
        decoration: const InputDecoration(
          labelText: 'తెలిసిన జనన సమయం చుట్టూ Search పరిధి',
          border: OutlineInputBorder(),
        ),
        items: const [
          DropdownMenuItem(value: 1, child: Text('±1 నిమిషం — Full 1 Second')) ,
          DropdownMenuItem(value: 2, child: Text('±2 నిమిషాలు — Full 1 Second')),
          DropdownMenuItem(value: 5, child: Text('±5 నిమిషాలు — Full 1 Second')),
          DropdownMenuItem(value: 10, child: Text('±10 నిమిషాలు — Full 1 Second')),
          DropdownMenuItem(value: 30, child: Text('±30 నిమిషాలు')),
          DropdownMenuItem(value: 60, child: Text('±60 నిమిషాలు')),
          DropdownMenuItem(value: 120, child: Text('±120 నిమిషాలు')),
          DropdownMenuItem(value: 360, child: Text('±6 గంటలు (అంచనా సమయానికి)')),
          DropdownMenuItem(value: 720, child: Text('±12 గంటలు (సమయం తెలియకపోతే)')),
        ],
        onChanged: _searching ? null : (value) {
          if (value != null) setState(() {
            _userEdited = true; _rangeMinutes = value; _fineCenter = null; _result = null;
          });
        },
      ),
      const SizedBox(height: 12),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: _searching ? null : () => _save(),
            icon: const Icon(Icons.save_outlined), label: const Text('సంఘటనలు Save'))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.icon(onPressed: _searching ? null : _search,
            icon: const Icon(Icons.search), label: const Text('Final BTR Search'))),
      ]),
      if (_searching) ...[
        const SizedBox(height: 12),
        LinearProgressIndicator(value: _total == 0 ? null :
            (_completed / _total).clamp(0.0, 1.0).toDouble()),
        Text('సమయాలు పరిశీలిస్తున్నాం: $_completed / $_total'),
      ],
      if (_error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 12),
        child: Text(_error!, style: const TextStyle(color: Colors.red))),
      if (_result != null) _resultCard(_result!),
      const SizedBox(height: 14),
      const Text('నియమ మూలం: S.K. Mehta — Synchronization of Period / '
          'New Dimensions. గణన: యాప్‌లో అమర్చిన exploratory candidate search. '
          'ఈ పద్ధతితో అసలు పుట్టిన సమయం సెకన్ల స్థాయిలో నిర్ధారణ అవుతుందని చెప్పలేం.',
          style: TextStyle(fontSize: 12.5, height: 1.5)),
    ])),
  );
}
