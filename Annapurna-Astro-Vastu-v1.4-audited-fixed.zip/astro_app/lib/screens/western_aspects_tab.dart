import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/western_aspect_service.dart';

class WesternAspectsTab extends StatefulWidget {
  final AstroChartResult chart;
  const WesternAspectsTab({super.key, required this.chart});

  @override
  State<WesternAspectsTab> createState() => _WesternAspectsTabState();
}

class _WesternAspectsTabState extends State<WesternAspectsTab> {
  bool _minor = false;
  bool _nodes = false;
  double _orb = 1.0;

  @override
  Widget build(BuildContext context) {
    final matches = WesternAspectService.calculate(
      widget.chart.planets,
      includeMinor: _minor,
      includeNodes: _nodes,
      orbMultiplier: _orb,
    );
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Western Aspects • గ్రహ దృష్టికోణాలు',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        const Text('రెండు గ్రహాల longitude మధ్య తక్కువ కోణదూరాన్ని లెక్కించి Western aspect orbతో పోలుస్తుంది. '
            'ఇవి KP Cusp/Significators లేదా వేద గ్రహదృష్టులు కావు.'),
        const SizedBox(height: 12),
        SwitchListTile(
          title: const Text('Minor Aspects (30°, 150°)'),
          value: _minor,
          onChanged: (value) => setState(() => _minor = value),
        ),
        SwitchListTile(
          title: const Text('Rahu / Ketu చేర్చండి'),
          value: _nodes,
          onChanged: (value) => setState(() => _nodes = value),
        ),
        Text('Orb sensitivity: ${_orb.toStringAsFixed(2)}×',
            style: const TextStyle(fontWeight: FontWeight.w700)),
        Slider(
          min: 0.25, max: 1.5, divisions: 10,
          value: _orb,
          label: '${_orb.toStringAsFixed(2)}×',
          onChanged: (value) => setState(() => _orb = value),
        ),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (final aspect in WesternAspectService.definitions)
            if (_minor || aspect.exactAngle != 30 && aspect.exactAngle != 150)
              Chip(label: Text('${aspect.name} ${aspect.exactAngle.toStringAsFixed(0)}° '
                  '±${(aspect.defaultOrb * _orb).toStringAsFixed(1)}°')),
        ]),
        const SizedBox(height: 12),
        Text('Matched aspects: ${matches.length}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        if (matches.isEmpty)
          const Padding(padding: EdgeInsets.all(18), child: Text('ఈ orb పరిమితిలో సరిపోయే గ్రహ జంటలు లేవు.')),
        for (final m in matches)
          Card(
            child: ListTile(
              title: Text('${m.body1} – ${m.body2}', style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${m.aspect.name} • ${m.aspect.exactAngle.toStringAsFixed(0)}° '
                  '\nActual ${m.separation.toStringAsFixed(3)}° • Orb ${m.deviation.toStringAsFixed(3)}° '
                  '\nRule ID: ${m.ruleId}'),
              isThreeLine: true,
            ),
          ),
        const SizedBox(height: 12),
        const Text('గమనిక: కోణదూరం ఒకే అయనాంశ మార్పుకు స్వతంత్రం. ఇవి జ్యామితీయ సంబంధాలు మాత్రమే; '
            'సంఘటనలు లేదా జనన సమయ ఖచ్చితత్వానికి స్వతంత్ర నిర్ధారణ కాదు.',
            style: TextStyle(fontSize: 12)),
      ],
    );
  }
}
