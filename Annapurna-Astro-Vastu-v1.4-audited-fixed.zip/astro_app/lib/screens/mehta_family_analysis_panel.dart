import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/mehta_family_house_service.dart';
import '../astrology/mehta_family_interpretation_service.dart';

/// Build117: Mehta-only family analysis. Result -> Chart evidence -> Rule -> Source.
/// A relative-house reading is not a new birth horoscope for the relative.
class MehtaFamilyAnalysisPanel extends StatefulWidget {
  final AstroChartResult chart;
  const MehtaFamilyAnalysisPanel({super.key, required this.chart});

  @override
  State<MehtaFamilyAnalysisPanel> createState() => _MehtaFamilyAnalysisPanelState();
}

class _MehtaFamilyAnalysisPanelState extends State<MehtaFamilyAnalysisPanel> {
  String relationId = 'father';
  String topicId = 'self';
  bool showAllTopics = true;
  static const Color _ink = Color(0xFF6A2435);

  MehtaFamilyRelation get relation =>
      MehtaFamilyHouseService.relations.firstWhere((r) => r.id == relationId);
  MehtaFamilyTopic get topic =>
      MehtaFamilyHouseService.topics.firstWhere((t) => t.id == topicId);

  Color _color(MehtaFamilyFindingType type) {
    switch (type) {
      case MehtaFamilyFindingType.supporting:
        return const Color(0xFF157F4A);
      case MehtaFamilyFindingType.cautionary:
        return const Color(0xFFAB6712);
      case MehtaFamilyFindingType.mixed:
        return const Color(0xFF955719);
      case MehtaFamilyFindingType.undetermined:
        return const Color(0xFF657080);
    }
  }

  IconData _icon(MehtaFamilyFindingType type) {
    switch (type) {
      case MehtaFamilyFindingType.supporting:
        return Icons.check_circle_outline;
      case MehtaFamilyFindingType.cautionary:
        return Icons.report_problem_outlined;
      case MehtaFamilyFindingType.mixed:
        return Icons.compare_arrows;
      case MehtaFamilyFindingType.undetermined:
        return Icons.info_outline;
    }
  }

  Widget _paragraph(String text, {bool bold = false}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Text(text,
            style: TextStyle(
              height: 1.52,
              fontSize: 15,
              fontWeight: bold ? FontWeight.w800 : FontWeight.normal,
            )),
      );

  Widget _nextButton(String title, String caption, VoidCallback onTap) => Card(
        color: const Color(0xFFF7EFF1),
        surfaceTintColor: Colors.transparent,
        child: ListTile(
          title: Text(title,
              style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text(caption, style: const TextStyle(height: 1.4)),
          trailing: const Icon(Icons.chevron_right),
          onTap: onTap,
        ),
      );

  Widget _check(MehtaFamilyRuleCheck c) {
    final color = !c.matched
        ? const Color(0xFF78808A)
        : c.type == MehtaFamilyEvidenceType.support
            ? const Color(0xFF157F4A)
            : c.type == MehtaFamilyEvidenceType.caution
                ? const Color(0xFFAA6712)
                : const Color(0xFF667085);
    return Card(
      surfaceTintColor: Colors.transparent,
      color: c.matched ? const Color(0xFFF7F6F3) : const Color(0xFFFAFAFA),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(c.matched ? Icons.check_circle_outline : Icons.radio_button_unchecked,
              color: color, size: 22),
          const SizedBox(width: 10),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${c.id} — ${c.rule}',
                style: const TextStyle(fontWeight: FontWeight.bold, height: 1.4)),
            const SizedBox(height: 4),
            Text(c.observed, style: const TextStyle(height: 1.4)),
            Text(c.source,
                style: const TextStyle(fontSize: 12.5, color: Color(0xFF6F5F64))),
          ])),
        ]),
      ),
    );
  }

  String _angleStatus(MehtaFamilyAngleResult angle) {
    final stress = angle.title.contains('అప్పులు') || angle.title.contains('వ్యయం') ||
        angle.title.contains('వివాదాలు') || angle.title.contains('ఖర్చు') ||
        angle.title.contains('ఆటంకాలు');
    if (stress && angle.supporting > 0 && angle.cautionary == 0) {
      return 'సంబంధిత భావబలం — శుభఫలిత హామీ కాదు';
    }
    if (angle.supporting > 0 && angle.cautionary > 0) return 'మిశ్రమ ఆధారాలు';
    if (angle.supporting > 0) return 'అనుకూల బలం';
    if (angle.cautionary > 0) return 'ఆటంక సూచనలు';
    return 'ప్రత్యేక నియమం సరిపోలలేదు';
  }

  String _percentLabel(int? percent) => percent == null
      ? 'శాతం: ఆధారం లేదు'
      : 'భావబల సూచిక: $percent%';

  Widget _percentBar(int? percent, {String? detail}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(_percentLabel(percent),
              style: const TextStyle(fontWeight: FontWeight.w900,
                  fontSize: 17, color: _ink)),
          if (percent != null) ...[
            const SizedBox(height: 5),
            LinearProgressIndicator(
              value: percent / 100,
              minHeight: 7,
              borderRadius: BorderRadius.circular(8),
              backgroundColor: const Color(0xFFE6D9DA),
              valueColor: const AlwaysStoppedAnimation<Color>(_ink),
            ),
          ],
          if (detail != null)
            Padding(padding: const EdgeInsets.only(top: 4),
                child: Text(detail,
                    style: const TextStyle(fontSize: 12.5, height: 1.35))),
        ]),
      );

  Widget _angleCard(MehtaFamilyAngleResult angle, {bool detailed = false}) =>
      Card(
        margin: const EdgeInsets.symmetric(vertical: 4),
        color: const Color(0xFFFFFBF8),
        surfaceTintColor: Colors.transparent,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(angle.title,
                style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15.5)),
            _percentBar(angle.evidencePercent,
                detail: 'అనుకూల ${angle.supporting} · ప్రతికూల ${angle.cautionary}; '
                    'ఇది సంఘటన జరిగే అవకాశం కాదు.'),
            Text(_angleStatus(angle),
                style: TextStyle(color: _color(angle.type), fontWeight: FontWeight.bold)),
            const SizedBox(height: 3),
            Text(angle.interpretation, style: const TextStyle(height: 1.4)),
            if (detailed) ...[
              const SizedBox(height: 6),
              Text('పరిశీలన: ${angle.purpose}', style: const TextStyle(height: 1.4)),
              Text('జాతక ${angle.referenceHouse}వ భావం • అధిపతి ${MehtaFamilyHouseService.planetTelugu[angle.referenceLord] ?? angle.referenceLord}',
                  style: const TextStyle(height: 1.4)),
              Text('మూలం: ${angle.source}',
                  style: const TextStyle(fontSize: 12.5, height: 1.4)),
            ],
          ]),
        ),
      );

  void _openTrail(MehtaFamilyFinding finding) {
    final r = finding.relation;
    final t = finding.topic;
    final chart = widget.chart;
    var stage = 1;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFCFA),
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) {
          final title = stage == 1
              ? '2. జాతక పరిశీలన'
              : stage == 2
                  ? '3. రూల్స్ — సరిపోలిన షరతులు'
                  : '4. మూలగ్రంథం / పరిహారం';
          final natalSign = MehtaFamilyHouseService.houseSign(
              chart, finding.targetHouse);
          final startSign = MehtaFamilyHouseService.houseSign(
              chart, finding.relationHouse);
          PlanetPosition? moon;
          for (final planet in chart.planets) {
            if (planet.name == 'Moon') { moon = planet; break; }
          }
          final moonRelativeSign = moon == null ? null :
              (moon.signIndex + finding.relationHouse - 1) % 12;
          final moonTopicSign = moon == null ? null :
              (moon.signIndex + finding.targetHouse - 1) % 12;
          return SafeArea(
            top: false,
            child: FractionallySizedBox(
              heightFactor: 0.9,
              child: ListView(
                // Every stage starts at the top; do not carry the previous
                // long inspection's scroll offset into the rule screen.
                key: ValueKey<int>(stage),
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 32),
                children: [
                  Row(children: [
                    if (stage > 1)
                      IconButton(
                          onPressed: () => setSheetState(() => stage--),
                          icon: const Icon(Icons.arrow_back)),
                    Expanded(
                        child: Text(title,
                            style: const TextStyle(
                                fontWeight: FontWeight.w900, fontSize: 20))),
                  ]),
                  const SizedBox(height: 8),
                  _paragraph('${r.title} → ${t.title}', bold: true),
                  _paragraph('1. ఫలితం: ${finding.heading}', bold: true),
                  _percentBar(finding.evidencePercent,
                      detail: 'ఆధారాలు లభించిన ప్రత్యేక భావాలు: '
                          '${finding.scoredAngleCount}/${finding.angles.map((a) => a.aspectTopicId).toSet().length}. '
                          'ఇది విజయావకాశం లేదా Mehta గ్రంథం ఇచ్చిన శాతం కాదు.'),
                  _paragraph(finding.result),
                  if (stage == 1) ...[
                    _paragraph('సమగ్ర అంశాలవారీ ఫలితాలు', bold: true),
                    _paragraph('ప్రతి ఉపాంశానికి ప్రత్యేక భావం, అధిపతి, 10 Mehta భావబల పరీక్షలు. ఇవి గ్రంథ సూత్రాల నుంచి చేసిన పరిశీలన విస్తరణలు; ప్రత్యేక యోగాలుగా ప్రకటించలేదు.'),
                    ...finding.angles.map((a) => _angleCard(a, detailed: true)),
                    _paragraph('చంద్రలగ్నం నుంచి స్వతంత్ర తనిఖీ:', bold: true),
                    _paragraph('చంద్రలగ్నం: ${_percentLabel(finding.moonReview?.evidencePercent)}. చంద్రలగ్న శాతాన్ని సమగ్ర శాతంలో మళ్లీ కలపలేదు.'),
                    _paragraph(finding.moonReview == null
                        ? 'చంద్రస్థితి అందుబాటులో లేక ప్రత్యేక తనిఖీ చేయలేకపోయాం.'
                        : 'చంద్రలగ్నం ఆధారంగా జాతక ${finding.moonReview!.referenceHouse}వ భావం; అధిపతి ${MehtaFamilyHouseService.planetTelugu[finding.moonReview!.lord] ?? finding.moonReview!.lord}; అనుకూల ${finding.moonReview!.supporting}; ప్రతికూల ${finding.moonReview!.cautionary}. ఈ లెక్కను జన్మలగ్న ఆధారాలతో కలిపి రెండుసార్లు లెక్కించలేదు.'),
                    _paragraph('మూల లగ్నం: ${MehtaFamilyHouseService.signs[chart.ascendantSignIndex]}'),
                    _paragraph('బంధువు లగ్నం: జాతకుని ${finding.relationHouse}వ భావం — ${MehtaFamilyHouseService.signs[startSign]}', bold: true),
                    _paragraph('అంశ భావం: బంధువు నుంచి ${t.offset}వది = జాతకుని ${finding.targetHouse}వ భావం — ${MehtaFamilyHouseService.signs[natalSign]}', bold: true),
                    _paragraph('భావాధిపతి: ${MehtaFamilyHouseService.planetTelugu[finding.lord] ?? finding.lord}'),
                    _paragraph('అధిపతి ఉన్న స్థానం: మూల జాతకంలోని ${finding.lordNatalHouse?.toString() ?? 'అందుబాటులో లేదు'}వ భావం; బంధువు నుంచి ${finding.lordRelativeHouse?.toString() ?? 'అందుబాటులో లేదు'}వ భావం'),
                    _paragraph('అధిపతి ఆధిపత్య భావాలు (బంధువు నుంచి): ${finding.lordOtherHouses.join(', ')}'),
                    _paragraph('భావంలో ఉన్న గ్రహాలు: ${MehtaFamilyHouseService.planetsLabel(finding.occupants)}'),
                    _paragraph('Mehta గ్రహ దృష్టులు: ${MehtaFamilyHouseService.planetsLabel(finding.aspecting)}'),
                    _paragraph('చంద్రలగ్నం — స్వతంత్ర సహాయక పరిశీలన:', bold: true),
                    _paragraph(moon == null ? 'చంద్రుని రాశి అందుబాటులో లేదు; చంద్రలగ్న పరిశీలన జరగలేదు.' :
                        'చంద్రలగ్నం ${MehtaFamilyHouseService.signs[moon.signIndex]}; బంధువు కొత్త సూచిక ${MehtaFamilyHouseService.signs[moonRelativeSign!]}; అదే అంశం ${MehtaFamilyHouseService.signs[moonTopicSign!]} (అధిపతి ${MehtaFamilyHouseService.planetTelugu[MehtaFamilyHouseService.signLords[moonTopicSign!]] ?? MehtaFamilyHouseService.signLords[moonTopicSign!]}). ఇది చంద్రలగ్న భావగణిత సహాయక పరిశీలన మాత్రమే; జన్మలగ్న ఫలితంలో ఆటోమేటిక్‌గా కలపలేదు.'),
                    _paragraph('గ్రహస్థితి / ఇతర సంబంధాల పరిశీలన:', bold: true),
                    ...finding.relationships.map(_paragraph),
                    _paragraph('ప్రయోగించిన అనుకూల నియమాలు: ${finding.favorable.length}; ప్రతికూల/మినహాయింపు పరిశీలనలు: ${finding.unfavorable.length}. ఇవి గ్రంథ ఫలితానికి సంభావ్యత శాతాలు కావు.'),
                    _paragraph(finding.limitations),
                    _nextButton('జాతక పరిశీలన → రూల్',
                        'ఏ షరతు సరిపోయింది, సరిపోలలేదు? Rule ID, గ్రంథ ఆధారాలను పరిశీలించండి',
                        () => setSheetState(() => stage = 2)),
                  ] else if (stage == 2) ...[
                    _paragraph('ఆ వ్యక్తికి మూల లగ్నం: జాతకుని ${finding.relationHouse}వ భావం. ${t.offset}వ అంశభావం = మూల జాతకంలోని ${finding.targetHouse}వ భావం.', bold: true),
                    _paragraph('లెక్క: ((బంధువు భావం + అంశ భావం − 2) % 12) + 1. ఈ లెక్క కుటుంబ సభ్యునికి కొత్త జనన జాతకం కాదు.'),
                    _paragraph('Rule IDs MF-01 నుంచి MF-10 వరకు యాప్‌లో ఇచ్చిన గుర్తింపులు. ఇవి Mehta రచయిత సంఖ్యా నియమాలు కావు.'),
                    _paragraph('యాప్ ఆధార సూచిక (%) = (అనుకూల ఆధారాలు + 1) ÷ '
                        '(అనుకూల + ప్రతికూల ఆధారాలు + 2) × 100; '
                        'సరిపోయిన ఆధారాలే లేకపోతే శాతం చూపించదు. '
                        'సమగ్ర శాతం ఒకే భావం పదేపదే వచ్చినా ఒక్కసారి మాత్రమే '
                        'లెక్కించి, ఆధారాలున్న విభిన్న భావాల సగటుగా చూపిస్తుంది. '
                        'ఈ శాతం S.K. Mehta రచించిన భవిష్యవాణి గణన కాదు; '
                        'యాప్‌లో ఉపయోగించే పరిశీలన సూచిక మాత్రమే.'),
                    _paragraph('✅ = ఆ గ్రహస్థితి షరతు సరిపోలింది; ఖాళీ గుర్తు = ఈ జాతకంలో ఆ షరతు లేదు. గ్రీన్ అనేది సంఘటన ఖచ్చితమని అర్థం కాదు.'),
                    ...finding.checks.map(_check),
                    _paragraph('అన్ని ఉపాంశాలకు స్వతంత్ర షరతుల పరీక్షలు', bold: true),
                    ...finding.angles.map((a) => ExpansionTile(
                      title: Text('${a.title} — ${_angleStatus(a)}',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('జాతక ${a.referenceHouse}వ భావం • ${a.source}',
                          style: const TextStyle(fontSize: 12)),
                      children: a.checks.map(_check).toList(),
                    )),
                    _nextButton('రూల్ → మూలగ్రంథం / పరిహారం',
                        'మెహతా గ్రంథ పేజీలు, కాలనిర్ణయ స్థితి, పరిహారం',
                        () => setSheetState(() => stage = 3)),
                  ] else ...[
                    _paragraph('S.K. Mehta — New Dimensions in Hindu Astrology: భావాల Portfolio & బంధువులు పుటలు 87–95 (ప్రత్యేకించి 95); ఉచ్చ–నీచ పట్టిక పుటలు 26–28; భావబల పరిశీలన పుటలు 100–109.'),
                    _paragraph('S.K. Mehta — New Rules and Combinations in Hindu Astrology: కుటుంబ సంబంధాల ఉదాహరణలు పుటలు 118, 138–145.'),
                    _paragraph('S.K. Mehta — Synchronization of Period: తల్లిదండ్రుల వివాహం 18–22; గ్రహస్థాన మార్పిడి, కాలనిర్ణయ నియమాలు 5–45; వ్యాఖ్యానం 121–158.'),
                    _paragraph('ఈ బంధుత్వ మార్గానికి ఆధారం: ${r.source}', bold: true),
                    _paragraph('ఈ అంశానికి మూల సూచన: ${MehtaFamilyInterpretationService.topicReferences[t.id] ?? 'New Dimensions — భావాల Portfolio'}'),
                    _paragraph('గ్రంథంలో ప్రతి బంధువు/అంశానికి స్వతంత్రంగా పూర్తి ఫలిత నియమం లేదు. ఇక్కడ చూపే 27 బంధుత్వ మార్గాల్లో కొన్ని Mehta ఉదాహరణల ఆధారిత భావగణిత విస్తరణలు; ప్రత్యేకమైన కొత్త మూల సూక్తులు కావు.'),
                    _paragraph('సంఘటన కాలం: ఆయా Mehta కాంబినేషన్‌ను ధృవీకరించి, వింశోత్తరి/త్రిభాగీయ దశ, చంద్రలగ్నం, Period Synchronization లెక్కింపును పూర్తిచేసిన తర్వాతనే ఇవ్వాలి. ఈ ఫ్యామిలీ ప్యానెల్ ఇంకా నిర్దిష్ట సంఘటన తేదీ/సంవత్సరాన్ని లెక్కించదు.'),
                    _paragraph('పరిహారం: ఇక్కడ పరీక్షించిన భావగణిత/బల నియమాల వద్ద ఖచ్చిత పరిహారం లభించలేదు. ఇతర పద్ధతి పరిహారాన్ని Mehta పేరుతో చూపించలేదు.'),
                    _paragraph(finding.limitations),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _findingCard(MehtaFamilyFinding finding) {
    final color = _color(finding.type);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      surfaceTintColor: Colors.transparent,
      color: const Color(0xFFFFFBF8),
      child: ListTile(
        isThreeLine: true,
        onTap: () => _openTrail(finding),
        leading: Icon(_icon(finding.type), color: color, size: 27),
        title: Text(finding.topic.title,
            style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(height: 6),
          Text(finding.heading,
              style: TextStyle(fontWeight: FontWeight.w800, color: color)),
          _percentBar(finding.evidencePercent,
              detail: 'వేరువేరు భావాల ఆధారాల సంఖ్య '
                  '${finding.scoredAngleCount}/${finding.angles.map((a) => a.aspectTopicId).toSet().length} · '
                  'శాతం = పరిశీలన ఆధార సూచిక మాత్రమే'),
          const SizedBox(height: 4),
          Text(finding.result, maxLines: 4, overflow: TextOverflow.ellipsis,
              style: const TextStyle(height: 1.4)),
          const SizedBox(height: 5),
          Text('సమగ్ర ఉపాంశాలు: ${finding.angles.length}; ఒక్కో అంశానికి ఆధారాలతో ఫలితం',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
          ...finding.angles.take(3).map((a) => Text('• ${a.title}: ${_percentLabel(a.evidencePercent)} — ${_angleStatus(a)}',
              style: const TextStyle(fontSize: 12.5, height: 1.4))),
          const SizedBox(height: 5),
          Text('జాతక ${finding.targetHouse}వ భావం • అనుకూల ${finding.favorable.length} • ప్రతికూల ${finding.unfavorable.length} • ఫలితం టచ్ → జాతక పరిశీలన → రూల్',
              style: const TextStyle(fontSize: 12.5, height: 1.3)),
        ]),
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final r = relation;
    final chart = widget.chart;
    final all = MehtaFamilyInterpretationService.allTopics(chart, r);
    final selected = all.firstWhere((finding) => finding.topic.id == topicId);
    return Card(
      color: const Color(0xFFFFF9F4),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('S.K. Mehta — కుటుంబ సభ్యుల పూర్తి భావ పరిశీలన',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          const Text('ఒకే D1 జాతకం → బంధువు లగ్నం → 12 అంశాలు + అంశాలవారీ ఉపపరిశీలన',
              style: TextStyle(fontWeight: FontWeight.w700, color: _ink)),
          const SizedBox(height: 10),
          const Text('ఒక అంశంలో ధనం–ఆదాయం–నిల్వలు–అప్పులు–ఆస్తి వంటి అనుబంధ కోణాలనూ విడిగా పరిశీలిస్తాం. ఫలితం → జాతక పరిశీలన → రూల్ → మూలగ్రంథం / పరిహారం.',
              style: TextStyle(height: 1.45)),
          const SizedBox(height: 13),
          DropdownButtonFormField<String>(
            value: relationId,
            isExpanded: true,
            decoration: const InputDecoration(
                labelText: 'కుటుంబ సభ్యుడు', border: OutlineInputBorder()),
            items: MehtaFamilyHouseService.relations
                .map((x) => DropdownMenuItem(
                    value: x.id,
                    child: Text(x.title, overflow: TextOverflow.ellipsis)))
                .toList(),
            onChanged: (v) { if (v != null) setState(() => relationId = v); },
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: topicId,
            isExpanded: true,
            decoration: const InputDecoration(
                labelText: 'పరిశీలించాల్సిన అంశం', border: OutlineInputBorder()),
            items: MehtaFamilyHouseService.topics
                .map((x) => DropdownMenuItem(
                    value: x.id,
                    child: Text(x.title, overflow: TextOverflow.ellipsis)))
                .toList(),
            onChanged: (v) { if (v != null) setState(() => topicId = v); },
          ),
          const SizedBox(height: 6),
          SwitchListTile.adaptive(
            contentPadding: EdgeInsets.zero,
            value: showAllTopics,
            title: const Text('ఈ కుటుంబ సభ్యునికి అన్ని 12 అంశాల ఫలితాలు',
                style: TextStyle(fontWeight: FontWeight.bold)),
            subtitle: const Text('ఆపితే ఎంచుకున్న అంశం మాత్రమే'),
            onChanged: (v) => setState(() => showAllTopics = v),
          ),
          const SizedBox(height: 5),
          Text('${r.title} — మీ జాతకంలోని ${MehtaFamilyHouseService.relativeHouse(r)}వ భావాన్ని కొత్త లగ్నంగా తీసుకున్న పరిశీలన.',
              style: const TextStyle(fontWeight: FontWeight.bold, height: 1.5)),
          const SizedBox(height: 8),
          if (showAllTopics) ...[
            const Text('12 అంశాల పరిశీలన ఫలితాలు',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            ...all.map(_findingCard),
          ] else _findingCard(selected),
          const SizedBox(height: 9),
          const Text('గమనిక: ఈ శాతాలు S.K. Mehta సూచించిన ఖచ్చిత ఫలిత శాతాలు కావు. ఇవి యాప్ లెక్కించిన భావబల ఆధారాల సమతుల్య సూచికలు మాత్రమే; విజయం, లాభం, ఆరోగ్యం, సంఘటన సంవత్సరం సంభావ్యతలు కావు. గ్రంథంలో లేని పరిహారాలు కలపలేదు.',
              style: TextStyle(fontSize: 12.5, height: 1.5)),
        ]),
      ),
    );
  }
}
