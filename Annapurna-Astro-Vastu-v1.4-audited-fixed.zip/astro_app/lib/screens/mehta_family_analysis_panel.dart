import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/mehta_family_house_service.dart';

/// Integrated only inside S.K. Mehta tab. Not a separate born horoscope.
/// User-mandated touch order: result -> rule -> horoscope inspection -> source/remedy.
class MehtaFamilyAnalysisPanel extends StatefulWidget {
  final AstroChartResult chart;
  const MehtaFamilyAnalysisPanel({super.key, required this.chart});
  @override
  State<MehtaFamilyAnalysisPanel> createState() => _MehtaFamilyAnalysisPanelState();
}

class _MehtaFamilyAnalysisPanelState extends State<MehtaFamilyAnalysisPanel> {
  String relationId = 'father';
  String topicId = 'self';
  MehtaFamilyRelation get relation => MehtaFamilyHouseService.relations.firstWhere((r) => r.id==relationId);
  MehtaFamilyTopic get topic => MehtaFamilyHouseService.topics.firstWhere((t) => t.id==topicId);
  static const _ink = Color(0xFF6A2435);

  Widget _para(String text, {bool bold=false}) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(text,style: TextStyle(height:1.55, fontSize:15,
        fontWeight:bold ? FontWeight.w800: FontWeight.normal)),
  );
  Widget _stepButton({required String title,required String caption,
      required VoidCallback onTap}) => Card(
    color: const Color(0xFFF7EFF1), surfaceTintColor: Colors.transparent,
    child: ListTile(
      title: Text(title,style:const TextStyle(fontWeight:FontWeight.w900)),
      subtitle: Text(caption,style:const TextStyle(height:1.45)),
      trailing:const Icon(Icons.chevron_right),
      onTap:onTap,
    ),
  );

  void _openTrail() {
    final r=relation, t=topic, chart=widget.chart;
    final base=MehtaFamilyHouseService.relativeHouse(r);
    final target=MehtaFamilyHouseService.targetHouse(r,t);
    final refSign=MehtaFamilyHouseService.houseSign(chart,base);
    final targetSign=MehtaFamilyHouseService.houseSign(chart,target);
    var stage=1;
    showModalBottomSheet<void>(
      context:context,isScrollControlled:true,showDragHandle:true,
      backgroundColor:const Color(0xFFFFFCFA),
      builder:(sheetContext)=>StatefulBuilder(builder:(context,setModalState){
        final title=stage==1 ? '1. మూల రూల్' : stage==2 ? '2. జాతక పరిశీలన' : '3. మూలగ్రంథం / పరిహారం';
        return SafeArea(top:false,child:FractionallySizedBox(
          heightFactor:0.84,
          child:ListView(padding: const EdgeInsets.fromLTRB(18,8,18,35),children:[
            Row(children:[
              if(stage>1) IconButton(icon:const Icon(Icons.arrow_back),onPressed:()=>setModalState(()=>stage--)),
              Expanded(child:Text(title,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:21))),
            ]),
            const SizedBox(height:12),
            _para('${r.title} → ${t.title}',bold:true),
            if(stage==1) ...[
              _para('పరిశీలన ID FH-01 (యాప్‌లో ఇచ్చిన గుర్తింపు; గ్రంథంలో ఈ సంఖ్య లేదు): సంబంధిత వ్యక్తి సూచించే భావాన్ని కొత్త లగ్నంగా తీసుకుని, ఆయన/ఆమె అంశానికి కావలసిన భావాన్ని అక్కడి నుంచి లెక్కించాలి.'),
              _para('Mehta తండ్రికి 10వ భావాన్ని ఉపయోగించారు. ఈ గ్రంథ పరిశీలనలో దాని స్థానంలో మరో పద్ధతిని కలపము.'),
              _para('ఫార్ములా: ((మూల భావం + తరువాతి భావం − 2) % 12) + 1.'),
              _para('బంధువు మూల భావం: $base; ఆ వ్యక్తి అంశ భావం: ${t.offset}; జాతకుని నుంచి పరిశీలించాల్సిన భావం: $target.',bold:true),
              _para('సంబంధ మార్గం: ${r.steps.map((s)=>'${s.label} (${s.offset})').join(' → ').isEmpty ? 'జాతకుని లగ్నం' : r.steps.map((s)=>'${s.label} (${s.offset})').join(' → ')}.'),
              _para('ఆధార రకం: ${r.evidenceType}. ఇదే మూల నియమాన్ని వర్తింపజేసిన గణిత విస్తరణలను స్వతంత్ర Mehta సూక్తులుగా లెక్కించము.'),
              _stepButton(title:'రూల్ టచ్ → జాతక పరిశీలన',caption:'ఏ రాశి, భావాధిపతి, గ్రహాలు, దృష్టులు ఉన్నాయో చూడండి',onTap:()=>setModalState(()=>stage=2)),
            ] else if(stage==2) ...[
              _para('జాతక లగ్న రాశి: ${MehtaFamilyHouseService.signs[chart.ascendantSignIndex]}'),
              _para('బంధువు కొత్త లగ్నం: జాతకుని ${base}వ భావం • ${MehtaFamilyHouseService.signs[refSign]}',bold:true),
              _para('పరిశీలన భావం: జాతకుని ${target}వ భావం • ${MehtaFamilyHouseService.signs[targetSign]}',bold:true),
              _para('భావాధిపతి: ${MehtaFamilyHouseService.planetTelugu[MehtaFamilyHouseService.signLord(chart,target)] ?? MehtaFamilyHouseService.signLord(chart,target)}'),
              _para('భావంలో ఉన్న గ్రహాలు: ${MehtaFamilyHouseService.planetsLabel(MehtaFamilyHouseService.occupants(chart,target))}'),
              _para('భావాన్ని వీక్షించే గ్రహాలు: ${MehtaFamilyHouseService.planetsLabel(MehtaFamilyHouseService.aspecting(chart,target))}'),
              _para('భావాధిపతి ఏ భావంలో ఉన్నాడు, అతని ఇతర అధిపత్యం, ఉచ్చ/నీచ, పరివర్తన, శని సంబంధాలు మరియు గ్రంథ మినహాయింపులను తరువాత విడిగా పరిశీలించాలి.'),
              _para('ఇవి D1 గ్రహస్థితుల ఆధారాలు మాత్రమే. అందువల్ల ఈ స్క్రీన్ వ్యక్తిగత కొత్త జనన జాతకాన్ని నిర్మించదు; ఖచ్చితమైన సంఘటన లేదా శుభ/అశుభ ఫలితాన్ని నిర్ధారించదు.'),
              _stepButton(title:'జాతక పరిశీలన టచ్ → మూలగ్రంథం/పరిహారం',caption:'Mehta మూల పేజీలు మరియు పరిహారం అందుబాటు స్థితి',onTap:()=>setModalState(()=>stage=3)),
            ] else ...[
              _para('S.K. Mehta — New Dimensions in Hindu Astrology: భావాల portfolios, పుటలు 87–95 (ప్రత్యేకంగా పు.95).'),
              _para('S.K. Mehta — New Rules and Combinations in Hindu Astrology: కుటుంబ బంధుత్వ జాతక ఉదాహరణలు, పుటలు 118, 138–145.'),
              _para('S.K. Mehta — Synchronization of Period: తల్లిదండ్రుల వివాహం, సంబంధిత భావాలు, పుటలు 18–22.'),
              _para('ఈ బంధుత్వ మార్గ ఆధారం: ${r.source}',bold:true),
              _para('పరిహారం: పరిశీలించిన మూలగ్రంథ భాగంలో ఈ భావగణితానికి ప్రత్యేకమైన పరిహారం ఇవ్వలేదు. ఇతర రచయితల పరిహారాలు ఇక్కడ చేర్చలేదు.'),
              _para('సంఘటన కాలం: Mehta గారి సంబంధిత గ్రహకాంబినేషన్ నిర్ధారించిన తరువాత అదే ట్యాబ్‌లో Event Timing / Synchronization పద్ధతితో వేరుగా పరిశీలించాలి.'),
            ],
          ]),
        ));
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    final r=relation, t=topic, chart=widget.chart;
    final base=MehtaFamilyHouseService.relativeHouse(r);
    final target=MehtaFamilyHouseService.targetHouse(r,t);
    final sign=MehtaFamilyHouseService.houseSign(chart,target);
    return Card(
      color:const Color(0xFFFFF9F4),surfaceTintColor:Colors.transparent,
      child:Padding(padding:const EdgeInsets.all(14),child:Column(
        crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('కుటుంబ సభ్యుల జాతక పరిశీలన',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),
          const SizedBox(height:5),
          const Text('S.K. Mehta — One Chart → Family Horoscope Analysis',style:TextStyle(fontWeight:FontWeight.w700,color:_ink)),
          const SizedBox(height:8),
          const Text('బంధువును, అంశాన్ని ఎంచుకోండి. ఫలితం టచ్ → రూల్ → జాతక పరిశీలన → మూలం/పరిహారం. ఇతర రచయితల నియమాలు లేవు.',style:TextStyle(height:1.45)),
          const SizedBox(height:13),
          DropdownButtonFormField<String>(
            value:relationId,isExpanded:true,
            decoration:const InputDecoration(labelText:'కుటుంబ సభ్యుడు',border:OutlineInputBorder()),
            items:MehtaFamilyHouseService.relations.map((x)=>DropdownMenuItem(
              value:x.id,child:Text(x.title,overflow:TextOverflow.ellipsis))).toList(),
            onChanged:(v){if(v!=null)setState(()=>relationId=v);},
          ),
          const SizedBox(height:12),
          DropdownButtonFormField<String>(
            value:topicId,isExpanded:true,
            decoration:const InputDecoration(labelText:'పరిశీలించాల్సిన అంశం',border:OutlineInputBorder()),
            items:MehtaFamilyHouseService.topics.map((x)=>DropdownMenuItem(
              value:x.id,child:Text(x.title,overflow:TextOverflow.ellipsis))).toList(),
            onChanged:(v){if(v!=null)setState(()=>topicId=v);},
          ),
          const SizedBox(height:14),
          Card(color:const Color(0xFFECF8F0),surfaceTintColor:Colors.transparent,
            child:ListTile(
              leading:const Icon(Icons.check_circle,color:Color(0xFF13804B)),
              title:Text('${r.title} — ${t.title}',style:const TextStyle(fontWeight:FontWeight.w900)),
              subtitle:Text('భావ గణన పూర్తి: సంబంధిత లగ్నం $base → మూల జాతకంలోని ${target}వ భావం (${MehtaFamilyHouseService.signs[sign]}).\nఫలితం టచ్ చేసి పరిశీలన చూడండి.',style:const TextStyle(height:1.4)),
              trailing:const Icon(Icons.chevron_right),onTap:_openTrail,
            ),
          ),
          const SizedBox(height:7),
          Text('భావ సంఖ్య గణన పూర్తయింది అనే గ్రీన్ గుర్తు మాత్రమే; శుభఫలితం లేదా ఖచ్చిత సంఘటన అని కాదు. ఆధారం: ${r.evidenceType}.',style:const TextStyle(fontSize:12.5,height:1.45)),
          const SizedBox(height:3),
          ExpansionTile(title:const Text('12 అంశాల భావ మ్యాప్',style:TextStyle(fontWeight:FontWeight.w800)),
            children:MehtaFamilyHouseService.topics.map((e){
              final h=MehtaFamilyHouseService.targetHouse(r,e);
              return ListTile(dense:true,title:Text(e.title),
                trailing:Text('${h}వ భావం',style:const TextStyle(fontWeight:FontWeight.w800)));
            }).toList(),
          ),
        ],
      )),
    );
  }
}
