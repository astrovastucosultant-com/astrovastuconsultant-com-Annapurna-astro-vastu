import 'package:flutter/material.dart';

/// Presentation only. All conclusions MUST come from the calling rule engine.
/// Never infer a favourable result from missing evidence.
enum RuleVerdict { favourable, adverse, mixed, unverified }

class RuleResultData {
  const RuleResultData({
    required this.topic,
    required this.result,
    required this.verdict,
    required this.examination,
    required this.rule,
    this.ruleId,
    this.source,
    this.remedy,
    this.evidencePercent,
  });

  final String topic;
  final String result;
  final RuleVerdict verdict;
  final String examination;
  final String rule;
  final String? ruleId;
  final String? source;
  final String? remedy;
  /// Evidence index only; NEVER label as event probability.
  final double? evidencePercent;
}

class UnifiedRuleResultTile extends StatefulWidget {
  const UnifiedRuleResultTile({super.key, required this.data});
  final RuleResultData data;

  @override
  State<UnifiedRuleResultTile> createState() => _UnifiedRuleResultTileState();
}

class _UnifiedRuleResultTileState extends State<UnifiedRuleResultTile> {
  bool showExamination = false;
  bool showRule = false;
  bool showSource = false;

  Color get accent {
    switch (widget.data.verdict) {
      case RuleVerdict.favourable: return const Color(0xFF187A47);
      case RuleVerdict.adverse: return const Color(0xFFB32635);
      case RuleVerdict.mixed: return const Color(0xFF9B6A0E);
      case RuleVerdict.unverified: return const Color(0xFF657080);
    }
  }

  String get verdictLabel {
    switch (widget.data.verdict) {
      case RuleVerdict.favourable: return 'అనుకూలం';
      case RuleVerdict.adverse: return 'ప్రతికూలం';
      case RuleVerdict.mixed: return 'మిశ్రమం';
      case RuleVerdict.unverified: return 'ధృవీకరణ అవసరం';
    }
  }

  IconData get verdictIcon {
    switch (widget.data.verdict) {
      case RuleVerdict.favourable: return Icons.check_circle_outline;
      case RuleVerdict.adverse: return Icons.cancel_outlined;
      case RuleVerdict.mixed: return Icons.info_outline;
      case RuleVerdict.unverified: return Icons.help_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.data;
    final percent = d.evidencePercent;
    return Card(
      color: Color.alphaBlend(accent.withOpacity(0.065), Theme.of(context).cardColor),
      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          InkWell(
            onTap: () => setState(() {showExamination = !showExamination; if (!showExamination) {showRule = false; showSource = false;}}),
            child: Row(children: [
              Icon(verdictIcon, color: accent),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(d.topic, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(d.result),
                Text(verdictLabel, style: TextStyle(color: accent, fontWeight: FontWeight.w700)),
                if (percent != null && percent.isFinite && percent >= 0 && percent <= 100)
                  Text('ఆధార సూచిక ${percent.toStringAsFixed(0)}% (సంభావ్యత కాదు)', style: const TextStyle(fontSize: 12)),
              ])),
              Icon(showExamination ? Icons.keyboard_arrow_up : Icons.chevron_right),
            ]),
          ),
          if (showExamination) ...[
            const Divider(),
            const Text('జాతక పరిశీలన', style: TextStyle(fontWeight: FontWeight.bold)),
            Text(d.examination.isNotEmpty ? d.examination : 'ఆధారాలు ఇంకా నమోదు కాలేదు.'),
            TextButton.icon(
              onPressed: () => setState(() { showRule = !showRule; if (!showRule) showSource = false; }),
              icon: Icon(showRule ? Icons.expand_less : Icons.expand_more),
              label: const Text('రూల్ చూడండి'),
            ),
            if (showRule) ...[
              if (d.ruleId != null) Text('Rule ID: ${d.ruleId}'),
              Text(d.rule.isNotEmpty ? d.rule : 'పూర్తి రూల్ ధృవీకరించలేదు.'),
              TextButton.icon(
                onPressed: () => setState(() => showSource = !showSource),
                icon: Icon(showSource ? Icons.expand_less : Icons.expand_more),
                label: const Text('మూలాధారం / పరిహారం'),
              ),
              if (showSource) ...[
                Text('మూలం: ${d.source ?? 'మూలగ్రంథ నిర్ధారణ పెండింగ్'}'),
                Text('పరిహారం: ${d.remedy ?? 'మూలంలో ధృవీకరించిన పరిహారం లేదు'}'),
              ],
            ],
          ],
        ]),
      ),
    );
  }
}
