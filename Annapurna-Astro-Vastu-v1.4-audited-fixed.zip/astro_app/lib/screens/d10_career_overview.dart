import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/d10_career_service.dart';
import '../astrology/d10_career_year_service.dart';
import '../astrology/d10_final_profession_engine.dart';
import '../astrology/varga_rule_service.dart';
import '../astrology/varga_service.dart';

/// Build 74: results-first presentation of the existing Build 73 D10 engines.
/// No chart values, professions, or years are fabricated in the UI.
class D10CareerOverview extends StatelessWidget {
  final AstroChartResult chart;
  final DateTime birthDateTime;
  final List<VargaRuleHit> rules;
  final ValueChanged<VargaRuleHit> onRuleTap;

  const D10CareerOverview({
    super.key,
    required this.chart,
    required this.birthDateTime,
    required this.rules,
    required this.onRuleTap,
  });

  static bool isYoga(VargaRuleHit hit) =>
      hit.ruleId.startsWith('D10-VRY-') ||
      hit.ruleId.startsWith('D10-R6.') ||
      hit.ruleId == 'D10-RAJAYOGA' ||
      hit.ruleId == 'D10-MAHABHAGYA' ||
      hit.topic.contains('యోగ') ||
      hit.topic.toLowerCase().contains('yoga');

  static const _maroon = Color(0xFF812536);
  static const _ink = Color(0xFF2B2325);

  Widget _panel({
    required Widget child,
    Color color = const Color(0xFFFFFAF0),
  }) => Card(
        margin: const EdgeInsets.only(bottom: 10),
        color: color,
        surfaceTintColor: Colors.transparent,
        child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), child: child),
      );

  String _labelForState(String value) => switch (value) {
        'GOCHARASHTHA' => 'గోచరిస్తా — వ్యాపారం / స్వయం ఉపాధి',
        'AGOCHARASHTHA' => 'అగోచరిస్తా — ఉద్యోగం / సర్వీస్',
        _ => 'మిశ్రమం / నిర్ధారణ కావాలి',
      };

  String _businessTitle(String source) => switch (source) {
        'Engineering / Technical' => 'ఇంజినీరింగ్ ప్రాజెక్టులు / సర్వీసులు',
        'IT / Software / Data' => 'సాఫ్ట్‌వేర్ / ఐటీ సంస్థ',
        'Manufacturing / Industry / Skilled Technical Work' => 'తయారీ పరిశ్రమ / టెక్నికల్ వర్క్‌షాప్',
        'Banking / Finance' => 'ఆర్థిక సలహా / ఆర్థిక సేవల సంస్థ',
        'Teaching / Education' => 'శిక్షణ సంస్థ / విద్యా సేవలు',
        'Accounting / Audit / Tax' => 'అకౌంటింగ్ / టాక్స్ కన్సల్టెన్సీ',
        'Medicine / Healthcare' => 'ఆరోగ్య సేవల కేంద్రం (అర్హతకు లోబడి)',
        'Agriculture / Environment / Natural Resources' => 'వ్యవసాయ వ్యాపారం / సేవలు',
        'Occult / Astrology / Traditional Studies' => 'జ్యోతిష్య / సంప్రదాయ సలహా సేవలు',
        'Consulting / Advisory' => 'స్వతంత్ర కన్సల్టెన్సీ',
        'Commercial / Business / Entrepreneurship' => 'వర్తకం / స్వంత వ్యాపారం',
        'Government / Administration' => 'పరిపాలనా కన్సల్టెన్సీ / కాంట్రాక్ట్ సేవలు',
        'Law / Judiciary / Compliance' => 'లీగల్ / కంప్లయన్స్ ప్రాక్టీస్ (అర్హతకు లోబడి)',
        _ => '$source — స్వయం ఉపాధి / సంస్థ',
      };

  String _jobTitle(String source) => switch (source) {
        'Engineering / Technical' => 'ఇంజినీర్ / టెక్నికల్ ఉద్యోగం',
        'IT / Software / Data' => 'సాఫ్ట్‌వేర్ / ఐటీ ఉద్యోగం',
        'Manufacturing / Industry / Skilled Technical Work' => 'పరిశ్రమ / టెక్నీషియన్ ఉద్యోగం',
        'Banking / Finance' => 'బ్యాంక్ / ఫైనాన్స్ ఉద్యోగం',
        'Teaching / Education' => 'ఉపాధ్యాయ / విద్యా సంస్థ ఉద్యోగం',
        'Accounting / Audit / Tax' => 'అకౌంట్స్ / ఆడిట్ ఉద్యోగం',
        'Medicine / Healthcare' => 'ఆరోగ్యరంగ ఉద్యోగం (అర్హతకు లోబడి)',
        'Government / Administration' => 'ప్రభుత్వ / పరిపాలనా సర్వీస్',
        'Defence / Police / Security' => 'రక్షణ / పోలీస్ / భద్రతా సర్వీస్',
        'Consulting / Advisory' => 'సలహాదారు / కన్సల్టింగ్ ఉద్యోగం',
        'Occult / Astrology / Traditional Studies' => 'జ్యోతిష్య / సంప్రదాయ అధ్యయన సంస్థలో పని',
        _ => '$source — ఉద్యోగం / సర్వీస్',
      };

  Widget _professionGroup({
    required bool isBusiness,
    required String state,
    required List<D10ProfessionCandidate> candidates,
    required VargaRuleHit? source,
  }) {
    final matched = state == (isBusiness ? 'GOCHARASHTHA' : 'AGOCHARASHTHA');
    final title = isBusiness ? '1. గోచరిస్తా — Business / Self Employment' : '2. అగోచరిస్తా — Job / Service';
    return _panel(
      color: matched ? const Color(0xFFECF7EF) : const Color(0xFFFFF8EA),
      child: ExpansionTile(
        key: PageStorageKey<String>(isBusiness ? 'd10-business' : 'd10-job'),
        tilePadding: EdgeInsets.zero,
        initiallyExpanded: matched,
        leading: Icon(isBusiness ? Icons.storefront_outlined : Icons.badge_outlined,
            color: matched ? const Color(0xFF1A794A) : const Color(0xFF8C671E)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: _ink)),
        subtitle: Text(matched
            ? 'D10 శని స్థితి ఈ వృత్తి విధానానికి మద్దతు ఇస్తోంది.'
            : 'ఈ విధానం ప్రస్తుతం D10లో match కాలేదు; ప్రత్యామ్నాయ రంగాలుగా మాత్రమే చూడండి.'),
        children: [
          if (candidates.isEmpty)
            const Padding(padding: EdgeInsets.all(12), child: Text('ఇంకా profession family evidence అందుబాటులో లేదు.')),
          for (final candidate in candidates)
            ListTile(
              contentPadding: EdgeInsets.zero,
              dense: true,
              leading: const Icon(Icons.chevron_right, size: 22, color: _maroon),
              title: Text(isBusiness ? _businessTitle(candidate.profession) : _jobTitle(candidate.profession),
                  style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${candidate.profession} • ${candidate.evidenceMatchPercent}% evidence match'),
              onTap: source == null ? null : () => onRuleTap(source),
            ),
          const Padding(
            padding: EdgeInsets.only(top: 4, bottom: 10),
            child: Text('గమనిక: ఇది లెక్కించిన వృత్తి *రంగాన్ని* ఉద్యోగం/స్వయం ఉపాధి విధానంలో చూపించే జాబితా. Exact profession నిర్ధారణ కాదు; Evidence % అనేది probability కాదు.',
                style: TextStyle(fontSize: 12, color: Color(0xFF65585B))),
          ),
        ],
      ),
    );
  }

  Widget _yearGroup(BuildContext context, List<D10CareerWindow> windows, D10YearCategory category) {
    final years = D10CareerYearService.yearsFor(windows, category);
    final (title, icon, tint) = switch (category) {
      D10YearCategory.rise => ('ఎదుగుదల — Rise / Promotion', Icons.trending_up, const Color(0xFFEAF6EE)),
      D10YearCategory.fall => ('పతనం — Fall / Job-Loss Caution', Icons.trending_down, const Color(0xFFFFF0EF)),
      D10YearCategory.middle => ('మధ్యస్థం — Change / Mixed', Icons.swap_horiz, const Color(0xFFFFF8E7)),
    };
    return _panel(
      color: tint,
      child: ExpansionTile(
        key: PageStorageKey<String>('d10-years-${category.name}'),
        tilePadding: EdgeInsets.zero,
        leading: Icon(icon, color: _maroon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(years.isEmpty ? 'రూల్‌కు సరిపోయే సంవత్సరం ఈ లెక్కలో లేదు.' : '${years.length} సంవత్సరాలు • టచ్ చేసి తేదీలు చూడండి'),
        children: [
          if (years.isEmpty)
            const Padding(
              padding: EdgeInsets.all(10),
              child: Text('డేటా లేని సంవత్సరాన్ని అనుకూలం/మధ్యస్థం/ప్రతికూలంగా ఊహించలేదు.'),
            ),
          for (final entry in years.entries)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${entry.key} సంవత్సరం', style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${entry.value.length} దశా సూచనలు • తేదీలు, గ్రహాలు, రూల్స్'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 15, color: _maroon),
              onTap: () => _showYearDetails(context, entry.key, entry.value, title),
            ),
        ],
      ),
    );
  }

  void _showYearDetails(BuildContext context, int year, List<D10CareerWindow> windows, String heading) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        top: false,
        child: FractionallySizedBox(
          heightFactor: 0.76,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
            children: [
              Text('$year — $heading', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('ఇవి జ్యోతిష్య నియమాల ఆధారంగా లెక్కించిన దశా కాల సూచనలు; సంఘటన జరిగిందని ధృవీకరణ లేదా భవిష్యత్తు హామీ కాదు.',
                  style: TextStyle(fontSize: 12.5, color: Color(0xFF665B5C))),
              const SizedBox(height: 12),
              for (final item in windows) Card(
                color: const Color(0xFFFFFAF5),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                      const SizedBox(height: 4),
                      Text('${D10CareerService.formatDate(D10CareerYearService.segmentStart(item, year))} → ${D10CareerService.formatDate(D10CareerYearService.segmentEnd(item, year))}'),
                      Text('మహాదశ / అంతర్దశ: ${item.mahadasha} / ${item.antardasha}'),
                      Text('రూల్స్: ${item.ruleIds.join(' • ')}', style: const TextStyle(color: _maroon)),
                      const SizedBox(height: 6),
                      Text(item.reason),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _careerSuitabilityPanel({
    required List<D10ProfessionCandidate> candidates,
    required VargaRuleHit? source,
  }) {
    return _panel(
      color: const Color(0xFFFFF8E8),
      child: ExpansionTile(
        key: const PageStorageKey<String>('d10-career-suitability'),
        initiallyExpanded: true,
        tilePadding: EdgeInsets.zero,
        leading: const Icon(Icons.workspace_premium_outlined, color: _maroon),
        title: const Text('5. ఏ వృత్తి అనుకూలం? / Career Suitability', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text(candidates.isEmpty
            ? 'Independent profession evidence match కాలేదు.'
            : 'Top ${candidates.length} profession families • Evidence Match % probability కాదు'),
        children: [
          if (candidates.isEmpty)
            const Padding(
              padding: EdgeInsets.all(10),
              child: Text('10L + Nakshatra + Sign + conjunction evidenceలో profession family match రాలేదు.'),
            ),
          for (var i = 0; i < candidates.length; i++)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                radius: 15,
                backgroundColor: const Color(0xFFF1E4D4),
                child: Text('${i + 1}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: _maroon)),
              ),
              title: Text(candidates[i].profession, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${candidates[i].evidenceMatchPercent}% Evidence Match • ${candidates[i].natureCompatibility}'),
              trailing: const Text('ఫలితం', style: TextStyle(fontWeight: FontWeight.w800, color: _maroon)),
              onTap: source == null ? null : () => onRuleTap(source),
            ),
          const Padding(
            padding: EdgeInsets.only(top: 4, bottom: 8),
            child: Text(
              'Amsha Devata ఈ %ను పెంచదు/తగ్గించదు. అది ఎంపికైన profession యొక్క పని విధానం మాత్రమే modify చేస్తుంది.',
              style: TextStyle(fontSize: 12, color: Color(0xFF66585B)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _natureDevataPanel({
    required D10FinalProfessionResult engine,
    required List<D10ProfessionCandidate> candidates,
    required VargaRuleHit? source,
    required VargaRuleHit? workflowSource,
  }) {
    final top = candidates.take(4).map((x) => x.profession).join(' • ');
    return _panel(
      color: const Color(0xFFECF7EF),
      child: ExpansionTile(
        key: const PageStorageKey<String>('d10-nature-devata'),
        initiallyExpanded: true,
        tilePadding: EdgeInsets.zero,
        leading: const Icon(Icons.route_outlined, color: Color(0xFF1A794A)),
        title: const Text('6. Profession Nature + Amsha Devata', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Text('${engine.professionNature} • ${engine.amshaDevata.deity} (${engine.amshaDevata.direction})'),
        children: [
          _auditLine('10వ భావాధిపతి', engine.tenthLord),
          _auditLine('10L రాశి', '${engine.tenthLordSignName} • ${engine.professionNature}'),
          _auditLine('Amsha Devata', '${engine.amshaDevata.deity} • ${engine.amshaDevata.direction}'),
          _auditLine('Work Flow Modifier', engine.amshaDevata.workflowModifier),
          const Divider(height: 18),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              top.isEmpty
                  ? 'Final Career Interpretation: profession evidence లేకుండా Devata ఒక్కటితో వృత్తి ప్రకటించము.'
                  : 'Final Career Interpretation: $top రంగాలు ${engine.professionNature} natureలో, ${engine.amshaDevata.deity} స్వభావం ప్రకారం ${engine.amshaDevata.workflowModifier}',
              style: const TextStyle(fontWeight: FontWeight.w700, height: 1.4),
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              if (workflowSource != null)
                TextButton.icon(
                  onPressed: () => onRuleTap(workflowSource),
                  icon: const Icon(Icons.account_tree_outlined),
                  label: const Text('Career Interpretation Rule'),
                ),
              if (source != null)
                TextButton.icon(
                  onPressed: () => onRuleTap(source),
                  icon: const Icon(Icons.menu_book_outlined),
                  label: const Text('Nature / Devata Source'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _strengthQualityPanel({required VargaRuleHit? source}) {
    return _panel(
      color: const Color(0xFFF3F4F6),
      child: ExpansionTile(
        key: const PageStorageKey<String>('d10-strength-quality'),
        initiallyExpanded: false,
        tilePadding: EdgeInsets.zero,
        leading: const Icon(Icons.menu_book_outlined, color: Color(0xFF53606A)),
        title: const Text('7. Graha Strength / Career Quality', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('Career Suitability % • BPHS Avastha Strength • Brihat Jataka Quality — మూడు వేర్వేరు layers'),
        children: [
          const ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('BPHS Graha Avastha', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('Balaadi → Jagradadi → Deeptadi → Lajjitadi → Shayanadi. Source-supported calculation ఉన్న state మాత్రమే resultగా చూపాలి.'),
          ),
          const ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('Shayanadi', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('Arithmetic engine ఉంది. Exact local sunrise నుంచి Birth Ghati మరియు validated Name Anka లభించినప్పుడు మాత్రమే Main state + Drishti/Cheshta/Vicheshta result ఇవ్వాలి.'),
          ),
          const ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text('Brihat Jataka Result Quality', style: TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text('Quality layerను Career Evidence %లో arbitrary +/- pointsగా కలపము. Exact source condition match అయిన quality మాత్రమే చూపాలి.'),
          ),
          if (source != null)
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                onPressed: () => onRuleTap(source),
                icon: const Icon(Icons.fact_check_outlined),
                label: const Text('Strength / Quality Rule & Source'),
              ),
            ),
        ],
      ),
    );
  }

  Widget _auditLine(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 132, child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800))),
            Expanded(child: Text(value)),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    final saturn = D10CareerService.saturnStream(chart);
    final engine = D10FinalProfessionEngine.evaluate(chart: chart, d10: VargaService.calculate(chart, 10));
    final candidates = engine.candidates
        .where((c) => c.natureCompatibility.endsWith('Match'))
        .take(8)
        .toList(growable: false);
    final shortlist = candidates.isNotEmpty ? candidates : engine.candidates.take(8).toList(growable: false);
    final timeline = D10CareerService.timingWindows(chart: chart, birthDateTime: birthDateTime);
    VargaRuleHit? find(String id) {
      for (final rule in rules) {
        if (rule.ruleId == id) return rule;
      }
      return null;
    }

    final yogaRules = rules.where((r) => isYoga(r) && r.autoEvaluated && r.applicable).toList(growable: false);
    final auditedYogaCount = rules.where((r) => isYoga(r) && (!r.autoEvaluated || !r.applicable)).length;
    final positiveYogaCount = yogaRules.where((r) => r.tone == VargaRuleTone.favorable).length;
    final cautionYogaCount = yogaRules.where((r) => r.tone == VargaRuleTone.caution).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Padding(
          padding: EdgeInsets.only(top: 6, bottom: 8),
          child: Text('D10 — సమగ్ర వృత్తి ఫలితం', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: _maroon)),
        ),
        _panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('ప్రధాన వృత్తి విధానం', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(_labelForState(saturn.dashamsaState), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: _maroon)),
              const SizedBox(height: 6),
              Text('జన్మ: ${_labelForState(saturn.birthState)}\nD9: ${_labelForState(saturn.navamsaState)}\nD10: ${_labelForState(saturn.dashamsaState)}'),
              const SizedBox(height: 8),
              Text('క్రమం: ${saturn.result}', style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 5),
              Text(saturn.reason, style: const TextStyle(fontSize: 12.5, color: Color(0xFF66585B))),
              if (find('D10-SEQUENCE') != null)
                TextButton.icon(onPressed: () => onRuleTap(find('D10-SEQUENCE')!), icon: const Icon(Icons.menu_book_outlined), label: const Text('విధాన రూల్ / Source')),
            ],
          ),
        ),
        _professionGroup(isBusiness: true, state: saturn.dashamsaState,
          candidates: shortlist, source: find('D10-FINAL-MASTER-PROF')),
        _professionGroup(isBusiness: false, state: saturn.dashamsaState,
          candidates: shortlist, source: find('D10-FINAL-MASTER-PROF')),
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Text('3. సంవత్సరాల వారీ వృత్తి ఫలితాలు — సంవత్సరం టచ్ చేయండి', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: _maroon)),
        ),
        _yearGroup(context, timeline, D10YearCategory.rise),
        _yearGroup(context, timeline, D10YearCategory.fall),
        _yearGroup(context, timeline, D10YearCategory.middle),
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 6),
          child: Text('4. అన్ని యోగాలు — ఒకేచోట', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: _maroon)),
        ),
        _panel(
          color: const Color(0xFFEFF5F3),
          child: ExpansionTile(
            key: const PageStorageKey<String>('d10-all-yogas'),
            initiallyExpanded: false,
            tilePadding: EdgeInsets.zero,
            leading: const Icon(Icons.auto_awesome_outlined, color: _maroon),
            title: const Text('అన్ని వర్తించిన యోగాలు — ఒకేచోట', style: TextStyle(fontWeight: FontWeight.w900)),
            subtitle: Text('అనుకూలం $positiveYogaCount • జాగ్రత్త $cautionYogaCount • మొత్తం ${yogaRules.length} వర్తించినవి • $auditedYogaCount source-only'),
            children: [
              if (yogaRules.isEmpty)
                const Padding(padding: EdgeInsets.all(10), child: Text('ప్రస్తుతం auto-confirm అయిన యోగం లేదు. మిగతావి క్రింద Audit భాగంలో చూడవచ్చు.')),
              for (final yoga in yogaRules)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(yoga.tone == VargaRuleTone.caution ? Icons.warning_amber_outlined : Icons.check_circle_outline,
                      color: yoga.tone == VargaRuleTone.caution ? const Color(0xFFB3261E) : const Color(0xFF1B7F3A)),
                  title: Text(yoga.topic, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${yoga.ruleId} • ${yoga.result}', maxLines: 3, overflow: TextOverflow.ellipsis),
                  trailing: const Text('ఫలితం', style: TextStyle(fontWeight: FontWeight.w800, color: _maroon)),
                  onTap: () => onRuleTap(yoga),
                ),
            ],
          ),
        ),
        _careerSuitabilityPanel(
          candidates: shortlist,
          source: find('D10-FINAL-MASTER-PROF'),
        ),
        _natureDevataPanel(
          engine: engine,
          candidates: shortlist,
          source: find('D10-FINAL-MASTER-NATURE'),
          workflowSource: find('D10-FINAL-WORKFLOW'),
        ),
        _strengthQualityPanel(source: find('D10-FINAL-STRENGTH-QUALITY')),
        const Padding(
          padding: EdgeInsets.only(top: 4, bottom: 12),
          child: Text('గమనిక: ఒకే సంవత్సరంలో ఎదుగుదల మరియు పతనం సూచనలు వేర్వేరు దశల్లో ఉంటే రెండు జాబితాల్లోనూ కనిపించవచ్చు. “మధ్యస్థం”లో change/transfer సూచనలు మాత్రమే ఉంటాయి; మిగతా సంవత్సరాలను ఊహించము. ఇది సంప్రదాయ జ్యోతిష్య విశ్లేషణ, ఖచ్చితమైన భవిష్యవాణి కాదు.',
              style: TextStyle(fontSize: 12, color: Color(0xFF66585B))),
        ),
      ],
    );
  }
}
