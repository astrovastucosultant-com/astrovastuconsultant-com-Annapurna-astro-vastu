import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Source-inspection and BTR rulebook screen. Never labels catalog text as a
/// chart-confirmed result. No source is merged into the Mehta-only evaluator.
class MehtaBtrRulebookScreen extends StatefulWidget {
  final String? initialRuleId;
  final VoidCallback? onOpenBtr;
  /// Choose a contextual action label when returning to an existing BTR form.
  final String btrButtonLabel;
  const MehtaBtrRulebookScreen({super.key, this.initialRuleId,
    this.onOpenBtr,
    this.btrButtonLabel = 'BTR — గత సంఘటనల నమోదు / Final Search',
  });

  @override
  State<MehtaBtrRulebookScreen> createState() => _MehtaBtrRulebookScreenState();
}

class _MehtaBtrRulebookScreenState extends State<MehtaBtrRulebookScreen> {
  static const Map<String, String> _books = {
    'nd': 'assets/btr/sk_mehta_new_dimensions_206.json',
    'r85': 'assets/btr/sk_mehta_new_rules_85.json',
    'btr': 'assets/btr/btr_macro_seconds_46.json',
    'bpd': 'assets/btr/bpd_nadi_praveshika_23.json',
  };
  final TextEditingController _query = TextEditingController();
  Map<String, List<Map<String, dynamic>>> _rules = {};
  String _book = 'nd';
  String _group = 'అన్నీ';
  bool _loading = true;
  String? _error;
  Map<String, dynamic>? _selected;
  int _stage = 0;

  @override
  void initState() {
    super.initState();
    if (widget.initialRuleId?.startsWith('R') == true) _book = 'r85';
    if (widget.initialRuleId?.startsWith('IN-') == true) _book = 'btr';
    if (widget.initialRuleId?.startsWith('NP-BPD-') == true) _book = 'bpd';
    _load();
    _query.addListener(() {if (mounted) setState(() {});});
  }

  Future<void> _load() async {
    try {
      final catalog = <String, List<Map<String, dynamic>>>{};
      for (final item in _books.entries) {
        final raw = await rootBundle.loadString(item.value);
        final parsed = jsonDecode(raw) as Map<String, dynamic>;
        final rows = parsed['rules'] as List<dynamic>;
        catalog[item.key] = rows
            .map((r) => Map<String, dynamic>.from(r as Map))
            .toList(growable: false);
      }
      if (mounted) setState(() {
        _rules = catalog; _loading = false;
        if (widget.initialRuleId != null) {
          for (final entry in catalog.entries) {
            for (final rule in entry.value) {
              if (rule['id']?.toString() == widget.initialRuleId) {
                _book = entry.key; _selected = rule; _stage = 0;
                _query.text = widget.initialRuleId!;
                break;
              }
            }
          }
        }
      });
    } catch (error) {
      if (mounted) setState(() { _error = error.toString(); _loading = false; });
    }
  }

  @override
  void dispose() { _query.dispose(); super.dispose(); }

  String _string(Map<String, dynamic> r, String key) =>
      r[key]?.toString().trim() ?? '';
  String _category(Map<String, dynamic> r) => _book == 'nd'
      ? _string(r, 'group') : _book == 'bpd'
      ? _string(r, 'group') : _book == 'btr'
      ? _string(r, 'title') : _string(r, 'title').split(' | ').first.trim();
  String _condition(Map<String, dynamic> r) => _string(r,
      (_book == 'btr' || _book == 'bpd') ? 'condition' : 'conditions');
  String _inspection(Map<String, dynamic> r) => _string(r, 'inspection');

  Widget _detail(Map<String, dynamic> r) {
    final id = _string(r, 'id');
    final source = _string(r, 'source');
    final isBtr = _book == 'btr' || _book == 'bpd';
    final inspection = _inspection(r).isNotEmpty ? _inspection(r)
        : isBtr
        ? 'నిజమైన జన్మచక్రం, కాలగణన మరియు గత సంఘటనలతో ఈ షరతు పరీక్షించాలి.'
        : 'అసలు గ్రంథం ప్రకారం గ్రహబలం, భావాధిపత్యం, దృష్టి, డిగ్రీలు మరియు మినహాయింపులు పరిశీలించాలి.';
    final content = <(String, String)>[
      ('ఫలితం', _string(r, 'result')),
      ('రూల్ / IF', _condition(r)),
      ('జాతక పరిశీలన', inspection),
      ('పరిహారం', 'ఈ రూల్‌లో ధృవీకరించిన నిర్దిష్ట పరిహారం అందుబాటులో లేదు. '
          'మూలం లేకుండా బయట పరిహారం చేర్చలేదు.'),
    ];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('$id — ${_string(r, 'title')}',
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      Text('మూలం: $source', style: const TextStyle(fontSize: 12.5)),
      if (r['page'] != null) Text('ముద్రిత పుట: ${r['page']}'),
      if (r['pdf_page'] != null) Text('PDF పుట: ${r['pdf_page']}'),
      const Padding(padding: EdgeInsets.symmetric(vertical: 7),
        child: Text('రూల్‌బుక్ వివరణ మాత్రమే — ఈ పేజీలో జన్మచక్రంపై '
            'షరతు పరీక్షించలేదు. BTR గణన కోసం పై బటన్‌ను ఉపయోగించండి.',
          style: TextStyle(color: Colors.deepOrange))),
      ...[for (var i = 0; i <= _stage; i++)
        Card(color: const Color(0xFFF1F5F9),child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${i + 1}. ${content[i].$1}',
              style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(content[i].$2.isEmpty ? 'మూలంలో వివరాలు లేవు' : content[i].$2),
          ]),
        )),
      ],
      if (_stage >= 2 && _string(r, 'exception').isNotEmpty)
        ListTile(title: const Text('మినహాయింపు / జాగ్రత్త'),
          subtitle: Text(_string(r, 'exception'))),
      if (_stage < 3) FilledButton(
        onPressed: () => setState(() => _stage++),
        child: Text('${content[_stage + 1].$1} చూపించండి →'),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final rules = _rules[_book] ?? const <Map<String, dynamic>>[];
    final uniqueGroups = <String>{for (final r in rules) _category(r)};
    final sortedGroups = uniqueGroups.where((s) => s.isNotEmpty).toList()..sort();
    final groups = <String>['అన్నీ', ...sortedGroups];
    final find = _query.text.trim().toLowerCase();
    final visible = rules.where((r) {
      if (_group != 'అన్నీ' && _category(r) != _group) return false;
      if (find.isEmpty) return true;
      return <String>[
        _string(r, 'id'), _string(r, 'title'), _category(r),
        _condition(r), _string(r, 'result'),
      ].join(' ').toLowerCase().contains(find);
    }).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('SK Mehta + BTR రూల్‌బుక్')),
      body: _loading ? const Center(child: CircularProgressIndicator())
          : _error != null ? Center(child: Text('రూల్‌బుక్ లోడ్ కాలేదు: $_error'))
          : ListView(padding: const EdgeInsets.all(14),children: [
        const Text('మూల గ్రంథాల నియమాలు విడిగా • BTR సందర్భ నియమాలు విడిగా. '
            'ఇక్కడ రూల్ బ్రౌజింగ్ మాత్రమే; జాతక మ్యాచ్ చేసినట్లు కాదు.',
          style: TextStyle(fontSize: 12.5)),
        if (widget.onOpenBtr != null) ...[
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: widget.onOpenBtr,
            icon: const Icon(Icons.manage_search),
            label: Text(widget.btrButtonLabel),
          ),
        ] else ...[
          const SizedBox(height: 10),
          const Text('BTRకి వెళ్లడానికి ముందుగా ఈ జాతకాన్ని తెరవండి. '
              'ఇక్కడ గ్రంథ నియమాల వివరాలు మాత్రమే కనిపిస్తాయి.',
            style: TextStyle(fontSize: 12, color: Colors.deepOrange)),
        ],
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _book, isExpanded:true,
          decoration: const InputDecoration(border:OutlineInputBorder(),labelText:'రూల్‌బుక్'),
          items: const [
            DropdownMenuItem(value:'nd',child:Text('SK Mehta — New Dimensions (206)')),
            DropdownMenuItem(value:'r85',child:Text('SK Mehta — 85 Combinations')),
            DropdownMenuItem(value:'btr',child:Text('BNN / BCP / BPD / KP BTR (46)')),
            DropdownMenuItem(value:'bpd',child:Text('Nādi Praveshikā — BPD Dictums (23)')),
          ],
          onChanged: (v) {if(v!=null)setState(() {
            _book=v;_group='అన్నీ';_selected=null;_stage=0;
          });},
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: groups.contains(_group) ? _group : 'అన్నీ',
          isExpanded:true,
          decoration: const InputDecoration(border:OutlineInputBorder(),labelText:'అంశం'),
          items: groups.map((g)=>DropdownMenuItem(value:g,
            child:Text(g,overflow:TextOverflow.ellipsis))).toList(),
          onChanged: (v) {if(v!=null)setState(() {_group=v;_selected=null;_stage=0;});},
        ),
        const SizedBox(height: 10),
        TextField(controller: _query,
          decoration: const InputDecoration(border:OutlineInputBorder(),
            prefixIcon: Icon(Icons.search),labelText:'ID / అంశం / రూల్ సెర్చ్')),
        Padding(padding: const EdgeInsets.symmetric(vertical: 9),
          child: Text('${visible.length} / ${rules.length} రూల్స్',
            style: const TextStyle(fontWeight:FontWeight.w600))),
        if (_selected != null) ...[
          _detail(_selected!),
          const Divider(height:24),
        ],
        ...visible.map((r) => Card(child: ListTile(
          title: Text('${_string(r, 'id')} • ${_string(r, 'title')}',
            maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text(_category(r),maxLines:1,overflow:TextOverflow.ellipsis),
          trailing: const Icon(Icons.chevron_right),
          onTap: ()=>setState(() { _selected=r; _stage=0; }),
        ))),
      ]),
    );
  }
}
