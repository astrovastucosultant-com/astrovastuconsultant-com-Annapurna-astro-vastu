import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/shapa_rule_service.dart';

class ShapaOverview extends StatelessWidget {
  final AstroChartResult chart;
  const ShapaOverview({super.key,required this.chart});
  @override
  Widget build(BuildContext context) {
    final matches=ShapaRuleService.screen(chart);
    return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('శాపాలు / దోషాల పరిశీలన',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      const Text('శాపాలు.pdf ఆధారంగా సంప్రదాయ జ్యోతిష్య సూచనలు మాత్రమే; వ్యక్తికి నిజంగా శాపం ఉన్నట్లు నిర్ధారణ కాదు.'),
      if(matches.isEmpty) const Padding(padding:EdgeInsets.all(8),
        child:Text('పరిశీలించిన ప్రత్యక్ష యుతి నియమాల్లో సరిపోలిక లేదు. ఇతర నియమాల పరిశీలన ఇంకా పెండింగ్.')),
      for(final match in matches)
        ExpansionTile(title:Text(match.rule.title),
          subtitle:Text('వర్తించిన సూచన • ${match.rule.id}'),children:[
          Padding(padding:const EdgeInsets.all(8),child:Text('జాతక పరిశీలన: ${match.observation}')),
          ExpansionTile(title:const Text('నియమం చూడండి'),children:[
            Padding(padding:const EdgeInsets.all(8),child:Text(
              '${match.rule.id} • ${match.rule.source} పేజీ ${match.rule.page}\n${match.rule.condition}')),
            ExpansionTile(title:const Text('నియమం టచ్ → పరిహారం'),children:[
              Padding(padding:const EdgeInsets.all(8),child:Text(
                '${match.rule.remedy}\nమూలం: శాపాలు.pdf, పేజీ ${match.rule.page}. విలియమ్స్ / remidi.pdf అనుసంధానం ధృవీకరణ పెండింగ్.')),
            ]),
          ]),
        ]),
      ExpansionTile(title:const Text('అన్ని 12 నియమాల మూల జాబితా (పూర్తి Matching పెండింగ్)'),children:[
        for(final r in ShapaRuleService.rules)
          ExpansionTile(title:Text('${r.id} • ${r.title}'),children:[
            Padding(padding:const EdgeInsets.all(8),child:Text(
              'మూలం: ${r.source}, పేజీ ${r.page}\n${r.condition}\nపరిహారం: ${r.remedy}')),
          ]),
      ]),
    ])));
  }
}
