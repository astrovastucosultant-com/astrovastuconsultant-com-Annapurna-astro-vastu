import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../astrology/ashtakavarga_service.dart';
import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/dasha_service.dart';
import '../astrology/jaimini_service.dart';
import '../astrology/kp_service.dart';
import '../astrology/varga_service.dart';
import '../astrology/vedic_calculation_service.dart';
import '../models/birth_data.dart';
import '../services/report_storage_service.dart';
import '../utils/astro_format.dart';


enum _AstroSystem {
  dasha,
  jamakola,
  jaimini,
  tajik,
  bcp,
  bsp,
  bnn,
  kp,
}

extension _AstroSystemLabel on _AstroSystem {
  String get title => switch (this) {
        _AstroSystem.dasha => 'దశలు',
        _AstroSystem.jamakola => 'Jamakola',
        _AstroSystem.jaimini => 'జైమిని System',
        _AstroSystem.tajik => 'Tajik / Varshaphala',
        _AstroSystem.bcp => 'BCP',
        _AstroSystem.bsp => 'BSP',
        _AstroSystem.bnn => 'BNN',
        _AstroSystem.kp => 'KP',
      };

  IconData get icon => switch (this) {
        _AstroSystem.dasha => Icons.timeline_outlined,
        _AstroSystem.jamakola => Icons.auto_awesome_outlined,
        _AstroSystem.jaimini => Icons.account_tree_outlined,
        _AstroSystem.tajik => Icons.calendar_month_outlined,
        _AstroSystem.bcp => Icons.rotate_right_outlined,
        _AstroSystem.bsp => Icons.rule_folder_outlined,
        _AstroSystem.bnn => Icons.hub_outlined,
        _AstroSystem.kp => Icons.functions_outlined,
      };
}

class ChartScreen extends StatefulWidget {
  final BirthData birthData;

  const ChartScreen({
    super.key,
    required this.birthData,
  });

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  late final Future<AstroChartResult> _future;
  int _selectedVarga = 9;
  String _selectedBav = 'Sun';
  _AstroSystem? _activeSystem;

  @override
  void initState() {
    super.initState();
    _future = AstroCalculationService.calculate(widget.birthData);
  }

  String _formatDateTime(DateTime dt) => AstroFormat.dateTime(dt);

  String _formatLongitude(double longitude) =>
      AstroFormat.longitudeDms(longitude);

  String _reportText(AstroChartResult result) {
    final b = widget.birthData;
    final panchanga = VedicCalculationService.panchanga(result);
    final av = AshtakavargaService.calculate(result);
    final d9 = VargaService.calculate(result, 9);
    final d10 = VargaService.calculate(result, 10);

    String placementText(VargaChartData data) {
      final items = data.planets
          .map((p) => '${p.shortName}:${p.signIndex + 1}')
          .join(', ');
      return '${data.definition.code} ${data.definition.teluguName}: '
          'Lg ${data.ascendantSignIndex + 1} | $items';
    }

    final buffer = StringBuffer()
      ..writeln('అన్నపూర్ణ ఆస్ట్రో వాస్తు')
      ..writeln('పేరు: ${b.name}')
      ..writeln('స్థలం: ${b.place}')
      ..writeln('Latitude: ${b.latitude}, Longitude: ${b.longitude}')
      ..writeln('Local: ${_formatDateTime(b.localDateTime)}')
      ..writeln('UTC: ${_formatDateTime(b.utcDateTime)}')
      ..writeln('Ayanamsa: ${b.ayanamsa.label}')
      ..writeln('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°')
      ..writeln('Lagna: ${_formatLongitude(result.ascendantLongitude)}')
      ..writeln('')
      ..writeln('పంచాంగ సారాంశం:')
      ..writeln('${panchanga.paksha} • ${panchanga.tithi}')
      ..writeln(
        '${panchanga.nakshatra} ${panchanga.nakshatraPada} పాదం • ${panchanga.yoga} యోగం • ${panchanga.karana} కరణం',
      )
      ..writeln('')
      ..writeln('గ్రహ స్థితులు:');

    for (final planet in result.planets) {
      final n = VedicCalculationService.nakshatra(planet.longitude);
      final house = VedicCalculationService.wholeSignHouse(
        planet.signIndex,
        result.ascendantSignIndex,
      );
      buffer.writeln(
        '${planet.name}: ${_formatLongitude(planet.longitude)} | '
        '${VedicCalculationService.nakshatraNamesTe[n.index]}-${n.pada} | '
        'House $house${planet.retrograde ? ' | R' : ''}',
      );
    }

    buffer
      ..writeln('')
      ..writeln(placementText(d9))
      ..writeln(placementText(d10))
      ..writeln('')
      ..writeln('Sarvashtakavarga: ${av.sarva.join(', ')}')
      ..writeln('SAV Total: ${av.grandTotal} ${av.totalsValid ? '(verified)' : '(check required)'}')
      ..writeln('')
      ..writeln('Engine: Swiss Ephemeris ${result.engineVersion} (Moshier mode)');
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        drawer: _SystemDrawer(
          selected: _activeSystem,
          onSelect: (system) => setState(() => _activeSystem = system),
          onMain: () => setState(() => _activeSystem = null),
        ),
        appBar: AppBar(
          title: Text(_activeSystem?.title ?? 'జాతక విశ్లేషణ'),
          bottom: _activeSystem == null
              ? const TabBar(
                  isScrollable: true,
                  labelColor: Colors.white,
                  unselectedLabelColor: Color(0xFFFFD7DD),
                  indicatorColor: Colors.white,
                  tabs: [
                    Tab(icon: Icon(Icons.grid_on_outlined), text: 'జాతకం'),
                    Tab(icon: Icon(Icons.dashboard_outlined), text: 'వర్గాలు'),
                    Tab(icon: Icon(Icons.apps_outlined), text: 'అష్టకవర్గం'),
                    Tab(icon: Icon(Icons.calculate_outlined), text: 'లెక్కలు'),
                    Tab(icon: Icon(Icons.account_tree_outlined), text: 'సిస్టమ్స్'),
                  ],
                )
              : null,
        ),
        body: FutureBuilder<AstroChartResult>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 14),
                    Text('Swiss Ephemeris calculation జరుగుతోంది…'),
                  ],
                ),
              );
            }

            if (snapshot.hasError || !snapshot.hasData) {
              return _ErrorView(
                message: snapshot.error?.toString() ?? 'Calculation failed',
              );
            }

            final result = snapshot.data!;
            final av = AshtakavargaService.calculate(result);

            if (_activeSystem != null) {
              return _SystemDetailPage(
                system: _activeSystem!,
                birthData: widget.birthData,
                result: result,
                onBackToMain: () => setState(() => _activeSystem = null),
              );
            }

            return TabBarView(
              children: [
                _JatakaTab(
                  birthData: widget.birthData,
                  result: result,
                  reportText: () => _reportText(result),
                ),
                _VargaTab(
                  result: result,
                  selectedVarga: _selectedVarga,
                  onChanged: (value) => setState(() => _selectedVarga = value),
                ),
                _AshtakavargaTab(
                  result: av,
                  ascendantSignIndex: result.ascendantSignIndex,
                  selectedPlanet: _selectedBav,
                  onPlanetChanged: (value) =>
                      setState(() => _selectedBav = value),
                ),
                _CalculationsTab(
                  birthData: widget.birthData,
                  result: result,
                ),
                _SystemsTab(
                  birthData: widget.birthData,
                  result: result,
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _JatakaTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;
  final String Function() reportText;

  const _JatakaTab({
    required this.birthData,
    required this.result,
    required this.reportText,
  });

  @override
  Widget build(BuildContext context) {
    final rasi = VargaService.calculate(result, 1);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _BirthSummaryCard(birthData: birthData),
        const SizedBox(height: 12),
        _CalculationSummaryCard(
          result: result,
          ayanamsaName: birthData.ayanamsa.label,
        ),
        const SizedBox(height: 16),
        const _SectionTitle('రాశి / జన్మ చక్రం'),
        const SizedBox(height: 10),
        _SouthIndianChart(
          title: 'D1 రాశి',
          ascendantSignIndex: rasi.ascendantSignIndex,
          occupants: _occupantsFromVarga(rasi, includeDegreesFrom: result),
        ),
        const SizedBox(height: 18),
        const _SectionTitle('గ్రహ స్థితులు'),
        const SizedBox(height: 8),
        ...result.planets.map((planet) {
          final n = VedicCalculationService.nakshatra(planet.longitude);
          final house = VedicCalculationService.wholeSignHouse(
            planet.signIndex,
            result.ascendantSignIndex,
          );
          return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              title: Text(
                planet.name,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              subtitle: Text(
                '${AstroFormat.longitudeDms(planet.longitude)}\n'
                '${VedicCalculationService.nakshatraNamesTe[n.index]} • ${n.pada} పాదం • House $house',
              ),
              isThreeLine: true,
              trailing: planet.retrograde
                  ? const Chip(label: Text('R'))
                  : null,
            ),
          );
        }),
        const SizedBox(height: 12),
        _ReportActions(
          title: birthData.name,
          reportText: reportText,
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _VargaTab extends StatelessWidget {
  final AstroChartResult result;
  final int selectedVarga;
  final ValueChanged<int> onChanged;

  const _VargaTab({
    required this.result,
    required this.selectedVarga,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final data = VargaService.calculate(result, selectedVarga);
    final definition = data.definition;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('షోడశ వర్గ చక్రములు'),
        const SizedBox(height: 8),
        const Text(
          'D1 నుంచి D60 వరకు 16 classical Parashari vargas. ప్రతి వర్గం అదే sidereal planetary longitude ను తన ప్రత్యేక నియమంతో కొత్త రాశిలో map చేస్తుంది.',
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: VargaService.definitions.map((v) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(v.code),
                  selected: selectedVarga == v.factor,
                  onSelected: (_) => onChanged(v.factor),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 12),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${definition.code} ${definition.teluguName} (${definition.name})',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text('ప్రధాన ఉపయోగం: ${definition.domain}'),
                Text('Division: 30° / ${definition.factor}'),
                if (definition.factor >= 40) ...[
                  const SizedBox(height: 8),
                  const Text(
                    'గమనిక: D40 / D45 / D60 లగ్నం జనన సమయానికి చాలా సున్నితంగా మారుతుంది.',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        _SouthIndianChart(
          title: '${definition.code} ${definition.teluguName}',
          ascendantSignIndex: data.ascendantSignIndex,
          occupants: _occupantsFromVarga(data),
        ),
        const SizedBox(height: 14),
        _VargaPlanetList(data: data),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _VargaPlanetList extends StatelessWidget {
  final VargaChartData data;

  const _VargaPlanetList({required this.data});

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text(
                'వర్గ గ్రహ స్థానాలు',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Lagna: ${data.ascendantSignIndex + 1}',
              ),
            ),
            const Divider(),
            ...data.planets.map(
              (p) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(p.name),
                trailing: Text(
                  '${p.signIndex + 1}${p.retrograde ? '  R' : ''}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AshtakavargaTab extends StatelessWidget {
  final AshtakavargaResult result;
  final int ascendantSignIndex;
  final String selectedPlanet;
  final ValueChanged<String> onPlanetChanged;

  const _AshtakavargaTab({
    required this.result,
    required this.ascendantSignIndex,
    required this.selectedPlanet,
    required this.onPlanetChanged,
  });

  @override
  Widget build(BuildContext context) {
    final bav = result.bhinna[selectedPlanet]!;
    final expected = result.expectedPlanetTotals[selectedPlanet]!;
    final actual = result.totalFor(selectedPlanet);
    final prastara = result.prastara[selectedPlanet]!;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('అష్టకవర్గం'),
        const SizedBox(height: 8),
        const Text(
          'Parashari Bhinna Ashtakavarga (BAV) లో సూర్యుడు నుంచి శని వరకు 7 గ్రహాలకు, 7 గ్రహాలు + లగ్నం అనే 8 reference points నుంచి bindus లెక్కించబడతాయి. SAV అనేది 7 BAV rows యొక్క మొత్తం.',
        ),
        const SizedBox(height: 12),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(
                  result.totalsValid
                      ? Icons.verified_outlined
                      : Icons.warning_amber_outlined,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Sarvashtakavarga (SAV)',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text('Grand total: ${result.grandTotal} / 337'),
                      Text(
                        result.totalsValid
                            ? 'Classical fixed totals verification passed.'
                            : 'Fixed total verification failed — result check చేయాలి.',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: 'Sarvashtakavarga (SAV)',
          values: result.sarva,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _ScoreGrid(values: result.sarva),
        const SizedBox(height: 18),
        DropdownButtonFormField<String>(
          value: selectedPlanet,
          decoration: const InputDecoration(
            labelText: 'Bhinna Ashtakavarga గ్రహం',
            border: OutlineInputBorder(),
          ),
          items: AshtakavargaService.planetOrder
              .map(
                (planet) => DropdownMenuItem(
                  value: planet,
                  child: Text(planet),
                ),
              )
              .toList(),
          onChanged: (value) {
            if (value != null) onPlanetChanged(value);
          },
        ),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: ListTile(
            title: Text('$selectedPlanet BAV'),
            subtitle: Text('Bindu total: $actual / expected $expected'),
            trailing: actual == expected
                ? const Icon(Icons.check_circle_outline)
                : const Icon(Icons.error_outline),
          ),
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: '$selectedPlanet BAV',
          values: bav,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _ScoreGrid(values: bav),
        const SizedBox(height: 18),
        const _SectionTitle('Prastara Ashtakavarga'),
        const SizedBox(height: 8),
        const Text(
          'ఎంచుకున్న గ్రహం BAV లో 7 గ్రహాలు + లగ్నం నుంచి ఏ రాశికి bindu వచ్చిందో 1/0 రూపంలో చూపిస్తుంది.',
        ),
        const SizedBox(height: 8),
        _PrastaraTable(rows: prastara),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _AshtakavargaSouthChart extends StatelessWidget {
  final String title;
  final List<int> values;
  final int ascendantSignIndex;

  const _AshtakavargaSouthChart({
    required this.title,
    required this.values,
    required this.ascendantSignIndex,
  });

  @override
  Widget build(BuildContext context) {
    final occupants = <int, List<String>>{
      for (var sign = 0; sign < 12; sign++) sign: ['${values[sign]}'],
    };
    return _SouthIndianChart(
      title: title,
      ascendantSignIndex: ascendantSignIndex,
      occupants: occupants,
    );
  }
}

class _PrastaraTable extends StatelessWidget {
  final Map<String, List<int>> rows;

  const _PrastaraTable({required this.rows});

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columnSpacing: 18,
          columns: [
            const DataColumn(label: Text('Ref')),
            ...List.generate(
              12,
              (index) => DataColumn(
                label: Text(
                  '${index + 1}',
                  style: const TextStyle(fontSize: 11),
                ),
              ),
            ),
          ],
          rows: rows.entries.map((entry) {
            return DataRow(
              cells: [
                DataCell(Text(entry.key)),
                ...entry.value.map((value) => DataCell(Text('$value'))),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _ScoreGrid extends StatelessWidget {
  final List<int> values;

  const _ScoreGrid({required this.values});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 2.2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: 12,
      itemBuilder: (context, index) {
        return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    '${index + 1}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                Text(
                  values[index].toString(),
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CalculationsTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;

  const _CalculationsTab({
    required this.birthData,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final p = VedicCalculationService.panchanga(result);
    final quickVargas = [1, 9, 10, 60]
        .map((factor) => VargaService.calculate(result, factor))
        .toList(growable: false);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Calculation / గణన విభాగం'),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'పంచాంగ గణనలు',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('పక్షం: ${p.paksha}'),
                Text('తిథి: ${p.tithi}'),
                Text('చంద్ర నక్షత్రం: ${p.nakshatra} • ${p.nakshatraPada} పాదం'),
                Text('యోగం: ${p.yoga}'),
                Text('కరణం: ${p.karana}'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Engine / Settings',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('Swiss Ephemeris: ${result.engineVersion}'),
                const Text('Planet mode: Sidereal + Moshier'),
                const Text('Node: True Rahu; Ketu = exact 180° opposite'),
                Text('Ayanamsa: ${birthData.ayanamsa.label}'),
                Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
                Text('Julian Day (UT): ${result.julianDay.toStringAsFixed(6)}'),
                Text('Lagna: ${AstroFormat.longitudeDms(result.ascendantLongitude)}'),
                const SizedBox(height: 6),
                const Text(
                  'House column below uses whole-sign houses from the Lagna sign.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const _SectionTitle('గ్రహ గణన పట్టిక'),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const [
              DataColumn(label: Text('Planet')),
              DataColumn(label: Text('Rasi')),
              DataColumn(label: Text('Longitude')),
              DataColumn(label: Text('Nakshatra')),
              DataColumn(label: Text('Pada')),
              DataColumn(label: Text('House')),
              DataColumn(label: Text('Motion')),
            ],
            rows: result.planets.map((planet) {
              final n = VedicCalculationService.nakshatra(planet.longitude);
              final house = VedicCalculationService.wholeSignHouse(
                planet.signIndex,
                result.ascendantSignIndex,
              );
              return DataRow(
                cells: [
                  DataCell(Text(planet.name)),
                  DataCell(Text('${planet.signIndex + 1}')),
                  DataCell(Text(AstroFormat.longitudeDms(planet.longitude))),
                  DataCell(Text(VedicCalculationService.nakshatraNamesTe[n.index])),
                  DataCell(Text('${n.pada}')),
                  DataCell(Text('$house')),
                  DataCell(Text(planet.retrograde ? 'Retrograde' : 'Direct')),
                ],
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 18),
        const _SectionTitle('Quick Varga Matrix'),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: [
              const DataColumn(label: Text('Planet')),
              ...quickVargas.map(
                (v) => DataColumn(label: Text(v.definition.code)),
              ),
            ],
            rows: result.planets.map((planet) {
              return DataRow(
                cells: [
                  DataCell(Text(planet.name)),
                  ...quickVargas.map((v) {
                    final placement =
                        v.planets.firstWhere((item) => item.name == planet.name);
                    return DataCell(
                      Text('${placement.signIndex + 1}'),
                    );
                  }),
                ],
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 14),
        const Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'ఈ version లో verified core calculations, BAV/SAV మరియు Prastara Ashtakavarga చూపించబడుతున్నాయి. Shadbala, Bhava Bala, Trikona/Ekadhipatya Shodhana, Shodhya Pinda వంటి advanced modules ను source-rule verification తర్వాత మాత్రమే add చేయాలి; ఊహా formulas ఉపయోగించకూడదు.',
            ),
          ),
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


class _SystemDrawer extends StatelessWidget {
  final _AstroSystem? selected;
  final ValueChanged<_AstroSystem> onSelect;
  final VoidCallback onMain;

  const _SystemDrawer({
    required this.selected,
    required this.onSelect,
    required this.onMain,
  });

  @override
  Widget build(BuildContext context) {
    const maroon = Color(0xFF7B1E2B);
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 20, 16, 18),
              color: maroon,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.menu_book_outlined, color: Colors.white, size: 34),
                  SizedBox(height: 10),
                  Text(
                    'అన్నపూర్ణ ఆస్ట్రో వాస్తు',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'జ్యోతిష్య విధానాలు',
                    style: TextStyle(color: Color(0xFFFFD7DD)),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  ListTile(
                    leading: const Icon(Icons.home_outlined),
                    title: const Text(
                      'ప్రధాన జాతకం',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    selected: selected == null,
                    selectedTileColor: const Color(0xFFFFF0F2),
                    onTap: () {
                      Navigator.pop(context);
                      onMain();
                    },
                  ),
                  const Divider(height: 12),
                  for (final system in _AstroSystem.values)
                    ListTile(
                      leading: Icon(system.icon, color: maroon),
                      title: Text(
                        system.title,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      selected: selected == system,
                      selectedTileColor: const Color(0xFFFFF0F2),
                      onTap: () {
                        Navigator.pop(context);
                        onSelect(system);
                      },
                    ),
                  const Divider(height: 18),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 4, 16, 18),
                    child: Text(
                      'గణిత ఫలితాలు verified rules ఉన్న modulesలో మాత్రమే చూపించబడతాయి. Source పూర్తి కాని systemలో ఊహా calculation చూపించము.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF65585A)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SystemDetailPage extends StatelessWidget {
  final _AstroSystem system;
  final BirthData birthData;
  final AstroChartResult result;
  final VoidCallback onBackToMain;

  const _SystemDetailPage({
    required this.system,
    required this.birthData,
    required this.result,
    required this.onBackToMain,
  });

  @override
  Widget build(BuildContext context) {
    final children = <Widget>[
      _SystemPageHeader(
        system: system,
        onBackToMain: onBackToMain,
      ),
      const SizedBox(height: 12),
    ];

    switch (system) {
      case _AstroSystem.dasha:
        children.add(
          _DashaSystemsCard(
            chart: result,
            birthDateTime: birthData.localDateTime,
          ),
        );
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'దశల పూర్తి విభాగం',
            items: [
              'త్రిభాగి 80 — S.K. Mehta',
              'వింశోత్తరి 120',
              'ఖండ దశ 40',
              'యోగిని 36',
              'జనన దశా balance',
              'మహాదశ / అంతర్దశ / ప్రత్యంతర్దశ',
              'సూక్ష్మ / ప్రాణ దశ',
              'ఏ తేదీకి అయినా 5-level దశా స్థితి',
              'ప్రతి level ప్రారంభం–ముగింపు తేదీలు',
              'ప్రస్తుత levelకి పూర్తి sub-period పట్టిక',
            ],
            note:
                'త్రిభాగి = Vimshottari duration × 2/3; ఖండ = ×1/3. Mehta timingలో 2–5 స్థాయులు (AD, PD, Sukshma, Prana) ముఖ్యంగా చూపించబడతాయి. Source ratiosను మార్చకుండా date engine reproducible civil-year conventionతో పని చేస్తుంది.',
          ),
        );
        break;

      case _AstroSystem.jaimini:
        final jai = JaiminiService.calculate(result);
        children.add(_JaiminiCard(result: jai, chart: result));
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'జైమిని విభాగం',
            items: [
              'Chara Karakas',
              'Atmakaraka',
              'Karakamsa',
              'Rashi Drishti',
              'Argala / Virodha Argala',
              'Pada P1–P12 (Arudha A1–A12)',
              'P7 / Darapada',
              'P12 / Upapada',
              'Chara Dasha + Antardasha',
              'అంశాల వారీ applicable combinations / yogas',
              'Green / Red result status',
              'Result touch → జాతక పరిశీలన + పరిహారం',
            ],
            note:
                'Supplied Jaimini sourceలో స్పష్టంగా ఉన్న applicable rulesను అంశాల వారీగా auto-evaluate చేస్తుంది. ఒకే ruleతో final verdict ఇవ్వదు. Sourceలో పరిహారం లేని చోట ఊహా remedy చూపించదు.',
          ),
        );
        break;

      case _AstroSystem.kp:
        children.add(_KpCard(rows: KpService.planetaryTable(result)));
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'KP పూర్తి నిర్మాణం',
            items: [
              'Planet Sign Lord',
              'Star Lord',
              'Sub Lord',
              '12 Cusps',
              'Cusp Star/Sub Lord',
              'Significators',
              'Ruling Planets',
              'Event house groups',
              'Promise / Denial',
              'Event timing',
            ],
            note:
                'Planetary Star/Sub arithmetic active. Exact cusp sub-lord/significator engine కోసం 12 cusp longitude calculation మరియు supplied KP source rulesను layer-by-layer validate చేసి మాత్రమే enable చేయాలి.',
          ),
        );
        break;

      case _AstroSystem.jamakola:
        children.add(
          _PendingSystemDetail(
            title: 'Jamakola',
            birthData: birthData,
            result: result,
            sections: [
              'జనన ఆధార గణన',
              'గ్రహ/భావ సంబంధ నియమాలు',
              'Event combinations',
              'Timing rules',
              'Rule → Result trace',
              'Final event report',
            ],
          ),
        );
        break;

      case _AstroSystem.tajik:
        children.add(
          _PendingSystemDetail(
            title: 'Tajik / Varshaphala',
            birthData: birthData,
            result: result,
            sections: [
              'Varsha Pravesha / annual chart',
              'Muntha',
              'Annual lord / Varshesha',
              'Tajik aspects',
              'Tajik yogas',
              'Sahams',
              'Annual timing & result',
            ],
          ),
        );
        break;

      case _AstroSystem.bcp:
        children.add(
          _PendingSystemDetail(
            title: 'BCP',
            birthData: birthData,
            result: result,
            sections: [
              'Source rule index',
              'Age / year activation',
              'Activated house/sign',
              'Planet/lord evidence',
              'Event rule trace',
              'Timing & final result',
            ],
          ),
        );
        break;

      case _AstroSystem.bsp:
        children.add(
          _PendingSystemDetail(
            title: 'BSP',
            birthData: birthData,
            result: result,
            sections: [
              'Source rule index',
              'Planet / sign / house trigger',
              'Rule combinations',
              'Exception rules',
              'Event result',
              'Timing / validation',
            ],
          ),
        );
        break;

      case _AstroSystem.bnn:
        children.add(
          _PendingSystemDetail(
            title: 'BNN',
            birthData: birthData,
            result: result,
            sections: [
              'Planet significations',
              'Planetary links / conjunction chain',
              'Sign & trinal relationships',
              'Karaka evidence layers',
              'Event combinations',
              'Timing & final report',
            ],
          ),
        );
        break;
    }

    children.add(const SizedBox(height: 28));
    return ListView(
      padding: const EdgeInsets.all(16),
      children: children,
    );
  }
}

class _SystemPageHeader extends StatelessWidget {
  final _AstroSystem system;
  final VoidCallback onBackToMain;

  const _SystemPageHeader({
    required this.system,
    required this.onBackToMain,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFFFF7F3),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: const Color(0xFF7B1E2B),
              foregroundColor: Colors.white,
              child: Icon(system.icon),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    system.title,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const Text(
                    'Rule → Calculation → Result',
                    style: TextStyle(color: Color(0xFF6E5D60)),
                  ),
                ],
              ),
            ),
            TextButton.icon(
              onPressed: onBackToMain,
              icon: const Icon(Icons.grid_view_outlined),
              label: const Text('జాతకం'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ModuleChecklistCard extends StatelessWidget {
  final String title;
  final List<String> items;
  final String note;

  const _ModuleChecklistCard({
    required this.title,
    required this.items,
    required this.note,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            for (final item in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.check_circle_outline,
                      size: 19,
                      color: Color(0xFF7B1E2B),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(item)),
                  ],
                ),
              ),
            const Divider(height: 20),
            Text(note, style: const TextStyle(fontSize: 12.5)),
          ],
        ),
      ),
    );
  }
}

class _PendingSystemDetail extends StatefulWidget {
  final String title;
  final List<String> sections;
  final BirthData birthData;
  final AstroChartResult result;

  const _PendingSystemDetail({
    required this.title,
    required this.sections,
    required this.birthData,
    required this.result,
  });

  @override
  State<_PendingSystemDetail> createState() => _PendingSystemDetailState();
}

class _PendingSystemDetailState extends State<_PendingSystemDetail> {
  int? _openIndex;

  String _signForLongitude(double longitude) {
    final index = ((longitude % 360) / 30).floor().clamp(0, 11);
    return '${index + 1}';
  }

  String _planetSummary() {
    return widget.result.planets
        .map((p) => '${p.shortName}:${p.signIndex + 1}')
        .join('  •  ');
  }

  void _copyContext() {
    final b = widget.birthData;
    final text = StringBuffer()
      ..writeln(widget.title)
      ..writeln('Name: ${b.name}')
      ..writeln('DOB/Time: ${AstroFormat.dateTime(b.localDateTime)}')
      ..writeln('Place: ${b.place}')
      ..writeln('Lagna: ${_signForLongitude(widget.result.ascendantLongitude)}')
      ..writeln('Planets: ${_planetSummary()}');
    Clipboard.setData(ClipboardData(text: text.toString()));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('జాతక calculation context copy అయింది')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lagna = _signForLongitude(widget.result.ascendantLongitude);
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.verified_user_outlined,
                  color: Color(0xFF7B1E2B),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${widget.title} — working module',
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'ఈ moduleలో navigation, birth-chart context మరియు ప్రతి విభాగం touch/expand ఇప్పుడు పనిచేస్తాయి. మీరు rules ఇచ్చిన తర్వాత మాత్రమే ఆ విభాగానికి exact rule calculation/result engine జోడిస్తాం; అప్పటివరకు ఊహా prediction చూపించము.',
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF0F2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE4C8CD)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'జాతక ఆధారం LOADED',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 5),
                  Text('పేరు: ${widget.birthData.name}'),
                  Text('లగ్నం: $lagna'),
                  Text('స్థలం: ${widget.birthData.place}'),
                  const SizedBox(height: 5),
                  Text(
                    _planetSummary(),
                    style: const TextStyle(fontSize: 12.5),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _copyContext,
                    icon: const Icon(Icons.copy_outlined, size: 18),
                    label: const Text('Calculation context copy'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            for (var i = 0; i < widget.sections.length; i++)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF7F3),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE4C8CD)),
                ),
                child: Theme(
                  data: Theme.of(context).copyWith(
                    dividerColor: Colors.transparent,
                    splashColor: const Color(0xFFFFE7EB),
                  ),
                  child: ExpansionTile(
                    key: PageStorageKey('${widget.title}-$i'),
                    initiallyExpanded: _openIndex == i,
                    onExpansionChanged: (open) {
                      setState(() => _openIndex = open ? i : null);
                    },
                    leading: const Icon(
                      Icons.chevron_right,
                      color: Color(0xFF7B1E2B),
                    ),
                    title: Text(
                      widget.sections[i],
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: const Chip(label: Text('READY')),
                    childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: const Color(0xFFEAD9DC)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: const [
                                Icon(
                                  Icons.check_circle_outline,
                                  size: 18,
                                  color: Color(0xFF7B1E2B),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  'Screen / input layer active',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '${widget.sections[i]} కోసం birth chart data సిద్ధంగా ఉంది. Rule source వచ్చిన తర్వాత Rule → Calculation → Result → Validation రూపంలో ఇదే sectionలో output చూపిస్తాం.',
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'RULE ENGINE: rules pending',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF8D3140),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}


class _SystemsTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;

  const _SystemsTab({
    required this.birthData,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final vim = DashaService.vimshottari(
      chart: result,
      birthDateTime: birthData.localDateTime,
    );
    final jai = JaiminiService.calculate(result);
    final kpRows = KpService.planetaryTable(result);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('దశలు • Jamakola • జైమిని • Tajik • BCP • BSP • BNN • KP'),
        const SizedBox(height: 8),
        const Text(
          'ఎడమపై ☰ menu టచ్ చేసి కావలసిన system ఎంచుకోండి. ప్రతి systemకు ప్రత్యేక scroll page ఉంటుంది. Verified sourceలో స్పష్టంగా లేని arithmetic/result rulesను ఊహించి hard-code చేయము.',
        ),
        const SizedBox(height: 14),
        _VimshottariCard(result: vim, birthDateTime: birthData.localDateTime),
        const SizedBox(height: 14),
        _JaiminiCard(result: jai, chart: result),
        const SizedBox(height: 14),
        _KpCard(rows: kpRows),
        const SizedBox(height: 14),
        const _SourcePendingCard(
          title: 'Jamakola System',
          icon: Icons.auto_awesome_outlined,
          text:
              'Jamakola కోసం module slot సిద్ధంగా ఉంది. మీరు ఇచ్చే/ఇప్పటికే ఉన్న verified Jamakola source rulesను మాత్రమే engineలో hard-code చేస్తాం; source లేకుండా prediction rulesను కలపము.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'Tajik / Varshaphala',
          icon: Icons.calendar_month_outlined,
          text:
              'Tajik annual-chart module slot సిద్ధంగా ఉంది. Verified Tajik sourceలోని Muntha, annual lord, sahams/yogas మరియు timing rules వచ్చిన తర్వాత source-tagతో enable చేస్తాం.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BCP',
          icon: Icons.rotate_right_outlined,
          text:
              'BCP menu సిద్ధంగా ఉంది. Supplied/verified source rules వచ్చిన తర్వాత age/year activation, evidence మరియు timing calculationsను enable చేస్తాం.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BSP',
          icon: Icons.rule_folder_outlined,
          text:
              'BSP menu సిద్ధంగా ఉంది. Exact source rule/exception tablesను verify చేసిన తర్వాత మాత్రమే result engine activate చేస్తాం.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BNN',
          icon: Icons.hub_outlined,
          text:
              'BNN menu సిద్ధంగా ఉంది. Planetary links, significations, event combinations మరియు timing rules verified sourceతోనే add చేస్తాం.',
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


class _DashaSystemsCard extends StatefulWidget {
  final AstroChartResult chart;
  final DateTime birthDateTime;

  const _DashaSystemsCard({
    required this.chart,
    required this.birthDateTime,
  });

  @override
  State<_DashaSystemsCard> createState() => _DashaSystemsCardState();
}

class _DashaSystemsCardState extends State<_DashaSystemsCard> {
  DashaSystemKind _selectedKind = DashaSystemKind.tribhagi;
  late DateTime _probeDate;

  @override
  void initState() {
    super.initState();
    _probeDate = DateTime.now();
  }

  String _date(DateTime dt) =>
      '${AstroFormat.two(dt.day)}-${AstroFormat.two(dt.month)}-${dt.year}';

  String _dateTime(DateTime dt) =>
      '${_date(dt)} ${AstroFormat.two(dt.hour)}:${AstroFormat.two(dt.minute)}';

  String _years(double value) {
    if (value >= 1) return '${value.toStringAsFixed(4)} y';
    final days = value * 365.2425;
    if (days >= 1) return '${days.toStringAsFixed(2)} d';
    return '${(days * 24).toStringAsFixed(2)} h';
  }

  Future<void> _pickDate() async {
    final first = DateTime(widget.birthDateTime.year - 10, 1, 1);
    final last = DateTime(widget.birthDateTime.year + 150, 12, 31);
    var initial = _probeDate;
    if (initial.isBefore(first)) initial = first;
    if (initial.isAfter(last)) initial = last;

    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: last,
      helpText: 'దశా తేదీ ఎంచుకోండి',
    );
    if (!mounted || picked == null) return;
    setState(() {
      _probeDate = DateTime(
        picked.year,
        picked.month,
        picked.day,
        12,
      );
    });
  }

  Widget _pathTile(
    String level,
    DashaPeriod period, {
    bool emphasize = false,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: emphasize ? const Color(0xFFFFECEF) : const Color(0xFFFFF8F4),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: emphasize ? const Color(0xFF8D3140) : const Color(0xFFE3C7CC),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$level • ${period.lord}',
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 3),
          Text('${_dateTime(period.start)} → ${_dateTime(period.end)}'),
          Text(
            _years(period.years),
            style: const TextStyle(fontSize: 12, color: Color(0xFF66595B)),
          ),
        ],
      ),
    );
  }

  Widget _periodTable(
    String title,
    List<DashaPeriod> periods,
    String? activeLord,
  ) {
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      childrenPadding: EdgeInsets.zero,
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.w800),
      ),
      subtitle: Text('${periods.length} periods'),
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columnSpacing: 18,
            headingRowHeight: 42,
            dataRowMinHeight: 42,
            dataRowMaxHeight: 54,
            columns: const [
              DataColumn(label: Text('Lord')),
              DataColumn(label: Text('Start')),
              DataColumn(label: Text('End')),
              DataColumn(label: Text('Duration')),
            ],
            rows: periods
                .map(
                  (p) => DataRow(
                    selected: activeLord != null && p.lord == activeLord,
                    cells: [
                      DataCell(Text(p.lord)),
                      DataCell(Text(_date(p.start))),
                      DataCell(Text(_date(p.end))),
                      DataCell(Text(_years(p.years))),
                    ],
                  ),
                )
                .toList(),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final system = DashaService.system(
      kind: _selectedKind,
      chart: widget.chart,
      birthDateTime: widget.birthDateTime,
    );
    final path = DashaService.pathAt(system, _probeDate);

    final ads = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.mahadasha);
    final pds = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.antardasha);
    final suks = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.pratyantardasha);
    final pranas = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.sukshma);

    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'దశా గణన',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            const Text(
              'త్రిభాగి • వింశోత్తరి • ఖండ • యోగిని — birth balance నుంచి 5 స్థాయుల వరకు.',
              style: TextStyle(color: Color(0xFF65585A)),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: DashaSystemKind.values
                  .map(
                    (kind) => ChoiceChip(
                      label: Text(kind.teluguLabel),
                      selected: _selectedKind == kind,
                      onSelected: (_) => setState(() => _selectedKind = kind),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF5F6),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE0C1C7)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    system.label,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Birth start: ${system.startingLord} • Nakshatra ${(system.moonNakshatraIndex + 1)} • '
                    'elapsed ${(system.nakshatraFractionElapsed * 100).toStringAsFixed(2)}%',
                  ),
                  Text(
                    'Birth balance: ${system.birthBalanceYears.toStringAsFixed(6)} years '
                    '• source Y-M-D(360): ${DashaService.sourceYmd360(system.birthBalanceYears)}',
                  ),
                  const SizedBox(height: 6),
                  Text(
                    system.sourceNote,
                    style: const TextStyle(fontSize: 12.5, color: Color(0xFF65585A)),
                  ),
                  if (_selectedKind == DashaSystemKind.tribhagi) ...[
                    const SizedBox(height: 6),
                    const Text(
                      'Mehta timing priority: 2వ స్థాయి అంతర్దశ → 3వ ప్రత్యంతర్దశ → 4వ సూక్ష్మ → 5వ ప్రాణం. మహాదశను eventకు ఒక్కటే నిర్ణయకంగా తీసుకోరు.',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'పరిశీలన తేదీ: ${_date(_probeDate)}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: _pickDate,
                  icon: const Icon(Icons.calendar_month_outlined),
                  label: const Text('తేదీ'),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (path == null)
              const Text(
                'ఈ తేదీ generated dasha range బయట ఉంది. వేరే తేదీ ఎంచుకోండి.',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
              )
            else ...[
              const Text(
                'ఈ తేదీకి 5 స్థాయుల దశా స్థితి',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              _pathTile('1. మహాదశ', path.mahadasha),
              _pathTile('2. అంతర్దశ', path.antardasha, emphasize: true),
              _pathTile('3. ప్రత్యంతర్దశ', path.pratyantardasha, emphasize: true),
              _pathTile('4. సూక్ష్మ', path.sukshma, emphasize: true),
              _pathTile('5. ప్రాణ', path.prana, emphasize: true),
              const Divider(height: 24),
              _periodTable(
                'మహాదశ క్రమం',
                system.mahadashas,
                path.mahadasha.lord,
              ),
              _periodTable(
                '${path.mahadasha.lord} — అంతర్దశలు',
                ads,
                path.antardasha.lord,
              ),
              _periodTable(
                '${path.antardasha.lord} — ప్రత్యంతర్దశలు',
                pds,
                path.pratyantardasha.lord,
              ),
              _periodTable(
                '${path.pratyantardasha.lord} — సూక్ష్మ దశలు',
                suks,
                path.sukshma.lord,
              ),
              _periodTable(
                '${path.sukshma.lord} — ప్రాణ దశలు',
                pranas,
                path.prana.lord,
              ),
            ],
            const SizedBox(height: 8),
            const Text(
              'Date mapping: civil year 365.2425 days. Mehta supplied period tables also show Y-M-D reference values on a 360-day year / 30-day month convention; the app displays that reference balance separately instead of silently mixing conventions.',
              style: TextStyle(fontSize: 11.5, color: Color(0xFF6A5D60)),
            ),
          ],
        ),
      ),
    );
  }
}

class _VimshottariCard extends StatelessWidget {
  final VimshottariResult result;
  final DateTime birthDateTime;

  const _VimshottariCard({
    required this.result,
    required this.birthDateTime,
  });

  String _date(DateTime dt) =>
      '${AstroFormat.two(dt.day)}-${AstroFormat.two(dt.month)}-${dt.year}';

  @override
  Widget build(BuildContext context) {
    final birthMd = result.currentMahadasha;
    final now = DateTime.now();
    final currentMd =
        DashaService.periodAt(result.mahadashas, now) ?? birthMd;
    final currentAds = DashaService.subPeriods(currentMd);
    final currentAd =
        DashaService.periodAt(currentAds, now) ?? currentAds.first;
    final currentPds = DashaService.subPeriods(currentAd);
    final currentPd =
        DashaService.periodAt(currentPds, now) ?? currentPds.first;

    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'వింశోత్తరి దశలు',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(
              'Moon Nakshatra lord: ${result.moonNakshatraLord} • '
              'elapsed ${(result.nakshatraFractionElapsed * 100).toStringAsFixed(2)}%',
            ),
            const SizedBox(height: 8),
            DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xFFFFF0F2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF8D3140)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Text(
                  'Birth Mahadasha: ${birthMd.lord}  '
                  '${_date(birthMd.start)} → ${_date(birthMd.end)}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF7F3),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE4C8CD)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'ప్రస్తుత దశా స్థితి',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'MD ${currentMd.lord}: ${_date(currentMd.start)} → ${_date(currentMd.end)}',
                  ),
                  Text(
                    'AD ${currentAd.lord}: ${_date(currentAd.start)} → ${_date(currentAd.end)}',
                  ),
                  Text(
                    'PD ${currentPd.lord}: ${_date(currentPd.start)} → ${_date(currentPd.end)}',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Mahadasha sequence',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('Lord')),
                  DataColumn(label: Text('Start')),
                  DataColumn(label: Text('End')),
                ],
                rows: result.mahadashas.take(10).map((p) => DataRow(cells: [
                      DataCell(Text(p.lord)),
                      DataCell(Text(_date(p.start))),
                      DataCell(Text(_date(p.end))),
                    ])).toList(),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              '${birthMd.lord} birth-MD Antardashas',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            ...result.currentAntardashas.map(
              (p) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('${p.lord}: ${_date(p.start)} → ${_date(p.end)}'),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Convention: 120-year Vimshottari proportions; civil year = 365.2425 days. '
              'Calculation convention is shown explicitly so dates are reproducible.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}


class _JaiminiCard extends StatelessWidget {
  final JaiminiResult result;
  final AstroChartResult chart;

  const _JaiminiCard({required this.result, required this.chart});

  Map<int, List<String>> _jaiminiOccupants() {
    final occupants = <int, List<String>>{
      for (var i = 0; i < 12; i++) i: <String>[],
    };

    final karakaByPlanet = <String, String>{
      for (final k in result.charaKarakas) k.planet: k.code,
    };

    for (final planet in chart.planets) {
      final karaka = karakaByPlanet[planet.name];
      var label = '${planet.shortName} ${planet.degreesInSign.toStringAsFixed(1)}°';
      if (karaka != null) label += ' $karaka';
      occupants[planet.signIndex]!.add(label);
    }

    for (final pada in result.arudhaPadas) {
      occupants[pada.padaSignIndex]!.add('P${pada.padaNumber}');
    }

    return occupants;
  }

  @override
  Widget build(BuildContext context) {
    final rahu = chart.planets.firstWhere((p) => p.name == 'Rahu');
    final rahuEffective = 30.0 - rahu.degreesInSign;
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('జైమిని System', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            _JaiminiApplicableRules(rules: result.applicableRules),
            const SizedBox(height: 16),
            _SouthIndianChart(
              title: 'జైమిని చక్రం • P1–P12',
              ascendantSignIndex: chart.ascendantSignIndex,
              occupants: _jaiminiOccupants(),
            ),
            const SizedBox(height: 12),
            const Text(
              'Pada / Arudha P1–P12',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            ...result.arudhaPadas.map(
              (p) => Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(
                  'P${p.padaNumber}: ${p.sourceSignIndex + 1} → ${p.lord} ${p.lordSignIndex + 1} • దూరం ${p.distance} → ${p.padaSignIndex + 1}',
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text('Atmakaraka: ${result.atmakaraka}'),
            Text('Karakamsa: ${result.karakamsaSignIndex + 1}'),
            Text('Rahu effective degree reference: ${rahuEffective.toStringAsFixed(4)}°'),
            if (result.hasDegreeTie)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text(
                  'Degree tie detected — supplied source tie/empty-slot procedure must be applied manually before final karaka assignment.',
                  style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF8D3140)),
                ),
              ),
            const SizedBox(height: 10),
            const Text('Chara Karakas (7-karaka core)', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: result.charaKarakas
                  .map((k) => Chip(label: Text('${k.code}: ${k.planet} ${k.effectiveDegree.toStringAsFixed(2)}°')))
                  .toList(),
            ),
            const SizedBox(height: 12),
            const Text('Lagna Argala / Virodha', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            ...result.argalaFromLagna.map(
              (row) => Text(
                '${row.label}: ${row.signIndex + 1}  ${row.planets.isEmpty ? '—' : row.planets.join(', ')}',
              ),
            ),
            const SizedBox(height: 12),
            const Text('Rashi Drishti', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...List.generate(12, (i) {
              final targets = result.rashiDrishti[i]!
                  .map((s) => '${s + 1}')
                  .join(', ');
              return Text('${i + 1} → $targets');
            }),
            const SizedBox(height: 8),
            const Text(
              'P1–P12 calculation: source sign నుండి lord వరకు inclusive దూరం ఎంతైతే, lord నుండి అదే inclusive దూరం count చేసి Pada పొందుతుంది. 4వ/7వ source examples కూడా ఇదే విధంగా అమలవుతాయి. Chara Dasha variants మాత్రం source verification తర్వాత enable చేయాలి.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}


class _JaiminiApplicableRules extends StatelessWidget {
  final List<JaiminiRuleHit> rules;

  const _JaiminiApplicableRules({required this.rules});

  Color _color(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => const Color(0xFF1B7F3A),
        JaiminiRuleNature.adverse => const Color(0xFFB3261E),
        JaiminiRuleNature.neutral => const Color(0xFF6B5B5E),
      };

  IconData _icon(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => Icons.check_circle,
        JaiminiRuleNature.adverse => Icons.cancel,
        JaiminiRuleNature.neutral => Icons.info_outline,
      };

  String _status(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => 'అనుకూలం',
        JaiminiRuleNature.adverse => 'ప్రతికూలం / జాగ్రత్త',
        JaiminiRuleNature.neutral => 'వివరణాత్మక సూచన',
      };

  void _showDetails(BuildContext context, JaiminiRuleHit rule) {
    final color = _color(rule.nature);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            18,
            20,
            24 + MediaQuery.of(sheetContext).viewInsets.bottom,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(_icon(rule.nature), color: color, size: 30),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          rule.topic,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          _status(rule.nature),
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                rule.combination,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
              ),
              const Divider(height: 28),
              const Text('పలితం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.result, style: const TextStyle(fontSize: 16, height: 1.45)),
              const SizedBox(height: 18),
              const Text('జాతక పరిశీలన', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.analysis, style: const TextStyle(fontSize: 16, height: 1.45)),
              const SizedBox(height: 18),
              const Text('పరిహారం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.remedy, style: const TextStyle(fontSize: 16, height: 1.45)),
              const Divider(height: 28),
              Text(
                '${rule.ruleId} • ${rule.source}',
                style: const TextStyle(fontSize: 12, color: Color(0xFF6E5D60)),
              ),
              const SizedBox(height: 8),
              const Text(
                'గమనిక: ఒకే నియమంతో తుది తీర్పు ఇవ్వకుండా, అనుకూల మరియు ప్రతికూల supporting rules అన్నింటినీ కలిపి పరిశీలించాలి.',
                style: TextStyle(fontSize: 12, color: Color(0xFF6E5D60)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (rules.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF7F3),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE4C6C9)),
        ),
        child: const Text(
          'ఈ జాతకానికి ప్రస్తుతం active source-verified Jaimini combinations match కాలేదు. Chart, P1–P12, Karakas మాత్రం క్రింద చూడవచ్చు.',
        ),
      );
    }

    final yogaCount = rules.where((r) => r.isYoga).length;
    final favorable = rules.where((r) => r.nature == JaiminiRuleNature.favorable).length;
    final adverse = rules.where((r) => r.nature == JaiminiRuleNature.adverse).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'ఈ జాతకానికి వర్తించే కాంబినేషన్స్ / యోగాలు',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 6),
        Text(
          'యోగాలు $yogaCount  •  అనుకూలం $favorable  •  ప్రతికూలం $adverse',
          style: const TextStyle(color: Color(0xFF6E5D60), fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        ...rules.map((rule) {
          final color = _color(rule.nature);
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.35)),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 10, 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Icon(_icon(rule.nature), color: color, size: 28),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'అంశము: ${rule.topic}',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          rule.combination,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 8),
                        InkWell(
                          borderRadius: BorderRadius.circular(8),
                          onTap: () => _showDetails(context, rule),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Text(
                                    'పలితం: ${rule.result}',
                                    style: TextStyle(
                                      color: color,
                                      fontWeight: FontWeight.w800,
                                      height: 1.35,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Icon(Icons.touch_app_outlined, size: 18, color: color),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }
}

class _KpCard extends StatelessWidget {
  final List<KpStellarPosition> rows;

  const _KpCard({required this.rows});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('KP System', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'Planet → Sign Lord → Star Lord → Sub Lord stellar table. Sub divisions use unequal Vimshottari proportions inside each 13°20′ star.',
            ),
            const SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('Planet')),
                  DataColumn(label: Text('Sign Lord')),
                  DataColumn(label: Text('Star Lord')),
                  DataColumn(label: Text('Sub Lord')),
                ],
                rows: rows.map((r) => DataRow(cells: [
                      DataCell(Text(r.body)),
                      DataCell(Text(r.signLord)),
                      DataCell(Text(r.starLord)),
                      DataCell(Text(r.subLord)),
                    ])).toList(),
              ),
            ),
            const SizedBox(height: 12),
            const Text('Source-based Event House Groups', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...KpService.eventGroups.map(
              (e) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '${e.event}: ${e.favourableHouses.join(', ')}  • Primary ${e.primaryCusp}'
                  '${e.contraryHouses.isEmpty ? '' : ' • Contrary ${e.contraryHouses.join(', ')}'}',
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'KP Cusp Sub-Lord promise/denial engineకు exact 12 cusp longitudes + house ownership/signification layer అవసరం. ఈ buildలో planetary Star/Sub coreను మాత్రమే activate చేశాం; cusp resultను ఊహించి చూపడం లేదు.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class _SourcePendingCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final String text;

  const _SourcePendingCard({
    required this.title,
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: const Color(0xFF7B1E2B)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(text),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BirthSummaryCard extends StatelessWidget {
  final BirthData birthData;

  const _BirthSummaryCard({required this.birthData});

  @override
  Widget build(BuildContext context) {
    final dt = birthData.localDateTime;
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              birthData.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('స్థలం: ${birthData.place}'),
            Text(
              'Lat ${birthData.latitude.toStringAsFixed(6)}  •  '
              'Lon ${birthData.longitude.toStringAsFixed(6)}',
            ),
            Text('జనన సమయం: ${AstroFormat.dateTime(dt)}'),
            Text(
              'Timezone: ${AstroFormat.timezoneOffset(birthData.timezoneOffsetHours)}',
            ),
          ],
        ),
      ),
    );
  }
}

class _CalculationSummaryCard extends StatelessWidget {
  final AstroChartResult result;
  final String ayanamsaName;

  const _CalculationSummaryCard({
    required this.result,
    required this.ayanamsaName,
  });

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.verified_outlined),
                SizedBox(width: 8),
                Text(
                  'Calculation',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text('Engine: Swiss Ephemeris ${result.engineVersion}'),
            const Text('Mode: Sidereal + Moshier ephemeris'),
            Text('Ayanamsa: $ayanamsaName'),
            Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
            const SizedBox(height: 8),
            Text(
              'లగ్నం: ${AstroFormat.longitudeDms(result.ascendantLongitude)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

class _SouthIndianChart extends StatelessWidget {
  final String title;
  final int ascendantSignIndex;
  final Map<int, List<String>> occupants;

  const _SouthIndianChart({
    required this.title,
    required this.ascendantSignIndex,
    required this.occupants,
  });

  // Traditional South-Indian fixed-sign layout (fixed Rasi positions).
  // Row 1: Pisces | Aries | Taurus | Gemini
  // Row 2: Aquarius |        centre       | Cancer
  // Row 3: Capricorn|        centre       | Leo
  // Row 4: Sagittarius | Scorpio | Libra | Virgo
  static const Map<int, (int, int)> _positionBySign = <int, (int, int)>{
    11: (0, 0), // Pisces
    0: (0, 1),  // Aries
    1: (0, 2),  // Taurus
    2: (0, 3),  // Gemini
    10: (1, 0), // Aquarius
    3: (1, 3),  // Cancer
    9: (2, 0),  // Capricorn
    4: (2, 3),  // Leo
    8: (3, 0),  // Sagittarius
    7: (3, 1),  // Scorpio
    6: (3, 2),  // Libra
    5: (3, 3),  // Virgo
  };

  @override
  Widget build(BuildContext context) {
    const lineColor = Color(0xFF8B2D3B);
    const centreColor = Color(0xFFFFFBF6);

    return Card(color: Colors.white, surfaceTintColor: Colors.transparent,
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Color(0xFF2C2022),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'South Indian fixed-sign chart • లగ్నం: ${ascendantSignIndex + 1}',
              style: const TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: Color(0xFF5F5052),
              ),
            ),
            const SizedBox(height: 12),
            AspectRatio(
              aspectRatio: 1,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final side = constraints.maxWidth;
                  final cell = side / 4;
                  return DecoratedBox(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: lineColor, width: 2),
                    ),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        for (final entry in _positionBySign.entries)
                          Positioned(
                            left: entry.value.$2 * cell,
                            top: entry.value.$1 * cell,
                            width: cell,
                            height: cell,
                            child: _TraditionalRasiCell(
                              signIndex: entry.key,
                              isAscendant: entry.key == ascendantSignIndex,
                              occupants: occupants[entry.key] ?? const <String>[],
                            ),
                          ),
                        Positioned(
                          left: cell,
                          top: cell,
                          width: cell * 2,
                          height: cell * 2,
                          child: Container(
                            decoration: BoxDecoration(
                              color: centreColor,
                              border: Border.all(color: lineColor, width: 2),
                            ),
                            padding: const EdgeInsets.all(10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  title,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFF2C2022),
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'లగ్నం • ${ascendantSignIndex + 1}',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    color: lineColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TraditionalRasiCell extends StatelessWidget {
  final int signIndex;
  final bool isAscendant;
  final List<String> occupants;

  const _TraditionalRasiCell({
    required this.signIndex,
    required this.isAscendant,
    required this.occupants,
  });

  @override
  Widget build(BuildContext context) {
    const lineColor = Color(0xFF8B2D3B);
    return Container(
      decoration: BoxDecoration(
        color: isAscendant ? const Color(0xFFFFECEF) : Colors.white,
        border: Border.all(color: lineColor, width: 1),
      ),
      padding: const EdgeInsets.all(5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  '${signIndex + 1}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF2C2022),
                  ),
                ),
              ),
              if (isAscendant)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: lineColor,
                  ),
                  child: const Text(
                    'Lg',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 9.5,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 4),
          Expanded(
            child: SingleChildScrollView(
              child: Wrap(
                spacing: 4,
                runSpacing: 2,
                children: occupants.map((text) {
                  return Text(
                    text,
                    style: const TextStyle(
                      fontSize: 10.8,
                      height: 1.15,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF3B2C2E),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReportActions extends StatelessWidget {
  final String title;
  final String Function() reportText;

  const _ReportActions({required this.title, required this.reportText});

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Report',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(text: reportText()),
                      );
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Report clipboardకి copy అయింది'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.copy_all_outlined),
                    label: const Text('Copy'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await ReportStorageService.save(
                        title: title,
                        body: reportText(),
                      );
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Report locally save అయింది'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('Save'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () async {
                  await SharePlus.instance.share(
                    ShareParams(
                      text: reportText(),
                      title: 'Annapurna Astro Vastu - $title',
                    ),
                  );
                },
                icon: const Icon(Icons.share_outlined),
                label: const Text('Share Report'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;

  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
    );
  }
}

Map<int, List<String>> _occupantsFromVarga(
  VargaChartData data, {
  AstroChartResult? includeDegreesFrom,
}) {
  final result = <int, List<String>>{
    for (var i = 0; i < 12; i++) i: <String>[],
  };

  for (final planet in data.planets) {
    var label = planet.shortName;
    if (includeDegreesFrom != null && data.definition.factor == 1) {
      final source =
          includeDegreesFrom.planets.firstWhere((p) => p.name == planet.name);
      label += ' ${source.degreesInSign.toStringAsFixed(1)}°';
    }
    if (planet.retrograde) label += 'R';
    result[planet.signIndex]!.add(label);
  }
  return result;
}

class _ErrorView extends StatelessWidget {
  final String message;

  const _ErrorView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 46),
                const SizedBox(height: 12),
                const Text(
                  'Calculation ప్రారంభం కాలేదు',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(message, textAlign: TextAlign.center),
                const SizedBox(height: 10),
                const Text(
                  'flutter pub get చేసిన తర్వాత Android buildలో sweph native library కూడా build అవుతుంది.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
