import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../models/birth_data.dart';
import '../services/report_storage_service.dart';
import '../utils/astro_format.dart';

class ChartScreen extends StatefulWidget {
  final BirthData birthData;

  const ChartScreen({
    super.key,
    required this.birthData,
  });

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  late final Future<AstroChartResult> _future;

  static const signNames = AstroFormat.signNamesTe;
  @override
  void initState() {
    super.initState();
    _future = AstroCalculationService.calculate(widget.birthData);
  }

  String _formatDateTime(DateTime dt) => AstroFormat.dateTime(dt);

  String _formatLongitude(double longitude) =>
      AstroFormat.longitudeDms(longitude);

  String _reportText(AstroChartResult result) {
    final b = widget.birthData;
    final buffer = StringBuffer()
      ..writeln('అన్నపూర్ణ ఆస్ట్రో వాస్తు')
      ..writeln('పేరు: ${b.name}')
      ..writeln('స్థలం: ${b.place}')
      ..writeln('Latitude: ${b.latitude}, Longitude: ${b.longitude}')
      ..writeln('Local: ${_formatDateTime(b.localDateTime)}')
      ..writeln('UTC: ${_formatDateTime(b.utcDateTime)}')
      ..writeln('Ayanamsa: ${b.ayanamsa.label}')
      ..writeln('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°')
      ..writeln('Lagna: ${_formatLongitude(result.ascendantLongitude)}')
      ..writeln('')
      ..writeln('గ్రహ స్థితులు:');

    for (final planet in result.planets) {
      buffer.writeln(
        '${planet.name}: ${_formatLongitude(planet.longitude)}'
        '${planet.retrograde ? '  (R)' : ''}',
      );
    }
    buffer
      ..writeln('')
      ..writeln('Engine: Swiss Ephemeris ${result.engineVersion} (Moshier mode)');
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('జాతక చక్రం'),
      ),
      body: FutureBuilder<AstroChartResult>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 14),
                  Text('Swiss Ephemeris calculation జరుగుతోంది…'),
                ],
              ),
            );
          }

          if (snapshot.hasError || !snapshot.hasData) {
            return _ErrorView(
              message: snapshot.error?.toString() ?? 'Calculation failed',
            );
          }

          final result = snapshot.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _BirthSummaryCard(birthData: widget.birthData),
              const SizedBox(height: 12),
              _CalculationSummaryCard(
                result: result,
                formatLongitude: _formatLongitude,
                ayanamsaName: widget.birthData.ayanamsa.label,
              ),
              const SizedBox(height: 16),
              const Text(
                'రాశి చక్రం',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              _RasiGrid(
                result: result,
                signNames: signNames,
              ),
              const SizedBox(height: 18),
              const Text(
                'గ్రహ స్థితులు',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              ...result.planets.map(
                (planet) => Card(
                  margin: const EdgeInsets.only(bottom: 8),
                  child: ListTile(
                    title: Text(
                      planet.name,
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    subtitle: Text(_formatLongitude(planet.longitude)),
                    trailing: planet.retrograde
                        ? const Chip(label: Text('R'))
                        : null,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Event Result / శాతం',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'ఈ ZIPలో verified event-rule database లేదు. అందువల్ల అనుకూల శాతాన్ని ఊహించి చూపించడం లేదు. '
                        'గ్రహస్థితులు, లగ్నం మాత్రం Swiss Ephemeris ద్వారా లెక్కించబడుతున్నాయి.',
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () async {
                                await Clipboard.setData(
                                  ClipboardData(text: _reportText(result)),
                                );
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Report clipboardకి copy అయింది'),
                                  ),
                                );
                              },
                              icon: const Icon(Icons.copy_all_outlined),
                              label: const Text('Copy'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: () async {
                                await ReportStorageService.save(
                                  title: widget.birthData.name,
                                  body: _reportText(result),
                                );
                                if (!context.mounted) return;
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Report locally save అయింది'),
                                  ),
                                );
                              },
                              icon: const Icon(Icons.save_outlined),
                              label: const Text('Save'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: () async {
                            await SharePlus.instance.share(
                              ShareParams(
                                text: _reportText(result),
                                title: 'Annapurna Astro Vastu - ${widget.birthData.name}',
                              ),
                            );
                          },
                          icon: const Icon(Icons.share_outlined),
                          label: const Text('Share Report'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 30),
            ],
          );
        },
      ),
    );
  }
}

class _BirthSummaryCard extends StatelessWidget {
  final BirthData birthData;

  const _BirthSummaryCard({required this.birthData});

  @override
  Widget build(BuildContext context) {
    final dt = birthData.localDateTime;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              birthData.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('స్థలం: ${birthData.place}'),
            Text(
              'Lat ${birthData.latitude.toStringAsFixed(6)}  •  '
              'Lon ${birthData.longitude.toStringAsFixed(6)}',
            ),
            Text(
              'జనన సమయం: ${AstroFormat.dateTime(dt)}',
            ),
            Text('Timezone: ${AstroFormat.timezoneOffset(birthData.timezoneOffsetHours)}'),
          ],
        ),
      ),
    );
  }
}

class _CalculationSummaryCard extends StatelessWidget {
  final AstroChartResult result;
  final String Function(double) formatLongitude;
  final String ayanamsaName;

  const _CalculationSummaryCard({
    required this.result,
    required this.formatLongitude,
    required this.ayanamsaName,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.verified_outlined),
                SizedBox(width: 8),
                Text(
                  'Calculation',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text('Engine: Swiss Ephemeris ${result.engineVersion}'),
            const Text('Mode: Sidereal + Moshier ephemeris'),
            Text('Ayanamsa: $ayanamsaName'),
            Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
            const SizedBox(height: 8),
            Text(
              'లగ్నం: ${formatLongitude(result.ascendantLongitude)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

class _RasiGrid extends StatelessWidget {
  final AstroChartResult result;
  final List<String> signNames;

  const _RasiGrid({
    required this.result,
    required this.signNames,
  });

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 1.05,
        crossAxisSpacing: 6,
        mainAxisSpacing: 6,
      ),
      itemCount: 12,
      itemBuilder: (context, sign) {
        final planets = result.planets.where((p) => p.signIndex == sign).toList();
        final isAsc = result.ascendantSignIndex == sign;
        return Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            border: Border.all(
              color: isAsc
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).dividerColor,
              width: isAsc ? 2 : 1,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${sign + 1}. ${signNames[sign]}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                  if (isAsc)
                    const Text(
                      'Lg',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                ],
              ),
              const SizedBox(height: 5),
              Expanded(
                child: SingleChildScrollView(
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: planets.map((planet) {
                      final d = planet.degreesInSign;
                      return Text(
                        '${planet.shortName} ${d.toStringAsFixed(1)}°${planet.retrograde ? 'R' : ''}',
                        style: const TextStyle(fontSize: 12),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;

  const _ErrorView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 46),
                const SizedBox(height: 12),
                const Text(
                  'Calculation ప్రారంభం కాలేదు',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(message, textAlign: TextAlign.center),
                const SizedBox(height: 10),
                const Text(
                  'flutter pub get చేసిన తర్వాత Android buildలో sweph native library కూడా build అవుతుంది.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
