import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../astrology/ashtakavarga_service.dart';
import '../astrology/bsp_service.dart';
import '../astrology/bnn_service.dart';
import '../astrology/ashtakavarga_interpretation_service.dart';
import '../astrology/ashtakavarga_timing_service.dart';
import '../astrology/ashtakavarga_transit_window_service.dart';
import '../astrology/ashtakavarga_event_evidence_service.dart';
import '../astrology/ashtakavarga_event_year_service.dart';
import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/d10_career_service.dart';
import '../astrology/dasha_service.dart';
import '../astrology/d10_validation_service.dart';
import '../astrology/d27_health_service.dart';
import '../astrology/d9_marriage_service.dart';
import '../astrology/gem_remedy_service.dart';
import '../astrology/consultation_service.dart';
import '../astrology/consultation_timing_service.dart';
import '../astrology/jaimini_service.dart';
import '../astrology/jaimini_chara_dasha_service.dart';
import '../astrology/marriage_material_registry.dart';
import '../astrology/sk_mehta_service.dart';
import '../astrology/mehta_combination_service.dart';
import '../astrology/kp_service.dart';
import '../astrology/planet_detail_service.dart';
import '../astrology/panchadha_maitri_service.dart';
import '../astrology/varga_service.dart';
import '../astrology/varga_rule_service.dart';
import '../astrology/vedic_calculation_service.dart';
import '../models/birth_data.dart';
import '../services/chart_storage_service.dart';
import '../services/report_storage_service.dart';
import '../utils/astro_format.dart';
import 'hasta_samudrika_tab.dart';
import 'd10_career_overview.dart';


enum _AstroSystem {
  dasha,
  jamakola,
  jaimini,
  tajik,
  bcp,
  bsp,
  bnn,
  kp,
}

extension _AstroSystemLabel on _AstroSystem {
  String get title => switch (this) {
        _AstroSystem.dasha => 'దశలు',
        _AstroSystem.jamakola => 'Jamakola',
        _AstroSystem.jaimini => 'జైమిని System',
        _AstroSystem.tajik => 'Tajik / Varshaphala',
        _AstroSystem.bcp => 'BCP',
        _AstroSystem.bsp => 'BSP',
        _AstroSystem.bnn => 'BNN',
        _AstroSystem.kp => 'KP',
      };

  IconData get icon => switch (this) {
        _AstroSystem.dasha => Icons.timeline_outlined,
        _AstroSystem.jamakola => Icons.auto_awesome_outlined,
        _AstroSystem.jaimini => Icons.account_tree_outlined,
        _AstroSystem.tajik => Icons.calendar_month_outlined,
        _AstroSystem.bcp => Icons.rotate_right_outlined,
        _AstroSystem.bsp => Icons.rule_folder_outlined,
        _AstroSystem.bnn => Icons.hub_outlined,
        _AstroSystem.kp => Icons.functions_outlined,
      };
}

class _BirthTimeEditResult {
  final bool useOriginal;
  final int? hour;
  final int? minute;
  final int? second;

  const _BirthTimeEditResult({
    this.useOriginal = false,
    this.hour,
    this.minute,
    this.second,
  });
}

class ChartScreen extends StatefulWidget {
  final BirthData birthData;
  final String? savedChartId;

  const ChartScreen({
    super.key,
    required this.birthData,
    this.savedChartId,
  });

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  late final Future<AstroChartResult> _future;
  int _selectedVarga = 9;
  String _selectedBav = 'Sun';
  _AstroSystem? _activeSystem;
  String? _savedChartId;

  @override
  void initState() {
    super.initState();
    _savedChartId = widget.savedChartId;
    _future = AstroCalculationService.calculate(widget.birthData);
  }

  Future<void> _saveChart({bool saveAsNew = false}) async {
    final wasAlreadySaved = _savedChartId != null;
    final id = await ChartStorageService.save(
      widget.birthData,
      existingId: saveAsNew ? null : _savedChartId,
      saveAsNew: saveAsNew,
    );
    if (!mounted) return;
    if (!saveAsNew) {
      setState(() => _savedChartId = id);
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          saveAsNew
              ? 'ఈ జాతకం కొత్త Saved Chartగా save అయింది'
              : (wasAlreadySaved
                  ? 'జాతక చార్ట్ Update అయింది'
                  : 'జాతక చార్ట్ Saved Chartsలో save అయింది'),
        ),
      ),
    );
  }

  String _birthTimeOnly(DateTime dt) {
    String two(int value) => value.toString().padLeft(2, '0');
    return '${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
  }

  Future<void> _editBirthTime() async {
    final active = widget.birthData.localDateTime;
    final original = widget.birthData.originalBirthDateTime;
    final hour = TextEditingController(text: active.hour.toString().padLeft(2, '0'));
    final minute = TextEditingController(text: active.minute.toString().padLeft(2, '0'));
    final second = TextEditingController(text: active.second.toString().padLeft(2, '0'));

    final choice = await showDialog<_BirthTimeEditResult>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Birth Time మార్చండి'),
        content: SizedBox(
          width: 420,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Original Birth Time: ${_birthTimeOnly(original)}'),
              const SizedBox(height: 4),
              Text('Current / Rectified Time: ${_birthTimeOnly(active)}'),
              const SizedBox(height: 14),
              const Text(
                'కొత్త సమయం',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: hour,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'HH (0–23)'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: minute,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'MM (0–59)'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: second,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'SS (0–59)'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              const Text(
                'Apply & Recalculate చేసినప్పుడు అన్ని D1/Bhava/Varga/Dasha calculations కొత్త సమయంతో మళ్లీ లెక్కించబడతాయి. Original time మాత్రం safeగా ఉంటుంది.',
                style: TextStyle(fontSize: 12.5),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(
              context,
              _BirthTimeEditResult(useOriginal: true),
            ),
            child: const Text('Use Original & Recalculate'),
          ),
          FilledButton(
            onPressed: () {
              final h = int.tryParse(hour.text.trim());
              final m = int.tryParse(minute.text.trim());
              final sec = int.tryParse(second.text.trim());
              if (h == null || h < 0 || h > 23 ||
                  m == null || m < 0 || m > 59 ||
                  sec == null || sec < 0 || sec > 59) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Birth Time సరిగా ఇవ్వండి')),
                );
                return;
              }
              Navigator.pop(
                context,
                _BirthTimeEditResult(hour: h, minute: m, second: sec),
              );
            },
            child: const Text('Apply & Recalculate'),
          ),
        ],
      ),
    );

    hour.dispose();
    minute.dispose();
    second.dispose();
    if (!mounted || choice == null) return;

    late final BirthData updated;
    if (choice.useOriginal) {
      updated = widget.birthData.copyWith(
        localDateTime: original,
        originalLocalDateTime: original,
      );
    } else {
      final newTime = DateTime(
        active.year,
        active.month,
        active.day,
        choice.hour!,
        choice.minute!,
        choice.second!,
      );
      updated = widget.birthData.copyWith(
        localDateTime: newTime,
        originalLocalDateTime:
            widget.birthData.originalLocalDateTime ?? active,
      );
    }

    await Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => ChartScreen(
          birthData: updated,
          savedChartId: _savedChartId,
        ),
      ),
    );
  }

  String _formatDateTime(DateTime dt) => AstroFormat.dateTime(dt);

  String _formatLongitude(double longitude) =>
      AstroFormat.longitudeDms(longitude);

  String _reportText(AstroChartResult result) {
    final b = widget.birthData;
    final panchanga = VedicCalculationService.panchanga(result);
    final av = AshtakavargaService.calculate(result);
    final d9 = VargaService.calculate(result, 9);
    final d10 = VargaService.calculate(result, 10);

    String placementText(VargaChartData data) {
      final items = data.planets
          .map((p) => '${p.shortName}:${p.signIndex + 1}')
          .join(', ');
      return '${data.definition.code} ${data.definition.teluguName}: '
          'Lg ${data.ascendantSignIndex + 1} | $items';
    }

    final buffer = StringBuffer()
      ..writeln('అన్నపూర్ణ ఆస్ట్రో వాస్తు')
      ..writeln('పేరు: ${b.name}')
      ..writeln('స్థలం: ${b.place}')
      ..writeln('Latitude: ${b.latitude}, Longitude: ${b.longitude}')
      ..writeln('Local: ${_formatDateTime(b.localDateTime)}')
      ..writeln(
        b.hasRectifiedTime
            ? 'Original Birth Time: ${_formatDateTime(b.originalBirthDateTime)}'
            : 'Original Birth Time: same as active time',
      )
      ..writeln('UTC: ${_formatDateTime(b.utcDateTime)}')
      ..writeln('Ayanamsa: ${b.ayanamsa.label}')
      ..writeln('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°')
      ..writeln('Lagna: ${_formatLongitude(result.ascendantLongitude)}')
      ..writeln('')
      ..writeln('పంచాంగ సారాంశం:')
      ..writeln('${panchanga.paksha} • ${panchanga.tithi}')
      ..writeln(
        '${panchanga.nakshatra} ${panchanga.nakshatraPada} పాదం • ${panchanga.yoga} యోగం • ${panchanga.karana} కరణం',
      )
      ..writeln('')
      ..writeln('గ్రహ స్థితులు:');

    for (final planet in result.planets) {
      final n = VedicCalculationService.nakshatra(planet.longitude);
      final house = VedicCalculationService.wholeSignHouse(
        planet.signIndex,
        result.ascendantSignIndex,
      );
      buffer.writeln(
        '${planet.name}: ${_formatLongitude(planet.longitude)} | '
        '${VedicCalculationService.nakshatraNamesTe[n.index]}-${n.pada} | '
        'House $house${planet.retrograde ? ' | R' : ''}',
      );
    }

    buffer
      ..writeln('')
      ..writeln(placementText(d9))
      ..writeln(placementText(d10))
      ..writeln('')
      ..writeln('Sarvashtakavarga: ${av.sarva.join(', ')}')
      ..writeln('SAV Total: ${av.grandTotal} ${av.totalsValid ? '(verified)' : '(check required)'}')
      ..writeln('')
      ..writeln('Engine: Swiss Ephemeris ${result.engineVersion} (Moshier mode)');
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 10,
      child: Scaffold(
        drawer: _SystemDrawer(
          selected: _activeSystem,
          onSelect: (system) => setState(() => _activeSystem = system),
          onMain: () => setState(() => _activeSystem = null),
        ),
        appBar: AppBar(
          title: Text(_activeSystem?.title ?? 'జాతక విశ్లేషణ'),
          actions: [
            IconButton(
              tooltip: 'Edit Birth Time / Recalculate',
              onPressed: _editBirthTime,
              icon: const Icon(Icons.more_time_outlined),
            ),
            IconButton(
              tooltip: _savedChartId == null ? 'Save Chart' : 'Save / Update Chart',
              onPressed: () => _saveChart(),
              icon: const Icon(Icons.bookmark_add_outlined),
            ),
            PopupMenuButton<String>(
              tooltip: 'Chart options',
              onSelected: (value) {
                if (value == 'save_new') {
                  _saveChart(saveAsNew: true);
                } else if (value == 'edit_time') {
                  _editBirthTime();
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(
                  value: 'save_new',
                  child: Text('Save as New'),
                ),
                PopupMenuItem(
                  value: 'edit_time',
                  child: Text('Edit Birth Time'),
                ),
              ],
            ),
          ],
          bottom: _activeSystem == null
              ? const TabBar(
                  isScrollable: true,
                  labelColor: Colors.white,
                  unselectedLabelColor: Color(0xFFFFD7DD),
                  indicatorColor: Colors.white,
                  tabs: [
                    Tab(icon: Icon(Icons.grid_on_outlined), text: 'జాతకం'),
                    Tab(icon: Icon(Icons.record_voice_over_outlined), text: 'క్లైంట్'),
                    Tab(icon: Icon(Icons.dashboard_outlined), text: 'వర్గాలు'),
                    Tab(icon: Icon(Icons.apps_outlined), text: 'అష్టకవర్గం'),
                    Tab(icon: Icon(Icons.favorite_outline), text: 'వివాహ పొంతన'),
                    Tab(icon: Icon(Icons.diamond_outlined), text: 'Gem Remedy'),
                    Tab(icon: Icon(Icons.auto_awesome_outlined), text: 'S.K. Mehta'),
                    Tab(icon: Icon(Icons.pan_tool_alt_outlined), text: 'హస్త సాముద్రికం'),
                    Tab(icon: Icon(Icons.calculate_outlined), text: 'లెక్కలు'),
                    Tab(icon: Icon(Icons.account_tree_outlined), text: 'సిస్టమ్స్'),
                  ],
                )
              : null,
        ),
        body: FutureBuilder<AstroChartResult>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 14),
                    Text('Swiss Ephemeris calculation జరుగుతోంది…'),
                  ],
                ),
              );
            }

            if (snapshot.hasError || !snapshot.hasData) {
              return _ErrorView(
                message: snapshot.error?.toString() ?? 'Calculation failed',
              );
            }

            final result = snapshot.data!;
            final av = AshtakavargaService.calculate(result);

            if (_activeSystem != null) {
              return _ResponsiveChartBody(
                child: _SystemDetailPage(
                  system: _activeSystem!,
                  birthData: widget.birthData,
                  result: result,
                  onBackToMain: () => setState(() => _activeSystem = null),
                ),
              );
            }

            return _ResponsiveChartBody(
              child: TabBarView(
              children: [
                _JatakaTab(
                  birthData: widget.birthData,
                  result: result,
                  reportText: () => _reportText(result),
                  onSaveChart: () => _saveChart(),
                ),
                _ConsultationTab(
                  birthData: widget.birthData,
                  result: result,
                  av: av,
                  onSaveChart: () => _saveChart(),
                ),
                _VargaTab(
                  birthData: widget.birthData,
                  result: result,
                  selectedVarga: _selectedVarga,
                  onChanged: (value) => setState(() => _selectedVarga = value),
                ),
                _AshtakavargaTab(
                  result: av,
                  chart: result,
                  birthData: widget.birthData,
                  ascendantSignIndex: result.ascendantSignIndex,
                  selectedPlanet: _selectedBav,
                  onPlanetChanged: (value) =>
                      setState(() => _selectedBav = value),
                ),
                _MarriageMatchingTab(
                  birthData: widget.birthData,
                  result: result,
                ),
                _GemRemedyTab(
                  result: result,
                  av: av,
                ),
                _SkMehtaTab(
                  birthData: widget.birthData,
                  result: result,
                  av: av,
                ),
                const HastaSamudrikaTab(),
                _CalculationsTab(
                  birthData: widget.birthData,
                  result: result,
                ),
                _SystemsTab(
                  birthData: widget.birthData,
                  result: result,
                ),
              ],
              ),
            );
          },
        ),
      ),
    );
  }
}


class _ResponsiveChartBody extends StatelessWidget {
  final Widget child;

  const _ResponsiveChartBody({required this.child});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth > 1180
            ? 1180.0
            : constraints.maxWidth;
        return Align(
          alignment: Alignment.topCenter,
          child: SizedBox(
            width: width,
            height: constraints.maxHeight,
            child: child,
          ),
        );
      },
    );
  }
}

class _JatakaTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;
  final String Function() reportText;
  final Future<void> Function() onSaveChart;

  const _JatakaTab({
    required this.birthData,
    required this.result,
    required this.reportText,
    required this.onSaveChart,
  });

  @override
  Widget build(BuildContext context) {
    final rasi = VargaService.calculate(result, 1);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _BirthSummaryCard(birthData: birthData),
        const SizedBox(height: 12),
        _CalculationSummaryCard(
          result: result,
          ayanamsaName: birthData.ayanamsa.label,
        ),
        const SizedBox(height: 16),
        const _SectionTitle('రాశి / జన్మ చక్రం'),
        const SizedBox(height: 10),
        _SouthIndianChart(
          title: 'D1 రాశి',
          ascendantSignIndex: rasi.ascendantSignIndex,
          occupants: _occupantsFromVarga(rasi, includeDegreesFrom: result),
          onOccupantTap: (label) {
            final planet = _planetFromOccupantLabel(result, label);
            if (planet != null) _showPlanetDetailSheet(context, result, planet);
          },
        ),
        const SizedBox(height: 12),
        const Text(
          'గ్రహాల డిగ్రీలు రాశి చక్రంలోనే చూపించబడతాయి. గ్రహం పేరును టచ్ చేస్తే పూర్తి Degree • Star Lord • Sub Lord • Amsa Devata • Vargaja/Vimshopaka వివరాలు కనిపిస్తాయి.',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B5B5E)),
        ),
        const SizedBox(height: 12),
        _ReportActions(
          title: birthData.name,
          reportText: reportText,
          onSaveChart: onSaveChart,
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


class _PlanetTapCard extends StatelessWidget {
  final AstroChartResult chart;
  final PlanetPosition planet;

  const _PlanetTapCard({required this.chart, required this.planet});

  @override
  Widget build(BuildContext context) {
    final n = VedicCalculationService.nakshatra(planet.longitude);
    final house = VedicCalculationService.wholeSignHouse(
      planet.signIndex,
      chart.ascendantSignIndex,
    );
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        onTap: () => _showPlanetDetailSheet(context, chart, planet),
        title: Text(
          planet.name,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          'డిగ్రీ: ${AstroFormat.degreeDms(planet.degreesInSign)}\n'
          '${VedicCalculationService.nakshatraNamesTe[n.index]} • ${n.pada} పాదం • House $house',
        ),
        isThreeLine: true,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (planet.retrograde) const Chip(label: Text('R')),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }
}

void _showPlanetDetailSheet(
  BuildContext context,
  AstroChartResult chart,
  PlanetPosition planet,
) {
  final detail = PlanetDetailService.forPlanet(chart, planet);
  final n = VedicCalculationService.nakshatra(planet.longitude);
  final v = detail.vargaStrength;
  final consult = ConsultationService.planetSummary(chart: chart, planet: planet);

  String factors(List<int> items) =>
      items.isEmpty ? '—' : items.map((e) => 'D$e').join(', ');

  Widget row(String label, String value, {FontWeight? valueWeight}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 5,
            child: Text(label, style: const TextStyle(color: Color(0xFF5F5052))),
          ),
          Expanded(
            flex: 6,
            child: Text(
              value,
              style: TextStyle(fontWeight: valueWeight ?? FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    constraints: const BoxConstraints(maxWidth: 760),
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (sheetContext) => SafeArea(
      child: FractionallySizedBox(
        heightFactor: 0.90,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: const Color(0xFFFFE8EC),
                    foregroundColor: const Color(0xFF8B1E2D),
                    child: Text(planet.shortName),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          planet.name,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                        ),
                        Text(
                          'డిగ్రీ: ${AstroFormat.degreeDms(planet.degreesInSign)}${planet.retrograde ? ' • R' : ''}',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(sheetContext).pop(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Card(
                color: const Color(0xFFFFF8F3),
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    children: [
                      row('Nakshatra', '${VedicCalculationService.nakshatraNamesTe[n.index]} • ${n.pada} పాదం'),
                      row('Star Lord', detail.kp.starLord),
                      row('Sub Lord', detail.kp.subLord),
                      row(
                        'Amsa Devata (D60)',
                        '${detail.amsaDevata.teluguName} (${detail.amsaDevata.name})',
                      ),
                      row('D60 Amsa', '${detail.amsaDevata.effectivePart} / 60'),
                      row('Amsa Nature', detail.amsaDevata.nature),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'వర్గ బలం',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              Card(
                color: Colors.white,
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    children: [
                      row('Saptavargaja', '${v.saptavargaja}'),
                      row('Shadvargaja', '${v.shadvargaja}'),
                      row('Dashavargaja', '${v.dashavargaja}'),
                      row('Shodashavargaja', '${v.shodashavargaja}'),
                      row(
                        'Vimshopaka Bala',
                        v.shodashaVimsopaka.toStringAsFixed(2),
                        valueWeight: FontWeight.w900,
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                color: const Color(0xFFEAF6EE),
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.record_voice_over_outlined, color: Color(0xFF1B7F3A)),
                          SizedBox(width: 8),
                          Text('క్లయింట్‌కు చెప్పండి', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(consult.sayThis),
                      const SizedBox(height: 8),
                      Text(consult.technicalNote, style: const TextStyle(fontSize: 12, color: Color(0xFF5F5052))),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: () async {
                            await Clipboard.setData(ClipboardData(text: consult.sayThis));
                            if (!sheetContext.mounted) return;
                            ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Client line copy అయింది')));
                          },
                          icon: const Icon(Icons.copy_all_outlined),
                          label: const Text('Copy'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                color: const Color(0xFFFFFBF8),
                surfaceTintColor: Colors.transparent,
                child: ExpansionTile(
                  title: const Text(
                    'Vargaja / Vimshopaka పూర్తి వివరాలు',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                  children: [
                    row('Shadvarga support', factors(v.shadSupport)),
                    row('Shadvarga Bala', v.shadVimsopaka.toStringAsFixed(2)),
                    row('Saptavarga support', factors(v.saptaSupport)),
                    row('Saptavarga Bala', v.saptaVimsopaka.toStringAsFixed(2)),
                    row('Dashavarga support', factors(v.dashaSupport)),
                    row('Dashavarga Bala', v.dashaVimsopaka.toStringAsFixed(2)),
                    row('Shodashavarga support', factors(v.shodashaSupport)),
                    row('Shodashavarga Bala', v.shodashaVimsopaka.toStringAsFixed(2)),
                    const SizedBox(height: 8),
                    const Text(
                      'Vargaja count = own / exalted / moolatrikona support ఉన్న vargas. Vimshopaka Bala 20-point weighted varga strength. Amsa Devata D60 source ruleలో odd signs forward, even signs reverse order ఉపయోగిస్తుంది.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF6B5B5E)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

PlanetPosition? _planetFromOccupantLabel(
  AstroChartResult chart,
  String label,
) {
  for (final planet in chart.planets) {
    if (label == planet.shortName || label.startsWith('${planet.shortName} ')) {
      return planet;
    }
  }
  return null;
}

class _VargaTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;
  final int selectedVarga;
  final ValueChanged<int> onChanged;

  const _VargaTab({
    required this.birthData,
    required this.result,
    required this.selectedVarga,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final data = VargaService.calculate(result, selectedVarga);
    final definition = data.definition;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('షోడశ వర్గ చక్రములు'),
        const SizedBox(height: 8),
        const Text(
          'D1 నుంచి D60 వరకు 16 classical Parashari vargas. ప్రతి వర్గం అదే sidereal planetary longitude ను తన ప్రత్యేక నియమంతో కొత్త రాశిలో map చేస్తుంది.',
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: VargaService.definitions.map((v) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(v.code),
                  selected: selectedVarga == v.factor,
                  onSelected: (_) => onChanged(v.factor),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 12),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${definition.code} ${definition.teluguName} (${definition.name})',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text('ప్రధాన ఉపయోగం: ${definition.domain}'),
                Text('Division: 30° / ${definition.factor}'),
                if (definition.factor >= 40) ...[
                  const SizedBox(height: 8),
                  const Text(
                    'గమనిక: D40 / D45 / D60 లగ్నం జనన సమయానికి చాలా సున్నితంగా మారుతుంది.',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (selectedVarga == 1) ...[
          const _V50SourceRulebooksPanel(),
          const SizedBox(height: 12),
        ],
        _SouthIndianChart(
          title: '${definition.code} ${definition.teluguName}',
          ascendantSignIndex: data.ascendantSignIndex,
          occupants: _occupantsFromVarga(data, includeDegreesFrom: result),
          onOccupantTap: (label) {
            final planet = _planetFromOccupantLabel(result, label);
            if (planet != null) _showPlanetDetailSheet(context, result, planet);
          },
        ),
        const SizedBox(height: 14),
        const Text(
          'గ్రహాల డిగ్రీలు పై వర్గ చక్రంలోని రాశి గడులలోనే ఉన్నాయి. గ్రహం పేరును టచ్ చేస్తే పూర్తి గ్రహ వివరాలు తెరుచుకుంటాయి.',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B5B5E)),
        ),
        const SizedBox(height: 14),
        _PanchadhaMaitriVargaPanel(chart: result, factor: selectedVarga),
        const SizedBox(height: 14),
        _VargaRulePanel(chart: result, factor: selectedVarga, birthDateTime: birthData.localDateTime, birthData: birthData),
        const SizedBox(height: 42),
      ],
    );
  }
}


class _PanchadhaMaitriVargaPanel extends StatelessWidget {
  final AstroChartResult chart;
  final int factor;

  const _PanchadhaMaitriVargaPanel({
    required this.chart,
    required this.factor,
  });

  static const _planetTe = <String, String>{
    'Sun': 'సూర్యుడు',
    'Moon': 'చంద్రుడు',
    'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు',
    'Jupiter': 'గురువు',
    'Venus': 'శుక్రుడు',
    'Saturn': 'శని',
  };

  @override
  Widget build(BuildContext context) {
    final rows = PanchadhaMaitriService.evaluateVarga(chart: chart, factor: factor);
    final definition = VargaService.definitionFor(factor);

    return Card(
      color: const Color(0xFFF3F7FF),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        initiallyExpanded: factor == 1,
        leading: const Icon(Icons.handshake_outlined, color: Color(0xFF355C9A)),
        title: Text(
          '${definition.code} — పంచధా మైత్రి / Mandatory Strength',
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: const Text(
          'D1లో ఏర్పడిన Panchadha Maitri సంబంధాన్ని ఈ వర్గంలో గ్రహం ఉన్న రాశి అధిపతితో పోల్చి బలం చూపిస్తుంది.',
          style: TextStyle(fontSize: 11.5, height: 1.35),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 14),
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFD7E1F1)),
            ),
            child: const Text(
              'అధిమిత్రుడు 22.5 • మిత్రుడు 15 • సముడు 7.5 • శత్రువు 3.75 • అధిశత్రువు 1.875 • స్వరాశి 30. ఈ layer ప్రతి వర్గ ఫలితానికి తప్పనిసరి strength modifier; ఒక్కదానితో final prediction చేయదు.',
              style: TextStyle(fontSize: 11.5, height: 1.4, color: Color(0xFF4C5E79)),
            ),
          ),
          const SizedBox(height: 8),
          ...rows.map((r) => Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE2E8F2)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${_planetTe[r.planet] ?? r.planet} — ${PanchadhaMaitriService.signNamesTe[r.signIndex]}',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            'రాశి అధిపతి: ${_planetTe[r.signLord] ?? r.signLord} • ${PanchadhaMaitriService.relationTelugu(r.relationToSignLord)}',
                            style: const TextStyle(fontSize: 12.2, height: 1.35),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      r.strength.toStringAsFixed(r.strength.truncateToDouble() == r.strength ? 0 : (r.strength * 10).truncateToDouble() == r.strength * 10 ? 1 : 3),
                      style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF355C9A)),
                    ),
                  ],
                ),
              )),
          const SizedBox(height: 2),
          const Text(
            'Directional rule: A→B మరియు B→A సంబంధం తప్పనిసరిగా ఒకటే కావాల్సిన అవసరం లేదు. Dasha/Bhukti లేదా రెండు గ్రహాల joint-resultలో రెండు దిశలూ విడిగా చూడాలి.',
            style: TextStyle(fontSize: 11.2, height: 1.4, color: Color(0xFF6B5B5E)),
          ),
        ],
      ),
    );
  }
}


class _V50SourceRulebooksPanel extends StatelessWidget {
  const _V50SourceRulebooksPanel();

  @override
  Widget build(BuildContext context) {
    const books = [
      (
        'S.K. Mehta — జ్యోతిష నియమావళి',
        '36 pages • భావ/గ్రహ బలం • ఆరోగ్యం • వివాహం • సంతానం • వృత్తి • ధనం • timing/synchronization',
        'D1 primary • D3/D4/D7/D9/D10 topic cross-link',
      ),
      (
        'Brighu Naadi — Purnna Rulebook',
        '21 pages • R-A / C / E / F / G / H / I / J / K indexed Nadi rules',
        'D1 / Nadi method primary',
      ),
      (
        'అవయవాల వారి రోగ నియమాలు',
        '24 pages • body-part/organ localization • disease indicators • Roga-sthana analysis order',
        'D1 Health / Roga source registry',
      ),
      (
        'Medical Roga Rules Complete',
        '19 pages • Medical Astrology chapters • Rule → result structure • disease/organ topics',
        'D1 Health / Medical Astrology source registry',
      ),
    ];

    return Card(
      color: const Color(0xFFF7F0E8),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.library_books_outlined, color: Color(0xFF7B1E2B)),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'V50 — Source Rulebooks Registry',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              'ఏ source rule ఏ అంశానికి సంబంధించినదో అదే సంబంధిత varga కింద Source Rules libraryలో చూపిస్తాం. Exact condition పూర్తిగా validate కానప్పుడు app ఊహించి ఫలితం సృష్టించదు.',
              style: TextStyle(fontSize: 12.5, height: 1.4, color: Color(0xFF5F5052)),
            ),
            const SizedBox(height: 10),
            ...books.map(
              (b) => Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(11),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE5D8D0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(b.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(b.$2, style: const TextStyle(fontSize: 12.5, height: 1.35)),
                    const SizedBox(height: 5),
                    Text(
                      b.$3,
                      style: const TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF7B1E2B),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 2),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF6EE),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFB9DFC5)),
              ),
              child: const Text(
                'Health safety: ఆరోగ్య జ్యోతిష్య rulesను సంప్రదాయ సూచికలుగా మాత్రమే చూపిస్తాం. ఇవి వైద్య నిర్ధారణ లేదా చికిత్స కాదు; app medicines/treatment prescribe చేయదు.',
                style: TextStyle(fontSize: 12, height: 1.4),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


class _VargaPlanetList extends StatelessWidget {
  final VargaChartData data;
  final AstroChartResult natalChart;

  const _VargaPlanetList({required this.data, required this.natalChart});

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text(
                'వర్గ గ్రహ స్థానాలు',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: const Text(
                'లగ్నం చక్రంలో Lg గుర్తుతో చూపించబడింది.',
              ),
            ),
            const Divider(),
            ...data.planets.map((p) {
              final natal = natalChart.planets.firstWhere((x) => x.name == p.name);
              return ListTile(
                onTap: () => _showPlanetDetailSheet(context, natalChart, natal),
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(p.name),
                subtitle: Text('డిగ్రీ: ${AstroFormat.degreeDms(natal.degreesInSign)}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (p.retrograde) const Chip(label: Text('R')),
                    const Icon(Icons.chevron_right),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}


class _VargaRulePanel extends StatelessWidget {
  final AstroChartResult chart;
  final int factor;
  final DateTime birthDateTime;
  final BirthData birthData;

  const _VargaRulePanel({
    required this.chart,
    required this.factor,
    required this.birthDateTime,
    required this.birthData,
  });

  Color _toneColor(VargaRuleTone tone) => switch (tone) {
        VargaRuleTone.favorable => const Color(0xFF1B7F3A),
        VargaRuleTone.caution => const Color(0xFFB3261E),
        VargaRuleTone.neutral => const Color(0xFF8A5A00),
        VargaRuleTone.info => const Color(0xFF536471),
      };

  IconData _toneIcon(VargaRuleTone tone) => switch (tone) {
        VargaRuleTone.favorable => Icons.check_circle_outline,
        VargaRuleTone.caution => Icons.cancel_outlined,
        VargaRuleTone.neutral => Icons.info_outline,
        VargaRuleTone.info => Icons.menu_book_outlined,
      };

  String _toneText(VargaRuleTone tone) => switch (tone) {
        VargaRuleTone.favorable => 'అనుకూలం',
        VargaRuleTone.caution => 'జాగ్రత్త',
        VargaRuleTone.neutral => 'మిశ్రమ / పరిశీలన',
        VargaRuleTone.info => 'సమాచారం / Source',
      };

  void _showD24Result(BuildContext rootContext, VargaRuleHit item) {
    showModalBottomSheet<void>(
      context: rootContext,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.of(sheetContext).viewPadding.bottom + 40,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 30),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.topic, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                        Text(_toneText(item.tone), style: TextStyle(color: _toneColor(item.tone), fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              const Text('Rule ID', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, color: Color(0xFF8B1E2D))),
              const SizedBox(height: 5),
              SelectableText(item.ruleId, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 16),
              const Text('Result / ఫలితం', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              Text(item.result, style: const TextStyle(fontSize: 16, height: 1.5)),
              const SizedBox(height: 16),
              const Text('Source / మూలం', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              Text(item.source, style: const TextStyle(fontSize: 15, color: Color(0xFF5F5052), height: 1.45)),
              const SizedBox(height: 18),
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.of(sheetContext).pop();
                  Future<void>.delayed(Duration.zero, () => _showRule(rootContext, item));
                },
                icon: const Icon(Icons.rule_outlined),
                label: const Text('Rule / పరిశీలన వివరాలు'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showResult(BuildContext rootContext, VargaRuleHit item) {
    showModalBottomSheet<void>(
      context: rootContext,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.of(sheetContext).viewPadding.bottom + 40,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 30),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.topic, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                        Text(_toneText(item.tone), style: TextStyle(color: _toneColor(item.tone), fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 18),
              const Text('జాతకమునకు అప్లయ్ అయిన ఫలితం', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text(item.result, style: const TextStyle(fontSize: 16, height: 1.5)),
              const SizedBox(height: 14),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  FilledButton.icon(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      Future<void>.delayed(Duration.zero, () => _showRule(rootContext, item));
                    },
                    icon: const Icon(Icons.rule_outlined),
                    label: const Text('Rule / Source'),
                  ),
                  OutlinedButton.icon(
                    onPressed: () {
                      Navigator.of(sheetContext).pop();
                      Future<void>.delayed(Duration.zero, () => _showRemedy(rootContext, item));
                    },
                    icon: const Icon(Icons.health_and_safety_outlined),
                    label: const Text('పరిహారం / Guidance'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showRule(BuildContext rootContext, VargaRuleHit item) {
    showModalBottomSheet<void>(
      context: rootContext,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.of(sheetContext).viewPadding.bottom + 40,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('రూల్ • ${item.ruleId}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              Card(
                color: const Color(0xFFF6F0EC),
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text(item.rule, style: const TextStyle(fontSize: 15.5, height: 1.45)),
                ),
              ),
              const SizedBox(height: 14),
              const Text('ఈ జాతకంలో పరిశీలన', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 6),
              Text(item.inspection),
              const SizedBox(height: 14),
              const Text('మూలం', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 6),
              Text(item.source, style: const TextStyle(color: Color(0xFF5F5052))),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () {
                  Navigator.of(sheetContext).pop();
                  Future<void>.delayed(Duration.zero, () => _showRemedy(rootContext, item));
                },
                icon: const Icon(Icons.health_and_safety_outlined),
                label: const Text('ఈ రూల్‌కు పరిహారం చూడండి'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showRemedy(BuildContext rootContext, VargaRuleHit item) {
    showModalBottomSheet<void>(
      context: rootContext,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.of(sheetContext).viewPadding.bottom + 48,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('పరిహారం / Remedy', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: item.tone == VargaRuleTone.caution
                      ? const Color(0xFFFFF1EF)
                      : const Color(0xFFEAF6EE),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE2D2D5)),
                ),
                child: Text(item.remedy, style: const TextStyle(fontSize: 16, height: 1.5)),
              ),
              const SizedBox(height: 14),
              const Text(
                'రత్న పరిహారం safety',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              const Text(
                'Gemstoneను ఈ varga result ఒక్కదాని ఆధారంగా ఇవ్వకూడదు. Lagna/Lordship, Grahashakti, Bhavabala, Maraka/Badhaka/Dushthana restrictions మరియు Rahu–Ketu safeguardsను supplied Gemstone Remedy rule-engineతో వేరుగా పరీక్షించాలి.',
                style: TextStyle(fontSize: 13, color: Color(0xFF5F5052), height: 1.45),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _validationLine(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 112,
            child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(value, style: const TextStyle(height: 1.35))),
        ],
      ),
    );
  }

  Widget _d24SummaryGroupHeader(String title, String subtitle, IconData icon) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 12, bottom: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFEEE8),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE7C9C2)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: const Color(0xFF8B1E2D)),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 3),
                Text(subtitle, style: const TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.35)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _d24SummaryLine(String label, String value, {IconData? icon}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 18, color: const Color(0xFF8B1E2D)),
            const SizedBox(width: 8),
          ],
          SizedBox(
            width: 132,
            child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(value, style: const TextStyle(height: 1.4))),
        ],
      ),
    );
  }

  Widget _d9MarriageSummaryCard() {
    final report = D9MarriageService.evaluate(
      chart: chart,
      birthDateTime: birthDateTime,
    );

    Widget metric(
      String title,
      String value, {
      String? detail,
      IconData icon = Icons.check_circle_outline,
      Color? color,
    }) {
      final c = color ?? const Color(0xFF7C2536);
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 9),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE7DADB)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: c, size: 22),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 3),
                  Text(value, style: const TextStyle(height: 1.35)),
                  if (detail != null && detail.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      detail,
                      style: const TextStyle(
                        fontSize: 11.5,
                        color: Color(0xFF6B5B5E),
                        height: 1.35,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      );
    }

    final timingRows = report.timingWindows.map((w) {
      final start = '${w.start.day.toString().padLeft(2, '0')}-${w.start.month.toString().padLeft(2, '0')}-${w.start.year}';
      final end = '${w.end.day.toString().padLeft(2, '0')}-${w.end.month.toString().padLeft(2, '0')}-${w.end.year}';
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          color: const Color(0xFFF7FAF5),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFD9E8D7)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${w.year} — ${w.evidencePercent}% Evidence Match',
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 3),
            Text('${w.mahadasha} MD / ${w.antardasha} AD • $start → $end'),
            const SizedBox(height: 3),
            Text(
              w.matchedEvidence.join(' • '),
              style: const TextStyle(fontSize: 11.5, color: Color(0xFF5F5052), height: 1.35),
            ),
          ],
        ),
      );
    }).toList(growable: false);

    final d7Detail = report.d7KetuMatches.isEmpty
        ? 'D7 Ketu Sutra 35 condition auto-match కాలేదు.'
        : report.d7KetuMatches.join(' • ');
    final affairDetail = report.affairEvidence.isEmpty
        ? 'Source-defined affair combinations auto-match కాలేదు.'
        : report.affairEvidence.join(' • ');

    return Card(
      color: const Color(0xFFFFF8F2),
      surfaceTintColor: Colors.transparent,
      margin: const EdgeInsets.only(top: 10, bottom: 12),
      child: ExpansionTile(
        initiallyExpanded: true,
        leading: const Icon(Icons.favorite_outline, color: Color(0xFF8B1E2D)),
        title: const Text(
          'D9 — Final Marriage Report / వివాహ పూర్తి ఫలితం',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: const Text('Marriage → Timing → Before/After → Affairs → D7 Ketu Divorce confirmation'),
        childrenPadding: const EdgeInsets.fromLTRB(14, 2, 14, 16),
        children: [
          metric(
            '1. Marriage Promise / వివాహ యోగం',
            '${report.marriagePromise} • ${report.marriagePromisePercent}% Evidence Match',
            detail: 'D9 Lagna + Lagna Lord + 7H + 7L independent evidence blocks.',
            icon: Icons.favorite,
          ),
          metric(
            '2. 7వ భావం / Spouse & Stability',
            report.seventhHouseResult,
            detail: 'Rule layer: D9 7H / 7L. Exact spouse judgementను ఇతర matched layersతో కలిపి మాత్రమే చూడాలి.',
            icon: Icons.people_alt_outlined,
          ),
          metric(
            '3. Before Marriage Obstacles',
            '${report.obstaclePercent}% Evidence Match',
            detail: report.delayResult,
            icon: Icons.warning_amber_outlined,
            color: const Color(0xFF9B6500),
          ),
          metric(
            '4. Before Marriage Relationship',
            '${report.beforeMarriageRelationshipPercent}% Evidence Match',
            detail: '5L↔7L, Mars↔Venus, 5H/5L Vipreet-lord influence వంటి relationship evidence. Actual before/after date classificationకు event timing boundary అవసరం.',
            icon: Icons.timeline_outlined,
          ),
          const Divider(height: 24),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              '5. Timing of Marriage / వివాహ సమయ సూచనలు',
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 4),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'ఇక్కడ % అనేది probability కాదు; ప్రస్తుతం machine-calculable D9 + Vimshottari evidence coverage. V.P. Goel Saturn transit మరియు handwritten year/transit rules exact arithmeticతో connect అయినప్పుడు అదనపు evidence blocksగా కలపాలి.',
              style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.4),
            ),
          ),
          const SizedBox(height: 8),
          if (timingRows.isEmpty)
            metric(
              'Marriage Timing',
              '40% పైగా evidence ఉన్న Vimshottari window auto-match కాలేదు.',
              icon: Icons.event_busy_outlined,
            )
          else
            ...timingRows,
          const Divider(height: 24),
          metric(
            '6. After Marriage / వివాహానంతర జీవితం',
            '${report.afterMarriagePercent}% stress evidence • ${report.afterMarriageResult}',
            detail: 'D9 2H = first experience after marriage; D9 2L = later events.',
            icon: Icons.home_outlined,
          ),
          metric(
            '7. Affair After Marriage',
            '${report.affairAfterMarriagePercent}% Evidence Match',
            detail: affairDetail,
            icon: Icons.link_outlined,
            color: const Color(0xFF9B6500),
          ),
          metric(
            '8. Multiple Affairs / Repeated Relationship Pattern',
            '${report.multipleAffairPercent}% Evidence Match',
            detail: 'ఒకే indicationతో result ఇవ్వము. Multiple independent combinations repeat అయినప్పుడు మాత్రమే repeated-pattern evidence పెరుగుతుంది.',
            icon: Icons.repeat_outlined,
            color: const Color(0xFF9B6500),
          ),
          metric(
            '9. D7 Ketu Divorce Confirmation — Sutra 35',
            report.d7KetuDivorceConfirmation ? 'Matched ✅' : 'Not matched',
            detail: d7Detail,
            icon: Icons.rule_outlined,
            color: report.d7KetuDivorceConfirmation
                ? const Color(0xFFB3261E)
                : const Color(0xFF536471),
          ),
          metric(
            '10. Separation / Divorce Evidence',
            '${report.divorceEvidencePercent}% Evidence Match • ${report.divorceStatus}',
            detail: report.divorceEvidence.isEmpty
                ? 'Strong breakdown evidence auto-match కాలేదు.'
                : report.divorceEvidence.join(' • '),
            icon: Icons.call_split_outlined,
            color: const Color(0xFFB3261E),
          ),
          const Divider(height: 24),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Rule / Source Audit',
              style: TextStyle(fontWeight: FontWeight.w900),
            ),
          ),
          const SizedBox(height: 6),
          ...report.sourceNotes.map(
            (x) => Padding(
              padding: const EdgeInsets.only(bottom: 5),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('• '),
                  Expanded(child: Text(x, style: const TextStyle(fontSize: 11.5, height: 1.35))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            'Sensitive relationship/divorce results are evidence classifications only. D7 Ketu confirmation alone does not create a deterministic divorce verdict.',
            style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.4),
          ),
        ],
      ),
    );
  }

  Widget _d24SummaryCard(List<VargaRuleHit> applied) {
    VargaRuleHit? hit(String id) {
      for (final item in applied) {
        if (item.ruleId == id) return item;
      }
      return null;
    }

    final scoreItems = applied.where((x) => x.ruleId != 'EDU-D24-SIGN-NATURE').toList(growable: false);
    final favorable = scoreItems.where((x) => x.tone == VargaRuleTone.favorable).length;
    final caution = scoreItems.where((x) => x.tone == VargaRuleTone.caution).length;
    final mixed = scoreItems.where((x) => x.tone == VargaRuleTone.neutral).length;
    final overall = scoreItems.isEmpty
        ? 'ప్రస్తుతం source-safe matched education rule తక్కువగా ఉంది.'
        : favorable > caution + mixed
            ? 'అనుకూలం — positive education support ఎక్కువగా ఉంది.'
            : caution > favorable + mixed
                ? 'జాగ్రత్త — obstacles/break indicators ఎక్కువగా ఉన్నాయి.'
                : 'మిశ్రమం — అనుకూలతతో పాటు కొన్ని caution layers ఉన్నాయి.';

    final natureHit = hit('EDU-D24-SIGN-NATURE');
    String? nature;
    if (natureHit != null) {
      final arrow = natureHit.result.indexOf('→');
      nature = arrow >= 0 ? natureHit.result.substring(arrow + 1).trim() : natureHit.result;
    }

    final rows = <Widget>[
      _d24SummaryLine('Overall Result', overall, icon: Icons.assessment_outlined),
    ];

    void addMatched(String label, String id, {IconData? icon}) {
      final item = hit(id);
      if (item == null) return;
      rows.add(_d24SummaryLine(label, item.result, icon: icon));
    }

    addMatched('Education Desire', 'EDU-D24-LAGNA');
    addMatched('Dedication', 'EDU-D24-SUN');
    addMatched('Learning Capacity', 'EDU-D24-MOON');

    rows.add(_d24SummaryGroupHeader(
      'A. Education Continuity / విద్య సాగే స్థాయి',
      'ఇది విద్య ఎంతవరకు/ఎలా కొనసాగుతుందో మాత్రమే చెబుతుంది. ఏ subject/course చదవాలో ఈ భాగం నిర్ణయించదు.',
      Icons.timeline_outlined,
    ));
    addMatched('School / Intermediate వరకు', 'EDU-D24-LEVEL-INTER');
    addMatched('Degree / B.Tech వరకు', 'EDU-D24-LEVEL-DEGREE');
    addMatched('PG వరకు', 'EDU-D24-LEVEL-PG');
    addMatched('Post-PG వరకు', 'EDU-D24-LEVEL-POSTPG');

    rows.add(_d24SummaryGroupHeader(
      'B. Education Field / చదవవలసిన విద్య',
      'ఇది 5వ భావం starting point +15° → Nakshatra → Nakshatra Lord → Lord sign → sign/planet/aspect education evidence ద్వారా ఏమి చదవాలి/ఏం చదువుతారు అని shortlist ఇస్తుంది.',
      Icons.menu_book_outlined,
    ));
    addMatched('5H +15° Selection', 'EDU-D24-SELECTION-POINT');
    if (nature != null) {
      rows.add(_d24SummaryLine('Education Nature', nature));
    }
    addMatched('అనుకూల విద్యలు %', 'EDU-D24-COURSE-SUITABILITY');
    addMatched('Sign Lord Careers', 'EDU-D24-LORD-PROF-GUIDANCE');

    rows.add(_d24SummaryGroupHeader(
      'C. Research / Deeper Study',
      'Hostel / ఇంటికి దూరంగా చదువు / Foreign / Break / Resume సూచనలు ఇప్పుడు విడిగా కాకుండా 4H, 9H, 2H, 7H education stageలోనే కనిపిస్తాయి. Research/Deeper Study మాత్రమే separate supporting layerగా ఉంటుంది.',
      Icons.science_outlined,
    ));
    addMatched('Research / PhD', 'EDU-D24-H8');

    return Card(
      color: const Color(0xFFFFF7F2),
      surfaceTintColor: Colors.transparent,
      margin: const EdgeInsets.only(top: 10, bottom: 12),
      child: ExpansionTile(
        initiallyExpanded: true,
        leading: const Icon(Icons.school_outlined, color: Color(0xFF8B1E2D)),
        title: const Text(
          'Final Education Summary / పూర్తి విద్యా సారాంశం',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text('Matched auto-rules: ${applied.length} • Favorable $favorable • Mixed $mixed • Caution $caution'),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
        children: [
          ...rows,
          const Divider(height: 22),
          const Text(
            'Education Continuityలో ప్రతి stageకే Hostel/Away, Foreign, Break/Resumeను జతచేస్తాం: 4H→School/Intermediate, 9H→Degree/B.Tech, 2H→PG, 7H→Post-PG. అందువల్ల clientకి ఏ stageలో ఇంటికి దూరంగా/hostel/foreign/break ఉందో అదే rowలో తెలుస్తుంది. Education Field మాత్రం 5H start +15° → Nakshatra lord → lord sign → sign/planet/aspect evidence ద్వారా ఏమి చదవాలి/ఏం చదువుతారు అనే shortlistను suitability %తో ఇస్తుంది.',
            style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.45),
          ),
          const SizedBox(height: 8),
          const Text(
            'Education Timing: D24 ఒక్కటితో date/year ఇవ్వము. Dasha/Antardasha/Transit timing engineతో source-supported timing rule match అయినప్పుడు మాత్రమే timing చూపాలి.',
            style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.45),
          ),
          const SizedBox(height: 8),
          const Text(
            'గమనిక: Education.pdfలో case-example మాత్రమే ఉన్న subject patternsను exact universal predictionగా మార్చలేదు. క్రింద కనిపించే matched rule cardలో “ఫలితం” టచ్ చేస్తే Rule ID → Result → Source కనిపిస్తుంది.',
            style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.45),
          ),
        ],
      ),
    );
  }

  Widget _d27HealthSummaryCard(BuildContext context) {
    final health = D27HealthService.evaluate(
      chart: chart,
      birthDateTime: birthDateTime,
    );
    final gender = birthData.gender.label;

    Widget line(String label, String value, {IconData? icon}) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (icon != null) ...[
              Icon(icon, size: 18, color: const Color(0xFF8B1E2D)),
              const SizedBox(width: 8),
            ],
            SizedBox(
              width: 118,
              child: Text(
                label,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(child: Text(value, style: const TextStyle(height: 1.35))),
          ],
        ),
      );
    }

    if (!health.hasAutoTrigger) {
      return Card(
        color: const Color(0xFFF7F7F7),
        surfaceTintColor: Colors.transparent,
        margin: const EdgeInsets.only(top: 10, bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'D27 — రోగ / Health Final Summary',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
              ),
              const SizedBox(height: 10),
              line('లింగం', gender, icon: birthData.gender == BirthGender.female ? Icons.female : Icons.male),
              line('Evidence Match', '0% — D1+D3 source-safe auto-trigger లేదు.'),
              const SizedBox(height: 8),
              const Text(
                'ఇది వైద్య నిర్ధారణ కాదు. లక్షణాలు ఉంటే qualified doctor/health professionalను సంప్రదించాలి.',
                style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.4),
              ),
            ],
          ),
        ),
      );
    }

    final region = health.bodyRegion!;
    final timing = health.timingWindows;

    return Card(
      color: const Color(0xFFFFF8F3),
      surfaceTintColor: Colors.transparent,
      margin: const EdgeInsets.only(top: 10, bottom: 12),
      child: ExpansionTile(
        initiallyExpanded: true,
        leading: const Icon(Icons.health_and_safety_outlined, color: Color(0xFF8B1E2D)),
        title: const Text(
          'D27 — రోగ / Health Final Summary',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Text('Traditional astrology Evidence Match ${health.evidencePercent}% • probability కాదు'),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => showDialog<void>(
              context: context,
              builder: (dialogContext) => Dialog(
                insetPadding: const EdgeInsets.all(10),
                child: InteractiveViewer(
                  minScale: 0.8,
                  maxScale: 4.0,
                  child: Image.asset(
                    'assets/health/d27_locate_disease_visual_guide.png',
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.asset(
                'assets/health/d27_locate_disease_visual_guide.png',
                width: double.infinity,
                fit: BoxFit.fitWidth,
              ),
            ),
          ),
          const SizedBox(height: 6),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Full Body Locate Disease visual guide — చిత్రం టచ్ చేస్తే zoom చేసి చూడవచ్చు. Rule result మాత్రం source-backed D27/D3 calculation నుంచే వస్తుంది.',
              style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.4),
            ),
          ),
          const SizedBox(height: 10),
          line('లింగం', gender, icon: birthData.gender == BirthGender.female ? Icons.female : Icons.male),
          const SizedBox(height: 4),
          LinearProgressIndicator(
            value: health.evidencePercent / 100,
            minHeight: 8,
            borderRadius: BorderRadius.circular(8),
          ),
          const SizedBox(height: 10),
          line('రోగ Evidence', '${health.evidencePercent}% — ${health.evidence.join(' • ')}'),
          const SizedBox(height: 10),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('D1 + D3 — అవయవాలు / రోగ సూచనలు', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          ),
          const SizedBox(height: 6),
          ...health.organEvidence.map((o) {
                final kharaText = o.has22DLink || o.has64NLink
                    ? '${o.has22DLink ? '22D ✓' : '22D —'} • ${o.has64NLink ? '64N ✓' : '64N —'}'
                    : 'No direct link to current affected organ';
                return Card(
                  margin: const EdgeInsets.symmetric(vertical: 4),
                  color: Colors.white,
                  surfaceTintColor: Colors.transparent,
                  child: ListTile(
                    dense: false,
                    title: Text(
                      o.bodyRegion,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      'Supporting planets: ${o.supportingPlanets.join(', ')}\n'
                      'Signs: ${o.supportingSigns.join(', ')} • ${o.locationType}\n'
                      'D1+D3 Organ Match ${o.d1d3EvidencePercent}%\n'
                      'D27 Severity Confirmation ${o.d27StrengthPercent}%\n'
                      'Khara / 22D / 64N ${o.kharaEvidencePercent}% — $kharaText\n'
                      'Final Astrology Evidence ${o.finalEvidencePercent}%\n'
                      '${o.evidence.join(' • ')}',
                    ),
                  ),
                );
              }),
          const Divider(height: 24),
          line('22వ ద్రెక్కాణ', '${health.kharaLayer.drekkana22Lord} • organ cardలో direct link ఉన్నప్పుడే scoreలో చేరుతుంది'),
          line('64వ నవాంశ', '${health.kharaLayer.navamsa64Lord} • organ cardలో direct link ఉన్నప్పుడే scoreలో చేరుతుంది'),
          line('Khara Risk', '${health.kharaLayer.evidencePercent}% — ఇది global Khara context మాత్రమే; final organ scoreలో direct organ-link మాత్రమే లెక్క.'),
          line('ప్రధాన గ్రహం', '${health.primaryPlanet} • D27 H${health.d27House} • ${health.d27SignName} • ${health.d27Nakshatra}'),
          line('స్థానం', health.locationType),
          line('స్వభావం', health.natureSummary),
          const Divider(height: 24),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.asset(
                  'assets/health/${region.assetName}',
                  width: 125,
                  height: 250,
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('అవయవ / Body Region', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 8),
                    Text(region.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text('బాహ్య భాగం: ${region.externalPart}'),
                    const SizedBox(height: 4),
                    Text('అంతరంగ భాగం: ${region.internalPart}'),
                    const SizedBox(height: 4),
                    Text('నిర్గమ/సంధి భాగం: ${region.outletPart}'),
                    const SizedBox(height: 8),
                    const Text(
                      'చిత్రం body-region illustration మాత్రమే; medical diagnosis కాదు.',
                      style: TextStyle(fontSize: 11, color: Color(0xFF6B5B5E)),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const Divider(height: 24),
          line(
            'పంచధా మైత్రి',
            '${health.panchadhaRelation} • ${health.panchadhaStrength.toStringAsFixed(3)} / 30 = ${health.panchadhaStrengthPercent}% strength',
          ),
          line('Bhamsa Devata', '${health.amshaDevata}'),
          line('Devata ప్రభావం', health.devataContext),
          Padding(
            padding: const EdgeInsets.only(top: 2, bottom: 8),
            child: Text(
              health.devataNote,
              style: const TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.4),
            ),
          ),
          const Divider(height: 24),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('ఎప్పుడు / Age & Timing — Evidence %', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          ),
          const SizedBox(height: 8),
          if (timing.isEmpty)
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('Source-safe Dasha timing window auto-match కాలేదు.'),
            )
          else
            ...timing.map((w) => Card(
                  margin: const EdgeInsets.symmetric(vertical: 5),
                  color: Colors.white,
                  surfaceTintColor: Colors.transparent,
                  child: ListTile(
                    dense: true,
                    leading: CircleAvatar(child: Text('${w.evidencePercent}%')),
                    title: Text('Age ${w.startAge}–${w.endAge} • ${w.mahadasha} MD – ${w.antardasha} AD'),
                    subtitle: Text(
                      '${_dateOnly(w.start)} → ${_dateOnly(w.end)}\n${w.matchedEvidence.join(' + ')}',
                    ),
                  ),
                )),
          const Divider(height: 24),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('పరిహారం / Remedy', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
          ),
          const SizedBox(height: 6),
          line('Primary Planet Remedy', health.remedy.planetRemedy),
          if (health.remedy.dashaPair != '—') line('MD–AD Remedy', '${health.remedy.dashaPair} • ${health.remedy.dashaRemedies.isEmpty ? 'specific pair mapping sourceలో auto-match కాలేదు' : health.remedy.dashaRemedies.join(' • ')}'),
          const SizedBox(height: 8),
          const Text(
            'వైద్య చికిత్స తప్పనిసరి. పూజ / మంత్ర / దానం / దేవతారాధన వంటి జ్యోతిష్య పరిహారాలు సహాయకంగా మాత్రమే ఉపయోగించాలి.',
            style: TextStyle(fontWeight: FontWeight.w800, height: 1.45),
          ),
          const SizedBox(height: 6),
          const Text(
            'గమనిక: % = matched astrology evidence coverage మాత్రమే; వ్యాధి probability లేదా medical risk percentage కాదు. లక్షణాలు ఉంటే qualified doctorను సంప్రదించాలి.',
            style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E), height: 1.45),
          ),
        ],
      ),
    );
  }

  String _dateOnly(DateTime dt) =>
      '${dt.day.toString().padLeft(2, '0')}-${dt.month.toString().padLeft(2, '0')}-${dt.year}';

  @override
  Widget build(BuildContext context) {
    final all = VargaRuleService.allFor(chart: chart, factor: factor, birthDateTime: birthDateTime);
    final applied = all.where((x) => x.autoEvaluated && x.applicable).toList(growable: false);
    final validationReport = factor == 10 && D10ValidationService.isExample1(birthData)
        ? D10ValidationService.validate(chart: chart, birthData: birthData)
        : null;
    final validationMode = factor == 10
        ? all.where((x) => x.ruleId == 'D10-PROF-MODE-SOURCE').toList(growable: false)
        : const <VargaRuleHit>[];
    final validationProfession = factor == 10
        ? all.where((x) => x.ruleId == 'D10-EXACT-PROF-SUMMARY').toList(growable: false)
        : const <VargaRuleHit>[];
    // Build73: keep the client-facing D10 screen matched-only.
    // Preserve source-only / unmatched rules in a collapsed audit drawer instead
    // of showing red/no-match cards as if they were client conclusions.
    final d10PinnedFinal = factor == 10
        ? all.where((x) => x.ruleId.startsWith('D10-FINAL-')).toList(growable: false)
        : const <VargaRuleHit>[];
    final displayed = factor == 10
        ? <VargaRuleHit>[
            ...applied,
            ...d10PinnedFinal.where((x) => !applied.contains(x)),
          ]
        : applied;
    final d10AuditOnly = factor == 10
        ? all.where((x) => !displayed.contains(x)).toList(growable: false)
        : const <VargaRuleHit>[];
    final definition = VargaService.definitionFor(factor);

    Color cardColor(VargaRuleTone tone) => switch (tone) {
          VargaRuleTone.favorable => const Color(0xFFF0F8F2),
          VargaRuleTone.caution => const Color(0xFFFFF2F0),
          VargaRuleTone.neutral => const Color(0xFFFFF8E8),
          VargaRuleTone.info => const Color(0xFFF3F4F6),
        };

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionTitle(
          factor == 10
              ? 'D10 — వృత్తి / ఉద్యోగం / వ్యాపారం అంశాలు'
              : factor == 24
                  ? 'D24 — విద్య / అభ్యాసం పూర్తి Rule Engine'
                  : factor == 27
                      ? 'D27 — రోగ / Health Rule Engine'
                  : factor == 9
                      ? 'D9 — వివాహం / Navamsa పూర్తి Rule Engine'
                      : '${definition.code} — జాతకానికి వర్తించిన ఫలితాలు',
        ),
        const SizedBox(height: 8),
        Text(
          factor == 10
              ? 'ముందుగా గోచరిష్ట (Business) / అగోచరిష్ట (Job) వృత్తి విధానం, వాటి రంగాల జాబితాలు, ఎదుగుదల / పతనం / మధ్యస్థం సంవత్సరాలు, యోగాల సమగ్ర ఫలితం వస్తాయి. మిగతా detailed source rules కింద తెరవవచ్చు. Evidence Match % అనేది probability కాదు.'
              : factor == 24
                  ? 'D24లో రెండు ప్రధాన engines ఉంటాయి. A) Education Continuity / విద్య సాగే స్థాయి: 4H→School/Intermediate, 9H→Degree/B.Tech, 2H→PG, 7H→Post-PG. ప్రతి stageలోనే Hostel/ఇంటికి దూరంగా చదువు, Foreign Education, Break/Resume కనిపిస్తాయి. B) Education Field / చదవవలసిన విద్య: 5వ భావం start +15° → Nakshatra lord → అతని D24 రాశి → ఆ రాశి విద్యలు + అక్కడి గ్రహాల విద్యలు + Nakshatra lordను చూస్తున్న గ్రహాల విద్యలు కలిపి, రాశి తత్వానికి సరిపోయే విద్యలను suitability %తో చూపిస్తుంది. ఫలితం టచ్ → Rule ID → Result → Source; Rule/పరిశీలన వివరాల్లో పూర్తి calculation chain కనిపిస్తుంది.'
                  : factor == 27
                      ? 'D27లో Gender, ప్రధాన health-trigger planet, D27 రాశి/నక్షత్రం, body-region image, Internal/External rule, Panchadha strength %, Bhamsa Devata, Vimshottari age/timing Evidence % చూపిస్తాం. % అనేది astrology evidence coverage మాత్రమే; medical probability కాదు.'
                  : factor == 9
                      ? 'D9లో Marriage Promise, 7H/7L stability, before-marriage obstacles/relationship, timing evidence list, after-marriage 2H/2L quality, affair/repeated-relationship evidence, D7 Ketu Sutra-35 divorce confirmation మరియు final separation/divorce evidenceను point-wiseగా చూపిస్తాం. % = evidence coverage మాత్రమే; probability కాదు.'
                      : 'ఈ జాతకానికి source rule condition నిజంగా match అయిన ఫలితాలు మాత్రమే ఇక్కడ చూపిస్తాం. పలితం టచ్ → రూల్ → పరిహారం. Sourceలో పూర్తి arithmetic లేకపోతే ఊహించి auto-result ఇవ్వము.',
          style: const TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
        ),
        if (factor == 10 || factor == 24) ...[
          const SizedBox(height: 10),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: factor == 24
                ? const [
                    Chip(label: Text('✓ అనుకూలం')),
                    Chip(label: Text('! జాగ్రత్త')),
                    Chip(label: Text('△ మిశ్రమం')),
                    Chip(label: Text('Matched only')),
                  ]
                : const [
                    Chip(label: Text('✓ అనుకూలం')),
                    Chip(label: Text('! జాగ్రత్త')),
                    Chip(label: Text('△ మిశ్రమం')),
                    Chip(label: Text('Matched + Audit')),
                  ],
          ),
        ],
        if (factor == 9) _d9MarriageSummaryCard(),
        if (factor == 27) _d27HealthSummaryCard(context),
        if (factor == 24) _d24SummaryCard(applied),
        if (factor == 10)
          D10CareerOverview(
            chart: chart,
            birthDateTime: birthDateTime,
            rules: all,
            onRuleTap: (hit) => _showResult(context, hit),
          ),
        if (validationReport != null) ...[
          const SizedBox(height: 10),
          Card(
            color: const Color(0xFFF7F1FF),
            surfaceTintColor: Colors.transparent,
            child: ExpansionTile(
              initiallyExpanded: true,
              leading: const Icon(Icons.fact_check_outlined, color: Color(0xFF6B3FA0)),
              title: const Text(
                'D10 Master Validation Example-1',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: Text(
                'Mallikarjuna • 15-12-1981 15:50 • Life-event audit ${validationReport.scorePercent}% • exact ${validationReport.matched}, near ${validationReport.near}, miss ${validationReport.missed}',
              ),
              childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Actual current pattern: Astrology/Vastu consultancy + gems sales ప్రధాన ఆదాయ stream; bank daily-wage/service parallel stream. గతంలో NBFC service → partnership business → gems business → consultancy. ఈ history predictive rulesను మార్చదు; ఇప్పటికే లెక్కించిన D10 windowsతో మాత్రమే compare అవుతుంది.',
                    style: const TextStyle(height: 1.45),
                  ),
                ),
                const SizedBox(height: 8),
                if (validationMode.isNotEmpty)
                  _validationLine('Current Mode', validationMode.first.result),
                if (validationProfession.isNotEmpty)
                  _validationLine('Exact Profession', validationProfession.first.result),
                const Divider(height: 22),
                ...validationReport.matches.map((m) {
                  final icon = switch (m.status) {
                    D10ValidationStatus.matched => '🟢',
                    D10ValidationStatus.near => '🟡',
                    D10ValidationStatus.missed => '🔴',
                  };
                  final window = m.window;
                  final predicted = window == null
                      ? 'matching D10 window లేదు'
                      : '${D10CareerService.formatDate(window.start)} → ${D10CareerService.formatDate(window.end)} • ${window.title} • ${window.mahadasha}/${window.antardasha}${m.gapDays > 0 ? ' • gap ${m.gapDays}d' : ''}';
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 9),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(11),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFFE4D9EF)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('$icon ${m.event.title}', style: const TextStyle(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 3),
                          Text('Actual: ${m.event.actualNote}', style: const TextStyle(fontSize: 12.5)),
                          Text('Engine: $predicted', style: const TextStyle(fontSize: 12.5, color: Color(0xFF5F5052))),
                        ],
                      ),
                    ),
                  );
                }),
                const SizedBox(height: 4),
                const Text(
                  'Validation score = app audit metric మాత్రమే; classical probability కాదు. Real-life eventsను చూసి rule thresholdsను ఆటోగా మార్చదు.',
                  style: TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E)),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 10),
        if (factor == 10)
          Card(
            color: const Color(0xFFF7F4F1),
            surfaceTintColor: Colors.transparent,
            child: ExpansionTile(
              initiallyExpanded: false,
              title: const Text('8. Rule / పరిశీలన వివరాలు — Detailed D10 Audit', style: TextStyle(fontWeight: FontWeight.w900)),
              subtitle: Text('${displayed.length} source-linked applied/final rules • టచ్ చేసి Rule ID → Result → Source చూడండి'),
              children: displayed.map((item) => ListTile(
                leading: Icon(_toneIcon(item.tone), color: _toneColor(item.tone)),
                title: Text(item.topic, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(item.result, maxLines: 2, overflow: TextOverflow.ellipsis),
                onTap: () => _showResult(context, item),
                trailing: const Text('ఫలితం', style: TextStyle(color: Color(0xFF8B1E2D))),
              )).toList(),
            ),
          )
        else if (displayed.isEmpty)
          Card(
            color: const Color(0xFFFFF4DB),
            surfaceTintColor: Colors.transparent,
            child: const Padding(
              padding: EdgeInsets.all(14),
              child: Text('ఈ జాతకానికి ప్రస్తుతం వర్తించిన source rule లేదు.'),
            ),
          )
        else
          ...displayed.map(
            (item) => Card(
              color: cardColor(item.tone),
              surfaceTintColor: Colors.transparent,
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                onTap: () => factor == 24 ? _showD24Result(context, item) : _showResult(context, item),
                leading: Icon(_toneIcon(item.tone), color: _toneColor(item.tone)),
                title: Text(item.topic, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(item.result, maxLines: factor == 10 ? 4 : 3, overflow: TextOverflow.ellipsis),
                trailing: factor == 24
                    ? TextButton(
                        onPressed: () => _showD24Result(context, item),
                        child: const Text(
                          'ఫలితం',
                          style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF8B1E2D)),
                        ),
                      )
                    : Text(
                        item.autoEvaluated ? 'ఫలితం' : 'Source',
                        style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF8B1E2D)),
                      ),
              ),
            ),
          ),
        if (factor == 10 && d10AuditOnly.isNotEmpty)
          Card(
            color: const Color(0xFFF7F4F1),
            surfaceTintColor: Colors.transparent,
            margin: const EdgeInsets.only(top: 8, bottom: 10),
            child: ExpansionTile(
              initiallyExpanded: false,
              leading: const Icon(Icons.fact_check_outlined, color: Color(0xFF6B5B5E)),
              title: const Text(
                'Audit / Source-only rules',
                style: TextStyle(fontWeight: FontWeight.w900),
              ),
              subtitle: Text('${d10AuditOnly.length} unmatched/source-only rules — client resultలో చూపించము'),
              childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              children: d10AuditOnly.map((item) => ListTile(
                dense: true,
                onTap: () => _showResult(context, item),
                leading: Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 20),
                title: Text(item.topic, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(item.result, maxLines: 2, overflow: TextOverflow.ellipsis),
                trailing: const Text('Audit', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
              )).toList(growable: false),
            ),
          ),
      ],
    );
  }
}


class _MarriageMatchingTab extends StatefulWidget {
  final BirthData birthData;
  final AstroChartResult result;

  const _MarriageMatchingTab({
    required this.birthData,
    required this.result,
  });

  @override
  State<_MarriageMatchingTab> createState() => _MarriageMatchingTabState();
}

class _MarriageMatchingTabState extends State<_MarriageMatchingTab> {
  late Future<List<SavedChart>> _savedFuture;
  SavedChart? _partner;
  Future<AstroChartResult>? _partnerFuture;

  @override
  void initState() {
    super.initState();
    _savedFuture = ChartStorageService.load();
  }

  bool _isCurrent(BirthData b) =>
      b.name == widget.birthData.name &&
      b.localDateTime == widget.birthData.localDateTime &&
      b.latitude == widget.birthData.latitude &&
      b.longitude == widget.birthData.longitude;

  void _selectPartner(SavedChart? chart) {
    setState(() {
      _partner = chart;
      _partnerFuture = chart == null
          ? null
          : AstroCalculationService.calculate(chart.birthData);
    });
  }

  @override
  Widget build(BuildContext context) {
    final twoChartRules = MarriageMaterialRegistry.entries
        .where((e) => e.requiresTwoCharts)
        .toList(growable: false);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('వివాహ పొంతన'),
        const SizedBox(height: 8),
        Text(
          'మొదటి జాతకం: ${widget.birthData.name}. రెండవ జాతకాన్ని Saved Charts నుంచి ఎంచుకోండి. రెండు జాతకాలు అవసరమైన source rules ఈ tabలో మాత్రమే evaluate చేయాలి.',
          style: const TextStyle(height: 1.45),
        ),
        const SizedBox(height: 14),
        FutureBuilder<List<SavedChart>>(
          future: _savedFuture,
          builder: (context, snapshot) {
            final charts = (snapshot.data ?? const <SavedChart>[])
                .where((x) => !_isCurrent(x.birthData))
                .toList(growable: false);
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (charts.isEmpty) {
              return Card(
                color: const Color(0xFFFFF4DB),
                surfaceTintColor: Colors.transparent,
                child: const Padding(
                  padding: EdgeInsets.all(14),
                  child: Text(
                    'రెండవ జాతకం Saved Chartsలో లేదు. ముందుగా వధువు/వరుడు జాతకాన్ని Save Chart చేయండి; తరువాత ఇక్కడ select చేయవచ్చు.',
                  ),
                ),
              );
            }
            return DropdownButtonFormField<String>(
              value: _partner?.id,
              decoration: const InputDecoration(
                labelText: 'వధువు / వరుడు రెండవ జాతకం',
                border: OutlineInputBorder(),
              ),
              items: charts
                  .map(
                    (x) => DropdownMenuItem<String>(
                      value: x.id,
                      child: Text('${x.birthData.name} — ${x.birthData.place}'),
                    ),
                  )
                  .toList(),
              onChanged: (id) {
                SavedChart? selected;
                for (final item in charts) {
                  if (item.id == id) {
                    selected = item;
                    break;
                  }
                }
                _selectPartner(selected);
              },
            );
          },
        ),
        const SizedBox(height: 14),
        if (_partnerFuture != null)
          FutureBuilder<AstroChartResult>(
            future: _partnerFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return const Card(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Row(
                      children: [
                        SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)),
                        SizedBox(width: 12),
                        Text('రెండవ జాతకం calculate చేస్తున్నాం…'),
                      ],
                    ),
                  ),
                );
              }
              if (!snapshot.hasData) {
                return const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('రెండవ జాతకం calculation failed.')));
              }
              final other = snapshot.data!;
              final d9a = VargaService.calculate(widget.result, 9);
              final d9b = VargaService.calculate(other, 9);
              return Card(
                color: const Color(0xFFF2EAFB),
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('రెండు జాతకాలు సిద్ధం', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                      const SizedBox(height: 8),
                      Text('${widget.birthData.name}: D9 Lagna ${d9a.ascendantSignIndex + 1}'),
                      Text('${_partner!.birthData.name}: D9 Lagna ${d9b.ascendantSignIndex + 1}'),
                      const SizedBox(height: 8),
                      Text('${twoChartRules.length} supplied two-chart matching rules source registryలో ఉన్నాయి.'),
                    ],
                  ),
                ),
              );
            },
          ),
        const SizedBox(height: 16),
        const Text('పొంతన Source Rules', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        ...twoChartRules.map(
          (rule) => Card(
            color: Colors.white,
            surfaceTintColor: Colors.transparent,
            child: ListTile(
              leading: const Icon(Icons.rule_outlined),
              title: Text(rule.topic, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('Source page ${rule.page} • ${rule.id}'),
              onTap: () => showModalBottomSheet<void>(
                context: context,
                showDragHandle: true,
                builder: (sheetContext) => SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(rule.topic, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 10),
                        Text(rule.note, style: const TextStyle(height: 1.45)),
                        const SizedBox(height: 10),
                        Text('Rule ID: ${rule.id} • Source page ${rule.page}', style: const TextStyle(color: Color(0xFF6B5B5E))),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _GemRemedyTab extends StatefulWidget {
  final AstroChartResult result;
  final AshtakavargaResult av;

  const _GemRemedyTab({
    required this.result,
    required this.av,
  });

  @override
  State<_GemRemedyTab> createState() => _GemRemedyTabState();
}

class _GemRemedyTabState extends State<_GemRemedyTab> {
  String _planet = 'Jupiter';

  Color _statusColor(GemDecisionStatus status) => switch (status) {
        GemDecisionStatus.eligible => const Color(0xFF197A45),
        GemDecisionStatus.conditional => const Color(0xFF9A6500),
        GemDecisionStatus.restricted => const Color(0xFFB3261E),
        GemDecisionStatus.notIndicated => const Color(0xFF5F6368),
      };

  String _statusLabel(GemDecisionStatus status) => switch (status) {
        GemDecisionStatus.eligible => 'ELIGIBLE / పరిగణించవచ్చు',
        GemDecisionStatus.conditional => 'CONDITIONAL / షరతులతో',
        GemDecisionStatus.restricted => 'RESTRICTED / ఇవ్వకూడదు',
        GemDecisionStatus.notIndicated => 'NOT INDICATED / అవసరం కనిపించలేదు',
      };

  IconData _statusIcon(GemDecisionStatus status) => switch (status) {
        GemDecisionStatus.eligible => Icons.check_circle_outline,
        GemDecisionStatus.conditional => Icons.warning_amber_outlined,
        GemDecisionStatus.restricted => Icons.block_outlined,
        GemDecisionStatus.notIndicated => Icons.remove_circle_outline,
      };

  void _showAppliedRules(GemEvaluation eval) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.of(sheetContext).viewPadding.bottom + 36,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${eval.gemEnglish} — అప్లయ్ అయిన రూల్స్', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              if (eval.rules.isEmpty)
                const Card(
                  child: Padding(
                    padding: EdgeInsets.all(14),
                    child: Text('ఈ gemకు ప్రస్తుతం source rule condition match కాలేదు.'),
                  ),
                )
              else
                ...eval.rules.map(
                  (rule) => Card(
                    color: rule.blocking
                        ? const Color(0xFFFFECE9)
                        : rule.conditional
                            ? const Color(0xFFFFF4DB)
                            : const Color(0xFFEAF6EE),
                    surfaceTintColor: Colors.transparent,
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('${rule.id} • ${rule.title}', style: const TextStyle(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 6),
                          Text(rule.inspection, style: const TextStyle(height: 1.45)),
                          const SizedBox(height: 6),
                          Text(rule.source, style: const TextStyle(fontSize: 12.5, color: Color(0xFF6B5B5E))),
                        ],
                      ),
                    ),
                  ),
                ),
              if (eval.safeguards.isNotEmpty) ...[
                const SizedBox(height: 10),
                const Text('Safeguard', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                ...eval.safeguards.map((x) => Text('• $x')),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final eval = GemRemedyService.evaluate(
      chart: widget.result,
      ashtakavarga: widget.av,
      planet: _planet,
    );
    final color = _statusColor(eval.status);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Gem Remedy'),
        const SizedBox(height: 8),
        const Text(
          'Gem select చేస్తే Varga Bala + భావ strength inputsను తీసుకుని supplied Principle 1–10 మరియు Rahu–Ketu restrictions apply చేస్తుంది. ఫలితం టచ్ చేస్తే match అయిన rule + source page కనిపిస్తుంది.',
          style: TextStyle(height: 1.45),
        ),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: _planet,
          decoration: const InputDecoration(
            labelText: 'Gem ఎంచుకోండి',
            border: OutlineInputBorder(),
          ),
          items: GemRemedyService.selectablePlanets.map((planet) {
            final gem = GemRemedyService.gemNames[planet]!;
            return DropdownMenuItem<String>(
              value: planet,
              child: Text('${gem.$1} — $planet'),
            );
          }).toList(),
          onChanged: (value) {
            if (value != null) setState(() => _planet = value);
          },
        ),
        const SizedBox(height: 14),
        InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _showAppliedRules(eval),
          child: Card(
            color: color.withOpacity(0.10),
            surfaceTintColor: Colors.transparent,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: color.withOpacity(0.35)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(_statusIcon(eval.status), color: color, size: 30),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          '${eval.gemTelugu} (${eval.gemEnglish})',
                          style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(_statusLabel(eval.status), style: TextStyle(color: color, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text(eval.summary, style: const TextStyle(fontSize: 15.5, height: 1.45)),
                  const SizedBox(height: 10),
                  const Text('ఫలితం టచ్ చేస్తే అప్లయ్ అయిన రూల్ చూడండి', style: TextStyle(fontWeight: FontWeight.w800)),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text('వర్గ బలాలు / Grahashakti input', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Card(
          color: Colors.white,
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                _GemMetricRow(label: 'Shadvarga Vimshopaka', value: '${eval.strength.shadVimsopaka.toStringAsFixed(2)}/20'),
                _GemMetricRow(label: 'Saptavarga Vimshopaka', value: '${eval.strength.saptaVimsopaka.toStringAsFixed(2)}/20'),
                _GemMetricRow(label: 'Dashavarga Vimshopaka', value: '${eval.strength.dashaVimsopaka.toStringAsFixed(2)}/20'),
                _GemMetricRow(label: 'Shodashavarga Vimshopaka', value: '${eval.strength.shodashaVimsopaka.toStringAsFixed(2)}/20'),
                _GemMetricRow(label: 'Supporting Vargas', value: eval.strength.shodashaSupport.isEmpty ? '—' : eval.strength.shodashaSupport.map((x) => 'D$x').join(', ')),
                _GemMetricRow(label: 'App Grahashakti status', value: eval.strength.grahaDeficient ? 'Deficient (< ${GemRemedyService.grahaDeficientCutoff.toStringAsFixed(0)}/20)' : 'Sufficient'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        const Text('భావ బలం / Bhava strength input', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        Card(
          color: Colors.white,
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: eval.strength.ownedHouseStrengths.isEmpty
                ? Text('${eval.planet}కు sign-lord house ownership లేదు; node rulesను placement restrictions ఆధారంగా evaluate చేస్తాం.')
                : Column(
                    children: [
                      ...eval.strength.ownedHouseStrengths.map(
                        (h) => _GemMetricRow(
                          label: '${h.house}వ భావం SAV',
                          value: '${h.savPoints} • ${h.deficient ? 'Deficient' : 'Sufficient'}',
                        ),
                      ),
                      _GemMetricRow(label: 'Owned-house average', value: eval.strength.ownedHouseAverage.toStringAsFixed(1)),
                      _GemMetricRow(label: 'Planet placement', value: '${eval.strength.placementHouse}వ భావం'),
                    ],
                  ),
          ),
        ),
        const SizedBox(height: 16),
        _StrengthTables(
          chart: widget.result,
          av: widget.av,
          title: 'పూర్తి Strength Tables',
          initiallyExpanded: false,
        ),
        const SizedBox(height: 12),
        const Card(
          color: Color(0xFFFFF4DB),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.all(14),
            child: Text(
              'Calculation note: supplied Gem remedy source Grahashakti/Bhavabala conditionsను ఇస్తుంది, కానీ పూర్తి classical Shadbala/Bhava-Bala arithmeticను ఈ pagesలో ఇవ్వలేదు. అందువల్ల ఈ tabలో verified Vimshopaka Varga Balaను Grahashakti inputగా, SAV house pointsను Bhava-strength inputగా ఉపయోగిస్తున్నాం. Thresholds app decision thresholds మాత్రమే; source numeric cut-offs కావు.',
              style: TextStyle(fontSize: 12.5, height: 1.45),
            ),
          ),
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}



class _SkMehtaTab extends StatefulWidget {
  final BirthData birthData;
  final AstroChartResult result;
  final AshtakavargaResult av;

  const _SkMehtaTab({
    required this.birthData,
    required this.result,
    required this.av,
  });

  @override
  State<_SkMehtaTab> createState() => _SkMehtaTabState();
}

class _SkMehtaTabState extends State<_SkMehtaTab> {
  String _eventId = SkMehtaService.events.first.id;

  SkMehtaEventRule get _selected => SkMehtaService.events
      .firstWhere((rule) => rule.id == _eventId);

  bool _isSensitive(SkMehtaEventRule rule) =>
      const {'M10', 'M15', 'M16'}.contains(rule.id);

  String _periodText(DashaPeriod p) =>
      '${p.lord}: ${AstroFormat.dateTime(p.start)} → ${AstroFormat.dateTime(p.end)}';

  String _lordMap(List<int> houses, List<String> lords) {
    final parts = <String>[];
    for (var i = 0; i < houses.length && i < lords.length; i++) {
      parts.add('${houses[i]}వ=${lords[i]}');
    }
    return parts.join(' • ').replaceAll(r'$', '');
  }

  void _showRuleDetail(SkMehtaChartEvidence evidence) {
    final rule = evidence.rule;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.of(sheetContext).viewPadding.bottom + 36,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${rule.id} • ${rule.event}',
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              const Text('S.K. Mehta Combination',
                  style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 4),
              Text(rule.combination, style: const TextStyle(height: 1.45)),
              const SizedBox(height: 12),
              Text('Primary period check: ${rule.primaryPeriodCheck}'),
              Text('Micro synchronization: ${rule.microSynchronization}'),
              Text('Tribhagi: ${rule.tribhagi}'),
              Text('Timing adjustment: ${rule.timingAdjustment}'),
              Text('Replacement: ${rule.replacement}'),
              Text('Output: ${rule.appOutput}'),
              const SizedBox(height: 14),
              const Text('ఈ జాతకంలో గుర్తించిన బాధ్యత గ్రహాలు',
                  style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('ASC: ${_lordMap(rule.ascHouses, evidence.ascLords)}'),
              if (rule.moonAscCheck)
                Text('Moon ASC: ${_lordMap(rule.moonAscHouses.isEmpty ? rule.ascHouses : rule.moonAscHouses, evidence.moonAscLords)}'),
              if (rule.fixedPlanets.isNotEmpty)
                Text('Source fixed planets: ${rule.fixedPlanets.join(' + ')}'),
              if (_isSensitive(rule)) ...[
                const SizedBox(height: 14),
                const Card(
                  color: Color(0xFFEFF7F0),
                  surfaceTintColor: Colors.transparent,
                  child: Padding(
                    padding: EdgeInsets.all(12),
                    child: Text(
                      'Traditional Remedy: మహా మృత్యుంజయ జపం / హోమం — సంప్రదాయ ఆధ్యాత్మిక పరిహారం. ఇది S.K. Mehta source rule కాదు; ఫలితం హామీ కాదు. Accident concern ఉంటే సాధారణ భద్రతా జాగ్రత్తలను కూడా పాటించాలి.',
                      style: TextStyle(height: 1.45, fontWeight: FontWeight.w700),
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 14),
              Text(rule.source,
                  style: const TextStyle(fontSize: 12.5, color: Color(0xFF6B5B5E))),
              const SizedBox(height: 12),
              const Card(
                color: Color(0xFFFFF4DB),
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(
                    'గమనిక: ఈ tabలో S.K. Mehta source combination + synchronization evidence మాత్రమే చూపిస్తాం. Sourceలో స్పష్టంగా లేని exact glyph/exceptionను ఊహించి final prediction చేయము.',
                    style: TextStyle(height: 1.45),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _comboColor(MehtaComboTone tone) => switch (tone) {
        MehtaComboTone.favorable => const Color(0xFF1B7F3A),
        MehtaComboTone.caution => const Color(0xFFB3261E),
        MehtaComboTone.mixed => const Color(0xFFB26A00),
        MehtaComboTone.info => const Color(0xFF315E8A),
      };

  IconData _comboIcon(MehtaComboTone tone) => switch (tone) {
        MehtaComboTone.favorable => Icons.check_circle,
        MehtaComboTone.caution => Icons.warning_amber_rounded,
        MehtaComboTone.mixed => Icons.change_circle_outlined,
        MehtaComboTone.info => Icons.info_outline,
      };

  String _comboStatus(MehtaCombinationMatch row) {
    if (!row.rule.autoEvaluated) return 'Source / Timing rule — manual layer';
    if (!row.matched) return 'ఈ జాతకానికి match కాలేదు';
    return switch (row.tone) {
      MehtaComboTone.favorable => 'అనుకూలం',
      MehtaComboTone.caution => 'జాగ్రత్త / ప్రతికూల ప్రభావం',
      MehtaComboTone.mixed => 'మిశ్రమ ఫలితం',
      MehtaComboTone.info => 'Source సమాచారం',
    };
  }

  void _showComboDetail(MehtaCombinationMatch row) {
    final color = row.matched ? _comboColor(row.tone) : const Color(0xFF6E5D60);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.of(sheetContext).viewPadding.bottom + 32,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(row.matched ? _comboIcon(row.tone) : Icons.radio_button_unchecked,
                      color: color, size: 30),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(row.rule.title,
                            style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                        Text('${row.rule.folderLabel} • Rule ${row.rule.no}',
                            style: TextStyle(color: color, fontWeight: FontWeight.w800)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: row.matched ? color.withOpacity(0.08) : const Color(0xFFF4F1F1),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: color.withOpacity(0.28)),
                ),
                child: Text(
                  _comboStatus(row),
                  style: TextStyle(fontWeight: FontWeight.w900, color: color, fontSize: 16),
                ),
              ),
              if (row.matched) ...[
                const SizedBox(height: 16),
                const Text('పలితం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text(row.sourceResult, style: const TextStyle(fontSize: 16, height: 1.5)),
                if (row.affectedSignIndex != null) ...[
                  const SizedBox(height: 14),
                  const Text('ఈ జాతకంలో ప్రభావిత స్థానం',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 6),
                  Text(row.evidence, style: const TextStyle(fontSize: 16, height: 1.45)),
                  const SizedBox(height: 6),
                  Text(
                    'ఫలితం తీసుకున్న reference: ${row.reference.label}. ${row.affectedHouse ?? 0}వ భావం → ${row.affectedHouse == null ? '—' : MehtaCombinationService.houseTopics(row.affectedHouse!)}',
                    style: const TextStyle(fontWeight: FontWeight.w800, height: 1.45),
                  ),
                ],
              ],
              const Divider(height: 30),
              const Text('అప్లయ్ చేసిన Rule', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(row.rule.ruleText, style: const TextStyle(fontSize: 16, height: 1.45)),
              const SizedBox(height: 12),
              const Text('జాతక Match Logic', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text(row.logic, style: const TextStyle(height: 1.45)),
              const SizedBox(height: 12),
              const Text('Lagna Reference నిర్ణయం', style: TextStyle(fontWeight: FontWeight.w900)),
              const SizedBox(height: 5),
              Text(row.reference.reason, style: const TextStyle(height: 1.45)),
              const SizedBox(height: 14),
              Text(
                'Source registry: annapurna-jataka-16 — S.K. Mehta New Rules & Combinations (stored paraphrase) • ${row.rule.id}/${row.rule.no}',
                style: const TextStyle(fontSize: 12.5, color: Color(0xFF6E5D60), height: 1.4),
              ),
              const SizedBox(height: 10),
              const Card(
                color: Color(0xFFFFF4DB),
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: EdgeInsets.all(12),
                  child: Text(
                    'Source discipline: rule condition match కాకపోతే resultగా చూపించము. Health/safety-sensitive rulesను diagnosis లేదా ఖచ్చిత ఘటన predictionగా ఉపయోగించము. Sourceలో స్పష్టంగా లేని condition manual/source-reviewగా ఉంటుంది.',
                    style: TextStyle(height: 1.45),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _referenceCard(MehtaReferenceChoice ref) {
    final janma = MehtaCombinationService.signNamesTe[widget.result.ascendantSignIndex];
    final moonPos = widget.result.planets.firstWhere((p) => p.name == 'Moon');
    final moon = MehtaCombinationService.signNamesTe[moonPos.signIndex];
    return Card(
      color: const Color(0xFFF3F0FA),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ఫలితం ఏ లగ్నం నుండి తీసుకున్నాం?',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text('జన్మ లగ్నం: $janma   •   చంద్ర లగ్నం: $moon'),
            const SizedBox(height: 6),
            Text('Selected reference: ${ref.label}',
                style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF6D2440))),
            const SizedBox(height: 6),
            Text(ref.reason, style: const TextStyle(height: 1.4)),
          ],
        ),
      ),
    );
  }

  Widget _comboDashboard(List<MehtaCombinationMatch> all) {
    final groups = <String, List<MehtaCombinationMatch>>{};
    for (final row in all) {
      groups.putIfAbsent(row.rule.folderLabel, () => <MehtaCombinationMatch>[]).add(row);
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('అంశాల ఫలితాలు', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text(
          'అనుకూల source condition అయితే ఆకుపచ్చ ✓. జాగ్రత్త condition అయితే ఎరుపు సూచన. అంశాన్ని టచ్ చేస్తే match అయిన combinations మరియు వాటి ఫలితాలు కనిపిస్తాయి.',
          style: TextStyle(height: 1.4, color: Color(0xFF6E5D60)),
        ),
        const SizedBox(height: 10),
        ...groups.entries.map((entry) {
          final hits = entry.value.where((x) => x.matched).toList();
          final hasCaution = hits.any((x) => x.tone == MehtaComboTone.caution);
          final hasMixed = hits.any((x) => x.tone == MehtaComboTone.mixed);
          final allFavourable = hits.isNotEmpty && hits.every((x) => x.tone == MehtaComboTone.favorable);
          final color = allFavourable
              ? const Color(0xFF1B7F3A)
              : hasCaution
                  ? const Color(0xFFB3261E)
                  : hasMixed
                      ? const Color(0xFFB26A00)
                      : const Color(0xFF6E5D60);
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            surfaceTintColor: Colors.transparent,
            child: ExpansionTile(
              leading: Icon(
                allFavourable ? Icons.check_circle : hits.isEmpty ? Icons.radio_button_unchecked : Icons.analytics_outlined,
                color: color,
              ),
              title: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w900)),
              subtitle: Text(hits.isEmpty ? 'ప్రస్తుతం match అయిన source combination లేదు' : '${hits.length} combination(s) ఈ జాతకానికి match అయ్యాయి'),
              children: hits.isEmpty
                  ? const [
                      Padding(
                        padding: EdgeInsets.fromLTRB(16, 0, 16, 14),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text('ఈ అంశానికి source match లభించలేదు.'),
                        ),
                      ),
                    ]
                  : hits.map((row) {
                      final c = _comboColor(row.tone);
                      return ListTile(
                        leading: Icon(_comboIcon(row.tone), color: c),
                        title: Text(row.rule.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text(row.sourceResult, maxLines: 3, overflow: TextOverflow.ellipsis),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => _showComboDetail(row),
                      );
                    }).toList(),
            ),
          );
        }),
        const SizedBox(height: 8),
        ExpansionTile(
          title: Text('అన్ని ${all.length} S.K. Mehta Combinations',
              style: const TextStyle(fontWeight: FontWeight.w900)),
          subtitle: const Text('Match / Not matched / Source-only status చూడండి'),
          children: all.map((row) {
            final color = row.matched ? _comboColor(row.tone) : const Color(0xFF8B8082);
            return ListTile(
              dense: true,
              leading: Icon(
                row.matched
                    ? _comboIcon(row.tone)
                    : row.rule.autoEvaluated
                        ? Icons.radio_button_unchecked
                        : Icons.menu_book_outlined,
                color: color,
              ),
              title: Text('${row.rule.no} • ${row.rule.title}'),
              subtitle: Text(_comboStatus(row)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => _showComboDetail(row),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _syncCard(String title, SkMehtaSyncResult sync) {
    final path = sync.path;
    final required = sync.requiredMatchCount;
    final statusText = path == null
        ? 'ఈ తేదీకి period path దొరకలేదు.'
        : '${sync.matchedCount}/$required అవసరమైన బాధ్యత గ్రహాలు primary 2–4 placesలో కనిపించాయి.';
    final full = sync.fullPrimaryMatch;
    return Card(
      color: full ? const Color(0xFFEAF6EE) : Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(full ? Icons.check_circle_outline : Icons.timeline_outlined,
                    color: full ? const Color(0xFF2E7D32) : const Color(0xFF7B1E2B)),
                const SizedBox(width: 8),
                Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
              ],
            ),
            const SizedBox(height: 8),
            Text(statusText, style: const TextStyle(fontWeight: FontWeight.w700)),
            if (path != null) ...[
              const SizedBox(height: 8),
              Text('1. MD — ${_periodText(path.mahadasha)}'),
              Text('2. AD — ${_periodText(path.antardasha)}'),
              Text('3. PD — ${_periodText(path.pratyantardasha)}'),
              Text('4. Sukshma — ${_periodText(path.sukshma)}'),
              Text('5. Prana — ${_periodText(path.prana)}'),
              const SizedBox(height: 6),
              Text('Primary 2–4: ${sync.primaryPlaces.join(' → ')}',
                  style: const TextStyle(fontWeight: FontWeight.w800)),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final rule = _selected;
    final evidence = SkMehtaService.evaluate(
      rule: rule,
      chart: widget.result,
      birthDateTime: widget.birthData.localDateTime,
    );
    final ascMap = _lordMap(rule.ascHouses, evidence.ascLords);
    final moonHouses = rule.moonAscHouses.isEmpty ? rule.ascHouses : rule.moonAscHouses;
    final moonMap = _lordMap(moonHouses, evidence.moonAscLords);
    final comboRows = MehtaCombinationService.evaluateAll(widget.result);
    final reference = comboRows.isEmpty ? MehtaCombinationService.referenceChoice(widget.result) : comboRows.first.reference;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('S.K. Mehta System'),
        const SizedBox(height: 8),
        const Text(
          'ఈ tabలో uploaded S.K. Mehta Synchronization / New Dimensions source rules మాత్రమే వాడుతాం. Event combination → ASC/Moon ASC బాధ్యత గ్రహాలు → Vimshottari/Tribhagi 2nd–4th place synchronization క్రమంలో చూపిస్తాం. Accident/death సంబంధిత material source-risk analysisగా మాత్రమే చూపిస్తాం; certainty/date predictionగా కాదు.',
          style: TextStyle(height: 1.45),
        ),
        const SizedBox(height: 14),
        _referenceCard(reference),
        const SizedBox(height: 14),
        _comboDashboard(comboRows),
        const SizedBox(height: 18),
        const Text('Event Timing / Synchronization',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: _eventId,
          decoration: const InputDecoration(
            labelText: 'Mehta Event ఎంచుకోండి',
            border: OutlineInputBorder(),
          ),
          items: SkMehtaService.events
              .map((e) => DropdownMenuItem<String>(
                    value: e.id,
                    child: Text('${e.id} — ${e.event}'),
                  ))
              .toList(),
          onChanged: (value) {
            if (value != null) setState(() => _eventId = value);
          },
        ),
        const SizedBox(height: 14),
        InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _showRuleDetail(evidence),
          child: Card(
            color: const Color(0xFFF2EAFB),
            surfaceTintColor: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${rule.id} • ${rule.event}',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 8),
                  Text(rule.combination,
                      style: const TextStyle(fontSize: 16, height: 1.45, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  Text('ASC బాధ్యత గ్రహాలు: $ascMap'),
                  if (rule.moonAscCheck) Text('Moon ASC బాధ్యత గ్రహాలు: $moonMap'),
                  if (rule.fixedPlanets.isNotEmpty)
                    Text('Source fixed planets: ${rule.fixedPlanets.join(' + ')}'),
                  const SizedBox(height: 10),
                  const Text('ఈ ఫలితం/రూల్ కార్డ్ టచ్ చేస్తే పూర్తి source rule trail చూడండి',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                ],
              ),
            ),
          ),
        ),
        if (_isSensitive(rule)) ...[
          const SizedBox(height: 12),
          const Card(
            color: Color(0xFFEFF7F0),
            surfaceTintColor: Colors.transparent,
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('సంప్రదాయ పరిహారం',
                      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                  SizedBox(height: 6),
                  Text(
                    'మహా మృత్యుంజయ జపం / హోమం — సంప్రదాయ ఆధ్యాత్మిక పరిహారం; ఫలితం హామీ కాదు. ఇది S.K. Mehta source ruleగా చూపించము. Accident concern ఉంటే సాధారణ భద్రతా జాగ్రత్తలు/అవసరమైన వైద్య సహాయం కూడా ప్రాధాన్యమే.',
                    style: TextStyle(height: 1.45),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'ఈ tab source risk indicators మాత్రమే చూపిస్తుంది; ఖచ్చితమైన ప్రమాదం లేదా మరణ తేదీని ప్రకటించదు.',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ),
          ),
        ],
        const SizedBox(height: 16),
        _StrengthTables(
          chart: widget.result,
          av: widget.av,
          title: 'షడ్వర్గ & భావ బల Tables',
          initiallyExpanded: false,
        ),
        const SizedBox(height: 16),
        const Text('ప్రస్తుత Period Synchronization',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        _syncCard('Vimshottari', evidence.vimshottari),
        _syncCard('S.K. Mehta Tribhagi', evidence.tribhagi),
        const SizedBox(height: 14),
        const Card(
          color: Color(0xFFFFF4DB),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: EdgeInsets.all(14),
            child: Text(
              'Primary synchronizationలో 2nd→3rd→4th placesను ముందుగా చూస్తాం. 5th/6th micro-sync source అవసరమని చెప్పినప్పుడు మాత్రమే deeper timing చేయాలి. Current-period match కనిపించినా అది ఒక్కటే final event prediction కాదు; natal promise, strength, source exceptions/adjustment కూడా అవసరం.',
              style: TextStyle(height: 1.45),
            ),
          ),
        ),
        const SizedBox(height: 16),
        ExpansionTile(
          title: const Text('S.K. Mehta Source Guardrails',
              style: TextStyle(fontWeight: FontWeight.w900)),
          children: [
            ...SkMehtaService.guardrails.map(
              (x) => ListTile(
                dense: true,
                leading: const Icon(Icons.verified_user_outlined),
                title: Text(x),
              ),
            ),
          ],
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _StrengthTables extends StatelessWidget {
  final AstroChartResult chart;
  final AshtakavargaResult av;
  final String title;
  final bool initiallyExpanded;

  const _StrengthTables({
    required this.chart,
    required this.av,
    required this.title,
    this.initiallyExpanded = false,
  });

  static const List<int> _shadvargaFactors = [1, 2, 3, 9, 12, 30];

  @override
  Widget build(BuildContext context) {
    final planetRows = chart.planets.map((planet) {
      final strength = PlanetDetailService.forPlanet(chart, planet).vargaStrength;
      final support = strength.shadSupport.toSet();
      return DataRow(
        cells: [
          DataCell(Text(planet.name, style: const TextStyle(fontWeight: FontWeight.w800))),
          ..._shadvargaFactors.map((d) => DataCell(Text(support.contains(d) ? '✓' : '—'))),
          DataCell(Text('${strength.shadvargaja}/6')),
          DataCell(Text(strength.shadVimsopaka.toStringAsFixed(2))),
        ],
      );
    }).toList(growable: false);

    final housePoints = <int, int>{
      for (var house = 1; house <= 12; house++)
        house: av.arithmetic.savHouse(house),
    };
    final ordered = housePoints.entries.toList()
      ..sort((a, b) {
        final byPoints = b.value.compareTo(a.value);
        return byPoints != 0 ? byPoints : a.key.compareTo(b.key);
      });
    final ranks = <int, int>{};
    for (var i = 0; i < ordered.length; i++) {
      ranks[ordered[i].key] = i + 1;
    }

    final houseRows = <DataRow>[];
    for (var house = 1; house <= 12; house++) {
      final sign = (chart.ascendantSignIndex + house - 1) % 12;
      final points = housePoints[house]!;
      final lord = GemRemedyService.lordOfHouse(chart, house);
      houseRows.add(
        DataRow(
          cells: [
            DataCell(Text('$house')),
            DataCell(Text(AstroFormat.signNamesTe[sign])),
            DataCell(Text(lord)),
            DataCell(Text('$points')),
            DataCell(Text('${ranks[house]}')),
            DataCell(Text(points < GemRemedyService.bhavaDeficientCutoff ? 'App: Deficient' : 'App: Sufficient')),
          ],
        ),
      );
    }

    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        initiallyExpanded: initiallyExpanded,
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('గ్రహాల షడ్వర్గ బలం + 1–12 భావాల strength summary'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 16),
        children: [
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('షడ్వర్గ బలం — D1 / D2 / D3 / D9 / D12 / D30',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columnSpacing: 18,
              headingRowHeight: 42,
              dataRowMinHeight: 40,
              dataRowMaxHeight: 52,
              columns: const [
                DataColumn(label: Text('గ్రహం')),
                DataColumn(label: Text('D1')),
                DataColumn(label: Text('D2')),
                DataColumn(label: Text('D3')),
                DataColumn(label: Text('D9')),
                DataColumn(label: Text('D12')),
                DataColumn(label: Text('D30')),
                DataColumn(label: Text('Vargaja')),
                DataColumn(label: Text('Vimshopaka /20')),
              ],
              rows: planetRows,
            ),
          ),
          const SizedBox(height: 18),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('భావ బలం — SAV ఆధారిత app strength table',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columnSpacing: 20,
              headingRowHeight: 42,
              dataRowMinHeight: 40,
              dataRowMaxHeight: 52,
              columns: const [
                DataColumn(label: Text('భావం')),
                DataColumn(label: Text('రాశి')),
                DataColumn(label: Text('అధిపతి')),
                DataColumn(label: Text('SAV')),
                DataColumn(label: Text('Rank')),
                DataColumn(label: Text('App status')),
              ],
              rows: houseRows,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'గమనిక: షడ్వర్గ tableలో ✓ అంటే ఆ vargaలో app dignity/support condition match అయింది. భావ tableలో SAV pointsను strength inputగా చూపిస్తున్నాం. ఇది supplied Gem source case-studyలో కనిపించే పూర్తి classical Bhava Bala component arithmeticకు ప్రత్యామ్నాయం కాదు; ఆ పూర్తి formula sourceలో లభిస్తే దాన్ని ప్రత్యేకంగా implement చేయాలి.',
            style: TextStyle(fontSize: 12.5, height: 1.45, color: Color(0xFF6B5B5E)),
          ),
        ],
      ),
    );
  }
}

class _GemMetricRow extends StatelessWidget {
  final String label;
  final String value;

  const _GemMetricRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w700))),
          const SizedBox(width: 12),
          Flexible(child: Text(value, textAlign: TextAlign.right)),
        ],
      ),
    );
  }
}


class _AshtakavargaTab extends StatelessWidget {
  final AshtakavargaResult result;
  final AstroChartResult chart;
  final BirthData birthData;
  final int ascendantSignIndex;
  final String selectedPlanet;
  final ValueChanged<String> onPlanetChanged;

  const _AshtakavargaTab({
    required this.result,
    required this.chart,
    required this.birthData,
    required this.ascendantSignIndex,
    required this.selectedPlanet,
    required this.onPlanetChanged,
  });

  @override
  Widget build(BuildContext context) {
    final bav = result.bhinna[selectedPlanet]!;
    final expected = result.expectedPlanetTotals[selectedPlanet]!;
    final actual = result.totalFor(selectedPlanet);
    final prastara = result.prastara[selectedPlanet]!;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('అష్టకవర్గం'),
        const SizedBox(height: 8),
        const Text(
          'Parashari Bhinna Ashtakavarga (BAV) లో సూర్యుడు నుంచి శని వరకు 7 గ్రహాలకు, 7 గ్రహాలు + లగ్నం అనే 8 reference points నుంచి bindus లెక్కించబడతాయి. SAV అనేది 7 BAV rows యొక్క మొత్తం.',
        ),
        const SizedBox(height: 12),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(
                  result.totalsValid
                      ? Icons.verified_outlined
                      : Icons.warning_amber_outlined,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Sarvashtakavarga (SAV)',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text('Grand total: ${result.grandTotal} / 337'),
                      Text(
                        result.totalsValid
                            ? 'Classical fixed totals verification passed.'
                            : 'Fixed total verification failed — result check చేయాలి.',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: 'Sarvashtakavarga (SAV)',
          values: result.sarva,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _ScoreGrid(values: result.sarva),
        const SizedBox(height: 18),
        _AshtakavargaArithmeticPanel(
          chart: chart,
          av: result,
        ),
        const SizedBox(height: 18),
        _AshtakavargaLifeMirrorPanel(av: result),
        const SizedBox(height: 18),
        _AshtakavargaEventEvidencePanel(
          birthData: birthData,
          natalChart: chart,
          av: result,
        ),
        const SizedBox(height: 18),
        _AshtakavargaPlanetTimingPanel(
          birthData: birthData,
          chart: chart,
          av: result,
        ),
        const SizedBox(height: 18),
        _AshtakavargaJatakaResults(
          chart: chart,
          av: result,
        ),
        const SizedBox(height: 18),
        DropdownButtonFormField<String>(
          value: selectedPlanet,
          decoration: const InputDecoration(
            labelText: 'Bhinna Ashtakavarga గ్రహం',
            border: OutlineInputBorder(),
          ),
          items: AshtakavargaService.planetOrder
              .map(
                (planet) => DropdownMenuItem(
                  value: planet,
                  child: Text(planet),
                ),
              )
              .toList(),
          onChanged: (value) {
            if (value != null) onPlanetChanged(value);
          },
        ),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: ListTile(
            title: Text('$selectedPlanet BAV'),
            subtitle: Text('Bindu total: $actual / expected $expected'),
            trailing: actual == expected
                ? const Icon(Icons.check_circle_outline)
                : const Icon(Icons.error_outline),
          ),
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: '$selectedPlanet BAV',
          values: bav,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _ScoreGrid(values: bav),
        const SizedBox(height: 18),
        _AshtakavargaSouthChart(
          title: '$selectedPlanet — Trikona Shodhana',
          values: result.arithmetic.afterTrikona[selectedPlanet]!,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: '$selectedPlanet — Ekadhipatya Shodhana',
          values: result.arithmetic.afterEkadhipatya[selectedPlanet]!,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        Builder(builder: (context) {
          final practical = result.arithmetic.practicalPindas[selectedPlanet]!;
          final pvr = result.arithmetic.pvrPindas[selectedPlanet]!;
          return Card(
            color: Colors.white,
            surfaceTintColor: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$selectedPlanet — Pinda', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                  const SizedBox(height: 8),
                  Text('Practical: Rasi ${practical.rashiPinda} + Graha ${practical.grahaPinda} = Shodhya ${practical.shodhyaPinda}'),
                  Text('PVR: Rasi ${pvr.rashiPinda} + Graha ${pvr.grahaPinda} = Shodhya ${pvr.shodhyaPinda}'),
                ],
              ),
            ),
          );
        }),
        const SizedBox(height: 18),
        const _SectionTitle('Prastara Ashtakavarga'),
        const SizedBox(height: 8),
        const Text(
          'ఎంచుకున్న గ్రహం BAV లో 7 గ్రహాలు + లగ్నం నుంచి ఏ రాశికి bindu వచ్చిందో 1/0 రూపంలో చూపిస్తుంది.',
        ),
        const SizedBox(height: 8),
        _PrastaraTable(rows: prastara),
        const SizedBox(height: 10),
        _PrastaraWhyPanel(
          planet: selectedPlanet,
          rows: prastara,
          values: bav,
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}



class _AshtakavargaArithmeticPanel extends StatelessWidget {
  final AstroChartResult chart;
  final AshtakavargaResult av;

  const _AshtakavargaArithmeticPanel({
    required this.chart,
    required this.av,
  });

  @override
  Widget build(BuildContext context) {
    final a = av.arithmetic;
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        initiallyExpanded: true,
        leading: Icon(
          a.auditValid && av.totalsValid
              ? Icons.verified_outlined
              : Icons.warning_amber_outlined,
          color: a.auditValid && av.totalsValid
              ? const Color(0xFF1B7F3A)
              : const Color(0xFFB3261E),
        ),
        title: const Text(
          'అష్టకవర్గ Arithmetic Engine',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          a.auditValid && av.totalsValid
              ? 'BAV → SAV → త్రికోణ శోధన → ఏకాధిపత్య శోధన → పిండ గణితం: PASS'
              : 'Arithmetic auditలో తేడా ఉంది — values verify చేయాలి',
        ),
        children: [
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'లగ్నం నుండి 1–12 భావాల SAV',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: List.generate(12, (i) {
                    return Chip(label: Text('${i + 1}: ${a.savByHouse[i]}'));
                  }),
                ),
                const SizedBox(height: 16),
                const Text(
                  'గ్రహాల పూర్తి arithmetic',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columnSpacing: 18,
                    columns: const [
                      DataColumn(label: Text('గ్రహం')),
                      DataColumn(label: Text('BAV')),
                      DataColumn(label: Text('జన్మ బిందు')),
                      DataColumn(label: Text('భావం')),
                      DataColumn(label: Text('Trikona')),
                      DataColumn(label: Text('Ekadhi.')),
                      DataColumn(label: Text('Rasi P')),
                      DataColumn(label: Text('Graha P')),
                      DataColumn(label: Text('Shodhya P')),
                    ],
                    rows: AshtakavargaService.planetOrder.map((planet) {
                      final tri = a.afterTrikona[planet]!
                          .fold<int>(0, (sum, value) => sum + value);
                      final eka = a.afterEkadhipatya[planet]!
                          .fold<int>(0, (sum, value) => sum + value);
                      final p = a.practicalPindas[planet]!;
                      return DataRow(cells: [
                        DataCell(Text(planet)),
                        DataCell(Text('${av.totalFor(planet)}')),
                        DataCell(Text('${a.natalBavScore[planet]}')),
                        DataCell(Text('${a.natalHouse[planet]}')),
                        DataCell(Text('$tri')),
                        DataCell(Text('$eka')),
                        DataCell(Text('${p.rashiPinda}')),
                        DataCell(Text('${p.grahaPinda}')),
                        DataCell(Text('${p.shodhyaPinda}')),
                      ]);
                    }).toList(),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Pinda practical profile: Rāśi multipliersలో Virgo=5. PVR profile (Virgo=6) కూడా engineలో విడిగా లెక్కించబడుతుంది; రెండు విధానాలు mix చేయబడవు.',
                  style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                ),
                const SizedBox(height: 16),
                const Text(
                  'SAV group arithmetic',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                ...a.groupSums.entries.map(
                  (e) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(
                      children: [
                        Expanded(child: Text(e.key)),
                        Text('${e.value}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Kakshya arithmetic: ప్రతి రాశి 8 సమ భాగాలు; ఒక్కో భాగం 3°45′. Transit longitude ఇచ్చినప్పుడు engine 1–8 Kakshya index మరియు ఆ రాశిలో BAV/SAV bindusను నేరుగా తీసుకోగలదు.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}




class _AshtakavargaLifeMirrorPanel extends StatelessWidget {
  final AshtakavargaResult av;

  const _AshtakavargaLifeMirrorPanel({required this.av});

  ({String label, int sum, int count}) _group(String key, String label, int count) =>
      (label: label, sum: av.arithmetic.groupSums[key] ?? 0, count: count);

  Color _color(double avg) {
    if (avg >= 28) return const Color(0xFF1B7F3A);
    if (avg < 25) return const Color(0xFFB3261E);
    return const Color(0xFF8A5A00);
  }

  String _status(double avg) {
    if (avg >= 28) return 'Strong';
    if (avg < 25) return 'Weak / caution';
    return 'Medium';
  }

  @override
  Widget build(BuildContext context) {
    final groups = [
      _group('Dhana 2+11', 'ధనం / లాభం', 2),
      _group('Education 5+9', 'విద్య / ఉన్నత విద్య', 2),
      _group('Career 6+10+11+12', 'వృత్తి / ఉద్యోగం', 4),
      _group('Upachaya 3+6+10+11', 'వృద్ధి / Upachaya', 4),
      _group('Kendra 1+4+7+10', 'కేంద్ర బలం', 4),
      _group('Kona 1+5+9', 'కోణ బలం', 3),
    ];
    final income = av.arithmetic.groupSums['Income set 1+2+4+9+10+11'] ?? 0;
    final expense = av.arithmetic.groupSums['Expense set 6+8+12'] ?? 0;
    final independentA = av.arithmetic.groupSums['Independent A 1+5+9'] ?? 0;
    final independentB = av.arithmetic.groupSums['Independent B 2+6+10'] ?? 0;
    final inner = av.arithmetic.groupSums['Inner A 1+4+5+7+9+10'] ?? 0;
    final outer = av.arithmetic.groupSums['Outer B 2+3+6+8+11+12'] ?? 0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle('Life Mirror — అష్టకవర్గ సారాంశం'),
        const SizedBox(height: 8),
        const Text(
          'Raw totalsను మాత్రమే కాకుండా ప్రతి life-areaలో house-average strengthను చూపిస్తుంది. ఇది supporting evidence మాత్రమే; standalone prediction కాదు.',
        ),
        const SizedBox(height: 10),
        ...groups.map((g) {
          final avg = g.sum / g.count;
          final color = _color(avg);
          return Card(
            color: Colors.white,
            surfaceTintColor: Colors.transparent,
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(
                avg >= 28
                    ? Icons.check_circle
                    : avg < 25
                        ? Icons.cancel
                        : Icons.info,
                color: color,
              ),
              title: Text(g.label, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Total ${g.sum} • Average ${avg.toStringAsFixed(1)}'),
              trailing: Text(_status(avg), style: TextStyle(color: color, fontWeight: FontWeight.bold)),
            ),
          );
        }),
        Card(
          color: const Color(0xFFFFF8F3),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Group comparisons', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Income set: $income • Expense set: $expense • ${income > expense ? 'Income side stronger' : 'Expense/pressure side stronger or equal'}'),
                const SizedBox(height: 5),
                Text('Independent A: $independentA • B: $independentB • ${independentA > independentB ? 'Independent tendency support' : 'Mixed/dependent tendency'}'),
                const SizedBox(height: 5),
                Text('Inner A: $inner • Outer B: $outer • ${inner > outer ? 'Inner/dharma side stronger' : 'Outer/practical side equal or stronger'}'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _AshtakavargaEventEvidencePanel extends StatefulWidget {
  final BirthData birthData;
  final AstroChartResult natalChart;
  final AshtakavargaResult av;

  const _AshtakavargaEventEvidencePanel({
    required this.birthData,
    required this.natalChart,
    required this.av,
  });

  @override
  State<_AshtakavargaEventEvidencePanel> createState() =>
      _AshtakavargaEventEvidencePanelState();
}

class _AshtakavargaEventEvidencePanelState
    extends State<_AshtakavargaEventEvidencePanel> {
  late final DateTime _asOfLocal;
  late final Future<AstroChartResult> _transitFuture;

  @override
  void initState() {
    super.initState();
    final nowUtc = DateTime.now().toUtc();
    final offsetMinutes = (widget.birthData.timezoneOffsetHours * 60).round();
    _asOfLocal = nowUtc.add(Duration(minutes: offsetMinutes));
    final transitData = BirthData(
      name: widget.birthData.name,
      localDateTime: _asOfLocal,
      place: widget.birthData.place,
      latitude: widget.birthData.latitude,
      longitude: widget.birthData.longitude,
      timezoneOffsetHours: widget.birthData.timezoneOffsetHours,
      ayanamsa: widget.birthData.ayanamsa,
      gender: widget.birthData.gender,
    );
    _transitFuture = AstroCalculationService.calculate(transitData);
  }

  Color _toneColor(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => const Color(0xFF1B7F3A),
        AvTimingTone.unfavorable => const Color(0xFFB3261E),
        AvTimingTone.neutral => const Color(0xFF8A5A00),
        AvTimingTone.info => const Color(0xFF355E8A),
        AvTimingTone.restricted => const Color(0xFF5F6368),
      };

  IconData _toneIcon(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => Icons.check_circle,
        AvTimingTone.unfavorable => Icons.cancel,
        AvTimingTone.neutral => Icons.info_outline,
        AvTimingTone.info => Icons.schedule_outlined,
        AvTimingTone.restricted => Icons.shield_outlined,
      };

  void _showEvidenceDetail(BuildContext context, AvEventEvidence item) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.78,
        minChildSize: 0.45,
        maxChildSize: 0.95,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.viewPaddingOf(context).bottom + 40,
          ),
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.title,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              item.finalResult,
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: _toneColor(item.tone),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'App evidence layers: ${item.evidenceLayersPassed}/${item.evidenceLayersTotal}. ఇది classical probability % కాదు.',
              style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
            ),
            const Divider(height: 30),
            const Text('1. జాతక / భావ బలం', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.houseEvidence),
            const Divider(height: 26),
            const Text('2. దశా పరిశీలన', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.dashaEvidence),
            const Divider(height: 26),
            const Text('3. ప్రస్తుత గోచార BAV/SAV', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.transitEvidence),
            const Divider(height: 26),
            const Text('4. Timing support', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.timingEvidence),
            const Divider(height: 26),
            const Text('రూల్స్', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.ruleIds),
            const SizedBox(height: 14),
            const Text(
              'Final label అనేది house + dasha + current transit అనే evidence layersను కలిపిన app summary. Bindusను నేరుగా percentageగా మార్చడం లేదు.',
              style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
            ),
          ],
        ),
      ),
    );
  }

  String _eventYearVector(List<AvEventYearPathNode> nodes) => nodes
      .map((n) => '${n.signNumber}: BAV ${n.planetBav}, SAV ${n.sav}')
      .join('  •  ');

  Widget _eventYearSourceTrace() {
    final traces = AshtakavargaEventYearService.evaluate(
      chart: widget.natalChart,
      av: widget.av,
    );
    return Card(
      color: const Color(0xFFFFF8E8),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Event Year / Age — AV-008/AV-009 source trace',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            const Text(
              'ప్రస్తుతం sourceలో స్పష్టంగా ఉన్న దశలవరకు మాత్రమే చూపిస్తున్నాం. Final age/yearను ఊహించి తయారు చేయము.',
            ),
            const SizedBox(height: 8),
            const Text(
              'Sourceలో స్పష్టమైన భాగం: Lagna → planet bindu-based values, planet → Lagna bindu-based values; తరువాత రెండు resultsను combine చేసి eventful age పొందాలి. కానీ ఆ final combine/conversion operator ప్రస్తుతం supplied source summaryలో లేదు.',
              style: TextStyle(fontSize: 12),
            ),
            const Divider(height: 22),
            ...traces.map(
              (trace) => ExpansionTile(
                tilePadding: EdgeInsets.zero,
                childrenPadding: const EdgeInsets.only(bottom: 12),
                title: Text(
                  trace.planet,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  'Lagna ${trace.lagnaSignNumber} → Planet ${trace.planetSignNumber} → Lagna',
                ),
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '1. Lagna → ${trace.planet}: ${_eventYearVector(trace.lagnaToPlanet)}',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '2. ${trace.planet} → Lagna: ${_eventYearVector(trace.planetToLagna)}',
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '3. Final age conversion: SOURCE-PENDING — combine operator / reduction / recurrence interval స్పష్టంగా లేనందున ageను emit చేయడం లేదు.',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'AV-009: AV-008 final age source-confirm అయిన తరువాత మాత్రమే repeat-event windows tabulate చేస్తాం. ఇప్పుడే recurrence years ఊహించము.',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Rule: AV-008 / AV-009',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AstroChartResult>(
      future: _transitFuture,
      builder: (context, snapshot) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _SectionTitle('Event Evidence — దశ + అష్టకవర్గ + గోచారం'),
            const SizedBox(height: 8),
            Text(
              'తేదీ: ${AstroFormat.dateTime(_asOfLocal)} • ${AstroFormat.timezoneOffset(widget.birthData.timezoneOffsetHours)}',
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 10),
            if (snapshot.connectionState != ConnectionState.done)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Row(
                    children: [
                      SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                      SizedBox(width: 12),
                      Expanded(child: Text('ప్రస్తుత గోచారాన్ని Swiss Ephemerisతో లెక్కిస్తున్నాం…')),
                    ],
                  ),
                ),
              )
            else if (snapshot.hasError || !snapshot.hasData)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text('ప్రస్తుత గోచార layer load కాలేదు: ${snapshot.error ?? 'unknown error'}'),
                ),
              )
            else
              ...AshtakavargaEventEvidenceService.evaluate(
                birthData: widget.birthData,
                natalChart: widget.natalChart,
                transitChart: snapshot.data!,
                av: widget.av,
                asOfLocal: _asOfLocal,
              ).map((item) {
                final color = _toneColor(item.tone);
                return Card(
                  color: Colors.white,
                  surfaceTintColor: Colors.transparent,
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: Icon(_toneIcon(item.tone), color: color),
                    title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(
                      '${item.finalResult} • Evidence ${item.evidenceLayersPassed}/${item.evidenceLayersTotal}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _showEvidenceDetail(context, item),
                  ),
                );
              }),
            const SizedBox(height: 4),
            _eventYearSourceTrace(),
          ],
        );
      },
    );
  }
}

class _AshtakavargaPlanetTimingPanel extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult chart;
  final AshtakavargaResult av;

  const _AshtakavargaPlanetTimingPanel({
    required this.birthData,
    required this.chart,
    required this.av,
  });

  static const Map<String, String> _planetUse = {
    'Sun': 'అధికారం • పదవి • నాయకత్వం • తండ్రి-సంబంధ support',
    'Moon': 'మనస్సు • తల్లి • ప్రజలు • ప్రయాణ/ప్రజా సంబంధ support',
    'Mars': 'సోదరులు • భూమి • చర్య • ధైర్యం • లాభ trigger',
    'Mercury': 'విద్య • వృత్తి • వ్యాపారం • కమ్యూనికేషన్',
    'Jupiter': 'సంతానం • విద్య • ధనం • గురుత్వం',
    'Venus': 'వివాహం • భాగస్వామ్యం • సుఖాలు • సంబంధాలు',
    'Saturn': 'ఉద్యోగం • శ్రమ • స్థిరత్వం • దీర్ఘకాల బాధ్యతలు',
  };

  static const Map<String, String> _planetTimingUse = {
    'Sun': 'Sourceలో safe layerగా దిక్కు, 1–12 support, Kakshyaని ఉపయోగించాలి. Sensitive deterministic timingను app final eventగా చూపదు.',
    'Moon': 'దిక్కు, 1–12 support, Kakshyaని సహాయక timing layerగా ఉపయోగించాలి. Sensitive deterministic timingను app final eventగా చూపదు.',
    'Mars': 'సోదర/లాభ eventకు source arithmetic trigger ఉంటే, దశ supportతో కలిపి transit confirmationగా చూడాలి.',
    'Mercury': 'వృత్తి/వ్యాపారం, విద్య/ఆర్థిక వృద్ధి triggersను దశ + transit supportతో కలిపి చూడాలి.',
    'Jupiter': 'సంతాన eventకు నక్షత్ర/సౌర మాస triggerను దశ + గురు transit confirmationతో కలిపి చూడాలి.',
    'Venus': 'వివాహ eventకు నక్షత్ర/సౌర మాస triggerను దశ-అంతర్దశ + transit confirmationతో కలిపి చూడాలి.',
    'Saturn': 'దిక్కు, 1–12 support, Kakshyaని దీర్ఘకాల timing supportగా ఉపయోగించాలి. Sensitive deterministic timingను app final eventగా చూపదు.',
  };

  void _showUsageGuide(BuildContext context, AvPlanetTimingProfile profile) {
    final top3 = profile.monthSupport.take(3).toList(growable: false);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFFFFAF7),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.78,
          minChildSize: 0.45,
          maxChildSize: 0.94,
          builder: (context, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
            children: [
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: const Color(0xFF8B1E2D).withOpacity(0.30),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                '${profile.planetTe} (${profile.planet}) — ఎలా ఉపయోగించాలి',
                style: const TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF3B2327),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _planetUse[profile.planet] ?? '',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 16),
              _UsageGuideStep(
                number: 1,
                title: 'ముందుగా Event Promise చూడండి',
                body: 'జాతకంలో సంబంధిత భావాలు/గ్రహాలు eventకు support చేస్తున్నాయా చూడాలి. అష్టకవర్గం ఒక్కదానితో final event నిర్ణయించవద్దు.',
              ),
              _UsageGuideStep(
                number: 2,
                title: 'దశా support కలపండి',
                body: 'ప్రస్తుత మహాదశ–అంతర్దశ–ప్రత్యంతర్దశలో సంబంధిత గ్రహం లేదా భావ సంబంధం ఉందా చూడండి.',
              ),
              _UsageGuideStep(
                number: 3,
                title: 'BAV + SAV బలం చదవండి',
                body: 'BAV 5 లేదా ఎక్కువ + SAV 28 లేదా ఎక్కువ అయితే app Green supportగా చూపిస్తుంది. BAV 4 లేదా మధ్యస్థ SAV అయితే mixed; BAV 1–3 లేదా SAV 25 కంటే తక్కువైతే cautionగా చూపిస్తుంది.',
              ),
              _UsageGuideStep(
                number: 4,
                title: 'దిక్కు బలం ఉపయోగించండి',
                body: 'ప్రస్తుత chartలో ప్రధాన దిక్కు: ${profile.strongestDirections.join(' / ')}. బలహీన దిక్కు: ${profile.weakestDirections.join(' / ')}. Eventకు travel/direction సంబంధం ఉన్నప్పుడు ఇది secondary support.',
              ),
              _UsageGuideStep(
                number: 5,
                title: 'Top transit indices చూడండి',
                body: 'Top 3: ${top3.map((m) => '${m.monthNumber} (BAV ${m.bavBindus}, SAV ${m.savBindus})').join(' • ')}. 1–12 అనేవి calendar నెల పేర్లు కాదు; సౌర మాస/రాశి సూచికలు.',
              ),
              _UsageGuideStep(
                number: 6,
                title: 'Kakshyaతో finer timing',
                body: '${profile.kakshyaDuration}. ముందుగా దశ + transit support సరిపోతే, తరువాత Kakshyaని finer timing layerగా ఉపయోగించండి.',
              ),
              _UsageGuideStep(
                number: 7,
                title: 'Source Event Timing చివరలో చూడండి',
                body: _planetTimingUse[profile.planet] ?? '',
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8E4E6),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF8B1E2D).withOpacity(0.24)),
                ),
                child: const Text(
                  'సరైన క్రమం: జాతక promise → దశ → BAV/SAV → transit index → దిక్కు → Kakshya → source event arithmetic → final judgment.',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showTransitCalendar(
    BuildContext context,
    AvPlanetTimingProfile profile,
  ) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFFFFAF7),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (context) => _AvTransitCalendarSheet(
        birthData: birthData,
        av: av,
        profile: profile,
      ),
    );
  }

  Color _toneColor(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => const Color(0xFF1B7F3A),
        AvTimingTone.unfavorable => const Color(0xFFB3261E),
        AvTimingTone.neutral => const Color(0xFF8A5A00),
        AvTimingTone.info => const Color(0xFF355E8A),
        AvTimingTone.restricted => const Color(0xFF5F6368),
      };

  IconData _toneIcon(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => Icons.check_circle,
        AvTimingTone.unfavorable => Icons.cancel,
        AvTimingTone.neutral => Icons.info_outline,
        AvTimingTone.info => Icons.schedule_outlined,
        AvTimingTone.restricted => Icons.shield_outlined,
      };

  @override
  Widget build(BuildContext context) {
    final profiles = AshtakavargaTimingService.evaluate(chart: chart, av: av);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle('గ్రహవారీ దిక్కు • మాసం • Event Timing'),
        const SizedBox(height: 8),
        const Text(
          'ప్రతి గ్రహానికి BAV/SAV ఆధారంగా బలమైన దిక్కు, 1–12 సౌర మాస/రాశి support, Kakshya కాలం మరియు sourceలో స్పష్టంగా ఉన్న event timing arithmetic చూపిస్తుంది. రాశి పేర్లు కాకుండా సంఖ్యలు మాత్రమే చూపిస్తాం.',
        ),
        const SizedBox(height: 6),
        const Text(
          'గమనిక: 1–12 = సౌర మాస/రాశి సూచిక; 1–27 = నక్షత్ర సూచిక. “Calendar windows” టచ్ చేస్తే Swiss Ephemerisతో ఆ సూచికలు ఏ actual తేదీ/సమయంలో వస్తాయో చూపిస్తుంది.',
          style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
        ),
        const SizedBox(height: 12),
        Card(
          color: const Color(0xFFFFF4F4),
          surfaceTintColor: Colors.transparent,
          child: ExpansionTile(
            leading: const Icon(Icons.menu_book_outlined, color: Color(0xFF8B1E2D)),
            title: const Text(
              'అష్టకవర్గ timing — ఎలా ఉపయోగించాలి',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: const Text('జాతక promise → దశ → BAV/SAV → transit → దిక్కు → Kakshya'),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
            children: const [
              Text(
                '1) ముందుగా event జాతకంలో promise ఉందా చూడండి. 2) ప్రస్తుత దశ support చూడండి. 3) సంబంధిత గ్రహం BAV/SAV బలం చూడండి. 4) Top transit index మరియు దిక్కు support కలపండి. 5) Kakshyaతో windowని narrow చేయండి. 6) Source arithmetic ఉన్న eventలకు మాత్రమే formula outputను confirmationగా ఉపయోగించండి.',
              ),
              SizedBox(height: 8),
              Text(
                'Green = అనుకూల support • Amber = mixed • Red = caution • Blue = timing/info • Grey = restricted/sensitive source rule.',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        ...profiles.map((profile) {
          final top3 = profile.monthSupport.take(3).toList(growable: false);
          final best = top3.first;
          return Card(
            color: Colors.white,
            surfaceTintColor: Colors.transparent,
            margin: const EdgeInsets.only(bottom: 12),
            child: ExpansionTile(
              initiallyExpanded: profile.planet == 'Sun',
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFF8E4E6),
                foregroundColor: const Color(0xFF8B1E2D),
                child: Text(profile.planet.substring(0, 2)),
              ),
              title: Text(
                '${profile.planetTe} (${profile.planet})',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'ముఖ్య దిక్కు: ${profile.strongestDirections.join(' / ')} • టాప్ మాసం: ${best.monthNumber}',
              ),
              children: [
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          Chip(
                            avatar: const Icon(Icons.explore_outlined, size: 18),
                            label: Text('దిక్కు: ${profile.strongestDirections.join(' / ')}'),
                          ),
                          Chip(
                            avatar: const Icon(Icons.navigation_outlined, size: 18),
                            label: Text('8-దిక్కు support: ${profile.eightDirection}'),
                          ),
                          Chip(
                            avatar: const Icon(Icons.calendar_month_outlined, size: 18),
                            label: Text('సౌర మాసం: ${best.monthNumber}'),
                          ),
                          Chip(
                            avatar: const Icon(Icons.timelapse_outlined, size: 18),
                            label: Text(profile.kakshyaDuration),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          OutlinedButton.icon(
                            onPressed: () => _showUsageGuide(context, profile),
                            icon: const Icon(Icons.help_outline),
                            label: const Text('ఎలా ఉపయోగించాలి'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF8B1E2D),
                              side: const BorderSide(color: Color(0xFF8B1E2D)),
                            ),
                          ),
                          FilledButton.icon(
                            onPressed: () => _showTransitCalendar(context, profile),
                            icon: const Icon(Icons.event_available_outlined),
                            label: const Text('Calendar windows'),
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF8B1E2D),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'దిశా బలం — R4.19',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      ...profile.directions.map((d) {
                        final isHigh = profile.strongestDirections.contains(d.direction);
                        final isLow = profile.weakestDirections.contains(d.direction);
                        final color = isHigh
                            ? const Color(0xFF1B7F3A)
                            : isLow
                                ? const Color(0xFFB3261E)
                                : const Color(0xFF5F6368);
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Row(
                            children: [
                              Icon(
                                isHigh
                                    ? Icons.check_circle_outline
                                    : isLow
                                        ? Icons.remove_circle_outline
                                        : Icons.circle_outlined,
                                size: 18,
                                color: color,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  '${d.direction} — ${d.signNumbers.join(', ')}',
                                ),
                              ),
                              Text(
                                '${d.score}',
                                style: TextStyle(fontWeight: FontWeight.bold, color: color),
                              ),
                            ],
                          ),
                        );
                      }),
                      const SizedBox(height: 10),
                      Text(
                        'బలహీన దిక్కు: ${profile.weakestDirections.join(' / ')}',
                        style: const TextStyle(color: Color(0xFFB3261E)),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'టాప్ 3 మాస / transit support',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      ...top3.map((m) {
                        final color = _toneColor(m.tone);
                        return ListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(_toneIcon(m.tone), color: color),
                          title: Text('మాస సూచిక ${m.monthNumber}'),
                          subtitle: Text('BAV ${m.bavBindus}/8 • SAV ${m.savBindus}'),
                        );
                      }),
                      ExpansionTile(
                        tilePadding: EdgeInsets.zero,
                        childrenPadding: EdgeInsets.zero,
                        title: const Text(
                          '12 మాసాల పూర్తి support',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        children: [
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: (([...profile.monthSupport]
                                  ..sort((a, b) => a.monthNumber.compareTo(b.monthNumber))))
                                .map((m) => Chip(
                                      avatar: Icon(
                                        _toneIcon(m.tone),
                                        size: 16,
                                        color: _toneColor(m.tone),
                                      ),
                                      label: Text('${m.monthNumber}: ${m.bavBindus}/${m.savBindus}'),
                                    ))
                                .toList(),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Event timing — source arithmetic',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      ...profile.eventTiming.map((event) {
                        final c = _toneColor(event.tone);
                        return Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: c.withOpacity(0.06),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: c.withOpacity(0.28)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(_toneIcon(event.tone), color: c, size: 20),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      event.item,
                                      style: const TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(event.result),
                              const SizedBox(height: 8),
                              Text(
                                'Formula: ${event.formula}',
                                style: const TextStyle(fontSize: 12),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                'Rule: ${event.ruleId}',
                                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}


class _AvTransitCalendarSheet extends StatefulWidget {
  final BirthData birthData;
  final AshtakavargaResult av;
  final AvPlanetTimingProfile profile;

  const _AvTransitCalendarSheet({
    required this.birthData,
    required this.av,
    required this.profile,
  });

  @override
  State<_AvTransitCalendarSheet> createState() => _AvTransitCalendarSheetState();
}

class _AvTransitCalendarSheetState extends State<_AvTransitCalendarSheet> {
  late int _year;
  late Future<List<AvTransitWindow>> _future;

  @override
  void initState() {
    super.initState();
    final nowUtc = DateTime.now().toUtc();
    final offset = Duration(
      minutes: (widget.birthData.timezoneOffsetHours * 60).round(),
    );
    _year = nowUtc.add(offset).year;
    _reload();
  }

  void _reload() {
    _future = AshtakavargaTransitWindowService.supportedWindowsForYear(
      birthData: widget.birthData,
      av: widget.av,
      planet: widget.profile.planet,
      year: _year,
    );
  }

  void _changeYear(int delta) {
    setState(() {
      _year += delta;
      _reload();
    });
  }

  Color _toneColor(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => const Color(0xFF1B7F3A),
        AvTimingTone.unfavorable => const Color(0xFFB3261E),
        AvTimingTone.neutral => const Color(0xFF8A5A00),
        AvTimingTone.info => const Color(0xFF355E8A),
        AvTimingTone.restricted => const Color(0xFF5F6368),
      };

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.88,
        minChildSize: 0.55,
        maxChildSize: 0.96,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
          children: [
            Center(
              child: Container(
                width: 42,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFF8B1E2D).withOpacity(0.28),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              '${widget.profile.planetTe} — Swiss Ephemeris Calendar Windows',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              'Top 3 BAV/SAV support సూచికలు actual calendarలో ఎప్పుడు వస్తాయో చూపిస్తుంది. Time zone: ${AstroFormat.timezoneOffset(widget.birthData.timezoneOffsetHours)}.',
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                IconButton(
                  onPressed: () => _changeYear(-1),
                  icon: const Icon(Icons.chevron_left),
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      '$_year',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => _changeYear(1),
                  icon: const Icon(Icons.chevron_right),
                ),
              ],
            ),
            const SizedBox(height: 8),
            FutureBuilder<List<AvTransitWindow>>(
              future: _future,
              builder: (context, snapshot) {
                if (snapshot.connectionState != ConnectionState.done) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 36),
                    child: Column(
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 12),
                        Text('Transit ingress/egress times లెక్కిస్తున్నాం…'),
                      ],
                    ),
                  );
                }
                if (snapshot.hasError) {
                  return Text('Calendar calculation error: ${snapshot.error}');
                }
                final windows = snapshot.data ?? const <AvTransitWindow>[];
                if (windows.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text('ఈ సంవత్సరంలో selected top-support signsకు transit window దొరకలేదు.'),
                  );
                }
                return Column(
                  children: windows.map((w) {
                    final c = _toneColor(w.tone);
                    return Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: c.withOpacity(0.055),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: c.withOpacity(0.30)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.event_available_outlined, color: c, size: 20),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'సూచిక ${w.signNumber} • BAV ${w.bavBindus}/8 • SAV ${w.savBindus}',
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 7),
                          Text('Start: ${AstroFormat.dateTime(w.startLocal)}'),
                          Text('End:   ${AstroFormat.dateTime(w.endLocal)}'),
                          const SizedBox(height: 5),
                          Text(
                            'Entry Kakshya: ${w.entryKakshya}/8 • ${w.retrogradeAtEntry ? 'Retrograde entry' : 'Direct entry'}',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                );
              },
            ),
            const SizedBox(height: 10),
            const Text(
              'ఈ calendar layer sourceలోని BAV/SAV support indicesను Swiss Ephemeris actual ingress/egress datesకు map చేస్తుంది. ఇది స్వతంత్ర event prediction కాదు; దశ + natal promiseతో కలిపి ఉపయోగించాలి.',
              style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
            ),
          ],
        ),
      ),
    );
  }
}

class _UsageGuideStep extends StatelessWidget {
  final int number;
  final String title;
  final String body;

  const _UsageGuideStep({
    required this.number,
    required this.title,
    required this.body,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 13),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
              color: Color(0xFF8B1E2D),
              shape: BoxShape.circle,
            ),
            child: Text(
              '$number',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(body),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AshtakavargaJatakaResults extends StatelessWidget {
  final AstroChartResult chart;
  final AshtakavargaResult av;

  const _AshtakavargaJatakaResults({
    required this.chart,
    required this.av,
  });

  Color _toneColor(AvFindingTone tone) => switch (tone) {
        AvFindingTone.favorable => const Color(0xFF1B7F3A),
        AvFindingTone.unfavorable => const Color(0xFFB3261E),
        AvFindingTone.neutral => const Color(0xFF8A5A00),
        AvFindingTone.pending => const Color(0xFF5F6368),
      };

  IconData _toneIcon(AvFindingTone tone) => switch (tone) {
        AvFindingTone.favorable => Icons.check_circle,
        AvFindingTone.unfavorable => Icons.cancel,
        AvFindingTone.neutral => Icons.info,
        AvFindingTone.pending => Icons.hourglass_bottom,
      };

  void _showDetail(BuildContext context, AvJatakaFinding item) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.72,
        minChildSize: 0.45,
        maxChildSize: 0.95,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: EdgeInsets.fromLTRB(20, 4, 20, MediaQuery.of(context).viewPadding.bottom + 64),
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.item,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text('పలితం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.result),
            const Divider(height: 30),
            const Text('రూల్', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.rule),
            const SizedBox(height: 5),
            Text('Rule ID: ${item.ruleId}', style: const TextStyle(fontWeight: FontWeight.w600)),
            const Divider(height: 30),
            const Text('జాతక పరిశీలన', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.inspection),
            const Divider(height: 30),
            const Text('మూలం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.source),
            if (item.category.contains('ఆయుర్దాయ') || item.category.contains('రోగ')) ...[
              const SizedBox(height: 14),
              const Text(
                'గమనిక: ఆరోగ్యం/ఆయుర్దాయ అంశాలు సాంప్రదాయ జ్యోతిష్య సూచనలుగా మాత్రమే చూపించబడతాయి; ఇవి వైద్య నిర్ధారణ లేదా జీవితకాల నిర్ణయం కాదు.',
                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = AshtakavargaInterpretationService.evaluate(chart: chart, av: av);
    final grouped = <String, List<AvJatakaFinding>>{};
    for (final item in items) {
      grouped.putIfAbsent(item.category, () => []).add(item);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle('జాతకానికి వర్తించిన అష్టకవర్గ ఫలితాలు'),
        const SizedBox(height: 8),
        const Text(
          'అన్ని అంశాలు వరుసగా చూపిస్తాయి. “పలితం” టచ్ చేస్తే రూల్ → జాతక పరిశీలన → మూలం తెరుచుకుంటాయి. Green = అనుకూలం, Red = ప్రతికూల/జాగ్రత్త, Amber = మధ్యస్థం, Grey = అదనపు source calculation అవసరం.',
        ),
        const SizedBox(height: 12),
        ...grouped.entries.map((entry) => Card(
          color: Colors.white,
          surfaceTintColor: Colors.transparent,
          margin: const EdgeInsets.only(bottom: 12),
          child: ExpansionTile(
            initiallyExpanded: entry.key == 'భావ బలం — వరుసగా 1 నుండి 12',
            title: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.bold)),
            children: entry.value.map((item) {
              final c = _toneColor(item.tone);
              return ListTile(
                leading: Icon(_toneIcon(item.tone), color: c),
                title: Text(item.item, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(item.result, maxLines: 2, overflow: TextOverflow.ellipsis),
                trailing: TextButton(
                  onPressed: () => _showDetail(context, item),
                  child: const Text('పలితం'),
                ),
                onTap: () => _showDetail(context, item),
              );
            }).toList(),
          ),
        )),
      ],
    );
  }
}

class _AshtakavargaSouthChart extends StatelessWidget {
  final String title;
  final List<int> values;
  final int ascendantSignIndex;

  const _AshtakavargaSouthChart({
    required this.title,
    required this.values,
    required this.ascendantSignIndex,
  });

  @override
  Widget build(BuildContext context) {
    final occupants = <int, List<String>>{
      for (var sign = 0; sign < 12; sign++) sign: ['${values[sign]}'],
    };
    return _SouthIndianChart(
      title: title,
      ascendantSignIndex: ascendantSignIndex,
      occupants: occupants,
    );
  }
}

class _PrastaraTable extends StatelessWidget {
  final Map<String, List<int>> rows;

  const _PrastaraTable({required this.rows});

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columnSpacing: 18,
          columns: [
            const DataColumn(label: Text('Ref')),
            ...List.generate(
              12,
              (index) => DataColumn(
                label: Text(
                  '${index + 1}',
                  style: const TextStyle(fontSize: 11),
                ),
              ),
            ),
          ],
          rows: rows.entries.map((entry) {
            return DataRow(
              cells: [
                DataCell(Text(entry.key)),
                ...entry.value.map((value) => DataCell(Text('$value'))),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}


class _PrastaraWhyPanel extends StatelessWidget {
  final String planet;
  final Map<String, List<int>> rows;
  final List<int> values;

  const _PrastaraWhyPanel({
    required this.planet,
    required this.rows,
    required this.values,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFFFF8F3),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        leading: const Icon(Icons.help_center_outlined, color: Color(0xFF8B1E2D)),
        title: Text('$planet BAV — “ఈ score ఎందుకు?”'),
        subtitle: const Text('ప్రతి 1–12 సూచికకు bindu ఇచ్చిన reference points చూడండి'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: List.generate(12, (sign) {
          final contributors = <String>[];
          final nonContributors = <String>[];
          for (final entry in rows.entries) {
            if (entry.value[sign] == 1) {
              contributors.add(entry.key);
            } else {
              nonContributors.add(entry.key);
            }
          }
          return ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: Text('సూచిక ${sign + 1} — ${values[sign]}/8'),
            childrenPadding: const EdgeInsets.only(left: 8, right: 8, bottom: 10),
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Bindu ✓: ${contributors.join(', ')}'),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Bindu లేదు: ${nonContributors.join(', ')}'),
              ),
            ],
          );
        }),
      ),
    );
  }
}

class _ScoreGrid extends StatelessWidget {
  final List<int> values;

  const _ScoreGrid({required this.values});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 2.2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: 12,
      itemBuilder: (context, index) {
        return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    '${index + 1}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                Text(
                  values[index].toString(),
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CalculationsTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;

  const _CalculationsTab({
    required this.birthData,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final p = VedicCalculationService.panchanga(result);
    final quickVargas = [1, 9, 10, 60]
        .map((factor) => VargaService.calculate(result, factor))
        .toList(growable: false);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Calculation / గణన విభాగం'),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'పంచాంగ గణనలు',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('పక్షం: ${p.paksha}'),
                Text('తిథి: ${p.tithi}'),
                Text('చంద్ర నక్షత్రం: ${p.nakshatra} • ${p.nakshatraPada} పాదం'),
                Text('యోగం: ${p.yoga}'),
                Text('కరణం: ${p.karana}'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Engine / Settings',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('Swiss Ephemeris: ${result.engineVersion}'),
                const Text('Planet mode: Sidereal + Moshier'),
                const Text('Node: True Rahu; Ketu = exact 180° opposite'),
                Text('Ayanamsa: ${birthData.ayanamsa.label}'),
                Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
                Text('Julian Day (UT): ${result.julianDay.toStringAsFixed(6)}'),
                Text('Lagna: ${AstroFormat.longitudeDms(result.ascendantLongitude)}'),
                const SizedBox(height: 6),
                const Text(
                  'House column below uses whole-sign houses from the Lagna sign.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const _SectionTitle('గ్రహ గణన పట్టిక'),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const [
              DataColumn(label: Text('Planet')),
              DataColumn(label: Text('Rasi')),
              DataColumn(label: Text('Longitude')),
              DataColumn(label: Text('Nakshatra')),
              DataColumn(label: Text('Pada')),
              DataColumn(label: Text('House')),
              DataColumn(label: Text('Motion')),
            ],
            rows: result.planets.map((planet) {
              final n = VedicCalculationService.nakshatra(planet.longitude);
              final house = VedicCalculationService.wholeSignHouse(
                planet.signIndex,
                result.ascendantSignIndex,
              );
              return DataRow(
                cells: [
                  DataCell(Text(planet.name)),
                  DataCell(Text('${planet.signIndex + 1}')),
                  DataCell(Text(AstroFormat.longitudeDms(planet.longitude))),
                  DataCell(Text(VedicCalculationService.nakshatraNamesTe[n.index])),
                  DataCell(Text('${n.pada}')),
                  DataCell(Text('$house')),
                  DataCell(Text(planet.retrograde ? 'Retrograde' : 'Direct')),
                ],
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 18),
        const _SectionTitle('Quick Varga Matrix'),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: [
              const DataColumn(label: Text('Planet')),
              ...quickVargas.map(
                (v) => DataColumn(label: Text(v.definition.code)),
              ),
            ],
            rows: result.planets.map((planet) {
              return DataRow(
                cells: [
                  DataCell(Text(planet.name)),
                  ...quickVargas.map((v) {
                    final placement =
                        v.planets.firstWhere((item) => item.name == planet.name);
                    return DataCell(
                      Text('${placement.signIndex + 1}'),
                    );
                  }),
                ],
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 14),
        const Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'ఈ versionలో verified core calculations, BAV/SAV, Prastara మరియు Gem Remedy కోసం Vimsopaka Varga Bala + SAV house-strength inputs చూపించబడుతున్నాయి. Gem sourceలో పూర్తి classical Shadbala/Bhava Bala arithmetic ఇవ్వబడలేదు కాబట్టి వాటిని classical Shadbala/Bhava Bala అని claim చేయము; Gem tabలో వాడిన strength inputs స్పష్టంగా చూపిస్తాం.',
            ),
          ),
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


class _SystemDrawer extends StatelessWidget {
  final _AstroSystem? selected;
  final ValueChanged<_AstroSystem> onSelect;
  final VoidCallback onMain;

  const _SystemDrawer({
    required this.selected,
    required this.onSelect,
    required this.onMain,
  });

  @override
  Widget build(BuildContext context) {
    const maroon = Color(0xFF7B1E2B);
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 20, 16, 18),
              color: maroon,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.menu_book_outlined, color: Colors.white, size: 34),
                  SizedBox(height: 10),
                  Text(
                    'అన్నపూర్ణ ఆస్ట్రో వాస్తు',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'జ్యోతిష్య విధానాలు',
                    style: TextStyle(color: Color(0xFFFFD7DD)),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  ListTile(
                    leading: const Icon(Icons.home_outlined),
                    title: const Text(
                      'ప్రధాన జాతకం',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    selected: selected == null,
                    selectedTileColor: const Color(0xFFFFF0F2),
                    onTap: () {
                      Navigator.pop(context);
                      onMain();
                    },
                  ),
                  const Divider(height: 12),
                  for (final system in _AstroSystem.values)
                    ListTile(
                      leading: Icon(system.icon, color: maroon),
                      title: Text(
                        system.title,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      selected: selected == system,
                      selectedTileColor: const Color(0xFFFFF0F2),
                      onTap: () {
                        Navigator.pop(context);
                        onSelect(system);
                      },
                    ),
                  const Divider(height: 18),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 4, 16, 18),
                    child: Text(
                      'గణిత ఫలితాలు verified rules ఉన్న modulesలో మాత్రమే చూపించబడతాయి. Source పూర్తి కాని systemలో ఊహా calculation చూపించము.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF65585A)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SystemDetailPage extends StatelessWidget {
  final _AstroSystem system;
  final BirthData birthData;
  final AstroChartResult result;
  final VoidCallback onBackToMain;

  const _SystemDetailPage({
    required this.system,
    required this.birthData,
    required this.result,
    required this.onBackToMain,
  });

  @override
  Widget build(BuildContext context) {
    final children = <Widget>[
      _SystemPageHeader(
        system: system,
        onBackToMain: onBackToMain,
      ),
      const SizedBox(height: 12),
    ];

    switch (system) {
      case _AstroSystem.dasha:
        children.add(
          _DashaSystemsCard(
            chart: result,
            birthDateTime: birthData.localDateTime,
          ),
        );
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'దశల పూర్తి విభాగం',
            items: [
              'త్రిభాగి 80 — S.K. Mehta',
              'వింశోత్తరి 120',
              'ఖండ దశ 40',
              'యోగిని 36',
              'జనన దశా balance',
              'మహాదశ / అంతర్దశ / ప్రత్యంతర్దశ',
              'సూక్ష్మ / ప్రాణ దశ',
              'ఏ తేదీకి అయినా 5-level దశా స్థితి',
              'ప్రతి level ప్రారంభం–ముగింపు తేదీలు',
              'ప్రస్తుత levelకి పూర్తి sub-period పట్టిక',
            ],
            note:
                'త్రిభాగి = Vimshottari duration × 2/3; ఖండ = ×1/3. Mehta timingలో 2–5 స్థాయులు (AD, PD, Sukshma, Prana) ముఖ్యంగా చూపించబడతాయి. Source ratiosను మార్చకుండా date engine reproducible civil-year conventionతో పని చేస్తుంది.',
          ),
        );
        break;

      case _AstroSystem.jaimini:
        final jai = JaiminiService.calculate(result);
        children.add(_JaiminiCard(result: jai, chart: result, birthData: birthData));
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'జైమిని విభాగం',
            items: [
              'Chara Karakas • Atmakaraka • Karakamsa',
              'Rashi Drishti • Argala / Virodha Argala',
              'Pada P1–P12 • P7/Darapada • P12/Upapada',
              'CD-01–CD-07 Chara Dasha calculation',
              'Method A / Method B / Custom',
              'Scorpio Mars/Ketu • Aquarius Saturn/Rahu configurable co-lords',
              'Actual Mahadasha + Antardasha calendar dates',
              'Marriage / Career / Children / Property / Wealth / Education / Foreign event engine',
              '100-point app decision-support score',
              'Rule ID → Condition → Matched/Not Matched → Score → Reason → Source audit',
              'Consultation: Vimshottari + Tribhagi + Chara MD/AD + Transit AV overlap',
              'Result touch → Rule audit → source-based remedy note',
            ],
            note:
                'Supplied Jaimini sourceలోని direction, sign-to-lord years, own-sign 12-year rule, exaltation/debilitation adjustment, co-lord handling మరియు Antardasha subdivisionను source-controlled variantsగా అమలు చేశాం. 100-point value classical probability కాదు; app decision-support score మాత్రమే. Sourceలో పరిహారం లేని చోట ఊహా remedy చూపించదు.',
          ),
        );
        break;

      case _AstroSystem.kp:
        children.add(_KpCard(rows: KpService.planetaryTable(result)));
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'KP పూర్తి నిర్మాణం',
            items: [
              'Planet Sign Lord',
              'Star Lord',
              'Sub Lord',
              '12 Cusps',
              'Cusp Star/Sub Lord',
              'Significators',
              'Ruling Planets',
              'Event house groups',
              'Promise / Denial',
              'Event timing',
            ],
            note:
                'Planetary Star/Sub arithmetic active. Exact cusp sub-lord/significator engine కోసం 12 cusp longitude calculation మరియు supplied KP source rulesను layer-by-layer validate చేసి మాత్రమే enable చేయాలి.',
          ),
        );
        break;

      case _AstroSystem.jamakola:
        children.add(
          _PendingSystemDetail(
            title: 'Jamakola',
            birthData: birthData,
            result: result,
            sections: [
              'జనన ఆధార గణన',
              'గ్రహ/భావ సంబంధ నియమాలు',
              'Event combinations',
              'Timing rules',
              'Rule → Result trace',
              'Final event report',
            ],
          ),
        );
        break;

      case _AstroSystem.tajik:
        children.add(
          _PendingSystemDetail(
            title: 'Tajik / Varshaphala',
            birthData: birthData,
            result: result,
            sections: [
              'Varsha Pravesha / annual chart',
              'Muntha',
              'Annual lord / Varshesha',
              'Tajik aspects',
              'Tajik yogas',
              'Sahams',
              'Annual timing & result',
            ],
          ),
        );
        break;

      case _AstroSystem.bcp:
        children.add(
          _PendingSystemDetail(
            title: 'BCP',
            birthData: birthData,
            result: result,
            sections: [
              'Source rule index',
              'Age / year activation',
              'Activated house/sign',
              'Planet/lord evidence',
              'Event rule trace',
              'Timing & final result',
            ],
          ),
        );
        break;

      case _AstroSystem.bsp:
        children.add(
          _BspCard(
            chart: result,
            birthData: birthData,
          ),
        );
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'BSP — source-linked year engine',
            items: [
              'Appendix-1లోని year → planet → implementation rules',
              '10, 18, 20, 22, 24, 25, 27, 28, 30, 32, 35, 36, 37, 38, 40, 48, 51, 66, 69 years',
              'BSP 37 Moon–Mars conjunction/opposition → 32/33 years',
              'Year touch → active BSP rules → implementation house → chart result',
              'Planet lordship + activated house + natural-karaka evidence',
              'Rule ID → source text → reason → source page audit',
              'Source scan unclear notation is flagged; not guessed',
            ],
            note:
                'BSP year period is calculated by birth anniversaries: Nth year = (N−1)th birthday నుంచి Nth birthday వరకు. Appendix implementation pointను natal chartలో house/signగా map చేసి, source worked-example styleలో house + lordship themesను స్పష్టంగా చూపిస్తుంది.',
          ),
        );
        break;

      case _AstroSystem.bnn:
        children.add(
          _BnnPanel(
            chart: result,
            birthData: birthData,
          ),
        );
        break;
    }

    children.add(const SizedBox(height: 28));
    return ListView(
      padding: const EdgeInsets.all(16),
      children: children,
    );
  }
}

class _SystemPageHeader extends StatelessWidget {
  final _AstroSystem system;
  final VoidCallback onBackToMain;

  const _SystemPageHeader({
    required this.system,
    required this.onBackToMain,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFFFF7F3),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: const Color(0xFF7B1E2B),
              foregroundColor: Colors.white,
              child: Icon(system.icon),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    system.title,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const Text(
                    'Rule → Calculation → Result',
                    style: TextStyle(color: Color(0xFF6E5D60)),
                  ),
                ],
              ),
            ),
            TextButton.icon(
              onPressed: onBackToMain,
              icon: const Icon(Icons.grid_view_outlined),
              label: const Text('జాతకం'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ModuleChecklistCard extends StatelessWidget {
  final String title;
  final List<String> items;
  final String note;

  const _ModuleChecklistCard({
    required this.title,
    required this.items,
    required this.note,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            for (final item in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.check_circle_outline,
                      size: 19,
                      color: Color(0xFF7B1E2B),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(item)),
                  ],
                ),
              ),
            const Divider(height: 20),
            Text(note, style: const TextStyle(fontSize: 12.5)),
          ],
        ),
      ),
    );
  }
}

class _PendingSystemDetail extends StatefulWidget {
  final String title;
  final List<String> sections;
  final BirthData birthData;
  final AstroChartResult result;

  const _PendingSystemDetail({
    required this.title,
    required this.sections,
    required this.birthData,
    required this.result,
  });

  @override
  State<_PendingSystemDetail> createState() => _PendingSystemDetailState();
}

class _PendingSystemDetailState extends State<_PendingSystemDetail> {
  int? _openIndex;

  String _signForLongitude(double longitude) {
    final index = ((longitude % 360) / 30).floor().clamp(0, 11);
    return '${index + 1}';
  }

  String _planetSummary() {
    return widget.result.planets
        .map((p) => '${p.shortName}:${p.signIndex + 1}')
        .join('  •  ');
  }

  void _copyContext() {
    final b = widget.birthData;
    final text = StringBuffer()
      ..writeln(widget.title)
      ..writeln('Name: ${b.name}')
      ..writeln('DOB/Time: ${AstroFormat.dateTime(b.localDateTime)}')
      ..writeln('Place: ${b.place}')
      ..writeln('Lagna: ${_signForLongitude(widget.result.ascendantLongitude)}')
      ..writeln('Planets: ${_planetSummary()}');
    Clipboard.setData(ClipboardData(text: text.toString()));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('జాతక calculation context copy అయింది')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lagna = _signForLongitude(widget.result.ascendantLongitude);
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.verified_user_outlined,
                  color: Color(0xFF7B1E2B),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${widget.title} — working module',
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'ఈ moduleలో navigation, birth-chart context మరియు ప్రతి విభాగం touch/expand ఇప్పుడు పనిచేస్తాయి. మీరు rules ఇచ్చిన తర్వాత మాత్రమే ఆ విభాగానికి exact rule calculation/result engine జోడిస్తాం; అప్పటివరకు ఊహా prediction చూపించము.',
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF0F2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE4C8CD)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'జాతక ఆధారం LOADED',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 5),
                  Text('పేరు: ${widget.birthData.name}'),
                  Text('లగ్నం: $lagna'),
                  Text('స్థలం: ${widget.birthData.place}'),
                  const SizedBox(height: 5),
                  Text(
                    _planetSummary(),
                    style: const TextStyle(fontSize: 12.5),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _copyContext,
                    icon: const Icon(Icons.copy_outlined, size: 18),
                    label: const Text('Calculation context copy'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            for (var i = 0; i < widget.sections.length; i++)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF7F3),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE4C8CD)),
                ),
                child: Theme(
                  data: Theme.of(context).copyWith(
                    dividerColor: Colors.transparent,
                    splashColor: const Color(0xFFFFE7EB),
                  ),
                  child: ExpansionTile(
                    key: PageStorageKey('${widget.title}-$i'),
                    initiallyExpanded: _openIndex == i,
                    onExpansionChanged: (open) {
                      setState(() => _openIndex = open ? i : null);
                    },
                    leading: const Icon(
                      Icons.chevron_right,
                      color: Color(0xFF7B1E2B),
                    ),
                    title: Text(
                      widget.sections[i],
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: const Chip(label: Text('READY')),
                    childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: const Color(0xFFEAD9DC)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: const [
                                Icon(
                                  Icons.check_circle_outline,
                                  size: 18,
                                  color: Color(0xFF7B1E2B),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  'Screen / input layer active',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '${widget.sections[i]} కోసం birth chart data సిద్ధంగా ఉంది. Rule source వచ్చిన తర్వాత Rule → Calculation → Result → Validation రూపంలో ఇదే sectionలో output చూపిస్తాం.',
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'RULE ENGINE: rules pending',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF8D3140),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}



class _ConsultationTab extends StatefulWidget {
  final BirthData birthData;
  final AstroChartResult result;
  final AshtakavargaResult av;
  final Future<void> Function() onSaveChart;

  const _ConsultationTab({
    required this.birthData,
    required this.result,
    required this.av,
    required this.onSaveChart,
  });

  @override
  State<_ConsultationTab> createState() => _ConsultationTabState();
}

class _ConsultationTabState extends State<_ConsultationTab> {
  late final DateTime _asOfLocal;
  late final Future<AstroChartResult> _transitFuture;

  @override
  void initState() {
    super.initState();
    final nowUtc = DateTime.now().toUtc();
    final offsetMinutes = (widget.birthData.timezoneOffsetHours * 60).round();
    _asOfLocal = nowUtc.add(Duration(minutes: offsetMinutes));
    _transitFuture = AstroCalculationService.calculate(
      BirthData(
        name: widget.birthData.name,
        localDateTime: _asOfLocal,
        place: widget.birthData.place,
        latitude: widget.birthData.latitude,
        longitude: widget.birthData.longitude,
        timezoneOffsetHours: widget.birthData.timezoneOffsetHours,
        ayanamsa: widget.birthData.ayanamsa,
        gender: widget.birthData.gender,
      ),
    );
  }

  Color _toneColor(ConsultationTone tone) => switch (tone) {
        ConsultationTone.strong => const Color(0xFF1B7F3A),
        ConsultationTone.caution => const Color(0xFFB3261E),
        ConsultationTone.moderate => const Color(0xFF8A5A00),
        ConsultationTone.info => const Color(0xFF355E8A),
      };

  IconData _toneIcon(ConsultationTone tone) => switch (tone) {
        ConsultationTone.strong => Icons.check_circle,
        ConsultationTone.caution => Icons.warning_amber_rounded,
        ConsultationTone.moderate => Icons.info_outline,
        ConsultationTone.info => Icons.fact_check_outlined,
      };

  String _toneLabel(ConsultationTone tone) => switch (tone) {
        ConsultationTone.strong => 'అనుకూల మద్దతు',
        ConsultationTone.caution => 'జాగ్రత్త',
        ConsultationTone.moderate => 'మధ్యస్థ / మిశ్రమం',
        ConsultationTone.info => 'సాంకేతిక సమాచారం',
      };

  String _reportText({
    required ConsultationOverallSummary overall,
    required ConsultationDashaSummary dasha,
    required List<ConsultationEventSummary> events,
    required List<ConsultationPlanetSummary> planets,
  }) {
    final b = StringBuffer()
      ..writeln('అన్నపూర్ణ ఆస్ట్రో వాస్తు — Client Consultation Summary')
      ..writeln('క్లయింట్: ${widget.birthData.name}')
      ..writeln('తేదీ: ${AstroFormat.dateTime(_asOfLocal)}')
      ..writeln('స్థలం: ${widget.birthData.place}')
      ..writeln('')
      ..writeln('Overall: ${overall.headline}')
      ..writeln('Strong ${overall.strongCount} • Mixed ${overall.mixedCount} • Caution ${overall.cautionCount}')
      ..writeln('')
      ..writeln('ప్రస్తుత దశలు:')
      ..writeln(dasha.vimshottari)
      ..writeln(dasha.tribhagi)
      ..writeln('')
      ..writeln('అంశాలవారీ ఫలితాలు:');
    for (final item in events) {
      b
        ..writeln('')
        ..writeln('${item.title} — ${_toneLabel(item.tone)}')
        ..writeln('పలితం: ${item.result}')
        ..writeln('క్లయింట్‌కు చెప్పండి: ${item.sayThis}')
        ..writeln('సలహా: ${item.practicalAdvice}')
        ..writeln('Evidence: ${item.evidencePassed}/${item.evidenceTotal}')
        ..writeln('Rule: ${item.ruleIds}');
    }
    b
      ..writeln('')
      ..writeln('గ్రహ బలం — quick reading:');
    for (final p in planets) {
      b.writeln('${p.planet}: ${p.strength.toStringAsFixed(2)}/20 • ${p.strengthLabel} • Star ${p.starLord} • Sub ${p.subLord}');
    }
    b
      ..writeln('')
      ..writeln('గమనిక: ఈ summary app evidence helper మాత్రమే. ఇది probability % కాదు; ఒక్క rule/ఒక్క varga ఆధారంగా deterministic prediction కాదు.');
    return b.toString();
  }

  void _showEventDetail(
    BuildContext context,
    ConsultationEventSummary item,
    JaiminiResult jaimini,
  ) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.82,
        minChildSize: 0.48,
        maxChildSize: 0.95,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      Text(_toneLabel(item.tone), style: TextStyle(fontWeight: FontWeight.w700, color: _toneColor(item.tone))),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _ConsultationInfoBox(
              icon: Icons.record_voice_over_outlined,
              title: 'క్లయింట్‌కు చెప్పండి',
              body: item.sayThis,
              color: const Color(0xFFEAF6EE),
            ),
            const SizedBox(height: 10),
            _ConsultationInfoBox(
              icon: Icons.lightbulb_outline,
              title: 'ప్రాక్టికల్ సలహా',
              body: item.practicalAdvice,
              color: const Color(0xFFFFF4DB),
            ),
            const SizedBox(height: 10),
            _ConsultationTimingFinder(
              item: item,
              birthData: widget.birthData,
              natalChart: widget.result,
              av: widget.av,
              asOfLocal: _asOfLocal,
              jaimini: jaimini,
            ),
            const SizedBox(height: 10),
            Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              child: ExpansionTile(
                title: const Text('ఎందుకు? — Evidence', style: TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${item.evidencePassed}/${item.evidenceTotal} evidence layers'),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                children: [
                  _ConsultationEvidenceRow('1. భావ బలం', item.houseEvidence),
                  _ConsultationEvidenceRow('2. దశ', item.dashaEvidence),
                  _ConsultationEvidenceRow('3. గోచారం', item.transitEvidence),
                  _ConsultationEvidenceRow('4. Timing support', item.timingEvidence),
                ],
              ),
            ),
            Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              child: ExpansionTile(
                title: const Text('Rule / Technical', style: TextStyle(fontWeight: FontWeight.w800)),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                children: [
                  Align(alignment: Alignment.centerLeft, child: Text(item.ruleIds)),
                  const SizedBox(height: 8),
                  const Text(
                    'Final label house + dasha + current transit evidenceను కలిపిన app summary. Bindusను probability percentageగా మార్చడం లేదు.',
                    style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: () async {
                final text = '${item.title}\n${item.sayThis}\nసలహా: ${item.practicalAdvice}';
                await Clipboard.setData(ClipboardData(text: text));
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Client script copy అయింది')),
                );
              },
              icon: const Icon(Icons.copy_all_outlined),
              label: const Text('ఈ Client Script Copy చేయండి'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _speakingOrderCard() {
    const steps = [
      ('1', 'ప్రస్తుత దశ', 'ముందుగా MD / AD / PD — ప్రస్తుతం ఏ గ్రహాల కాలం నడుస్తుందో చెప్పండి.'),
      ('2', 'బలమైన అంశాలు', 'Green cards ముందుగా చెప్పండి. క్లయింట్‌కు confidence ఇచ్చే supporting evidenceను సంక్షిప్తంగా చెప్పండి.'),
      ('3', 'మధ్యస్థ అంశాలు', 'Mixed support ఉన్న చోట “అవకాశం ఉంది, timing చూడాలి” అని చెప్పండి.'),
      ('4', 'జాగ్రత్త అంశాలు', 'Red cardను భయపెట్టేలా కాకుండా “తొందరపడకుండా practical verification చేయండి” అని చెప్పండి.'),
      ('5', 'Timing', 'దశ + గోచారం + BAV/SAV support సరిపోతేనే మంచి windowగా చెప్పండి.'),
      ('6', 'సలహా / పరిహారం', 'ముందుగా practical advice; source-supported remedy ఉంటే మాత్రమే పరిహారం చెప్పండి.'),
    ];
    return Card(
      color: const Color(0xFFFFF7F2),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        initiallyExpanded: true,
        leading: const Icon(Icons.format_list_numbered),
        title: const Text('క్లయింట్‌తో మాట్లాడే క్రమం', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('Consultationలో ఏది ముందు చెప్పాలో ready order'),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: steps.map((s) => Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(radius: 15, backgroundColor: const Color(0xFF8B1E2D), foregroundColor: Colors.white, child: Text(s.$1, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(s.$3, style: const TextStyle(fontSize: 12.5, color: Color(0xFF5F5052))),
              ])),
            ],
          ),
        )).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AstroChartResult>(
      future: _transitFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 12),
                Text('Consultation summary కోసం ప్రస్తుత గోచారం లెక్కిస్తున్నాం…'),
              ],
            ),
          );
        }
        if (snapshot.hasError || !snapshot.hasData) {
          return _ErrorView(message: 'Consultation transit layer: ${snapshot.error ?? 'unknown error'}');
        }

        final evidence = AshtakavargaEventEvidenceService.evaluate(
          birthData: widget.birthData,
          natalChart: widget.result,
          transitChart: snapshot.data!,
          av: widget.av,
          asOfLocal: _asOfLocal,
        );
        final events = ConsultationService.eventSummaries(evidence);
        final overall = ConsultationService.overall(events);
        final dasha = ConsultationService.dashaSummary(
          birthData: widget.birthData,
          chart: widget.result,
          asOfLocal: _asOfLocal,
        );
        final planets = widget.result.planets
            .map((p) => ConsultationService.planetSummary(chart: widget.result, planet: p))
            .toList(growable: false);
        final jaimini = JaiminiService.calculate(widget.result);
        final jaiminiFavorable = jaimini.applicableRules.where((r) => r.nature == JaiminiRuleNature.favorable).length;
        final jaiminiAdverse = jaimini.applicableRules.where((r) => r.nature == JaiminiRuleNature.adverse).length;
        final jaiminiYogas = jaimini.applicableRules.where((r) => r.isYoga).length;
        final report = _reportText(
          overall: overall,
          dasha: dasha,
          events: events,
          planets: planets,
        );

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                const Expanded(child: _SectionTitle('Client Consultation Mode')),
                IconButton(
                  tooltip: 'Copy summary',
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: report));
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Consultation summary copy అయింది')));
                  },
                  icon: const Icon(Icons.copy_all_outlined),
                ),
                IconButton(
                  tooltip: 'Share summary',
                  onPressed: () async {
                    await SharePlus.instance.share(
                      ShareParams(text: report, title: 'Annapurna Astro Vastu - ${widget.birthData.name}'),
                    );
                  },
                  icon: const Icon(Icons.share_outlined),
                ),
              ],
            ),
            const SizedBox(height: 4),
            const Text(
              'ఈ screen raw calculationsను consultationలో చెప్పడానికి సులభమైన క్రమంలో చూపిస్తుంది. Green/Amber/Red అనేవి app evidence labels మాత్రమే; probability % కాదు.',
              style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
            ),
            const SizedBox(height: 12),
            Card(
              color: _toneColor(overall.tone).withOpacity(0.08),
              surfaceTintColor: Colors.transparent,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Icon(_toneIcon(overall.tone), color: _toneColor(overall.tone)),
                      const SizedBox(width: 8),
                      Expanded(child: Text(overall.headline, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
                    ]),
                    const SizedBox(height: 10),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      Chip(avatar: const Icon(Icons.check_circle, size: 18, color: Color(0xFF1B7F3A)), label: Text('Strong ${overall.strongCount}')),
                      Chip(avatar: const Icon(Icons.info_outline, size: 18, color: Color(0xFF8A5A00)), label: Text('Mixed ${overall.mixedCount}')),
                      Chip(avatar: const Icon(Icons.warning_amber_rounded, size: 18, color: Color(0xFFB3261E)), label: Text('Caution ${overall.cautionCount}')),
                    ]),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              color: const Color(0xFFF6F2FF),
              surfaceTintColor: Colors.transparent,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.campaign_outlined, color: Color(0xFF5A3D8A)),
                        SizedBox(width: 8),
                        Text('మొదటి 30 సెకన్లలో ఇలా చెప్పండి', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(overall.headline, style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text(
                      'బలంగా కనిపిస్తున్న అంశాలు: ${events.where((e) => e.tone == ConsultationTone.strong).map((e) => e.title).take(3).join(' • ').isEmpty ? 'ప్రస్తుతం ప్రత్యేకంగా లేదు' : events.where((e) => e.tone == ConsultationTone.strong).map((e) => e.title).take(3).join(' • ')}',
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'జాగ్రత్తగా చూడాల్సినవి: ${events.where((e) => e.tone == ConsultationTone.caution).map((e) => e.title).take(3).join(' • ').isEmpty ? 'ప్రస్తుతం ప్రత్యేకంగా లేదు' : events.where((e) => e.tone == ConsultationTone.caution).map((e) => e.title).take(3).join(' • ')}',
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'తర్వాత క్లయింట్ ఏ అంశం గురించి అడిగితే ఆ cardను టచ్ చేసి “క్లయింట్‌కు చెప్పండి” line చదవండి.',
                      style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            _speakingOrderCard(),
            const SizedBox(height: 10),
            Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(children: [Icon(Icons.timeline_outlined), SizedBox(width: 8), Text('ప్రస్తుత దశ — ముందుగా చెప్పండి', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))]),
                    const SizedBox(height: 10),
                    Text(dasha.vimshottari),
                    const SizedBox(height: 6),
                    Text(dasha.tribhagi),
                    const SizedBox(height: 8),
                    const Text('ఈ దశా పేర్లను Event cardsలోని సంబంధిత గ్రహ evidenceతో కలిపి final judgment చేయండి.', style: TextStyle(fontSize: 12, color: Color(0xFF5F5052))),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              child: ExpansionTile(
                leading: const Icon(Icons.account_tree_outlined),
                title: const Text('జైమిని — వర్తించిన కాంబినేషన్స్', style: TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text('AK ${jaimini.atmakaraka} • అనుకూలం $jaiminiFavorable • జాగ్రత్త $jaiminiAdverse • యోగాలు $jaiminiYogas'),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                children: [
                  if (jaimini.applicableRules.isEmpty)
                    const Align(alignment: Alignment.centerLeft, child: Text('ప్రస్తుతం source-verified applicable rule hit లేదు.'))
                  else
                    ...jaimini.applicableRules.take(10).map((r) {
                      final color = r.nature == JaiminiRuleNature.favorable
                          ? const Color(0xFF1B7F3A)
                          : r.nature == JaiminiRuleNature.adverse
                              ? const Color(0xFFB3261E)
                              : const Color(0xFF8A5A00);
                      return Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(r.nature == JaiminiRuleNature.favorable ? Icons.check_circle : r.nature == JaiminiRuleNature.adverse ? Icons.warning_amber_rounded : Icons.info_outline, color: color, size: 19),
                            const SizedBox(width: 8),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(r.topic, style: const TextStyle(fontWeight: FontWeight.w800)),
                              Text(r.result),
                              Text('Rule: ${r.ruleId}', style: const TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E))),
                            ])),
                          ],
                        ),
                      );
                    }),
                  const SizedBox(height: 10),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('జైమిని rule hitను main event cardకు supporting evidenceగా మాత్రమే ఉపయోగించండి; ఒక్క ruleతో final verdict ఇవ్వవద్దు.', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
                  ),
                ],
              ),
            ),
            Card(
              color: const Color(0xFFF5F7FA),
              surfaceTintColor: Colors.transparent,
              child: const ListTile(
                leading: Icon(Icons.functions_outlined),
                title: Text('KP — consultation usage', style: TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text('Planet Star Lord / Sub Lord వివరాలు గ్రహ cardలో active. Exact 12-cusp Sub-Lord promise/denial engine పూర్తిగా source-validated అయ్యే వరకు KPని final verdictగా కలపము.'),
              ),
            ),
            const SizedBox(height: 18),
            const _SectionTitle('అంశాలవారీగా క్లయింట్‌కు చెప్పాల్సింది'),
            const SizedBox(height: 8),
            ...events.map((item) => Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                onTap: () => _showEventDetail(context, item, jaimini),
                leading: Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 29),
                title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${item.result}\nEvidence ${item.evidencePassed}/${item.evidenceTotal} • టచ్ → Client Script + సలహా'),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_right),
              ),
            )),
            const SizedBox(height: 12),
            const _SectionTitle('గ్రహ బలం — Quick Speaking Notes'),
            const SizedBox(height: 6),
            const Text('గ్రహాన్ని టచ్ చేస్తే పూర్తి Degree • Star Lord • Sub Lord • Amsa Devata • Vargaja వివరాలు వస్తాయి.', style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052))),
            const SizedBox(height: 8),
            ...planets.map((p) {
              final natal = widget.result.planets.firstWhere((x) => x.name == p.planet);
              return Card(
                color: Colors.white,
                surfaceTintColor: Colors.transparent,
                margin: const EdgeInsets.only(bottom: 8),
                child: ExpansionTile(
                  leading: CircleAvatar(backgroundColor: _toneColor(p.tone).withOpacity(0.12), foregroundColor: _toneColor(p.tone), child: Text(p.shortName)),
                  title: Text('${p.planet} — ${p.strength.toStringAsFixed(2)}/20', style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${p.strengthLabel} • ${p.theme}'),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                  children: [
                    Align(alignment: Alignment.centerLeft, child: Text('క్లయింట్‌కు చెప్పండి: ${p.sayThis}')),
                    const SizedBox(height: 8),
                    Align(alignment: Alignment.centerLeft, child: Text('D60: ${p.amsaDevata} • ${p.amsaNature}')),
                    const SizedBox(height: 6),
                    Align(alignment: Alignment.centerLeft, child: Text(p.technicalNote, style: const TextStyle(fontSize: 12, color: Color(0xFF5F5052)))),
                    const SizedBox(height: 8),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: OutlinedButton.icon(
                        onPressed: () => _showPlanetDetailSheet(context, widget.result, natal),
                        icon: const Icon(Icons.analytics_outlined),
                        label: const Text('పూర్తి గ్రహ వివరాలు'),
                      ),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 12),
            _ReportActions(
              title: '${widget.birthData.name} - Consultation',
              reportText: () => report,
              onSaveChart: widget.onSaveChart,
            ),
            const SizedBox(height: 30),
          ],
        );
      },
    );
  }
}


class _ConsultationTimingFinder extends StatefulWidget {
  final ConsultationEventSummary item;
  final BirthData birthData;
  final AstroChartResult natalChart;
  final AshtakavargaResult av;
  final DateTime asOfLocal;
  final JaiminiResult jaimini;

  const _ConsultationTimingFinder({
    required this.item,
    required this.birthData,
    required this.natalChart,
    required this.av,
    required this.asOfLocal,
    required this.jaimini,
  });

  @override
  State<_ConsultationTimingFinder> createState() => _ConsultationTimingFinderState();
}

class _ConsultationTimingFinderState extends State<_ConsultationTimingFinder> {
  Future<ConsultationTimingResult>? _future;

  String _two(int value) => value.toString().padLeft(2, '0');

  String _dateTime(DateTime value) =>
      '${_two(value.day)}-${_two(value.month)}-${value.year} ${_two(value.hour)}:${_two(value.minute)}';

  String _date(DateTime value) =>
      '${_two(value.day)}-${_two(value.month)}-${value.year}';

  String _tone(ConsultationTimingTone tone) => switch (tone) {
        ConsultationTimingTone.strong => 'Strong Confluence',
        ConsultationTimingTone.supportive => 'Supportive Window',
        ConsultationTimingTone.mixed => 'Mixed Window',
      };

  Color _color(ConsultationTimingTone tone) => switch (tone) {
        ConsultationTimingTone.strong => const Color(0xFF1B7F3A),
        ConsultationTimingTone.supportive => const Color(0xFF8A5A00),
        ConsultationTimingTone.mixed => const Color(0xFF355E8A),
      };

  Future<ConsultationTimingResult> _load() => ConsultationTimingService.findUpcoming(
        eventKey: widget.item.key,
        birthData: widget.birthData,
        natalChart: widget.natalChart,
        av: widget.av,
        fromLocal: widget.asOfLocal,
        jaimini: widget.jaimini,
        horizonMonths: 12,
      );

  void _start() {
    setState(() {
      _future ??= _load();
    });
  }

  ConsultationTimingWindow? _bestWindow(List<ConsultationTimingWindow> windows) {
    if (windows.isEmpty) return null;
    final strong = windows.where((w) => w.tone == ConsultationTimingTone.strong).toList();
    final pool = strong.isNotEmpty ? strong : windows;
    pool.sort((a, b) {
      final sav = b.savBindus.compareTo(a.savBindus);
      if (sav != 0) return sav;
      final bav = b.bavBindus.compareTo(a.bavBindus);
      if (bav != 0) return bav;
      return a.startLocal.compareTo(b.startLocal);
    });
    return pool.first;
  }

  String _periodText(List<String> periods) =>
      periods.isEmpty ? 'వర్తించదు / active support లేదు' : periods.join(' • ');

  ConsultationTimingWindow? _peakWindow(
    List<ConsultationTimingWindow> windows,
    ConsultationTimingWindow? best,
  ) {
    if (best == null) return null;
    if (best.tone == ConsultationTimingTone.strong) return best;
    final strong = windows
        .where((w) => w.tone == ConsultationTimingTone.strong)
        .toList();
    if (strong.isEmpty) return null;
    strong.sort((a, b) {
      final sav = b.savBindus.compareTo(a.savBindus);
      if (sav != 0) return sav;
      return b.bavBindus.compareTo(a.bavBindus);
    });
    return strong.first;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFF3F8FF),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.event_available_outlined, color: Color(0xFF355E8A)),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'దశ + గోచారం ఎప్పుడు కలుస్తాయి?',
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              'Vimshottari/Tribhagi MD–AD–PD + Jaimini Chara MD/AD + exact transit BAV/SAV overlapను 12 నెలలకు లెక్కిస్తుంది. Jaimini source-rule hitsను additional confirmationగా చూపిస్తుంది.',
              style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
            ),
            const SizedBox(height: 10),
            if (_future == null)
              FilledButton.icon(
                onPressed: _start,
                icon: const Icon(Icons.calculate_outlined),
                label: const Text('Timing Window లెక్కించండి'),
              )
            else
              FutureBuilder<ConsultationTimingResult>(
                future: _future,
                builder: (context, snapshot) {
                  if (snapshot.connectionState != ConnectionState.done) {
                    return const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Row(
                        children: [
                          SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)),
                          SizedBox(width: 10),
                          Expanded(child: Text('దశ + గోచార overlap లెక్కిస్తున్నాం…')),
                        ],
                      ),
                    );
                  }
                  if (snapshot.hasError || !snapshot.hasData) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Timing calculation error: ${snapshot.error}', style: const TextStyle(color: Color(0xFFB3261E))),
                        TextButton.icon(
                          onPressed: () => setState(() => _future = _load()),
                          icon: const Icon(Icons.refresh),
                          label: const Text('మళ్లీ ప్రయత్నించండి'),
                        ),
                      ],
                    );
                  }

                  final result = snapshot.data!;
                  final best = _bestWindow([...result.windows]);
                  final peak = _peakWindow([...result.windows], best);
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Search: ${_date(result.searchStart)} → ${_date(result.searchEnd)}',
                        style: const TextStyle(fontSize: 12, color: Color(0xFF5F5052)),
                      ),
                      const SizedBox(height: 8),
                      if (best == null)
                        const _ConsultationInfoBox(
                          icon: Icons.info_outline,
                          title: 'Strong overlap దొరకలేదు',
                          body: 'ఈ 12 నెలల rangeలో favorable BAV/SAV transit + Jaimini Chara MD/AD + Vimshottari/Tribhagi overlap కనిపించలేదు. దీన్ని “event జరగదు” అని అర్థం చేసుకోకండి; rangeను తర్వాత మళ్లీ చూడాలి.',
                          color: Color(0xFFFFF4DB),
                        )
                      else ...[
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: _color(best.tone).withOpacity(0.08),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _color(best.tone).withOpacity(0.35)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('⭐ Best Window — ${_tone(best.tone)}', style: TextStyle(fontWeight: FontWeight.w900, color: _color(best.tone))),
                              const SizedBox(height: 5),
                              Text('${_dateTime(best.startLocal)} → ${_dateTime(best.endLocal)}', style: const TextStyle(fontWeight: FontWeight.w800)),
                              const SizedBox(height: 4),
                              Text('${best.transitPlanet} transit • BAV ${best.bavBindus}/8 • SAV ${best.savBindus} • Kakshya ${best.entryKakshya}${best.retrogradeAtEntry ? ' • Retrograde entry' : ''}'),
                              const SizedBox(height: 8),
                              Text('Vimshottari MD/AD/PD: ${_periodText(best.vimshottariPeriods)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 3),
                              Text('Tribhagi MD/AD/PD: ${_periodText(best.tribhagiPeriods)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 3),
                              Text('Chara MD/AD: ${_periodText(best.charaDashaPeriods)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 3),
                              Text(
                                'Jaimini rules: ${best.jaiminiFavorable} అనుకూల rule hit(s) ✅ • ${best.jaiminiAdverse} జాగ్రత్త',
                                style: const TextStyle(fontWeight: FontWeight.w700),
                              ),
                              const SizedBox(height: 8),
                              if (peak != null)
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFEAF6EE),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: const Color(0xFF1B7F3A).withOpacity(0.25)),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'PEAK EVIDENCE WINDOW',
                                        style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900, color: Color(0xFF1B7F3A)),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        '${_dateTime(peak.startLocal)} → ${_dateTime(peak.endLocal)}',
                                        style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF1B7F3A)),
                                      ),
                                      if (identical(peak, best) ||
                                          (peak.startLocal == best.startLocal && peak.endLocal == best.endLocal))
                                        const Padding(
                                          padding: EdgeInsets.only(top: 3),
                                          child: Text(
                                            'ఈ మొత్తం Strong Confluence intervalనే ప్రస్తుతం source-backed peakగా తీసుకుంటున్నాం; artificial మధ్య తేదీ తయారు చేయడం లేదు.',
                                            style: TextStyle(fontSize: 11.5, color: Color(0xFF46674F)),
                                          ),
                                        ),
                                    ],
                                  ),
                                )
                              else
                                const Text(
                                  'Peak: ఈ searchలో అదనపు source-backed Strong Confluence window లేదు.',
                                  style: TextStyle(fontSize: 12.5, color: Color(0xFF6B5B5E)),
                                ),
                              const SizedBox(height: 8),
                              Text(
                                peak != null
                                    ? 'క్లయింట్‌కు చెప్పండి: “${widget.item.title} విషయంలో ${_date(best.startLocal)} నుంచి ${_date(best.endLocal)} వరకు Vimshottari/Tribhagi + Chara Dasha + గోచార AV support ఒకేసారి కనిపిస్తోంది. ముఖ్య evidence window ${_date(peak.startLocal)} నుంచి ${_date(peak.endLocal)} వరకు ఉంది. Jaiminiలో ${best.jaiminiFavorable} అనుకూల rule hit(s), ${best.jaiminiAdverse} జాగ్రత్త rule hit(s) కనిపిస్తున్నాయి. ఇది comparatively stronger astrological window; ఖచ్చిత సంఘటన హామీగా కాదు.”'
                                    : 'క్లయింట్‌కు చెప్పండి: “${widget.item.title} విషయంలో ${_date(best.startLocal)} నుంచి ${_date(best.endLocal)} వరకు Chara Dasha + Vimshottari/Tribhagi + గోచార AV support కలుస్తోంది. Jaiminiలో ${best.jaiminiFavorable} అనుకూల rule hit(s), ${best.jaiminiAdverse} జాగ్రత్త rule hit(s) కనిపిస్తున్నాయి. ఇది supportive astrological window; ఖచ్చిత సంఘటన హామీగా కాదు.”',
                                style: const TextStyle(fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        const Text('ఇతర supporting windows', style: TextStyle(fontWeight: FontWeight.w800)),
                        ...result.windows
                            .where((w) => best == null ||
                                w.startLocal != best.startLocal ||
                                w.endLocal != best.endLocal)
                            .take(5)
                            .map((w) => Padding(
                              padding: const EdgeInsets.only(top: 7),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(
                                    w.tone == ConsultationTimingTone.strong ? Icons.check_circle : Icons.info_outline,
                                    color: _color(w.tone),
                                    size: 18,
                                  ),
                                  const SizedBox(width: 7),
                                  Expanded(
                                    child: Text(
                                      '${_date(w.startLocal)} → ${_date(w.endLocal)} • ${w.transitPlanet} • '
                                      'Vim ${_periodText(w.vimshottariPeriods)} • '
                                      'Tribhagi ${_periodText(w.tribhagiPeriods)} • '
                                      'Chara ${_periodText(w.charaDashaPeriods)} • '
                                      'BAV ${w.bavBindus}/8 • SAV ${w.savBindus}',
                                      style: const TextStyle(fontSize: 12.5),
                                    ),
                                  ),
                                ],
                              ),
                            )),
                      ],
                      const SizedBox(height: 10),
                      ExpansionTile(
                        tilePadding: EdgeInsets.zero,
                        childrenPadding: EdgeInsets.zero,
                        title: const Text('జైమిని confirmation — పూర్తి వివరాలు', style: TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text('అనుకూల rule hits ${result.jaiminiFavorable} • జాగ్రత్త ${result.jaiminiAdverse}'),
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              result.jaiminiRuleIds.isEmpty ? 'ఈ eventకు direct Jaimini rule hit లేదు.' : 'Rules: ${result.jaiminiRuleIds.join(', ')}',
                              style: const TextStyle(fontSize: 12.5),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(result.jaiminiNote, style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: Color(0xFF5F5052))),
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _ConsultationInfoBox extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final Color color;

  const _ConsultationInfoBox({
    required this.icon,
    required this.title,
    required this.body,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2D2D5)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFF7B1E2B)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text(body),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ConsultationEvidenceRow extends StatelessWidget {
  final String title;
  final String body;

  const _ConsultationEvidenceRow(this.title, this.body);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(body),
          ],
        ),
      ),
    );
  }
}


class _SystemsTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;

  const _SystemsTab({
    required this.birthData,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final vim = DashaService.vimshottari(
      chart: result,
      birthDateTime: birthData.localDateTime,
    );
    final jai = JaiminiService.calculate(result);
    final kpRows = KpService.planetaryTable(result);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('దశలు • Jamakola • జైమిని • Tajik • BCP • BSP • BNN • KP'),
        const SizedBox(height: 8),
        const Text(
          'ఎడమపై ☰ menu టచ్ చేసి కావలసిన system ఎంచుకోండి. ప్రతి systemకు ప్రత్యేక scroll page ఉంటుంది. Verified sourceలో స్పష్టంగా లేని arithmetic/result rulesను ఊహించి hard-code చేయము.',
        ),
        const SizedBox(height: 14),
        _VimshottariCard(result: vim, birthDateTime: birthData.localDateTime),
        const SizedBox(height: 14),
        _JaiminiCard(result: jai, chart: result, birthData: birthData),
        const SizedBox(height: 14),
        _KpCard(rows: kpRows),
        const SizedBox(height: 14),
        const _SourcePendingCard(
          title: 'Jamakola System',
          icon: Icons.auto_awesome_outlined,
          text:
              'Jamakola కోసం module slot సిద్ధంగా ఉంది. మీరు ఇచ్చే/ఇప్పటికే ఉన్న verified Jamakola source rulesను మాత్రమే engineలో hard-code చేస్తాం; source లేకుండా prediction rulesను కలపము.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'Tajik / Varshaphala',
          icon: Icons.calendar_month_outlined,
          text:
              'Tajik annual-chart module slot సిద్ధంగా ఉంది. Verified Tajik sourceలోని Muntha, annual lord, sahams/yogas మరియు timing rules వచ్చిన తర్వాత source-tagతో enable చేస్తాం.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BCP',
          icon: Icons.rotate_right_outlined,
          text:
              'BCP menu సిద్ధంగా ఉంది. Supplied/verified source rules వచ్చిన తర్వాత age/year activation, evidence మరియు timing calculationsను enable చేస్తాం.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BSP',
          icon: Icons.rule_folder_outlined,
          text:
              'BSP source engine active: Appendix year rules + BSP 37 Moon–Mars rule. ☰ → BSPలో వరుస year listను టచ్ చేస్తే జాతకానికి అమలైన implementation houses, lordships, ఫలితాలు మరియు source-rule audit కనిపిస్తాయి.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BNN',
          icon: Icons.hub_outlined,
          text:
              'BNN source engine active: Guru-reference house mapping, 343 indexed source rules, age tables, Rule ID → source-page audit, మరియు 21-page rulebook source registry. ☰ → BNNలో పూర్తి వివరాలు చూడండి.',
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


class _BnnPanel extends StatelessWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const _BnnPanel({required this.chart, required this.birthData});

  int _ageOn(DateTime now) {
    var age = now.year - birthData.localDateTime.year;
    final beforeBirthday = now.month < birthData.localDateTime.month ||
        (now.month == birthData.localDateTime.month &&
            now.day < birthData.localDateTime.day);
    if (beforeBirthday) age--;
    return age < 0 ? 0 : age;
  }

  Future<void> _showSourcePage(BuildContext context, int page) async {
    if (page == 6 || page == 7) {
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('BNN Source • Page $page'),
          content: const Text(
            'ఈ source pageలో sensitive health/safety material ఉంది. App దాన్ని వ్యక్తిగత predictionగా చూపించదు. అవసరమైన non-sensitive rule IDs మాత్రం BNN registryలో audit కోసం కొనసాగుతాయి.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      );
      return;
    }
    final asset =
        'assets/source_reference/bnn/bnn-${page.toString().padLeft(2, '0')}.jpg';
    await showDialog<void>(
      context: context,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.all(10),
        child: SafeArea(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 10, 8, 6),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'BNN Source • Page $page / ${BnnService.sourcePageCount}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                        ),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1),
              Expanded(
                child: InteractiveViewer(
                  minScale: 0.7,
                  maxScale: 4,
                  child: Center(
                    child: Image.asset(asset, fit: BoxFit.contain),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _showRule(
    BuildContext context,
    BnnSourceSection section,
    String id,
  ) async {
    final page = BnnService.pageForRule(id);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$id • ${section.title}',
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 10),
              Text(
                'Source page: $page • ${BnnService.sourceFile}',
                style: const TextStyle(color: Color(0xFF6A5C5E)),
              ),
              const SizedBox(height: 10),
              const Text(
                'ఈ rule entry supplied BNN rulebookలోని original source IDతో link అయింది. Sourceలో ఉన్న exact condition/resultను ఊహించి మార్చకుండా page image నుంచే audit చేయాలి. Machine-readable condition స్పష్టంగా ఉన్న rules మాత్రమే auto-resultగా ఉపయోగించబడతాయి.',
                style: TextStyle(height: 1.45),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(sheetContext);
                  _showSourcePage(context, page);
                },
                icon: const Icon(Icons.menu_book_outlined),
                label: const Text('Original source page చూడండి'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final analysis = BnnService.analyze(chart);
    final now = DateTime.now();
    final currentAge = _ageOn(now);
    final totalRules = BnnService.sourceSections.fold<int>(
      0,
      (sum, section) => sum + section.count,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          color: const Color(0xFFF8F1EB),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.hub_outlined, color: Color(0xFF8A2331)),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'BNN — భృగు నాడి సంగ్రహ',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  '$totalRules indexed source rules • ${BnnService.sourcePageCount} source pages • Guru-reference calculation',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                const Text(
                  'ఈ BNN moduleలో గురువు ఉన్న రాశినే 1వ భావంగా తీసుకుంటుంది. సాధారణ జన్మలగ్న house numberingతో కలపదు. Sourceలో స్పష్టంగా machine-readable అయిన tables/relations మాత్రమే auto-calculate అవుతాయి; మిగతా ప్రతి rule original source pageతో audit చేయవచ్చు.',
                  style: TextStyle(height: 1.45),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    Chip(
                      avatar: const Icon(Icons.center_focus_strong, size: 18),
                      label: Text(
                        'BNN 1వ భావం: ${BnnService.signNamesTe[analysis.jupiterSignIndex]}',
                      ),
                    ),
                    Chip(
                      avatar: const Icon(Icons.cake_outlined, size: 18),
                      label: Text('ప్రస్తుత వయస్సు: $currentAge'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'గ్రహాలు — గురు నుంచి భావ స్థానం',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 5),
                const Text(
                  'Source method: గురు రాశి = 1వ ఇల్లు. 1/5/9 త్రికోణం; 1/4/7/10 కేంద్రం; 6/8/12 త్రిక; 2/3/11 మధ్యస్థ.',
                  style: TextStyle(fontSize: 12.5, color: Color(0xFF6C5D5F)),
                ),
                const SizedBox(height: 10),
                ...analysis.planets.map(
                  (p) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 78,
                          child: Text(
                            p.name,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            '${BnnService.signNamesTe[p.signIndex]} • గురు నుంచి ${p.houseFromJupiter}వ భావం',
                          ),
                        ),
                        Text(
                          p.houseClass,
                          style: const TextStyle(fontSize: 11.5, color: Color(0xFF7A5B60)),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: () => _showSourcePage(context, 1),
                  icon: const Icon(Icons.menu_book_outlined),
                  label: const Text('పద్ధతి / భావ వర్గీకరణ source చూడండి'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (analysis.lifeTurningPoint != null)
          Card(
            color: const Color(0xFFF7F4FF),
            surfaceTintColor: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'జీవిత ఘట్టాలు — గురు మొదటి అధిపతి',
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'గురు రాశి అధిపతి: ${analysis.lifeTurningPoint!.lord} • గురు నుంచి ${analysis.lifeTurningPoint!.houseFromJupiter}వ భావం',
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${analysis.lifeTurningPoint!.theme} • source ages: ${analysis.lifeTurningPoint!.ages.join(', ')}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'ఈ ages source timing indicators మాత్రమే; ఖచ్చిత సంఘటన guarantee కాదు.',
                    style: TextStyle(fontSize: 12, color: Color(0xFF6A5C5E)),
                  ),
                ],
              ),
            ),
          ),
        if (analysis.lifeTurningPoint != null) const SizedBox(height: 12),
        Card(
          color: const Color(0xFFF8FBF4),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'BNN కాల సూచనలు — ఈ జాతకానికి table match',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 6),
                const Text(
                  'వివాహం, వృత్తి, ఆర్థికాభివృద్ధి, పేరు/ప్రఖ్యాతి, స్థల మార్పు వంటి non-sensitive source tables మాత్రమే ఇక్కడ auto-map అవుతాయి.',
                  style: TextStyle(fontSize: 12.5, color: Color(0xFF5D675B)),
                ),
                const SizedBox(height: 10),
                if (analysis.ageIndications.isEmpty)
                  const Text('ఈ chartలో ప్రస్తుతం auto-mapped age table entry లేదు.')
                else
                  ...analysis.ageIndications.map((item) {
                    final current = item.ages.contains(currentAge);
                    return Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 9),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: current
                              ? const Color(0xFF4B7A3A)
                              : const Color(0xFFE3DDD8),
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  item.title,
                                  style: const TextStyle(fontWeight: FontWeight.w900),
                                ),
                              ),
                              if (current)
                                const Chip(
                                  visualDensity: VisualDensity.compact,
                                  label: Text('ఈ వయస్సు'),
                                ),
                            ],
                          ),
                          Text(
                            '${item.fromPlanet} నుంచి ${item.toPlanet}: ${item.relativeHouse}వ భావం',
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Source ages: ${item.ages.join(', ')}',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          const SizedBox(height: 6),
                          TextButton.icon(
                            onPressed: () => _showSourcePage(context, item.sourcePage),
                            icon: const Icon(Icons.menu_book_outlined, size: 18),
                            label: Text('Source page ${item.sourcePage}'),
                          ),
                        ],
                      ),
                    );
                  }),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'BNN Rule Library — మొత్తం source index',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 5),
                const Text(
                  'Section తెరిచి Rule IDని టచ్ చేస్తే ఆ rule ఉన్న original source page కనిపిస్తుంది. ఇది source textను ఊహించి rewrite చేయకుండా audit చేయడానికి.',
                  style: TextStyle(fontSize: 12.5, color: Color(0xFF6A5C5E)),
                ),
                const SizedBox(height: 8),
                ...BnnService.sourceSections.map(
                  (section) => ExpansionTile(
                    tilePadding: EdgeInsets.zero,
                    childrenPadding: const EdgeInsets.only(bottom: 12),
                    title: Text(
                      '${section.code}. ${section.title}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      '${section.count} rules • pages ${section.pages.join(', ')} • ${section.subtitle}',
                    ),
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: section.ruleIds
                              .map(
                                (id) => ActionChip(
                                  label: Text(id),
                                  onPressed: () => _showRule(context, section, id),
                                ),
                              )
                              .toList(growable: false),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          color: const Color(0xFFFFF8E8),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'BNN App అనువర్తన క్రమం',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                const Text(
                  '1. గురు రాశిని మొదటి భావంగా సెట్ చేయాలి.\n'
                  '2. ప్రతి గ్రహం గురు నుంచి ఏ భావంలో ఉందో లెక్కించాలి.\n'
                  '3. త్రికోణం / కేంద్రం / త్రిక / మధ్యస్థం ట్యాగ్ చేయాలి.\n'
                  '4. గ్రహం-వారీ source rules YES/NOగా audit చేయాలి.\n'
                  '5. వయస్సు tablesను source సంబంధంతో మాత్రమే apply చేయాలి.\n'
                  '6. Rule → chart relation → result → age/source అనే trace చూపించాలి.\n'
                  '7. Sensitive health/safety rulesను deterministic personal predictionగా చూపించకూడదు.\n'
                  '8. Exact source స్పష్టంగా లేని చోట auto-result ఇవ్వకూడదు.',
                  style: TextStyle(height: 1.55),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: () => _showSourcePage(context, 17),
                  icon: const Icon(Icons.schema_outlined),
                  label: const Text('Source application order • page 17'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Source Pages',
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 7,
                  runSpacing: 7,
                  children: [
                    for (var p = 1; p <= BnnService.sourcePageCount; p++)
                      ActionChip(
                        avatar: const Icon(Icons.description_outlined, size: 17),
                        label: Text('P$p'),
                        onPressed: () => _showSourcePage(context, p),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Note: sensitive health/safety source pages are not rendered as personal predictions. The rest of the supplied rulebook is preserved page-for-page for source audit.',
                  style: TextStyle(fontSize: 11.5, color: Color(0xFF6A5C5E)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _BspCard extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const _BspCard({required this.chart, required this.birthData});

  @override
  State<_BspCard> createState() => _BspCardState();
}

class _BspCardState extends State<_BspCard> {
  late final List<BspYearResult> _years;
  late final int _currentYear;

  @override
  void initState() {
    super.initState();
    _years = BspService.evaluateAll(
      chart: widget.chart,
      birthDateTime: widget.birthData.localDateTime,
    );
    _currentYear = BspService.currentBspYear(
      widget.birthData.localDateTime,
      DateTime.now(),
    );
  }

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

  String _signs(List<int> signs) => signs.isEmpty
      ? '—'
      : signs
          .map((s) => '${s + 1} ${AstroFormat.signNamesTe[s]}')
          .join(', ');

  String _houses(List<int> houses) =>
      houses.isEmpty ? '—' : houses.map((h) => '$h').join(', ');

  void _showRule(BspActivation a) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${a.rule.id} • ${a.rule.planet}'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              _BspLabelValue('BSP No.', a.rule.bspNo?.toString() ?? 'Appendix entry'),
              _BspLabelValue('Year', '${a.rule.year}'),
              _BspLabelValue('Source rule', a.rule.implementation),
              _BspLabelValue('Natal sign', _signs([a.natalSign])),
              _BspLabelValue('Natal house', '${a.natalHouse}'),
              _BspLabelValue('Implementation sign(s)', _signs(a.targetSigns)),
              _BspLabelValue('Implementation house(s)', _houses(a.targetHouses)),
              if (a.optionalTargetSigns.isNotEmpty)
                _BspLabelValue('Optional / OR sign(s)', _signs(a.optionalTargetSigns)),
              if (a.optionalTargetHouses.isNotEmpty)
                _BspLabelValue('Optional / OR house(s)', _houses(a.optionalTargetHouses)),
              _BspLabelValue(
                'Planet lordship houses',
                a.lordshipHouses.isEmpty ? 'standard lordship not assigned' : _houses(a.lordshipHouses),
              ),
              const Divider(height: 22),
              const Text('ఎందుకు ఈ ఫలితం?', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text(a.reason),
              if (a.rule.sourceNote.isNotEmpty) ...[
                const SizedBox(height: 10),
                Text(
                  a.rule.sourceNote,
                  style: const TextStyle(color: Color(0xFF8A5A00), fontWeight: FontWeight.w600),
                ),
              ],
              const Divider(height: 22),
              const Text('మూలం', style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text(a.rule.source),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('మూసివేయండి')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final currentHasSource = BspService.sourceYearOrder.contains(_currentYear);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          color: const Color(0xFFFFF8EA),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.rule_folder_outlined, color: Color(0xFF7B1E2B)),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'BSP — Year-wise Result Engine',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'B S P source Appendixలో ఉన్న year → planet → implementation నియమాలను ఈ జాతకంలోని రాశి/భావానికి map చేశాం. Yearను టచ్ చేస్తే ఆ సంవత్సరానికి apply అయ్యే ఫలితాలు, rule reason మరియు source కనిపిస్తాయి.',
                ),
                const SizedBox(height: 10),
                Text(
                  'ప్రస్తుత జీవన సంవత్సరం: $_currentYear${currentHasSource ? ' • BSP source activation ఉంది' : ' • ఈ source setలో ప్రత్యేక BSP entry లేదు'}',
                  style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF7B1E2B)),
                ),
                const SizedBox(height: 6),
                const Text(
                  'కాల గణన: Nవ year = (N−1)వ జన్మదినం నుంచి Nవ జన్మదినం వరకు. Source scanలో స్పష్టంగా లేని notationను app ఊహించి calculate చేయదు.',
                  style: TextStyle(fontSize: 12.5, color: Color(0xFF65585A)),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        for (final yr in _years) _BspYearTile(year: yr, currentYear: _currentYear, onRuleTap: _showRule),
      ],
    );
  }
}

class _BspYearTile extends StatelessWidget {
  final BspYearResult year;
  final int currentYear;
  final ValueChanged<BspActivation> onRuleTap;

  const _BspYearTile({required this.year, required this.currentYear, required this.onRuleTap});

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

  @override
  Widget build(BuildContext context) {
    final isCurrent = year.year == currentYear;
    final count = year.activations.length + ((year.bsp37?.matched ?? false) ? 1 : 0);
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      color: isCurrent ? const Color(0xFFFFEEF1) : Colors.white,
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        key: PageStorageKey('bsp-year-${year.year}'),
        leading: CircleAvatar(
          backgroundColor: isCurrent ? const Color(0xFF7B1E2B) : const Color(0xFFF3E6E8),
          foregroundColor: isCurrent ? Colors.white : const Color(0xFF7B1E2B),
          child: Text('${year.year}', style: const TextStyle(fontWeight: FontWeight.w800)),
        ),
        title: Text('${year.year}వ సంవత్సరం', style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${_date(year.start)} → ${_date(year.end)} • $count active source rule${count == 1 ? '' : 's'}'),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: [
          if (year.activations.isEmpty && year.bsp37 == null)
            const Padding(
              padding: EdgeInsets.all(10),
              child: Text('ఈ సంవత్సరం కోసం supplied BSP sourceలో ప్రత్యేక rule లేదు.'),
            ),
          for (final a in year.activations) _BspActivationCard(activation: a, onRuleTap: () => onRuleTap(a)),
          if (year.bsp37 != null) _Bsp37Card(result: year.bsp37!, year: year.year),
        ],
      ),
    );
  }
}

class _BspActivationCard extends StatelessWidget {
  final BspActivation activation;
  final VoidCallback onRuleTap;

  const _BspActivationCard({required this.activation, required this.onRuleTap});

  @override
  Widget build(BuildContext context) {
    final a = activation;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFFF9F6F2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE5DDD4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  '${a.rule.planet} • ${a.rule.id}',
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                ),
              ),
              if (!a.rule.exactArithmeticAvailable)
                const Tooltip(message: 'Source scan unclear', child: Icon(Icons.warning_amber_rounded, color: Color(0xFFB36B00))),
            ],
          ),
          const SizedBox(height: 4),
          Text(a.rule.implementation, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 9),
          const Text('ఈ జాతకానికి వచ్చే ఫలితాలు', style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF7B1E2B))),
          const SizedBox(height: 5),
          for (final line in a.resultLines)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text('• $line'),
            ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: onRuleTap,
            icon: const Icon(Icons.menu_book_outlined, size: 18),
            label: const Text('అప్లయ్ అయిన Rule / Source చూడండి'),
          ),
        ],
      ),
    );
  }
}

class _Bsp37Card extends StatelessWidget {
  final Bsp37Result result;
  final int year;

  const _Bsp37Card({required this.result, required this.year});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: result.matched ? const Color(0xFFEFF8F1) : const Color(0xFFF6F6F6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: result.matched ? const Color(0xFFBFDCC7) : const Color(0xFFDDDDDD)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'BSP 37 • Moon & Mars • $yearవ సంవత్సరం',
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
          ),
          const SizedBox(height: 5),
          Text('Condition: Moon–Mars conjunction/opposition • Status: ${result.matched ? 'MATCHED' : 'NOT MATCHED'}'),
          const SizedBox(height: 7),
          for (final line in result.resultLines)
            Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text('• $line'),
            ),
          const SizedBox(height: 4),
          const Text(
            'Source: B S P — BSP 37 Moon & Mars Conjunction & Opposition, uploaded pp.15–21.',
            style: TextStyle(fontSize: 12.5, color: Color(0xFF65585A)),
          ),
        ],
      ),
    );
  }
}

class _BspLabelValue extends StatelessWidget {
  final String label;
  final String value;
  const _BspLabelValue(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF65585A), fontWeight: FontWeight.w700)),
          Text(value),
        ],
      ),
    );
  }
}

class _DashaSystemsCard extends StatefulWidget {
  final AstroChartResult chart;
  final DateTime birthDateTime;

  const _DashaSystemsCard({
    required this.chart,
    required this.birthDateTime,
  });

  @override
  State<_DashaSystemsCard> createState() => _DashaSystemsCardState();
}

class _DashaSystemsCardState extends State<_DashaSystemsCard> {
  DashaSystemKind _selectedKind = DashaSystemKind.tribhagi;
  late DateTime _probeDate;

  @override
  void initState() {
    super.initState();
    _probeDate = DateTime.now();
  }

  String _date(DateTime dt) =>
      '${AstroFormat.two(dt.day)}-${AstroFormat.two(dt.month)}-${dt.year}';

  String _dateTime(DateTime dt) =>
      '${_date(dt)} ${AstroFormat.two(dt.hour)}:${AstroFormat.two(dt.minute)}';

  String _years(double value) {
    if (value >= 1) return '${value.toStringAsFixed(4)} y';
    final days = value * 365.2425;
    if (days >= 1) return '${days.toStringAsFixed(2)} d';
    return '${(days * 24).toStringAsFixed(2)} h';
  }

  Future<void> _pickDate() async {
    final first = DateTime(widget.birthDateTime.year - 10, 1, 1);
    final last = DateTime(widget.birthDateTime.year + 150, 12, 31);
    var initial = _probeDate;
    if (initial.isBefore(first)) initial = first;
    if (initial.isAfter(last)) initial = last;

    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: last,
      helpText: 'దశా తేదీ ఎంచుకోండి',
    );
    if (!mounted || picked == null) return;
    setState(() {
      _probeDate = DateTime(
        picked.year,
        picked.month,
        picked.day,
        12,
      );
    });
  }

  Widget _pathTile(
    String level,
    DashaPeriod period, {
    bool emphasize = false,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: emphasize ? const Color(0xFFFFECEF) : const Color(0xFFFFF8F4),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: emphasize ? const Color(0xFF8D3140) : const Color(0xFFE3C7CC),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$level • ${period.lord}',
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 3),
          Text('${_dateTime(period.start)} → ${_dateTime(period.end)}'),
          Text(
            _years(period.years),
            style: const TextStyle(fontSize: 12, color: Color(0xFF66595B)),
          ),
        ],
      ),
    );
  }

  Widget _periodTable(
    String title,
    List<DashaPeriod> periods,
    String? activeLord,
  ) {
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      childrenPadding: EdgeInsets.zero,
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.w800),
      ),
      subtitle: Text('${periods.length} periods'),
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columnSpacing: 18,
            headingRowHeight: 42,
            dataRowMinHeight: 42,
            dataRowMaxHeight: 54,
            columns: const [
              DataColumn(label: Text('Lord')),
              DataColumn(label: Text('Start')),
              DataColumn(label: Text('End')),
              DataColumn(label: Text('Duration')),
            ],
            rows: periods
                .map(
                  (p) => DataRow(
                    selected: activeLord != null && p.lord == activeLord,
                    cells: [
                      DataCell(Text(p.lord)),
                      DataCell(Text(_date(p.start))),
                      DataCell(Text(_date(p.end))),
                      DataCell(Text(_years(p.years))),
                    ],
                  ),
                )
                .toList(),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final system = DashaService.system(
      kind: _selectedKind,
      chart: widget.chart,
      birthDateTime: widget.birthDateTime,
    );
    final path = DashaService.pathAt(system, _probeDate);

    final ads = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.mahadasha);
    final pds = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.antardasha);
    final suks = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.pratyantardasha);
    final pranas = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.sukshma);

    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'దశా గణన',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            const Text(
              'త్రిభాగి • వింశోత్తరి • ఖండ • యోగిని — birth balance నుంచి 5 స్థాయుల వరకు.',
              style: TextStyle(color: Color(0xFF65585A)),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: DashaSystemKind.values
                  .map(
                    (kind) => ChoiceChip(
                      label: Text(kind.teluguLabel),
                      selected: _selectedKind == kind,
                      onSelected: (_) => setState(() => _selectedKind = kind),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF5F6),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE0C1C7)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    system.label,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Birth start: ${system.startingLord} • Nakshatra ${(system.moonNakshatraIndex + 1)} • '
                    'elapsed ${(system.nakshatraFractionElapsed * 100).toStringAsFixed(2)}%',
                  ),
                  Text(
                    'Birth balance: ${system.birthBalanceYears.toStringAsFixed(6)} years '
                    '• source Y-M-D(360): ${DashaService.sourceYmd360(system.birthBalanceYears)}',
                  ),
                  const SizedBox(height: 6),
                  Text(
                    system.sourceNote,
                    style: const TextStyle(fontSize: 12.5, color: Color(0xFF65585A)),
                  ),
                  if (_selectedKind == DashaSystemKind.tribhagi) ...[
                    const SizedBox(height: 6),
                    const Text(
                      'Mehta timing priority: 2వ స్థాయి అంతర్దశ → 3వ ప్రత్యంతర్దశ → 4వ సూక్ష్మ → 5వ ప్రాణం. మహాదశను eventకు ఒక్కటే నిర్ణయకంగా తీసుకోరు.',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'పరిశీలన తేదీ: ${_date(_probeDate)}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: _pickDate,
                  icon: const Icon(Icons.calendar_month_outlined),
                  label: const Text('తేదీ'),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (path == null)
              const Text(
                'ఈ తేదీ generated dasha range బయట ఉంది. వేరే తేదీ ఎంచుకోండి.',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
              )
            else ...[
              const Text(
                'ఈ తేదీకి 5 స్థాయుల దశా స్థితి',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              _pathTile('1. మహాదశ', path.mahadasha),
              _pathTile('2. అంతర్దశ', path.antardasha, emphasize: true),
              _pathTile('3. ప్రత్యంతర్దశ', path.pratyantardasha, emphasize: true),
              _pathTile('4. సూక్ష్మ', path.sukshma, emphasize: true),
              _pathTile('5. ప్రాణ', path.prana, emphasize: true),
              const Divider(height: 24),
              _periodTable(
                'మహాదశ క్రమం',
                system.mahadashas,
                path.mahadasha.lord,
              ),
              _periodTable(
                '${path.mahadasha.lord} — అంతర్దశలు',
                ads,
                path.antardasha.lord,
              ),
              _periodTable(
                '${path.antardasha.lord} — ప్రత్యంతర్దశలు',
                pds,
                path.pratyantardasha.lord,
              ),
              _periodTable(
                '${path.pratyantardasha.lord} — సూక్ష్మ దశలు',
                suks,
                path.sukshma.lord,
              ),
              _periodTable(
                '${path.sukshma.lord} — ప్రాణ దశలు',
                pranas,
                path.prana.lord,
              ),
            ],
            const SizedBox(height: 8),
            const Text(
              'Date mapping: civil year 365.2425 days. Mehta supplied period tables also show Y-M-D reference values on a 360-day year / 30-day month convention; the app displays that reference balance separately instead of silently mixing conventions.',
              style: TextStyle(fontSize: 11.5, color: Color(0xFF6A5D60)),
            ),
          ],
        ),
      ),
    );
  }
}

class _VimshottariCard extends StatelessWidget {
  final VimshottariResult result;
  final DateTime birthDateTime;

  const _VimshottariCard({
    required this.result,
    required this.birthDateTime,
  });

  String _date(DateTime dt) =>
      '${AstroFormat.two(dt.day)}-${AstroFormat.two(dt.month)}-${dt.year}';

  @override
  Widget build(BuildContext context) {
    final birthMd = result.currentMahadasha;
    final now = DateTime.now();
    final currentMd =
        DashaService.periodAt(result.mahadashas, now) ?? birthMd;
    final currentAds = DashaService.subPeriods(currentMd);
    final currentAd =
        DashaService.periodAt(currentAds, now) ?? currentAds.first;
    final currentPds = DashaService.subPeriods(currentAd);
    final currentPd =
        DashaService.periodAt(currentPds, now) ?? currentPds.first;

    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'వింశోత్తరి దశలు',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(
              'Moon Nakshatra lord: ${result.moonNakshatraLord} • '
              'elapsed ${(result.nakshatraFractionElapsed * 100).toStringAsFixed(2)}%',
            ),
            const SizedBox(height: 8),
            DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xFFFFF0F2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF8D3140)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Text(
                  'Birth Mahadasha: ${birthMd.lord}  '
                  '${_date(birthMd.start)} → ${_date(birthMd.end)}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF7F3),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE4C8CD)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'ప్రస్తుత దశా స్థితి',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'MD ${currentMd.lord}: ${_date(currentMd.start)} → ${_date(currentMd.end)}',
                  ),
                  Text(
                    'AD ${currentAd.lord}: ${_date(currentAd.start)} → ${_date(currentAd.end)}',
                  ),
                  Text(
                    'PD ${currentPd.lord}: ${_date(currentPd.start)} → ${_date(currentPd.end)}',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Mahadasha sequence',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('Lord')),
                  DataColumn(label: Text('Start')),
                  DataColumn(label: Text('End')),
                ],
                rows: result.mahadashas.take(10).map((p) => DataRow(cells: [
                      DataCell(Text(p.lord)),
                      DataCell(Text(_date(p.start))),
                      DataCell(Text(_date(p.end))),
                    ])).toList(),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              '${birthMd.lord} birth-MD Antardashas',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            ...result.currentAntardashas.map(
              (p) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('${p.lord}: ${_date(p.start)} → ${_date(p.end)}'),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Convention: 120-year Vimshottari proportions; civil year = 365.2425 days. '
              'Calculation convention is shown explicitly so dates are reproducible.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}


class _JaiminiCard extends StatefulWidget {
  final JaiminiResult result;
  final AstroChartResult chart;
  final BirthData birthData;

  const _JaiminiCard({
    required this.result,
    required this.chart,
    required this.birthData,
  });

  @override
  State<_JaiminiCard> createState() => _JaiminiCardState();
}

class _JaiminiCardState extends State<_JaiminiCard> {
  JaiminiCharaMethod _method = JaiminiCharaMethod.methodB;
  int _customStartSign = 0;
  bool _customForward = true;
  JaiminiCoLordChoice _scorpioChoice = JaiminiCoLordChoice.autoSource;
  JaiminiCoLordChoice _aquariusChoice = JaiminiCoLordChoice.autoSource;
  String _eventKey = 'marriage';
  late final TextEditingController _selfYearsController;

  @override
  void initState() {
    super.initState();
    _customStartSign = widget.chart.ascendantSignIndex;
    _selfYearsController = TextEditingController(text: '12');
  }

  @override
  void dispose() {
    _selfYearsController.dispose();
    super.dispose();
  }

  double get _selfSignYears {
    final v = double.tryParse(_selfYearsController.text.trim()) ?? 12;
    return v.clamp(1, 30).toDouble();
  }

  JaiminiCharaConfig get _config => JaiminiCharaConfig(
        method: _method,
        customStartSignIndex: _customStartSign,
        customForward: _customForward,
        selfSignYears: _selfSignYears,
        scorpioLordChoice: _scorpioChoice,
        aquariusLordChoice: _aquariusChoice,
      );

  Map<int, List<String>> _jaiminiOccupants() {
    final occupants = <int, List<String>>{
      for (var i = 0; i < 12; i++) i: <String>[],
    };

    final karakaByPlanet = <String, String>{
      for (final k in widget.result.charaKarakas) k.planet: k.code,
    };

    for (final planet in widget.chart.planets) {
      final karaka = karakaByPlanet[planet.name];
      var label = '${planet.shortName} ${planet.degreesInSign.toStringAsFixed(1)}°';
      if (karaka != null) label += ' $karaka';
      occupants[planet.signIndex]!.add(label);
    }

    for (final pada in widget.result.arudhaPadas) {
      occupants[pada.padaSignIndex]!.add('P${pada.padaNumber}');
    }

    return occupants;
  }

  String _date(DateTime dt) =>
      '${AstroFormat.two(dt.day)}-${AstroFormat.two(dt.month)}-${dt.year}';

  Color _scoreColor(int score) {
    if (score >= 70) return const Color(0xFF1B7F3A);
    if (score >= 50) return const Color(0xFF9A6B00);
    return const Color(0xFF8D3140);
  }

  void _showRuleAudit(BuildContext context, JaiminiEventRuleCheck rule) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'రూల్ • ${rule.ruleId}',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              Chip(
                label: Text(rule.matched ? 'MATCHED' : 'NOT MATCHED'),
                avatar: Icon(
                  rule.matched ? Icons.check_circle : Icons.radio_button_unchecked,
                  size: 18,
                ),
              ),
              const Divider(height: 28),
              const Text('Input condition', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text(rule.condition, style: const TextStyle(height: 1.45)),
              const SizedBox(height: 16),
              const Text('Reason', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text(rule.reason, style: const TextStyle(height: 1.45)),
              const SizedBox(height: 16),
              const Text('పరిహారం', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
              const SizedBox(height: 5),
              Text(rule.remedy, style: const TextStyle(height: 1.45)),
              const Divider(height: 28),
              Text('Source: ${rule.source}', style: const TextStyle(fontSize: 12, color: Color(0xFF6E5D60))),
            ],
          ),
        ),
      ),
    );
  }

  void _showEventResult(BuildContext context, JaiminiEventScore score) {
    final color = _scoreColor(score.score);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(score.eventTitle, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text(
                '${score.score}/100 • ${score.band}',
                style: TextStyle(fontSize: 22, color: color, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              Text(score.summary),
              const SizedBox(height: 18),
              const Text('100-point decision-support audit', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              ...score.components.map((c) => Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: Icon(c.matched ? Icons.check_circle : Icons.radio_button_unchecked,
                          color: c.matched ? const Color(0xFF1B7F3A) : const Color(0xFF8A7C7E)),
                      title: Text('${c.label} • ${c.awardedScore}/${c.maxScore}',
                          style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: Text('${c.reason}\nRules: ${c.ruleIds.isEmpty ? '—' : c.ruleIds.join(', ')}'),
                      isThreeLine: true,
                    ),
                  )),
              const SizedBox(height: 14),
              const Text('Rule ID → Condition → Match → Reason → Source', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              ...score.ruleChecks.map((r) => Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      onTap: () => _showRuleAudit(sheetContext, r),
                      leading: Icon(r.matched ? Icons.check_circle : Icons.radio_button_unchecked,
                          color: r.matched ? const Color(0xFF1B7F3A) : const Color(0xFF8A7C7E)),
                      title: Text(r.ruleId, style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: Text(r.condition),
                      trailing: const Icon(Icons.chevron_right),
                    ),
                  )),
              const SizedBox(height: 8),
              const Text(
                'ఈ 100-point సంఖ్య classical probability కాదు; app decision-support score మాత్రమే.',
                style: TextStyle(fontSize: 12, color: Color(0xFF6E5D60)),
              ),
            ],
          ),
        ),
      ),
    );
  }


  DateTime _periodMidpoint(DateTime start, DateTime end) {
    final micros = end.difference(start).inMicroseconds;
    return start.add(Duration(microseconds: micros ~/ 2));
  }

  List<JaiminiEventScore> _scoresAt(
    DateTime at,
    JaiminiCharaDashaResult dasha,
  ) {
    final rows = JaiminiCharaDashaService.eventTitles.keys
        .map((eventKey) => JaiminiCharaDashaService.scoreEvent(
              eventKey: eventKey,
              at: at,
              chart: widget.chart,
              jaimini: widget.result,
              dasha: dasha,
            ))
        .toList();
    rows.sort((a, b) => b.score.compareTo(a.score));
    return rows;
  }

  void _showAntardashaPeriodResult(
    BuildContext context,
    JaiminiCharaMahadasha md,
    JaiminiCharaAntardasha ad,
    JaiminiCharaDashaResult dasha,
  ) {
    final at = _periodMidpoint(ad.start, ad.end);
    final scores = _scoresAt(at, dasha);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${AstroFormat.signNamesTe[md.signIndex]} MD → ${AstroFormat.signNamesTe[ad.signIndex]} AD',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              Text('${_date(ad.start)} → ${_date(ad.end)}'),
              const SizedBox(height: 6),
              const Text(
                'ఈ అంతర్దశ మధ్య తేదీ ఆధారంగా event rulesను evaluate చేసి క్రింద చూపిస్తున్నాం. Score classical probability కాదు; app decision-support మాత్రమే.',
                style: TextStyle(fontSize: 12, color: Color(0xFF6E5D60), height: 1.4),
              ),
              const SizedBox(height: 14),
              ...scores.map((score) => Card(
                    margin: const EdgeInsets.only(bottom: 9),
                    child: ListTile(
                      onTap: () => _showEventResult(sheetContext, score),
                      leading: CircleAvatar(
                        backgroundColor: _scoreColor(score.score),
                        child: Text('${score.score}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                      ),
                      title: Text(score.eventTitle, style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: Text('${score.band}\nఫలితం టచ్ చేస్తే Rule audit వస్తుంది.'),
                      isThreeLine: true,
                      trailing: const Icon(Icons.chevron_right),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }

  void _showMahadashaPeriodResult(
    BuildContext context,
    JaiminiCharaMahadasha md,
    JaiminiCharaDashaResult dasha,
  ) {
    final summaries = <({JaiminiEventScore score, int supportiveAds, int bestAdSign})>[];
    for (final eventKey in JaiminiCharaDashaService.eventTitles.keys) {
      JaiminiEventScore? best;
      var supportiveAds = 0;
      var bestAdSign = md.antardashas.first.signIndex;
      for (final ad in md.antardashas) {
        final score = JaiminiCharaDashaService.scoreEvent(
          eventKey: eventKey,
          at: _periodMidpoint(ad.start, ad.end),
          chart: widget.chart,
          jaimini: widget.result,
          dasha: dasha,
        );
        if (score.score >= 50) supportiveAds++;
        if (best == null || score.score > best.score) {
          best = score;
          bestAdSign = ad.signIndex;
        }
      }
      if (best != null) {
        summaries.add((score: best, supportiveAds: supportiveAds, bestAdSign: bestAdSign));
      }
    }
    summaries.sort((a, b) => b.score.score.compareTo(a.score.score));

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${AstroFormat.signNamesTe[md.signIndex]} Mahadasha — కాల ఫలితాలు',
                style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 6),
              Text('${_date(md.start)} → ${_date(md.end)} • ${md.years.toStringAsFixed(md.years == md.years.roundToDouble() ? 0 : 2)} years'),
              const SizedBox(height: 6),
              Text('Lord ${md.selectedLord} • ${md.calculationReason}', style: const TextStyle(fontSize: 12, color: Color(0xFF6E5D60), height: 1.4)),
              const SizedBox(height: 10),
              const Text(
                'మహాదశ మొత్తం 12 అంతర్దశలను విడిగా evaluate చేసి, ప్రతి అంశానికి strongest AD score + 50 పైగా support ఉన్న ADల సంఖ్య చూపిస్తున్నాం.',
                style: TextStyle(fontSize: 12, color: Color(0xFF6E5D60), height: 1.4),
              ),
              const SizedBox(height: 14),
              ...summaries.map((row) => Card(
                    margin: const EdgeInsets.only(bottom: 9),
                    child: ListTile(
                      onTap: () => _showEventResult(sheetContext, row.score),
                      leading: CircleAvatar(
                        backgroundColor: _scoreColor(row.score.score),
                        child: Text('${row.score.score}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                      ),
                      title: Text(row.score.eventTitle, style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: Text(
                        '${row.score.band} • strongest: ${AstroFormat.signNamesTe[row.bestAdSign]} AD\n'
                        'Supportive ADs: ${row.supportiveAds}/12 • టచ్ చేస్తే Rule audit',
                      ),
                      isThreeLine: true,
                      trailing: const Icon(Icons.chevron_right),
                    ),
                  )),
              const SizedBox(height: 6),
              const Text(
                'గమనిక: strongest AD score అనేది app decision-support summary మాత్రమే; ఖచ్చిత సంఘటన probability కాదు.',
                style: TextStyle(fontSize: 12, color: Color(0xFF6E5D60)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _charaDashaPanel(BuildContext context) {
    final dasha = JaiminiCharaDashaService.calculate(
      chart: widget.chart,
      birthDateTime: widget.birthData.localDateTime,
      config: _config,
    );
    final now = DateTime.now();
    final currentMd = dasha.mahadashaAt(now);
    final currentAd = dasha.antardashaAt(now);
    final eventScore = JaiminiCharaDashaService.scoreEvent(
      eventKey: _eventKey,
      at: now,
      chart: widget.chart,
      jaimini: widget.result,
      dasha: dasha,
    );

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Divider(height: 30),
        const Text('Chara Dasha • CD-01–CD-07', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        const Text(
          'Method A / Method B / Customను వేర్వేరు variantsగా ఉంచాం. Sourceలో స్పష్టంగా లేని co-lord strength tieను autoగా invent చేయకుండా manual override అందుబాటులో ఉంది.',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B5B5E)),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<JaiminiCharaMethod>(
          value: _method,
          decoration: const InputDecoration(labelText: 'Chara Dasha Method', border: OutlineInputBorder()),
          items: JaiminiCharaMethod.values
              .map((m) => DropdownMenuItem(value: m, child: Text(m.label)))
              .toList(),
          onChanged: (v) => setState(() => _method = v ?? _method),
        ),
        if (_method == JaiminiCharaMethod.custom) ...[
          const SizedBox(height: 10),
          DropdownButtonFormField<int>(
            value: _customStartSign,
            decoration: const InputDecoration(labelText: 'Starting sign', border: OutlineInputBorder()),
            items: List.generate(12, (i) => DropdownMenuItem(value: i, child: Text('${i + 1} • ${AstroFormat.signNamesTe[i]}'))),
            onChanged: (v) => setState(() => _customStartSign = v ?? _customStartSign),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<bool>(
            value: _customForward,
            decoration: const InputDecoration(labelText: 'Direction', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: true, child: Text('Forward / Clockwise')),
              DropdownMenuItem(value: false, child: Text('Reverse / Anti-clockwise')),
            ],
            onChanged: (v) => setState(() => _customForward = v ?? _customForward),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _selfYearsController,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Own-sign duration (years)', border: OutlineInputBorder()),
            onChanged: (_) => setState(() {}),
          ),
        ],
        const SizedBox(height: 10),
        DropdownButtonFormField<JaiminiCoLordChoice>(
          value: _scorpioChoice,
          decoration: const InputDecoration(labelText: 'Scorpio • Mars / Ketu', border: OutlineInputBorder()),
          items: JaiminiCoLordChoice.values.map((c) => DropdownMenuItem(
            value: c,
            child: Text(c == JaiminiCoLordChoice.primary ? 'Mars only' : c == JaiminiCoLordChoice.node ? 'Ketu co-lord' : c.label),
          )).toList(),
          onChanged: (v) => setState(() => _scorpioChoice = v ?? _scorpioChoice),
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<JaiminiCoLordChoice>(
          value: _aquariusChoice,
          decoration: const InputDecoration(labelText: 'Aquarius • Saturn / Rahu', border: OutlineInputBorder()),
          items: JaiminiCoLordChoice.values.map((c) => DropdownMenuItem(
            value: c,
            child: Text(c == JaiminiCoLordChoice.primary ? 'Saturn only' : c == JaiminiCoLordChoice.node ? 'Rahu co-lord' : c.label),
          )).toList(),
          onChanged: (v) => setState(() => _aquariusChoice = v ?? _aquariusChoice),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF8EA),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFE9D39A)),
          ),
          child: Text(
            'Start: ${dasha.startSignIndex + 1} ${AstroFormat.signNamesTe[dasha.startSignIndex]} • '
            'Sequence: ${dasha.sequenceForward ? 'Forward' : 'Reverse'}\n'
            'ప్రస్తుతం: ${currentMd == null ? '—' : '${AstroFormat.signNamesTe[currentMd.signIndex]} MD'} / '
            '${currentAd == null ? '—' : '${AstroFormat.signNamesTe[currentAd.signIndex]} AD'}',
          ),
        ),
        const SizedBox(height: 12),
        ExpansionTile(
          tilePadding: EdgeInsets.zero,
          title: const Text('Chara Mahadasha + Antardasha calendar', style: TextStyle(fontWeight: FontWeight.w900)),
          subtitle: const Text('ప్రతి period టచ్ చేస్తే ఆ దశ/అంతర్దశ ఫలితాలు + Rule audit'),
          children: dasha.mahadashas.map((md) => ExpansionTile(
                tilePadding: const EdgeInsets.symmetric(horizontal: 4),
                title: InkWell(
                  onTap: () => _showMahadashaPeriodResult(context, md, dasha),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${AstroFormat.signNamesTe[md.signIndex]} • ${md.years.toStringAsFixed(md.years == md.years.roundToDouble() ? 0 : 2)} years',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        const Text('ఫలితం', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Color(0xFF8D3140))),
                        const SizedBox(width: 3),
                        const Icon(Icons.analytics_outlined, size: 18, color: Color(0xFF8D3140)),
                      ],
                    ),
                  ),
                ),
                subtitle: Text('${_date(md.start)} → ${_date(md.end)} • Lord ${md.selectedLord}\n${md.calculationReason}'),
                children: md.antardashas.map((ad) => ListTile(
                      dense: true,
                      onTap: () => _showAntardashaPeriodResult(context, md, ad, dasha),
                      title: Text('${AstroFormat.signNamesTe[ad.signIndex]} AD', style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${_date(ad.start)} → ${_date(ad.end)}\nటచ్ చేస్తే ఈ అంతర్దశలో అన్ని అంశాల ఫలితాలు'),
                      isThreeLine: true,
                      trailing: const Icon(Icons.chevron_right),
                    )).toList(),
              )).toList(),
        ),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: _eventKey,
          decoration: const InputDecoration(labelText: 'Event analysis', border: OutlineInputBorder()),
          items: JaiminiCharaDashaService.eventTitles.entries
              .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
              .toList(),
          onChanged: (v) => setState(() => _eventKey = v ?? _eventKey),
        ),
        const SizedBox(height: 12),
        InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: () => _showEventResult(context, eventScore),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: _scoreColor(eventScore.score).withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _scoreColor(eventScore.score).withOpacity(0.35)),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: _scoreColor(eventScore.score),
                  child: Text('${eventScore.score}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(eventScore.eventTitle, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 3),
                      Text('${eventScore.band} • పలితం టచ్ చేస్తే పూర్తి Rule audit వస్తుంది.'),
                    ],
                  ),
                ),
                const Icon(Icons.chevron_right),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'Score bands: 0–29 Weak • 30–49 Possible • 50–69 Moderate • 70–84 Strong • 85–100 Very Strong. ఇది app decision-support మాత్రమే; classical probability కాదు.',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B5B5E)),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final rahu = widget.chart.planets.firstWhere((p) => p.name == 'Rahu');
    final rahuEffective = 30.0 - rahu.degreesInSign;
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('జైమిని System', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            _JaiminiApplicableRules(rules: widget.result.applicableRules),
            const SizedBox(height: 16),
            _SouthIndianChart(
              title: 'జైమిని చక్రం • P1–P12',
              ascendantSignIndex: widget.chart.ascendantSignIndex,
              occupants: _jaiminiOccupants(),
              onOccupantTap: (label) {
                final planet = _planetFromOccupantLabel(widget.chart, label);
                if (planet != null) _showPlanetDetailSheet(context, widget.chart, planet);
              },
            ),
            const SizedBox(height: 12),
            const Text('Pada / Arudha P1–P12', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...widget.result.arudhaPadas.map(
              (p) => Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(
                  'P${p.padaNumber}: ${p.sourceSignIndex + 1} → ${p.lord} ${p.lordSignIndex + 1} • దూరం ${p.distance} → ${p.padaSignIndex + 1}',
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text('Atmakaraka: ${widget.result.atmakaraka}'),
            Text('Karakamsa: ${widget.result.karakamsaSignIndex + 1}'),
            Text('Rahu effective degree reference: ${rahuEffective.toStringAsFixed(4)}°'),
            if (widget.result.hasDegreeTie)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text(
                  'Degree tie detected — supplied source tie/empty-slot procedure must be applied manually before final karaka assignment.',
                  style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF8D3140)),
                ),
              ),
            const SizedBox(height: 10),
            const Text('Chara Karakas (7-karaka core)', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: widget.result.charaKarakas
                  .map((k) => Chip(label: Text('${k.code}: ${k.planet} ${k.effectiveDegree.toStringAsFixed(2)}°')))
                  .toList(),
            ),
            const SizedBox(height: 12),
            const Text('Lagna Argala / Virodha', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            ...widget.result.argalaFromLagna.map(
              (row) => Text(
                '${row.label}: ${row.signIndex + 1}  ${row.planets.isEmpty ? '—' : row.planets.join(', ')}',
              ),
            ),
            const SizedBox(height: 12),
            const Text('Rashi Drishti', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...List.generate(12, (i) {
              final targets = widget.result.rashiDrishti[i]!.map((s) => '${s + 1}').join(', ');
              return Text('${i + 1} → $targets');
            }),
            const SizedBox(height: 8),
            const Text(
              'P1–P12 calculation: source sign నుండి lord వరకు inclusive దూరం ఎంతైతే, lord నుండి అదే inclusive దూరం count చేసి Pada పొందుతుంది. 4వ/7వ source examples కూడా ఇదే విధంగా అమలవుతాయి.',
              style: TextStyle(fontSize: 12),
            ),
            _charaDashaPanel(context),
          ],
        ),
      ),
    );
  }
}


class _JaiminiApplicableRules extends StatelessWidget {
  final List<JaiminiRuleHit> rules;

  const _JaiminiApplicableRules({required this.rules});

  Color _color(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => const Color(0xFF1B7F3A),
        JaiminiRuleNature.adverse => const Color(0xFFB3261E),
        JaiminiRuleNature.neutral => const Color(0xFF6B5B5E),
      };

  IconData _icon(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => Icons.check_circle,
        JaiminiRuleNature.adverse => Icons.cancel,
        JaiminiRuleNature.neutral => Icons.info_outline,
      };

  String _status(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => 'అనుకూలం',
        JaiminiRuleNature.adverse => 'ప్రతికూలం / జాగ్రత్త',
        JaiminiRuleNature.neutral => 'వివరణాత్మక సూచన',
      };

  String _groupTitle(String topic) {
    final t = topic.toLowerCase();
    if (t.contains('వివాహ') || t.contains('దాంపత్య') || t.contains('upapada') || t.contains('సంబంధ')) return 'వివాహం / సంబంధాలు';
    if (t.contains('ధనం') || t.contains('లాభ') || t.contains('వ్యయం') || t.contains('ఆర్థిక')) return 'ధనం / లాభం / వ్యయం';
    if (t.contains('వృత్తి') || t.contains('ప్రతిష్ఠ') || t.contains('స్థాయి') || t.contains('సేవ')) return 'వృత్తి / స్థాయి / ప్రతిష్ఠ';
    if (t.contains('విద్య') || t.contains('పాండిత్య') || t.contains('బుద్ధి')) return 'విద్య / పాండిత్యం';
    if (t.contains('సంతానం')) return 'సంతానం';
    if (t.contains('ఇల్లు') || t.contains('స్థిరాస్తి') || t.contains('సౌఖ్యం')) return 'ఇల్లు / స్థిరాస్తి / సౌఖ్యం';
    if (t.contains('ధర్మ') || t.contains('ఆధ్యాత్మిక') || t.contains('గురువు')) return 'ధర్మం / ఆధ్యాత్మికం';
    if (t.contains('రాజయోగ') || t.contains('అధికారం')) return 'రాజయోగం / అధికారం';
    if (t.contains('ఆరోగ్య')) return 'ఆరోగ్య సూచనలు';
    if (t.contains('సోదర')) return 'సోదరులు / కుటుంబం';
    if (t.contains('ఆత్మకారక') || t.contains('కారకాంశ')) return 'కారకాలు / స్వభావం';
    return 'ఇతర జైమిని ఫలితాలు';
  }

  Color _groupColor(List<JaiminiRuleHit> rows) {
    if (rows.any((r) => r.nature == JaiminiRuleNature.adverse)) return const Color(0xFFB3261E);
    if (rows.isNotEmpty && rows.every((r) => r.nature == JaiminiRuleNature.favorable)) return const Color(0xFF1B7F3A);
    if (rows.any((r) => r.nature == JaiminiRuleNature.favorable)) return const Color(0xFFB26A00);
    return const Color(0xFF6E5D60);
  }

  Widget _topicDashboard(BuildContext context) {
    final grouped = <String, List<JaiminiRuleHit>>{};
    for (final rule in rules) {
      grouped.putIfAbsent(_groupTitle(rule.topic), () => <JaiminiRuleHit>[]).add(rule);
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('జైమిని అంశాల ఫలితాలు',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text(
          'అంశం టచ్ చేస్తే ఈ జాతకానికి వర్తించిన Jaimini combinations మాత్రమే కనిపిస్తాయి. అనుకూలం ఆకుపచ్చ ✓; ప్రతికూల/జాగ్రత్త ఎరుపు; మిశ్రమం amber.',
          style: TextStyle(height: 1.4, color: Color(0xFF6E5D60)),
        ),
        const SizedBox(height: 10),
        ...grouped.entries.map((entry) {
          final color = _groupColor(entry.value);
          final fav = entry.value.where((r) => r.nature == JaiminiRuleNature.favorable).length;
          final adv = entry.value.where((r) => r.nature == JaiminiRuleNature.adverse).length;
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            surfaceTintColor: Colors.transparent,
            child: ExpansionTile(
              leading: Icon(
                adv > 0 ? Icons.warning_amber_rounded : fav == entry.value.length ? Icons.check_circle : Icons.analytics_outlined,
                color: color,
              ),
              title: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w900)),
              subtitle: Text('${entry.value.length} applied rules • అనుకూలం $fav${adv == 0 ? '' : ' • జాగ్రత్త $adv'}'),
              children: entry.value.map((rule) {
                final c = _color(rule.nature);
                return ListTile(
                  leading: Icon(_icon(rule.nature), color: c),
                  title: Text(rule.result, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${rule.topic}\n${rule.combination}', maxLines: 3, overflow: TextOverflow.ellipsis),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showDetails(context, rule),
                );
              }).toList(),
            ),
          );
        }),
      ],
    );
  }

  void _showDetails(BuildContext context, JaiminiRuleHit rule) {
    final color = _color(rule.nature);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            18,
            20,
            24 + MediaQuery.of(sheetContext).viewInsets.bottom,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(_icon(rule.nature), color: color, size: 30),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          rule.topic,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          _status(rule.nature),
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                rule.combination,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
              ),
              const Divider(height: 28),
              const Text('పలితం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.result, style: const TextStyle(fontSize: 16, height: 1.45)),
              const SizedBox(height: 18),
              const Text('జాతక పరిశీలన', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.analysis, style: const TextStyle(fontSize: 16, height: 1.45)),
              const SizedBox(height: 18),
              const Text('పరిహారం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.remedy, style: const TextStyle(fontSize: 16, height: 1.45)),
              const Divider(height: 28),
              Text(
                '${rule.ruleId} • ${rule.source}',
                style: const TextStyle(fontSize: 12, color: Color(0xFF6E5D60)),
              ),
              const SizedBox(height: 8),
              const Text(
                'గమనిక: ఒకే నియమంతో తుది తీర్పు ఇవ్వకుండా, అనుకూల మరియు ప్రతికూల supporting rules అన్నింటినీ కలిపి పరిశీలించాలి.',
                style: TextStyle(fontSize: 12, color: Color(0xFF6E5D60)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (rules.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF7F3),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE4C6C9)),
        ),
        child: const Text(
          'ఈ జాతకానికి ప్రస్తుతం active source-verified Jaimini combinations match కాలేదు. Chart, P1–P12, Karakas మాత్రం క్రింద చూడవచ్చు.',
        ),
      );
    }

    final yogaCount = rules.where((r) => r.isYoga).length;
    final favorable = rules.where((r) => r.nature == JaiminiRuleNature.favorable).length;
    final adverse = rules.where((r) => r.nature == JaiminiRuleNature.adverse).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _topicDashboard(context),
        const SizedBox(height: 12),
        ExpansionTile(
          title: const Text('అప్లయ్ అయిన అన్ని Jaimini Rules',
              style: TextStyle(fontWeight: FontWeight.w900)),
          subtitle: Text('యోగాలు $yogaCount • అనుకూలం $favorable • జాగ్రత్త $adverse'),
          children: rules.map((rule) {
            final color = _color(rule.nature);
            return ListTile(
              leading: Icon(_icon(rule.nature), color: color),
              title: Text('అంశము: ${rule.topic}', style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('పలితం: ${rule.result}\n${rule.combination}', maxLines: 4, overflow: TextOverflow.ellipsis),
              isThreeLine: true,
              trailing: const Icon(Icons.touch_app_outlined),
              onTap: () => _showDetails(context, rule),
            );
          }).toList(),
        ),
      ],
    );
  }

}

class _KpCard extends StatelessWidget {
  final List<KpStellarPosition> rows;

  const _KpCard({required this.rows});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('KP System', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'Planet → Sign Lord → Star Lord → Sub Lord stellar table. Sub divisions use unequal Vimshottari proportions inside each 13°20′ star.',
            ),
            const SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('Planet')),
                  DataColumn(label: Text('Sign Lord')),
                  DataColumn(label: Text('Star Lord')),
                  DataColumn(label: Text('Sub Lord')),
                ],
                rows: rows.map((r) => DataRow(cells: [
                      DataCell(Text(r.body)),
                      DataCell(Text(r.signLord)),
                      DataCell(Text(r.starLord)),
                      DataCell(Text(r.subLord)),
                    ])).toList(),
              ),
            ),
            const SizedBox(height: 12),
            const Text('Source-based Event House Groups', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...KpService.eventGroups.map(
              (e) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '${e.event}: ${e.favourableHouses.join(', ')}  • Primary ${e.primaryCusp}'
                  '${e.contraryHouses.isEmpty ? '' : ' • Contrary ${e.contraryHouses.join(', ')}'}',
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'KP Cusp Sub-Lord promise/denial engineకు exact 12 cusp longitudes + house ownership/signification layer అవసరం. ఈ buildలో planetary Star/Sub coreను మాత్రమే activate చేశాం; cusp resultను ఊహించి చూపడం లేదు.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class _SourcePendingCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final String text;

  const _SourcePendingCard({
    required this.title,
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: const Color(0xFF7B1E2B)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(text),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BirthSummaryCard extends StatelessWidget {
  final BirthData birthData;

  const _BirthSummaryCard({required this.birthData});

  @override
  Widget build(BuildContext context) {
    final dt = birthData.localDateTime;
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              birthData.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('లింగం: ${birthData.gender.label}'),
            Text('స్థలం: ${birthData.place}'),
            Text(
              'Lat ${birthData.latitude.toStringAsFixed(6)}  •  '
              'Lon ${birthData.longitude.toStringAsFixed(6)}',
            ),
            Text('జనన సమయం: ${AstroFormat.dateTime(dt)}'),
            Text(
              'Timezone: ${AstroFormat.timezoneOffset(birthData.timezoneOffsetHours)}',
            ),
          ],
        ),
      ),
    );
  }
}

class _CalculationSummaryCard extends StatelessWidget {
  final AstroChartResult result;
  final String ayanamsaName;

  const _CalculationSummaryCard({
    required this.result,
    required this.ayanamsaName,
  });

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.verified_outlined),
                SizedBox(width: 8),
                Text(
                  'Calculation',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text('Engine: Swiss Ephemeris ${result.engineVersion}'),
            const Text('Mode: Sidereal + Moshier ephemeris'),
            Text('Ayanamsa: $ayanamsaName'),
            Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
            const SizedBox(height: 8),
            Text(
              'లగ్నం: ${AstroFormat.longitudeDms(result.ascendantLongitude)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

class _SouthIndianChart extends StatelessWidget {
  final String title;
  final int ascendantSignIndex;
  final Map<int, List<String>> occupants;
  final ValueChanged<String>? onOccupantTap;

  const _SouthIndianChart({
    required this.title,
    required this.ascendantSignIndex,
    required this.occupants,
    this.onOccupantTap,
  });

  // Traditional South-Indian fixed-sign layout (fixed Rasi positions).
  // Row 1: Pisces | Aries | Taurus | Gemini
  // Row 2: Aquarius |        centre       | Cancer
  // Row 3: Capricorn|        centre       | Leo
  // Row 4: Sagittarius | Scorpio | Libra | Virgo
  static const Map<int, (int, int)> _positionBySign = <int, (int, int)>{
    11: (0, 0), // Pisces
    0: (0, 1),  // Aries
    1: (0, 2),  // Taurus
    2: (0, 3),  // Gemini
    10: (1, 0), // Aquarius
    3: (1, 3),  // Cancer
    9: (2, 0),  // Capricorn
    4: (2, 3),  // Leo
    8: (3, 0),  // Sagittarius
    7: (3, 1),  // Scorpio
    6: (3, 2),  // Libra
    5: (3, 3),  // Virgo
  };

  @override
  Widget build(BuildContext context) {
    const lineColor = Color(0xFF8B2D3B);
    const centreColor = Color(0xFFFFFBF6);

    return Card(color: Colors.white, surfaceTintColor: Colors.transparent,
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Color(0xFF2C2022),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'South Indian fixed-sign chart',
              style: const TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: Color(0xFF5F5052),
              ),
            ),
            const SizedBox(height: 12),
            AspectRatio(
              aspectRatio: 1,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final side = constraints.maxWidth;
                  final cell = side / 4;
                  return DecoratedBox(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: lineColor, width: 2),
                    ),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        for (final entry in _positionBySign.entries)
                          Positioned(
                            left: entry.value.$2 * cell,
                            top: entry.value.$1 * cell,
                            width: cell,
                            height: cell,
                            child: _TraditionalRasiCell(
                              signIndex: entry.key,
                              isAscendant: entry.key == ascendantSignIndex,
                              occupants: occupants[entry.key] ?? const <String>[],
                              onOccupantTap: onOccupantTap,
                            ),
                          ),
                        Positioned(
                          left: cell,
                          top: cell,
                          width: cell * 2,
                          height: cell * 2,
                          child: Container(
                            decoration: BoxDecoration(
                              color: centreColor,
                              border: Border.all(color: lineColor, width: 2),
                            ),
                            padding: const EdgeInsets.all(10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  title,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFF2C2022),
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'లగ్నం',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    color: lineColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TraditionalRasiCell extends StatelessWidget {
  final int signIndex;
  final bool isAscendant;
  final List<String> occupants;
  final ValueChanged<String>? onOccupantTap;

  const _TraditionalRasiCell({
    required this.signIndex,
    required this.isAscendant,
    required this.occupants,
    this.onOccupantTap,
  });

  @override
  Widget build(BuildContext context) {
    const lineColor = Color(0xFF8B2D3B);
    return Container(
      decoration: BoxDecoration(
        color: isAscendant ? const Color(0xFFFFECEF) : Colors.white,
        border: Border.all(color: lineColor, width: 1),
      ),
      padding: const EdgeInsets.all(5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (isAscendant)
            Align(
              alignment: Alignment.topRight,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: lineColor,
                ),
                child: const Text(
                  'Lg',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          if (isAscendant) const SizedBox(height: 4),
          Expanded(
            child: SingleChildScrollView(
              child: Wrap(
                spacing: 4,
                runSpacing: 2,
                children: occupants.map((text) {
                  final child = Text(
                    text,
                    style: const TextStyle(
                      fontSize: 10.8,
                      height: 1.15,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF3B2C2E),
                    ),
                  );
                  if (onOccupantTap == null) return child;
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => onOccupantTap!(text),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: child,
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReportActions extends StatelessWidget {
  final String title;
  final String Function() reportText;
  final Future<void> Function()? onSaveChart;

  const _ReportActions({
    required this.title,
    required this.reportText,
    this.onSaveChart,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Save / Report',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            if (onSaveChart != null) ...[
              const Text(
                'Save Chart → Saved Chartsలో నిల్వ అవుతుంది. తర్వాత Saved Charts నుంచి మళ్లీ Open / Edit చేయవచ్చు.',
                style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () async => onSaveChart!(),
                  icon: const Icon(Icons.bookmark_add_outlined),
                  label: const Text('Save Chart — Reopen Later'),
                ),
              ),
              const SizedBox(height: 10),
            ],
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(text: reportText()),
                      );
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Report clipboardకి copy అయింది'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.copy_all_outlined),
                    label: const Text('Copy'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await ReportStorageService.save(
                        title: title,
                        body: reportText(),
                      );
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Text report Reportsలో save అయింది'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.description_outlined),
                    label: const Text('Save Report'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () async {
                  await SharePlus.instance.share(
                    ShareParams(
                      text: reportText(),
                      title: 'Annapurna Astro Vastu - $title',
                    ),
                  );
                },
                icon: const Icon(Icons.share_outlined),
                label: const Text('Share Report'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;

  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
    );
  }
}

Map<int, List<String>> _occupantsFromVarga(
  VargaChartData data, {
  AstroChartResult? includeDegreesFrom,
}) {
  final result = <int, List<String>>{
    for (var i = 0; i < 12; i++) i: <String>[],
  };

  for (final planet in data.planets) {
    var label = planet.shortName;
    if (includeDegreesFrom != null) {
      final source =
          includeDegreesFrom.planets.firstWhere((p) => p.name == planet.name);
      label += ' ${AstroFormat.degreeDms(source.degreesInSign)}';
    }
    if (planet.retrograde) label += 'R';
    result[planet.signIndex]!.add(label);
  }
  return result;
}

class _ErrorView extends StatelessWidget {
  final String message;

  const _ErrorView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 46),
                const SizedBox(height: 12),
                const Text(
                  'Calculation ప్రారంభం కాలేదు',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(message, textAlign: TextAlign.center),
                const SizedBox(height: 10),
                const Text(
                  'flutter pub get చేసిన తర్వాత Android buildలో sweph native library కూడా build అవుతుంది.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
