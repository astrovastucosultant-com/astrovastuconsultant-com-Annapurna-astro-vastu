import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../astrology/ashtakavarga_service.dart';
import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/varga_service.dart';
import '../astrology/vedic_calculation_service.dart';
import '../models/birth_data.dart';
import '../services/report_storage_service.dart';
import '../utils/astro_format.dart';

class ChartScreen extends StatefulWidget {
  final BirthData birthData;

  const ChartScreen({
    super.key,
    required this.birthData,
  });

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  late final Future<AstroChartResult> _future;
  int _selectedVarga = 9;
  String _selectedBav = 'Sun';

  static const signNames = AstroFormat.signNamesTe;

  @override
  void initState() {
    super.initState();
    _future = AstroCalculationService.calculate(widget.birthData);
  }

  String _formatDateTime(DateTime dt) => AstroFormat.dateTime(dt);

  String _formatLongitude(double longitude) =>
      AstroFormat.longitudeDms(longitude);

  String _reportText(AstroChartResult result) {
    final b = widget.birthData;
    final panchanga = VedicCalculationService.panchanga(result);
    final av = AshtakavargaService.calculate(result);
    final d9 = VargaService.calculate(result, 9);
    final d10 = VargaService.calculate(result, 10);

    String placementText(VargaChartData data) {
      final items = data.planets
          .map((p) => '${p.shortName}:${signNames[p.signIndex]}')
          .join(', ');
      return '${data.definition.code} ${data.definition.teluguName}: '
          'Lg ${signNames[data.ascendantSignIndex]} | $items';
    }

    final buffer = StringBuffer()
      ..writeln('అన్నపూర్ణ ఆస్ట్రో వాస్తు')
      ..writeln('పేరు: ${b.name}')
      ..writeln('స్థలం: ${b.place}')
      ..writeln('Latitude: ${b.latitude}, Longitude: ${b.longitude}')
      ..writeln('Local: ${_formatDateTime(b.localDateTime)}')
      ..writeln('UTC: ${_formatDateTime(b.utcDateTime)}')
      ..writeln('Ayanamsa: ${b.ayanamsa.label}')
      ..writeln('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°')
      ..writeln('Lagna: ${_formatLongitude(result.ascendantLongitude)}')
      ..writeln('')
      ..writeln('పంచాంగ సారాంశం:')
      ..writeln('${panchanga.paksha} • ${panchanga.tithi}')
      ..writeln(
        '${panchanga.nakshatra} ${panchanga.nakshatraPada} పాదం • ${panchanga.yoga} యోగం • ${panchanga.karana} కరణం',
      )
      ..writeln('')
      ..writeln('గ్రహ స్థితులు:');

    for (final planet in result.planets) {
      final n = VedicCalculationService.nakshatra(planet.longitude);
      final house = VedicCalculationService.wholeSignHouse(
        planet.signIndex,
        result.ascendantSignIndex,
      );
      buffer.writeln(
        '${planet.name}: ${_formatLongitude(planet.longitude)} | '
        '${VedicCalculationService.nakshatraNamesTe[n.index]}-${n.pada} | '
        'House $house${planet.retrograde ? ' | R' : ''}',
      );
    }

    buffer
      ..writeln('')
      ..writeln(placementText(d9))
      ..writeln(placementText(d10))
      ..writeln('')
      ..writeln('Sarvashtakavarga: ${av.sarva.join(', ')}')
      ..writeln('SAV Total: ${av.grandTotal} ${av.totalsValid ? '(verified)' : '(check required)'}')
      ..writeln('')
      ..writeln('Engine: Swiss Ephemeris ${result.engineVersion} (Moshier mode)');
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('జాతక విశ్లేషణ • Build 9'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(icon: Icon(Icons.grid_on_outlined), text: 'జాతకం'),
              Tab(icon: Icon(Icons.dashboard_outlined), text: 'వర్గాలు'),
              Tab(icon: Icon(Icons.apps_outlined), text: 'అష్టకవర్గం'),
              Tab(icon: Icon(Icons.calculate_outlined), text: 'లెక్కలు'),
            ],
          ),
        ),
        body: FutureBuilder<AstroChartResult>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 14),
                    Text('Swiss Ephemeris calculation జరుగుతోంది…'),
                  ],
                ),
              );
            }

            if (snapshot.hasError || !snapshot.hasData) {
              return _ErrorView(
                message: snapshot.error?.toString() ?? 'Calculation failed',
              );
            }

            final result = snapshot.data!;
            final av = AshtakavargaService.calculate(result);
            return TabBarView(
              children: [
                _JatakaTab(
                  birthData: widget.birthData,
                  result: result,
                  reportText: () => _reportText(result),
                ),
                _VargaTab(
                  result: result,
                  selectedVarga: _selectedVarga,
                  onChanged: (value) => setState(() => _selectedVarga = value),
                ),
                _AshtakavargaTab(
                  result: av,
                  ascendantSignIndex: result.ascendantSignIndex,
                  selectedPlanet: _selectedBav,
                  onPlanetChanged: (value) =>
                      setState(() => _selectedBav = value),
                ),
                _CalculationsTab(
                  birthData: widget.birthData,
                  result: result,
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _JatakaTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;
  final String Function() reportText;

  const _JatakaTab({
    required this.birthData,
    required this.result,
    required this.reportText,
  });

  @override
  Widget build(BuildContext context) {
    final rasi = VargaService.calculate(result, 1);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _BirthSummaryCard(birthData: birthData),
        const SizedBox(height: 12),
        _CalculationSummaryCard(
          result: result,
          ayanamsaName: birthData.ayanamsa.label,
        ),
        const SizedBox(height: 16),
        const _SectionTitle('రాశి / జన్మ చక్రం'),
        const SizedBox(height: 10),
        _SouthIndianChart(
          title: 'D1 రాశి',
          ascendantSignIndex: rasi.ascendantSignIndex,
          occupants: _occupantsFromVarga(rasi, includeDegreesFrom: result),
        ),
        const SizedBox(height: 18),
        const _SectionTitle('గ్రహ స్థితులు'),
        const SizedBox(height: 8),
        ...result.planets.map((planet) {
          final n = VedicCalculationService.nakshatra(planet.longitude);
          final house = VedicCalculationService.wholeSignHouse(
            planet.signIndex,
            result.ascendantSignIndex,
          );
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              title: Text(
                planet.name,
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              subtitle: Text(
                '${AstroFormat.longitudeDms(planet.longitude)}\n'
                '${VedicCalculationService.nakshatraNamesTe[n.index]} • ${n.pada} పాదం • House $house',
              ),
              isThreeLine: true,
              trailing: planet.retrograde
                  ? const Chip(label: Text('R'))
                  : null,
            ),
          );
        }),
        const SizedBox(height: 12),
        _ReportActions(
          title: birthData.name,
          reportText: reportText,
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _VargaTab extends StatelessWidget {
  final AstroChartResult result;
  final int selectedVarga;
  final ValueChanged<int> onChanged;

  const _VargaTab({
    required this.result,
    required this.selectedVarga,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final data = VargaService.calculate(result, selectedVarga);
    final definition = data.definition;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('షోడశ వర్గ చక్రములు'),
        const SizedBox(height: 8),
        const Text(
          'D1 నుంచి D60 వరకు 16 classical Parashari vargas. ప్రతి వర్గం అదే sidereal planetary longitude ను తన ప్రత్యేక నియమంతో కొత్త రాశిలో map చేస్తుంది.',
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: VargaService.definitions.map((v) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(v.code),
                  selected: selectedVarga == v.factor,
                  onSelected: (_) => onChanged(v.factor),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${definition.code} ${definition.teluguName} (${definition.name})',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text('ప్రధాన ఉపయోగం: ${definition.domain}'),
                Text('Division: 30° / ${definition.factor}'),
                if (definition.factor >= 40) ...[
                  const SizedBox(height: 8),
                  const Text(
                    'గమనిక: D40 / D45 / D60 లగ్నం జనన సమయానికి చాలా సున్నితంగా మారుతుంది.',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        _SouthIndianChart(
          title: '${definition.code} ${definition.teluguName}',
          ascendantSignIndex: data.ascendantSignIndex,
          occupants: _occupantsFromVarga(data),
        ),
        const SizedBox(height: 14),
        _VargaPlanetList(data: data),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _VargaPlanetList extends StatelessWidget {
  final VargaChartData data;

  const _VargaPlanetList({required this.data});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text(
                'వర్గ గ్రహ స్థానాలు',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Lagna: ${AstroFormat.signNamesTe[data.ascendantSignIndex]}',
              ),
            ),
            const Divider(),
            ...data.planets.map(
              (p) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(p.name),
                trailing: Text(
                  '${AstroFormat.signNamesTe[p.signIndex]}${p.retrograde ? '  R' : ''}',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AshtakavargaTab extends StatelessWidget {
  final AshtakavargaResult result;
  final int ascendantSignIndex;
  final String selectedPlanet;
  final ValueChanged<String> onPlanetChanged;

  const _AshtakavargaTab({
    required this.result,
    required this.ascendantSignIndex,
    required this.selectedPlanet,
    required this.onPlanetChanged,
  });

  @override
  Widget build(BuildContext context) {
    final bav = result.bhinna[selectedPlanet]!;
    final expected = result.expectedPlanetTotals[selectedPlanet]!;
    final actual = result.totalFor(selectedPlanet);
    final prastara = result.prastara[selectedPlanet]!;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('అష్టకవర్గం'),
        const SizedBox(height: 8),
        const Text(
          'Parashari Bhinna Ashtakavarga (BAV) లో సూర్యుడు నుంచి శని వరకు 7 గ్రహాలకు, 7 గ్రహాలు + లగ్నం అనే 8 reference points నుంచి bindus లెక్కించబడతాయి. SAV అనేది 7 BAV rows యొక్క మొత్తం.',
        ),
        const SizedBox(height: 12),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(
                  result.totalsValid
                      ? Icons.verified_outlined
                      : Icons.warning_amber_outlined,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Sarvashtakavarga (SAV)',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text('Grand total: ${result.grandTotal} / 337'),
                      Text(
                        result.totalsValid
                            ? 'Classical fixed totals verification passed.'
                            : 'Fixed total verification failed — result check చేయాలి.',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: 'Sarvashtakavarga (SAV)',
          values: result.sarva,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _ScoreGrid(values: result.sarva),
        const SizedBox(height: 18),
        DropdownButtonFormField<String>(
          value: selectedPlanet,
          decoration: const InputDecoration(
            labelText: 'Bhinna Ashtakavarga గ్రహం',
            border: OutlineInputBorder(),
          ),
          items: AshtakavargaService.planetOrder
              .map(
                (planet) => DropdownMenuItem(
                  value: planet,
                  child: Text(planet),
                ),
              )
              .toList(),
          onChanged: (value) {
            if (value != null) onPlanetChanged(value);
          },
        ),
        const SizedBox(height: 10),
        Card(
          child: ListTile(
            title: Text('$selectedPlanet BAV'),
            subtitle: Text('Bindu total: $actual / expected $expected'),
            trailing: actual == expected
                ? const Icon(Icons.check_circle_outline)
                : const Icon(Icons.error_outline),
          ),
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: '$selectedPlanet BAV',
          values: bav,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _ScoreGrid(values: bav),
        const SizedBox(height: 18),
        const _SectionTitle('Prastara Ashtakavarga'),
        const SizedBox(height: 8),
        const Text(
          'ఎంచుకున్న గ్రహం BAV లో 7 గ్రహాలు + లగ్నం నుంచి ఏ రాశికి bindu వచ్చిందో 1/0 రూపంలో చూపిస్తుంది.',
        ),
        const SizedBox(height: 8),
        _PrastaraTable(rows: prastara),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _AshtakavargaSouthChart extends StatelessWidget {
  final String title;
  final List<int> values;
  final int ascendantSignIndex;

  const _AshtakavargaSouthChart({
    required this.title,
    required this.values,
    required this.ascendantSignIndex,
  });

  @override
  Widget build(BuildContext context) {
    final occupants = <int, List<String>>{
      for (var sign = 0; sign < 12; sign++) sign: ['${values[sign]}'],
    };
    return _SouthIndianChart(
      title: title,
      ascendantSignIndex: ascendantSignIndex,
      occupants: occupants,
    );
  }
}

class _PrastaraTable extends StatelessWidget {
  final Map<String, List<int>> rows;

  const _PrastaraTable({required this.rows});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columnSpacing: 18,
          columns: [
            const DataColumn(label: Text('Ref')),
            ...List.generate(
              12,
              (index) => DataColumn(
                label: Text(
                  AstroFormat.signNamesTe[index],
                  style: const TextStyle(fontSize: 11),
                ),
              ),
            ),
          ],
          rows: rows.entries.map((entry) {
            return DataRow(
              cells: [
                DataCell(Text(entry.key)),
                ...entry.value.map((value) => DataCell(Text('$value'))),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}

class _ScoreGrid extends StatelessWidget {
  final List<int> values;

  const _ScoreGrid({required this.values});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 2.2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: 12,
      itemBuilder: (context, index) {
        return Card(
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    AstroFormat.signNamesTe[index],
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                Text(
                  values[index].toString(),
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CalculationsTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;

  const _CalculationsTab({
    required this.birthData,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final p = VedicCalculationService.panchanga(result);
    final quickVargas = [1, 9, 10, 60]
        .map((factor) => VargaService.calculate(result, factor))
        .toList(growable: false);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Calculation / గణన విభాగం'),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'పంచాంగ గణనలు',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('పక్షం: ${p.paksha}'),
                Text('తిథి: ${p.tithi}'),
                Text('చంద్ర నక్షత్రం: ${p.nakshatra} • ${p.nakshatraPada} పాదం'),
                Text('యోగం: ${p.yoga}'),
                Text('కరణం: ${p.karana}'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Engine / Settings',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('Swiss Ephemeris: ${result.engineVersion}'),
                const Text('Planet mode: Sidereal + Moshier'),
                const Text('Node: True Rahu; Ketu = exact 180° opposite'),
                Text('Ayanamsa: ${birthData.ayanamsa.label}'),
                Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
                Text('Julian Day (UT): ${result.julianDay.toStringAsFixed(6)}'),
                Text('Lagna: ${AstroFormat.longitudeDms(result.ascendantLongitude)}'),
                const SizedBox(height: 6),
                const Text(
                  'House column below uses whole-sign houses from the Lagna sign.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const _SectionTitle('గ్రహ గణన పట్టిక'),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const [
              DataColumn(label: Text('Planet')),
              DataColumn(label: Text('Rasi')),
              DataColumn(label: Text('Longitude')),
              DataColumn(label: Text('Nakshatra')),
              DataColumn(label: Text('Pada')),
              DataColumn(label: Text('House')),
              DataColumn(label: Text('Motion')),
            ],
            rows: result.planets.map((planet) {
              final n = VedicCalculationService.nakshatra(planet.longitude);
              final house = VedicCalculationService.wholeSignHouse(
                planet.signIndex,
                result.ascendantSignIndex,
              );
              return DataRow(
                cells: [
                  DataCell(Text(planet.name)),
                  DataCell(Text(AstroFormat.signNamesTe[planet.signIndex])),
                  DataCell(Text(AstroFormat.longitudeDms(planet.longitude))),
                  DataCell(Text(VedicCalculationService.nakshatraNamesTe[n.index])),
                  DataCell(Text('${n.pada}')),
                  DataCell(Text('$house')),
                  DataCell(Text(planet.retrograde ? 'Retrograde' : 'Direct')),
                ],
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 18),
        const _SectionTitle('Quick Varga Matrix'),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: [
              const DataColumn(label: Text('Planet')),
              ...quickVargas.map(
                (v) => DataColumn(label: Text(v.definition.code)),
              ),
            ],
            rows: result.planets.map((planet) {
              return DataRow(
                cells: [
                  DataCell(Text(planet.name)),
                  ...quickVargas.map((v) {
                    final placement =
                        v.planets.firstWhere((item) => item.name == planet.name);
                    return DataCell(
                      Text(AstroFormat.signNamesTe[placement.signIndex]),
                    );
                  }),
                ],
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 14),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'ఈ version లో verified core calculations, BAV/SAV మరియు Prastara Ashtakavarga చూపించబడుతున్నాయి. Shadbala, Bhava Bala, Trikona/Ekadhipatya Shodhana, Shodhya Pinda వంటి advanced modules ను source-rule verification తర్వాత మాత్రమే add చేయాలి; ఊహా formulas ఉపయోగించకూడదు.',
            ),
          ),
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _BirthSummaryCard extends StatelessWidget {
  final BirthData birthData;

  const _BirthSummaryCard({required this.birthData});

  @override
  Widget build(BuildContext context) {
    final dt = birthData.localDateTime;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              birthData.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('స్థలం: ${birthData.place}'),
            Text(
              'Lat ${birthData.latitude.toStringAsFixed(6)}  •  '
              'Lon ${birthData.longitude.toStringAsFixed(6)}',
            ),
            Text('జనన సమయం: ${AstroFormat.dateTime(dt)}'),
            Text(
              'Timezone: ${AstroFormat.timezoneOffset(birthData.timezoneOffsetHours)}',
            ),
          ],
        ),
      ),
    );
  }
}

class _CalculationSummaryCard extends StatelessWidget {
  final AstroChartResult result;
  final String ayanamsaName;

  const _CalculationSummaryCard({
    required this.result,
    required this.ayanamsaName,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.verified_outlined),
                SizedBox(width: 8),
                Text(
                  'Calculation',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text('Engine: Swiss Ephemeris ${result.engineVersion}'),
            const Text('Mode: Sidereal + Moshier ephemeris'),
            Text('Ayanamsa: $ayanamsaName'),
            Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
            const SizedBox(height: 8),
            Text(
              'లగ్నం: ${AstroFormat.longitudeDms(result.ascendantLongitude)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

class _SouthIndianChart extends StatelessWidget {
  final String title;
  final int ascendantSignIndex;
  final Map<int, List<String>> occupants;

  const _SouthIndianChart({
    required this.title,
    required this.ascendantSignIndex,
    required this.occupants,
  });

  // Traditional South-Indian fixed-sign layout:
  // Pisces | Aries | Taurus | Gemini
  // Aquarius |       centre       | Cancer
  // Capricorn|       centre       | Leo
  // Sagittarius|Scorpio|Libra|Virgo
  static const List<int?> _signByCell = <int?>[
    11, 0, 1, 2,
    10, null, null, 3,
    9, null, null, 4,
    8, 7, 6, 5,
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final lineColor = theme.colorScheme.primary;

    return Card(
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: theme.colorScheme.primaryContainer,
                  ),
                  child: const Text(
                    'BUILD 10',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              'South Indian fixed-sign chart • లగ్నం: ${AstroFormat.signNamesTe[ascendantSignIndex]}',
              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 10),
            AspectRatio(
              aspectRatio: 1,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final side = constraints.maxWidth;
                  final cell = side / 4;
                  return Stack(
                    fit: StackFit.expand,
                    children: [
                      Table(
                        border: TableBorder.all(color: lineColor, width: 1.8),
                        defaultVerticalAlignment: TableCellVerticalAlignment.fill,
                        children: List.generate(4, (row) {
                          return TableRow(
                            children: List.generate(4, (col) {
                              final sign = _signByCell[row * 4 + col];
                              if (sign == null) {
                                return const SizedBox.expand();
                              }
                              return SizedBox(
                                height: cell,
                                child: _TraditionalRasiCell(
                                  signIndex: sign,
                                  isAscendant: sign == ascendantSignIndex,
                                  occupants: occupants[sign] ?? const <String>[],
                                ),
                              );
                            }),
                          );
                        }),
                      ),
                      Positioned(
                        left: cell,
                        top: cell,
                        width: cell * 2,
                        height: cell * 2,
                        child: Container(
                          decoration: BoxDecoration(
                            color: theme.colorScheme.surface,
                            border: Border.all(color: lineColor, width: 1.8),
                          ),
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                title,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'లగ్నం • ${AstroFormat.signNamesTe[ascendantSignIndex]}',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  color: theme.colorScheme.primary,
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                'South Indian',
                                style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TraditionalRasiCell extends StatelessWidget {
  final int signIndex;
  final bool isAscendant;
  final List<String> occupants;

  const _TraditionalRasiCell({
    required this.signIndex,
    required this.isAscendant,
    required this.occupants,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(6),
      color: isAscendant
          ? theme.colorScheme.primaryContainer.withValues(alpha: 0.38)
          : theme.colorScheme.surface,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  AstroFormat.signNamesTe[signIndex],
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900),
                ),
              ),
              if (isAscendant)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: theme.colorScheme.primary,
                  ),
                  child: const Text(
                    'ల',
                    style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w900),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 4),
          Expanded(
            child: SingleChildScrollView(
              child: Wrap(
                spacing: 5,
                runSpacing: 3,
                children: occupants.map((text) {
                  return Text(
                    text,
                    style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReportActions extends StatelessWidget {
  final String title;
  final String Function() reportText;

  const _ReportActions({required this.title, required this.reportText});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Report',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(text: reportText()),
                      );
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Report clipboardకి copy అయింది'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.copy_all_outlined),
                    label: const Text('Copy'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await ReportStorageService.save(
                        title: title,
                        body: reportText(),
                      );
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Report locally save అయింది'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('Save'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () async {
                  await SharePlus.instance.share(
                    ShareParams(
                      text: reportText(),
                      title: 'Annapurna Astro Vastu - $title',
                    ),
                  );
                },
                icon: const Icon(Icons.share_outlined),
                label: const Text('Share Report'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;

  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
    );
  }
}

Map<int, List<String>> _occupantsFromVarga(
  VargaChartData data, {
  AstroChartResult? includeDegreesFrom,
}) {
  final result = <int, List<String>>{
    for (var i = 0; i < 12; i++) i: <String>[],
  };

  for (final planet in data.planets) {
    var label = planet.shortName;
    if (includeDegreesFrom != null && data.definition.factor == 1) {
      final source =
          includeDegreesFrom.planets.firstWhere((p) => p.name == planet.name);
      label += ' ${source.degreesInSign.toStringAsFixed(1)}°';
    }
    if (planet.retrograde) label += 'R';
    result[planet.signIndex]!.add(label);
  }
  return result;
}

class _ErrorView extends StatelessWidget {
  final String message;

  const _ErrorView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 46),
                const SizedBox(height: 12),
                const Text(
                  'Calculation ప్రారంభం కాలేదు',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(message, textAlign: TextAlign.center),
                const SizedBox(height: 10),
                const Text(
                  'flutter pub get చేసిన తర్వాత Android buildలో sweph native library కూడా build అవుతుంది.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
