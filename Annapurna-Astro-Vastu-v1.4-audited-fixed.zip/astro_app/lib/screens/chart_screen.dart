import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';

import '../astrology/ashtakavarga_service.dart';
import '../astrology/ashtakavarga_interpretation_service.dart';
import '../astrology/ashtakavarga_timing_service.dart';
import '../astrology/ashtakavarga_transit_window_service.dart';
import '../astrology/ashtakavarga_event_evidence_service.dart';
import '../astrology/ashtakavarga_event_year_service.dart';
import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/dasha_service.dart';
import '../astrology/consultation_service.dart';
import '../astrology/consultation_timing_service.dart';
import '../astrology/jaimini_service.dart';
import '../astrology/kp_service.dart';
import '../astrology/planet_detail_service.dart';
import '../astrology/varga_service.dart';
import '../astrology/vedic_calculation_service.dart';
import '../models/birth_data.dart';
import '../services/chart_storage_service.dart';
import '../services/report_storage_service.dart';
import '../utils/astro_format.dart';


enum _AstroSystem {
  dasha,
  jamakola,
  jaimini,
  tajik,
  bcp,
  bsp,
  bnn,
  kp,
}

extension _AstroSystemLabel on _AstroSystem {
  String get title => switch (this) {
        _AstroSystem.dasha => 'దశలు',
        _AstroSystem.jamakola => 'Jamakola',
        _AstroSystem.jaimini => 'జైమిని System',
        _AstroSystem.tajik => 'Tajik / Varshaphala',
        _AstroSystem.bcp => 'BCP',
        _AstroSystem.bsp => 'BSP',
        _AstroSystem.bnn => 'BNN',
        _AstroSystem.kp => 'KP',
      };

  IconData get icon => switch (this) {
        _AstroSystem.dasha => Icons.timeline_outlined,
        _AstroSystem.jamakola => Icons.auto_awesome_outlined,
        _AstroSystem.jaimini => Icons.account_tree_outlined,
        _AstroSystem.tajik => Icons.calendar_month_outlined,
        _AstroSystem.bcp => Icons.rotate_right_outlined,
        _AstroSystem.bsp => Icons.rule_folder_outlined,
        _AstroSystem.bnn => Icons.hub_outlined,
        _AstroSystem.kp => Icons.functions_outlined,
      };
}

class ChartScreen extends StatefulWidget {
  final BirthData birthData;

  const ChartScreen({
    super.key,
    required this.birthData,
  });

  @override
  State<ChartScreen> createState() => _ChartScreenState();
}

class _ChartScreenState extends State<ChartScreen> {
  late final Future<AstroChartResult> _future;
  int _selectedVarga = 9;
  String _selectedBav = 'Sun';
  _AstroSystem? _activeSystem;

  @override
  void initState() {
    super.initState();
    _future = AstroCalculationService.calculate(widget.birthData);
  }

  Future<void> _saveChart() async {
    await ChartStorageService.save(widget.birthData);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('జాతక చార్ట్ Saved Chartsలో save అయింది'),
      ),
    );
  }

  String _formatDateTime(DateTime dt) => AstroFormat.dateTime(dt);

  String _formatLongitude(double longitude) =>
      AstroFormat.longitudeDms(longitude);

  String _reportText(AstroChartResult result) {
    final b = widget.birthData;
    final panchanga = VedicCalculationService.panchanga(result);
    final av = AshtakavargaService.calculate(result);
    final d9 = VargaService.calculate(result, 9);
    final d10 = VargaService.calculate(result, 10);

    String placementText(VargaChartData data) {
      final items = data.planets
          .map((p) => '${p.shortName}:${p.signIndex + 1}')
          .join(', ');
      return '${data.definition.code} ${data.definition.teluguName}: '
          'Lg ${data.ascendantSignIndex + 1} | $items';
    }

    final buffer = StringBuffer()
      ..writeln('అన్నపూర్ణ ఆస్ట్రో వాస్తు')
      ..writeln('పేరు: ${b.name}')
      ..writeln('స్థలం: ${b.place}')
      ..writeln('Latitude: ${b.latitude}, Longitude: ${b.longitude}')
      ..writeln('Local: ${_formatDateTime(b.localDateTime)}')
      ..writeln('UTC: ${_formatDateTime(b.utcDateTime)}')
      ..writeln('Ayanamsa: ${b.ayanamsa.label}')
      ..writeln('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°')
      ..writeln('Lagna: ${_formatLongitude(result.ascendantLongitude)}')
      ..writeln('')
      ..writeln('పంచాంగ సారాంశం:')
      ..writeln('${panchanga.paksha} • ${panchanga.tithi}')
      ..writeln(
        '${panchanga.nakshatra} ${panchanga.nakshatraPada} పాదం • ${panchanga.yoga} యోగం • ${panchanga.karana} కరణం',
      )
      ..writeln('')
      ..writeln('గ్రహ స్థితులు:');

    for (final planet in result.planets) {
      final n = VedicCalculationService.nakshatra(planet.longitude);
      final house = VedicCalculationService.wholeSignHouse(
        planet.signIndex,
        result.ascendantSignIndex,
      );
      buffer.writeln(
        '${planet.name}: ${_formatLongitude(planet.longitude)} | '
        '${VedicCalculationService.nakshatraNamesTe[n.index]}-${n.pada} | '
        'House $house${planet.retrograde ? ' | R' : ''}',
      );
    }

    buffer
      ..writeln('')
      ..writeln(placementText(d9))
      ..writeln(placementText(d10))
      ..writeln('')
      ..writeln('Sarvashtakavarga: ${av.sarva.join(', ')}')
      ..writeln('SAV Total: ${av.grandTotal} ${av.totalsValid ? '(verified)' : '(check required)'}')
      ..writeln('')
      ..writeln('Engine: Swiss Ephemeris ${result.engineVersion} (Moshier mode)');
    return buffer.toString();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        drawer: _SystemDrawer(
          selected: _activeSystem,
          onSelect: (system) => setState(() => _activeSystem = system),
          onMain: () => setState(() => _activeSystem = null),
        ),
        appBar: AppBar(
          title: Text(_activeSystem?.title ?? 'జాతక విశ్లేషణ'),
          actions: [
            IconButton(
              tooltip: 'Save Chart',
              onPressed: _saveChart,
              icon: const Icon(Icons.bookmark_add_outlined),
            ),
          ],
          bottom: _activeSystem == null
              ? const TabBar(
                  isScrollable: true,
                  labelColor: Colors.white,
                  unselectedLabelColor: Color(0xFFFFD7DD),
                  indicatorColor: Colors.white,
                  tabs: [
                    Tab(icon: Icon(Icons.grid_on_outlined), text: 'జాతకం'),
                    Tab(icon: Icon(Icons.record_voice_over_outlined), text: 'క్లైంట్'),
                    Tab(icon: Icon(Icons.dashboard_outlined), text: 'వర్గాలు'),
                    Tab(icon: Icon(Icons.apps_outlined), text: 'అష్టకవర్గం'),
                    Tab(icon: Icon(Icons.calculate_outlined), text: 'లెక్కలు'),
                    Tab(icon: Icon(Icons.account_tree_outlined), text: 'సిస్టమ్స్'),
                  ],
                )
              : null,
        ),
        body: FutureBuilder<AstroChartResult>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 14),
                    Text('Swiss Ephemeris calculation జరుగుతోంది…'),
                  ],
                ),
              );
            }

            if (snapshot.hasError || !snapshot.hasData) {
              return _ErrorView(
                message: snapshot.error?.toString() ?? 'Calculation failed',
              );
            }

            final result = snapshot.data!;
            final av = AshtakavargaService.calculate(result);

            if (_activeSystem != null) {
              return _ResponsiveChartBody(
                child: _SystemDetailPage(
                  system: _activeSystem!,
                  birthData: widget.birthData,
                  result: result,
                  onBackToMain: () => setState(() => _activeSystem = null),
                ),
              );
            }

            return _ResponsiveChartBody(
              child: TabBarView(
              children: [
                _JatakaTab(
                  birthData: widget.birthData,
                  result: result,
                  reportText: () => _reportText(result),
                ),
                _ConsultationTab(
                  birthData: widget.birthData,
                  result: result,
                  av: av,
                ),
                _VargaTab(
                  result: result,
                  selectedVarga: _selectedVarga,
                  onChanged: (value) => setState(() => _selectedVarga = value),
                ),
                _AshtakavargaTab(
                  result: av,
                  chart: result,
                  birthData: widget.birthData,
                  ascendantSignIndex: result.ascendantSignIndex,
                  selectedPlanet: _selectedBav,
                  onPlanetChanged: (value) =>
                      setState(() => _selectedBav = value),
                ),
                _CalculationsTab(
                  birthData: widget.birthData,
                  result: result,
                ),
                _SystemsTab(
                  birthData: widget.birthData,
                  result: result,
                ),
              ],
              ),
            );
          },
        ),
      ),
    );
  }
}


class _ResponsiveChartBody extends StatelessWidget {
  final Widget child;

  const _ResponsiveChartBody({required this.child});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth > 1180
            ? 1180.0
            : constraints.maxWidth;
        return Align(
          alignment: Alignment.topCenter,
          child: SizedBox(
            width: width,
            height: constraints.maxHeight,
            child: child,
          ),
        );
      },
    );
  }
}

class _JatakaTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;
  final String Function() reportText;

  const _JatakaTab({
    required this.birthData,
    required this.result,
    required this.reportText,
  });

  @override
  Widget build(BuildContext context) {
    final rasi = VargaService.calculate(result, 1);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _BirthSummaryCard(birthData: birthData),
        const SizedBox(height: 12),
        _CalculationSummaryCard(
          result: result,
          ayanamsaName: birthData.ayanamsa.label,
        ),
        const SizedBox(height: 16),
        const _SectionTitle('రాశి / జన్మ చక్రం'),
        const SizedBox(height: 10),
        _SouthIndianChart(
          title: 'D1 రాశి',
          ascendantSignIndex: rasi.ascendantSignIndex,
          occupants: _occupantsFromVarga(rasi, includeDegreesFrom: result),
          onOccupantTap: (label) {
            final planet = _planetFromOccupantLabel(result, label);
            if (planet != null) _showPlanetDetailSheet(context, result, planet);
          },
        ),
        const SizedBox(height: 18),
        const _SectionTitle('గ్రహ స్థితులు'),
        const SizedBox(height: 8),
        const Text(
          'గ్రహాన్ని టచ్ చేస్తే Degree • Star Lord • Sub Lord • Amsa Devata • Vargaja/Vimshopaka వివరాలు కనిపిస్తాయి.',
          style: TextStyle(fontSize: 12, color: Color(0xFF6B5B5E)),
        ),
        const SizedBox(height: 8),
        ...result.planets.map(
          (planet) => _PlanetTapCard(chart: result, planet: planet),
        ),
        const SizedBox(height: 12),
        _ReportActions(
          title: birthData.name,
          reportText: reportText,
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


class _PlanetTapCard extends StatelessWidget {
  final AstroChartResult chart;
  final PlanetPosition planet;

  const _PlanetTapCard({required this.chart, required this.planet});

  @override
  Widget build(BuildContext context) {
    final n = VedicCalculationService.nakshatra(planet.longitude);
    final house = VedicCalculationService.wholeSignHouse(
      planet.signIndex,
      chart.ascendantSignIndex,
    );
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        onTap: () => _showPlanetDetailSheet(context, chart, planet),
        title: Text(
          planet.name,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          'డిగ్రీ: ${AstroFormat.degreeDms(planet.degreesInSign)}\n'
          '${VedicCalculationService.nakshatraNamesTe[n.index]} • ${n.pada} పాదం • House $house',
        ),
        isThreeLine: true,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (planet.retrograde) const Chip(label: Text('R')),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }
}

void _showPlanetDetailSheet(
  BuildContext context,
  AstroChartResult chart,
  PlanetPosition planet,
) {
  final detail = PlanetDetailService.forPlanet(chart, planet);
  final n = VedicCalculationService.nakshatra(planet.longitude);
  final v = detail.vargaStrength;
  final consult = ConsultationService.planetSummary(chart: chart, planet: planet);

  String factors(List<int> items) =>
      items.isEmpty ? '—' : items.map((e) => 'D$e').join(', ');

  Widget row(String label, String value, {FontWeight? valueWeight}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 5,
            child: Text(label, style: const TextStyle(color: Color(0xFF5F5052))),
          ),
          Expanded(
            flex: 6,
            child: Text(
              value,
              style: TextStyle(fontWeight: valueWeight ?? FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    constraints: const BoxConstraints(maxWidth: 760),
    backgroundColor: Colors.white,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (sheetContext) => SafeArea(
      child: FractionallySizedBox(
        heightFactor: 0.90,
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: const Color(0xFFFFE8EC),
                    foregroundColor: const Color(0xFF8B1E2D),
                    child: Text(planet.shortName),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          planet.name,
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900),
                        ),
                        Text(
                          'డిగ్రీ: ${AstroFormat.degreeDms(planet.degreesInSign)}${planet.retrograde ? ' • R' : ''}',
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(sheetContext).pop(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Card(
                color: const Color(0xFFFFF8F3),
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    children: [
                      row('Nakshatra', '${VedicCalculationService.nakshatraNamesTe[n.index]} • ${n.pada} పాదం'),
                      row('Star Lord', detail.kp.starLord),
                      row('Sub Lord', detail.kp.subLord),
                      row(
                        'Amsa Devata (D60)',
                        '${detail.amsaDevata.teluguName} (${detail.amsaDevata.name})',
                      ),
                      row('D60 Amsa', '${detail.amsaDevata.effectivePart} / 60'),
                      row('Amsa Nature', detail.amsaDevata.nature),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              const Text(
                'వర్గ బలం',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              Card(
                color: Colors.white,
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    children: [
                      row('Saptavargaja', '${v.saptavargaja}'),
                      row('Shadvargaja', '${v.shadvargaja}'),
                      row('Dashavargaja', '${v.dashavargaja}'),
                      row('Shodashavargaja', '${v.shodashavargaja}'),
                      row(
                        'Vimshopaka Bala',
                        v.shodashaVimsopaka.toStringAsFixed(2),
                        valueWeight: FontWeight.w900,
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                color: const Color(0xFFEAF6EE),
                surfaceTintColor: Colors.transparent,
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.record_voice_over_outlined, color: Color(0xFF1B7F3A)),
                          SizedBox(width: 8),
                          Text('క్లయింట్‌కు చెప్పండి', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(consult.sayThis),
                      const SizedBox(height: 8),
                      Text(consult.technicalNote, style: const TextStyle(fontSize: 12, color: Color(0xFF5F5052))),
                      const SizedBox(height: 8),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          onPressed: () async {
                            await Clipboard.setData(ClipboardData(text: consult.sayThis));
                            if (!sheetContext.mounted) return;
                            ScaffoldMessenger.of(sheetContext).showSnackBar(const SnackBar(content: Text('Client line copy అయింది')));
                          },
                          icon: const Icon(Icons.copy_all_outlined),
                          label: const Text('Copy'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Card(
                color: const Color(0xFFFFFBF8),
                surfaceTintColor: Colors.transparent,
                child: ExpansionTile(
                  title: const Text(
                    'Vargaja / Vimshopaka పూర్తి వివరాలు',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                  children: [
                    row('Shadvarga support', factors(v.shadSupport)),
                    row('Shadvarga Bala', v.shadVimsopaka.toStringAsFixed(2)),
                    row('Saptavarga support', factors(v.saptaSupport)),
                    row('Saptavarga Bala', v.saptaVimsopaka.toStringAsFixed(2)),
                    row('Dashavarga support', factors(v.dashaSupport)),
                    row('Dashavarga Bala', v.dashaVimsopaka.toStringAsFixed(2)),
                    row('Shodashavarga support', factors(v.shodashaSupport)),
                    row('Shodashavarga Bala', v.shodashaVimsopaka.toStringAsFixed(2)),
                    const SizedBox(height: 8),
                    const Text(
                      'Vargaja count = own / exalted / moolatrikona support ఉన్న vargas. Vimshopaka Bala 20-point weighted varga strength. Amsa Devata D60 source ruleలో odd signs forward, even signs reverse order ఉపయోగిస్తుంది.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF6B5B5E)),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}

PlanetPosition? _planetFromOccupantLabel(
  AstroChartResult chart,
  String label,
) {
  for (final planet in chart.planets) {
    if (label == planet.shortName || label.startsWith('${planet.shortName} ')) {
      return planet;
    }
  }
  return null;
}

class _VargaTab extends StatelessWidget {
  final AstroChartResult result;
  final int selectedVarga;
  final ValueChanged<int> onChanged;

  const _VargaTab({
    required this.result,
    required this.selectedVarga,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final data = VargaService.calculate(result, selectedVarga);
    final definition = data.definition;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('షోడశ వర్గ చక్రములు'),
        const SizedBox(height: 8),
        const Text(
          'D1 నుంచి D60 వరకు 16 classical Parashari vargas. ప్రతి వర్గం అదే sidereal planetary longitude ను తన ప్రత్యేక నియమంతో కొత్త రాశిలో map చేస్తుంది.',
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: VargaService.definitions.map((v) {
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(v.code),
                  selected: selectedVarga == v.factor,
                  onSelected: (_) => onChanged(v.factor),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 12),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${definition.code} ${definition.teluguName} (${definition.name})',
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text('ప్రధాన ఉపయోగం: ${definition.domain}'),
                Text('Division: 30° / ${definition.factor}'),
                if (definition.factor >= 40) ...[
                  const SizedBox(height: 8),
                  const Text(
                    'గమనిక: D40 / D45 / D60 లగ్నం జనన సమయానికి చాలా సున్నితంగా మారుతుంది.',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        _SouthIndianChart(
          title: '${definition.code} ${definition.teluguName}',
          ascendantSignIndex: data.ascendantSignIndex,
          occupants: _occupantsFromVarga(data),
          onOccupantTap: (label) {
            final planet = _planetFromOccupantLabel(result, label);
            if (planet != null) _showPlanetDetailSheet(context, result, planet);
          },
        ),
        const SizedBox(height: 14),
        _VargaPlanetList(data: data, natalChart: result),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _VargaPlanetList extends StatelessWidget {
  final VargaChartData data;
  final AstroChartResult natalChart;

  const _VargaPlanetList({required this.data, required this.natalChart});

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text(
                'వర్గ గ్రహ స్థానాలు',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: const Text(
                'లగ్నం చక్రంలో Lg గుర్తుతో చూపించబడింది.',
              ),
            ),
            const Divider(),
            ...data.planets.map((p) {
              final natal = natalChart.planets.firstWhere((x) => x.name == p.name);
              return ListTile(
                onTap: () => _showPlanetDetailSheet(context, natalChart, natal),
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(p.name),
                subtitle: Text('డిగ్రీ: ${AstroFormat.degreeDms(natal.degreesInSign)}'),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (p.retrograde) const Chip(label: Text('R')),
                    const Icon(Icons.chevron_right),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}

class _AshtakavargaTab extends StatelessWidget {
  final AshtakavargaResult result;
  final AstroChartResult chart;
  final BirthData birthData;
  final int ascendantSignIndex;
  final String selectedPlanet;
  final ValueChanged<String> onPlanetChanged;

  const _AshtakavargaTab({
    required this.result,
    required this.chart,
    required this.birthData,
    required this.ascendantSignIndex,
    required this.selectedPlanet,
    required this.onPlanetChanged,
  });

  @override
  Widget build(BuildContext context) {
    final bav = result.bhinna[selectedPlanet]!;
    final expected = result.expectedPlanetTotals[selectedPlanet]!;
    final actual = result.totalFor(selectedPlanet);
    final prastara = result.prastara[selectedPlanet]!;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('అష్టకవర్గం'),
        const SizedBox(height: 8),
        const Text(
          'Parashari Bhinna Ashtakavarga (BAV) లో సూర్యుడు నుంచి శని వరకు 7 గ్రహాలకు, 7 గ్రహాలు + లగ్నం అనే 8 reference points నుంచి bindus లెక్కించబడతాయి. SAV అనేది 7 BAV rows యొక్క మొత్తం.',
        ),
        const SizedBox(height: 12),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(
                  result.totalsValid
                      ? Icons.verified_outlined
                      : Icons.warning_amber_outlined,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Sarvashtakavarga (SAV)',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text('Grand total: ${result.grandTotal} / 337'),
                      Text(
                        result.totalsValid
                            ? 'Classical fixed totals verification passed.'
                            : 'Fixed total verification failed — result check చేయాలి.',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: 'Sarvashtakavarga (SAV)',
          values: result.sarva,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _ScoreGrid(values: result.sarva),
        const SizedBox(height: 18),
        _AshtakavargaArithmeticPanel(
          chart: chart,
          av: result,
        ),
        const SizedBox(height: 18),
        _AshtakavargaLifeMirrorPanel(av: result),
        const SizedBox(height: 18),
        _AshtakavargaEventEvidencePanel(
          birthData: birthData,
          natalChart: chart,
          av: result,
        ),
        const SizedBox(height: 18),
        _AshtakavargaPlanetTimingPanel(
          birthData: birthData,
          chart: chart,
          av: result,
        ),
        const SizedBox(height: 18),
        _AshtakavargaJatakaResults(
          chart: chart,
          av: result,
        ),
        const SizedBox(height: 18),
        DropdownButtonFormField<String>(
          value: selectedPlanet,
          decoration: const InputDecoration(
            labelText: 'Bhinna Ashtakavarga గ్రహం',
            border: OutlineInputBorder(),
          ),
          items: AshtakavargaService.planetOrder
              .map(
                (planet) => DropdownMenuItem(
                  value: planet,
                  child: Text(planet),
                ),
              )
              .toList(),
          onChanged: (value) {
            if (value != null) onPlanetChanged(value);
          },
        ),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: ListTile(
            title: Text('$selectedPlanet BAV'),
            subtitle: Text('Bindu total: $actual / expected $expected'),
            trailing: actual == expected
                ? const Icon(Icons.check_circle_outline)
                : const Icon(Icons.error_outline),
          ),
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: '$selectedPlanet BAV',
          values: bav,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _ScoreGrid(values: bav),
        const SizedBox(height: 18),
        _AshtakavargaSouthChart(
          title: '$selectedPlanet — Trikona Shodhana',
          values: result.arithmetic.afterTrikona[selectedPlanet]!,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        _AshtakavargaSouthChart(
          title: '$selectedPlanet — Ekadhipatya Shodhana',
          values: result.arithmetic.afterEkadhipatya[selectedPlanet]!,
          ascendantSignIndex: ascendantSignIndex,
        ),
        const SizedBox(height: 10),
        Builder(builder: (context) {
          final practical = result.arithmetic.practicalPindas[selectedPlanet]!;
          final pvr = result.arithmetic.pvrPindas[selectedPlanet]!;
          return Card(
            color: Colors.white,
            surfaceTintColor: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$selectedPlanet — Pinda', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
                  const SizedBox(height: 8),
                  Text('Practical: Rasi ${practical.rashiPinda} + Graha ${practical.grahaPinda} = Shodhya ${practical.shodhyaPinda}'),
                  Text('PVR: Rasi ${pvr.rashiPinda} + Graha ${pvr.grahaPinda} = Shodhya ${pvr.shodhyaPinda}'),
                ],
              ),
            ),
          );
        }),
        const SizedBox(height: 18),
        const _SectionTitle('Prastara Ashtakavarga'),
        const SizedBox(height: 8),
        const Text(
          'ఎంచుకున్న గ్రహం BAV లో 7 గ్రహాలు + లగ్నం నుంచి ఏ రాశికి bindu వచ్చిందో 1/0 రూపంలో చూపిస్తుంది.',
        ),
        const SizedBox(height: 8),
        _PrastaraTable(rows: prastara),
        const SizedBox(height: 10),
        _PrastaraWhyPanel(
          planet: selectedPlanet,
          rows: prastara,
          values: bav,
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}



class _AshtakavargaArithmeticPanel extends StatelessWidget {
  final AstroChartResult chart;
  final AshtakavargaResult av;

  const _AshtakavargaArithmeticPanel({
    required this.chart,
    required this.av,
  });

  @override
  Widget build(BuildContext context) {
    final a = av.arithmetic;
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        initiallyExpanded: true,
        leading: Icon(
          a.auditValid && av.totalsValid
              ? Icons.verified_outlined
              : Icons.warning_amber_outlined,
          color: a.auditValid && av.totalsValid
              ? const Color(0xFF1B7F3A)
              : const Color(0xFFB3261E),
        ),
        title: const Text(
          'అష్టకవర్గ Arithmetic Engine',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          a.auditValid && av.totalsValid
              ? 'BAV → SAV → త్రికోణ శోధన → ఏకాధిపత్య శోధన → పిండ గణితం: PASS'
              : 'Arithmetic auditలో తేడా ఉంది — values verify చేయాలి',
        ),
        children: [
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'లగ్నం నుండి 1–12 భావాల SAV',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: List.generate(12, (i) {
                    return Chip(label: Text('${i + 1}: ${a.savByHouse[i]}'));
                  }),
                ),
                const SizedBox(height: 16),
                const Text(
                  'గ్రహాల పూర్తి arithmetic',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    columnSpacing: 18,
                    columns: const [
                      DataColumn(label: Text('గ్రహం')),
                      DataColumn(label: Text('BAV')),
                      DataColumn(label: Text('జన్మ బిందు')),
                      DataColumn(label: Text('భావం')),
                      DataColumn(label: Text('Trikona')),
                      DataColumn(label: Text('Ekadhi.')),
                      DataColumn(label: Text('Rasi P')),
                      DataColumn(label: Text('Graha P')),
                      DataColumn(label: Text('Shodhya P')),
                    ],
                    rows: AshtakavargaService.planetOrder.map((planet) {
                      final tri = a.afterTrikona[planet]!
                          .fold<int>(0, (sum, value) => sum + value);
                      final eka = a.afterEkadhipatya[planet]!
                          .fold<int>(0, (sum, value) => sum + value);
                      final p = a.practicalPindas[planet]!;
                      return DataRow(cells: [
                        DataCell(Text(planet)),
                        DataCell(Text('${av.totalFor(planet)}')),
                        DataCell(Text('${a.natalBavScore[planet]}')),
                        DataCell(Text('${a.natalHouse[planet]}')),
                        DataCell(Text('$tri')),
                        DataCell(Text('$eka')),
                        DataCell(Text('${p.rashiPinda}')),
                        DataCell(Text('${p.grahaPinda}')),
                        DataCell(Text('${p.shodhyaPinda}')),
                      ]);
                    }).toList(),
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Pinda practical profile: Rāśi multipliersలో Virgo=5. PVR profile (Virgo=6) కూడా engineలో విడిగా లెక్కించబడుతుంది; రెండు విధానాలు mix చేయబడవు.',
                  style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                ),
                const SizedBox(height: 16),
                const Text(
                  'SAV group arithmetic',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                ...a.groupSums.entries.map(
                  (e) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 3),
                    child: Row(
                      children: [
                        Expanded(child: Text(e.key)),
                        Text('${e.value}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'Kakshya arithmetic: ప్రతి రాశి 8 సమ భాగాలు; ఒక్కో భాగం 3°45′. Transit longitude ఇచ్చినప్పుడు engine 1–8 Kakshya index మరియు ఆ రాశిలో BAV/SAV bindusను నేరుగా తీసుకోగలదు.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}




class _AshtakavargaLifeMirrorPanel extends StatelessWidget {
  final AshtakavargaResult av;

  const _AshtakavargaLifeMirrorPanel({required this.av});

  ({String label, int sum, int count}) _group(String key, String label, int count) =>
      (label: label, sum: av.arithmetic.groupSums[key] ?? 0, count: count);

  Color _color(double avg) {
    if (avg >= 28) return const Color(0xFF1B7F3A);
    if (avg < 25) return const Color(0xFFB3261E);
    return const Color(0xFF8A5A00);
  }

  String _status(double avg) {
    if (avg >= 28) return 'Strong';
    if (avg < 25) return 'Weak / caution';
    return 'Medium';
  }

  @override
  Widget build(BuildContext context) {
    final groups = [
      _group('Dhana 2+11', 'ధనం / లాభం', 2),
      _group('Education 5+9', 'విద్య / ఉన్నత విద్య', 2),
      _group('Career 6+10+11+12', 'వృత్తి / ఉద్యోగం', 4),
      _group('Upachaya 3+6+10+11', 'వృద్ధి / Upachaya', 4),
      _group('Kendra 1+4+7+10', 'కేంద్ర బలం', 4),
      _group('Kona 1+5+9', 'కోణ బలం', 3),
    ];
    final income = av.arithmetic.groupSums['Income set 1+2+4+9+10+11'] ?? 0;
    final expense = av.arithmetic.groupSums['Expense set 6+8+12'] ?? 0;
    final independentA = av.arithmetic.groupSums['Independent A 1+5+9'] ?? 0;
    final independentB = av.arithmetic.groupSums['Independent B 2+6+10'] ?? 0;
    final inner = av.arithmetic.groupSums['Inner A 1+4+5+7+9+10'] ?? 0;
    final outer = av.arithmetic.groupSums['Outer B 2+3+6+8+11+12'] ?? 0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle('Life Mirror — అష్టకవర్గ సారాంశం'),
        const SizedBox(height: 8),
        const Text(
          'Raw totalsను మాత్రమే కాకుండా ప్రతి life-areaలో house-average strengthను చూపిస్తుంది. ఇది supporting evidence మాత్రమే; standalone prediction కాదు.',
        ),
        const SizedBox(height: 10),
        ...groups.map((g) {
          final avg = g.sum / g.count;
          final color = _color(avg);
          return Card(
            color: Colors.white,
            surfaceTintColor: Colors.transparent,
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(
                avg >= 28
                    ? Icons.check_circle
                    : avg < 25
                        ? Icons.cancel
                        : Icons.info,
                color: color,
              ),
              title: Text(g.label, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('Total ${g.sum} • Average ${avg.toStringAsFixed(1)}'),
              trailing: Text(_status(avg), style: TextStyle(color: color, fontWeight: FontWeight.bold)),
            ),
          );
        }),
        Card(
          color: const Color(0xFFFFF8F3),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Group comparisons', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('Income set: $income • Expense set: $expense • ${income > expense ? 'Income side stronger' : 'Expense/pressure side stronger or equal'}'),
                const SizedBox(height: 5),
                Text('Independent A: $independentA • B: $independentB • ${independentA > independentB ? 'Independent tendency support' : 'Mixed/dependent tendency'}'),
                const SizedBox(height: 5),
                Text('Inner A: $inner • Outer B: $outer • ${inner > outer ? 'Inner/dharma side stronger' : 'Outer/practical side equal or stronger'}'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _AshtakavargaEventEvidencePanel extends StatefulWidget {
  final BirthData birthData;
  final AstroChartResult natalChart;
  final AshtakavargaResult av;

  const _AshtakavargaEventEvidencePanel({
    required this.birthData,
    required this.natalChart,
    required this.av,
  });

  @override
  State<_AshtakavargaEventEvidencePanel> createState() =>
      _AshtakavargaEventEvidencePanelState();
}

class _AshtakavargaEventEvidencePanelState
    extends State<_AshtakavargaEventEvidencePanel> {
  late final DateTime _asOfLocal;
  late final Future<AstroChartResult> _transitFuture;

  @override
  void initState() {
    super.initState();
    final nowUtc = DateTime.now().toUtc();
    final offsetMinutes = (widget.birthData.timezoneOffsetHours * 60).round();
    _asOfLocal = nowUtc.add(Duration(minutes: offsetMinutes));
    final transitData = BirthData(
      name: widget.birthData.name,
      localDateTime: _asOfLocal,
      place: widget.birthData.place,
      latitude: widget.birthData.latitude,
      longitude: widget.birthData.longitude,
      timezoneOffsetHours: widget.birthData.timezoneOffsetHours,
      ayanamsa: widget.birthData.ayanamsa,
    );
    _transitFuture = AstroCalculationService.calculate(transitData);
  }

  Color _toneColor(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => const Color(0xFF1B7F3A),
        AvTimingTone.unfavorable => const Color(0xFFB3261E),
        AvTimingTone.neutral => const Color(0xFF8A5A00),
        AvTimingTone.info => const Color(0xFF355E8A),
        AvTimingTone.restricted => const Color(0xFF5F6368),
      };

  IconData _toneIcon(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => Icons.check_circle,
        AvTimingTone.unfavorable => Icons.cancel,
        AvTimingTone.neutral => Icons.info_outline,
        AvTimingTone.info => Icons.schedule_outlined,
        AvTimingTone.restricted => Icons.shield_outlined,
      };

  void _showEvidenceDetail(BuildContext context, AvEventEvidence item) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.78,
        minChildSize: 0.45,
        maxChildSize: 0.95,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: EdgeInsets.fromLTRB(
            20,
            4,
            20,
            MediaQuery.viewPaddingOf(context).bottom + 40,
          ),
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.title,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              item.finalResult,
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: _toneColor(item.tone),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'App evidence layers: ${item.evidenceLayersPassed}/${item.evidenceLayersTotal}. ఇది classical probability % కాదు.',
              style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
            ),
            const Divider(height: 30),
            const Text('1. జాతక / భావ బలం', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.houseEvidence),
            const Divider(height: 26),
            const Text('2. దశా పరిశీలన', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.dashaEvidence),
            const Divider(height: 26),
            const Text('3. ప్రస్తుత గోచార BAV/SAV', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.transitEvidence),
            const Divider(height: 26),
            const Text('4. Timing support', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.timingEvidence),
            const Divider(height: 26),
            const Text('రూల్స్', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.ruleIds),
            const SizedBox(height: 14),
            const Text(
              'Final label అనేది house + dasha + current transit అనే evidence layersను కలిపిన app summary. Bindusను నేరుగా percentageగా మార్చడం లేదు.',
              style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
            ),
          ],
        ),
      ),
    );
  }

  String _eventYearVector(List<AvEventYearPathNode> nodes) => nodes
      .map((n) => '${n.signNumber}: BAV ${n.planetBav}, SAV ${n.sav}')
      .join('  •  ');

  Widget _eventYearSourceTrace() {
    final traces = AshtakavargaEventYearService.evaluate(
      chart: widget.natalChart,
      av: widget.av,
    );
    return Card(
      color: const Color(0xFFFFF8E8),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Event Year / Age — AV-008/AV-009 source trace',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            const Text(
              'ప్రస్తుతం sourceలో స్పష్టంగా ఉన్న దశలవరకు మాత్రమే చూపిస్తున్నాం. Final age/yearను ఊహించి తయారు చేయము.',
            ),
            const SizedBox(height: 8),
            const Text(
              'Sourceలో స్పష్టమైన భాగం: Lagna → planet bindu-based values, planet → Lagna bindu-based values; తరువాత రెండు resultsను combine చేసి eventful age పొందాలి. కానీ ఆ final combine/conversion operator ప్రస్తుతం supplied source summaryలో లేదు.',
              style: TextStyle(fontSize: 12),
            ),
            const Divider(height: 22),
            ...traces.map(
              (trace) => ExpansionTile(
                tilePadding: EdgeInsets.zero,
                childrenPadding: const EdgeInsets.only(bottom: 12),
                title: Text(
                  trace.planet,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  'Lagna ${trace.lagnaSignNumber} → Planet ${trace.planetSignNumber} → Lagna',
                ),
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '1. Lagna → ${trace.planet}: ${_eventYearVector(trace.lagnaToPlanet)}',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '2. ${trace.planet} → Lagna: ${_eventYearVector(trace.planetToLagna)}',
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '3. Final age conversion: SOURCE-PENDING — combine operator / reduction / recurrence interval స్పష్టంగా లేనందున ageను emit చేయడం లేదు.',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'AV-009: AV-008 final age source-confirm అయిన తరువాత మాత్రమే repeat-event windows tabulate చేస్తాం. ఇప్పుడే recurrence years ఊహించము.',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Rule: AV-008 / AV-009',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AstroChartResult>(
      future: _transitFuture,
      builder: (context, snapshot) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _SectionTitle('Event Evidence — దశ + అష్టకవర్గ + గోచారం'),
            const SizedBox(height: 8),
            Text(
              'తేదీ: ${AstroFormat.dateTime(_asOfLocal)} • ${AstroFormat.timezoneOffset(widget.birthData.timezoneOffsetHours)}',
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 10),
            if (snapshot.connectionState != ConnectionState.done)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Row(
                    children: [
                      SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)),
                      SizedBox(width: 12),
                      Expanded(child: Text('ప్రస్తుత గోచారాన్ని Swiss Ephemerisతో లెక్కిస్తున్నాం…')),
                    ],
                  ),
                ),
              )
            else if (snapshot.hasError || !snapshot.hasData)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text('ప్రస్తుత గోచార layer load కాలేదు: ${snapshot.error ?? 'unknown error'}'),
                ),
              )
            else
              ...AshtakavargaEventEvidenceService.evaluate(
                birthData: widget.birthData,
                natalChart: widget.natalChart,
                transitChart: snapshot.data!,
                av: widget.av,
                asOfLocal: _asOfLocal,
              ).map((item) {
                final color = _toneColor(item.tone);
                return Card(
                  color: Colors.white,
                  surfaceTintColor: Colors.transparent,
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: Icon(_toneIcon(item.tone), color: color),
                    title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(
                      '${item.finalResult} • Evidence ${item.evidenceLayersPassed}/${item.evidenceLayersTotal}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _showEvidenceDetail(context, item),
                  ),
                );
              }),
            const SizedBox(height: 4),
            _eventYearSourceTrace(),
          ],
        );
      },
    );
  }
}

class _AshtakavargaPlanetTimingPanel extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult chart;
  final AshtakavargaResult av;

  const _AshtakavargaPlanetTimingPanel({
    required this.birthData,
    required this.chart,
    required this.av,
  });

  static const Map<String, String> _planetUse = {
    'Sun': 'అధికారం • పదవి • నాయకత్వం • తండ్రి-సంబంధ support',
    'Moon': 'మనస్సు • తల్లి • ప్రజలు • ప్రయాణ/ప్రజా సంబంధ support',
    'Mars': 'సోదరులు • భూమి • చర్య • ధైర్యం • లాభ trigger',
    'Mercury': 'విద్య • వృత్తి • వ్యాపారం • కమ్యూనికేషన్',
    'Jupiter': 'సంతానం • విద్య • ధనం • గురుత్వం',
    'Venus': 'వివాహం • భాగస్వామ్యం • సుఖాలు • సంబంధాలు',
    'Saturn': 'ఉద్యోగం • శ్రమ • స్థిరత్వం • దీర్ఘకాల బాధ్యతలు',
  };

  static const Map<String, String> _planetTimingUse = {
    'Sun': 'Sourceలో safe layerగా దిక్కు, 1–12 support, Kakshyaని ఉపయోగించాలి. Sensitive deterministic timingను app final eventగా చూపదు.',
    'Moon': 'దిక్కు, 1–12 support, Kakshyaని సహాయక timing layerగా ఉపయోగించాలి. Sensitive deterministic timingను app final eventగా చూపదు.',
    'Mars': 'సోదర/లాభ eventకు source arithmetic trigger ఉంటే, దశ supportతో కలిపి transit confirmationగా చూడాలి.',
    'Mercury': 'వృత్తి/వ్యాపారం, విద్య/ఆర్థిక వృద్ధి triggersను దశ + transit supportతో కలిపి చూడాలి.',
    'Jupiter': 'సంతాన eventకు నక్షత్ర/సౌర మాస triggerను దశ + గురు transit confirmationతో కలిపి చూడాలి.',
    'Venus': 'వివాహ eventకు నక్షత్ర/సౌర మాస triggerను దశ-అంతర్దశ + transit confirmationతో కలిపి చూడాలి.',
    'Saturn': 'దిక్కు, 1–12 support, Kakshyaని దీర్ఘకాల timing supportగా ఉపయోగించాలి. Sensitive deterministic timingను app final eventగా చూపదు.',
  };

  void _showUsageGuide(BuildContext context, AvPlanetTimingProfile profile) {
    final top3 = profile.monthSupport.take(3).toList(growable: false);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFFFFAF7),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.78,
          minChildSize: 0.45,
          maxChildSize: 0.94,
          builder: (context, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
            children: [
              Center(
                child: Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                    color: const Color(0xFF8B1E2D).withOpacity(0.30),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                '${profile.planetTe} (${profile.planet}) — ఎలా ఉపయోగించాలి',
                style: const TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF3B2327),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _planetUse[profile.planet] ?? '',
                style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 16),
              _UsageGuideStep(
                number: 1,
                title: 'ముందుగా Event Promise చూడండి',
                body: 'జాతకంలో సంబంధిత భావాలు/గ్రహాలు eventకు support చేస్తున్నాయా చూడాలి. అష్టకవర్గం ఒక్కదానితో final event నిర్ణయించవద్దు.',
              ),
              _UsageGuideStep(
                number: 2,
                title: 'దశా support కలపండి',
                body: 'ప్రస్తుత మహాదశ–అంతర్దశ–ప్రత్యంతర్దశలో సంబంధిత గ్రహం లేదా భావ సంబంధం ఉందా చూడండి.',
              ),
              _UsageGuideStep(
                number: 3,
                title: 'BAV + SAV బలం చదవండి',
                body: 'BAV 5 లేదా ఎక్కువ + SAV 28 లేదా ఎక్కువ అయితే app Green supportగా చూపిస్తుంది. BAV 4 లేదా మధ్యస్థ SAV అయితే mixed; BAV 1–3 లేదా SAV 25 కంటే తక్కువైతే cautionగా చూపిస్తుంది.',
              ),
              _UsageGuideStep(
                number: 4,
                title: 'దిక్కు బలం ఉపయోగించండి',
                body: 'ప్రస్తుత chartలో ప్రధాన దిక్కు: ${profile.strongestDirections.join(' / ')}. బలహీన దిక్కు: ${profile.weakestDirections.join(' / ')}. Eventకు travel/direction సంబంధం ఉన్నప్పుడు ఇది secondary support.',
              ),
              _UsageGuideStep(
                number: 5,
                title: 'Top transit indices చూడండి',
                body: 'Top 3: ${top3.map((m) => '${m.monthNumber} (BAV ${m.bavBindus}, SAV ${m.savBindus})').join(' • ')}. 1–12 అనేవి calendar నెల పేర్లు కాదు; సౌర మాస/రాశి సూచికలు.',
              ),
              _UsageGuideStep(
                number: 6,
                title: 'Kakshyaతో finer timing',
                body: '${profile.kakshyaDuration}. ముందుగా దశ + transit support సరిపోతే, తరువాత Kakshyaని finer timing layerగా ఉపయోగించండి.',
              ),
              _UsageGuideStep(
                number: 7,
                title: 'Source Event Timing చివరలో చూడండి',
                body: _planetTimingUse[profile.planet] ?? '',
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8E4E6),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFF8B1E2D).withOpacity(0.24)),
                ),
                child: const Text(
                  'సరైన క్రమం: జాతక promise → దశ → BAV/SAV → transit index → దిక్కు → Kakshya → source event arithmetic → final judgment.',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showTransitCalendar(
    BuildContext context,
    AvPlanetTimingProfile profile,
  ) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFFFFAF7),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (context) => _AvTransitCalendarSheet(
        birthData: birthData,
        av: av,
        profile: profile,
      ),
    );
  }

  Color _toneColor(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => const Color(0xFF1B7F3A),
        AvTimingTone.unfavorable => const Color(0xFFB3261E),
        AvTimingTone.neutral => const Color(0xFF8A5A00),
        AvTimingTone.info => const Color(0xFF355E8A),
        AvTimingTone.restricted => const Color(0xFF5F6368),
      };

  IconData _toneIcon(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => Icons.check_circle,
        AvTimingTone.unfavorable => Icons.cancel,
        AvTimingTone.neutral => Icons.info_outline,
        AvTimingTone.info => Icons.schedule_outlined,
        AvTimingTone.restricted => Icons.shield_outlined,
      };

  @override
  Widget build(BuildContext context) {
    final profiles = AshtakavargaTimingService.evaluate(chart: chart, av: av);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle('గ్రహవారీ దిక్కు • మాసం • Event Timing'),
        const SizedBox(height: 8),
        const Text(
          'ప్రతి గ్రహానికి BAV/SAV ఆధారంగా బలమైన దిక్కు, 1–12 సౌర మాస/రాశి support, Kakshya కాలం మరియు sourceలో స్పష్టంగా ఉన్న event timing arithmetic చూపిస్తుంది. రాశి పేర్లు కాకుండా సంఖ్యలు మాత్రమే చూపిస్తాం.',
        ),
        const SizedBox(height: 6),
        const Text(
          'గమనిక: 1–12 = సౌర మాస/రాశి సూచిక; 1–27 = నక్షత్ర సూచిక. “Calendar windows” టచ్ చేస్తే Swiss Ephemerisతో ఆ సూచికలు ఏ actual తేదీ/సమయంలో వస్తాయో చూపిస్తుంది.',
          style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
        ),
        const SizedBox(height: 12),
        Card(
          color: const Color(0xFFFFF4F4),
          surfaceTintColor: Colors.transparent,
          child: ExpansionTile(
            leading: const Icon(Icons.menu_book_outlined, color: Color(0xFF8B1E2D)),
            title: const Text(
              'అష్టకవర్గ timing — ఎలా ఉపయోగించాలి',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: const Text('జాతక promise → దశ → BAV/SAV → transit → దిక్కు → Kakshya'),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
            children: const [
              Text(
                '1) ముందుగా event జాతకంలో promise ఉందా చూడండి. 2) ప్రస్తుత దశ support చూడండి. 3) సంబంధిత గ్రహం BAV/SAV బలం చూడండి. 4) Top transit index మరియు దిక్కు support కలపండి. 5) Kakshyaతో windowని narrow చేయండి. 6) Source arithmetic ఉన్న eventలకు మాత్రమే formula outputను confirmationగా ఉపయోగించండి.',
              ),
              SizedBox(height: 8),
              Text(
                'Green = అనుకూల support • Amber = mixed • Red = caution • Blue = timing/info • Grey = restricted/sensitive source rule.',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        ...profiles.map((profile) {
          final top3 = profile.monthSupport.take(3).toList(growable: false);
          final best = top3.first;
          return Card(
            color: Colors.white,
            surfaceTintColor: Colors.transparent,
            margin: const EdgeInsets.only(bottom: 12),
            child: ExpansionTile(
              initiallyExpanded: profile.planet == 'Sun',
              leading: CircleAvatar(
                backgroundColor: const Color(0xFFF8E4E6),
                foregroundColor: const Color(0xFF8B1E2D),
                child: Text(profile.planet.substring(0, 2)),
              ),
              title: Text(
                '${profile.planetTe} (${profile.planet})',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'ముఖ్య దిక్కు: ${profile.strongestDirections.join(' / ')} • టాప్ మాసం: ${best.monthNumber}',
              ),
              children: [
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          Chip(
                            avatar: const Icon(Icons.explore_outlined, size: 18),
                            label: Text('దిక్కు: ${profile.strongestDirections.join(' / ')}'),
                          ),
                          Chip(
                            avatar: const Icon(Icons.navigation_outlined, size: 18),
                            label: Text('8-దిక్కు support: ${profile.eightDirection}'),
                          ),
                          Chip(
                            avatar: const Icon(Icons.calendar_month_outlined, size: 18),
                            label: Text('సౌర మాసం: ${best.monthNumber}'),
                          ),
                          Chip(
                            avatar: const Icon(Icons.timelapse_outlined, size: 18),
                            label: Text(profile.kakshyaDuration),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          OutlinedButton.icon(
                            onPressed: () => _showUsageGuide(context, profile),
                            icon: const Icon(Icons.help_outline),
                            label: const Text('ఎలా ఉపయోగించాలి'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: const Color(0xFF8B1E2D),
                              side: const BorderSide(color: Color(0xFF8B1E2D)),
                            ),
                          ),
                          FilledButton.icon(
                            onPressed: () => _showTransitCalendar(context, profile),
                            icon: const Icon(Icons.event_available_outlined),
                            label: const Text('Calendar windows'),
                            style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF8B1E2D),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      const Text(
                        'దిశా బలం — R4.19',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      ...profile.directions.map((d) {
                        final isHigh = profile.strongestDirections.contains(d.direction);
                        final isLow = profile.weakestDirections.contains(d.direction);
                        final color = isHigh
                            ? const Color(0xFF1B7F3A)
                            : isLow
                                ? const Color(0xFFB3261E)
                                : const Color(0xFF5F6368);
                        return Padding(
                          padding: const EdgeInsets.symmetric(vertical: 3),
                          child: Row(
                            children: [
                              Icon(
                                isHigh
                                    ? Icons.check_circle_outline
                                    : isLow
                                        ? Icons.remove_circle_outline
                                        : Icons.circle_outlined,
                                size: 18,
                                color: color,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  '${d.direction} — ${d.signNumbers.join(', ')}',
                                ),
                              ),
                              Text(
                                '${d.score}',
                                style: TextStyle(fontWeight: FontWeight.bold, color: color),
                              ),
                            ],
                          ),
                        );
                      }),
                      const SizedBox(height: 10),
                      Text(
                        'బలహీన దిక్కు: ${profile.weakestDirections.join(' / ')}',
                        style: const TextStyle(color: Color(0xFFB3261E)),
                      ),
                      const SizedBox(height: 16),
                      const Text(
                        'టాప్ 3 మాస / transit support',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      ...top3.map((m) {
                        final color = _toneColor(m.tone);
                        return ListTile(
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(_toneIcon(m.tone), color: color),
                          title: Text('మాస సూచిక ${m.monthNumber}'),
                          subtitle: Text('BAV ${m.bavBindus}/8 • SAV ${m.savBindus}'),
                        );
                      }),
                      ExpansionTile(
                        tilePadding: EdgeInsets.zero,
                        childrenPadding: EdgeInsets.zero,
                        title: const Text(
                          '12 మాసాల పూర్తి support',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        children: [
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: (([...profile.monthSupport]
                                  ..sort((a, b) => a.monthNumber.compareTo(b.monthNumber))))
                                .map((m) => Chip(
                                      avatar: Icon(
                                        _toneIcon(m.tone),
                                        size: 16,
                                        color: _toneColor(m.tone),
                                      ),
                                      label: Text('${m.monthNumber}: ${m.bavBindus}/${m.savBindus}'),
                                    ))
                                .toList(),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Event timing — source arithmetic',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      ...profile.eventTiming.map((event) {
                        final c = _toneColor(event.tone);
                        return Container(
                          width: double.infinity,
                          margin: const EdgeInsets.only(bottom: 10),
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: c.withOpacity(0.06),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: c.withOpacity(0.28)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(_toneIcon(event.tone), color: c, size: 20),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      event.item,
                                      style: const TextStyle(fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 6),
                              Text(event.result),
                              const SizedBox(height: 8),
                              Text(
                                'Formula: ${event.formula}',
                                style: const TextStyle(fontSize: 12),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                'Rule: ${event.ruleId}',
                                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        );
                      }),
                    ],
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}


class _AvTransitCalendarSheet extends StatefulWidget {
  final BirthData birthData;
  final AshtakavargaResult av;
  final AvPlanetTimingProfile profile;

  const _AvTransitCalendarSheet({
    required this.birthData,
    required this.av,
    required this.profile,
  });

  @override
  State<_AvTransitCalendarSheet> createState() => _AvTransitCalendarSheetState();
}

class _AvTransitCalendarSheetState extends State<_AvTransitCalendarSheet> {
  late int _year;
  late Future<List<AvTransitWindow>> _future;

  @override
  void initState() {
    super.initState();
    final nowUtc = DateTime.now().toUtc();
    final offset = Duration(
      minutes: (widget.birthData.timezoneOffsetHours * 60).round(),
    );
    _year = nowUtc.add(offset).year;
    _reload();
  }

  void _reload() {
    _future = AshtakavargaTransitWindowService.supportedWindowsForYear(
      birthData: widget.birthData,
      av: widget.av,
      planet: widget.profile.planet,
      year: _year,
    );
  }

  void _changeYear(int delta) {
    setState(() {
      _year += delta;
      _reload();
    });
  }

  Color _toneColor(AvTimingTone tone) => switch (tone) {
        AvTimingTone.favorable => const Color(0xFF1B7F3A),
        AvTimingTone.unfavorable => const Color(0xFFB3261E),
        AvTimingTone.neutral => const Color(0xFF8A5A00),
        AvTimingTone.info => const Color(0xFF355E8A),
        AvTimingTone.restricted => const Color(0xFF5F6368),
      };

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.88,
        minChildSize: 0.55,
        maxChildSize: 0.96,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
          children: [
            Center(
              child: Container(
                width: 42,
                height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFF8B1E2D).withOpacity(0.28),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(
              '${widget.profile.planetTe} — Swiss Ephemeris Calendar Windows',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 6),
            Text(
              'Top 3 BAV/SAV support సూచికలు actual calendarలో ఎప్పుడు వస్తాయో చూపిస్తుంది. Time zone: ${AstroFormat.timezoneOffset(widget.birthData.timezoneOffsetHours)}.',
              style: const TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                IconButton(
                  onPressed: () => _changeYear(-1),
                  icon: const Icon(Icons.chevron_left),
                ),
                Expanded(
                  child: Center(
                    child: Text(
                      '$_year',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () => _changeYear(1),
                  icon: const Icon(Icons.chevron_right),
                ),
              ],
            ),
            const SizedBox(height: 8),
            FutureBuilder<List<AvTransitWindow>>(
              future: _future,
              builder: (context, snapshot) {
                if (snapshot.connectionState != ConnectionState.done) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 36),
                    child: Column(
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 12),
                        Text('Transit ingress/egress times లెక్కిస్తున్నాం…'),
                      ],
                    ),
                  );
                }
                if (snapshot.hasError) {
                  return Text('Calendar calculation error: ${snapshot.error}');
                }
                final windows = snapshot.data ?? const <AvTransitWindow>[];
                if (windows.isEmpty) {
                  return const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text('ఈ సంవత్సరంలో selected top-support signsకు transit window దొరకలేదు.'),
                  );
                }
                return Column(
                  children: windows.map((w) {
                    final c = _toneColor(w.tone);
                    return Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: c.withOpacity(0.055),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: c.withOpacity(0.30)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(Icons.event_available_outlined, color: c, size: 20),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  'సూచిక ${w.signNumber} • BAV ${w.bavBindus}/8 • SAV ${w.savBindus}',
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 7),
                          Text('Start: ${AstroFormat.dateTime(w.startLocal)}'),
                          Text('End:   ${AstroFormat.dateTime(w.endLocal)}'),
                          const SizedBox(height: 5),
                          Text(
                            'Entry Kakshya: ${w.entryKakshya}/8 • ${w.retrogradeAtEntry ? 'Retrograde entry' : 'Direct entry'}',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ],
                      ),
                    );
                  }).toList(),
                );
              },
            ),
            const SizedBox(height: 10),
            const Text(
              'ఈ calendar layer sourceలోని BAV/SAV support indicesను Swiss Ephemeris actual ingress/egress datesకు map చేస్తుంది. ఇది స్వతంత్ర event prediction కాదు; దశ + natal promiseతో కలిపి ఉపయోగించాలి.',
              style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
            ),
          ],
        ),
      ),
    );
  }
}

class _UsageGuideStep extends StatelessWidget {
  final int number;
  final String title;
  final String body;

  const _UsageGuideStep({
    required this.number,
    required this.title,
    required this.body,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 13),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 30,
            height: 30,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
              color: Color(0xFF8B1E2D),
              shape: BoxShape.circle,
            ),
            child: Text(
              '$number',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(body),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AshtakavargaJatakaResults extends StatelessWidget {
  final AstroChartResult chart;
  final AshtakavargaResult av;

  const _AshtakavargaJatakaResults({
    required this.chart,
    required this.av,
  });

  Color _toneColor(AvFindingTone tone) => switch (tone) {
        AvFindingTone.favorable => const Color(0xFF1B7F3A),
        AvFindingTone.unfavorable => const Color(0xFFB3261E),
        AvFindingTone.neutral => const Color(0xFF8A5A00),
        AvFindingTone.pending => const Color(0xFF5F6368),
      };

  IconData _toneIcon(AvFindingTone tone) => switch (tone) {
        AvFindingTone.favorable => Icons.check_circle,
        AvFindingTone.unfavorable => Icons.cancel,
        AvFindingTone.neutral => Icons.info,
        AvFindingTone.pending => Icons.hourglass_bottom,
      };

  void _showDetail(BuildContext context, AvJatakaFinding item) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.72,
        minChildSize: 0.45,
        maxChildSize: 0.95,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    item.item,
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text('పలితం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.result),
            const Divider(height: 30),
            const Text('రూల్', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.rule),
            const SizedBox(height: 5),
            Text('Rule ID: ${item.ruleId}', style: const TextStyle(fontWeight: FontWeight.w600)),
            const Divider(height: 30),
            const Text('జాతక పరిశీలన', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.inspection),
            const Divider(height: 30),
            const Text('మూలం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(item.source),
            if (item.category.contains('ఆయుర్దాయ') || item.category.contains('రోగ')) ...[
              const SizedBox(height: 14),
              const Text(
                'గమనిక: ఆరోగ్యం/ఆయుర్దాయ అంశాలు సాంప్రదాయ జ్యోతిష్య సూచనలుగా మాత్రమే చూపించబడతాయి; ఇవి వైద్య నిర్ధారణ లేదా జీవితకాల నిర్ణయం కాదు.',
                style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = AshtakavargaInterpretationService.evaluate(chart: chart, av: av);
    final grouped = <String, List<AvJatakaFinding>>{};
    for (final item in items) {
      grouped.putIfAbsent(item.category, () => []).add(item);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _SectionTitle('జాతకానికి వర్తించిన అష్టకవర్గ ఫలితాలు'),
        const SizedBox(height: 8),
        const Text(
          'అన్ని అంశాలు వరుసగా చూపిస్తాయి. “పలితం” టచ్ చేస్తే రూల్ → జాతక పరిశీలన → మూలం తెరుచుకుంటాయి. Green = అనుకూలం, Red = ప్రతికూల/జాగ్రత్త, Amber = మధ్యస్థం, Grey = అదనపు source calculation అవసరం.',
        ),
        const SizedBox(height: 12),
        ...grouped.entries.map((entry) => Card(
          color: Colors.white,
          surfaceTintColor: Colors.transparent,
          margin: const EdgeInsets.only(bottom: 12),
          child: ExpansionTile(
            initiallyExpanded: entry.key == 'భావ బలం — వరుసగా 1 నుండి 12',
            title: Text(entry.key, style: const TextStyle(fontWeight: FontWeight.bold)),
            children: entry.value.map((item) {
              final c = _toneColor(item.tone);
              return ListTile(
                leading: Icon(_toneIcon(item.tone), color: c),
                title: Text(item.item, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Text(item.result, maxLines: 2, overflow: TextOverflow.ellipsis),
                trailing: TextButton(
                  onPressed: () => _showDetail(context, item),
                  child: const Text('పలితం'),
                ),
                onTap: () => _showDetail(context, item),
              );
            }).toList(),
          ),
        )),
      ],
    );
  }
}

class _AshtakavargaSouthChart extends StatelessWidget {
  final String title;
  final List<int> values;
  final int ascendantSignIndex;

  const _AshtakavargaSouthChart({
    required this.title,
    required this.values,
    required this.ascendantSignIndex,
  });

  @override
  Widget build(BuildContext context) {
    final occupants = <int, List<String>>{
      for (var sign = 0; sign < 12; sign++) sign: ['${values[sign]}'],
    };
    return _SouthIndianChart(
      title: title,
      ascendantSignIndex: ascendantSignIndex,
      occupants: occupants,
    );
  }
}

class _PrastaraTable extends StatelessWidget {
  final Map<String, List<int>> rows;

  const _PrastaraTable({required this.rows});

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: DataTable(
          columnSpacing: 18,
          columns: [
            const DataColumn(label: Text('Ref')),
            ...List.generate(
              12,
              (index) => DataColumn(
                label: Text(
                  '${index + 1}',
                  style: const TextStyle(fontSize: 11),
                ),
              ),
            ),
          ],
          rows: rows.entries.map((entry) {
            return DataRow(
              cells: [
                DataCell(Text(entry.key)),
                ...entry.value.map((value) => DataCell(Text('$value'))),
              ],
            );
          }).toList(),
        ),
      ),
    );
  }
}


class _PrastaraWhyPanel extends StatelessWidget {
  final String planet;
  final Map<String, List<int>> rows;
  final List<int> values;

  const _PrastaraWhyPanel({
    required this.planet,
    required this.rows,
    required this.values,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFFFF8F3),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        leading: const Icon(Icons.help_center_outlined, color: Color(0xFF8B1E2D)),
        title: Text('$planet BAV — “ఈ score ఎందుకు?”'),
        subtitle: const Text('ప్రతి 1–12 సూచికకు bindu ఇచ్చిన reference points చూడండి'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: List.generate(12, (sign) {
          final contributors = <String>[];
          final nonContributors = <String>[];
          for (final entry in rows.entries) {
            if (entry.value[sign] == 1) {
              contributors.add(entry.key);
            } else {
              nonContributors.add(entry.key);
            }
          }
          return ExpansionTile(
            tilePadding: EdgeInsets.zero,
            title: Text('సూచిక ${sign + 1} — ${values[sign]}/8'),
            childrenPadding: const EdgeInsets.only(left: 8, right: 8, bottom: 10),
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Bindu ✓: ${contributors.join(', ')}'),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Bindu లేదు: ${nonContributors.join(', ')}'),
              ),
            ],
          );
        }),
      ),
    );
  }
}

class _ScoreGrid extends StatelessWidget {
  final List<int> values;

  const _ScoreGrid({required this.values});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 2.2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: 12,
      itemBuilder: (context, index) {
        return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          margin: EdgeInsets.zero,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    '${index + 1}',
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
                Text(
                  values[index].toString(),
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _CalculationsTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;

  const _CalculationsTab({
    required this.birthData,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final p = VedicCalculationService.panchanga(result);
    final quickVargas = [1, 9, 10, 60]
        .map((factor) => VargaService.calculate(result, factor))
        .toList(growable: false);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('Calculation / గణన విభాగం'),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'పంచాంగ గణనలు',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('పక్షం: ${p.paksha}'),
                Text('తిథి: ${p.tithi}'),
                Text('చంద్ర నక్షత్రం: ${p.nakshatra} • ${p.nakshatraPada} పాదం'),
                Text('యోగం: ${p.yoga}'),
                Text('కరణం: ${p.karana}'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Engine / Settings',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text('Swiss Ephemeris: ${result.engineVersion}'),
                const Text('Planet mode: Sidereal + Moshier'),
                const Text('Node: True Rahu; Ketu = exact 180° opposite'),
                Text('Ayanamsa: ${birthData.ayanamsa.label}'),
                Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
                Text('Julian Day (UT): ${result.julianDay.toStringAsFixed(6)}'),
                Text('Lagna: ${AstroFormat.longitudeDms(result.ascendantLongitude)}'),
                const SizedBox(height: 6),
                const Text(
                  'House column below uses whole-sign houses from the Lagna sign.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const _SectionTitle('గ్రహ గణన పట్టిక'),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: const [
              DataColumn(label: Text('Planet')),
              DataColumn(label: Text('Rasi')),
              DataColumn(label: Text('Longitude')),
              DataColumn(label: Text('Nakshatra')),
              DataColumn(label: Text('Pada')),
              DataColumn(label: Text('House')),
              DataColumn(label: Text('Motion')),
            ],
            rows: result.planets.map((planet) {
              final n = VedicCalculationService.nakshatra(planet.longitude);
              final house = VedicCalculationService.wholeSignHouse(
                planet.signIndex,
                result.ascendantSignIndex,
              );
              return DataRow(
                cells: [
                  DataCell(Text(planet.name)),
                  DataCell(Text('${planet.signIndex + 1}')),
                  DataCell(Text(AstroFormat.longitudeDms(planet.longitude))),
                  DataCell(Text(VedicCalculationService.nakshatraNamesTe[n.index])),
                  DataCell(Text('${n.pada}')),
                  DataCell(Text('$house')),
                  DataCell(Text(planet.retrograde ? 'Retrograde' : 'Direct')),
                ],
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 18),
        const _SectionTitle('Quick Varga Matrix'),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columns: [
              const DataColumn(label: Text('Planet')),
              ...quickVargas.map(
                (v) => DataColumn(label: Text(v.definition.code)),
              ),
            ],
            rows: result.planets.map((planet) {
              return DataRow(
                cells: [
                  DataCell(Text(planet.name)),
                  ...quickVargas.map((v) {
                    final placement =
                        v.planets.firstWhere((item) => item.name == planet.name);
                    return DataCell(
                      Text('${placement.signIndex + 1}'),
                    );
                  }),
                ],
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 14),
        const Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'ఈ version లో verified core calculations, BAV/SAV మరియు Prastara Ashtakavarga చూపించబడుతున్నాయి. Shadbala, Bhava Bala, Trikona/Ekadhipatya Shodhana, Shodhya Pinda వంటి advanced modules ను source-rule verification తర్వాత మాత్రమే add చేయాలి; ఊహా formulas ఉపయోగించకూడదు.',
            ),
          ),
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


class _SystemDrawer extends StatelessWidget {
  final _AstroSystem? selected;
  final ValueChanged<_AstroSystem> onSelect;
  final VoidCallback onMain;

  const _SystemDrawer({
    required this.selected,
    required this.onSelect,
    required this.onMain,
  });

  @override
  Widget build(BuildContext context) {
    const maroon = Color(0xFF7B1E2B);
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 20, 16, 18),
              color: maroon,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.menu_book_outlined, color: Colors.white, size: 34),
                  SizedBox(height: 10),
                  Text(
                    'అన్నపూర్ణ ఆస్ట్రో వాస్తు',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'జ్యోతిష్య విధానాలు',
                    style: TextStyle(color: Color(0xFFFFD7DD)),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  ListTile(
                    leading: const Icon(Icons.home_outlined),
                    title: const Text(
                      'ప్రధాన జాతకం',
                      style: TextStyle(fontWeight: FontWeight.w700),
                    ),
                    selected: selected == null,
                    selectedTileColor: const Color(0xFFFFF0F2),
                    onTap: () {
                      Navigator.pop(context);
                      onMain();
                    },
                  ),
                  const Divider(height: 12),
                  for (final system in _AstroSystem.values)
                    ListTile(
                      leading: Icon(system.icon, color: maroon),
                      title: Text(
                        system.title,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      trailing: const Icon(Icons.chevron_right),
                      selected: selected == system,
                      selectedTileColor: const Color(0xFFFFF0F2),
                      onTap: () {
                        Navigator.pop(context);
                        onSelect(system);
                      },
                    ),
                  const Divider(height: 18),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 4, 16, 18),
                    child: Text(
                      'గణిత ఫలితాలు verified rules ఉన్న modulesలో మాత్రమే చూపించబడతాయి. Source పూర్తి కాని systemలో ఊహా calculation చూపించము.',
                      style: TextStyle(fontSize: 12, color: Color(0xFF65585A)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SystemDetailPage extends StatelessWidget {
  final _AstroSystem system;
  final BirthData birthData;
  final AstroChartResult result;
  final VoidCallback onBackToMain;

  const _SystemDetailPage({
    required this.system,
    required this.birthData,
    required this.result,
    required this.onBackToMain,
  });

  @override
  Widget build(BuildContext context) {
    final children = <Widget>[
      _SystemPageHeader(
        system: system,
        onBackToMain: onBackToMain,
      ),
      const SizedBox(height: 12),
    ];

    switch (system) {
      case _AstroSystem.dasha:
        children.add(
          _DashaSystemsCard(
            chart: result,
            birthDateTime: birthData.localDateTime,
          ),
        );
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'దశల పూర్తి విభాగం',
            items: [
              'త్రిభాగి 80 — S.K. Mehta',
              'వింశోత్తరి 120',
              'ఖండ దశ 40',
              'యోగిని 36',
              'జనన దశా balance',
              'మహాదశ / అంతర్దశ / ప్రత్యంతర్దశ',
              'సూక్ష్మ / ప్రాణ దశ',
              'ఏ తేదీకి అయినా 5-level దశా స్థితి',
              'ప్రతి level ప్రారంభం–ముగింపు తేదీలు',
              'ప్రస్తుత levelకి పూర్తి sub-period పట్టిక',
            ],
            note:
                'త్రిభాగి = Vimshottari duration × 2/3; ఖండ = ×1/3. Mehta timingలో 2–5 స్థాయులు (AD, PD, Sukshma, Prana) ముఖ్యంగా చూపించబడతాయి. Source ratiosను మార్చకుండా date engine reproducible civil-year conventionతో పని చేస్తుంది.',
          ),
        );
        break;

      case _AstroSystem.jaimini:
        final jai = JaiminiService.calculate(result);
        children.add(_JaiminiCard(result: jai, chart: result));
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'జైమిని విభాగం',
            items: [
              'Chara Karakas',
              'Atmakaraka',
              'Karakamsa',
              'Rashi Drishti',
              'Argala / Virodha Argala',
              'Pada P1–P12 (Arudha A1–A12)',
              'P7 / Darapada',
              'P12 / Upapada',
              'Chara Dasha + Antardasha',
              'అంశాల వారీ applicable combinations / yogas',
              'Green / Red result status',
              'Result touch → జాతక పరిశీలన + పరిహారం',
            ],
            note:
                'Supplied Jaimini sourceలో స్పష్టంగా ఉన్న applicable rulesను అంశాల వారీగా auto-evaluate చేస్తుంది. ఒకే ruleతో final verdict ఇవ్వదు. Sourceలో పరిహారం లేని చోట ఊహా remedy చూపించదు.',
          ),
        );
        break;

      case _AstroSystem.kp:
        children.add(_KpCard(rows: KpService.planetaryTable(result)));
        children.add(const SizedBox(height: 12));
        children.add(
          const _ModuleChecklistCard(
            title: 'KP పూర్తి నిర్మాణం',
            items: [
              'Planet Sign Lord',
              'Star Lord',
              'Sub Lord',
              '12 Cusps',
              'Cusp Star/Sub Lord',
              'Significators',
              'Ruling Planets',
              'Event house groups',
              'Promise / Denial',
              'Event timing',
            ],
            note:
                'Planetary Star/Sub arithmetic active. Exact cusp sub-lord/significator engine కోసం 12 cusp longitude calculation మరియు supplied KP source rulesను layer-by-layer validate చేసి మాత్రమే enable చేయాలి.',
          ),
        );
        break;

      case _AstroSystem.jamakola:
        children.add(
          _PendingSystemDetail(
            title: 'Jamakola',
            birthData: birthData,
            result: result,
            sections: [
              'జనన ఆధార గణన',
              'గ్రహ/భావ సంబంధ నియమాలు',
              'Event combinations',
              'Timing rules',
              'Rule → Result trace',
              'Final event report',
            ],
          ),
        );
        break;

      case _AstroSystem.tajik:
        children.add(
          _PendingSystemDetail(
            title: 'Tajik / Varshaphala',
            birthData: birthData,
            result: result,
            sections: [
              'Varsha Pravesha / annual chart',
              'Muntha',
              'Annual lord / Varshesha',
              'Tajik aspects',
              'Tajik yogas',
              'Sahams',
              'Annual timing & result',
            ],
          ),
        );
        break;

      case _AstroSystem.bcp:
        children.add(
          _PendingSystemDetail(
            title: 'BCP',
            birthData: birthData,
            result: result,
            sections: [
              'Source rule index',
              'Age / year activation',
              'Activated house/sign',
              'Planet/lord evidence',
              'Event rule trace',
              'Timing & final result',
            ],
          ),
        );
        break;

      case _AstroSystem.bsp:
        children.add(
          _PendingSystemDetail(
            title: 'BSP',
            birthData: birthData,
            result: result,
            sections: [
              'Source rule index',
              'Planet / sign / house trigger',
              'Rule combinations',
              'Exception rules',
              'Event result',
              'Timing / validation',
            ],
          ),
        );
        break;

      case _AstroSystem.bnn:
        children.add(
          _PendingSystemDetail(
            title: 'BNN',
            birthData: birthData,
            result: result,
            sections: [
              'Planet significations',
              'Planetary links / conjunction chain',
              'Sign & trinal relationships',
              'Karaka evidence layers',
              'Event combinations',
              'Timing & final report',
            ],
          ),
        );
        break;
    }

    children.add(const SizedBox(height: 28));
    return ListView(
      padding: const EdgeInsets.all(16),
      children: children,
    );
  }
}

class _SystemPageHeader extends StatelessWidget {
  final _AstroSystem system;
  final VoidCallback onBackToMain;

  const _SystemPageHeader({
    required this.system,
    required this.onBackToMain,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFFFF7F3),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: const Color(0xFF7B1E2B),
              foregroundColor: Colors.white,
              child: Icon(system.icon),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    system.title,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const Text(
                    'Rule → Calculation → Result',
                    style: TextStyle(color: Color(0xFF6E5D60)),
                  ),
                ],
              ),
            ),
            TextButton.icon(
              onPressed: onBackToMain,
              icon: const Icon(Icons.grid_view_outlined),
              label: const Text('జాతకం'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ModuleChecklistCard extends StatelessWidget {
  final String title;
  final List<String> items;
  final String note;

  const _ModuleChecklistCard({
    required this.title,
    required this.items,
    required this.note,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            for (final item in items)
              Padding(
                padding: const EdgeInsets.only(bottom: 7),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(
                      Icons.check_circle_outline,
                      size: 19,
                      color: Color(0xFF7B1E2B),
                    ),
                    const SizedBox(width: 8),
                    Expanded(child: Text(item)),
                  ],
                ),
              ),
            const Divider(height: 20),
            Text(note, style: const TextStyle(fontSize: 12.5)),
          ],
        ),
      ),
    );
  }
}

class _PendingSystemDetail extends StatefulWidget {
  final String title;
  final List<String> sections;
  final BirthData birthData;
  final AstroChartResult result;

  const _PendingSystemDetail({
    required this.title,
    required this.sections,
    required this.birthData,
    required this.result,
  });

  @override
  State<_PendingSystemDetail> createState() => _PendingSystemDetailState();
}

class _PendingSystemDetailState extends State<_PendingSystemDetail> {
  int? _openIndex;

  String _signForLongitude(double longitude) {
    final index = ((longitude % 360) / 30).floor().clamp(0, 11);
    return '${index + 1}';
  }

  String _planetSummary() {
    return widget.result.planets
        .map((p) => '${p.shortName}:${p.signIndex + 1}')
        .join('  •  ');
  }

  void _copyContext() {
    final b = widget.birthData;
    final text = StringBuffer()
      ..writeln(widget.title)
      ..writeln('Name: ${b.name}')
      ..writeln('DOB/Time: ${AstroFormat.dateTime(b.localDateTime)}')
      ..writeln('Place: ${b.place}')
      ..writeln('Lagna: ${_signForLongitude(widget.result.ascendantLongitude)}')
      ..writeln('Planets: ${_planetSummary()}');
    Clipboard.setData(ClipboardData(text: text.toString()));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('జాతక calculation context copy అయింది')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lagna = _signForLongitude(widget.result.ascendantLongitude);
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.verified_user_outlined,
                  color: Color(0xFF7B1E2B),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${widget.title} — working module',
                    style: const TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'ఈ moduleలో navigation, birth-chart context మరియు ప్రతి విభాగం touch/expand ఇప్పుడు పనిచేస్తాయి. మీరు rules ఇచ్చిన తర్వాత మాత్రమే ఆ విభాగానికి exact rule calculation/result engine జోడిస్తాం; అప్పటివరకు ఊహా prediction చూపించము.',
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF0F2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE4C8CD)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'జాతక ఆధారం LOADED',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 5),
                  Text('పేరు: ${widget.birthData.name}'),
                  Text('లగ్నం: $lagna'),
                  Text('స్థలం: ${widget.birthData.place}'),
                  const SizedBox(height: 5),
                  Text(
                    _planetSummary(),
                    style: const TextStyle(fontSize: 12.5),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _copyContext,
                    icon: const Icon(Icons.copy_outlined, size: 18),
                    label: const Text('Calculation context copy'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            for (var i = 0; i < widget.sections.length; i++)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF7F3),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFE4C8CD)),
                ),
                child: Theme(
                  data: Theme.of(context).copyWith(
                    dividerColor: Colors.transparent,
                    splashColor: const Color(0xFFFFE7EB),
                  ),
                  child: ExpansionTile(
                    key: PageStorageKey('${widget.title}-$i'),
                    initiallyExpanded: _openIndex == i,
                    onExpansionChanged: (open) {
                      setState(() => _openIndex = open ? i : null);
                    },
                    leading: const Icon(
                      Icons.chevron_right,
                      color: Color(0xFF7B1E2B),
                    ),
                    title: Text(
                      widget.sections[i],
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                    trailing: const Chip(label: Text('READY')),
                    childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: const Color(0xFFEAD9DC)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: const [
                                Icon(
                                  Icons.check_circle_outline,
                                  size: 18,
                                  color: Color(0xFF7B1E2B),
                                ),
                                SizedBox(width: 6),
                                Text(
                                  'Screen / input layer active',
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            Text(
                              '${widget.sections[i]} కోసం birth chart data సిద్ధంగా ఉంది. Rule source వచ్చిన తర్వాత Rule → Calculation → Result → Validation రూపంలో ఇదే sectionలో output చూపిస్తాం.',
                            ),
                            const SizedBox(height: 8),
                            const Text(
                              'RULE ENGINE: rules pending',
                              style: TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF8D3140),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}



class _ConsultationTab extends StatefulWidget {
  final BirthData birthData;
  final AstroChartResult result;
  final AshtakavargaResult av;

  const _ConsultationTab({
    required this.birthData,
    required this.result,
    required this.av,
  });

  @override
  State<_ConsultationTab> createState() => _ConsultationTabState();
}

class _ConsultationTabState extends State<_ConsultationTab> {
  late final DateTime _asOfLocal;
  late final Future<AstroChartResult> _transitFuture;

  @override
  void initState() {
    super.initState();
    final nowUtc = DateTime.now().toUtc();
    final offsetMinutes = (widget.birthData.timezoneOffsetHours * 60).round();
    _asOfLocal = nowUtc.add(Duration(minutes: offsetMinutes));
    _transitFuture = AstroCalculationService.calculate(
      BirthData(
        name: widget.birthData.name,
        localDateTime: _asOfLocal,
        place: widget.birthData.place,
        latitude: widget.birthData.latitude,
        longitude: widget.birthData.longitude,
        timezoneOffsetHours: widget.birthData.timezoneOffsetHours,
        ayanamsa: widget.birthData.ayanamsa,
      ),
    );
  }

  Color _toneColor(ConsultationTone tone) => switch (tone) {
        ConsultationTone.strong => const Color(0xFF1B7F3A),
        ConsultationTone.caution => const Color(0xFFB3261E),
        ConsultationTone.moderate => const Color(0xFF8A5A00),
        ConsultationTone.info => const Color(0xFF355E8A),
      };

  IconData _toneIcon(ConsultationTone tone) => switch (tone) {
        ConsultationTone.strong => Icons.check_circle,
        ConsultationTone.caution => Icons.warning_amber_rounded,
        ConsultationTone.moderate => Icons.info_outline,
        ConsultationTone.info => Icons.fact_check_outlined,
      };

  String _toneLabel(ConsultationTone tone) => switch (tone) {
        ConsultationTone.strong => 'అనుకూల మద్దతు',
        ConsultationTone.caution => 'జాగ్రత్త',
        ConsultationTone.moderate => 'మధ్యస్థ / మిశ్రమం',
        ConsultationTone.info => 'సాంకేతిక సమాచారం',
      };

  String _reportText({
    required ConsultationOverallSummary overall,
    required ConsultationDashaSummary dasha,
    required List<ConsultationEventSummary> events,
    required List<ConsultationPlanetSummary> planets,
  }) {
    final b = StringBuffer()
      ..writeln('అన్నపూర్ణ ఆస్ట్రో వాస్తు — Client Consultation Summary')
      ..writeln('క్లయింట్: ${widget.birthData.name}')
      ..writeln('తేదీ: ${AstroFormat.dateTime(_asOfLocal)}')
      ..writeln('స్థలం: ${widget.birthData.place}')
      ..writeln('')
      ..writeln('Overall: ${overall.headline}')
      ..writeln('Strong ${overall.strongCount} • Mixed ${overall.mixedCount} • Caution ${overall.cautionCount}')
      ..writeln('')
      ..writeln('ప్రస్తుత దశలు:')
      ..writeln(dasha.vimshottari)
      ..writeln(dasha.tribhagi)
      ..writeln('')
      ..writeln('అంశాలవారీ ఫలితాలు:');
    for (final item in events) {
      b
        ..writeln('')
        ..writeln('${item.title} — ${_toneLabel(item.tone)}')
        ..writeln('పలితం: ${item.result}')
        ..writeln('క్లయింట్‌కు చెప్పండి: ${item.sayThis}')
        ..writeln('సలహా: ${item.practicalAdvice}')
        ..writeln('Evidence: ${item.evidencePassed}/${item.evidenceTotal}')
        ..writeln('Rule: ${item.ruleIds}');
    }
    b
      ..writeln('')
      ..writeln('గ్రహ బలం — quick reading:');
    for (final p in planets) {
      b.writeln('${p.planet}: ${p.strength.toStringAsFixed(2)}/20 • ${p.strengthLabel} • Star ${p.starLord} • Sub ${p.subLord}');
    }
    b
      ..writeln('')
      ..writeln('గమనిక: ఈ summary app evidence helper మాత్రమే. ఇది probability % కాదు; ఒక్క rule/ఒక్క varga ఆధారంగా deterministic prediction కాదు.');
    return b.toString();
  }

  void _showEventDetail(
    BuildContext context,
    ConsultationEventSummary item,
    JaiminiResult jaimini,
  ) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      backgroundColor: const Color(0xFFFFFAF7),
      builder: (context) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.82,
        minChildSize: 0.48,
        maxChildSize: 0.95,
        builder: (context, controller) => ListView(
          controller: controller,
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 28),
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 30),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      Text(_toneLabel(item.tone), style: TextStyle(fontWeight: FontWeight.w700, color: _toneColor(item.tone))),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            _ConsultationInfoBox(
              icon: Icons.record_voice_over_outlined,
              title: 'క్లయింట్‌కు చెప్పండి',
              body: item.sayThis,
              color: const Color(0xFFEAF6EE),
            ),
            const SizedBox(height: 10),
            _ConsultationInfoBox(
              icon: Icons.lightbulb_outline,
              title: 'ప్రాక్టికల్ సలహా',
              body: item.practicalAdvice,
              color: const Color(0xFFFFF4DB),
            ),
            const SizedBox(height: 10),
            _ConsultationTimingFinder(
              item: item,
              birthData: widget.birthData,
              natalChart: widget.result,
              av: widget.av,
              asOfLocal: _asOfLocal,
              jaimini: jaimini,
            ),
            const SizedBox(height: 10),
            Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              child: ExpansionTile(
                title: const Text('ఎందుకు? — Evidence', style: TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${item.evidencePassed}/${item.evidenceTotal} evidence layers'),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                children: [
                  _ConsultationEvidenceRow('1. భావ బలం', item.houseEvidence),
                  _ConsultationEvidenceRow('2. దశ', item.dashaEvidence),
                  _ConsultationEvidenceRow('3. గోచారం', item.transitEvidence),
                  _ConsultationEvidenceRow('4. Timing support', item.timingEvidence),
                ],
              ),
            ),
            Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              child: ExpansionTile(
                title: const Text('Rule / Technical', style: TextStyle(fontWeight: FontWeight.w800)),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                children: [
                  Align(alignment: Alignment.centerLeft, child: Text(item.ruleIds)),
                  const SizedBox(height: 8),
                  const Text(
                    'Final label house + dasha + current transit evidenceను కలిపిన app summary. Bindusను probability percentageగా మార్చడం లేదు.',
                    style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: () async {
                final text = '${item.title}\n${item.sayThis}\nసలహా: ${item.practicalAdvice}';
                await Clipboard.setData(ClipboardData(text: text));
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Client script copy అయింది')),
                );
              },
              icon: const Icon(Icons.copy_all_outlined),
              label: const Text('ఈ Client Script Copy చేయండి'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _speakingOrderCard() {
    const steps = [
      ('1', 'ప్రస్తుత దశ', 'ముందుగా MD / AD / PD — ప్రస్తుతం ఏ గ్రహాల కాలం నడుస్తుందో చెప్పండి.'),
      ('2', 'బలమైన అంశాలు', 'Green cards ముందుగా చెప్పండి. క్లయింట్‌కు confidence ఇచ్చే supporting evidenceను సంక్షిప్తంగా చెప్పండి.'),
      ('3', 'మధ్యస్థ అంశాలు', 'Mixed support ఉన్న చోట “అవకాశం ఉంది, timing చూడాలి” అని చెప్పండి.'),
      ('4', 'జాగ్రత్త అంశాలు', 'Red cardను భయపెట్టేలా కాకుండా “తొందరపడకుండా practical verification చేయండి” అని చెప్పండి.'),
      ('5', 'Timing', 'దశ + గోచారం + BAV/SAV support సరిపోతేనే మంచి windowగా చెప్పండి.'),
      ('6', 'సలహా / పరిహారం', 'ముందుగా practical advice; source-supported remedy ఉంటే మాత్రమే పరిహారం చెప్పండి.'),
    ];
    return Card(
      color: const Color(0xFFFFF7F2),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        initiallyExpanded: true,
        leading: const Icon(Icons.format_list_numbered),
        title: const Text('క్లయింట్‌తో మాట్లాడే క్రమం', style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('Consultationలో ఏది ముందు చెప్పాలో ready order'),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: steps.map((s) => Padding(
          padding: const EdgeInsets.only(top: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(radius: 15, backgroundColor: const Color(0xFF8B1E2D), foregroundColor: Colors.white, child: Text(s.$1, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s.$2, style: const TextStyle(fontWeight: FontWeight.w800)),
                Text(s.$3, style: const TextStyle(fontSize: 12.5, color: Color(0xFF5F5052))),
              ])),
            ],
          ),
        )).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<AstroChartResult>(
      future: _transitFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 12),
                Text('Consultation summary కోసం ప్రస్తుత గోచారం లెక్కిస్తున్నాం…'),
              ],
            ),
          );
        }
        if (snapshot.hasError || !snapshot.hasData) {
          return _ErrorView(message: 'Consultation transit layer: ${snapshot.error ?? 'unknown error'}');
        }

        final evidence = AshtakavargaEventEvidenceService.evaluate(
          birthData: widget.birthData,
          natalChart: widget.result,
          transitChart: snapshot.data!,
          av: widget.av,
          asOfLocal: _asOfLocal,
        );
        final events = ConsultationService.eventSummaries(evidence);
        final overall = ConsultationService.overall(events);
        final dasha = ConsultationService.dashaSummary(
          birthData: widget.birthData,
          chart: widget.result,
          asOfLocal: _asOfLocal,
        );
        final planets = widget.result.planets
            .map((p) => ConsultationService.planetSummary(chart: widget.result, planet: p))
            .toList(growable: false);
        final jaimini = JaiminiService.calculate(widget.result);
        final jaiminiFavorable = jaimini.applicableRules.where((r) => r.nature == JaiminiRuleNature.favorable).length;
        final jaiminiAdverse = jaimini.applicableRules.where((r) => r.nature == JaiminiRuleNature.adverse).length;
        final jaiminiYogas = jaimini.applicableRules.where((r) => r.isYoga).length;
        final report = _reportText(
          overall: overall,
          dasha: dasha,
          events: events,
          planets: planets,
        );

        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                const Expanded(child: _SectionTitle('Client Consultation Mode')),
                IconButton(
                  tooltip: 'Copy summary',
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: report));
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Consultation summary copy అయింది')));
                  },
                  icon: const Icon(Icons.copy_all_outlined),
                ),
                IconButton(
                  tooltip: 'Share summary',
                  onPressed: () async {
                    await SharePlus.instance.share(
                      ShareParams(text: report, title: 'Annapurna Astro Vastu - ${widget.birthData.name}'),
                    );
                  },
                  icon: const Icon(Icons.share_outlined),
                ),
              ],
            ),
            const SizedBox(height: 4),
            const Text(
              'ఈ screen raw calculationsను consultationలో చెప్పడానికి సులభమైన క్రమంలో చూపిస్తుంది. Green/Amber/Red అనేవి app evidence labels మాత్రమే; probability % కాదు.',
              style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
            ),
            const SizedBox(height: 12),
            Card(
              color: _toneColor(overall.tone).withOpacity(0.08),
              surfaceTintColor: Colors.transparent,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Icon(_toneIcon(overall.tone), color: _toneColor(overall.tone)),
                      const SizedBox(width: 8),
                      Expanded(child: Text(overall.headline, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
                    ]),
                    const SizedBox(height: 10),
                    Wrap(spacing: 8, runSpacing: 8, children: [
                      Chip(avatar: const Icon(Icons.check_circle, size: 18, color: Color(0xFF1B7F3A)), label: Text('Strong ${overall.strongCount}')),
                      Chip(avatar: const Icon(Icons.info_outline, size: 18, color: Color(0xFF8A5A00)), label: Text('Mixed ${overall.mixedCount}')),
                      Chip(avatar: const Icon(Icons.warning_amber_rounded, size: 18, color: Color(0xFFB3261E)), label: Text('Caution ${overall.cautionCount}')),
                    ]),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              color: const Color(0xFFF6F2FF),
              surfaceTintColor: Colors.transparent,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.campaign_outlined, color: Color(0xFF5A3D8A)),
                        SizedBox(width: 8),
                        Text('మొదటి 30 సెకన్లలో ఇలా చెప్పండి', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(overall.headline, style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text(
                      'బలంగా కనిపిస్తున్న అంశాలు: ${events.where((e) => e.tone == ConsultationTone.strong).map((e) => e.title).take(3).join(' • ').isEmpty ? 'ప్రస్తుతం ప్రత్యేకంగా లేదు' : events.where((e) => e.tone == ConsultationTone.strong).map((e) => e.title).take(3).join(' • ')}',
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'జాగ్రత్తగా చూడాల్సినవి: ${events.where((e) => e.tone == ConsultationTone.caution).map((e) => e.title).take(3).join(' • ').isEmpty ? 'ప్రస్తుతం ప్రత్యేకంగా లేదు' : events.where((e) => e.tone == ConsultationTone.caution).map((e) => e.title).take(3).join(' • ')}',
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'తర్వాత క్లయింట్ ఏ అంశం గురించి అడిగితే ఆ cardను టచ్ చేసి “క్లయింట్‌కు చెప్పండి” line చదవండి.',
                      style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            _speakingOrderCard(),
            const SizedBox(height: 10),
            Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(children: [Icon(Icons.timeline_outlined), SizedBox(width: 8), Text('ప్రస్తుత దశ — ముందుగా చెప్పండి', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))]),
                    const SizedBox(height: 10),
                    Text(dasha.vimshottari),
                    const SizedBox(height: 6),
                    Text(dasha.tribhagi),
                    const SizedBox(height: 8),
                    const Text('ఈ దశా పేర్లను Event cardsలోని సంబంధిత గ్రహ evidenceతో కలిపి final judgment చేయండి.', style: TextStyle(fontSize: 12, color: Color(0xFF5F5052))),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              child: ExpansionTile(
                leading: const Icon(Icons.account_tree_outlined),
                title: const Text('జైమిని — వర్తించిన కాంబినేషన్స్', style: TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text('AK ${jaimini.atmakaraka} • అనుకూలం $jaiminiFavorable • జాగ్రత్త $jaiminiAdverse • యోగాలు $jaiminiYogas'),
                childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                children: [
                  if (jaimini.applicableRules.isEmpty)
                    const Align(alignment: Alignment.centerLeft, child: Text('ప్రస్తుతం source-verified applicable rule hit లేదు.'))
                  else
                    ...jaimini.applicableRules.take(10).map((r) {
                      final color = r.nature == JaiminiRuleNature.favorable
                          ? const Color(0xFF1B7F3A)
                          : r.nature == JaiminiRuleNature.adverse
                              ? const Color(0xFFB3261E)
                              : const Color(0xFF8A5A00);
                      return Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(r.nature == JaiminiRuleNature.favorable ? Icons.check_circle : r.nature == JaiminiRuleNature.adverse ? Icons.warning_amber_rounded : Icons.info_outline, color: color, size: 19),
                            const SizedBox(width: 8),
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(r.topic, style: const TextStyle(fontWeight: FontWeight.w800)),
                              Text(r.result),
                              Text('Rule: ${r.ruleId}', style: const TextStyle(fontSize: 11.5, color: Color(0xFF6B5B5E))),
                            ])),
                          ],
                        ),
                      );
                    }),
                  const SizedBox(height: 10),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('జైమిని rule hitను main event cardకు supporting evidenceగా మాత్రమే ఉపయోగించండి; ఒక్క ruleతో final verdict ఇవ్వవద్దు.', style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic)),
                  ),
                ],
              ),
            ),
            Card(
              color: const Color(0xFFF5F7FA),
              surfaceTintColor: Colors.transparent,
              child: const ListTile(
                leading: Icon(Icons.functions_outlined),
                title: Text('KP — consultation usage', style: TextStyle(fontWeight: FontWeight.w900)),
                subtitle: Text('Planet Star Lord / Sub Lord వివరాలు గ్రహ cardలో active. Exact 12-cusp Sub-Lord promise/denial engine పూర్తిగా source-validated అయ్యే వరకు KPని final verdictగా కలపము.'),
              ),
            ),
            const SizedBox(height: 18),
            const _SectionTitle('అంశాలవారీగా క్లయింట్‌కు చెప్పాల్సింది'),
            const SizedBox(height: 8),
            ...events.map((item) => Card(
              color: Colors.white,
              surfaceTintColor: Colors.transparent,
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                onTap: () => _showEventDetail(context, item, jaimini),
                leading: Icon(_toneIcon(item.tone), color: _toneColor(item.tone), size: 29),
                title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text('${item.result}\nEvidence ${item.evidencePassed}/${item.evidenceTotal} • టచ్ → Client Script + సలహా'),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_right),
              ),
            )),
            const SizedBox(height: 12),
            const _SectionTitle('గ్రహ బలం — Quick Speaking Notes'),
            const SizedBox(height: 6),
            const Text('గ్రహాన్ని టచ్ చేస్తే పూర్తి Degree • Star Lord • Sub Lord • Amsa Devata • Vargaja వివరాలు వస్తాయి.', style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052))),
            const SizedBox(height: 8),
            ...planets.map((p) {
              final natal = widget.result.planets.firstWhere((x) => x.name == p.planet);
              return Card(
                color: Colors.white,
                surfaceTintColor: Colors.transparent,
                margin: const EdgeInsets.only(bottom: 8),
                child: ExpansionTile(
                  leading: CircleAvatar(backgroundColor: _toneColor(p.tone).withOpacity(0.12), foregroundColor: _toneColor(p.tone), child: Text(p.shortName)),
                  title: Text('${p.planet} — ${p.strength.toStringAsFixed(2)}/20', style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${p.strengthLabel} • ${p.theme}'),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                  children: [
                    Align(alignment: Alignment.centerLeft, child: Text('క్లయింట్‌కు చెప్పండి: ${p.sayThis}')),
                    const SizedBox(height: 8),
                    Align(alignment: Alignment.centerLeft, child: Text('D60: ${p.amsaDevata} • ${p.amsaNature}')),
                    const SizedBox(height: 6),
                    Align(alignment: Alignment.centerLeft, child: Text(p.technicalNote, style: const TextStyle(fontSize: 12, color: Color(0xFF5F5052)))),
                    const SizedBox(height: 8),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: OutlinedButton.icon(
                        onPressed: () => _showPlanetDetailSheet(context, widget.result, natal),
                        icon: const Icon(Icons.analytics_outlined),
                        label: const Text('పూర్తి గ్రహ వివరాలు'),
                      ),
                    ),
                  ],
                ),
              );
            }),
            const SizedBox(height: 12),
            _ReportActions(
              title: '${widget.birthData.name} - Consultation',
              reportText: () => report,
            ),
            const SizedBox(height: 30),
          ],
        );
      },
    );
  }
}


class _ConsultationTimingFinder extends StatefulWidget {
  final ConsultationEventSummary item;
  final BirthData birthData;
  final AstroChartResult natalChart;
  final AshtakavargaResult av;
  final DateTime asOfLocal;
  final JaiminiResult jaimini;

  const _ConsultationTimingFinder({
    required this.item,
    required this.birthData,
    required this.natalChart,
    required this.av,
    required this.asOfLocal,
    required this.jaimini,
  });

  @override
  State<_ConsultationTimingFinder> createState() => _ConsultationTimingFinderState();
}

class _ConsultationTimingFinderState extends State<_ConsultationTimingFinder> {
  Future<ConsultationTimingResult>? _future;

  String _two(int value) => value.toString().padLeft(2, '0');

  String _dateTime(DateTime value) =>
      '${_two(value.day)}-${_two(value.month)}-${value.year} ${_two(value.hour)}:${_two(value.minute)}';

  String _date(DateTime value) =>
      '${_two(value.day)}-${_two(value.month)}-${value.year}';

  String _tone(ConsultationTimingTone tone) => switch (tone) {
        ConsultationTimingTone.strong => 'Strong Confluence',
        ConsultationTimingTone.supportive => 'Supportive Window',
        ConsultationTimingTone.mixed => 'Mixed Window',
      };

  Color _color(ConsultationTimingTone tone) => switch (tone) {
        ConsultationTimingTone.strong => const Color(0xFF1B7F3A),
        ConsultationTimingTone.supportive => const Color(0xFF8A5A00),
        ConsultationTimingTone.mixed => const Color(0xFF355E8A),
      };

  Future<ConsultationTimingResult> _load() => ConsultationTimingService.findUpcoming(
        eventKey: widget.item.key,
        birthData: widget.birthData,
        natalChart: widget.natalChart,
        av: widget.av,
        fromLocal: widget.asOfLocal,
        jaimini: widget.jaimini,
        horizonMonths: 12,
      );

  void _start() {
    setState(() {
      _future ??= _load();
    });
  }

  ConsultationTimingWindow? _bestWindow(List<ConsultationTimingWindow> windows) {
    if (windows.isEmpty) return null;
    final strong = windows.where((w) => w.tone == ConsultationTimingTone.strong).toList();
    final pool = strong.isNotEmpty ? strong : windows;
    pool.sort((a, b) {
      final sav = b.savBindus.compareTo(a.savBindus);
      if (sav != 0) return sav;
      final bav = b.bavBindus.compareTo(a.bavBindus);
      if (bav != 0) return bav;
      return a.startLocal.compareTo(b.startLocal);
    });
    return pool.first;
  }

  String _periodText(List<String> periods) =>
      periods.isEmpty ? '—' : periods.join(' • ');

  ConsultationTimingWindow? _peakWindow(
    List<ConsultationTimingWindow> windows,
    ConsultationTimingWindow? best,
  ) {
    if (best == null) return null;
    if (best.tone == ConsultationTimingTone.strong) return best;
    final strong = windows
        .where((w) => w.tone == ConsultationTimingTone.strong)
        .toList();
    if (strong.isEmpty) return null;
    strong.sort((a, b) {
      final sav = b.savBindus.compareTo(a.savBindus);
      if (sav != 0) return sav;
      return b.bavBindus.compareTo(a.bavBindus);
    });
    return strong.first;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFF3F8FF),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.event_available_outlined, color: Color(0xFF355E8A)),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'దశ + గోచారం ఎప్పుడు కలుస్తాయి?',
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              'Vimshottari/Tribhagi MD–AD–PD + exact transit BAV/SAV overlapను 12 నెలలకు లెక్కిస్తుంది. Jaimini rule hitsను independent confirmationగా చూపిస్తుంది.',
              style: TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
            ),
            const SizedBox(height: 10),
            if (_future == null)
              FilledButton.icon(
                onPressed: _start,
                icon: const Icon(Icons.calculate_outlined),
                label: const Text('Timing Window లెక్కించండి'),
              )
            else
              FutureBuilder<ConsultationTimingResult>(
                future: _future,
                builder: (context, snapshot) {
                  if (snapshot.connectionState != ConnectionState.done) {
                    return const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Row(
                        children: [
                          SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2.5)),
                          SizedBox(width: 10),
                          Expanded(child: Text('దశ + గోచార overlap లెక్కిస్తున్నాం…')),
                        ],
                      ),
                    );
                  }
                  if (snapshot.hasError || !snapshot.hasData) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Timing calculation error: ${snapshot.error}', style: const TextStyle(color: Color(0xFFB3261E))),
                        TextButton.icon(
                          onPressed: () => setState(() => _future = _load()),
                          icon: const Icon(Icons.refresh),
                          label: const Text('మళ్లీ ప్రయత్నించండి'),
                        ),
                      ],
                    );
                  }

                  final result = snapshot.data!;
                  final best = _bestWindow([...result.windows]);
                  final peak = _peakWindow([...result.windows], best);
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Search: ${_date(result.searchStart)} → ${_date(result.searchEnd)}',
                        style: const TextStyle(fontSize: 12, color: Color(0xFF5F5052)),
                      ),
                      const SizedBox(height: 8),
                      if (best == null)
                        const _ConsultationInfoBox(
                          icon: Icons.info_outline,
                          title: 'Strong overlap దొరకలేదు',
                          body: 'ఈ 12 నెలల rangeలో favorable BAV/SAV transitతో Vimshottari లేదా Tribhagi supportive MD/AD/PD overlap కనిపించలేదు. దీన్ని “event జరగదు” అని అర్థం చేసుకోకండి; rangeను తర్వాత మళ్లీ చూడాలి.',
                          color: Color(0xFFFFF4DB),
                        )
                      else ...[
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: _color(best.tone).withOpacity(0.08),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _color(best.tone).withOpacity(0.35)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Best overlap — ${_tone(best.tone)}', style: TextStyle(fontWeight: FontWeight.w900, color: _color(best.tone))),
                              const SizedBox(height: 5),
                              Text('${_dateTime(best.startLocal)} → ${_dateTime(best.endLocal)}', style: const TextStyle(fontWeight: FontWeight.w800)),
                              const SizedBox(height: 4),
                              Text('${best.transitPlanet} transit • BAV ${best.bavBindus}/8 • SAV ${best.savBindus} • Kakshya ${best.entryKakshya}${best.retrogradeAtEntry ? ' • Retrograde entry' : ''}'),
                              const SizedBox(height: 8),
                              Text('Vimshottari MD/AD/PD: ${_periodText(best.vimshottariPeriods)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 3),
                              Text('Tribhagi MD/AD/PD: ${_periodText(best.tribhagiPeriods)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                              const SizedBox(height: 3),
                              Text(
                                'Jaimini confirmation: ${best.jaiminiFavorable} అనుకూల • ${best.jaiminiAdverse} జాగ్రత్త',
                                style: const TextStyle(fontWeight: FontWeight.w700),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                result.jaiminiRuleIds.isEmpty
                                    ? 'Jaimini rules: ఈ eventకు direct source-rule hit లేదు.'
                                    : 'Jaimini rules: ${result.jaiminiRuleIds.join(', ')}',
                                style: const TextStyle(fontSize: 12.5, color: Color(0xFF5F5052)),
                              ),
                              const SizedBox(height: 8),
                              if (peak != null)
                                Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFEAF6EE),
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(color: const Color(0xFF1B7F3A).withOpacity(0.25)),
                                  ),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'PEAK EVIDENCE WINDOW',
                                        style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w900, color: Color(0xFF1B7F3A)),
                                      ),
                                      const SizedBox(height: 3),
                                      Text(
                                        '${_dateTime(peak.startLocal)} → ${_dateTime(peak.endLocal)}',
                                        style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF1B7F3A)),
                                      ),
                                      if (identical(peak, best) ||
                                          (peak.startLocal == best.startLocal && peak.endLocal == best.endLocal))
                                        const Padding(
                                          padding: EdgeInsets.only(top: 3),
                                          child: Text(
                                            'ఈ మొత్తం Strong Confluence intervalనే ప్రస్తుతం source-backed peakగా తీసుకుంటున్నాం; artificial మధ్య తేదీ తయారు చేయడం లేదు.',
                                            style: TextStyle(fontSize: 11.5, color: Color(0xFF46674F)),
                                          ),
                                        ),
                                    ],
                                  ),
                                )
                              else
                                const Text(
                                  'Peak: ఈ searchలో అదనపు source-backed Strong Confluence window లేదు.',
                                  style: TextStyle(fontSize: 12.5, color: Color(0xFF6B5B5E)),
                                ),
                              const SizedBox(height: 8),
                              Text(
                                peak != null
                                    ? 'క్లయింట్‌కు చెప్పండి: “${widget.item.title} విషయంలో ${_date(best.startLocal)} నుంచి ${_date(best.endLocal)} వరకు దశ మరియు గోచార support ఒకేసారి కనిపిస్తోంది. ముఖ్య evidence window ${_date(peak.startLocal)} నుంచి ${_date(peak.endLocal)} వరకు ఉంది. Jaiminiలో ${best.jaiminiFavorable} అనుకూల rule hit(s), ${best.jaiminiAdverse} జాగ్రత్త rule hit(s) కనిపిస్తున్నాయి. ఇది comparatively stronger astrological window; ఖచ్చిత సంఘటన హామీగా కాదు.”'
                                    : 'క్లయింట్‌కు చెప్పండి: “${widget.item.title} విషయంలో ${_date(best.startLocal)} నుంచి ${_date(best.endLocal)} వరకు దశ మరియు గోచార support ఒకేసారి కనిపిస్తోంది. Jaiminiలో ${best.jaiminiFavorable} అనుకూల rule hit(s), ${best.jaiminiAdverse} జాగ్రత్త rule hit(s) కనిపిస్తున్నాయి. ఇది supportive astrological window; ఖచ్చిత సంఘటన హామీగా కాదు.”',
                                style: const TextStyle(fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        const Text('ఇతర supporting windows', style: TextStyle(fontWeight: FontWeight.w800)),
                        ...result.windows.take(6).map((w) => Padding(
                              padding: const EdgeInsets.only(top: 7),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(
                                    w.tone == ConsultationTimingTone.strong ? Icons.check_circle : Icons.info_outline,
                                    color: _color(w.tone),
                                    size: 18,
                                  ),
                                  const SizedBox(width: 7),
                                  Expanded(
                                    child: Text(
                                      '${_date(w.startLocal)} → ${_date(w.endLocal)} • ${w.transitPlanet} • '
                                      'Vim ${_periodText(w.vimshottariPeriods)} • '
                                      'Tribhagi ${_periodText(w.tribhagiPeriods)} • '
                                      'BAV ${w.bavBindus}/8 • SAV ${w.savBindus}',
                                      style: const TextStyle(fontSize: 12.5),
                                    ),
                                  ),
                                ],
                              ),
                            )),
                      ],
                      const SizedBox(height: 10),
                      ExpansionTile(
                        tilePadding: EdgeInsets.zero,
                        childrenPadding: EdgeInsets.zero,
                        title: const Text('జైమిని confirmation', style: TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text('అనుకూల rule hits ${result.jaiminiFavorable} • జాగ్రత్త ${result.jaiminiAdverse}'),
                        children: [
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(
                              result.jaiminiRuleIds.isEmpty ? 'ఈ eventకు direct Jaimini rule hit లేదు.' : 'Rules: ${result.jaiminiRuleIds.join(', ')}',
                              style: const TextStyle(fontSize: 12.5),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: Text(result.jaiminiNote, style: const TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: Color(0xFF5F5052))),
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _ConsultationInfoBox extends StatelessWidget {
  final IconData icon;
  final String title;
  final String body;
  final Color color;

  const _ConsultationInfoBox({
    required this.icon,
    required this.title,
    required this.body,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2D2D5)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFF7B1E2B)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text(body),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ConsultationEvidenceRow extends StatelessWidget {
  final String title;
  final String body;

  const _ConsultationEvidenceRow(this.title, this.body);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Align(
        alignment: Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(body),
          ],
        ),
      ),
    );
  }
}


class _SystemsTab extends StatelessWidget {
  final BirthData birthData;
  final AstroChartResult result;

  const _SystemsTab({
    required this.birthData,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    final vim = DashaService.vimshottari(
      chart: result,
      birthDateTime: birthData.localDateTime,
    );
    final jai = JaiminiService.calculate(result);
    final kpRows = KpService.planetaryTable(result);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionTitle('దశలు • Jamakola • జైమిని • Tajik • BCP • BSP • BNN • KP'),
        const SizedBox(height: 8),
        const Text(
          'ఎడమపై ☰ menu టచ్ చేసి కావలసిన system ఎంచుకోండి. ప్రతి systemకు ప్రత్యేక scroll page ఉంటుంది. Verified sourceలో స్పష్టంగా లేని arithmetic/result rulesను ఊహించి hard-code చేయము.',
        ),
        const SizedBox(height: 14),
        _VimshottariCard(result: vim, birthDateTime: birthData.localDateTime),
        const SizedBox(height: 14),
        _JaiminiCard(result: jai, chart: result),
        const SizedBox(height: 14),
        _KpCard(rows: kpRows),
        const SizedBox(height: 14),
        const _SourcePendingCard(
          title: 'Jamakola System',
          icon: Icons.auto_awesome_outlined,
          text:
              'Jamakola కోసం module slot సిద్ధంగా ఉంది. మీరు ఇచ్చే/ఇప్పటికే ఉన్న verified Jamakola source rulesను మాత్రమే engineలో hard-code చేస్తాం; source లేకుండా prediction rulesను కలపము.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'Tajik / Varshaphala',
          icon: Icons.calendar_month_outlined,
          text:
              'Tajik annual-chart module slot సిద్ధంగా ఉంది. Verified Tajik sourceలోని Muntha, annual lord, sahams/yogas మరియు timing rules వచ్చిన తర్వాత source-tagతో enable చేస్తాం.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BCP',
          icon: Icons.rotate_right_outlined,
          text:
              'BCP menu సిద్ధంగా ఉంది. Supplied/verified source rules వచ్చిన తర్వాత age/year activation, evidence మరియు timing calculationsను enable చేస్తాం.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BSP',
          icon: Icons.rule_folder_outlined,
          text:
              'BSP menu సిద్ధంగా ఉంది. Exact source rule/exception tablesను verify చేసిన తర్వాత మాత్రమే result engine activate చేస్తాం.',
        ),
        const SizedBox(height: 12),
        const _SourcePendingCard(
          title: 'BNN',
          icon: Icons.hub_outlined,
          text:
              'BNN menu సిద్ధంగా ఉంది. Planetary links, significations, event combinations మరియు timing rules verified sourceతోనే add చేస్తాం.',
        ),
        const SizedBox(height: 30),
      ],
    );
  }
}


class _DashaSystemsCard extends StatefulWidget {
  final AstroChartResult chart;
  final DateTime birthDateTime;

  const _DashaSystemsCard({
    required this.chart,
    required this.birthDateTime,
  });

  @override
  State<_DashaSystemsCard> createState() => _DashaSystemsCardState();
}

class _DashaSystemsCardState extends State<_DashaSystemsCard> {
  DashaSystemKind _selectedKind = DashaSystemKind.tribhagi;
  late DateTime _probeDate;

  @override
  void initState() {
    super.initState();
    _probeDate = DateTime.now();
  }

  String _date(DateTime dt) =>
      '${AstroFormat.two(dt.day)}-${AstroFormat.two(dt.month)}-${dt.year}';

  String _dateTime(DateTime dt) =>
      '${_date(dt)} ${AstroFormat.two(dt.hour)}:${AstroFormat.two(dt.minute)}';

  String _years(double value) {
    if (value >= 1) return '${value.toStringAsFixed(4)} y';
    final days = value * 365.2425;
    if (days >= 1) return '${days.toStringAsFixed(2)} d';
    return '${(days * 24).toStringAsFixed(2)} h';
  }

  Future<void> _pickDate() async {
    final first = DateTime(widget.birthDateTime.year - 10, 1, 1);
    final last = DateTime(widget.birthDateTime.year + 150, 12, 31);
    var initial = _probeDate;
    if (initial.isBefore(first)) initial = first;
    if (initial.isAfter(last)) initial = last;

    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first,
      lastDate: last,
      helpText: 'దశా తేదీ ఎంచుకోండి',
    );
    if (!mounted || picked == null) return;
    setState(() {
      _probeDate = DateTime(
        picked.year,
        picked.month,
        picked.day,
        12,
      );
    });
  }

  Widget _pathTile(
    String level,
    DashaPeriod period, {
    bool emphasize = false,
  }) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: emphasize ? const Color(0xFFFFECEF) : const Color(0xFFFFF8F4),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: emphasize ? const Color(0xFF8D3140) : const Color(0xFFE3C7CC),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$level • ${period.lord}',
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 3),
          Text('${_dateTime(period.start)} → ${_dateTime(period.end)}'),
          Text(
            _years(period.years),
            style: const TextStyle(fontSize: 12, color: Color(0xFF66595B)),
          ),
        ],
      ),
    );
  }

  Widget _periodTable(
    String title,
    List<DashaPeriod> periods,
    String? activeLord,
  ) {
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      childrenPadding: EdgeInsets.zero,
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.w800),
      ),
      subtitle: Text('${periods.length} periods'),
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            columnSpacing: 18,
            headingRowHeight: 42,
            dataRowMinHeight: 42,
            dataRowMaxHeight: 54,
            columns: const [
              DataColumn(label: Text('Lord')),
              DataColumn(label: Text('Start')),
              DataColumn(label: Text('End')),
              DataColumn(label: Text('Duration')),
            ],
            rows: periods
                .map(
                  (p) => DataRow(
                    selected: activeLord != null && p.lord == activeLord,
                    cells: [
                      DataCell(Text(p.lord)),
                      DataCell(Text(_date(p.start))),
                      DataCell(Text(_date(p.end))),
                      DataCell(Text(_years(p.years))),
                    ],
                  ),
                )
                .toList(),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final system = DashaService.system(
      kind: _selectedKind,
      chart: widget.chart,
      birthDateTime: widget.birthDateTime,
    );
    final path = DashaService.pathAt(system, _probeDate);

    final ads = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.mahadasha);
    final pds = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.antardasha);
    final suks = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.pratyantardasha);
    final pranas = path == null
        ? const <DashaPeriod>[]
        : DashaService.subPeriodsFor(system, path.sukshma);

    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'దశా గణన',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            const Text(
              'త్రిభాగి • వింశోత్తరి • ఖండ • యోగిని — birth balance నుంచి 5 స్థాయుల వరకు.',
              style: TextStyle(color: Color(0xFF65585A)),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: DashaSystemKind.values
                  .map(
                    (kind) => ChoiceChip(
                      label: Text(kind.teluguLabel),
                      selected: _selectedKind == kind,
                      onSelected: (_) => setState(() => _selectedKind = kind),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF5F6),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE0C1C7)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    system.label,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'Birth start: ${system.startingLord} • Nakshatra ${(system.moonNakshatraIndex + 1)} • '
                    'elapsed ${(system.nakshatraFractionElapsed * 100).toStringAsFixed(2)}%',
                  ),
                  Text(
                    'Birth balance: ${system.birthBalanceYears.toStringAsFixed(6)} years '
                    '• source Y-M-D(360): ${DashaService.sourceYmd360(system.birthBalanceYears)}',
                  ),
                  const SizedBox(height: 6),
                  Text(
                    system.sourceNote,
                    style: const TextStyle(fontSize: 12.5, color: Color(0xFF65585A)),
                  ),
                  if (_selectedKind == DashaSystemKind.tribhagi) ...[
                    const SizedBox(height: 6),
                    const Text(
                      'Mehta timing priority: 2వ స్థాయి అంతర్దశ → 3వ ప్రత్యంతర్దశ → 4వ సూక్ష్మ → 5వ ప్రాణం. మహాదశను eventకు ఒక్కటే నిర్ణయకంగా తీసుకోరు.',
                      style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'పరిశీలన తేదీ: ${_date(_probeDate)}',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: _pickDate,
                  icon: const Icon(Icons.calendar_month_outlined),
                  label: const Text('తేదీ'),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (path == null)
              const Text(
                'ఈ తేదీ generated dasha range బయట ఉంది. వేరే తేదీ ఎంచుకోండి.',
                style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
              )
            else ...[
              const Text(
                'ఈ తేదీకి 5 స్థాయుల దశా స్థితి',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              _pathTile('1. మహాదశ', path.mahadasha),
              _pathTile('2. అంతర్దశ', path.antardasha, emphasize: true),
              _pathTile('3. ప్రత్యంతర్దశ', path.pratyantardasha, emphasize: true),
              _pathTile('4. సూక్ష్మ', path.sukshma, emphasize: true),
              _pathTile('5. ప్రాణ', path.prana, emphasize: true),
              const Divider(height: 24),
              _periodTable(
                'మహాదశ క్రమం',
                system.mahadashas,
                path.mahadasha.lord,
              ),
              _periodTable(
                '${path.mahadasha.lord} — అంతర్దశలు',
                ads,
                path.antardasha.lord,
              ),
              _periodTable(
                '${path.antardasha.lord} — ప్రత్యంతర్దశలు',
                pds,
                path.pratyantardasha.lord,
              ),
              _periodTable(
                '${path.pratyantardasha.lord} — సూక్ష్మ దశలు',
                suks,
                path.sukshma.lord,
              ),
              _periodTable(
                '${path.sukshma.lord} — ప్రాణ దశలు',
                pranas,
                path.prana.lord,
              ),
            ],
            const SizedBox(height: 8),
            const Text(
              'Date mapping: civil year 365.2425 days. Mehta supplied period tables also show Y-M-D reference values on a 360-day year / 30-day month convention; the app displays that reference balance separately instead of silently mixing conventions.',
              style: TextStyle(fontSize: 11.5, color: Color(0xFF6A5D60)),
            ),
          ],
        ),
      ),
    );
  }
}

class _VimshottariCard extends StatelessWidget {
  final VimshottariResult result;
  final DateTime birthDateTime;

  const _VimshottariCard({
    required this.result,
    required this.birthDateTime,
  });

  String _date(DateTime dt) =>
      '${AstroFormat.two(dt.day)}-${AstroFormat.two(dt.month)}-${dt.year}';

  @override
  Widget build(BuildContext context) {
    final birthMd = result.currentMahadasha;
    final now = DateTime.now();
    final currentMd =
        DashaService.periodAt(result.mahadashas, now) ?? birthMd;
    final currentAds = DashaService.subPeriods(currentMd);
    final currentAd =
        DashaService.periodAt(currentAds, now) ?? currentAds.first;
    final currentPds = DashaService.subPeriods(currentAd);
    final currentPd =
        DashaService.periodAt(currentPds, now) ?? currentPds.first;

    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'వింశోత్తరి దశలు',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(
              'Moon Nakshatra lord: ${result.moonNakshatraLord} • '
              'elapsed ${(result.nakshatraFractionElapsed * 100).toStringAsFixed(2)}%',
            ),
            const SizedBox(height: 8),
            DecoratedBox(
              decoration: BoxDecoration(
                color: const Color(0xFFFFF0F2),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF8D3140)),
              ),
              child: Padding(
                padding: const EdgeInsets.all(10),
                child: Text(
                  'Birth Mahadasha: ${birthMd.lord}  '
                  '${_date(birthMd.start)} → ${_date(birthMd.end)}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            ),
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFF7F3),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFE4C8CD)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'ప్రస్తుత దశా స్థితి',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    'MD ${currentMd.lord}: ${_date(currentMd.start)} → ${_date(currentMd.end)}',
                  ),
                  Text(
                    'AD ${currentAd.lord}: ${_date(currentAd.start)} → ${_date(currentAd.end)}',
                  ),
                  Text(
                    'PD ${currentPd.lord}: ${_date(currentPd.start)} → ${_date(currentPd.end)}',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Mahadasha sequence',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('Lord')),
                  DataColumn(label: Text('Start')),
                  DataColumn(label: Text('End')),
                ],
                rows: result.mahadashas.take(10).map((p) => DataRow(cells: [
                      DataCell(Text(p.lord)),
                      DataCell(Text(_date(p.start))),
                      DataCell(Text(_date(p.end))),
                    ])).toList(),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              '${birthMd.lord} birth-MD Antardashas',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            ...result.currentAntardashas.map(
              (p) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('${p.lord}: ${_date(p.start)} → ${_date(p.end)}'),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Convention: 120-year Vimshottari proportions; civil year = 365.2425 days. '
              'Calculation convention is shown explicitly so dates are reproducible.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}


class _JaiminiCard extends StatelessWidget {
  final JaiminiResult result;
  final AstroChartResult chart;

  const _JaiminiCard({required this.result, required this.chart});

  Map<int, List<String>> _jaiminiOccupants() {
    final occupants = <int, List<String>>{
      for (var i = 0; i < 12; i++) i: <String>[],
    };

    final karakaByPlanet = <String, String>{
      for (final k in result.charaKarakas) k.planet: k.code,
    };

    for (final planet in chart.planets) {
      final karaka = karakaByPlanet[planet.name];
      var label = '${planet.shortName} ${planet.degreesInSign.toStringAsFixed(1)}°';
      if (karaka != null) label += ' $karaka';
      occupants[planet.signIndex]!.add(label);
    }

    for (final pada in result.arudhaPadas) {
      occupants[pada.padaSignIndex]!.add('P${pada.padaNumber}');
    }

    return occupants;
  }

  @override
  Widget build(BuildContext context) {
    final rahu = chart.planets.firstWhere((p) => p.name == 'Rahu');
    final rahuEffective = 30.0 - rahu.degreesInSign;
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('జైమిని System', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            _JaiminiApplicableRules(rules: result.applicableRules),
            const SizedBox(height: 16),
            _SouthIndianChart(
              title: 'జైమిని చక్రం • P1–P12',
              ascendantSignIndex: chart.ascendantSignIndex,
              occupants: _jaiminiOccupants(),
              onOccupantTap: (label) {
                final planet = _planetFromOccupantLabel(chart, label);
                if (planet != null) _showPlanetDetailSheet(context, chart, planet);
              },
            ),
            const SizedBox(height: 12),
            const Text(
              'Pada / Arudha P1–P12',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            ...result.arudhaPadas.map(
              (p) => Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: Text(
                  'P${p.padaNumber}: ${p.sourceSignIndex + 1} → ${p.lord} ${p.lordSignIndex + 1} • దూరం ${p.distance} → ${p.padaSignIndex + 1}',
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text('Atmakaraka: ${result.atmakaraka}'),
            Text('Karakamsa: ${result.karakamsaSignIndex + 1}'),
            Text('Rahu effective degree reference: ${rahuEffective.toStringAsFixed(4)}°'),
            if (result.hasDegreeTie)
              const Padding(
                padding: EdgeInsets.only(top: 6),
                child: Text(
                  'Degree tie detected — supplied source tie/empty-slot procedure must be applied manually before final karaka assignment.',
                  style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF8D3140)),
                ),
              ),
            const SizedBox(height: 10),
            const Text('Chara Karakas (7-karaka core)', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: result.charaKarakas
                  .map((k) => Chip(label: Text('${k.code}: ${k.planet} ${k.effectiveDegree.toStringAsFixed(2)}°')))
                  .toList(),
            ),
            const SizedBox(height: 12),
            const Text('Lagna Argala / Virodha', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            ...result.argalaFromLagna.map(
              (row) => Text(
                '${row.label}: ${row.signIndex + 1}  ${row.planets.isEmpty ? '—' : row.planets.join(', ')}',
              ),
            ),
            const SizedBox(height: 12),
            const Text('Rashi Drishti', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...List.generate(12, (i) {
              final targets = result.rashiDrishti[i]!
                  .map((s) => '${s + 1}')
                  .join(', ');
              return Text('${i + 1} → $targets');
            }),
            const SizedBox(height: 8),
            const Text(
              'P1–P12 calculation: source sign నుండి lord వరకు inclusive దూరం ఎంతైతే, lord నుండి అదే inclusive దూరం count చేసి Pada పొందుతుంది. 4వ/7వ source examples కూడా ఇదే విధంగా అమలవుతాయి. Chara Dasha variants మాత్రం source verification తర్వాత enable చేయాలి.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}


class _JaiminiApplicableRules extends StatelessWidget {
  final List<JaiminiRuleHit> rules;

  const _JaiminiApplicableRules({required this.rules});

  Color _color(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => const Color(0xFF1B7F3A),
        JaiminiRuleNature.adverse => const Color(0xFFB3261E),
        JaiminiRuleNature.neutral => const Color(0xFF6B5B5E),
      };

  IconData _icon(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => Icons.check_circle,
        JaiminiRuleNature.adverse => Icons.cancel,
        JaiminiRuleNature.neutral => Icons.info_outline,
      };

  String _status(JaiminiRuleNature nature) => switch (nature) {
        JaiminiRuleNature.favorable => 'అనుకూలం',
        JaiminiRuleNature.adverse => 'ప్రతికూలం / జాగ్రత్త',
        JaiminiRuleNature.neutral => 'వివరణాత్మక సూచన',
      };

  void _showDetails(BuildContext context, JaiminiRuleHit rule) {
    final color = _color(rule.nature);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) => SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(
            20,
            18,
            20,
            24 + MediaQuery.of(sheetContext).viewInsets.bottom,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(_icon(rule.nature), color: color, size: 30),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          rule.topic,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        Text(
                          _status(rule.nature),
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                rule.combination,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
              ),
              const Divider(height: 28),
              const Text('పలితం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.result, style: const TextStyle(fontSize: 16, height: 1.45)),
              const SizedBox(height: 18),
              const Text('జాతక పరిశీలన', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.analysis, style: const TextStyle(fontSize: 16, height: 1.45)),
              const SizedBox(height: 18),
              const Text('పరిహారం', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(rule.remedy, style: const TextStyle(fontSize: 16, height: 1.45)),
              const Divider(height: 28),
              Text(
                '${rule.ruleId} • ${rule.source}',
                style: const TextStyle(fontSize: 12, color: Color(0xFF6E5D60)),
              ),
              const SizedBox(height: 8),
              const Text(
                'గమనిక: ఒకే నియమంతో తుది తీర్పు ఇవ్వకుండా, అనుకూల మరియు ప్రతికూల supporting rules అన్నింటినీ కలిపి పరిశీలించాలి.',
                style: TextStyle(fontSize: 12, color: Color(0xFF6E5D60)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (rules.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF7F3),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE4C6C9)),
        ),
        child: const Text(
          'ఈ జాతకానికి ప్రస్తుతం active source-verified Jaimini combinations match కాలేదు. Chart, P1–P12, Karakas మాత్రం క్రింద చూడవచ్చు.',
        ),
      );
    }

    final yogaCount = rules.where((r) => r.isYoga).length;
    final favorable = rules.where((r) => r.nature == JaiminiRuleNature.favorable).length;
    final adverse = rules.where((r) => r.nature == JaiminiRuleNature.adverse).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'ఈ జాతకానికి వర్తించే కాంబినేషన్స్ / యోగాలు',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 6),
        Text(
          'యోగాలు $yogaCount  •  అనుకూలం $favorable  •  ప్రతికూలం $adverse',
          style: const TextStyle(color: Color(0xFF6E5D60), fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 10),
        ...rules.map((rule) {
          final color = _color(rule.nature);
          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: color.withOpacity(0.35)),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 10, 12),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Icon(_icon(rule.nature), color: color, size: 28),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'అంశము: ${rule.topic}',
                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          rule.combination,
                          style: const TextStyle(fontWeight: FontWeight.w600),
                        ),
                        const SizedBox(height: 8),
                        InkWell(
                          borderRadius: BorderRadius.circular(8),
                          onTap: () => _showDetails(context, rule),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Text(
                                    'పలితం: ${rule.result}',
                                    style: TextStyle(
                                      color: color,
                                      fontWeight: FontWeight.w800,
                                      height: 1.35,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Icon(Icons.touch_app_outlined, size: 18, color: color),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }
}

class _KpCard extends StatelessWidget {
  final List<KpStellarPosition> rows;

  const _KpCard({required this.rows});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('KP System', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'Planet → Sign Lord → Star Lord → Sub Lord stellar table. Sub divisions use unequal Vimshottari proportions inside each 13°20′ star.',
            ),
            const SizedBox(height: 10),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: DataTable(
                columns: const [
                  DataColumn(label: Text('Planet')),
                  DataColumn(label: Text('Sign Lord')),
                  DataColumn(label: Text('Star Lord')),
                  DataColumn(label: Text('Sub Lord')),
                ],
                rows: rows.map((r) => DataRow(cells: [
                      DataCell(Text(r.body)),
                      DataCell(Text(r.signLord)),
                      DataCell(Text(r.starLord)),
                      DataCell(Text(r.subLord)),
                    ])).toList(),
              ),
            ),
            const SizedBox(height: 12),
            const Text('Source-based Event House Groups', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            ...KpService.eventGroups.map(
              (e) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '${e.event}: ${e.favourableHouses.join(', ')}  • Primary ${e.primaryCusp}'
                  '${e.contraryHouses.isEmpty ? '' : ' • Contrary ${e.contraryHouses.join(', ')}'}',
                ),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'KP Cusp Sub-Lord promise/denial engineకు exact 12 cusp longitudes + house ownership/signification layer అవసరం. ఈ buildలో planetary Star/Sub coreను మాత్రమే activate చేశాం; cusp resultను ఊహించి చూపడం లేదు.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class _SourcePendingCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final String text;

  const _SourcePendingCard({
    required this.title,
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: const Color(0xFF7B1E2B)),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(text),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BirthSummaryCard extends StatelessWidget {
  final BirthData birthData;

  const _BirthSummaryCard({required this.birthData});

  @override
  Widget build(BuildContext context) {
    final dt = birthData.localDateTime;
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              birthData.name,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text('స్థలం: ${birthData.place}'),
            Text(
              'Lat ${birthData.latitude.toStringAsFixed(6)}  •  '
              'Lon ${birthData.longitude.toStringAsFixed(6)}',
            ),
            Text('జనన సమయం: ${AstroFormat.dateTime(dt)}'),
            Text(
              'Timezone: ${AstroFormat.timezoneOffset(birthData.timezoneOffsetHours)}',
            ),
          ],
        ),
      ),
    );
  }
}

class _CalculationSummaryCard extends StatelessWidget {
  final AstroChartResult result;
  final String ayanamsaName;

  const _CalculationSummaryCard({
    required this.result,
    required this.ayanamsaName,
  });

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.verified_outlined),
                SizedBox(width: 8),
                Text(
                  'Calculation',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Text('Engine: Swiss Ephemeris ${result.engineVersion}'),
            const Text('Mode: Sidereal + Moshier ephemeris'),
            Text('Ayanamsa: $ayanamsaName'),
            Text('Ayanamsa value: ${result.ayanamsaDegrees.toStringAsFixed(6)}°'),
            const SizedBox(height: 8),
            Text(
              'లగ్నం: ${AstroFormat.longitudeDms(result.ascendantLongitude)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

class _SouthIndianChart extends StatelessWidget {
  final String title;
  final int ascendantSignIndex;
  final Map<int, List<String>> occupants;
  final ValueChanged<String>? onOccupantTap;

  const _SouthIndianChart({
    required this.title,
    required this.ascendantSignIndex,
    required this.occupants,
    this.onOccupantTap,
  });

  // Traditional South-Indian fixed-sign layout (fixed Rasi positions).
  // Row 1: Pisces | Aries | Taurus | Gemini
  // Row 2: Aquarius |        centre       | Cancer
  // Row 3: Capricorn|        centre       | Leo
  // Row 4: Sagittarius | Scorpio | Libra | Virgo
  static const Map<int, (int, int)> _positionBySign = <int, (int, int)>{
    11: (0, 0), // Pisces
    0: (0, 1),  // Aries
    1: (0, 2),  // Taurus
    2: (0, 3),  // Gemini
    10: (1, 0), // Aquarius
    3: (1, 3),  // Cancer
    9: (2, 0),  // Capricorn
    4: (2, 3),  // Leo
    8: (3, 0),  // Sagittarius
    7: (3, 1),  // Scorpio
    6: (3, 2),  // Libra
    5: (3, 3),  // Virgo
  };

  @override
  Widget build(BuildContext context) {
    const lineColor = Color(0xFF8B2D3B);
    const centreColor = Color(0xFFFFFBF6);

    return Card(color: Colors.white, surfaceTintColor: Colors.transparent,
      elevation: 1,
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Color(0xFF2C2022),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'South Indian fixed-sign chart',
              style: const TextStyle(
                fontSize: 12.5,
                fontWeight: FontWeight.w600,
                color: Color(0xFF5F5052),
              ),
            ),
            const SizedBox(height: 12),
            AspectRatio(
              aspectRatio: 1,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final side = constraints.maxWidth;
                  final cell = side / 4;
                  return DecoratedBox(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: lineColor, width: 2),
                    ),
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        for (final entry in _positionBySign.entries)
                          Positioned(
                            left: entry.value.$2 * cell,
                            top: entry.value.$1 * cell,
                            width: cell,
                            height: cell,
                            child: _TraditionalRasiCell(
                              signIndex: entry.key,
                              isAscendant: entry.key == ascendantSignIndex,
                              occupants: occupants[entry.key] ?? const <String>[],
                              onOccupantTap: onOccupantTap,
                            ),
                          ),
                        Positioned(
                          left: cell,
                          top: cell,
                          width: cell * 2,
                          height: cell * 2,
                          child: Container(
                            decoration: BoxDecoration(
                              color: centreColor,
                              border: Border.all(color: lineColor, width: 2),
                            ),
                            padding: const EdgeInsets.all(10),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  title,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w900,
                                    color: Color(0xFF2C2022),
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  'లగ్నం',
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w800,
                                    color: lineColor,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TraditionalRasiCell extends StatelessWidget {
  final int signIndex;
  final bool isAscendant;
  final List<String> occupants;
  final ValueChanged<String>? onOccupantTap;

  const _TraditionalRasiCell({
    required this.signIndex,
    required this.isAscendant,
    required this.occupants,
    this.onOccupantTap,
  });

  @override
  Widget build(BuildContext context) {
    const lineColor = Color(0xFF8B2D3B);
    return Container(
      decoration: BoxDecoration(
        color: isAscendant ? const Color(0xFFFFECEF) : Colors.white,
        border: Border.all(color: lineColor, width: 1),
      ),
      padding: const EdgeInsets.all(5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (isAscendant)
            Align(
              alignment: Alignment.topRight,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: lineColor,
                ),
                child: const Text(
                  'Lg',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9.5,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          if (isAscendant) const SizedBox(height: 4),
          Expanded(
            child: SingleChildScrollView(
              child: Wrap(
                spacing: 4,
                runSpacing: 2,
                children: occupants.map((text) {
                  final child = Text(
                    text,
                    style: const TextStyle(
                      fontSize: 10.8,
                      height: 1.15,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF3B2C2E),
                    ),
                  );
                  if (onOccupantTap == null) return child;
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => onOccupantTap!(text),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2),
                      child: child,
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReportActions extends StatelessWidget {
  final String title;
  final String Function() reportText;

  const _ReportActions({required this.title, required this.reportText});

  @override
  Widget build(BuildContext context) {
    return Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Report',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await Clipboard.setData(
                        ClipboardData(text: reportText()),
                      );
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Report clipboardకి copy అయింది'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.copy_all_outlined),
                    label: const Text('Copy'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      await ReportStorageService.save(
                        title: title,
                        body: reportText(),
                      );
                      if (!context.mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Report locally save అయింది'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.save_outlined),
                    label: const Text('Save'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: () async {
                  await SharePlus.instance.share(
                    ShareParams(
                      text: reportText(),
                      title: 'Annapurna Astro Vastu - $title',
                    ),
                  );
                },
                icon: const Icon(Icons.share_outlined),
                label: const Text('Share Report'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;

  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
    );
  }
}

Map<int, List<String>> _occupantsFromVarga(
  VargaChartData data, {
  AstroChartResult? includeDegreesFrom,
}) {
  final result = <int, List<String>>{
    for (var i = 0; i < 12; i++) i: <String>[],
  };

  for (final planet in data.planets) {
    var label = planet.shortName;
    if (includeDegreesFrom != null && data.definition.factor == 1) {
      final source =
          includeDegreesFrom.planets.firstWhere((p) => p.name == planet.name);
      label += ' ${source.degreesInSign.toStringAsFixed(1)}°';
    }
    if (planet.retrograde) label += 'R';
    result[planet.signIndex]!.add(label);
  }
  return result;
}

class _ErrorView extends StatelessWidget {
  final String message;

  const _ErrorView({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 46),
                const SizedBox(height: 12),
                const Text(
                  'Calculation ప్రారంభం కాలేదు',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text(message, textAlign: TextAlign.center),
                const SizedBox(height: 10),
                const Text(
                  'flutter pub get చేసిన తర్వాత Android buildలో sweph native library కూడా build అవుతుంది.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
