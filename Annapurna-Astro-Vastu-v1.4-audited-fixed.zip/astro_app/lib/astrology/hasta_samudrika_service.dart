class HastaSamudrikaRule {
  final String id;
  final String category;
  final String title;
  final String source;
  final String evidence;
  final String interpretation;
  final bool finalResultReady;

  const HastaSamudrikaRule({
    required this.id,
    required this.category,
    required this.title,
    required this.source,
    required this.evidence,
    required this.interpretation,
    this.finalResultReady = true,
  });
}

class HastaSamudrikaService {
  static const sourceBook = 'హస్త సాముద్రికం — user supplied PDF';

  /// Initial source registry.  This is deliberately modular: later source
  /// rules can be appended without changing the photo workflow.
  static const List<HastaSamudrikaRule> rules = [
    // Hand-shape classification — supplied PDF pp.31–37 (printed pp.46–52).
    HastaSamudrikaRule(
      id: 'HS-H01',
      category: 'చేతి ఆకృతి',
      title: 'ప్రారంభిక హస్తము / Elementary Hand',
      source: 'PDF p.31 • printed p.46',
      evidence: 'మందమైన/బలమైన చేతి ఆకృతి, చిన్న లేదా గట్టిగా కనిపించే వేళ్లు వంటి source shape లక్షణాలు.',
      interpretation: 'సాంప్రదాయ sourceలో ఈ వర్గాన్ని నేరుగా స్పందించే, సరళమైన జీవనశైలికి దగ్గరగా ఉండే చేతి రకంగా వర్గీకరిస్తుంది. వ్యక్తిత్వంపై ఖచ్చిత నిర్ణయం కాదు.',
    ),
    HastaSamudrikaRule(
      id: 'HS-H02',
      category: 'చేతి ఆకృతి',
      title: 'చతురస్ర హస్తము / Square Hand',
      source: 'PDF p.32 • printed p.47',
      evidence: 'చేతి మరియు వేళ్ల చివరలు చతురస్రాకారంగా/సమంగా కనిపించడం.',
      interpretation: 'Sourceలో నియమం, క్రమశిక్షణ, బాధ్యత, స్థిరమైన ఆలోచన వంటి లక్షణాలతో ఈ వర్గాన్ని అనుసంధానిస్తుంది; technical/administrative/legal రంగాల వంటి వృత్తులను ఉదాహరణగా చూపిస్తుంది.',
    ),
    HastaSamudrikaRule(
      id: 'HS-H03',
      category: 'చేతి ఆకృతి',
      title: 'తత్వజ్ఞాన హస్తము / Philosophic Hand',
      source: 'PDF p.33 • printed p.48',
      evidence: 'పొడవైన/సన్నని వేళ్లు, స్పష్టమైన కణుపులు, తాత్విక హస్తానికి sourceలో చూపిన ఆకృతి.',
      interpretation: 'సాంప్రదాయంగా ఆలోచన, పరిశీలన, తాత్విక/ఆధ్యాత్మిక ఆసక్తి వైపు మొగ్గు చూపే వర్గంగా source వివరిస్తుంది.',
    ),
    HastaSamudrikaRule(
      id: 'HS-H04',
      category: 'చేతి ఆకృతి',
      title: 'విస్తరించిన హస్తము / Spatulated Hand',
      source: 'PDF p.34 • printed p.49',
      evidence: 'వేళ్ల చివరలు విస్తరించి spatula ఆకృతిలో కనిపించడం.',
      interpretation: 'Source సంప్రదాయంలో చురుకుదనం, అన్వేషణ, పని ద్వారా ఫలితం సాధించే ధోరణితో ఈ వర్గాన్ని కలుపుతుంది.',
    ),
    HastaSamudrikaRule(
      id: 'HS-H05',
      category: 'చేతి ఆకృతి',
      title: 'కోణిక / కళా హస్తము / Conic–Artistic Hand',
      source: 'PDF p.35 • printed p.50',
      evidence: 'క్రమంగా సన్నబడే వేళ్లు, కోణిక చివరలు, sourceలో చూపిన artistic hand ఆకృతి.',
      interpretation: 'సాంప్రదాయంగా కళాత్మక అభిరుచి, సౌందర్య స్పృహ, భావోద్వేగ స్పందనలతో ఈ వర్గాన్ని source అనుసంధానిస్తుంది.',
    ),
    HastaSamudrikaRule(
      id: 'HS-H06',
      category: 'చేతి ఆకృతి',
      title: 'మొనదేలిన / Idealistic–Pointed Hand',
      source: 'PDF p.36 • printed p.51',
      evidence: 'పొడవైన సన్నని వేళ్లు, స్పష్టంగా మొనదేలిన fingertips.',
      interpretation: 'Source సంప్రదాయంలో ఆదర్శవాదం, ఊహాశక్తి, సున్నితమైన/ఆధ్యాత్మిక ఆసక్తులను సూచించే వర్గంగా చూపుతుంది.',
    ),
    HastaSamudrikaRule(
      id: 'HS-H07',
      category: 'చేతి ఆకృతి',
      title: 'మిశ్రమ హస్తము / Mixed Hand',
      source: 'PDF p.37 • printed p.52',
      evidence: 'ఒకే చేతిలో రెండు లేదా అంతకంటే ఎక్కువ hand-type లక్షణాలు కలిసివుండటం.',
      interpretation: 'ఒకే వర్గానికి పరిమితం కాని మిశ్రమ ధోరణులు/అనుకూలనాన్ని source వర్గీకరణగా చూపుతుంది.',
    ),

    // Line / mark visual vocabulary — supplied PDF pp.18–23 (printed pp.33–38).
    HastaSamudrikaRule(id: 'HS-L01', category: 'రేఖలు & గుర్తులు', title: 'పైకి వెళ్లే రేఖలు / Upward Lines', source: 'PDF p.18 • printed p.33', evidence: 'పైకి ఎగబాకే చిన్న/పొడవైన రేఖలు.', interpretation: 'ఈ source page ఆకారాన్ని గుర్తింపు కోసం నిర్వచిస్తుంది. ప్రత్యేక ఫలితం కోసం సంబంధిత తరువాతి ruleతో కలపాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L02', category: 'రేఖలు & గుర్తులు', title: 'క్రిందకు వెళ్లే రేఖలు / Downward Lines', source: 'PDF p.18 • printed p.33', evidence: 'క్రిందకు దిగే రేఖలు.', interpretation: 'Visual evidence entry మాత్రమే; సంబంధిత yoga/result ruleతో కలిపి నిర్ణయించాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L03', category: 'రేఖలు & గుర్తులు', title: 'Falling Lines', source: 'PDF p.18 • printed p.33', evidence: 'వాలుతూ/పడుతూ కనిపించే రేఖలు.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L04', category: 'రేఖలు & గుర్తులు', title: 'Wave Lines', source: 'PDF p.18 • printed p.33', evidence: 'అలల వంటి వంకర రేఖలు.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L05', category: 'రేఖలు & గుర్తులు', title: 'Forked Lines', source: 'PDF p.18 • printed p.33', evidence: 'రేఖ చివర రెండు/మూడు శాఖలుగా విడిపోవడం.', interpretation: 'Visual evidence entry మాత్రమే; branch-specific result తరువాతి source ruleతో నిర్ణయించాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L06', category: 'రేఖలు & గుర్తులు', title: 'Tassel Lines', source: 'PDF p.18 • printed p.33', evidence: 'ఒక చివర అనేక చిన్న శాఖలుగా విస్తరించడం.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L07', category: 'రేఖలు & గుర్తులు', title: 'Stair Lines', source: 'PDF p.19 • printed p.34', evidence: 'మెట్ల మాదిరిగా వరుస segments.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L08', category: 'రేఖలు & గుర్తులు', title: 'Up & Down Lines', source: 'PDF p.19 • printed p.34', evidence: 'ఎత్తు-పల్లం/zig movement కలిగిన line.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L09', category: 'రేఖలు & గుర్తులు', title: 'Strong / Thick Lines', source: 'PDF p.19 • printed p.34', evidence: 'గాఢంగా, మందంగా కనిపించే రేఖ.', interpretation: 'రేఖ బలం/దృఢత్వానికి photo evidenceగా నమోదు చేయాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L10', category: 'రేఖలు & గుర్తులు', title: 'Light / Thin Lines', source: 'PDF p.19 • printed p.34', evidence: 'సన్నగా, పలుచగా కనిపించే రేఖ.', interpretation: 'రేఖ బలం/దృఢత్వానికి photo evidenceగా నమోదు చేయాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L11', category: 'రేఖలు & గుర్తులు', title: 'Short / Small Lines', source: 'PDF p.19 • printed p.34', evidence: 'చిన్న segments.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L12', category: 'రేఖలు & గుర్తులు', title: 'Double / Sister / Helping Lines', source: 'PDF p.19 • printed p.34', evidence: 'ప్రధాన రేఖకు సమాంతరంగా మరో సహాయక రేఖ.', interpretation: 'Visual evidence entry; ఏ ప్రధాన రేఖకు తోడుగా ఉందో తరువాతి ruleలో అవసరం.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L13', category: 'రేఖలు & గుర్తులు', title: 'Straight Lines', source: 'PDF p.19 • printed p.34', evidence: 'నేరుగా వెళ్లే రేఖలు.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L14', category: 'రేఖలు & గుర్తులు', title: 'Cutting Lines', source: 'PDF p.19 • printed p.34', evidence: 'మరొక రేఖను కోస్తూ వెళ్లే చిన్న రేఖ.', interpretation: 'Visual evidence entry; ఏ రేఖను కోస్తుందో నమోదు చేయాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L15', category: 'రేఖలు & గుర్తులు', title: 'Parallel Lines', source: 'PDF p.19 • printed p.34', evidence: 'సమాంతరంగా నడిచే రేఖలు.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-L16', category: 'రేఖలు & గుర్తులు', title: 'Zig-Zag Lines', source: 'PDF p.19 • printed p.34', evidence: 'జిగ్-జాగ్/అస్తవ్యస్త దిశలో రేఖ.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M01', category: 'రేఖలు & గుర్తులు', title: 'Breaks / Broken Lines', source: 'PDF p.20 • printed p.35', evidence: 'రేఖ మధ్యలో విరామం/తెగిన భాగం.', interpretation: 'Break evidence; సంబంధిత ప్రధాన రేఖ ruleతో కలపాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M02', category: 'రేఖలు & గుర్తులు', title: 'Chained Lines', source: 'PDF p.20 • printed p.35', evidence: 'చైన్/గొలుసు మాదిరి చిన్న loops.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M03', category: 'రేఖలు & గుర్తులు', title: 'Islands', source: 'PDF p.20 • printed p.35', evidence: 'రేఖపై ద్వీపం/ఓవల్ వంటి మూసుకుపోయిన ఆకృతి.', interpretation: 'Island evidence; దాని స్థానం/ప్రధాన రేఖతో కలిపి rule నిర్ణయించాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M04', category: 'రేఖలు & గుర్తులు', title: 'Circles', source: 'PDF p.20 • printed p.35', evidence: 'వృత్త/చక్ర ఆకారం.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M05', category: 'రేఖలు & గుర్తులు', title: 'Triangles', source: 'PDF p.20 • printed p.35', evidence: 'త్రిభుజ గుర్తు.', interpretation: 'Visual evidence entry; mount/line location అవసరం.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M06', category: 'రేఖలు & గుర్తులు', title: 'Squares', source: 'PDF p.20 • printed p.35', evidence: 'చతురస్ర గుర్తు.', interpretation: 'Visual evidence entry; location-specific ruleతో కలపాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M07', category: 'రేఖలు & గుర్తులు', title: 'Grills', source: 'PDF p.20 • printed p.35', evidence: 'చిన్న grid/grill గుర్తులు.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M08', category: 'రేఖలు & గుర్తులు', title: 'Stars', source: 'PDF p.20 • printed p.35', evidence: 'స్టార్/నక్షత్ర గుర్తు.', interpretation: 'Visual evidence entry; mount/line location అవసరం.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M09', category: 'రేఖలు & గుర్తులు', title: 'Cross Marks', source: 'PDF p.21 • printed p.36', evidence: 'రెండు రేఖలు క్రాస్ కావడం.', interpretation: 'Visual evidence entry; location-specific result rule అవసరం.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M10', category: 'రేఖలు & గుర్తులు', title: 'Tripods', source: 'PDF p.21 • printed p.36', evidence: 'మూడు శాఖలు/త్రిశాఖ గుర్తు.', interpretation: 'Visual evidence entry మాత్రమే.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M11', category: 'రేఖలు & గుర్తులు', title: 'Moles', source: 'PDF p.21 • printed p.36', evidence: 'పుట్టుమచ్చ.', interpretation: 'స్థానం ముఖ్యమైన evidence; final interpretationకు location rule అవసరం.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M12', category: 'రేఖలు & గుర్తులు', title: 'Spots / Dots', source: 'PDF p.21 • printed p.36', evidence: 'చుక్క/spot గుర్తు.', interpretation: 'స్థానం ఆధారంగా తరువాతి ruleతో కలపాలి.', finalResultReady: false),
    HastaSamudrikaRule(id: 'HS-M13', category: 'రేఖలు & గుర్తులు', title: 'Angles', source: 'PDF p.21 • printed p.36', evidence: 'కోణ ఆకృతి.', interpretation: 'Angle evidence; exact location/degree అవసరం.', finalResultReady: false),

    // Thumb angle vocabulary — supplied PDF pp.63–64 (printed pp.78–79).
    HastaSamudrikaRule(id: 'HS-T01', category: 'బొటనవేలు', title: 'బొటనవేలు 90° దగ్గర విస్తరణ', source: 'PDF pp.63–64 • printed pp.78–79', evidence: 'బొటనవేలు index finger నుంచి దాదాపు 90° వద్ద విస్తరించడం.', interpretation: 'Sourceలో thumb-angle classificationగా ఉంది. పూర్తి వ్యక్తిగత ఫలితం ముందు మొత్తం చేతి ఆకృతి/ఇతర thumb లక్షణాలతో cross-check చేయాలి.'),
    HastaSamudrikaRule(id: 'HS-T02', category: 'బొటనవేలు', title: 'బొటనవేలు 60° దగ్గర విస్తరణ', source: 'PDF pp.63–64 • printed pp.78–79', evidence: 'బొటనవేలు దాదాపు 60° విస్తరణ.', interpretation: 'Source thumb-angle evidence. ఒంటరిగా final prediction కాదు.'),
    HastaSamudrikaRule(id: 'HS-T03', category: 'బొటనవేలు', title: 'బొటనవేలు 45° దగ్గర విస్తరణ', source: 'PDF pp.63–64 • printed pp.78–79', evidence: 'బొటనవేలు దాదాపు 45° విస్తరణ.', interpretation: 'Source thumb-angle evidence. ఇతర thumb/hand factorsతో కలిపి చూడాలి.'),
  ];

  static List<String> get categories {
    final out = <String>[];
    for (final rule in rules) {
      if (!out.contains(rule.category)) out.add(rule.category);
    }
    return out;
  }

  static HastaSamudrikaRule byId(String id) =>
      rules.firstWhere((rule) => rule.id == id);

  static List<HastaSamudrikaRule> selected(Iterable<String> ids) {
    final set = ids.toSet();
    return rules.where((r) => set.contains(r.id)).toList(growable: false);
  }
}
