import 'astro_models.dart';
import 'ashtakavarga_service.dart';

enum AvTimingTone { favorable, unfavorable, neutral, info, restricted }

class AvDirectionScore {
  final String direction;
  final int score;
  final List<int> signNumbers;

  const AvDirectionScore({
    required this.direction,
    required this.score,
    required this.signNumbers,
  });
}

class AvMonthSupport {
  final int monthNumber;
  final int bavBindus;
  final int savBindus;
  final AvTimingTone tone;

  const AvMonthSupport({
    required this.monthNumber,
    required this.bavBindus,
    required this.savBindus,
    required this.tone,
  });
}

class AvEventTimingIndicator {
  final String item;
  final String result;
  final String formula;
  final String ruleId;
  final AvTimingTone tone;

  const AvEventTimingIndicator({
    required this.item,
    required this.result,
    required this.formula,
    required this.ruleId,
    required this.tone,
  });
}

class AvPlanetTimingProfile {
  final String planet;
  final String planetTe;
  final List<AvDirectionScore> directions;
  final List<String> strongestDirections;
  final List<String> weakestDirections;
  final String eightDirection;
  final List<AvMonthSupport> monthSupport;
  final String kakshyaDuration;
  final List<AvEventTimingIndicator> eventTiming;

  const AvPlanetTimingProfile({
    required this.planet,
    required this.planetTe,
    required this.directions,
    required this.strongestDirections,
    required this.weakestDirections,
    required this.eightDirection,
    required this.monthSupport,
    required this.kakshyaDuration,
    required this.eventTiming,
  });
}

/// Source-driven timing/support layer for the supplied Ashtakavarga material.
///
/// Important:
/// - Month numbers are 1..12 solar-sign/month indices. Sign names are not
///   displayed because the app preference is to show numbers only.
/// - Nakshatra numbers are 1..27 indices.
/// - The source contains some parent/longevity/death timing arithmetic. Those
///   sensitive rules are deliberately not exposed as deterministic events.
/// - Direction rules follow R4.19/R4.20; month support follows the source's
///   BAV/SAV transit-strength method; safe event timing formulas are included
///   where the supplied rules give explicit arithmetic.
class AshtakavargaTimingService {
  static const Map<String, String> _planetTe = {
    'Sun': 'సూర్యుడు',
    'Moon': 'చంద్రుడు',
    'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు',
    'Jupiter': 'గురుడు',
    'Venus': 'శుక్రుడు',
    'Saturn': 'శని',
  };

  // R5.6: approximate time spent by the source in one Kakshya (3°45′).
  // The supplied source does not give a fixed Venus value in that list.
  static const Map<String, String> _kakshyaDurations = {
    'Sun': 'సుమారు 3¾ రోజులు / Kakshya',
    'Moon': 'సుమారు 6¾ గంటలు / Kakshya',
    'Mars': 'సుమారు 5 రోజులు / Kakshya',
    'Mercury': 'సుమారు 2½ రోజులు / Kakshya',
    'Jupiter': 'సుమారు 1½ నెలలు / Kakshya',
    'Venus': 'ఈ source జాబితాలో స్థిర Kakshya కాలం ఇవ్వలేదు',
    'Saturn': 'సుమారు 3¾ నెలలు / Kakshya',
  };

  // R4.19: four directional trines.
  static const Map<String, List<int>> _directionGroups = {
    'తూర్పు': [0, 4, 8],       // 1,5,9
    'దక్షిణం': [1, 5, 9],      // 2,6,10
    'పడమర': [2, 6, 10],        // 3,7,11
    'ఉత్తరం': [3, 7, 11],      // 4,8,12
  };

  static int _mod1(int value, int modulus) {
    final r = value % modulus;
    return r == 0 ? modulus : r;
  }

  static int _relativeSign(int planetSign, int house) =>
      (planetSign + house - 1) % 12;

  static int _relativeBav(
    AshtakavargaResult av,
    AstroChartResult chart,
    String planet,
    int house,
  ) {
    final position = chart.planets.firstWhere((p) => p.name == planet);
    return av.bhinna[planet]![_relativeSign(position.signIndex, house)];
  }

  static int _relativeShodhitaBav(
    AshtakavargaResult av,
    AstroChartResult chart,
    String planet,
    int house,
  ) {
    final position = chart.planets.firstWhere((p) => p.name == planet);
    return av.arithmetic.afterEkadhipatya[planet]![
      _relativeSign(position.signIndex, house)
    ];
  }

  static List<AvDirectionScore> _directionScores(List<int> bav) {
    final out = <AvDirectionScore>[];
    for (final entry in _directionGroups.entries) {
      final score = entry.value.fold<int>(0, (s, i) => s + bav[i]);
      out.add(AvDirectionScore(
        direction: entry.key,
        score: score,
        signNumbers: entry.value.map((i) => i + 1).toList(growable: false),
      ));
    }
    return List<AvDirectionScore>.unmodifiable(out);
  }

  static String _eightDirectionForSign(int signIndex) {
    // R4.20 source mapping; sign names intentionally omitted in UI.
    if (signIndex == 0 || signIndex == 1) return 'తూర్పు';
    if (signIndex == 2) return 'ఆగ్నేయం';
    if (signIndex == 3 || signIndex == 4) return 'దక్షిణం';
    if (signIndex == 5) return 'నైఋతి';
    if (signIndex == 6 || signIndex == 7) return 'పడమర';
    if (signIndex == 8) return 'వాయువ్యం';
    if (signIndex == 9 || signIndex == 10) return 'ఉత్తరం';
    return 'ఈశాన్యం';
  }

  static AvTimingTone _monthTone(int bav, int sav) {
    // Source BAV zones: 5+ supportive, 4 mixed, 1-3 weak; SAV is kept as
    // a separate support layer rather than being converted to a percentage.
    if (bav >= 5 && sav >= 28) return AvTimingTone.favorable;
    if (bav <= 3 || sav < 25) return AvTimingTone.unfavorable;
    return AvTimingTone.neutral;
  }

  static List<AvMonthSupport> _monthSupport(
    AshtakavargaResult av,
    String planet,
  ) {
    final items = List<AvMonthSupport>.generate(12, (i) {
      final bav = av.bhinna[planet]![i];
      final sav = av.sarva[i];
      return AvMonthSupport(
        monthNumber: i + 1,
        bavBindus: bav,
        savBindus: sav,
        tone: _monthTone(bav, sav),
      );
    });
    items.sort((a, b) {
      final byBav = b.bavBindus.compareTo(a.bavBindus);
      if (byBav != 0) return byBav;
      final bySav = b.savBindus.compareTo(a.savBindus);
      if (bySav != 0) return bySav;
      return a.monthNumber.compareTo(b.monthNumber);
    });
    return List<AvMonthSupport>.unmodifiable(items);
  }

  static List<AvEventTimingIndicator> _eventTiming({
    required AstroChartResult chart,
    required AshtakavargaResult av,
    required String planet,
  }) {
    final out = <AvEventTimingIndicator>[];
    final pinda = av.arithmetic.practicalPindas[planet]!.shodhyaPinda;

    // Every planet gets a non-deterministic transit support line based on its
    // own BAV and SAV. Exact calendar dates require the transit ephemeris date
    // layer; the arithmetic here identifies the source month/sign indices.
    final months = _monthSupport(av, planet);
    final top = months.take(3).map((m) =>
        '${m.monthNumber} (BAV ${m.bavBindus}, SAV ${m.savBindus})').join(', ');
    out.add(AvEventTimingIndicator(
      item: 'టాప్ 3 transit month/support సూచికలు',
      result: top,
      formula: 'గ్రహ స్వీయ BAV బిందువులు ముందుగా; tie అయితే అదే రాశి SAV బలం. ఇది AV-010/R4.11–R4.16 support ranking; percentage కాదు.',
      ruleId: 'AV-010 + R4.11–R4.16',
      tone: AvTimingTone.info,
    ));

    switch (planet) {
      case 'Mars':
        final b3 = _relativeBav(av, chart, 'Mars', 3);
        final product = pinda * b3;
        final sign = _mod1(product, 12);
        out.add(AvEventTimingIndicator(
          item: 'సోదర సంబంధ event / లాభ trigger',
          result: 'సూచిక రాశి/సౌర మాసం: $sign / 12. ఆ రాశిలో గురు గోచారం లేదా రాశ్యధిపతి దశ-అంతర్దశను source confirmationగా చూస్తుంది.',
          formula: 'కుజ Shodhya Pinda ($pinda) × కుజుని నుండి 3వ భావ BAV ($b3) = $product; ÷12 శేషం → $sign.',
          ruleId: 'R8.17–R8.18',
          tone: AvTimingTone.info,
        ));
        break;
      case 'Mercury':
        final b10 = _relativeBav(av, chart, 'Mercury', 10);
        final prod10 = pinda * b10;
        final n10 = _mod1(prod10, 27);
        out.add(AvEventTimingIndicator(
          item: 'వృత్తి / వ్యాపార Saturn-transit trigger',
          result: 'నక్షత్ర సూచిక: $n10 / 27. ఆ నక్షత్రంలో శని గోచారాన్ని source వృత్తి/వ్యాపార మార్పు లేదా ఒత్తిడి timing evidenceగా ఉపయోగిస్తుంది.',
          formula: 'బుధ Shodhya Pinda ($pinda) × బుధుని నుండి 10వ భావ BAV ($b10) = $prod10; ÷27 శేషం → $n10.',
          ruleId: 'R9.19',
          tone: AvTimingTone.info,
        ));

        final b2 = _relativeBav(av, chart, 'Mercury', 2);
        final prod2 = pinda * b2;
        final s2 = _mod1(prod2, 12);
        out.add(AvEventTimingIndicator(
          item: 'విద్య / వ్యాపార-ఆర్థిక వృద్ధి trigger',
          result: 'రాశి/సౌర మాస సూచిక: $s2 / 12. ఆ రాశ్యధిపతి దశ-అంతర్దశ + ఆ రాశిలో బుధ గోచారం sourceలో confirmation.',
          formula: 'బుధ Shodhya Pinda ($pinda) × బుధుని నుండి 2వ భావ BAV ($b2) = $prod2; ÷12 శేషం → $s2.',
          ruleId: 'R9.20',
          tone: AvTimingTone.favorable,
        ));

        final b4 = _relativeBav(av, chart, 'Mercury', 4);
        final prod4 = pinda * b4;
        final n4 = _mod1(prod4, 27);
        out.add(AvEventTimingIndicator(
          item: '4వ భావ సంబంధ multi-transit trigger',
          result: 'నక్షత్ర సూచిక: $n4 / 27. sourceలో శని + చంద్ర/గురు confirmation layerగా ఉపయోగిస్తుంది.',
          formula: 'బుధ Shodhya Pinda ($pinda) × బుధుని నుండి 4వ భావ BAV ($b4) = $prod4; ÷27 శేషం → $n4.',
          ruleId: 'R9.21',
          tone: AvTimingTone.info,
        ));
        break;
      case 'Jupiter':
        final b5 = _relativeBav(av, chart, 'Jupiter', 5);
        final prod5 = pinda * b5;
        final n5 = _mod1(prod5, 27);
        out.add(AvEventTimingIndicator(
          item: 'సంతాన event నక్షత్ర trigger',
          result: 'నక్షత్ర సూచిక: $n5 / 27. ఆ నక్షత్రంలో గురు గోచారం sourceలో సంతాన timing confirmationగా ఉపయోగించబడుతుంది.',
          formula: 'గురు Shodhya Pinda ($pinda) × గురుని నుండి 5వ భావ BAV ($b5) = $prod5; ÷27 శేషం → $n5.',
          ruleId: 'R10.18',
          tone: AvTimingTone.favorable,
        ));

        final shodhita5 = _relativeShodhitaBav(av, chart, 'Jupiter', 5);
        final prodMonth = pinda * shodhita5;
        final month = _mod1(prodMonth, 12);
        out.add(AvEventTimingIndicator(
          item: 'సంతాన సౌర మాస trigger',
          result: 'సౌర మాస సూచిక: $month / 12.',
          formula: 'గురు Shodhya Pinda ($pinda) × గురుని నుండి 5వ భావ Shodhita BAV ($shodhita5) = $prodMonth; ÷12 శేషం → $month.',
          ruleId: 'R10.20',
          tone: AvTimingTone.favorable,
        ));

        final n7 = _mod1(pinda * 7, 27);
        final s4 = _mod1(pinda * 4, 12);
        final s9 = _mod1(pinda * 9, 12);
        out.add(AvEventTimingIndicator(
          item: 'సంతాన అదనపు confirmation సూచికలు',
          result: 'గురు గోచార నక్షత్ర సూచిక $n7/27; సూర్య గోచార రాశి/మాస సూచిక $s4/12; 5వ భావాధిపతి support సూచిక $s9/12.',
          formula: 'Shodhya Pinda ×7 ÷27; ×4 ÷12; ×9 ÷12.',
          ruleId: 'R10.19',
          tone: AvTimingTone.info,
        ));
        break;
      case 'Venus':
        final b7 = _relativeBav(av, chart, 'Venus', 7);
        final product = pinda * b7;
        final nak = _mod1(product, 27);
        final sign = _mod1(product, 12);
        out.add(AvEventTimingIndicator(
          item: 'వివాహ timing trigger',
          result: 'గురు గోచార నక్షత్ర సూచిక: $nak / 27; రాశి/సౌర మాస సూచిక: $sign / 12. sourceలో ఆ రాశ్యధిపతి దశ-అంతర్దశను కూడా confirmationగా చూస్తుంది.',
          formula: 'శుక్ర Shodhya Pinda ($pinda) × శుక్రుని నుండి 7వ భావ BAV ($b7) = $product; ÷27 → $nak; ÷12 → $sign.',
          ruleId: 'R11.21',
          tone: AvTimingTone.favorable,
        ));
        break;
      case 'Sun':
        out.add(const AvEventTimingIndicator(
          item: 'Sun source timing scope',
          result: 'సూర్యుడికి దిక్కు, సౌర మాస support, Kakshya కాలం పూర్తి చూపిస్తాం. Parent/longevityకి సంబంధించిన sensitive deterministic timing rulesను event predictionగా చూపించము.',
          formula: 'Safe layer: R4.19/R4.20 + R5.6 + AV-010. Sensitive R6.20–R6.24 user-facing deterministic output నుంచి వేరు.',
          ruleId: 'R4.19–R5.6 / AV-010',
          tone: AvTimingTone.restricted,
        ));
        break;
      case 'Moon':
        out.add(const AvEventTimingIndicator(
          item: 'Moon source timing scope',
          result: 'చంద్రుడికి దిక్కు, రాశి/మాస support, Kakshya కాలం చూపిస్తాం. Parent/longevity sensitive timing arithmeticను deterministic eventగా చూపించము.',
          formula: 'Safe layer: R4.19/R4.20 + R5.6 + AV-010; sensitive R7.22–R7.23 excluded from deterministic output.',
          ruleId: 'R4.19–R5.6 / AV-010',
          tone: AvTimingTone.restricted,
        ));
        break;
      case 'Saturn':
        out.add(const AvEventTimingIndicator(
          item: 'Saturn source timing scope',
          result: 'శనికి దిక్కు, రాశి/మాస support, Kakshya కాలం చూపిస్తాం. Sourceలోని longevity/death arithmeticను deterministic event timingగా చూపించము.',
          formula: 'Safe layer: R4.19/R4.20 + R5.6 + AV-010; sensitive R12.19–R12.21 excluded from deterministic output.',
          ruleId: 'R4.19–R5.6 / AV-010',
          tone: AvTimingTone.restricted,
        ));
        break;
    }

    return List<AvEventTimingIndicator>.unmodifiable(out);
  }

  static List<AvPlanetTimingProfile> evaluate({
    required AstroChartResult chart,
    required AshtakavargaResult av,
  }) {
    return AshtakavargaService.planetOrder.map((planet) {
      final bav = av.bhinna[planet]!;
      final directions = _directionScores(bav);
      final high = directions.map((d) => d.score).reduce((a, b) => a > b ? a : b);
      final low = directions.map((d) => d.score).reduce((a, b) => a < b ? a : b);
      final strongest = directions
          .where((d) => d.score == high)
          .map((d) => d.direction)
          .toList(growable: false);
      final weakest = directions
          .where((d) => d.score == low)
          .map((d) => d.direction)
          .toList(growable: false);

      final months = _monthSupport(av, planet);
      final strongestSignIndex = months.first.monthNumber - 1;

      return AvPlanetTimingProfile(
        planet: planet,
        planetTe: _planetTe[planet]!,
        directions: directions,
        strongestDirections: strongest,
        weakestDirections: weakest,
        eightDirection: _eightDirectionForSign(strongestSignIndex),
        monthSupport: months,
        kakshyaDuration: _kakshyaDurations[planet]!,
        eventTiming: _eventTiming(chart: chart, av: av, planet: planet),
      );
    }).toList(growable: false);
  }
}
