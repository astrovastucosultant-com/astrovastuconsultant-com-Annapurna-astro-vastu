import '../models/birth_data.dart';
import 'ashtakavarga_service.dart';
import 'ashtakavarga_timing_service.dart';
import 'astro_calculation_service.dart';

class AvTransitWindow {
  final String planet;
  final int signNumber;
  final DateTime startLocal;
  final DateTime endLocal;
  final int bavBindus;
  final int savBindus;
  final int entryKakshya;
  final bool retrogradeAtEntry;
  final AvTimingTone tone;

  const AvTransitWindow({
    required this.planet,
    required this.signNumber,
    required this.startLocal,
    required this.endLocal,
    required this.bavBindus,
    required this.savBindus,
    required this.entryKakshya,
    required this.retrogradeAtEntry,
    required this.tone,
  });
}

/// Converts the existing BAV/SAV support indices into real calendar transit
/// windows by using Swiss Ephemeris. The source rules rank signs/months; this
/// service only maps those source indices to actual ingress/egress dates.
/// It does not invent a new predictive rule.
class AshtakavargaTransitWindowService {
  static Duration _scanStep(String planet) => switch (planet) {
        'Moon' => const Duration(hours: 6),
        'Mercury' || 'Venus' || 'Sun' => const Duration(hours: 12),
        'Mars' => const Duration(hours: 18),
        'Jupiter' => const Duration(days: 2),
        'Saturn' => const Duration(days: 3),
        _ => const Duration(hours: 12),
      };

  static AvTimingTone _tone(int bav, int sav) {
    if (bav >= 5 && sav >= 28) return AvTimingTone.favorable;
    if (bav <= 3 || sav < 25) return AvTimingTone.unfavorable;
    return AvTimingTone.neutral;
  }

  static DateTime _localToUtc(BirthData birthData, DateTime local) {
    final localAsUtc = DateTime.utc(
      local.year,
      local.month,
      local.day,
      local.hour,
      local.minute,
      local.second,
      local.millisecond,
    );
    final offsetMinutes = (birthData.timezoneOffsetHours * 60).round();
    return localAsUtc.subtract(Duration(minutes: offsetMinutes));
  }

  static Future<({int sign, int kakshya, bool retrograde})> _stateAt({
    required BirthData birthData,
    required String planet,
    required DateTime local,
  }) async {
    final pos = await AstroCalculationService.calculatePlanetAtUtc(
      utc: _localToUtc(birthData, local),
      planetName: planet,
      ayanamsa: birthData.ayanamsa,
    );
    return (
      sign: pos.signIndex,
      kakshya: AshtakavargaService.kakshyaIndex(pos.longitude),
      retrograde: pos.retrograde,
    );
  }

  static Future<DateTime> _refineBoundary({
    required BirthData birthData,
    required String planet,
    required DateTime left,
    required DateTime right,
    required int oldSign,
  }) async {
    var lo = left;
    var hi = right;
    // ~20 iterations on a 3-day interval reaches well below one second.
    for (var i = 0; i < 22; i++) {
      final span = hi.difference(lo);
      if (span.inMilliseconds <= 1000) break;
      final mid = lo.add(
        Duration(microseconds: span.inMicroseconds ~/ 2),
      );
      final state = await _stateAt(
        birthData: birthData,
        planet: planet,
        local: mid,
      );
      if (state.sign == oldSign) {
        lo = mid;
      } else {
        hi = mid;
      }
    }
    return hi;
  }

  static List<int> _topSignIndices(
    AshtakavargaResult av,
    String planet, {
    int count = 3,
  }) {
    final indices = List<int>.generate(12, (i) => i);
    indices.sort((a, b) {
      final bavCompare = av.bhinna[planet]![b].compareTo(av.bhinna[planet]![a]);
      if (bavCompare != 0) return bavCompare;
      final savCompare = av.sarva[b].compareTo(av.sarva[a]);
      if (savCompare != 0) return savCompare;
      return a.compareTo(b);
    });
    return indices.take(count).toList(growable: false);
  }

  static Future<List<AvTransitWindow>> supportedWindowsForYear({
    required BirthData birthData,
    required AshtakavargaResult av,
    required String planet,
    required int year,
    int topSignCount = 3,
  }) async {
    final targetSigns = _topSignIndices(
      av,
      planet,
      count: topSignCount,
    ).toSet();

    final yearStart = DateTime(year, 1, 1);
    final yearEnd = DateTime(year + 1, 1, 1);
    final step = _scanStep(planet);

    var cursor = yearStart;
    var state = await _stateAt(
      birthData: birthData,
      planet: planet,
      local: cursor,
    );
    DateTime? activeStart = targetSigns.contains(state.sign) ? cursor : null;
    var activeSign = state.sign;
    var activeEntryKakshya = state.kakshya;
    var activeRetrograde = state.retrograde;

    final windows = <AvTransitWindow>[];

    while (cursor.isBefore(yearEnd)) {
      var next = cursor.add(step);
      if (next.isAfter(yearEnd)) next = yearEnd;
      final nextState = await _stateAt(
        birthData: birthData,
        planet: planet,
        local: next,
      );

      if (nextState.sign != state.sign) {
        final boundary = await _refineBoundary(
          birthData: birthData,
          planet: planet,
          left: cursor,
          right: next,
          oldSign: state.sign,
        );

        if (activeStart != null) {
          final bav = av.bhinna[planet]![activeSign];
          final sav = av.sarva[activeSign];
          windows.add(
            AvTransitWindow(
              planet: planet,
              signNumber: activeSign + 1,
              startLocal: activeStart,
              endLocal: boundary,
              bavBindus: bav,
              savBindus: sav,
              entryKakshya: activeEntryKakshya,
              retrogradeAtEntry: activeRetrograde,
              tone: _tone(bav, sav),
            ),
          );
          activeStart = null;
        }

        if (targetSigns.contains(nextState.sign)) {
          final entryState = await _stateAt(
            birthData: birthData,
            planet: planet,
            local: boundary.add(const Duration(seconds: 2)),
          );
          activeStart = boundary;
          activeSign = nextState.sign;
          activeEntryKakshya = entryState.kakshya;
          activeRetrograde = entryState.retrograde;
        }
      }

      cursor = next;
      state = nextState;
    }

    if (activeStart != null && activeStart.isBefore(yearEnd)) {
      final bav = av.bhinna[planet]![activeSign];
      final sav = av.sarva[activeSign];
      windows.add(
        AvTransitWindow(
          planet: planet,
          signNumber: activeSign + 1,
          startLocal: activeStart,
          endLocal: yearEnd,
          bavBindus: bav,
          savBindus: sav,
          entryKakshya: activeEntryKakshya,
          retrogradeAtEntry: activeRetrograde,
          tone: _tone(bav, sav),
        ),
      );
    }

    windows.sort((a, b) => a.startLocal.compareTo(b.startLocal));
    return List<AvTransitWindow>.unmodifiable(windows);
  }
}
