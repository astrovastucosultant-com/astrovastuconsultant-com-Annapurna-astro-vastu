import '../models/birth_data.dart';
import 'astro_models.dart';
import 'd10_career_service.dart';

class D10ValidationEvent {
  final String id;
  final String title;
  final DateTime start;
  final DateTime end;
  final List<String> expectedWindowKeys;
  final int nearToleranceDays;
  final String actualNote;

  const D10ValidationEvent({
    required this.id,
    required this.title,
    required this.start,
    required this.end,
    required this.expectedWindowKeys,
    required this.nearToleranceDays,
    required this.actualNote,
  });
}

enum D10ValidationStatus { matched, near, missed }

class D10ValidationMatch {
  final D10ValidationEvent event;
  final D10CareerWindow? window;
  final D10ValidationStatus status;
  final int gapDays;

  const D10ValidationMatch({
    required this.event,
    required this.window,
    required this.status,
    required this.gapDays,
  });
}

class D10ValidationReport {
  final List<D10ValidationMatch> matches;

  const D10ValidationReport(this.matches);

  int get matched =>
      matches.where((x) => x.status == D10ValidationStatus.matched).length;
  int get near => matches.where((x) => x.status == D10ValidationStatus.near).length;
  int get missed => matches.where((x) => x.status == D10ValidationStatus.missed).length;

  int get scorePercent {
    if (matches.isEmpty) return 0;
    // Validation display score: exact-overlap = 1, near-window = 0.5.
    // This is an app audit score, not a classical astrology probability.
    final points = matched + near * 0.5;
    return ((points / matches.length) * 100).round();
  }
}

/// Real-life D10 benchmark supplied by the app owner.
///
/// It is deliberately isolated from the predictive rules: these events are
/// never used to manufacture or alter D10 rules. They are only compared with
/// the already-calculated source-based windows, so the screen can show where
/// the current engine agrees, is close, or misses.
class D10ValidationService {
  static BirthData get example1BirthData => BirthData(
        name: 'Mallikarjuna',
        localDateTime: DateTime(1981, 12, 15, 15, 50, 0),
        place: 'PIN 522414, India',
        latitude: 16.593221,
        longitude: 79.736383,
        timezoneOffsetHours: 5.5,
        ayanamsa: AyanamsaType.lahiri,
      );

  static bool isExample1(BirthData data) {
    final b = example1BirthData;
    return data.localDateTime.year == b.localDateTime.year &&
        data.localDateTime.month == b.localDateTime.month &&
        data.localDateTime.day == b.localDateTime.day &&
        data.localDateTime.hour == b.localDateTime.hour &&
        data.localDateTime.minute == b.localDateTime.minute &&
        (data.latitude - b.latitude).abs() < 0.0005 &&
        (data.longitude - b.longitude).abs() < 0.0005 &&
        (data.timezoneOffsetHours - b.timezoneOffsetHours).abs() < 0.01 &&
        data.ayanamsa == AyanamsaType.lahiri;
  }

  static DateTime _startOfYear(int year) => DateTime(year, 1, 1);
  static DateTime _endOfYear(int year) => DateTime(year, 12, 31, 23, 59, 59);
  static DateTime _startOfMonth(int year, int month) => DateTime(year, month, 1);
  static DateTime _endOfMonth(int year, int month) =>
      DateTime(year, month + 1, 1).subtract(const Duration(seconds: 1));

  static List<D10ValidationEvent> get example1Events => <D10ValidationEvent>[
        D10ValidationEvent(
          id: 'VAL-2004-JOB',
          title: 'NBFC Job Join',
          start: _startOfYear(2004),
          end: _endOfYear(2004),
          expectedWindowKeys: const ['career_start', 'rise'],
          nearToleranceDays: 240,
          actualNote: '2004లో NBFC job/service ప్రారంభం.',
        ),
        D10ValidationEvent(
          id: 'VAL-2005-PROMO-TR',
          title: 'Promotion + Nearby Transfer',
          start: _startOfYear(2005),
          end: _endOfYear(2005),
          expectedWindowKeys: const ['promotion', 'transfer', 'rise'],
          nearToleranceDays: 180,
          actualNote: '2005 promotion + nearest transfer.',
        ),
        D10ValidationEvent(
          id: 'VAL-2006-DOWN-TR',
          title: 'Demotion + Nearby Transfer',
          start: _startOfYear(2006),
          end: _endOfYear(2006),
          expectedWindowKeys: const ['job_loss', 'transfer', 'career_change'],
          nearToleranceDays: 180,
          actualNote: '2006 demotion + nearest transfer.',
        ),
        D10ValidationEvent(
          id: 'VAL-2007-PROMO-TR',
          title: 'Promotion + Nearby Transfer',
          start: _startOfYear(2007),
          end: _endOfYear(2007),
          expectedWindowKeys: const ['promotion', 'transfer', 'rise'],
          nearToleranceDays: 180,
          actualNote: '2007 promotion + nearest transfer.',
        ),
        D10ValidationEvent(
          id: 'VAL-2008-PROMO-LONGTR',
          title: 'Promotion + Long Transfer',
          start: _startOfYear(2008),
          end: _endOfYear(2008),
          expectedWindowKeys: const ['promotion', 'transfer', 'rise'],
          nearToleranceDays: 180,
          actualNote: '2008 promotion + long-distance transfer.',
        ),
        D10ValidationEvent(
          id: 'VAL-2010-TR',
          title: 'Nearby Transfer',
          start: _startOfYear(2010),
          end: _endOfYear(2010),
          expectedWindowKeys: const ['transfer', 'career_change'],
          nearToleranceDays: 180,
          actualNote: '2010 nearest transfer.',
        ),
        D10ValidationEvent(
          id: 'VAL-2011-RESIGN',
          title: 'Resignation / Job Exit',
          start: _startOfYear(2011),
          end: _endOfYear(2011),
          expectedWindowKeys: const ['job_loss', 'career_change', 'transfer'],
          nearToleranceDays: 240,
          actualNote: '2011 NBFC resignation.',
        ),
        D10ValidationEvent(
          id: 'VAL-2012-APR-PARTNER',
          title: '7-member Partnership Business Start',
          start: _startOfMonth(2012, 4),
          end: _endOfMonth(2012, 4),
          expectedWindowKeys: const ['career_change', 'rise'],
          nearToleranceDays: 180,
          actualNote: 'April 2012 partnership business ప్రారంభం.',
        ),
        D10ValidationEvent(
          id: 'VAL-2012-SEP-COLLAPSE',
          title: 'Partnership Collapse',
          start: _startOfMonth(2012, 9),
          end: _endOfMonth(2012, 9),
          expectedWindowKeys: const ['job_loss', 'career_change'],
          nearToleranceDays: 150,
          actualNote: 'September 2012 seven-member partnership collapse.',
        ),
        D10ValidationEvent(
          id: 'VAL-2012-DEC-GEMS',
          title: 'Gems Business Start',
          start: _startOfMonth(2012, 12),
          end: _endOfMonth(2012, 12),
          expectedWindowKeys: const ['career_change', 'rise'],
          nearToleranceDays: 150,
          actualNote: 'December 2012 one-partner gems business ప్రారంభం.',
        ),
        D10ValidationEvent(
          id: 'VAL-2013-DEC-CLOSE',
          title: 'Gems Business Close',
          start: _startOfMonth(2013, 12),
          end: _endOfMonth(2013, 12),
          expectedWindowKeys: const ['job_loss', 'career_change'],
          nearToleranceDays: 180,
          actualNote: 'December 2013 business close.',
        ),
        D10ValidationEvent(
          id: 'VAL-2014-APR-CONSULT',
          title: 'Astro–Vastu Consultancy Start',
          start: _startOfMonth(2014, 4),
          end: _endOfMonth(2014, 4),
          expectedWindowKeys: const ['career_change', 'rise'],
          nearToleranceDays: 180,
          actualNote: 'April 2014 నుంచి astrology/vastu consultancy running.',
        ),
      ];

  static D10ValidationReport validate({
    required AstroChartResult chart,
    required BirthData birthData,
  }) {
    final windows = D10CareerService.timingWindows(
      chart: chart,
      birthDateTime: birthData.localDateTime,
    );
    final matches = example1Events.map((event) {
      final candidates = windows
          .where((w) => event.expectedWindowKeys.contains(w.eventKey))
          .toList(growable: false);
      D10CareerWindow? best;
      var bestGap = 1 << 30;
      var bestOverlap = false;
      var bestScore = -1;
      for (final w in candidates) {
        final overlap = !w.end.isBefore(event.start) && !w.start.isAfter(event.end);
        final gap = overlap
            ? 0
            : w.end.isBefore(event.start)
                ? event.start.difference(w.end).inDays.abs()
                : w.start.difference(event.end).inDays.abs();
        if (best == null ||
            (overlap && !bestOverlap) ||
            (overlap == bestOverlap && gap < bestGap) ||
            (overlap == bestOverlap && gap == bestGap && w.score > bestScore)) {
          best = w;
          bestGap = gap;
          bestOverlap = overlap;
          bestScore = w.score;
        }
      }
      if (best == null) {
        return D10ValidationMatch(
          event: event,
          window: null,
          status: D10ValidationStatus.missed,
          gapDays: -1,
        );
      }
      final status = bestOverlap
          ? D10ValidationStatus.matched
          : bestGap <= event.nearToleranceDays
              ? D10ValidationStatus.near
              : D10ValidationStatus.missed;
      return D10ValidationMatch(
        event: event,
        window: best,
        status: status,
        gapDays: bestGap,
      );
    }).toList(growable: false);
    return D10ValidationReport(matches);
  }
}
