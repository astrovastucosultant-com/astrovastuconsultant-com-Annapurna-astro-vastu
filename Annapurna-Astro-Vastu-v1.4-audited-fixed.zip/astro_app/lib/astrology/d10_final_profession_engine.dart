import 'astro_models.dart';
import 'd10_career_service.dart';
import 'varga_service.dart';
import 'vedic_calculation_service.dart';

class D10ProfessionFamily {
  final String name;
  final Set<String> planets;
  final Set<String> compatibleNatures;

  const D10ProfessionFamily({
    required this.name,
    required this.planets,
    required this.compatibleNatures,
  });
}

class D10NakshatraProfessionProfile {
  final String nameTe;
  final String lord;
  final Set<String> professionFamilies;
  final String evidenceLevel;

  const D10NakshatraProfessionProfile({
    required this.nameTe,
    required this.lord,
    required this.professionFamilies,
    required this.evidenceLevel,
  });
}

class D10ProfessionCandidate {
  final String profession;
  final int evidenceMatchPercent;
  final List<String> matchedEvidence;
  final int availableEvidenceBlocks;
  final String natureCompatibility;
  final bool devataSupport;

  const D10ProfessionCandidate({
    required this.profession,
    required this.evidenceMatchPercent,
    required this.matchedEvidence,
    required this.availableEvidenceBlocks,
    required this.natureCompatibility,
    required this.devataSupport,
  });
}

class D10FinalProfessionResult {
  final String tenthLord;
  final int tenthLordSignIndex;
  final String tenthLordSignName;
  final String professionNature;
  final double d10TenthLordLongitude;
  final int nakshatraIndex;
  final String nakshatraName;
  final String nakshatraLord;
  final List<String> conjunctions;
  final D10DevataProfile amshaDevata;
  final List<D10ProfessionCandidate> candidates;

  const D10FinalProfessionResult({
    required this.tenthLord,
    required this.tenthLordSignIndex,
    required this.tenthLordSignName,
    required this.professionNature,
    required this.d10TenthLordLongitude,
    required this.nakshatraIndex,
    required this.nakshatraName,
    required this.nakshatraLord,
    required this.conjunctions,
    required this.amshaDevata,
    required this.candidates,
  });
}

class D10ShayanadiResult {
  final int stateNumber;
  final String state;
  final int? subStateRemainder;
  final String? subState;
  final String expression;
  final String audit;

  const D10ShayanadiResult({
    required this.stateNumber,
    required this.state,
    required this.subStateRemainder,
    required this.subState,
    required this.expression,
    required this.audit,
  });
}

/// Final user-approved D10 profession architecture.
///
/// Profession selection:
/// 10L planet professions + 10L D10-nakshatra professions + 10L D10-sign
/// professions + conjunction-planet professions -> family merge -> independent
/// evidence coverage %.  Sign nature is a FILTER/MODE, not an extra percentage
/// block.  Amsha Devata is a modifier and never creates a profession by itself.
class D10FinalProfessionEngine {
  static const signNamesTe = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  // User-locked classification. Do not substitute a different classification.
  static const technicalSigns = <int>{0, 7, 9, 10};
  static const semiTechnicalSigns = <int>{2, 4, 5};
  static const nonTechnicalSigns = <int>{1, 3, 6, 8, 11};

  static String signNature(int signIndex) {
    if (technicalSigns.contains(signIndex)) return 'Technical';
    if (semiTechnicalSigns.contains(signIndex)) return 'Semi-Technical';
    return 'Non-Technical';
  }

  static const professionFamilies = <D10ProfessionFamily>[
    D10ProfessionFamily(name: 'Government / Administration', planets: {'Sun', 'Mercury', 'Saturn'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Management / High Position', planets: {'Sun', 'Jupiter', 'Saturn'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Banking / Finance', planets: {'Jupiter', 'Mercury', 'Venus'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Accounting / Audit / Tax', planets: {'Mercury', 'Jupiter', 'Saturn'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Teaching / Education', planets: {'Jupiter', 'Mercury', 'Venus'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Law / Judiciary / Compliance', planets: {'Jupiter', 'Mercury', 'Saturn', 'Sun'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Engineering / Technical', planets: {'Mars', 'Saturn', 'Rahu', 'Ketu'}, compatibleNatures: {'Technical'}),
    D10ProfessionFamily(name: 'IT / Software / Data', planets: {'Mercury', 'Rahu', 'Ketu', 'Saturn'}, compatibleNatures: {'Technical', 'Semi-Technical'}),
    D10ProfessionFamily(name: 'Electronics / Communication Technology', planets: {'Mercury', 'Mars', 'Rahu', 'Ketu'}, compatibleNatures: {'Technical', 'Semi-Technical'}),
    D10ProfessionFamily(name: 'Architecture / Design', planets: {'Mars', 'Mercury', 'Venus'}, compatibleNatures: {'Technical', 'Semi-Technical'}),
    D10ProfessionFamily(name: 'Medicine / Healthcare', planets: {'Sun', 'Mars', 'Jupiter', 'Moon', 'Mercury', 'Ketu'}, compatibleNatures: {'Technical', 'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Research / R&D / Investigation', planets: {'Ketu', 'Rahu', 'Mercury', 'Mars', 'Jupiter', 'Saturn'}, compatibleNatures: {'Technical', 'Semi-Technical'}),
    D10ProfessionFamily(name: 'Defence / Police / Security', planets: {'Mars', 'Sun', 'Saturn', 'Rahu', 'Ketu'}, compatibleNatures: {'Technical'}),
    D10ProfessionFamily(name: 'Journalism / Writing / Media', planets: {'Mercury', 'Moon', 'Venus', 'Jupiter'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Communication / Languages', planets: {'Mercury', 'Moon', 'Jupiter'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Travel / Tourism / Logistics', planets: {'Mercury', 'Moon', 'Rahu', 'Venus'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Hospitality / Food / Nutrition', planets: {'Moon', 'Venus', 'Jupiter'}, compatibleNatures: {'Non-Technical'}),
    D10ProfessionFamily(name: 'Music / Arts / Performance', planets: {'Moon', 'Venus', 'Mercury'}, compatibleNatures: {'Non-Technical', 'Semi-Technical'}),
    D10ProfessionFamily(name: 'Fashion / Beauty / Creative Design', planets: {'Venus', 'Moon', 'Mercury'}, compatibleNatures: {'Non-Technical', 'Semi-Technical'}),
    D10ProfessionFamily(name: 'Manufacturing / Industry / Skilled Technical Work', planets: {'Saturn', 'Mars', 'Rahu'}, compatibleNatures: {'Technical'}),
    D10ProfessionFamily(name: 'Aviation / Transport', planets: {'Rahu', 'Mars', 'Mercury'}, compatibleNatures: {'Technical', 'Semi-Technical'}),
    D10ProfessionFamily(name: 'Import / Export / Foreign Relations', planets: {'Rahu', 'Moon', 'Mercury', 'Sun'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Agriculture / Environment / Natural Resources', planets: {'Saturn', 'Moon', 'Jupiter', 'Venus'}, compatibleNatures: {'Non-Technical', 'Technical'}),
    D10ProfessionFamily(name: 'Commercial / Business / Entrepreneurship', planets: {'Mercury', 'Venus', 'Rahu', 'Sun', 'Mars'}, compatibleNatures: {'Technical', 'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Consulting / Advisory', planets: {'Jupiter', 'Mercury', 'Sun'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
    D10ProfessionFamily(name: 'Social / Community Service', planets: {'Jupiter', 'Moon', 'Saturn', 'Venus'}, compatibleNatures: {'Non-Technical'}),
    D10ProfessionFamily(name: 'Occult / Astrology / Traditional Studies', planets: {'Jupiter', 'Ketu', 'Mercury'}, compatibleNatures: {'Semi-Technical', 'Non-Technical'}),
  ];

  // Broad sign-profession support used only in the user's final formula.
  // The nature classification is kept separate, so the sign is not counted twice.
  static const signProfessionFamilies = <int, Set<String>>{
    0: {'Engineering / Technical', 'Defence / Police / Security', 'Medicine / Healthcare', 'Manufacturing / Industry / Skilled Technical Work'},
    1: {'Banking / Finance', 'Hospitality / Food / Nutrition', 'Music / Arts / Performance', 'Fashion / Beauty / Creative Design', 'Commercial / Business / Entrepreneurship'},
    2: {'IT / Software / Data', 'Communication / Languages', 'Journalism / Writing / Media', 'Commercial / Business / Entrepreneurship', 'Accounting / Audit / Tax'},
    3: {'Medicine / Healthcare', 'Hospitality / Food / Nutrition', 'Teaching / Education', 'Social / Community Service', 'Travel / Tourism / Logistics'},
    4: {'Government / Administration', 'Management / High Position', 'Teaching / Education', 'Journalism / Writing / Media', 'Commercial / Business / Entrepreneurship'},
    5: {'Accounting / Audit / Tax', 'Medicine / Healthcare', 'Research / R&D / Investigation', 'IT / Software / Data', 'Consulting / Advisory'},
    6: {'Law / Judiciary / Compliance', 'Fashion / Beauty / Creative Design', 'Music / Arts / Performance', 'Commercial / Business / Entrepreneurship', 'Consulting / Advisory'},
    7: {'Engineering / Technical', 'Research / R&D / Investigation', 'Medicine / Healthcare', 'Defence / Police / Security', 'Occult / Astrology / Traditional Studies'},
    8: {'Teaching / Education', 'Law / Judiciary / Compliance', 'Consulting / Advisory', 'Travel / Tourism / Logistics', 'Occult / Astrology / Traditional Studies'},
    9: {'Engineering / Technical', 'Government / Administration', 'Manufacturing / Industry / Skilled Technical Work', 'Accounting / Audit / Tax', 'Management / High Position'},
    10: {'IT / Software / Data', 'Engineering / Technical', 'Research / R&D / Investigation', 'Electronics / Communication Technology', 'Social / Community Service'},
    11: {'Medicine / Healthcare', 'Music / Arts / Performance', 'Social / Community Service', 'Travel / Tourism / Logistics', 'Occult / Astrology / Traditional Studies'},
  };

  // 27 nakshatra profession tags extracted/source-derived from the uploaded
  // Dr. Arjun Pai handbook. These are supporting evidence, not stand-alone
  // final profession verdicts.
  static const nakshatraProfiles = <D10NakshatraProfessionProfile>[
    D10NakshatraProfessionProfile(nameTe: 'అశ్విని', lord: 'Ketu', professionFamilies: {'Medicine / Healthcare', 'Management / High Position'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'భరణి', lord: 'Venus', professionFamilies: {'Law / Judiciary / Compliance', 'Government / Administration', 'Management / High Position'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'కృత్తిక', lord: 'Sun', professionFamilies: {'Defence / Police / Security', 'Government / Administration', 'Management / High Position', 'Research / R&D / Investigation'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'రోహిణి', lord: 'Moon', professionFamilies: {'Music / Arts / Performance', 'Fashion / Beauty / Creative Design', 'Journalism / Writing / Media', 'Architecture / Design'}, evidenceLevel: 'Direct'),
    D10NakshatraProfessionProfile(nameTe: 'మృగశిర', lord: 'Mars', professionFamilies: {'Research / R&D / Investigation', 'Consulting / Advisory', 'Journalism / Writing / Media'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'ఆర్ద్ర', lord: 'Rahu', professionFamilies: {'Research / R&D / Investigation', 'IT / Software / Data', 'Electronics / Communication Technology'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'పునర్వసు', lord: 'Jupiter', professionFamilies: {'Medicine / Healthcare', 'Hospitality / Food / Nutrition', 'Travel / Tourism / Logistics', 'Consulting / Advisory'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'పుష్యమి', lord: 'Saturn', professionFamilies: {'Engineering / Technical', 'Manufacturing / Industry / Skilled Technical Work', 'Research / R&D / Investigation', 'Consulting / Advisory'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'ఆశ్లేష', lord: 'Mercury', professionFamilies: {'Research / R&D / Investigation', 'Medicine / Healthcare', 'Consulting / Advisory', 'Defence / Police / Security'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'మఖ', lord: 'Ketu', professionFamilies: {'Government / Administration', 'Management / High Position', 'Occult / Astrology / Traditional Studies'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'పుబ్బ', lord: 'Venus', professionFamilies: {'Journalism / Writing / Media', 'Commercial / Business / Entrepreneurship', 'Social / Community Service', 'Music / Arts / Performance'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'ఉత్తర', lord: 'Sun', professionFamilies: {'Commercial / Business / Entrepreneurship', 'Management / High Position', 'Law / Judiciary / Compliance', 'Consulting / Advisory'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'హస్త', lord: 'Moon', professionFamilies: {'Commercial / Business / Entrepreneurship', 'Communication / Languages', 'Manufacturing / Industry / Skilled Technical Work'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'చిత్త', lord: 'Mars', professionFamilies: {'Architecture / Design', 'Engineering / Technical', 'Commercial / Business / Entrepreneurship'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'స్వాతి', lord: 'Rahu', professionFamilies: {'Commercial / Business / Entrepreneurship', 'Import / Export / Foreign Relations', 'Communication / Languages'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'విశాఖ', lord: 'Jupiter', professionFamilies: {'Management / High Position', 'Commercial / Business / Entrepreneurship', 'Teaching / Education', 'Consulting / Advisory'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'అనూరాధ', lord: 'Saturn', professionFamilies: {'Management / High Position', 'Social / Community Service', 'Consulting / Advisory'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'జ్యేష్ఠ', lord: 'Mercury', professionFamilies: {'Research / R&D / Investigation', 'Government / Administration', 'Travel / Tourism / Logistics', 'Occult / Astrology / Traditional Studies'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'మూల', lord: 'Ketu', professionFamilies: {'Research / R&D / Investigation', 'Occult / Astrology / Traditional Studies'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'పూర్వాషాఢ', lord: 'Venus', professionFamilies: {'Consulting / Advisory', 'Social / Community Service', 'Hospitality / Food / Nutrition', 'Fashion / Beauty / Creative Design', 'Research / R&D / Investigation'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'ఉత్తరాషాఢ', lord: 'Sun', professionFamilies: {'Research / R&D / Investigation', 'Engineering / Technical', 'Management / High Position', 'Government / Administration'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'శ్రవణం', lord: 'Moon', professionFamilies: {'Communication / Languages', 'Teaching / Education', 'Music / Arts / Performance', 'Consulting / Advisory'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'ధనిష్ఠ', lord: 'Mars', professionFamilies: {'Commercial / Business / Entrepreneurship', 'Social / Community Service', 'Music / Arts / Performance'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'శతభిషం', lord: 'Rahu', professionFamilies: {'Medicine / Healthcare', 'Research / R&D / Investigation', 'Law / Judiciary / Compliance', 'Occult / Astrology / Traditional Studies'}, evidenceLevel: 'Strong source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'పూర్వాభాద్ర', lord: 'Jupiter', professionFamilies: {'Journalism / Writing / Media', 'Management / High Position', 'Social / Community Service', 'Consulting / Advisory'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'ఉత్తరాభాద్ర', lord: 'Saturn', professionFamilies: {'Music / Arts / Performance', 'Hospitality / Food / Nutrition', 'Social / Community Service', 'Government / Administration'}, evidenceLevel: 'Source-derived'),
    D10NakshatraProfessionProfile(nameTe: 'రేవతి', lord: 'Mercury', professionFamilies: {'Social / Community Service', 'Travel / Tourism / Logistics', 'Journalism / Writing / Media', 'Music / Arts / Performance', 'Hospitality / Food / Nutrition', 'Communication / Languages'}, evidenceLevel: 'Strong source-derived'),
  ];

  static D10FinalProfessionResult evaluate({
    required AstroChartResult chart,
    required VargaChartData d10,
  }) {
    final tenthSign = (d10.ascendantSignIndex + 9) % 12;
    final tenthLord = _signLord(tenthSign);
    final tenthLordPlacement = d10.planets.firstWhere((p) => p.name == tenthLord);
    final tenthLordSign = tenthLordPlacement.signIndex;
    final nature = signNature(tenthLordSign);
    final natal10L = chart.planets.firstWhere((p) => p.name == tenthLord);
    final d10Longitude = VargaService.d10LongitudeForLongitude(natal10L.longitude);
    final nak = VedicCalculationService.nakshatra(d10Longitude);
    final nakProfile = nakshatraProfiles[nak.index];
    final conjunctions = d10.planets
        .where((p) => p.name != tenthLord && p.signIndex == tenthLordSign)
        .map((p) => p.name)
        .toList(growable: false);
    final devata = D10CareerService.devataForLongitude(natal10L.longitude);
    final signGroups = signProfessionFamilies[tenthLordSign] ?? const <String>{};

    final availableBlocks = 3 + (conjunctions.isEmpty ? 0 : 1);
    final ranked = <D10ProfessionCandidate>[];

    for (final family in professionFamilies) {
      final matches = <String>[];
      if (family.planets.contains(tenthLord)) {
        matches.add('10L $tenthLord');
      }
      if (nakProfile.professionFamilies.contains(family.name)) {
        matches.add('Nakshatra ${nakProfile.nameTe}');
      }
      if (signGroups.contains(family.name)) {
        matches.add('10L రాశి ${signNamesTe[tenthLordSign]}');
      }
      if (conjunctions.isNotEmpty && conjunctions.any(family.planets.contains)) {
        final matching = conjunctions.where(family.planets.contains).join(', ');
        matches.add('10Lతో కలిసిన $matching');
      }
      if (matches.isEmpty) continue;

      final percent = ((matches.length / availableBlocks) * 100).round();
      final compatible = family.compatibleNatures.contains(nature);
      final natureStatus = compatible ? '$nature Match' : '$nature Partial/Secondary';
      final devataSupport = devata.professionGroups.contains(family.name) ||
          _devataFamilyAliasMatch(devata.professionGroups, family.name);

      ranked.add(
        D10ProfessionCandidate(
          profession: family.name,
          evidenceMatchPercent: percent,
          matchedEvidence: List<String>.unmodifiable(matches),
          availableEvidenceBlocks: availableBlocks,
          natureCompatibility: natureStatus,
          devataSupport: devataSupport,
        ),
      );
    }

    ranked.sort((a, b) {
      final natureA = a.natureCompatibility.endsWith('Match') ? 1 : 0;
      final natureB = b.natureCompatibility.endsWith('Match') ? 1 : 0;
      if (natureA != natureB) return natureB.compareTo(natureA);
      final p = b.evidenceMatchPercent.compareTo(a.evidenceMatchPercent);
      if (p != 0) return p;
      final d = (b.devataSupport ? 1 : 0).compareTo(a.devataSupport ? 1 : 0);
      if (d != 0) return d;
      return a.profession.compareTo(b.profession);
    });

    return D10FinalProfessionResult(
      tenthLord: tenthLord,
      tenthLordSignIndex: tenthLordSign,
      tenthLordSignName: signNamesTe[tenthLordSign],
      professionNature: nature,
      d10TenthLordLongitude: d10Longitude,
      nakshatraIndex: nak.index,
      nakshatraName: nakProfile.nameTe,
      nakshatraLord: nakProfile.lord,
      conjunctions: List<String>.unmodifiable(conjunctions),
      amshaDevata: devata,
      candidates: List<D10ProfessionCandidate>.unmodifiable(ranked),
    );
  }

  static bool _devataFamilyAliasMatch(List<String> devataGroups, String family) {
    for (final group in devataGroups) {
      if (family.contains(group) || group.contains(family)) return true;
      if (group == 'Accounting' && family == 'Accounting / Audit / Tax') return true;
      if (group == 'Engineering / Technical' && family == 'Engineering / Technical') return true;
      if (group == 'Medicine / Surgery' && family == 'Medicine / Healthcare') return true;
      if (group == 'Research / Specialized Studies' && family == 'Research / R&D / Investigation') return true;
      if (group == 'Government / Administration' && family == 'Government / Administration') return true;
      if (group == 'Commercial / Business' && family == 'Commercial / Business / Entrepreneurship') return true;
    }
    return false;
  }

  static String _signLord(int sign) => const [
        'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
        'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
      ][sign];

  /// BPHS Ch.45 Shayanadi arithmetic. `birthGhati` must be obtained from the
  /// exact local sunrise implementation. The calculator never guesses it.
  static D10ShayanadiResult shayanadi({
    required String planet,
    required double siderealLongitude,
    required int janmaNakshatraNumber,
    required int birthGhati,
    required int lagnaSignNumber,
    int? nameAnka,
  }) {
    final planetNak = VedicCalculationService.nakshatra(siderealLongitude).index + 1;
    final planetNumber = _planetNumber(planet);
    final degreeInSign = ((siderealLongitude % 30) + 30) % 30;
    final navamsaIndex = (degreeInSign / (30 / 9)).floor().clamp(0, 8).toInt() + 1;
    final total = (planetNak * planetNumber * navamsaIndex) +
        janmaNakshatraNumber + birthGhati + lagnaSignNumber;
    final rem = total % 12;
    final stateNo = rem == 0 ? 12 : rem;
    final state = _shayanadiStates[stateNo - 1];

    if (nameAnka == null) {
      return D10ShayanadiResult(
        stateNumber: stateNo,
        state: state,
        subStateRemainder: null,
        subState: null,
        expression: 'Name Anka required for Drishti/Cheshta/Vicheshta',
        audit: 'S=$planetNak × P=$planetNumber × N=$navamsaIndex + J=$janmaNakshatraNumber + G=$birthGhati + L=$lagnaSignNumber = $total → mod12=$stateNo → $state.',
      );
    }

    final r1 = ((stateNo * stateNo) + nameAnka) % 12;
    final additive = _planetAdditive(planet);
    final r2 = (r1 + additive) % 3;
    final sub = switch (r2) { 1 => 'Drishti', 2 => 'Cheshta', _ => 'Vicheshta' };
    final expression = switch (r2) { 1 => 'Medium', 2 => 'Full', _ => 'Negligible' };
    return D10ShayanadiResult(
      stateNumber: stateNo,
      state: state,
      subStateRemainder: r2,
      subState: sub,
      expression: expression,
      audit: 'Main: S=$planetNak × P=$planetNumber × N=$navamsaIndex + J=$janmaNakshatraNumber + G=$birthGhati + L=$lagnaSignNumber = $total → $state. Sub: ($stateNo² + NameAnka=$nameAnka) mod12=$r1; + planet additive $additive → mod3=$r2 → $sub ($expression).',
    );
  }

  static int _planetNumber(String planet) => switch (planet) {
        'Sun' => 1,
        'Moon' => 2,
        'Mars' => 3,
        'Mercury' => 4,
        'Jupiter' => 5,
        'Venus' => 6,
        'Saturn' => 7,
        'Rahu' => 8,
        'Ketu' => 9,
        _ => throw ArgumentError('Unsupported Shayanadi planet: $planet'),
      };

  static int _planetAdditive(String planet) => switch (planet) {
        'Sun' => 5,
        'Moon' => 2,
        'Mars' => 2,
        'Mercury' => 3,
        'Jupiter' => 5,
        'Venus' => 3,
        'Saturn' => 3,
        'Rahu' || 'Ketu' => 4,
        _ => throw ArgumentError('Unsupported Shayanadi planet: $planet'),
      };

  static const _shayanadiStates = <String>[
    'Shayana',
    'Upaveshana',
    'Netrapani',
    'Prakasha',
    'Gamana',
    'Agaman',
    'Sabha',
    'Agama',
    'Bhojana',
    'Nritya-Lipsa',
    'Kautuka',
    'Nidra',
  ];
}
