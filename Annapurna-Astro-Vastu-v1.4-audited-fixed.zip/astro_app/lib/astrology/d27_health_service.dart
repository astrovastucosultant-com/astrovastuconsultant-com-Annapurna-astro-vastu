import 'astro_models.dart';
import 'dasha_service.dart';
import 'panchadha_maitri_service.dart';
import 'varga_service.dart';

class D27BodyRegion {
  final String title;
  final String externalPart;
  final String internalPart;
  final String outletPart;
  final String assetName;

  const D27BodyRegion({
    required this.title,
    required this.externalPart,
    required this.internalPart,
    required this.outletPart,
    required this.assetName,
  });
}

class D27TimingWindow {
  final DateTime start;
  final DateTime end;
  final int startAge;
  final int endAge;
  final String mahadasha;
  final String antardasha;
  final int evidencePercent;
  final List<String> matchedEvidence;

  const D27TimingWindow({
    required this.start,
    required this.end,
    required this.startAge,
    required this.endAge,
    required this.mahadasha,
    required this.antardasha,
    required this.evidencePercent,
    required this.matchedEvidence,
  });
}

class D27HealthResult {
  final bool hasAutoTrigger;
  final String? primaryPlanet;
  final int? d27House;
  final int? d27SignIndex;
  final String? d27SignName;
  final String? d27Nakshatra;
  final String? amshaDevata;
  final String devataContext;
  final String devataNote;
  final D27BodyRegion? bodyRegion;
  final String locationType;
  final String natureSummary;
  final String panchadhaRelation;
  final double panchadhaStrength;
  final int panchadhaStrengthPercent;
  final int evidencePercent;
  final List<String> evidence;
  final List<D27TimingWindow> timingWindows;

  const D27HealthResult({
    required this.hasAutoTrigger,
    required this.primaryPlanet,
    required this.d27House,
    required this.d27SignIndex,
    required this.d27SignName,
    required this.d27Nakshatra,
    required this.amshaDevata,
    required this.devataContext,
    required this.devataNote,
    required this.bodyRegion,
    required this.locationType,
    required this.natureSummary,
    required this.panchadhaRelation,
    required this.panchadhaStrength,
    required this.panchadhaStrengthPercent,
    required this.evidencePercent,
    required this.evidence,
    required this.timingWindows,
  });
}

/// Traditional D27 health/roga support layer used for the user's requested
/// report layout. This is an astrological evidence engine, not a medical
/// diagnosis engine. Percentages are rule/evidence coverage only.
class D27HealthService {
  static const _malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};
  static const _signNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];
  static const _signLords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];
  static const _nakshatras = <String>[
    'అశ్విని', 'భరణి', 'కృత్తిక', 'రోహిణి', 'మృగశిర', 'ఆర్ద్ర',
    'పునర్వసు', 'పుష్యమి', 'ఆశ్లేష', 'మఖ', 'పూర్వ ఫల్గుణి',
    'ఉత్తర ఫల్గుణి', 'హస్త', 'చిత్త', 'స్వాతి', 'విశాఖ', 'అనూరాధ',
    'జ్యేష్ఠ', 'మూల', 'పూర్వాషాఢ', 'ఉత్తరాషాఢ', 'శ్రవణం', 'ధనిష్ఠ',
    'శతభిషం', 'పూర్వాభాద్ర', 'ఉత్తరాభాద్ర', 'రేవతి',
  ];

  // BPHS Ch.6 Saptavimshamsha / Bhamsa presiding deities. For an even
  // natal sign the sequence is read in reverse.
  static const _bhamsaDeities = <String>[
    'Dasra / Ashwini Kumara',
    'Yama',
    'Agni',
    'Brahma',
    'Chandra',
    'Isha',
    'Aditi',
    'Jiva',
    'Ahi',
    'Pitara',
    'Bhaga',
    'Aryama',
    'Surya',
    'Tvashta',
    'Marut',
    'Sakragni',
    'Mitra',
    'Vasava',
    'Rakshasa',
    'Varuna',
    'Vishwadeva',
    'Govinda',
    'Vasu',
    'Varuna',
    'Ajapa',
    'Ahirbudhnya',
    'Pusha',
  ];

  static const _regions = <D27BodyRegion>[
    D27BodyRegion(title: 'తల / Head region', externalPart: 'తల, ముఖ పైభాగం', internalPart: 'మెదడు / cranial region', outletPart: 'తల-ముఖ సంబంధిత మార్గాలు', assetName: 'd27_region_01.png'),
    D27BodyRegion(title: 'ముఖం / గొంతు', externalPart: 'ముఖం, మెడ', internalPart: 'గొంతు / స్వరపేటిక', outletPart: 'ముఖ-దవడ ప్రాంతం', assetName: 'd27_region_02.png'),
    D27BodyRegion(title: 'భుజాలు / చేతులు / శ్వాస ప్రాంతం', externalPart: 'భుజాలు, చేతులు, ఎగువ ఛాతి', internalPart: 'శ్వాసనాళం / ఊపిరితిత్తుల పైభాగం', outletPart: 'భుజ-చేతి ఎముక ప్రాంతం', assetName: 'd27_region_03.png'),
    D27BodyRegion(title: 'ఛాతి / Chest region', externalPart: 'ఛాతి, స్తన ప్రాంతం', internalPart: 'హృదయం / ఊపిరితిత్తులు', outletPart: 'ఛాతి ఎముకల ప్రాంతం', assetName: 'd27_region_04.png'),
    D27BodyRegion(title: 'ఎగువ ఉదరం / Upper abdomen', externalPart: 'ఎగువ ఉదరం / వెన్ను', internalPart: 'జీర్ణక్రియ / హృదయ-పిత్త సంబంధిత ప్రాంతం', outletPart: 'ఎగువ వెన్ను ప్రాంతం', assetName: 'd27_region_05.png'),
    D27BodyRegion(title: 'కింది ఉదరం / Intestinal region', externalPart: 'కింది ఉదరం', internalPart: 'ప్రేగులు / పెద్ద ప్రేగు ప్రాంతం', outletPart: 'కింది వెన్ను-ఉదర ప్రాంతం', assetName: 'd27_region_06.png'),
    D27BodyRegion(title: 'నాభి / నడుము / Kidney region', externalPart: 'నడుము / నాభి ప్రాంతం', internalPart: 'మూత్రపిండ / ద్రవ సమతుల్య ప్రాంతం', outletPart: 'నడుము ప్రాంతం', assetName: 'd27_region_07.png'),
    D27BodyRegion(title: 'ప్రజనన / మూత్ర ప్రాంతం', externalPart: 'ప్రజనన అవయవ ప్రాంతం', internalPart: 'మూత్రాశయం / reproductive region', outletPart: 'pelvic outlet region', assetName: 'd27_region_08.png'),
    D27BodyRegion(title: 'తొడలు / Hips & thighs', externalPart: 'తొడలు / hip region', internalPart: 'muscle / liver-support region', outletPart: 'తొడ ఎముక ప్రాంతం', assetName: 'd27_region_09.png'),
    D27BodyRegion(title: 'మోకాళ్లు / Knees', externalPart: 'మోకాళ్లు', internalPart: 'ఎముక / joint region', outletPart: 'మోకాలి సంధి ప్రాంతం', assetName: 'd27_region_10.png'),
    D27BodyRegion(title: 'కాళ్ల కింది భాగం / Calves & ankles', externalPart: 'కాల్వ్స్ / మడమలు', internalPart: 'రక్త ప్రసరణ సంబంధిత ప్రాంతం', outletPart: 'కాలి ఎముక ప్రాంతం', assetName: 'd27_region_11.png'),
    D27BodyRegion(title: 'పాదాలు / Feet', externalPart: 'పాదాలు / వేళ్లు', internalPart: 'లింఫ్ / ద్రవ చలనం సంబంధిత ప్రాంతం', outletPart: 'పాద ఎముక ప్రాంతం', assetName: 'd27_region_12.png'),
  ];

  static D27HealthResult evaluate({
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    final d27 = VargaService.calculate(chart, 27);
    final panchadha = PanchadhaMaitriService.evaluateVarga(chart: chart, factor: 27);

    PanchadhaVargaStrength? strengthFor(String planet) {
      for (final item in panchadha) {
        if (item.planet == planet) return item;
      }
      return null;
    }

    int houseFor(VargaPlacement p) => ((p.signIndex - d27.ascendantSignIndex + 12) % 12) + 1;

    final candidates = d27.planets.where((p) {
      final h = houseFor(p);
      return h == 6 || h == 8;
    }).toList(growable: false);

    if (candidates.isEmpty) {
      return const D27HealthResult(
        hasAutoTrigger: false,
        primaryPlanet: null,
        d27House: null,
        d27SignIndex: null,
        d27SignName: null,
        d27Nakshatra: null,
        amshaDevata: null,
        devataContext: '—',
        devataNote: 'D27లో 6/8 auto-trigger లేకపోవడంతో Devata health modifierను final disease resultగా ఉపయోగించలేదు.',
        bodyRegion: null,
        locationType: 'No auto-trigger',
        natureSummary: 'ఈ simple D27 evaluatorలో strong auto-matched health trigger కనిపించలేదు.',
        panchadhaRelation: '—',
        panchadhaStrength: 0,
        panchadhaStrengthPercent: 0,
        evidencePercent: 0,
        evidence: <String>[],
        timingWindows: <D27TimingWindow>[],
      );
    }

    int riskScore(VargaPlacement p) {
      final h = houseFor(p);
      final strength = strengthFor(p.name);
      var score = h == 8 ? 3 : 2;
      if (_malefics.contains(p.name)) score += 2;
      if (strength != null &&
          (strength.relationToSignLord == PanchadhaRelation.shatru ||
              strength.relationToSignLord == PanchadhaRelation.adhishatru)) {
        score += 2;
      } else if (strength != null && strength.relationToSignLord == PanchadhaRelation.sama) {
        score += 1;
      }
      if (const {'Saturn', 'Rahu', 'Ketu', 'Mars'}.contains(p.name)) score += 1;
      return score;
    }

    final ordered = [...candidates]..sort((a, b) => riskScore(b).compareTo(riskScore(a)));
    final primary = ordered.first;
    final primaryHouse = houseFor(primary);
    final primaryD27Sign = primary.signIndex;
    final natal = chart.planets.firstWhere((p) => p.name == primary.name);
    final d27Long = VargaService.d27LongitudeForLongitude(natal.longitude);
    final nakIndex = (d27Long / (360.0 / 27.0)).floor().clamp(0, 26).toInt();
    final nakName = _nakshatras[nakIndex];

    final pStrength = strengthFor(primary.name);
    final panchadhaPercent = pStrength == null
        ? 0
        : ((pStrength.strength / 30.0) * 100).round().clamp(0, 100).toInt();

    final evidence = <String>[];
    var availableEvidenceBlocks = 3; // D27 house + malefic + D1 confirmation
    evidence.add('D27 ${primaryHouse}వ భావ సంబంధం ✓');
    if (_malefics.contains(primary.name)) evidence.add('పాపగ్రహ/రోగకారక support ✓');
    if (pStrength != null) {
      availableEvidenceBlocks += 1;
      final weakPanchadha = pStrength.relationToSignLord == PanchadhaRelation.sama ||
          pStrength.relationToSignLord == PanchadhaRelation.shatru ||
          pStrength.relationToSignLord == PanchadhaRelation.adhishatru;
      if (weakPanchadha) evidence.add('పంచధా మైత్రి బలం తక్కువ/మధ్యస్థం ✓');
    }

    final d1House = ((natal.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final d1HealthConfirm = const {6, 8, 12}.contains(d1House);
    if (d1HealthConfirm) evidence.add('D1 6/8/12 confirmation ✓');
    final evidencePercent = ((evidence.length / availableEvidenceBlocks) * 100).round().clamp(0, 100).toInt();

    final degreeWithinDrekkana = natal.degreesInSign % 10.0;
    final location = degreeWithinDrekkana < 5.0
        ? 'Internal / అంతరంగ సూచన'
        : 'External / బాహ్య సూచన';

    final natureBits = <String>[];
    if (candidates.any((p) => p.name == 'Saturn' || p.name == 'Rahu')) {
      natureBits.add('Chronic / దీర్ఘకాల tendency layer');
    }
    if (candidates.any((p) => p.name == 'Mars' || p.name == 'Ketu')) {
      natureBits.add('Surgery / intervention caution layer');
    }
    if (natureBits.isEmpty) natureBits.add('General health-stress indication');

    final segmentSize = 30.0 / 27.0;
    final natalSignIndex = natal.signIndex;
    final division = (natal.degreesInSign / segmentSize).floor().clamp(0, 26).toInt();
    final deityIndex = natalSignIndex.isEven ? division : 26 - division;
    final deity = _bhamsaDeities[deityIndex];

    final affectedNames = candidates.map((p) => p.name).toSet();
    final timing = _timingWindows(
      chart: chart,
      birthDateTime: birthDateTime,
      affectedPlanets: affectedNames,
      primaryPlanet: primary.name,
    );

    return D27HealthResult(
      hasAutoTrigger: true,
      primaryPlanet: primary.name,
      d27House: primaryHouse,
      d27SignIndex: primaryD27Sign,
      d27SignName: _signNames[primaryD27Sign],
      d27Nakshatra: nakName,
      amshaDevata: deity,
      devataContext: _devataContext(deity),
      devataNote: 'Bhamsa Devataను contextual modifierగా మాత్రమే చూపిస్తాం. ఈ sourceలో Devata→specific disease/organ medical mapping ఇవ్వలేదు; అందువల్ల Devataకి ప్రత్యేక disease % జోడించము.',
      bodyRegion: _regions[primaryD27Sign],
      locationType: location,
      natureSummary: natureBits.join(' • '),
      panchadhaRelation: pStrength == null
          ? 'Rahu/Ketuకు user Panchadha tableలో score లేదు'
          : PanchadhaMaitriService.relationTelugu(pStrength.relationToSignLord),
      panchadhaStrength: pStrength?.strength ?? 0,
      panchadhaStrengthPercent: panchadhaPercent,
      evidencePercent: evidencePercent,
      evidence: evidence,
      timingWindows: timing,
    );
  }

  static String _devataContext(String deity) {
    if (deity.startsWith('Dasra')) return 'Healing / recovery symbolism — contextual modifier మాత్రమే.';
    if (deity == 'Yama') return 'Restraint, discipline, limitation symbolism — contextual modifier.';
    if (deity == 'Agni' || deity == 'Sakragni' || deity == 'Surya') return 'Heat, activation, intensity symbolism — contextual modifier.';
    if (deity == 'Chandra' || deity == 'Varuna') return 'Fluidity, nourishment, regulation symbolism — contextual modifier.';
    if (deity == 'Brahma' || deity == 'Tvashta') return 'Formation, structure, rebuilding symbolism — contextual modifier.';
    if (deity == 'Aditi' || deity == 'Mitra' || deity == 'Vishwadeva' || deity == 'Govinda' || deity == 'Pusha') return 'Support, protection, nourishment symbolism — contextual modifier.';
    if (deity == 'Jiva' || deity == 'Bhaga' || deity == 'Aryama' || deity == 'Vasu' || deity == 'Vasava') return 'Vitality/support/resource symbolism — contextual modifier.';
    if (deity == 'Marut') return 'Movement / air / circulation symbolism — contextual modifier.';
    if (deity == 'Ahi' || deity == 'Rakshasa' || deity == 'Ahirbudhnya') return 'Hidden/deep/intense symbolism — contextual modifier.';
    if (deity == 'Pitara') return 'Ancestral/hereditary symbolism — contextual modifier.';
    if (deity == 'Isha' || deity == 'Ajapa') return 'Transformation / restraint / inward-focus symbolism — contextual modifier.';
    return 'Contextual symbolic modifier మాత్రమే; direct medical mapping కాదు.';
  }

  static List<D27TimingWindow> _timingWindows({
    required AstroChartResult chart,
    required DateTime birthDateTime,
    required Set<String> affectedPlanets,
    required String primaryPlanet,
  }) {
    final system = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birthDateTime,
    );
    final out = <D27TimingWindow>[];

    for (final md in system.mahadashas) {
      final ads = DashaService.subPeriodsFor(system, md);
      for (final ad in ads) {
        var score = 0;
        final reasons = <String>[];
        if (affectedPlanets.contains(md.lord)) {
          score += 50;
          reasons.add('${md.lord} Mahadasha = affected D27 planet');
        }
        if (affectedPlanets.contains(ad.lord)) {
          score += 50;
          reasons.add('${ad.lord} Antardasha = affected D27 planet');
        }
        if (score == 0) continue;

        // Primary planet is not given extra percentage: it only breaks ties,
        // avoiding invented double-counting.
        final startAge = _ageAt(birthDateTime, ad.start);
        final endAge = _ageAt(birthDateTime, ad.end);
        if (endAge < 0 || startAge > 100) continue;
        out.add(
          D27TimingWindow(
            start: ad.start,
            end: ad.end,
            startAge: startAge < 0 ? 0 : startAge,
            endAge: endAge < 0 ? 0 : endAge,
            mahadasha: md.lord,
            antardasha: ad.lord,
            evidencePercent: score,
            matchedEvidence: reasons,
          ),
        );
      }
    }

    out.sort((a, b) {
      final score = b.evidencePercent.compareTo(a.evidencePercent);
      if (score != 0) return score;
      final aPrimary = a.mahadasha == primaryPlanet || a.antardasha == primaryPlanet;
      final bPrimary = b.mahadasha == primaryPlanet || b.antardasha == primaryPlanet;
      if (aPrimary != bPrimary) return bPrimary ? 1 : -1;
      return a.start.compareTo(b.start);
    });
    return out.take(8).toList(growable: false);
  }

  static int _ageAt(DateTime birth, DateTime date) {
    var age = date.year - birth.year;
    final beforeBirthday = date.month < birth.month ||
        (date.month == birth.month && date.day < birth.day);
    if (beforeBirthday) age--;
    return age;
  }
}
