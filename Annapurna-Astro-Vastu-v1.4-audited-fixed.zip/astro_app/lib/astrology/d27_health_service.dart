import 'astro_models.dart';
import 'dasha_service.dart';
import 'panchadha_maitri_service.dart';
import 'varga_service.dart';

class D27BodyRegion {
  final String title;
  final String externalPart;
  final String internalPart;
  final String outletPart;
  final String assetName;

  const D27BodyRegion({
    required this.title,
    required this.externalPart,
    required this.internalPart,
    required this.outletPart,
    required this.assetName,
  });
}

class D27TimingWindow {
  final DateTime start;
  final DateTime end;
  final int startAge;
  final int endAge;
  final String mahadasha;
  final String antardasha;
  final int evidencePercent;
  final List<String> matchedEvidence;

  const D27TimingWindow({
    required this.start,
    required this.end,
    required this.startAge,
    required this.endAge,
    required this.mahadasha,
    required this.antardasha,
    required this.evidencePercent,
    required this.matchedEvidence,
  });
}


class D27OrganEvidence {
  final String planet;
  final String signName;
  final String bodyRegion;
  final String locationType;
  final int d1d3EvidencePercent;
  final int d27StrengthPercent;
  final int kharaEvidencePercent;
  final int finalEvidencePercent;
  final bool has22DLink;
  final bool has64NLink;
  final List<String> supportingPlanets;
  final List<String> supportingSigns;
  final List<String> locationDetails;
  final List<String> naturalKarakas;
  final int karakaEvidencePercent;
  final String karakaStatus;
  final List<String> vitaminSupport;
  final List<String> mineralSupport;
  final List<String> evidence;

  const D27OrganEvidence({
    required this.planet,
    required this.signName,
    required this.bodyRegion,
    required this.locationType,
    required this.d1d3EvidencePercent,
    required this.d27StrengthPercent,
    this.kharaEvidencePercent = 0,
    this.finalEvidencePercent = 0,
    this.has22DLink = false,
    this.has64NLink = false,
    this.supportingPlanets = const <String>[],
    this.supportingSigns = const <String>[],
    this.locationDetails = const <String>[],
    this.naturalKarakas = const <String>[],
    this.karakaEvidencePercent = 0,
    this.karakaStatus = 'No direct karaka confirmation',
    this.vitaminSupport = const <String>[],
    this.mineralSupport = const <String>[],
    required this.evidence,
  });
}

class D27KharaLayer {
  final String drekkana22Lord;
  final String navamsa64Lord;
  final int evidencePercent;
  final List<String> evidence;

  const D27KharaLayer({
    required this.drekkana22Lord,
    required this.navamsa64Lord,
    required this.evidencePercent,
    required this.evidence,
  });
}

class D27RemedyResult {
  final String planetRemedy;
  final String dashaPair;
  final List<String> dashaRemedies;

  const D27RemedyResult({
    required this.planetRemedy,
    required this.dashaPair,
    required this.dashaRemedies,
  });
}

class D27HealthResult {
  final bool hasAutoTrigger;
  final String? primaryPlanet;
  final int? d27House;
  final int? d27SignIndex;
  final String? d27SignName;
  final String? d27Nakshatra;
  final String? amshaDevata;
  final String devataContext;
  final String devataNote;
  final D27BodyRegion? bodyRegion;
  final String locationType;
  final String natureSummary;
  final String panchadhaRelation;
  final double panchadhaStrength;
  final int panchadhaStrengthPercent;
  final int evidencePercent;
  final List<String> evidence;
  final List<D27TimingWindow> timingWindows;
  final List<D27OrganEvidence> organEvidence;
  final D27KharaLayer kharaLayer;
  final D27RemedyResult remedy;

  const D27HealthResult({
    required this.hasAutoTrigger,
    required this.primaryPlanet,
    required this.d27House,
    required this.d27SignIndex,
    required this.d27SignName,
    required this.d27Nakshatra,
    required this.amshaDevata,
    required this.devataContext,
    required this.devataNote,
    required this.bodyRegion,
    required this.locationType,
    required this.natureSummary,
    required this.panchadhaRelation,
    required this.panchadhaStrength,
    required this.panchadhaStrengthPercent,
    required this.evidencePercent,
    required this.evidence,
    required this.timingWindows,
    required this.organEvidence,
    required this.kharaLayer,
    required this.remedy,
  });
}

/// Traditional D27 health/roga support layer used for the user's requested
/// report layout. This is an astrological evidence engine, not a medical
/// diagnosis engine. Percentages are rule/evidence coverage only.
class D27HealthService {
  static const _malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};
  static const _signNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];
  static const _signLords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];
  static const _nakshatras = <String>[
    'అశ్విని', 'భరణి', 'కృత్తిక', 'రోహిణి', 'మృగశిర', 'ఆర్ద్ర',
    'పునర్వసు', 'పుష్యమి', 'ఆశ్లేష', 'మఖ', 'పూర్వ ఫల్గుణి',
    'ఉత్తర ఫల్గుణి', 'హస్త', 'చిత్త', 'స్వాతి', 'విశాఖ', 'అనూరాధ',
    'జ్యేష్ఠ', 'మూల', 'పూర్వాషాఢ', 'ఉత్తరాషాఢ', 'శ్రవణం', 'ధనిష్ఠ',
    'శతభిషం', 'పూర్వాభాద్ర', 'ఉత్తరాభాద్ర', 'రేవతి',
  ];

  // BPHS Ch.6 Saptavimshamsha / Bhamsa presiding deities. For an even
  // natal sign the sequence is read in reverse.
  static const _bhamsaDeities = <String>[
    'Dasra / Ashwini Kumara',
    'Yama',
    'Agni',
    'Brahma',
    'Chandra',
    'Isha',
    'Aditi',
    'Jiva',
    'Ahi',
    'Pitara',
    'Bhaga',
    'Aryama',
    'Surya',
    'Tvashta',
    'Marut',
    'Sakragni',
    'Mitra',
    'Vasava',
    'Rakshasa',
    'Varuna',
    'Vishwadeva',
    'Govinda',
    'Vasu',
    'Varuna',
    'Ajapa',
    'Ahirbudhnya',
    'Pusha',
  ];

  static const _regions = <D27BodyRegion>[
    D27BodyRegion(title: 'తల / Head region', externalPart: 'తల, ముఖ పైభాగం', internalPart: 'మెదడు / cranial region', outletPart: 'తల-ముఖ సంబంధిత మార్గాలు', assetName: 'd27_region_01.png'),
    D27BodyRegion(title: 'ముఖం / గొంతు', externalPart: 'ముఖం, మెడ', internalPart: 'గొంతు / స్వరపేటిక', outletPart: 'ముఖ-దవడ ప్రాంతం', assetName: 'd27_region_02.png'),
    D27BodyRegion(title: 'భుజాలు / చేతులు / శ్వాస ప్రాంతం', externalPart: 'భుజాలు, చేతులు, ఎగువ ఛాతి', internalPart: 'శ్వాసనాళం / ఊపిరితిత్తుల పైభాగం', outletPart: 'భుజ-చేతి ఎముక ప్రాంతం', assetName: 'd27_region_03.png'),
    D27BodyRegion(title: 'ఛాతి / Chest region', externalPart: 'ఛాతి, స్తన ప్రాంతం', internalPart: 'హృదయం / ఊపిరితిత్తులు', outletPart: 'ఛాతి ఎముకల ప్రాంతం', assetName: 'd27_region_04.png'),
    D27BodyRegion(title: 'ఎగువ ఉదరం / Upper abdomen', externalPart: 'ఎగువ ఉదరం / వెన్ను', internalPart: 'జీర్ణక్రియ / హృదయ-పిత్త సంబంధిత ప్రాంతం', outletPart: 'ఎగువ వెన్ను ప్రాంతం', assetName: 'd27_region_05.png'),
    D27BodyRegion(title: 'కింది ఉదరం / Intestinal region', externalPart: 'కింది ఉదరం', internalPart: 'ప్రేగులు / పెద్ద ప్రేగు ప్రాంతం', outletPart: 'కింది వెన్ను-ఉదర ప్రాంతం', assetName: 'd27_region_06.png'),
    D27BodyRegion(title: 'నాభి / నడుము / Kidney region', externalPart: 'నడుము / నాభి ప్రాంతం', internalPart: 'మూత్రపిండ / ద్రవ సమతుల్య ప్రాంతం', outletPart: 'నడుము ప్రాంతం', assetName: 'd27_region_07.png'),
    D27BodyRegion(title: 'ప్రజనన / మూత్ర ప్రాంతం', externalPart: 'ప్రజనన అవయవ ప్రాంతం', internalPart: 'మూత్రాశయం / reproductive region', outletPart: 'pelvic outlet region', assetName: 'd27_region_08.png'),
    D27BodyRegion(title: 'తొడలు / Hips & thighs', externalPart: 'తొడలు / hip region', internalPart: 'muscle / liver-support region', outletPart: 'తొడ ఎముక ప్రాంతం', assetName: 'd27_region_09.png'),
    D27BodyRegion(title: 'మోకాళ్లు / Knees', externalPart: 'మోకాళ్లు', internalPart: 'ఎముక / joint region', outletPart: 'మోకాలి సంధి ప్రాంతం', assetName: 'd27_region_10.png'),
    D27BodyRegion(title: 'కాళ్ల కింది భాగం / Calves & ankles', externalPart: 'కాల్వ్స్ / మడమలు', internalPart: 'రక్త ప్రసరణ సంబంధిత ప్రాంతం', outletPart: 'కాలి ఎముక ప్రాంతం', assetName: 'd27_region_11.png'),
    D27BodyRegion(title: 'పాదాలు / Feet', externalPart: 'పాదాలు / వేళ్లు', internalPart: 'లింఫ్ / ద్రవ చలనం సంబంధిత ప్రాంతం', outletPart: 'పాద ఎముక ప్రాంతం', assetName: 'd27_region_12.png'),
  ];


  // User-approved fine-tuned support map. This is intentionally labelled as
  // modern medical-astrology + Vedic-dhatu cross-check, not as a classical
  // vitamin/mineral prescription system. It is used only as a support/check
  // indicator; deficiency must be established by medical testing.
  static const _karakaByRegion = <int, List<String>>{
    0: <String>['Moon', 'Mercury'], // mind / nerves
    1: <String>['Mercury', 'Venus'], // nerves / skin-related support
    2: <String>['Mercury'], // nervous-system support for upper limbs/respiratory region
    3: <String>['Sun'], // heart / vitality
    4: <String>['Jupiter'], // liver / metabolism / immunity
    5: <String>['Mercury'], // gut-neural / rasa support layer
    6: <String>['Venus'], // kidneys
    7: <String>['Venus'], // reproductive / urinary system
    8: <String>['Mars', 'Jupiter'], // muscle + liver/metabolic support
    9: <String>['Saturn'], // joints / bone structure
    10: <String>['Mars', 'Saturn'], // blood/muscle + bone/joint support
    11: <String>['Moon', 'Saturn'], // fluids + structural support
  };

  static const _vitaminSupport = <String, List<String>>{
    'Sun': <String>['Vitamin D — primary', 'Vitamin A'],
    'Moon': <String>['Vitamin B2', 'Vitamin B12'],
    'Mars': <String>['Vitamin C', 'Vitamin B12'],
    'Mercury': <String>['Vitamin B1', 'Vitamin B6'],
    'Jupiter': <String>['Vitamin D — secondary', 'Vitamin B6'],
    'Venus': <String>['Vitamin E', 'Vitamin B3 (Niacin)'],
    'Saturn': <String>['Vitamin K', 'Vitamin C'],
  };

  static const _mineralSupport = <String, List<String>>{
    'Sun': <String>['Magnesium — shared', 'Iodine'],
    'Moon': <String>['Potassium', 'Calcium — secondary'],
    'Mars': <String>['Iron — primary'],
    'Mercury': <String>['Magnesium — shared'],
    'Jupiter': <String>['Zinc', 'Chromium'],
    'Venus': <String>['Copper'],
    'Saturn': <String>['Calcium — primary', 'Sulfur'],
  };

  static bool _planetAfflictedInD1(AstroChartResult chart, String planetName) {
    final p = chart.planets.firstWhere((x) => x.name == planetName);
    final house = ((p.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final sameSignMalefic = chart.planets.any((x) =>
        x.name != planetName && x.signIndex == p.signIndex && _malefics.contains(x.name));
    return const {6, 8, 12}.contains(house) || sameSignMalefic;
  }

  static bool _planetAfflictedInD27(VargaChartData d27, String planetName) {
    final p = d27.planets.firstWhere((x) => x.name == planetName);
    final house = ((p.signIndex - d27.ascendantSignIndex + 12) % 12) + 1;
    final sameSignMalefic = d27.planets.any((x) =>
        x.name != planetName && x.signIndex == p.signIndex && _malefics.contains(x.name));
    final prev = (p.signIndex + 11) % 12;
    final next = (p.signIndex + 1) % 12;
    final papakartari = d27.planets.any((x) => x.signIndex == prev && _malefics.contains(x.name)) &&
        d27.planets.any((x) => x.signIndex == next && _malefics.contains(x.name));
    return const {6, 8}.contains(house) || sameSignMalefic || papakartari;
  }

  static int _karakaEvidencePercent({
    required AstroChartResult chart,
    required VargaChartData d27,
    required int regionIndex,
    required int d1House,
    required bool signTriggered,
  }) {
    final karakas = _karakaByRegion[regionIndex] ?? const <String>[];
    if (karakas.isEmpty) return 0;
    final karakaAfflicted = karakas.any((k) =>
        _planetAfflictedInD1(chart, k) || _planetAfflictedInD27(d27, k));
    final houseAfflicted = const {6, 8, 12}.contains(d1House);
    if (!karakaAfflicted) return 0;
    var matched = 1; // Karaka itself is afflicted: confirmation can now begin.
    if (signTriggered) matched++;
    if (houseAfflicted) matched++;
    return ((matched / 3) * 100).round().clamp(0, 100).toInt();
  }

  static String _karakaStatus(int pct) {
    if (pct >= 100) return 'Very Strong Karaka Confirmation';
    if (pct >= 67) return 'Strong Karaka Confirmation';
    if (pct >= 34) return 'Moderate Karaka Confirmation';
    if (pct > 0) return 'Weak Karaka Confirmation';
    return 'No direct karaka confirmation';
  }

  static String evidenceLabel(int pct) {
    if (pct >= 75) return 'Strong';
    if (pct >= 50) return 'Moderate';
    if (pct >= 25) return 'Weak';
    return 'Low';
  }

  static D27HealthResult evaluate({
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    final d27 = VargaService.calculate(chart, 27);
    final panchadha = PanchadhaMaitriService.evaluateVarga(chart: chart, factor: 27);

    PanchadhaVargaStrength? strengthFor(String planet) {
      for (final item in panchadha) {
        if (item.planet == planet) return item;
      }
      return null;
    }

    int d27HouseFor(VargaPlacement p) => ((p.signIndex - d27.ascendantSignIndex + 12) % 12) + 1;

    // User-approved master flow:
    // D1 -> primary organ/disease promise; D3/Drekkana -> exact side + Internal/External;
    // D27 -> strength/severity confirmation; 22nd Drekkana/64th Navamsa -> Khara risk support.
    final organList = <D27OrganEvidence>[];
    final khara = _kharaLayer(chart);

    for (final natal in chart.planets) {
      final d1House = ((natal.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
      final signIsAfflicted = _malefics.contains(natal.name) || const {6, 8, 12}.contains(d1House);
      if (!signIsAfflicted) continue;

      final d27p = d27.planets.firstWhere((x) => x.name == natal.name);
      final d27House = d27HouseFor(d27p);
      final sameD27Sign = d27.planets.where((x) => x.signIndex == d27p.signIndex && x.name != natal.name).toList();
      final d27MaleficConjunction = sameD27Sign.any((x) => _malefics.contains(x.name));
      final prev = (d27p.signIndex + 11) % 12;
      final next = (d27p.signIndex + 1) % 12;
      final prevMalefic = d27.planets.any((x) => x.signIndex == prev && _malefics.contains(x.name));
      final nextMalefic = d27.planets.any((x) => x.signIndex == next && _malefics.contains(x.name));
      final papakartari = prevMalefic && nextMalefic;

      final d1d3Evidence = <String>['D1 afflicted sign/planet ✓', 'D3 Drekkana location ✓'];
      if (const {6, 8, 12}.contains(d1House)) d1d3Evidence.add('D1 6/8/12 house support ✓');
      final d1d3Percent = ((d1d3Evidence.length / 3) * 100).round().clamp(0, 100).toInt();

      final strengthEvidence = <String>[];
      const strengthBlocks = 3;
      if (const {6, 8}.contains(d27House)) strengthEvidence.add('D27 6/8 relation ✓');
      if (d27MaleficConjunction) strengthEvidence.add('D27 malefic conjunction ✓');
      if (papakartari) strengthEvidence.add('D27 Papakartari ✓');
      final d27Percent = ((strengthEvidence.length / strengthBlocks) * 100).round().clamp(0, 100).toInt();

      final degreeWithinDrekkana = natal.degreesInSign % 10.0;
      final isInternal = degreeWithinDrekkana < 5.0;
      final location = isInternal
          ? 'Internal / అంతరంగ సూచన'
          : 'External / బాహ్య సూచన';
      final locationDetail =
          '${natal.name}: ${natal.degreesInSign.toStringAsFixed(2)}° in sign • '
          '${degreeWithinDrekkana.toStringAsFixed(2)}° within current Drekkana • '
          '${isInternal ? 'first 5° = Internal' : 'second 5° = External'}';

      final has22DLink = khara.drekkana22Lord == natal.name ||
          _signLords[natal.signIndex] == khara.drekkana22Lord;
      final has64NLink = khara.navamsa64Lord == natal.name ||
          _signLords[natal.signIndex] == khara.navamsa64Lord;
      final kharaMatches = (has22DLink ? 1 : 0) + (has64NLink ? 1 : 0);
      final organKharaPercent = ((kharaMatches / 2) * 100).round();

      final karakas = _karakaByRegion[natal.signIndex] ?? const <String>[];
      final karakaPercent = _karakaEvidencePercent(
        chart: chart,
        d27: d27,
        regionIndex: natal.signIndex,
        d1House: d1House,
        signTriggered: signIsAfflicted,
      );
      final vitaminSupport = karakas.expand((k) => _vitaminSupport[k] ?? const <String>[]).toSet().toList();
      final mineralSupport = karakas.expand((k) => _mineralSupport[k] ?? const <String>[]).toSet().toList();

      // Audit-safe separated weighting: Khara is NOT counted inside D27 again.
      // Karaka is a mandatory confirmation layer, while nutrients remain support-only.
      final organFinalPercent = ((d1d3Percent * 0.45) +
              (d27Percent * 0.30) +
              (organKharaPercent * 0.10) +
              (karakaPercent * 0.15))
          .round()
          .clamp(0, 100)
          .toInt();

      organList.add(D27OrganEvidence(
        planet: natal.name,
        signName: _signNames[natal.signIndex],
        bodyRegion: _regions[natal.signIndex].title,
        locationType: location,
        d1d3EvidencePercent: d1d3Percent,
        d27StrengthPercent: d27Percent,
        kharaEvidencePercent: organKharaPercent,
        finalEvidencePercent: organFinalPercent,
        has22DLink: has22DLink,
        has64NLink: has64NLink,
        supportingPlanets: <String>[natal.name],
        supportingSigns: <String>[_signNames[natal.signIndex]],
        locationDetails: <String>[locationDetail],
        naturalKarakas: karakas,
        karakaEvidencePercent: karakaPercent,
        karakaStatus: _karakaStatus(karakaPercent),
        vitaminSupport: vitaminSupport,
        mineralSupport: mineralSupport,
        evidence: <String>[...d1d3Evidence, ...strengthEvidence],
      ));
    }

    // Client-facing consolidation: the same body region must appear once.
    // Multiple planets become supporting evidence inside the same organ card.
    final grouped = <String, List<D27OrganEvidence>>{};
    for (final item in organList) {
      final key = item.bodyRegion;
      grouped.putIfAbsent(key, () => <D27OrganEvidence>[]).add(item);
    }
    final consolidated = <D27OrganEvidence>[];
    for (final entries in grouped.values) {
      entries.sort((a, b) => b.finalEvidencePercent.compareTo(a.finalEvidencePercent));
      final lead = entries.first;
      final planets = entries.expand((e) => e.supportingPlanets).toSet().toList();
      final signs = entries.expand((e) => e.supportingSigns).toSet().toList();
      final locationDetails = entries.expand((e) => e.locationDetails).toSet().toList();
      final locationTypes = entries.map((e) => e.locationType).toSet();
      final consolidatedLocation = locationTypes.length > 1
          ? 'Internal + External / అంతరంగ + బాహ్య సూచనలు'
          : locationTypes.first;
      final karakas = entries.expand((e) => e.naturalKarakas).toSet().toList();
      final vitamins = entries.expand((e) => e.vitaminSupport).toSet().toList();
      final minerals = entries.expand((e) => e.mineralSupport).toSet().toList();
      final evidenceSet = entries.expand((e) => e.evidence).toSet().toList();
      final d1d3 = entries.map((e) => e.d1d3EvidencePercent).reduce((a, b) => a > b ? a : b);
      final d27 = entries.map((e) => e.d27StrengthPercent).reduce((a, b) => a > b ? a : b);
      final karakaPct = entries.map((e) => e.karakaEvidencePercent).reduce((a, b) => a > b ? a : b);
      final has22 = entries.any((e) => e.has22DLink);
      final has64 = entries.any((e) => e.has64NLink);
      final kharaPct = (((has22 ? 1 : 0) + (has64 ? 1 : 0)) / 2 * 100).round();
      final finalPct = ((d1d3 * 0.45) +
              (d27 * 0.30) +
              (kharaPct * 0.10) +
              (karakaPct * 0.15))
          .round()
          .clamp(0, 100)
          .toInt();
      consolidated.add(D27OrganEvidence(
        planet: planets.join(', '),
        signName: signs.join(', '),
        bodyRegion: lead.bodyRegion,
        locationType: consolidatedLocation,
        d1d3EvidencePercent: d1d3,
        d27StrengthPercent: d27,
        kharaEvidencePercent: kharaPct,
        finalEvidencePercent: finalPct,
        has22DLink: has22,
        has64NLink: has64,
        supportingPlanets: planets,
        supportingSigns: signs,
        locationDetails: locationDetails,
        naturalKarakas: karakas,
        karakaEvidencePercent: karakaPct,
        karakaStatus: _karakaStatus(karakaPct),
        vitaminSupport: vitamins,
        mineralSupport: minerals,
        evidence: evidenceSet,
      ));
    }
    organList
      ..clear()
      ..addAll(consolidated)
      ..sort((a, b) => b.finalEvidencePercent.compareTo(a.finalEvidencePercent));

    if (organList.isEmpty) {
      return D27HealthResult(
        hasAutoTrigger: false,
        primaryPlanet: null,
        d27House: null,
        d27SignIndex: null,
        d27SignName: null,
        d27Nakshatra: null,
        amshaDevata: null,
        devataContext: '—',
        devataNote: 'D1+D3లో source-safe health trigger auto-match కాలేదు.',
        bodyRegion: null,
        locationType: 'No auto-trigger',
        natureSummary: 'D1+D3 primary organ listలో strong auto-match లేదు.',
        panchadhaRelation: '—',
        panchadhaStrength: 0,
        panchadhaStrengthPercent: 0,
        evidencePercent: 0,
        evidence: const <String>[],
        timingWindows: const <D27TimingWindow>[],
        organEvidence: const <D27OrganEvidence>[],
        kharaLayer: khara,
        remedy: const D27RemedyResult(planetRemedy: '—', dashaPair: '—', dashaRemedies: <String>[]),
      );
    }

    final primaryOrgan = organList.first;
    final primaryPlanetName = primaryOrgan.supportingPlanets.isNotEmpty
        ? primaryOrgan.supportingPlanets.first
        : primaryOrgan.planet;
    final natal = chart.planets.firstWhere((p) => p.name == primaryPlanetName);
    final primary = d27.planets.firstWhere((p) => p.name == primaryPlanetName);
    final primaryHouse = d27HouseFor(primary);
    final primaryD27Sign = primary.signIndex;
    final d27Long = VargaService.d27LongitudeForLongitude(natal.longitude);
    final nakIndex = (d27Long / (360.0 / 27.0)).floor().clamp(0, 26).toInt();
    final nakName = _nakshatras[nakIndex];

    final pStrength = strengthFor(primary.name);
    final panchadhaPercent = pStrength == null
        ? 0
        : ((pStrength.strength / 30.0) * 100).round().clamp(0, 100).toInt();

    final evidence = <String>[
      'D1+D3 organ match ${primaryOrgan.d1d3EvidencePercent}% ✓',
      if (primaryOrgan.d27StrengthPercent > 0) 'D27 strength confirmation ${primaryOrgan.d27StrengthPercent}% ✓',
      if (primaryOrgan.has22DLink) '22nd Drekkana direct organ link ✓',
      if (primaryOrgan.has64NLink) '64th Navamsa direct organ link ✓',
    ];
    final evidencePercent = primaryOrgan.finalEvidencePercent;

    final location = primaryOrgan.locationType;

    final natureBits = <String>[];
    final sameD27Sign = d27.planets.where((x) => x.signIndex == primary.signIndex).toList();
    if (sameD27Sign.any((p) => p.name == 'Saturn' || p.name == 'Rahu')) {
      natureBits.add('Chronic / దీర్ఘకాల tendency layer');
    }
    if (sameD27Sign.any((p) => p.name == 'Mars' || p.name == 'Ketu')) {
      natureBits.add('Surgery / intervention caution layer');
    }
    if (natureBits.isEmpty) natureBits.add('General health-stress indication');

    final segmentSize = 30.0 / 27.0;
    final natalSignIndex = natal.signIndex;
    final division = (natal.degreesInSign / segmentSize).floor().clamp(0, 26).toInt();
    final deityIndex = natalSignIndex.isEven ? division : 26 - division;
    final deity = _bhamsaDeities[deityIndex];

    final affectedNames = organList.expand((p) => p.supportingPlanets).toSet();
    final timing = _timingWindows(
      chart: chart,
      birthDateTime: birthDateTime,
      affectedPlanets: affectedNames,
      primaryPlanet: primary.name,
    );
    final remedy = _remedyFor(primary.name, timing.isEmpty ? null : timing.first);

    return D27HealthResult(
      hasAutoTrigger: true,
      primaryPlanet: primary.name,
      d27House: primaryHouse,
      d27SignIndex: primaryD27Sign,
      d27SignName: _signNames[primaryD27Sign],
      d27Nakshatra: nakName,
      amshaDevata: deity,
      devataContext: _devataContext(deity),
      devataNote: 'Bhamsa Devataను contextual modifierగా మాత్రమే చూపిస్తాం. Devata direct medical diagnosis కాదు.',
      bodyRegion: _regions[natal.signIndex],
      locationType: location,
      natureSummary: natureBits.join(' • '),
      panchadhaRelation: pStrength == null
          ? 'Rahu/Ketuకు user Panchadha tableలో score లేదు'
          : PanchadhaMaitriService.relationTelugu(pStrength.relationToSignLord),
      panchadhaStrength: pStrength?.strength ?? 0,
      panchadhaStrengthPercent: panchadhaPercent,
      evidencePercent: evidencePercent,
      evidence: evidence,
      timingWindows: timing,
      organEvidence: organList.take(8).toList(growable: false),
      kharaLayer: khara,
      remedy: remedy,
    );
  }

  static D27KharaLayer _kharaLayer(AstroChartResult chart) {
    // 22nd Drekkana: same Drekkana ordinal in the 8th rasi from Lagna.
    final ascDeg = chart.ascendantLongitude % 30.0;
    final targetRasi22 = (chart.ascendantSignIndex + 7) % 12;
    final targetD3Sign = VargaService.signForLongitude(targetRasi22 * 30.0 + ascDeg, 3);
    final d22Lord = _signLords[targetD3Sign];

    // 64th Navamsa from Moon: same navamsa ordinal in the 8th rasi from Moon.
    final moon = chart.planets.firstWhere((p) => p.name == 'Moon');
    final moonDeg = moon.degreesInSign;
    final targetRasi64 = (moon.signIndex + 7) % 12;
    final targetD9Sign = VargaService.signForLongitude(targetRasi64 * 30.0 + moonDeg, 9);
    final n64Lord = _signLords[targetD9Sign];

    final evidence = <String>[];
    if (_malefics.contains(d22Lord)) evidence.add('22nd Drekkana lord is natural malefic ✓');
    if (_malefics.contains(n64Lord)) evidence.add('64th Navamsa lord is natural malefic ✓');
    if (d22Lord == n64Lord) evidence.add('22D lord = 64N lord repeated Khara support ✓');
    final percent = ((evidence.length / 3) * 100).round().clamp(0, 100).toInt();
    return D27KharaLayer(
      drekkana22Lord: d22Lord,
      navamsa64Lord: n64Lord,
      evidencePercent: percent,
      evidence: evidence,
    );
  }

  static D27RemedyResult _remedyFor(String planet, D27TimingWindow? timing) {
    const planetRemedies = <String, String>{
      'Sun': 'Sunday • East • Red • Copper/Gold • Wheat • Ruby • Surya Japa',
      'Moon': 'Monday • North-West • White • Silver • Rice • Pearl • Chandra Japa',
      'Mars': 'Tuesday • South • Red • Mars mantra / propitiation',
      'Mercury': 'Wednesday • North • Green • Green gram • Emerald • Vishnu/Budha Japa',
      'Jupiter': 'Thursday • North-East • Yellow • Gold • Gram/curd rice • Yellow Topaz • Guru Japa',
      'Venus': 'Friday • South-East • White/multicolour • Silver • Rice with ghee • Diamond • Shukra Japa',
      'Saturn': 'Saturday • West • Blue • Iron • Sesame • Blue Sapphire • Shani Japa',
      'Rahu': 'South-West • Brown/smoky • Lead • Black gram • Rahu propitiation',
      'Ketu': 'South-West/North-West • Brown/smoky • Brass • Horse gram • Cat’s Eye • Ketu Japa',
    };
    const pairRemedies = <String, List<String>>{
      'Sun/Sun': ['Mrityunjaya Japa', 'Worship Sun God'],
      'Sun/Moon': ['White cow / female buffalo charity'],
      'Sun/Mars': ['Vedic mantra recitation', 'Mrityunjaya Japa'],
      'Sun/Rahu': ['Durga Saptashati / Durga mantra', 'Goat charity'],
      'Sun/Jupiter': ['Ishta Devata mantra', 'Gold / Kapila cow charity'],
      'Sun/Saturn': ['Mrityunjaya Japa', 'Black cow / female buffalo charity'],
      'Sun/Mercury': ['Vishnu Sahasranama', 'Silver and grains charity'],
      'Sun/Ketu': ['Durga mantra', 'Goat charity'],
      'Sun/Venus': ['Mrityunjaya Japa', 'Shiva Japa', 'White cow / female buffalo charity'],
      'Moon/Mercury': ['Vishnu Sahasranama', 'Goat charity'],
      'Moon/Rahu': ['Shiva mantra Japa', 'Goat charity'],
      'Moon/Jupiter': ['Shiva Sahasranama', 'Gold charity'],
      'Moon/Saturn': ['Mrityunjaya / Kali mantra', 'Cow or buffalo charity'],
      'Mars/Rahu': ['Naga Devata worship', 'Food to Brahmins', 'Mrityunjaya mantra'],
      'Mars/Jupiter': ['Shiva Sahasranama'],
      'Mars/Saturn': ['Mrityunjaya mantra'],
      'Mars/Mercury': ['Vishnu Sahasranama', 'Horse charity'],
      'Mars/Ketu': ['Mrityunjaya mantra'],
      'Jupiter/Jupiter': ['Vishnu Sahasranama', 'Rudra puja', 'Cow charity'],
      'Jupiter/Saturn': ['Vishnu Sahasranama', 'Black cow / female buffalo charity'],
      'Jupiter/Mercury': ['Vishnu Sahasranama'],
      'Jupiter/Ketu': ['Mrityunjaya Japa', 'Goat charity'],
      'Jupiter/Venus': ['White cow / female buffalo charity', 'Pious deeds'],
      'Jupiter/Sun': ['Aditya Hridaya Patha'],
      'Jupiter/Moon': ['Durga Saptashati'],
      'Jupiter/Mars': ['Bull charity'],
      'Saturn/Saturn': ['Mrityunjaya mantra'],
      'Saturn/Mercury': ['Vishnu Sahasranama', 'Food/grains charity'],
      'Saturn/Ketu': ['Goat charity'],
      'Saturn/Venus': ['Durga Saptashati', 'White cow / female buffalo charity'],
      'Saturn/Sun': ['Worship Sun God'],
      'Saturn/Moon': ['Sesame offering', 'Jaggery/ghee/rice charity', 'Black cow / female buffalo charity'],
      'Saturn/Mars': ['Havan', 'Buffalo charity'],
      'Saturn/Rahu': ['Mrityunjaya mantra', 'Goat charity'],
      'Mercury/Mercury': ['Vishnu Sahasranama'],
      'Mercury/Ketu': ['Goat charity'],
      'Mercury/Venus': ['Goddess Jagdamba mantra'],
      'Mercury/Sun': ['Shanti Patha'],
      'Mercury/Moon': ['Durga / Jagdamba worship', 'Clothes charity'],
      'Mercury/Mars': ['Mrityunjaya mantra to Shiva', 'Grain charity'],
      'Mercury/Rahu': ['Goddess Laxmi worship', 'Cow/buffalo charity'],
      'Mercury/Jupiter': ['Vishnu Sahasranama', 'Oil/gold charity'],
      'Ketu/Ketu': ['Durga Japa', 'Mrityunjaya Patha'],
      'Ketu/Venus': ['Durga Japa', 'Cow/buffalo charity'],
      'Ketu/Sun': ['Gold and cow charity'],
      'Ketu/Moon': ['Worship Moon'],
      'Ketu/Mars': ['Goat charity'],
      'Ketu/Rahu': ['Durga Japa'],
      'Ketu/Jupiter': ['Shiva Sahasranama', 'Mrityunjaya mantra'],
      'Ketu/Saturn': ['Sesame fire offering', 'Black cow / female buffalo charity'],
      'Ketu/Mercury': ['Vishnu Sahasranama'],
      'Venus/Venus': ['Durga Japa', 'Cow charity'],
      'Venus/Sun': ['Worship Sun God'],
      'Venus/Moon': ['Please Moon God'],
      'Venus/Mars': ['Bull charity'],
      'Venus/Rahu': ['Mrityunjaya mantra'],
      'Venus/Jupiter': ['Maha Mrityunjaya mantra'],
      'Venus/Saturn': ['Mrityunjaya mantra', 'Worship Durga'],
      'Venus/Mercury': ['Vishnu Sahasranama'],
      'Venus/Ketu': ['Mrityunjaya mantra', 'Goat charity'],
    };
    if (timing == null) {
      return D27RemedyResult(
        planetRemedy: planetRemedies[planet] ?? 'Source-backed planet remedy unavailable.',
        dashaPair: '—',
        dashaRemedies: const <String>[],
      );
    }
    final key = '${timing.mahadasha}/${timing.antardasha}';
    return D27RemedyResult(
      planetRemedy: planetRemedies[planet] ?? 'Source-backed planet remedy unavailable.',
      dashaPair: key,
      dashaRemedies: pairRemedies[key] ?? const <String>[],
    );
  }

  static String _devataContext(String deity) {
    if (deity.startsWith('Dasra')) return 'Healing / recovery symbolism — contextual modifier మాత్రమే.';
    if (deity == 'Yama') return 'Restraint, discipline, limitation symbolism — contextual modifier.';
    if (deity == 'Agni' || deity == 'Sakragni' || deity == 'Surya') return 'Heat, activation, intensity symbolism — contextual modifier.';
    if (deity == 'Chandra' || deity == 'Varuna') return 'Fluidity, nourishment, regulation symbolism — contextual modifier.';
    if (deity == 'Brahma' || deity == 'Tvashta') return 'Formation, structure, rebuilding symbolism — contextual modifier.';
    if (deity == 'Aditi' || deity == 'Mitra' || deity == 'Vishwadeva' || deity == 'Govinda' || deity == 'Pusha') return 'Support, protection, nourishment symbolism — contextual modifier.';
    if (deity == 'Jiva' || deity == 'Bhaga' || deity == 'Aryama' || deity == 'Vasu' || deity == 'Vasava') return 'Vitality/support/resource symbolism — contextual modifier.';
    if (deity == 'Marut') return 'Movement / air / circulation symbolism — contextual modifier.';
    if (deity == 'Ahi' || deity == 'Rakshasa' || deity == 'Ahirbudhnya') return 'Hidden/deep/intense symbolism — contextual modifier.';
    if (deity == 'Pitara') return 'Ancestral/hereditary symbolism — contextual modifier.';
    if (deity == 'Isha' || deity == 'Ajapa') return 'Transformation / restraint / inward-focus symbolism — contextual modifier.';
    return 'Contextual symbolic modifier మాత్రమే; direct medical mapping కాదు.';
  }

  static List<D27TimingWindow> _timingWindows({
    required AstroChartResult chart,
    required DateTime birthDateTime,
    required Set<String> affectedPlanets,
    required String primaryPlanet,
  }) {
    final system = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birthDateTime,
    );
    final out = <D27TimingWindow>[];

    for (final md in system.mahadashas) {
      final ads = DashaService.subPeriodsFor(system, md);
      for (final ad in ads) {
        var score = 0;
        final reasons = <String>[];
        if (affectedPlanets.contains(md.lord)) {
          score += 50;
          reasons.add('${md.lord} Mahadasha = affected D27 planet');
        }
        if (affectedPlanets.contains(ad.lord)) {
          score += 50;
          reasons.add('${ad.lord} Antardasha = affected D27 planet');
        }
        if (score == 0) continue;

        // Primary planet is not given extra percentage: it only breaks ties,
        // avoiding invented double-counting.
        final startAge = _ageAt(birthDateTime, ad.start);
        final endAge = _ageAt(birthDateTime, ad.end);
        if (endAge < 0 || startAge > 100) continue;
        out.add(
          D27TimingWindow(
            start: ad.start,
            end: ad.end,
            startAge: startAge < 0 ? 0 : startAge,
            endAge: endAge < 0 ? 0 : endAge,
            mahadasha: md.lord,
            antardasha: ad.lord,
            evidencePercent: score,
            matchedEvidence: reasons,
          ),
        );
      }
    }

    out.sort((a, b) {
      final score = b.evidencePercent.compareTo(a.evidencePercent);
      if (score != 0) return score;
      final aPrimary = a.mahadasha == primaryPlanet || a.antardasha == primaryPlanet;
      final bPrimary = b.mahadasha == primaryPlanet || b.antardasha == primaryPlanet;
      if (aPrimary != bPrimary) return bPrimary ? 1 : -1;
      return a.start.compareTo(b.start);
    });
    return out.take(8).toList(growable: false);
  }

  static int _ageAt(DateTime birth, DateTime date) {
    var age = date.year - birth.year;
    final beforeBirthday = date.month < birth.month ||
        (date.month == birth.month && date.day < birth.day);
    if (beforeBirthday) age--;
    return age;
  }
}
