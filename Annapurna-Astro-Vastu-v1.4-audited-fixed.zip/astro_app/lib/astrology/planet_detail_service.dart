import 'astro_models.dart';
import 'kp_service.dart';
import 'varga_service.dart';

class AmsaDevataDetail {
  final int rawPart;
  final int effectivePart;
  final String name;
  final String teluguName;
  final String nature;

  const AmsaDevataDetail({
    required this.rawPart,
    required this.effectivePart,
    required this.name,
    required this.teluguName,
    required this.nature,
  });
}

class VargaStrengthDetail {
  final int shadvargaja;
  final int saptavargaja;
  final int dashavargaja;
  final int shodashavargaja;
  final List<int> shadSupport;
  final List<int> saptaSupport;
  final List<int> dashaSupport;
  final List<int> shodashaSupport;
  final double shadVimsopaka;
  final double saptaVimsopaka;
  final double dashaVimsopaka;
  final double shodashaVimsopaka;

  const VargaStrengthDetail({
    required this.shadvargaja,
    required this.saptavargaja,
    required this.dashavargaja,
    required this.shodashavargaja,
    required this.shadSupport,
    required this.saptaSupport,
    required this.dashaSupport,
    required this.shodashaSupport,
    required this.shadVimsopaka,
    required this.saptaVimsopaka,
    required this.dashaVimsopaka,
    required this.shodashaVimsopaka,
  });
}

class PlanetTapDetail {
  final PlanetPosition planet;
  final KpStellarPosition kp;
  final AmsaDevataDetail amsaDevata;
  final VargaStrengthDetail vargaStrength;

  const PlanetTapDetail({
    required this.planet,
    required this.kp,
    required this.amsaDevata,
    required this.vargaStrength,
  });
}

class _D60Entry {
  final String name;
  final String teluguName;
  final String nature;

  const _D60Entry(this.name, this.teluguName, this.nature);
}

/// Planet tap details used by the Jataka / Varga screens.
///
/// - Star/Sub Lord: KP unequal Vimshottari subdivision already used by the app.
/// - Amsa Devata: BPHS D60/Shashtiamsa source rulebook supplied for this project.
/// - Vargaja/Vimsopaka: classical/JHora-compatible varga group arithmetic.
class PlanetDetailService {
  static const List<String> _planetOrder = [
    'Sun',
    'Moon',
    'Mars',
    'Mercury',
    'Jupiter',
    'Venus',
    'Saturn',
    'Rahu',
    'Ketu',
  ];

  // Standard sign lords in Aries..Pisces order.
  static const List<int> _signLords = [2, 5, 3, 1, 0, 3, 5, 2, 4, 6, 6, 4];

  // 5=own, 4=exalted, 3=friend, 2=neutral, 1=enemy, 0=debilitated.
  // Sun..Ketu rows; Aries..Pisces columns.
  static const List<List<int>> _houseStrengths = [
    [4, 1, 2, 2, 5, 2, 0, 3, 3, 1, 1, 3],
    [2, 4, 3, 5, 3, 3, 2, 0, 2, 2, 2, 2],
    [5, 2, 1, 0, 3, 1, 2, 5, 3, 4, 2, 3],
    [2, 3, 5, 1, 3, 5, 3, 2, 2, 2, 2, 0],
    [3, 1, 1, 4, 3, 1, 1, 3, 5, 0, 2, 5],
    [2, 5, 3, 1, 1, 0, 5, 2, 3, 3, 3, 4],
    [0, 3, 3, 1, 1, 3, 4, 1, 2, 5, 5, 2],
    [1, 4, 4, 1, 1, 3, 3, 0, 0, 3, 1, 3],
    [1, 0, 0, 1, 1, 3, 3, 4, 4, 3, 1, 3],
  ];

  static const List<int> _moolaTrikona = [4, 1, 0, 5, 8, 6, 10, 5, 11];

  // Natural relationship matrix: 3=friend, 2=neutral, 1=enemy.
  static const List<List<int>> _naturalRelations = [
    [5, 3, 3, 2, 3, 1, 1, 1, 2],
    [3, 5, 2, 3, 2, 2, 2, 2, 2],
    [3, 3, 5, 1, 3, 2, 2, 2, 2],
    [3, 1, 2, 5, 2, 3, 2, 2, 1],
    [3, 3, 3, 1, 5, 1, 2, 1, 2],
    [1, 1, 2, 3, 2, 5, 3, 3, 2],
    [1, 1, 1, 3, 2, 3, 5, 3, 1],
    [1, 1, 1, 2, 2, 3, 3, 5, 2],
    [3, 2, 3, 2, 2, 1, 1, 2, 5],
  ];

  static const Map<int, double> _shadWeights = {
    1: 6,
    2: 2,
    3: 4,
    9: 5,
    12: 2,
    30: 1,
  };

  static const Map<int, double> _saptaWeights = {
    1: 5,
    2: 2,
    3: 3,
    7: 1,
    9: 2.5,
    12: 4.5,
    30: 2,
  };

  static const Map<int, double> _dashaWeights = {
    1: 3,
    2: 1.5,
    3: 1.5,
    7: 1.5,
    9: 1.5,
    10: 1.5,
    12: 1.5,
    16: 1.5,
    30: 1.5,
    60: 5,
  };

  static const Map<int, double> _shodashaWeights = {
    1: 3.5,
    2: 1,
    3: 1,
    4: 0.5,
    7: 0.5,
    9: 3,
    10: 0.5,
    12: 0.5,
    16: 2,
    20: 0.5,
    24: 0.5,
    27: 0.5,
    30: 1,
    40: 0.5,
    45: 0.5,
    60: 4,
  };

  // D60/Shashtiamsa odd-sign order. Even signs reverse this order.
  static const List<_D60Entry> _d60 = [
    _D60Entry('Ghora', 'ఘోర', 'అశుభ'),
    _D60Entry('Rakshasa', 'రాక్షస', 'అశుభ'),
    _D60Entry('Deva', 'దేవ', 'శుభ'),
    _D60Entry('Kubera', 'కుబేర', 'శుభ'),
    _D60Entry('Yaksha', 'యక్ష', 'శుభ'),
    _D60Entry('Kinnara', 'కిన్నర', 'శుభ'),
    _D60Entry('Bhrashta', 'భ్రష్ట', 'అశుభ'),
    _D60Entry('Kulaghna', 'కులఘ్న', 'అశుభ'),
    _D60Entry('Garala', 'గరళ', 'అశుభ'),
    _D60Entry('Vahni', 'వహ్ని', 'అశుభ'),
    _D60Entry('Maya', 'మాయ', 'అశుభ'),
    _D60Entry('Purishaka', 'పురీషక', 'అశుభ'),
    _D60Entry('Apampati', 'అపాంపతి', 'శుభ'),
    _D60Entry('Marutwan', 'మరుత్వాన్', 'శుభ'),
    _D60Entry('Kala', 'కాల', 'అశుభ'),
    _D60Entry('Sarpa', 'సర్ప', 'అశుభ'),
    _D60Entry('Amrita', 'అమృత', 'శుభ'),
    _D60Entry('Indu', 'ఇందు', 'శుభ'),
    _D60Entry('Mridu', 'మృదు', 'శుభ'),
    _D60Entry('Komala', 'కోమల', 'శుభ'),
    _D60Entry('Heramba', 'హేరంబ', 'శుభ'),
    _D60Entry('Brahma', 'బ్రహ్మ', 'శుభ'),
    _D60Entry('Vishnu', 'విష్ణు', 'శుభ'),
    _D60Entry('Maheswara', 'మహేశ్వర', 'శుభ'),
    _D60Entry('Deva', 'దేవ', 'శుభ'),
    _D60Entry('Ardra', 'ఆర్ద్ర', 'శుభ'),
    _D60Entry('Kalinasa', 'కలినాశ', 'మిశ్రమ / గ్రంథభేదం'),
    _D60Entry('Kshiteesa', 'క్షితీశ', 'శుభ'),
    _D60Entry('Kamalakara', 'కమలాకర', 'శుభ'),
    _D60Entry('Gulika', 'గుళిక', 'అశుభ'),
    _D60Entry('Mrityu', 'మృత్యు', 'అశుభ'),
    _D60Entry('Kala', 'కాల', 'అశుభ'),
    _D60Entry('Davagni', 'దావాగ్ని', 'అశుభ'),
    _D60Entry('Ghora', 'ఘోర', 'అశుభ'),
    _D60Entry('Yama', 'యమ', 'అశుభ'),
    _D60Entry('Kantaka', 'కంటక', 'అశుభ'),
    _D60Entry('Sudha', 'సుధా', 'శుభ'),
    _D60Entry('Amrita', 'అమృత', 'శుభ'),
    _D60Entry('Poornachandra', 'పూర్ణచంద్ర', 'శుభ'),
    _D60Entry('Vishadagdha', 'విషదగ్ధ', 'అశుభ'),
    _D60Entry('Kulanasa', 'కులనాశ', 'అశుభ'),
    _D60Entry('Vamsakshaya', 'వంశక్షయ', 'అశుభ'),
    _D60Entry('Utpata', 'ఉత్పాత', 'అశుభ'),
    _D60Entry('Kala', 'కాల', 'అశుభ'),
    _D60Entry('Saumya', 'సౌమ్య', 'శుభ'),
    _D60Entry('Komala', 'కోమల', 'శుభ'),
    _D60Entry('Seetala', 'శీతల', 'శుభ'),
    _D60Entry('Karala Damshtra', 'కరాళదంష్ట్ర', 'అశుభ'),
    _D60Entry('Chandramukhi', 'చంద్రముఖి', 'శుభ / మిశ్రమ'),
    _D60Entry('Praveena', 'ప్రవీణ', 'శుభ'),
    _D60Entry('Kalapavaka', 'కాలపావక', 'అశుభ'),
    _D60Entry('Dandayudha', 'దండాయుధ', 'అశుభ / మిశ్రమ'),
    _D60Entry('Nirmala', 'నిర్మల', 'శుభ'),
    _D60Entry('Saumya', 'సౌమ్య', 'శుభ'),
    _D60Entry('Kroora', 'క్రూర', 'అశుభ'),
    _D60Entry('Atiseetala', 'అతిశీతల', 'అశుభ / మిశ్రమ'),
    _D60Entry('Amrita', 'అమృత', 'శుభ'),
    _D60Entry('Payodhi', 'పయోధి', 'మిశ్రమ'),
    _D60Entry('Bhramana', 'భ్రమణ', 'మిశ్రమ'),
    _D60Entry('Chandrarekha / Indurekha', 'చంద్రరేఖ / ఇందురేఖ', 'మూల పాఠ్య designation'),
  ];

  static PlanetTapDetail forPlanet(AstroChartResult chart, PlanetPosition planet) {
    return PlanetTapDetail(
      planet: planet,
      kp: KpService.forLongitude(planet.name, planet.longitude),
      amsaDevata: _amsaDevata(planet),
      vargaStrength: _vargaStrength(chart, planet),
    );
  }

  static AmsaDevataDetail _amsaDevata(PlanetPosition planet) {
    final within = planet.degreesInSign;
    var raw = (within * 2.0).floor() + 1;
    if (raw < 1) raw = 1;
    if (raw > 60) raw = 60;

    // Zero-based even index = odd zodiac sign (Aries=1, Gemini=3...).
    final oddSign = planet.signIndex.isEven;
    final effective = oddSign ? raw : 61 - raw;
    final entry = _d60[effective - 1];
    return AmsaDevataDetail(
      rawPart: raw,
      effectivePart: effective,
      name: entry.name,
      teluguName: entry.teluguName,
      nature: entry.nature,
    );
  }

  static VargaStrengthDetail _vargaStrength(
    AstroChartResult chart,
    PlanetPosition planet,
  ) {
    final p = _planetOrder.indexOf(planet.name);
    if (p < 0) {
      return const VargaStrengthDetail(
        shadvargaja: 0,
        saptavargaja: 0,
        dashavargaja: 0,
        shodashavargaja: 0,
        shadSupport: [],
        saptaSupport: [],
        dashaSupport: [],
        shodashaSupport: [],
        shadVimsopaka: 0,
        saptaVimsopaka: 0,
        dashaVimsopaka: 0,
        shodashaVimsopaka: 0,
      );
    }

    final shad = _supportingVargas(planet, p, _shadWeights.keys);
    final sapta = _supportingVargas(planet, p, _saptaWeights.keys);
    final dasha = _supportingVargas(planet, p, _dashaWeights.keys);
    final shodasha = _supportingVargas(planet, p, _shodashaWeights.keys);

    return VargaStrengthDetail(
      shadvargaja: shad.length,
      saptavargaja: sapta.length,
      dashavargaja: dasha.length,
      shodashavargaja: shodasha.length,
      shadSupport: shad,
      saptaSupport: sapta,
      dashaSupport: dasha,
      shodashaSupport: shodasha,
      shadVimsopaka: _vimsopaka(chart, planet, p, _shadWeights),
      saptaVimsopaka: _vimsopaka(chart, planet, p, _saptaWeights),
      dashaVimsopaka: _vimsopaka(chart, planet, p, _dashaWeights),
      shodashaVimsopaka: _vimsopaka(chart, planet, p, _shodashaWeights),
    );
  }

  static List<int> _supportingVargas(
    PlanetPosition planet,
    int planetIndex,
    Iterable<int> factors,
  ) {
    final out = <int>[];
    for (final factor in factors) {
      final sign = VargaService.signForLongitude(planet.longitude, factor);
      final dignity = _houseStrengths[planetIndex][sign];
      if (sign == _moolaTrikona[planetIndex] || dignity > 3) {
        out.add(factor);
      }
    }
    return out;
  }

  static double _vimsopaka(
    AstroChartResult chart,
    PlanetPosition planet,
    int planetIndex,
    Map<int, double> weights,
  ) {
    var total = 0.0;
    for (final entry in weights.entries) {
      final sign = VargaService.signForLongitude(planet.longitude, entry.key);
      final dignity = _houseStrengths[planetIndex][sign];
      final viswa = dignity == 5
          ? 20.0
          : _relationshipViswa(chart, planetIndex, _signLords[sign]);
      total += entry.value * viswa / 20.0;
    }
    return total;
  }

  static double _relationshipViswa(
    AstroChartResult chart,
    int planetIndex,
    int signLordIndex,
  ) {
    if (planetIndex == signLordIndex) return 20.0;

    final pSign = _planetSign(chart, planetIndex);
    final lordSign = _planetSign(chart, signLordIndex);
    final offset = (lordSign - pSign + 12) % 12;
    final temporaryFriend = const [1, 2, 3, 9, 10, 11].contains(offset);
    final natural = _naturalRelations[planetIndex][signLordIndex];

    // Compound relationship score index: 0=great enemy, 1=enemy,
    // 2=neutral, 3=friend, 4=great friend.
    int compoundIndex;
    if (natural == 3 && temporaryFriend) {
      compoundIndex = 4;
    } else if ((natural == 3 && !temporaryFriend) ||
        (natural == 1 && temporaryFriend)) {
      compoundIndex = 2;
    } else if (natural == 2 && temporaryFriend) {
      compoundIndex = 3;
    } else if (natural == 2 && !temporaryFriend) {
      compoundIndex = 1;
    } else {
      compoundIndex = 0;
    }

    const values = [5.0, 7.0, 10.0, 15.0, 18.0];
    return values[compoundIndex];
  }

  static int _planetSign(AstroChartResult chart, int index) {
    final name = _planetOrder[index];
    return chart.planets.firstWhere((p) => p.name == name).signIndex;
  }
}
