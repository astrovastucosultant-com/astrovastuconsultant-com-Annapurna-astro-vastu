import 'astro_models.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';

enum JaiminiCharaMethod { methodA, methodB, custom }

enum JaiminiCoLordChoice { autoSource, primary, node }

extension JaiminiCharaMethodLabel on JaiminiCharaMethod {
  String get label => switch (this) {
        JaiminiCharaMethod.methodA => 'Method A — Odd/Even',
        JaiminiCharaMethod.methodB => 'Method B — Vishama/Sama',
        JaiminiCharaMethod.custom => 'Custom',
      };
}

extension JaiminiCoLordChoiceLabel on JaiminiCoLordChoice {
  String get label => switch (this) {
        JaiminiCoLordChoice.autoSource => 'Auto • source rules',
        JaiminiCoLordChoice.primary => 'Primary lord only',
        JaiminiCoLordChoice.node => 'Node co-lord',
      };
}

class JaiminiCharaConfig {
  final JaiminiCharaMethod method;
  final int customStartSignIndex;
  final bool customForward;
  final double selfSignYears;
  final JaiminiCoLordChoice scorpioLordChoice;
  final JaiminiCoLordChoice aquariusLordChoice;

  const JaiminiCharaConfig({
    this.method = JaiminiCharaMethod.methodB,
    this.customStartSignIndex = 0,
    this.customForward = true,
    this.selfSignYears = 12,
    this.scorpioLordChoice = JaiminiCoLordChoice.autoSource,
    this.aquariusLordChoice = JaiminiCoLordChoice.autoSource,
  });

  JaiminiCharaConfig copyWith({
    JaiminiCharaMethod? method,
    int? customStartSignIndex,
    bool? customForward,
    double? selfSignYears,
    JaiminiCoLordChoice? scorpioLordChoice,
    JaiminiCoLordChoice? aquariusLordChoice,
  }) {
    return JaiminiCharaConfig(
      method: method ?? this.method,
      customStartSignIndex: customStartSignIndex ?? this.customStartSignIndex,
      customForward: customForward ?? this.customForward,
      selfSignYears: selfSignYears ?? this.selfSignYears,
      scorpioLordChoice: scorpioLordChoice ?? this.scorpioLordChoice,
      aquariusLordChoice: aquariusLordChoice ?? this.aquariusLordChoice,
    );
  }
}

class JaiminiCharaAntardasha {
  final int signIndex;
  final DateTime start;
  final DateTime end;
  final double years;

  const JaiminiCharaAntardasha({
    required this.signIndex,
    required this.start,
    required this.end,
    required this.years,
  });

  bool contains(DateTime dt) => !dt.isBefore(start) && dt.isBefore(end);
}

class JaiminiCharaMahadasha {
  final int signIndex;
  final DateTime start;
  final DateTime end;
  final double years;
  final String selectedLord;
  final int lordSignIndex;
  final bool countForward;
  final String calculationReason;
  final List<String> sourceRuleIds;
  final List<JaiminiCharaAntardasha> antardashas;

  const JaiminiCharaMahadasha({
    required this.signIndex,
    required this.start,
    required this.end,
    required this.years,
    required this.selectedLord,
    required this.lordSignIndex,
    required this.countForward,
    required this.calculationReason,
    required this.sourceRuleIds,
    required this.antardashas,
  });

  bool contains(DateTime dt) => !dt.isBefore(start) && dt.isBefore(end);
}

class JaiminiCharaDashaResult {
  final JaiminiCharaConfig config;
  final int startSignIndex;
  final bool sequenceForward;
  final List<JaiminiCharaMahadasha> mahadashas;
  final String sourceNote;

  const JaiminiCharaDashaResult({
    required this.config,
    required this.startSignIndex,
    required this.sequenceForward,
    required this.mahadashas,
    required this.sourceNote,
  });

  JaiminiCharaMahadasha? mahadashaAt(DateTime dt) {
    for (final p in mahadashas) {
      if (p.contains(dt)) return p;
    }
    return null;
  }

  JaiminiCharaAntardasha? antardashaAt(DateTime dt) {
    final md = mahadashaAt(dt);
    if (md == null) return null;
    for (final ad in md.antardashas) {
      if (ad.contains(dt)) return ad;
    }
    return null;
  }
}

class JaiminiEventRuleCheck {
  final String ruleId;
  final String condition;
  final bool matched;
  final String reason;
  final String source;
  final String remedy;

  const JaiminiEventRuleCheck({
    required this.ruleId,
    required this.condition,
    required this.matched,
    required this.reason,
    required this.source,
    required this.remedy,
  });
}

class JaiminiScoreComponent {
  final String label;
  final int maxScore;
  final int awardedScore;
  final bool matched;
  final String reason;
  final List<String> ruleIds;

  const JaiminiScoreComponent({
    required this.label,
    required this.maxScore,
    required this.awardedScore,
    required this.matched,
    required this.reason,
    required this.ruleIds,
  });
}

class JaiminiEventScore {
  final String eventKey;
  final String eventTitle;
  final int score;
  final String band;
  final String summary;
  final List<JaiminiEventRuleCheck> ruleChecks;
  final List<JaiminiScoreComponent> components;

  const JaiminiEventScore({
    required this.eventKey,
    required this.eventTitle,
    required this.score,
    required this.band,
    required this.summary,
    required this.ruleChecks,
    required this.components,
  });
}

class JaiminiCharaDashaService {
  static const double _daysPerYear = 365.2425;

  static const Map<String, String> eventTitles = {
    'marriage': 'వివాహం / భాగస్వామ్యం',
    'career': 'వృత్తి / ఉద్యోగం / వ్యాపారం',
    'children': 'సంతానం',
    'property': 'స్థిరాస్తి / ఇల్లు / వాహనం',
    'wealth': 'ధనం / లాభం',
    'education': 'విద్య / ఉన్నత విద్య',
    'foreign': 'విదేశీ ప్రయాణం / నివాసం',
  };

  static const Map<String, List<String>> _eventRuleIds = {
    'marriage': ['M-01', 'M-02', 'M-03', 'M-04', 'M-05', 'M-06'],
    'career': ['C-01', 'C-02', 'C-03', 'C-04', 'C-05'],
    'children': ['CH-01', 'CH-02', 'CH-03', 'CH-04'],
    'wealth': ['W-01', 'W-02', 'W-03', 'W-04'],
    'property': ['P-01', 'P-02', 'P-03'],
    'education': ['E-01', 'E-02', 'E-03'],
    'foreign': ['F-01', 'F-02', 'F-03'],
  };

  static const Map<String, List<String>> _eventKeywords = {
    'marriage': ['వివాహ', 'సంబంధ', 'spouse', 'darapada', 'upapada', 'దాంపత్య'],
    'career': ['వృత్తి', 'సేవ', 'ప్రతిష్ఠ', 'స్థానం', 'వ్యాపార', 'career'],
    'children': ['సంతానం', 'children', 'putra'],
    'property': ['ఇల్లు', 'స్థిరాస్తి', 'నివాస', 'సౌఖ్యం', 'property'],
    'wealth': ['ధనం', 'లాభ', 'సంపద', 'ఆర్థిక', 'wealth'],
    'education': ['విద్య', 'పాండిత్యం', 'శాస్త్ర', 'బుద్ధి', 'education'],
    'foreign': ['విదేశ', 'foreign', 'ప్రయాణ', 'residence'],
  };

  static JaiminiCharaDashaResult calculate({
    required AstroChartResult chart,
    required DateTime birthDateTime,
    JaiminiCharaConfig config = const JaiminiCharaConfig(),
  }) {
    final startSign = config.method == JaiminiCharaMethod.custom
        ? config.customStartSignIndex.clamp(0, 11).toInt()
        : chart.ascendantSignIndex;
    final sequenceForward = _sequenceForward(startSign, config);
    final signSequence = List<int>.generate(
      12,
      (i) => (startSign + (sequenceForward ? i : -i) + 120) % 12,
      growable: false,
    );

    var cursor = birthDateTime;
    final periods = <JaiminiCharaMahadasha>[];
    for (final sign in signSequence) {
      final calc = _yearsForSign(chart: chart, sign: sign, config: config);
      final end = _addYears(cursor, calc.years);
      final ads = _buildAntardashas(
        mahadashaSign: sign,
        start: cursor,
        end: end,
        years: calc.years,
        config: config,
      );
      periods.add(
        JaiminiCharaMahadasha(
          signIndex: sign,
          start: cursor,
          end: end,
          years: calc.years,
          selectedLord: calc.lord,
          lordSignIndex: calc.lordSign,
          countForward: calc.forward,
          calculationReason: calc.reason,
          sourceRuleIds: calc.ruleIds,
          antardashas: ads,
        ),
      );
      cursor = end;
    }

    return JaiminiCharaDashaResult(
      config: config,
      startSignIndex: startSign,
      sequenceForward: sequenceForward,
      mahadashas: List<JaiminiCharaMahadasha>.unmodifiable(periods),
      sourceNote:
          'CD-01–CD-07 source-controlled engine. Method A = ordinary odd/even direction; Method B = supplied Vishama/Sama + special-direction variant; Custom exposes start/direction/self-sign/co-lord choices. Dasa years use sign-to-lord count, own-sign duration, +1 exaltation / −1 debilitation and source-controlled Scorpio/Aquarius co-lords.',
    );
  }

  static DateTime _addYears(DateTime start, double years) {
    final rounded = years.round();
    if ((years - rounded).abs() < 1e-9) {
      // Chara Dasha source durations are normally whole years. Keep whole-year
      // periods on the same civil calendar date instead of accumulating a
      // 365.2425-day approximation drift across Mahadashas.
      return DateTime(
        start.year + rounded,
        start.month,
        start.day,
        start.hour,
        start.minute,
        start.second,
        start.millisecond,
        start.microsecond,
      );
    }
    return start.add(
      Duration(seconds: (years * _daysPerYear * 86400).round()),
    );
  }

  static bool _sequenceForward(int sign, JaiminiCharaConfig config) {
    if (config.method == JaiminiCharaMethod.custom) return config.customForward;
    if (config.method == JaiminiCharaMethod.methodA) {
      // Ordinary odd/even zodiac grouping used as a selectable variant.
      return const {0, 2, 4, 6, 8, 10}.contains(sign);
    }
    // Supplied Chara-Dasha Vishama/Sama grouping. Source notes special
    // direction treatment for Taurus/Scorpio and Leo/Aquarius.
    if (sign == 1 || sign == 7) return true;
    if (sign == 4 || sign == 10) return false;
    return const {0, 1, 2, 6, 7, 8}.contains(sign);
  }

  static bool _countForward(int sign, JaiminiCharaConfig config) {
    if (config.method == JaiminiCharaMethod.custom) return config.customForward;
    if (config.method == JaiminiCharaMethod.methodA) {
      return const {0, 2, 4, 6, 8, 10}.contains(sign);
    }
    if (sign == 1 || sign == 7) return true;
    if (sign == 4 || sign == 10) return false;
    return const {0, 1, 2, 6, 7, 8}.contains(sign);
  }

  static ({
    String lord,
    int lordSign,
    double years,
    bool forward,
    String reason,
    List<String> ruleIds,
  }) _yearsForSign({
    required AstroChartResult chart,
    required int sign,
    required JaiminiCharaConfig config,
  }) {
    final forward = _countForward(sign, config);
    final selected = _selectLord(chart, sign, config);
    final lordSign = chart.planets.firstWhere((p) => p.name == selected.lord).signIndex;

    if (selected.bothCoLordsTogetherInOwnSign) {
      return (
        lord: selected.lord,
        lordSign: lordSign,
        years: config.selfSignYears,
        forward: forward,
        reason:
            'Co-lords source case: both co-lords own signలో కలిసి ఉన్నందున self-sign duration ${config.selfSignYears.toStringAsFixed(0)} years.',
        ruleIds: const ['CD-03', 'CD-04', 'CD-05'],
      );
    }

    if (lordSign == sign) {
      return (
        lord: selected.lord,
        lordSign: lordSign,
        years: config.selfSignYears,
        forward: forward,
        reason:
            '${selected.reason} Lord own signలో ఉన్నందున self-sign duration ${config.selfSignYears.toStringAsFixed(0)} years.',
        ruleIds: const ['CD-03', 'CD-04', 'CD-05'],
      );
    }

    final raw = forward
        ? (lordSign - sign + 12) % 12
        : (sign - lordSign + 12) % 12;
    var years = raw == 0 ? config.selfSignYears : raw.toDouble();
    final adjustment = _dignityAdjustment(selected.lord, lordSign);
    years += adjustment;
    if (years < 1) years = 1;

    final adjText = adjustment > 0
        ? ' +1 exaltation'
        : adjustment < 0
            ? ' −1 debilitation'
            : '';
    return (
      lord: selected.lord,
      lordSign: lordSign,
      years: years,
      forward: forward,
      reason:
          '${selected.reason} ${forward ? 'forward' : 'reverse'} count: sign ${sign + 1} → lord sign ${lordSign + 1} = $raw years$adjText ⇒ ${years.toStringAsFixed(years == years.roundToDouble() ? 0 : 2)} years.',
      ruleIds: const ['CD-02', 'CD-03', 'CD-04', 'CD-05'],
    );
  }

  static ({String lord, String reason, bool bothCoLordsTogetherInOwnSign}) _selectLord(
    AstroChartResult chart,
    int sign,
    JaiminiCharaConfig config,
  ) {
    if (sign != 7 && sign != 10) {
      return (
        lord: _primaryLord(sign),
        reason: 'Single-lord sign.',
        bothCoLordsTogetherInOwnSign: false,
      );
    }

    final primary = sign == 7 ? 'Mars' : 'Saturn';
    final node = sign == 7 ? 'Ketu' : 'Rahu';
    final choice = sign == 7 ? config.scorpioLordChoice : config.aquariusLordChoice;
    if (choice == JaiminiCoLordChoice.primary) {
      return (
        lord: primary,
        reason: 'Config: $primary-only co-lord variant.',
        bothCoLordsTogetherInOwnSign: false,
      );
    }
    if (choice == JaiminiCoLordChoice.node) {
      return (
        lord: node,
        reason: 'Config: $node co-lord selected.',
        bothCoLordsTogetherInOwnSign: false,
      );
    }

    final p = chart.planets.firstWhere((x) => x.name == primary);
    final n = chart.planets.firstWhere((x) => x.name == node);
    if (p.signIndex == sign && n.signIndex == sign) {
      return (
        lord: primary,
        reason: 'Auto source: both co-lords own sign together.',
        bothCoLordsTogetherInOwnSign: true,
      );
    }
    if (p.signIndex == sign && n.signIndex != sign) {
      return (
        lord: node,
        reason: 'Auto source: one co-lord is in own sign; use the other co-lord.',
        bothCoLordsTogetherInOwnSign: false,
      );
    }
    if (n.signIndex == sign && p.signIndex != sign) {
      return (
        lord: primary,
        reason: 'Auto source: one co-lord is in own sign; use the other co-lord.',
        bothCoLordsTogetherInOwnSign: false,
      );
    }
    if (p.signIndex == n.signIndex) {
      return (
        lord: primary,
        reason:
            'Auto source: co-lords are together outside own sign; destination sign is identical. Primary lord is retained for audit identity.',
        bothCoLordsTogetherInOwnSign: false,
      );
    }

    final pAdj = _dignityAdjustment(primary, p.signIndex);
    final nAdj = _dignityAdjustment(node, n.signIndex);
    if (pAdj != nAdj) {
      final pickPrimary = pAdj > nAdj;
      return (
        lord: pickPrimary ? primary : node,
        reason:
            'Auto source: different signs; explicit exaltation/debilitation condition resolves the stronger co-lord.',
        bothCoLordsTogetherInOwnSign: false,
      );
    }

    // The supplied source says to compare association/rashi strength when the
    // two co-lords are otherwise unresolved. The app does not invent a numeric
    // rashi-strength coefficient here. It uses the primary lord as a stable
    // fallback and makes the unresolved strength step visible in the audit.
    return (
      lord: primary,
      reason:
          'Auto source: co-lord strength tie is not numerically resolved by the supplied source; primary lord fallback used. Choose Primary/Node manually in Custom review if required.',
      bothCoLordsTogetherInOwnSign: false,
    );
  }

  static List<JaiminiCharaAntardasha> _buildAntardashas({
    required int mahadashaSign,
    required DateTime start,
    required DateTime end,
    required double years,
    required JaiminiCharaConfig config,
  }) {
    final forward = _countForward(mahadashaSign, config);
    final totalMicros = end.difference(start).inMicroseconds;
    final out = <JaiminiCharaAntardasha>[];
    for (var i = 0; i < 12; i++) {
      final adStart = start.add(Duration(microseconds: (totalMicros * i / 12).round()));
      final adEnd = i == 11
          ? end
          : start.add(Duration(microseconds: (totalMicros * (i + 1) / 12).round()));
      final sign = (mahadashaSign + (forward ? i : -i) + 120) % 12;
      out.add(
        JaiminiCharaAntardasha(
          signIndex: sign,
          start: adStart,
          end: adEnd,
          years: years / 12.0,
        ),
      );
    }
    return List<JaiminiCharaAntardasha>.unmodifiable(out);
  }

  static String _primaryLord(int signIndex) => switch (signIndex) {
        0 => 'Mars',
        1 => 'Venus',
        2 => 'Mercury',
        3 => 'Moon',
        4 => 'Sun',
        5 => 'Mercury',
        6 => 'Venus',
        7 => 'Mars',
        8 => 'Jupiter',
        9 => 'Saturn',
        10 => 'Saturn',
        11 => 'Jupiter',
        _ => throw ArgumentError('Invalid sign index: $signIndex'),
      };

  static double _dignityAdjustment(String planet, int sign) {
    const exaltation = <String, int>{
      'Sun': 0,
      'Moon': 1,
      'Mars': 9,
      'Mercury': 5,
      'Jupiter': 3,
      'Venus': 11,
      'Saturn': 6,
    };
    const debilitation = <String, int>{
      'Sun': 6,
      'Moon': 7,
      'Mars': 3,
      'Mercury': 11,
      'Jupiter': 9,
      'Venus': 5,
      'Saturn': 0,
    };
    if (exaltation[planet] == sign) return 1;
    if (debilitation[planet] == sign) return -1;
    return 0;
  }

  static bool _isOwnOrExalted(String planet, int sign) {
    if (_dignityAdjustment(planet, sign) > 0) return true;
    final ownSigns = <String, Set<int>>{
      'Sun': {4},
      'Moon': {3},
      'Mars': {0, 7},
      'Mercury': {2, 5},
      'Jupiter': {8, 11},
      'Venus': {1, 6},
      'Saturn': {9, 10},
    };
    return ownSigns[planet]?.contains(sign) ?? false;
  }

  static JaiminiEventScore scoreEvent({
    required String eventKey,
    required DateTime at,
    required AstroChartResult chart,
    required JaiminiResult jaimini,
    required JaiminiCharaDashaResult dasha,
  }) {
    final title = eventTitles[eventKey] ?? eventKey;
    final md = dasha.mahadashaAt(at);
    final ad = dasha.antardashaAt(at);
    if (md == null || ad == null) {
      return JaiminiEventScore(
        eventKey: eventKey,
        eventTitle: title,
        score: 0,
        band: 'Weak',
        summary: 'ఈ తేదీ Chara Dasha calendar range బయట ఉంది.',
        ruleChecks: const [],
        components: const [],
      );
    }

    final refs = _eventReferences(eventKey, chart, jaimini);
    final eventRules = _eventRuleChecks(
      eventKey: eventKey,
      chart: chart,
      jaimini: jaimini,
      mdSign: md.signIndex,
      adSign: ad.signIndex,
      references: refs,
    );

    final mdMatch = refs.relevantSigns.contains(md.signIndex);
    final adMatch = refs.relevantSigns.contains(ad.signIndex);
    final karakaMatch = refs.karakaPlanets.any((name) {
      final p = chart.planets.where((x) => x.name == name).toList();
      if (p.isEmpty) return false;
      final sign = p.first.signIndex;
      return sign == md.signIndex || sign == ad.signIndex ||
          refs.relevantSigns.any((target) => _rashiDrishtiTargets(sign).contains(target));
    });
    final arudhaMatch = refs.arudhaSigns.contains(md.signIndex) || refs.arudhaSigns.contains(ad.signIndex);
    final drishtiMatch = refs.relevantSigns.any((target) {
      return _rashiDrishtiTargets(md.signIndex).contains(target) ||
          _rashiDrishtiTargets(ad.signIndex).contains(target) ||
          _rashiDrishtiTargets(target).contains(md.signIndex) ||
          _rashiDrishtiTargets(target).contains(ad.signIndex);
    });
    final mdLordSign = chart.planets.firstWhere((p) => p.name == md.selectedLord).signIndex;
    final adLord = _primaryLord(ad.signIndex);
    final adLordPos = chart.planets.where((p) => p.name == adLord).toList();
    final lordStrength = _isOwnOrExalted(md.selectedLord, mdLordSign) ||
        (adLordPos.isNotEmpty && _isOwnOrExalted(adLord, adLordPos.first.signIndex));
    final vargaMatch = _vargaConfirmation(eventKey, chart, jaimini);
    final firstSevenMatches = [
      mdMatch,
      adMatch,
      karakaMatch,
      arudhaMatch,
      drishtiMatch,
      lordStrength,
      vargaMatch,
    ].where((x) => x).length;
    final repeated = firstSevenMatches >= 3 || eventRules.where((r) => r.matched).length >= 2;

    JaiminiScoreComponent comp(
      String label,
      int max,
      bool matched,
      String reason,
      List<String> ruleIds,
    ) =>
        JaiminiScoreComponent(
          label: label,
          maxScore: max,
          awardedScore: matched ? max : 0,
          matched: matched,
          reason: reason,
          ruleIds: List<String>.unmodifiable(ruleIds),
        );

    final components = <JaiminiScoreComponent>[
      comp('Mahadasha sign', 20, mdMatch,
          'MD sign ${md.signIndex + 1}${mdMatch ? ' event referenceతో match అయింది.' : ' event referenceతో match కాలేదు.'}',
          [eventRules.isEmpty ? 'APP-MD' : eventRules.first.ruleId]),
      comp('Antardasha', 15, adMatch,
          'AD sign ${ad.signIndex + 1}${adMatch ? ' event referenceతో match అయింది.' : ' event referenceతో match కాలేదు.'}',
          [eventRules.length > 1 ? eventRules[1].ruleId : 'APP-AD']),
      comp('Relevant Karaka', 15, karakaMatch,
          '${refs.karakaPlanets.join(', ')} activation / rashi-drishti cross-check.',
          eventRules.map((r) => r.ruleId).take(2).toList()),
      comp('Arudha / UL', 15, arudhaMatch,
          'Event Arudha references: ${refs.arudhaSigns.map((s) => s + 1).join(', ')}.',
          eventRules.map((r) => r.ruleId).take(3).toList()),
      comp('Rashi Drishti', 10, drishtiMatch,
          'Active MD/AD signs మరియు event reference signs మధ్య Jaimini rashi-drishti check.',
          const ['J1Q1-R1.1']),
      comp('Sign-lord strength', 10, lordStrength,
          'MD/AD sign-lord own/exaltation source-strength layer.',
          const ['J1Q1-R5.3', 'J1Q1-R5.4']),
      comp('Varga confirmation', 10, vargaMatch,
          '${refs.vargaCode}లో event-relevant karaka/natural significator kendra/trikona cross-check.',
          eventRules.map((r) => r.ruleId).skip(2).take(2).toList()),
      comp('Repeated confirmation', 5, repeated,
          'మూడు లేదా అంతకంటే ఎక్కువ independent evidence layers / రెండు source event rules match అయితే confirmation.',
          eventRules.where((r) => r.matched).map((r) => r.ruleId).toList()),
    ];

    final score = components.fold<int>(0, (sum, c) => sum + c.awardedScore);
    final band = _band(score);
    final matchedRules = eventRules.where((r) => r.matched).length;
    return JaiminiEventScore(
      eventKey: eventKey,
      eventTitle: title,
      score: score,
      band: band,
      summary:
          '$title — app decision-support score $score/100 ($band). MD ${md.signIndex + 1} / AD ${ad.signIndex + 1}; source event rules matched $matchedRules/${eventRules.length}. ఇది classical probability కాదు.',
      ruleChecks: List<JaiminiEventRuleCheck>.unmodifiable(eventRules),
      components: List<JaiminiScoreComponent>.unmodifiable(components),
    );
  }

  static String _band(int score) {
    if (score >= 85) return 'Very Strong';
    if (score >= 70) return 'Strong';
    if (score >= 50) return 'Moderate';
    if (score >= 30) return 'Possible';
    return 'Weak';
  }

  static ({
    Set<int> relevantSigns,
    Set<int> arudhaSigns,
    Set<String> karakaPlanets,
    String vargaCode,
  }) _eventReferences(
    String eventKey,
    AstroChartResult chart,
    JaiminiResult jaimini,
  ) {
    int p(int number) => jaimini.arudhaPadas
        .firstWhere((x) => x.padaNumber == number)
        .padaSignIndex;
    String? karaka(String code) {
      final rows = jaimini.charaKarakas.where((k) => k.code == code).toList();
      return rows.isEmpty ? null : rows.first.planet;
    }

    final lagna = chart.ascendantSignIndex;
    final kc = jaimini.karakamsaSignIndex;
    final relevant = <int>{};
    final arudhas = <int>{};
    final karakas = <String>{};
    var varga = 'D1';

    switch (eventKey) {
      case 'marriage':
        relevant.addAll({(lagna + 6) % 12, p(7), p(12), (kc + 6) % 12});
        arudhas.addAll({p(7), p(12)});
        final dk = karaka('DK');
        if (dk != null) karakas.add(dk);
        karakas.add('Venus');
        varga = 'D9';
        break;
      case 'career':
        relevant.addAll({(lagna + 9) % 12, p(10), (kc + 9) % 12});
        arudhas.add(p(10));
        final amk = karaka('AmK');
        if (amk != null) karakas.add(amk);
        karakas.addAll({'Sun', 'Saturn', 'Mercury'});
        varga = 'D10';
        break;
      case 'children':
        relevant.addAll({(lagna + 4) % 12, p(5), (kc + 4) % 12, (kc + 8) % 12});
        arudhas.add(p(5));
        final pk = karaka('PK');
        if (pk != null) karakas.add(pk);
        karakas.add('Jupiter');
        varga = 'D7';
        break;
      case 'property':
        relevant.addAll({(lagna + 3) % 12, p(4), (kc + 3) % 12});
        arudhas.add(p(4));
        karakas.addAll({'Mars', 'Venus'});
        varga = 'D4';
        break;
      case 'wealth':
        relevant.addAll({(lagna + 1) % 12, (lagna + 10) % 12, p(2), p(11), p(1)});
        arudhas.addAll({p(1), p(2), p(11)});
        karakas.addAll({'Jupiter', 'Mercury', 'Venus'});
        varga = 'D2';
        break;
      case 'education':
        relevant.addAll({(lagna + 4) % 12, (lagna + 8) % 12, p(5), p(9), (kc + 1) % 12, (kc + 4) % 12});
        arudhas.addAll({p(5), p(9)});
        karakas.addAll({'Mercury', 'Jupiter'});
        varga = 'D24';
        break;
      case 'foreign':
        relevant.addAll({(lagna + 11) % 12, p(12), (kc + 11) % 12});
        arudhas.add(p(12));
        karakas.addAll({'Rahu', 'Ketu', 'Moon'});
        varga = 'D4';
        break;
      default:
        relevant.add(lagna);
        arudhas.add(p(1));
        karakas.add(jaimini.atmakaraka);
    }

    return (
      relevantSigns: relevant,
      arudhaSigns: arudhas,
      karakaPlanets: karakas,
      vargaCode: varga,
    );
  }

  static List<JaiminiEventRuleCheck> _eventRuleChecks({
    required String eventKey,
    required AstroChartResult chart,
    required JaiminiResult jaimini,
    required int mdSign,
    required int adSign,
    required ({
      Set<int> relevantSigns,
      Set<int> arudhaSigns,
      Set<String> karakaPlanets,
      String vargaCode,
    }) references,
  }) {
    final ids = _eventRuleIds[eventKey] ?? const <String>[];
    final keywords = _eventKeywords[eventKey] ?? const <String>[];
    final directSourceHits = jaimini.applicableRules.where((r) {
      final hay = '${r.topic} ${r.combination} ${r.result} ${r.analysis}'.toLowerCase();
      return keywords.any((k) => hay.contains(k.toLowerCase()));
    }).toList(growable: false);

    final karakaActivated = references.karakaPlanets.any((name) {
      final rows = chart.planets.where((p) => p.name == name).toList();
      return rows.isNotEmpty && (rows.first.signIndex == mdSign || rows.first.signIndex == adSign);
    });
    final arudhaActivated = references.arudhaSigns.contains(mdSign) || references.arudhaSigns.contains(adSign);
    final mdAdReference = references.relevantSigns.contains(mdSign) || references.relevantSigns.contains(adSign);
    final vargaMatch = _vargaConfirmation(eventKey, chart, jaimini);

    final checks = <JaiminiEventRuleCheck>[];
    for (var i = 0; i < ids.length; i++) {
      final id = ids[i];
      bool matched;
      String condition;
      String reason;
      if (i == 0) {
        matched = mdAdReference;
        condition = 'Active Chara MD/AD event reference signను activate చేయాలి.';
        reason = matched
            ? 'MD/ADలో కనీసం ఒకటి event reference signతో match అయింది.'
            : 'MD/AD event reference signsతో match కాలేదు.';
      } else if (i == 1) {
        matched = karakaActivated;
        condition = 'Relevant Chara/Natural Karaka active MD/AD signతో సంబంధం కలిగి ఉండాలి.';
        reason = matched
            ? 'Relevant karaka active signలో ఉంది.'
            : 'Relevant karaka active signలో లేదు.';
      } else if (i == 2) {
        matched = arudhaActivated;
        condition = 'Relevant Arudha / Upapada / Pada activation ఉండాలి.';
        reason = matched
            ? 'Relevant Arudha sign active MD/ADలో ఉంది.'
            : 'Relevant Arudha sign active MD/ADలో లేదు.';
      } else if (i == ids.length - 1) {
        matched = vargaMatch;
        condition = '${references.vargaCode} confirmation layer support చేయాలి.';
        reason = matched
            ? '${references.vargaCode} cross-check support ఉంది.'
            : '${references.vargaCode} cross-check support లేదు.';
      } else {
        matched = directSourceHits.isNotEmpty;
        condition = 'Supplied Jaimini sourceలో event-specific applicable rule hit ఉండాలి.';
        reason = matched
            ? 'Matched source rules: ${directSourceHits.map((r) => r.ruleId).take(4).join(', ')}.'
            : 'ఈ chartలో event keywordకి direct source-rule hit లేదు.';
      }
      checks.add(
        JaiminiEventRuleCheck(
          ruleId: id,
          condition: condition,
          matched: matched,
          reason: reason,
          source: directSourceHits.isNotEmpty
              ? directSourceHits.first.source
              : 'Jaimini supplied source • event decision-support mapping',
          remedy:
              'ఈ Jaimini event ruleకు supplied sourceలో ప్రత్యేక పరిహారం లేకపోతే app ఊహించి పరిహారం ఇవ్వదు. అవసరమైతే ఇతర source-backed Remedy moduleను వేరుగా పరిశీలించాలి.',
        ),
      );
    }
    return checks;
  }

  static bool _vargaConfirmation(
    String eventKey,
    AstroChartResult chart,
    JaiminiResult jaimini,
  ) {
    final refs = _eventReferences(eventKey, chart, jaimini);
    final division = switch (refs.vargaCode) {
      'D2' => 2,
      'D4' => 4,
      'D7' => 7,
      'D9' => 9,
      'D10' => 10,
      'D24' => 24,
      _ => 1,
    };
    final varga = VargaService.calculate(chart, division);
    const goodHouses = {1, 4, 5, 7, 9, 10};
    for (final name in refs.karakaPlanets) {
      final rows = varga.planets.where((p) => p.name == name).toList();
      if (rows.isEmpty) continue;
      final house = ((rows.first.signIndex - varga.ascendantSignIndex + 12) % 12) + 1;
      if (goodHouses.contains(house)) return true;
    }
    return false;
  }

  static List<JaiminiCharaAntardasha> supportiveAntardashas({
    required String eventKey,
    required AstroChartResult chart,
    required JaiminiResult jaimini,
    required JaiminiCharaDashaResult dasha,
    required DateTime start,
    required DateTime end,
  }) {
    final refs = _eventReferences(eventKey, chart, jaimini);
    final out = <JaiminiCharaAntardasha>[];
    for (final md in dasha.mahadashas) {
      if (!_overlaps(md.start, md.end, start, end)) continue;
      for (final ad in md.antardashas) {
        if (!_overlaps(ad.start, ad.end, start, end)) continue;
        if (refs.relevantSigns.contains(md.signIndex) || refs.relevantSigns.contains(ad.signIndex)) {
          out.add(ad);
        }
      }
    }
    return List<JaiminiCharaAntardasha>.unmodifiable(out);
  }

  static bool _overlaps(DateTime aStart, DateTime aEnd, DateTime bStart, DateTime bEnd) =>
      aStart.isBefore(bEnd) && bStart.isBefore(aEnd);

  static List<int> _rashiDrishtiTargets(int source) {
    final modality = source % 3;
    final offsets = switch (modality) {
      0 => const [4, 7, 10],
      1 => const [2, 5, 8],
      _ => const [3, 6, 9],
    };
    return offsets.map((o) => (source + o) % 12).toList(growable: false);
  }
}
