import 'ashtakavarga_service.dart';
import 'astro_models.dart';

class AvEventYearPathNode {
  final int signNumber;
  final int planetBav;
  final int sav;

  const AvEventYearPathNode({
    required this.signNumber,
    required this.planetBav,
    required this.sav,
  });
}

class AvEventYearTrace {
  final String planet;
  final int lagnaSignNumber;
  final int planetSignNumber;
  final List<AvEventYearPathNode> lagnaToPlanet;
  final List<AvEventYearPathNode> planetToLagna;

  const AvEventYearTrace({
    required this.planet,
    required this.lagnaSignNumber,
    required this.planetSignNumber,
    required this.lagnaToPlanet,
    required this.planetToLagna,
  });

  String get ruleIds => 'AV-008 / AV-009';

  String get sourceStatus =>
      'Source-supported trace ready; final age operator/conversion is not present in the currently supplied source summary.';
}

/// AV-008 / AV-009 source-disciplined trace.
///
/// The currently supplied rule summary explicitly says that the practical
/// Event-Year method works from Lagna to a planet and back using bindu-based
/// values, and then combines those results. It does not state the exact
/// operator/conversion that turns those two counts into the final age.
///
/// Therefore this service only prepares the source inputs that are
/// unambiguous in the current material:
///   * Lagna sign and natal planet sign,
///   * the zodiacal path in both directions,
///   * the selected planet's raw BAV and the SAV value at every path sign.
///
/// It intentionally DOES NOT emit a final event age or repeat interval.
class AshtakavargaEventYearService {
  static List<int> _forwardInclusivePath(int startSign, int endSign) {
    final out = <int>[startSign];
    var current = startSign;
    while (current != endSign) {
      current = (current + 1) % 12;
      out.add(current);
      if (out.length > 12) break;
    }
    return List<int>.unmodifiable(out);
  }

  static List<AvEventYearPathNode> _nodes({
    required List<int> signs,
    required List<int> bav,
    required List<int> sav,
  }) =>
      List<AvEventYearPathNode>.unmodifiable(
        signs.map(
          (sign) => AvEventYearPathNode(
            signNumber: sign + 1,
            planetBav: bav[sign],
            sav: sav[sign],
          ),
        ),
      );

  static List<AvEventYearTrace> evaluate({
    required AstroChartResult chart,
    required AshtakavargaResult av,
  }) {
    final lagna = chart.ascendantSignIndex;
    final byPlanet = {
      for (final p in chart.planets)
        if (AshtakavargaService.planetOrder.contains(p.name)) p.name: p.signIndex,
    };

    return List<AvEventYearTrace>.unmodifiable(
      AshtakavargaService.planetOrder.map((planet) {
        final planetSign = byPlanet[planet]!;
        final bav = av.bhinna[planet]!;
        final outward = _forwardInclusivePath(lagna, planetSign);
        final back = _forwardInclusivePath(planetSign, lagna);
        return AvEventYearTrace(
          planet: planet,
          lagnaSignNumber: lagna + 1,
          planetSignNumber: planetSign + 1,
          lagnaToPlanet: _nodes(signs: outward, bav: bav, sav: av.sarva),
          planetToLagna: _nodes(signs: back, bav: bav, sav: av.sarva),
        );
      }),
    );
  }
}
