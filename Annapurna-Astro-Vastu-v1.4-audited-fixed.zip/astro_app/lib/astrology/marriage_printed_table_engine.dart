import 'astro_models.dart';
import 'varga_service.dart';

/// Literal source-specific comparisons from `marriage my meterial.pdf`, pp 1–5.
/// Null is intentional: a printed classification alone is NOT a compatibility verdict.
class PrintedMatchResult {
  final bool? favourable;
  final String examination;
  final String sourceRule;
  const PrintedMatchResult(this.favourable, this.examination, this.sourceRule);
}

class MarriagePrintedTableEngine {
  static const signs = <String>['మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య','తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం'];
  static const stars = <String>['అశ్విని','భరణి','కృత్తిక','రోహిణి','మృగశిర','ఆర్ద్ర','పునర్వసు','పుష్యమి','ఆశ్లేష','మఖ','పుబ్బ','ఉత్తర','హస్త','చిత్త','స్వాతి','విశాఖ','అనూరాధ','జ్యేష్ఠ','మూల','పూర్వాషాఢ','ఉత్తరాషాఢ','శ్రవణం','ధనిష్ఠ','శతభిషం','పూర్వాభాద్ర','ఉత్తరాభాద్ర','రేవతి'];
  static PlanetPosition? planet(AstroChartResult c, String name) {
    for(final p in c.planets){ if(p.name.toLowerCase()==name.toLowerCase()) return p; }
    return null;
  }
  static VargaPlacement? vargaPlanet(VargaChartData c,String name){
    for(final p in c.planets){if(p.name.toLowerCase()==name.toLowerCase())return p;}
    return null;
  }
  static int? star(AstroChartResult c){
    final moon=planet(c,'Moon');
    if(moon==null)return null;
    return ((moon.longitude%360)/(360/27)).floor().clamp(0,26);
  }
  static int house(int sign, int lagna) => ((sign-lagna+12)%12)+1;
  static const nadi = <int>[
    0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,
  ]; // Source p.4 columns Adi/Madhya/Antya. Index 0=Adi,1=Madhya,2=Antya.
  static const nadiNames = ['ఆది','మధ్య','అంత్య'];
  static const goodPairs=<List<int>>[[0,7],[1,6],[3,8],[4,11],[5,10],[2,9]];
  static const badPairs=<List<int>>[[0,5],[1,3],[2,10],[4,9],[6,11],[8,7]];
  static bool matches(List<int> pair,int a,int b)=>pair.contains(a)&&pair.contains(b);

  static PrintedMatchResult evaluate(String id,AstroChartResult groom, AstroChartResult bride){
    final ga=star(groom),ba=star(bride);
    final gn=ga==null?'చంద్రుడు లేడు':stars[ga];
    final bn=ba==null?'చంద్రుడు లేడు':stars[ba];
    switch(id){
      case 'MM-P01-S02':
        return const PrintedMatchResult(null,
          'పుట 1: వరుడు/వధువు జననకాల దశా–భుక్తినాథులు, 2 జాతకాల లగ్నాధిపతులతో సంబంధం తనిఖీ చేయాలి. దశా–భుక్తి జననకాల గణన ఈ పట్టికలో ఇవ్వలేదు.',
          'వధువు జనన దశా–భుక్తినాథులు వరుడి జన్మ చక్రంలో, వరుడి జనన దశా–భుక్తినాథులు వధువు జన్మ చక్రంలో లగ్నం/సప్తమం లేదా అధిపతితో గ్రంథంలోని విధంగా సంబంధం ఉండాలి.');
      case 'MM-P02-R01':case 'MM-P02-R02':case 'MM-P02-R03':
        final d7=VargaService.calculate(groom,7);
        final mars=vargaPlanet(d7,'Mars');
        final target=id.endsWith('R01')?'Moon':id.endsWith('R02')?'Jupiter':'Saturn';
        final observer=vargaPlanet(d7,target);
        if(mars==null||observer==null)return const PrintedMatchResult(null,'D7 గ్రహస్థితులు అందుబాటులో లేవు','మూలం పుట 2: కుజుడు 2/4/7/8/12లో, సంబంధిత గ్రహ యుతి/దృష్టి.');
        final mh=house(mars.signIndex,d7.ascendantSignIndex);
        final inHomes=[2,4,7,8,12].contains(mh);
        final oh=house(mars.signIndex,observer.signIndex);
        // Classical planet aspects: 7 for Moon, Jupiter 5/7/9, Saturn 3/7/10.
        final aspects=target=='Jupiter'?[1,5,7,9]:target=='Saturn'?[1,3,7,10]:[1,7];
        final contact=aspects.contains(oh);
        final hit=inHomes&&contact;
        return PrintedMatchResult(hit?false:null,
          'వరుడి D7: కుజుడు ${mh}వ భావం; $target నుంచి కుజుని భావదూరం $oh. ${inHomes?'కుజ స్థానం షరతు సరిపోయింది':'కుజ స్థానం షరతు సరిపోలేదు'}; ${contact?'యుతి/దృష్టి ఉంది':'యుతి/దృష్టి లేదు'}.',
          'పుట 2, సూత్రం 03 / $id: D7 కుజుడు 2,4,7,8,12 స్థానాలలో ఉండి $target యుతి/దృష్టి పొందినప్పుడు గ్రంథం దోష సూచన పేర్కొంటుంది. ఇది పూర్తి వివాహ అననుకూలత తీర్పు కాదు.');
      case 'MM-P02-S04':
        final g=groom.ascendantSignIndex,b=bride.ascendantSignIndex;
        final good=goodPairs.any((x)=>matches(x,g,b));
        final bad=badPairs.any((x)=>matches(x,g,b));
        return PrintedMatchResult(good?true:bad?false:null,
          'D1 లగ్నరాశులు: వరుడు ${signs[g]}, వధువు ${signs[b]}. శుభ జంట ${good?'సరిపోయింది':'లేదు'}, అశుభ జంట ${bad?'సరిపోయింది':'లేదు'}.',
          'పుట 2 సూత్రం 04: గ్రంథంలోని శుభ/అశుభ పుష్టి జంటల పట్టిక. రెండు జంటలలోనూ లేకుంటే ఫలితం సూచించబడలేదు.');
      case 'MM-P03-S05':
        final g=groom.ascendantSignIndex,b=bride.ascendantSignIndex;
        final male={0,2,4,6,8,10}.contains(g);
        final female={1,3,5,7,9,11}.contains(b);
        return PrintedMatchResult(male&&female?true:null,
          'వరుడు ${signs[g]} (${male?'పురుష వర్గం':'ఇతర వర్గం'}), వధువు ${signs[b]} (${female?'స్త్రీ వర్గం':'ఇతర వర్గం'}).',
          'పుట 3 సూత్రం 05: పురుష/స్త్రీ రాశి వర్గ పట్టిక; గ్రంథం ప్రకారం ఈ వర్గ కలయిక అనుకూలం. ఇతర కలయికకు ఈ పట్టిక తీర్పు ఇవ్వదు.');
      case 'MM-P03-S06':
        if(ga==null||ba==null)return const PrintedMatchResult(null,'చంద్ర నక్షత్రం అందుబాటులో లేదు','మూలం పుట 3 సూత్రం 06 వేధ నక్షత్ర చిత్రం.');
        // Source p.3: Vedha Nakshatra diagram. Exact marked opposing pairs;
        // Mrigashira–Chitra–Dhanishtha is the three-way marked exception.
        const vedhaGroups=<List<int>>[
          [0,17],[1,16],[2,15],[3,14],[4,13,22],[5,21],[6,20],
          [7,19],[8,18],[9,26],[10,25],[11,24],[12,23],
        ];
        final vedha=vedhaGroups.any((group)=>group.contains(ga)&&group.contains(ba)&&ga!=ba);
        return PrintedMatchResult(vedha?false:null,
          'వరుడు $gn (${ga+1}), వధువు $bn (${ba+1}). ${vedha?'చిత్రంలోని వేధ జంట గుర్తించబడింది':'నిర్ధారించిన వేధ జంటలో లేదు'}.',
          'పుట 3 సూత్రం 06: వేధ నక్షత్రాల గ్రంథ చిత్రం. చిత్రంలోని అన్ని క్రాస్-లైన్లు సమాన జంటలని ఊహించకుండా స్పష్టమైన ఎదురు జంటలకే నియమం.');
      case 'MM-P04-S07':
        if(ga==null||ba==null)return const PrintedMatchResult(null,'చంద్ర నక్షత్రం అందుబాటులో లేదు','మూలం పుట 4 నాడీ కూట పట్టిక');
        final x=nadi[ga],y=nadi[ba];
        return PrintedMatchResult(x!=y,'వరుడు $gn — ${nadiNames[x]} నాడి, వధువు $bn — ${nadiNames[y]} నాడి. ${x==y?'ఏక నాడి':'వేర్వేరు నాడి'}.',
          'పుట 4 సూత్రం 07: ఆదినాడి, మధ్యనాడి, అంత్యనాడి 27 నక్షత్రాల పట్టిక. ఒకే నాడి కాకూడదని గమనిక. ప్రత్యేక నాడీ దోషభంగ మినహాయింపులు ఇక్కడ ఇవ్వలేదు.');
      case 'MM-P04-S08':
        if(ga==null||ba==null)return const PrintedMatchResult(null,'చంద్ర నక్షత్రం అందుబాటులో లేదు','మూలం పుట 4 రాజ్జు కూట పట్టిక');
        // The printed title is RAJJU (not Rashi). Source lines in star names.
        const groups=<String,List<int>>{
          'శిరో రాజ్జు':[4,13,22],
          'కంఠ రాజ్జు':[3,5,12,14,21,23],
          'ఉదర రాజ్జు':[2,6,11,15,20,24],
          'కటి రాజ్జు':[1,7,10,16,19,25],
          'పాద రాజ్జు':[0,8,9,17,18,26],
        };
        String? group(int index){for(final e in groups.entries){if(e.value.contains(index))return e.key;}return null;}
        final x=group(ga),y=group(ba);
        return PrintedMatchResult(x!=null&&y!=null?x!=y:null,
          'వరుడు $gn — ${x??'పట్టికలో నిర్ణయం లేదు'}, వధువు $bn — ${y??'పట్టికలో నిర్ణయం లేదు'}.',
          'పుట 4 సూత్రం 08: రాజ్జు కూటము (రాశి కూటము కాదు). ఒకే రాజ్జు కాకూడదని మూల గమనిక.');
      case 'MM-P05-S09':
        final g=groom.ascendantSignIndex,b=bride.ascendantSignIndex;
        const elements=['పృథ్వి','జలం','వాయు','అగ్ని','అగ్ని','జలం','వాయు','జలం','అగ్ని','పృథ్వి','వాయు','జలం'];
        return PrintedMatchResult(null,
          'వరుడు ${signs[g]}: ${elements[g]}; వధువు ${signs[b]}: ${elements[b]}. మూల పట్టికలో గ్రహం, వర్ణం, మాసం, తిథి కూడా ఉన్నాయి.',
          'పుట 5 సూత్రం 09: భూత కూటము. రాశివారీ వర్గీకరణ ఉంది; కానీ అన్ని రెండు-భూత జంటలకు Green/Red తీర్పు ఇచ్చే మ్యాట్రిక్స్ ఈ పేజీలో లేదు.');
      default:return const PrintedMatchResult(null,'తెలియని Source Rule ID','');
    }
  }
}
