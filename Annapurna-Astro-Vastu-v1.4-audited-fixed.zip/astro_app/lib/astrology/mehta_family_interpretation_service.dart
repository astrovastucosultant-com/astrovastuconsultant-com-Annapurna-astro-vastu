// Annapurna Astro Vastu — Build116
// Source-only family inspection. S.K. Mehta: New Dimensions in Hindu Astrology,
// printed pp. 26–28 (planet dignity), 87–95 (house portfolios / relatives),
// 100–109 (house strength, exchange, aspects), 129–160 (life topics).
// Relative-house arithmetic is an editorial extension where explicitly marked.
// This does NOT manufacture another person's natal chart, diagnoses or dates.
import 'astro_models.dart';
import 'mehta_family_house_service.dart';

enum MehtaFamilyEvidenceType { support, caution, neutral }

enum MehtaFamilyFindingType { supporting, cautionary, mixed, undetermined }

class MehtaFamilyRuleCheck {
  final String id;
  final String rule;
  final String observed;
  final String source;
  final bool matched;
  final MehtaFamilyEvidenceType type;
  const MehtaFamilyRuleCheck({
    required this.id,
    required this.rule,
    required this.observed,
    required this.source,
    required this.matched,
    required this.type,
  });
}

class MehtaFamilyFinding {
  final MehtaFamilyRelation relation;
  final MehtaFamilyTopic topic;
  final int relationHouse;
  final int targetHouse;
  final String lord;
  final int? lordNatalHouse;
  final int? lordRelativeHouse;
  final List<int> lordOtherHouses;
  final List<PlanetPosition> occupants;
  final List<PlanetPosition> aspecting;
  final List<MehtaFamilyRuleCheck> checks;
  final List<String> relationships;
  final MehtaFamilyFindingType type;
  final String result;
  final String limitations;

  const MehtaFamilyFinding({
    required this.relation,
    required this.topic,
    required this.relationHouse,
    required this.targetHouse,
    required this.lord,
    required this.lordNatalHouse,
    required this.lordRelativeHouse,
    required this.lordOtherHouses,
    required this.occupants,
    required this.aspecting,
    required this.checks,
    required this.relationships,
    required this.type,
    required this.result,
    required this.limitations,
  });

  List<MehtaFamilyRuleCheck> get matched =>
      checks.where((x) => x.matched).toList(growable: false);
  List<MehtaFamilyRuleCheck> get favorable => matched
      .where((x) => x.type == MehtaFamilyEvidenceType.support)
      .toList(growable: false);
  List<MehtaFamilyRuleCheck> get unfavorable => matched
      .where((x) => x.type == MehtaFamilyEvidenceType.caution)
      .toList(growable: false);
  String get heading {
    switch (type) {
      case MehtaFamilyFindingType.supporting:
        return 'అనుకూల బల సూచనలు';
      case MehtaFamilyFindingType.cautionary:
        return 'బలహీనత సూచనలు — మినహాయింపులతో';
      case MehtaFamilyFindingType.mixed:
        return 'మిశ్రమ బల సూచనలు';
      case MehtaFamilyFindingType.undetermined:
        return 'నిర్ణయానికి ఆధారాలు తగినంత లేవు';
    }
  }
}

class MehtaFamilyInterpretationService {
  // Source-specific dignity table: New Dimensions, printed p. 28. Aries index 0.
  // Do not silently replace Mercury's / other exaltation signs with another book.
  static const Map<String, List<int>> exalted = {
    'Sun': [0], 'Moon': [1], 'Mars': [9], 'Mercury': [10],
    'Jupiter': [3], 'Venus': [11], 'Saturn': [6],
  };
  static const Map<String, List<int>> fallen = {
    'Sun': [6], 'Moon': [7], 'Mars': [3], 'Mercury': [4],
    'Jupiter': [9], 'Venus': [5], 'Saturn': [0],
  };
  static const Map<String, String> topicReferences = {
    'self': 'New Dimensions పుటలు 87, 100–109',
    'money': 'New Dimensions పుటలు 87–88, 90, 100–109; Synchronization పుట 23–24',
    'younger': 'New Dimensions పుటలు 88, 95; Synchronization పుట 134–135',
    'property': 'New Dimensions పుటలు 88, 95; Synchronization పుటలు 30–31, 135–136',
    'children': 'New Dimensions పుటలు 89, 95, 170–180; Synchronization పుటలు 27–29',
    'service': 'New Dimensions పుటలు 89, 200–217; Synchronization పుట 137',
    'marriage': 'New Dimensions పుటలు 89, 160–169; Synchronization పుటలు 12–22',
    'inheritance': 'New Dimensions పుట 90; New Rules and Combinations పుటలు 142–145',
    'fortune': 'New Dimensions పుటలు 90, 95',
    'profession': 'New Dimensions పుటలు 90, 143–160; Synchronization పుటలు 35–40',
    'elder': 'New Dimensions పుటలు 90, 95',
    'foreign': 'New Dimensions పుటలు 90, 182–185; Synchronization పుటలు 25–27',
  };

  static String _pn(String name) =>
      MehtaFamilyHouseService.planetTelugu[name] ?? name;

  static PlanetPosition? _planet(AstroChartResult chart, String name) {
    for (final item in chart.planets) {
      if (item.name == name) return item;
    }
    return null;
  }

  static int _natalHouse(AstroChartResult chart, int sign) =>
      ((sign - chart.ascendantSignIndex + 12) % 12) + 1;

  static int _relativeHouse(AstroChartResult chart, int sign, int startHouse) =>
      ((sign - MehtaFamilyHouseService.houseSign(chart, startHouse) + 12) % 12) + 1;

  static bool _aspectsSign(PlanetPosition p, int sign) {
    final step = ((sign - p.signIndex + 12) % 12) + 1;
    return (MehtaFamilyHouseService.aspects[p.name] ?? const <int>[])
        .contains(step);
  }

  static bool _inOwnSign(PlanetPosition p) =>
      MehtaFamilyHouseService.signLords[p.signIndex] == p.name;
  static bool _exalted(PlanetPosition p) =>
      (exalted[p.name] ?? const <int>[]).contains(p.signIndex);
  static bool _fallen(PlanetPosition p) =>
      (fallen[p.name] ?? const <int>[]).contains(p.signIndex);

  // Two-way sign exchange: each planet occupies one of the other's own signs.
  static List<String> _exchangePartners(
      AstroChartResult chart, PlanetPosition lord) {
    final result = <String>[];
    for (final candidate in chart.planets) {
      if (candidate.name == lord.name ||
          !MehtaFamilyHouseService.signLords.contains(candidate.name)) {
        continue;
      }
      if (MehtaFamilyHouseService.signLords[lord.signIndex] == candidate.name &&
          MehtaFamilyHouseService.signLords[candidate.signIndex] == lord.name) {
        result.add(candidate.name);
      }
    }
    return result;
  }

  static MehtaFamilyFinding inspect(
    AstroChartResult chart,
    MehtaFamilyRelation relation,
    MehtaFamilyTopic topic,
  ) {
    final relationHouse = MehtaFamilyHouseService.relativeHouse(relation);
    final targetHouse = MehtaFamilyHouseService.targetHouse(relation, topic);
    final sign = MehtaFamilyHouseService.houseSign(chart, targetHouse);
    final lordName = MehtaFamilyHouseService.signLord(chart, targetHouse);
    final lord = _planet(chart, lordName);
    final occupies = MehtaFamilyHouseService.occupants(chart, targetHouse);
    final watchers = MehtaFamilyHouseService.aspecting(chart, targetHouse);
    final myHouses = <int>[];
    for (var h = 1; h <= 12; h++) {
      if (MehtaFamilyHouseService.signLord(chart, h) == lordName) {
        myHouses.add(_relativeHouse(chart,
            MehtaFamilyHouseService.houseSign(chart, h), relationHouse));
      }
    }
    final checks = <MehtaFamilyRuleCheck>[];
    void add(String id, String rule, String observed, String source,
        bool matched, MehtaFamilyEvidenceType type) {
      checks.add(MehtaFamilyRuleCheck(
        id: id, rule: rule, observed: observed, source: source,
        matched: matched, type: type,
      ));
    }
    const strength = 'New Dimensions పుటలు 100–109, ముఖ్యంగా 102–107';
    const dignity = 'New Dimensions పుటలు 26–28, 96–99';
    final lordHouse = lord == null
        ? null : _relativeHouse(chart, lord.signIndex, relationHouse);
    final lordOwnHouse = lord != null && lord.signIndex == sign;
    add('MF-01', 'ఆ భావంలో తన అధిపతి ఉండటం',
        lordOwnHouse ? '${_pn(lordName)} అదే భావంలో ఉన్నాడు' :
        '${_pn(lordName)} ఆ భావంలో లేడు', strength,
        lordOwnHouse, MehtaFamilyEvidenceType.support);

    final ownAspect = lord != null && !lordOwnHouse && _aspectsSign(lord, sign);
    add('MF-02', 'భావాన్ని స్వాధిపతి దృష్టించడం',
        ownAspect ? '${_pn(lordName)} స్వభావాన్ని దృష్టిస్తున్నాడు' :
        'స్వాధిపతి దృష్టి కనిపించలేదు', strength,
        ownAspect, MehtaFamilyEvidenceType.support);

    final exaltOccupants = occupies.where(_exalted).toList();
    add('MF-03', 'ఉచ్చస్థితి గ్రహం భావంలో ఉండటం',
        exaltOccupants.isEmpty ? 'ఈ భావంలో ఉచ్చగ్రహం లేదు' :
        '${exaltOccupants.map((p) => _pn(p.name)).join(' / ')} ఉచ్చంలో ఉంది',
        strength, exaltOccupants.isNotEmpty, MehtaFamilyEvidenceType.support);

    final exaltWatchers = watchers.where(_exalted).toList();
    add('MF-04', 'ఉచ్చస్థితి గ్రహదృష్టి భావానికి రావటం',
        exaltWatchers.isEmpty ? 'ఉచ్చగ్రహ దృష్టి లేదు' :
        '${exaltWatchers.map((p) => _pn(p.name)).join(' / ')} ఉచ్చ దృష్టి',
        strength, exaltWatchers.isNotEmpty, MehtaFamilyEvidenceType.support);

    final exchanged = lord == null ? <String>[] : _exchangePartners(chart, lord);
    add('MF-05', 'భావాధిపతి మరో గ్రహంతో రాశి పరివర్తన',
        exchanged.isEmpty ? 'పరివర్తన లేదు' :
        '${_pn(lordName)} ⇄ ${exchanged.map(_pn).join(' / ')} పరివర్తన',
        'New Dimensions పుటలు 103–105',
        exchanged.isNotEmpty, MehtaFamilyEvidenceType.support);

    final lordGood = lord != null && (_inOwnSign(lord) || _exalted(lord));
    add('MF-06', 'భావాధిపతి స్వక్షేత్రం లేదా ఉచ్చంలో ఉండటం',
        lord == null ? 'అధిపతి గ్రహ సమాచారం లేదు' :
        lordGood ? '${_pn(lordName)} ${_exalted(lord) ? 'ఉచ్చంలో' : 'స్వక్షేత్రంలో'}' :
        '${_pn(lordName)} ఉచ్చ/స్వక్షేత్రంలో లేడు',
        dignity, lordGood, MehtaFamilyEvidenceType.support);

    final lordDusthana = lordHouse != null && const <int>[6, 8, 12].contains(lordHouse);
    add('MF-07', 'బంధువు లగ్నం నుంచి భావాధిపతి 6/8/12లో ఉండటం',
        lordHouse == null ? 'అధిపతి స్థానం అందుబాటులో లేదు' :
        '${_pn(lordName)} బంధువు లగ్నం నుంచి ${lordHouse}వ భావంలో ఉన్నాడు',
        'New Dimensions పుటలు 105–107',
        lordDusthana, MehtaFamilyEvidenceType.caution);

    final lordInFall = lord != null && _fallen(lord);
    add('MF-08', 'భావాధిపతి నీచస్థితి',
        lordInFall ? '${_pn(lordName)} Mehta ఉచ్చ–నీచ పట్టిక ప్రకారం నీచంలో ఉన్నాడు' :
        'అధిపతికి నీచస్థితి గుర్తించలేదు',
        dignity, lordInFall, MehtaFamilyEvidenceType.caution);

    final fallOccupants = occupies.where(_fallen).toList();
    add('MF-09', 'నీచగ్రహం ఆ భావంలో ఉండటం',
        fallOccupants.isEmpty ? 'నీచగ్రహ నివాసం కనిపించలేదు' :
        '${fallOccupants.map((p) => _pn(p.name)).join(' / ')} నీచగ్రహ ప్రభావం',
        'New Dimensions పుటలు 106–109',
        fallOccupants.isNotEmpty, MehtaFamilyEvidenceType.caution);

    final fallWatchers = watchers.where(_fallen).toList();
    add('MF-10', 'నీచగ్రహ దృష్టి ఆ భావానికి రావటం',
        fallWatchers.isEmpty ? 'నీచగ్రహ దృష్టి కనిపించలేదు' :
        '${fallWatchers.map((p) => _pn(p.name)).join(' / ')} నీచగ్రహ దృష్టి',
        'New Dimensions పుటలు 106–109',
        fallWatchers.isNotEmpty, MehtaFamilyEvidenceType.caution);

    final relationships = <String>[];
    for (final p in occupies) {
      final names = <String>[];
      if (_inOwnSign(p)) names.add('స్వక్షేత్రం');
      if (_exalted(p)) names.add('ఉచ్చ');
      if (_fallen(p)) names.add('నీచ');
      if (p.retrograde) names.add('వక్ర');
      relationships.add('${_pn(p.name)} — ${names.isEmpty ? 'సాధారణ రాశి స్థితి' : names.join(', ')}; బంధువు లగ్నం నుంచి ${_relativeHouse(chart, p.signIndex, relationHouse)}వ భావం');
    }
    for (final p in watchers) {
      relationships.add('${_pn(p.name)} — ${_relativeHouse(chart, p.signIndex, relationHouse)}వ భావం నుంచి ${topic.offset}వ భావానికి Mehta దృష్టి');
    }
    for (final name in exchanged) {
      relationships.add('${_pn(lordName)}–${_pn(name)} పరివర్తన: రెండు అధిపత్యాల పోర్ట్‌ఫోలియోలను కలిసి చూడాలి');
    }
    if (lord != null) {
      relationships.add('భావాధిపతి ${_pn(lordName)} — మూల జాతక ${_natalHouse(chart, lord.signIndex)}వ భావం; బంధువు ${lordHouse}వ భావం; ${MehtaFamilyHouseService.signs[lord.signIndex]} రాశి; ${lord.degreesInSign.toStringAsFixed(2)}°; ${lord.retrograde ? 'వక్ర' : 'మార్గి'}');
    }
    final good = checks.where((x) => x.matched && x.type == MehtaFamilyEvidenceType.support).length;
    final caution = checks.where((x) => x.matched && x.type == MehtaFamilyEvidenceType.caution).length;
    final findingType = good > 0 && caution > 0
        ? MehtaFamilyFindingType.mixed
        : good > 0 ? MehtaFamilyFindingType.supporting
        : caution > 0 ? MehtaFamilyFindingType.cautionary
        : MehtaFamilyFindingType.undetermined;
    final heading = switch (findingType) {
      MehtaFamilyFindingType.supporting =>
        'ఈ అంశానికి గ్రంథంలోని భావబలాన్ని సూచించే సంబంధాలు కనిపించాయి. ఇవి అనుకూల ఆధారాలు; వ్యక్తిగత సంఘటన జరిగిందని నిర్ధారణ కాదు.',
      MehtaFamilyFindingType.cautionary =>
        'ఈ అంశానికి బలహీనతను సూచించే సంబంధాలు కనిపించాయి. మినహాయింపులు, ఇతర గ్రహసంబంధాలు, గత సంఘటనలు పరీక్షించకుండా ప్రతికూల ఫలితాన్ని ఖరారు చేయరాదు.',
      MehtaFamilyFindingType.mixed =>
        'ఈ అంశానికి అనుకూల, ప్రతికూల సూచనలు రెండూ ఉన్నాయి. ఏది బలంగా పనిచేస్తుందో గ్రంథంలోని ఇతర సంబంధాలు, సంఘటనల నేపథ్యం, దశలతో నిర్ణయించాలి.',
      MehtaFamilyFindingType.undetermined =>
        'ఈ అంశానికి పరీక్షించిన ప్రత్యేక బల/బలహీనత నియమాలు సరిపోలలేదు. అందువల్ల ఈ అంశం లేదని లేదా ఫలితం రాదని అర్థం కాదు.',
    };
    return MehtaFamilyFinding(
      relation: relation, topic: topic, relationHouse: relationHouse,
      targetHouse: targetHouse, lord: lordName,
      lordNatalHouse: lord == null ? null : _natalHouse(chart, lord.signIndex),
      lordRelativeHouse: lordHouse,
      lordOtherHouses: myHouses,
      occupants: occupies, aspecting: watchers, checks: checks,
      relationships: relationships, type: findingType,
      result: heading,
      limitations: 'ఈ పరిశీలన Mehta గ్రంథంలోని భావబలం/అధిపత్యం/దృష్టి నియమాలపై ఆధారపడినది. ఇతర ప్రత్యేక కాంబినేషన్లు, నవాంశం వంటి వేరే పద్ధతులు ఇక్కడ కలపలేదు. దశ–అంతర్దశ / Synchronization ధృవీకరణ లేకుండా సంఘటన తేదీ ఇవ్వము. వైద్య సమస్య, మరణం, వ్యక్తిత్వం, కుటుంబ సంబంధాలపై నిర్ధారిత తీర్పుగా పరిగణించరాదు.',
    );
  }

  static List<MehtaFamilyFinding> allTopics(
      AstroChartResult chart, MehtaFamilyRelation relation) =>
      MehtaFamilyHouseService.topics
          .map((topic) => inspect(chart, relation, topic)).toList(growable: false);
}
