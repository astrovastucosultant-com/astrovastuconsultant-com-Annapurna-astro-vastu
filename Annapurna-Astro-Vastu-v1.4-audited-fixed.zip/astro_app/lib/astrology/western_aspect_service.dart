import 'dart:math' as math;

import 'astro_models.dart';

/// Geometric ecliptic longitude aspects. Angular separation is identical
/// whether all bodies use the same tropical or sidereal ayanamsa offset.
/// These are Western aspect definitions, NOT a KP significator or BPD rule.
class WesternAspectDefinition {
  final String id;
  final String name;
  final double exactAngle;
  final double defaultOrb;
  const WesternAspectDefinition(this.id, this.name, this.exactAngle, this.defaultOrb);
}

class WesternAspectMatch {
  final String body1;
  final String body2;
  final WesternAspectDefinition aspect;
  final double separation;
  final double deviation;
  const WesternAspectMatch({
    required this.body1,
    required this.body2,
    required this.aspect,
    required this.separation,
    required this.deviation,
  });
  String get ruleId => 'WEST-${aspect.id}';
}

class WesternAspectService {
  static const definitions = <WesternAspectDefinition>[
    WesternAspectDefinition('CONJ', 'Conjunction', 0, 8),
    WesternAspectDefinition('SEXT', 'Sextile', 60, 5),
    WesternAspectDefinition('SQR', 'Square', 90, 6),
    WesternAspectDefinition('TRI', 'Trine', 120, 7),
    WesternAspectDefinition('OPP', 'Opposition', 180, 8),
    WesternAspectDefinition('SSXT', 'Semi-sextile', 30, 2),
    WesternAspectDefinition('QUIN', 'Quincunx', 150, 3),
  ];

  static double separation(double a, double b) {
    if (!a.isFinite || !b.isFinite) throw ArgumentError('Planet longitude must be finite');
    final first = (a % 360 + 360) % 360;
    final second = (b % 360 + 360) % 360;
    final arc = (first - second).abs();
    return math.min(arc, 360.0 - arc);
  }

  /// [orbMultiplier] adjusts the per-aspect standard orb, without modifying
  /// natal planetary positions. Minor aspects are opt-in.
  static List<WesternAspectMatch> calculate(
    List<PlanetPosition> planets, {
    bool includeMinor = false,
    bool includeNodes = false,
    double orbMultiplier = 1.0,
  }) {
    if (!orbMultiplier.isFinite || orbMultiplier <= 0) {
      throw ArgumentError.value(orbMultiplier, 'orbMultiplier');
    }
    final filtered = planets.where((p) =>
        includeNodes || (p.name != 'Rahu' && p.name != 'Ketu')).toList();
    final chosen = includeMinor ? definitions : definitions.take(5);
    final results = <WesternAspectMatch>[];
    for (var i = 0; i < filtered.length; i++) {
      for (var j = i + 1; j < filtered.length; j++) {
        final a = filtered[i];
        final b = filtered[j];
        final angle = separation(a.longitude, b.longitude);
        WesternAspectMatch? best;
        for (final def in chosen) {
          final error = (angle - def.exactAngle).abs();
          if (error > def.defaultOrb * orbMultiplier + 1e-9) continue;
          if (best == null || error < best.deviation) {
            best = WesternAspectMatch(
              body1: a.name, body2: b.name,
              aspect: def, separation: angle, deviation: error,
            );
          }
        }
        if (best != null) results.add(best);
      }
    }
    results.sort((a, b) {
      final order = a.deviation.compareTo(b.deviation);
      if (order != 0) return order;
      return '${a.body1}-${a.body2}'.compareTo('${b.body1}-${b.body2}');
    });
    return List.unmodifiable(results);
  }
}
