import 'astro_models.dart';
import 'varga_service.dart';

class JaiminiKaraka {
  final String code;
  final String planet;
  final double effectiveDegree;

  const JaiminiKaraka({
    required this.code,
    required this.planet,
    required this.effectiveDegree,
  });
}

class JaiminiArgalaRow {
  final String label;
  final int signIndex;
  final List<String> planets;

  const JaiminiArgalaRow({
    required this.label,
    required this.signIndex,
    required this.planets,
  });
}

class JaiminiResult {
  final List<JaiminiKaraka> charaKarakas;
  final String atmakaraka;
  final int karakamsaSignIndex;
  final Map<int, List<int>> rashiDrishti;
  final List<JaiminiArgalaRow> argalaFromLagna;
  final bool hasDegreeTie;

  const JaiminiResult({
    required this.charaKarakas,
    required this.atmakaraka,
    required this.karakamsaSignIndex,
    required this.rashiDrishti,
    required this.argalaFromLagna,
    required this.hasDegreeTie,
  });
}

class JaiminiService {
  static const _karakaCodes = ['AK', 'AmK', 'BK', 'MK', 'PK', 'GK', 'DK'];

  static JaiminiResult calculate(AstroChartResult chart) {
    final classicalSeven = chart.planets
        .where((p) => const {
              'Sun',
              'Moon',
              'Mars',
              'Mercury',
              'Jupiter',
              'Venus',
              'Saturn',
            }.contains(p.name))
        .toList(growable: false);

    final ranked = [...classicalSeven]
      ..sort((a, b) => b.degreesInSign.compareTo(a.degreesInSign));

    var tie = false;
    for (var i = 1; i < ranked.length; i++) {
      if ((ranked[i - 1].degreesInSign - ranked[i].degreesInSign).abs() < 1e-8) {
        tie = true;
      }
    }

    final karakas = <JaiminiKaraka>[];
    for (var i = 0; i < ranked.length && i < _karakaCodes.length; i++) {
      karakas.add(
        JaiminiKaraka(
          code: _karakaCodes[i],
          planet: ranked[i].name,
          effectiveDegree: ranked[i].degreesInSign,
        ),
      );
    }

    final ak = ranked.first;
    final navamsa = VargaService.calculate(chart, 9);
    final akD9 = navamsa.planets.firstWhere((p) => p.name == ak.name);

    return JaiminiResult(
      charaKarakas: karakas,
      atmakaraka: ak.name,
      karakamsaSignIndex: akD9.signIndex,
      rashiDrishti: {
        for (var sign = 0; sign < 12; sign++) sign: _drishtiTargets(sign),
      },
      argalaFromLagna: _argalaRows(chart),
      hasDegreeTie: tie,
    );
  }

  /// Supplied source core: movable -> 5/8/11, fixed -> 3/6/9,
  /// dual -> 4/7/10 counted from the source sign.
  static List<int> _drishtiTargets(int source) {
    final modality = source % 3; // 0 movable, 1 fixed, 2 dual
    final offsets = switch (modality) {
      0 => const [4, 7, 10],
      1 => const [2, 5, 8],
      _ => const [3, 6, 9],
    };
    return offsets.map((o) => (source + o) % 12).toList(growable: false);
  }

  static List<JaiminiArgalaRow> _argalaRows(AstroChartResult chart) {
    final lagna = chart.ascendantSignIndex;
    final labels = <(String, int)>[
      ('2వ అర్గళ', 2),
      ('4వ అర్గళ', 4),
      ('11వ అర్గళ', 11),
      ('5వ అర్గళ', 5),
      ('12వ విరోధ', 12),
      ('10వ విరోధ', 10),
      ('3వ విరోధ', 3),
      ('9వ విరోధ', 9),
    ];
    return labels.map((entry) {
      final sign = (lagna + entry.$2 - 1) % 12;
      final planets = chart.planets
          .where((p) => p.signIndex == sign)
          .map((p) => p.shortName)
          .toList(growable: false);
      return JaiminiArgalaRow(
        label: entry.$1,
        signIndex: sign,
        planets: planets,
      );
    }).toList(growable: false);
  }
}
