import 'astro_models.dart';
import 'varga_service.dart';

enum JaiminiRuleNature { favorable, adverse, neutral }

class JaiminiRuleHit {
  final String ruleId;
  final String topic;
  final String combination;
  final String result;
  final String analysis;
  final String remedy;
  final String source;
  final JaiminiRuleNature nature;
  final bool isYoga;

  const JaiminiRuleHit({
    required this.ruleId,
    required this.topic,
    required this.combination,
    required this.result,
    required this.analysis,
    required this.remedy,
    required this.source,
    required this.nature,
    this.isYoga = false,
  });
}

class JaiminiKaraka {
  final String code;
  final String planet;
  final double effectiveDegree;

  const JaiminiKaraka({
    required this.code,
    required this.planet,
    required this.effectiveDegree,
  });
}

class JaiminiPadaRow {
  final int padaNumber;
  final int sourceSignIndex;
  final String lord;
  final int lordSignIndex;
  final int distance;
  final int padaSignIndex;

  const JaiminiPadaRow({
    required this.padaNumber,
    required this.sourceSignIndex,
    required this.lord,
    required this.lordSignIndex,
    required this.distance,
    required this.padaSignIndex,
  });
}

class JaiminiArgalaRow {
  final String label;
  final int signIndex;
  final List<String> planets;

  const JaiminiArgalaRow({
    required this.label,
    required this.signIndex,
    required this.planets,
  });
}

class JaiminiResult {
  final List<JaiminiKaraka> charaKarakas;
  final String atmakaraka;
  final int karakamsaSignIndex;
  final Map<int, List<int>> rashiDrishti;
  final List<JaiminiArgalaRow> argalaFromLagna;
  final List<JaiminiPadaRow> arudhaPadas;
  final List<JaiminiRuleHit> applicableRules;
  final bool hasDegreeTie;

  const JaiminiResult({
    required this.charaKarakas,
    required this.atmakaraka,
    required this.karakamsaSignIndex,
    required this.rashiDrishti,
    required this.argalaFromLagna,
    required this.arudhaPadas,
    required this.applicableRules,
    required this.hasDegreeTie,
  });
}

class JaiminiService {
  static const _karakaCodes = ['AK', 'AmK', 'BK', 'MK', 'PK', 'GK', 'DK'];
  static const _benefics = {'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = {'Saturn', 'Mars', 'Rahu', 'Ketu'};

  static JaiminiResult calculate(AstroChartResult chart) {
    final classicalSeven = chart.planets
        .where((p) => const {
              'Sun',
              'Moon',
              'Mars',
              'Mercury',
              'Jupiter',
              'Venus',
              'Saturn',
            }.contains(p.name))
        .toList(growable: false);

    final ranked = [...classicalSeven]
      ..sort((a, b) => b.degreesInSign.compareTo(a.degreesInSign));

    var tie = false;
    for (var i = 1; i < ranked.length; i++) {
      if ((ranked[i - 1].degreesInSign - ranked[i].degreesInSign).abs() < 1e-8) {
        tie = true;
      }
    }

    final karakas = <JaiminiKaraka>[];
    for (var i = 0; i < ranked.length && i < _karakaCodes.length; i++) {
      karakas.add(
        JaiminiKaraka(
          code: _karakaCodes[i],
          planet: ranked[i].name,
          effectiveDegree: ranked[i].degreesInSign,
        ),
      );
    }

    final ak = ranked.first;
    final navamsa = VargaService.calculate(chart, 9);
    final akD9 = navamsa.planets.firstWhere((p) => p.name == ak.name);
    final padas = _calculateArudhaPadas(chart);

    return JaiminiResult(
      charaKarakas: karakas,
      atmakaraka: ak.name,
      karakamsaSignIndex: akD9.signIndex,
      rashiDrishti: {
        for (var sign = 0; sign < 12; sign++) sign: _drishtiTargets(sign),
      },
      argalaFromLagna: _argalaRows(chart),
      arudhaPadas: padas,
      applicableRules: _evaluateApplicableRules(
        chart: chart,
        navamsa: navamsa,
        atmakaraka: ak.name,
        karakamsaSign: akD9.signIndex,
        padas: padas,
      ),
      hasDegreeTie: tie,
    );
  }

  /// Source-verified Arudha/Pada algorithm (P1–P12):
  /// 1) take the source house-sign from Lagna;
  /// 2) count inclusively from that sign to its lord;
  /// 3) count the same inclusive distance from the lord;
  /// 4) the reached sign is the Pada/Arudha of that house.
  static List<JaiminiPadaRow> _calculateArudhaPadas(AstroChartResult chart) {
    final lagna = chart.ascendantSignIndex;
    final result = <JaiminiPadaRow>[];

    for (var house = 1; house <= 12; house++) {
      final sourceSign = (lagna + house - 1) % 12;
      final lord = _signLord(sourceSign);
      final lordPlanet = chart.planets.firstWhere((p) => p.name == lord);
      final lordSign = lordPlanet.signIndex;
      final distance = ((lordSign - sourceSign + 12) % 12) + 1;
      final padaSign = (lordSign + distance - 1) % 12;

      result.add(
        JaiminiPadaRow(
          padaNumber: house,
          sourceSignIndex: sourceSign,
          lord: lord,
          lordSignIndex: lordSign,
          distance: distance,
          padaSignIndex: padaSign,
        ),
      );
    }

    return result;
  }

  static List<JaiminiRuleHit> _evaluateApplicableRules({
    required AstroChartResult chart,
    required VargaChartData navamsa,
    required String atmakaraka,
    required int karakamsaSign,
    required List<JaiminiPadaRow> padas,
  }) {
    final hits = <JaiminiRuleHit>[];
    final al = padas.firstWhere((p) => p.padaNumber == 1).padaSignIndex;
    final a7 = padas.firstWhere((p) => p.padaNumber == 7).padaSignIndex;
    final ul = padas.firstWhere((p) => p.padaNumber == 12).padaSignIndex;
    final akPlanet = chart.planets.firstWhere((p) => p.name == atmakaraka);
    final akRasi = akPlanet.signIndex;

    void add({
      required String id,
      required String topic,
      required String combination,
      required String result,
      required String analysis,
      required JaiminiRuleNature nature,
      bool isYoga = false,
      String source = 'Jaimini supplied source',
    }) {
      hits.add(
        JaiminiRuleHit(
          ruleId: id,
          topic: topic,
          combination: combination,
          result: result,
          analysis: analysis,
          remedy: _remedyText(nature),
          source: source,
          nature: nature,
          isYoga: isYoga,
        ),
      );
    }

    // AK dignity layer.
    if (_isExalted(atmakaraka, akRasi)) {
      add(
        id: 'J1Q1-R3.5',
        topic: 'ఆత్మకారక / బలం',
        combination: 'AK $atmakaraka ఉచ్చ స్థితి',
        result: 'ఆత్మకారక బలం అనుకూలంగా ఉంది.',
        analysis: 'AK $atmakaraka ${akRasi + 1}వ రాశిలో ఉచ్చస్థితిలో ఉంది. Source ప్రకారం ఇది favourable/moksha-support layer.',
        nature: JaiminiRuleNature.favorable,
      );
    } else if (_isDebilitated(atmakaraka, akRasi)) {
      add(
        id: 'J1Q1-R3.5',
        topic: 'ఆత్మకారక / బలం',
        combination: 'AK $atmakaraka నీచ స్థితి',
        result: 'ఆత్మకారక బలంలో ప్రతికూల సూచన.',
        analysis: 'AK $atmakaraka ${akRasi + 1}వ రాశిలో నీచస్థితిలో ఉంది. Source దీన్ని బంధన/అడ్డంకి layerగా చూడమంటుంది.',
        nature: JaiminiRuleNature.adverse,
      );
    }

    // AK Navamsa / Karakamsa sign results available in supplied source.
    final akNavamsaRules = <int, (String, String, JaiminiRuleNature)> {
      0: ('AK Navamsa 1', 'జంతువులు/కాటు సంబంధిత జాగ్రత్త సూచన.', JaiminiRuleNature.adverse),
      1: ('AK Navamsa 2', 'భూమి, వ్యవసాయం, సంపద సంబంధిత అనుకూల సూచన.', JaiminiRuleNature.favorable),
      2: ('AK Navamsa 3', 'నాడీ/చర్మ/వాయు సంబంధిత source సూచన.', JaiminiRuleNature.adverse),
      3: ('AK Navamsa 4', 'జల సంబంధిత భయం/అసౌకర్య సూచన.', JaiminiRuleNature.adverse),
      4: ('AK Navamsa 5', 'జంతు సంబంధిత జాగ్రత్త సూచన.', JaiminiRuleNature.adverse),
      5: ('AK Navamsa 6', 'ఆరోగ్య సంబంధిత source జాగ్రత్త సూచన.', JaiminiRuleNature.adverse),
      6: ('AK Navamsa 7', 'వాణిజ్య/వ్యాపార స్వభావానికి అనుకూల సూచన.', JaiminiRuleNature.favorable),
      7: ('AK Navamsa 8', 'కీటక/విష సంబంధిత జాగ్రత్త సూచన.', JaiminiRuleNature.adverse),
      8: ('AK Navamsa 9', 'జంతు సంబంధిత జాగ్రత్త సూచన.', JaiminiRuleNature.adverse),
    };
    final akNavRule = akNavamsaRules[karakamsaSign];
    if (akNavRule != null) {
      add(
        id: 'J1Q1-C${(karakamsaSign + 1).toString().padLeft(2, '0')}',
        topic: 'కారకాంశ / స్వభావం',
        combination: akNavRule.$1,
        result: akNavRule.$2,
        analysis: 'AK $atmakaraka నవాంశంలో ${karakamsaSign + 1}వ రాశిలో ఉంది; అదే Karakamsa referenceగా తీసుకున్నాం.',
        nature: akNavRule.$3,
      );
    }

    // Karakamsa rules are evaluated in D9.
    final kc2 = _signAt(karakamsaSign, 2);
    final kc3 = _signAt(karakamsaSign, 3);
    final kc4 = _signAt(karakamsaSign, 4);
    final kc5 = _signAt(karakamsaSign, 5);
    final kc6 = _signAt(karakamsaSign, 6);
    final kc9 = _signAt(karakamsaSign, 9);

    if (_d9Has(navamsa, kc2, 'Mercury')) {
      add(id: 'J1Q1-C10', topic: 'విద్య / బుద్ధి / వృత్తి', combination: 'Karakamsa 2వలో Mercury', result: 'విద్య, రచన, వాణిజ్య, బుద్ధి రంగాలకు అనుకూల సూచన.', analysis: 'Karakamsa ${karakamsaSign + 1}; 2వ రాశి ${kc2 + 1}లో Mercury ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (_d9Has(navamsa, kc2, 'Jupiter')) {
      add(id: 'J1Q1-C11', topic: 'విద్య / ధర్మం', combination: 'Karakamsa 2వలో Jupiter', result: 'ధర్మం, శాస్త్రం, తత్వజ్ఞానం, న్యాయబద్ధతకు అనుకూల సూచన.', analysis: 'Karakamsa నుండి 2వ రాశిలో Jupiter ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (_d9Has(navamsa, kc2, 'Saturn')) {
      add(id: 'J1Q1-C12', topic: 'వృత్తి / ప్రతిష్ఠ', combination: 'Karakamsa 2వలో Saturn', result: 'ఎంచుకున్న రంగంలో స్థానం/ప్రసిద్ధికి source సూచన.', analysis: 'Karakamsa నుండి 2వ రాశిలో Saturn ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (_d9Has(navamsa, kc2, 'Rahu')) {
      add(id: 'J1Q1-C13', topic: 'నైతికత / జాగ్రత్త', combination: 'Karakamsa 2వలో Rahu', result: 'అనైతిక లేదా మోసపూరిత మార్గాలపై source జాగ్రత్త సూచన.', analysis: 'Karakamsa నుండి 2వ రాశిలో Rahu ఉంది.', nature: JaiminiRuleNature.adverse);
    }

    if (_d9HasAny(navamsa, kc4, const {'Saturn', 'Rahu'})) {
      add(id: 'J1Q1-C15', topic: 'ఇల్లు / స్థిరాస్తి', combination: 'Karakamsa 4వలో Saturn/Rahu', result: 'కఠిన పదార్థాలు/రాళ్ల నిర్మాణం వంటి source సూచన.', analysis: 'Karakamsa నుండి 4వ రాశి ${kc4 + 1}లో Saturn లేదా Rahu ఉంది.', nature: JaiminiRuleNature.neutral);
    }
    if (_d9Has(navamsa, kc4, 'Jupiter')) {
      add(id: 'J1Q1-C16', topic: 'ఇల్లు / సౌఖ్యం', combination: 'Karakamsa 4వలో Jupiter', result: 'మంచి/విశాల నివాసానికి అనుకూల సూచన.', analysis: 'Karakamsa నుండి 4వ రాశిలో Jupiter ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (_d9HasAny(navamsa, kc4, const {'Mars', 'Ketu'})) {
      add(id: 'J1Q1-C17', topic: 'ఇల్లు / స్థిరాస్తి', combination: 'Karakamsa 4వలో Mars/Ketu', result: 'ఇటుక/కఠిన నిర్మాణ పదార్థాలకు source సూచన.', analysis: 'Karakamsa నుండి 4వ రాశిలో Mars లేదా Ketu ఉంది.', nature: JaiminiRuleNature.neutral);
    }
    if (_d9HasAll(navamsa, kc4, const {'Venus', 'Moon'})) {
      add(id: 'J1Q1-C21', topic: 'సౌఖ్యం / స్థాయి', combination: 'Karakamsa 4వలో Venus + Moon', result: 'విలాసం, సౌఖ్యం, రాజసంబంధ స్థాయి సూచన.', analysis: 'Karakamsa నుండి 4వ రాశిలో Venus మరియు Moon కలిసి ఉన్నాయి.', nature: JaiminiRuleNature.favorable, isYoga: true);
    }

    if (_d9HasAny(navamsa, kc9, _benefics)) {
      add(id: 'J1Q1-C18', topic: 'ధర్మం / ఆధ్యాత్మికం', combination: 'Karakamsa 9వలో benefic influence', result: 'ధర్మం, సత్యం, గురు/శాస్త్రభక్తికి అనుకూల సూచన.', analysis: 'Karakamsa నుండి 9వ రాశి ${kc9 + 1}లో శుభగ్రహ ప్రభావం ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (_d9HasAny(navamsa, kc9, const {'Saturn', 'Rahu'})) {
      add(id: 'J1Q1-C19', topic: 'ధర్మం / గురువులు', combination: 'Karakamsa 9వలో Saturn/Rahu', result: 'గురువులు/elders లేదా ధర్మ భావంలో ప్రతికూల source సూచన.', analysis: 'Karakamsa నుండి 9వ రాశిలో Saturn లేదా Rahu ఉంది.', nature: JaiminiRuleNature.adverse);
    }
    if (_d9HasAll(navamsa, kc9, const {'Mars', 'Venus'})) {
      add(id: 'J1Q1-C20', topic: 'సంబంధాలు / జాగ్రత్త', combination: 'Karakamsa 9వలో Mars + Venus', result: 'సంబంధాలలో పరిమితులు/నైతిక స్పష్టత అవసరమనే source జాగ్రత్త సూచన.', analysis: 'Karakamsa నుండి 9వ రాశిలో Mars మరియు Venus కలిసి ఉన్నాయి.', nature: JaiminiRuleNature.adverse);
    }
    if (_d9Has(navamsa, kc9, 'Jupiter')) {
      add(id: 'J1Q1-C23', topic: 'విద్య / పాండిత్యం', combination: 'Karakamsa 9వలో Jupiter', result: 'వేదాంతం, శాస్త్రం, సంగీతం, పాండిత్యానికి అనుకూల సూచన.', analysis: 'Karakamsa నుండి 9వ రాశిలో Jupiter ఉంది.', nature: JaiminiRuleNature.favorable);
    }

    final maleficKc36 = _d9Names(navamsa, kc3).where(_malefics.contains).length +
        _d9Names(navamsa, kc6).where(_malefics.contains).length;
    if (maleficKc36 > 0) {
      add(id: 'J1Q1-C22', topic: 'వృత్తి / సేవ', combination: 'Karakamsa 3/6లో malefic influence', result: 'కృషి, సేవ, కార్యరంగంలో శ్రమ ఆధారిత పురోగతికి source సూచన.', analysis: 'Karakamsa 3వ/6వ స్థానాల్లో $maleficKc36 పాపగ్రహ ప్రభావాలు నమోదయ్యాయి.', nature: JaiminiRuleNature.neutral);
    }

    for (final planet in const ['Jupiter', 'Venus', 'Mercury', 'Ketu']) {
      if (_d9Has(navamsa, karakamsaSign, planet) || _d9Has(navamsa, kc5, planet)) {
        final data = switch (planet) {
          'Jupiter' => ('J1Q1-C24', 'విద్య / పాండిత్యం', 'వేదాంతం, పాండిత్యం, రచనా సామర్థ్యానికి అనుకూల సూచన.', JaiminiRuleNature.favorable),
          'Venus' => ('J1Q1-C25', 'కళలు / రచన', 'రచన, సంగీతం, కళా రంగాలకు అనుకూల సూచన.', JaiminiRuleNature.favorable),
          'Mercury' => ('J1Q1-C26', 'విద్య / రచన', 'శాస్త్ర, రచన, బుద్ధి రంగాలకు అనుకూల సూచన.', JaiminiRuleNature.favorable),
          _ => ('J1Q1-C27', 'గణితం / ఆధ్యాత్మికం', 'గణితం, తత్వం, ఆధ్యాత్మిక రంగాలకు source సూచన.', JaiminiRuleNature.neutral),
        };
        add(id: data.$1, topic: data.$2, combination: '$planet Karakamsa/5వ ప్రభావం', result: data.$3, analysis: '$planet Karakamsa లేదా దాని 5వ స్థానంలో ఉంది.', nature: data.$4);
      }
    }

    final moonD9 = navamsa.planets.firstWhere((p) => p.name == 'Moon').signIndex;
    final moon2 = _signAt(moonD9, 2);
    final moon8 = _signAt(moonD9, 8);
    if (_d9Names(navamsa, moon2).isEmpty && _d9Names(navamsa, moon8).isEmpty) {
      add(id: 'J1Q1-C28', topic: 'ఆర్థిక స్థిరత్వం / జాగ్రత్త', combination: 'Jaimini Kemadruma source condition', result: 'ఆర్థిక/స్థిరత్వ విషయంలో source జాగ్రత్త సూచన.', analysis: 'D9 Moon నుండి 2వ మరియు 8వ స్థానాల్లో గ్రహాలు లేవు. Source ప్రకారం severityని ఇతర supportive rulesతో కలిపి చూడాలి.', nature: JaiminiRuleNature.adverse, isYoga: true);
    }

    // Arudha Lagna wealth / expenditure / marriage rules.
    final al11 = _signAt(al, 11);
    final al12 = _signAt(al, 12);
    final al2 = _signAt(al, 2);
    final al11Planets = _rasiNames(chart, al11);
    if (al11Planets.isNotEmpty) {
      add(id: 'J1Q3-01', topic: 'ధనం / లాభం', combination: 'AL 11వలో గ్రహ ప్రభావం', result: 'లాభ/సంపద సామర్థ్యానికి source సూచన.', analysis: 'P1/AL ${al + 1}; 11వ రాశి ${al11 + 1}లో ${al11Planets.join(', ')} ఉన్నాయి.', nature: JaiminiRuleNature.favorable, isYoga: true);
      if (al11Planets.any(_benefics.contains)) {
        add(id: 'J1Q3-02', topic: 'ధనం / లాభం', combination: 'AL 11వలో benefic', result: 'న్యాయబద్ధ/సానుకూల లాభాలకు అనుకూల సూచన.', analysis: 'AL 11వలో శుభగ్రహ ప్రభావం ఉంది.', nature: JaiminiRuleNature.favorable);
      }
      if (al11Planets.any(_malefics.contains)) {
        add(id: 'J1Q3-03', topic: 'ధనం / జాగ్రత్త', combination: 'AL 11వలో malefic', result: 'లాభ మార్గాల్లో నైతిక/చట్టపరమైన జాగ్రత్త అవసరమనే source సూచన.', analysis: 'AL 11వలో పాపగ్రహ ప్రభావం ఉంది.', nature: JaiminiRuleNature.adverse);
      }
    }

    if (_rasiNames(chart, al12).any(_malefics.contains)) {
      add(id: 'J1Q3-05', topic: 'వ్యయం / నష్టం', combination: 'AL 12వలో malefic influence', result: 'ఆదాయంతో పోలిస్తే వ్యయం పెరగగలదనే source సూచన.', analysis: 'AL 12వ రాశి ${al12 + 1}లో పాపగ్రహ ప్రభావం ఉంది.', nature: JaiminiRuleNature.adverse);
    }
    if (_allInfluence(chart, al12, const {'Sun', 'Rahu', 'Venus'})) {
      add(id: 'J1Q3-06', topic: 'వ్యయం / అధికార సంబంధం', combination: 'AL 12వపై Sun + Rahu + Venus', result: 'ప్రభుత్వ/అధికార సంబంధిత వ్యయం లేదా నష్టం source సూచన.', analysis: 'AL 12వపై Sun, Rahu, Venus మూడు ప్రభావాలు నమోదయ్యాయి.', nature: JaiminiRuleNature.adverse);
    }
    if (_influences(chart, al12, 'Mercury')) {
      add(id: 'J1Q3-08', topic: 'వ్యయం / వివాదాలు', combination: 'AL 12వపై Mercury', result: 'వివాదాలు/సంబంధాల ద్వారా వ్యయం source సూచన.', analysis: 'Mercury AL 12వను occupy/aspect చేస్తోంది.', nature: JaiminiRuleNature.adverse);
    }
    if (_influences(chart, al12, 'Jupiter')) {
      add(id: 'J1Q3-09', topic: 'వ్యయం / అధికార చెల్లింపులు', combination: 'AL 12వపై Jupiter', result: 'పన్నులు/అధికారిక చెల్లింపుల వల్ల వ్యయం source సూచన.', analysis: 'Jupiter AL 12వతో సంబంధం కలిగి ఉంది.', nature: JaiminiRuleNature.neutral);
    }
    if (_allInfluence(chart, al12, const {'Mars', 'Saturn'})) {
      add(id: 'J1Q3-10', topic: 'వ్యయం / కుటుంబం', combination: 'AL 12వపై Mars + Saturn', result: 'సోదర/కుటుంబ సంబంధ కారణాలతో వ్యయ జాగ్రత్త source సూచన.', analysis: 'AL 12వపై Mars మరియు Saturn ప్రభావాలు ఉన్నాయి.', nature: JaiminiRuleNature.adverse);
    }

    final exaltedInAl2 = chart.planets.where((p) => p.signIndex == al2 && _isExalted(p.name, p.signIndex)).toList();
    if (exaltedInAl2.isNotEmpty) {
      add(id: 'J1Q3-12', topic: 'ధనం / సంపద', combination: 'AL 2వలో exalted planet', result: 'సంపద/స్థిరత్వానికి అనుకూల source సూచన.', analysis: 'AL 2వ రాశిలో ${exaltedInAl2.map((p) => p.name).join(', ')} ఉచ్చస్థితిలో ఉంది.', nature: JaiminiRuleNature.favorable, isYoga: true);
    }

    final a7FromAl = _relativeHouse(al, a7);
    if (_isKendra(a7FromAl) || _isTrikona(a7FromAl)) {
      add(id: 'J1Q3-13', topic: 'ధనం / దారపదం', combination: 'P7 (Darapada) AL నుండి Kendra/Trikona', result: 'సంపద/పురోగతికి బలమైన అనుకూల సూచన.', analysis: 'AL ${al + 1} నుండి P7 ${a7 + 1} = $a7FromAlవ స్థానం.', nature: JaiminiRuleNature.favorable, isYoga: true);
    }
    if (_isKendra(a7FromAl) || _isTrikona(a7FromAl) || _isUpachaya(a7FromAl)) {
      add(id: 'J1Q3-15', topic: 'వివాహం / దాంపత్యం', combination: 'P7 AL నుండి Kendra/Trikona/Upachaya', result: 'దాంపత్య అనుకూలత/సమన్వయానికి source అనుకూల సూచన.', analysis: 'AL నుంచి P7 $a7FromAlవ స్థానంలో ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (const {6, 8, 12}.contains(a7FromAl)) {
      add(id: 'J1Q3-16', topic: 'వివాహం / దాంపత్యం', combination: 'AL–P7 6/8/12 సంబంధం', result: 'సమన్వయంలో విభేదాలు/అడ్డంకుల source సూచన.', analysis: 'AL నుంచి P7 $a7FromAlవ స్థానంలో ఉంది.', nature: JaiminiRuleNature.adverse);
    }

    // Clear Rajayoga: Lagna lord and 5th lord relation/exchange.
    final lagna = chart.ascendantSignIndex;
    final fifth = _signAt(lagna, 5);
    final lagnaLord = _signLord(lagna);
    final fifthLord = _signLord(fifth);
    final llSign = chart.planets.firstWhere((p) => p.name == lagnaLord).signIndex;
    final flSign = chart.planets.firstWhere((p) => p.name == fifthLord).signIndex;
    final lordRelation = llSign == flSign ||
        _drishtiTargets(llSign).contains(flSign) ||
        (llSign == fifth && flSign == lagna);
    if (lordRelation) {
      add(id: 'J2Q1-01', topic: 'రాజయోగం / అధికారం', combination: 'Lagna lord – 5th lord relation', result: 'రాజయోగ సూచన.', analysis: 'Lagna lord $lagnaLord మరియు 5th lord $fifthLord conjunction/aspect/exchange relationలో ఉన్నాయి.', nature: JaiminiRuleNature.favorable, isYoga: true);
    }

    // Rahu fifth from AL + Sun aspect.
    final al5 = _signAt(al, 5);
    if (_rasiHas(chart, al5, 'Rahu') && _influences(chart, al5, 'Sun')) {
      add(id: 'J1Q3-35', topic: 'ఆరోగ్య జాగ్రత్త', combination: 'AL 5వలో Rahu + Sun influence', result: 'కంటి ఆరోగ్యం విషయంలో source జాగ్రత్త సూచన.', analysis: 'AL 5వ రాశిలో Rahu ఉంది; Sun influence కూడా ఉంది. ఇది వైద్య నిర్ధారణ కాదు.', nature: JaiminiRuleNature.adverse);
    }

    final ak4 = _signAt(akRasi, 4);
    if (_rasiHasAll(chart, ak4, const {'Venus', 'Moon'})) {
      add(id: 'J1Q3-36', topic: 'స్థాయి / ప్రతిష్ఠ', combination: 'AK 4వలో Venus + Moon', result: 'స్థాయి/గౌరవ సూచన.', analysis: 'AK రాశి ${akRasi + 1} నుండి 4వ రాశిలో Venus మరియు Moon కలిసి ఉన్నాయి.', nature: JaiminiRuleNature.favorable, isYoga: true);
    }

    // Upapada spouse-family layer.
    final ul2 = _signAt(ul, 2);
    final ul2Names = _rasiNames(chart, ul2);
    if (ul2Names.any(_malefics.contains)) {
      add(id: 'J1Q4-02', topic: 'వివాహం / Upapada', combination: 'UL 2వలో malefic influence', result: 'సంబంధ స్థిరత్వంలో అడ్డంకి/దూరం source సూచన.', analysis: 'P12/UL ${ul + 1}; 2వ రాశి ${ul2 + 1}లో పాపగ్రహ ప్రభావం ఉంది. Source ఫలితాన్ని ఇతర cancellation rulesతో కలిపి చూడాలి.', nature: JaiminiRuleNature.adverse);
    }
    if (ul2Names.any(_benefics.contains)) {
      add(id: 'J1Q4-04', topic: 'వివాహం / Upapada', combination: 'UL 2వలో benefic influence', result: 'ప్రతికూల spouse-loss సూచనను తగ్గించే/నిరోధించే source layer.', analysis: 'UL 2వలో శుభగ్రహ ప్రభావం ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    final ulOr2 = {ul, ul2};
    final debilitatedUl = chart.planets.where((p) => ulOr2.contains(p.signIndex) && _isDebilitated(p.name, p.signIndex)).toList();
    if (debilitatedUl.isNotEmpty) {
      add(id: 'J1Q4-05', topic: 'వివాహం / Upapada', combination: 'UL/2వలో debilitated planet', result: 'దాంపత్య స్థిరత్వంపై ప్రతికూల source సూచన.', analysis: 'UL/2వ layerలో ${debilitatedUl.map((p) => p.name).join(', ')} నీచస్థితిలో ఉంది.', nature: JaiminiRuleNature.adverse);
    }
    final exaltedUl = chart.planets.where((p) => ulOr2.contains(p.signIndex) && _isExalted(p.name, p.signIndex)).toList();
    if (exaltedUl.isNotEmpty) {
      add(id: 'J1Q4-07', topic: 'వివాహం / కుటుంబ స్థాయి', combination: 'UL/2వలో exalted influence', result: 'జీవిత భాగస్వామి కుటుంబ స్థాయి/గౌరవానికి అనుకూల source సూచన.', analysis: 'UL/2వ layerలో ${exaltedUl.map((p) => p.name).join(', ')} ఉచ్చస్థితిలో ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (_rasiHasAny(chart, ul, _benefics) || _rasiHasAny(chart, ul2, _benefics)) {
      add(id: 'J1Q4-09', topic: 'వివాహం / అనుకూలత', combination: 'UL/2వలో benefic placement', result: 'భాగస్వామి/దాంపత్య గుణాలకు అనుకూల source సూచన.', analysis: 'UL లేదా దాని 2వ స్థానంలో శుభగ్రహ స్థానం ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if ((_rasiHas(chart, ul, 'Saturn') || _rasiHas(chart, ul2, 'Saturn')) &&
        (_rasiHas(chart, ul, 'Rahu') || _rasiHas(chart, ul2, 'Rahu'))) {
      add(id: 'J1Q4-10', topic: 'వివాహం / జాగ్రత్త', combination: 'UL/2వ layerలో Saturn + Rahu', result: 'దాంపత్యంలో తీవ్ర విభేదాలు/దూరం పట్ల source జాగ్రత్త సూచన.', analysis: 'UL/2వ layerలో Saturn మరియు Rahu రెండూ సంబంధం కలిగి ఉన్నాయి.', nature: JaiminiRuleNature.adverse);
    }

    // Children layer: historical source indications only, never certainty.
    final ul7 = _signAt(ul, 7);
    final kc7 = _signAt(karakamsaSign, 7);
    final childDeny = _rasiHasAny(chart, ul7, const {'Mercury', 'Saturn', 'Venus'}) ||
        _d9HasAny(navamsa, kc7, const {'Mercury', 'Saturn', 'Venus'});
    if (childDeny) {
      add(id: 'J1Q4-22', topic: 'సంతానం / జాగ్రత్త', combination: 'UL/Karakamsa 7వ source condition', result: 'సంతానం విషయంలో ఆలస్యం/అడ్డంకి source సూచన మాత్రమే.', analysis: 'UL లేదా Karakamsa సంబంధిత 7వ referenceలో Mercury/Saturn/Venus source condition నమోదైంది. ఇది certainty కాదు.', nature: JaiminiRuleNature.adverse);
    }
    final child9Rasi = _signAt(ul7, 9);
    final child9D9 = _signAt(kc7, 9);
    if (_rasiHasAny(chart, child9Rasi, const {'Sun', 'Jupiter', 'Rahu'}) ||
        _d9HasAny(navamsa, child9D9, const {'Sun', 'Jupiter', 'Rahu'})) {
      add(id: 'J1Q4-23', topic: 'సంతానం', combination: 'Child-reference 9వలో Sun/Jupiter/Rahu', result: 'సంతానం విస్తరణకు source అనుకూల సూచన.', analysis: 'సంతానం reference 9వ layerలో Sun/Jupiter/Rahu ప్రభావం ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (_rasiHas(chart, child9Rasi, 'Moon') || _d9Has(navamsa, child9D9, 'Moon')) {
      add(id: 'J1Q4-24', topic: 'సంతానం', combination: 'Child-reference 9వలో Moon', result: 'ఒక ప్రధాన సంతాన సూచనగా source పేర్కొంటుంది.', analysis: 'సంతానం reference 9వ layerలో Moon ఉంది.', nature: JaiminiRuleNature.neutral);
    }

    // Sibling layer from UL / UL lord references (direct UL layer implemented here).
    final ul3 = _signAt(ul, 3);
    final ul11 = _signAt(ul, 11);
    if ((_rasiHas(chart, ul3, 'Saturn') || _rasiHas(chart, ul11, 'Saturn')) &&
        (_rasiHas(chart, ul3, 'Rahu') || _rasiHas(chart, ul11, 'Rahu'))) {
      add(id: 'J1Q4-30', topic: 'సోదరులు / జాగ్రత్త', combination: 'UL 3/11లో Saturn + Rahu', result: 'సోదర సంబంధాల్లో తీవ్ర అడ్డంకి/దూరం source సూచన.', analysis: 'UL నుండి 3/11 స్థానాల్లో Saturn మరియు Rahu ప్రభావం ఉంది.', nature: JaiminiRuleNature.adverse);
    }
    final siblingPlanets = <String>{..._rasiNames(chart, ul3), ..._rasiNames(chart, ul11)};
    if (siblingPlanets.any((p) => const {'Mars', 'Jupiter', 'Moon', 'Mercury'}.contains(p))) {
      add(id: 'J1Q4-32', topic: 'సోదరులు', combination: 'UL 3/11లో sibling-giving planets', result: 'సోదరులు/సోదరీమణుల సంఖ్యకు అనుకూల source సూచన.', analysis: 'UL 3/11 layerలో Mars/Jupiter/Moon/Mercuryలో కనీసం ఒకటి ఉంది.', nature: JaiminiRuleNature.favorable);
    }
    if (_rasiHas(chart, ul3, 'Ketu') || _rasiHas(chart, ul11, 'Ketu')) {
      add(id: 'J1Q4-35', topic: 'సోదరులు', combination: 'UL 3/11లో Ketu', result: 'సోదరీమణుల ప్రాధాన్యానికి source సూచన.', analysis: 'UL 3వ లేదా 11వ స్థానంలో Ketu ఉంది.', nature: JaiminiRuleNature.neutral);
    }

    // Stable ordering: yogas first, then favourable, adverse, neutral; within that by topic/rule id.
    int rank(JaiminiRuleHit h) {
      if (h.isYoga) return 0;
      return switch (h.nature) {
        JaiminiRuleNature.favorable => 1,
        JaiminiRuleNature.adverse => 2,
        JaiminiRuleNature.neutral => 3,
      };
    }
    hits.sort((a, b) {
      final r = rank(a).compareTo(rank(b));
      if (r != 0) return r;
      final t = a.topic.compareTo(b.topic);
      if (t != 0) return t;
      return a.ruleId.compareTo(b.ruleId);
    });
    return hits;
  }

  static String _remedyText(JaiminiRuleNature nature) {
    if (nature == JaiminiRuleNature.favorable) {
      return 'ఈ supplied జైమిని sourceలో ఈ అనుకూల ఫలితానికి ప్రత్యేక పరిహారం ఇవ్వలేదు.';
    }
    return 'ఈ supplied జైమిని sourceలో నిర్దిష్ట పరిహారం ఇవ్వలేదు. ఇతర supportive/obstructive నియమాలతో ఫలితాన్ని కలిపి పరిశీలించాలి; source ఆధారిత పరిహార నియమాలు అందిన తర్వాత మాత్రమే ఇక్కడ జోడించాలి.';
  }

  static int _signAt(int referenceSign, int house) => (referenceSign + house - 1) % 12;

  static int _relativeHouse(int fromSign, int toSign) => ((toSign - fromSign + 12) % 12) + 1;

  static bool _isKendra(int house) => const {1, 4, 7, 10}.contains(house);
  static bool _isTrikona(int house) => const {1, 5, 9}.contains(house);
  static bool _isUpachaya(int house) => const {3, 6, 10, 11}.contains(house);

  static bool _rasiHas(AstroChartResult chart, int sign, String planet) =>
      chart.planets.any((p) => p.name == planet && p.signIndex == sign);

  static bool _rasiHasAny(AstroChartResult chart, int sign, Set<String> planets) =>
      chart.planets.any((p) => p.signIndex == sign && planets.contains(p.name));

  static bool _rasiHasAll(AstroChartResult chart, int sign, Set<String> planets) =>
      planets.every((name) => _rasiHas(chart, sign, name));

  static List<String> _rasiNames(AstroChartResult chart, int sign) =>
      chart.planets.where((p) => p.signIndex == sign).map((p) => p.name).toList(growable: false);

  static bool _d9Has(VargaChartData d9, int sign, String planet) =>
      d9.planets.any((p) => p.name == planet && p.signIndex == sign);

  static bool _d9HasAny(VargaChartData d9, int sign, Set<String> planets) =>
      d9.planets.any((p) => p.signIndex == sign && planets.contains(p.name));

  static bool _d9HasAll(VargaChartData d9, int sign, Set<String> planets) =>
      planets.every((name) => _d9Has(d9, sign, name));

  static List<String> _d9Names(VargaChartData d9, int sign) =>
      d9.planets.where((p) => p.signIndex == sign).map((p) => p.name).toList(growable: false);

  static bool _influences(AstroChartResult chart, int targetSign, String planet) {
    final p = chart.planets.firstWhere((x) => x.name == planet);
    return p.signIndex == targetSign || _drishtiTargets(p.signIndex).contains(targetSign);
  }

  static bool _allInfluence(AstroChartResult chart, int targetSign, Set<String> planets) =>
      planets.every((p) => _influences(chart, targetSign, p));

  static bool _isExalted(String planet, int sign) {
    final exaltation = <String, int>{
      'Sun': 0,
      'Moon': 1,
      'Mars': 9,
      'Mercury': 5,
      'Jupiter': 3,
      'Venus': 11,
      'Saturn': 6,
    };
    return exaltation[planet] == sign;
  }

  static bool _isDebilitated(String planet, int sign) {
    final debilitation = <String, int>{
      'Sun': 6,
      'Moon': 7,
      'Mars': 3,
      'Mercury': 11,
      'Jupiter': 9,
      'Venus': 5,
      'Saturn': 0,
    };
    return debilitation[planet] == sign;
  }

  static String _signLord(int signIndex) {
    return switch (signIndex) {
      0 => 'Mars',
      1 => 'Venus',
      2 => 'Mercury',
      3 => 'Moon',
      4 => 'Sun',
      5 => 'Mercury',
      6 => 'Venus',
      7 => 'Mars',
      8 => 'Jupiter',
      9 => 'Saturn',
      10 => 'Saturn',
      11 => 'Jupiter',
      _ => throw ArgumentError('Invalid sign index: $signIndex'),
    };
  }

  /// Supplied source core: movable -> 5/8/11, fixed -> 3/6/9,
  /// dual -> 4/7/10 counted from the source sign.
  static List<int> _drishtiTargets(int source) {
    final modality = source % 3; // 0 movable, 1 fixed, 2 dual
    final offsets = switch (modality) {
      0 => const [4, 7, 10],
      1 => const [2, 5, 8],
      _ => const [3, 6, 9],
    };
    return offsets.map((o) => (source + o) % 12).toList(growable: false);
  }

  static List<JaiminiArgalaRow> _argalaRows(AstroChartResult chart) {
    final lagna = chart.ascendantSignIndex;
    final labels = <(String, int)>[
      ('2వ అర్గళ', 2),
      ('4వ అర్గళ', 4),
      ('11వ అర్గళ', 11),
      ('5వ అర్గళ', 5),
      ('12వ విరోధ', 12),
      ('10వ విరోధ', 10),
      ('3వ విరోధ', 3),
      ('9వ విరోధ', 9),
    ];
    return labels.map((entry) {
      final sign = (lagna + entry.$2 - 1) % 12;
      final planets = chart.planets
          .where((p) => p.signIndex == sign)
          .map((p) => p.shortName)
          .toList(growable: false);
      return JaiminiArgalaRow(
        label: entry.$1,
        signIndex: sign,
        planets: planets,
      );
    }).toList(growable: false);
  }
}
