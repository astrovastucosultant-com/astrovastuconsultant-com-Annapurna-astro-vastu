import 'astro_models.dart';

class BnnSourceSection {
  final String code;
  final String title;
  final String subtitle;
  final int count;
  final List<int> pages;
  final List<String> ruleIds;

  const BnnSourceSection({
    required this.code,
    required this.title,
    required this.subtitle,
    required this.count,
    required this.pages,
    required this.ruleIds,
  });
}

class BnnPlanetEvidence {
  final String name;
  final String shortName;
  final int signIndex;
  final int houseFromJupiter;
  final String houseClass;

  const BnnPlanetEvidence({
    required this.name,
    required this.shortName,
    required this.signIndex,
    required this.houseFromJupiter,
    required this.houseClass,
  });
}

class BnnAgeIndication {
  final String id;
  final String title;
  final String fromPlanet;
  final String toPlanet;
  final int relativeHouse;
  final List<int> ages;
  final int sourcePage;
  final bool sensitive;
  final String note;

  const BnnAgeIndication({
    required this.id,
    required this.title,
    required this.fromPlanet,
    required this.toPlanet,
    required this.relativeHouse,
    required this.ages,
    required this.sourcePage,
    this.sensitive = false,
    this.note = '',
  });
}

class BnnLifeTurningPoint {
  final String lord;
  final int houseFromJupiter;
  final String theme;
  final List<int> ages;

  const BnnLifeTurningPoint({
    required this.lord,
    required this.houseFromJupiter,
    required this.theme,
    required this.ages,
  });
}

class BnnAnalysis {
  final int jupiterSignIndex;
  final List<BnnPlanetEvidence> planets;
  final List<BnnAgeIndication> ageIndications;
  final BnnLifeTurningPoint? lifeTurningPoint;

  const BnnAnalysis({
    required this.jupiterSignIndex,
    required this.planets,
    required this.ageIndications,
    required this.lifeTurningPoint,
  });
}

/// Bhrigu Nandi Nadi / Brighu Naadi source-linked engine.
///
/// The supplied 21-page rulebook explicitly says to treat Jupiter's sign as
/// the first house for this model. The app therefore keeps this BNN reference
/// frame separate from the ordinary birth Ascendant. Rules that are not yet
/// safely machine-readable remain available through the complete source-page
/// registry rather than being guessed.
class BnnService {
  static const sourceTitle = 'భృగు నాడి సంగ్రహ — రూల్ బేస్ రిఫరెన్స్';
  static const sourceFile = 'Brighu_Naadi_Purnna_Rulebook.pdf';
  static const sourcePageCount = 21;

  static const List<String> signNamesTe = [
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  static const List<String> _signLords = [
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];

  static List<String> _ids(String prefix, int from, int to, {int width = 2}) =>
      [for (var i = from; i <= to; i++) '$prefix${i.toString().padLeft(width, '0')}'];

  static List<String> _aIds() => [for (var i = 1; i <= 15; i++) 'R-A${i.toString().padLeft(2, '0')}'];

  static final List<BnnSourceSection> sourceSections = [
    BnnSourceSection(
      code: 'A',
      title: 'పద్ధతి / కాల నిర్ణయం',
      subtitle: 'BNN మూల రూల్స్ R-A01–R-A15',
      count: 15,
      pages: const [2],
      ruleIds: _aIds(),
    ),
    BnnSourceSection(
      code: 'C',
      title: 'గురు యోగాలు',
      subtitle: 'C01–C65 • గురు నుంచి భావాలు / గ్రహ సంబంధాలు',
      count: 65,
      pages: const [3, 4],
      ruleIds: _ids('C', 1, 65),
    ),
    BnnSourceSection(
      code: 'E',
      title: 'శని — వృత్తి / కర్మ రూల్స్',
      subtitle: 'E01–E74',
      count: 74,
      pages: const [8, 9],
      ruleIds: _ids('E', 1, 74),
    ),
    BnnSourceSection(
      code: 'F',
      title: 'బుధుడు — విద్య / బుద్ధి',
      subtitle: 'F01–F28',
      count: 28,
      pages: const [10, 11],
      ruleIds: _ids('F', 1, 28),
    ),
    BnnSourceSection(
      code: 'G',
      title: 'సూర్యుడు — తండ్రి / గౌరవం / జీవనస్థలం',
      subtitle: 'G01–G38',
      count: 38,
      pages: const [11, 12],
      ruleIds: _ids('G', 1, 38),
    ),
    BnnSourceSection(
      code: 'H',
      title: 'శుక్రుడు — వివాహం / ధనం / భార్య',
      subtitle: 'H01–H41',
      count: 41,
      pages: const [13, 14],
      ruleIds: _ids('H', 1, 41),
    ),
    BnnSourceSection(
      code: 'I',
      title: 'కుజుడు — సోదరులు / భూమి / భర్త',
      subtitle: 'I01–I42',
      count: 42,
      pages: const [14, 15],
      ruleIds: _ids('I', 1, 42),
    ),
    BnnSourceSection(
      code: 'J',
      title: 'చంద్రుడు — తల్లి / మనసు / ప్రయాణం',
      subtitle: 'J01–J26',
      count: 26,
      pages: const [15, 16],
      ruleIds: _ids('J', 1, 26),
    ),
    BnnSourceSection(
      code: 'K',
      title: 'రాహు / కేతు / దిశలు',
      subtitle: 'K01–K14',
      count: 14,
      pages: const [16],
      ruleIds: _ids('K', 1, 14),
    ),
  ];

  static int pageForRule(String id) {
    if (id.startsWith('R-A')) return 2;
    final prefix = id.substring(0, 1);
    final n = int.tryParse(id.substring(1)) ?? 0;
    return switch (prefix) {
      'C' => n <= 36 ? 3 : 4,
      'E' => n <= 36 ? 8 : 9,
      'F' => n <= 4 ? 10 : 11,
      'G' => n <= 12 ? 11 : 12,
      'H' => n <= 28 ? 13 : 14,
      'I' => n <= 18 ? 14 : 15,
      'J' => n <= 10 ? 15 : 16,
      'K' => 16,
      _ => 1,
    };
  }

  static BnnAnalysis analyze(AstroChartResult chart) {
    final jupiter = _planet(chart, 'Jupiter');
    final jupiterSign = jupiter?.signIndex ?? 0;
    final planets = chart.planets.map((p) {
      final h = relativeHouse(jupiterSign, p.signIndex);
      return BnnPlanetEvidence(
        name: p.name,
        shortName: p.shortName,
        signIndex: p.signIndex,
        houseFromJupiter: h,
        houseClass: classifyHouse(h),
      );
    }).toList(growable: false);

    final age = <BnnAgeIndication>[];
    void addAge({
      required String id,
      required String title,
      required String from,
      required String to,
      required Map<int, List<int>> table,
      required int page,
      bool sensitive = false,
      String note = '',
    }) {
      final a = _planet(chart, from);
      final b = _planet(chart, to);
      if (a == null || b == null) return;
      final h = relativeHouse(a.signIndex, b.signIndex);
      final ages = table[h];
      if (ages == null || ages.isEmpty) return;
      age.add(BnnAgeIndication(
        id: id,
        title: title,
        fromPlanet: from,
        toPlanet: to,
        relativeHouse: h,
        ages: ages,
        sourcePage: page,
        sensitive: sensitive,
        note: note,
      ));
    }

    addAge(
      id: 'BNN-AGE-CAREER',
      title: 'వృత్తి ప్రారంభం / మార్పు',
      from: 'Saturn',
      to: 'Venus',
      table: _careerSaturnVenus,
      page: 18,
    );
    addAge(
      id: 'BNN-AGE-MARRIAGE',
      title: 'వివాహ వయస్సు',
      from: 'Jupiter',
      to: 'Venus',
      table: _marriageJupiterVenus,
      page: 18,
    );
    addAge(
      id: 'BNN-AGE-FINANCE',
      title: 'ఆర్థికాభివృద్ధి వయస్సులు',
      from: 'Jupiter',
      to: 'Venus',
      table: _financeJupiterVenus,
      page: 18,
    );
    addAge(
      id: 'BNN-AGE-FAME',
      title: 'పేరు / ప్రఖ్యాతి వయస్సులు',
      from: 'Jupiter',
      to: 'Sun',
      table: _fameJupiterSun,
      page: 19,
    );
    addAge(
      id: 'BNN-AGE-PLACE-JU-SA',
      title: 'స్థల మార్పు వయస్సు',
      from: 'Jupiter',
      to: 'Saturn',
      table: _placeJupiterSaturn,
      page: 19,
    );
    addAge(
      id: 'BNN-AGE-PLACE-SA-MO',
      title: 'స్థల మార్పు — శని/చంద్ర సంబంధం',
      from: 'Saturn',
      to: 'Moon',
      table: _placeSaturnMoon,
      page: 20,
    );

    final lordName = _signLords[jupiterSign];
    final lordPlanet = _planet(chart, lordName);
    BnnLifeTurningPoint? turning;
    if (lordPlanet != null) {
      final h = relativeHouse(jupiterSign, lordPlanet.signIndex);
      final t = _lifeTurning[h];
      if (t != null && t.$2.isNotEmpty) {
        turning = BnnLifeTurningPoint(
          lord: lordName,
          houseFromJupiter: h,
          theme: t.$1,
          ages: t.$2,
        );
      }
    }

    return BnnAnalysis(
      jupiterSignIndex: jupiterSign,
      planets: planets,
      ageIndications: age,
      lifeTurningPoint: turning,
    );
  }

  static PlanetPosition? _planet(AstroChartResult chart, String name) {
    for (final p in chart.planets) {
      if (p.name == name) return p;
    }
    return null;
  }

  static int relativeHouse(int fromSign, int toSign) => ((toSign - fromSign + 12) % 12) + 1;

  static String classifyHouse(int h) {
    if (h == 1) return 'త్రికోణ + కేంద్ర';
    if (const {5, 9}.contains(h)) return 'త్రికోణ • శ్రేష్ఠం';
    if (const {4, 7, 10}.contains(h)) return 'కేంద్ర • మంచి';
    if (const {6, 8, 12}.contains(h)) return 'త్రిక • జాగ్రత్త';
    return 'మధ్యస్థ';
  }

  static const Map<int, List<int>> _careerSaturnVenus = {
    3: [8, 21],
    4: [10, 25],
    5: [12, 26],
    6: [15, 22],
    7: [18, 24],
    8: [20, 31],
    9: [22, 35],
    10: [25],
    11: [22],
    12: [30],
  };

  static const Map<int, List<int>> _marriageJupiterVenus = {
    2: [24, 25],
    3: [26, 27],
    4: [15, 16],
    5: [16, 22],
    6: [29, 30],
    7: [18, 19],
    8: [20, 21],
    9: [22],
    10: [22],
    11: [22, 23],
    12: [24, 30],
  };

  static const Map<int, List<int>> _financeJupiterVenus = {
    2: [25, 32, 38, 44, 50, 56],
    3: [27, 33, 39, 45, 51, 57],
    4: [28, 34, 40, 46, 52, 58],
    5: [29, 35, 41, 47, 53, 59],
    6: [24, 30, 36, 42, 48, 54],
    7: [25, 31, 37, 43, 49, 55],
    8: [26, 32, 38, 44, 50, 56],
    9: [21, 27, 33, 34, 51, 57],
    10: [22, 28, 34, 40, 46, 52, 58],
    11: [23, 29, 35, 41, 47, 53, 59],
    12: [24, 30, 36, 42, 48, 54, 60],
  };

  static const Map<int, List<int>> _fameJupiterSun = {
    2: [31, 43, 55],
    3: [32, 38, 44],
    4: [34, 40, 46],
    5: [28, 34, 46],
    6: [35, 41],
    7: [31, 36, 43, 48],
    8: [37, 50],
    9: [44, 50],
    10: [45, 57],
    11: [28, 34, 40, 46, 52],
    12: [36, 42, 47],
  };

  static const Map<int, List<int>> _placeJupiterSaturn = {
    1: [31],
    2: [30],
    3: [57],
    4: [55],
    5: [52],
    6: [50],
    7: [48],
    8: [45],
    9: [42],
    10: [40],
    11: [37],
  };

  static const Map<int, List<int>> _placeSaturnMoon = {
    6: [15, 30, 45],
    7: [17, 32, 47],
    8: [20, 35, 50],
    9: [7, 22, 37, 52],
    10: [10, 25, 40, 55],
    11: [12, 27, 42, 57],
    12: [17, 30, 45, 60],
  };

  static const Map<int, (String, List<int>)> _lifeTurning = {
    1: ('అదృష్టం / శుభజయం', [13, 25, 37, 49]),
    2: ('కష్టపడి ధనం', [26, 38, 50]),
    3: ('సక్సెస్ / ప్రయాణాలు', [15, 27, 39, 51]),
    4: ('భూమి / వాహనత్వం', [28, 40, 52]),
    5: ('సుఖాలు', [17, 29, 41, 53]),
    6: ('అనారోగ్య సూచన', [18, 30, 42, 54]),
    7: ('శతృవుల అధికం', [19, 31, 43, 45]),
    8: ('సెన్సిటివ్ source entry — వ్యక్తిగత ఫలితంగా app చూపించదు', const <int>[]),
    9: ('సుదూర ప్రయాణాలు', [21, 33, 45, 57]),
    10: ('గొప్ప గౌరవాలు', [22, 34, 46, 58]),
    11: ('ధనం / కొత్త స్నేహితులు', [23, 35, 47, 59]),
    12: ('సెన్సిటివ్ source entry — వ్యక్తిగత ఫలితంగా app చూపించదు', const <int>[]),
  };
}
