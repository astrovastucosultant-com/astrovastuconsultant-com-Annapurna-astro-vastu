import 'd10_career_service.dart';

enum D10YearCategory { rise, fall, middle }

/// Display-only grouping of *calculated* MD/AD windows. Never fills gaps with
/// invented dates, and never calls an unverified year a neutral year.
class D10CareerYearService {
  static bool matches(D10CareerWindow window, D10YearCategory category) {
    switch (category) {
      case D10YearCategory.rise:
        return window.eventKey == 'rise' || window.eventKey == 'promotion';
      case D10YearCategory.fall:
        return window.eventKey == 'job_loss';
      case D10YearCategory.middle:
        return window.eventKey == 'career_change' || window.eventKey == 'transfer';
    }
  }

  static Map<int, List<D10CareerWindow>> yearsFor(
    List<D10CareerWindow> windows,
    D10YearCategory category,
  ) {
    final result = <int, List<D10CareerWindow>>{};
    for (final window in windows) {
      if (!matches(window, category) || !window.end.isAfter(window.start)) continue;
      // Dasha end is exclusive: a window ending Jan 1 is NOT active next year.
      final inclusiveEnd = window.end.subtract(const Duration(microseconds: 1));
      for (var year = window.start.year; year <= inclusiveEnd.year; year++) {
        result.putIfAbsent(year, () => <D10CareerWindow>[]).add(window);
      }
    }
    return Map<int, List<D10CareerWindow>>.fromEntries(
      result.entries.toList()..sort((a, b) => a.key.compareTo(b.key)),
    );
  }

  static DateTime segmentStart(D10CareerWindow window, int year) {
    final first = DateTime(year);
    return window.start.isAfter(first) ? window.start : first;
  }

  static DateTime segmentEnd(D10CareerWindow window, int year) {
    final afterYear = DateTime(year + 1);
    return window.end.isBefore(afterYear) ? window.end : afterYear;
  }
}
