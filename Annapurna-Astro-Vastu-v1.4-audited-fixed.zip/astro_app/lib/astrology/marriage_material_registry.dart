class MarriageMaterialRuleEntry {
  final String id;
  final int page;
  final List<int> factors;
  final String topic;
  final String note;
  final bool requiresTwoCharts;

  const MarriageMaterialRuleEntry({
    required this.id,
    required this.page,
    required this.factors,
    required this.topic,
    required this.note,
    this.requiresTwoCharts = false,
  });
}

/// Source registry for the user-supplied `marriage my meterial.pdf`.
///
/// Important boundary: the PDF contains a mixture of printed tables and
/// handwritten formulas. Every distinct source rule is indexed here so it is
/// part of the app's rule catalog. A rule is not auto-fired merely because it
/// exists in this registry. Exact chart arithmetic/conditions must be
/// transcribed and validated before an automatic verdict is enabled.
class MarriageMaterialRegistry {
  static const String sourceName = 'marriage my meterial.pdf';

  static const List<MarriageMaterialRuleEntry> entries = [
    // Printed matching / relationship tables — pages 1–5.
    MarriageMaterialRuleEntry(id: 'MM-P01-S02', page: 1, factors: [9], topic: 'వధూవర / దశ-భుక్తి సంబంధ పట్టిక', note: 'Printed source table; two-person/matching context.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P02-R01', page: 2, factors: [7, 9], topic: 'Matching rule R-01', note: 'Printed R-01 table; exact source cells must be used.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P02-R02', page: 2, factors: [7, 9], topic: 'Matching rule R-02', note: 'Printed R-02 table; exact source cells must be used.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P02-R03', page: 2, factors: [7, 9], topic: 'Matching rule R-03', note: 'Printed R-03 table; exact source cells must be used.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P02-S04', page: 2, factors: [9], topic: 'Matching rule — సూత్రం 04', note: 'Printed compatible/incompatible pairing table.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P03-S05', page: 3, factors: [9], topic: 'Matching rule — సూత్రం 05', note: 'Printed male/female group table.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P03-S06', page: 3, factors: [9], topic: 'వేధ నక్షత్ర rule — సూత్రం 06', note: 'Printed Vedha Nakshatra diagram.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P04-S07', page: 4, factors: [9], topic: 'నాడి కూటము — సూత్రం 07', note: 'Printed Adi/Madhya/Antya Nadi table.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P04-S08', page: 4, factors: [9], topic: 'రాశి కూటము — సూత్రం 08', note: 'Printed Rashi matching table.', requiresTwoCharts: true),
    MarriageMaterialRuleEntry(id: 'MM-P05-S09', page: 5, factors: [9], topic: 'భూత కూటము — సూత్రం 09', note: 'Printed Bhuta matching table.', requiresTwoCharts: true),

    // Handwritten source rules — pages 6–20. Page/factor mapping follows the
    // chart labels written in the source (D1/D7/D9/D30 where explicit).
    MarriageMaterialRuleEntry(id: 'MM-R01', page: 6, factors: [1], topic: 'వివాహ rule 01', note: 'Handwritten D1 marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R02', page: 6, factors: [1], topic: 'వివాహ rule 02', note: 'Handwritten D1 marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R03', page: 6, factors: [1], topic: 'వివాహ rule 03', note: 'Handwritten D1 house-combination rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R04', page: 6, factors: [1], topic: 'వివాహ rule 04', note: 'Handwritten D1 marriage combination rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R05', page: 6, factors: [9], topic: 'నవాంశ rule 05', note: 'Handwritten D9/Navamsha rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R06', page: 6, factors: [1, 9], topic: 'వివాహ rule 06', note: 'Handwritten cross-chart marriage rule.'),

    MarriageMaterialRuleEntry(id: 'MM-R07', page: 7, factors: [1], topic: 'రాశి చక్ర వివాహ rule 07', note: 'Handwritten D1 rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R07.1', page: 7, factors: [1], topic: 'రాశి చక్ర వివాహ rule 07.1', note: 'Handwritten D1 supplementary rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R08', page: 7, factors: [9], topic: 'ప్రేమ పెళ్లి / D9 rule 08', note: 'Handwritten D9 marriage/love rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R08.01', page: 7, factors: [9], topic: 'నవాంశ rule 08.01', note: 'Handwritten D9 supplementary marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R08.02', page: 7, factors: [1, 9], topic: 'వివాహ rule 08.02', note: 'Handwritten relationship/marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R08.03', page: 7, factors: [1, 9], topic: 'వివాహ rule 08.03', note: 'Handwritten continuation rule.'),

    MarriageMaterialRuleEntry(id: 'MM-R09', page: 8, factors: [1, 30], topic: 'వివాహ rule 09', note: 'Handwritten D1/D30 cross-check rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R10-A', page: 8, factors: [1], topic: 'వివాహ rule 10-A', note: 'Handwritten D1 sub-rule A.'),
    MarriageMaterialRuleEntry(id: 'MM-R10-B', page: 8, factors: [1], topic: 'వివాహ rule 10-B', note: 'Handwritten D1 sub-rule B.'),
    MarriageMaterialRuleEntry(id: 'MM-R10-C', page: 8, factors: [1], topic: 'వివాహ rule 10-C', note: 'Handwritten D1 sub-rule C.'),

    MarriageMaterialRuleEntry(id: 'MM-R11-A', page: 9, factors: [1, 9], topic: 'వివాహ rule 11-A', note: 'Handwritten rule 11 first condition.'),
    MarriageMaterialRuleEntry(id: 'MM-R11-B', page: 9, factors: [1, 9], topic: 'వివాహ rule 11-B', note: 'Handwritten rule 11 second condition.'),
    MarriageMaterialRuleEntry(id: 'MM-R12-1', page: 9, factors: [1], topic: '11వ భావ సంబంధ rule 12-1', note: 'Handwritten rule 12 first condition.'),
    MarriageMaterialRuleEntry(id: 'MM-R12-2', page: 9, factors: [1], topic: '11వ భావ సంబంధ rule 12-2', note: 'Handwritten rule 12 second condition.'),

    MarriageMaterialRuleEntry(id: 'MM-R13', page: 10, factors: [7], topic: 'D7 rule 13', note: 'Handwritten D7 table/condition rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R14', page: 10, factors: [7], topic: 'D7 rule 14', note: 'Handwritten D7 supplementary table/condition rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R15', page: 11, factors: [7], topic: 'D7 rule 15', note: 'Handwritten D7 house/table rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R16', page: 11, factors: [7], topic: 'D7 rule 16', note: 'Handwritten D7 calculation table rule.'),

    MarriageMaterialRuleEntry(id: 'MM-R17.1', page: 12, factors: [1, 9], topic: 'వివాహ rule 17.1', note: 'Handwritten marriage timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R17.2', page: 12, factors: [1, 9], topic: 'వివాహ rule 17.2', note: 'Handwritten marriage timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R17.3', page: 12, factors: [1, 9], topic: 'వివాహ rule 17.3', note: 'Handwritten marriage timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R17.4', page: 12, factors: [1, 9], topic: 'వివాహ rule 17.4', note: 'Handwritten marriage timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R17.5', page: 12, factors: [1, 9], topic: 'వివాహ rule 17.5', note: 'Handwritten marriage timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R17.6', page: 12, factors: [1, 9], topic: 'వివాహ rule 17.6', note: 'Handwritten marriage timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R18', page: 12, factors: [1, 9], topic: 'వివాహ rule 18', note: 'Handwritten PL/D1 relationship rule.'),

    MarriageMaterialRuleEntry(id: 'MM-R19', page: 13, factors: [1, 9], topic: 'వివాహ rule 19', note: 'Handwritten marriage relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R20', page: 13, factors: [1, 9], topic: 'వివాహ rule 20', note: 'Handwritten marriage relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R21', page: 13, factors: [1, 9], topic: 'వివాహ rule 21', note: 'Handwritten marriage relationship/timing rule.'),

    MarriageMaterialRuleEntry(id: 'MM-R22', page: 14, factors: [1, 9], topic: 'వివాహ rule 22', note: 'Handwritten marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R23', page: 14, factors: [1, 9], topic: 'వివాహ rule 23', note: 'Handwritten marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R24', page: 14, factors: [1, 9], topic: 'వివాహ timing table — rule 24', note: 'Handwritten year/number timing table.'),

    MarriageMaterialRuleEntry(id: 'MM-R25.1', page: 15, factors: [1, 9], topic: 'వివాహ rule 25.1', note: 'Handwritten timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R25.2', page: 15, factors: [1, 9], topic: 'వివాహ rule 25.2', note: 'Handwritten timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R25.3', page: 15, factors: [1, 9], topic: 'వివాహ rule 25.3', note: 'Handwritten timing/relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R26', page: 15, factors: [1, 9], topic: 'వివాహ rule 26', note: 'Handwritten marriage timing rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R27', page: 15, factors: [1, 9], topic: 'వివాహ rule 27', note: 'Handwritten marriage timing rule.'),

    MarriageMaterialRuleEntry(id: 'MM-R28', page: 16, factors: [1, 9], topic: 'వివాహ rule 28', note: 'Handwritten marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R29', page: 16, factors: [1, 9], topic: 'వివాహ rule 29', note: 'Handwritten marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R30', page: 16, factors: [1, 9], topic: 'వివాహ rule 30', note: 'Handwritten marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R31', page: 16, factors: [1, 9], topic: 'వివాహ rule 31', note: 'Handwritten marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R32', page: 16, factors: [1, 9], topic: 'వివాహ rule 32', note: 'Handwritten marriage rule.'),

    MarriageMaterialRuleEntry(id: 'MM-R33', page: 17, factors: [1, 9], topic: 'వివాహ rule 33', note: 'Handwritten house/lord relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R34', page: 17, factors: [1, 9], topic: 'వివాహ సంబంధ rule 34', note: 'Handwritten relationship rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R35', page: 17, factors: [1, 9], topic: 'వివాహ rule 35', note: 'Handwritten marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R36', page: 17, factors: [1, 9], topic: 'వివాహ rule 36', note: 'Handwritten D1 marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R37', page: 17, factors: [1, 9], topic: 'వివాహ rule 37', note: 'Handwritten marriage rule.'),

    MarriageMaterialRuleEntry(id: 'MM-R38', page: 18, factors: [1, 9], topic: 'వివాహ rule 38', note: 'Handwritten marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R39', page: 18, factors: [1, 9], topic: 'వివాహ కారక / వర్ణ table rule 39', note: 'Handwritten marriage-significator table and continuation.'),

    MarriageMaterialRuleEntry(id: 'MM-R41', page: 19, factors: [1, 9], topic: 'రెండవ వివాహ rule 41', note: 'Handwritten second-marriage rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R42', page: 19, factors: [1, 9], topic: 'వివాహ యోగము rule 42', note: 'Handwritten D1 house-relation rule.'),
    MarriageMaterialRuleEntry(id: 'MM-R43', page: 19, factors: [1, 9], topic: 'UL / వివాహ rule 43', note: 'Handwritten Upapada/UL relationship rule; continues on page 20.'),
    MarriageMaterialRuleEntry(id: 'MM-R44', page: 20, factors: [1, 9], topic: 'వివాహ rule 44', note: 'Handwritten final marriage rule.'),
  ];

  static int get totalRuleCount => entries.length;

  static List<MarriageMaterialRuleEntry> forFactor(int factor) =>
      entries.where((e) => e.factors.contains(factor)).toList(growable: false);
}
