/// Configurable Western event-significator profiles: traditional
/// interpretive conventions, not validated predictive probabilities.
class WesternEventRuleProfile {
  final String id;
  final String label;
  final List<String> planets;
  final List<String> angles;
  final List<int> houses;
  const WesternEventRuleProfile(this.id,this.label,this.planets,this.angles,this.houses);
}

class WesternEventRuleBook {
  static const profiles = <WesternEventRuleProfile>[
    WesternEventRuleProfile('marriage','Marriage',['Venus','Moon','Jupiter'],['Asc','Desc'],[1,7]),
    WesternEventRuleProfile('career','Career',['Sun','Saturn','Jupiter','Mercury'],['MC'],[2,6,10]),
    WesternEventRuleProfile('children','Children',['Moon','Jupiter','Venus'],['Asc'],[5]),
    WesternEventRuleProfile('property','Property',['Moon','Saturn','Jupiter'],['IC'],[4]),
    WesternEventRuleProfile('education','Education',['Mercury','Jupiter'],['MC'],[3,9]),
    WesternEventRuleProfile('relocation','Relocation',['Moon','Mercury','Jupiter'],['IC','Asc'],[4,9,12]),
    WesternEventRuleProfile('health','Health',['Sun','Moon','Mars','Saturn'],['Asc'],[1,6]),
  ];
  static WesternEventRuleProfile? find(String name) {
    var key=name.toLowerCase().trim();
    if(key=='first child' || key=='second child') key='children';
    for(final p in profiles) {
      if(p.id==key || p.label.toLowerCase()==key) return p;
    }
    return null;
  }
  /// Strict angular event gate: one contact must join a profile significator
  /// with an allowed angle. A planet in one contact and an angle in another
  /// must never be combined into an artificial event-specific match.
  static bool matchesAngularContact({required String eventType,
      required String moving, required String natal}) {
    final p=find(eventType);
    if(p==null) return false;
    return (p.planets.contains(moving) && p.angles.contains(natal)) ||
        (p.planets.contains(natal) && p.angles.contains(moving));
  }

  static bool isRelevant({required String eventType,
    required String moving, required String natal}) {
    final p=find(eventType);
    if(p==null) return false; // Never score unknown event as a generic hit.
    return p.planets.contains(moving) || p.planets.contains(natal) ||
        p.angles.contains(moving) || p.angles.contains(natal);
  }
}


extension WesternEventLookup on WesternEventRuleBook {
  static String? profileForTelugu(String label) {
    if (label.contains('వివాహ') || label.contains('ప్రేమ') || label.contains('నిశ్చితార్థ')) return 'Marriage';
    if (label.contains('సంతాన') || label.contains('గర్భ')) return 'Children';
    if (label.contains('విద్య') || label.contains('పరీక్ష')) return 'Education';
    if (label.contains('ఉద్యోగ') || label.contains('వ్యాపార') || label.contains('ప్రమోషన్') || label.contains('విరమణ') || label.contains('గుర్తింపు')) return 'Career';
    if (label.contains('ఆస్తి') || label.contains('ఇంటి') || label.contains('భూమి') || label.contains('వాహనం')) return 'Property';
    if (label.contains('విదేశ') || label.contains('స్థాన మార్పు')) return 'Relocation';
    if (label.contains('ఆరోగ్య') || label.contains('శస్త్ర') || label.contains('ప్రమాద')) return 'Health';
    return null;
  }
}


/// Traditional sign rulership only. Houses must be supplied by a separately
/// verified natal house-cusp calculation; this helper does not calculate cusps.
class WesternNatalHouseLords {
  static const List<String> traditionalRulers = <String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];

  /// signIndex: Aries=0 through Pisces=11.
  static String rulerOfSign(int signIndex) {
    if (signIndex < 0 || signIndex > 11) {
      throw RangeError.range(signIndex, 0, 11, 'signIndex');
    }
    return traditionalRulers[signIndex];
  }

  /// Returns an explicit audit record; does NOT assert that an event occurred.
  static Map<String, Object> auditEventHouse({
    required String eventType,
    required int cuspSignIndex,
    required String contactingPlanet,
  }) {
    final profile = WesternEventRuleBook.find(eventType);
    if (profile == null) {
      return <String,Object>{'status':'UNKNOWN_EVENT'};
    }
    final lord = rulerOfSign(cuspSignIndex);
    return <String,Object>{
      'status':'RULE_CHECK_ONLY',
      'event':profile.id,
      'cuspSignIndex':cuspSignIndex,
      'houseLord':lord,
      'houseLordContact':contactingPlanet == lord,
      'warning':'Requires verified natal cusp, direction, orb and independent event validation',
    };
  }
}
