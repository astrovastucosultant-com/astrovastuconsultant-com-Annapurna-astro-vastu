/// Configurable Western event-significator profiles: traditional
/// interpretive conventions, not validated predictive probabilities.
class WesternEventRuleProfile {
  final String id;
  final String label;
  final List<String> planets;
  final List<String> angles;
  final List<int> houses;
  const WesternEventRuleProfile(this.id,this.label,this.planets,this.angles,this.houses);
}

class WesternEventRuleBook {
  static const profiles = <WesternEventRuleProfile>[
    WesternEventRuleProfile('marriage','Marriage',['Venus','Moon','Jupiter'],['Asc','Desc'],[1,7]),
    WesternEventRuleProfile('career','Career',['Sun','Saturn','Jupiter','Mercury'],['MC'],[2,6,10]),
    WesternEventRuleProfile('children','Children',['Moon','Jupiter','Venus'],['Asc'],[5]),
    WesternEventRuleProfile('property','Property',['Moon','Saturn','Jupiter'],['IC'],[4]),
    WesternEventRuleProfile('education','Education',['Mercury','Jupiter'],['MC'],[4,5,9]),
    WesternEventRuleProfile('relocation','Relocation',['Moon','Mercury','Jupiter'],['IC','Asc'],[4,9,12]),
    WesternEventRuleProfile('health','Health',['Sun','Moon','Mars','Saturn'],['Asc'],[1,6,8]),
    WesternEventRuleProfile('finance','Finance',['Jupiter','Venus'],['Asc'],[2,11]),
    WesternEventRuleProfile('business','Business',['Mercury','Jupiter'],['Asc','MC'],[2,7,10]),
    WesternEventRuleProfile('turning_point','Turning Point',['Uranus','Pluto'],['Asc','MC'],[1,10]),
    WesternEventRuleProfile('spirituality','Spirituality',['Jupiter','Ketu'],['Asc'],[9,12]),
    WesternEventRuleProfile('end_of_life','End of Life',['Saturn'],['Asc'],[8]),
  ];
  static WesternEventRuleProfile? find(String name) {
    var key=name.toLowerCase().trim();
    if(key=='first child' || key=='second child' || key=='childbirth') key='children';
    if(key=='job' || key=='promotion') key='career';
    if(key=='income' || key=='money') key='finance';
    if(key=='foreign travel' || key=='migration') key='relocation';
    if(key=='surgery') key='health';
    if(key=='self employment') key='business';
    if(key=='life change') key='turning_point';
    if(key=='spiritual') key='spirituality';
    for(final p in profiles) {
      if(p.id==key || p.label.toLowerCase()==key) return p;
    }
    return null;
  }
  /// Strict angular event gate: one contact must join a profile significator
  /// with an allowed angle. A planet in one contact and an angle in another
  /// must never be combined into an artificial event-specific match.
  static bool matchesAngularContact({required String eventType,
      required String moving, required String natal}) {
    final p=find(eventType);
    if(p==null) return false;
    return (p.planets.contains(moving) && p.angles.contains(natal)) ||
        (p.planets.contains(natal) && p.angles.contains(moving));
  }

  static bool isRelevant({required String eventType,
    required String moving, required String natal}) {
    final p=find(eventType);
    if(p==null) return false; // Never score unknown event as a generic hit.
    return p.planets.contains(moving) || p.planets.contains(natal) ||
        p.angles.contains(moving) || p.angles.contains(natal);
  }
}


extension WesternEventLookup on WesternEventRuleBook {
  static String? profileForTelugu(String label) {
    if (label.contains('వివాహ') || label.contains('ప్రేమ') || label.contains('నిశ్చితార్థ')) return 'Marriage';
    if (label.contains('సంతాన') || label.contains('గర్భ')) return 'Children';
    if (label.contains('ఆదాయం') || label.contains('ధన') || label.contains('నష్టం')) return 'Finance';
    if (label.contains('ఆధ్యాత్మిక') || label.contains('మతపర')) return 'Spirituality';
    if (label.contains('జీవిత మలుపు') || label.contains('పెద్ద మార్పు')) return 'Turning Point';
    if (label.contains('విద్య') || label.contains('పరీక్ష')) return 'Education';
    if (label.contains('ఉద్యోగ') || label.contains('వ్యాపార') || label.contains('ప్రమోషన్') || label.contains('విరమణ') || label.contains('గుర్తింపు')) return 'Career';
    if (label.contains('ఆస్తి') || label.contains('ఇంటి') || label.contains('భూమి') || label.contains('వాహనం')) return 'Property';
    if (label.contains('విదేశ') || label.contains('స్థాన మార్పు')) return 'Relocation';
    if (label.contains('ఆరోగ్య') || label.contains('శస్త్ర') || label.contains('ప్రమాద')) return 'Health';
    return null;
  }
}


/// Traditional sign rulership only. Houses must be supplied by a separately
/// verified natal house-cusp calculation; this helper does not calculate cusps.
class WesternNatalHouseLords {
  static const List<String> traditionalRulers = <String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];

  /// signIndex: Aries=0 through Pisces=11.
  static String rulerOfSign(int signIndex) {
    if (signIndex < 0 || signIndex > 11) {
      throw RangeError.range(signIndex, 0, 11, 'signIndex');
    }
    return traditionalRulers[signIndex];
  }

  /// Returns an explicit audit record; does NOT assert that an event occurred.
  static Map<String, Object> auditEventHouse({
    required String eventType,
    required int cuspSignIndex,
    required String contactingPlanet,
  }) {
    final profile = WesternEventRuleBook.find(eventType);
    if (profile == null) {
      return <String,Object>{'status':'UNKNOWN_EVENT'};
    }
    final lord = rulerOfSign(cuspSignIndex);
    return <String,Object>{
      'status':'RULE_CHECK_ONLY',
      'event':profile.id,
      'cuspSignIndex':cuspSignIndex,
      'houseLord':lord,
      'houseLordContact':contactingPlanet == lord,
      'warning':'Requires verified natal cusp, direction, orb and independent event validation',
    };
  }
}

/// Explicit gate status for historical audit. A positive status is NOT
/// evidence that an event occurred, and is not a calibrated probability.
class WesternHouseGateAudit {
  static String status({required String eventType, Map<int,int>? cuspSigns}) {
    final profile=WesternEventRuleBook.find(eventType);
    if(profile==null) return 'UNKNOWN_EVENT';
    final house=profile.id=='marriage' ? 7 : profile.id=='children' ? 5 : null;
    if(house==null) return 'NOT_HOUSE_GATED';
    final sign=cuspSigns?[house];
    if(sign==null || sign<0 || sign>11) return 'INSUFFICIENT_CUSP_EVIDENCE';
    return 'CUSP_AVAILABLE_RULE_MATCH_PENDING';
  }
}


/// Reference-only event activation catalog based on user-supplied
/// Annapurna_All_Event_Principles.pdf (2026-10-17), pages 1-3.
/// IMPORTANT: these are traditional interpretive heuristics, not validated
/// predictors; house positions and exact aspects require real ephemerides.
class WesternProgressionEventPrinciple {
  final String eventId;
  final List<int> natalHouses;
  final List<String> naturalSignificators;
  final List<int> natalHouseLords;
  final List<String> solarArcTargets;
  final List<int> progressedMoonHouses;
  final List<String> transitTriggers;
  const WesternProgressionEventPrinciple({required this.eventId,
    required this.natalHouses, required this.naturalSignificators,
    required this.natalHouseLords, required this.solarArcTargets,
    required this.progressedMoonHouses, required this.transitTriggers});
}

class WesternProgressionPrinciples {
  static const double solarArcMaxOrbDegrees = 1.0;
  static const double progressedMoonMaxOrbDegrees = 1.0;
  static const double secondaryOtherMaxOrbDegrees = 1.0;
  static const List<WesternProgressionEventPrinciple> events = [
    WesternProgressionEventPrinciple(eventId:'marriage',natalHouses:[7],naturalSignificators:['Venus'],natalHouseLords:[7],solarArcTargets:['Desc','Asc'],progressedMoonHouses:[7],transitTriggers:['Venus','Jupiter']),
    WesternProgressionEventPrinciple(eventId:'career',natalHouses:[10],naturalSignificators:['Sun','Saturn'],natalHouseLords:[10],solarArcTargets:['MC','Asc'],progressedMoonHouses:[10],transitTriggers:['Saturn','Jupiter']),
    WesternProgressionEventPrinciple(eventId:'children',natalHouses:[5],naturalSignificators:['Jupiter'],natalHouseLords:[5],solarArcTargets:['House5','Asc'],progressedMoonHouses:[5],transitTriggers:['Jupiter']),
    WesternProgressionEventPrinciple(eventId:'property',natalHouses:[4],naturalSignificators:['Moon'],natalHouseLords:[4],solarArcTargets:['IC','Asc'],progressedMoonHouses:[4],transitTriggers:[]),
    WesternProgressionEventPrinciple(eventId:'finance',natalHouses:[2,11],naturalSignificators:['Jupiter','Venus'],natalHouseLords:[2,11],solarArcTargets:['House2','House11','Asc'],progressedMoonHouses:[2,11],transitTriggers:[]),
    WesternProgressionEventPrinciple(eventId:'education',natalHouses:[4,5,9],naturalSignificators:['Mercury','Jupiter'],natalHouseLords:[4,5,9],solarArcTargets:['House5','House9'],progressedMoonHouses:[5,9],transitTriggers:['Mercury','Jupiter']),
    WesternProgressionEventPrinciple(eventId:'relocation',natalHouses:[9,12],naturalSignificators:['Rahu','Jupiter'],natalHouseLords:[9,12],solarArcTargets:['Asc','MC'],progressedMoonHouses:[9,12],transitTriggers:[]),
    WesternProgressionEventPrinciple(eventId:'health',natalHouses:[6,8],naturalSignificators:['Saturn','Mars'],natalHouseLords:[6,8],solarArcTargets:['Asc','House6'],progressedMoonHouses:[6,8],transitTriggers:['Saturn','Mars']),
    WesternProgressionEventPrinciple(eventId:'business',natalHouses:[2,7,10],naturalSignificators:['Mercury','Jupiter'],natalHouseLords:[2,7,10],solarArcTargets:['MC','Asc'],progressedMoonHouses:[2,10],transitTriggers:[]),
    WesternProgressionEventPrinciple(eventId:'turning_point',natalHouses:[1,10],naturalSignificators:['Uranus','Pluto'],natalHouseLords:[],solarArcTargets:['Asc','MC'],progressedMoonHouses:[],transitTriggers:[]),
    WesternProgressionEventPrinciple(eventId:'spirituality',natalHouses:[9,12],naturalSignificators:['Ketu','Jupiter'],natalHouseLords:[9,12],solarArcTargets:['House9','House12'],progressedMoonHouses:[9,12],transitTriggers:[]),
    WesternProgressionEventPrinciple(eventId:'end_of_life',natalHouses:[8],naturalSignificators:['Saturn'],natalHouseLords:[8],solarArcTargets:['Asc'],progressedMoonHouses:[8],transitTriggers:['Saturn']),
  ];
  static WesternProgressionEventPrinciple? forEvent(String label) {
    final profile = WesternEventRuleBook.find(label);
    if(profile==null) return null;
    for(final principle in events) {
      if(principle.eventId==profile.id) return principle;
    }
    return null;
  }
  /// A contact is supporting evidence, not an event prediction.
  static bool solarArcOrbWithinReference(double orb) =>
      orb.isFinite && orb >= 0 && orb <= solarArcMaxOrbDegrees;
}
