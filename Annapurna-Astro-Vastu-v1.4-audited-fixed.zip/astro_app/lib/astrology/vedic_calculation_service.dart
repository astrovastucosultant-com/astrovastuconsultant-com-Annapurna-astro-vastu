import 'astro_models.dart';

class NakshatraPosition {
  final int index;
  final int pada;

  const NakshatraPosition({required this.index, required this.pada});
}

class PanchangaSummary {
  final String tithi;
  final String paksha;
  final String nakshatra;
  final int nakshatraPada;
  final String yoga;
  final String karana;

  const PanchangaSummary({
    required this.tithi,
    required this.paksha,
    required this.nakshatra,
    required this.nakshatraPada,
    required this.yoga,
    required this.karana,
  });
}

class VedicCalculationService {
  static const List<String> nakshatraNamesTe = [
    'అశ్విని',
    'భరణి',
    'కృత్తిక',
    'రోహిణి',
    'మృగశిర',
    'ఆర్ద్ర',
    'పునర్వసు',
    'పుష్యమి',
    'ఆశ్లేష',
    'మఖ',
    'పుబ్బ',
    'ఉత్తర',
    'హస్త',
    'చిత్త',
    'స్వాతి',
    'విశాఖ',
    'అనూరాధ',
    'జ్యేష్ఠ',
    'మూల',
    'పూర్వాషాఢ',
    'ఉత్తరాషాఢ',
    'శ్రవణం',
    'ధనిష్ఠ',
    'శతభిషం',
    'పూర్వాభాద్ర',
    'ఉత్తరాభాద్ర',
    'రేవతి',
  ];

  static const List<String> yogaNamesTe = [
    'విష్కంభ',
    'ప్రీతి',
    'ఆయుష్మాన్',
    'సౌభాగ్య',
    'శోభన',
    'అతిగండ',
    'సుకర్మ',
    'ధృతి',
    'శూల',
    'గండ',
    'వృద్ధి',
    'ధ్రువ',
    'వ్యాఘాత',
    'హర్షణ',
    'వజ్ర',
    'సిద్ధి',
    'వ్యతీపాత',
    'వరీయాన్',
    'పరిఘ',
    'శివ',
    'సిద్ధ',
    'సాధ్య',
    'శుభ',
    'శుక్ల',
    'బ్రహ్మ',
    'ఇంద్ర',
    'వైధృతి',
  ];

  static const List<String> _tithiNames = [
    'పాడ్యమి',
    'విదియ',
    'తదియ',
    'చవితి',
    'పంచమి',
    'షష్ఠి',
    'సప్తమి',
    'అష్టమి',
    'నవమి',
    'దశమి',
    'ఏకాదశి',
    'ద్వాదశి',
    'త్రయోదశి',
    'చతుర్దశి',
  ];


  static const List<String> _repeatingKaranaNames = [
    'బవ',
    'బాలవ',
    'కౌలవ',
    'తైతిల',
    'గరజ',
    'వణిజ',
    'విష్టి (భద్ర)',
  ];

  static NakshatraPosition nakshatra(double longitude) {
    final normalized = _norm(longitude);
    const span = 360.0 / 27.0;
    const padaSpan = span / 4.0;
    final index = (normalized / span).floor().clamp(0, 26).toInt();
    final within = normalized - index * span;
    final pada = (within / padaSpan).floor().clamp(0, 3).toInt() + 1;
    return NakshatraPosition(index: index, pada: pada);
  }

  static PanchangaSummary panchanga(AstroChartResult result) {
    final sun = result.planets.firstWhere((p) => p.name == 'Sun');
    final moon = result.planets.firstWhere((p) => p.name == 'Moon');

    final elongation = _norm(moon.longitude - sun.longitude);
    final tithiIndex = (elongation / 12.0).floor().clamp(0, 29).toInt();
    final waxing = tithiIndex < 15;
    final tithiInPaksha = tithiIndex % 15;
    final tithiName = tithiInPaksha == 14
        ? (waxing ? 'పౌర్ణమి' : 'అమావాస్య')
        : _tithiNames[tithiInPaksha];

    final moonNakshatra = nakshatra(moon.longitude);
    final yogaIndex = (_norm(sun.longitude + moon.longitude) / (360.0 / 27.0))
        .floor()
        .clamp(0, 26)
        .toInt();
    final karana = _karanaForElongation(elongation);

    return PanchangaSummary(
      tithi: tithiName,
      paksha: waxing ? 'శుక్ల పక్షం' : 'కృష్ణ పక్షం',
      nakshatra: nakshatraNamesTe[moonNakshatra.index],
      nakshatraPada: moonNakshatra.pada,
      yoga: yogaNamesTe[yogaIndex],
      karana: karana,
    );
  }


  static String _karanaForElongation(double elongation) {
    final halfTithi = (elongation / 6.0).floor().clamp(0, 59).toInt();
    if (halfTithi == 0) return 'కింస్తుఘ్న';
    if (halfTithi == 57) return 'శకుని';
    if (halfTithi == 58) return 'చతుష్పాద';
    if (halfTithi == 59) return 'నాగ';
    return _repeatingKaranaNames[(halfTithi - 1) % 7];
  }

  static int wholeSignHouse(int planetSign, int ascendantSign) =>
      ((planetSign - ascendantSign + 12) % 12) + 1;

  static double _norm(double value) {
    var result = value % 360.0;
    if (result < 0) result += 360.0;
    return result;
  }
}
