import 'package:sweph/sweph.dart';

import '../models/birth_data.dart';
import 'astro_calculation_service.dart';
import 'western_timing_engine.dart';

/// Tropical geocentric astronomical positions. Does not use Vedic ayanamsa.
/// Longitude-only aspects are indicators, not event probabilities.
class WesternSky {
  final Map<String, double> planets;
  final double asc;
  final double mc;
  const WesternSky(this.planets, this.asc, this.mc);
  Map<String,double> get points => {...planets, 'Asc':asc, 'MC':mc};
}

class WesternContact {
  final String moving;
  final String natal;
  final int aspect;
  final double orb;
  const WesternContact(this.moving,this.natal,this.aspect,this.orb);
}

class WesternCalculation {
  final Map<String,WesternSky> charts;
  final Map<String,List<WesternContact>> contacts;
  final int profectedSign;
  final String profectionLord;
  final double solarArc;
  final double age;
  const WesternCalculation(this.charts,this.contacts,this.profectedSign,
      this.profectionLord,this.solarArc,this.age);
}

class WesternEphemerisService {
  static const bodies = <String,HeavenlyBody>{
    'Sun':HeavenlyBody.SE_SUN,'Moon':HeavenlyBody.SE_MOON,
    'Mercury':HeavenlyBody.SE_MERCURY,'Venus':HeavenlyBody.SE_VENUS,
    'Mars':HeavenlyBody.SE_MARS,'Jupiter':HeavenlyBody.SE_JUPITER,
    'Saturn':HeavenlyBody.SE_SATURN,'Rahu':HeavenlyBody.SE_TRUE_NODE,
  };
  static const signRulers = <String>['Mars','Venus','Mercury','Moon',
    'Sun','Mercury','Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'];
  static double norm(double n) => WesternTimingEngine.normalize(n);

  static Future<WesternSky> sky(DateTime when, BirthData birth) async {
    await AstroCalculationService.initialize();
    if (!AstroCalculationService.isInitialized) {
      throw StateError('Ephemeris initialization failed: ${AstroCalculationService.initError}');
    }
    final utc=when.toUtc();
    final hours=utc.hour+utc.minute/60.0+utc.second/3600.0+
        utc.millisecond/3600000.0;
    final jd=Sweph.swe_julday(utc.year,utc.month,utc.day,hours,
        CalendarType.SE_GREG_CAL);
    final flags=SwephFlag.SEFLG_MOSEPH | SwephFlag.SEFLG_SPEED;
    final planets=<String,double>{};
    for(final entry in bodies.entries){
      planets[entry.key]=norm(Sweph.swe_calc_ut(jd,entry.value,flags).longitude);
    }
    planets['Ketu']=norm(planets['Rahu']!+180);
    final houses=Sweph.swe_houses_ex(jd,SwephFlag.SEFLG_MOSEPH,birth.latitude,birth.longitude,Hsys.P);
    return WesternSky(planets,
      norm(houses.ascmc[AscmcIndex.SE_ASC.index]),
      norm(houses.ascmc[AscmcIndex.SE_MC.index]));
  }

  static WesternSky rotate(WesternSky natal,double arc) => WesternSky(
    {for(final entry in natal.planets.entries) entry.key:norm(entry.value+arc)},
    norm(natal.asc+arc),norm(natal.mc+arc));

  static List<WesternContact> match(WesternSky moving, WesternSky natal,
      {double maxOrb=1.0}) {
    final matches=<WesternContact>[];
    for(final entry in moving.points.entries){
      for(final target in natal.points.entries){
        for(final aspect in const [0,60,90,120,180]){
          final orb=WesternTimingEngine.aspectOrb(entry.value,target.value,aspect.toDouble());
          if(orb != null && orb<=maxOrb){
            matches.add(WesternContact(entry.key,target.key,aspect,orb));
          }
        }
      }
    }
    matches.sort((a,b)=>a.orb.compareTo(b.orb));
    return matches;
  }

  static Future<WesternCalculation> calculate(BirthData birth,DateTime event,
      {double maxOrb=1.0}) async {
    final natalTime=birth.utcDateTime;
    if(event.isBefore(natalTime)) throw ArgumentError('Event date before birth');
    final age=WesternTimingEngine.ageYears(natalTime,event);
    final natal=await sky(natalTime,birth);
    final secondary=await sky(WesternTimingEngine.secondaryDate(natalTime,event),birth);
    final tertiary=await sky(WesternTimingEngine.tertiaryDate(natalTime,event),birth);
    final minor=await sky(WesternTimingEngine.minorDate(natalTime,event),birth);
    final converse=await sky(WesternTimingEngine.secondaryDate(natalTime,event,
        converse:true),birth);
    final arc=WesternTimingEngine.signedShortestArc(
        secondary.planets['Sun']!,natal.planets['Sun']!);
    // Progressed ASC/MC here are explicitly labelled *symbolic natal-place*
    // angles, NOT a mathematically established quotidian progressed axis.
    final charts=<String,WesternSky>{
      'Secondary':secondary,'Solar Arc':rotate(natal,arc),
      'Tertiary-I':tertiary,'Minor':minor,
      'Naibod':rotate(natal,age*WesternTimingEngine.naibodDegreesPerYear),
      '1° Symbolic':rotate(natal,age),
      'Converse Secondary':converse,
    };
    final ascSign=(natal.asc/30).floor();
    final completed=(age+1e-8).floor();
    final profection=WesternTimingEngine.annualProfectionSign(ascSign,completed);
    return WesternCalculation(
      {'Natal':natal,...charts},
      {for(final e in charts.entries)e.key:match(e.value,natal,maxOrb:maxOrb)},
      profection,signRulers[profection],arc,age);
  }
}
