import 'astro_models.dart';
import 'dasha_service.dart';
import 'varga_service.dart';

class D9MarriageTimingWindow {
  final int year;
  final int evidencePercent;
  final String mahadasha;
  final String antardasha;
  final DateTime start;
  final DateTime end;
  final List<String> matchedEvidence;

  const D9MarriageTimingWindow({
    required this.year,
    required this.evidencePercent,
    required this.mahadasha,
    required this.antardasha,
    required this.start,
    required this.end,
    required this.matchedEvidence,
  });
}

class D9MarriageReport {
  final String marriagePromise;
  final int marriagePromisePercent;
  final String seventhHouseResult;
  final String delayResult;
  final int obstaclePercent;
  final String afterMarriageResult;
  final int afterMarriagePercent;
  final int beforeMarriageRelationshipPercent;
  final int affairAfterMarriagePercent;
  final int multipleAffairPercent;
  final bool d7KetuDivorceConfirmation;
  final List<String> d7KetuMatches;
  final int divorceEvidencePercent;
  final String divorceStatus;
  final List<String> divorceEvidence;
  final List<D9MarriageTimingWindow> timingWindows;
  final List<String> affairEvidence;
  final List<String> sourceNotes;

  const D9MarriageReport({
    required this.marriagePromise,
    required this.marriagePromisePercent,
    required this.seventhHouseResult,
    required this.delayResult,
    required this.obstaclePercent,
    required this.afterMarriageResult,
    required this.afterMarriagePercent,
    required this.beforeMarriageRelationshipPercent,
    required this.affairAfterMarriagePercent,
    required this.multipleAffairPercent,
    required this.d7KetuDivorceConfirmation,
    required this.d7KetuMatches,
    required this.divorceEvidencePercent,
    required this.divorceStatus,
    required this.divorceEvidence,
    required this.timingWindows,
    required this.affairEvidence,
    required this.sourceNotes,
  });
}

/// D9 marriage report layer built only from source-backed concepts that can be
/// reproduced from the current D1/D7/D9 placements and Vimshottari periods.
///
/// Important boundary:
/// - Percentages are evidence-coverage percentages, never event probabilities.
/// - V.P. Goel transit and handwritten marriage-year rules remain source-only
///   until their transit/arithmetic steps are machine-validated.
/// - D7 Ketu is a confirmation block, never a stand-alone deterministic divorce
///   verdict.
class D9MarriageService {
  static const _benefics = {'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};

  static const _lords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];

  static String _signLord(int sign) => _lords[sign % 12];

  static int _houseSign(VargaChartData v, int house) =>
      (v.ascendantSignIndex + house - 1) % 12;

  static int _houseOf(VargaChartData v, String planet) {
    final p = v.planets.firstWhere((x) => x.name == planet);
    return ((p.signIndex - v.ascendantSignIndex + 12) % 12) + 1;
  }

  static VargaPlacement _planet(VargaChartData v, String planet) =>
      v.planets.firstWhere((x) => x.name == planet);

  static bool _aspects(String planet, int fromSign, int toSign) {
    final diff = (toSign - fromSign + 12) % 12;
    if (diff == 6) return true;
    return switch (planet) {
      'Mars' => diff == 3 || diff == 7,
      'Jupiter' => diff == 4 || diff == 8,
      'Saturn' => diff == 2 || diff == 9,
      _ => false,
    };
  }

  static bool _related(VargaChartData v, String a, String b) {
    final pa = _planet(v, a);
    final pb = _planet(v, b);
    return pa.signIndex == pb.signIndex ||
        _aspects(a, pa.signIndex, pb.signIndex) ||
        _aspects(b, pb.signIndex, pa.signIndex);
  }

  static bool _planetInfluencesHouse(
    VargaChartData v,
    String planet,
    int house,
  ) {
    final p = _planet(v, planet);
    final sign = _houseSign(v, house);
    return p.signIndex == sign || _aspects(planet, p.signIndex, sign);
  }

  static List<String> _houseInfluencers(VargaChartData v, int house) =>
      v.planets
          .where((p) => _planetInfluencesHouse(v, p.name, house))
          .map((p) => p.name)
          .toList(growable: false);

  static bool _lordAfflicted(VargaChartData v, String lord) {
    final h = _houseOf(v, lord);
    if (h == 6 || h == 8 || h == 12) return true;
    final lp = _planet(v, lord);
    final maleficContact = v.planets.any((p) =>
        p.name != lord &&
        _malefics.contains(p.name) &&
        (p.signIndex == lp.signIndex ||
            _aspects(p.name, p.signIndex, lp.signIndex)));
    return maleficContact;
  }

  static bool _houseAfflicted(VargaChartData v, int house) {
    final influencers = _houseInfluencers(v, house);
    final mal = influencers.where(_malefics.contains).length;
    final ben = influencers.where(_benefics.contains).length;
    return mal > ben && mal > 0;
  }

  static int _pct(int matched, int available) {
    if (available <= 0) return 0;
    return ((matched * 100) / available).round().clamp(0, 100).toInt();
  }

  static String _strengthLabel(int percent) {
    if (percent >= 75) return 'Strong';
    if (percent >= 50) return 'Moderate';
    if (percent > 0) return 'Weak';
    return 'No matched evidence';
  }

  static D9MarriageReport evaluate({
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    final d9 = VargaService.calculate(chart, 9);
    final d7 = VargaService.calculate(chart, 7);

    final lagnaLord = _signLord(d9.ascendantSignIndex);
    final seventhLord = _signLord(_houseSign(d9, 7));
    final secondLord = _signLord(_houseSign(d9, 2));
    final thirdLord = _signLord(_houseSign(d9, 3));
    final fourthLord = _signLord(_houseSign(d9, 4));
    final fifthLord = _signLord(_houseSign(d9, 5));
    final sixthLord = _signLord(_houseSign(d9, 6));
    final eighthLord = _signLord(_houseSign(d9, 8));

    // Marriage promise: D9 Lagna + Lagna lord + 7H/7L. This follows the
    // Navamsa source architecture. Each independent block is one evidence unit.
    var promiseMatched = 0;
    const promiseAvailable = 4;
    final lagnaInfluencers = _houseInfluencers(d9, 1);
    final lagnaBen = lagnaInfluencers.where(_benefics.contains).length;
    final lagnaMal = lagnaInfluencers.where(_malefics.contains).length;
    if (lagnaBen >= lagnaMal && lagnaBen > 0) promiseMatched++;
    if (!_lordAfflicted(d9, lagnaLord)) promiseMatched++;
    if (!_houseAfflicted(d9, 7)) promiseMatched++;
    if (!_lordAfflicted(d9, seventhLord)) promiseMatched++;
    final promisePercent = _pct(promiseMatched, promiseAvailable);

    final seventhHouseResult = _houseAfflicted(d9, 7) ||
            _lordAfflicted(d9, seventhLord)
        ? '7వ భావం/7వ అధిపతిపై stress evidence ఉంది; ఇతర marriage layersతో కలిపి చూడాలి.'
        : '7వ భావం/7వ అధిపతికి severe affliction auto-match కాలేదు; stability support ఉంది.';

    // Before-marriage obstacles: source directly links Saturn with the 3H/3L.
    final saturnThird = _planetInfluencesHouse(d9, 'Saturn', 3) ||
        _related(d9, 'Saturn', thirdLord);
    final obstaclePercent = saturnThird ? 100 : 0;
    final delayResult = saturnThird
        ? 'Saturn ↔ 3వ భావం/3వ అధిపతి relation match అయింది; fixed marriage తర్వాత obstacle/postponement layerను చూడాలి.'
        : 'Saturn–3H/3L obstacle rule auto-match కాలేదు.';

    // After marriage: D9 2H = first experience; 2L = later events.
    final secondHouseAfflicted = _houseAfflicted(d9, 2);
    final secondLordAfflicted = _lordAfflicted(d9, secondLord);
    final afterMarriageMatched =
        (secondHouseAfflicted ? 1 : 0) + (secondLordAfflicted ? 1 : 0);
    final afterMarriagePercent = _pct(afterMarriageMatched, 2);
    final afterMarriageResult = afterMarriageMatched == 0
        ? 'D9 2H/2L severe affliction auto-match కాలేదు; after-marriage qualityకు supportive layer.'
        : afterMarriageMatched == 1
            ? 'D9 2H లేదా 2Lలో ఒక stress layer match అయింది; married-life quality mixedగా చూడాలి.'
            : 'D9 2H మరియు 2L రెండింటిలో stress evidence ఉంది; first/later married-life eventsను cautionగా చూడాలి.';

    // Affairs-after-marriage source combinations from the supplied D9 chapter.
    final affairEvidence = <String>[];
    const affairAvailable = 7;
    final trikaLords = <String>{
      _signLord(_houseSign(d9, 6)),
      _signLord(_houseSign(d9, 8)),
      _signLord(_houseSign(d9, 12)),
    };
    final fifthVipreet = trikaLords.any((l) =>
        _planetInfluencesHouse(d9, l, 5) || _related(d9, l, fifthLord));
    if (fifthVipreet) affairEvidence.add('5H/5Lపై Vipreet-house lord influence');
    if (_related(d9, fifthLord, seventhLord)) {
      affairEvidence.add('5L ↔ 7L relation');
    }
    if (_related(d9, 'Mars', 'Venus')) {
      affairEvidence.add('Mars ↔ Venus relation');
    }
    if (_related(d9, sixthLord, 'Venus')) {
      affairEvidence.add('6L ↔ Venus influence');
    }
    if (_planetInfluencesHouse(d9, sixthLord, 7) ||
        _related(d9, sixthLord, seventhLord)) {
      affairEvidence.add('6L influence on 7H/7L');
    }
    if (_planet(d9, 'Venus').signIndex == _planet(d9, 'Ketu').signIndex) {
      affairEvidence.add('Venus + Ketu');
    }
    if (_planetInfluencesHouse(d9, eighthLord, 4) ||
        _related(d9, eighthLord, fourthLord)) {
      affairEvidence.add('8L influence on 4H/4L — secrecy layer');
    }
    final affairPercent = _pct(affairEvidence.length, affairAvailable);

    // Before-marriage relationship evidence uses the relationship-specific
    // subset only; marriage-date classification belongs to the timing layer.
    var beforeMatched = 0;
    const beforeAvailable = 3;
    if (_related(d9, fifthLord, seventhLord)) beforeMatched++;
    if (_related(d9, 'Mars', 'Venus')) beforeMatched++;
    if (fifthVipreet) beforeMatched++;
    final beforePercent = _pct(beforeMatched, beforeAvailable);

    // Repeated/multiple relationship pattern requires multiple independent
    // source combinations; it is never a deterministic statement.
    final multipleAffairPercent = affairPercent;

    // D7 Ketu divorce confirmation, source Sutra 35:
    // Ketu relation with D7 6H / 6L / Lagna / Lagna lord.
    final d7SixthLord = _signLord(_houseSign(d7, 6));
    final d7LagnaLord = _signLord(d7.ascendantSignIndex);
    final d7KetuMatches = <String>[];
    if (_planetInfluencesHouse(d7, 'Ketu', 6)) d7KetuMatches.add('Ketu ↔ D7 6H');
    if (_related(d7, 'Ketu', d7SixthLord)) d7KetuMatches.add('Ketu ↔ D7 6L');
    if (_planet(d7, 'Ketu').signIndex == d7.ascendantSignIndex) {
      d7KetuMatches.add('Ketu ↔ D7 Lagna');
    }
    if (_related(d7, 'Ketu', d7LagnaLord)) {
      d7KetuMatches.add('Ketu ↔ D7 Lagna Lord');
    }
    final d7KetuConfirm = d7KetuMatches.isNotEmpty;

    // Divorce/separation = net evidence. D7 Ketu is one independent
    // confirmation block; it never decides divorce by itself.
    final divorceEvidence = <String>[];
    const divorceAvailable = 7;
    if (secondHouseAfflicted) divorceEvidence.add('D9 2H afflicted');
    if (secondLordAfflicted) divorceEvidence.add('D9 2L afflicted');
    if (_houseAfflicted(d9, 7)) divorceEvidence.add('D9 7H stress');
    if (_lordAfflicted(d9, seventhLord)) divorceEvidence.add('D9 7L stress');
    if (d7KetuConfirm) divorceEvidence.add('D7 Ketu Sutra 35 confirmation');
    if (affairPercent >= 50) divorceEvidence.add('Relationship-conflict evidence ≥50%');
    if (saturnThird) divorceEvidence.add('Before-marriage obstacle/Saturn stress');
    final divorcePercent = _pct(divorceEvidence.length, divorceAvailable);
    final divorceStatus = divorcePercent >= 75
        ? 'Strong separation/divorce evidence — confirmation required from timing and full chart.'
        : divorcePercent >= 50
            ? 'Moderate separation/divorce evidence.'
            : divorcePercent > 0
                ? 'Weak/partial separation evidence.'
                : 'No strong divorce evidence auto-matched.';

    final timing = _timingWindows(
      chart: chart,
      birthDateTime: birthDateTime,
      d9: d9,
      marriagePromisePercent: promisePercent,
      seventhLord: seventhLord,
      saturnObstacle: saturnThird,
    );

    return D9MarriageReport(
      marriagePromise: _strengthLabel(promisePercent),
      marriagePromisePercent: promisePercent,
      seventhHouseResult: seventhHouseResult,
      delayResult: delayResult,
      obstaclePercent: obstaclePercent,
      afterMarriageResult: afterMarriageResult,
      afterMarriagePercent: afterMarriagePercent,
      beforeMarriageRelationshipPercent: beforePercent,
      affairAfterMarriagePercent: affairPercent,
      multipleAffairPercent: multipleAffairPercent,
      d7KetuDivorceConfirmation: d7KetuConfirm,
      d7KetuMatches: List.unmodifiable(d7KetuMatches),
      divorceEvidencePercent: divorcePercent,
      divorceStatus: divorceStatus,
      divorceEvidence: List.unmodifiable(divorceEvidence),
      timingWindows: List.unmodifiable(timing),
      affairEvidence: List.unmodifiable(affairEvidence),
      sourceNotes: const [
        'Saral Jyotish Part VII — Navamsa D9: marriage promise, quality, before-marriage obstacles, after-marriage 2H/2L, affairs rules.',
        'Marriage Rules PDF — D7 Ketu divorce confirmation, Sutra 35.',
        'Marriage timing % is evidence coverage, not probability. V.P. Goel transit + handwritten transit/year rules remain source-only until exact transit arithmetic is connected.',
      ],
    );
  }

  static List<D9MarriageTimingWindow> _timingWindows({
    required AstroChartResult chart,
    required DateTime birthDateTime,
    required VargaChartData d9,
    required int marriagePromisePercent,
    required String seventhLord,
    required bool saturnObstacle,
  }) {
    final system = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birthDateTime,
    );
    final minDate = DateTime(
      birthDateTime.year + 18,
      birthDateTime.month,
      birthDateTime.day,
    );
    final maxDate = DateTime(
      birthDateTime.year + 60,
      birthDateTime.month,
      birthDateTime.day,
    );

    final byYear = <int, D9MarriageTimingWindow>{};
    for (final md in system.mahadashas) {
      if (md.end.isBefore(minDate) || md.start.isAfter(maxDate)) continue;
      for (final ad in DashaService.subPeriodsFor(system, md)) {
        if (ad.end.isBefore(minDate) || ad.start.isAfter(maxDate)) continue;

        final matched = <String>[];
        const available = 5;
        final keyLords = {seventhLord, 'Venus', 'Jupiter'};
        if (keyLords.contains(md.lord)) matched.add('MD lord marriage-significator/7L support');
        if (keyLords.contains(ad.lord)) matched.add('AD lord marriage-significator/7L support');
        if (marriagePromisePercent >= 50) matched.add('D9 marriage promise ≥50%');
        if (!_houseAfflicted(d9, 7) && !_lordAfflicted(d9, seventhLord)) {
          matched.add('D9 7H/7L stability support');
        }
        if (!saturnObstacle) matched.add('No Saturn–3H/3L obstacle match');

        final pct = _pct(matched.length, available);
        if (pct < 40) continue;

        var cursor = ad.start.isBefore(minDate) ? minDate : ad.start;
        final end = ad.end.isAfter(maxDate) ? maxDate : ad.end;
        while (!cursor.isAfter(end)) {
          final year = cursor.year;
          final candidate = D9MarriageTimingWindow(
            year: year,
            evidencePercent: pct,
            mahadasha: md.lord,
            antardasha: ad.lord,
            start: ad.start,
            end: ad.end,
            matchedEvidence: List.unmodifiable(matched),
          );
          final current = byYear[year];
          if (current == null || candidate.evidencePercent > current.evidencePercent) {
            byYear[year] = candidate;
          }
          cursor = DateTime(year + 1, 1, 1);
        }
      }
    }

    final ranked = byYear.values.toList()
      ..sort((a, b) {
        final score = b.evidencePercent.compareTo(a.evidencePercent);
        return score != 0 ? score : a.year.compareTo(b.year);
      });
    final top = ranked.take(8).toList(growable: true)
      ..sort((a, b) => a.year.compareTo(b.year));
    return List.unmodifiable(top);
  }
}
