import '../models/birth_data.dart';
import 'ashtakavarga_service.dart';
import 'ashtakavarga_timing_service.dart';
import 'ashtakavarga_transit_window_service.dart';
import 'astro_models.dart';
import 'dasha_service.dart';
import 'jaimini_service.dart';

enum ConsultationTimingTone { strong, supportive, mixed }

class ConsultationTimingWindow {
  final DateTime startLocal;
  final DateTime endLocal;
  final ConsultationTimingTone tone;
  final String transitPlanet;
  final int transitSignNumber;
  final int bavBindus;
  final int savBindus;
  final int entryKakshya;
  final bool retrogradeAtEntry;
  final bool vimshottariSupport;
  final bool tribhagiSupport;
  final List<String> vimshottariPeriods;
  final List<String> tribhagiPeriods;
  final int jaiminiFavorable;
  final int jaiminiAdverse;
  final List<String> reasons;

  const ConsultationTimingWindow({
    required this.startLocal,
    required this.endLocal,
    required this.tone,
    required this.transitPlanet,
    required this.transitSignNumber,
    required this.bavBindus,
    required this.savBindus,
    required this.entryKakshya,
    required this.retrogradeAtEntry,
    required this.vimshottariSupport,
    required this.tribhagiSupport,
    required this.vimshottariPeriods,
    required this.tribhagiPeriods,
    required this.jaiminiFavorable,
    required this.jaiminiAdverse,
    required this.reasons,
  });
}

class ConsultationTimingResult {
  final String eventKey;
  final String eventTitle;
  final DateTime searchStart;
  final DateTime searchEnd;
  final List<ConsultationTimingWindow> windows;
  final int jaiminiFavorable;
  final int jaiminiAdverse;
  final List<String> jaiminiRuleIds;
  final String jaiminiNote;

  const ConsultationTimingResult({
    required this.eventKey,
    required this.eventTitle,
    required this.searchStart,
    required this.searchEnd,
    required this.windows,
    required this.jaiminiFavorable,
    required this.jaiminiAdverse,
    required this.jaiminiRuleIds,
    required this.jaiminiNote,
  });
}

/// Consultation timing overlap helper.
///
/// It deliberately combines only calculations that are already source-backed
/// in the app:
///   1) Vimshottari MD/AD/PD relevance,
///   2) S.K. Mehta Tribhagi MD/AD/PD relevance,
///   3) exact Swiss-Ephemeris transit through favorable BAV/SAV signs,
///   4) Jaimini source-rule hits as an independent confirmation layer.
///
/// Jaimini Chara-Dasha calendar dates are NOT mixed into the date window yet.
/// The supplied Jaimini source contains source-defined special direction /
/// duration exceptions whose full arithmetic is not explicit in the current
/// rule file. We therefore show Jaimini rule confirmation without fabricating
/// a Chara-Dasha date.
class ConsultationTimingService {
  static const Map<String, ({String title, List<String> planets})> _events = {
    'career': (
      title: 'వృత్తి / ఉద్యోగం / వ్యాపారం',
      planets: ['Mercury', 'Saturn'],
    ),
    'education': (
      title: 'విద్య / ఉన్నత విద్య',
      planets: ['Mercury', 'Jupiter'],
    ),
    'wealth': (
      title: 'ధనం / లాభం',
      planets: ['Jupiter', 'Mercury'],
    ),
    'property': (
      title: 'ఇల్లు / స్థిరాస్తి / వాహనం',
      planets: ['Mars', 'Venus'],
    ),
    'siblings': (
      title: 'సోదరులు / ప్రయత్నం',
      planets: ['Mars'],
    ),
    'marriage': (
      title: 'వివాహం / భాగస్వామ్యం',
      planets: ['Venus', 'Jupiter'],
    ),
    'children': (
      title: 'సంతానం',
      planets: ['Jupiter'],
    ),
  };

  static const Map<String, List<String>> _jaiminiKeywords = {
    'career': ['వృత్తి', 'సేవ', 'ప్రతిష్ఠ', 'స్థానం', 'వ్యాపార'],
    'education': ['విద్య', 'పాండిత్యం', 'శాస్త్ర', 'బుద్ధి'],
    'wealth': ['ధనం', 'లాభ', 'సంపద', 'ఆర్థిక'],
    'property': ['ఇల్లు', 'స్థిరాస్తి', 'నివాస', 'సౌఖ్యం'],
    'siblings': ['సోదర', 'ప్రయత్న', 'Bhratri'],
    'marriage': ['వివాహ', 'సంబంధ', 'spouse', 'darapada', 'upapada'],
    'children': ['సంతానం', 'children', 'putra'],
  };

  static String _normalizeLord(String lord) {
    for (final planet in const [
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    ]) {
      if (lord.contains(planet)) return planet;
    }
    return lord;
  }

  static DateTime _maxDate(DateTime a, DateTime b) => a.isAfter(b) ? a : b;
  static DateTime _minDate(DateTime a, DateTime b) => a.isBefore(b) ? a : b;

  static bool _overlaps(DateTime aStart, DateTime aEnd, DateTime bStart, DateTime bEnd) =>
      aStart.isBefore(bEnd) && bStart.isBefore(aEnd);

  static List<DashaPeriod> _supportivePdIntervals({
    required DashaSystemResult system,
    required DateTime start,
    required DateTime end,
    required Set<String> planets,
  }) {
    final out = <DashaPeriod>[];
    for (final md in system.mahadashas) {
      if (!_overlaps(md.start, md.end, start, end)) continue;
      for (final ad in DashaService.subPeriodsFor(system, md)) {
        if (!_overlaps(ad.start, ad.end, start, end)) continue;
        for (final pd in DashaService.subPeriodsFor(system, ad)) {
          if (!_overlaps(pd.start, pd.end, start, end)) continue;
          final hit = planets.contains(_normalizeLord(md.lord)) ||
              planets.contains(_normalizeLord(ad.lord)) ||
              planets.contains(_normalizeLord(pd.lord));
          if (!hit) continue;
          final clippedStart = _maxDate(pd.start, start);
          final clippedEnd = _minDate(pd.end, end);
          if (clippedStart.isBefore(clippedEnd)) {
            out.add(DashaPeriod(
              lord: '${_normalizeLord(md.lord)}/${_normalizeLord(ad.lord)}/${_normalizeLord(pd.lord)}',
              start: clippedStart,
              end: clippedEnd,
              years: pd.years,
            ));
          }
        }
      }
    }
    return out;
  }

  static bool _hasSupport(
    List<DashaPeriod> intervals,
    DateTime start,
    DateTime end,
  ) => intervals.any((p) => _overlaps(p.start, p.end, start, end));

  static List<String> _supportLabels(
    List<DashaPeriod> intervals,
    DateTime start,
    DateTime end,
  ) {
    final labels = intervals
        .where((p) => _overlaps(p.start, p.end, start, end))
        .map((p) => p.lord)
        .toSet()
        .toList()
      ..sort();
    return List<String>.unmodifiable(labels);
  }

  static List<JaiminiRuleHit> _jaiminiEventRules(
    JaiminiResult result,
    String eventKey,
  ) {
    final keys = _jaiminiKeywords[eventKey] ?? const <String>[];
    if (keys.isEmpty) return const [];
    return result.applicableRules.where((rule) {
      final haystack = '${rule.topic} ${rule.combination} ${rule.result}'.toLowerCase();
      return keys.any((key) => haystack.contains(key.toLowerCase()));
    }).toList(growable: false);
  }

  static Future<ConsultationTimingResult> findUpcoming({
    required String eventKey,
    required BirthData birthData,
    required AstroChartResult natalChart,
    required AshtakavargaResult av,
    required DateTime fromLocal,
    required JaiminiResult jaimini,
    int horizonMonths = 12,
  }) async {
    final def = _events[eventKey] ??
        (title: eventKey, planets: const <String>[]);
    final endLocal = DateTime(
      fromLocal.year,
      fromLocal.month + horizonMonths,
      fromLocal.day,
      fromLocal.hour,
      fromLocal.minute,
      fromLocal.second,
    );
    final targetPlanets = def.planets.toSet();

    final vim = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: natalChart,
      birthDateTime: birthData.localDateTime,
    );
    final tri = DashaService.system(
      kind: DashaSystemKind.tribhagi,
      chart: natalChart,
      birthDateTime: birthData.localDateTime,
    );
    final vimIntervals = _supportivePdIntervals(
      system: vim,
      start: fromLocal,
      end: endLocal,
      planets: targetPlanets,
    );
    final triIntervals = _supportivePdIntervals(
      system: tri,
      start: fromLocal,
      end: endLocal,
      planets: targetPlanets,
    );

    final jRules = _jaiminiEventRules(jaimini, eventKey);
    final jFav = jRules.where((r) => r.nature == JaiminiRuleNature.favorable).length;
    final jAdv = jRules.where((r) => r.nature == JaiminiRuleNature.adverse).length;

    final candidates = <ConsultationTimingWindow>[];
    for (final planet in def.planets) {
      final transitWindows = await AshtakavargaTransitWindowService.supportedWindowsBetween(
        birthData: birthData,
        av: av,
        planet: planet,
        startLocal: fromLocal,
        endLocal: endLocal,
        topSignCount: 3,
      );
      for (final transit in transitWindows) {
        if (transit.tone != AvTimingTone.favorable) continue;

        // Split a transit window on exact supportive PD boundaries so the
        // displayed start/end is a real dasha + transit overlap, not merely a
        // transit range whose midpoint happens to be supportive.
        final boundaries = <DateTime>{transit.startLocal, transit.endLocal};
        for (final p in [...vimIntervals, ...triIntervals]) {
          if (!_overlaps(transit.startLocal, transit.endLocal, p.start, p.end)) continue;
          boundaries.add(_maxDate(transit.startLocal, p.start));
          boundaries.add(_minDate(transit.endLocal, p.end));
        }
        final sorted = boundaries.toList()..sort();
        for (var i = 0; i + 1 < sorted.length; i++) {
          final start = sorted[i];
          final end = sorted[i + 1];
          if (!start.isBefore(end)) continue;
          final vimSupport = _hasSupport(vimIntervals, start, end);
          final triSupport = _hasSupport(triIntervals, start, end);
          final vimLabels = _supportLabels(vimIntervals, start, end);
          final triLabels = _supportLabels(triIntervals, start, end);
          if (!vimSupport && !triSupport) continue;

          final tone = vimSupport && triSupport
              ? ConsultationTimingTone.strong
              : ConsultationTimingTone.supportive;
          final reasons = <String>[
            if (vimSupport) 'Vimshottari MD/AD/PD support',
            if (triSupport) 'Tribhagi MD/AD/PD support',
            '$planet transit BAV ${transit.bavBindus}/8 + SAV ${transit.savBindus}',
            'Kakshya ${transit.entryKakshya}',
            if (jFav > 0) 'Jaimini source-rule confirmation $jFav favorable',
            if (jAdv > 0) 'Jaimini caution rules $jAdv',
          ];
          candidates.add(
            ConsultationTimingWindow(
              startLocal: start,
              endLocal: end,
              tone: tone,
              transitPlanet: planet,
              transitSignNumber: transit.signNumber,
              bavBindus: transit.bavBindus,
              savBindus: transit.savBindus,
              entryKakshya: transit.entryKakshya,
              retrogradeAtEntry: transit.retrogradeAtEntry,
              vimshottariSupport: vimSupport,
              tribhagiSupport: triSupport,
              vimshottariPeriods: vimLabels,
              tribhagiPeriods: triLabels,
              jaiminiFavorable: jFav,
              jaiminiAdverse: jAdv,
              reasons: List<String>.unmodifiable(reasons),
            ),
          );
        }
      }
    }

    candidates.sort((a, b) {
      final toneA = a.tone == ConsultationTimingTone.strong ? 0 : 1;
      final toneB = b.tone == ConsultationTimingTone.strong ? 0 : 1;
      final toneCompare = toneA.compareTo(toneB);
      if (toneCompare != 0) return toneCompare;
      final savCompare = b.savBindus.compareTo(a.savBindus);
      if (savCompare != 0) return savCompare;
      final bavCompare = b.bavBindus.compareTo(a.bavBindus);
      if (bavCompare != 0) return bavCompare;
      return a.startLocal.compareTo(b.startLocal);
    });

    // Keep consultation output compact. These are independent candidate
    // windows, not probability-ranked certainties.
    final top = candidates.take(8).toList(growable: false);
    top.sort((a, b) => a.startLocal.compareTo(b.startLocal));

    return ConsultationTimingResult(
      eventKey: eventKey,
      eventTitle: def.title,
      searchStart: fromLocal,
      searchEnd: endLocal,
      windows: List<ConsultationTimingWindow>.unmodifiable(top),
      jaiminiFavorable: jFav,
      jaiminiAdverse: jAdv,
      jaiminiRuleIds: List<String>.unmodifiable(jRules.map((r) => r.ruleId).toSet()),
      jaiminiNote:
          'జైమిని source-rule hitsను independent confirmationగా మాత్రమే కలిపాం. Chara Dasha calendar datesను ఇంకా final overlapలో కలపలేదు; supplied sourceలో special direction/duration exceptions పూర్తి arithmeticగా స్పష్టమైన తర్వాత మాత్రమే తేదీలుగా enable చేస్తాం.',
    );
  }
}
