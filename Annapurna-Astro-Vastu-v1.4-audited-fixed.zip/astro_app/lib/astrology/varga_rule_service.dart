import 'astro_models.dart';
import 'varga_service.dart';
import 'marriage_material_registry.dart';

enum VargaRuleTone { favorable, caution, neutral, info }

class VargaRuleHit {
  final int factor;
  final String ruleId;
  final String topic;
  final String result;
  final String rule;
  final String inspection;
  final String remedy;
  final String source;
  final VargaRuleTone tone;
  final bool applicable;
  final bool autoEvaluated;

  const VargaRuleHit({
    required this.factor,
    required this.ruleId,
    required this.topic,
    required this.result,
    required this.rule,
    required this.inspection,
    required this.remedy,
    required this.source,
    required this.tone,
    required this.applicable,
    required this.autoEvaluated,
  });
}

/// Source-linked varga rule layer.
///
/// Boundary: only conditions that can be reproduced from the current D1/varga
/// placements are auto-fired. Rules requiring a source-specific strength,
/// aspect, special karaka, or unimplemented arithmetic stay in the source
/// catalog instead of being guessed.
class VargaRuleService {
  static const _benefics = {'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};

  static const _d10SignNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  // Source-backed profession significations carried forward from the supplied
  // D10 profession rulebook implementation (D10.pdf pp.42–47).
  static const _d10ProfessionCatalog = <(String, List<String>, List<int>)>[
    ('Government / Administration', ['Sun', 'Mercury'], [10]),
    ('Management / High Position', ['Sun', 'Jupiter', 'Saturn'], [10]),
    ('Banking / Finance', ['Jupiter', 'Mercury', 'Sun'], [2, 10, 11]),
    ('Accounting', ['Mercury'], [2, 11]),
    ('Teaching / Education', ['Jupiter', 'Mercury', 'Venus'], [5, 9]),
    ('Law / Judiciary', ['Jupiter', 'Mercury', 'Saturn'], [9, 10]),
    ('Engineering / Technical', ['Mars', 'Saturn', 'Rahu'], [3, 10]),
    ('Architecture', ['Mercury', 'Mars', 'Venus'], [3, 4, 10]),
    ('Medicine / Surgery', ['Sun', 'Mars', 'Jupiter'], [6, 10]),
    ('Nursing / Care', ['Moon', 'Jupiter'], [6, 12]),
    ('Journalism / Writing', ['Mercury', 'Moon'], [3, 5]),
    ('Communication / Languages', ['Mercury', 'Moon', 'Ketu'], [3, 7]),
    ('Travel / Tourism', ['Moon', 'Mercury'], [3, 9, 12]),
    ('Hospitality / Restaurants', ['Moon', 'Venus'], [4, 12]),
    ('Textiles / Clothing', ['Moon', 'Venus', 'Saturn'], [2, 4]),
    ('Music / Arts', ['Moon', 'Venus'], [5, 11]),
    ('Cinema / Acting / Dance', ['Venus', 'Moon'], [5, 11]),
    ('Fashion / Beauty / Design', ['Venus', 'Mercury'], [5, 7]),
    ('Interior Decoration', ['Venus', 'Mercury'], [4, 5]),
    ('Precious Stones / Jewellery', ['Sun', 'Venus', 'Jupiter'], [2, 10]),
    ('Metallurgy / Hardware', ['Mars', 'Saturn'], [3, 10]),
    ('Mining / Minerals', ['Saturn', 'Jupiter'], [8, 10]),
    ('Agriculture / Farming', ['Saturn', 'Moon'], [4, 11]),
    ('Food / Dairy', ['Moon', 'Venus'], [2, 4, 11]),
    ('Manufacturing / Industry', ['Saturn', 'Mars', 'Rahu'], [6, 10, 11]),
    ('Aviation / Piloting', ['Rahu', 'Mars', 'Mercury'], [3, 9, 12]),
    ('Import / Export', ['Moon', 'Rahu', 'Ketu'], [7, 12]),
    ('Diplomacy / Foreign Relations', ['Rahu', 'Sun', 'Mercury'], [7, 9, 12]),
    ('Research / Specialized Studies', ['Ketu', 'Saturn', 'Jupiter'], [8, 9]),
    ('Astrology / Traditional Studies', ['Jupiter', 'Ketu'], [8, 9]),
    ('Books / Publishing', ['Mercury', 'Jupiter', 'Ketu'], [3, 5, 9]),
    ('Surveying / Field Technical Work', ['Mars', 'Saturn'], [3, 4, 10]),
    ('Defence / Security', ['Mars', 'Sun', 'Rahu'], [6, 10]),
    ('Maintenance / Refrigeration', ['Saturn', 'Mars'], [6, 10, 12]),
    ('Commercial / Business', ['Mercury', 'Venus', 'Rahu'], [3, 7, 11]),
    ('Self-employment', ['Sun', 'Mars', 'Rahu', 'Moon'], [1, 3, 10, 11]),
    ('Service / Employment', ['Saturn', 'Moon', 'Mercury'], [6, 10, 11]),
  ];

  static List<VargaRuleHit> allFor({
    required AstroChartResult chart,
    required int factor,
  }) {
    final varga = VargaService.calculate(chart, factor);
    final out = <VargaRuleHit>[];

    void add({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto = true,
      String? remedy,
    }) {
      out.add(
        VargaRuleHit(
          factor: factor,
          ruleId: id,
          topic: topic,
          result: result,
          rule: rule,
          inspection: inspection,
          remedy: remedy ?? _remedyText(tone),
          source: source,
          tone: tone,
          applicable: applicable,
          autoEvaluated: auto,
        ),
      );
    }

    switch (factor) {
      case 1:
        _d1Gems(chart, add);
        break;
      case 2:
        add(
          id: 'SRC-D2-01',
          topic: 'ధనం / హోరా',
          result: 'ఈ buildలో supplied files నుంచి D2కి exact auto-rule evaluator జోడించలేదు.',
          rule: 'D2 ఫలితాన్ని source-specific rule ఉన్నప్పుడు మాత్రమే auto-match చేయాలి.',
          inspection: 'D2 chart calculation అందుబాటులో ఉంది; rule source mapping ఇంకా source-only.',
          source: 'Supplied varga sources — D2 explicit rule not used in this build',
          tone: VargaRuleTone.info,
          applicable: false,
          auto: false,
        );
        break;
      case 3:
        _d3(varga, add);
        break;
      case 4:
        _d4(varga, add);
        break;
      case 7:
        _d7(chart, varga, add);
        break;
      case 9:
        _d9(varga, add);
        break;
      case 10:
        _d10(chart, varga, add);
        break;
      case 12:
        _d12(varga, add);
        break;
      case 16:
        _d16(varga, add);
        break;
      case 20:
        _d20(varga, add);
        break;
      case 24:
        _d24(varga, add);
        break;
      case 27:
        _d27(varga, add);
        break;
      case 30:
        _d30(varga, add);
        break;
      case 40:
        _d40(varga, add);
        break;
      case 45:
        _d45(varga, add);
        break;
      case 60:
        _d60(varga, add);
        break;
    }

    // User-supplied marriage rulebook registry: every distinct rule is indexed
    // under its related chart layer. These entries are source-linked and remain
    // non-auto until the exact handwritten condition is machine-validated.
    _appendMarriageMaterialRegistry(factor, add);

    // V50 source registry: topic-wise source entries are attached under the
    // relevant varga without inventing an automatic verdict.
    _appendV50SourceRegistry(factor, add);

    return out;
  }

  static List<VargaRuleHit> applicableFor({
    required AstroChartResult chart,
    required int factor,
  }) => allFor(chart: chart, factor: factor)
      .where((x) => x.autoEvaluated && x.applicable)
      .toList(growable: false);

  static void _d1Gems(
    AstroChartResult chart,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final lagna = chart.ascendantSignIndex;
    final exaltedInLagna = chart.planets.where((p) => p.signIndex == lagna && _isExalted(p.name, p.signIndex)).toList();
    add(
      id: 'G-05',
      topic: 'లగ్నంలో ఉచ్చరాశి గ్రహం',
      result: exaltedInLagna.isEmpty
          ? 'ఈ జాతకంలో G-05 condition auto-match కాలేదు.'
          : 'లగ్న బలానికి అనుకూల source సూచన కనిపిస్తోంది.',
      rule: 'లగ్నంలో ఉచ్చ స్థితిలో గ్రహం ఉండి, సంబంధిత support ఉంటే లగ్నానికి బలం మరియు మంచి ఫలితాల సూచనగా చూడాలి.',
      inspection: exaltedInLagna.isEmpty
          ? 'లగ్నంలో ఉచ్చస్థితి గ్రహం లేదు.'
          : 'లగ్నంలో ఉచ్చస్థితి: ${exaltedInLagna.map((p) => p.name).join(', ')}.',
      source: '108 Gems of Predictive Astrology — G-05, supplied rule-based PDF p.2',
      tone: VargaRuleTone.favorable,
      applicable: exaltedInLagna.isNotEmpty,
    );

    for (final item in const [
      ('G-01', 'జన్మదినం', 'జన్మ వారాధిపతి 6/8 అధిపత్యం మరియు ఉచ్చ/నీచ స్థితిని కలిపి పరిశీలించే rule.'),
      ('G-06', 'లగ్నాధిపతి — 1', 'లగ్నాధిపతి స్థానం/బలం/దృష్టి layersను కలిపి నిర్ణయించే rule.'),
      ('G-07', 'లగ్నాధిపతి — 2', 'లగ్నాధిపతికి శుభ/పాప సంబంధాన్ని పరిశీలించే rule.'),
      ('G-08', 'లగ్నాధిపతి × చంద్రరాశ్యాధిపతి', 'లగ్నాధిపతి మరియు చంద్రరాశ్యాధిపతి కేంద్ర/సంబంధాన్ని పరిశీలించే rule.'),
      ('G-09', 'లగ్నాధిపతి × చంద్రరాశ్యాధిపతి ఉపచయం', 'ఇద్దరి ఉపచయ/కేంద్ర సంబంధాన్ని పరిశీలించే rule.'),
      ('G-10', 'నవమాధిపతి × లగ్నాధిపతి', '9వ అధిపతి–లగ్నాధిపతి సంబంధం ద్వారా భాగ్యం/శ్రేయస్సు layer.'),
    ]) {
      add(
        id: item.$1,
        topic: item.$2,
        result: 'Source rule catalogలో ఉంది; exact evaluator ఈ buildలో guess చేయకుండా source-onlyగా ఉంచాం.',
        rule: item.$3,
        inspection: 'ఈ ruleకు అవసరమైన పూర్తి source arithmetic/relationship layerను విడిగా validate చేసిన తర్వాత మాత్రమే auto-result ఇవ్వాలి.',
        source: '108 Gems of Predictive Astrology — supplied rule-based PDF pp.2–3',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
      );
    }
  }

  static void _d3(
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final lagnaNames = _houseNames(v, 1);
    final ben = lagnaNames.where(_benefics.contains).toList();
    final mal = lagnaNames.where(_malefics.contains).toList();
    add(
      id: 'S7-D3-01',
      topic: 'స్వప్రయత్నం / ధైర్యం',
      result: ben.isNotEmpty ? 'D3 లగ్నంలో శుభగ్రహ support ఉంది; స్వప్రయత్నానికి అనుకూల layer.' : 'D3 లగ్న శుభగ్రహ support auto-match కాలేదు.',
      rule: 'D3లో లగ్నం/లగ్నాధిపతి బలం స్వప్రయత్నం, ధైర్యం, కర్మఫలానికి ప్రధానంగా చూడాలి.',
      inspection: 'D3 లగ్నంలో: ${lagnaNames.isEmpty ? 'గ్రహం లేదు' : lagnaNames.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'S7-D3-02',
      topic: 'స్వప్రయత్నం / జాగ్రత్త',
      result: mal.isNotEmpty ? 'D3 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; ప్రయత్నంలో ఒత్తిడి/కఠినత layerగా చూడాలి.' : 'D3 లగ్న పాపగ్రహ condition auto-match కాలేదు.',
      rule: 'D3 lagna/lagna-lord affliction ఉంటే ప్రయత్నంలో ఆటంకం లేదా కఠిన ఫలితంగా source చూడమంటుంది.',
      inspection: 'D3 లగ్నంలో పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2',
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static void _d4(
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final fourthSign = _houseSign(v, 4);
    final lord = _signLord(fourthSign);
    final lordPlacement = v.planets.firstWhere((p) => p.name == lord);
    final lordHouse = _houseOf(v, lordPlacement);
    const results = <int, String>{
      1: 'విద్య, ఆభరణాలు, భూమి, వాహన అంశాలకు అనుకూలత; సాధారణంగా సంతోషం.',
      2: 'ధనం, సుఖం.',
      3: 'ధైర్యం; పాప ప్రభావం ఉంటే అనుభవం కఠినంగా మారవచ్చు.',
      4: 'సంపద, విద్య, గౌరవం.',
      5: 'రాజయోగ/మంచి సంతానం layer; బలహీనత ఉంటే సంతాన అంశం పరిశీలించాలి.',
      6: 'భౌతిక సుఖంలో ఒత్తిడి; పాప ప్రభావం ఉంటే ఆరోగ్య/తల్లి అంశం జాగ్రత్త.',
      7: 'విద్య, వాహనం; ఇతర సంబంధాలను కూడా చూడాలి.',
      8: 'గృహ సుఖం తగ్గే లేదా మార్పులు వచ్చే సూచన; వృత్తి/ధన సంబంధం కూడా చూడాలి.',
      9: 'రాజయోగ/ఉన్నత విద్య layer.',
      10: 'రాజ గౌరవం / స్థాయి.',
      11: 'దాతృత్వం; పాప ప్రభావం ఉంటే చెడు ఉపదేశం/మిశ్రమ ఫలితం.',
      12: 'సుఖ లోపం/నష్టం వంటి జాగ్రత్త సూచన.',
    };
    final tone = {1, 2, 4, 5, 7, 9, 10, 11}.contains(lordHouse)
        ? VargaRuleTone.favorable
        : {6, 8, 12}.contains(lordHouse)
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'S3-D4-L4H$lordHouse',
      topic: 'D4 4వ అధిపతి స్థానం',
      result: results[lordHouse]!,
      rule: 'D4లో 4వ భావ అధిపతి ఏ భావంలో ఉన్నాడో ఆధారంగా స్థిరాస్తి/సుఖ ఫలితాన్ని source tableలో చదవాలి.',
      inspection: 'D4 4వ భావ రాశి ${fourthSign + 1}; అధిపతి $lord; D4లో $lord ${lordHouse}వ భావంలో ఉంది.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 4th-lord result table pp.1–2',
      tone: tone,
      applicable: true,
    );

    final h4 = _houseNames(v, 4);
    final ben = h4.where(_benefics.contains).toList();
    final mal = h4.where(_malefics.contains).toList();
    add(
      id: 'S3-D4-H4-BEN',
      topic: 'స్థిరాస్తి / 4వ భావ support',
      result: ben.isNotEmpty ? 'D4 4వ భావంలో శుభగ్రహ support ఉంది; స్థిరాస్తి/సుఖానికి అనుకూల layer.' : 'D4 4వ భావ శుభగ్రహ condition auto-match కాలేదు.',
      rule: 'D4 4వ భావ బలం మరియు శుభ సంబంధాన్ని స్థిరాస్తి ఫలితానికి చూడాలి.',
      inspection: 'D4 4వ భావంలో ${h4.isEmpty ? 'గ్రహాలు లేవు' : h4.join(', ')}.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 property rules pp.1–2',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'S3-D4-H4-MAL',
      topic: 'స్థిరాస్తి / జాగ్రత్త',
      result: mal.isNotEmpty ? 'D4 4వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ఆస్తి/సుఖంలో ఒత్తిడి లేదా ఆలస్యం layerగా చూడాలి.' : 'D4 4వ భావ పాపగ్రహ condition auto-match కాలేదు.',
      rule: 'D4 4వ భావం పీడితమైతే స్థిరాస్తి/సుఖ అంశంలో జాగ్రత్తగా source ఫలితం చదవాలి.',
      inspection: 'D4 4వ భావ పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 property rules pp.1–2',
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static void _d7(
    AstroChartResult chart,
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final natal5Sign = (chart.ascendantSignIndex + 4) % 12;
    final natal5Lord = _signLord(natal5Sign);
    final natal5LordPlanet = chart.planets.firstWhere((p) => p.name == natal5Lord);
    final natal5LordHouse = ((natal5LordPlanet.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final jupiter = chart.planets.firstWhere((p) => p.name == 'Jupiter');
    final jupiterHouse = ((jupiter.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final lagnaLord = _signLord(chart.ascendantSignIndex);
    final lagnaLordPlanet = chart.planets.firstWhere((p) => p.name == lagnaLord);
    final lagnaLordHouse = ((lagnaLordPlanet.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final natalSupport = natal5LordHouse == 5 || jupiterHouse == 5 || lagnaLordHouse == 5;
    add(
      id: 'D7-SANTANA-01',
      topic: '5వ భావ బలం / సంతానం',
      result: natalSupport ? 'సంతాన వాగ్దానానికి 5వ భావ primary support కనిపిస్తోంది.' : '5వ భావ primary support ఈ simple evaluatorలో match కాలేదు; పూర్తి దృష్టి/శుభసంబంధం చూడాలి.',
      rule: 'సంతాన నిర్ణయంలో ముందుగా 5వ భావం, 5వ అధిపతి, కారకుడు గురువును పరిశీలించాలి; తరువాత D7 చూడాలి.',
      inspection: '5వ అధిపతి $natal5Lord — House $natal5LordHouse; Jupiter — House $jupiterHouse; Lagna lord $lagnaLord — House $lagnaLordHouse.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” pp.1–2',
      tone: natalSupport ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: natalSupport,
    );

    final d7h5 = _houseNames(v, 5);
    final ben = d7h5.where(_benefics.contains).toList();
    final mal = d7h5.where(_malefics.contains).toList();
    add(
      id: 'D7-SANTANA-02',
      topic: 'D7 5వ భావ support',
      result: ben.isNotEmpty ? 'D7 5వ భావంలో శుభగ్రహ support ఉంది; సంతాన అంశానికి అనుకూల layer.' : 'D7 5వ భావ శుభగ్రహ condition auto-match కాలేదు.',
      rule: 'D7లో 5వ భావం, 5వ అధిపతి, పుత్రకారక/గురు బలాన్ని కలిపి చూడాలి.',
      inspection: 'D7 5వ భావంలో: ${d7h5.isEmpty ? 'గ్రహాలు లేవు' : d7h5.join(', ')}.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” + Sarala VII D7 section',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'D7-SANTANA-03',
      topic: 'D7 5వ భావ జాగ్రత్త',
      result: mal.length >= 2 ? 'D7 5వ భావంపై బహుళ పాపగ్రహ ప్రభావం ఉంది; సంతాన అంశాన్ని ఇతర supportతో జాగ్రత్తగా చూడాలి.' : 'D7 5వ భావ బహుళ పాపగ్రహ condition match కాలేదు.',
      rule: '5వ భావం/5వ అధిపతి పాపగ్రహ పీడనలో ఉంటే సంతాన ఫలితంలో కష్ట/ఆలస్యం layerగా source చూడమంటుంది.',
      inspection: 'D7 5వ భావ పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” pp.1–2; Sarala VII D7 p.5',
      tone: VargaRuleTone.caution,
      applicable: mal.length >= 2,
    );
  }

  static void _d9(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 7,
      favorableId: 'S7-D9-01',
      cautionId: 'S7-D9-02',
      topic: 'వివాహ వాగ్దానం',
      favorableResult: 'D9 7వ భావంలో శుభగ్రహ support ఉంది; వివాహ/భాగస్వామ్యానికి అనుకూల layer.',
      cautionResult: 'D9 7వ భావంలో పాపగ్రహ ప్రభావం ఉంది; సంబంధాన్ని ఇతర factorsతో జాగ్రత్తగా చూడాలి.',
      rule: 'D9లో 7వ భావం, 7వ అధిపతి, దారాకారక/జ్ఞాతికారక సంబంధాన్ని వివాహానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D9, supplied “Sarala 7 final.pdf” p.6',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D9-03',
      cautionId: 'S7-D9-04',
      topic: 'ధర్మం / నైతిక దిశ',
      favorableResult: 'D9 9వ భావంలో శుభగ్రహ support ఉంది; ధర్మ/గురు/నైతికతకు అనుకూల layer.',
      cautionResult: 'D9 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ధర్మ/గురు అంశంలో జాగ్రత్త layer.',
      rule: 'D9 9వ భావం, 9వ అధిపతి, గురువును ధర్మ ఫలానికి పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D9, supplied “Sarala 7 final.pdf” pp.6–7',
      add: add,
    );
  }

  static void _d10(
    AstroChartResult chart,
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    final d9 = VargaService.calculate(chart, 9);
    final d10LagnaSign = v.ascendantSignIndex;
    final d10TenthSign = _houseSign(v, 10);
    final d10TenthLord = _signLord(d10TenthSign);
    final d10TenthLordPlacement = v.planets.firstWhere((p) => p.name == d10TenthLord);
    final d10TenthLordHouse = _houseOf(v, d10TenthLordPlacement);
    final d10FirstLord = _signLord(d10LagnaSign);
    final d10ThirdLord = _signLord(_houseSign(v, 3));
    final d10EleventhLord = _signLord(_houseSign(v, 11));
    final d10SeventhLord = _signLord(_houseSign(v, 7));
    final d1TenthSign = (chart.ascendantSignIndex + 9) % 12;
    final d1TenthLord = _signLord(d1TenthSign);
    final d9TenthLord = _signLord(_houseSign(d9, 10));
    final tenthNames = _houseNames(v, 10);
    final seventhNames = _houseNames(v, 7);
    final thirdNames = _houseNames(v, 3);
    final twelfthNames = _houseNames(v, 12);
    final eighthNames = _houseNames(v, 8);
    final tenthBenefics = tenthNames.where(_benefics.contains).toList();
    final tenthMalefics = tenthNames.where(_malefics.contains).toList();

    ({int score, String why}) professionScore(List<String> group) {
      var score = 0;
      final why = <String>[];
      if (group.contains(d10TenthLord)) {
        score += 30;
        why.add('D10 10వ అధిపతి $d10TenthLord match');
      }
      final tenthMatch = tenthNames.where(group.contains).toList();
      if (tenthMatch.isNotEmpty) {
        score += 25;
        why.add('D10 10వ భావంలో ${tenthMatch.join(', ')}');
      }
      final lagnaNames = _houseNames(v, 1);
      final lagnaMatch = lagnaNames.where(group.contains).toList();
      if (lagnaMatch.isNotEmpty) {
        score += 15;
        why.add('D10 లగ్నంలో ${lagnaMatch.join(', ')}');
      }
      if (group.contains(d1TenthLord)) {
        score += 15;
        why.add('D1 10వ అధిపతి $d1TenthLord match');
      }
      if (group.contains(d9TenthLord)) {
        score += 10;
        why.add('D9 10వ అధిపతి $d9TenthLord match');
      }
      final signType = switch (d10TenthSign) {
        0 || 5 || 7 || 9 || 10 => 'technical',
        2 || 4 || 6 => 'semitechnical',
        _ => 'nontechnical',
      };
      final typeMatch =
          (group.any((g) => const ['Mars', 'Saturn', 'Rahu'].contains(g)) && signType == 'technical') ||
          (group.any((g) => const ['Sun', 'Mercury'].contains(g)) && signType == 'semitechnical') ||
          (group.any((g) => const ['Moon', 'Jupiter', 'Venus'].contains(g)) && signType == 'nontechnical');
      if (typeMatch) {
        score += 5;
        why.add('D10 10వ రాశి classification: $signType');
      }
      return (score: score.clamp(0, 100).toInt(), why: why.isEmpty ? 'source-backed matching indicator స్పష్టంగా లేదు' : why.join(' • '));
    }

    _beneficMaleficHouseRule(
      v: v,
      house: 10,
      favorableId: 'D10-CAR-01',
      cautionId: 'D10-CAR-02',
      topic: 'వృత్తి / స్థాయి',
      favorableResult: 'D10 10వ భావంలో శుభగ్రహ support ఉంది; స్థాయి/గౌరవం/వృత్తికి అనుకూల layer.',
      cautionResult: 'D10 10వ భావంలో పాపగ్రహ ప్రభావం ఉంది; వృత్తిలో ఒత్తిడి/శిక్ష/అవమానం వంటి జాగ్రత్త layer.',
      rule: 'D10 Lagna, 10వ భావం, 10వ అధిపతి, అమాత్యకారక బలం/శుభ సంబంధాన్ని స్థాయి–కీర్తికి చూడాలి; పీడ ఉంటే అవమానం/శిక్ష layer.',
      source: '“D10-dashamsha-rule-guide.pdf” + Sarala VII D10 p.7',
      add: add,
    );

    final supportHouses = [2, 4, 11, 5];
    final obstructionHouses = [12, 10, 3, 9];
    final supportCount = supportHouses.fold<int>(0, (sum, h) => sum + _houseNames(v, h).length);
    final obstructionCount = obstructionHouses.fold<int>(0, (sum, h) => sum + _houseNames(v, h).length);
    final argalaTone = supportCount > obstructionCount
        ? VargaRuleTone.favorable
        : obstructionCount > supportCount
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'D10-R6.1',
      topic: 'వృత్తి అర్గళ బలం',
      result: supportCount > obstructionCount
          ? 'D10లో అర్గళ support అడ్డుకంటే ఎక్కువగా ఉంది; వృత్తి నిలకడకు అనుకూల source arithmetic.'
          : obstructionCount > supportCount
              ? 'D10లో అడ్డుగ్రహ count అర్గళ supportకంటే ఎక్కువగా ఉంది; వృత్తి స్థిరత్వంలో జాగ్రత్త layer.'
              : 'D10 అర్గళ–అడ్డుగ్రహ count సమంగా ఉంది; మిశ్రమ support.',
      rule: '4, 2, 11 భావాలు అర్గళ; వాటి అడ్డులు 10, 12, 3. 5వ భావం కూడా అర్గళ; 9వ భావం అడ్డుగా చూడాలి. అర్గళ గ్రహాలు అడ్డుకంటే బలంగా/ఎక్కువగా ఉంటే వృత్తి నిలుస్తుంది.',
      inspection: 'Argala houses 2/4/11/5 = $supportCount occupants; obstruction 12/10/3/9 = $obstructionCount occupants.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.1, p.8',
      tone: argalaTone,
      applicable: supportCount != obstructionCount,
    );

    final h3Mal = thirdNames.where(_malefics.contains).toList();
    add(
      id: 'D10-R6.2',
      topic: 'ప్రత్యేక అర్గళ',
      result: h3Mal.length >= 3 ? 'D10 3వ భావంలో 3+ పాపగ్రహాలు ఉన్నాయి; source ప్రకారం ప్రత్యేక అర్గళ layer.' : 'ప్రత్యేక అర్గళ condition match కాలేదు.',
      rule: '3వ భావంలో 3 లేదా ఎక్కువ పాపగ్రహాలు ఉంటే ప్రత్యేక అర్గళ; దీనికి అడ్డుగా source చూడదు.',
      inspection: 'D10 3వ భావ పాపగ్రహాలు: ${h3Mal.isEmpty ? 'లేవు' : h3Mal.join(', ')}.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.2, p.8',
      tone: h3Mal.length >= 3 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: h3Mal.length >= 3,
    );

    final natal10Planets = chart.planets.where((p) => p.signIndex == d1TenthSign).toList();
    final lordArgala = supportHouses.contains(d10TenthLordHouse) || d10TenthLordHouse == 1 || d10TenthLordHouse == 10;
    add(
      id: 'D10-R6.9',
      topic: 'జన్మ 10వ అధిపతి × D10',
      result: lordArgala ? 'జన్మ 10వ అధిపతి D10లో ముఖ్య/అర్గళ స్థానంలో ఉంది; వృత్తి నిర్ణయానికి బలమైన confirmation layer.' : 'జన్మ 10వ అధిపతి D10లో ప్రధాన argala/Lagna/10వ స్థానానికి match కాలేదు.',
      rule: 'జన్మ 10వ అధిపతి D10లో అర్గళ ఇస్తే ముఖ్యంగా చూడాలి; D10 Lagna/10వ సంబంధం ఉంటే ఫలిత weight పెరుగుతుంది.',
      inspection: 'జన్మ 10వ రాశి ${d1TenthSign + 1}; అధిపతి $d1TenthLord; D10లో $d1TenthLord House ${_houseOf(v, v.planets.firstWhere((p) => p.name == d1TenthLord))}. జన్మ 10వలో గ్రహాలు: ${natal10Planets.isEmpty ? 'లేవు' : natal10Planets.map((p) => p.name).join(', ')}.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.9, p.9',
      tone: lordArgala ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: lordArgala,
    );

    // Profession shortlist — source-backed layers only. The scoring weights are
    // the transparent app compatibility index already present in the supplied
    // Profession Rules file; they are not claimed as a classical percentage.
    final ranked = <({String name, int score, String why})>[];
    for (final item in _d10ProfessionCatalog) {
      final scored = professionScore(item.$2);
      ranked.add((name: item.$1, score: scored.score, why: scored.why));
    }
    ranked.sort((a, b) => b.score.compareTo(a.score));
    final topProf = ranked.take(8).toList(growable: false);
    add(
      id: 'D10-PROF-LIST',
      topic: 'అనుకూల వృత్తుల జాబితా',
      result: topProf.map((x) => '${x.name} — ${x.score}%').join(' • '),
      rule: 'D10 sourceలో ఉన్న 10వ అధిపతి, 10వ భావం, D10 లగ్నం, D1→D10 link, D9 confirmation మరియు 10వ రాశి technical/semi-technical/non-technical classification ఆధారంగా app compatibility index తయారవుతుంది. ఇది classical probability కాదు. నక్షత్ర వృత్తులు మరియు దశాంశ దేవత professionsకు exact supplied source table ఇప్పటి filesలో లేదు; అందువల్ల వాటిని scoreలో కలపలేదు.',
      inspection: 'D10 లగ్నం ${_d10SignNames[d10LagnaSign]}; 10వ రాశి ${_d10SignNames[d10TenthSign]}; 10వ అధిపతి $d10TenthLord ($d10TenthLordHouseవ భావం). Top evidence: ${topProf.take(3).map((x) => '${x.name}: ${x.why}').join(' | ')}.',
      source: 'Annapurna_Astro_Vastu_V38_Profession_Rules.html — D10.pdf pp.13–16, 38–47; app compatibility formula retained from supplied profession module.',
      tone: VargaRuleTone.favorable,
      applicable: true,
      remedy: 'వృత్తి ఎంపికకు ఇది source-backed suitability shortlist మాత్రమే. విద్య, నైపుణ్యం, ఆసక్తి, మార్కెట్ అవకాశాలు, అనుభవం వంటి practical factorsతో కలిపి నిర్ణయించాలి. Sourceలో వృత్తి కోసం ప్రత్యేక రత్న/హోమ పరిహారం ఇవ్వలేదు.',
    );

    final service = professionScore(const ['Saturn', 'Moon', 'Mercury']);
    final commercial = professionScore(const ['Mercury', 'Venus', 'Rahu']);
    final selfEmployment = professionScore(const ['Sun', 'Mars', 'Rahu', 'Moon']);
    final businessScore = commercial.score > selfEmployment.score ? commercial.score : selfEmployment.score;
    final jobVsBusinessTone = (service.score - businessScore).abs() < 15 ? VargaRuleTone.neutral : VargaRuleTone.favorable;
    final jobVsBusinessResult = service.score >= businessScore + 15
        ? 'ఉద్యోగం / Service సూచనలు బలంగా ఉన్నాయి — Job ${service.score}% vs Business $businessScore%.'
        : businessScore >= service.score + 15
            ? 'వ్యాపారం / Self-employment సూచనలు బలంగా ఉన్నాయి — Business $businessScore% vs Job ${service.score}%.'
            : 'ఉద్యోగం మరియు వ్యాపారం రెండింటికీ support ఉంది — Job ${service.score}% vs Business $businessScore%. ఇతర timing evidence అవసరం.';
    add(
      id: 'D10-JOB-BUSINESS',
      topic: 'Job లేదా Business',
      result: jobVsBusinessResult,
      rule: 'Supplied D10 profession sourceలో service/self-employment నిర్ణయానికి Saturn condition across D1/D9/D10, Sun/Moon/10th-lord relation, PP-planet pattern మరియు 3rd-house/3rd-lord relation supporting checksగా ఉన్నాయి. App shortlistలో Service/Employment మరియు Commercial/Self-employment source profession groupsను పోల్చాం.',
      inspection: 'Service evidence: ${service.why}. Business evidence: ${(commercial.score >= selfEmployment.score) ? commercial.why : selfEmployment.why}.',
      source: 'D10.pdf pp.60–72 + supplied Profession Rules module; KP job-vs-business source is kept as separate confirmation layer.',
      tone: jobVsBusinessTone,
      applicable: true,
      remedy: 'Job/Business నిర్ణయం కోసం పరిహారం కంటే skill, capital, stability, experience, family/financial obligations వంటి practical factorsను ముందుగా చూడాలి. Source-specific spiritual remedy ఉంటేనే appలో విడిగా చూపాలి.',
    );

    add(
      id: 'D10-SEQUENCE',
      topic: 'ముందు Job → తరువాత Business / ముందు Business → తరువాత Job',
      result: 'Static D10 chart ఒక్కటితో career sequenceను ఖచ్చితంగా నిర్ణయించే source rule మన current filesలో లేదు. Sequence కోసం Dasha/period timing rule తప్పనిసరి; source లేకుండా app orderను ఊహించదు.',
      rule: 'D10 వృత్తి స్వభావాన్ని చూపుతుంది; Job↔Business chronological orderకు source-defined period activation అవసరం. సంబంధిత dasha/timing source rule లభించిన తర్వాత మాత్రమే sequence auto-result ఇవ్వాలి.',
      inspection: 'ప్రస్తుత D10 tendency: Job ${service.score}% • Business $businessScore%. ఇది order కాదు.',
      source: 'D10 profession source + source-boundary policy; exact Job→Business / Business→Job timing formula not supplied.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );

    final highPosition = professionScore(const ['Sun', 'Jupiter', 'Saturn']);
    add(
      id: 'D10-HIGH-POSITION',
      topic: 'High position in Job / Management',
      result: highPosition.score >= 60
          ? 'Management / high-position profession indicators బలంగా ఉన్నాయి — app compatibility ${highPosition.score}%.'
          : highPosition.score >= 30
              ? 'High-position indicators మధ్యస్థంగా ఉన్నాయి — ${highPosition.score}%; ఇతర status/timing rulesతో confirm చేయాలి.'
              : 'High-position source indicators ఈ operational checkలో బలంగా కనిపించలేదు — ${highPosition.score}%.',
      rule: 'Supplied profession listలో Management / High Positionకు Sun + Jupiter + Saturn మరియు 10వ భావ సంబంధం ప్రధాన indicatorsగా ఉన్నాయి.',
      inspection: highPosition.why,
      source: 'Annapurna_Astro_Vastu_V38_Profession_Rules.html — profession list; D10.pdf profession significations.',
      tone: highPosition.score >= 60 ? VargaRuleTone.favorable : highPosition.score >= 30 ? VargaRuleTone.neutral : VargaRuleTone.caution,
      applicable: true,
    );

    for (final item in const [
      ('D10-GOCHARISTA', 'గోచరిస్తా / Gocharista', 'మీరు సూచించిన “Gocharista” termకు exact condition/formula current supplied D10 filesలో textగా దొరకలేదు. Rule page/source వచ్చినప్పుడు Business/High-position resultకు auto-link చేయాలి.'),
      ('D10-AGOCHARISTA', 'Agocharista', 'మీరు సూచించిన “Agocharista” termకు exact source condition current filesలో లేదు. Source లేకుండా meaning లేదా formulaను app సృష్టించదు.'),
    ]) {
      add(
        id: item.$1,
        topic: item.$2,
        result: item.$3,
        rule: 'Exact source condition అందిన తర్వాత మాత్రమే ఈ termకు matched/not-matched verdict ఇవ్వాలి.',
        inspection: 'D10 chart సిద్ధంగా ఉంది; కానీ source rule missing.',
        source: 'User-requested D10 topic — exact source page pending.',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
      );
    }

    final saturnD1 = chart.planets.firstWhere((p) => p.name == 'Saturn');
    final saturnD9 = d9.planets.firstWhere((p) => p.name == 'Saturn');
    final saturnD10 = v.planets.firstWhere((p) => p.name == 'Saturn');
    final sunD10 = v.planets.firstWhere((p) => p.name == 'Sun');
    final moonD10 = v.planets.firstWhere((p) => p.name == 'Moon');
    final sameWith = <String>[];
    if (saturnD10.signIndex == sunD10.signIndex) sameWith.add('Sun');
    if (saturnD10.signIndex == moonD10.signIndex) sameWith.add('Moon');
    if (saturnD10.signIndex == d10TenthLordPlacement.signIndex && d10TenthLord != 'Saturn') sameWith.add('10L $d10TenthLord');
    add(
      id: 'D10-SATURN-REL',
      topic: 'Relation of Saturn',
      result: 'Saturn: D1 ${((saturnD1.signIndex - chart.ascendantSignIndex + 12) % 12) + 1}వ భావం • D9 ${_houseOf(d9, saturnD9)}వ భావం • D10 ${_houseOf(v, saturnD10)}వ భావం. D10 same-sign relation: ${sameWith.isEmpty ? 'Sun/Moon/10Lతో conjunction లేదు' : sameWith.join(', ')}.',
      rule: 'Supplied D10 source self-employment/service assessmentలో Saturn condition across D1, Navamsha, Dashamsha మరియు Sun/Moon/10th-lord relationను supporting checkగా ఉపయోగిస్తుంది. Exact aspect scheme source-defined అయినందున ఇక్కడ same-sign association మాత్రమే auto-check చేశాం.',
      inspection: 'D10 Saturn ${_d10SignNames[saturnD10.signIndex]} • House ${_houseOf(v, saturnD10)}; Sun House ${_houseOf(v, sunD10)}; Moon House ${_houseOf(v, moonD10)}; 10L $d10TenthLord House $d10TenthLordHouse.',
      source: 'D10.pdf pp.60–72 — self-employment/service supporting checks.',
      tone: VargaRuleTone.neutral,
      applicable: true,
    );

    final ppPlanets = const ['Mercury', 'Jupiter', 'Venus'];
    final ppStrong = ppPlanets.where((name) {
      final h = _houseOf(v, v.planets.firstWhere((p) => p.name == name));
      return const [1, 4, 5, 7, 9, 10].contains(h);
    }).toList();
    add(
      id: 'D10-PP',
      topic: 'PP Planets',
      result: ppStrong.isNotEmpty
          ? 'PP/Purna-Paramatma groupలో ${ppStrong.join(', ')} D10 kendra/trikona supportలో ఉన్నాయి; source implementationలో profession quality supportగా పరిగణించబడింది.'
          : 'PP group Mercury/Jupiter/Venusకు ఈ simple D10 kendra/trikona checkలో బలమైన placement కనిపించలేదు.',
      rule: 'Supplied legacy D10 implementationలో Mercury/Jupiter/Venus group strengthను profession-quality supporting checkగా ఉపయోగించారు. ఇది standalone career verdict కాదు.',
      inspection: ppPlanets.map((name) => '$name H${_houseOf(v, v.planets.firstWhere((p) => p.name == name))}').join(' • '),
      source: 'annapurna-jataka-16.html — V.P. Goel D10 implementation / PP-planet support.',
      tone: ppStrong.isNotEmpty ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: ppStrong.isNotEmpty,
    );

    int? fivePlanetHouse;
    for (var h = 1; h <= 12; h++) {
      if (_houseNames(v, h).length >= 5) {
        fivePlanetHouse = h;
        break;
      }
    }
    add(
      id: 'D10-FIVE-PLANETS',
      topic: 'Five Planets',
      result: fivePlanetHouse == null
          ? 'D10లో ఒకే భావంలో 5+ గ్రహాల concentration లేదు.'
          : 'D10 $fivePlanetHouseవ భావంలో 5+ గ్రహాలు ఉన్నాయి; source implementation ప్రకారం ఆ భావం అత్యంత బలంగా emphasize అవుతుంది.',
      rule: 'ఐదు గ్రహాలు ఒకే D10 భావంలో ఉంటే ఆ భావం అతి బలంగా/ప్రధానంగా పనిచేస్తుందని supplied legacy implementationలో rule ఉంది.',
      inspection: fivePlanetHouse == null ? '5+ planet cluster లేదు.' : 'House $fivePlanetHouse: ${_houseNames(v, fivePlanetHouse).join(', ')}.',
      source: 'annapurna-jataka-16.html — V.P. Goel D10 implementation.',
      tone: fivePlanetHouse == null ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: fivePlanetHouse != null,
    );

    final thirdLordPlacement = v.planets.firstWhere((p) => p.name == d10ThirdLord);
    final thirdLordHouse = _houseOf(v, thirdLordPlacement);
    add(
      id: 'D10-THIRD-HOUSE',
      topic: 'Third House / Lord',
      result: 'D10 3వ భావం: ${thirdNames.isEmpty ? 'ఖాళీ' : thirdNames.join(', ')}. 3వ అధిపతి $d10ThirdLord $thirdLordHouseవ భావంలో. Source ప్రకారం 3వ భావం ధైర్యం, side-work, self-effort, transfer మరియు self-employment/service distinctionకు supporting layer.',
      rule: 'D10 profession sourceలో 3rd house / 3rd lord relationను self-employment/service supporting checkగా ఉపయోగించాలి; 3వ భావంలో 3+ malefics ఉంటే special argala ruleను విడిగా చూడాలి.',
      inspection: '3H occupants: ${thirdNames.isEmpty ? 'none' : thirdNames.join(', ')} • 3L $d10ThirdLord → H$thirdLordHouse.',
      source: 'D10.pdf pp.46–47, 60–72 + D10 Rule 6.2.',
      tone: VargaRuleTone.neutral,
      applicable: true,
    );

    final statusTone = d10TenthLordHouse == 8 || d10TenthLordHouse == 12
        ? VargaRuleTone.caution
        : const [1, 4, 5, 7, 9, 10, 11, 2].contains(d10TenthLordHouse)
            ? VargaRuleTone.favorable
            : VargaRuleTone.neutral;
    add(
      id: 'D10-STATUS',
      topic: 'Status / Position',
      result: 'D10 10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ భావంలో; 10వ భావంలో ${tenthNames.isEmpty ? 'గ్రహాలు లేవు' : tenthNames.join(', ')}. ${tenthBenefics.isNotEmpty ? 'Benefic support: ${tenthBenefics.join(', ')}.' : ''} ${tenthMalefics.isNotEmpty ? 'Malefic pressure: ${tenthMalefics.join(', ')}.' : ''}',
      rule: 'D10 10వ భావం profession/status/earning direction; 10వ అధిపతి placement మరియు associationsతో statusను refine చేయాలి.',
      inspection: '10H sign ${_d10SignNames[d10TenthSign]} • 10L $d10TenthLord H$d10TenthLordHouse.',
      source: 'D10.pdf pp.14–16; supplied Profession Rules.',
      tone: statusTone,
      applicable: true,
    );

    for (final item in const [
      ('D10-RAJAYOGA', 'రాజయోగం', 'D10-specific Rajayogaకు exact supplied career-source condition current D10 filesలో స్పష్టంగా లేదు. Jaimini/other source Rajayoga rulesను D10 ruleగా silently మార్చము.'),
      ('D10-MAHABHAGYA', 'Mahabhagya Yoga', 'Mahabhagya Yogaను D10 career verdictగా apply చేసే exact supplied source rule ప్రస్తుతం లభించలేదు; source వచ్చిన తర్వాత మాత్రమే evaluator చేయాలి.'),
    ]) {
      add(
        id: item.$1,
        topic: item.$2,
        result: item.$3,
        rule: 'ఈ topicకు source-specific D10 condition అవసరం.',
        inspection: 'Chart calculated; exact D10 source condition pending.',
        source: 'Requested D10 topic — exact supplied rule pending.',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
      );
    }

    final rise = const [1, 4, 5, 7, 9, 10, 2, 11].contains(d10TenthLordHouse);
    final fall = const [6, 8, 12].contains(d10TenthLordHouse);
    add(
      id: 'D10-RISE-FALL',
      topic: 'Rise / Fall',
      result: rise
          ? '10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ భావంలో ఉండటం source placement table ప్రకారం rise/support వైపు బలం చూపిస్తోంది.'
          : fall
              ? '10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ దుస్థానంలో; career obstacles/fall-risk layerగా జాగ్రత్తగా చూడాలి.'
              : '10వ అధిపతి placement mixed/effort-oriented. ఇతర D10 supportతో కలిపి నిర్ణయించాలి.',
      rule: 'Supplied Goel implementation: 10వ అధిపతి Kendra=సుఖం, Trikona=శ్రీ, 2/11=ధనం, 3=శ్రమ, 6/8/12=ఆటంకం.',
      inspection: 'D10 10L $d10TenthLord → House $d10TenthLordHouse.',
      source: 'annapurna-jataka-16.html — V.P. Goel D10 implementation.',
      tone: rise ? VargaRuleTone.favorable : fall ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    final keyLords = <String>{d10FirstLord, d10ThirdLord, d10SeventhLord, d10TenthLord, d10EleventhLord}.toList();
    final inter = <String>[];
    for (var i = 0; i < keyLords.length; i++) {
      for (var j = i + 1; j < keyLords.length; j++) {
        final a = v.planets.firstWhere((p) => p.name == keyLords[i]);
        final b = v.planets.firstWhere((p) => p.name == keyLords[j]);
        if (a.signIndex == b.signIndex) inter.add('${keyLords[i]} + ${keyLords[j]}');
      }
    }
    add(
      id: 'D10-INTERRELATION',
      topic: 'Inter-relation',
      result: inter.isEmpty ? 'D10 1L/3L/7L/10L/11L మధ్య same-sign conjunction ఈ simple auto-checkలో లేదు.' : 'Career key lords same-sign inter-relations: ${inter.join(' • ')}.',
      rule: 'D10 profession assessmentలో relevant lords/planets relationshipsను చూడాలి. Source-specific aspect scheme పూర్తిగా implement చేయకుండా ఇక్కడ conjunction/same-sign relation మాత్రమే auto-check అవుతుంది.',
      inspection: '1L $d10FirstLord • 3L $d10ThirdLord • 7L $d10SeventhLord • 10L $d10TenthLord • 11L $d10EleventhLord.',
      source: 'D10 source rule: relevant planets/relationships; exact aspect scheme remains source-bound.',
      tone: inter.isEmpty ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    final partnership = professionScore(const ['Mercury', 'Venus', 'Rahu']);
    add(
      id: 'D10-PARTNERSHIP',
      topic: 'Partnership / Business Partnership',
      result: partnership.score >= 60
          ? 'Partnership/business indicators బలంగా ఉన్నాయి — ${partnership.score}%. 7వ భావం: ${seventhNames.isEmpty ? 'ఖాళీ' : seventhNames.join(', ')}.'
          : 'Partnership/business support ${partnership.score}%. 7వ భావం మరియు 3/11 సంబంధాలను ఇతర evidenceతో confirm చేయాలి.',
      rule: 'D10 house-profession sourceలో 7వ భావం business/partnership; Commercial/Business groupకు Mercury, Venus, Rahu మరియు 3/7/11 houses ప్రధాన source indicators.',
      inspection: '${partnership.why} • 7L $d10SeventhLord H${_houseOf(v, v.planets.firstWhere((p) => p.name == d10SeventhLord))}.',
      source: 'D10.pdf pp.46–47 + supplied Profession Rules profession list.',
      tone: partnership.score >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    add(
      id: 'D10-CAREER-GRAPH',
      topic: 'Career Graph',
      result: 'Career graphకు D10 static strength మాత్రమే సరిపోదు. Year/period-wise rise/fall graph కోసం dasha/timing activation rule source అవసరం; source లేకుండా artificial graph చూపించము.',
      rule: 'Career graph = D10 promise + source-defined timing periods. Exact period weighting supplied sourceలో లభించిన తర్వాత year-wise graph తయారు చేయాలి.',
      inspection: 'D10 promise layers calculated; timing graph source pending.',
      source: 'Requested D10 topic; timing source mapping pending.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );

    final rahuHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == 'Rahu'));
    final foreignSupport = d10TenthLordHouse == 12 || rahuHouse == 12 || twelfthNames.any(const ['Moon', 'Mercury', 'Rahu', 'Ketu'].contains);
    add(
      id: 'D10-FOREIGN-JOB',
      topic: 'Job in Foreign Land',
      result: foreignSupport
          ? 'D10 12వ భావ/foreign-institutional layer careerతో connect అవుతోంది; foreign job/travel-related professionకు supportగా చూడవచ్చు.'
          : 'D10 12వ భావంతో 10L/Rahu/foreign-career indicators ఈ simple evaluatorలో direct match కాలేదు.',
      rule: 'Supplied D10 house-profession ruleలో 12వ భావం foreign/institutional work. Travel/Tourism, Import/Export, Diplomacy వంటి source profession groups 12వ సంబంధాన్ని ఉపయోగిస్తాయి.',
      inspection: '10L H$d10TenthLordHouse • Rahu H$rahuHouse • 12H occupants: ${twelfthNames.isEmpty ? 'none' : twelfthNames.join(', ')}.',
      source: 'D10.pdf pp.46–47 + supplied Profession Rules list.',
      tone: foreignSupport ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    add(
      id: 'D10-PROMOTION',
      topic: 'Promotions',
      result: 'D10 status supportను ఇక్కడ చూడవచ్చు; కానీ exact promotion eventకు supplied KP rule 10th/11th cusp sub-lord → 2,6,10,11 significationsను కోరుతుంది. Current D10-only dataతో ఆ cusp ruleను auto-fire చేయము.',
      rule: 'Promotion source: 10th or 11th cusp sub-lord signifies 2,6,10,11. D10 10వ భావ/10L strength supporting evidence మాత్రమే.',
      inspection: 'D10 status evidence: 10L $d10TenthLord H$d10TenthLordHouse; 10H ${tenthNames.isEmpty ? 'empty' : tenthNames.join(', ')}.',
      source: 'k.p rules (horary).pdf p.9 — KP-SAFE-017 + D10 supporting layer.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );

    final jobLossRisk = d10TenthLordHouse == 8 || d10TenthLordHouse == 12 || (tenthMalefics.length >= 2 && tenthBenefics.isEmpty);
    add(
      id: 'D10-JOB-LOSS',
      topic: 'Loss in Job',
      result: jobLossRisk
          ? 'D10లో job-loss/instability జాగ్రత్త layer కనిపిస్తోంది: 10L H$d10TenthLordHouse; 10వ భావ malefic pressure ${tenthMalefics.isEmpty ? 'లేదు' : tenthMalefics.join(', ')}. ఇది certainty కాదు.'
          : 'D10లో 10L 8/12 placement లేదా strong unmitigated 10H pressure ఈ simple checkలో కనిపించలేదు.',
      rule: 'Supplied D10 house meaningsలో 8వ భావం sudden change/debt, 12వ భావం loss/foreign/institutional work; 10వ భావ pressure status/career difficulty layer. వీటిని ఇతర timing evidenceతో confirm చేయాలి.',
      inspection: '8H ${eighthNames.isEmpty ? 'empty' : eighthNames.join(', ')} • 10H ${tenthNames.isEmpty ? 'empty' : tenthNames.join(', ')} • 12H ${twelfthNames.isEmpty ? 'empty' : twelfthNames.join(', ')}.',
      source: 'annapurna-jataka-16.html — V.P. Goel D10 house interpretation; D10.pdf pp.46–47.',
      tone: jobLossRisk ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఉద్యోగ స్థిరత్వంపై ఆందోళన ఉంటే skill-upgrade, documentation, financial buffer, professional communication వంటి practical steps ముందుగా చేయాలి. ఈ D10 sourceలో నిర్దిష్ట spiritual remedy prescription లేదు.',
    );

    final transferSupport = d10TenthLordHouse == 3 || thirdLordHouse == 10 || thirdNames.isNotEmpty;
    add(
      id: 'D10-TRANSFER',
      topic: 'Transfer / Job Location Change',
      result: transferSupport
          ? 'D10 3వ భావం/3L careerతో సంబంధం చూపుతోంది; transfer/location-change possibilityకు supporting layer ఉంది. Exact timingకు period rule అవసరం.'
          : 'D10 3H/3L నుంచి direct career-transfer relation ఈ simple evaluatorలో బలంగా కనిపించలేదు.',
      rule: 'Supplied Goel D10 implementationలో 3వ భావం ధైర్యం, side-work, transfer. Exact event timingకు separate source period/KP rule అవసరం.',
      inspection: '3H: ${thirdNames.isEmpty ? 'empty' : thirdNames.join(', ')} • 3L $d10ThirdLord H$thirdLordHouse • 10L H$d10TenthLordHouse.',
      source: 'annapurna-jataka-16.html — V.P. Goel D10 implementation; KP transfer rule is separate confirmation.',
      tone: transferSupport ? VargaRuleTone.neutral : VargaRuleTone.info,
      applicable: true,
    );

    add(
      id: 'D10-RETIREMENT',
      topic: 'Retirement',
      result: 'Retirement timingకు exact supplied D10 rule current career sourcesలో లేదు. వయస్సు/దశ/10వ career disengagement source rule వచ్చిన తర్వాత మాత్రమే result ఇవ్వాలి.',
      rule: 'Static D10తో retirement age/dateను ఊహించరాదు; source-defined timing rule అవసరం.',
      inspection: 'D10 career chart calculated; retirement timing rule pending.',
      source: 'Requested D10 topic — exact supplied source rule pending.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );

    add(
      id: 'D10-NAKSHATRA-PROF',
      topic: 'నక్షత్ర వృత్తులు',
      result: 'Profession shortlistలో నక్షత్ర వృత్తుల layerను కలపడానికి exact nakshatra→profession source table current filesలో లేదు. Table వచ్చిన వెంటనే top profession scoreలో separate evidenceగా కలపవచ్చు.',
      rule: 'Nakshatra profession mapping source table లేకుండా general astrology mappingను appలో substitute చేయకూడదు.',
      inspection: 'Current shortlist uses D10 10L/10H/Lagna + D1/D9 + sign classification only.',
      source: 'Requested profession layer — source table pending.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );

    add(
      id: 'D10-DEVATA-PROF',
      topic: 'దశాంశ దేవత ఆధార వృత్తులు',
      result: 'D10 Devata→profession exact source mapping current supplied filesలో లేదు. Source table లేకుండా దేవత పేర్లు/వృత్తులను ఊహించి scoreలో కలపలేదు.',
      rule: 'Dashamsha Devata profession layerను source tableతో validate చేసిన తర్వాత మాత్రమే profession shortlistలో weight ఇవ్వాలి.',
      inspection: 'D10 divisions calculated; Devata profession source mapping pending.',
      source: 'Requested D10 layer — exact Devata profession source pending.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );
  }

  static void _d12(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D12-01',
      cautionId: 'S7-D12-02',
      topic: 'పూర్వీక ఆశీర్వాదం / కుటుంబ రక్షణ',
      favorableResult: 'D12 లగ్నంలో శుభగ్రహ support ఉంది; పూర్వీక/తల్లిదండ్రుల సహకారానికి అనుకూల layer.',
      cautionResult: 'D12 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; కుటుంబ/పూర్వీక అంశంలో కఠిన అనుభవ layer.',
      rule: 'D12లో కారకాంశ లగ్నం/లగ్నాధిపతి బలం మరియు శుభ/క్రూర సంబంధాన్ని పూర్వీక ఆశీర్వాదానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D12, supplied “Sarala 7 final.pdf” p.9',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 4,
      favorableId: 'S7-D12-03',
      cautionId: 'S7-D12-04',
      topic: 'తల్లి / సుఖం',
      favorableResult: 'D12 4వ భావంలో శుభగ్రహ support ఉంది; తల్లి/గృహ సౌఖ్యానికి అనుకూల layer.',
      cautionResult: 'D12 4వ భావంలో పాపగ్రహ ప్రభావం ఉంది; తల్లి/గృహసుఖ అంశంలో జాగ్రత్త layer.',
      rule: 'D12లో 4వ భావ పీడను తల్లి/కుటుంబ సుఖానికి పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D12, supplied “Sarala 7 final.pdf” p.9',
      add: add,
    );
  }

  static void _d16(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D16-01',
      cautionId: 'S7-D16-02',
      topic: 'సుఖభోగం / వాహనం',
      favorableResult: 'D16 లగ్నంలో శుభగ్రహ support ఉంది; సుఖం/వాహన యోగానికి అనుకూల layer.',
      cautionResult: 'D16 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; సుఖం/వాహన అంశంలో జాగ్రత్త layer.',
      rule: 'D16లో లగ్నం, లగ్నాధిపతి, 4వ భావం, పుత్రకారక/సంబంధిత గ్రహాలను సుఖ–వాహన ఫలానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D16, supplied “Sarala 7 final.pdf” p.11',
      add: add,
    );
    final h468 = [4, 6, 8].expand((h) => _houseNames(v, h)).where(_malefics.contains).toList();
    add(
      id: 'S7-D16-03',
      topic: 'వాహన జాగ్రత్త',
      result: h468.length >= 2 ? 'D16 4/6/8 సంబంధిత ప్రాంతాల్లో బహుళ పాపగ్రహ ప్రభావం ఉంది; వాహన/ప్రయాణంలో జాగ్రత్త layer.' : 'D16 accident-caution simple condition match కాలేదు.',
      rule: '4, 6, 8 సంబంధం మరియు పాప ప్రభావాన్ని వాహన ప్రమాద/దొంగతనం అంశంలో source పరిశీలిస్తుంది.',
      inspection: 'D16 4/6/8లో పాపగ్రహ count: ${h468.length} (${h468.isEmpty ? 'లేవు' : h468.join(', ')}).',
      source: 'Sarala Jyotisham Part VII — D16, supplied “Sarala 7 final.pdf” pp.11–12',
      tone: VargaRuleTone.caution,
      applicable: h468.length >= 2,
    );
  }

  static void _d20(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 5,
      favorableId: 'S7-D20-01',
      cautionId: 'S7-D20-02',
      topic: 'బుద్ధి / ఆధ్యాత్మిక సాధన',
      favorableResult: 'D20 5వ భావంలో శుభగ్రహ support ఉంది; ఆధ్యాత్మిక బుద్ధి/సాధనకు అనుకూల layer.',
      cautionResult: 'D20 5వ భావంలో పాపగ్రహ ప్రభావం ఉంది; సాధనలో దృష్టి చెదరే/అడ్డంకి layer.',
      rule: 'D20లో 5వ భావం స్వభావ/బుద్ధి సూచకంగా; పుత్రకారక యోగం/జ్ఞాతికారక సంబంధాన్ని కూడా పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D20, supplied “Sarala 7 final.pdf” p.12',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D20-03',
      cautionId: 'S7-D20-04',
      topic: 'కర్మ / ధర్మ మార్గం',
      favorableResult: 'D20 9వ భావంలో శుభగ్రహ support ఉంది; కర్మ/ధర్మ సాధనకు అనుకూల layer.',
      cautionResult: 'D20 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; కర్మ/ధర్మ మార్గంలో అడ్డంకి layer.',
      rule: 'D20లో 9వ భావాన్ని కర్మవృత్తి/జ్ఞానం/విధానం సూచనగా source చూడమంటుంది.',
      source: 'Sarala Jyotisham Part VII — D20, supplied “Sarala 7 final.pdf” pp.12–13',
      add: add,
    );
  }

  static void _d24(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D24-01',
      cautionId: 'S7-D24-02',
      topic: 'విద్య వాగ్దానం',
      favorableResult: 'D24 లగ్నంలో శుభగ్రహ support ఉంది; విద్య/అభ్యాసానికి అనుకూల layer.',
      cautionResult: 'D24 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; విద్యలో ఆలస్యం/అడ్డంకి layer.',
      rule: 'D24లో లగ్న బలం విద్య వాగ్దానానికి ప్రధానంగా చూడాలి; 8వ భావం దీర్ఘ/లోతైన విద్యకు, 4వ/9వ/2వ/7వ భావాలు విద్య స్థాయిలకు source సూచిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D24, supplied “Sarala 7 final.pdf” p.13',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 8,
      favorableId: 'S7-D24-03',
      cautionId: 'S7-D24-04',
      topic: 'లోతైన విద్య / పరిశోధన',
      favorableResult: 'D24 8వ భావంలో శుభగ్రహ support ఉంది; దీర్ఘ/లోతైన విద్యకు అనుకూల layer.',
      cautionResult: 'D24 8వ భావంలో పాపగ్రహ ప్రభావం ఉంది; విద్యలో విరామం/దీర్ఘ అడ్డంకి layer.',
      rule: 'D24లో 8వ భావాన్ని విద్య ఆయుష్షు/దీర్ఘ కొనసాగింపుగా source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D24, supplied “Sarala 7 final.pdf” p.13',
      add: add,
    );
  }

  static void _d27(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    final afflictions = [6, 8]
        .expand((h) => _houseNames(v, h))
        .where(_malefics.contains)
        .toList();
    if (afflictions.isNotEmpty) {
      final severe = afflictions.length >= 2;
      add(
        id: severe ? 'S7-D27-02' : 'S7-D27-01',
        topic: 'శరీర/రోగ కారక జాగ్రత్త',
        result: severe
            ? 'D27 6/8 ప్రాంతాల్లో రెండు లేదా ఎక్కువ పాప ప్రభావాలు ఉన్నాయి; source ప్రకారం ఆరోగ్య అంశాన్ని గట్టిగా పరిశీలించాల్సిన layer.'
            : 'D27 6/8 ప్రాంతంలో ఒక పాప ప్రభావం ఉంది; చిన్న జాగ్రత్త layerగా చూడాలి.',
        rule: 'D27లో 6/8 సంబంధిత పాప ప్రభావాల సంఖ్యను రోగ/బాధ తీవ్రతకు source ఉపయోగిస్తుంది; ఒక పీడ చిన్న బాధ, రెండు లేదా ఎక్కువైతే కఠినత పెరుగుతుంది.',
        inspection: 'D27 6/8 పాపగ్రహాలు: ${afflictions.join(', ')}.',
        source: 'Sarala Jyotisham Part VII — D27, supplied “Sarala 7 final.pdf” pp.13–14',
        tone: VargaRuleTone.caution,
        applicable: true,
        remedy: 'ఈ sourceలో వైద్య పరిహారం prescription లేదు. ఆరోగ్య సమస్య ఉంటే వైద్యుడి సలహా అవసరం. జ్యోతిష్య పరిహారం ఇవ్వాలంటే separate source-supported remedy rules మాత్రమే వాడాలి.',
      );
    } else {
      add(
        id: 'S7-D27-00',
        topic: 'శరీర/రోగ కారక పరిశీలన',
        result: 'D27 6/8లో ఈ simple evaluatorకు పాపగ్రహ trigger కనిపించలేదు.',
        rule: 'D27 6/8 పాప ప్రభావాలను source రోగ కారక layerగా పరిశీలిస్తుంది.',
        inspection: 'D27 6/8 పాపగ్రహ count 0.',
        source: 'Sarala Jyotisham Part VII — D27, supplied “Sarala 7 final.pdf” pp.13–14',
        tone: VargaRuleTone.info,
        applicable: false,
      );
    }
  }

  static void _d30(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D30-01',
      cautionId: 'S7-D30-02',
      topic: 'అరిష్ట / సహనశక్తి',
      favorableResult: 'D30 లగ్నంలో శుభగ్రహ support ఉంది; కష్టాల్ని ఎదుర్కొనే resilienceకు అనుకూల layer.',
      cautionResult: 'D30 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; అరిష్ట/కష్టాల layerను ఇతర chart factorsతో జాగ్రత్తగా చూడాలి.',
      rule: 'D30లో కారకాంశ లగ్నంపై శుభ/పాప ప్రభావాన్ని శుభ జన్మ/కారక బలం/అరిష్ట అంశాలకు source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D30, supplied “Sarala 7 final.pdf” pp.14–15',
      add: add,
    );
  }

  static void _d40(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    add(
      id: 'S7-D40-SRC',
      topic: 'వృత్తి అడ్డంకులు / వృత్తి స్థాయి',
      result: 'D40 source rules ఉన్నాయి; అవి “జ్ఞాతికారక/వృత్తి అడ్డంకి గ్రహం” వంటి ప్రత్యేక karaka selectionపై ఆధారపడి ఉంటాయి. ఈ buildలో guess చేయకుండా source-onlyగా ఉంచాం.',
      rule: 'Sarala VII D40లో వృత్తి అడ్డంకి గ్రహ dignity/స్థానం ఆధారంగా వృత్తి కష్ట/స్థాయి ఫలితాలు ఉన్నాయి.',
      inspection: 'D40 chart సిద్ధంగా ఉంది; special career-obstacle karaka selection engine ఇంకా activate కాలేదు.',
      source: 'Sarala Jyotisham Part VII — D40, supplied “Sarala 7 final.pdf” pp.15–16',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );
  }

  static void _d45(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D45-01',
      cautionId: 'S7-D45-02',
      topic: 'ఆధ్యాత్మికత / పితృ సంస్కారం',
      favorableResult: 'D45 9వ భావంలో శుభగ్రహ support ఉంది; ఆధ్యాత్మిక/ధర్మ దిశకు అనుకూల layer.',
      cautionResult: 'D45 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ఆధ్యాత్మిక/పితృ సంస్కార దిశలో కఠిన అనుభవ layer.',
      rule: 'D45లో 5వ/9వ భావాలు, లగ్న/లగ్నాధిపతి, గురు త్రికోణ సంబంధాన్ని ఆధ్యాత్మిక ఫలానికి source పరిశీలిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D45, supplied “Sarala 7 final.pdf” pp.16–17',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 5,
      favorableId: 'S7-D45-03',
      cautionId: 'S7-D45-04',
      topic: 'పూర్వ పుణ్యం / బుద్ధి',
      favorableResult: 'D45 5వ భావంలో శుభగ్రహ support ఉంది; పూర్వపుణ్య/సంస్కారానికి అనుకూల layer.',
      cautionResult: 'D45 5వ భావంలో పాపగ్రహ ప్రభావం ఉంది; పూర్వపుణ్య/సంస్కార అంశంలో కఠిన layer.',
      rule: 'D45లో 5వ భావ పీడ/శుభ సంబంధాన్ని ఆధ్యాత్మిక అనుభవానికి source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D45, supplied “Sarala 7 final.pdf” pp.16–17',
      add: add,
    );
  }

  static void _d60(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D60-01',
      cautionId: 'S7-D60-02',
      topic: 'సూక్ష్మ కర్మ / కారక ఫలం',
      favorableResult: 'D60 లగ్నంలో శుభగ్రహ support ఉంది; సూక్ష్మ కర్మ layerలో అనుకూల background evidence.',
      cautionResult: 'D60 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; సూక్ష్మ కర్మ layerలో కఠిన background evidence.',
      rule: 'D60లో ప్రతి కారకుడిని విడిగా చూడాలి; శుభ సంబంధం మంచి ఫలం, పాప సంబంధం కష్ట/చివరి ఫలం layerగా source సూచిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D60, supplied “Sarala 7 final.pdf” p.18',
      add: add,
    );
    add(
      id: 'S7-D60-SRC',
      topic: 'D60 source boundary',
      result: 'D60 ఒక్కటితో final తీర్పు ఇవ్వకూడదు; source కూడా కారకాంశ/D1 layersతో కలిపి చూడమంటుంది.',
      rule: 'D60 సూక్ష్మ chart. Birth time sensitivity ఎక్కువ. ప్రతి కారకుడిని D1 మరియు ఇతర evidenceతో కలిపి చూడాలి.',
      inspection: 'D60 chart background evidenceగా మాత్రమే ఉపయోగించాలి.',
      source: 'Sarala Jyotisham Part VII — D60, supplied “Sarala 7 final.pdf” p.18',
      tone: VargaRuleTone.info,
      applicable: true,
      remedy: 'D60లో అశుభ సూచన కనిపించినందుకు మాత్రమే రత్నం/పరిహారం prescribe చేయవద్దు. ఇతర chart evidence + separate remedy source rule అవసరం.',
    );
  }


  static void _appendMarriageMaterialRegistry(
    int factor,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    for (final entry in MarriageMaterialRegistry.forFactor(factor)) {
      final partnerNote = entry.requiresTwoCharts
          ? 'ఈ ruleకు వధువు + వరుడు రెండింటి జాతకాలు అవసరం; single-chart resultగా fire చేయదు.'
          : 'ఈ handwritten/source rule exact condition పూర్తిగా machine-validated అయినప్పుడే auto-resultగా fire చేయాలి.';
      add(
        id: entry.id,
        topic: entry.topic,
        result: 'Source rule engineలో నమోదు అయింది; exact condition match కాకుండా result ఇవ్వదు.',
        rule: '${entry.note} $partnerNote',
        inspection: 'సంబంధిత chart layer D$factor లెక్కించబడింది. Source page ${entry.page}ను referenceగా ఉంచాం; ఊహా arithmetic ఉపయోగించము.',
        source: '${MarriageMaterialRegistry.sourceName} p.${entry.page}',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
        remedy: 'ఈ supplied marriage source ruleలో స్పష్టమైన పరిహారం ఉంటేనే link చేయాలి. Sourceలో లేని పరిహారం లేదా రత్నం auto-generate చేయరాదు.',
      );
    }
  }

  static void _appendV50SourceRegistry(
    int factor,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    void sourceOnly({
      required String id,
      required String topic,
      required String rule,
      required String source,
      String? remedy,
    }) {
      add(
        id: id,
        topic: topic,
        result: 'ఈ source rule సంబంధిత varga కింద నమోదు అయింది. Exact condition/strength inputs పూర్తిగా match అయినప్పుడు మాత్రమే positive/negative verdict ఇవ్వాలి.',
        rule: rule,
        inspection: 'ఈ chart layer లెక్కించబడింది; source-specific strength/aspect/exception inputs పూర్తిగా validate చేయకుండా auto-result ఇవ్వము.',
        source: source,
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
        remedy: remedy,
      );
    }

    switch (factor) {
      case 1:
        sourceOnly(
          id: 'SKM-V50-BASE',
          topic: 'S.K. Mehta — జాతక rule registry',
          rule: 'భావ/గ్రహ బలం, exchange, aspect, dignity, event-wise combinations మరియు timing/synchronizationను విడివిడిగా evidence layersగా పరిశీలించాలి. Exact event result source condition match అయినప్పుడే ఇవ్వాలి.',
          source: 'sk mehatha jyotisha-niyamavali.pdf — 36 pages',
        );
        sourceOnly(
          id: 'BNN-V50-BASE',
          topic: 'Brighu Naadi — Nadi rule registry',
          rule: 'R-A, C, E, F, G, H, I, J, K seriesగా indexed Nadi rulesను D1/Nadi method కింద source IDతో నిల్వ చేసి, exact combination match అయినప్పుడు మాత్రమే resultగా చూపాలి.',
          source: 'Brighu_Naadi_Purnna_Rulebook.pdf — 21 pages',
          remedy: 'ఈ Brighu Nadi source registry entryకి ప్రత్యేక remedy rule attach కాలేదు. Sourceలో remedy స్పష్టంగా ఉన్నప్పుడు మాత్రమే link చేయాలి; ఊహించి పరిహారం ఇవ్వకూడదు.',
        );
        sourceOnly(
          id: 'MED-ORG-V50',
          topic: 'అవయవ / రోగ జ్యోతిష్య సూచికలు',
          rule: 'రాశి/భావ/గ్రహ ఆధారంగా body-part, organ, disease-location indicatorsను source orderలో పరిశీలించాలి. ఇది సంప్రదాయ జ్యోతిష్య సూచిక మాత్రమే; వైద్య నిర్ధారణ కాదు.',
          source: 'avayava_roga_niyamalu.pdf — 24 pages',
          remedy: 'ఈ health rule నుంచి మందు, చికిత్స లేదా diagnosisను app ఇవ్వదు. ఆరోగ్య సమస్య ఉంటే qualified doctor/health professionalను సంప్రదించాలి. జ్యోతిష్య పరిహారం sourceలో స్పష్టంగా ఉంటేనే విడిగా చూపాలి.',
        );
        sourceOnly(
          id: 'MED-ROGA-V50',
          topic: 'Medical Astrology — Roga rule registry',
          rule: 'Medical Astrology sourceలో chapter-wise Rule → result నిర్మాణం ఉంది. సంబంధిత భావ/గ్రహ/లగ్న factors match అయినప్పుడు source ruleను చూపాలి; medical diagnosis/treatment output చేయకూడదు.',
          source: 'medical_roga_rules_complete.pdf — 19 pages',
          remedy: 'Medical Astrology resultను వైద్య సలహాగా ఉపయోగించకూడదు. App మందులు/చికిత్స prescribe చేయదు; అవసరమైతే doctor evaluation తీసుకోవాలి.',
        );
        break;
      case 2:
        sourceOnly(
          id: 'AV-015-V50',
          topic: 'ధనం — 2వ/11వ అష్టకవర్గ support',
          rule: 'Wealth/gains ప్రశ్నలకు 2వ మరియు 11వ భావ bindusను supporting evidenceగా పోల్చాలి; standalone verdictగా ఉపయోగించకూడదు.',
          source: 'Ashtakavarga practical source — Wealth 2nd/11th support',
        );
        break;
      case 3:
        sourceOnly(
          id: 'SK-012-V50',
          topic: 'సహోదరులు / Sibling event',
          rule: '3వ/11వ భావాలు మరియు అవసరమైన derivative-house logicను source ప్రకారం పరిశీలించాలి; ఒకే భావానికి పరిమితం చేయకూడదు.',
          source: 'S.K. Mehta — New Dimensions / Synchronization',
        );
        sourceOnly(
          id: 'AV-017-V50',
          topic: '3వ భావ అష్టకవర్గ support',
          rule: 'Sibling/effort అంశాలకు 3వ భావ SAV/BAV బలం supporting evidenceగా ఉపయోగించాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
      case 4:
        sourceOnly(
          id: 'SK-009-V50',
          topic: 'స్థిరాస్తి / Property-home-vehicle',
          rule: '4వ భావం/అధిపతి conditions, strength, aspects మరియు exchangesను property/home/vehicle evidenceగా ఉపయోగించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        sourceOnly(
          id: 'AV-016-V50',
          topic: '4వ భావ అష్టకవర్గ support',
          rule: 'Property/home/vehicle/mother-related ప్రశ్నలకు 4వ భావ SAV/BAV బలం supporting layerగా ఉపయోగించాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
      case 7:
        sourceOnly(
          id: 'SK-011-V50',
          topic: 'సంతానం promise',
          rule: '5వ భావం/అధిపతి, సంబంధిత గ్రహాలు, strength, affliction/support మరియు source-specific combinationsను పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 9:
        sourceOnly(
          id: 'SK-010-V50',
          topic: 'వివాహ promise',
          rule: '7వ భావం/అధిపతి, relationship planets, strength, aspect, association, exchange మరియు source-specific exceptionsను పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 10:
        sourceOnly(
          id: 'SK-006-V50',
          topic: 'వృత్తి promise',
          rule: 'Profession-related houses/lords, relevant planets, relationships, strength మరియు source combinationsను timingకు ముందు పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 16:
        sourceOnly(
          id: 'SK-009-X-V50',
          topic: 'వాహనం / సౌకర్యం cross-reference',
          rule: 'Property/home/vehicle ruleలో 4వ భావం/అధిపతి, strength, aspects, exchanges ప్రధాన evidence. D16ను vehicle/comfort cross-checkగా మాత్రమే చూడాలి; source rule D16ని ప్రత్యేకంగా నిర్దేశించకపోతే కొత్త rule సృష్టించరాదు.',
          source: 'S.K. Mehta — Property/home/vehicle rule',
        );
        break;
      case 24:
        sourceOnly(
          id: 'SK-005-V50',
          topic: 'విద్య promise',
          rule: 'Education-related houses/lords, relevant planets, strength, combinations మరియు exceptions పరిశీలించిన తర్వాతే timing చేయాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        sourceOnly(
          id: 'AV-014-V50',
          topic: 'Higher education — 5వ/9వ support',
          rule: 'Higher-education సూచనలకు 5వ మరియు 9వ భావ bindusను supporting evidenceగా పోల్చాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
    }
  }

  static void _beneficMaleficHouseRule({
    required VargaChartData v,
    required int house,
    required String favorableId,
    required String cautionId,
    required String topic,
    required String favorableResult,
    required String cautionResult,
    required String rule,
    required String source,
    required void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  }) {
    final names = _houseNames(v, house);
    final ben = names.where(_benefics.contains).toList();
    final mal = names.where(_malefics.contains).toList();
    add(
      id: favorableId,
      topic: topic,
      result: ben.isNotEmpty ? favorableResult : '$topic శుభగ్రహ condition auto-match కాలేదు.',
      rule: rule,
      inspection: 'D${v.definition.factor} $houseవ భావంలో ${names.isEmpty ? 'గ్రహాలు లేవు' : names.join(', ')}. శుభగ్రహాలు: ${ben.isEmpty ? 'లేవు' : ben.join(', ')}.',
      source: source,
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: cautionId,
      topic: topic,
      result: mal.isNotEmpty ? cautionResult : '$topic పాపగ్రహ condition auto-match కాలేదు.',
      rule: rule,
      inspection: 'D${v.definition.factor} $houseవ భావంలో పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: source,
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static int _houseSign(VargaChartData v, int house) =>
      (v.ascendantSignIndex + house - 1) % 12;

  static int _houseOf(VargaChartData v, VargaPlacement p) =>
      ((p.signIndex - v.ascendantSignIndex + 12) % 12) + 1;

  static List<String> _houseNames(VargaChartData v, int house) {
    final sign = _houseSign(v, house);
    return v.planets.where((p) => p.signIndex == sign).map((p) => p.name).toList(growable: false);
  }

  static String _signLord(int sign) => switch (sign % 12) {
        0 || 7 => 'Mars',
        1 || 6 => 'Venus',
        2 || 5 => 'Mercury',
        3 => 'Moon',
        4 => 'Sun',
        8 || 11 => 'Jupiter',
        9 || 10 => 'Saturn',
        _ => 'Sun',
      };

  static bool _isExalted(String planet, int sign) {
    const exalt = {
      'Sun': 0,
      'Moon': 1,
      'Mars': 9,
      'Mercury': 5,
      'Jupiter': 3,
      'Venus': 11,
      'Saturn': 6,
    };
    return exalt[planet] == sign;
  }

  static String _remedyText(VargaRuleTone tone) => switch (tone) {
        VargaRuleTone.favorable =>
          'ఈ sourceలో ప్రత్యేక పరిహారం అవసరం అని చెప్పలేదు. అనుకూల బలాన్ని timing/ప్రాక్టికల్ చర్యలతో ఉపయోగించండి.',
        VargaRuleTone.caution =>
          'ఈ varga sourceలో ప్రత్యేక remedy prescription లేదు. ముందుగా practical correction చేయాలి. రత్నం/గ్రహ పరిహారం ఇవ్వాలంటే supplied Gemstone Remedy rule-engine eligibilityని విడిగా పరీక్షించాలి; automatic gemstone ఇవ్వవద్దు.',
        VargaRuleTone.neutral =>
          'ఇది పరిశీలన layer. Sourceలో ప్రత్యేక పరిహారం ఇవ్వలేదు; ఇతర chart evidenceతో కలిపి నిర్ణయించాలి.',
        VargaRuleTone.info =>
          'ఈ rule source-only. Exact condition పూర్తిగా validate అయ్యే వరకు పరిహారం auto-generate చేయరాదు.',
      };
}
