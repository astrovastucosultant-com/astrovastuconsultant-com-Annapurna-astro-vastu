import 'astro_models.dart';
import 'ashtakavarga_service.dart';
import 'd2_dhana_asthi_registry.dart';
import 'd2_wealth_evaluation_service.dart';
import 'd10_career_service.dart';
import 'd10_final_profession_engine.dart';
import 'd10_profession_registry.dart';
import 'dasha_service.dart';
import 'd24_education_registry.dart';
import 'varga_service.dart';
import 'vedic_calculation_service.dart';
import 'marriage_material_registry.dart';
import 'remedy_rule_service.dart';

enum VargaRuleTone { favorable, caution, neutral, info }

class VargaRuleHit {
  final int factor;
  final String ruleId;
  final String topic;
  final String result;
  final String rule;
  final String inspection;
  final String remedy;
  final String source;
  final VargaRuleTone tone;
  final bool applicable;
  final bool autoEvaluated;

  const VargaRuleHit({
    required this.factor,
    required this.ruleId,
    required this.topic,
    required this.result,
    required this.rule,
    required this.inspection,
    required this.remedy,
    required this.source,
    required this.tone,
    required this.applicable,
    required this.autoEvaluated,
  });
}

/// Source-linked varga rule layer.
///
/// Boundary: only conditions that can be reproduced from the current D1/varga
/// placements are auto-fired. Rules requiring a source-specific strength,
/// aspect, special karaka, or unimplemented arithmetic stay in the source
/// catalog instead of being guessed.
class VargaRuleService {
  static const _benefics = {'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};

  static const _d10SignNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  // Source-backed profession significations carried forward from the supplied
  // D10 profession rulebook implementation (D10.pdf pp.42–47).
  static const _d10ProfessionCatalog = <(String, List<String>, List<int>)>[
    ('Government / Administration', ['Sun', 'Mercury'], [10]),
    ('Management / High Position', ['Sun', 'Jupiter', 'Saturn'], [10]),
    ('Banking / Finance', ['Jupiter', 'Mercury', 'Sun'], [2, 10, 11]),
    ('Accounting', ['Mercury'], [2, 11]),
    ('Teaching / Education', ['Jupiter', 'Mercury', 'Venus'], [5, 9]),
    ('Law / Judiciary', ['Jupiter', 'Mercury', 'Saturn'], [9, 10]),
    ('Engineering / Technical', ['Mars', 'Saturn', 'Rahu'], [3, 10]),
    ('Architecture', ['Mercury', 'Mars', 'Venus'], [3, 4, 10]),
    ('Medicine / Surgery', ['Sun', 'Mars', 'Jupiter'], [6, 10]),
    ('Nursing / Care', ['Moon', 'Jupiter'], [6, 12]),
    ('Journalism / Writing', ['Mercury', 'Moon'], [3, 5]),
    ('Communication / Languages', ['Mercury', 'Moon', 'Ketu'], [3, 7]),
    ('Travel / Tourism', ['Moon', 'Mercury'], [3, 9, 12]),
    ('Hospitality / Restaurants', ['Moon', 'Venus'], [4, 12]),
    ('Textiles / Clothing', ['Moon', 'Venus', 'Saturn'], [2, 4]),
    ('Music / Arts', ['Moon', 'Venus'], [5, 11]),
    ('Cinema / Acting / Dance', ['Venus', 'Moon'], [5, 11]),
    ('Fashion / Beauty / Design', ['Venus', 'Mercury'], [5, 7]),
    ('Interior Decoration', ['Venus', 'Mercury'], [4, 5]),
    ('Precious Stones / Jewellery', ['Sun', 'Venus', 'Jupiter'], [2, 10]),
    ('Metallurgy / Hardware', ['Mars', 'Saturn'], [3, 10]),
    ('Mining / Minerals', ['Saturn', 'Jupiter'], [8, 10]),
    ('Agriculture / Farming', ['Saturn', 'Moon'], [4, 11]),
    ('Food / Dairy', ['Moon', 'Venus'], [2, 4, 11]),
    ('Manufacturing / Industry', ['Saturn', 'Mars', 'Rahu'], [6, 10, 11]),
    ('Aviation / Piloting', ['Rahu', 'Mars', 'Mercury'], [3, 9, 12]),
    ('Import / Export', ['Moon', 'Rahu', 'Ketu'], [7, 12]),
    ('Diplomacy / Foreign Relations', ['Rahu', 'Sun', 'Mercury'], [7, 9, 12]),
    ('Research / Specialized Studies', ['Ketu', 'Saturn', 'Jupiter'], [8, 9]),
    ('Astrology / Traditional Studies', ['Jupiter', 'Ketu'], [8, 9]),
    ('Astrologer / Jyotisha Practitioner', ['Jupiter', 'Ketu'], [8, 9]),
    ('Astrology Consultant / Jyotisha Consultant', ['Jupiter', 'Ketu', 'Mercury'], [8, 9, 10]),
    ('Consultant / Advisor', ['Jupiter', 'Mercury'], [7, 9, 10]),
    ('Priest / Spiritual Consultant', ['Jupiter', 'Ketu'], [9, 10]),
    ('Books / Publishing', ['Mercury', 'Jupiter', 'Ketu'], [3, 5, 9]),
    ('Surveying / Field Technical Work', ['Mars', 'Saturn'], [3, 4, 10]),
    ('Defence / Security', ['Mars', 'Sun', 'Rahu'], [6, 10]),
    ('Maintenance / Refrigeration', ['Saturn', 'Mars'], [6, 10, 12]),
    ('Plumber / Electrician / Skilled Trades', ['Saturn', 'Mars'], [6, 10]),
    ('Skilled Service / Manual Work', ['Saturn', 'Mars', 'Moon'], [6, 10]),
    ('Daily-wage / Manual Worker', ['Saturn', 'Mars', 'Moon'], [6, 10]),
    ('Farm / Agricultural Worker', ['Saturn', 'Moon'], [4, 6, 11]),
    ('Commercial / Business', ['Mercury', 'Venus', 'Rahu'], [3, 7, 11]),
    ('Self-employment', ['Sun', 'Mars', 'Rahu', 'Moon'], [1, 3, 10, 11]),
    ('Service / Employment', ['Saturn', 'Moon', 'Mercury'], [6, 10, 11]),
  ];

  static List<VargaRuleHit> allFor({
    required AstroChartResult chart,
    required int factor,
    DateTime? birthDateTime,
  }) {
    final varga = VargaService.calculate(chart, factor);
    final out = <VargaRuleHit>[];

    void add({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto = true,
      String? remedy,
    }) {
      out.add(
        VargaRuleHit(
          factor: factor,
          ruleId: id,
          topic: topic,
          result: result,
          rule: rule,
          inspection: inspection,
          remedy: (() {
            // Rinanubandha is a source-audit / cross-varga inspection only.
            // No remidi.pdf remedy has been exactly matched to these rows.
            if (factor == 7 && (id.startsWith('D7-RUNA-') ||
                id.startsWith('D7-KAKA-') || id.startsWith('D7-ADOPT-') ||
                id.startsWith('D7-TWINS-') || id.startsWith('D7-LUX-') ||
                id.startsWith('D7-FORM-'))) {
              return 'ఈ గ్రంథ నియమానికి నిర్దిష్ట పరిహారం ఇంకా ధృవీకరించలేదు. '
                  'remidi.pdfలో ఖచ్చితమైన రూల్–పరిహారం ఆధారం దొరికే వరకు పరిహారం నిర్ణయించము.';
            }
            // Never prescribe a D2 remedy just because a source-only rule
            // appears in the catalog; it must match the current horoscope.
            if (factor == 2 && !applicable) {
              return 'ఈ రూల్ జాతకానికి auto-match కాలేదు లేదా గణన పెండింగ్. '
                  'పరిహారం నిర్ణయించలేదు. Source: remidi.pdf; '
                  'ముందుగా రూల్ షరతులు మరియు బాధిత గ్రహం ధృవీకరించాలి.';
            }
            final sourceRemedy = RemedyRuleService.forContext(
              factor: factor,
              topic: topic,
              result: result,
              rule: rule,
              tone: tone.name,
            );
            if (remedy == null || remedy.trim().isEmpty) return sourceRemedy;
            return '$remedy\n\nSource-backed Remedy Support (remidi.pdf):\n$sourceRemedy';
          })(),
          source: source,
          tone: tone,
          applicable: applicable,
          autoEvaluated: auto,
        ),
      );
    }

    switch (factor) {
      case 1:
        _d1Gems(chart, add);
        break;
      case 2:
        // Build90: actual horoscope result mode first. Only reproducible source
        // conditions are auto-evaluated; every source rule is still preserved
        // below as audit/source catalog.
        for (final h in D2WealthEvaluationService.evaluate(chart)) {
          final r = D2DhanaAsthiRegistry.rules.firstWhere((x) => x.id == h.ruleId);
          add(
            id: r.id,
            topic: '${r.group} • ${r.name} — ${h.percent}%',
            result: '${r.result}  •  Evidence Match ${h.percent}%',
            rule: r.condition,
            inspection: 'Evidence Match: ${h.percent}% (probability కాదు)\n${h.evidence}\nSource chart: ${r.sourceChart}${r.note.isEmpty ? '' : '\nNote: ${r.note}'}',
            source: '${D2DhanaAsthiRegistry.sourceFilename} • page ${r.sourcePage}',
            tone: h.caution ? VargaRuleTone.caution : VargaRuleTone.favorable,
            applicable: true,
            auto: true,
          );
        }
        final matchedIds = out.where((x) => x.factor == 2 && x.applicable).map((x) => x.ruleId).toSet();
        for (final r in D2DhanaAsthiRegistry.rules) {
          if (matchedIds.contains(r.id)) continue;
          add(
            id: r.id,
            topic: '${r.group} • ${r.name}',
            result: D2WealthEvaluationService.pendingReason.containsKey(r.id) ? 'ఇంకా పూర్తి ఆటో పరిశీలన జరగలేదు • మూల ఫలితం: ${r.result}' : 'ఈ జాతకంలో రూల్ షరతులు సరిపోలలేదు • మూల ఫలితం: ${r.result}',
            rule: r.condition,
            inspection: '${D2WealthEvaluationService.auditReason(r.id, matched: false)}\nSource chart: ${r.sourceChart}${r.note.isEmpty ? '' : '\nNote: ${r.note}'}',
            source: '${D2DhanaAsthiRegistry.sourceFilename} • page ${r.sourcePage}',
            tone: VargaRuleTone.info,
            applicable: false,
            auto: false,
          );
        }
        break;
      case 3:
        _d3(varga, add);
        break;
      case 4:
        _d4FullPropertyEngine(chart, varga, birthDateTime, add);
        _d4(varga, add);
        break;
      case 7:
        _d7(chart, varga, birthDateTime, add);
        break;
      case 9:
        _d9(varga, add);
        break;
      case 10:
        _d10(chart, varga, birthDateTime, add);
        break;
      case 12:
        _d12(chart, varga, add);
        break;
      case 16:
        _d16(chart, varga, birthDateTime, add);
        break;
      case 20:
        _d20(chart, varga, add);
        break;
      case 24:
        _d24(chart, varga, add);
        break;
      case 27:
        _d27(varga, add);
        break;
      case 30:
        _d30(varga, add);
        break;
      case 40:
        _d40(varga, add);
        break;
      case 45:
        _d45(varga, add);
        break;
      case 60:
        _d60(varga, add);
        break;
    }

    // User-supplied marriage rulebook registry: every distinct rule is indexed
    // under its related chart layer. These entries are source-linked and remain
    // non-auto until the exact handwritten condition is machine-validated.
    _appendMarriageMaterialRegistry(factor, add);

    // V50 source registry: topic-wise source entries are attached under the
    // relevant varga without inventing an automatic verdict.
    _appendV50SourceRegistry(factor, add);

    return out;
  }

  static List<VargaRuleHit> applicableFor({
    required AstroChartResult chart,
    required int factor,
    DateTime? birthDateTime,
  }) => allFor(chart: chart, factor: factor, birthDateTime: birthDateTime)
      .where((x) => x.autoEvaluated && x.applicable)
      .toList(growable: false);

  static void _d1Gems(
    AstroChartResult chart,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final lagna = chart.ascendantSignIndex;
    final exaltedInLagna = chart.planets.where((p) => p.signIndex == lagna && _isExalted(p.name, p.signIndex)).toList();
    add(
      id: 'G-05',
      topic: 'లగ్నంలో ఉచ్చరాశి గ్రహం',
      result: exaltedInLagna.isEmpty
          ? 'ఈ జాతకంలో G-05 condition auto-match కాలేదు.'
          : 'లగ్న బలానికి అనుకూల source సూచన కనిపిస్తోంది.',
      rule: 'లగ్నంలో ఉచ్చ స్థితిలో గ్రహం ఉండి, సంబంధిత support ఉంటే లగ్నానికి బలం మరియు మంచి ఫలితాల సూచనగా చూడాలి.',
      inspection: exaltedInLagna.isEmpty
          ? 'లగ్నంలో ఉచ్చస్థితి గ్రహం లేదు.'
          : 'లగ్నంలో ఉచ్చస్థితి: ${exaltedInLagna.map((p) => p.name).join(', ')}.',
      source: '108 Gems of Predictive Astrology — G-05, supplied rule-based PDF p.2',
      tone: VargaRuleTone.favorable,
      applicable: exaltedInLagna.isNotEmpty,
    );

    for (final item in const [
      ('G-01', 'జన్మదినం', 'జన్మ వారాధిపతి 6/8 అధిపత్యం మరియు ఉచ్చ/నీచ స్థితిని కలిపి పరిశీలించే rule.'),
      ('G-06', 'లగ్నాధిపతి — 1', 'లగ్నాధిపతి స్థానం/బలం/దృష్టి layersను కలిపి నిర్ణయించే rule.'),
      ('G-07', 'లగ్నాధిపతి — 2', 'లగ్నాధిపతికి శుభ/పాప సంబంధాన్ని పరిశీలించే rule.'),
      ('G-08', 'లగ్నాధిపతి × చంద్రరాశ్యాధిపతి', 'లగ్నాధిపతి మరియు చంద్రరాశ్యాధిపతి కేంద్ర/సంబంధాన్ని పరిశీలించే rule.'),
      ('G-09', 'లగ్నాధిపతి × చంద్రరాశ్యాధిపతి ఉపచయం', 'ఇద్దరి ఉపచయ/కేంద్ర సంబంధాన్ని పరిశీలించే rule.'),
      ('G-10', 'నవమాధిపతి × లగ్నాధిపతి', '9వ అధిపతి–లగ్నాధిపతి సంబంధం ద్వారా భాగ్యం/శ్రేయస్సు layer.'),
    ]) {
      add(
        id: item.$1,
        topic: item.$2,
        result: 'Source rule catalogలో ఉంది; exact evaluator ఈ buildలో guess చేయకుండా source-onlyగా ఉంచాం.',
        rule: item.$3,
        inspection: 'ఈ ruleకు అవసరమైన పూర్తి source arithmetic/relationship layerను విడిగా validate చేసిన తర్వాత మాత్రమే auto-result ఇవ్వాలి.',
        source: '108 Gems of Predictive Astrology — supplied rule-based PDF pp.2–3',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
      );
    }
  }

  static void _d3(
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final lagnaNames = _houseNames(v, 1);
    final ben = lagnaNames.where(_benefics.contains).toList();
    final mal = lagnaNames.where(_malefics.contains).toList();
    final lagnaLord = _signLord(_houseSign(v, 1));
    final lagnaLordHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == lagnaLord));
    final marsHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == 'Mars'));
    final h3 = _houseNames(v, 3);
    final d3Checks = <bool>[
      ben.isNotEmpty,
      {1, 3, 5, 7, 9, 10, 11}.contains(lagnaLordHouse),
      {1, 3, 5, 6, 10, 11}.contains(marsHouse),
      h3.any(_benefics.contains),
    ];
    final d3Matched = d3Checks.where((x) => x).length;
    final d3Pct = (100 * d3Matched / d3Checks.length).round();
    add(
      id: 'D3-SUMMARY-EVIDENCE',
      topic: 'D3 స్వప్రయత్నం / ధైర్యం — Evidence $d3Pct%',
      result: 'D3 Lagna + Lagna lord + Mars + 3H evidenceలో $d3Matched/${d3Checks.length} support blocks match అయ్యాయి.',
      rule: 'D3లో లగ్నం, లగ్నాధిపతి, 3వ భావం మరియు కుజ బలాన్ని కలిపి స్వప్రయత్నం/ధైర్యం layerగా చూడాలి.',
      inspection: 'Lagna=${lagnaNames.isEmpty ? 'empty' : lagnaNames.join(', ')}; Lagna lord=$lagnaLord H$lagnaLordHouse; Mars=H$marsHouse; D3 3H=${h3.isEmpty ? 'empty' : h3.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2. % is app evidence coverage, not probability.',
      tone: d3Pct >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );
    add(
      id: 'S7-D3-01',
      topic: 'స్వప్రయత్నం / ధైర్యం',
      result: ben.isNotEmpty ? 'D3 లగ్నంలో శుభగ్రహ support ఉంది; స్వప్రయత్నానికి అనుకూల layer.' : 'D3 లగ్న శుభగ్రహ support auto-match కాలేదు.',
      rule: 'D3లో లగ్నం/లగ్నాధిపతి బలం స్వప్రయత్నం, ధైర్యం, కర్మఫలానికి ప్రధానంగా చూడాలి.',
      inspection: 'D3 లగ్నంలో: ${lagnaNames.isEmpty ? 'గ్రహం లేదు' : lagnaNames.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'S7-D3-02',
      topic: 'స్వప్రయత్నం / జాగ్రత్త',
      result: mal.isNotEmpty ? 'D3 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; ప్రయత్నంలో ఒత్తిడి/కఠినత layerగా చూడాలి.' : 'D3 లగ్న పాపగ్రహ condition auto-match కాలేదు.',
      rule: 'D3 lagna/lagna-lord affliction ఉంటే ప్రయత్నంలో ఆటంకం లేదా కఠిన ఫలితంగా source చూడమంటుంది.',
      inspection: 'D3 లగ్నంలో పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2',
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static void _d4FullPropertyEngine(
    AstroChartResult chart,
    VargaChartData v,
    DateTime? birthDateTime,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    // Build95: expose the complete source-backed property/inheritance layer on
    // the D4 screen instead of collapsing it into one generic percentage.
    // The actual rule conditions are evaluated by the audited D2 property
    // evaluator because those source rules explicitly combine D1 + D4.
    final matches = D2WealthEvaluationService.evaluate(chart);
    final matchById = <String, D2WealthMatch>{for (final m in matches) m.ruleId: m};
    final propertyRules = D2DhanaAsthiRegistry.rules.where((r) =>
      r.groupCode == 'PR' || r.groupCode == 'IH' || r.id == 'D2-OT-004').toList(growable: false);

    for (final r in propertyRules) {
      // PR-011 receives a dedicated Dasha window calculation below.
      if (r.id == 'D2-PR-011') continue;
      final m = matchById[r.id];
      if (m != null) {
        add(
          id: 'D4-${r.id}',
          topic: '${r.name} — Evidence ${m.percent}%',
          result: '${r.result}  •  Evidence ${m.percent}% (probability కాదు)\nMatched evidence: ${m.evidence.replaceAll('\n', ' • ')}',
          rule: r.condition,
          inspection: '${m.evidence}\nSource chart: ${r.sourceChart}${r.note.isEmpty ? '' : '\nNote: ${r.note}'}',
          source: '${D2DhanaAsthiRegistry.sourceFilename} • page ${r.sourcePage}',
          tone: m.caution ? VargaRuleTone.caution : VargaRuleTone.favorable,
          applicable: true,
        );
      } else {
        add(
          id: 'D4-${r.id}',
          topic: r.name,
          result: 'ఈ జాతకంలో ఈ source rule condition auto-match కాలేదు. రూల్ Auditలో భద్రంగా ఉంది.',
          rule: r.condition,
          inspection: D2WealthEvaluationService.auditReason(r.id, matched: false),
          source: '${D2DhanaAsthiRegistry.sourceFilename} • page ${r.sourcePage}',
          tone: VargaRuleTone.info,
          applicable: false,
          auto: false,
        );
      }
    }

    // Source D2-PR-011: property purchase opportunity in the periods of the
    // 4th, 9th or 11th lords, with D4 confirmation. We surface source-safe
    // candidate windows, not a guaranteed purchase date.
    final d4FourthSign = _houseSign(v, 4);
    final d4FourthLord = _signLord(d4FourthSign);
    final d4FourthLordPlacement = v.planets.firstWhere((p) => p.name == d4FourthLord);
    final d4FourthLordHouse = _houseOf(v, d4FourthLordPlacement);
    final d4Confirmed = const {1, 4, 5, 7, 9, 10}.contains(d4FourthLordHouse);

    var purchaseTimingApplied = false;
    if (birthDateTime != null) {
      final l4 = _signLord((chart.ascendantSignIndex + 3) % 12);
      final l9 = _signLord((chart.ascendantSignIndex + 8) % 12);
      final l11 = _signLord((chart.ascendantSignIndex + 10) % 12);
      final targetLords = <String>{l4, l9, l11};
      final vim = DashaService.system(
        kind: DashaSystemKind.vimshottari,
        chart: chart,
        birthDateTime: birthDateTime,
      );
      final windows = <({DashaPeriod md, DashaPeriod ad, int score})>[];
      for (final md in vim.mahadashas) {
        for (final ad in DashaService.subPeriodsFor(vim, md)) {
          var score = 0;
          if (targetLords.contains(md.lord)) score += 2;
          if (targetLords.contains(ad.lord)) score += 1;
          if (d4Confirmed) score += 1;
          if (score >= 2) windows.add((md: md, ad: ad, score: score));
        }
      }
      windows.sort((a, b) {
        final sc = b.score.compareTo(a.score);
        return sc != 0 ? sc : a.ad.start.compareTo(b.ad.start);
      });
      // Build96: timing hierarchy. Past periods are audit-only; current and
      // future windows are client-facing, strongest evidence first. This avoids
      // leading the user with old dates such as 2012–2019 when future windows
      // are available.
      final now = DateTime.now();
      final current = windows.where((w) => !w.ad.start.isAfter(now) && w.ad.end.isAfter(now)).toList(growable: false)
        ..sort((a, b) => b.score.compareTo(a.score));
      final future = windows.where((w) => w.ad.start.isAfter(now)).toList(growable: false)
        ..sort((a, b) {
          final sc = b.score.compareTo(a.score);
          return sc != 0 ? sc : a.ad.start.compareTo(b.ad.start);
        });
      final past = windows.where((w) => !w.ad.end.isAfter(now)).toList(growable: false)
        ..sort((a, b) => b.ad.end.compareTo(a.ad.end));

      int ageAt(DateTime d) {
        var age = d.year - birthDateTime.year;
        if (d.month < birthDateTime.month || (d.month == birthDateTime.month && d.day < birthDateTime.day)) age--;
        return age < 0 ? 0 : age;
      }
      String windowLine(({DashaPeriod md, DashaPeriod ad, int score}) w) {
        final startAge = ageAt(w.ad.start);
        final endAge = ageAt(w.ad.end);
        return '${w.md.lord}/${w.ad.lord}: ${w.ad.start.year}–${w.ad.end.year} (age $startAge–$endAge)';
      }

      final clientSelected = <({DashaPeriod md, DashaPeriod ad, int score})>[
        ...current.take(2),
        ...future.take(6),
      ];
      if (clientSelected.isNotEmpty) {
        purchaseTimingApplied = true;
        final maxScore = clientSelected.map((w) => w.score).reduce((a, b) => a > b ? a : b);
        final pct = ((maxScore / 4) * 100).round().clamp(25, 100);
        final currentText = current.isEmpty ? '' : 'ప్రస్తుతం: ${current.take(2).map(windowLine).join(' • ')}';
        final futureText = future.isEmpty ? '' : 'భవిష్యత్తు strongest windows: ${future.take(6).map(windowLine).join(' • ')}';
        final lines = [currentText, futureText].where((x) => x.isNotEmpty).join('\n');
        add(
          id: 'D4-D2-PR-011',
          topic: 'ఆస్తి కొనుగోలు — Current / Future Candidate Years — Evidence $pct%',
          result: lines,
          rule: '4వ, 9వ లేదా 11వ అధిపతుల దశ/అంతర్దశలను D4 స్థిరాస్తి ధృవీకరణతో కలిపి candidate purchase windowsగా పరిశీలించాలి.',
          inspection: 'D1 4L=$l4 • 9L=$l9 • 11L=$l11 • D4 4L=$d4FourthLord H$d4FourthLordHouse • D4 confirmation=${d4Confirmed ? '✓' : '—'}. Current/future periods మాత్రమే main resultలో చూపుతున్నాం. ఇవి candidate windows మాత్రమే; కొనుగోలు హామీ కాదు.',
          source: '${D2DhanaAsthiRegistry.sourceFilename} • page 4 • D2-PR-011',
          tone: d4Confirmed ? VargaRuleTone.favorable : VargaRuleTone.neutral,
          applicable: true,
        );
      }
      if (past.isNotEmpty) {
        add(
          id: 'D4-D2-PR-011-PAST-AUDIT',
          topic: 'Audit మాత్రమే — గత ఆస్తి కొనుగోలు candidate periods',
          result: past.take(8).map(windowLine).join(' • '),
          rule: 'గత దశ/అంతర్దశలను audit/reference కోసం మాత్రమే భద్రపరచాలి; main client resultలో future timingతో కలపకూడదు.',
          inspection: 'Past timing windows: ${past.take(8).map(windowLine).join(' • ')}',
          source: '${D2DhanaAsthiRegistry.sourceFilename} • page 4 • D2-PR-011',
          tone: VargaRuleTone.info,
          applicable: false,
          auto: false,
        );
      }
    }

    // A compact D4-specific summary helps the client see the separate result
    // families without merging positive and caution rules into one verdict.
    final matchedProperty = propertyRules.where((r) => matchById.containsKey(r.id)).length + (purchaseTimingApplied ? 1 : 0);
    final positive = propertyRules.where((r) => matchById[r.id] != null && !matchById[r.id]!.caution).length;
    final caution = propertyRules.where((r) => matchById[r.id]?.caution == true).length;
    final pct = propertyRules.isEmpty ? 0 : (100 * matchedProperty / propertyRules.length).round();
    // Coverage is an audit metric, not a horoscope result. Keep it out of
    // the client-facing matched cards and expose it only under Source Rules / Audit.
    add(
      id: 'D4-FULL-SUMMARY',
      topic: 'Audit మాత్రమే — D4 పూర్తి స్థిరాస్తి Rule Coverage — $pct%',
      result: '$matchedProperty/${propertyRules.length} source property/inheritance conditions match అయ్యాయి • అనుకూలం $positive • జాగ్రత్త $caution.',
      rule: 'స్థిరాస్తి ఫలితాలను ఒకే cardలో విలీనం చేయకుండా, ఇల్లు/భూమి/ఆలస్యం/తగాదా/వారసత్వం/తల్లి-తండ్రి వైపు ఆస్తి/విదేశ ఇల్లు/timingను విడిగా పరిశీలించాలి.',
      inspection: 'Applied source IDs: ${propertyRules.where((r) => matchById.containsKey(r.id)).map((r) => r.id).join(', ')}${purchaseTimingApplied ? ', D2-PR-011' : ''}',
      source: '${D2DhanaAsthiRegistry.sourceFilename} • Property + Inheritance rules pp.4–6',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );
  }

  static void _d4(
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final fourthSign = _houseSign(v, 4);
    final lord = _signLord(fourthSign);
    final lordPlacement = v.planets.firstWhere((p) => p.name == lord);
    final lordHouse = _houseOf(v, lordPlacement);
    const results = <int, String>{
      1: 'విద్య, ఆభరణాలు, భూమి, వాహన అంశాలకు అనుకూలత; సాధారణంగా సంతోషం.',
      2: 'ధనం, సుఖం.',
      3: 'ధైర్యం; పాప ప్రభావం ఉంటే అనుభవం కఠినంగా మారవచ్చు.',
      4: 'సంపద, విద్య, గౌరవం.',
      5: 'రాజయోగ/మంచి సంతానం layer; బలహీనత ఉంటే సంతాన అంశం పరిశీలించాలి.',
      6: 'భౌతిక సుఖంలో ఒత్తిడి; పాప ప్రభావం ఉంటే ఆరోగ్య/తల్లి అంశం జాగ్రత్త.',
      7: 'విద్య, వాహనం; ఇతర సంబంధాలను కూడా చూడాలి.',
      8: 'గృహ సుఖం తగ్గే లేదా మార్పులు వచ్చే సూచన; వృత్తి/ధన సంబంధం కూడా చూడాలి.',
      9: 'రాజయోగ/ఉన్నత విద్య layer.',
      10: 'రాజ గౌరవం / స్థాయి.',
      11: 'దాతృత్వం; పాప ప్రభావం ఉంటే చెడు ఉపదేశం/మిశ్రమ ఫలితం.',
      12: 'సుఖ లోపం/నష్టం వంటి జాగ్రత్త సూచన.',
    };
    final tone = {1, 2, 4, 5, 7, 9, 10, 11}.contains(lordHouse)
        ? VargaRuleTone.favorable
        : {6, 8, 12}.contains(lordHouse)
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    final d4h4 = _houseNames(v, 4);
    final venusHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == 'Venus'));
    final marsHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == 'Mars'));
    final d4Checks = <bool>[
      {1, 2, 4, 5, 7, 9, 10, 11}.contains(lordHouse),
      d4h4.any(_benefics.contains),
      {1, 4, 5, 7, 9, 10, 11}.contains(venusHouse),
      {1, 3, 4, 6, 10, 11}.contains(marsHouse),
    ];
    final d4Matched = d4Checks.where((x) => x).length;
    final d4Pct = (100 * d4Matched / d4Checks.length).round();
    add(
      id: 'D4-PROPERTY-EVIDENCE',
      topic: 'స్థిరాస్తి / ఇల్లు / భూమి — Evidence $d4Pct%',
      result: 'D4 4L + 4H + Venus comfort + Mars land supportలో $d4Matched/${d4Checks.length} blocks match అయ్యాయి.',
      rule: 'స్థిరాస్తి నిర్ణయంలో D4 4వ భావం/4వ అధిపతి ప్రధానంగా, శుక్రుడు సౌఖ్యానికి మరియు కుజుడు భూమి/నిర్మాణానికి supporting karaka layersగా చూడాలి.',
      inspection: 'D4 4L=$lord H$lordHouse; 4H=${d4h4.isEmpty ? 'empty' : d4h4.join(', ')}; Venus=H$venusHouse; Mars=H$marsHouse.',
      source: 'Saral3_nundi_Ippativaraku.pdf — D4 property rules pp.1–2. % is app evidence coverage, not probability.',
      tone: d4Pct >= 60 ? VargaRuleTone.favorable : (d4Pct <= 25 ? VargaRuleTone.caution : VargaRuleTone.neutral),
      applicable: true,
    );
    add(
      id: 'S3-D4-L4H$lordHouse',
      topic: 'D4 4వ అధిపతి స్థానం',
      result: results[lordHouse]!,
      rule: 'D4లో 4వ భావ అధిపతి ఏ భావంలో ఉన్నాడో ఆధారంగా స్థిరాస్తి/సుఖ ఫలితాన్ని source tableలో చదవాలి.',
      inspection: 'D4 4వ భావ రాశి ${fourthSign + 1}; అధిపతి $lord; D4లో $lord ${lordHouse}వ భావంలో ఉంది.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 4th-lord result table pp.1–2',
      tone: tone,
      applicable: true,
    );

    final h4 = _houseNames(v, 4);
    final ben = h4.where(_benefics.contains).toList();
    final mal = h4.where(_malefics.contains).toList();
    add(
      id: 'S3-D4-H4-BEN',
      topic: 'స్థిరాస్తి / 4వ భావ support',
      result: ben.isNotEmpty ? 'D4 4వ భావంలో శుభగ్రహ support ఉంది; స్థిరాస్తి/సుఖానికి అనుకూల layer.' : 'D4 4వ భావ శుభగ్రహ condition auto-match కాలేదు.',
      rule: 'D4 4వ భావ బలం మరియు శుభ సంబంధాన్ని స్థిరాస్తి ఫలితానికి చూడాలి.',
      inspection: 'D4 4వ భావంలో ${h4.isEmpty ? 'గ్రహాలు లేవు' : h4.join(', ')}.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 property rules pp.1–2',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'S3-D4-H4-MAL',
      topic: 'స్థిరాస్తి / జాగ్రత్త',
      result: mal.isNotEmpty ? 'D4 4వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ఆస్తి/సుఖంలో ఒత్తిడి లేదా ఆలస్యం layerగా చూడాలి.' : 'D4 4వ భావ పాపగ్రహ condition auto-match కాలేదు.',
      rule: 'D4 4వ భావం పీడితమైతే స్థిరాస్తి/సుఖ అంశంలో జాగ్రత్తగా source ఫలితం చదవాలి.',
      inspection: 'D4 4వ భావ పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 property rules pp.1–2',
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static void _d7(
    AstroChartResult chart,
    VargaChartData v,
    DateTime? birthDateTime,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final natal5Sign = (chart.ascendantSignIndex + 4) % 12;
    final natal5Lord = _signLord(natal5Sign);
    final natal5LordPlanet = chart.planets.firstWhere((p) => p.name == natal5Lord);
    final natal5LordHouse = ((natal5LordPlanet.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final jupiter = chart.planets.firstWhere((p) => p.name == 'Jupiter');
    final jupiterHouse = ((jupiter.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;

    int d7House(String planet) {
      final rows = v.planets.where((p) => p.name == planet).toList(growable: false);
      return rows.isEmpty ? 0 : _houseOf(v, rows.first);
    }

    int d7Sign(String planet) {
      final rows = v.planets.where((p) => p.name == planet).toList(growable: false);
      return rows.isEmpty ? -1 : rows.first.signIndex;
    }

    bool sameHouse(String a, String b) => d7House(a) > 0 && d7House(a) == d7House(b);
    bool aspectsHouse(String planet, int targetHouse) => _vargaPlanetAspectsHouse(v, planet, targetHouse);
    bool relatedToHouse(String planet, int targetHouse) =>
        d7House(planet) == targetHouse || aspectsHouse(planet, targetHouse);

    final d7FifthSign = _houseSign(v, 5);
    final d7FifthLord = _signLord(d7FifthSign);
    final d7FifthLordHouse = d7House(d7FifthLord);
    final d7JupiterHouse = d7House('Jupiter');
    final d7MoonHouse = d7House('Moon');
    final d7VenusHouse = d7House('Venus');
    final d7h5 = _houseNames(v, 5);
    final ben = d7h5.where(_benefics.contains).toList();
    final mal = d7h5.where(_malefics.contains).toList();

    final d7FifthLordMaleficConj = _malefics.any((p) => p != d7FifthLord && sameHouse(p, d7FifthLord));
    final d7FifthAfflictedBySlow =
        ['Saturn', 'Rahu', 'Ketu'].where((p) => relatedToHouse(p, 5) || sameHouse(p, d7FifthLord)).toList();
    final d7FifthSupportedByJupiter = relatedToHouse('Jupiter', 5) || sameHouse('Jupiter', d7FifthLord);
    final d7FifthSupportedByVenus = relatedToHouse('Venus', 5) || sameHouse('Venus', d7FifthLord);
    final d7FifthSupportedByMoon = relatedToHouse('Moon', 5) || sameHouse('Moon', d7FifthLord);

    final promiseChecks = <bool>[
      {1, 4, 5, 7, 9, 10, 11}.contains(natal5LordHouse),
      {1, 2, 5, 9, 11}.contains(jupiterHouse),
      {1, 4, 5, 7, 9, 10, 11}.contains(d7FifthLordHouse),
      {1, 2, 5, 9, 11}.contains(d7JupiterHouse),
      ben.isNotEmpty || d7FifthSupportedByJupiter,
    ];
    final promiseMatched = promiseChecks.where((x) => x).length;
    final promisePercent = ((promiseMatched / promiseChecks.length) * 100).round();

    add(
      id: 'D7-SANTANA-001',
      topic: 'సంతాన యోగం — Evidence $promisePercent%',
      result: 'D1 5వ భావం/5వ అధిపతి + గురువు + D7 5వ భావం/5వ అధిపతి/గురు evidenceలో $promiseMatched/${promiseChecks.length} support blocks match అయ్యాయి.',
      rule: 'సంతాన ఫలితానికి D1 5వ భావం/5వ అధిపతి/గురు మరియు D7 5వ భావం/5వ అధిపతి/గురువును కలిపి చూడాలి. ఒక్క factorతో final verdict ఇవ్వకూడదు.',
      inspection: 'D1 5L=$natal5Lord H$natal5LordHouse; D1 Jupiter=H$jupiterHouse; D7 5H sign=${_signNameTe(d7FifthSign)}; D7 5L=$d7FifthLord H$d7FifthLordHouse; D7 Jupiter=H$d7JupiterHouse; D7 5H=${d7h5.isEmpty ? 'empty' : d7h5.join(', ')}.',
      source: 'Saptamsha_Santana_Niyamalu.pdf pp.1–3, 7–9, 15–18; app Evidence % = matched source blocks, probability కాదు.',
      tone: promisePercent >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    if (ben.isNotEmpty || d7FifthSupportedByJupiter || d7FifthSupportedByVenus || d7FifthSupportedByMoon) {
      final supports = <String>[
        if (ben.isNotEmpty) '5H benefics: ${ben.join(', ')}',
        if (d7FifthSupportedByJupiter) 'Jupiter support',
        if (d7FifthSupportedByVenus) 'Venus support',
        if (d7FifthSupportedByMoon) 'Moon support',
      ];
      add(
        id: 'D7-SANTANA-002',
        topic: '5వ భావం / 5వ అధిపతి శుభ support',
        result: 'సంతాన అంశానికి శుభ support కనిపిస్తోంది: ${supports.join(' • ')}.',
        rule: 'D7 5వ భావం, 5వ అధిపతి, గురు మరియు శుభగ్రహ సంబంధం/దృష్టి/కలయికను సంతాన supportగా చూడాలి.',
        inspection: supports.join(' • '),
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.1–3, 15–18.',
        tone: VargaRuleTone.favorable,
        applicable: true,
      );
    }

    if (mal.isNotEmpty || d7FifthLordMaleficConj || d7FifthAfflictedBySlow.isNotEmpty) {
      final aff = <String>[
        if (mal.isNotEmpty) '5H malefics: ${mal.join(', ')}',
        if (d7FifthLordMaleficConj) '5L malefic conjunction',
        if (d7FifthAfflictedBySlow.isNotEmpty) 'Saturn/Rahu/Ketu: ${d7FifthAfflictedBySlow.join(', ')}',
      ];
      add(
        id: 'D7-SANTANA-003',
        topic: 'సంతాన ఆలస్యం / అడ్డంకి సూచన',
        result: 'D7లో delay/obstacle source conditionsలో కొన్ని match అయ్యాయి: ${aff.join(' • ')}. ఇది denial అని ఒక్కటే చెప్పదు.',
        rule: '5వ భావం/5వ అధిపతి బహుళ పాప ప్రభావం, ముఖ్యంగా Saturn/Rahu/Ketu సంబంధం ఉంటే delay/obstacle layerగా చూడాలి; support rulesతో కలిపి నిర్ణయించాలి.',
        inspection: aff.join(' • '),
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.15–18 (delay/denial sections).',
        tone: VargaRuleTone.caution,
        applicable: true,
      );
    }

    const fertileSigns = {3, 7, 11};
    const lessFertileSigns = {0, 2, 4, 5};
    if (fertileSigns.contains(d7FifthSign)) {
      add(
        id: 'D7-SANTANA-004',
        topic: 'సంతానానికి ఫలవంతమైన రాశి support',
        result: 'D7 5వ భావం ${_signNameTe(d7FifthSign)}లో ఉంది; source fertility classificationలో ఇది supportive sign.',
        rule: 'Source/KP child frameworkలో కర్కాటకం, వృశ్చికం, మీనం ఫలవంతమైన రాశులుగా ఉపయోగించబడతాయి.',
        inspection: 'D7 5H sign = ${_signNameTe(d7FifthSign)}.',
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.6–8; KP child-birth source.',
        tone: VargaRuleTone.favorable,
        applicable: true,
      );
    } else if (lessFertileSigns.contains(d7FifthSign)) {
      add(
        id: 'D7-SANTANA-005',
        topic: '5వ భావ రాశి — అదనపు జాగ్రత్త layer',
        result: 'D7 5వ భావం ${_signNameTe(d7FifthSign)}లో ఉంది; source fertility classificationలో ఇది lower-support sign. ఇతర support ఉంటే ఫలితం మారుతుంది.',
        rule: 'మేషం, మిథునం, సింహం, కన్యను source child frameworkలో lower-fertility signsగా ఉపయోగిస్తుంది; ఇది ఒక్కటే denial rule కాదు.',
        inspection: 'D7 5H sign = ${_signNameTe(d7FifthSign)}.',
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.6–8; KP child-birth source.',
        tone: VargaRuleTone.caution,
        applicable: true,
      );
    }

    if ({1, 4, 5, 7, 9, 10, 11}.contains(d7FifthLordHouse)) {
      add(
        id: 'D7-SANTANA-006',
        topic: 'D7 5వ అధిపతి స్థానం — support',
        result: 'D7 5వ అధిపతి $d7FifthLord $d7FifthLordHouseవ భావంలో ఉండి సంతాన promiseకు supportive placementగా పనిచేస్తోంది.',
        rule: 'D7 5వ అధిపతి బలం/స్థానం మరియు శుభ సంబంధం child promiseలో ప్రధాన factor.',
        inspection: 'D7 5L=$d7FifthLord • House $d7FifthLordHouse • Sign ${_signNameTe(d7Sign(d7FifthLord))}.',
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.1–3, 15–18.',
        tone: VargaRuleTone.favorable,
        applicable: true,
      );
    } else if ({6, 8, 12}.contains(d7FifthLordHouse)) {
      add(
        id: 'D7-SANTANA-007',
        topic: 'D7 5వ అధిపతి దుస్థాన స్థానం',
        result: 'D7 5వ అధిపతి $d7FifthLord $d7FifthLordHouseవ భావంలో ఉంది; delay/strain layerగా sourceలో పరిశీలించాలి.',
        rule: '5వ అధిపతి 6/8/12లో ఉండటం ఇతర affliction/supportతో కలిపి delay/denial analysisలో ఉపయోగించాలి.',
        inspection: 'D7 5L=$d7FifthLord • House $d7FifthLordHouse.',
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.15–18.',
        tone: VargaRuleTone.caution,
        applicable: true,
      );
    }

    if ({1, 2, 5, 9, 11}.contains(d7JupiterHouse) || d7FifthSupportedByJupiter) {
      add(
        id: 'D7-SANTANA-008',
        topic: 'గురువు / పుత్రకారక support',
        result: 'D7లో గురువు సంతాన అంశానికి supportive placement/relation కలిగి ఉన్నాడు.',
        rule: 'గురువు పుత్రకారకుడిగా D1 + D7లో 5వ భావం/5వ అధిపతితో సంబంధం మరియు బలాన్ని పరిశీలించాలి.',
        inspection: 'D7 Jupiter H$d7JupiterHouse; 5H relation=${d7FifthSupportedByJupiter ? 'yes' : 'no'}.',
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.1–3, 7–9, 15–18.',
        tone: VargaRuleTone.favorable,
        applicable: true,
      );
    }

    if ({1, 2, 4, 5, 7, 9, 10, 11}.contains(d7MoonHouse) &&
        (d7FifthSupportedByMoon || sameHouse('Moon', d7FifthLord))) {
      add(
        id: 'D7-SANTANA-009',
        topic: 'చంద్ర support / గర్భధారణ సహకార layer',
        result: 'D7లో చంద్రుడు 5వ భావం/5వ అధిపతితో supportive relationలో ఉన్నాడు.',
        rule: 'చంద్రుని స్థానం, 5వ భావం/5వ అధిపతి సంబంధం మరియు fertility indicatorsను కలిసి చూడాలి.',
        inspection: 'D7 Moon H$d7MoonHouse; 5H relation=${d7FifthSupportedByMoon ? 'yes' : 'no'}.',
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.5–8, 15–18.',
        tone: VargaRuleTone.favorable,
        applicable: true,
      );
    }

    final luxurySupport = <String>[];
    if ({2, 4, 5, 9, 11}.contains(d7JupiterHouse)) luxurySupport.add('Jupiter H$d7JupiterHouse');
    if ({2, 4, 5, 9, 11}.contains(d7VenusHouse)) luxurySupport.add('Venus H$d7VenusHouse');
    if (_houseNames(v, 2).any(_benefics.contains)) luxurySupport.add('2H benefic support');
    if (_houseNames(v, 11).any(_benefics.contains)) luxurySupport.add('11H benefic support');
    if (luxurySupport.isNotEmpty) {
      add(
        id: 'D7-SANTANA-010',
        topic: 'సంతానం సౌఖ్యం / పోషణ / సౌకర్యం',
        result: 'D7లో పిల్లల సౌఖ్యం/సౌకర్యానికి supportive combinations ఉన్నాయి: ${luxurySupport.join(' • ')}.',
        rule: 'D7లో 2/4/5/9/11 భావాల శుభ support, గురు/శుక్ర బలం child-comfort/luxury layerగా sourceలో ఉపయోగించబడుతుంది.',
        inspection: luxurySupport.join(' • '),
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.18–19 (Luxury/comfort section).',
        tone: VargaRuleTone.favorable,
        applicable: true,
      );
    }

    final childHealthAff = <String>[];
    final d7h6Mal = _houseNames(v, 6).where(_malefics.contains).toList();
    final d7h8Mal = _houseNames(v, 8).where(_malefics.contains).toList();
    if (d7h6Mal.isNotEmpty) childHealthAff.add('6H malefics ${d7h6Mal.join(', ')}');
    if (d7h8Mal.isNotEmpty) childHealthAff.add('8H malefics ${d7h8Mal.join(', ')}');
    if ({6, 8, 12}.contains(d7FifthLordHouse)) childHealthAff.add('5L in H$d7FifthLordHouse');
    if (childHealthAff.isNotEmpty) {
      add(
        id: 'D7-SANTANA-011',
        topic: 'పిల్లల ఆరోగ్యం / బలహీనత — జాగ్రత్త',
        result: 'D7 child-health caution layer match అయింది: ${childHealthAff.join(' • ')}. ఇది medical diagnosis కాదు.',
        rule: 'D7లో 5వ భావం/5వ అధిపతి మరియు 6/8/12 afflictionను పిల్లల ఆరోగ్యం/బలహీనతకు source cautionగా మాత్రమే చూడాలి.',
        inspection: childHealthAff.join(' • '),
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.22–24 (health/weakness sections).',
        tone: VargaRuleTone.caution,
        applicable: true,
        remedy: 'పిల్లల ఆరోగ్యంపై ఏ practical concern ఉన్నా qualified pediatric/medical evaluation ముందుగా తీసుకోవాలి. జ్యోతిష్య పరిహారం spiritual support మాత్రమే.',
      );
    }

    final familySupport = <String>[];
    final d7h7Ben = _houseNames(v, 7).where(_benefics.contains).toList();
    final d7h2Ben = _houseNames(v, 2).where(_benefics.contains).toList();
    if (d7h7Ben.isNotEmpty) familySupport.add('7H benefics ${d7h7Ben.join(', ')}');
    if (d7h2Ben.isNotEmpty) familySupport.add('2H benefics ${d7h2Ben.join(', ')}');
    if (familySupport.isNotEmpty) {
      add(
        id: 'D7-SANTANA-012',
        topic: 'సంతానం వల్ల కుటుంబ / దాంపత్య support',
        result: 'D7లో family/relationship support సూచనలు కనిపిస్తున్నాయి: ${familySupport.join(' • ')}.',
        rule: 'D7లో 2వ/7వ భావాలు మరియు వాటి శుభ supportను సంతానం–కుటుంబ/దాంపత్య అనుసంధానంగా sourceలో పరిశీలించాలి.',
        inspection: familySupport.join(' • '),
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.19–22 (marriage/family impact sections).',
        tone: VargaRuleTone.favorable,
        applicable: true,
      );
    }

    final familyStrain = <String>[];
    final d7h7Mal = _houseNames(v, 7).where(_malefics.contains).toList();
    final d7h2Mal = _houseNames(v, 2).where(_malefics.contains).toList();
    if (d7h7Mal.isNotEmpty) familyStrain.add('7H malefics ${d7h7Mal.join(', ')}');
    if (d7h2Mal.length >= 2) familyStrain.add('2H multiple malefics ${d7h2Mal.join(', ')}');
    if (familyStrain.isNotEmpty) {
      add(
        id: 'D7-SANTANA-013',
        topic: 'సంతానం–కుటుంబ సంబంధంలో జాగ్రత్త',
        result: 'D7లో family/relationship strain source conditionsలో కొన్ని match అయ్యాయి: ${familyStrain.join(' • ')}.',
        rule: 'D7 2వ/7వ భావాల పాప ప్రభావాన్ని పిల్లల–కుటుంబ సంబంధ stress layerగా మాత్రమే చూడాలి; D1/D9తో confirm చేయాలి.',
        inspection: familyStrain.join(' • '),
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.19–22.',
        tone: VargaRuleTone.caution,
        applicable: true,
      );
    }

    final dualSigns = {2, 5, 8, 11};
    final multiIndicators = <String>[];
    if (dualSigns.contains(d7FifthSign)) multiIndicators.add('5H dual sign ${_signNameTe(d7FifthSign)}');
    if (relatedToHouse('Mercury', 5)) multiIndicators.add('Mercury ↔ 5H');
    if (relatedToHouse('Jupiter', 5)) multiIndicators.add('Jupiter ↔ 5H');
    if (multiIndicators.length >= 2) {
      add(
        id: 'D7-SANTANA-014',
        topic: 'Multiple / twin-type pattern — source indicator',
        result: 'D7లో multiple/twin-type child patternకు source indicators కలిసి కనిపిస్తున్నాయి: ${multiIndicators.join(' • ')}. ఇది medical prediction కాదు.',
        rule: 'ద్విస్వభావ రాశి + Mercury/Jupiter child-house support వంటి source combinationsను multiple/twin-type patternకు supporting indicatorగా మాత్రమే చూడాలి.',
        inspection: multiIndicators.join(' • '),
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.20–22 (multiple/twin pattern section).',
        tone: VargaRuleTone.neutral,
        applicable: true,
      );
    }

    final vitalitySupport = <String>[];
    if ({1, 5, 9, 11}.contains(d7JupiterHouse)) vitalitySupport.add('Jupiter H$d7JupiterHouse');
    if ({1, 5, 9, 11}.contains(d7FifthLordHouse)) vitalitySupport.add('5L H$d7FifthLordHouse');
    if (ben.isNotEmpty) vitalitySupport.add('5H benefic support');
    if (vitalitySupport.length >= 2) {
      add(
        id: 'D7-SANTANA-015',
        topic: 'పిల్లల vitality / wellbeing support',
        result: 'D7లో child wellbeingకు supportive evidence ఉంది: ${vitalitySupport.join(' • ')}.',
        rule: 'Sourceలో longevity-sensitive rows ఉన్నప్పటికీ app deterministic lifespan/death verdict ఇవ్వదు; 5H/5L/Jupiter strengthను wellbeing supportగా మాత్రమే చూపిస్తుంది.',
        inspection: vitalitySupport.join(' • '),
        source: 'Saptamsha_Santana_Niyamalu.pdf pp.23–25; sensitive longevity rows converted to non-deterministic wellbeing support.',
        tone: VargaRuleTone.favorable,
        applicable: true,
      );
    }

    if (birthDateTime != null) {
      final system = DashaService.system(
        kind: DashaSystemKind.vimshottari,
        chart: chart,
        birthDateTime: birthDateTime,
      );
      final ranked = <MapEntry<int, String>>[];
      final past = <MapEntry<int, String>>[];
      final now = DateTime.now();
      for (final md in system.mahadashas) {
        for (final ad in DashaService.subPeriodsFor(system, md)) {
          final mdScore = _childTimingPlanetScore(chart, v, md.lord, d7FifthLord);
          final adScore = _childTimingPlanetScore(chart, v, ad.lord, d7FifthLord);
          final score = mdScore + adScore;
          final startAge = ad.start.difference(birthDateTime).inDays / 365.2425;
          final endAge = ad.end.difference(birthDateTime).inDays / 365.2425;
          if (endAge < 12 || startAge > 60) continue;
          final evidencePct = ((score / 8) * 100).clamp(0, 100).round();
          final line =
              '${ad.start.year}–${ad.end.year} • Age ${startAge.clamp(0, 99).toStringAsFixed(1)}–${endAge.clamp(0, 99).toStringAsFixed(1)} • ${md.lord}/${ad.lord} • Evidence $evidencePct%';
          final entry = MapEntry(score, line);
          if (ad.end.isBefore(now)) {
            past.add(entry);
          } else {
            ranked.add(entry);
          }
        }
      }
      ranked.sort((a, b) => b.key.compareTo(a.key));
      past.sort((a, b) => b.key.compareTo(a.key));
      final strong = ranked.where((x) => x.key >= 4).take(8).toList();
      final chosen = strong.isNotEmpty ? strong : ranked.take(6).toList();
      final windows = chosen.map((x) => x.value).toList(growable: false);

      if (windows.isNotEmpty) {
        add(
          id: 'D7-SANTANA-016',
          topic: 'పిల్లలు పుట్టే Current / Future Candidate Years',
          result: windows.join('\n'),
          rule: 'Child-birth timingకు 2/5/11 activation + D1 5L/Jupiter + D7 5H/5L/Jupiter confirmationను MD/ADలో rank చేయాలి. ఇది candidate window మాత్రమే; guaranteed birth year కాదు.',
          inspection: 'Current/future MD/AD windows మాత్రమే main resultలో చూపించాం. Strong windows=${strong.length}; future ranked=${ranked.length}; past archived=${past.length}.',
          source: 'Saptamsha_Santana_Niyamalu.pdf pp.28–29 + KP child-birth framework (2/5/11) + Vimshottari timing.',
          tone: VargaRuleTone.favorable,
          applicable: true,
        );
      }

      if (past.isNotEmpty) {
        add(
          id: 'D7-AUDIT-PAST-TIMING',
          topic: 'Past child-birth timing windows — Audit',
          result: past.take(8).map((x) => x.value).join('\n'),
          rule: 'Past MD/AD child-timing windowsను client-facing future listలో కలపకూడదు; audit/history కోసం మాత్రమే ఉంచాలి.',
          inspection: 'Past ranked windows=${past.length}.',
          source: 'Saptamsha_Santana_Niyamalu.pdf pp.28–29 + Vimshottari timing audit.',
          tone: VargaRuleTone.info,
          applicable: false,
          auto: false,
        );
      }
    }

    // Build99: p.5 specifies the exact BS and KS arithmetic. Treat the
    // subsequent male/female tradition as two *methods*, not as a claim about
    // the chart owner's sex. Neither method determines fertility medically.
    final byName = {for (final p in chart.planets) p.name: p.longitude};
    if (['Jupiter', 'Venus', 'Sun', 'Mars', 'Moon']
        .every(byName.containsKey)) {
      double wrap360(double degrees) => (degrees % 360.0 + 360.0) % 360.0;
      final bs = wrap360(byName['Jupiter']! + byName['Venus']! + byName['Sun']!);
      final ks = wrap360(byName['Jupiter']! + byName['Mars']! + byName['Moon']!);

      String degreeLabel(double longitude) {
        final sign = VargaService.signForLongitude(longitude, 1);
        final degrees = longitude % 30;
        return '${_signNameTe(sign)} ${degrees.toStringAsFixed(3)}°'
            ' (${longitude.toStringAsFixed(3)}°)';
      }

      String vargaSigns(double longitude) => [1, 9, 7]
          .map((n) => 'D$n ${_signNameTe(VargaService.signForLongitude(longitude, n))}')
          .join(' • ');

      final bsSigns = [1, 9, 7]
          .map((n) => VargaService.signForLongitude(bs, n)).toList();
      final ksSigns = [1, 9, 7]
          .map((n) => VargaService.signForLongitude(ks, n)).toList();
      // Sign indices are 0-based: Aries(0) is the first *odd-numbered* sign.
      final bsAllOdd = bsSigns.every((sign) => sign.isEven);
      final ksDispositor = _signLord(ksSigns.first);
      final ksDispositorLongitude = byName[ksDispositor];
      final ksDispositorSigns = ksDispositorLongitude == null
          ? <int>[]
          : [1, 9, 7]
              .map((n) => VargaService.signForLongitude(ksDispositorLongitude, n))
              .toList();
      final ksAllEven = ksSigns.every((sign) => sign.isOdd) &&
          ksDispositorSigns.length == 3 &&
          ksDispositorSigns.every((sign) => sign.isOdd);
      final ksDispositorSummary = ksDispositorLongitude == null
          ? 'KS అధిపతి గ్రహస్థానం లభించలేదు'
          : 'KS రాశ్యాధిపతి $ksDispositor: ${vargaSigns(ksDispositorLongitude)}';
      final raw = 'BS = (గురు + శుక్ర + సూర్య) mod 360 = ${degreeLabel(bs)};'
          ' ${vargaSigns(bs)}.\n'
          'KS = (గురు + కుజ + చంద్ర) mod 360 = ${degreeLabel(ks)};'
          ' ${vargaSigns(ks)}.\n$ksDispositorSummary';
      add(
        id: 'D7-SANTANA-017',
        topic: 'బీజ స్ఫుటం — రాశి/నవాంశ/సప్తాంశ పరిశీలన',
        result: bsAllOdd
            ? 'BS మూడు వర్గాల్లో బేసి సంఖ్య రాశులలో ఉంది; మూలగ్రంథ పురుష-జాతక పద్ధతిలో అనుకూల సూచన. వైద్యపరమైన నిర్ధారణ కాదు.'
            : 'BS మూడు వర్గాల్లో బేసి రాశి ప్రమాణం పూర్తిగా సరిపోలలేదు. ఇతర సూచనలతో కలిపి పరిశీలించాలి.',
        rule: 'BS = (గురు నిరయణ రేఖాంశం + శుక్ర నిరయణ రేఖాంశం + సూర్య నిరయణ రేఖాంశం) mod 360. '
            'BS రాశి, నవాంశ, సప్తాంశ మూడు వర్గాల్లో బేసి సంఖ్య రాశుల్లో ఉంటే మూల పద్ధతిలో అనుకూల సంతాన సూచనగా తీసుకుంటారు.',
        inspection: '$raw\nBS మూడు బేసి రాశుల్లో ఉందా? ${bsAllOdd ? 'అవును' : 'కాదు'}.'
            '\nగమనిక: పద్ధతి మాత్రమే; జాతకుని లింగం ఇక్కడ నిర్ధారించడం లేదు.',
        source: 'Saptamsha_Santana_Niyamalu.pdf p.5 — బీజ స్ఫుటం / BS-వర్గానం.',
        tone: bsAllOdd ? VargaRuleTone.favorable : VargaRuleTone.info,
        applicable: bsAllOdd,
        auto: bsAllOdd,
      );
      add(
        id: 'D7-SANTANA-018',
        topic: 'క్షేత్ర స్ఫుటం — రాశి/నవాంశ/సప్తాంశ పరిశీలన',
        result: ksAllEven
            ? 'KS మరియు KS రాశ్యాధిపతి మూడు వర్గాల్లో సరి సంఖ్య రాశులలో ఉన్నారు; మూల స్త్రీ-జాతక పద్ధతిలో అనుకూల సూచన. వైద్యపరమైన నిర్ధారణ కాదు.'
            : 'KS లేదా KS రాశ్యాధిపతి మూడు వర్గాల్లో సరి రాశి ప్రమాణం పూర్తిగా సరిపోలలేదు; ఇతర సూచనలతో కలిపి పరిశీలించాలి.',
        rule: 'KS = (గురు నిరయణ రేఖాంశం + కుజ నిరయణ రేఖాంశం + చంద్ర నిరయణ రేఖాంశం) mod 360. '
            'KS మరియు దాని రాశ్యాధిపతి రాశి, నవాంశ, సప్తాంశ మూడు వర్గాల్లో సరి సంఖ్య రాశుల్లో ఉంటే మూల పద్ధతిలో అనుకూల సంతాన సూచనగా తీసుకుంటారు.',
        inspection: '$raw\nKS మూడు సరి రాశుల్లో ఉందా? ${ksAllEven ? 'అవును' : 'కాదు'}.'
            '\nKS రాశ్యాధిపతి=$ksDispositor. గమనిక: పద్ధతి మాత్రమే; జాతకుని లింగం ఇక్కడ నిర్ధారించడం లేదు.',
        source: 'Saptamsha_Santana_Niyamalu.pdf p.5 — క్షేత్ర స్ఫుటం / KS-వర్గానం.',
        tone: ksAllEven ? VargaRuleTone.favorable : VargaRuleTone.info,
        applicable: ksAllEven,
        auto: ksAllEven,
      );
    }

    // p.9 explicitly supplies a single interpretation row for the D7
    // ascendant lord by planet. This is one actual, reproducible match.
    const lagnaLordIndications = <String, String>{
      'Sun': 'వీరత్వం, బలం, కీర్తి, ధైర్యం, ఆకర్షణీయ వ్యక్తిత్వం',
      'Moon': 'సత్యప్రవర్తన, బుద్ధిమంతత్వం, సామ్యం, ధర్మాచరణ',
      'Mars': 'తన ధైర్యంపై గర్వం, భరించలేని వ్యక్తిత్వ లక్షణాలు',
      'Mercury': 'బుద్ధిమంతత్వం, వాక్చాతుర్యం, విద్య, కళలపై ఆసక్తి',
      'Jupiter': 'జ్ఞానం, సంతోషం, ధైర్యంలో స్థిరత్వం',
      'Venus': 'సంగీతం, పాటలలో ఆనందం, కామాసక్తి',
      'Saturn': 'తప్పు మార్గాలలో పనులు, చెడులో ఆనందం వంటి సంప్రదాయ హెచ్చరిక',
    };
    final d7LagnaLord = _signLord(v.ascendantSignIndex);
    final lordMeaning = lagnaLordIndications[d7LagnaLord];
    if (lordMeaning != null) {
      add(
        id: 'D7-SANTANA-019',
        topic: 'D7 లగ్నాధిపతి — గ్రహ-ఫల సూచిక',
        result: 'D7 లగ్నాధిపతి $d7LagnaLord. మూల పట్టిక ప్రకారం సూచన: $lordMeaning. ఇవి సంప్రదాయ వర్ణనలు మాత్రమే.',
        rule: 'సప్తాంశ లగ్న రాశి అధిపతిని గుర్తించి PDF p.9లోని ఏడు గ్రహాల లగ్నాధిపతి ఫలిత పట్టికలో సరైన rowను మాత్రమే వర్తింపజేయాలి.',
        inspection: 'D7 Lagna = ${_signNameTe(v.ascendantSignIndex)}; లగ్నాధిపతి=$d7LagnaLord; D7లో గ్రహ స్థానం H${d7House(d7LagnaLord)}.',
        source: 'Saptamsha_Santana_Niyamalu.pdf p.9 — సప్తాంశ లగ్నాధిపతి పట్టిక.',
        tone: VargaRuleTone.neutral,
        applicable: true,
      );
    }

    // Source pp.8–9: 12 house topic table. Only a *populated* D7 house
    // becomes a matched chart-inspection row. An empty house remains in the
    // audit catalog, rather than being presented as a predictive combination.
    const houseDomains = <String>[
      'సంతాన సాధ్యత, పూర్వపుణ్యం, ఆయుష్షు, కీర్తి, ఆకాంక్ష ఫలితాల పరిశీలన',
      'పూర్వజన్మ సంస్కారాలు, పిల్లల సంపద, క్షేమం, వారసత్వ సామర్థ్యం',
      'పిల్లల ధైర్యం, బలం, తోబుట్టువుల మర్యాద, అనుబంధం',
      'పిల్లల సంతోషం, ఇల్లు/సుఖం, తల్లి, విద్య, అనుబంధం',
      'సంతాన పూర్వపుణ్యం, మీ బుద్ధి, పిల్లల బుద్ధి, ధర్మ నిష్ఠ',
      'పిల్లలకు / పిల్లల వలన సమస్యలు, వ్యాధులు, భాగస్వామికి బాధ',
      'గర్భధారణ, వ్యతిరేక లింగంతో సంబంధాలు, పిల్లల బలహీనతలు',
      'పిల్లల ఆయుష్షు, బంధుతల ఆయుష్షు, గర్భస్రావ సంప్రదాయ సూచన',
      'మనుమలు, పిల్లల అదృష్టం, పిల్లల దూర ప్రయాణం, దైవానుగ్రహం',
      'తల్లిదండ్రుల నుంచి వచ్చే వంశ వృత్తులు, పిల్లల నుంచి లభించే సేవ/కీర్తి',
      'పిల్లల లాభాలు, పిల్లల ద్వారా లాభసాధ్యత, స్నేహితులు',
      'పిల్లల సాధారణ వ్యయాలు, పెంపకం ఖర్చులు, అనుకోని సంఘటనలు',
    ];
    for (var h = 1; h <= 12; h++) {
      final inHouse = _houseNames(v, h);
      final active = inHouse.isNotEmpty;
      add(
        id: 'D7-HOUSE-${h.toString().padLeft(2, '0')}',
        topic: 'D7 $h వ భావం — అంశాల పరిశీలన',
        result: active
            ? 'D7 $h వ భావంలో ${inHouse.join(', ')} ఉంది/ఉన్నారు. ఈ భావంలో పరిశీలించాల్సిన అంశాలు: ${houseDomains[h - 1]}. ఇది స్వతంత్ర యోగ నిర్ణయం కాదు.'
            : 'D7 $h వ భావంలో గ్రహాలు లేవు. మూల పట్టికలో చూడాల్సిన అంశాలు: ${houseDomains[h - 1]}. అధిపతి/దృష్టి పరిశీలన విడిగా అవసరం.',
        rule: 'PDFలో ఇచ్చిన D7 $h వ భావం సంబంధిత అర్థాలను ఆ భావంలో ఉన్న గ్రహాలతో కలిపి చూడాలి; ఖాళీ భావంపై ఫలితాన్ని ఆటోగా నిర్ణయించకూడదు.',
        inspection: 'D7 H$h=${_signNameTe(_houseSign(v, h))}; occupants=${active ? inHouse.join(', ') : 'none'}; house lord=${_signLord(_houseSign(v, h))}.',
        source: 'Saptamsha_Santana_Niyamalu.pdf ${h == 12 ? 'p.9' : 'p.8'} — D7 భావాలు, $h వ భావం.',
        tone: VargaRuleTone.info,
        applicable: active,
        auto: active,
      );
    }

    // p.27: Jupiter's 5th sign in Guru BAV must be read from the *D1*
    // Ashtakavarga sign-indexed table, never from the D7 chart index.
    // Report raw bindus rather than inventing a fertility threshold.
    final ashtaka = AshtakavargaService.calculate(chart);
    if (ashtaka.totalsValid) {
      final jupiterFifth = (jupiter.signIndex + 4) % 12;
      final guruBindus = ashtaka.bhinna['Jupiter']?[jupiterFifth];
      if (guruBindus != null) {
        add(
          id: 'D7-SANTANA-020',
          topic: 'గురు BAV — గురువు నుండి 5వ రాశి బిందువులు',
          result: 'జన్మ D1లో గురువు నుంచి 5వ రాశి ${_signNameTe(jupiterFifth)}. '
              'ఆ రాశికి గురు BAV బిందువులు $guruBindus/8. ఇది లెక్కించిన మూలబలం మాత్రమే; సంతాన సంఖ్య లేదా నిరాకరణ తీర్పు కాదు.',
          rule: 'జన్మ రాశి చక్రంలో గురువు ఉన్న రాశి నుండి 5వ రాశికి గురు భిన్నాష్టకవర్గంలో వచ్చిన బిందువులు పరిశీలించాలి; ఇతర 5H/5L, D7, BS/KS పద్ధతులతో సమన్వయం అవసరం.',
          inspection: 'D1 గురువు=${_signNameTe(jupiter.signIndex)}; గురువు నుండి 5వ రాశి=${_signNameTe(jupiterFifth)}; '
              'Guru BAV[$jupiterFifth]=$guruBindus; BAV audited totals=${ashtaka.totalsValid}.',
          source: 'Saptamsha_Santana_Niyamalu.pdf p.27 — పద్ధతి 3, గురు BAV.',
          tone: VargaRuleTone.info,
          applicable: true,
        );
      }
    }

    void sourceOnly(String id, String topic, String rule, String source, {String? note}) {
      add(
        id: id,
        topic: topic,
        result: note ?? 'Source rule భద్రంగా ఉంది; exact source arithmetic/condition పూర్తి validate అయ్యే వరకు client-facing auto-result ఇవ్వము.',
        rule: rule,
        inspection: 'Source catalog entry. Auto-match disabled to avoid guessed result.',
        source: source,
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
      );
    }

    // Build100: Rinanubandha / intergenerational bonds. The supplied scanned
    // Saptamsha source explicitly associates D7 2H with purvajanma samskaras
    // and santana karma (p.8). It DOES NOT provide an explicit, validated
    // IF–THEN rule diagnosing an actual past-life debt. Preserve the audit
    // evidence and avoid falsely coloring it as a matched yoga.
    final d12Lineage = VargaService.calculate(chart, 12);
    final d7SecondSign = _houseSign(v, 2);
    final d7SecondLord = _signLord(d7SecondSign);
    final d7SecondLordHouse = d7House(d7SecondLord);
    final d7SecondOccupants = _houseNames(v, 2);
    final d7NinthOccupants = _houseNames(v, 9);
    final d1FifthOccupants = chart.planets
        .where((p) => p.signIndex == natal5Sign)
        .map((p) => p.name)
        .toList(growable: false);
    String occupants(List<String> names) =>
        names.isEmpty ? 'ఖాళీ (అధిపతి/దృష్టి పరిశీలన అవసరం)' : names.join(', ');

    add(
      id: 'D7-RUNA-001',
      topic: 'ఋణానుబంధం — పూర్వజన్మ సంస్కారాలు / సంతాన కర్మ (D7)',
      result: 'సప్తాంశ మూలంలోని D7 2వ భావం పూర్వజన్మ సంస్కారాలు, సంతాన కర్మ అనే విషయాలకు సంబంధించినది. '
          'ఈ జాతకంలోని గ్రహస్థితుల వివరాలు పరిశీలనకు అందుబాటులో ఉన్నాయి; '
          'ఋణానుబంధం ఉందని లేదా లేదని నిర్ణయించే ధృవీకృత IF–THEN యోగం ఇంకా లేదు.',
      rule: 'మూల PDF p.8: D7 2వ భావం — పూర్వజన్మ సంస్కారాల ప్రభావిత సంతాన కర్మ, పిల్లల సంపద, క్షేమం, వారసత్వ సామర్థ్యం. '
          'ఈ అంశాల జాబితా స్వతంత్ర ఋణానుబంధ దోష/యోగ నిర్ణయ సూత్రం కాదు.',
      inspection: 'D7 2H: ${_signNameTe(d7SecondSign)}; occupants=${occupants(d7SecondOccupants)}; '
          '2L=$d7SecondLord, D7 H$d7SecondLordHouse. '
          'D1 5H: ${_signNameTe(natal5Sign)}; occupants=${occupants(d1FifthOccupants)}; '
          '5L=$natal5Lord, D1 H$natal5LordHouse; గురువు D1 H$jupiterHouse. '
          'D7 5H occupants=${occupants(d7h5)}; 5L=$d7FifthLord, D7 H$d7FifthLordHouse; '
          'గురువు D7 H$d7JupiterHouse. '
          'ఇవి chart evidence మాత్రమే; కర్మ కారణ-ఫలాన్ని నిర్ధారించవు.',
      source: 'Saptamsha_Santana_Niyamalu.pdf p.8 — D7 2వ భావం / పూర్వజన్మ సంస్కారాలు.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );

    add(
      id: 'D7-RUNA-002',
      topic: 'ఋణానుబంధం — తల్లిదండ్రులు–పిల్లల వంశ అనుబంధ పరిశీలన',
      result: 'సంతాన సంబంధాన్ని D7 4వ/5వ/9వ భావాలతో, వంశ / తల్లిదండ్రుల నేపథ్యాన్ని '
          'D12తో కలిపి చూడటానికి chart data సేకరించాం. '
          'నిర్దిష్ట ఋణానుబంధం/పూర్వజన్మ బంధం ఉందనే ఫలితం చెప్పేందుకు మూల నియమం ఇంకా ధృవీకరించాలి.',
      rule: 'D7 PDF p.8లో 4వ భావం పిల్లల సుఖం/తల్లి/అనుబంధం, 5వ భావం సంతాన పూర్వపుణ్యం, '
          '9వ భావం మనుమలు/పిల్లల అదృష్టం వంటి అంశాలను సూచిస్తుంది. '
          'D12 తల్లిదండ్రులు/వంశం పరిశీలన కోసం appలో ఉన్న వేరొక వర్గ చక్రం. '
          'ఈ అంశాల కలయికకు మూలంలో స్పష్టమైన ఋణానుబంధ IF–THEN సూత్రం పేర్కొనబడలేదు.',
      inspection: 'D7 4H: ${_signNameTe(_houseSign(v, 4))}, occupants=${occupants(_houseNames(v, 4))}; '
          'D7 5H: ${_signNameTe(d7FifthSign)}, occupants=${occupants(d7h5)}; '
          'D7 9H: ${_signNameTe(_houseSign(v, 9))}, occupants=${occupants(d7NinthOccupants)}; '
          'D12 4H: ${_signNameTe(_houseSign(d12Lineage, 4))}, occupants=${occupants(_houseNames(d12Lineage, 4))}; '
          'D12 9H: ${_signNameTe(_houseSign(d12Lineage, 9))}, occupants=${occupants(_houseNames(d12Lineage, 9))}. '
          'Chart mapping మాత్రమే; karmic diagnosis కాదు.',
      source: 'Saptamsha_Santana_Niyamalu.pdf p.8 — D7 భావ సూచనలు; '
          'D12 parentage context = app varga definition (not a Rinanubandha rule from the PDF).',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );

    // Build101 — extra source-grounded D7 sections, pp.19–26.
    // Explicit IF–THEN rules below come from the identified scanned PDF rows.
    // The culturally traditional outcomes must never be presented as a medical
    // diagnosis, established adoption plan, or a certainty of twins/birth.
    const suppliedBookNotice = 'గ్రంథాధారిత సంప్రదాయ జ్యోతిష్య సూచన మాత్రమే; '
        'స్వతంత్ర వైద్య/శాస్త్రీయ నిర్ధారణ కాదు.';

    bool isRelated(String planet, int house) =>
        d7House(planet) == house || aspectsHouse(planet, house);
    bool lordAfflicted(String lord) {
      final ownHouse = d7House(lord);
      return ownHouse > 0 && _malefics.any((mal) => mal != lord &&
          (sameHouse(mal, lord) || aspectsHouse(mal, ownHouse)));
    }
    void verifiedRow({
      required String id,
      required String topic,
      required bool matches,
      required String traditionalMeaning,
      required String conditions,
      required String actual,
      required int page,
      VargaRuleTone tone = VargaRuleTone.favorable,
    }) {
      add(
        id: id,
        topic: topic,
        result: matches
            ? '$traditionalMeaning. $suppliedBookNotice'
            : 'ఈ జాతకంలో పేర్కొన్న పూర్తి షరతులు సరిపోలలేదు; మూల రూల్ auditలో ఉంది.',
        rule: conditions,
        inspection: '$actual\nRule check: ${matches ? 'MATCH' : 'NOT MATCH'}',
        source: 'Saptamsha_Santana_Niyamalu.pdf p.$page — $id',
        tone: matches ? tone : VargaRuleTone.info,
        applicable: matches,
        auto: true,
      );
    }

    // Kaka-vandhya is often used for a one-child-only / secondary-conception
    // pattern, not a blanket claim that conception has never happened. No
    // specific, named Kaka-vandhya test occurs in the checked PDF pages.
    // The book covers fifth/ninth child-order and delay/denial indicators;
    // keep this named label as a transparent combination-review, not a hit.
    final d7NinthLord = _signLord(_houseSign(v, 9));
    final ninthAfflicted = lordAfflicted(d7NinthLord) ||
        {6, 8, 12}.contains(d7House(d7NinthLord));
    final firstSupported = d7FifthSupportedByJupiter || ben.isNotEmpty;
    add(
      id: 'D7-KAKA-001',
      topic: 'కాకవంధ్య యోగము — మొదటి/తరువాతి సంతానం వేర్వేరు పరిశీలన',
      result: 'మూలంలో సంతాన క్రమం, 5వ/9వ భావాలు, ఆలస్యం/నిరాకరణ రూల్స్ ఉన్నాయి. '
          'ఈ పేజీల్లో కాకవంధ్య అనే పేరుతో ఖచ్చిత IF–THEN నిర్ణయ సూత్రం ధృవీకరించలేదు. '
          'జాతకంతో పాటు ఇప్పటికే సంతానం ఉందో లేదో తెలియకుండానే తుది నిర్ణయం ఇవ్వకూడదు.',
      rule: 'ఒక సంతానం తరువాత మరొక సంతానానికి ఆటంకం అనే కాకవంధ్య అంశాన్ని '
          '5వ భావం/5L, తదుపరి సంతానానికి 9వ భావం/9L, సంతాన క్రమం మరియు '
          'అనుకూల–ప్రతికూల దశలతో సమీక్షించాలి. ఇది app రూపొందించిన comparative audit; '
          'గ్రంథంలోని ఒకే ప్రత్యేక "కాకవంధ్య" యోగంగా ఆపాదించలేదు.',
      inspection: 'D7 5L=$d7FifthLord H$d7FifthLordHouse, first support=$firstSupported; '
          'D7 9L=$d7NinthLord H${d7House(d7NinthLord)}, ninth caution=$ninthAfflicted. '
          'Actual prior-child history unavailable; no deterministic match.',
      source: 'Saptamsha_Santana_Niyamalu.pdf pp.15–18,20–21,25–26; '
          'special name/combined decision = app audit (not verbatim source yoga).',
      tone: VargaRuleTone.info, applicable: false, auto: false,
    );

    // Rinanubandha: source chapter is *actually* pp.19–22. Build100
    // chart-based discussion of p.8 was only a partial read.
    final sixthLord = _signLord(_houseSign(v, 6));
    verifiedRow(
      id: 'D7-RUNA-003',
      topic: 'ఋణానుబంధం — 5వ అధిపతి 6వ భావంలో',
      matches: d7FifthLordHouse == 6,
      traditionalMeaning: 'మూల D7-4 పద్ధతిలో సంతానంతో ప్రతికూల/ఋణ సంబంధాన్ని సమీక్షించాల్సిన సూచన',
      conditions: 'PDF p.20 D7–4: D7 5వ అధిపతి 6వ భావంలో ఉంటే ప్రతికూల ఋణానుబంధం సూచనగా పరిగణిస్తుంది.',
      actual: 'D7 5L=$d7FifthLord, house=$d7FifthLordHouse; required H6.',
      page: 20, tone: VargaRuleTone.caution,
    );
    final lord6Relation = isRelated(sixthLord, 5) ||
        (d7House(sixthLord) > 0 && d7House(sixthLord) == d7FifthLordHouse) ||
        aspectsHouse(sixthLord, d7FifthLordHouse);
    verifiedRow(
      id: 'D7-RUNA-004',
      topic: 'ఋణానుబంధం — 6వ అధిపతి / 5వ భావ సంబంధం',
      matches: lord6Relation,
      traditionalMeaning: 'మూల D7-3 ప్రకారం సంతాన సంబంధాల్లో సమస్యల సూచనను పరిశీలించాలి',
      conditions: 'PDF p.20 D7–3: 5వ భావం లేదా 5వ అధిపతిపై 6వ అధిపతి దృష్టి లేదా యుతి.',
      actual: 'D7 6L=$sixthLord H${d7House(sixthLord)}; 5H=${_signNameTe(d7FifthSign)}; '
          '5L=$d7FifthLord H$d7FifthLordHouse; relation=$lord6Relation.',
      page: 20, tone: VargaRuleTone.caution,
    );
    final malAtLagna = _malefics.where((p) => isRelated(p, 1)).toList();
    verifiedRow(
      id: 'D7-RUNA-005',
      topic: 'ఋణానుబంధం — D7 లగ్నంపై పాప ప్రభావం',
      matches: malAtLagna.isNotEmpty,
      traditionalMeaning: 'మూల D7-1లో ప్రతికూల ఋణానుబంధం అనే సంప్రదాయ సూచన',
      conditions: 'PDF p.20 D7–1: సప్తాంశ లగ్నంపై పాప ప్రభావం.',
      actual: 'D7 Lagna=${_signNameTe(v.ascendantSignIndex)}; '
          'malefic occupying/aspecting lagna=${malAtLagna.isEmpty ? 'none' : malAtLagna.join(', ')}.',
      page: 20, tone: VargaRuleTone.caution,
    );

    // Adoption / Dattata section, pp.23–25. The source says possible,
    // NOT proof of adoption or inability to have biological children.
    final d7FifthLordTwelfth = d7FifthLordHouse == 12;
    final d7NinthLordTwelfth = d7House(d7NinthLord) == 12;
    verifiedRow(
      id: 'D7-ADOPT-001',
      topic: 'దత్తత — 5వ/9వ అధిపతి వ్యయస్థాన సంబంధం',
      matches: d7FifthLordTwelfth || d7NinthLordTwelfth,
      traditionalMeaning: 'మూల D7–2 ప్రకారం దత్తత సంతాన అవకాశాన్ని సమీక్షించాల్సిన సూచన',
      conditions: 'PDF p.24 D7–2లో లగ్నం/5వ/9వ అధిపతి 12వ స్థాన సంబంధాన్ని దత్తత సూచనగా పేర్కొంది. '
          'ఇక్కడ స్పష్టంగా లెక్కించగల లగ్నం నుంచి 12వ భావాన్ని మాత్రమే స్వయంచాలకంగా పరీక్షిస్తున్నాం.',
      actual: 'D7 5L=$d7FifthLord H$d7FifthLordHouse, '
          'D7 9L=$d7NinthLord H${d7House(d7NinthLord)}; both check H12.',
      page: 24, tone: VargaRuleTone.neutral,
    );
    final adoptAffliction = lordAfflicted(d7FifthLord) || lordAfflicted(d7NinthLord);
    verifiedRow(
      id: 'D7-ADOPT-002',
      topic: 'దత్తత — 5వ/9వ అధిపతి పాపగ్రహ పీడ',
      matches: adoptAffliction,
      traditionalMeaning: 'మూల D7–3లో చెప్పిన దత్తత సంభావ్యతను అదనపు జాతక సాక్ష్యంతో పరిశీలించాలి',
      conditions: 'PDF p.24 D7–3: లగ్నం, 5వ లేదా 9వ అధిపతికి పాపగ్రహ పీడ సంబంధం.',
      actual: 'D7 5L afflicted=${lordAfflicted(d7FifthLord)}, '
          '9L afflicted=${lordAfflicted(d7NinthLord)}. '
          'Affliction check = same-house or graha drishti from malefic.',
      page: 24, tone: VargaRuleTone.caution,
    );
    final adoptSaturn = {9, 10}.contains(d7FifthSign) &&
        d7House('Saturn') == 5 && aspectsHouse('Moon', 5);
    final adoptMercury = {2, 5}.contains(d7FifthSign) &&
        d7House('Mercury') == 5 && aspectsHouse('Moon', 5);
    verifiedRow(
      id: 'D7-ADOPT-003',
      topic: 'దత్తత — 5వ భావ శని/బుధ రాశి ప్రత్యేక సంయోగం',
      matches: adoptSaturn || adoptMercury,
      traditionalMeaning: 'మూల p.23లోని ప్రత్యేక దత్తత/కోడళ్ళు అనుబంధ సూచన',
      conditions: 'PDF p.23: 5వ భావం శని రాశిలో శని ఉండి చంద్ర దృష్టి, '
          'లేదా 5వ భావం బుధ రాశిలో బుధుడు ఉండి చంద్ర దృష్టి వంటి కాంబినేషన్లు.',
      actual: 'D7 5H=${_signNameTe(d7FifthSign)}; Saturn H${d7House('Saturn')}; '
          'Mercury H${d7House('Mercury')}; Moon aspects 5=${aspectsHouse('Moon', 5)}.',
      page: 23, tone: VargaRuleTone.neutral,
    );

    // Twin patterns p.25–26: dual signs and dual-sign lords are supporting
    // markers, not reliable genetic or obstetric predictions.
    const dualSigns = {2, 5, 8, 11};
    final lonByName = {for (final p in chart.planets) p.name: p.longitude};
    if (['Sun', 'Moon', 'Mars', 'Jupiter', 'Venus'].every(lonByName.containsKey)) {
      double norm360(double x) => ((x % 360) + 360) % 360;
      final bsD7 = VargaService.signForLongitude(norm360(lonByName['Sun']! + lonByName['Jupiter']! + lonByName['Venus']!), 7);
      final ksD7 = VargaService.signForLongitude(norm360(lonByName['Moon']! + lonByName['Mars']! + lonByName['Jupiter']!), 7);
      verifiedRow(
        id: 'D7-TWINS-001',
        topic: 'కవలలు — BS/KS ద్విస్వభావ రాశి',
        matches: dualSigns.contains(bsD7) || dualSigns.contains(ksD7),
        traditionalMeaning: 'మూల D7–4 కవలల సంభావ్యతకు supporting factor',
        conditions: 'PDF p.26 D7–4: BS/KS ద్విస్వభావ రాశి లేదా సంబంధిత గ్రహ/రాహు–కేతు సంబంధాలు. '
            'ఇక్కడ ద్విస్వభావ రాశి షరతును మాత్రమే పరీక్షిస్తున్నాం.',
        actual: 'BS D7=${_signNameTe(bsD7)}; KS D7=${_signNameTe(ksD7)}; '
            'dual = మిథునం/కన్య/ధనుస్సు/మీనం.',
        page: 26,
      );
    }
    final d7LagnaRashiLord = _signLord(v.ascendantSignIndex);
    final natalPlanet = chart.planets.where((p) => p.name == d7LagnaRashiLord).toList();
    final d7LagnaLordDualD1 = natalPlanet.isNotEmpty &&
        dualSigns.contains(natalPlanet.first.signIndex);
    final d7LagnaLordDualD9 = natalPlanet.isNotEmpty &&
        dualSigns.contains(VargaService.signForLongitude(natalPlanet.first.longitude, 9));
    final d7LagnaLordDualD7 = dualSigns.contains(d7Sign(d7LagnaRashiLord));
    verifiedRow(
      id: 'D7-TWINS-002',
      topic: 'కవలలు — సప్తాంశ లగ్నాధిపతి ద్విస్వభావ సంబంధం',
      matches: d7LagnaLordDualD1 || d7LagnaLordDualD9 || d7LagnaLordDualD7,
      traditionalMeaning: 'మూల D7–5 పద్ధతిలో కవలల సూచనకు ఒక supporting factor',
      conditions: 'PDF p.26 D7–5: D7 లగ్నాధిపతి D1, D9 లేదా D7లో ద్విస్వభావ రాశిలో '
          'ఉండటం; ఇతర యోగాలను విడిగా సమీక్షించాలి.',
      actual: 'D7 lagna lord=$d7LagnaRashiLord; '
          'D1 dual=$d7LagnaLordDualD1; D9 dual=$d7LagnaLordDualD9; D7 dual=$d7LagnaLordDualD7.',
      page: 26,
    );

    // Exact source-based comfort/luxury combinations, source pp.18–19.
    if (['Sun', 'Moon', 'Mars', 'Jupiter', 'Venus'].every(lonByName.containsKey)) {
      double mod360(double x) => ((x % 360) + 360) % 360;
      final bsSign = VargaService.signForLongitude(mod360(lonByName['Sun']! + lonByName['Venus']! + lonByName['Jupiter']!), 7);
      final ksSign = VargaService.signForLongitude(mod360(lonByName['Moon']! + lonByName['Mars']! + lonByName['Jupiter']!), 7);
      int spHouse(int sign) => ((sign - v.ascendantSignIndex + 12) % 12) + 1;
      final bsHouse = spHouse(bsSign);
      final ksHouse = spHouse(ksSign);
      const kendraTrikona = {1, 4, 5, 7, 9, 10};
      verifiedRow(
        id: 'D7-LUX-001',
        topic: 'సుఖభోగాలు — బీజ/క్షేత్ర స్ఫుట కేంద్రత్రికోణం',
        matches: kendraTrikona.contains(bsHouse) && kendraTrikona.contains(ksHouse),
        traditionalMeaning: 'మూల సుఖభోగ 1/3 నియమాల అనుకూల స్థాన ఆధారం',
        conditions: 'PDF p.19: BS/KS స్ఫుటాలు D7 కేంద్రము లేదా త్రికోణంలో ఉండటం ఒక అనుకూల layer; '
            'పాపగ్రహ సంబంధం, త్రిక స్థాన షరతులను విడిగా కూడా చూడాలి.',
        actual: 'BS D7=${_signNameTe(bsSign)} H$bsHouse; '
            'KS D7=${_signNameTe(ksSign)} H$ksHouse; Kendra/Trikona=$kendraTrikona.',
        page: 19,
      );
      final spSaturnInfluence =
          isRelated('Saturn', bsHouse) || isRelated('Saturn', ksHouse);
      verifiedRow(
        id: 'D7-LUX-002',
        topic: 'సుఖభోగాలు — స్ఫుటంపై శని ప్రభావం',
        matches: spSaturnInfluence,
        traditionalMeaning: 'మూల సుఖభోగ–4 ప్రకారం సౌకర్యాల విషయంలో తగ్గుదల/జాగ్రత్త సూచన',
        conditions: 'PDF p.19 సుఖభోగ–4: స్ఫుటంపై శని దృష్టి లేదా సంబంధం.',
        actual: 'BS H$bsHouse; KS H$ksHouse; Saturn H${d7House('Saturn')}; '
            'Saturn relationship=$spSaturnInfluence.',
        page: 19, tone: VargaRuleTone.caution,
      );
      final bsLord = _signLord(bsSign);
      final ksLord = _signLord(ksSign);
      verifiedRow(
        id: 'D7-LUX-003',
        topic: 'సుఖభోగాలు — స్ఫుటాధిపతి బలం',
        matches: kendraTrikona.contains(d7House(bsLord)) ||
            kendraTrikona.contains(d7House(ksLord)),
        traditionalMeaning: 'మూల సుఖభోగ–5లో స్ఫుటాధిపతి కేంద్ర/త్రికోణ సంబంధం',
        conditions: 'PDF p.19 సుఖభోగ–5: స్ఫుటాధిపతి కేంద్ర లేదా త్రికోణంలో ఉండటం.',
        actual: 'BS lord=$bsLord H${d7House(bsLord)}; '
            'KS lord=$ksLord H${d7House(ksLord)}.',
        page: 19,
      );
    }

    // The 84 body/nature descriptions are in the *birth-sign* + exact 1..7
    // amsha table, not merely the derived D7 Lagna sign. We can auto-fire
    // a faithfully transcribed row only where that actual row was checked.
    final birthAscSign = chart.ascendantSignIndex;
    final amshaPart = ((chart.ascendantLongitude % 30.0) / (30.0 / 7.0))
        .floor().clamp(0, 6).toInt() + 1;
    const exactBodyRows = <int, List<String>>{
      0: [
        'సన్నని బలహీన శరీరం; ఎర్రని కంటి కోనలు; ఉగ్ర స్వభావం',
        'కాంతివంతమైన చర్మం, విశాల నేత్రాలు; కళా ఆసక్తి',
        'విశాల కళ్ళు; నిటారుగా నిలిచే దేహభంగిమ; ఆధ్యాత్మిక ఆసక్తి',
        'వాలిన భుజాలు, విశాల భావనలు; సంగీత జ్ఞానం',
        'పొడవైన తెల్లని వ్యక్తిత్వం, విశాల శిరస్సు; గౌరవపూర్వక స్వభావం',
        'దృఢమైన అవయవాలు; క్రీడలు, వాద్యసంగీతంలో ఆసక్తి',
        'పెద్ద కళ్ళు, దృఢమైన పక్క; భావోద్వేగ స్వభావం',
      ],
      1: [
        'కాంతివంతమైన వర్ణం, సన్నని కళ్ళు; అందమైన ముఖం',
        'దృఢమైన కండరాలు, పొడవైన శరీరం; ధనాశ',
        'సన్నని, ఎర్రని శరీరం; ఉత్సాహం',
        'ఎత్తైన నాసిక, బంగారు వర్ణం; మృదుస్వభావం',
        'అందమైన తెల్లని వ్యక్తిత్వం; క్రమశిక్షణ',
        'అందమైన విశాల శరీరం; భావవ్యక్తీకరణ',
        'నల్లని/కళాభిరుచి కలిగిన అవయవాలు; ధైర్య స్వభావం',
      ],
    };
    final sourcePage = birthAscSign == 0 && amshaPart <= 5 ? 9 :
        birthAscSign <= 2 ? 10 : birthAscSign <= 4 ? 11 :
        birthAscSign <= 6 ? 12 : birthAscSign <= 8 ? 13 :
        birthAscSign <= 10 ? 14 : 15;
    final sourceRow = exactBodyRows[birthAscSign];
    if (sourceRow != null) {
      verifiedRow(
        id: 'D7-FORM-${(birthAscSign + 1).toString().padLeft(2,'0')}-${amshaPart.toString().padLeft(2,'0')}',
        topic: 'శరీర ఆకృతి / స్వభావం — జన్మలగ్న సప్తాంశం $amshaPart',
        matches: true,
        traditionalMeaning: sourceRow[amshaPart - 1],
        conditions: 'PDF pp.9–10: జన్మలగ్న రాశి, 30°లో పడిన 1–7వ సప్తాంశాన్ని కలిపి '
            'సరైన శరీర ఆకృతి–స్వభావపు rowను తీసుకోవాలి. '
            'శరీర సూచనలు సంప్రదాయ పదప్రయోగాలు; వ్యక్తిత్వాన్ని నిర్ధారించవు.',
        actual: 'D1 Lagna=${_signNameTe(birthAscSign)}; '
            'D1 degree=${(chart.ascendantLongitude % 30.0).toStringAsFixed(4)}°, '
            'D7 amsha=$amshaPart, D7 lagna=${_signNameTe(v.ascendantSignIndex)}.',
        page: sourcePage, tone: VargaRuleTone.neutral,
      );
    } else {
      add(
        id: 'D7-FORM-AUDIT',
        topic: 'శరీర ఆకృతి / స్వభావం — $amshaPart వ సప్తాంశం',
        result: 'జన్మలగ్న రాశి ${_signNameTe(birthAscSign)}; సప్తాంశం $amshaPart. '
            'గ్రంథంలో వివరాలు ఉన్నాయి; ఆ ప్రత్యేక row పదాలు ఇంకా పూర్తిగా '
            'ట్రాన్స్‌క్రైబ్/సరిచూడలేదు. ఫలితం ఊహించి చూపించము.',
        rule: 'జన్మలగ్న రాశి + 30/7° భాగాన్ని గ్రంథం pp.9–15 పట్టికలో matching rowకి కలపాలి.',
        inspection: 'D1 degree=${(chart.ascendantLongitude % 30.0).toStringAsFixed(4)}°, '
            'amsha=$amshaPart, sign=${_signNameTe(birthAscSign)}.',
        source: 'Saptamsha_Santana_Niyamalu.pdf p.$sourcePage.',
        tone: VargaRuleTone.info, applicable: false, auto: false,
      );
    }

    sourceOnly(
      'D7-SRC-001',
      'BS/KS అదనపు యోగాలు — 6/8/12, త్రికోణ సంబంధం',
      'మూల BS/KS గణన ఇప్పుడు D7-SANTANA-017/018 ద్వారా అమలులో ఉంది. కానీ BS/KS అధిపతి/లగ్నాధిపతి నుంచి 6/8/12, త్రికోణ, కేంద్రము, శుభ/పాప సంబంధాలన్నీ వేరుగా validate చేయాలి.',
      'Saptamsha_Santana_Niyamalu.pdf pp.5–7.',
    );
    sourceOnly(
      'D7-SRC-002',
      'సంతాన సంఖ్య / Order of Children',
      'Sourceలో child-count/order rules ఉన్నాయి. Exact countను ఒక్క generic D7 house patternతో నిర్ణయించకుండా source-defined sequence, BS/KS, 5H/5L, Jupiter మరియు timing layersతో మాత్రమే ఇవ్వాలి.',
      'Saptamsha_Santana_Niyamalu.pdf pp.15–18, 20–22.',
    );
    sourceOnly(
      'D7-SRC-003',
      '12 రాశులు × 7 సప్తాంశ లగ్న భాగాల ఫలిత పట్టిక',
      'Source pp.9–15లో మేషం నుంచి మీనం వరకు లగ్నానికి సంబంధించిన 1–7 సప్తాంశ భాగాల row-wise ఫలితాలు ఉన్నాయి. 84 rowsను ధృవీకరించిన lookupతో మాత్రమే auto-fire చేయాలి; సాధారణ గ్రహ రాశి ఫలితాలతో కలపకూడదు.',
      'Saptamsha_Santana_Niyamalu.pdf pp.9–15.',
    );
    sourceOnly(
      'D7-SRC-004',
      'Gender-specific child indication',
      'Sourceలో gender-specific rows ఉన్నాయి; app prenatal sex/gender determinationగా ఉపయోగించదు. Historical/source auditగా మాత్రమే ఉంచాలి.',
      'Saptamsha_Santana_Niyamalu.pdf pp.5–8.',
      note: 'Sourceలో rule ఉంది; prenatal sex determination/medical claimగా app చూపించదు.',
    );
    sourceOnly(
      'D7-SRC-005',
      'Denial / No-child sensitive rows',
      'Source denial rulesను multiple independent confirmationsతో మాత్రమే audit చేయాలి; ఒక్క ruleతో deterministic “సంతానం లేదు” verdict ఇవ్వకూడదు.',
      'Saptamsha_Santana_Niyamalu.pdf pp.17–18.',
      note: 'Sensitive source section preserved. App deterministic denial verdict ఇవ్వదు; supportive/obstructive evidence మాత్రమే చూపిస్తుంది.',
    );
    sourceOnly(
      'D7-SRC-006',
      'Child longevity / lifespan sensitive rows',
      'Sourceలో longevity-sensitive child rows ఉన్నాయి; app lifespan/death predictionను deterministic client resultగా ఇవ్వదు.',
      'Saptamsha_Santana_Niyamalu.pdf pp.23–25.',
      note: 'Sensitive source section preserved; app wellbeing/vitality evidenceగా మాత్రమే safe transform చేస్తుంది.',
    );
    sourceOnly(
      'D7-SRC-007',
      'BAV విస్తృత పద్ధతులు — అనేక గ్రహ బిందు క్రమాలు',
      'గురువు నుంచి 5వ రాశికి గురు BAV బిందువులు ఇప్పుడు D7-SANTANA-020లో లెక్కిస్తున్నాం. కానీ sourceలోని 4/5 బిందువుల నిర్దిష్ట గ్రహ క్రమం, మొదటి/రెండో సంతాన పద్ధతులు వేరుగా ధృవీకరించాలి.',
      'Saptamsha_Santana_Niyamalu.pdf pp.27–28.',
    );
  }

  static void _d9(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 7,
      favorableId: 'S7-D9-01',
      cautionId: 'S7-D9-02',
      topic: 'వివాహ వాగ్దానం',
      favorableResult: 'D9 7వ భావంలో శుభగ్రహ support ఉంది; వివాహ/భాగస్వామ్యానికి అనుకూల layer.',
      cautionResult: 'D9 7వ భావంలో పాపగ్రహ ప్రభావం ఉంది; సంబంధాన్ని ఇతర factorsతో జాగ్రత్తగా చూడాలి.',
      rule: 'D9లో 7వ భావం, 7వ అధిపతి, దారాకారక/జ్ఞాతికారక సంబంధాన్ని వివాహానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D9, supplied “Sarala 7 final.pdf” p.6',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D9-03',
      cautionId: 'S7-D9-04',
      topic: 'ధర్మం / నైతిక దిశ',
      favorableResult: 'D9 9వ భావంలో శుభగ్రహ support ఉంది; ధర్మ/గురు/నైతికతకు అనుకూల layer.',
      cautionResult: 'D9 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ధర్మ/గురు అంశంలో జాగ్రత్త layer.',
      rule: 'D9 9వ భావం, 9వ అధిపతి, గురువును ధర్మ ఫలానికి పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D9, supplied “Sarala 7 final.pdf” pp.6–7',
      add: add,
    );
  }

  static void _d10(
    AstroChartResult chart,
    VargaChartData v,
    DateTime? birthDateTime,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    final d9 = VargaService.calculate(chart, 9);
    final d10LagnaSign = v.ascendantSignIndex;
    final d10TenthSign = _houseSign(v, 10);
    final d10TenthLord = _signLord(d10TenthSign);
    final d10TenthLordPlacement = v.planets.firstWhere((p) => p.name == d10TenthLord);
    final d10TenthLordHouse = _houseOf(v, d10TenthLordPlacement);
    final d10FirstLord = _signLord(d10LagnaSign);
    final d10ThirdLord = _signLord(_houseSign(v, 3));
    final d10EleventhLord = _signLord(_houseSign(v, 11));
    final d10SeventhLord = _signLord(_houseSign(v, 7));
    final d1TenthSign = (chart.ascendantSignIndex + 9) % 12;
    final d1TenthLord = _signLord(d1TenthSign);
    final d9TenthLord = _signLord(_houseSign(d9, 10));
    final d10LagnaNames = _houseNames(v, 1);
    final fourthNames = _houseNames(v, 4);
    final tenthNames = _houseNames(v, 10);
    final seventhNames = _houseNames(v, 7);
    final thirdNames = _houseNames(v, 3);
    final twelfthNames = _houseNames(v, 12);
    final eighthNames = _houseNames(v, 8);
    final tenthBenefics = tenthNames.where(_benefics.contains).toList();
    final tenthMalefics = tenthNames.where(_malefics.contains).toList();
    final saturnStream = D10CareerService.saturnStream(chart);
    final d10TenthLordNatal = chart.planets.firstWhere((p) => p.name == d10TenthLord);
    final careerDevata = D10CareerService.devataForLongitude(d10TenthLordNatal.longitude);
    final lagnaDevata = D10CareerService.devataForLongitude(chart.ascendantLongitude);
    final careerWindows = birthDateTime == null
        ? const <D10CareerWindow>[]
        : D10CareerService.timingWindows(chart: chart, birthDateTime: birthDateTime);
    final finalProfession = D10FinalProfessionEngine.evaluate(chart: chart, d10: v);

    final finalTop = finalProfession.candidates
        .where((x) => x.natureCompatibility.endsWith('Match'))
        .take(8)
        .toList(growable: false);
    final finalVisible = finalTop.isNotEmpty
        ? finalTop
        : finalProfession.candidates.take(8).toList(growable: false);
    add(
      id: 'D10-FINAL-MASTER-PROF',
      topic: 'FINAL — అనుకూల వృత్తులు / Career Suitability',
      result: finalVisible.isEmpty
          ? 'Independent evidence blocksలో profession family match కాలేదు.'
          : finalVisible.map((x) => '${x.profession} — ${x.evidenceMatchPercent}%').join(' • '),
      rule: 'User-final D10 formula: 10వ భావాధిపతి వృత్తులు + 10L స్థితి పొందిన D10 నక్షత్ర వృత్తులు + 10L D10 రాశి వృత్తులు + 10Lతో కలిసి ఉన్న గ్రహాల వృత్తులు → Profession Family Merge → independent Evidence Match %. Technical/Semi-Technical/Non-Technical రాశి nature percentage block కాదు; profession విధానం/filter మాత్రమే. Amsha Devata professionను సృష్టించదు లేదా %ను మార్చదు; వచ్చిన profession యొక్క work-flow/styleను మాత్రమే modify చేస్తుంది.',
      inspection: '10L ${finalProfession.tenthLord} • D10 రాశి ${finalProfession.tenthLordSignName} (${finalProfession.professionNature}) • D10 longitude ${finalProfession.d10TenthLordLongitude.toStringAsFixed(4)}° • Nakshatra ${finalProfession.nakshatraName} (${finalProfession.nakshatraLord}) • conjunctions: ${finalProfession.conjunctions.isEmpty ? 'లేవు' : finalProfession.conjunctions.join(', ')} • Devata ${finalProfession.amshaDevata.deity}. Top evidence: ${finalVisible.take(4).map((x) => '${x.profession}: ${x.matchedEvidence.join(' + ')} / ${x.availableEvidenceBlocks} blocks').join(' | ')}.',
      source: 'User-final D10 profession formula + uploaded 27 Nakshatra source-derived profession tags + supplied D10 profession/sign/Devata rule registries.',
      tone: finalVisible.any((x) => x.evidenceMatchPercent >= 75) ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Career Suitability % అనేది evidence coverage మాత్రమే; probability కాదు. Qualification, skill, experience, opportunity, income model మరియు practical constraintsతో కలిపి నిర్ణయించాలి.',
    );

    add(
      id: 'D10-FINAL-MASTER-NATURE',
      topic: 'FINAL — వృత్తి విధానం / Nature + Amsha Devata',
      result: '${finalProfession.professionNature} profession nature. 10L ${finalProfession.tenthLord} ${finalProfession.tenthLordSignName}లో ఉంది. Amsha Devata: ${finalProfession.amshaDevata.deity} (${finalProfession.amshaDevata.direction}). Work Flow: ${finalProfession.amshaDevata.workflowModifier}',
      rule: 'User-locked sign classification: Technical = మేషం, వృశ్చికం, మకరం, కుంభం; Semi-Technical = మిథునం, సింహం, కన్య; Non-Technical = వృషభం, కర్కాటకం, తుల, ధనుస్సు, మీనం. Nature profession nameను కొత్తగా సృష్టించదు; candidate profession ఎలా వ్యక్తమవుతుందో filter చేస్తుంది. Devata status/style modifier మాత్రమే.',
      inspection: '10L sign index ${finalProfession.tenthLordSignIndex + 1}. Devata source nature: ${finalProfession.amshaDevata.sourceMeaning} Work-flow modifier: ${finalProfession.amshaDevata.workflowModifier}. Broad profession groups source-audit కోసం మాత్రమే: ${finalProfession.amshaDevata.professionGroups.isEmpty ? 'narrow profession list లేదు' : finalProfession.amshaDevata.professionGroups.join(', ')}.',
      source: 'User-supplied D10 sign-nature classification + supplied Dashamsha Devata rules.',
      tone: VargaRuleTone.favorable,
      applicable: true,
    );

    final workflowProfessions = finalVisible.take(4).map((x) => x.profession).join(' • ');
    add(
      id: 'D10-FINAL-WORKFLOW',
      topic: 'FINAL — వృత్తి + పని విధానం / Career Interpretation',
      result: finalVisible.isEmpty
          ? 'Profession family evidence లేకుండా Devata ఒక్కటితో వృత్తి ప్రకటించము. Work-flow modifier: ${finalProfession.amshaDevata.workflowModifier}'
          : 'ప్రధాన అనుకూల వృత్తులు: $workflowProfessions. ${finalProfession.professionNature} natureలో ${finalProfession.amshaDevata.deity} Devata స్వభావం వల్ల పని విధానం: ${finalProfession.amshaDevata.workflowModifier}',
      rule: 'Final interpretation = ఇప్పటికే D10 evidence ద్వారా ఎంపికైన profession families + sign nature + Amsha Devata work-flow modifier. Devata కొత్త professionను జోడించదు, Evidence Match %ను మార్చదు, profession rankingను reorder చేయదు.',
      inspection: 'Selected professions: ${finalVisible.take(6).map((x) => '${x.profession} ${x.evidenceMatchPercent}%').join(' | ')}. Devata ${finalProfession.amshaDevata.deity}: ${finalProfession.amshaDevata.sourceMeaning}',
      source: 'User-approved D10 Final Master Profession formula + supplied Dashamsha Devata source layer.',
      tone: finalVisible.isEmpty ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    add(
      id: 'D10-FINAL-STRENGTH-QUALITY',
      topic: 'FINAL — Graha Strength / Result Quality',
      result: 'Career Suitability %, BPHS Graha-Avastha Strength, Brihat Jataka Result Quality మూడు వేర్వేరు layers. Shayanadi arithmetic engine sourceలో చేర్చబడింది; exact local sunrise నుంచి Birth Ghati మరియు validated Name Anka లభించినప్పుడే Drishti/Cheshta/Vicheshta auto-result ఇవ్వాలి.',
      rule: 'Profession Selection → Evidence Match % → Nature/Devata modifier → BPHS Balaadi/Jagradadi/Deeptadi/Lajjitadi/Shayanadi strength → Brihat Jataka Chapter 8 quality. Avastha/BJ statesను arbitrary +/− percentageగా Career Suitabilityలో కలపకూడదు.',
      inspection: 'Shayanadi calculator: T=(S×P×N)+J+G+L → mod12; sub-state=(A²+NameAnka) mod12 + planet additive → mod3. Current varga panel birth inputలో exact sunrise-ghati/name-anka validated mapper అందుబాటులో లేనప్పుడు engine resultను ఊహించదు.',
      source: 'BPHS Chapter 45 Graha Avastha supplied PDF + BPHS Shayanadi arithmetic implementation spec + Brihat Jataka Chapter 8 supplied rule engine.',
      tone: VargaRuleTone.info,
      applicable: true,
      auto: false,
      remedy: 'Source arithmetic పూర్తిగా లభించిన layerకే auto-result. Missing sunrise/name-anka/BJ exact state conditionను default valueతో నింపకూడదు.',
    );


    ({int score, String why}) professionScore(List<String> group) {
      var score = 0;
      final why = <String>[];
      if (group.contains(d10TenthLord)) {
        score += 30;
        why.add('D10 10వ అధిపతి $d10TenthLord match');
      }
      final tenthMatch = tenthNames.where(group.contains).toList();
      if (tenthMatch.isNotEmpty) {
        score += 25;
        why.add('D10 10వ భావంలో ${tenthMatch.join(', ')}');
      }
      final lagnaNames = _houseNames(v, 1);
      final lagnaMatch = lagnaNames.where(group.contains).toList();
      if (lagnaMatch.isNotEmpty) {
        score += 15;
        why.add('D10 లగ్నంలో ${lagnaMatch.join(', ')}');
      }
      if (group.contains(d1TenthLord)) {
        score += 15;
        why.add('D1 10వ అధిపతి $d1TenthLord match');
      }
      if (group.contains(d9TenthLord)) {
        score += 10;
        why.add('D9 10వ అధిపతి $d9TenthLord match');
      }
      final signType = switch (d10TenthSign) {
        0 || 7 || 9 || 10 => 'technical',
        2 || 4 || 5 => 'semitechnical',
        _ => 'nontechnical',
      };
      final typeMatch =
          (group.any((g) => const ['Mars', 'Saturn', 'Rahu'].contains(g)) && signType == 'technical') ||
          (group.any((g) => const ['Sun', 'Mercury'].contains(g)) && signType == 'semitechnical') ||
          (group.any((g) => const ['Moon', 'Jupiter', 'Venus'].contains(g)) && signType == 'nontechnical');
      if (typeMatch) {
        score += 5;
        why.add('D10 10వ రాశి classification: $signType');
      }
      return (score: score.clamp(0, 100).toInt(), why: why.isEmpty ? 'source-backed matching indicator స్పష్టంగా లేదు' : why.join(' • '));
    }

    // Build 51 — D10 foundational result layer from the supplied D10 Basics
    // pages plus the user's explicit interpretation requirements.
    // Papakartari operational check = both adjacent houses contain at least
    // one natural malefic. This deterministic mapping is shown in the audit
    // trail and is not presented as a universal strength formula.
    int prevHouse(int house) => house == 1 ? 12 : house - 1;
    int nextHouse(int house) => house == 12 ? 1 : house + 1;
    List<String> maleficsInHouse(int house) =>
        _houseNames(v, house).where(_malefics.contains).toList(growable: false);
    List<String> beneficsInHouse(int house) =>
        _houseNames(v, house).where(_benefics.contains).toList(growable: false);
    bool papaKartari(int house) =>
        maleficsInHouse(prevHouse(house)).isNotEmpty &&
        maleficsInHouse(nextHouse(house)).isNotEmpty;
    List<String> conjunctionsOf(String planet) {
      final p = v.planets.firstWhere((x) => x.name == planet);
      return v.planets
          .where((x) => x.name != planet && x.signIndex == p.signIndex)
          .map((x) => x.name)
          .toList(growable: false);
    }

    final lagnaMalefics = d10LagnaNames.where(_malefics.contains).toList();
    final lagnaPapakartari = papaKartari(1);
    final lagnaAfflicted = lagnaMalefics.isNotEmpty || lagnaPapakartari;
    final lagnaAdjacentMalefics = <String>{
      ...maleficsInHouse(12),
      ...maleficsInHouse(2),
    }.toList();
    add(
      id: 'D10-BASE-01',
      topic: 'D10 లగ్నం — వృత్తిపై కోరిక / ఆసక్తి',
      result: lagnaAfflicted
          ? 'D10 లగ్నం పాపగ్రహ/పాపకర్తరీ ప్రభావంలో ఉంది. ఈ source interpretation ప్రకారం పనిమీద ఆసక్తి తగ్గడం, నిరాసక్తి లేదా కర్మలో అడ్డంకులు వచ్చే జాగ్రత్త layer.'
          : 'D10 లగ్నంపై ఈ evaluatorలో direct పాపగ్రహ లేదా పాపకర్తరీ దెబ్బ కనిపించలేదు; వృత్తిపై కోరిక/ఆసక్తిని నిలబెట్టుకునే అనుకూల layer.',
      rule: 'D10 Lagna ఈ జీవితంలోని karma చేయాలనే intention/aspirationను చూపుతుంది. లగ్నంలో పాపగ్రహాలు లేదా పాపకర్తరీ ఉంటే వృత్తిపై ఆసక్తి/ప్రవర్తన దెబ్బతినే layerగా చూడాలి. ప్రభావం ఏ గ్రహాల వల్ల వచ్చిందో అదే auditలో చూపాలి.',
      inspection: 'D10 Lagna ${_d10SignNames[d10LagnaSign]}. లగ్నంలో: ${d10LagnaNames.isEmpty ? 'గ్రహాలు లేవు' : d10LagnaNames.join(', ')}. పాపగ్రహాలు: ${lagnaMalefics.isEmpty ? 'లేవు' : lagnaMalefics.join(', ')}. పాపకర్తరీ: ${lagnaPapakartari ? 'అవును — పక్క భావాల పాపగ్రహాలు ${lagnaAdjacentMalefics.join(', ')}' : 'లేదు'}.',
      source: 'D10 special.pdf — Chapter 02 Basics, “Lagan” and “First house” (uploaded PDF pp.58–61 / printed pp.11–14). User-supplied D10 interpretation for malefic/Papakartari impact.',
      tone: lagnaAfflicted ? VargaRuleTone.caution : VargaRuleTone.favorable,
      applicable: true,
      remedy: 'ఇది వృత్తి ఆసక్తి/కర్మ patternకు జ్యోతిష్య సూచన మాత్రమే. Practicalగా ఆసక్తి తగ్గితే పని రకం, నైపుణ్యం, పని వాతావరణం, విశ్రాంతి మరియు మార్గదర్శకత్వాన్ని పరిశీలించాలి; source-specific పరిహారం ఉంటేనే విడిగా చూపాలి.',
    );

    final lagnaLord = d10FirstLord;
    final lagnaLordPlacement = v.planets.firstWhere((p) => p.name == lagnaLord);
    final lagnaLordHouse = _houseOf(v, lagnaLordPlacement);
    final lagnaLordConjunctions = conjunctionsOf(lagnaLord);
    final lagnaLordMalConj = lagnaLordConjunctions.where(_malefics.contains).toList();
    final lagnaLordPapakartari = papaKartari(lagnaLordHouse);
    final lagnaLordAfflicted = lagnaLordMalConj.isNotEmpty || lagnaLordPapakartari;
    add(
      id: 'D10-BASE-02',
      topic: 'D10 లగ్నాధిపతి — స్వయంకృత వృత్తి సమస్యలు',
      result: lagnaLordAfflicted
          ? 'D10 లగ్నాధిపతి దెబ్బతిన్న layer కనిపిస్తోంది. మీరు ఇచ్చిన rule ప్రకారం జాతకుడు స్వయంగా తీసుకునే నిర్ణయాలు/ప్రవర్తన వల్ల వృత్తిలో సమస్యలు తెచ్చుకునే అవకాశం పరిశీలించాలి; లగ్నాధిపతి ఉన్న భావం మరియు కలిసిన గ్రహాల అంశాలు కారణాన్ని చూపుతాయి.'
          : 'D10 లగ్నాధిపతికి direct పాపగ్రహ conjunction లేదా పాపకర్తరీ ఈ evaluatorలో కనిపించలేదు; స్వయంకృత అడ్డంకి strong match కాలేదు.',
      rule: 'D10 Lagna lord జాతకుడు తన karmaను ఎలా execute చేస్తాడో చూపుతుంది. లగ్నాధిపతి పాపగ్రహ కలయిక/పాపకర్తరీతో దెబ్బతింటే self-created professional difficultyగా చదవాలి; అది ఉన్న భావం మరియు conjunction planets వల్ల ఏ అంశాల ద్వారా సమస్య వస్తుందో audit చేయాలి.',
      inspection: 'లగ్నాధిపతి $lagnaLord • D10లో $lagnaLordHouseవ భావం • కలిసిన గ్రహాలు: ${lagnaLordConjunctions.isEmpty ? 'లేవు' : lagnaLordConjunctions.join(', ')} • పాప కలయిక: ${lagnaLordMalConj.isEmpty ? 'లేదు' : lagnaLordMalConj.join(', ')} • పాపకర్తరీ: ${lagnaLordPapakartari ? 'అవును' : 'లేదు'}.',
      source: 'D10 special.pdf — Chapter 02 Basics, “Lagan/First house” (uploaded PDF pp.58–61 / printed pp.11–14). User-supplied Lagna-lord self-created-problem interpretation.',
      tone: lagnaLordAfflicted ? VargaRuleTone.caution : VargaRuleTone.favorable,
      applicable: true,
      remedy: 'లగ్నాధిపతి resultను blameగా కాకుండా decision-pattern auditగా వాడాలి. పెద్ద career నిర్ణయాల్లో రెండో అభిప్రాయం, written plan, skill-gap check మరియు financial-risk check ఉపయోగపడతాయి.',
    );

    final fourthBenefics = beneficsInHouse(4);
    final fourthMalefics = maleficsInHouse(4);
    final fourthLord = _signLord(_houseSign(v, 4));
    final fourthLordPlacement = v.planets.firstWhere((p) => p.name == fourthLord);
    final fourthLordHouse = _houseOf(v, fourthLordPlacement);
    final fourthPapakartari = papaKartari(4);
    final fourthComfortCaution = fourthPapakartari ||
        (fourthMalefics.isNotEmpty && fourthBenefics.isEmpty) ||
        const {6, 8, 12}.contains(fourthLordHouse);
    add(
      id: 'D10-BASE-03',
      topic: 'D10 4వ భావం — వృత్తిలో సుఖం / పని వాతావరణం',
      result: fourthComfortCaution
          ? 'D10 4వ భావంలో comfort/acceptance layer జాగ్రత్తగా ఉంది. వృత్తిలో సుఖం, office/work-location comfort లేదా recognitionలో ఇబ్బందులు అనుభవించే సూచనగా చూడాలి.'
          : 'D10 4వ భావం comfort/acceptance layerకు అనుకూల support ఉంది; వృత్తిలో పని వాతావరణం, గుర్తింపు, సుఖం మెరుగ్గా ఉండే సూచన.',
      rule: 'D10 4వ భావం professionలో happiness/acceptance, recognition of talents మరియు office/location of businessను చూపుతుంది. 4వ భావం/4L దెబ్బతింటే వృత్తి సుఖం తగ్గే layerగా చూడాలి.',
      inspection: 'D10 4వ భావం: ${fourthNames.isEmpty ? 'గ్రహాలు లేవు' : fourthNames.join(', ')} • శుభగ్రహాలు: ${fourthBenefics.isEmpty ? 'లేవు' : fourthBenefics.join(', ')} • పాపగ్రహాలు: ${fourthMalefics.isEmpty ? 'లేవు' : fourthMalefics.join(', ')} • 4L $fourthLord → $fourthLordHouseవ భావం • పాపకర్తరీ: ${fourthPapakartari ? 'అవును' : 'లేదు'}.',
      source: 'D10 special.pdf — Chapter 02 Basics, Fourth house (uploaded PDF pp.61–62 / printed pp.14–15; detailed example printed p.22).',
      tone: fourthComfortCaution ? VargaRuleTone.caution : VargaRuleTone.favorable,
      applicable: true,
      remedy: 'వృత్తి సుఖం తగ్గినప్పుడు practicalగా work environment, location, reporting structure, commute, workload మరియు role-fitను సరిచూడాలి. Source-specific spiritual remedy ఉంటేనే అదనంగా చూపాలి.',
    );

    final seventhBenefics = beneficsInHouse(7);
    final seventhMalefics = maleficsInHouse(7);
    final seventhLordPlacement = v.planets.firstWhere((p) => p.name == d10SeventhLord);
    final seventhLordHouse = _houseOf(v, seventhLordPlacement);
    final seventhPapakartari = papaKartari(7);
    final sunInSeventh = seventhNames.contains('Sun');
    final seventhCaution = seventhPapakartari ||
        (seventhMalefics.isNotEmpty && seventhBenefics.isEmpty && !sunInSeventh);
    add(
      id: 'D10-BASE-04',
      topic: 'D10 7వ భావం — 10వ నుండి 10వ / వృత్తి ఆత్మ',
      result: seventhCaution
          ? 'D10 7వ భావం (10వ నుండి 10వ) దెబ్బతిన్న layerలో ఉంది; public image, professional strength లేదా high-position expressionలో జాగ్రత్త అవసరం.'
          : 'D10 7వ భావం — 10వ నుండి 10వ — వృత్తి యొక్క కీలక strength/public-image layerగా support చూపుతోంది${sunInSeventh ? '; Sun 7వలో ఉండటం sourceలో directional-strength supportగా కూడా చెప్పబడింది' : ''}.',
      rule: 'D10 7వ భావం 10వ భావం నుండి 10వ భావం. Source దీన్ని ముఖ్యమైన profession houseగా, public image/high positionతో అనుసంధానిస్తుంది; Sun ఇక్కడ digbaliగా చెప్పబడింది.',
      inspection: 'D10 7వ భావం: ${seventhNames.isEmpty ? 'గ్రహాలు లేవు' : seventhNames.join(', ')} • 7L $d10SeventhLord → $seventhLordHouseవ భావం • శుభగ్రహాలు ${seventhBenefics.isEmpty ? 'లేవు' : seventhBenefics.join(', ')} • పాపగ్రహాలు ${seventhMalefics.isEmpty ? 'లేవు' : seventhMalefics.join(', ')} • పాపకర్తరీ ${seventhPapakartari ? 'అవును' : 'లేదు'}.',
      source: 'D10 special.pdf — Chapter 02 Basics, Seventh house (uploaded PDF p.62 / printed p.15).',
      tone: seventhCaution ? VargaRuleTone.caution : VargaRuleTone.favorable,
      applicable: true,
    );

    final sunD10Base = v.planets.firstWhere((p) => p.name == 'Sun');
    final sunHouseBase = _houseOf(v, sunD10Base);
    final sunConj = conjunctionsOf('Sun');
    final sunBen = sunConj.where(_benefics.contains).toList();
    final sunMal = sunConj.where((x) => _malefics.contains(x) && x != 'Sun').toList();
    final sunSupport = sunHouseBase == 7 || (sunBen.isNotEmpty && sunMal.isEmpty);
    final sunCaution = sunMal.isNotEmpty && !sunSupport;
    add(
      id: 'D10-BASE-05',
      topic: 'D10 సూర్యుడు — మంచి మార్గదర్శకులు / సహాయకులు',
      result: sunSupport
          ? 'D10 Sunకు supportive layer ఉంది; మీరు ఇచ్చిన interpretation ప్రకారం వృత్తిలో మంచి మార్గదర్శకులు/సహాయక వ్యక్తులు జత అయ్యే సూచనగా చూడవచ్చు.'
          : sunCaution
              ? 'D10 Sunపై పాపసంబంధం ఉంది; వృత్తిలో సరైన మార్గదర్శకులు/సహాయకులు ఎంపికలో జాగ్రత్తగా ఉండే layer.'
              : 'D10 Sun position/association మిశ్రమంగా ఉంది; మంచి మార్గదర్శకుల supportపై స్పష్టమైన strong auto-verdict ఇవ్వకుండా auditగా చూపుతున్నాం.',
      rule: 'మీరు ఇచ్చిన D10 interpretationలో Sun ద్వారా మంచి సహాయకులు/మార్గదర్శకులు జత అవుతారో చూడాలి. Supplied source example Sun placementకు “good guide and God grace” అనే supportను చూపుతుంది. App operational mappingలో 7వ భావ Sun లేదా same-sign benefic associationను supportగా, malefic-only associationను cautionగా చూపుతున్నాం; ఇది universal classical formula కాదు.',
      inspection: 'D10 Sun $sunHouseBaseవ భావంలో • కలిసిన గ్రహాలు: ${sunConj.isEmpty ? 'లేవు' : sunConj.join(', ')} • supportive association: ${sunBen.isEmpty ? 'లేదు' : sunBen.join(', ')} • caution association: ${sunMal.isEmpty ? 'లేదు' : sunMal.join(', ')}.',
      source: 'D10 special.pdf — Chapter 02 Basics examples (uploaded PDF p.65 / printed p.18: Sun placement gives good guide/God-grace layer) + user-supplied D10 interpretation.',
      tone: sunSupport ? VargaRuleTone.favorable : sunCaution ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    final moonD10Base = v.planets.firstWhere((p) => p.name == 'Moon');
    final moonHouseBase = _houseOf(v, moonD10Base);
    final moonConj = conjunctionsOf('Moon');
    final moonBen = moonConj.where((x) => _benefics.contains(x) && x != 'Moon').toList();
    final moonMal = moonConj.where(_malefics.contains).toList();
    final moonTone = moonBen.length > moonMal.length
        ? VargaRuleTone.favorable
        : moonMal.length > moonBen.length
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'D10-BASE-06',
      topic: 'D10 చంద్రుడు — వృత్తి మనస్సు / మానసిక స్థితి',
      result: moonTone == VargaRuleTone.favorable
          ? 'D10 Moonకు supportive associations ఎక్కువగా ఉన్నాయి; వృత్తి విషయాల్లో మనస్సు/అనుభూతి స్థిరంగా స్పందించే అనుకూల layer.'
          : moonTone == VargaRuleTone.caution
              ? 'D10 Moonపై పాపసంబంధం ఎక్కువగా ఉంది; వృత్తి విషయంలో మనస్సు ఒత్తిడి, అస్థిరత లేదా emotional strainను జాగ్రత్తగా పరిశీలించాలి.'
              : 'D10 Moon association మిశ్రమం/neutralగా ఉంది; వృత్తి మనస్సు స్థితిని Moon ఉన్న భావం మరియు సంబంధిత గ్రహాలతో కలిసి చదవాలి.',
      rule: 'మీరు ఇచ్చిన D10 interpretationలో Moon మనస్సు యొక్క స్థితిని చూపుతుంది. App deterministic layerలో Moon ఉన్న భావం మరియు same-sign benefic/malefic associationsను audit చేసి supportive/caution tone మాత్రమే ఇస్తుంది; దీనిని medical/psychological diagnosisగా చదవకూడదు.',
      inspection: 'D10 Moon $moonHouseBaseవ భావంలో • కలిసిన గ్రహాలు: ${moonConj.isEmpty ? 'లేవు' : moonConj.join(', ')} • supportive: ${moonBen.isEmpty ? 'లేదు' : moonBen.join(', ')} • caution: ${moonMal.isEmpty ? 'లేదు' : moonMal.join(', ')}.',
      source: 'D10 special.pdf — Chapter 02 Basics examples + user-supplied D10 Moon/mind interpretation.',
      tone: moonTone,
      applicable: true,
      remedy: 'ఈ Moon result జ్యోతిష్య reflection మాత్రమే, mental-health diagnosis కాదు. Stress ఎక్కువైతే sleep, workload, breaks, supportive people మరియు అవసరమైతే qualified professional supportను practicalగా చూడాలి.',
    );


    // Build 55 — Government Service + Vipareet Raja Yoga source rules.
    //
    // Government Service source boundary:
    // - D9 gives the promise through the D1 5L/9L Navamsha-sign trine rule.
    // - The uploaded Government Service chapter itself says this is not the
    //   final decider and that Dashamsha must be referred to for conclusion.
    // - Therefore the D10 layer below is labelled as supporting confirmation,
    //   not as a new "classical Government formula".
    final d1FifthSign = (chart.ascendantSignIndex + 4) % 12;
    final d1NinthSign = (chart.ascendantSignIndex + 8) % 12;
    final d1FifthLord = _signLord(d1FifthSign);
    final d1NinthLord = _signLord(d1NinthSign);
    final d9FifthLordSign =
        d9.planets.firstWhere((p) => p.name == d1FifthLord).signIndex;
    final d9NinthLordSign =
        d9.planets.firstWhere((p) => p.name == d1NinthLord).signIndex;

    bool d1TrineSign(int sign) =>
        sign == d1FifthSign || sign == d1NinthSign;

    final govRule5 = d1TrineSign(d9FifthLordSign);
    final govRule9 = d1TrineSign(d9NinthLordSign);
    final govPromiseCount = (govRule5 ? 1 : 0) + (govRule9 ? 1 : 0);

    final sunD10Gov = v.planets.firstWhere((p) => p.name == 'Sun');
    final sunD10GovHouse = _houseOf(v, sunD10Gov);
    final d10GovAuthoritySupport = careerDevata.deity == 'Indra' ||
        d10TenthLord == 'Sun' ||
        sunD10GovHouse == 10 ||
        D10CareerService.relatedVarga(v, 'Sun', d10TenthLord);

    final govModeText = switch (saturnStream.dashamsaState) {
      'AGOCHARASHTHA' =>
        'D10 Saturn service mode — direct Government/employee formకు support.',
      'GOCHARASHTHA' =>
        'D10 Saturn owner/independent mode — Government consultant/advisor/contractor formను కూడా పరిశీలించాలి.',
      _ =>
        'D10 Saturn mixed mode — direct service vs Government-linked independent workకు మరింత confirmation అవసరం.',
    };

    add(
      id: 'D10-GOV-01',
      topic: 'Government Service — 5వ అధిపతి Navamsha Rule',
      result: govRule5
          ? '🟢 Government-service promise rule match అయింది: D1 5వ అధిపతి $d1FifthLord D9లో జన్మలగ్నం నుండి 5/9 త్రికోణ రాశిలో ఉంది.'
          : 'ఈ 5వ అధిపతి Government-service promise rule match కాలేదు.',
      rule: 'Source Rule 1: జనన 5వ అధిపతి Navamshaలో పొందిన రాశి, జనన లగ్నం నుండి 5వ లేదా 9వ రాశి అయితే Government Service indication వస్తుంది.',
      inspection:
          'D1 Lagna sign ${chart.ascendantSignIndex + 1}; 5H sign ${d1FifthSign + 1}; 9H sign ${d1NinthSign + 1}; 5L $d1FifthLord → D9 sign ${d9FifthLordSign + 1}.',
      source: 'gov job.pdf — Chapter 26 Government Service, p.1 (Rule 1).',
      tone: govRule5 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఇది Government-service promise indicator మాత్రమే. Source స్వయంగా Dashamsha final confirmation అవసరమని చెబుతుంది; qualification/exam/eligibility/practical opportunityను కూడా తప్పకుండా చూడాలి.',
    );

    add(
      id: 'D10-GOV-02',
      topic: 'Government Service — 9వ అధిపతి Navamsha Rule',
      result: govRule9
          ? '🟢 Government-service/support rule match అయింది: D1 9వ అధిపతి $d1NinthLord D9లో జన్మలగ్నం నుండి 5/9 త్రికోణ రాశిలో ఉంది.'
          : 'ఈ 9వ అధిపతి Government-service/support promise rule match కాలేదు.',
      rule: 'Source Rule 2: జనన 9వ అధిపతి Navamshaలో పొందిన రాశి, జనన లగ్నం నుండి 5వ లేదా 9వ రాశి అయితే Government Service లేదా Government support indication వస్తుంది.',
      inspection:
          'D1 Lagna sign ${chart.ascendantSignIndex + 1}; 5H sign ${d1FifthSign + 1}; 9H sign ${d1NinthSign + 1}; 9L $d1NinthLord → D9 sign ${d9NinthLordSign + 1}.',
      source: 'gov job.pdf — Chapter 26 Government Service, p.1 (Rule 2).',
      tone: govRule9 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Government support అనేది direct ఉద్యోగమే కావాల్సిన అవసరం లేదు; sourceలో consultant/advisor/contractor form కూడా సూచించబడింది.',
    );

    final govD10Confirmed = govPromiseCount > 0 && d10GovAuthoritySupport;
    final govStrong = govPromiseCount == 2 && d10GovAuthoritySupport;
    final govResult = govStrong
        ? '🟢 Government promise బలంగా ఉంది (5L + 9L రెండు D9 rules) మరియు D10 authority confirmation కూడా ఉంది. $govModeText'
        : govD10Confirmed
            ? '🟢 Government promise + D10 authority support ఉంది. $govModeText'
            : govPromiseCount > 0
                ? '🟡 D9లో Government promise ఉంది; కానీ current D10 authority checkలో పూర్తి confirmation లేదు. Source ప్రకారం final conclusionకు D10ను తప్పకుండా చూడాలి.'
                : 'Government-service D9 promise rules ఈ chartలో match కాలేదు; D10 authority indicators ఒక్కటే Government jobను ప్రకటించడానికి సరిపోవు.';
    add(
      id: 'D10-GOV-03',
      topic: 'Government Service — D9 Promise → D10 Confirmation',
      result: govResult,
      rule: 'Uploaded Government Service source D9 5L/9L rulesను promiseగా ఇస్తుంది మరియు final conclusionకు Dashamsha చూడమని చెబుతుంది. D10 exact Government formula ఆ 8-page sourceలో ఇవ్వలేదు. అందువల్ల app existing source-backed D10 authority layer (Sun/10H/10L/Indra)ను supporting confirmationగా మాత్రమే ఉపయోగిస్తుంది.',
      inspection:
          'D9 promise count $govPromiseCount/2 • D10 10L $d10TenthLord • Sun H$sunD10GovHouse • 10L Devata ${careerDevata.deity} • D10 Saturn ${saturnStream.dashamsaState} • authority-support ${d10GovAuthoritySupport ? 'yes' : 'no'}.',
      source: 'gov job.pdf p.1 + D10 special.pdf / supplied D10 profession-authority rules.',
      tone: govStrong || govD10Confirmed
          ? VargaRuleTone.favorable
          : govPromiseCount > 0
              ? VargaRuleTone.neutral
              : VargaRuleTone.info,
      applicable: true,
      remedy: 'Government-job resultను career decision-supportగా మాత్రమే చూడాలి. Exam eligibility, education, age limits, vacancies, preparation మరియు actual recruitment processే practical deciding factors.',
    );

    add(
      id: 'D10-GOV-04',
      topic: 'Senior Government Position / Government-linked Role',
      result: govStrong
          ? 'Senior/authority Government roleకు source promise + D10 authority support రెండూ ఉన్నాయి; final status/timing rulesతో cross-check చేయాలి.'
          : govPromiseCount > 0 && saturnStream.dashamsaState == 'GOCHARASHTHA'
              ? 'Government-linked consultant / advisor / contractor formను కూడా పరిశీలించాలి; source Government chapter direct employee కాకపోయినా Government కోసం పని చేసే అవకాశం చెబుతుంది.'
              : govPromiseCount > 0
                  ? 'Government service/support indication ఉంది; senior-position verdictకు D10 status/rise rulesతో అదనపు confirmation అవసరం.'
                  : 'Senior Government Position ruleకు base Government promise ఈ evaluatorలో లేదు.',
      rule: 'Source examplesలో 5L/9L rules strongగా ఉన్నప్పుడు senior Government position కనిపిస్తుంది. Government chapter direct employee కాకుండా consultant/advisor/contractor possibilityను కూడా స్పష్టంగా ఉంచుతుంది.',
      inspection:
          '5L rule ${govRule5 ? '✓' : '✗'} • 9L rule ${govRule9 ? '✓' : '✗'} • D10 authority ${d10GovAuthoritySupport ? '✓' : '✗'} • mode ${saturnStream.dashamsaState}.',
      source: 'gov job.pdf pp.1–4 (Government Service rules and IAS/MNC examples).',
      tone: govStrong ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    // Vipareet Raja Yoga / Super-Strong Vipareet Raja Yoga.
    //
    // The source explicitly distinguishes the structural dusthana placement
    // from Phaladeepika's malefic-relation condition. The app therefore shows
    // "structural candidate" separately from "full source support".
    bool isDebilitatedInSign(String planet, int sign) => switch (planet) {
      'Sun' => sign == 6,      // Libra
      'Moon' => sign == 7,     // Scorpio
      'Mars' => sign == 3,     // Cancer
      'Mercury' => sign == 11, // Pisces
      'Jupiter' => sign == 9,  // Capricorn
      'Venus' => sign == 5,    // Virgo
      'Saturn' => sign == 0,   // Aries
      _ => false,
    };

    int relativeHouse(int fromHouse, int toHouse) =>
        ((toHouse - fromHouse + 12) % 12) + 1;

    List<String> relatedFromSet(String planet, Set<String> set) => set
        .where((other) =>
            other != planet &&
            D10CareerService.relatedVarga(v, planet, other))
        .toList(growable: false);

    ({String lord, int sourceHouse, int placementHouse, int sign,
      List<String> malefics, List<String> benefics})
        vipreetProfile(int sourceHouse) {
      final lord = _signLord(_houseSign(v, sourceHouse));
      final p = v.planets.firstWhere((x) => x.name == lord);
      return (
        lord: lord,
        sourceHouse: sourceHouse,
        placementHouse: _houseOf(v, p),
        sign: p.signIndex,
        malefics: relatedFromSet(lord, _malefics),
        benefics: relatedFromSet(lord, _benefics),
      );
    }

    final vp3 = vipreetProfile(3);
    final vp6 = vipreetProfile(6);
    final vp8 = vipreetProfile(8);
    final vp12 = vipreetProfile(12);

    bool fullMaleficSupport(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) =>
        p.malefics.isNotEmpty;

    bool mixedBenefic(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) =>
        p.malefics.isNotEmpty && p.benefics.isNotEmpty;

    final harshaStructure = const {8, 12}.contains(vp6.placementHouse);
    final saralaStructure = const {6, 12}.contains(vp8.placementHouse);
    final vimalaStructure = const {6, 8}.contains(vp12.placementHouse);

    void addVipreetClassic({
      required String id,
      required String name,
      required ({
        String lord,
        int sourceHouse,
        int placementHouse,
        int sign,
        List<String> malefics,
        List<String> benefics
      }) profile,
      required bool structure,
      required String placementRule,
    }) {
      final full = structure && fullMaleficSupport(profile);
      final mixed = full && mixedBenefic(profile);
      final status = !structure
          ? 'ఈ structural placement లేదు.'
          : !full
              ? 'Structural Vipareet placement ఉంది; Phaladeepika malefic-relation confirmation ఈ evaluatorలో లేదు.'
              : mixed
                  ? 'Vipareet placement + malefic relation ఉంది; benefic relation కూడా ఉండటంతో mixed/qualified result.'
                  : '🟢 Vipareet placement + malefic relation match — strong source support.';
      add(
        id: id,
        topic: '$name — D10 Career Vipareet Raja Yoga',
        result: status,
        rule: '$placementRule Phaladeepika layer: Vipareet-house lord bad houseలో ఉండి malefic conjunction/aspect పొందితే yoga result బలపడుతుంది. Benefic relation ఉంటే resultను mixed/qualifiedగా చూపాలి.',
        inspection:
            '${profile.lord} (H${profile.sourceHouse} lord) → D10 H${profile.placementHouse}, sign ${profile.sign + 1} • malefic relations: ${profile.malefics.isEmpty ? 'none' : profile.malefics.join(', ')} • benefic relations: ${profile.benefics.isEmpty ? 'none' : profile.benefics.join(', ')}.',
        source: 'vipareet raja yoga.pdf pp.1–5 (Uttar Kalamrita, Phaladeepika, BPHS/Mansagari summary).',
        tone: full && !mixed
            ? VargaRuleTone.favorable
            : structure
                ? VargaRuleTone.neutral
                : VargaRuleTone.info,
        applicable: true,
        remedy: 'ఈ yoga adversity తర్వాత rise అనే career patternకు source indicator మాత్రమే. Practical decisionsలో risk management, documentation, skill, finance మరియు timingను విడిగా చూడాలి.',
      );
    }

    addVipreetClassic(
      id: 'D10-VRY-01',
      name: 'Harsha',
      profile: vp6,
      structure: harshaStructure,
      placementRule: '6వ అధిపతి 8వ లేదా 12వ భావంలో ఉంటే Harsha-type Vipareet structural condition.',
    );
    addVipreetClassic(
      id: 'D10-VRY-02',
      name: 'Sarala',
      profile: vp8,
      structure: saralaStructure,
      placementRule: '8వ అధిపతి 6వ లేదా 12వ భావంలో ఉంటే Sarala-type Vipareet structural condition.',
    );
    addVipreetClassic(
      id: 'D10-VRY-03',
      name: 'Vimala',
      profile: vp12,
      structure: vimalaStructure,
      placementRule: '12వ అధిపతి 6వ లేదా 8వ భావంలో ఉంటే Vimala-type Vipareet structural condition.',
    );

    bool ssvyStructural(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) {
      const vipreetSet = {3, 6, 8, 12};
      return vipreetSet.contains(p.placementHouse) &&
          p.placementHouse != p.sourceHouse;
    }

    String ssvyAudit(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) {
      final structure = ssvyStructural(p);
      final fromOwnHouse =
          const {6, 8, 12}.contains(relativeHouse(p.sourceHouse, p.placementHouse));
      final deb = isDebilitatedInSign(p.lord, p.sign);
      final onlyMalefic = p.malefics.isNotEmpty && p.benefics.isEmpty;
      return 'H${p.sourceHouse}L ${p.lord} → H${p.placementHouse}: '
          'listed-vipreet ${structure ? '✓' : '✗'}, '
          '6/8/12 from own house ${fromOwnHouse ? '✓' : '✗'}, '
          'debilitation ${deb ? '✓' : '✗'} (enemy-sign variant source-only), '
          'only-malefic relation ${onlyMalefic ? '✓' : '✗'}';
    }

    bool superStrongAuto(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) {
      final structure = ssvyStructural(p);
      final fromOwnHouse =
          const {6, 8, 12}.contains(relativeHouse(p.sourceHouse, p.placementHouse));
      final signCondition = isDebilitatedInSign(p.lord, p.sign);
      final onlyMalefic = p.malefics.isNotEmpty && p.benefics.isEmpty;
      // Enemy-sign is a source condition too, but the supplied pages do not
      // include a friendship table. To avoid silently importing outside rules,
      // auto-confirmation is restricted to the explicit debilitation branch.
      return structure && fromOwnHouse && signCondition && onlyMalefic;
    }

    final ssvyProfiles = [vp3, vp6, vp8, vp12];
    final ssvyCandidates =
        ssvyProfiles.where(ssvyStructural).toList(growable: false);
    final ssvyAutoFull =
        ssvyProfiles.where(superStrongAuto).toList(growable: false);

    add(
      id: 'D10-VRY-04',
      topic: 'Super Strong Vipareet Raja Yoga — D10',
      result: ssvyAutoFull.isNotEmpty
          ? '🟢 Super-Strong Vipareet full auto-confirmation (debilitation branch) ${ssvyAutoFull.length} placement(s)లో ఉంది. D10 career significationsలో adversity తర్వాత strong rise/success patternను status/timing rulesతో cross-check చేయాలి.'
          : ssvyCandidates.isNotEmpty
              ? '🟡 Super-Strong Vipareet structural candidate ${ssvyCandidates.length} placement(s)లో ఉంది; enemy/debilitation + only-malefic పూర్తి source gate ఈ evaluatorలో పూర్తిగా confirm కాలేదు.'
              : 'Super-Strong Vipareet structural placement ఈ D10లో match కాలేదు.',
      rule: 'Source Super-Strong conditions: ఒక Vipareet lord మరో Vipareet houseలో ఉండాలి; తన source houseనుంచి కూడా 6/8/12 relation ఉండాలి; placement sign enemy లేదా debilitation కావాలి; relation only malefic కావాలి. Source later lists 3L/6L/8L/12L placements among 3/6/8/12. App enemy-sign friendship tableను outside source నుంచి import చేయదు; debilitation branch మాత్రమే auto-confirms.',
      inspection: [
        ssvyAudit(vp3),
        ssvyAudit(vp6),
        ssvyAudit(vp8),
        ssvyAudit(vp12),
      ].join(' | '),
      source: 'vipareet raja yoga.pdf pp.10–12 — Super Strong Vipreet Raj Yoga conditions and placement list.',
      tone: ssvyAutoFull.isNotEmpty
          ? VargaRuleTone.favorable
          : ssvyCandidates.isNotEmpty
              ? VargaRuleTone.neutral
              : VargaRuleTone.info,
      applicable: true,
    );

    final anyClassicStructure =
        harshaStructure || saralaStructure || vimalaStructure;
    final anyClassicFull =
        (harshaStructure && fullMaleficSupport(vp6)) ||
        (saralaStructure && fullMaleficSupport(vp8)) ||
        (vimalaStructure && fullMaleficSupport(vp12));
    add(
      id: 'D10-VRY-05',
      topic: 'Vipareet Raja Yoga — Career Effect / Timing Note',
      result: ssvyAutoFull.isNotEmpty
          ? 'D10లో Super-Strong Vipareet source support ఉంది. Source divisional-chart rule ప్రకారం D10 career/status significationsలో adversity/problems తర్వాత rise/great-success patternకు ఇది supportive layer; yoga lord Dasha/AD timingను విడిగా చూడాలి.'
          : anyClassicFull
              ? 'D10లో Vipareet Raja Yoga source support ఉంది. Careerలో ముందుగా ప్రతికూలత/సమస్యల తర్వాత recovery/rise patternను timing rulesతో చూడాలి.'
              : anyClassicStructure || ssvyCandidates.isNotEmpty
                  ? 'D10లో Vipareet structural indication ఉంది; పూర్తి yoga strength/timingకు remaining source conditions మరియు Dasha confirmation అవసరం.'
                  : 'D10లో current Vipareet structural rules match కాలేదు.',
      rule: 'Source divisional-chart rule: varga ఒక specific areaని సూచిస్తుంది; SSVY ఆ chart significationsను promote చేస్తుంది, సాధారణంగా సమస్యలు/బాధలు అనుభవించిన తర్వాత. Normal Vipareet effects దాని Dashaలో అనుభవించబడతాయని source note ఉంది.',
      inspection:
          'Classic structural ${anyClassicStructure ? 'yes' : 'no'} • classic malefic-confirmed ${anyClassicFull ? 'yes' : 'no'} • SSVY candidates ${ssvyCandidates.length} • auto-full ${ssvyAutoFull.length}.',
      source: 'vipareet raja yoga.pdf pp.11–12 & 19–32 (D10/other divisional examples and divisional-chart rule).',
      tone: ssvyAutoFull.isNotEmpty || anyClassicFull
          ? VargaRuleTone.favorable
          : anyClassicStructure || ssvyCandidates.isNotEmpty
              ? VargaRuleTone.neutral
              : VargaRuleTone.info,
      applicable: true,
      remedy: 'ఈ sourceలో D10 Vipareet career resultకు ప్రత్యేక పరిహారం ఇవ్వలేదు. Yogaను practical career-risk planningకు substitute చేయకూడదు.',
    );


    _beneficMaleficHouseRule(
      v: v,
      house: 10,
      favorableId: 'D10-CAR-01',
      cautionId: 'D10-CAR-02',
      topic: 'వృత్తి / స్థాయి',
      favorableResult: 'D10 10వ భావంలో శుభగ్రహ support ఉంది; స్థాయి/గౌరవం/వృత్తికి అనుకూల layer.',
      cautionResult: 'D10 10వ భావంలో పాపగ్రహ ప్రభావం ఉంది; వృత్తిలో ఒత్తిడి/శిక్ష/అవమానం వంటి జాగ్రత్త layer.',
      rule: 'D10 Lagna, 10వ భావం, 10వ అధిపతి, అమాత్యకారక బలం/శుభ సంబంధాన్ని స్థాయి–కీర్తికి చూడాలి; పీడ ఉంటే అవమానం/శిక్ష layer.',
      source: '“D10-dashamsha-rule-guide.pdf” + Sarala VII D10 p.7',
      add: add,
    );

    final supportHouses = [2, 4, 11, 5];
    final obstructionHouses = [12, 10, 3, 9];
    final supportCount = supportHouses.fold<int>(0, (sum, h) => sum + _houseNames(v, h).length);
    final obstructionCount = obstructionHouses.fold<int>(0, (sum, h) => sum + _houseNames(v, h).length);
    final argalaTone = supportCount > obstructionCount
        ? VargaRuleTone.favorable
        : obstructionCount > supportCount
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'D10-R6.1',
      topic: 'వృత్తి అర్గళ బలం',
      result: supportCount > obstructionCount
          ? 'D10లో అర్గళ support అడ్డుకంటే ఎక్కువగా ఉంది; వృత్తి నిలకడకు అనుకూల source arithmetic.'
          : obstructionCount > supportCount
              ? 'D10లో అడ్డుగ్రహ count అర్గళ supportకంటే ఎక్కువగా ఉంది; వృత్తి స్థిరత్వంలో జాగ్రత్త layer.'
              : 'D10 అర్గళ–అడ్డుగ్రహ count సమంగా ఉంది; మిశ్రమ support.',
      rule: '4, 2, 11 భావాలు అర్గళ; వాటి అడ్డులు 10, 12, 3. 5వ భావం కూడా అర్గళ; 9వ భావం అడ్డుగా చూడాలి. అర్గళ గ్రహాలు అడ్డుకంటే బలంగా/ఎక్కువగా ఉంటే వృత్తి నిలుస్తుంది.',
      inspection: 'Argala houses 2/4/11/5 = $supportCount occupants; obstruction 12/10/3/9 = $obstructionCount occupants.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.1, p.8',
      tone: argalaTone,
      applicable: supportCount != obstructionCount,
    );

    final h3Mal = thirdNames.where(_malefics.contains).toList();
    add(
      id: 'D10-R6.2',
      topic: 'ప్రత్యేక అర్గళ',
      result: h3Mal.length >= 3 ? 'D10 3వ భావంలో 3+ పాపగ్రహాలు ఉన్నాయి; source ప్రకారం ప్రత్యేక అర్గళ layer.' : 'ప్రత్యేక అర్గళ condition match కాలేదు.',
      rule: '3వ భావంలో 3 లేదా ఎక్కువ పాపగ్రహాలు ఉంటే ప్రత్యేక అర్గళ; దీనికి అడ్డుగా source చూడదు.',
      inspection: 'D10 3వ భావ పాపగ్రహాలు: ${h3Mal.isEmpty ? 'లేవు' : h3Mal.join(', ')}.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.2, p.8',
      tone: h3Mal.length >= 3 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: h3Mal.length >= 3,
    );

    final natal10Planets = chart.planets.where((p) => p.signIndex == d1TenthSign).toList();
    final lordArgala = supportHouses.contains(d10TenthLordHouse) || d10TenthLordHouse == 1 || d10TenthLordHouse == 10;
    add(
      id: 'D10-R6.9',
      topic: 'జన్మ 10వ అధిపతి × D10',
      result: lordArgala ? 'జన్మ 10వ అధిపతి D10లో ముఖ్య/అర్గళ స్థానంలో ఉంది; వృత్తి నిర్ణయానికి బలమైన confirmation layer.' : 'జన్మ 10వ అధిపతి D10లో ప్రధాన argala/Lagna/10వ స్థానానికి match కాలేదు.',
      rule: 'జన్మ 10వ అధిపతి D10లో అర్గళ ఇస్తే ముఖ్యంగా చూడాలి; D10 Lagna/10వ సంబంధం ఉంటే ఫలిత weight పెరుగుతుంది.',
      inspection: 'జన్మ 10వ రాశి ${d1TenthSign + 1}; అధిపతి $d1TenthLord; D10లో $d1TenthLord House ${_houseOf(v, v.planets.firstWhere((p) => p.name == d1TenthLord))}. జన్మ 10వలో గ్రహాలు: ${natal10Planets.isEmpty ? 'లేవు' : natal10Planets.map((p) => p.name).join(', ')}.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.9, p.9',
      tone: lordArgala ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: lordArgala,
    );


    // Build 50 — exact source-name profession registry.
    //
    // Source gate from vrutti-graha-devata.pdf:
    // 1) natal 10th-house planet is the profession-planet candidate,
    // 2) the same planet must connect with D10 Lagna / 10H / 10L,
    // 3) exact name is read from profession planet + 10th Dashamsha Devata,
    // 4) explicit Saturn Gocharastha/Agocharastha conditions refine owner/authority/service,
    // 5) the source "additional" column is used only where it is machine-readable;
    //    unclear strength/Navamsha wording is shown for audit instead of being invented.
    const extraPlanetTokens = <String, String>{
      'సూర్యుడు': 'Sun',
      'చంద్రు డు': 'Moon',
      'అంగారకుడు': 'Mars',
      'బుధుడు': 'Mercury',
      'గురువు': 'Jupiter',
      'శుక్రు డు': 'Venus',
      'శని': 'Saturn',
      'రాహువు': 'Rahu',
      'కేతువు': 'Ketu',
    };
    const standardDevatas = <String>{
      'Indra', 'Agni', 'Yama', 'Rakshash', 'Varuna', 'Vayu', 'Kubera', 'Ishana',
      'Brahma', 'Ananta',
    };

    bool axisSupport(String planet) {
      final p = v.planets.firstWhere((x) => x.name == planet);
      final h = _houseOf(v, p);
      return h == 1 ||
          h == 10 ||
          planet == d10TenthLord ||
          D10CareerService.relatedVarga(v, planet, d10TenthLord);
    }

    bool sameSign(String a, String b) {
      final pa = v.planets.firstWhere((x) => x.name == a);
      final pb = v.planets.firstWhere((x) => x.name == b);
      return pa.signIndex == pb.signIndex;
    }

    bool houseAxisSupport(String planet, int house) {
      final p = v.planets.firstWhere((x) => x.name == planet);
      if (_houseOf(v, p) == house) return true;
      final lord = _signLord(_houseSign(v, house));
      if (planet == lord || d10TenthLord == lord) return true;
      return D10CareerService.relatedVarga(v, planet, lord) ||
          D10CareerService.relatedVarga(v, d10TenthLord, lord);
    }

    final natalTenthNames = natal10Planets.map((p) => p.name).toSet();
    final exactProfessionRanked =
        <({D10ProfessionRule rule, int score, String status, String why})>[];
    var specialDevataSourceOnly = 0;

    for (final rule in d10ProfessionRules) {
      final birthCandidate = natalTenthNames.contains(rule.planet);
      final d10Confirm = axisSupport(rule.planet);
      final devataAuto = standardDevatas.contains(rule.devata);
      final devataMatch = devataAuto && careerDevata.deity == rule.devata;
      if (!devataAuto) specialDevataSourceOnly++;

      final extraPlanets = <String>[];
      extraPlanetTokens.forEach((token, planet) {
        if (rule.extra.contains(token) &&
            planet != rule.planet &&
            !extraPlanets.contains(planet)) {
          extraPlanets.add(planet);
        }
      });

      final hasConjunctionCondition = rule.extra.contains('కలిస్తే');
      final conjunctionOk = !hasConjunctionCondition ||
          extraPlanets.isEmpty ||
          extraPlanets.every((p) => sameSign(rule.planet, p));

      final extraPlanetOk = extraPlanets.isEmpty ||
          (hasConjunctionCondition
              ? conjunctionOk
              : extraPlanets.every(axisSupport));

      final houseNums = <int>[];
      if (!rule.extra.contains('నవాంశం')) {
        for (final m in RegExp(r'\d+').allMatches(rule.extra)) {
          final n = int.tryParse(m.group(0) ?? '');
          if (n != null && n >= 1 && n <= 12 && !houseNums.contains(n)) {
            houseNums.add(n);
          }
        }
      }
      final houseOk = houseNums.isEmpty ||
          houseNums.any((h) => houseAxisSupport(rule.planet, h));

      final needsGo = rule.extra.contains('శని గోచరం');
      final needsAgo = rule.extra.contains('శని అగోచరం');
      final modeOk = (!needsGo || saturnStream.dashamsaState == 'GOCHARASHTHA') &&
          (!needsAgo || saturnStream.dashamsaState == 'AGOCHARASHTHA');

      // "బలం" and explicit Navamsha-lord wording need a dedicated source
      // strength/Navamsha evaluator. They remain visible in the rule audit but
      // are not silently treated as satisfied.
      final manualExtra = rule.extra.contains('నవాంశం') ||
          rule.extra.contains(' బలం') ||
          rule.extra.endsWith('బలం');

      final bothCharts = birthCandidate && d10Confirm;
      final oneChart = birthCandidate != d10Confirm;
      final readableExtraOk = conjunctionOk && extraPlanetOk && houseOk && modeOk;

      String status;
      int score;
      // Build 52: an explicit machine-readable source condition (house,
      // conjunction, Saturn mode) must actually match before an exact
      // profession row can be shown as supported/confirmed. Previously a
      // matching planet+Devata could still surface a row even when its stated
      // house/conjunction condition failed, which made broad worker/consultant
      // labels look more certain than the source allowed.
      if (devataMatch && bothCharts && readableExtraOk) {
        if (manualExtra) {
          status = 'supported';
          score = 85;
        } else {
          status = 'confirmed';
          score = 100;
        }
      } else if (devataMatch && oneChart && readableExtraOk) {
        status = 'half';
        score = 55;
      } else {
        status = 'none';
        score = 0;
      }

      final why = <String>[
        'జనన 10వ భావ profession-planet ${birthCandidate ? '✓' : '✗'}',
        'D10 Lagna/10H/10L confirmation ${d10Confirm ? '✓' : '✗'}',
        '10వ Devata ${rule.devata}: ${devataMatch ? '✓' : (devataAuto ? '✗' : 'source-only')}',
        if (needsGo) 'Saturn Gocharastha ${saturnStream.dashamsaState == 'GOCHARASHTHA' ? '✓' : '✗'}',
        if (needsAgo) 'Saturn Agocharastha ${saturnStream.dashamsaState == 'AGOCHARASHTHA' ? '✓' : '✗'}',
        if (extraPlanets.isNotEmpty) 'అదనపు గ్రహ support ${extraPlanetOk ? '✓' : '✗'}',
        if (houseNums.isNotEmpty) 'అదనపు భావ support ${houseOk ? '✓' : '✗'}',
        if (manualExtra) 'source strength/Navamsha clause: manual/source-only',
      ].join(' • ');

      exactProfessionRanked.add(
        (rule: rule, score: score, status: status, why: why),
      );
    }

    exactProfessionRanked.sort((a, b) {
      final c = b.score.compareTo(a.score);
      if (c != 0) return c;
      return a.rule.id.compareTo(b.rule.id);
    });

    final exactStrong = exactProfessionRanked
        .where((x) => x.status == 'confirmed' || x.status == 'supported')
        .toList(growable: false);
    final exactHalf = exactProfessionRanked
        .where((x) => x.status == 'half')
        .toList(growable: false);
    final exactVisible = <({D10ProfessionRule rule, int score, String status, String why})>[
      ...exactStrong.take(12),
      ...exactHalf.take(6),
    ];
    final exactConfirmed = exactStrong;

    final d10Mode = switch (saturnStream.dashamsaState) {
      'GOCHARASHTHA' => (careerDevata.deity == 'Indra' || natalTenthNames.contains('Sun'))
          ? 'Self-employment / Owner + Authority potential'
          : 'Self-employment / Owner',
      'AGOCHARASHTHA' => 'Job / Service / Employee',
      _ => 'Mixed / needs supporting confirmation',
    };

    // Build 52 presentation order: Mode -> Exact Profession -> Supporting
    // Devata. These are deliberately separated so a generic work-level label
    // (for example "manual worker") cannot visually override an exact
    // source-name profession.
    add(
      id: 'D10-PROF-MODE-SOURCE',
      topic: '1. వృత్తి విధానం / Mode',
      result: '$d10Mode • D10 Saturn: ${saturnStream.dashamsaState}.',
      rule: 'Supplied Saturn source ప్రకారం profession పేరు planet + 10th Devata ద్వారా confirm అవుతుంది; Saturn profession type మాత్రమే చెబుతాడు. D10 Saturn Gocharastha అయితే self-employment/owner; Sun/Indra authority support ఉంటే authority/high-position layer. Agocharastha అయితే job/service/employee. ఇది transit కాదు — D10లో Saturn స్థితి.',
      inspection: 'D10 Saturn state: ${saturnStream.dashamsaState}; 10L Devata: ${careerDevata.deity}; natal 10H Sun: ${natalTenthNames.contains('Sun') ? 'yes' : 'no'}.',
      source: 'sani-gochara-agochara.pdf pp.1–2; swantam-perlu.pdf pp.1–2; agochara-perlu.pdf p.1.',
      tone: saturnStream.dashamsaState == 'MIXED' ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    final sourcePrimary = exactConfirmed.isEmpty ? null : exactConfirmed.first;
    final exactAlternatives = exactConfirmed.skip(1).take(5).map((x) => x.rule.name).toList();
    final halfAlternatives = exactHalf.take(5).map((x) => x.rule.name).toList();
    add(
      id: 'D10-EXACT-PROF-SUMMARY',
      topic: '2. Exact Profession / ఖచ్చిత వృత్తి',
      result: sourcePrimary != null
          ? 'ప్రధాన source-confirmed వృత్తి: ${sourcePrimary.rule.name}.${exactAlternatives.isEmpty ? '' : ' ఇతర బలమైన వృత్తులు: ${exactAlternatives.join(' • ')}.'}${halfAlternatives.isEmpty ? '' : ' పాక్షిక support: ${halfAlternatives.join(' • ')}.'}'
          : exactHalf.isNotEmpty
              ? 'పూర్తి source confirmation లేదు. పాక్షికంగా సరిపడిన వృత్తులు: ${halfAlternatives.join(' • ')}.'
              : 'ఈ strict source gateలో exact profession పేరు confirm కాలేదు. కింద broad career-field supportను మాత్రమే చూడండి.',
      rule: 'Exact profession పేరు = జనన 10వ భావ profession-planet + అదే గ్రహానికి D10 Lagna/10H/10L confirmation + 10వ Dashamsha Devata + sourceలో ఉన్న explicit అదనపు గ్రహ/భావ/Saturn-mode condition. Machine-readable అదనపు condition fail అయితే rowను confirmed/supportగా చూపకూడదు.',
      inspection: sourcePrimary != null
          ? sourcePrimary.why
          : 'జనన 10వలో: ${natalTenthNames.isEmpty ? 'గ్రహం లేదు' : natalTenthNames.join(', ')} • D10 10L: $d10TenthLord • 10L Devata: ${careerDevata.deity} • D10 Saturn: ${saturnStream.dashamsaState}.',
      source: 'vrutti-graha-devata.pdf pp.1–6; sani-gochara-agochara.pdf pp.1–2.',
      tone: sourcePrimary != null ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'వృత్తి పేరు source-rule matching మాత్రమే. విద్య, నైపుణ్యం, ఆసక్తి, అనుభవం, practical opportunity మరియు ఆర్థిక పరిస్థితిని కూడా కలిపి నిర్ణయించాలి.',
    );

    add(
      id: 'D10-EXACT-PROF-LIST',
      topic: 'జాతకం ప్రకారం Exact Profession List',
      result: exactVisible.isEmpty
          ? 'ఈ strict source gateలో exact profession పేరు confirm కాలేదు.'
          : exactVisible.map((x) {
              final icon = x.status == 'confirmed' ? '🟢' : x.status == 'supported' ? '✅' : '🟡';
              final tag = x.status == 'half' ? 'సగం support' : x.status == 'supported' ? 'source support' : 'confirm';
              return '$icon ${x.rule.name} — $tag';
            }).join(' • '),
      rule: 'Exact profession పేరు కోసం supplied vrutti-graha-devata source gate: జనన 10వ ఇంటి profession planet + అదే గ్రహానికి D10 Lagna/10H/10L confirmation + 10వ Dashamsha Devata match. Explicit అదనపు గ్రహ/భావ/Saturn condition కూడా match అయితేనే confirm/support. జననం లేదా D10లో ఒక్క layer మాత్రమే ఉంటే సగం support.',
      inspection: 'జనన 10వలో: ${natalTenthNames.isEmpty ? 'గ్రహం లేదు' : natalTenthNames.join(', ')} • D10 10L: $d10TenthLord • 10L Devata: ${careerDevata.deity} • D10 Saturn: ${saturnStream.dashamsaState} • Mode: $d10Mode • Loaded source-name rules: ${d10ProfessionRules.length} • Special Sun/Venus-deity rows source-only: $specialDevataSourceOnly.',
      source: 'vrutti-graha-devata.pdf — pp.1–6; sani-gochara-agochara.pdf — profession type rules; swantam-perlu.pdf / agochara-perlu.pdf — owner/service name layers.',
      tone: exactConfirmed.isNotEmpty ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Sourceలో profession selectionకు ప్రత్యేక spiritual remedy ఇవ్వలేదు. Qualification, training, aptitude, opportunity మరియు financial realityని కూడా చూడాలి.',
    );

    final devataExactMatches = exactConfirmed
        .where((x) => x.rule.devata == careerDevata.deity)
        .map((x) => x.rule.name)
        .take(6)
        .toList(growable: false);
    add(
      id: 'D10-DEVATA-PROF',
      topic: '3. Supporting Dashamsha Devata / దేవత ఆధారం',
      result: '10వ అధిపతి $d10TenthLord యొక్క Devata: ${careerDevata.deity} (${careerDevata.direction}). ${careerDevata.sourceMeaning} ${devataExactMatches.isEmpty ? 'ఈ దేవత ఒక్కటితో exact profession నిర్ణయించము.' : 'ఈ జాతకంలో exact source gateతో కలిసి నిలిచినవి: ${devataExactMatches.join(' • ')}.'}',
      rule: 'Dashamsha Devata professionకు supporting layer మాత్రమే. Devata meaningను చూసి ఒక్కటే ఆధారంగా Astrologer/Consultant/Teacher వంటి exact profession ప్రకటించకూడదు. Main profession planet + D10 confirmation + source అదనపు conditionతో కలిసినప్పుడే exact listలోకి తీసుకోవాలి.',
      inspection: '10L natal longitude ${d10TenthLordNatal.longitude.toStringAsFixed(4)}° → ${careerDevata.deity}. Devata broad support: ${careerDevata.professionGroups.isEmpty ? 'narrow list లేదు' : careerDevata.professionGroups.join(', ')}.',
      source: 'D10 special.pdf — Dashamsha details/deities, pp.6–9; vrutti-graha-devata.pdf pp.1–6.',
      tone: careerDevata.professionGroups.isEmpty ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    for (final item in exactVisible.take(10)) {
      final icon = item.status == 'confirmed' ? '🟢' : item.status == 'supported' ? '✅' : '🟡';
      add(
        id: item.rule.id,
        topic: 'వృత్తి: ${item.rule.name}',
        result: '$icon ${item.rule.name} • ${item.rule.category} • Mode: $d10Mode.',
        rule: 'Main profession planet: ${item.rule.planet}. 10వ Devata: ${item.rule.devata}. Source అదనం: ${item.rule.extra}. Exact nameను main planet + 10th Devata gate తర్వాత మాత్రమే చూపాలి; జననం+D10 రెండూ confirm అయితే strong, ఒక్కటే అయితే half-support.',
        inspection: item.why,
        source: 'vrutti-graha-devata.pdf — page ${item.rule.sourcePage}, ${item.rule.id}.',
        tone: item.status == 'confirmed' || item.status == 'supported'
            ? VargaRuleTone.favorable
            : VargaRuleTone.neutral,
        applicable: true,
        remedy: 'ఈ profession rowకు sourceలో ప్రత్యేక పరిహారం ఇవ్వలేదు. Career decisionలో qualification, training, aptitude మరియు opportunityను కలిపి చూడాలి.',
      );
    }

    // Profession shortlist — source-backed layers only. The scoring weights are
    // the transparent app compatibility index already present in the supplied
    // Profession Rules file; they are not claimed as a classical percentage.
    final ranked = <({String name, int score, String why})>[];
    for (final item in _d10ProfessionCatalog) {
      final scored = professionScore(item.$2);
      var score = scored.score;
      final why = <String>[scored.why];
      if (item.$3.contains(d10TenthLordHouse)) {
        score += 8;
        why.add('10వ అధిపతి $d10TenthLord ${d10TenthLordHouse}వ భావంలో — profession-house match');
      }
      if (careerDevata.professionGroups.contains(item.$1)) {
        score += 12;
        why.add('10L Dashamsha Devata ${careerDevata.deity} profession match');
      }
      // Supplied vrutti-graha-devata source: Lagna Devata shows desire /
      // inclination, not the profession name. Do not add it to profession
      // ranking. It remains visible in the audit only.
      ranked.add((name: item.$1, score: score.clamp(0, 100).toInt(), why: why.join(' • ')));
    }
    ranked.sort((a, b) => b.score.compareTo(a.score));
    const broadDisplayExcluded = <String>{
      'Astrologer / Jyotisha Practitioner',
      'Astrology Consultant / Jyotisha Consultant',
      'Consultant / Advisor',
      'Priest / Spiritual Consultant',
      'Plumber / Electrician / Skilled Trades',
      'Skilled Service / Manual Work',
      'Daily-wage / Manual Worker',
      'Farm / Agricultural Worker',
      'Self-employment',
      'Service / Employment',
    };
    final topProf = ranked
        .where((x) => !broadDisplayExcluded.contains(x.name))
        .take(8)
        .toList(growable: false);
    final primaryProf = topProf.first;
    add(
      id: 'D10-PRIMARY-PROF',
      topic: 'Supporting Career Field / సహాయక వృత్తి రంగం',
      result: sourcePrimary != null
          ? 'Source exact primary: ${sourcePrimary.rule.name}. Broad profession direction: ${primaryProf.name} — ${primaryProf.score}% evidence-convergence. Strong alternatives: ${exactConfirmed.skip(1).take(3).map((x) => x.rule.name).join(' • ')}.'
          : 'Strict source exact name confirm కాలేదు. Broad profession direction: ${primaryProf.name} — ${primaryProf.score}% evidence-convergence. Strong alternatives: ${topProf.skip(1).take(3).map((x) => '${x.name} ${x.score}%').join(' • ')}.',
      rule: 'ఇది exact profession కాదు; D10 10L/10H/Lagna, D1/D9 link, house-signification మరియు Devata ఆధారంగా broad career-field support మాత్రమే. Exact professionకు పై source-name gateనే priority.',
      inspection: sourcePrimary != null ? sourcePrimary.why : primaryProf.why,
      source: 'vrutti-graha-devata.pdf pp.1–6 + D10 special.pdf — Basics, Houses, Tenth-lord houses and Dashamsha Deities.',
      tone: primaryProf.score >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఇది classical certainty కాదు; source evidence-convergence shortlist. Actual career choiceలో education, aptitude, opportunity, capital, experience మరియు current job marketను కలిపి నిర్ణయించాలి.',
    );

    add(
      id: 'D10-PROF-LIST',
      topic: 'Supporting Broad Career Fields / విస్తృత రంగాలు',
      result: topProf.map((x) => '${x.name} — ${x.score}%').join(' • '),
      rule: 'ఈ list exact profession పేర్లు కాదు. D10 10వ అధిపతి + 10వ భావం + D10 లగ్నం + D1→D10 link + D9 confirmation + 10L placement-house + Dashamsha Devata ఆధార broad fields మాత్రమే. Mode labels మరియు exact worker/consultant titlesను ఈ broad listలో కలపము.',
      inspection: 'D10 లగ్నం ${_d10SignNames[d10LagnaSign]}; 10వ రాశి ${_d10SignNames[d10TenthSign]}; 10వ అధిపతి $d10TenthLord ($d10TenthLordHouseవ భావం). 10L Devata ${careerDevata.deity} (${careerDevata.direction}); Lagna Devata ${lagnaDevata.deity} (కోరిక/ఆసక్తి మాత్రమే; profession scoreలో లేదు). Top evidence: ${topProf.take(3).map((x) => '${x.name}: ${x.why}').join(' | ')}.',
      source: 'D10 special.pdf — Basics/10th-lord houses pp.11–35 and Dashamsha Deities pp.6–9; supplied Profession Rules profession catalog.',
      tone: VargaRuleTone.favorable,
      applicable: true,
      remedy: 'వృత్తి ఎంపికకు ఇది source-backed suitability shortlist మాత్రమే. విద్య, నైపుణ్యం, ఆసక్తి, మార్కెట్ అవకాశాలు, అనుభవం వంటి practical factorsతో కలిపి నిర్ణయించాలి. Sourceలో వృత్తి కోసం ప్రత్యేక రత్న/హోమ పరిహారం ఇవ్వలేదు.',
    );

    final astrologerExact = exactProfessionRanked.firstWhere((x) => x.rule.id == 'D10-PRO-172');
    add(
      id: 'D10-PROF-ASTROLOGER',
      topic: 'Astrologer / Jyotisha Practitioner',
      result: astrologerExact.status == 'confirmed'
          ? '🟢 జ్యోతిషం — exact source rule Confirmed.'
          : astrologerExact.status == 'supported'
              ? '✅ జ్యోతిషం — source support ఉంది; ఒక manual/source-only clause ఇంకా audit కావాలి.'
              : astrologerExact.status == 'half'
                  ? '🟡 జ్యోతిషం — పాక్షిక support మాత్రమే; exact professionగా final చేయకూడదు.'
                  : '△ జ్యోతిషం exact source rule ఈ chartలో confirm కాలేదు.',
      rule: 'జ్యోతిషం exact row: Ketu + Ishana Devata + Jupiter + 8/9/12 source condition. Broad Jupiter/Ketu/Ishana similarity ఒక్కటే final verdict కాదు.',
      inspection: astrologerExact.why,
      source: 'vrutti-graha-devata.pdf p.6 — D10-PRO-172.',
      tone: astrologerExact.status == 'confirmed' || astrologerExact.status == 'supported'
          ? VargaRuleTone.favorable
          : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Sourceలో Astrologer profession కోసం ప్రత్యేక remedy ఇవ్వలేదు. Training, శాస్త్ర అధ్యయనం, consultation ethics మరియు practical skillను career decisionలో కలిపి చూడాలి.',
    );

    final consultantExact = exactProfessionRanked.firstWhere((x) => x.rule.id == 'D10-PRO-054');
    final vastuExact = exactProfessionRanked.firstWhere((x) => x.rule.id == 'D10-PRO-173');
    add(
      id: 'D10-PROF-CONSULTANT',
      topic: 'Consultant / Advisor',
      result: 'General Consultant: ${consultantExact.status == 'confirmed' ? '🟢 Confirmed' : consultantExact.status == 'supported' ? '✅ Supported' : consultantExact.status == 'half' ? '🟡 Half-support' : '△ Not confirmed'} • Vastu Consultant: ${vastuExact.status == 'confirmed' ? '🟢 Confirmed' : vastuExact.status == 'supported' ? '✅ Supported' : vastuExact.status == 'half' ? '🟡 Half-support' : '△ Not confirmed'}.',
      rule: 'General Consultant exact row = Mercury + Vayu + Jupiter conjunction/support as supplied. Vastu Consultant exact row = Jupiter + Kubera + Mars + 4th-house source condition. Ishana/Kubera broad meaning ఒక్కటే exact title ఇవ్వదు.',
      inspection: 'Consultant: ${consultantExact.why} | Vastu: ${vastuExact.why}.',
      source: 'vrutti-graha-devata.pdf pp.2 & 6 — D10-PRO-054, D10-PRO-173.',
      tone: consultantExact.status == 'confirmed' || vastuExact.status == 'confirmed'
          ? VargaRuleTone.favorable
          : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Consultancy professionకు sourceలో ప్రత్యేక career remedy ఇవ్వలేదు. Subject expertise, communication skill, qualification మరియు practical experienceను పరిశీలించాలి.',
    );

    final sixthHouseNames = _houseNames(v, 6);
    final dailyWorkerExact = exactProfessionRanked.firstWhere((x) => x.rule.id == 'D10-PRO-178');
    const skilledIds = <String>{
      'D10-PRO-128', // mechanic
      'D10-PRO-129', // electrician
      'D10-PRO-130', // plumber
      'D10-PRO-131', // AC technician
      'D10-PRO-132', // mobile repair
      'D10-PRO-135', // carpenter
      'D10-PRO-136', // blacksmith
    };
    final exactSkilled = exactConfirmed
        .where((x) => skilledIds.contains(x.rule.id))
        .map((x) => x.rule.name)
        .take(6)
        .toList(growable: false);
    add(
      id: 'D10-PROF-WORKER',
      topic: 'Skilled Worker / Daily Worker / Manual Service',
      result: dailyWorkerExact.status == 'confirmed'
          ? '🟢 కూలీ / Daily-wage / Manual Worker — exact source rule Confirmed.${exactSkilled.isEmpty ? '' : ' Exact skilled matches: ${exactSkilled.join(' • ')}.'}'
          : 'Daily Worker exact rule ${dailyWorkerExact.status == 'half' ? 'పాక్షికంగా మాత్రమే సరిపడింది' : 'confirm కాలేదు'}.${exactSkilled.isEmpty ? ' Skilled trade exact match కూడా లేదు.' : ' Exact skilled matches: ${exactSkilled.join(' • ')}.'}',
      rule: 'Daily Workerను broad percentageతో confirm చేయకూడదు. Source exact row D10-PRO-178లో Saturn + Agni Devata + 6వ భావం; authority కాదు. ఈ పూర్తి gate match అయితేనే Confirmed. Mechanic/Electrician/Plumber వంటి skilled professions తమ తమ separate exact rowsతోనే చూపాలి.',
      inspection: 'Daily-worker row: ${dailyWorkerExact.why} • D10 6వ భావం: ${sixthHouseNames.isEmpty ? 'ఖాళీ' : sixthHouseNames.join(', ')}${exactSkilled.isEmpty ? '' : ' • Skilled exact: ${exactSkilled.join(', ')}'}.',
      source: 'vrutti-graha-devata.pdf pp.4 & 6 — exact skilled rows and D10-PRO-178.',
      tone: dailyWorkerExact.status == 'confirmed' || exactSkilled.isNotEmpty
          ? VargaRuleTone.favorable
          : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఇది work-type classification మాత్రమే. Skill training, safety, stable income, labour protections మరియు practical opportunitiesను ముందుగా చూడాలి.',
    );

    final service = professionScore(const ['Saturn', 'Moon', 'Mercury']);
    final commercial = professionScore(const ['Mercury', 'Venus', 'Rahu']);
    final selfEmployment = professionScore(const ['Sun', 'Mars', 'Rahu', 'Moon']);
    final businessScore = commercial.score > selfEmployment.score ? commercial.score : selfEmployment.score;
    final jobVsBusinessTone = (service.score - businessScore).abs() < 15 ? VargaRuleTone.neutral : VargaRuleTone.favorable;
    final jobVsBusinessResult = service.score >= businessScore + 15
        ? 'ఉద్యోగం / Service సూచనలు బలంగా ఉన్నాయి — Job ${service.score}% vs Business $businessScore%.'
        : businessScore >= service.score + 15
            ? 'వ్యాపారం / Self-employment సూచనలు బలంగా ఉన్నాయి — Business $businessScore% vs Job ${service.score}%.'
            : 'ఉద్యోగం మరియు వ్యాపారం రెండింటికీ support ఉంది — Job ${service.score}% vs Business $businessScore%. ఇతర timing evidence అవసరం.';
    add(
      id: 'D10-JOB-BUSINESS',
      topic: 'Job లేదా Business',
      result: jobVsBusinessResult,
      rule: 'Supplied D10 profession sourceలో service/self-employment నిర్ణయానికి Saturn condition across D1/D9/D10, Sun/Moon/10th-lord relation, PP-planet pattern మరియు 3rd-house/3rd-lord relation supporting checksగా ఉన్నాయి. App shortlistలో Service/Employment మరియు Commercial/Self-employment source profession groupsను పోల్చాం.',
      inspection: 'Service evidence: ${service.why}. Business evidence: ${(commercial.score >= selfEmployment.score) ? commercial.why : selfEmployment.why}.',
      source: 'D10.pdf pp.60–72 + supplied Profession Rules module; KP job-vs-business source is kept as separate confirmation layer.',
      tone: jobVsBusinessTone,
      applicable: true,
      remedy: 'Job/Business నిర్ణయం కోసం పరిహారం కంటే skill, capital, stability, experience, family/financial obligations వంటి practical factorsను ముందుగా చూడాలి. Source-specific spiritual remedy ఉంటేనే appలో విడిగా చూపాలి.',
    );

    add(
      id: 'D10-SEQUENCE',
      topic: 'ముందు Job → తరువాత Business / ముందు Business → తరువాత Job',
      result: saturnStream.result,
      rule: 'User-locked sequence: Saturn Gocharastha = self-employment/business; Agocharastha = service/job. D1 ప్రారంభ work-modeను, D10 తరువాత/final professional modeను చూపుతుంది. D1 Agocharastha → D10 Gocharastha అయితే ముందు Job తరువాత Business; D1 Gocharastha → D10 Agocharastha అయితే ముందు Business తరువాత Job. D9 audit/support మాత్రమే; sequenceను override చేయదు.',
      inspection: 'D1 Saturn ${saturnStream.birthState} • D10 ${saturnStream.dashamsaState} • D9 ${saturnStream.navamsaState} (audit/support only). ${saturnStream.reason}',
      source: 'D10 special.pdf — Chapter 04 Self Employed-Service, pp.50–51 (uploaded PDF pages 1–2).',
      tone: saturnStream.result.contains('Mixed') ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    final highPosition = professionScore(const ['Sun', 'Jupiter', 'Saturn']);
    add(
      id: 'D10-HIGH-POSITION',
      topic: 'High position in Job / Management',
      result: highPosition.score >= 60
          ? 'Management / high-position profession indicators బలంగా ఉన్నాయి — app compatibility ${highPosition.score}%.'
          : highPosition.score >= 30
              ? 'High-position indicators మధ్యస్థంగా ఉన్నాయి — ${highPosition.score}%; ఇతర status/timing rulesతో confirm చేయాలి.'
              : 'High-position source indicators ఈ operational checkలో బలంగా కనిపించలేదు — ${highPosition.score}%.',
      rule: 'Supplied profession listలో Management / High Positionకు Sun + Jupiter + Saturn మరియు 10వ భావ సంబంధం ప్రధాన indicatorsగా ఉన్నాయి.',
      inspection: highPosition.why,
      source: 'Annapurna_Astro_Vastu_V38_Profession_Rules.html — profession list; D10.pdf profession significations.',
      tone: highPosition.score >= 60 ? VargaRuleTone.favorable : highPosition.score >= 30 ? VargaRuleTone.neutral : VargaRuleTone.caution,
      applicable: true,
    );

    add(
      id: 'D10-GOCHARISTA',
      topic: 'గోచరిస్తా / Gocharastha',
      result: 'D1: ${saturnStream.birthState} • D10: ${saturnStream.dashamsaState} • D9: ${saturnStream.navamsaState} (audit). ${saturnStream.birthState == 'GOCHARASHTHA' || saturnStream.dashamsaState == 'GOCHARASHTHA' ? 'D1/D10 career flowలో Gocharastha ఉంది; independent/self-employment stageకు support.' : 'D1/D10 career flowలో Gocharastha match కాలేదు.'}',
      rule: 'Gocharastha: Saturn exalted/own signలో ఉండి Trika (6/8/12) సంబంధం లేకపోవడం. Sourceలో exalted/own Saturn Trikaతో సంబంధం ఉంటే Government/administrative-level job అనే ప్రత్యేక note ఉంది.',
      inspection: saturnStream.reason,
      source: 'D10 special.pdf — Chapter 04, p.50 (uploaded PDF page 1).',
      tone: saturnStream.birthState == 'GOCHARASHTHA' || saturnStream.dashamsaState == 'GOCHARASHTHA' ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    add(
      id: 'D10-AGOCHARISTA',
      topic: 'Agocharastha',
      result: 'D1: ${saturnStream.birthState} • D10: ${saturnStream.dashamsaState} • D9: ${saturnStream.navamsaState} (audit). ${saturnStream.birthState == 'AGOCHARASHTHA' || saturnStream.dashamsaState == 'AGOCHARASHTHA' ? 'D1/D10 career flowలో Agocharastha ఉంది; service/employment stageకు support.' : 'D1/D10 career flowలో Agocharastha match కాలేదు.'}',
      rule: 'Agocharastha: Saturn debilitated, Rahu/Ketuతో కలయిక, combust/planetary-war defeat లేదా Trika సంబంధం. Current appలో dignity + Rahu/Ketu conjunction + 6/8/12 placement auto-check అవుతుంది; combustion/planetary-war data లేకపోతే వాటిని ఊహించదు.',
      inspection: saturnStream.reason,
      source: 'D10 special.pdf — Chapter 04, pp.50–51 (uploaded PDF pages 1–2).',
      tone: saturnStream.birthState == 'AGOCHARASHTHA' || saturnStream.dashamsaState == 'AGOCHARASHTHA' ? VargaRuleTone.neutral : VargaRuleTone.info,
      applicable: true,
    );

    final saturnD1 = chart.planets.firstWhere((p) => p.name == 'Saturn');
    final saturnD9 = d9.planets.firstWhere((p) => p.name == 'Saturn');
    final saturnD10 = v.planets.firstWhere((p) => p.name == 'Saturn');
    final sunD10 = v.planets.firstWhere((p) => p.name == 'Sun');
    final moonD10 = v.planets.firstWhere((p) => p.name == 'Moon');
    final sameWith = <String>[];
    if (saturnD10.signIndex == sunD10.signIndex) sameWith.add('Sun');
    if (saturnD10.signIndex == moonD10.signIndex) sameWith.add('Moon');
    if (saturnD10.signIndex == d10TenthLordPlacement.signIndex && d10TenthLord != 'Saturn') sameWith.add('10L $d10TenthLord');
    add(
      id: 'D10-SATURN-REL',
      topic: 'Relation of Saturn',
      result: 'Saturn: D1 ${((saturnD1.signIndex - chart.ascendantSignIndex + 12) % 12) + 1}వ భావం • D9 ${_houseOf(d9, saturnD9)}వ భావం • D10 ${_houseOf(v, saturnD10)}వ భావం. D10 same-sign relation: ${sameWith.isEmpty ? 'Sun/Moon/10Lతో conjunction లేదు' : sameWith.join(', ')}.',
      rule: 'Supplied D10 source self-employment/service assessmentలో Saturn condition across D1, Navamsha, Dashamsha మరియు Sun/Moon/10th-lord relationను supporting checkగా ఉపయోగిస్తుంది. Exact aspect scheme source-defined అయినందున ఇక్కడ same-sign association మాత్రమే auto-check చేశాం.',
      inspection: 'D10 Saturn ${_d10SignNames[saturnD10.signIndex]} • House ${_houseOf(v, saturnD10)}; Sun House ${_houseOf(v, sunD10)}; Moon House ${_houseOf(v, moonD10)}; 10L $d10TenthLord House $d10TenthLordHouse.',
      source: 'D10.pdf pp.60–72 — self-employment/service supporting checks.',
      tone: VargaRuleTone.neutral,
      applicable: true,
    );

    final ppPlanets = const ['Sun', 'Moon', 'Mars', 'Rahu'];
    final d1FirstLord = _signLord(chart.ascendantSignIndex);
    final ppInfluencersD1 = <String>[];
    final ppInfluencersD10 = <String>[];
    for (final name in ppPlanets) {
      final h1 = ((chart.planets.firstWhere((x) => x.name == name).signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
      if (h1 == 1 || h1 == 10 ||
          D10CareerService.relatedD1(chart, name, d1FirstLord) ||
          D10CareerService.relatedD1(chart, name, d1TenthLord)) {
        ppInfluencersD1.add(name);
      }
      final h10 = _houseOf(v, v.planets.firstWhere((x) => x.name == name));
      if (h10 == 1 || h10 == 10 ||
          D10CareerService.relatedVarga(v, name, d10FirstLord) ||
          D10CareerService.relatedVarga(v, name, d10TenthLord)) {
        ppInfluencersD10.add(name);
      }
    }
    add(
      id: 'D10-PP',
      topic: 'PP Planets / Poorna Paramatma Planets',
      result: ppInfluencersD1.length >= 2
          ? 'Birth chartలో PP planets ${ppInfluencersD1.join(', ')} Lagna/10H/1L/10Lను ప్రభావితం చేస్తున్నాయి; independent professionకు source rule match. D10 confirmation: ${ppInfluencersD10.isEmpty ? 'none' : ppInfluencersD10.join(', ')}.'
          : 'Birth PP ruleకు కనీసం 2 influences కావాలి; match: ${ppInfluencersD1.isEmpty ? 'none' : ppInfluencersD1.join(', ')}. D10 confirmation: ${ppInfluencersD10.isEmpty ? 'none' : ppInfluencersD10.join(', ')}.',
      rule: 'PP planets = Sun, Moon, Mars, Rahu. Birth horoscopeలో వీటిలో కనీసం రెండు Lagna/10th house లేదా Lagna lord/10th lordను influence చేయాలి. Lagna influence = independent nature; 10th influence = independent profession.',
      inspection: 'Birth PP matches: ${ppInfluencersD1.isEmpty ? 'none' : ppInfluencersD1.join(', ')} • D10 matches: ${ppInfluencersD10.isEmpty ? 'none' : ppInfluencersD10.join(', ')}.',
      source: 'D10 special.pdf — Chapter 04 Self Employed-Service, p.51 (uploaded PDF page 2).',
      tone: ppInfluencersD1.length >= 2 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    final sector7to12 = <String>[];
    final sector10to3 = <String>[];
    for (final p in chart.planets) {
      final h = ((p.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
      if (h >= 7 && h <= 12) sector7to12.add(p.name);
      if (h >= 10 || h <= 3) sector10to3.add(p.name);
    }
    int ppCount(List<String> names) => names.where(ppPlanets.contains).length;
    final sectorAOk = sector7to12.length >= 5 && ppCount(sector7to12) >= 2;
    final sectorBOk = sector10to3.length >= 5 && ppCount(sector10to3) >= 2;
    add(
      id: 'D10-FIVE-PLANETS',
      topic: 'Five Planets Rule',
      result: sectorAOk || sectorBOk
          ? 'Birth chart Five-planets independence rule match: ${sectorAOk ? '7–12 sector ${sector7to12.join(', ')}' : ''}${sectorAOk && sectorBOk ? ' • ' : ''}${sectorBOk ? '10–3 sector ${sector10to3.join(', ')}' : ''}.'
          : 'Five-planets rule పూర్తి match కాలేదు. 7–12: ${sector7to12.length} planets / ${ppCount(sector7to12)} PP; 10–3: ${sector10to3.length} planets / ${ppCount(sector10to3)} PP.',
      rule: 'Source rule: horoscopeలో 7th–12th sector లేదా 10th–3rd wrapping sectorలో కనీసం 5 planets ఉండాలి; వాటిలో కనీసం 2 PP planets ఉండాలి. ఇది independent professionకు support.',
      inspection: 'Birth 7–12: ${sector7to12.join(', ')} • Birth 10–3: ${sector10to3.join(', ')}.',
      source: 'D10 special.pdf — Chapter 04 Self Employed-Service, p.52 (uploaded PDF page 3).',
      tone: sectorAOk || sectorBOk ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    final thirdLordPlacement = v.planets.firstWhere((p) => p.name == d10ThirdLord);
    final thirdLordHouse = _houseOf(v, thirdLordPlacement);
    add(
      id: 'D10-THIRD-HOUSE',
      topic: 'Third House / Lord',
      result: 'D10 3వ భావం: ${thirdNames.isEmpty ? 'ఖాళీ' : thirdNames.join(', ')}. 3వ అధిపతి $d10ThirdLord $thirdLordHouseవ భావంలో. Source ప్రకారం 3వ భావం ధైర్యం, side-work, self-effort, transfer మరియు self-employment/service distinctionకు supporting layer.',
      rule: 'D10 profession sourceలో 3rd house / 3rd lord relationను self-employment/service supporting checkగా ఉపయోగించాలి; 3వ భావంలో 3+ malefics ఉంటే special argala ruleను విడిగా చూడాలి.',
      inspection: '3H occupants: ${thirdNames.isEmpty ? 'none' : thirdNames.join(', ')} • 3L $d10ThirdLord → H$thirdLordHouse.',
      source: 'D10.pdf pp.46–47, 60–72 + D10 Rule 6.2.',
      tone: VargaRuleTone.neutral,
      applicable: true,
    );

    final statusTone = d10TenthLordHouse == 8 || d10TenthLordHouse == 12
        ? VargaRuleTone.caution
        : const [1, 4, 5, 7, 9, 10, 11, 2].contains(d10TenthLordHouse)
            ? VargaRuleTone.favorable
            : VargaRuleTone.neutral;
    add(
      id: 'D10-STATUS',
      topic: 'Status / Position',
      result: 'D10 10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ భావంలో; 10వ భావంలో ${tenthNames.isEmpty ? 'గ్రహాలు లేవు' : tenthNames.join(', ')}. ${tenthBenefics.isNotEmpty ? 'Benefic support: ${tenthBenefics.join(', ')}.' : ''} ${tenthMalefics.isNotEmpty ? 'Malefic pressure: ${tenthMalefics.join(', ')}.' : ''}',
      rule: 'D10 10వ భావం profession/status/earning direction; 10వ అధిపతి placement మరియు associationsతో statusను refine చేయాలి.',
      inspection: '10H sign ${_d10SignNames[d10TenthSign]} • 10L $d10TenthLord H$d10TenthLordHouse.',
      source: 'D10.pdf pp.14–16; supplied Profession Rules.',
      tone: statusTone,
      applicable: true,
    );

    final tenthLordHouseMeaning = switch (d10TenthLordHouse) {
      1 => 'Self-driven profession; leadership/independent work, name and fame when supported.',
      2 => 'Food/family business/finance and speech-based work; family linkage can be strong.',
      3 => 'Communication, writing, short travel, transport/agency, publishing/contract work; job changes can repeat.',
      4 => 'Own-land/home-linked work, authority, leadership; politics can arise with supporting Saturn relation.',
      5 => 'Learning/intelligence/creative-professional growth; sudden developments can change career direction.',
      6 => 'Service/servitude; judiciary, hospitals, prisons or competitive service environments; tenure can be shorter under affliction.',
      7 => 'Business/partnership/corporate/public dealings and foreigners; strong 7th can give impressive public image/high position.',
      8 => 'Career challenges and sudden changes; strong Lagna may still give high position after obstacles.',
      9 => 'Authority/government, rajayoga-type status, frequent change/travel or foreign influence; strong success after discipline.',
      10 => 'Distinction, honour, fame and strong professional identity; afflicted state can still make the rise swift but unstable.',
      11 => 'Gains, recognition, network/friends and employment with comparatively easier returns; affliction can delay success.',
      12 => 'Foreign/institutional/isolated work, hospitals/jails/retreat settings or repeated profession change; affliction can reduce stability.',
      _ => 'Source house meaning unavailable.',
    };
    add(
      id: 'D10-10L-HOUSE',
      topic: '10th Lord in House — Profession Nature',
      result: 'D10 10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ భావంలో. $tenthLordHouseMeaning',
      rule: 'Source gives separate professional interpretation for the Dashamsha 10th lord placed in each of the 12 houses. This is a profession-nature layer, not a standalone exact occupation verdict.',
      inspection: '10H sign ${_d10SignNames[d10TenthSign]} • 10L $d10TenthLord → H$d10TenthLordHouse.',
      source: 'D10 special.pdf — Tenth lord in houses / house examples, pp.18–35 (uploaded PDF pages 66–82).',
      tone: const [1, 4, 5, 7, 9, 10, 11, 2].contains(d10TenthLordHouse) ? VargaRuleTone.favorable : const [6, 8, 12].contains(d10TenthLordHouse) ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    bool exchangeD1(int aHouse, int bHouse) {
      final aSign = (chart.ascendantSignIndex + aHouse - 1) % 12;
      final bSign = (chart.ascendantSignIndex + bHouse - 1) % 12;
      final aLord = _signLord(aSign);
      final bLord = _signLord(bSign);
      final pa = chart.planets.firstWhere((p) => p.name == aLord);
      final pb = chart.planets.firstWhere((p) => p.name == bLord);
      return pa.signIndex == bSign && pb.signIndex == aSign;
    }
    bool exchangeD10(int aHouse, int bHouse) {
      final aSign = _houseSign(v, aHouse);
      final bSign = _houseSign(v, bHouse);
      final aLord = _signLord(aSign);
      final bLord = _signLord(bSign);
      final pa = v.planets.firstWhere((p) => p.name == aLord);
      final pb = v.planets.firstWhere((p) => p.name == bLord);
      return pa.signIndex == bSign && pb.signIndex == aSign;
    }
    final kendra = const [1, 4, 7, 10];
    final trikona = const [1, 5, 9];
    final d1YogaPairs = <String>[];
    final d10YogaPairs = <String>[];
    for (final kh in kendra) {
      for (final th in trikona) {
        if (kh == th) continue;
        final kl1 = _signLord((chart.ascendantSignIndex + kh - 1) % 12);
        final tl1 = _signLord((chart.ascendantSignIndex + th - 1) % 12);
        if (D10CareerService.relatedD1(chart, kl1, tl1) || exchangeD1(kh, th)) {
          d1YogaPairs.add('${kh}L $kl1 ↔ ${th}L $tl1');
        }
        final kl10 = _signLord(_houseSign(v, kh));
        final tl10 = _signLord(_houseSign(v, th));
        if (D10CareerService.relatedVarga(v, kl10, tl10) || exchangeD10(kh, th)) {
          d10YogaPairs.add('${kh}L $kl10 ↔ ${th}L $tl10');
        }
      }
    }
    final rajYogaRepeat = d1YogaPairs.isNotEmpty && d10YogaPairs.isNotEmpty;
    add(
      id: 'D10-RAJAYOGA',
      topic: 'రాజయోగం / Status Yoga',
      result: rajYogaRepeat
          ? 'Birth chart మరియు Dashamsha రెండింటిలో Kendra–Trikona lord relation కనిపిస్తోంది; status/riseకు repeated Rajayoga support.'
          : d1YogaPairs.isNotEmpty || d10YogaPairs.isNotEmpty
              ? 'Kendra–Trikona relation ఒక chartలో ఉంది కానీ Birth+D10 repetition పూర్తి కాలేదు; status support మిశ్రమం.'
              : 'Current conjunction/aspect/exchange evaluatorలో Kendra–Trikona lord relation match కాలేదు.',
      rule: 'Source Rajayoga: Kendra lord–Trikona lord relation conjunction, mutual aspect, sign exchange, nakshatra exchange లేదా reciprocal Kendra/Trikona influence ద్వారా రావచ్చు. Birth yoga D10లో repeat అయితే status potential బలపడుతుంది. Current auto-evaluator conjunction/classical aspect/sign exchangeను మాత్రమే check చేస్తుంది; nakshatra exchange separate source inputగా మిగిలింది.',
      inspection: 'D1 pairs: ${d1YogaPairs.isEmpty ? 'none' : d1YogaPairs.join(' • ')}. D10 pairs: ${d10YogaPairs.isEmpty ? 'none' : d10YogaPairs.join(' • ')}.',
      source: 'D10 special.pdf — Chapter 05 Status, pp.93–96 (uploaded PDF pages 6–9).',
      tone: rajYogaRepeat ? VargaRuleTone.favorable : (d1YogaPairs.isNotEmpty || d10YogaPairs.isNotEmpty ? VargaRuleTone.neutral : VargaRuleTone.info),
      applicable: true,
    );

    final sunSign = chart.planets.firstWhere((p) => p.name == 'Sun').signIndex;
    final moonSign = chart.planets.firstWhere((p) => p.name == 'Moon').signIndex;
    final allOddSigns = chart.ascendantSignIndex.isEven && sunSign.isEven && moonSign.isEven;
    final allEvenSigns = chart.ascendantSignIndex.isOdd && sunSign.isOdd && moonSign.isOdd;
    add(
      id: 'D10-MAHABHAGYA',
      topic: 'Mahabhagya Yoga',
      result: 'Source sign-condition check: Lagna/Sun/Moon ${allOddSigns ? 'మూడూ odd signsలో ఉన్నాయి' : allEvenSigns ? 'మూడూ even signsలో ఉన్నాయి' : 'ఒకే parityలో లేవు'}. Final Mahabhagya verdictకు male/female + day/night condition కూడా అవసరం; ఈ app birth formలో sex/day-night astronomical flag లేకపోవడంతో final YES/NOను ఊహించదు.',
      rule: 'Source: male nativityకి day birth + Lagna/Moon/Sun odd signs; female nativityకి night birth + Lagna/Moon/Sun even signs. ఇవన్నీ together కావాలి.',
      inspection: 'Lagna sign ${chart.ascendantSignIndex + 1} • Sun ${sunSign + 1} • Moon ${moonSign + 1}.',
      source: 'D10 special.pdf — Chapter 05 Status, p.93 (uploaded PDF page 6).',
      tone: allOddSigns || allEvenSigns ? VargaRuleTone.neutral : VargaRuleTone.info,
      applicable: true,
      auto: false,
    );

    final rise = const [1, 4, 5, 7, 9, 10, 2, 11].contains(d10TenthLordHouse);
    final fall = const [6, 8, 12].contains(d10TenthLordHouse);
    add(
      id: 'D10-RISE-FALL',
      topic: 'Rise / Fall',
      result: rise
          ? '10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ భావంలో ఉండటం source placement table ప్రకారం rise/support వైపు బలం చూపిస్తోంది.'
          : fall
              ? '10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ దుస్థానంలో; career obstacles/fall-risk layerగా జాగ్రత్తగా చూడాలి.'
              : '10వ అధిపతి placement mixed/effort-oriented. ఇతర D10 supportతో కలిపి నిర్ణయించాలి.',
      rule: 'Supplied Goel implementation: 10వ అధిపతి Kendra=సుఖం, Trikona=శ్రీ, 2/11=ధనం, 3=శ్రమ, 6/8/12=ఆటంకం.',
      inspection: 'D10 10L $d10TenthLord → House $d10TenthLordHouse.',
      source: 'annapurna-jataka-16.html — V.P. Goel D10 implementation.',
      tone: rise ? VargaRuleTone.favorable : fall ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    if (birthDateTime != null) {
      add(
        id: 'D10-CAREER-START',
        topic: 'Career Start / First Earning',
        result: D10CareerService.summarizeWindows(careerWindows, 'career_start', max: 4),
        rule: 'First earning timing: Birth chartలో MD/AD 10th, 2nd లేదా 11th house/lordsతో సంబంధం; D10లో Dasha lord Lagna, 10th, 2nd లేదా 11th house/lordsతో సంబంధం. Promise లేకపోతే timingను force చేయరాదు.',
        inspection: 'Vimshottari MD/AD source windows; ప్రతి windowలో D1 2/10/11 + D10 1/2/10/11 evidence combine అవుతుంది.',
        source: 'D10 special.pdf — Chapter 10 Career Graph, pp.174–183 (uploaded PDF pages 22–30).',
        tone: careerWindows.any((w) => w.eventKey == 'career_start') ? VargaRuleTone.favorable : VargaRuleTone.info,
        applicable: true,
      );
      add(
        id: 'D10-RISE-TIMING',
        topic: 'Career Rise / Fame — Date Duration',
        result: D10CareerService.summarizeWindows(careerWindows, 'rise', max: 5),
        rule: 'Rise timing: Vimshottari MDను Birth Kendra, Navamsha, Shodashamsha, Dashamshaలో repeatగా పరీక్షించి D10లో Kendra/11th support చూడాలి; ADతో అదే logicను repeat చేయాలి. Source Progress Yogini మరియు Chara Dasha కూడా confirmation methodsగా ఇస్తుంది; ఈ cardలో ప్రస్తుతం Vimshottari windowను primaryగా చూపుతుంది.',
        inspection: 'D1 Kendra + D9/D16 + D10 Kendra/11 period convergence ఆధారంగా windows రూపొందించబడ్డాయి.',
        source: 'D10 special.pdf — Chapter 06 Rise, pp.99–101 (uploaded PDF pages 12–14).',
        tone: careerWindows.any((w) => w.eventKey == 'rise') ? VargaRuleTone.favorable : VargaRuleTone.info,
        applicable: true,
      );
    }

    final keyLords = <String>{d10FirstLord, d10ThirdLord, d10SeventhLord, d10TenthLord, d10EleventhLord}.toList();
    final inter = <String>[];
    for (var i = 0; i < keyLords.length; i++) {
      for (var j = i + 1; j < keyLords.length; j++) {
        final a = v.planets.firstWhere((p) => p.name == keyLords[i]);
        final b = v.planets.firstWhere((p) => p.name == keyLords[j]);
        if (a.signIndex == b.signIndex) inter.add('${keyLords[i]} + ${keyLords[j]}');
      }
    }
    add(
      id: 'D10-INTERRELATION',
      topic: 'Inter-relation',
      result: inter.isEmpty ? 'D10 1L/3L/7L/10L/11L మధ్య same-sign conjunction ఈ simple auto-checkలో లేదు.' : 'Career key lords same-sign inter-relations: ${inter.join(' • ')}.',
      rule: 'D10 profession assessmentలో relevant lords/planets relationshipsను చూడాలి. Source-specific aspect scheme పూర్తిగా implement చేయకుండా ఇక్కడ conjunction/same-sign relation మాత్రమే auto-check అవుతుంది.',
      inspection: '1L $d10FirstLord • 3L $d10ThirdLord • 7L $d10SeventhLord • 10L $d10TenthLord • 11L $d10EleventhLord.',
      source: 'D10 source rule: relevant planets/relationships; exact aspect scheme remains source-bound.',
      tone: inter.isEmpty ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    final partnership = professionScore(const ['Mercury', 'Venus', 'Rahu']);
    add(
      id: 'D10-PARTNERSHIP',
      topic: 'Partnership / Business Partnership',
      result: partnership.score >= 60
          ? 'Partnership/business indicators బలంగా ఉన్నాయి — ${partnership.score}%. 7వ భావం: ${seventhNames.isEmpty ? 'ఖాళీ' : seventhNames.join(', ')}.'
          : 'Partnership/business support ${partnership.score}%. 7వ భావం మరియు 3/11 సంబంధాలను ఇతర evidenceతో confirm చేయాలి.',
      rule: 'D10 house-profession sourceలో 7వ భావం business/partnership; Commercial/Business groupకు Mercury, Venus, Rahu మరియు 3/7/11 houses ప్రధాన source indicators.',
      inspection: '${partnership.why} • 7L $d10SeventhLord H${_houseOf(v, v.planets.firstWhere((p) => p.name == d10SeventhLord))}.',
      source: 'D10.pdf pp.46–47 + supplied Profession Rules profession list.',
      tone: partnership.score >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    final graph = D10CareerService.graphWindows(careerWindows, max: 14);
    add(
      id: 'D10-CAREER-GRAPH',
      topic: 'Career Graph — Year / Date Duration',
      result: birthDateTime == null
          ? 'Birth date/time input లేకుండా period graph లెక్కించలేదు.'
          : graph.isEmpty
              ? 'Source thresholdsకు సరిపోయే major career milestone windows ఈ calculated rangeలో కనిపించలేదు.'
              : graph.map((w) {
                  final mark = w.tone == D10CareerTone.favorable ? '🟢' : w.tone == D10CareerTone.caution ? '🔴' : '🟡';
                  return '$mark ${D10CareerService.formatDate(w.start)} → ${D10CareerService.formatDate(w.end)} • ${w.title} • ${w.mahadasha}/${w.antardasha}';
                }).join('\n'),
      rule: 'Career Graph = D10 promise + source-defined Dasha timing. 10th house is the main professional milestone axis. App graph labels only source-supported windows: Career Start, Rise/Promotion, Foreign/Transfer, Downfall/Job-loss caution and Retirement.',
      inspection: birthDateTime == null ? 'Timing input missing.' : '${graph.length} milestone windows displayed from Vimshottari MD/AD source checks.',
      source: 'D10 special.pdf — Chapter 10 Career Graph, pp.173–205 (uploaded PDF pages 22–53).',
      tone: graph.any((w) => w.tone == D10CareerTone.caution) ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: birthDateTime != null,
      auto: birthDateTime != null,
    );

    final rahuHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == 'Rahu'));
    final foreignPromise = D10CareerService.foreignPromise(chart);
    add(
      id: 'D10-FOREIGN-JOB',
      topic: 'Job in Foreign Land',
      result: '${foreignPromise ? '🟢 Birth + D10 foreign-job promise match.' : '△ Full Birth + D10 promise ఈ evaluatorలో match కాలేదు.'}\n${birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'foreign', max: 5)}',
      rule: 'Foreign-job promise: Birth 8L influence Lagna/10H, 10H/10L relation to 9/12, 3H change; same combinations D10లో repeat; D10 8L relation to 10H/10L. Timing Dasha 10/12/9 houses/lordsతో సంబంధం కలిగి ఉండాలి.',
      inspection: '10L H$d10TenthLordHouse • Rahu H$rahuHouse • D10 12H: ${twelfthNames.isEmpty ? 'empty' : twelfthNames.join(', ')} • Promise=${foreignPromise ? 'YES' : 'NO'}.',
      source: 'D10 special.pdf — Job in foreign land, pp.183–188 (uploaded PDF pages 30–35).',
      tone: foreignPromise ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    add(
      id: 'D10-PROMOTION',
      topic: 'Promotion / Higher Position / Salary Rise',
      result: birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'promotion', max: 5),
      rule: 'Promotion: professional lifeలో higher post లేదా higher salary. Birth chartలో 10th/11th and 2nd houses; Dashamshaలో Lagna కూడా important. Dasha 10th, 2nd and 11th houses/lordsను activate చేయాలి.',
      inspection: 'D10 status: 10L $d10TenthLord H$d10TenthLordHouse; 10H ${tenthNames.isEmpty ? 'empty' : tenthNames.join(', ')}. Vimshottari windows D1 2/10/11 + D10 1/2/10/11 convergenceతో ఎంపిక.',
      source: 'D10 special.pdf — Promotion, pp.188–193 (uploaded PDF pages 35–40).',
      tone: careerWindows.any((w) => w.eventKey == 'promotion') ? VargaRuleTone.favorable : VargaRuleTone.info,
      applicable: true,
    );

    final jobLossPromise = D10CareerService.lossPromise(chart);
    add(
      id: 'D10-JOB-LOSS',
      topic: 'Downfall / Loss in Job',
      result: '${jobLossPromise ? '🔴 Job-loss/downfall promise layer ఉంది.' : '△ Full loss-promise layer బలంగా match కాలేదు.'}\n${birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'job_loss', max: 5)}',
      rule: 'Loss of Job: 10th houseను 3rd/9th/12th lords influence చేయడం loss promise. D10లో 3/9/12 activationను చూడాలి. MD favorableగా ఉండి AD adverse అయితే break shorter; MD itself job-support ఇవ్వకపోతే loss longer కావచ్చు.',
      inspection: '8H ${eighthNames.isEmpty ? 'empty' : eighthNames.join(', ')} • 10H ${tenthNames.isEmpty ? 'empty' : tenthNames.join(', ')} • 12H ${twelfthNames.isEmpty ? 'empty' : twelfthNames.join(', ')} • Promise=${jobLossPromise ? 'YES' : 'NO'}.',
      source: 'D10 special.pdf — Loss of Job, pp.193–197 (uploaded PDF pages 40–44).',
      tone: jobLossPromise ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఈ sourceలో నిర్దిష్ట spiritual remedy ఇవ్వలేదు. Caution windowను certaintyగా కాకుండా risk-planning signalగా మాత్రమే చూడాలి; skill-upgrade, financial buffer, documentation, communication వంటి practical safeguards ఉపయోగించండి.',
    );

    if (birthDateTime != null) {
      add(
        id: 'D10-CAREER-CHANGE',
        topic: 'Career Change / Job ↔ Business Switch',
        result: D10CareerService.summarizeWindows(careerWindows, 'career_change', max: 6),
        rule: 'Career-change decision-support: source house meanings ప్రకారం 3H change/effort, 7H business/partnership, 10H profession, 11H gains మరియు 12H loss/change of profession period activationను కలిసి చూడాలి. ఇది standalone classical yoga కాదు; source-described houses convergence మాత్రమే.',
        inspection: 'Vimshottari MD/ADలో D1 + D10 3/7/10/11/12 activation score thresholdతో candidate windows చూపబడతాయి. ఇవి actual-history calibrationకు ఉపయోగపడతాయి కానీ history చూసి threshold auto-change కాదు.',
        source: 'D10 special.pdf — Houses in Dashamsha + Career Graph / Transfer / Loss of Job chapters.',
        tone: careerWindows.any((w) => w.eventKey == 'career_change') ? VargaRuleTone.neutral : VargaRuleTone.info,
        applicable: true,
      );
    }

    final transferSupport = d10TenthLordHouse == 3 || thirdLordHouse == 10 || thirdNames.isNotEmpty;
    add(
      id: 'D10-TRANSFER',
      topic: 'Transfer / Job Location Change',
      result: '${transferSupport ? '3H/3L career-change support ఉంది.' : 'Static transfer support weak/mixed.'}\n${birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'transfer', max: 5)}',
      rule: 'Transfer = change of place for job. Source gives 3rd and 9th houses for change; rise in position/salary houses should also be involved. Dashamsha 12th house shows change of profession. Timing uses the corresponding Dasha lords.',
      inspection: '3H ${thirdNames.isEmpty ? 'empty' : thirdNames.join(', ')} • 3L $d10ThirdLord H$thirdLordHouse • 10L H$d10TenthLordHouse.',
      source: 'D10 special.pdf — Transfer, pp.197–200 (uploaded PDF pages 44–47).',
      tone: transferSupport ? VargaRuleTone.neutral : VargaRuleTone.info,
      applicable: true,
    );

    add(
      id: 'D10-RETIREMENT',
      topic: 'Retirement — Normal / Voluntary / Forced',
      result: birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'retirement', max: 5),
      rule: 'Retirement/end of career may be normal, voluntary or forced. Source activates 3rd, 9th and 12th houses through Dasha; unlike transfer, the lords/planets connected to those houses are important. 5th lord can give forced retirement. App shows late-career candidate windows, not a guaranteed legal retirement date.',
      inspection: 'Retirement window engine uses D1+D10 3/9/12 activation; 5L involvement labels forced/early-retirement caution. Display filter begins at age 48 only as an app safeguard, not as a classical age formula.',
      source: 'D10 special.pdf — Retirement, pp.200–205 (uploaded PDF pages 47–53).',
      tone: careerWindows.any((w) => w.eventKey == 'retirement' && w.tone == D10CareerTone.caution) ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    add(
      id: 'D10-NAKSHATRA-PROF',
      topic: 'నక్షత్ర వృత్తులు',
      result: 'Profession shortlistలో నక్షత్ర వృత్తుల layerను కలపడానికి exact nakshatra→profession source table current filesలో లేదు. Table వచ్చిన వెంటనే top profession scoreలో separate evidenceగా కలపవచ్చు.',
      rule: 'Nakshatra profession mapping source table లేకుండా general astrology mappingను appలో substitute చేయకూడదు.',
      inspection: 'Current shortlist uses D10 10L/10H/Lagna + D1/D9 + sign classification only.',
      source: 'Requested profession layer — source table pending.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );


  }

  static void _d12(
    AstroChartResult chart,
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D12-01',
      cautionId: 'S7-D12-02',
      topic: 'పూర్వీక ఆశీర్వాదం / కుటుంబ రక్షణ',
      favorableResult: 'D12 లగ్నంలో శుభగ్రహ support ఉంది; పూర్వీక/తల్లిదండ్రుల సహకారానికి అనుకూల layer.',
      cautionResult: 'D12 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; కుటుంబ/పూర్వీక అంశంలో కఠిన అనుభవ layer.',
      rule: 'D12లో లగ్నం/లగ్నాధిపతి బలం మరియు శుభ/పాప సంబంధాన్ని పూర్వీక/కుటుంబ patternకు చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D12, supplied “Sarala 7 final.pdf” p.9',
      add: add,
    );

    final motherHouse = _houseNames(v, 4);
    final fatherHouse = _houseNames(v, 9);
    final moonD12 = v.planets.firstWhere((p) => p.name == 'Moon');
    final sunD12 = v.planets.firstWhere((p) => p.name == 'Sun');
    final moonHouse = _houseOf(v, moonD12);
    final sunHouse = _houseOf(v, sunD12);
    final h4Lord = _signLord(_houseSign(v, 4));
    final h9Lord = _signLord(_houseSign(v, 9));
    final h4LordHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == h4Lord));
    final h9LordHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == h9Lord));

    final motherChecks = <bool>[
      motherHouse.any(_benefics.contains),
      {1, 4, 5, 7, 9, 10, 11}.contains(h4LordHouse),
      {1, 4, 5, 7, 9, 10, 11}.contains(moonHouse),
    ];
    final fatherChecks = <bool>[
      fatherHouse.any(_benefics.contains),
      {1, 4, 5, 7, 9, 10, 11}.contains(h9LordHouse),
      {1, 4, 5, 7, 9, 10, 11}.contains(sunHouse),
    ];
    final mPct = (100 * motherChecks.where((x) => x).length / motherChecks.length).round();
    final fPct = (100 * fatherChecks.where((x) => x).length / fatherChecks.length).round();
    add(
      id: 'D12-MOTHER-EVIDENCE',
      topic: 'తల్లి / మాతృవంశ support — $mPct%',
      result: 'D12 4H + 4L + Moon evidence coverage $mPct%.',
      rule: 'D12లో తల్లి/మాతృవంశానికి 4వ భావం, 4వ అధిపతి, చంద్రుడిని కలిపి చూడాలి.',
      inspection: 'D12 4H=${motherHouse.isEmpty ? 'empty' : motherHouse.join(', ')}; 4L=$h4Lord H$h4LordHouse; Moon=H$moonHouse.',
      source: 'Sarala VII D12 + remidi.pdf D12 lineage support. % is app evidence coverage, not probability.',
      tone: mPct >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );
    add(
      id: 'D12-FATHER-EVIDENCE',
      topic: 'తండ్రి / పితృవంశ support — $fPct%',
      result: 'D12 9H + 9L + Sun evidence coverage $fPct%.',
      rule: 'D12లో తండ్రి/పితృవంశానికి 9వ భావం, 9వ అధిపతి, సూర్యుడిని కలిపి చూడాలి.',
      inspection: 'D12 9H=${fatherHouse.isEmpty ? 'empty' : fatherHouse.join(', ')}; 9L=$h9Lord H$h9LordHouse; Sun=H$sunHouse.',
      source: 'Sarala VII D12 + remidi.pdf D12 lineage support. % is app evidence coverage, not probability.',
      tone: fPct >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );
  }

  static void _d16(
    AstroChartResult chart,
    VargaChartData v,
    DateTime? birthDateTime,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    final d1FourthSign = (chart.ascendantSignIndex + 3) % 12;
    final d1FourthLord = _signLord(d1FourthSign);
    final d1FourthLordPlanet = chart.planets.firstWhere((p) => p.name == d1FourthLord);
    final d1FourthLordHouse = ((d1FourthLordPlanet.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final d1Venus = chart.planets.firstWhere((p) => p.name == 'Venus');
    final d1VenusHouse = ((d1Venus.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final d16Lagna = _houseNames(v, 1);
    final d16Fourth = _houseNames(v, 4);
    final venusD16 = v.planets.firstWhere((p) => p.name == 'Venus');
    final venusD16House = _houseOf(v, venusD16);
    final fifthFromVenusSign = (venusD16.signIndex + 4) % 12;
    final fifthFromVenus = v.planets.where((p) => p.signIndex == fifthFromVenusSign).map((p) => p.name).toList();

    final opportunityChecks = <bool>[
      {1, 4, 5, 7, 9, 10, 11}.contains(d1FourthLordHouse),
      {1, 4, 5, 7, 9, 10, 11}.contains(d1VenusHouse),
      d16Lagna.any(_benefics.contains),
      d16Fourth.any(_benefics.contains),
      {1, 4, 5, 7, 9, 10, 11}.contains(venusD16House),
      fifthFromVenus.any(_benefics.contains),
    ];
    final matched = opportunityChecks.where((x) => x).length;
    final vehiclePct = (100 * matched / opportunityChecks.length).round();
    add(
      id: 'D16-VEHICLE-EVIDENCE',
      topic: 'వాహనం పొందే అవకాశం — Evidence $vehiclePct%',
      result: 'D1 4H/4L + Venus + D16 Lagna/4H + D16 Venus + Venus నుంచి 5వ స్థానం evidenceలో $matched/${opportunityChecks.length} support blocks match అయ్యాయి.',
      rule: 'వాహనానికి D1 4వ భావం/4వ అధిపతి/శుక్రుడు primary; D16 లగ్నం, 4వ భావం, శుక్రుడు మరియు Venus నుంచి 5వ స్థానం confirmationగా చూడాలి.',
      inspection: 'D1 4L=$d1FourthLord H$d1FourthLordHouse; D1 Venus=H$d1VenusHouse; D16 Lagna=${d16Lagna.isEmpty ? 'empty' : d16Lagna.join(', ')}; D16 4H=${d16Fourth.isEmpty ? 'empty' : d16Fourth.join(', ')}; D16 Venus=H$venusD16House; 5th from Venus=${fifthFromVenus.isEmpty ? 'empty' : fifthFromVenus.join(', ')}.',
      source: 'D1/D16 vehicle framework + remidi.pdf D16 Venus-from-5th support. % is app evidence coverage, not probability.',
      tone: vehiclePct >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    final d16VenusCompanions = v.planets.where((p) => p.signIndex == venusD16.signIndex && p.name != 'Venus').map((p) => p.name).toList();
    final luxuryChecks = <bool>[
      {1, 4, 5, 7, 9, 10, 11}.contains(venusD16House),
      d16Fourth.any((p) => p == 'Venus' || p == 'Jupiter' || p == 'Mercury'),
      fifthFromVenus.any(_benefics.contains),
      d16VenusCompanions.any(_benefics.contains),
    ];
    final luxuryMatched = luxuryChecks.where((x) => x).length;
    final luxuryPct = (100 * luxuryMatched / luxuryChecks.length).round();
    add(
      id: 'D16-LUXURY-COMFORT',
      topic: 'వాహన సౌఖ్యం / విలాస స్థాయి — Evidence $luxuryPct%',
      result: 'D16 Venus + 4H + Venus నుంచి 5వ స్థానం + benefic companyలో $luxuryMatched/${luxuryChecks.length} support blocks match అయ్యాయి.',
      rule: 'D16లో శుక్రుడు, 4వ భావం మరియు Venus నుంచి 5వ స్థానం వాహన/సౌఖ్య స్థాయికి confirmation layersగా ఉపయోగించాలి.',
      inspection: 'D16 Venus=H$venusD16House; 4H=${d16Fourth.isEmpty ? 'empty' : d16Fourth.join(', ')}; 5th from Venus=${fifthFromVenus.isEmpty ? 'empty' : fifthFromVenus.join(', ')}; Venus companions=${d16VenusCompanions.isEmpty ? 'none' : d16VenusCompanions.join(', ')}.',
      source: 'D16 vehicle/comfort source framework + remidi.pdf D16 layer. % is evidence coverage only.',
      tone: luxuryPct >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    final delayChecks = <bool>[
      {6, 8, 12}.contains(venusD16House),
      d16Fourth.any(_malefics.contains),
      d16VenusCompanions.any(_malefics.contains),
    ];
    final delayMatched = delayChecks.where((x) => x).length;
    final delayPct = (100 * delayMatched / delayChecks.length).round();
    add(
      id: 'D16-VEHICLE-DELAY',
      topic: 'వాహన ఆలస్యం / ఇబ్బంది — Evidence $delayPct%',
      result: '$delayMatched/${delayChecks.length} caution blocks match అయ్యాయి. ఇది delay/maintenance evidence మాత్రమే; ప్రమాదం లేదా వాహనం రాదని హామీ కాదు.',
      rule: 'D16 Venus dusthana placement, 4H malefic influence మరియు Venus malefic companyను vehicle delay/trouble confirmationగా చూడాలి.',
      inspection: 'Venus=H$venusD16House; D16 4H=${d16Fourth.isEmpty ? 'empty' : d16Fourth.join(', ')}; Venus companions=${d16VenusCompanions.isEmpty ? 'none' : d16VenusCompanions.join(', ')}.',
      source: 'Sarala VII D16 + app evidence synthesis. % is evidence coverage only.',
      tone: delayPct >= 67 ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    final cautionPlanets = [4, 6, 8].expand((h) => _houseNames(v, h)).where(_malefics.contains).toList();
    final cautionPct = ((cautionPlanets.length.clamp(0, 4) / 4) * 100).round();
    if (cautionPlanets.isNotEmpty) {
      add(
        id: 'D16-VEHICLE-CAUTION',
        topic: 'వాహన జాగ్రత్త — Evidence $cautionPct%',
        result: 'D16 4/6/8లో ${cautionPlanets.join(', ')} పాప ప్రభావం ఉంది. ఇది వాహన/ప్రయాణ జాగ్రత్త evidence మాత్రమే; ప్రమాదం ఖచ్చితమని కాదు.',
        rule: 'D16లో 4/6/8 సంబంధం మరియు పాప ప్రభావాన్ని vehicle trouble/caution layerగా పరిశీలించాలి.',
        inspection: 'D16 4/6/8 malefic count=${cautionPlanets.length}.',
        source: 'Sarala VII D16 pp.11–12. % is app evidence coverage, not accident probability.',
        tone: VargaRuleTone.caution,
        applicable: true,
      );
    }
  }

  static void _d20(
    AstroChartResult chart,
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 5,
      favorableId: 'S7-D20-01',
      cautionId: 'S7-D20-02',
      topic: 'బుద్ధి / ఆధ్యాత్మిక సాధన',
      favorableResult: 'D20 5వ భావంలో శుభగ్రహ support ఉంది; ఆధ్యాత్మిక బుద్ధి/సాధనకు అనుకూల layer.',
      cautionResult: 'D20 5వ భావంలో పాపగ్రహ ప్రభావం ఉంది; సాధనలో అడ్డంకి layer.',
      rule: 'D20లో 5వ భావం, 5వ అధిపతి, Lagna/Moon/Jupiter సంబంధాన్ని Upasana/Ishta Devata selectionలో పరిశీలించాలి.',
      source: 'Sarala VII D20 + remidi.pdf D20 Upasana/Ishta framework',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D20-03',
      cautionId: 'S7-D20-04',
      topic: 'ధర్మ / గురు మార్గం',
      favorableResult: 'D20 9వ భావంలో శుభగ్రహ support ఉంది; ధర్మ/గురు మార్గానికి అనుకూల layer.',
      cautionResult: 'D20 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ధర్మ/గురు మార్గంలో అడ్డంకి layer.',
      rule: 'D20లో 9వ భావం/9వ అధిపతి ధర్మ, గురు, సాధన మార్గాన్ని support చేస్తాయి.',
      source: 'Sarala VII D20 + remidi.pdf',
      add: add,
    );

    final fifthLord = _signLord(_houseSign(v, 5));
    final ninthLord = _signLord(_houseSign(v, 9));
    final fifthLordHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == fifthLord));
    final ninthLordHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == ninthLord));
    final fifthDevi = _mahavidyaForPlanet(fifthLord);
    final ninthDevi = _mahavidyaForPlanet(ninthLord);
    final lagnaDevi = 'Tripura Bhairavi';
    add(
      id: 'D20-MAHAVIDYA-GUIDE',
      topic: 'D20 ఉపాసన సారాంశం / Summary',
      result: 'ప్రధాన పూజా సూచన: $fifthDevi. ద్వితీయ సహాయం: $ninthDevi. లగ్న support: $lagnaDevi. ఇది later Mahavidya correspondence layer; classical BPHS prescription కాదు.',
      rule: 'remidi.pdf D20 framework 5th-from-Lagna/Moon/Jupiter మరియు Ishta/Upasana Devata selectionను ఉపయోగిస్తుంది. Mahavidya planet correspondence మాత్రం modern Jyotisha/Tantric tradition layer; classical BPHS ruleగా చూపకూడదు.',
      inspection: 'D20 5L=$fifthLord H$fifthLordHouse; D20 9L=$ninthLord H$ninthLordHouse; Lagna sign=${v.ascendantSignIndex + 1}.',
      source: 'remidi.pdf — D20 Ishta/Upasana framework; Mahavidya correspondence cross-check: Parasara.net + Musinara (web research 2026-10-10).',
      tone: VargaRuleTone.info,
      applicable: true,
      remedy: 'సాధారణ భక్తి/నామస్మరణ/దేవాలయ ప్రార్థనను మాత్రమే app సూచించాలి. Formal Tantric sadhana, beeja mantra, nyasa/homa వంటి initiation-based practicesకు qualified Guru guidance అవసరం.',
    );

    add(
      id: 'D20-PRIMARY-UPASANA',
      topic: 'ఎందుకు ఈ దేవత? / Why this deity?',
      result: 'Primary: D20 5వ అధిపతి $fifthLord → $fifthDevi. Secondary: D20 9వ అధిపతి $ninthLord → $ninthDevi. Lagna support → $lagnaDevi. ఈ card కారణం/actual matchను మాత్రమే వివరిస్తుంది; పూర్తి correspondence క్రింది reference cardలో ఉంది.',
      rule: 'D20 Upasana selectionలో 5వ భావ/5Lను primary devotion, 9వ భావ/9Lను dharma/guru supportగా చూపాలి. Mahavidya correspondenceను supportive later-tradition mappingగా మాత్రమే ఉపయోగించాలి.',
      inspection: '5L=$fifthLord H$fifthLordHouse → $fifthDevi; 9L=$ninthLord H$ninthLordHouse → $ninthDevi.',
      source: 'remidi.pdf D20 Upasana/Ishta framework + clearly-labelled later Mahavidya correspondence.',
      tone: VargaRuleTone.info,
      applicable: true,
      remedy: 'సాధారణ పూజ/నామస్మరణ/దేవాలయ దర్శనం మాత్రమే. Initiation-based Tantra, beeja, nyasa లేదా homaకు qualified Guru guidance అవసరం.',
    );

    add(
      id: 'D20-MAHAVIDYA-MAP',
      topic: 'దశ మహావిద్య పూర్తి correspondence',
      result: 'Sun → Matangi; Moon → Bhuvaneshwari; Mars → Bagalamukhi; Mercury → Tripura Sundari / Shodashi; Jupiter → Tara; Venus → Kamala; Saturn → Kali; Rahu → Chhinnamasta; Ketu → Dhumavati; Lagna support → Tripura Bhairavi. ఇది later Jyotisha/Tantric correspondence reference మాత్రమే.',
      rule: 'ఈ mapping later Jyotisha/Tantric correspondence; chart prescription కాదు. D20 source frameworkతో కలిపి supportive devotional referenceగా మాత్రమే వాడాలి.',
      inspection: 'Current D20 relevant lords: 5L=$fifthLord, 9L=$ninthLord.',
      source: 'External research cross-check: Parasara.net / Musinara; not an older BPHS source rule.',
      tone: VargaRuleTone.info,
      applicable: true,
      auto: true,
    );
  }

  static void _d24(
    AstroChartResult chart,
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    List<String> houseNames(int house) => _houseNames(v, house);
    List<String> beneficsIn(int house) =>
        houseNames(house).where(_benefics.contains).toList(growable: false);

    VargaPlacement? placementOf(String name) {
      for (final p in v.planets) {
        if (p.name == name) return p;
      }
      return null;
    }

    int? houseOfPlanet(String name) {
      final p = placementOf(name);
      return p == null ? null : _houseOf(v, p);
    }

    List<String> companionsOf(String name) {
      final p = placementOf(name);
      if (p == null) return const <String>[];
      return v.planets
          .where((x) => x.signIndex == p.signIndex && x.name != name)
          .map((x) => x.name)
          .toList(growable: false);
    }

    String lordOfHouse(int house) => _signLord(_houseSign(v, house));

    bool sameSign(String a, String b) {
      final pa = placementOf(a);
      final pb = placementOf(b);
      return pa != null && pb != null && pa.signIndex == pb.signIndex;
    }

    void houseRule(
      int house,
      String code,
      String topic,
      String favorable,
      String caution,
      String rule,
      String source,
    ) {
      final names = houseNames(house);
      final ben = names.where(_benefics.contains).toList(growable: false);
      final mal = names.where(_malefics.contains).toList(growable: false);
      if (ben.isEmpty && mal.isEmpty) return;

      final mixed = ben.isNotEmpty && mal.isNotEmpty;
      final tone = mixed
          ? VargaRuleTone.neutral
          : ben.isNotEmpty
              ? VargaRuleTone.favorable
              : VargaRuleTone.caution;
      final result = mixed
          ? '$topicలో శుభ మరియు పాప ప్రభావాలు రెండూ ఉన్నాయి. అనుకూలత కొనసాగినా మధ్యలో ఆటంకం/మార్పు అవకాశం ఉంటుంది; దీనిని ఒకే mixed net-resultగా చూడాలి.'
          : ben.isNotEmpty
              ? favorable
              : caution;

      add(
        id: 'EDU-D24-$code',
        topic: topic,
        result: result,
        rule: rule,
        inspection:
            'D24 $houseవ భావం: ${names.isEmpty ? 'గ్రహాలు లేవు' : names.join(', ')}. శుభగ్రహాలు: ${ben.isEmpty ? 'లేవు' : ben.join(', ')}; పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
        source: source,
        tone: tone,
        applicable: true,
      );
    }

    void educationLevelRule(
      int house,
      String code,
      String levelLabel,
    ) {
      final names = houseNames(house);
      final lord = lordOfHouse(house);
      final lordCompanions = companionsOf(lord);
      final directBen = <String>{
        ...names.where(_benefics.contains),
        ...lordCompanions.where(_benefics.contains),
      }.toList(growable: false);
      final directMal = <String>{
        ...names.where(_malefics.contains),
        ...lordCompanions.where(_malefics.contains),
      }.toList(growable: false);

      final mixed = directBen.isNotEmpty && directMal.isNotEmpty;
      final noDirect = directBen.isEmpty && directMal.isEmpty;
      final tone = noDirect || mixed
          ? VargaRuleTone.neutral
          : directBen.isNotEmpty
              ? VargaRuleTone.favorable
              : VargaRuleTone.caution;
      final continuity = noDirect
          ? 'ప్రత్యక్ష strong support/caution trigger ఈ simple evaluatorలో కనిపించలేదు. దీనిని “చదువు లేదు” అని అర్థం చేసుకోకూడదు; house lord, field suitability మరియు timingతో cross-check చేయాలి.'
          : mixed
              ? 'అనుకూల మరియు ఆటంక సూచనలు రెండూ ఉన్నాయి; ప్రయత్నంతో కొనసాగగల mixed support.'
              : directBen.isNotEmpty
                  ? 'అనుకూల support ఉంది.'
                  : 'delay/change/extra effort caution ఉంది; ఇది education denial కాదు.';

      // User-requested stage-wise study-environment indicators. Foreign / Hostel /
      // Away / Break are not shown as detached global results; they belong to the
      // education stage (4H / 9H / 2H / 7H) in which they are indicated.
      final l9 = lordOfHouse(9);
      final l12 = lordOfHouse(12);
      final lordHouse = houseOfPlanet(lord);
      final l9House = houseOfPlanet(l9);
      final l12House = houseOfPlanet(l12);

      final has12Link = lord == l12 ||
          sameSign(lord, l12) ||
          lordHouse == 12 ||
          l12House == house;
      final has9Link = house == 9 ||
          lord == l9 ||
          sameSign(lord, l9) ||
          lordHouse == 9 ||
          l9House == house;
      final foreignStudy = has12Link && has9Link;

      final breakTriggers = <String>{
        ...names.where((x) => x == 'Rahu' || x == 'Ketu'),
        ...lordCompanions.where((x) => x == 'Rahu' || x == 'Ketu'),
      }.toList(growable: false);
      final breakPossible = breakTriggers.isNotEmpty;
      final resumeSupport = breakPossible && directBen.isNotEmpty;

      final stageLines = <String>[
        '$levelLabel: $continuity',
        'Hostel / ఇంటికి దూరంగా చదువు: ${has12Link ? 'అనుకూల సూచన ఉంది.' : 'బలమైన సూచన లేదు.'}',
        'Foreign Education: ${foreignStudy ? 'ఈ విద్యా దశలో foreign-study support ఉంది.' : 'ఈ విద్యా దశలో బలమైన foreign-study సూచన లేదు.'}',
        'Break / Interruption: ${breakPossible ? '${breakTriggers.join(', ')} ప్రభావంతో break/change అవకాశం ఉంది.' : 'బలమైన break సూచన లేదు.'}',
        if (resumeSupport) 'Resume after Break: శుభ support వల్ల break తర్వాత చదువు మళ్లీ కొనసాగించే అవకాశం ఉంది.',
      ];

      add(
        id: 'EDU-D24-$code',
        topic: 'Education Continuity / విద్య సాగే స్థాయి — $levelLabel',
        result: stageLines.join('\n'),
        rule: 'User master Education Continuity rule: 4H = School/Intermediate వరకు; 9H = Degree/B.Tech వరకు; 2H = PG వరకు; 7H = Post-PG వరకు. ఈ ladder విద్య ఎంతవరకు/ఎలా కొనసాగుతుందో చెబుతుంది. Hostel/away, Foreign, Break/Resume సూచనలు ఏ stageలో వస్తాయో అదే stage rowలో చూపాలి. ఏ subject/course చదవాలో ఈ ladder నిర్ణయించదు.',
        inspection: 'D24 ${house}H occupants=${names.isEmpty ? 'లేవు' : names.join(', ')}; ${house}H lord=$lord (house ${lordHouse ?? '-'}); lord companions=${lordCompanions.isEmpty ? 'లేవు' : lordCompanions.join(', ')}; support=${directBen.isEmpty ? 'లేదు' : directBen.join(', ')}; caution=${directMal.isEmpty ? 'లేదు' : directMal.join(', ')}; 9L=$l9 (house ${l9House ?? '-'}); 12L=$l12 (house ${l12House ?? '-'}); 12-link=$has12Link; 9-link=$has9Link; foreign=$foreignStudy; break triggers=${breakTriggers.isEmpty ? 'లేవు' : breakTriggers.join(', ')}; resume support=$resumeSupport.',
        source: 'User-provided D24 Education Master Rule; Education.pdf guideline for 12H/away, 9H+12H foreign study and Rahu/Ketu interruption cross-check.',
        tone: tone,
        applicable: true,
      );
    }

    houseRule(
      1,
      'LAGNA',
      'D24 లగ్నం — చదువుపై కోరిక',
      'D24 లగ్నానికి శుభ support ఉంది; చదువుపై ఆసక్తి మరియు విద్యను కొనసాగించే కోరికకు అనుకూల సూచన.',
      'D24 లగ్నంపై పాప ప్రభావం ఉంది; చదువులో compulsion, delay లేదా extra effort అవసరమయ్యే సూచన.',
      'Education.pdfలో D24/Chaturvimshamsha Lagnaను desire to studyగా పరిశీలిస్తుంది; benefic/malefic supportతో desire strengthను cross-check చేయాలి.',
      'Education.pdf pp. 23, 35, 38, 50, 59',
    );

    final sunCompanions = companionsOf('Sun');
    final sunBen = sunCompanions.where(_benefics.contains).toList(growable: false);
    final sunMal = sunCompanions.where((x) => _malefics.contains(x)).toList(growable: false);
    if (sunBen.isNotEmpty || sunMal.isNotEmpty) {
      final mixed = sunBen.isNotEmpty && sunMal.isNotEmpty;
      add(
        id: 'EDU-D24-SUN',
        topic: 'సూర్యుడు — Dedication / Inner Drive',
        result: mixed
            ? 'చదువుపై dedication ఉంది, కానీ పాప conjunction వల్ల ఒత్తిడి/అడ్డంకి కూడా కలిసివచ్చే mixed indication.'
            : sunBen.isNotEmpty
                ? 'చదువుపై dedication మరియు inner urgeకు అనుకూల support ఉంది.'
                : 'చదువుపై dedication ఉన్నప్పటికీ పాప conjunction వల్ల pressure/delay caution ఉంది.',
        rule: 'Education.pdfలో Sunను dedication/inner urge కోసం పరిశీలిస్తుంది. ఈ buildలో source-safe auto-checkగా Sunతో ప్రత్యక్ష conjunction support/affliction మాత్రమే ఉపయోగించబడింది.',
        inspection:
            'Sunతో ఉన్న గ్రహాలు: ${sunCompanions.isEmpty ? 'లేవు' : sunCompanions.join(', ')}. శుభ support: ${sunBen.isEmpty ? 'లేదు' : sunBen.join(', ')}; పాప influence: ${sunMal.isEmpty ? 'లేదు' : sunMal.join(', ')}.',
        source: 'Education.pdf pp. 2, 8, 26, 59, 65',
        tone: mixed
            ? VargaRuleTone.neutral
            : sunBen.isNotEmpty
                ? VargaRuleTone.favorable
                : VargaRuleTone.caution,
        applicable: true,
      );
    }

    final moonCompanions = companionsOf('Moon');
    final moonBen = moonCompanions.where((x) => x == 'Jupiter' || x == 'Mercury' || x == 'Venus').toList(growable: false);
    final moonMal = moonCompanions.where((x) => x == 'Mars' || x == 'Saturn' || x == 'Rahu' || x == 'Ketu' || x == 'Sun').toList(growable: false);
    if (moonBen.isNotEmpty || moonMal.isNotEmpty) {
      final mixed = moonBen.isNotEmpty && moonMal.isNotEmpty;
      add(
        id: 'EDU-D24-MOON',
        topic: 'చంద్రుడు — Mind / Learning Capacity',
        result: mixed
            ? 'Learning capacity ఉంది; అయితే distraction/mental pressure కూడా కలిసివచ్చే mixed indication.'
            : moonBen.isNotEmpty
                ? 'గ్రహణశక్తి, concentration మరియు learning capacityకు అనుకూల support ఉంది.'
                : 'Learningలో distraction, mental pressure లేదా slow/aggressive learning caution కనిపిస్తోంది.',
        rule: 'Education.pdfలో Moonను mental inclination/learning కోసం ఉపయోగిస్తుంది; Jupiter/Mercury supportను అనుకూలంగా, malefic afflictionను learning difficultyగా case rulesలో పరిశీలిస్తుంది. ఈ build ప్రత్యక్ష conjunction evidence మాత్రమే auto-check చేస్తుంది.',
        inspection:
            'Moonతో ఉన్న గ్రహాలు: ${moonCompanions.isEmpty ? 'లేవు' : moonCompanions.join(', ')}. Learning support: ${moonBen.isEmpty ? 'లేదు' : moonBen.join(', ')}; pressure factors: ${moonMal.isEmpty ? 'లేదు' : moonMal.join(', ')}.',
        source: 'Education.pdf pp. 2, 5, 20, 23, 35, 44, 47, 59',
        tone: mixed
            ? VargaRuleTone.neutral
            : moonBen.isNotEmpty
                ? VargaRuleTone.favorable
                : VargaRuleTone.caution,
        applicable: true,
      );
    }

    // USER MASTER ENGINE A — EDUCATION CONTINUITY / LEVEL.
    // This ladder answers only: "విద్య ఎంతవరకు/ఎలా సాగుతుంది?"
    // It must NOT be used to decide the subject/course. Always return a
    // guidance row so an empty house is never misread as “no education”.
    educationLevelRule(4, 'LEVEL-INTER', 'Intermediate వరకు');
    educationLevelRule(9, 'LEVEL-DEGREE', 'Degree / B.Tech వరకు');
    educationLevelRule(2, 'LEVEL-PG', 'PG వరకు');
    educationLevelRule(7, 'LEVEL-POSTPG', 'Post-PG వరకు');

    // Education.pdf research/deeper-knowledge layer is retained as a
    // supporting rule, separate from the user-defined education-level ladder.
    houseRule(
      8,
      'H8',
      '8వ భావం — Research / Deeper Knowledge',
      '8వ భావానికి శుభ support ఉంది; research/deeper knowledgeకు అనుకూల సూచన.',
      '8వ భావంపై పాప ప్రభావం ఉంది; deep-study/research pathలో obstacle/break caution.',
      'Education.pdf guidelineలో 8Hను research/occult/deeper knowledgeకు పరిశీలిస్తుంది.',
      'Education.pdf pp. 2, 22, 23',
    );

    // Foreign / Hostel / Away / Break / Resume are evaluated inside each
    // 4H / 9H / 2H / 7H education stage above, so the client can see exactly
    // at which level the indication belongs. Detached global cards are avoided.

    // ------------------------------------------------------------------
    // USER MASTER ENGINE B — EDUCATION FIELD / WHAT TO STUDY.
    // This engine answers only: "ఏం చదవాలి / ఏం చదువుతారు?"
    // 5th-house starting point + 15° -> Nakshatra -> Nakshatra lord ->
    // lord's D24 sign -> sign nature. Then combine education fields from:
    //   1) that sign,
    //   2) planets occupying that sign,
    //   3) planets aspecting the Nakshatra lord.
    // Finally retain the fields that fit the sign nature and rank them by a
    // transparent suitability score: sign 40% + occupants 35% + aspects 25%.
    // ------------------------------------------------------------------
    double norm360(double value) {
      var x = value % 360.0;
      if (x < 0) x += 360.0;
      return x;
    }

    String pointText(double longitude) {
      final x = norm360(longitude);
      final sign = (x / 30.0).floor() % 12;
      final deg = x % 30.0;
      var d = deg.floor();
      final minuteFloat = (deg - d) * 60.0;
      var m = minuteFloat.floor();
      var sec = ((minuteFloat - m) * 60.0).round();
      if (sec == 60) {
        sec = 0;
        m += 1;
      }
      if (m == 60) {
        m = 0;
        d += 1;
      }
      return '${_d10SignNames[sign]} ${d.toString().padLeft(2, '0')}° ${m.toString().padLeft(2, '0')}′ ${sec.toString().padLeft(2, '0')}″';
    }

    bool grahaAspects(String planet, int fromSign, int toSign) {
      final diff = (toSign - fromSign + 12) % 12;
      if (diff == 6) return true; // universal 7th aspect
      return switch (planet) {
        'Mars' => diff == 3 || diff == 7,       // 4th / 8th
        'Jupiter' => diff == 4 || diff == 8,    // 5th / 9th
        'Saturn' => diff == 2 || diff == 9,     // 3rd / 10th
        _ => false,
      };
    }

    const nakshatraLords = <String>[
      'Ketu', 'Venus', 'Sun', 'Moon', 'Mars', 'Rahu', 'Jupiter', 'Saturn', 'Mercury',
    ];

    final d24Ascendant = VargaService.d24LongitudeForLongitude(chart.ascendantLongitude);
    final fifthHouseStart = norm360(d24Ascendant + 120.0);
    final educationPoint = norm360(fifthHouseStart + 15.0);
    const nakshatraSpan = 360.0 / 27.0;
    final nakshatraIndex = (educationPoint / nakshatraSpan).floor() % 27;
    final nakshatraName = VedicCalculationService.nakshatraNamesTe[nakshatraIndex];
    final nakshatraLord = nakshatraLords[nakshatraIndex % 9];
    final nakLordPlacement = placementOf(nakshatraLord);

    if (nakLordPlacement != null) {
      final lordSign = nakLordPlacement.signIndex;
      final lordSignName = _d10SignNames[lordSign];
      final nature = D24EducationRegistry.natureForSign(lordSign);
      final signEducation = D24EducationRegistry.educationForSign(lordSign);
      final allowedForNature = D24EducationRegistry.educationAllowedForNature(nature);

      final occupants = v.planets
          .where((p) => p.signIndex == lordSign)
          .map((p) => p.name)
          .toList(growable: false);
      final aspecting = v.planets
          .where((p) => p.name != nakshatraLord && grahaAspects(p.name, p.signIndex, lordSign))
          .map((p) => p.name)
          .toList(growable: false);

      final candidateFields = <String>{...signEducation};
      for (final planet in occupants) {
        candidateFields.addAll(D24EducationRegistry.educationForPlanet(planet));
      }
      for (final planet in aspecting) {
        candidateFields.addAll(D24EducationRegistry.educationForPlanet(planet));
      }

      final scored = <(String, int, List<String>)>[];
      for (final field in candidateFields) {
        if (!allowedForNature.contains(field)) continue;

        final evidence = <String>[];
        var score = 0.0;
        if (signEducation.contains(field)) {
          score += 40.0;
          evidence.add('$lordSignName రాశి విద్య');
        }

        final occupantSupport = occupants
            .where((planet) => D24EducationRegistry.educationForPlanet(planet).contains(field))
            .toList(growable: false);
        if (occupantSupport.isNotEmpty) {
          final denominator = occupants.isEmpty ? 1 : occupants.length;
          score += 35.0 * occupantSupport.length / denominator;
          evidence.add('స్థితి గ్రహాలు: ${occupantSupport.join(', ')}');
        }

        final aspectSupport = aspecting
            .where((planet) => D24EducationRegistry.educationForPlanet(planet).contains(field))
            .toList(growable: false);
        if (aspectSupport.isNotEmpty) {
          final denominator = aspecting.isEmpty ? 1 : aspecting.length;
          score += 25.0 * aspectSupport.length / denominator;
          evidence.add('దృష్టి గ్రహాలు: ${aspectSupport.join(', ')}');
        }

        if (score > 0) {
          scored.add((field, score.round().clamp(1, 100).toInt(), evidence));
        }
      }
      scored.sort((a, b) {
        final byScore = b.$2.compareTo(a.$2);
        return byScore != 0 ? byScore : a.$1.compareTo(b.$1);
      });

      final rankedText = scored.isEmpty
          ? 'ఈ రాశి తత్వానికి సరిపోయే course mapping ప్రస్తుతం లేదు.'
          : scored.map((x) => '${x.$1} — ${x.$2}%').join('\n');
      final evidenceText = scored.isEmpty
          ? 'లేదు'
          : scored.map((x) => '${x.$1}: ${x.$3.join(' + ')}').join('; ');

      add(
        id: 'EDU-D24-SELECTION-POINT',
        topic: 'Education Field / చదవవలసిన విద్య — 5వ భావం +15° Selection Point',
        result: '5వ భావం ప్రారంభం ${pointText(fifthHouseStart)}; +15° తర్వాత ${pointText(educationPoint)}. అక్కడ $nakshatraName నక్షత్రం; నక్షత్ర లార్డ్ $nakshatraLord.',
        rule: 'User master Education Field rule: D24 5th house starting pointకి +15° కలిపి, ఆ pointలోని నక్షత్రాన్ని మరియు నక్షత్ర లార్డ్‌ను తీసుకోవాలి. ఈ engine subject/course selection కోసం మాత్రమే; education level/continuity కోసం కాదు.',
        inspection: 'D24 Lagna ${pointText(d24Ascendant)} → 5H start ${pointText(fifthHouseStart)} → +15° ${pointText(educationPoint)} → Nakshatra $nakshatraName (#${nakshatraIndex + 1}) → Lord $nakshatraLord.',
        source: 'User-provided D24 Education Master Rule',
        tone: VargaRuleTone.info,
        applicable: true,
      );

      add(
        id: 'EDU-D24-SIGN-NATURE',
        topic: 'Education Field / చదవవలసిన విద్య — విద్యా స్వభావం',
        result: '$nakshatraName నక్షత్ర లార్డ్ $nakshatraLord D24లో $lordSignName రాశిలో ఉన్నాడు → $nature.',
        rule: 'User master Education Field classification: Nakshatra lord ఉన్న రాశి ద్వారా Technical / Semi-technical / Non-technical nature నిర్ణయించాలి. Technical = Aries, Scorpio, Capricorn, Aquarius; Semi-technical = Gemini, Leo, Virgo; Non-technical = Taurus, Cancer, Libra, Sagittarius, Pisces. ఇది ఏమి చదవాలి/ఏం చదువుతారు అనే shortlistకు base.',
        inspection: 'Nakshatra lord $nakshatraLord; D24 sign $lordSignName; category $nature.',
        source: 'User-provided D24 Education Master Rule',
        tone: VargaRuleTone.info,
        applicable: true,
      );

      add(
        id: 'EDU-D24-COURSE-SUITABILITY',
        topic: 'Education Field / చదవవలసిన విద్య — అనుకూల విద్యలు %',
        result: 'Education Nature: $nature. అనుకూల విద్యలు:\n$rankedText',
        rule: 'User master Education Field rule: Nakshatra lord ఉన్న రాశి విద్యలు + ఆ రాశిలో స్థితి పొందిన గ్రహాల విద్యలు + Nakshatra lordను చూస్తున్న గ్రహాల విద్యలు కలిపి, ఆ రాశి Technical / Semi-technical / Non-technical తత్వానికి సరిపోయే విద్యలను మాత్రమే బయటకు తీయాలి. ఈ output "ఏం చదవాలి / ఏం చదువుతారు" అనే guidance. Suitability score = sign support 40% + same-sign planet support 35% + aspecting-planet support 25%. ఈ శాతం probability కాదు; matching-evidence score.',
        inspection: '5H start=${pointText(fifthHouseStart)}; +15°=${pointText(educationPoint)}; Nakshatra=$nakshatraName; Nakshatra lord=$nakshatraLord; Lord sign=$lordSignName ($nature); sign education=${signEducation.join(', ')}; same-sign planets=${occupants.isEmpty ? 'లేవు' : occupants.join(', ')}; aspecting planets=${aspecting.isEmpty ? 'లేవు' : aspecting.join(', ')}; course evidence=$evidenceText.',
        source: 'User-provided D24 Education Master Rule + app advisory sign/planet education mapping. Percentages are evidence-match scores, not probabilities.',
        tone: VargaRuleTone.favorable,
        applicable: scored.isNotEmpty,
      );

      final signLord = _signLord(lordSign);
      final lordProfessions = _d10ProfessionCatalog
          .where((item) => item.$2.contains(signLord))
          .map((item) => item.$1)
          .where((name) => name != 'Daily-wage / Manual Worker' && name != 'Skilled Service / Manual Work')
          .toList(growable: false);
      if (lordProfessions.isNotEmpty) {
        add(
          id: 'EDU-D24-LORD-PROF-GUIDANCE',
          topic: '$lordSignName రాశి అధిపతి $signLord — వృత్తి మార్గదర్శకం',
          result: '$lordSignName రాశి అధిపతి $signLord. Broad profession guidance: ${lordProfessions.join(', ')}. Exact profession కోసం D10తో cross-check చేయాలి.',
          rule: 'Education-selection ruleలో వచ్చిన Nakshatra-lord sign యొక్క sign lordను తీసుకుని, appలో source-backed D10 profession catalogతో broad career guidance ఇవ్వాలి.',
          inspection: 'Nakshatra lord=$nakshatraLord; its D24 sign=$lordSignName; sign lord=$signLord; profession groups=${lordProfessions.length}.',
          source: 'User-requested sign-lord profession guidance + supplied D10 profession rulebook implementation / D10.pdf pp.42–47.',
          tone: VargaRuleTone.info,
          applicable: true,
        );
      }
    }

    for (final spec in D24EducationRegistry.rules) {
      add(
        id: 'SRC-${spec.id}',
        topic: spec.topic,
        result: spec.result,
        rule: spec.rule,
        inspection: 'Source-only rule library. Exact source condition fully available in the current calculator అయితే మాత్రమే auto-resultగా తీసుకోవాలి.',
        source: spec.source,
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
      );
    }
  }

  static void _d27(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    final afflictions = [6, 8]
        .expand((h) => _houseNames(v, h))
        .where(_malefics.contains)
        .toList();
    if (afflictions.isNotEmpty) {
      final severe = afflictions.length >= 2;
      add(
        id: severe ? 'S7-D27-02' : 'S7-D27-01',
        topic: 'శరీర/రోగ కారక జాగ్రత్త',
        result: severe
            ? 'D27 6/8 ప్రాంతాల్లో రెండు లేదా ఎక్కువ పాప ప్రభావాలు ఉన్నాయి; source ప్రకారం ఆరోగ్య అంశాన్ని గట్టిగా పరిశీలించాల్సిన layer.'
            : 'D27 6/8 ప్రాంతంలో ఒక పాప ప్రభావం ఉంది; చిన్న జాగ్రత్త layerగా చూడాలి.',
        rule: 'D27లో 6/8 సంబంధిత పాప ప్రభావాల సంఖ్యను రోగ/బాధ తీవ్రతకు source ఉపయోగిస్తుంది; ఒక పీడ చిన్న బాధ, రెండు లేదా ఎక్కువైతే కఠినత పెరుగుతుంది.',
        inspection: 'D27 6/8 పాపగ్రహాలు: ${afflictions.join(', ')}.',
        source: 'Sarala Jyotisham Part VII — D27, supplied “Sarala 7 final.pdf” pp.13–14',
        tone: VargaRuleTone.caution,
        applicable: true,
        remedy: 'ఈ sourceలో వైద్య పరిహారం prescription లేదు. ఆరోగ్య సమస్య ఉంటే వైద్యుడి సలహా అవసరం. జ్యోతిష్య పరిహారం ఇవ్వాలంటే separate source-supported remedy rules మాత్రమే వాడాలి.',
      );
    } else {
      add(
        id: 'S7-D27-00',
        topic: 'శరీర/రోగ కారక పరిశీలన',
        result: 'D27 6/8లో ఈ simple evaluatorకు పాపగ్రహ trigger కనిపించలేదు.',
        rule: 'D27 6/8 పాప ప్రభావాలను source రోగ కారక layerగా పరిశీలిస్తుంది.',
        inspection: 'D27 6/8 పాపగ్రహ count 0.',
        source: 'Sarala Jyotisham Part VII — D27, supplied “Sarala 7 final.pdf” pp.13–14',
        tone: VargaRuleTone.info,
        applicable: false,
      );
    }
  }

  static void _d30(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D30-01',
      cautionId: 'S7-D30-02',
      topic: 'అరిష్ట / సహనశక్తి',
      favorableResult: 'D30 లగ్నంలో శుభగ్రహ support ఉంది; కష్టాల్ని ఎదుర్కొనే resilienceకు అనుకూల layer.',
      cautionResult: 'D30 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; అరిష్ట/కష్టాల layerను ఇతర chart factorsతో జాగ్రత్తగా చూడాలి.',
      rule: 'D30లో Lagna/Lagna lord మరియు 6/8/12 afflictionను కలిసి కష్ట/అరిష్టానికి పరిశీలించాలి.',
      source: 'Sarala VII D30 + remidi.pdf D30 affliction framework',
      add: add,
    );
    final dusthana = <String>[];
    for (final h in const [6, 8, 12]) {
      for (final p in _houseNames(v, h).where(_malefics.contains)) {
        dusthana.add('$p@H$h');
      }
    }
    final d30LagnaLord = _signLord(v.ascendantSignIndex);
    final d30LagnaLordHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == d30LagnaLord));
    final blocks = <bool>[
      dusthana.isNotEmpty,
      dusthana.length >= 2,
      {6, 8, 12}.contains(d30LagnaLordHouse),
      _houseNames(v, 1).any(_malefics.contains),
    ];
    final pct = (100 * blocks.where((x) => x).length / blocks.length).round();
    if (pct > 0) {
      add(
        id: 'D30-AFFLICTION-EVIDENCE',
        topic: 'అరిష్ట / కష్ట evidence — $pct%',
        result: 'D30 dusthana/Lagna evidence coverage $pct%. ఇది hardship evidence మాత్రమే; ఖచ్చిత సంఘటన prediction కాదు.',
        rule: 'D30 6/8/12 పాప ప్రభావం, Lagna/Lagna lord afflictionను కలిపి కష్ట/దురదృష్ట layerగా పరిశీలించాలి.',
        inspection: '6/8/12 malefics=${dusthana.isEmpty ? 'none' : dusthana.join(', ')}; Lagna lord=$d30LagnaLord H$d30LagnaLordHouse.',
        source: 'Sarala VII D30 + remidi.pdf. % is app evidence coverage, not probability.',
        tone: VargaRuleTone.caution,
        applicable: true,
      );
    }
  }

  static void _d40(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    add(
      id: 'S7-D40-SRC',
      topic: 'వృత్తి అడ్డంకులు / వృత్తి స్థాయి',
      result: 'D40 source rules ఉన్నాయి; అవి “జ్ఞాతికారక/వృత్తి అడ్డంకి గ్రహం” వంటి ప్రత్యేక karaka selectionపై ఆధారపడి ఉంటాయి. ఈ buildలో guess చేయకుండా source-onlyగా ఉంచాం.',
      rule: 'Sarala VII D40లో వృత్తి అడ్డంకి గ్రహ dignity/స్థానం ఆధారంగా వృత్తి కష్ట/స్థాయి ఫలితాలు ఉన్నాయి.',
      inspection: 'D40 chart సిద్ధంగా ఉంది; special career-obstacle karaka selection engine ఇంకా activate కాలేదు.',
      source: 'Sarala Jyotisham Part VII — D40, supplied “Sarala 7 final.pdf” pp.15–16',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );
  }

  static void _d45(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D45-01',
      cautionId: 'S7-D45-02',
      topic: 'ఆధ్యాత్మికత / పితృ సంస్కారం',
      favorableResult: 'D45 9వ భావంలో శుభగ్రహ support ఉంది; ఆధ్యాత్మిక/ధర్మ దిశకు అనుకూల layer.',
      cautionResult: 'D45 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ఆధ్యాత్మిక/పితృ సంస్కార దిశలో కఠిన అనుభవ layer.',
      rule: 'D45లో 5వ/9వ భావాలు, లగ్న/లగ్నాధిపతి, గురు త్రికోణ సంబంధాన్ని ఆధ్యాత్మిక ఫలానికి source పరిశీలిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D45, supplied “Sarala 7 final.pdf” pp.16–17',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 5,
      favorableId: 'S7-D45-03',
      cautionId: 'S7-D45-04',
      topic: 'పూర్వ పుణ్యం / బుద్ధి',
      favorableResult: 'D45 5వ భావంలో శుభగ్రహ support ఉంది; పూర్వపుణ్య/సంస్కారానికి అనుకూల layer.',
      cautionResult: 'D45 5వ భావంలో పాపగ్రహ ప్రభావం ఉంది; పూర్వపుణ్య/సంస్కార అంశంలో కఠిన layer.',
      rule: 'D45లో 5వ భావ పీడ/శుభ సంబంధాన్ని ఆధ్యాత్మిక అనుభవానికి source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D45, supplied “Sarala 7 final.pdf” pp.16–17',
      add: add,
    );
  }

  static void _d60(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D60-01',
      cautionId: 'S7-D60-02',
      topic: 'సూక్ష్మ కర్మ / కారక ఫలం',
      favorableResult: 'D60 లగ్నంలో శుభగ్రహ support ఉంది; సూక్ష్మ కర్మ layerలో అనుకూల background evidence.',
      cautionResult: 'D60 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; సూక్ష్మ కర్మ layerలో కఠిన background evidence.',
      rule: 'D60లో ప్రతి కారకుడిని విడిగా చూడాలి; శుభ సంబంధం మంచి ఫలం, పాప సంబంధం కష్ట/చివరి ఫలం layerగా source సూచిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D60, supplied “Sarala 7 final.pdf” p.18',
      add: add,
    );
    add(
      id: 'S7-D60-SRC',
      topic: 'D60 source boundary',
      result: 'D60 ఒక్కటితో final తీర్పు ఇవ్వకూడదు; source కూడా కారకాంశ/D1 layersతో కలిపి చూడమంటుంది.',
      rule: 'D60 సూక్ష్మ chart. Birth time sensitivity ఎక్కువ. ప్రతి కారకుడిని D1 మరియు ఇతర evidenceతో కలిపి చూడాలి.',
      inspection: 'D60 chart background evidenceగా మాత్రమే ఉపయోగించాలి.',
      source: 'Sarala Jyotisham Part VII — D60, supplied “Sarala 7 final.pdf” p.18',
      tone: VargaRuleTone.info,
      applicable: true,
      remedy: 'D60లో అశుభ సూచన కనిపించినందుకు మాత్రమే రత్నం/పరిహారం prescribe చేయవద్దు. ఇతర chart evidence + separate remedy source rule అవసరం.',
    );
  }


  static void _appendMarriageMaterialRegistry(
    int factor,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    for (final entry in MarriageMaterialRegistry.forFactor(factor)) {
      final partnerNote = entry.requiresTwoCharts
          ? 'ఈ ruleకు వధువు + వరుడు రెండింటి జాతకాలు అవసరం; single-chart resultగా fire చేయదు.'
          : 'ఈ handwritten/source rule exact condition పూర్తిగా machine-validated అయినప్పుడే auto-resultగా fire చేయాలి.';
      add(
        id: entry.id,
        topic: entry.topic,
        result: 'Source rule engineలో నమోదు అయింది; exact condition match కాకుండా result ఇవ్వదు.',
        rule: '${entry.note} $partnerNote',
        inspection: 'సంబంధిత chart layer D$factor లెక్కించబడింది. Source page ${entry.page}ను referenceగా ఉంచాం; ఊహా arithmetic ఉపయోగించము.',
        source: '${MarriageMaterialRegistry.sourceName} p.${entry.page}',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
        remedy: 'ఈ supplied marriage source ruleలో స్పష్టమైన పరిహారం ఉంటేనే link చేయాలి. Sourceలో లేని పరిహారం లేదా రత్నం auto-generate చేయరాదు.',
      );
    }
  }

  static void _appendV50SourceRegistry(
    int factor,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    void sourceOnly({
      required String id,
      required String topic,
      required String rule,
      required String source,
      String? remedy,
    }) {
      add(
        id: id,
        topic: topic,
        result: 'ఈ source rule సంబంధిత varga కింద నమోదు అయింది. Exact condition/strength inputs పూర్తిగా match అయినప్పుడు మాత్రమే positive/negative verdict ఇవ్వాలి.',
        rule: rule,
        inspection: 'ఈ chart layer లెక్కించబడింది; source-specific strength/aspect/exception inputs పూర్తిగా validate చేయకుండా auto-result ఇవ్వము.',
        source: source,
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
        remedy: remedy,
      );
    }

    switch (factor) {
      case 1:
        sourceOnly(
          id: 'SKM-V50-BASE',
          topic: 'S.K. Mehta — జాతక rule registry',
          rule: 'భావ/గ్రహ బలం, exchange, aspect, dignity, event-wise combinations మరియు timing/synchronizationను విడివిడిగా evidence layersగా పరిశీలించాలి. Exact event result source condition match అయినప్పుడే ఇవ్వాలి.',
          source: 'sk mehatha jyotisha-niyamavali.pdf — 36 pages',
        );
        sourceOnly(
          id: 'BNN-V50-BASE',
          topic: 'Brighu Naadi — Nadi rule registry',
          rule: 'R-A, C, E, F, G, H, I, J, K seriesగా indexed Nadi rulesను D1/Nadi method కింద source IDతో నిల్వ చేసి, exact combination match అయినప్పుడు మాత్రమే resultగా చూపాలి.',
          source: 'Brighu_Naadi_Purnna_Rulebook.pdf — 21 pages',
          remedy: 'ఈ Brighu Nadi source registry entryకి ప్రత్యేక remedy rule attach కాలేదు. Sourceలో remedy స్పష్టంగా ఉన్నప్పుడు మాత్రమే link చేయాలి; ఊహించి పరిహారం ఇవ్వకూడదు.',
        );
        sourceOnly(
          id: 'MED-ORG-V50',
          topic: 'అవయవ / రోగ జ్యోతిష్య సూచికలు',
          rule: 'రాశి/భావ/గ్రహ ఆధారంగా body-part, organ, disease-location indicatorsను source orderలో పరిశీలించాలి. ఇది సంప్రదాయ జ్యోతిష్య సూచిక మాత్రమే; వైద్య నిర్ధారణ కాదు.',
          source: 'avayava_roga_niyamalu.pdf — 24 pages',
          remedy: 'ఈ health rule నుంచి మందు, చికిత్స లేదా diagnosisను app ఇవ్వదు. ఆరోగ్య సమస్య ఉంటే qualified doctor/health professionalను సంప్రదించాలి. జ్యోతిష్య పరిహారం sourceలో స్పష్టంగా ఉంటేనే విడిగా చూపాలి.',
        );
        sourceOnly(
          id: 'MED-ROGA-V50',
          topic: 'Medical Astrology — Roga rule registry',
          rule: 'Medical Astrology sourceలో chapter-wise Rule → result నిర్మాణం ఉంది. సంబంధిత భావ/గ్రహ/లగ్న factors match అయినప్పుడు source ruleను చూపాలి; medical diagnosis/treatment output చేయకూడదు.',
          source: 'medical_roga_rules_complete.pdf — 19 pages',
          remedy: 'Medical Astrology resultను వైద్య సలహాగా ఉపయోగించకూడదు. App మందులు/చికిత్స prescribe చేయదు; అవసరమైతే doctor evaluation తీసుకోవాలి.',
        );
        break;
      case 2:
        sourceOnly(
          id: 'AV-015-V50',
          topic: 'ధనం — 2వ/11వ అష్టకవర్గ support',
          rule: 'Wealth/gains ప్రశ్నలకు 2వ మరియు 11వ భావ bindusను supporting evidenceగా పోల్చాలి; standalone verdictగా ఉపయోగించకూడదు.',
          source: 'Ashtakavarga practical source — Wealth 2nd/11th support',
        );
        break;
      case 3:
        sourceOnly(
          id: 'SK-012-V50',
          topic: 'సహోదరులు / Sibling event',
          rule: '3వ/11వ భావాలు మరియు అవసరమైన derivative-house logicను source ప్రకారం పరిశీలించాలి; ఒకే భావానికి పరిమితం చేయకూడదు.',
          source: 'S.K. Mehta — New Dimensions / Synchronization',
        );
        sourceOnly(
          id: 'AV-017-V50',
          topic: '3వ భావ అష్టకవర్గ support',
          rule: 'Sibling/effort అంశాలకు 3వ భావ SAV/BAV బలం supporting evidenceగా ఉపయోగించాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
      case 4:
        sourceOnly(
          id: 'SK-009-V50',
          topic: 'స్థిరాస్తి / Property-home-vehicle',
          rule: '4వ భావం/అధిపతి conditions, strength, aspects మరియు exchangesను property/home/vehicle evidenceగా ఉపయోగించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        sourceOnly(
          id: 'AV-016-V50',
          topic: '4వ భావ అష్టకవర్గ support',
          rule: 'Property/home/vehicle/mother-related ప్రశ్నలకు 4వ భావ SAV/BAV బలం supporting layerగా ఉపయోగించాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
      case 7:
        sourceOnly(
          id: 'SK-011-V50',
          topic: 'సంతానం promise',
          rule: '5వ భావం/అధిపతి, సంబంధిత గ్రహాలు, strength, affliction/support మరియు source-specific combinationsను పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 9:
        sourceOnly(
          id: 'SK-010-V50',
          topic: 'వివాహ promise',
          rule: '7వ భావం/అధిపతి, relationship planets, strength, aspect, association, exchange మరియు source-specific exceptionsను పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 10:
        sourceOnly(
          id: 'SK-006-V50',
          topic: 'వృత్తి promise',
          rule: 'Profession-related houses/lords, relevant planets, relationships, strength మరియు source combinationsను timingకు ముందు పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 16:
        sourceOnly(
          id: 'SK-009-X-V50',
          topic: 'వాహనం / సౌకర్యం cross-reference',
          rule: 'Property/home/vehicle ruleలో 4వ భావం/అధిపతి, strength, aspects, exchanges ప్రధాన evidence. D16ను vehicle/comfort cross-checkగా మాత్రమే చూడాలి; source rule D16ని ప్రత్యేకంగా నిర్దేశించకపోతే కొత్త rule సృష్టించరాదు.',
          source: 'S.K. Mehta — Property/home/vehicle rule',
        );
        break;
      case 24:
        sourceOnly(
          id: 'SK-005-V50',
          topic: 'విద్య promise',
          rule: 'Education-related houses/lords, relevant planets, strength, combinations మరియు exceptions పరిశీలించిన తర్వాతే timing చేయాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        sourceOnly(
          id: 'AV-014-V50',
          topic: 'Higher education — 5వ/9వ support',
          rule: 'Higher-education సూచనలకు 5వ మరియు 9వ భావ bindusను supporting evidenceగా పోల్చాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
    }
  }

  static void _beneficMaleficHouseRule({
    required VargaChartData v,
    required int house,
    required String favorableId,
    required String cautionId,
    required String topic,
    required String favorableResult,
    required String cautionResult,
    required String rule,
    required String source,
    required void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  }) {
    final names = _houseNames(v, house);
    final ben = names.where(_benefics.contains).toList();
    final mal = names.where(_malefics.contains).toList();
    add(
      id: favorableId,
      topic: topic,
      result: ben.isNotEmpty ? favorableResult : '$topic శుభగ్రహ condition auto-match కాలేదు.',
      rule: rule,
      inspection: 'D${v.definition.factor} $houseవ భావంలో ${names.isEmpty ? 'గ్రహాలు లేవు' : names.join(', ')}. శుభగ్రహాలు: ${ben.isEmpty ? 'లేవు' : ben.join(', ')}.',
      source: source,
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: cautionId,
      topic: topic,
      result: mal.isNotEmpty ? cautionResult : '$topic పాపగ్రహ condition auto-match కాలేదు.',
      rule: rule,
      inspection: 'D${v.definition.factor} $houseవ భావంలో పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: source,
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static int _houseSign(VargaChartData v, int house) =>
      (v.ascendantSignIndex + house - 1) % 12;

  static int _houseOf(VargaChartData v, VargaPlacement p) =>
      ((p.signIndex - v.ascendantSignIndex + 12) % 12) + 1;

  static List<String> _houseNames(VargaChartData v, int house) {
    final sign = _houseSign(v, house);
    return v.planets.where((p) => p.signIndex == sign).map((p) => p.name).toList(growable: false);
  }

  static String _signLord(int sign) => switch (sign % 12) {
        0 || 7 => 'Mars',
        1 || 6 => 'Venus',
        2 || 5 => 'Mercury',
        3 => 'Moon',
        4 => 'Sun',
        8 || 11 => 'Jupiter',
        9 || 10 => 'Saturn',
        _ => 'Sun',
      };

  static bool _isExalted(String planet, int sign) {
    const exalt = {
      'Sun': 0,
      'Moon': 1,
      'Mars': 9,
      'Mercury': 5,
      'Jupiter': 3,
      'Venus': 11,
      'Saturn': 6,
    };
    return exalt[planet] == sign;
  }

  static int _natalHouseOfPlanet(AstroChartResult chart, String planet) {
    final p = chart.planets.firstWhere((x) => x.name == planet);
    return ((p.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
  }

  static int _childTimingPlanetScore(
    AstroChartResult chart,
    VargaChartData d7,
    String planet,
    String d7FifthLord,
  ) {
    var score = 0;
    final p = chart.planets.where((x) => x.name == planet).toList();
    if (p.isEmpty) return 0;
    final natalHouse = _natalHouseOfPlanet(chart, planet);
    if ({2, 5, 11}.contains(natalHouse)) score += 2;
    if (planet != 'Rahu' && planet != 'Ketu') {
      for (final h in const [2, 5, 11]) {
        if (_signLord((chart.ascendantSignIndex + h - 1) % 12) == planet) score += 1;
      }
    }
    if (planet == 'Jupiter') score += 1;
    if (planet == d7FifthLord) score += 1;
    final vp = d7.planets.where((x) => x.name == planet).toList();
    if (vp.isNotEmpty && {1, 2, 5, 9, 11}.contains(_houseOf(d7, vp.first))) score += 1;
    return score;
  }


  static bool _vargaPlanetAspectsHouse(VargaChartData v, String planet, int targetHouse) {
    final rows = v.planets.where((p) => p.name == planet).toList(growable: false);
    if (rows.isEmpty) return false;
    final from = _houseOf(v, rows.first);
    final diff = ((targetHouse - from + 12) % 12) + 1;
    if (diff == 7) return true;
    if (planet == 'Mars' && (diff == 4 || diff == 8)) return true;
    if (planet == 'Jupiter' && (diff == 5 || diff == 9)) return true;
    if (planet == 'Saturn' && (diff == 3 || diff == 10)) return true;
    return false;
  }

  static String _signNameTe(int sign) => const <String>[
        'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
        'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
      ][sign % 12];

  static String _mahavidyaForPlanet(String planet) => switch (planet) {
        'Sun' => 'Matangi',
        'Moon' => 'Bhuvaneshwari',
        'Mars' => 'Bagalamukhi',
        'Mercury' => 'Tripura Sundari / Shodashi',
        'Jupiter' => 'Tara',
        'Venus' => 'Kamala',
        'Saturn' => 'Kali',
        'Rahu' => 'Chhinnamasta',
        'Ketu' => 'Dhumavati',
        _ => 'Tripura Bhairavi',
      };

  static String _remedyText(VargaRuleTone tone) => switch (tone) {
        VargaRuleTone.favorable =>
          'ఈ sourceలో ప్రత్యేక పరిహారం అవసరం అని చెప్పలేదు. అనుకూల బలాన్ని timing/ప్రాక్టికల్ చర్యలతో ఉపయోగించండి.',
        VargaRuleTone.caution =>
          'ఈ varga sourceలో ప్రత్యేక remedy prescription లేదు. ముందుగా practical correction చేయాలి. రత్నం/గ్రహ పరిహారం ఇవ్వాలంటే supplied Gemstone Remedy rule-engine eligibilityని విడిగా పరీక్షించాలి; automatic gemstone ఇవ్వవద్దు.',
        VargaRuleTone.neutral =>
          'ఇది పరిశీలన layer. Sourceలో ప్రత్యేక పరిహారం ఇవ్వలేదు; ఇతర chart evidenceతో కలిపి నిర్ణయించాలి.',
        VargaRuleTone.info =>
          'ఈ rule source-only. Exact condition పూర్తిగా validate అయ్యే వరకు పరిహారం auto-generate చేయరాదు.',
      };
}
