import 'astro_models.dart';
import 'd10_career_service.dart';
import 'd10_profession_registry.dart';
import 'varga_service.dart';
import 'marriage_material_registry.dart';

enum VargaRuleTone { favorable, caution, neutral, info }

class VargaRuleHit {
  final int factor;
  final String ruleId;
  final String topic;
  final String result;
  final String rule;
  final String inspection;
  final String remedy;
  final String source;
  final VargaRuleTone tone;
  final bool applicable;
  final bool autoEvaluated;

  const VargaRuleHit({
    required this.factor,
    required this.ruleId,
    required this.topic,
    required this.result,
    required this.rule,
    required this.inspection,
    required this.remedy,
    required this.source,
    required this.tone,
    required this.applicable,
    required this.autoEvaluated,
  });
}

/// Source-linked varga rule layer.
///
/// Boundary: only conditions that can be reproduced from the current D1/varga
/// placements are auto-fired. Rules requiring a source-specific strength,
/// aspect, special karaka, or unimplemented arithmetic stay in the source
/// catalog instead of being guessed.
class VargaRuleService {
  static const _benefics = {'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};

  static const _d10SignNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  // Source-backed profession significations carried forward from the supplied
  // D10 profession rulebook implementation (D10.pdf pp.42–47).
  static const _d10ProfessionCatalog = <(String, List<String>, List<int>)>[
    ('Government / Administration', ['Sun', 'Mercury'], [10]),
    ('Management / High Position', ['Sun', 'Jupiter', 'Saturn'], [10]),
    ('Banking / Finance', ['Jupiter', 'Mercury', 'Sun'], [2, 10, 11]),
    ('Accounting', ['Mercury'], [2, 11]),
    ('Teaching / Education', ['Jupiter', 'Mercury', 'Venus'], [5, 9]),
    ('Law / Judiciary', ['Jupiter', 'Mercury', 'Saturn'], [9, 10]),
    ('Engineering / Technical', ['Mars', 'Saturn', 'Rahu'], [3, 10]),
    ('Architecture', ['Mercury', 'Mars', 'Venus'], [3, 4, 10]),
    ('Medicine / Surgery', ['Sun', 'Mars', 'Jupiter'], [6, 10]),
    ('Nursing / Care', ['Moon', 'Jupiter'], [6, 12]),
    ('Journalism / Writing', ['Mercury', 'Moon'], [3, 5]),
    ('Communication / Languages', ['Mercury', 'Moon', 'Ketu'], [3, 7]),
    ('Travel / Tourism', ['Moon', 'Mercury'], [3, 9, 12]),
    ('Hospitality / Restaurants', ['Moon', 'Venus'], [4, 12]),
    ('Textiles / Clothing', ['Moon', 'Venus', 'Saturn'], [2, 4]),
    ('Music / Arts', ['Moon', 'Venus'], [5, 11]),
    ('Cinema / Acting / Dance', ['Venus', 'Moon'], [5, 11]),
    ('Fashion / Beauty / Design', ['Venus', 'Mercury'], [5, 7]),
    ('Interior Decoration', ['Venus', 'Mercury'], [4, 5]),
    ('Precious Stones / Jewellery', ['Sun', 'Venus', 'Jupiter'], [2, 10]),
    ('Metallurgy / Hardware', ['Mars', 'Saturn'], [3, 10]),
    ('Mining / Minerals', ['Saturn', 'Jupiter'], [8, 10]),
    ('Agriculture / Farming', ['Saturn', 'Moon'], [4, 11]),
    ('Food / Dairy', ['Moon', 'Venus'], [2, 4, 11]),
    ('Manufacturing / Industry', ['Saturn', 'Mars', 'Rahu'], [6, 10, 11]),
    ('Aviation / Piloting', ['Rahu', 'Mars', 'Mercury'], [3, 9, 12]),
    ('Import / Export', ['Moon', 'Rahu', 'Ketu'], [7, 12]),
    ('Diplomacy / Foreign Relations', ['Rahu', 'Sun', 'Mercury'], [7, 9, 12]),
    ('Research / Specialized Studies', ['Ketu', 'Saturn', 'Jupiter'], [8, 9]),
    ('Astrology / Traditional Studies', ['Jupiter', 'Ketu'], [8, 9]),
    ('Astrologer / Jyotisha Practitioner', ['Jupiter', 'Ketu'], [8, 9]),
    ('Astrology Consultant / Jyotisha Consultant', ['Jupiter', 'Ketu', 'Mercury'], [8, 9, 10]),
    ('Consultant / Advisor', ['Jupiter', 'Mercury'], [7, 9, 10]),
    ('Priest / Spiritual Consultant', ['Jupiter', 'Ketu'], [9, 10]),
    ('Books / Publishing', ['Mercury', 'Jupiter', 'Ketu'], [3, 5, 9]),
    ('Surveying / Field Technical Work', ['Mars', 'Saturn'], [3, 4, 10]),
    ('Defence / Security', ['Mars', 'Sun', 'Rahu'], [6, 10]),
    ('Maintenance / Refrigeration', ['Saturn', 'Mars'], [6, 10, 12]),
    ('Plumber / Electrician / Skilled Trades', ['Saturn', 'Mars'], [6, 10]),
    ('Skilled Service / Manual Work', ['Saturn', 'Mars', 'Moon'], [6, 10]),
    ('Daily-wage / Manual Worker', ['Saturn', 'Mars', 'Moon'], [6, 10]),
    ('Farm / Agricultural Worker', ['Saturn', 'Moon'], [4, 6, 11]),
    ('Commercial / Business', ['Mercury', 'Venus', 'Rahu'], [3, 7, 11]),
    ('Self-employment', ['Sun', 'Mars', 'Rahu', 'Moon'], [1, 3, 10, 11]),
    ('Service / Employment', ['Saturn', 'Moon', 'Mercury'], [6, 10, 11]),
  ];

  static List<VargaRuleHit> allFor({
    required AstroChartResult chart,
    required int factor,
    DateTime? birthDateTime,
  }) {
    final varga = VargaService.calculate(chart, factor);
    final out = <VargaRuleHit>[];

    void add({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto = true,
      String? remedy,
    }) {
      out.add(
        VargaRuleHit(
          factor: factor,
          ruleId: id,
          topic: topic,
          result: result,
          rule: rule,
          inspection: inspection,
          remedy: remedy ?? _remedyText(tone),
          source: source,
          tone: tone,
          applicable: applicable,
          autoEvaluated: auto,
        ),
      );
    }

    switch (factor) {
      case 1:
        _d1Gems(chart, add);
        break;
      case 2:
        add(
          id: 'SRC-D2-01',
          topic: 'ధనం / హోరా',
          result: 'ఈ buildలో supplied files నుంచి D2కి exact auto-rule evaluator జోడించలేదు.',
          rule: 'D2 ఫలితాన్ని source-specific rule ఉన్నప్పుడు మాత్రమే auto-match చేయాలి.',
          inspection: 'D2 chart calculation అందుబాటులో ఉంది; rule source mapping ఇంకా source-only.',
          source: 'Supplied varga sources — D2 explicit rule not used in this build',
          tone: VargaRuleTone.info,
          applicable: false,
          auto: false,
        );
        break;
      case 3:
        _d3(varga, add);
        break;
      case 4:
        _d4(varga, add);
        break;
      case 7:
        _d7(chart, varga, add);
        break;
      case 9:
        _d9(varga, add);
        break;
      case 10:
        _d10(chart, varga, birthDateTime, add);
        break;
      case 12:
        _d12(varga, add);
        break;
      case 16:
        _d16(varga, add);
        break;
      case 20:
        _d20(varga, add);
        break;
      case 24:
        _d24(varga, add);
        break;
      case 27:
        _d27(varga, add);
        break;
      case 30:
        _d30(varga, add);
        break;
      case 40:
        _d40(varga, add);
        break;
      case 45:
        _d45(varga, add);
        break;
      case 60:
        _d60(varga, add);
        break;
    }

    // User-supplied marriage rulebook registry: every distinct rule is indexed
    // under its related chart layer. These entries are source-linked and remain
    // non-auto until the exact handwritten condition is machine-validated.
    _appendMarriageMaterialRegistry(factor, add);

    // V50 source registry: topic-wise source entries are attached under the
    // relevant varga without inventing an automatic verdict.
    _appendV50SourceRegistry(factor, add);

    return out;
  }

  static List<VargaRuleHit> applicableFor({
    required AstroChartResult chart,
    required int factor,
    DateTime? birthDateTime,
  }) => allFor(chart: chart, factor: factor, birthDateTime: birthDateTime)
      .where((x) => x.autoEvaluated && x.applicable)
      .toList(growable: false);

  static void _d1Gems(
    AstroChartResult chart,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final lagna = chart.ascendantSignIndex;
    final exaltedInLagna = chart.planets.where((p) => p.signIndex == lagna && _isExalted(p.name, p.signIndex)).toList();
    add(
      id: 'G-05',
      topic: 'లగ్నంలో ఉచ్చరాశి గ్రహం',
      result: exaltedInLagna.isEmpty
          ? 'ఈ జాతకంలో G-05 condition auto-match కాలేదు.'
          : 'లగ్న బలానికి అనుకూల source సూచన కనిపిస్తోంది.',
      rule: 'లగ్నంలో ఉచ్చ స్థితిలో గ్రహం ఉండి, సంబంధిత support ఉంటే లగ్నానికి బలం మరియు మంచి ఫలితాల సూచనగా చూడాలి.',
      inspection: exaltedInLagna.isEmpty
          ? 'లగ్నంలో ఉచ్చస్థితి గ్రహం లేదు.'
          : 'లగ్నంలో ఉచ్చస్థితి: ${exaltedInLagna.map((p) => p.name).join(', ')}.',
      source: '108 Gems of Predictive Astrology — G-05, supplied rule-based PDF p.2',
      tone: VargaRuleTone.favorable,
      applicable: exaltedInLagna.isNotEmpty,
    );

    for (final item in const [
      ('G-01', 'జన్మదినం', 'జన్మ వారాధిపతి 6/8 అధిపత్యం మరియు ఉచ్చ/నీచ స్థితిని కలిపి పరిశీలించే rule.'),
      ('G-06', 'లగ్నాధిపతి — 1', 'లగ్నాధిపతి స్థానం/బలం/దృష్టి layersను కలిపి నిర్ణయించే rule.'),
      ('G-07', 'లగ్నాధిపతి — 2', 'లగ్నాధిపతికి శుభ/పాప సంబంధాన్ని పరిశీలించే rule.'),
      ('G-08', 'లగ్నాధిపతి × చంద్రరాశ్యాధిపతి', 'లగ్నాధిపతి మరియు చంద్రరాశ్యాధిపతి కేంద్ర/సంబంధాన్ని పరిశీలించే rule.'),
      ('G-09', 'లగ్నాధిపతి × చంద్రరాశ్యాధిపతి ఉపచయం', 'ఇద్దరి ఉపచయ/కేంద్ర సంబంధాన్ని పరిశీలించే rule.'),
      ('G-10', 'నవమాధిపతి × లగ్నాధిపతి', '9వ అధిపతి–లగ్నాధిపతి సంబంధం ద్వారా భాగ్యం/శ్రేయస్సు layer.'),
    ]) {
      add(
        id: item.$1,
        topic: item.$2,
        result: 'Source rule catalogలో ఉంది; exact evaluator ఈ buildలో guess చేయకుండా source-onlyగా ఉంచాం.',
        rule: item.$3,
        inspection: 'ఈ ruleకు అవసరమైన పూర్తి source arithmetic/relationship layerను విడిగా validate చేసిన తర్వాత మాత్రమే auto-result ఇవ్వాలి.',
        source: '108 Gems of Predictive Astrology — supplied rule-based PDF pp.2–3',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
      );
    }
  }

  static void _d3(
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final lagnaNames = _houseNames(v, 1);
    final ben = lagnaNames.where(_benefics.contains).toList();
    final mal = lagnaNames.where(_malefics.contains).toList();
    add(
      id: 'S7-D3-01',
      topic: 'స్వప్రయత్నం / ధైర్యం',
      result: ben.isNotEmpty ? 'D3 లగ్నంలో శుభగ్రహ support ఉంది; స్వప్రయత్నానికి అనుకూల layer.' : 'D3 లగ్న శుభగ్రహ support auto-match కాలేదు.',
      rule: 'D3లో లగ్నం/లగ్నాధిపతి బలం స్వప్రయత్నం, ధైర్యం, కర్మఫలానికి ప్రధానంగా చూడాలి.',
      inspection: 'D3 లగ్నంలో: ${lagnaNames.isEmpty ? 'గ్రహం లేదు' : lagnaNames.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'S7-D3-02',
      topic: 'స్వప్రయత్నం / జాగ్రత్త',
      result: mal.isNotEmpty ? 'D3 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; ప్రయత్నంలో ఒత్తిడి/కఠినత layerగా చూడాలి.' : 'D3 లగ్న పాపగ్రహ condition auto-match కాలేదు.',
      rule: 'D3 lagna/lagna-lord affliction ఉంటే ప్రయత్నంలో ఆటంకం లేదా కఠిన ఫలితంగా source చూడమంటుంది.',
      inspection: 'D3 లగ్నంలో పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2',
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static void _d4(
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final fourthSign = _houseSign(v, 4);
    final lord = _signLord(fourthSign);
    final lordPlacement = v.planets.firstWhere((p) => p.name == lord);
    final lordHouse = _houseOf(v, lordPlacement);
    const results = <int, String>{
      1: 'విద్య, ఆభరణాలు, భూమి, వాహన అంశాలకు అనుకూలత; సాధారణంగా సంతోషం.',
      2: 'ధనం, సుఖం.',
      3: 'ధైర్యం; పాప ప్రభావం ఉంటే అనుభవం కఠినంగా మారవచ్చు.',
      4: 'సంపద, విద్య, గౌరవం.',
      5: 'రాజయోగ/మంచి సంతానం layer; బలహీనత ఉంటే సంతాన అంశం పరిశీలించాలి.',
      6: 'భౌతిక సుఖంలో ఒత్తిడి; పాప ప్రభావం ఉంటే ఆరోగ్య/తల్లి అంశం జాగ్రత్త.',
      7: 'విద్య, వాహనం; ఇతర సంబంధాలను కూడా చూడాలి.',
      8: 'గృహ సుఖం తగ్గే లేదా మార్పులు వచ్చే సూచన; వృత్తి/ధన సంబంధం కూడా చూడాలి.',
      9: 'రాజయోగ/ఉన్నత విద్య layer.',
      10: 'రాజ గౌరవం / స్థాయి.',
      11: 'దాతృత్వం; పాప ప్రభావం ఉంటే చెడు ఉపదేశం/మిశ్రమ ఫలితం.',
      12: 'సుఖ లోపం/నష్టం వంటి జాగ్రత్త సూచన.',
    };
    final tone = {1, 2, 4, 5, 7, 9, 10, 11}.contains(lordHouse)
        ? VargaRuleTone.favorable
        : {6, 8, 12}.contains(lordHouse)
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'S3-D4-L4H$lordHouse',
      topic: 'D4 4వ అధిపతి స్థానం',
      result: results[lordHouse]!,
      rule: 'D4లో 4వ భావ అధిపతి ఏ భావంలో ఉన్నాడో ఆధారంగా స్థిరాస్తి/సుఖ ఫలితాన్ని source tableలో చదవాలి.',
      inspection: 'D4 4వ భావ రాశి ${fourthSign + 1}; అధిపతి $lord; D4లో $lord ${lordHouse}వ భావంలో ఉంది.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 4th-lord result table pp.1–2',
      tone: tone,
      applicable: true,
    );

    final h4 = _houseNames(v, 4);
    final ben = h4.where(_benefics.contains).toList();
    final mal = h4.where(_malefics.contains).toList();
    add(
      id: 'S3-D4-H4-BEN',
      topic: 'స్థిరాస్తి / 4వ భావ support',
      result: ben.isNotEmpty ? 'D4 4వ భావంలో శుభగ్రహ support ఉంది; స్థిరాస్తి/సుఖానికి అనుకూల layer.' : 'D4 4వ భావ శుభగ్రహ condition auto-match కాలేదు.',
      rule: 'D4 4వ భావ బలం మరియు శుభ సంబంధాన్ని స్థిరాస్తి ఫలితానికి చూడాలి.',
      inspection: 'D4 4వ భావంలో ${h4.isEmpty ? 'గ్రహాలు లేవు' : h4.join(', ')}.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 property rules pp.1–2',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'S3-D4-H4-MAL',
      topic: 'స్థిరాస్తి / జాగ్రత్త',
      result: mal.isNotEmpty ? 'D4 4వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ఆస్తి/సుఖంలో ఒత్తిడి లేదా ఆలస్యం layerగా చూడాలి.' : 'D4 4వ భావ పాపగ్రహ condition auto-match కాలేదు.',
      rule: 'D4 4వ భావం పీడితమైతే స్థిరాస్తి/సుఖ అంశంలో జాగ్రత్తగా source ఫలితం చదవాలి.',
      inspection: 'D4 4వ భావ పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 property rules pp.1–2',
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static void _d7(
    AstroChartResult chart,
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final natal5Sign = (chart.ascendantSignIndex + 4) % 12;
    final natal5Lord = _signLord(natal5Sign);
    final natal5LordPlanet = chart.planets.firstWhere((p) => p.name == natal5Lord);
    final natal5LordHouse = ((natal5LordPlanet.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final jupiter = chart.planets.firstWhere((p) => p.name == 'Jupiter');
    final jupiterHouse = ((jupiter.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final lagnaLord = _signLord(chart.ascendantSignIndex);
    final lagnaLordPlanet = chart.planets.firstWhere((p) => p.name == lagnaLord);
    final lagnaLordHouse = ((lagnaLordPlanet.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final natalSupport = natal5LordHouse == 5 || jupiterHouse == 5 || lagnaLordHouse == 5;
    add(
      id: 'D7-SANTANA-01',
      topic: '5వ భావ బలం / సంతానం',
      result: natalSupport ? 'సంతాన వాగ్దానానికి 5వ భావ primary support కనిపిస్తోంది.' : '5వ భావ primary support ఈ simple evaluatorలో match కాలేదు; పూర్తి దృష్టి/శుభసంబంధం చూడాలి.',
      rule: 'సంతాన నిర్ణయంలో ముందుగా 5వ భావం, 5వ అధిపతి, కారకుడు గురువును పరిశీలించాలి; తరువాత D7 చూడాలి.',
      inspection: '5వ అధిపతి $natal5Lord — House $natal5LordHouse; Jupiter — House $jupiterHouse; Lagna lord $lagnaLord — House $lagnaLordHouse.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” pp.1–2',
      tone: natalSupport ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: natalSupport,
    );

    final d7h5 = _houseNames(v, 5);
    final ben = d7h5.where(_benefics.contains).toList();
    final mal = d7h5.where(_malefics.contains).toList();
    add(
      id: 'D7-SANTANA-02',
      topic: 'D7 5వ భావ support',
      result: ben.isNotEmpty ? 'D7 5వ భావంలో శుభగ్రహ support ఉంది; సంతాన అంశానికి అనుకూల layer.' : 'D7 5వ భావ శుభగ్రహ condition auto-match కాలేదు.',
      rule: 'D7లో 5వ భావం, 5వ అధిపతి, పుత్రకారక/గురు బలాన్ని కలిపి చూడాలి.',
      inspection: 'D7 5వ భావంలో: ${d7h5.isEmpty ? 'గ్రహాలు లేవు' : d7h5.join(', ')}.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” + Sarala VII D7 section',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'D7-SANTANA-03',
      topic: 'D7 5వ భావ జాగ్రత్త',
      result: mal.length >= 2 ? 'D7 5వ భావంపై బహుళ పాపగ్రహ ప్రభావం ఉంది; సంతాన అంశాన్ని ఇతర supportతో జాగ్రత్తగా చూడాలి.' : 'D7 5వ భావ బహుళ పాపగ్రహ condition match కాలేదు.',
      rule: '5వ భావం/5వ అధిపతి పాపగ్రహ పీడనలో ఉంటే సంతాన ఫలితంలో కష్ట/ఆలస్యం layerగా source చూడమంటుంది.',
      inspection: 'D7 5వ భావ పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” pp.1–2; Sarala VII D7 p.5',
      tone: VargaRuleTone.caution,
      applicable: mal.length >= 2,
    );
  }

  static void _d9(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 7,
      favorableId: 'S7-D9-01',
      cautionId: 'S7-D9-02',
      topic: 'వివాహ వాగ్దానం',
      favorableResult: 'D9 7వ భావంలో శుభగ్రహ support ఉంది; వివాహ/భాగస్వామ్యానికి అనుకూల layer.',
      cautionResult: 'D9 7వ భావంలో పాపగ్రహ ప్రభావం ఉంది; సంబంధాన్ని ఇతర factorsతో జాగ్రత్తగా చూడాలి.',
      rule: 'D9లో 7వ భావం, 7వ అధిపతి, దారాకారక/జ్ఞాతికారక సంబంధాన్ని వివాహానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D9, supplied “Sarala 7 final.pdf” p.6',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D9-03',
      cautionId: 'S7-D9-04',
      topic: 'ధర్మం / నైతిక దిశ',
      favorableResult: 'D9 9వ భావంలో శుభగ్రహ support ఉంది; ధర్మ/గురు/నైతికతకు అనుకూల layer.',
      cautionResult: 'D9 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ధర్మ/గురు అంశంలో జాగ్రత్త layer.',
      rule: 'D9 9వ భావం, 9వ అధిపతి, గురువును ధర్మ ఫలానికి పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D9, supplied “Sarala 7 final.pdf” pp.6–7',
      add: add,
    );
  }

  static void _d10(
    AstroChartResult chart,
    VargaChartData v,
    DateTime? birthDateTime,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    final d9 = VargaService.calculate(chart, 9);
    final d10LagnaSign = v.ascendantSignIndex;
    final d10TenthSign = _houseSign(v, 10);
    final d10TenthLord = _signLord(d10TenthSign);
    final d10TenthLordPlacement = v.planets.firstWhere((p) => p.name == d10TenthLord);
    final d10TenthLordHouse = _houseOf(v, d10TenthLordPlacement);
    final d10FirstLord = _signLord(d10LagnaSign);
    final d10ThirdLord = _signLord(_houseSign(v, 3));
    final d10EleventhLord = _signLord(_houseSign(v, 11));
    final d10SeventhLord = _signLord(_houseSign(v, 7));
    final d1TenthSign = (chart.ascendantSignIndex + 9) % 12;
    final d1TenthLord = _signLord(d1TenthSign);
    final d9TenthLord = _signLord(_houseSign(d9, 10));
    final d10LagnaNames = _houseNames(v, 1);
    final fourthNames = _houseNames(v, 4);
    final tenthNames = _houseNames(v, 10);
    final seventhNames = _houseNames(v, 7);
    final thirdNames = _houseNames(v, 3);
    final twelfthNames = _houseNames(v, 12);
    final eighthNames = _houseNames(v, 8);
    final tenthBenefics = tenthNames.where(_benefics.contains).toList();
    final tenthMalefics = tenthNames.where(_malefics.contains).toList();
    final saturnStream = D10CareerService.saturnStream(chart);
    final d10TenthLordNatal = chart.planets.firstWhere((p) => p.name == d10TenthLord);
    final careerDevata = D10CareerService.devataForLongitude(d10TenthLordNatal.longitude);
    final lagnaDevata = D10CareerService.devataForLongitude(chart.ascendantLongitude);
    final careerWindows = birthDateTime == null
        ? const <D10CareerWindow>[]
        : D10CareerService.timingWindows(chart: chart, birthDateTime: birthDateTime);

    ({int score, String why}) professionScore(List<String> group) {
      var score = 0;
      final why = <String>[];
      if (group.contains(d10TenthLord)) {
        score += 30;
        why.add('D10 10వ అధిపతి $d10TenthLord match');
      }
      final tenthMatch = tenthNames.where(group.contains).toList();
      if (tenthMatch.isNotEmpty) {
        score += 25;
        why.add('D10 10వ భావంలో ${tenthMatch.join(', ')}');
      }
      final lagnaNames = _houseNames(v, 1);
      final lagnaMatch = lagnaNames.where(group.contains).toList();
      if (lagnaMatch.isNotEmpty) {
        score += 15;
        why.add('D10 లగ్నంలో ${lagnaMatch.join(', ')}');
      }
      if (group.contains(d1TenthLord)) {
        score += 15;
        why.add('D1 10వ అధిపతి $d1TenthLord match');
      }
      if (group.contains(d9TenthLord)) {
        score += 10;
        why.add('D9 10వ అధిపతి $d9TenthLord match');
      }
      final signType = switch (d10TenthSign) {
        0 || 5 || 7 || 9 || 10 => 'technical',
        2 || 4 || 6 => 'semitechnical',
        _ => 'nontechnical',
      };
      final typeMatch =
          (group.any((g) => const ['Mars', 'Saturn', 'Rahu'].contains(g)) && signType == 'technical') ||
          (group.any((g) => const ['Sun', 'Mercury'].contains(g)) && signType == 'semitechnical') ||
          (group.any((g) => const ['Moon', 'Jupiter', 'Venus'].contains(g)) && signType == 'nontechnical');
      if (typeMatch) {
        score += 5;
        why.add('D10 10వ రాశి classification: $signType');
      }
      return (score: score.clamp(0, 100).toInt(), why: why.isEmpty ? 'source-backed matching indicator స్పష్టంగా లేదు' : why.join(' • '));
    }

    // Build 51 — D10 foundational result layer from the supplied D10 Basics
    // pages plus the user's explicit interpretation requirements.
    // Papakartari operational check = both adjacent houses contain at least
    // one natural malefic. This deterministic mapping is shown in the audit
    // trail and is not presented as a universal strength formula.
    int prevHouse(int house) => house == 1 ? 12 : house - 1;
    int nextHouse(int house) => house == 12 ? 1 : house + 1;
    List<String> maleficsInHouse(int house) =>
        _houseNames(v, house).where(_malefics.contains).toList(growable: false);
    List<String> beneficsInHouse(int house) =>
        _houseNames(v, house).where(_benefics.contains).toList(growable: false);
    bool papaKartari(int house) =>
        maleficsInHouse(prevHouse(house)).isNotEmpty &&
        maleficsInHouse(nextHouse(house)).isNotEmpty;
    List<String> conjunctionsOf(String planet) {
      final p = v.planets.firstWhere((x) => x.name == planet);
      return v.planets
          .where((x) => x.name != planet && x.signIndex == p.signIndex)
          .map((x) => x.name)
          .toList(growable: false);
    }

    final lagnaMalefics = d10LagnaNames.where(_malefics.contains).toList();
    final lagnaPapakartari = papaKartari(1);
    final lagnaAfflicted = lagnaMalefics.isNotEmpty || lagnaPapakartari;
    final lagnaAdjacentMalefics = <String>{
      ...maleficsInHouse(12),
      ...maleficsInHouse(2),
    }.toList();
    add(
      id: 'D10-BASE-01',
      topic: 'D10 లగ్నం — వృత్తిపై కోరిక / ఆసక్తి',
      result: lagnaAfflicted
          ? 'D10 లగ్నం పాపగ్రహ/పాపకర్తరీ ప్రభావంలో ఉంది. ఈ source interpretation ప్రకారం పనిమీద ఆసక్తి తగ్గడం, నిరాసక్తి లేదా కర్మలో అడ్డంకులు వచ్చే జాగ్రత్త layer.'
          : 'D10 లగ్నంపై ఈ evaluatorలో direct పాపగ్రహ లేదా పాపకర్తరీ దెబ్బ కనిపించలేదు; వృత్తిపై కోరిక/ఆసక్తిని నిలబెట్టుకునే అనుకూల layer.',
      rule: 'D10 Lagna ఈ జీవితంలోని karma చేయాలనే intention/aspirationను చూపుతుంది. లగ్నంలో పాపగ్రహాలు లేదా పాపకర్తరీ ఉంటే వృత్తిపై ఆసక్తి/ప్రవర్తన దెబ్బతినే layerగా చూడాలి. ప్రభావం ఏ గ్రహాల వల్ల వచ్చిందో అదే auditలో చూపాలి.',
      inspection: 'D10 Lagna ${_d10SignNames[d10LagnaSign]}. లగ్నంలో: ${d10LagnaNames.isEmpty ? 'గ్రహాలు లేవు' : d10LagnaNames.join(', ')}. పాపగ్రహాలు: ${lagnaMalefics.isEmpty ? 'లేవు' : lagnaMalefics.join(', ')}. పాపకర్తరీ: ${lagnaPapakartari ? 'అవును — పక్క భావాల పాపగ్రహాలు ${lagnaAdjacentMalefics.join(', ')}' : 'లేదు'}.',
      source: 'D10 special.pdf — Chapter 02 Basics, “Lagan” and “First house” (uploaded PDF pp.58–61 / printed pp.11–14). User-supplied D10 interpretation for malefic/Papakartari impact.',
      tone: lagnaAfflicted ? VargaRuleTone.caution : VargaRuleTone.favorable,
      applicable: true,
      remedy: 'ఇది వృత్తి ఆసక్తి/కర్మ patternకు జ్యోతిష్య సూచన మాత్రమే. Practicalగా ఆసక్తి తగ్గితే పని రకం, నైపుణ్యం, పని వాతావరణం, విశ్రాంతి మరియు మార్గదర్శకత్వాన్ని పరిశీలించాలి; source-specific పరిహారం ఉంటేనే విడిగా చూపాలి.',
    );

    final lagnaLord = d10FirstLord;
    final lagnaLordPlacement = v.planets.firstWhere((p) => p.name == lagnaLord);
    final lagnaLordHouse = _houseOf(v, lagnaLordPlacement);
    final lagnaLordConjunctions = conjunctionsOf(lagnaLord);
    final lagnaLordMalConj = lagnaLordConjunctions.where(_malefics.contains).toList();
    final lagnaLordPapakartari = papaKartari(lagnaLordHouse);
    final lagnaLordAfflicted = lagnaLordMalConj.isNotEmpty || lagnaLordPapakartari;
    add(
      id: 'D10-BASE-02',
      topic: 'D10 లగ్నాధిపతి — స్వయంకృత వృత్తి సమస్యలు',
      result: lagnaLordAfflicted
          ? 'D10 లగ్నాధిపతి దెబ్బతిన్న layer కనిపిస్తోంది. మీరు ఇచ్చిన rule ప్రకారం జాతకుడు స్వయంగా తీసుకునే నిర్ణయాలు/ప్రవర్తన వల్ల వృత్తిలో సమస్యలు తెచ్చుకునే అవకాశం పరిశీలించాలి; లగ్నాధిపతి ఉన్న భావం మరియు కలిసిన గ్రహాల అంశాలు కారణాన్ని చూపుతాయి.'
          : 'D10 లగ్నాధిపతికి direct పాపగ్రహ conjunction లేదా పాపకర్తరీ ఈ evaluatorలో కనిపించలేదు; స్వయంకృత అడ్డంకి strong match కాలేదు.',
      rule: 'D10 Lagna lord జాతకుడు తన karmaను ఎలా execute చేస్తాడో చూపుతుంది. లగ్నాధిపతి పాపగ్రహ కలయిక/పాపకర్తరీతో దెబ్బతింటే self-created professional difficultyగా చదవాలి; అది ఉన్న భావం మరియు conjunction planets వల్ల ఏ అంశాల ద్వారా సమస్య వస్తుందో audit చేయాలి.',
      inspection: 'లగ్నాధిపతి $lagnaLord • D10లో $lagnaLordHouseవ భావం • కలిసిన గ్రహాలు: ${lagnaLordConjunctions.isEmpty ? 'లేవు' : lagnaLordConjunctions.join(', ')} • పాప కలయిక: ${lagnaLordMalConj.isEmpty ? 'లేదు' : lagnaLordMalConj.join(', ')} • పాపకర్తరీ: ${lagnaLordPapakartari ? 'అవును' : 'లేదు'}.',
      source: 'D10 special.pdf — Chapter 02 Basics, “Lagan/First house” (uploaded PDF pp.58–61 / printed pp.11–14). User-supplied Lagna-lord self-created-problem interpretation.',
      tone: lagnaLordAfflicted ? VargaRuleTone.caution : VargaRuleTone.favorable,
      applicable: true,
      remedy: 'లగ్నాధిపతి resultను blameగా కాకుండా decision-pattern auditగా వాడాలి. పెద్ద career నిర్ణయాల్లో రెండో అభిప్రాయం, written plan, skill-gap check మరియు financial-risk check ఉపయోగపడతాయి.',
    );

    final fourthBenefics = beneficsInHouse(4);
    final fourthMalefics = maleficsInHouse(4);
    final fourthLord = _signLord(_houseSign(v, 4));
    final fourthLordPlacement = v.planets.firstWhere((p) => p.name == fourthLord);
    final fourthLordHouse = _houseOf(v, fourthLordPlacement);
    final fourthPapakartari = papaKartari(4);
    final fourthComfortCaution = fourthPapakartari ||
        (fourthMalefics.isNotEmpty && fourthBenefics.isEmpty) ||
        const {6, 8, 12}.contains(fourthLordHouse);
    add(
      id: 'D10-BASE-03',
      topic: 'D10 4వ భావం — వృత్తిలో సుఖం / పని వాతావరణం',
      result: fourthComfortCaution
          ? 'D10 4వ భావంలో comfort/acceptance layer జాగ్రత్తగా ఉంది. వృత్తిలో సుఖం, office/work-location comfort లేదా recognitionలో ఇబ్బందులు అనుభవించే సూచనగా చూడాలి.'
          : 'D10 4వ భావం comfort/acceptance layerకు అనుకూల support ఉంది; వృత్తిలో పని వాతావరణం, గుర్తింపు, సుఖం మెరుగ్గా ఉండే సూచన.',
      rule: 'D10 4వ భావం professionలో happiness/acceptance, recognition of talents మరియు office/location of businessను చూపుతుంది. 4వ భావం/4L దెబ్బతింటే వృత్తి సుఖం తగ్గే layerగా చూడాలి.',
      inspection: 'D10 4వ భావం: ${fourthNames.isEmpty ? 'గ్రహాలు లేవు' : fourthNames.join(', ')} • శుభగ్రహాలు: ${fourthBenefics.isEmpty ? 'లేవు' : fourthBenefics.join(', ')} • పాపగ్రహాలు: ${fourthMalefics.isEmpty ? 'లేవు' : fourthMalefics.join(', ')} • 4L $fourthLord → $fourthLordHouseవ భావం • పాపకర్తరీ: ${fourthPapakartari ? 'అవును' : 'లేదు'}.',
      source: 'D10 special.pdf — Chapter 02 Basics, Fourth house (uploaded PDF pp.61–62 / printed pp.14–15; detailed example printed p.22).',
      tone: fourthComfortCaution ? VargaRuleTone.caution : VargaRuleTone.favorable,
      applicable: true,
      remedy: 'వృత్తి సుఖం తగ్గినప్పుడు practicalగా work environment, location, reporting structure, commute, workload మరియు role-fitను సరిచూడాలి. Source-specific spiritual remedy ఉంటేనే అదనంగా చూపాలి.',
    );

    final seventhBenefics = beneficsInHouse(7);
    final seventhMalefics = maleficsInHouse(7);
    final seventhLordPlacement = v.planets.firstWhere((p) => p.name == d10SeventhLord);
    final seventhLordHouse = _houseOf(v, seventhLordPlacement);
    final seventhPapakartari = papaKartari(7);
    final sunInSeventh = seventhNames.contains('Sun');
    final seventhCaution = seventhPapakartari ||
        (seventhMalefics.isNotEmpty && seventhBenefics.isEmpty && !sunInSeventh);
    add(
      id: 'D10-BASE-04',
      topic: 'D10 7వ భావం — 10వ నుండి 10వ / వృత్తి ఆత్మ',
      result: seventhCaution
          ? 'D10 7వ భావం (10వ నుండి 10వ) దెబ్బతిన్న layerలో ఉంది; public image, professional strength లేదా high-position expressionలో జాగ్రత్త అవసరం.'
          : 'D10 7వ భావం — 10వ నుండి 10వ — వృత్తి యొక్క కీలక strength/public-image layerగా support చూపుతోంది${sunInSeventh ? '; Sun 7వలో ఉండటం sourceలో directional-strength supportగా కూడా చెప్పబడింది' : ''}.',
      rule: 'D10 7వ భావం 10వ భావం నుండి 10వ భావం. Source దీన్ని ముఖ్యమైన profession houseగా, public image/high positionతో అనుసంధానిస్తుంది; Sun ఇక్కడ digbaliగా చెప్పబడింది.',
      inspection: 'D10 7వ భావం: ${seventhNames.isEmpty ? 'గ్రహాలు లేవు' : seventhNames.join(', ')} • 7L $d10SeventhLord → $seventhLordHouseవ భావం • శుభగ్రహాలు ${seventhBenefics.isEmpty ? 'లేవు' : seventhBenefics.join(', ')} • పాపగ్రహాలు ${seventhMalefics.isEmpty ? 'లేవు' : seventhMalefics.join(', ')} • పాపకర్తరీ ${seventhPapakartari ? 'అవును' : 'లేదు'}.',
      source: 'D10 special.pdf — Chapter 02 Basics, Seventh house (uploaded PDF p.62 / printed p.15).',
      tone: seventhCaution ? VargaRuleTone.caution : VargaRuleTone.favorable,
      applicable: true,
    );

    final sunD10Base = v.planets.firstWhere((p) => p.name == 'Sun');
    final sunHouseBase = _houseOf(v, sunD10Base);
    final sunConj = conjunctionsOf('Sun');
    final sunBen = sunConj.where(_benefics.contains).toList();
    final sunMal = sunConj.where((x) => _malefics.contains(x) && x != 'Sun').toList();
    final sunSupport = sunHouseBase == 7 || (sunBen.isNotEmpty && sunMal.isEmpty);
    final sunCaution = sunMal.isNotEmpty && !sunSupport;
    add(
      id: 'D10-BASE-05',
      topic: 'D10 సూర్యుడు — మంచి మార్గదర్శకులు / సహాయకులు',
      result: sunSupport
          ? 'D10 Sunకు supportive layer ఉంది; మీరు ఇచ్చిన interpretation ప్రకారం వృత్తిలో మంచి మార్గదర్శకులు/సహాయక వ్యక్తులు జత అయ్యే సూచనగా చూడవచ్చు.'
          : sunCaution
              ? 'D10 Sunపై పాపసంబంధం ఉంది; వృత్తిలో సరైన మార్గదర్శకులు/సహాయకులు ఎంపికలో జాగ్రత్తగా ఉండే layer.'
              : 'D10 Sun position/association మిశ్రమంగా ఉంది; మంచి మార్గదర్శకుల supportపై స్పష్టమైన strong auto-verdict ఇవ్వకుండా auditగా చూపుతున్నాం.',
      rule: 'మీరు ఇచ్చిన D10 interpretationలో Sun ద్వారా మంచి సహాయకులు/మార్గదర్శకులు జత అవుతారో చూడాలి. Supplied source example Sun placementకు “good guide and God grace” అనే supportను చూపుతుంది. App operational mappingలో 7వ భావ Sun లేదా same-sign benefic associationను supportగా, malefic-only associationను cautionగా చూపుతున్నాం; ఇది universal classical formula కాదు.',
      inspection: 'D10 Sun $sunHouseBaseవ భావంలో • కలిసిన గ్రహాలు: ${sunConj.isEmpty ? 'లేవు' : sunConj.join(', ')} • supportive association: ${sunBen.isEmpty ? 'లేదు' : sunBen.join(', ')} • caution association: ${sunMal.isEmpty ? 'లేదు' : sunMal.join(', ')}.',
      source: 'D10 special.pdf — Chapter 02 Basics examples (uploaded PDF p.65 / printed p.18: Sun placement gives good guide/God-grace layer) + user-supplied D10 interpretation.',
      tone: sunSupport ? VargaRuleTone.favorable : sunCaution ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    final moonD10Base = v.planets.firstWhere((p) => p.name == 'Moon');
    final moonHouseBase = _houseOf(v, moonD10Base);
    final moonConj = conjunctionsOf('Moon');
    final moonBen = moonConj.where((x) => _benefics.contains(x) && x != 'Moon').toList();
    final moonMal = moonConj.where(_malefics.contains).toList();
    final moonTone = moonBen.length > moonMal.length
        ? VargaRuleTone.favorable
        : moonMal.length > moonBen.length
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'D10-BASE-06',
      topic: 'D10 చంద్రుడు — వృత్తి మనస్సు / మానసిక స్థితి',
      result: moonTone == VargaRuleTone.favorable
          ? 'D10 Moonకు supportive associations ఎక్కువగా ఉన్నాయి; వృత్తి విషయాల్లో మనస్సు/అనుభూతి స్థిరంగా స్పందించే అనుకూల layer.'
          : moonTone == VargaRuleTone.caution
              ? 'D10 Moonపై పాపసంబంధం ఎక్కువగా ఉంది; వృత్తి విషయంలో మనస్సు ఒత్తిడి, అస్థిరత లేదా emotional strainను జాగ్రత్తగా పరిశీలించాలి.'
              : 'D10 Moon association మిశ్రమం/neutralగా ఉంది; వృత్తి మనస్సు స్థితిని Moon ఉన్న భావం మరియు సంబంధిత గ్రహాలతో కలిసి చదవాలి.',
      rule: 'మీరు ఇచ్చిన D10 interpretationలో Moon మనస్సు యొక్క స్థితిని చూపుతుంది. App deterministic layerలో Moon ఉన్న భావం మరియు same-sign benefic/malefic associationsను audit చేసి supportive/caution tone మాత్రమే ఇస్తుంది; దీనిని medical/psychological diagnosisగా చదవకూడదు.',
      inspection: 'D10 Moon $moonHouseBaseవ భావంలో • కలిసిన గ్రహాలు: ${moonConj.isEmpty ? 'లేవు' : moonConj.join(', ')} • supportive: ${moonBen.isEmpty ? 'లేదు' : moonBen.join(', ')} • caution: ${moonMal.isEmpty ? 'లేదు' : moonMal.join(', ')}.',
      source: 'D10 special.pdf — Chapter 02 Basics examples + user-supplied D10 Moon/mind interpretation.',
      tone: moonTone,
      applicable: true,
      remedy: 'ఈ Moon result జ్యోతిష్య reflection మాత్రమే, mental-health diagnosis కాదు. Stress ఎక్కువైతే sleep, workload, breaks, supportive people మరియు అవసరమైతే qualified professional supportను practicalగా చూడాలి.',
    );


    // Build 55 — Government Service + Vipareet Raja Yoga source rules.
    //
    // Government Service source boundary:
    // - D9 gives the promise through the D1 5L/9L Navamsha-sign trine rule.
    // - The uploaded Government Service chapter itself says this is not the
    //   final decider and that Dashamsha must be referred to for conclusion.
    // - Therefore the D10 layer below is labelled as supporting confirmation,
    //   not as a new "classical Government formula".
    final d1FifthSign = (chart.ascendantSignIndex + 4) % 12;
    final d1NinthSign = (chart.ascendantSignIndex + 8) % 12;
    final d1FifthLord = _signLord(d1FifthSign);
    final d1NinthLord = _signLord(d1NinthSign);
    final d9FifthLordSign =
        d9.planets.firstWhere((p) => p.name == d1FifthLord).signIndex;
    final d9NinthLordSign =
        d9.planets.firstWhere((p) => p.name == d1NinthLord).signIndex;

    bool d1TrineSign(int sign) =>
        sign == d1FifthSign || sign == d1NinthSign;

    final govRule5 = d1TrineSign(d9FifthLordSign);
    final govRule9 = d1TrineSign(d9NinthLordSign);
    final govPromiseCount = (govRule5 ? 1 : 0) + (govRule9 ? 1 : 0);

    final sunD10Gov = v.planets.firstWhere((p) => p.name == 'Sun');
    final sunD10GovHouse = _houseOf(v, sunD10Gov);
    final d10GovAuthoritySupport = careerDevata.deity == 'Indra' ||
        d10TenthLord == 'Sun' ||
        sunD10GovHouse == 10 ||
        D10CareerService.relatedVarga(v, 'Sun', d10TenthLord);

    final govModeText = switch (saturnStream.dashamsaState) {
      'AGOCHARASHTHA' =>
        'D10 Saturn service mode — direct Government/employee formకు support.',
      'GOCHARASHTHA' =>
        'D10 Saturn owner/independent mode — Government consultant/advisor/contractor formను కూడా పరిశీలించాలి.',
      _ =>
        'D10 Saturn mixed mode — direct service vs Government-linked independent workకు మరింత confirmation అవసరం.',
    };

    add(
      id: 'D10-GOV-01',
      topic: 'Government Service — 5వ అధిపతి Navamsha Rule',
      result: govRule5
          ? '🟢 Government-service promise rule match అయింది: D1 5వ అధిపతి $d1FifthLord D9లో జన్మలగ్నం నుండి 5/9 త్రికోణ రాశిలో ఉంది.'
          : 'ఈ 5వ అధిపతి Government-service promise rule match కాలేదు.',
      rule: 'Source Rule 1: జనన 5వ అధిపతి Navamshaలో పొందిన రాశి, జనన లగ్నం నుండి 5వ లేదా 9వ రాశి అయితే Government Service indication వస్తుంది.',
      inspection:
          'D1 Lagna sign ${chart.ascendantSignIndex + 1}; 5H sign ${d1FifthSign + 1}; 9H sign ${d1NinthSign + 1}; 5L $d1FifthLord → D9 sign ${d9FifthLordSign + 1}.',
      source: 'gov job.pdf — Chapter 26 Government Service, p.1 (Rule 1).',
      tone: govRule5 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఇది Government-service promise indicator మాత్రమే. Source స్వయంగా Dashamsha final confirmation అవసరమని చెబుతుంది; qualification/exam/eligibility/practical opportunityను కూడా తప్పకుండా చూడాలి.',
    );

    add(
      id: 'D10-GOV-02',
      topic: 'Government Service — 9వ అధిపతి Navamsha Rule',
      result: govRule9
          ? '🟢 Government-service/support rule match అయింది: D1 9వ అధిపతి $d1NinthLord D9లో జన్మలగ్నం నుండి 5/9 త్రికోణ రాశిలో ఉంది.'
          : 'ఈ 9వ అధిపతి Government-service/support promise rule match కాలేదు.',
      rule: 'Source Rule 2: జనన 9వ అధిపతి Navamshaలో పొందిన రాశి, జనన లగ్నం నుండి 5వ లేదా 9వ రాశి అయితే Government Service లేదా Government support indication వస్తుంది.',
      inspection:
          'D1 Lagna sign ${chart.ascendantSignIndex + 1}; 5H sign ${d1FifthSign + 1}; 9H sign ${d1NinthSign + 1}; 9L $d1NinthLord → D9 sign ${d9NinthLordSign + 1}.',
      source: 'gov job.pdf — Chapter 26 Government Service, p.1 (Rule 2).',
      tone: govRule9 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Government support అనేది direct ఉద్యోగమే కావాల్సిన అవసరం లేదు; sourceలో consultant/advisor/contractor form కూడా సూచించబడింది.',
    );

    final govD10Confirmed = govPromiseCount > 0 && d10GovAuthoritySupport;
    final govStrong = govPromiseCount == 2 && d10GovAuthoritySupport;
    final govResult = govStrong
        ? '🟢 Government promise బలంగా ఉంది (5L + 9L రెండు D9 rules) మరియు D10 authority confirmation కూడా ఉంది. $govModeText'
        : govD10Confirmed
            ? '🟢 Government promise + D10 authority support ఉంది. $govModeText'
            : govPromiseCount > 0
                ? '🟡 D9లో Government promise ఉంది; కానీ current D10 authority checkలో పూర్తి confirmation లేదు. Source ప్రకారం final conclusionకు D10ను తప్పకుండా చూడాలి.'
                : 'Government-service D9 promise rules ఈ chartలో match కాలేదు; D10 authority indicators ఒక్కటే Government jobను ప్రకటించడానికి సరిపోవు.';
    add(
      id: 'D10-GOV-03',
      topic: 'Government Service — D9 Promise → D10 Confirmation',
      result: govResult,
      rule: 'Uploaded Government Service source D9 5L/9L rulesను promiseగా ఇస్తుంది మరియు final conclusionకు Dashamsha చూడమని చెబుతుంది. D10 exact Government formula ఆ 8-page sourceలో ఇవ్వలేదు. అందువల్ల app existing source-backed D10 authority layer (Sun/10H/10L/Indra)ను supporting confirmationగా మాత్రమే ఉపయోగిస్తుంది.',
      inspection:
          'D9 promise count $govPromiseCount/2 • D10 10L $d10TenthLord • Sun H$sunD10GovHouse • 10L Devata ${careerDevata.deity} • D10 Saturn ${saturnStream.dashamsaState} • authority-support ${d10GovAuthoritySupport ? 'yes' : 'no'}.',
      source: 'gov job.pdf p.1 + D10 special.pdf / supplied D10 profession-authority rules.',
      tone: govStrong || govD10Confirmed
          ? VargaRuleTone.favorable
          : govPromiseCount > 0
              ? VargaRuleTone.neutral
              : VargaRuleTone.info,
      applicable: true,
      remedy: 'Government-job resultను career decision-supportగా మాత్రమే చూడాలి. Exam eligibility, education, age limits, vacancies, preparation మరియు actual recruitment processే practical deciding factors.',
    );

    add(
      id: 'D10-GOV-04',
      topic: 'Senior Government Position / Government-linked Role',
      result: govStrong
          ? 'Senior/authority Government roleకు source promise + D10 authority support రెండూ ఉన్నాయి; final status/timing rulesతో cross-check చేయాలి.'
          : govPromiseCount > 0 && saturnStream.dashamsaState == 'GOCHARASHTHA'
              ? 'Government-linked consultant / advisor / contractor formను కూడా పరిశీలించాలి; source Government chapter direct employee కాకపోయినా Government కోసం పని చేసే అవకాశం చెబుతుంది.'
              : govPromiseCount > 0
                  ? 'Government service/support indication ఉంది; senior-position verdictకు D10 status/rise rulesతో అదనపు confirmation అవసరం.'
                  : 'Senior Government Position ruleకు base Government promise ఈ evaluatorలో లేదు.',
      rule: 'Source examplesలో 5L/9L rules strongగా ఉన్నప్పుడు senior Government position కనిపిస్తుంది. Government chapter direct employee కాకుండా consultant/advisor/contractor possibilityను కూడా స్పష్టంగా ఉంచుతుంది.',
      inspection:
          '5L rule ${govRule5 ? '✓' : '✗'} • 9L rule ${govRule9 ? '✓' : '✗'} • D10 authority ${d10GovAuthoritySupport ? '✓' : '✗'} • mode ${saturnStream.dashamsaState}.',
      source: 'gov job.pdf pp.1–4 (Government Service rules and IAS/MNC examples).',
      tone: govStrong ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    // Vipareet Raja Yoga / Super-Strong Vipareet Raja Yoga.
    //
    // The source explicitly distinguishes the structural dusthana placement
    // from Phaladeepika's malefic-relation condition. The app therefore shows
    // "structural candidate" separately from "full source support".
    bool isDebilitatedInSign(String planet, int sign) => switch (planet) {
      'Sun' => sign == 6,      // Libra
      'Moon' => sign == 7,     // Scorpio
      'Mars' => sign == 3,     // Cancer
      'Mercury' => sign == 11, // Pisces
      'Jupiter' => sign == 9,  // Capricorn
      'Venus' => sign == 5,    // Virgo
      'Saturn' => sign == 0,   // Aries
      _ => false,
    };

    int relativeHouse(int fromHouse, int toHouse) =>
        ((toHouse - fromHouse + 12) % 12) + 1;

    List<String> relatedFromSet(String planet, Set<String> set) => set
        .where((other) =>
            other != planet &&
            D10CareerService.relatedVarga(v, planet, other))
        .toList(growable: false);

    ({String lord, int sourceHouse, int placementHouse, int sign,
      List<String> malefics, List<String> benefics})
        vipreetProfile(int sourceHouse) {
      final lord = _signLord(_houseSign(v, sourceHouse));
      final p = v.planets.firstWhere((x) => x.name == lord);
      return (
        lord: lord,
        sourceHouse: sourceHouse,
        placementHouse: _houseOf(v, p),
        sign: p.signIndex,
        malefics: relatedFromSet(lord, _malefics),
        benefics: relatedFromSet(lord, _benefics),
      );
    }

    final vp3 = vipreetProfile(3);
    final vp6 = vipreetProfile(6);
    final vp8 = vipreetProfile(8);
    final vp12 = vipreetProfile(12);

    bool fullMaleficSupport(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) =>
        p.malefics.isNotEmpty;

    bool mixedBenefic(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) =>
        p.malefics.isNotEmpty && p.benefics.isNotEmpty;

    final harshaStructure = const {8, 12}.contains(vp6.placementHouse);
    final saralaStructure = const {6, 12}.contains(vp8.placementHouse);
    final vimalaStructure = const {6, 8}.contains(vp12.placementHouse);

    void addVipreetClassic({
      required String id,
      required String name,
      required ({
        String lord,
        int sourceHouse,
        int placementHouse,
        int sign,
        List<String> malefics,
        List<String> benefics
      }) profile,
      required bool structure,
      required String placementRule,
    }) {
      final full = structure && fullMaleficSupport(profile);
      final mixed = full && mixedBenefic(profile);
      final status = !structure
          ? 'ఈ structural placement లేదు.'
          : !full
              ? 'Structural Vipareet placement ఉంది; Phaladeepika malefic-relation confirmation ఈ evaluatorలో లేదు.'
              : mixed
                  ? 'Vipareet placement + malefic relation ఉంది; benefic relation కూడా ఉండటంతో mixed/qualified result.'
                  : '🟢 Vipareet placement + malefic relation match — strong source support.';
      add(
        id: id,
        topic: '$name — D10 Career Vipareet Raja Yoga',
        result: status,
        rule: '$placementRule Phaladeepika layer: Vipareet-house lord bad houseలో ఉండి malefic conjunction/aspect పొందితే yoga result బలపడుతుంది. Benefic relation ఉంటే resultను mixed/qualifiedగా చూపాలి.',
        inspection:
            '${profile.lord} (H${profile.sourceHouse} lord) → D10 H${profile.placementHouse}, sign ${profile.sign + 1} • malefic relations: ${profile.malefics.isEmpty ? 'none' : profile.malefics.join(', ')} • benefic relations: ${profile.benefics.isEmpty ? 'none' : profile.benefics.join(', ')}.',
        source: 'vipareet raja yoga.pdf pp.1–5 (Uttar Kalamrita, Phaladeepika, BPHS/Mansagari summary).',
        tone: full && !mixed
            ? VargaRuleTone.favorable
            : structure
                ? VargaRuleTone.neutral
                : VargaRuleTone.info,
        applicable: true,
        remedy: 'ఈ yoga adversity తర్వాత rise అనే career patternకు source indicator మాత్రమే. Practical decisionsలో risk management, documentation, skill, finance మరియు timingను విడిగా చూడాలి.',
      );
    }

    addVipreetClassic(
      id: 'D10-VRY-01',
      name: 'Harsha',
      profile: vp6,
      structure: harshaStructure,
      placementRule: '6వ అధిపతి 8వ లేదా 12వ భావంలో ఉంటే Harsha-type Vipareet structural condition.',
    );
    addVipreetClassic(
      id: 'D10-VRY-02',
      name: 'Sarala',
      profile: vp8,
      structure: saralaStructure,
      placementRule: '8వ అధిపతి 6వ లేదా 12వ భావంలో ఉంటే Sarala-type Vipareet structural condition.',
    );
    addVipreetClassic(
      id: 'D10-VRY-03',
      name: 'Vimala',
      profile: vp12,
      structure: vimalaStructure,
      placementRule: '12వ అధిపతి 6వ లేదా 8వ భావంలో ఉంటే Vimala-type Vipareet structural condition.',
    );

    bool ssvyStructural(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) {
      const vipreetSet = {3, 6, 8, 12};
      return vipreetSet.contains(p.placementHouse) &&
          p.placementHouse != p.sourceHouse;
    }

    String ssvyAudit(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) {
      final structure = ssvyStructural(p);
      final fromOwnHouse =
          const {6, 8, 12}.contains(relativeHouse(p.sourceHouse, p.placementHouse));
      final deb = isDebilitatedInSign(p.lord, p.sign);
      final onlyMalefic = p.malefics.isNotEmpty && p.benefics.isEmpty;
      return 'H${p.sourceHouse}L ${p.lord} → H${p.placementHouse}: '
          'listed-vipreet ${structure ? '✓' : '✗'}, '
          '6/8/12 from own house ${fromOwnHouse ? '✓' : '✗'}, '
          'debilitation ${deb ? '✓' : '✗'} (enemy-sign variant source-only), '
          'only-malefic relation ${onlyMalefic ? '✓' : '✗'}';
    }

    bool superStrongAuto(({
      String lord,
      int sourceHouse,
      int placementHouse,
      int sign,
      List<String> malefics,
      List<String> benefics
    }) p) {
      final structure = ssvyStructural(p);
      final fromOwnHouse =
          const {6, 8, 12}.contains(relativeHouse(p.sourceHouse, p.placementHouse));
      final signCondition = isDebilitatedInSign(p.lord, p.sign);
      final onlyMalefic = p.malefics.isNotEmpty && p.benefics.isEmpty;
      // Enemy-sign is a source condition too, but the supplied pages do not
      // include a friendship table. To avoid silently importing outside rules,
      // auto-confirmation is restricted to the explicit debilitation branch.
      return structure && fromOwnHouse && signCondition && onlyMalefic;
    }

    final ssvyProfiles = [vp3, vp6, vp8, vp12];
    final ssvyCandidates =
        ssvyProfiles.where(ssvyStructural).toList(growable: false);
    final ssvyAutoFull =
        ssvyProfiles.where(superStrongAuto).toList(growable: false);

    add(
      id: 'D10-VRY-04',
      topic: 'Super Strong Vipareet Raja Yoga — D10',
      result: ssvyAutoFull.isNotEmpty
          ? '🟢 Super-Strong Vipareet full auto-confirmation (debilitation branch) ${ssvyAutoFull.length} placement(s)లో ఉంది. D10 career significationsలో adversity తర్వాత strong rise/success patternను status/timing rulesతో cross-check చేయాలి.'
          : ssvyCandidates.isNotEmpty
              ? '🟡 Super-Strong Vipareet structural candidate ${ssvyCandidates.length} placement(s)లో ఉంది; enemy/debilitation + only-malefic పూర్తి source gate ఈ evaluatorలో పూర్తిగా confirm కాలేదు.'
              : 'Super-Strong Vipareet structural placement ఈ D10లో match కాలేదు.',
      rule: 'Source Super-Strong conditions: ఒక Vipareet lord మరో Vipareet houseలో ఉండాలి; తన source houseనుంచి కూడా 6/8/12 relation ఉండాలి; placement sign enemy లేదా debilitation కావాలి; relation only malefic కావాలి. Source later lists 3L/6L/8L/12L placements among 3/6/8/12. App enemy-sign friendship tableను outside source నుంచి import చేయదు; debilitation branch మాత్రమే auto-confirms.',
      inspection: [
        ssvyAudit(vp3),
        ssvyAudit(vp6),
        ssvyAudit(vp8),
        ssvyAudit(vp12),
      ].join(' | '),
      source: 'vipareet raja yoga.pdf pp.10–12 — Super Strong Vipreet Raj Yoga conditions and placement list.',
      tone: ssvyAutoFull.isNotEmpty
          ? VargaRuleTone.favorable
          : ssvyCandidates.isNotEmpty
              ? VargaRuleTone.neutral
              : VargaRuleTone.info,
      applicable: true,
    );

    final anyClassicStructure =
        harshaStructure || saralaStructure || vimalaStructure;
    final anyClassicFull =
        (harshaStructure && fullMaleficSupport(vp6)) ||
        (saralaStructure && fullMaleficSupport(vp8)) ||
        (vimalaStructure && fullMaleficSupport(vp12));
    add(
      id: 'D10-VRY-05',
      topic: 'Vipareet Raja Yoga — Career Effect / Timing Note',
      result: ssvyAutoFull.isNotEmpty
          ? 'D10లో Super-Strong Vipareet source support ఉంది. Source divisional-chart rule ప్రకారం D10 career/status significationsలో adversity/problems తర్వాత rise/great-success patternకు ఇది supportive layer; yoga lord Dasha/AD timingను విడిగా చూడాలి.'
          : anyClassicFull
              ? 'D10లో Vipareet Raja Yoga source support ఉంది. Careerలో ముందుగా ప్రతికూలత/సమస్యల తర్వాత recovery/rise patternను timing rulesతో చూడాలి.'
              : anyClassicStructure || ssvyCandidates.isNotEmpty
                  ? 'D10లో Vipareet structural indication ఉంది; పూర్తి yoga strength/timingకు remaining source conditions మరియు Dasha confirmation అవసరం.'
                  : 'D10లో current Vipareet structural rules match కాలేదు.',
      rule: 'Source divisional-chart rule: varga ఒక specific areaని సూచిస్తుంది; SSVY ఆ chart significationsను promote చేస్తుంది, సాధారణంగా సమస్యలు/బాధలు అనుభవించిన తర్వాత. Normal Vipareet effects దాని Dashaలో అనుభవించబడతాయని source note ఉంది.',
      inspection:
          'Classic structural ${anyClassicStructure ? 'yes' : 'no'} • classic malefic-confirmed ${anyClassicFull ? 'yes' : 'no'} • SSVY candidates ${ssvyCandidates.length} • auto-full ${ssvyAutoFull.length}.',
      source: 'vipareet raja yoga.pdf pp.11–12 & 19–32 (D10/other divisional examples and divisional-chart rule).',
      tone: ssvyAutoFull.isNotEmpty || anyClassicFull
          ? VargaRuleTone.favorable
          : anyClassicStructure || ssvyCandidates.isNotEmpty
              ? VargaRuleTone.neutral
              : VargaRuleTone.info,
      applicable: true,
      remedy: 'ఈ sourceలో D10 Vipareet career resultకు ప్రత్యేక పరిహారం ఇవ్వలేదు. Yogaను practical career-risk planningకు substitute చేయకూడదు.',
    );


    _beneficMaleficHouseRule(
      v: v,
      house: 10,
      favorableId: 'D10-CAR-01',
      cautionId: 'D10-CAR-02',
      topic: 'వృత్తి / స్థాయి',
      favorableResult: 'D10 10వ భావంలో శుభగ్రహ support ఉంది; స్థాయి/గౌరవం/వృత్తికి అనుకూల layer.',
      cautionResult: 'D10 10వ భావంలో పాపగ్రహ ప్రభావం ఉంది; వృత్తిలో ఒత్తిడి/శిక్ష/అవమానం వంటి జాగ్రత్త layer.',
      rule: 'D10 Lagna, 10వ భావం, 10వ అధిపతి, అమాత్యకారక బలం/శుభ సంబంధాన్ని స్థాయి–కీర్తికి చూడాలి; పీడ ఉంటే అవమానం/శిక్ష layer.',
      source: '“D10-dashamsha-rule-guide.pdf” + Sarala VII D10 p.7',
      add: add,
    );

    final supportHouses = [2, 4, 11, 5];
    final obstructionHouses = [12, 10, 3, 9];
    final supportCount = supportHouses.fold<int>(0, (sum, h) => sum + _houseNames(v, h).length);
    final obstructionCount = obstructionHouses.fold<int>(0, (sum, h) => sum + _houseNames(v, h).length);
    final argalaTone = supportCount > obstructionCount
        ? VargaRuleTone.favorable
        : obstructionCount > supportCount
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'D10-R6.1',
      topic: 'వృత్తి అర్గళ బలం',
      result: supportCount > obstructionCount
          ? 'D10లో అర్గళ support అడ్డుకంటే ఎక్కువగా ఉంది; వృత్తి నిలకడకు అనుకూల source arithmetic.'
          : obstructionCount > supportCount
              ? 'D10లో అడ్డుగ్రహ count అర్గళ supportకంటే ఎక్కువగా ఉంది; వృత్తి స్థిరత్వంలో జాగ్రత్త layer.'
              : 'D10 అర్గళ–అడ్డుగ్రహ count సమంగా ఉంది; మిశ్రమ support.',
      rule: '4, 2, 11 భావాలు అర్గళ; వాటి అడ్డులు 10, 12, 3. 5వ భావం కూడా అర్గళ; 9వ భావం అడ్డుగా చూడాలి. అర్గళ గ్రహాలు అడ్డుకంటే బలంగా/ఎక్కువగా ఉంటే వృత్తి నిలుస్తుంది.',
      inspection: 'Argala houses 2/4/11/5 = $supportCount occupants; obstruction 12/10/3/9 = $obstructionCount occupants.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.1, p.8',
      tone: argalaTone,
      applicable: supportCount != obstructionCount,
    );

    final h3Mal = thirdNames.where(_malefics.contains).toList();
    add(
      id: 'D10-R6.2',
      topic: 'ప్రత్యేక అర్గళ',
      result: h3Mal.length >= 3 ? 'D10 3వ భావంలో 3+ పాపగ్రహాలు ఉన్నాయి; source ప్రకారం ప్రత్యేక అర్గళ layer.' : 'ప్రత్యేక అర్గళ condition match కాలేదు.',
      rule: '3వ భావంలో 3 లేదా ఎక్కువ పాపగ్రహాలు ఉంటే ప్రత్యేక అర్గళ; దీనికి అడ్డుగా source చూడదు.',
      inspection: 'D10 3వ భావ పాపగ్రహాలు: ${h3Mal.isEmpty ? 'లేవు' : h3Mal.join(', ')}.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.2, p.8',
      tone: h3Mal.length >= 3 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: h3Mal.length >= 3,
    );

    final natal10Planets = chart.planets.where((p) => p.signIndex == d1TenthSign).toList();
    final lordArgala = supportHouses.contains(d10TenthLordHouse) || d10TenthLordHouse == 1 || d10TenthLordHouse == 10;
    add(
      id: 'D10-R6.9',
      topic: 'జన్మ 10వ అధిపతి × D10',
      result: lordArgala ? 'జన్మ 10వ అధిపతి D10లో ముఖ్య/అర్గళ స్థానంలో ఉంది; వృత్తి నిర్ణయానికి బలమైన confirmation layer.' : 'జన్మ 10వ అధిపతి D10లో ప్రధాన argala/Lagna/10వ స్థానానికి match కాలేదు.',
      rule: 'జన్మ 10వ అధిపతి D10లో అర్గళ ఇస్తే ముఖ్యంగా చూడాలి; D10 Lagna/10వ సంబంధం ఉంటే ఫలిత weight పెరుగుతుంది.',
      inspection: 'జన్మ 10వ రాశి ${d1TenthSign + 1}; అధిపతి $d1TenthLord; D10లో $d1TenthLord House ${_houseOf(v, v.planets.firstWhere((p) => p.name == d1TenthLord))}. జన్మ 10వలో గ్రహాలు: ${natal10Planets.isEmpty ? 'లేవు' : natal10Planets.map((p) => p.name).join(', ')}.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.9, p.9',
      tone: lordArgala ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: lordArgala,
    );


    // Build 50 — exact source-name profession registry.
    //
    // Source gate from vrutti-graha-devata.pdf:
    // 1) natal 10th-house planet is the profession-planet candidate,
    // 2) the same planet must connect with D10 Lagna / 10H / 10L,
    // 3) exact name is read from profession planet + 10th Dashamsha Devata,
    // 4) explicit Saturn Gocharastha/Agocharastha conditions refine owner/authority/service,
    // 5) the source "additional" column is used only where it is machine-readable;
    //    unclear strength/Navamsha wording is shown for audit instead of being invented.
    const extraPlanetTokens = <String, String>{
      'సూర్యుడు': 'Sun',
      'చంద్రు డు': 'Moon',
      'అంగారకుడు': 'Mars',
      'బుధుడు': 'Mercury',
      'గురువు': 'Jupiter',
      'శుక్రు డు': 'Venus',
      'శని': 'Saturn',
      'రాహువు': 'Rahu',
      'కేతువు': 'Ketu',
    };
    const standardDevatas = <String>{
      'Indra', 'Agni', 'Yama', 'Rakshash', 'Varuna', 'Vayu', 'Kubera', 'Ishana',
      'Brahma', 'Ananta',
    };

    bool axisSupport(String planet) {
      final p = v.planets.firstWhere((x) => x.name == planet);
      final h = _houseOf(v, p);
      return h == 1 ||
          h == 10 ||
          planet == d10TenthLord ||
          D10CareerService.relatedVarga(v, planet, d10TenthLord);
    }

    bool sameSign(String a, String b) {
      final pa = v.planets.firstWhere((x) => x.name == a);
      final pb = v.planets.firstWhere((x) => x.name == b);
      return pa.signIndex == pb.signIndex;
    }

    bool houseAxisSupport(String planet, int house) {
      final p = v.planets.firstWhere((x) => x.name == planet);
      if (_houseOf(v, p) == house) return true;
      final lord = _signLord(_houseSign(v, house));
      if (planet == lord || d10TenthLord == lord) return true;
      return D10CareerService.relatedVarga(v, planet, lord) ||
          D10CareerService.relatedVarga(v, d10TenthLord, lord);
    }

    final natalTenthNames = natal10Planets.map((p) => p.name).toSet();
    final exactProfessionRanked =
        <({D10ProfessionRule rule, int score, String status, String why})>[];
    var specialDevataSourceOnly = 0;

    for (final rule in d10ProfessionRules) {
      final birthCandidate = natalTenthNames.contains(rule.planet);
      final d10Confirm = axisSupport(rule.planet);
      final devataAuto = standardDevatas.contains(rule.devata);
      final devataMatch = devataAuto && careerDevata.deity == rule.devata;
      if (!devataAuto) specialDevataSourceOnly++;

      final extraPlanets = <String>[];
      extraPlanetTokens.forEach((token, planet) {
        if (rule.extra.contains(token) &&
            planet != rule.planet &&
            !extraPlanets.contains(planet)) {
          extraPlanets.add(planet);
        }
      });

      final hasConjunctionCondition = rule.extra.contains('కలిస్తే');
      final conjunctionOk = !hasConjunctionCondition ||
          extraPlanets.isEmpty ||
          extraPlanets.every((p) => sameSign(rule.planet, p));

      final extraPlanetOk = extraPlanets.isEmpty ||
          (hasConjunctionCondition
              ? conjunctionOk
              : extraPlanets.every(axisSupport));

      final houseNums = <int>[];
      if (!rule.extra.contains('నవాంశం')) {
        for (final m in RegExp(r'\d+').allMatches(rule.extra)) {
          final n = int.tryParse(m.group(0) ?? '');
          if (n != null && n >= 1 && n <= 12 && !houseNums.contains(n)) {
            houseNums.add(n);
          }
        }
      }
      final houseOk = houseNums.isEmpty ||
          houseNums.any((h) => houseAxisSupport(rule.planet, h));

      final needsGo = rule.extra.contains('శని గోచరం');
      final needsAgo = rule.extra.contains('శని అగోచరం');
      final modeOk = (!needsGo || saturnStream.dashamsaState == 'GOCHARASHTHA') &&
          (!needsAgo || saturnStream.dashamsaState == 'AGOCHARASHTHA');

      // "బలం" and explicit Navamsha-lord wording need a dedicated source
      // strength/Navamsha evaluator. They remain visible in the rule audit but
      // are not silently treated as satisfied.
      final manualExtra = rule.extra.contains('నవాంశం') ||
          rule.extra.contains(' బలం') ||
          rule.extra.endsWith('బలం');

      final bothCharts = birthCandidate && d10Confirm;
      final oneChart = birthCandidate != d10Confirm;
      final readableExtraOk = conjunctionOk && extraPlanetOk && houseOk && modeOk;

      String status;
      int score;
      // Build 52: an explicit machine-readable source condition (house,
      // conjunction, Saturn mode) must actually match before an exact
      // profession row can be shown as supported/confirmed. Previously a
      // matching planet+Devata could still surface a row even when its stated
      // house/conjunction condition failed, which made broad worker/consultant
      // labels look more certain than the source allowed.
      if (devataMatch && bothCharts && readableExtraOk) {
        if (manualExtra) {
          status = 'supported';
          score = 85;
        } else {
          status = 'confirmed';
          score = 100;
        }
      } else if (devataMatch && oneChart && readableExtraOk) {
        status = 'half';
        score = 55;
      } else {
        status = 'none';
        score = 0;
      }

      final why = <String>[
        'జనన 10వ భావ profession-planet ${birthCandidate ? '✓' : '✗'}',
        'D10 Lagna/10H/10L confirmation ${d10Confirm ? '✓' : '✗'}',
        '10వ Devata ${rule.devata}: ${devataMatch ? '✓' : (devataAuto ? '✗' : 'source-only')}',
        if (needsGo) 'Saturn Gocharastha ${saturnStream.dashamsaState == 'GOCHARASHTHA' ? '✓' : '✗'}',
        if (needsAgo) 'Saturn Agocharastha ${saturnStream.dashamsaState == 'AGOCHARASHTHA' ? '✓' : '✗'}',
        if (extraPlanets.isNotEmpty) 'అదనపు గ్రహ support ${extraPlanetOk ? '✓' : '✗'}',
        if (houseNums.isNotEmpty) 'అదనపు భావ support ${houseOk ? '✓' : '✗'}',
        if (manualExtra) 'source strength/Navamsha clause: manual/source-only',
      ].join(' • ');

      exactProfessionRanked.add(
        (rule: rule, score: score, status: status, why: why),
      );
    }

    exactProfessionRanked.sort((a, b) {
      final c = b.score.compareTo(a.score);
      if (c != 0) return c;
      return a.rule.id.compareTo(b.rule.id);
    });

    final exactStrong = exactProfessionRanked
        .where((x) => x.status == 'confirmed' || x.status == 'supported')
        .toList(growable: false);
    final exactHalf = exactProfessionRanked
        .where((x) => x.status == 'half')
        .toList(growable: false);
    final exactVisible = <({D10ProfessionRule rule, int score, String status, String why})>[
      ...exactStrong.take(12),
      ...exactHalf.take(6),
    ];
    final exactConfirmed = exactStrong;

    final d10Mode = switch (saturnStream.dashamsaState) {
      'GOCHARASHTHA' => (careerDevata.deity == 'Indra' || natalTenthNames.contains('Sun'))
          ? 'Self-employment / Owner + Authority potential'
          : 'Self-employment / Owner',
      'AGOCHARASHTHA' => 'Job / Service / Employee',
      _ => 'Mixed / needs supporting confirmation',
    };

    // Build 52 presentation order: Mode -> Exact Profession -> Supporting
    // Devata. These are deliberately separated so a generic work-level label
    // (for example "manual worker") cannot visually override an exact
    // source-name profession.
    add(
      id: 'D10-PROF-MODE-SOURCE',
      topic: '1. వృత్తి విధానం / Mode',
      result: '$d10Mode • D10 Saturn: ${saturnStream.dashamsaState}.',
      rule: 'Supplied Saturn source ప్రకారం profession పేరు planet + 10th Devata ద్వారా confirm అవుతుంది; Saturn profession type మాత్రమే చెబుతాడు. D10 Saturn Gocharastha అయితే self-employment/owner; Sun/Indra authority support ఉంటే authority/high-position layer. Agocharastha అయితే job/service/employee. ఇది transit కాదు — D10లో Saturn స్థితి.',
      inspection: 'D10 Saturn state: ${saturnStream.dashamsaState}; 10L Devata: ${careerDevata.deity}; natal 10H Sun: ${natalTenthNames.contains('Sun') ? 'yes' : 'no'}.',
      source: 'sani-gochara-agochara.pdf pp.1–2; swantam-perlu.pdf pp.1–2; agochara-perlu.pdf p.1.',
      tone: saturnStream.dashamsaState == 'MIXED' ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    final sourcePrimary = exactConfirmed.isEmpty ? null : exactConfirmed.first;
    final exactAlternatives = exactConfirmed.skip(1).take(5).map((x) => x.rule.name).toList();
    final halfAlternatives = exactHalf.take(5).map((x) => x.rule.name).toList();
    add(
      id: 'D10-EXACT-PROF-SUMMARY',
      topic: '2. Exact Profession / ఖచ్చిత వృత్తి',
      result: sourcePrimary != null
          ? 'ప్రధాన source-confirmed వృత్తి: ${sourcePrimary.rule.name}.${exactAlternatives.isEmpty ? '' : ' ఇతర బలమైన వృత్తులు: ${exactAlternatives.join(' • ')}.'}${halfAlternatives.isEmpty ? '' : ' పాక్షిక support: ${halfAlternatives.join(' • ')}.'}'
          : exactHalf.isNotEmpty
              ? 'పూర్తి source confirmation లేదు. పాక్షికంగా సరిపడిన వృత్తులు: ${halfAlternatives.join(' • ')}.'
              : 'ఈ strict source gateలో exact profession పేరు confirm కాలేదు. కింద broad career-field supportను మాత్రమే చూడండి.',
      rule: 'Exact profession పేరు = జనన 10వ భావ profession-planet + అదే గ్రహానికి D10 Lagna/10H/10L confirmation + 10వ Dashamsha Devata + sourceలో ఉన్న explicit అదనపు గ్రహ/భావ/Saturn-mode condition. Machine-readable అదనపు condition fail అయితే rowను confirmed/supportగా చూపకూడదు.',
      inspection: sourcePrimary != null
          ? sourcePrimary.why
          : 'జనన 10వలో: ${natalTenthNames.isEmpty ? 'గ్రహం లేదు' : natalTenthNames.join(', ')} • D10 10L: $d10TenthLord • 10L Devata: ${careerDevata.deity} • D10 Saturn: ${saturnStream.dashamsaState}.',
      source: 'vrutti-graha-devata.pdf pp.1–6; sani-gochara-agochara.pdf pp.1–2.',
      tone: sourcePrimary != null ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'వృత్తి పేరు source-rule matching మాత్రమే. విద్య, నైపుణ్యం, ఆసక్తి, అనుభవం, practical opportunity మరియు ఆర్థిక పరిస్థితిని కూడా కలిపి నిర్ణయించాలి.',
    );

    add(
      id: 'D10-EXACT-PROF-LIST',
      topic: 'జాతకం ప్రకారం Exact Profession List',
      result: exactVisible.isEmpty
          ? 'ఈ strict source gateలో exact profession పేరు confirm కాలేదు.'
          : exactVisible.map((x) {
              final icon = x.status == 'confirmed' ? '🟢' : x.status == 'supported' ? '✅' : '🟡';
              final tag = x.status == 'half' ? 'సగం support' : x.status == 'supported' ? 'source support' : 'confirm';
              return '$icon ${x.rule.name} — $tag';
            }).join(' • '),
      rule: 'Exact profession పేరు కోసం supplied vrutti-graha-devata source gate: జనన 10వ ఇంటి profession planet + అదే గ్రహానికి D10 Lagna/10H/10L confirmation + 10వ Dashamsha Devata match. Explicit అదనపు గ్రహ/భావ/Saturn condition కూడా match అయితేనే confirm/support. జననం లేదా D10లో ఒక్క layer మాత్రమే ఉంటే సగం support.',
      inspection: 'జనన 10వలో: ${natalTenthNames.isEmpty ? 'గ్రహం లేదు' : natalTenthNames.join(', ')} • D10 10L: $d10TenthLord • 10L Devata: ${careerDevata.deity} • D10 Saturn: ${saturnStream.dashamsaState} • Mode: $d10Mode • Loaded source-name rules: ${d10ProfessionRules.length} • Special Sun/Venus-deity rows source-only: $specialDevataSourceOnly.',
      source: 'vrutti-graha-devata.pdf — pp.1–6; sani-gochara-agochara.pdf — profession type rules; swantam-perlu.pdf / agochara-perlu.pdf — owner/service name layers.',
      tone: exactConfirmed.isNotEmpty ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Sourceలో profession selectionకు ప్రత్యేక spiritual remedy ఇవ్వలేదు. Qualification, training, aptitude, opportunity మరియు financial realityని కూడా చూడాలి.',
    );

    final devataExactMatches = exactConfirmed
        .where((x) => x.rule.devata == careerDevata.deity)
        .map((x) => x.rule.name)
        .take(6)
        .toList(growable: false);
    add(
      id: 'D10-DEVATA-PROF',
      topic: '3. Supporting Dashamsha Devata / దేవత ఆధారం',
      result: '10వ అధిపతి $d10TenthLord యొక్క Devata: ${careerDevata.deity} (${careerDevata.direction}). ${careerDevata.sourceMeaning} ${devataExactMatches.isEmpty ? 'ఈ దేవత ఒక్కటితో exact profession నిర్ణయించము.' : 'ఈ జాతకంలో exact source gateతో కలిసి నిలిచినవి: ${devataExactMatches.join(' • ')}.'}',
      rule: 'Dashamsha Devata professionకు supporting layer మాత్రమే. Devata meaningను చూసి ఒక్కటే ఆధారంగా Astrologer/Consultant/Teacher వంటి exact profession ప్రకటించకూడదు. Main profession planet + D10 confirmation + source అదనపు conditionతో కలిసినప్పుడే exact listలోకి తీసుకోవాలి.',
      inspection: '10L natal longitude ${d10TenthLordNatal.longitude.toStringAsFixed(4)}° → ${careerDevata.deity}. Devata broad support: ${careerDevata.professionGroups.isEmpty ? 'narrow list లేదు' : careerDevata.professionGroups.join(', ')}.',
      source: 'D10 special.pdf — Dashamsha details/deities, pp.6–9; vrutti-graha-devata.pdf pp.1–6.',
      tone: careerDevata.professionGroups.isEmpty ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    for (final item in exactVisible.take(10)) {
      final icon = item.status == 'confirmed' ? '🟢' : item.status == 'supported' ? '✅' : '🟡';
      add(
        id: item.rule.id,
        topic: 'వృత్తి: ${item.rule.name}',
        result: '$icon ${item.rule.name} • ${item.rule.category} • Mode: $d10Mode.',
        rule: 'Main profession planet: ${item.rule.planet}. 10వ Devata: ${item.rule.devata}. Source అదనం: ${item.rule.extra}. Exact nameను main planet + 10th Devata gate తర్వాత మాత్రమే చూపాలి; జననం+D10 రెండూ confirm అయితే strong, ఒక్కటే అయితే half-support.',
        inspection: item.why,
        source: 'vrutti-graha-devata.pdf — page ${item.rule.sourcePage}, ${item.rule.id}.',
        tone: item.status == 'confirmed' || item.status == 'supported'
            ? VargaRuleTone.favorable
            : VargaRuleTone.neutral,
        applicable: true,
        remedy: 'ఈ profession rowకు sourceలో ప్రత్యేక పరిహారం ఇవ్వలేదు. Career decisionలో qualification, training, aptitude మరియు opportunityను కలిపి చూడాలి.',
      );
    }

    // Profession shortlist — source-backed layers only. The scoring weights are
    // the transparent app compatibility index already present in the supplied
    // Profession Rules file; they are not claimed as a classical percentage.
    final ranked = <({String name, int score, String why})>[];
    for (final item in _d10ProfessionCatalog) {
      final scored = professionScore(item.$2);
      var score = scored.score;
      final why = <String>[scored.why];
      if (item.$3.contains(d10TenthLordHouse)) {
        score += 8;
        why.add('10వ అధిపతి $d10TenthLord ${d10TenthLordHouse}వ భావంలో — profession-house match');
      }
      if (careerDevata.professionGroups.contains(item.$1)) {
        score += 12;
        why.add('10L Dashamsha Devata ${careerDevata.deity} profession match');
      }
      // Supplied vrutti-graha-devata source: Lagna Devata shows desire /
      // inclination, not the profession name. Do not add it to profession
      // ranking. It remains visible in the audit only.
      ranked.add((name: item.$1, score: score.clamp(0, 100).toInt(), why: why.join(' • ')));
    }
    ranked.sort((a, b) => b.score.compareTo(a.score));
    const broadDisplayExcluded = <String>{
      'Astrologer / Jyotisha Practitioner',
      'Astrology Consultant / Jyotisha Consultant',
      'Consultant / Advisor',
      'Priest / Spiritual Consultant',
      'Plumber / Electrician / Skilled Trades',
      'Skilled Service / Manual Work',
      'Daily-wage / Manual Worker',
      'Farm / Agricultural Worker',
      'Self-employment',
      'Service / Employment',
    };
    final topProf = ranked
        .where((x) => !broadDisplayExcluded.contains(x.name))
        .take(8)
        .toList(growable: false);
    final primaryProf = topProf.first;
    add(
      id: 'D10-PRIMARY-PROF',
      topic: 'Supporting Career Field / సహాయక వృత్తి రంగం',
      result: sourcePrimary != null
          ? 'Source exact primary: ${sourcePrimary.rule.name}. Broad profession direction: ${primaryProf.name} — ${primaryProf.score}% evidence-convergence. Strong alternatives: ${exactConfirmed.skip(1).take(3).map((x) => x.rule.name).join(' • ')}.'
          : 'Strict source exact name confirm కాలేదు. Broad profession direction: ${primaryProf.name} — ${primaryProf.score}% evidence-convergence. Strong alternatives: ${topProf.skip(1).take(3).map((x) => '${x.name} ${x.score}%').join(' • ')}.',
      rule: 'ఇది exact profession కాదు; D10 10L/10H/Lagna, D1/D9 link, house-signification మరియు Devata ఆధారంగా broad career-field support మాత్రమే. Exact professionకు పై source-name gateనే priority.',
      inspection: sourcePrimary != null ? sourcePrimary.why : primaryProf.why,
      source: 'vrutti-graha-devata.pdf pp.1–6 + D10 special.pdf — Basics, Houses, Tenth-lord houses and Dashamsha Deities.',
      tone: primaryProf.score >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఇది classical certainty కాదు; source evidence-convergence shortlist. Actual career choiceలో education, aptitude, opportunity, capital, experience మరియు current job marketను కలిపి నిర్ణయించాలి.',
    );

    add(
      id: 'D10-PROF-LIST',
      topic: 'Supporting Broad Career Fields / విస్తృత రంగాలు',
      result: topProf.map((x) => '${x.name} — ${x.score}%').join(' • '),
      rule: 'ఈ list exact profession పేర్లు కాదు. D10 10వ అధిపతి + 10వ భావం + D10 లగ్నం + D1→D10 link + D9 confirmation + 10L placement-house + Dashamsha Devata ఆధార broad fields మాత్రమే. Mode labels మరియు exact worker/consultant titlesను ఈ broad listలో కలపము.',
      inspection: 'D10 లగ్నం ${_d10SignNames[d10LagnaSign]}; 10వ రాశి ${_d10SignNames[d10TenthSign]}; 10వ అధిపతి $d10TenthLord ($d10TenthLordHouseవ భావం). 10L Devata ${careerDevata.deity} (${careerDevata.direction}); Lagna Devata ${lagnaDevata.deity} (కోరిక/ఆసక్తి మాత్రమే; profession scoreలో లేదు). Top evidence: ${topProf.take(3).map((x) => '${x.name}: ${x.why}').join(' | ')}.',
      source: 'D10 special.pdf — Basics/10th-lord houses pp.11–35 and Dashamsha Deities pp.6–9; supplied Profession Rules profession catalog.',
      tone: VargaRuleTone.favorable,
      applicable: true,
      remedy: 'వృత్తి ఎంపికకు ఇది source-backed suitability shortlist మాత్రమే. విద్య, నైపుణ్యం, ఆసక్తి, మార్కెట్ అవకాశాలు, అనుభవం వంటి practical factorsతో కలిపి నిర్ణయించాలి. Sourceలో వృత్తి కోసం ప్రత్యేక రత్న/హోమ పరిహారం ఇవ్వలేదు.',
    );

    final astrologerExact = exactProfessionRanked.firstWhere((x) => x.rule.id == 'D10-PRO-172');
    add(
      id: 'D10-PROF-ASTROLOGER',
      topic: 'Astrologer / Jyotisha Practitioner',
      result: astrologerExact.status == 'confirmed'
          ? '🟢 జ్యోతిషం — exact source rule Confirmed.'
          : astrologerExact.status == 'supported'
              ? '✅ జ్యోతిషం — source support ఉంది; ఒక manual/source-only clause ఇంకా audit కావాలి.'
              : astrologerExact.status == 'half'
                  ? '🟡 జ్యోతిషం — పాక్షిక support మాత్రమే; exact professionగా final చేయకూడదు.'
                  : '△ జ్యోతిషం exact source rule ఈ chartలో confirm కాలేదు.',
      rule: 'జ్యోతిషం exact row: Ketu + Ishana Devata + Jupiter + 8/9/12 source condition. Broad Jupiter/Ketu/Ishana similarity ఒక్కటే final verdict కాదు.',
      inspection: astrologerExact.why,
      source: 'vrutti-graha-devata.pdf p.6 — D10-PRO-172.',
      tone: astrologerExact.status == 'confirmed' || astrologerExact.status == 'supported'
          ? VargaRuleTone.favorable
          : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Sourceలో Astrologer profession కోసం ప్రత్యేక remedy ఇవ్వలేదు. Training, శాస్త్ర అధ్యయనం, consultation ethics మరియు practical skillను career decisionలో కలిపి చూడాలి.',
    );

    final consultantExact = exactProfessionRanked.firstWhere((x) => x.rule.id == 'D10-PRO-054');
    final vastuExact = exactProfessionRanked.firstWhere((x) => x.rule.id == 'D10-PRO-173');
    add(
      id: 'D10-PROF-CONSULTANT',
      topic: 'Consultant / Advisor',
      result: 'General Consultant: ${consultantExact.status == 'confirmed' ? '🟢 Confirmed' : consultantExact.status == 'supported' ? '✅ Supported' : consultantExact.status == 'half' ? '🟡 Half-support' : '△ Not confirmed'} • Vastu Consultant: ${vastuExact.status == 'confirmed' ? '🟢 Confirmed' : vastuExact.status == 'supported' ? '✅ Supported' : vastuExact.status == 'half' ? '🟡 Half-support' : '△ Not confirmed'}.',
      rule: 'General Consultant exact row = Mercury + Vayu + Jupiter conjunction/support as supplied. Vastu Consultant exact row = Jupiter + Kubera + Mars + 4th-house source condition. Ishana/Kubera broad meaning ఒక్కటే exact title ఇవ్వదు.',
      inspection: 'Consultant: ${consultantExact.why} | Vastu: ${vastuExact.why}.',
      source: 'vrutti-graha-devata.pdf pp.2 & 6 — D10-PRO-054, D10-PRO-173.',
      tone: consultantExact.status == 'confirmed' || vastuExact.status == 'confirmed'
          ? VargaRuleTone.favorable
          : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'Consultancy professionకు sourceలో ప్రత్యేక career remedy ఇవ్వలేదు. Subject expertise, communication skill, qualification మరియు practical experienceను పరిశీలించాలి.',
    );

    final sixthHouseNames = _houseNames(v, 6);
    final dailyWorkerExact = exactProfessionRanked.firstWhere((x) => x.rule.id == 'D10-PRO-178');
    const skilledIds = <String>{
      'D10-PRO-128', // mechanic
      'D10-PRO-129', // electrician
      'D10-PRO-130', // plumber
      'D10-PRO-131', // AC technician
      'D10-PRO-132', // mobile repair
      'D10-PRO-135', // carpenter
      'D10-PRO-136', // blacksmith
    };
    final exactSkilled = exactConfirmed
        .where((x) => skilledIds.contains(x.rule.id))
        .map((x) => x.rule.name)
        .take(6)
        .toList(growable: false);
    add(
      id: 'D10-PROF-WORKER',
      topic: 'Skilled Worker / Daily Worker / Manual Service',
      result: dailyWorkerExact.status == 'confirmed'
          ? '🟢 కూలీ / Daily-wage / Manual Worker — exact source rule Confirmed.${exactSkilled.isEmpty ? '' : ' Exact skilled matches: ${exactSkilled.join(' • ')}.'}'
          : 'Daily Worker exact rule ${dailyWorkerExact.status == 'half' ? 'పాక్షికంగా మాత్రమే సరిపడింది' : 'confirm కాలేదు'}.${exactSkilled.isEmpty ? ' Skilled trade exact match కూడా లేదు.' : ' Exact skilled matches: ${exactSkilled.join(' • ')}.'}',
      rule: 'Daily Workerను broad percentageతో confirm చేయకూడదు. Source exact row D10-PRO-178లో Saturn + Agni Devata + 6వ భావం; authority కాదు. ఈ పూర్తి gate match అయితేనే Confirmed. Mechanic/Electrician/Plumber వంటి skilled professions తమ తమ separate exact rowsతోనే చూపాలి.',
      inspection: 'Daily-worker row: ${dailyWorkerExact.why} • D10 6వ భావం: ${sixthHouseNames.isEmpty ? 'ఖాళీ' : sixthHouseNames.join(', ')}${exactSkilled.isEmpty ? '' : ' • Skilled exact: ${exactSkilled.join(', ')}'}.',
      source: 'vrutti-graha-devata.pdf pp.4 & 6 — exact skilled rows and D10-PRO-178.',
      tone: dailyWorkerExact.status == 'confirmed' || exactSkilled.isNotEmpty
          ? VargaRuleTone.favorable
          : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఇది work-type classification మాత్రమే. Skill training, safety, stable income, labour protections మరియు practical opportunitiesను ముందుగా చూడాలి.',
    );

    final service = professionScore(const ['Saturn', 'Moon', 'Mercury']);
    final commercial = professionScore(const ['Mercury', 'Venus', 'Rahu']);
    final selfEmployment = professionScore(const ['Sun', 'Mars', 'Rahu', 'Moon']);
    final businessScore = commercial.score > selfEmployment.score ? commercial.score : selfEmployment.score;
    final jobVsBusinessTone = (service.score - businessScore).abs() < 15 ? VargaRuleTone.neutral : VargaRuleTone.favorable;
    final jobVsBusinessResult = service.score >= businessScore + 15
        ? 'ఉద్యోగం / Service సూచనలు బలంగా ఉన్నాయి — Job ${service.score}% vs Business $businessScore%.'
        : businessScore >= service.score + 15
            ? 'వ్యాపారం / Self-employment సూచనలు బలంగా ఉన్నాయి — Business $businessScore% vs Job ${service.score}%.'
            : 'ఉద్యోగం మరియు వ్యాపారం రెండింటికీ support ఉంది — Job ${service.score}% vs Business $businessScore%. ఇతర timing evidence అవసరం.';
    add(
      id: 'D10-JOB-BUSINESS',
      topic: 'Job లేదా Business',
      result: jobVsBusinessResult,
      rule: 'Supplied D10 profession sourceలో service/self-employment నిర్ణయానికి Saturn condition across D1/D9/D10, Sun/Moon/10th-lord relation, PP-planet pattern మరియు 3rd-house/3rd-lord relation supporting checksగా ఉన్నాయి. App shortlistలో Service/Employment మరియు Commercial/Self-employment source profession groupsను పోల్చాం.',
      inspection: 'Service evidence: ${service.why}. Business evidence: ${(commercial.score >= selfEmployment.score) ? commercial.why : selfEmployment.why}.',
      source: 'D10.pdf pp.60–72 + supplied Profession Rules module; KP job-vs-business source is kept as separate confirmation layer.',
      tone: jobVsBusinessTone,
      applicable: true,
      remedy: 'Job/Business నిర్ణయం కోసం పరిహారం కంటే skill, capital, stability, experience, family/financial obligations వంటి practical factorsను ముందుగా చూడాలి. Source-specific spiritual remedy ఉంటేనే appలో విడిగా చూపాలి.',
    );

    add(
      id: 'D10-SEQUENCE',
      topic: 'ముందు Job → తరువాత Business / ముందు Business → తరువాత Job',
      result: saturnStream.result,
      rule: 'Source rule: Saturn Gocharastha అయితే self-employment; Agocharastha అయితే service. Birth chartలో Agocharastha ఉండి Navamsha/Dashamshaలో Gocharastha అయితే service నుంచి self-employmentకు మార్పు; reverse అయితే self-employment నుంచి serviceకు మార్పు. మూడు chartsలో అదే స్థితి repeat అయితే అదే stream కొనసాగుతుంది.',
      inspection: 'Birth Saturn ${saturnStream.birthState} • D9 ${saturnStream.navamsaState} • D10 ${saturnStream.dashamsaState}. ${saturnStream.reason}',
      source: 'D10 special.pdf — Chapter 04 Self Employed-Service, pp.50–51 (uploaded PDF pages 1–2).',
      tone: saturnStream.result.contains('Mixed') ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    final highPosition = professionScore(const ['Sun', 'Jupiter', 'Saturn']);
    add(
      id: 'D10-HIGH-POSITION',
      topic: 'High position in Job / Management',
      result: highPosition.score >= 60
          ? 'Management / high-position profession indicators బలంగా ఉన్నాయి — app compatibility ${highPosition.score}%.'
          : highPosition.score >= 30
              ? 'High-position indicators మధ్యస్థంగా ఉన్నాయి — ${highPosition.score}%; ఇతర status/timing rulesతో confirm చేయాలి.'
              : 'High-position source indicators ఈ operational checkలో బలంగా కనిపించలేదు — ${highPosition.score}%.',
      rule: 'Supplied profession listలో Management / High Positionకు Sun + Jupiter + Saturn మరియు 10వ భావ సంబంధం ప్రధాన indicatorsగా ఉన్నాయి.',
      inspection: highPosition.why,
      source: 'Annapurna_Astro_Vastu_V38_Profession_Rules.html — profession list; D10.pdf profession significations.',
      tone: highPosition.score >= 60 ? VargaRuleTone.favorable : highPosition.score >= 30 ? VargaRuleTone.neutral : VargaRuleTone.caution,
      applicable: true,
    );

    add(
      id: 'D10-GOCHARISTA',
      topic: 'గోచరిస్తా / Gocharastha',
      result: 'Birth: ${saturnStream.birthState} • D9: ${saturnStream.navamsaState} • D10: ${saturnStream.dashamsaState}. ${saturnStream.birthState == 'GOCHARASHTHA' || saturnStream.navamsaState == 'GOCHARASHTHA' || saturnStream.dashamsaState == 'GOCHARASHTHA' ? 'Gocharastha condition ఒకటి లేదా ఎక్కువ chartsలో ఉంది; independent/self-employment streamకు source support.' : 'Gocharastha condition ఈ operational evaluatorలో match కాలేదు.'}',
      rule: 'Gocharastha: Saturn exalted/own signలో ఉండి Trika (6/8/12) సంబంధం లేకపోవడం. Sourceలో exalted/own Saturn Trikaతో సంబంధం ఉంటే Government/administrative-level job అనే ప్రత్యేక note ఉంది.',
      inspection: saturnStream.reason,
      source: 'D10 special.pdf — Chapter 04, p.50 (uploaded PDF page 1).',
      tone: saturnStream.birthState == 'GOCHARASHTHA' || saturnStream.navamsaState == 'GOCHARASHTHA' || saturnStream.dashamsaState == 'GOCHARASHTHA' ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    add(
      id: 'D10-AGOCHARISTA',
      topic: 'Agocharastha',
      result: 'Birth: ${saturnStream.birthState} • D9: ${saturnStream.navamsaState} • D10: ${saturnStream.dashamsaState}. ${saturnStream.birthState == 'AGOCHARASHTHA' || saturnStream.navamsaState == 'AGOCHARASHTHA' || saturnStream.dashamsaState == 'AGOCHARASHTHA' ? 'Agocharastha condition ఒకటి లేదా ఎక్కువ chartsలో ఉంది; service/employment streamకు source support.' : 'Agocharastha condition ఈ operational evaluatorలో match కాలేదు.'}',
      rule: 'Agocharastha: Saturn debilitated, Rahu/Ketuతో కలయిక, combust/planetary-war defeat లేదా Trika సంబంధం. Current appలో dignity + Rahu/Ketu conjunction + 6/8/12 placement auto-check అవుతుంది; combustion/planetary-war data లేకపోతే వాటిని ఊహించదు.',
      inspection: saturnStream.reason,
      source: 'D10 special.pdf — Chapter 04, pp.50–51 (uploaded PDF pages 1–2).',
      tone: saturnStream.birthState == 'AGOCHARASHTHA' || saturnStream.navamsaState == 'AGOCHARASHTHA' || saturnStream.dashamsaState == 'AGOCHARASHTHA' ? VargaRuleTone.neutral : VargaRuleTone.info,
      applicable: true,
    );

    final saturnD1 = chart.planets.firstWhere((p) => p.name == 'Saturn');
    final saturnD9 = d9.planets.firstWhere((p) => p.name == 'Saturn');
    final saturnD10 = v.planets.firstWhere((p) => p.name == 'Saturn');
    final sunD10 = v.planets.firstWhere((p) => p.name == 'Sun');
    final moonD10 = v.planets.firstWhere((p) => p.name == 'Moon');
    final sameWith = <String>[];
    if (saturnD10.signIndex == sunD10.signIndex) sameWith.add('Sun');
    if (saturnD10.signIndex == moonD10.signIndex) sameWith.add('Moon');
    if (saturnD10.signIndex == d10TenthLordPlacement.signIndex && d10TenthLord != 'Saturn') sameWith.add('10L $d10TenthLord');
    add(
      id: 'D10-SATURN-REL',
      topic: 'Relation of Saturn',
      result: 'Saturn: D1 ${((saturnD1.signIndex - chart.ascendantSignIndex + 12) % 12) + 1}వ భావం • D9 ${_houseOf(d9, saturnD9)}వ భావం • D10 ${_houseOf(v, saturnD10)}వ భావం. D10 same-sign relation: ${sameWith.isEmpty ? 'Sun/Moon/10Lతో conjunction లేదు' : sameWith.join(', ')}.',
      rule: 'Supplied D10 source self-employment/service assessmentలో Saturn condition across D1, Navamsha, Dashamsha మరియు Sun/Moon/10th-lord relationను supporting checkగా ఉపయోగిస్తుంది. Exact aspect scheme source-defined అయినందున ఇక్కడ same-sign association మాత్రమే auto-check చేశాం.',
      inspection: 'D10 Saturn ${_d10SignNames[saturnD10.signIndex]} • House ${_houseOf(v, saturnD10)}; Sun House ${_houseOf(v, sunD10)}; Moon House ${_houseOf(v, moonD10)}; 10L $d10TenthLord House $d10TenthLordHouse.',
      source: 'D10.pdf pp.60–72 — self-employment/service supporting checks.',
      tone: VargaRuleTone.neutral,
      applicable: true,
    );

    final ppPlanets = const ['Sun', 'Moon', 'Mars', 'Rahu'];
    final d1FirstLord = _signLord(chart.ascendantSignIndex);
    final ppInfluencersD1 = <String>[];
    final ppInfluencersD10 = <String>[];
    for (final name in ppPlanets) {
      final h1 = ((chart.planets.firstWhere((x) => x.name == name).signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
      if (h1 == 1 || h1 == 10 ||
          D10CareerService.relatedD1(chart, name, d1FirstLord) ||
          D10CareerService.relatedD1(chart, name, d1TenthLord)) {
        ppInfluencersD1.add(name);
      }
      final h10 = _houseOf(v, v.planets.firstWhere((x) => x.name == name));
      if (h10 == 1 || h10 == 10 ||
          D10CareerService.relatedVarga(v, name, d10FirstLord) ||
          D10CareerService.relatedVarga(v, name, d10TenthLord)) {
        ppInfluencersD10.add(name);
      }
    }
    add(
      id: 'D10-PP',
      topic: 'PP Planets / Poorna Paramatma Planets',
      result: ppInfluencersD1.length >= 2
          ? 'Birth chartలో PP planets ${ppInfluencersD1.join(', ')} Lagna/10H/1L/10Lను ప్రభావితం చేస్తున్నాయి; independent professionకు source rule match. D10 confirmation: ${ppInfluencersD10.isEmpty ? 'none' : ppInfluencersD10.join(', ')}.'
          : 'Birth PP ruleకు కనీసం 2 influences కావాలి; match: ${ppInfluencersD1.isEmpty ? 'none' : ppInfluencersD1.join(', ')}. D10 confirmation: ${ppInfluencersD10.isEmpty ? 'none' : ppInfluencersD10.join(', ')}.',
      rule: 'PP planets = Sun, Moon, Mars, Rahu. Birth horoscopeలో వీటిలో కనీసం రెండు Lagna/10th house లేదా Lagna lord/10th lordను influence చేయాలి. Lagna influence = independent nature; 10th influence = independent profession.',
      inspection: 'Birth PP matches: ${ppInfluencersD1.isEmpty ? 'none' : ppInfluencersD1.join(', ')} • D10 matches: ${ppInfluencersD10.isEmpty ? 'none' : ppInfluencersD10.join(', ')}.',
      source: 'D10 special.pdf — Chapter 04 Self Employed-Service, p.51 (uploaded PDF page 2).',
      tone: ppInfluencersD1.length >= 2 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    final sector7to12 = <String>[];
    final sector10to3 = <String>[];
    for (final p in chart.planets) {
      final h = ((p.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
      if (h >= 7 && h <= 12) sector7to12.add(p.name);
      if (h >= 10 || h <= 3) sector10to3.add(p.name);
    }
    int ppCount(List<String> names) => names.where(ppPlanets.contains).length;
    final sectorAOk = sector7to12.length >= 5 && ppCount(sector7to12) >= 2;
    final sectorBOk = sector10to3.length >= 5 && ppCount(sector10to3) >= 2;
    add(
      id: 'D10-FIVE-PLANETS',
      topic: 'Five Planets Rule',
      result: sectorAOk || sectorBOk
          ? 'Birth chart Five-planets independence rule match: ${sectorAOk ? '7–12 sector ${sector7to12.join(', ')}' : ''}${sectorAOk && sectorBOk ? ' • ' : ''}${sectorBOk ? '10–3 sector ${sector10to3.join(', ')}' : ''}.'
          : 'Five-planets rule పూర్తి match కాలేదు. 7–12: ${sector7to12.length} planets / ${ppCount(sector7to12)} PP; 10–3: ${sector10to3.length} planets / ${ppCount(sector10to3)} PP.',
      rule: 'Source rule: horoscopeలో 7th–12th sector లేదా 10th–3rd wrapping sectorలో కనీసం 5 planets ఉండాలి; వాటిలో కనీసం 2 PP planets ఉండాలి. ఇది independent professionకు support.',
      inspection: 'Birth 7–12: ${sector7to12.join(', ')} • Birth 10–3: ${sector10to3.join(', ')}.',
      source: 'D10 special.pdf — Chapter 04 Self Employed-Service, p.52 (uploaded PDF page 3).',
      tone: sectorAOk || sectorBOk ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    final thirdLordPlacement = v.planets.firstWhere((p) => p.name == d10ThirdLord);
    final thirdLordHouse = _houseOf(v, thirdLordPlacement);
    add(
      id: 'D10-THIRD-HOUSE',
      topic: 'Third House / Lord',
      result: 'D10 3వ భావం: ${thirdNames.isEmpty ? 'ఖాళీ' : thirdNames.join(', ')}. 3వ అధిపతి $d10ThirdLord $thirdLordHouseవ భావంలో. Source ప్రకారం 3వ భావం ధైర్యం, side-work, self-effort, transfer మరియు self-employment/service distinctionకు supporting layer.',
      rule: 'D10 profession sourceలో 3rd house / 3rd lord relationను self-employment/service supporting checkగా ఉపయోగించాలి; 3వ భావంలో 3+ malefics ఉంటే special argala ruleను విడిగా చూడాలి.',
      inspection: '3H occupants: ${thirdNames.isEmpty ? 'none' : thirdNames.join(', ')} • 3L $d10ThirdLord → H$thirdLordHouse.',
      source: 'D10.pdf pp.46–47, 60–72 + D10 Rule 6.2.',
      tone: VargaRuleTone.neutral,
      applicable: true,
    );

    final statusTone = d10TenthLordHouse == 8 || d10TenthLordHouse == 12
        ? VargaRuleTone.caution
        : const [1, 4, 5, 7, 9, 10, 11, 2].contains(d10TenthLordHouse)
            ? VargaRuleTone.favorable
            : VargaRuleTone.neutral;
    add(
      id: 'D10-STATUS',
      topic: 'Status / Position',
      result: 'D10 10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ భావంలో; 10వ భావంలో ${tenthNames.isEmpty ? 'గ్రహాలు లేవు' : tenthNames.join(', ')}. ${tenthBenefics.isNotEmpty ? 'Benefic support: ${tenthBenefics.join(', ')}.' : ''} ${tenthMalefics.isNotEmpty ? 'Malefic pressure: ${tenthMalefics.join(', ')}.' : ''}',
      rule: 'D10 10వ భావం profession/status/earning direction; 10వ అధిపతి placement మరియు associationsతో statusను refine చేయాలి.',
      inspection: '10H sign ${_d10SignNames[d10TenthSign]} • 10L $d10TenthLord H$d10TenthLordHouse.',
      source: 'D10.pdf pp.14–16; supplied Profession Rules.',
      tone: statusTone,
      applicable: true,
    );

    final tenthLordHouseMeaning = switch (d10TenthLordHouse) {
      1 => 'Self-driven profession; leadership/independent work, name and fame when supported.',
      2 => 'Food/family business/finance and speech-based work; family linkage can be strong.',
      3 => 'Communication, writing, short travel, transport/agency, publishing/contract work; job changes can repeat.',
      4 => 'Own-land/home-linked work, authority, leadership; politics can arise with supporting Saturn relation.',
      5 => 'Learning/intelligence/creative-professional growth; sudden developments can change career direction.',
      6 => 'Service/servitude; judiciary, hospitals, prisons or competitive service environments; tenure can be shorter under affliction.',
      7 => 'Business/partnership/corporate/public dealings and foreigners; strong 7th can give impressive public image/high position.',
      8 => 'Career challenges and sudden changes; strong Lagna may still give high position after obstacles.',
      9 => 'Authority/government, rajayoga-type status, frequent change/travel or foreign influence; strong success after discipline.',
      10 => 'Distinction, honour, fame and strong professional identity; afflicted state can still make the rise swift but unstable.',
      11 => 'Gains, recognition, network/friends and employment with comparatively easier returns; affliction can delay success.',
      12 => 'Foreign/institutional/isolated work, hospitals/jails/retreat settings or repeated profession change; affliction can reduce stability.',
      _ => 'Source house meaning unavailable.',
    };
    add(
      id: 'D10-10L-HOUSE',
      topic: '10th Lord in House — Profession Nature',
      result: 'D10 10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ భావంలో. $tenthLordHouseMeaning',
      rule: 'Source gives separate professional interpretation for the Dashamsha 10th lord placed in each of the 12 houses. This is a profession-nature layer, not a standalone exact occupation verdict.',
      inspection: '10H sign ${_d10SignNames[d10TenthSign]} • 10L $d10TenthLord → H$d10TenthLordHouse.',
      source: 'D10 special.pdf — Tenth lord in houses / house examples, pp.18–35 (uploaded PDF pages 66–82).',
      tone: const [1, 4, 5, 7, 9, 10, 11, 2].contains(d10TenthLordHouse) ? VargaRuleTone.favorable : const [6, 8, 12].contains(d10TenthLordHouse) ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    bool exchangeD1(int aHouse, int bHouse) {
      final aSign = (chart.ascendantSignIndex + aHouse - 1) % 12;
      final bSign = (chart.ascendantSignIndex + bHouse - 1) % 12;
      final aLord = _signLord(aSign);
      final bLord = _signLord(bSign);
      final pa = chart.planets.firstWhere((p) => p.name == aLord);
      final pb = chart.planets.firstWhere((p) => p.name == bLord);
      return pa.signIndex == bSign && pb.signIndex == aSign;
    }
    bool exchangeD10(int aHouse, int bHouse) {
      final aSign = _houseSign(v, aHouse);
      final bSign = _houseSign(v, bHouse);
      final aLord = _signLord(aSign);
      final bLord = _signLord(bSign);
      final pa = v.planets.firstWhere((p) => p.name == aLord);
      final pb = v.planets.firstWhere((p) => p.name == bLord);
      return pa.signIndex == bSign && pb.signIndex == aSign;
    }
    final kendra = const [1, 4, 7, 10];
    final trikona = const [1, 5, 9];
    final d1YogaPairs = <String>[];
    final d10YogaPairs = <String>[];
    for (final kh in kendra) {
      for (final th in trikona) {
        if (kh == th) continue;
        final kl1 = _signLord((chart.ascendantSignIndex + kh - 1) % 12);
        final tl1 = _signLord((chart.ascendantSignIndex + th - 1) % 12);
        if (D10CareerService.relatedD1(chart, kl1, tl1) || exchangeD1(kh, th)) {
          d1YogaPairs.add('${kh}L $kl1 ↔ ${th}L $tl1');
        }
        final kl10 = _signLord(_houseSign(v, kh));
        final tl10 = _signLord(_houseSign(v, th));
        if (D10CareerService.relatedVarga(v, kl10, tl10) || exchangeD10(kh, th)) {
          d10YogaPairs.add('${kh}L $kl10 ↔ ${th}L $tl10');
        }
      }
    }
    final rajYogaRepeat = d1YogaPairs.isNotEmpty && d10YogaPairs.isNotEmpty;
    add(
      id: 'D10-RAJAYOGA',
      topic: 'రాజయోగం / Status Yoga',
      result: rajYogaRepeat
          ? 'Birth chart మరియు Dashamsha రెండింటిలో Kendra–Trikona lord relation కనిపిస్తోంది; status/riseకు repeated Rajayoga support.'
          : d1YogaPairs.isNotEmpty || d10YogaPairs.isNotEmpty
              ? 'Kendra–Trikona relation ఒక chartలో ఉంది కానీ Birth+D10 repetition పూర్తి కాలేదు; status support మిశ్రమం.'
              : 'Current conjunction/aspect/exchange evaluatorలో Kendra–Trikona lord relation match కాలేదు.',
      rule: 'Source Rajayoga: Kendra lord–Trikona lord relation conjunction, mutual aspect, sign exchange, nakshatra exchange లేదా reciprocal Kendra/Trikona influence ద్వారా రావచ్చు. Birth yoga D10లో repeat అయితే status potential బలపడుతుంది. Current auto-evaluator conjunction/classical aspect/sign exchangeను మాత్రమే check చేస్తుంది; nakshatra exchange separate source inputగా మిగిలింది.',
      inspection: 'D1 pairs: ${d1YogaPairs.isEmpty ? 'none' : d1YogaPairs.join(' • ')}. D10 pairs: ${d10YogaPairs.isEmpty ? 'none' : d10YogaPairs.join(' • ')}.',
      source: 'D10 special.pdf — Chapter 05 Status, pp.93–96 (uploaded PDF pages 6–9).',
      tone: rajYogaRepeat ? VargaRuleTone.favorable : (d1YogaPairs.isNotEmpty || d10YogaPairs.isNotEmpty ? VargaRuleTone.neutral : VargaRuleTone.info),
      applicable: true,
    );

    final sunSign = chart.planets.firstWhere((p) => p.name == 'Sun').signIndex;
    final moonSign = chart.planets.firstWhere((p) => p.name == 'Moon').signIndex;
    final allOddSigns = chart.ascendantSignIndex.isEven && sunSign.isEven && moonSign.isEven;
    final allEvenSigns = chart.ascendantSignIndex.isOdd && sunSign.isOdd && moonSign.isOdd;
    add(
      id: 'D10-MAHABHAGYA',
      topic: 'Mahabhagya Yoga',
      result: 'Source sign-condition check: Lagna/Sun/Moon ${allOddSigns ? 'మూడూ odd signsలో ఉన్నాయి' : allEvenSigns ? 'మూడూ even signsలో ఉన్నాయి' : 'ఒకే parityలో లేవు'}. Final Mahabhagya verdictకు male/female + day/night condition కూడా అవసరం; ఈ app birth formలో sex/day-night astronomical flag లేకపోవడంతో final YES/NOను ఊహించదు.',
      rule: 'Source: male nativityకి day birth + Lagna/Moon/Sun odd signs; female nativityకి night birth + Lagna/Moon/Sun even signs. ఇవన్నీ together కావాలి.',
      inspection: 'Lagna sign ${chart.ascendantSignIndex + 1} • Sun ${sunSign + 1} • Moon ${moonSign + 1}.',
      source: 'D10 special.pdf — Chapter 05 Status, p.93 (uploaded PDF page 6).',
      tone: allOddSigns || allEvenSigns ? VargaRuleTone.neutral : VargaRuleTone.info,
      applicable: true,
      auto: false,
    );

    final rise = const [1, 4, 5, 7, 9, 10, 2, 11].contains(d10TenthLordHouse);
    final fall = const [6, 8, 12].contains(d10TenthLordHouse);
    add(
      id: 'D10-RISE-FALL',
      topic: 'Rise / Fall',
      result: rise
          ? '10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ భావంలో ఉండటం source placement table ప్రకారం rise/support వైపు బలం చూపిస్తోంది.'
          : fall
              ? '10వ అధిపతి $d10TenthLord $d10TenthLordHouseవ దుస్థానంలో; career obstacles/fall-risk layerగా జాగ్రత్తగా చూడాలి.'
              : '10వ అధిపతి placement mixed/effort-oriented. ఇతర D10 supportతో కలిపి నిర్ణయించాలి.',
      rule: 'Supplied Goel implementation: 10వ అధిపతి Kendra=సుఖం, Trikona=శ్రీ, 2/11=ధనం, 3=శ్రమ, 6/8/12=ఆటంకం.',
      inspection: 'D10 10L $d10TenthLord → House $d10TenthLordHouse.',
      source: 'annapurna-jataka-16.html — V.P. Goel D10 implementation.',
      tone: rise ? VargaRuleTone.favorable : fall ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    if (birthDateTime != null) {
      add(
        id: 'D10-CAREER-START',
        topic: 'Career Start / First Earning',
        result: D10CareerService.summarizeWindows(careerWindows, 'career_start', max: 4),
        rule: 'First earning timing: Birth chartలో MD/AD 10th, 2nd లేదా 11th house/lordsతో సంబంధం; D10లో Dasha lord Lagna, 10th, 2nd లేదా 11th house/lordsతో సంబంధం. Promise లేకపోతే timingను force చేయరాదు.',
        inspection: 'Vimshottari MD/AD source windows; ప్రతి windowలో D1 2/10/11 + D10 1/2/10/11 evidence combine అవుతుంది.',
        source: 'D10 special.pdf — Chapter 10 Career Graph, pp.174–183 (uploaded PDF pages 22–30).',
        tone: careerWindows.any((w) => w.eventKey == 'career_start') ? VargaRuleTone.favorable : VargaRuleTone.info,
        applicable: true,
      );
      add(
        id: 'D10-RISE-TIMING',
        topic: 'Career Rise / Fame — Date Duration',
        result: D10CareerService.summarizeWindows(careerWindows, 'rise', max: 5),
        rule: 'Rise timing: Vimshottari MDను Birth Kendra, Navamsha, Shodashamsha, Dashamshaలో repeatగా పరీక్షించి D10లో Kendra/11th support చూడాలి; ADతో అదే logicను repeat చేయాలి. Source Progress Yogini మరియు Chara Dasha కూడా confirmation methodsగా ఇస్తుంది; ఈ cardలో ప్రస్తుతం Vimshottari windowను primaryగా చూపుతుంది.',
        inspection: 'D1 Kendra + D9/D16 + D10 Kendra/11 period convergence ఆధారంగా windows రూపొందించబడ్డాయి.',
        source: 'D10 special.pdf — Chapter 06 Rise, pp.99–101 (uploaded PDF pages 12–14).',
        tone: careerWindows.any((w) => w.eventKey == 'rise') ? VargaRuleTone.favorable : VargaRuleTone.info,
        applicable: true,
      );
    }

    final keyLords = <String>{d10FirstLord, d10ThirdLord, d10SeventhLord, d10TenthLord, d10EleventhLord}.toList();
    final inter = <String>[];
    for (var i = 0; i < keyLords.length; i++) {
      for (var j = i + 1; j < keyLords.length; j++) {
        final a = v.planets.firstWhere((p) => p.name == keyLords[i]);
        final b = v.planets.firstWhere((p) => p.name == keyLords[j]);
        if (a.signIndex == b.signIndex) inter.add('${keyLords[i]} + ${keyLords[j]}');
      }
    }
    add(
      id: 'D10-INTERRELATION',
      topic: 'Inter-relation',
      result: inter.isEmpty ? 'D10 1L/3L/7L/10L/11L మధ్య same-sign conjunction ఈ simple auto-checkలో లేదు.' : 'Career key lords same-sign inter-relations: ${inter.join(' • ')}.',
      rule: 'D10 profession assessmentలో relevant lords/planets relationshipsను చూడాలి. Source-specific aspect scheme పూర్తిగా implement చేయకుండా ఇక్కడ conjunction/same-sign relation మాత్రమే auto-check అవుతుంది.',
      inspection: '1L $d10FirstLord • 3L $d10ThirdLord • 7L $d10SeventhLord • 10L $d10TenthLord • 11L $d10EleventhLord.',
      source: 'D10 source rule: relevant planets/relationships; exact aspect scheme remains source-bound.',
      tone: inter.isEmpty ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: true,
    );

    final partnership = professionScore(const ['Mercury', 'Venus', 'Rahu']);
    add(
      id: 'D10-PARTNERSHIP',
      topic: 'Partnership / Business Partnership',
      result: partnership.score >= 60
          ? 'Partnership/business indicators బలంగా ఉన్నాయి — ${partnership.score}%. 7వ భావం: ${seventhNames.isEmpty ? 'ఖాళీ' : seventhNames.join(', ')}.'
          : 'Partnership/business support ${partnership.score}%. 7వ భావం మరియు 3/11 సంబంధాలను ఇతర evidenceతో confirm చేయాలి.',
      rule: 'D10 house-profession sourceలో 7వ భావం business/partnership; Commercial/Business groupకు Mercury, Venus, Rahu మరియు 3/7/11 houses ప్రధాన source indicators.',
      inspection: '${partnership.why} • 7L $d10SeventhLord H${_houseOf(v, v.planets.firstWhere((p) => p.name == d10SeventhLord))}.',
      source: 'D10.pdf pp.46–47 + supplied Profession Rules profession list.',
      tone: partnership.score >= 60 ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    final graph = D10CareerService.graphWindows(careerWindows, max: 14);
    add(
      id: 'D10-CAREER-GRAPH',
      topic: 'Career Graph — Year / Date Duration',
      result: birthDateTime == null
          ? 'Birth date/time input లేకుండా period graph లెక్కించలేదు.'
          : graph.isEmpty
              ? 'Source thresholdsకు సరిపోయే major career milestone windows ఈ calculated rangeలో కనిపించలేదు.'
              : graph.map((w) {
                  final mark = w.tone == D10CareerTone.favorable ? '🟢' : w.tone == D10CareerTone.caution ? '🔴' : '🟡';
                  return '$mark ${D10CareerService.formatDate(w.start)} → ${D10CareerService.formatDate(w.end)} • ${w.title} • ${w.mahadasha}/${w.antardasha}';
                }).join('\n'),
      rule: 'Career Graph = D10 promise + source-defined Dasha timing. 10th house is the main professional milestone axis. App graph labels only source-supported windows: Career Start, Rise/Promotion, Foreign/Transfer, Downfall/Job-loss caution and Retirement.',
      inspection: birthDateTime == null ? 'Timing input missing.' : '${graph.length} milestone windows displayed from Vimshottari MD/AD source checks.',
      source: 'D10 special.pdf — Chapter 10 Career Graph, pp.173–205 (uploaded PDF pages 22–53).',
      tone: graph.any((w) => w.tone == D10CareerTone.caution) ? VargaRuleTone.neutral : VargaRuleTone.favorable,
      applicable: birthDateTime != null,
      auto: birthDateTime != null,
    );

    final rahuHouse = _houseOf(v, v.planets.firstWhere((p) => p.name == 'Rahu'));
    final foreignPromise = D10CareerService.foreignPromise(chart);
    add(
      id: 'D10-FOREIGN-JOB',
      topic: 'Job in Foreign Land',
      result: '${foreignPromise ? '🟢 Birth + D10 foreign-job promise match.' : '△ Full Birth + D10 promise ఈ evaluatorలో match కాలేదు.'}\n${birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'foreign', max: 5)}',
      rule: 'Foreign-job promise: Birth 8L influence Lagna/10H, 10H/10L relation to 9/12, 3H change; same combinations D10లో repeat; D10 8L relation to 10H/10L. Timing Dasha 10/12/9 houses/lordsతో సంబంధం కలిగి ఉండాలి.',
      inspection: '10L H$d10TenthLordHouse • Rahu H$rahuHouse • D10 12H: ${twelfthNames.isEmpty ? 'empty' : twelfthNames.join(', ')} • Promise=${foreignPromise ? 'YES' : 'NO'}.',
      source: 'D10 special.pdf — Job in foreign land, pp.183–188 (uploaded PDF pages 30–35).',
      tone: foreignPromise ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: true,
    );

    add(
      id: 'D10-PROMOTION',
      topic: 'Promotion / Higher Position / Salary Rise',
      result: birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'promotion', max: 5),
      rule: 'Promotion: professional lifeలో higher post లేదా higher salary. Birth chartలో 10th/11th and 2nd houses; Dashamshaలో Lagna కూడా important. Dasha 10th, 2nd and 11th houses/lordsను activate చేయాలి.',
      inspection: 'D10 status: 10L $d10TenthLord H$d10TenthLordHouse; 10H ${tenthNames.isEmpty ? 'empty' : tenthNames.join(', ')}. Vimshottari windows D1 2/10/11 + D10 1/2/10/11 convergenceతో ఎంపిక.',
      source: 'D10 special.pdf — Promotion, pp.188–193 (uploaded PDF pages 35–40).',
      tone: careerWindows.any((w) => w.eventKey == 'promotion') ? VargaRuleTone.favorable : VargaRuleTone.info,
      applicable: true,
    );

    final jobLossPromise = D10CareerService.lossPromise(chart);
    add(
      id: 'D10-JOB-LOSS',
      topic: 'Downfall / Loss in Job',
      result: '${jobLossPromise ? '🔴 Job-loss/downfall promise layer ఉంది.' : '△ Full loss-promise layer బలంగా match కాలేదు.'}\n${birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'job_loss', max: 5)}',
      rule: 'Loss of Job: 10th houseను 3rd/9th/12th lords influence చేయడం loss promise. D10లో 3/9/12 activationను చూడాలి. MD favorableగా ఉండి AD adverse అయితే break shorter; MD itself job-support ఇవ్వకపోతే loss longer కావచ్చు.',
      inspection: '8H ${eighthNames.isEmpty ? 'empty' : eighthNames.join(', ')} • 10H ${tenthNames.isEmpty ? 'empty' : tenthNames.join(', ')} • 12H ${twelfthNames.isEmpty ? 'empty' : twelfthNames.join(', ')} • Promise=${jobLossPromise ? 'YES' : 'NO'}.',
      source: 'D10 special.pdf — Loss of Job, pp.193–197 (uploaded PDF pages 40–44).',
      tone: jobLossPromise ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
      remedy: 'ఈ sourceలో నిర్దిష్ట spiritual remedy ఇవ్వలేదు. Caution windowను certaintyగా కాకుండా risk-planning signalగా మాత్రమే చూడాలి; skill-upgrade, financial buffer, documentation, communication వంటి practical safeguards ఉపయోగించండి.',
    );

    if (birthDateTime != null) {
      add(
        id: 'D10-CAREER-CHANGE',
        topic: 'Career Change / Job ↔ Business Switch',
        result: D10CareerService.summarizeWindows(careerWindows, 'career_change', max: 6),
        rule: 'Career-change decision-support: source house meanings ప్రకారం 3H change/effort, 7H business/partnership, 10H profession, 11H gains మరియు 12H loss/change of profession period activationను కలిసి చూడాలి. ఇది standalone classical yoga కాదు; source-described houses convergence మాత్రమే.',
        inspection: 'Vimshottari MD/ADలో D1 + D10 3/7/10/11/12 activation score thresholdతో candidate windows చూపబడతాయి. ఇవి actual-history calibrationకు ఉపయోగపడతాయి కానీ history చూసి threshold auto-change కాదు.',
        source: 'D10 special.pdf — Houses in Dashamsha + Career Graph / Transfer / Loss of Job chapters.',
        tone: careerWindows.any((w) => w.eventKey == 'career_change') ? VargaRuleTone.neutral : VargaRuleTone.info,
        applicable: true,
      );
    }

    final transferSupport = d10TenthLordHouse == 3 || thirdLordHouse == 10 || thirdNames.isNotEmpty;
    add(
      id: 'D10-TRANSFER',
      topic: 'Transfer / Job Location Change',
      result: '${transferSupport ? '3H/3L career-change support ఉంది.' : 'Static transfer support weak/mixed.'}\n${birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'transfer', max: 5)}',
      rule: 'Transfer = change of place for job. Source gives 3rd and 9th houses for change; rise in position/salary houses should also be involved. Dashamsha 12th house shows change of profession. Timing uses the corresponding Dasha lords.',
      inspection: '3H ${thirdNames.isEmpty ? 'empty' : thirdNames.join(', ')} • 3L $d10ThirdLord H$thirdLordHouse • 10L H$d10TenthLordHouse.',
      source: 'D10 special.pdf — Transfer, pp.197–200 (uploaded PDF pages 44–47).',
      tone: transferSupport ? VargaRuleTone.neutral : VargaRuleTone.info,
      applicable: true,
    );

    add(
      id: 'D10-RETIREMENT',
      topic: 'Retirement — Normal / Voluntary / Forced',
      result: birthDateTime == null ? 'Timing input లేదు.' : D10CareerService.summarizeWindows(careerWindows, 'retirement', max: 5),
      rule: 'Retirement/end of career may be normal, voluntary or forced. Source activates 3rd, 9th and 12th houses through Dasha; unlike transfer, the lords/planets connected to those houses are important. 5th lord can give forced retirement. App shows late-career candidate windows, not a guaranteed legal retirement date.',
      inspection: 'Retirement window engine uses D1+D10 3/9/12 activation; 5L involvement labels forced/early-retirement caution. Display filter begins at age 48 only as an app safeguard, not as a classical age formula.',
      source: 'D10 special.pdf — Retirement, pp.200–205 (uploaded PDF pages 47–53).',
      tone: careerWindows.any((w) => w.eventKey == 'retirement' && w.tone == D10CareerTone.caution) ? VargaRuleTone.caution : VargaRuleTone.neutral,
      applicable: true,
    );

    add(
      id: 'D10-NAKSHATRA-PROF',
      topic: 'నక్షత్ర వృత్తులు',
      result: 'Profession shortlistలో నక్షత్ర వృత్తుల layerను కలపడానికి exact nakshatra→profession source table current filesలో లేదు. Table వచ్చిన వెంటనే top profession scoreలో separate evidenceగా కలపవచ్చు.',
      rule: 'Nakshatra profession mapping source table లేకుండా general astrology mappingను appలో substitute చేయకూడదు.',
      inspection: 'Current shortlist uses D10 10L/10H/Lagna + D1/D9 + sign classification only.',
      source: 'Requested profession layer — source table pending.',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );


  }

  static void _d12(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D12-01',
      cautionId: 'S7-D12-02',
      topic: 'పూర్వీక ఆశీర్వాదం / కుటుంబ రక్షణ',
      favorableResult: 'D12 లగ్నంలో శుభగ్రహ support ఉంది; పూర్వీక/తల్లిదండ్రుల సహకారానికి అనుకూల layer.',
      cautionResult: 'D12 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; కుటుంబ/పూర్వీక అంశంలో కఠిన అనుభవ layer.',
      rule: 'D12లో కారకాంశ లగ్నం/లగ్నాధిపతి బలం మరియు శుభ/క్రూర సంబంధాన్ని పూర్వీక ఆశీర్వాదానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D12, supplied “Sarala 7 final.pdf” p.9',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 4,
      favorableId: 'S7-D12-03',
      cautionId: 'S7-D12-04',
      topic: 'తల్లి / సుఖం',
      favorableResult: 'D12 4వ భావంలో శుభగ్రహ support ఉంది; తల్లి/గృహ సౌఖ్యానికి అనుకూల layer.',
      cautionResult: 'D12 4వ భావంలో పాపగ్రహ ప్రభావం ఉంది; తల్లి/గృహసుఖ అంశంలో జాగ్రత్త layer.',
      rule: 'D12లో 4వ భావ పీడను తల్లి/కుటుంబ సుఖానికి పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D12, supplied “Sarala 7 final.pdf” p.9',
      add: add,
    );
  }

  static void _d16(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D16-01',
      cautionId: 'S7-D16-02',
      topic: 'సుఖభోగం / వాహనం',
      favorableResult: 'D16 లగ్నంలో శుభగ్రహ support ఉంది; సుఖం/వాహన యోగానికి అనుకూల layer.',
      cautionResult: 'D16 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; సుఖం/వాహన అంశంలో జాగ్రత్త layer.',
      rule: 'D16లో లగ్నం, లగ్నాధిపతి, 4వ భావం, పుత్రకారక/సంబంధిత గ్రహాలను సుఖ–వాహన ఫలానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D16, supplied “Sarala 7 final.pdf” p.11',
      add: add,
    );
    final h468 = [4, 6, 8].expand((h) => _houseNames(v, h)).where(_malefics.contains).toList();
    add(
      id: 'S7-D16-03',
      topic: 'వాహన జాగ్రత్త',
      result: h468.length >= 2 ? 'D16 4/6/8 సంబంధిత ప్రాంతాల్లో బహుళ పాపగ్రహ ప్రభావం ఉంది; వాహన/ప్రయాణంలో జాగ్రత్త layer.' : 'D16 accident-caution simple condition match కాలేదు.',
      rule: '4, 6, 8 సంబంధం మరియు పాప ప్రభావాన్ని వాహన ప్రమాద/దొంగతనం అంశంలో source పరిశీలిస్తుంది.',
      inspection: 'D16 4/6/8లో పాపగ్రహ count: ${h468.length} (${h468.isEmpty ? 'లేవు' : h468.join(', ')}).',
      source: 'Sarala Jyotisham Part VII — D16, supplied “Sarala 7 final.pdf” pp.11–12',
      tone: VargaRuleTone.caution,
      applicable: h468.length >= 2,
    );
  }

  static void _d20(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 5,
      favorableId: 'S7-D20-01',
      cautionId: 'S7-D20-02',
      topic: 'బుద్ధి / ఆధ్యాత్మిక సాధన',
      favorableResult: 'D20 5వ భావంలో శుభగ్రహ support ఉంది; ఆధ్యాత్మిక బుద్ధి/సాధనకు అనుకూల layer.',
      cautionResult: 'D20 5వ భావంలో పాపగ్రహ ప్రభావం ఉంది; సాధనలో దృష్టి చెదరే/అడ్డంకి layer.',
      rule: 'D20లో 5వ భావం స్వభావ/బుద్ధి సూచకంగా; పుత్రకారక యోగం/జ్ఞాతికారక సంబంధాన్ని కూడా పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D20, supplied “Sarala 7 final.pdf” p.12',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D20-03',
      cautionId: 'S7-D20-04',
      topic: 'కర్మ / ధర్మ మార్గం',
      favorableResult: 'D20 9వ భావంలో శుభగ్రహ support ఉంది; కర్మ/ధర్మ సాధనకు అనుకూల layer.',
      cautionResult: 'D20 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; కర్మ/ధర్మ మార్గంలో అడ్డంకి layer.',
      rule: 'D20లో 9వ భావాన్ని కర్మవృత్తి/జ్ఞానం/విధానం సూచనగా source చూడమంటుంది.',
      source: 'Sarala Jyotisham Part VII — D20, supplied “Sarala 7 final.pdf” pp.12–13',
      add: add,
    );
  }

  static void _d24(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D24-01',
      cautionId: 'S7-D24-02',
      topic: 'విద్య వాగ్దానం',
      favorableResult: 'D24 లగ్నంలో శుభగ్రహ support ఉంది; విద్య/అభ్యాసానికి అనుకూల layer.',
      cautionResult: 'D24 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; విద్యలో ఆలస్యం/అడ్డంకి layer.',
      rule: 'D24లో లగ్న బలం విద్య వాగ్దానానికి ప్రధానంగా చూడాలి; 8వ భావం దీర్ఘ/లోతైన విద్యకు, 4వ/9వ/2వ/7వ భావాలు విద్య స్థాయిలకు source సూచిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D24, supplied “Sarala 7 final.pdf” p.13',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 8,
      favorableId: 'S7-D24-03',
      cautionId: 'S7-D24-04',
      topic: 'లోతైన విద్య / పరిశోధన',
      favorableResult: 'D24 8వ భావంలో శుభగ్రహ support ఉంది; దీర్ఘ/లోతైన విద్యకు అనుకూల layer.',
      cautionResult: 'D24 8వ భావంలో పాపగ్రహ ప్రభావం ఉంది; విద్యలో విరామం/దీర్ఘ అడ్డంకి layer.',
      rule: 'D24లో 8వ భావాన్ని విద్య ఆయుష్షు/దీర్ఘ కొనసాగింపుగా source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D24, supplied “Sarala 7 final.pdf” p.13',
      add: add,
    );
  }

  static void _d27(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    final afflictions = [6, 8]
        .expand((h) => _houseNames(v, h))
        .where(_malefics.contains)
        .toList();
    if (afflictions.isNotEmpty) {
      final severe = afflictions.length >= 2;
      add(
        id: severe ? 'S7-D27-02' : 'S7-D27-01',
        topic: 'శరీర/రోగ కారక జాగ్రత్త',
        result: severe
            ? 'D27 6/8 ప్రాంతాల్లో రెండు లేదా ఎక్కువ పాప ప్రభావాలు ఉన్నాయి; source ప్రకారం ఆరోగ్య అంశాన్ని గట్టిగా పరిశీలించాల్సిన layer.'
            : 'D27 6/8 ప్రాంతంలో ఒక పాప ప్రభావం ఉంది; చిన్న జాగ్రత్త layerగా చూడాలి.',
        rule: 'D27లో 6/8 సంబంధిత పాప ప్రభావాల సంఖ్యను రోగ/బాధ తీవ్రతకు source ఉపయోగిస్తుంది; ఒక పీడ చిన్న బాధ, రెండు లేదా ఎక్కువైతే కఠినత పెరుగుతుంది.',
        inspection: 'D27 6/8 పాపగ్రహాలు: ${afflictions.join(', ')}.',
        source: 'Sarala Jyotisham Part VII — D27, supplied “Sarala 7 final.pdf” pp.13–14',
        tone: VargaRuleTone.caution,
        applicable: true,
        remedy: 'ఈ sourceలో వైద్య పరిహారం prescription లేదు. ఆరోగ్య సమస్య ఉంటే వైద్యుడి సలహా అవసరం. జ్యోతిష్య పరిహారం ఇవ్వాలంటే separate source-supported remedy rules మాత్రమే వాడాలి.',
      );
    } else {
      add(
        id: 'S7-D27-00',
        topic: 'శరీర/రోగ కారక పరిశీలన',
        result: 'D27 6/8లో ఈ simple evaluatorకు పాపగ్రహ trigger కనిపించలేదు.',
        rule: 'D27 6/8 పాప ప్రభావాలను source రోగ కారక layerగా పరిశీలిస్తుంది.',
        inspection: 'D27 6/8 పాపగ్రహ count 0.',
        source: 'Sarala Jyotisham Part VII — D27, supplied “Sarala 7 final.pdf” pp.13–14',
        tone: VargaRuleTone.info,
        applicable: false,
      );
    }
  }

  static void _d30(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D30-01',
      cautionId: 'S7-D30-02',
      topic: 'అరిష్ట / సహనశక్తి',
      favorableResult: 'D30 లగ్నంలో శుభగ్రహ support ఉంది; కష్టాల్ని ఎదుర్కొనే resilienceకు అనుకూల layer.',
      cautionResult: 'D30 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; అరిష్ట/కష్టాల layerను ఇతర chart factorsతో జాగ్రత్తగా చూడాలి.',
      rule: 'D30లో కారకాంశ లగ్నంపై శుభ/పాప ప్రభావాన్ని శుభ జన్మ/కారక బలం/అరిష్ట అంశాలకు source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D30, supplied “Sarala 7 final.pdf” pp.14–15',
      add: add,
    );
  }

  static void _d40(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    add(
      id: 'S7-D40-SRC',
      topic: 'వృత్తి అడ్డంకులు / వృత్తి స్థాయి',
      result: 'D40 source rules ఉన్నాయి; అవి “జ్ఞాతికారక/వృత్తి అడ్డంకి గ్రహం” వంటి ప్రత్యేక karaka selectionపై ఆధారపడి ఉంటాయి. ఈ buildలో guess చేయకుండా source-onlyగా ఉంచాం.',
      rule: 'Sarala VII D40లో వృత్తి అడ్డంకి గ్రహ dignity/స్థానం ఆధారంగా వృత్తి కష్ట/స్థాయి ఫలితాలు ఉన్నాయి.',
      inspection: 'D40 chart సిద్ధంగా ఉంది; special career-obstacle karaka selection engine ఇంకా activate కాలేదు.',
      source: 'Sarala Jyotisham Part VII — D40, supplied “Sarala 7 final.pdf” pp.15–16',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );
  }

  static void _d45(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D45-01',
      cautionId: 'S7-D45-02',
      topic: 'ఆధ్యాత్మికత / పితృ సంస్కారం',
      favorableResult: 'D45 9వ భావంలో శుభగ్రహ support ఉంది; ఆధ్యాత్మిక/ధర్మ దిశకు అనుకూల layer.',
      cautionResult: 'D45 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ఆధ్యాత్మిక/పితృ సంస్కార దిశలో కఠిన అనుభవ layer.',
      rule: 'D45లో 5వ/9వ భావాలు, లగ్న/లగ్నాధిపతి, గురు త్రికోణ సంబంధాన్ని ఆధ్యాత్మిక ఫలానికి source పరిశీలిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D45, supplied “Sarala 7 final.pdf” pp.16–17',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 5,
      favorableId: 'S7-D45-03',
      cautionId: 'S7-D45-04',
      topic: 'పూర్వ పుణ్యం / బుద్ధి',
      favorableResult: 'D45 5వ భావంలో శుభగ్రహ support ఉంది; పూర్వపుణ్య/సంస్కారానికి అనుకూల layer.',
      cautionResult: 'D45 5వ భావంలో పాపగ్రహ ప్రభావం ఉంది; పూర్వపుణ్య/సంస్కార అంశంలో కఠిన layer.',
      rule: 'D45లో 5వ భావ పీడ/శుభ సంబంధాన్ని ఆధ్యాత్మిక అనుభవానికి source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D45, supplied “Sarala 7 final.pdf” pp.16–17',
      add: add,
    );
  }

  static void _d60(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D60-01',
      cautionId: 'S7-D60-02',
      topic: 'సూక్ష్మ కర్మ / కారక ఫలం',
      favorableResult: 'D60 లగ్నంలో శుభగ్రహ support ఉంది; సూక్ష్మ కర్మ layerలో అనుకూల background evidence.',
      cautionResult: 'D60 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; సూక్ష్మ కర్మ layerలో కఠిన background evidence.',
      rule: 'D60లో ప్రతి కారకుడిని విడిగా చూడాలి; శుభ సంబంధం మంచి ఫలం, పాప సంబంధం కష్ట/చివరి ఫలం layerగా source సూచిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D60, supplied “Sarala 7 final.pdf” p.18',
      add: add,
    );
    add(
      id: 'S7-D60-SRC',
      topic: 'D60 source boundary',
      result: 'D60 ఒక్కటితో final తీర్పు ఇవ్వకూడదు; source కూడా కారకాంశ/D1 layersతో కలిపి చూడమంటుంది.',
      rule: 'D60 సూక్ష్మ chart. Birth time sensitivity ఎక్కువ. ప్రతి కారకుడిని D1 మరియు ఇతర evidenceతో కలిపి చూడాలి.',
      inspection: 'D60 chart background evidenceగా మాత్రమే ఉపయోగించాలి.',
      source: 'Sarala Jyotisham Part VII — D60, supplied “Sarala 7 final.pdf” p.18',
      tone: VargaRuleTone.info,
      applicable: true,
      remedy: 'D60లో అశుభ సూచన కనిపించినందుకు మాత్రమే రత్నం/పరిహారం prescribe చేయవద్దు. ఇతర chart evidence + separate remedy source rule అవసరం.',
    );
  }


  static void _appendMarriageMaterialRegistry(
    int factor,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    for (final entry in MarriageMaterialRegistry.forFactor(factor)) {
      final partnerNote = entry.requiresTwoCharts
          ? 'ఈ ruleకు వధువు + వరుడు రెండింటి జాతకాలు అవసరం; single-chart resultగా fire చేయదు.'
          : 'ఈ handwritten/source rule exact condition పూర్తిగా machine-validated అయినప్పుడే auto-resultగా fire చేయాలి.';
      add(
        id: entry.id,
        topic: entry.topic,
        result: 'Source rule engineలో నమోదు అయింది; exact condition match కాకుండా result ఇవ్వదు.',
        rule: '${entry.note} $partnerNote',
        inspection: 'సంబంధిత chart layer D$factor లెక్కించబడింది. Source page ${entry.page}ను referenceగా ఉంచాం; ఊహా arithmetic ఉపయోగించము.',
        source: '${MarriageMaterialRegistry.sourceName} p.${entry.page}',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
        remedy: 'ఈ supplied marriage source ruleలో స్పష్టమైన పరిహారం ఉంటేనే link చేయాలి. Sourceలో లేని పరిహారం లేదా రత్నం auto-generate చేయరాదు.',
      );
    }
  }

  static void _appendV50SourceRegistry(
    int factor,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    void sourceOnly({
      required String id,
      required String topic,
      required String rule,
      required String source,
      String? remedy,
    }) {
      add(
        id: id,
        topic: topic,
        result: 'ఈ source rule సంబంధిత varga కింద నమోదు అయింది. Exact condition/strength inputs పూర్తిగా match అయినప్పుడు మాత్రమే positive/negative verdict ఇవ్వాలి.',
        rule: rule,
        inspection: 'ఈ chart layer లెక్కించబడింది; source-specific strength/aspect/exception inputs పూర్తిగా validate చేయకుండా auto-result ఇవ్వము.',
        source: source,
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
        remedy: remedy,
      );
    }

    switch (factor) {
      case 1:
        sourceOnly(
          id: 'SKM-V50-BASE',
          topic: 'S.K. Mehta — జాతక rule registry',
          rule: 'భావ/గ్రహ బలం, exchange, aspect, dignity, event-wise combinations మరియు timing/synchronizationను విడివిడిగా evidence layersగా పరిశీలించాలి. Exact event result source condition match అయినప్పుడే ఇవ్వాలి.',
          source: 'sk mehatha jyotisha-niyamavali.pdf — 36 pages',
        );
        sourceOnly(
          id: 'BNN-V50-BASE',
          topic: 'Brighu Naadi — Nadi rule registry',
          rule: 'R-A, C, E, F, G, H, I, J, K seriesగా indexed Nadi rulesను D1/Nadi method కింద source IDతో నిల్వ చేసి, exact combination match అయినప్పుడు మాత్రమే resultగా చూపాలి.',
          source: 'Brighu_Naadi_Purnna_Rulebook.pdf — 21 pages',
          remedy: 'ఈ Brighu Nadi source registry entryకి ప్రత్యేక remedy rule attach కాలేదు. Sourceలో remedy స్పష్టంగా ఉన్నప్పుడు మాత్రమే link చేయాలి; ఊహించి పరిహారం ఇవ్వకూడదు.',
        );
        sourceOnly(
          id: 'MED-ORG-V50',
          topic: 'అవయవ / రోగ జ్యోతిష్య సూచికలు',
          rule: 'రాశి/భావ/గ్రహ ఆధారంగా body-part, organ, disease-location indicatorsను source orderలో పరిశీలించాలి. ఇది సంప్రదాయ జ్యోతిష్య సూచిక మాత్రమే; వైద్య నిర్ధారణ కాదు.',
          source: 'avayava_roga_niyamalu.pdf — 24 pages',
          remedy: 'ఈ health rule నుంచి మందు, చికిత్స లేదా diagnosisను app ఇవ్వదు. ఆరోగ్య సమస్య ఉంటే qualified doctor/health professionalను సంప్రదించాలి. జ్యోతిష్య పరిహారం sourceలో స్పష్టంగా ఉంటేనే విడిగా చూపాలి.',
        );
        sourceOnly(
          id: 'MED-ROGA-V50',
          topic: 'Medical Astrology — Roga rule registry',
          rule: 'Medical Astrology sourceలో chapter-wise Rule → result నిర్మాణం ఉంది. సంబంధిత భావ/గ్రహ/లగ్న factors match అయినప్పుడు source ruleను చూపాలి; medical diagnosis/treatment output చేయకూడదు.',
          source: 'medical_roga_rules_complete.pdf — 19 pages',
          remedy: 'Medical Astrology resultను వైద్య సలహాగా ఉపయోగించకూడదు. App మందులు/చికిత్స prescribe చేయదు; అవసరమైతే doctor evaluation తీసుకోవాలి.',
        );
        break;
      case 2:
        sourceOnly(
          id: 'AV-015-V50',
          topic: 'ధనం — 2వ/11వ అష్టకవర్గ support',
          rule: 'Wealth/gains ప్రశ్నలకు 2వ మరియు 11వ భావ bindusను supporting evidenceగా పోల్చాలి; standalone verdictగా ఉపయోగించకూడదు.',
          source: 'Ashtakavarga practical source — Wealth 2nd/11th support',
        );
        break;
      case 3:
        sourceOnly(
          id: 'SK-012-V50',
          topic: 'సహోదరులు / Sibling event',
          rule: '3వ/11వ భావాలు మరియు అవసరమైన derivative-house logicను source ప్రకారం పరిశీలించాలి; ఒకే భావానికి పరిమితం చేయకూడదు.',
          source: 'S.K. Mehta — New Dimensions / Synchronization',
        );
        sourceOnly(
          id: 'AV-017-V50',
          topic: '3వ భావ అష్టకవర్గ support',
          rule: 'Sibling/effort అంశాలకు 3వ భావ SAV/BAV బలం supporting evidenceగా ఉపయోగించాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
      case 4:
        sourceOnly(
          id: 'SK-009-V50',
          topic: 'స్థిరాస్తి / Property-home-vehicle',
          rule: '4వ భావం/అధిపతి conditions, strength, aspects మరియు exchangesను property/home/vehicle evidenceగా ఉపయోగించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        sourceOnly(
          id: 'AV-016-V50',
          topic: '4వ భావ అష్టకవర్గ support',
          rule: 'Property/home/vehicle/mother-related ప్రశ్నలకు 4వ భావ SAV/BAV బలం supporting layerగా ఉపయోగించాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
      case 7:
        sourceOnly(
          id: 'SK-011-V50',
          topic: 'సంతానం promise',
          rule: '5వ భావం/అధిపతి, సంబంధిత గ్రహాలు, strength, affliction/support మరియు source-specific combinationsను పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 9:
        sourceOnly(
          id: 'SK-010-V50',
          topic: 'వివాహ promise',
          rule: '7వ భావం/అధిపతి, relationship planets, strength, aspect, association, exchange మరియు source-specific exceptionsను పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 10:
        sourceOnly(
          id: 'SK-006-V50',
          topic: 'వృత్తి promise',
          rule: 'Profession-related houses/lords, relevant planets, relationships, strength మరియు source combinationsను timingకు ముందు పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 16:
        sourceOnly(
          id: 'SK-009-X-V50',
          topic: 'వాహనం / సౌకర్యం cross-reference',
          rule: 'Property/home/vehicle ruleలో 4వ భావం/అధిపతి, strength, aspects, exchanges ప్రధాన evidence. D16ను vehicle/comfort cross-checkగా మాత్రమే చూడాలి; source rule D16ని ప్రత్యేకంగా నిర్దేశించకపోతే కొత్త rule సృష్టించరాదు.',
          source: 'S.K. Mehta — Property/home/vehicle rule',
        );
        break;
      case 24:
        sourceOnly(
          id: 'SK-005-V50',
          topic: 'విద్య promise',
          rule: 'Education-related houses/lords, relevant planets, strength, combinations మరియు exceptions పరిశీలించిన తర్వాతే timing చేయాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        sourceOnly(
          id: 'AV-014-V50',
          topic: 'Higher education — 5వ/9వ support',
          rule: 'Higher-education సూచనలకు 5వ మరియు 9వ భావ bindusను supporting evidenceగా పోల్చాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
    }
  }

  static void _beneficMaleficHouseRule({
    required VargaChartData v,
    required int house,
    required String favorableId,
    required String cautionId,
    required String topic,
    required String favorableResult,
    required String cautionResult,
    required String rule,
    required String source,
    required void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  }) {
    final names = _houseNames(v, house);
    final ben = names.where(_benefics.contains).toList();
    final mal = names.where(_malefics.contains).toList();
    add(
      id: favorableId,
      topic: topic,
      result: ben.isNotEmpty ? favorableResult : '$topic శుభగ్రహ condition auto-match కాలేదు.',
      rule: rule,
      inspection: 'D${v.definition.factor} $houseవ భావంలో ${names.isEmpty ? 'గ్రహాలు లేవు' : names.join(', ')}. శుభగ్రహాలు: ${ben.isEmpty ? 'లేవు' : ben.join(', ')}.',
      source: source,
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: cautionId,
      topic: topic,
      result: mal.isNotEmpty ? cautionResult : '$topic పాపగ్రహ condition auto-match కాలేదు.',
      rule: rule,
      inspection: 'D${v.definition.factor} $houseవ భావంలో పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: source,
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static int _houseSign(VargaChartData v, int house) =>
      (v.ascendantSignIndex + house - 1) % 12;

  static int _houseOf(VargaChartData v, VargaPlacement p) =>
      ((p.signIndex - v.ascendantSignIndex + 12) % 12) + 1;

  static List<String> _houseNames(VargaChartData v, int house) {
    final sign = _houseSign(v, house);
    return v.planets.where((p) => p.signIndex == sign).map((p) => p.name).toList(growable: false);
  }

  static String _signLord(int sign) => switch (sign % 12) {
        0 || 7 => 'Mars',
        1 || 6 => 'Venus',
        2 || 5 => 'Mercury',
        3 => 'Moon',
        4 => 'Sun',
        8 || 11 => 'Jupiter',
        9 || 10 => 'Saturn',
        _ => 'Sun',
      };

  static bool _isExalted(String planet, int sign) {
    const exalt = {
      'Sun': 0,
      'Moon': 1,
      'Mars': 9,
      'Mercury': 5,
      'Jupiter': 3,
      'Venus': 11,
      'Saturn': 6,
    };
    return exalt[planet] == sign;
  }

  static String _remedyText(VargaRuleTone tone) => switch (tone) {
        VargaRuleTone.favorable =>
          'ఈ sourceలో ప్రత్యేక పరిహారం అవసరం అని చెప్పలేదు. అనుకూల బలాన్ని timing/ప్రాక్టికల్ చర్యలతో ఉపయోగించండి.',
        VargaRuleTone.caution =>
          'ఈ varga sourceలో ప్రత్యేక remedy prescription లేదు. ముందుగా practical correction చేయాలి. రత్నం/గ్రహ పరిహారం ఇవ్వాలంటే supplied Gemstone Remedy rule-engine eligibilityని విడిగా పరీక్షించాలి; automatic gemstone ఇవ్వవద్దు.',
        VargaRuleTone.neutral =>
          'ఇది పరిశీలన layer. Sourceలో ప్రత్యేక పరిహారం ఇవ్వలేదు; ఇతర chart evidenceతో కలిపి నిర్ణయించాలి.',
        VargaRuleTone.info =>
          'ఈ rule source-only. Exact condition పూర్తిగా validate అయ్యే వరకు పరిహారం auto-generate చేయరాదు.',
      };
}
