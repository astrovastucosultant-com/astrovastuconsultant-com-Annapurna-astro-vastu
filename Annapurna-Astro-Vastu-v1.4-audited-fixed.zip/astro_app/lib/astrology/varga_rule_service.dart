import 'astro_models.dart';
import 'varga_service.dart';

enum VargaRuleTone { favorable, caution, neutral, info }

class VargaRuleHit {
  final int factor;
  final String ruleId;
  final String topic;
  final String result;
  final String rule;
  final String inspection;
  final String remedy;
  final String source;
  final VargaRuleTone tone;
  final bool applicable;
  final bool autoEvaluated;

  const VargaRuleHit({
    required this.factor,
    required this.ruleId,
    required this.topic,
    required this.result,
    required this.rule,
    required this.inspection,
    required this.remedy,
    required this.source,
    required this.tone,
    required this.applicable,
    required this.autoEvaluated,
  });
}

/// Source-linked varga rule layer.
///
/// Boundary: only conditions that can be reproduced from the current D1/varga
/// placements are auto-fired. Rules requiring a source-specific strength,
/// aspect, special karaka, or unimplemented arithmetic stay in the source
/// catalog instead of being guessed.
class VargaRuleService {
  static const _benefics = {'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};

  static List<VargaRuleHit> allFor({
    required AstroChartResult chart,
    required int factor,
  }) {
    final varga = VargaService.calculate(chart, factor);
    final out = <VargaRuleHit>[];

    void add({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto = true,
      String? remedy,
    }) {
      out.add(
        VargaRuleHit(
          factor: factor,
          ruleId: id,
          topic: topic,
          result: result,
          rule: rule,
          inspection: inspection,
          remedy: remedy ?? _remedyText(tone),
          source: source,
          tone: tone,
          applicable: applicable,
          autoEvaluated: auto,
        ),
      );
    }

    switch (factor) {
      case 1:
        _d1Gems(chart, add);
        break;
      case 2:
        add(
          id: 'SRC-D2-01',
          topic: 'ధనం / హోరా',
          result: 'ఈ buildలో supplied files నుంచి D2కి exact auto-rule evaluator జోడించలేదు.',
          rule: 'D2 ఫలితాన్ని source-specific rule ఉన్నప్పుడు మాత్రమే auto-match చేయాలి.',
          inspection: 'D2 chart calculation అందుబాటులో ఉంది; rule source mapping ఇంకా source-only.',
          source: 'Supplied varga sources — D2 explicit rule not used in this build',
          tone: VargaRuleTone.info,
          applicable: false,
          auto: false,
        );
        break;
      case 3:
        _d3(varga, add);
        break;
      case 4:
        _d4(varga, add);
        break;
      case 7:
        _d7(chart, varga, add);
        break;
      case 9:
        _d9(varga, add);
        break;
      case 10:
        _d10(chart, varga, add);
        break;
      case 12:
        _d12(varga, add);
        break;
      case 16:
        _d16(varga, add);
        break;
      case 20:
        _d20(varga, add);
        break;
      case 24:
        _d24(varga, add);
        break;
      case 27:
        _d27(varga, add);
        break;
      case 30:
        _d30(varga, add);
        break;
      case 40:
        _d40(varga, add);
        break;
      case 45:
        _d45(varga, add);
        break;
      case 60:
        _d60(varga, add);
        break;
    }

    // V50 source registry: topic-wise source entries are attached under the
    // relevant varga without inventing an automatic verdict.
    _appendV50SourceRegistry(factor, add);

    return out;
  }

  static List<VargaRuleHit> applicableFor({
    required AstroChartResult chart,
    required int factor,
  }) => allFor(chart: chart, factor: factor)
      .where((x) => x.autoEvaluated && x.applicable)
      .toList(growable: false);

  static void _d1Gems(
    AstroChartResult chart,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final lagna = chart.ascendantSignIndex;
    final exaltedInLagna = chart.planets.where((p) => p.signIndex == lagna && _isExalted(p.name, p.signIndex)).toList();
    add(
      id: 'G-05',
      topic: 'లగ్నంలో ఉచ్చరాశి గ్రహం',
      result: exaltedInLagna.isEmpty
          ? 'ఈ జాతకంలో G-05 condition auto-match కాలేదు.'
          : 'లగ్న బలానికి అనుకూల source సూచన కనిపిస్తోంది.',
      rule: 'లగ్నంలో ఉచ్చ స్థితిలో గ్రహం ఉండి, సంబంధిత support ఉంటే లగ్నానికి బలం మరియు మంచి ఫలితాల సూచనగా చూడాలి.',
      inspection: exaltedInLagna.isEmpty
          ? 'లగ్నంలో ఉచ్చస్థితి గ్రహం లేదు.'
          : 'లగ్నంలో ఉచ్చస్థితి: ${exaltedInLagna.map((p) => p.name).join(', ')}.',
      source: '108 Gems of Predictive Astrology — G-05, supplied rule-based PDF p.2',
      tone: VargaRuleTone.favorable,
      applicable: exaltedInLagna.isNotEmpty,
    );

    for (final item in const [
      ('G-01', 'జన్మదినం', 'జన్మ వారాధిపతి 6/8 అధిపత్యం మరియు ఉచ్చ/నీచ స్థితిని కలిపి పరిశీలించే rule.'),
      ('G-06', 'లగ్నాధిపతి — 1', 'లగ్నాధిపతి స్థానం/బలం/దృష్టి layersను కలిపి నిర్ణయించే rule.'),
      ('G-07', 'లగ్నాధిపతి — 2', 'లగ్నాధిపతికి శుభ/పాప సంబంధాన్ని పరిశీలించే rule.'),
      ('G-08', 'లగ్నాధిపతి × చంద్రరాశ్యాధిపతి', 'లగ్నాధిపతి మరియు చంద్రరాశ్యాధిపతి కేంద్ర/సంబంధాన్ని పరిశీలించే rule.'),
      ('G-09', 'లగ్నాధిపతి × చంద్రరాశ్యాధిపతి ఉపచయం', 'ఇద్దరి ఉపచయ/కేంద్ర సంబంధాన్ని పరిశీలించే rule.'),
      ('G-10', 'నవమాధిపతి × లగ్నాధిపతి', '9వ అధిపతి–లగ్నాధిపతి సంబంధం ద్వారా భాగ్యం/శ్రేయస్సు layer.'),
    ]) {
      add(
        id: item.$1,
        topic: item.$2,
        result: 'Source rule catalogలో ఉంది; exact evaluator ఈ buildలో guess చేయకుండా source-onlyగా ఉంచాం.',
        rule: item.$3,
        inspection: 'ఈ ruleకు అవసరమైన పూర్తి source arithmetic/relationship layerను విడిగా validate చేసిన తర్వాత మాత్రమే auto-result ఇవ్వాలి.',
        source: '108 Gems of Predictive Astrology — supplied rule-based PDF pp.2–3',
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
      );
    }
  }

  static void _d3(
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final lagnaNames = _houseNames(v, 1);
    final ben = lagnaNames.where(_benefics.contains).toList();
    final mal = lagnaNames.where(_malefics.contains).toList();
    add(
      id: 'S7-D3-01',
      topic: 'స్వప్రయత్నం / ధైర్యం',
      result: ben.isNotEmpty ? 'D3 లగ్నంలో శుభగ్రహ support ఉంది; స్వప్రయత్నానికి అనుకూల layer.' : 'D3 లగ్న శుభగ్రహ support auto-match కాలేదు.',
      rule: 'D3లో లగ్నం/లగ్నాధిపతి బలం స్వప్రయత్నం, ధైర్యం, కర్మఫలానికి ప్రధానంగా చూడాలి.',
      inspection: 'D3 లగ్నంలో: ${lagnaNames.isEmpty ? 'గ్రహం లేదు' : lagnaNames.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'S7-D3-02',
      topic: 'స్వప్రయత్నం / జాగ్రత్త',
      result: mal.isNotEmpty ? 'D3 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; ప్రయత్నంలో ఒత్తిడి/కఠినత layerగా చూడాలి.' : 'D3 లగ్న పాపగ్రహ condition auto-match కాలేదు.',
      rule: 'D3 lagna/lagna-lord affliction ఉంటే ప్రయత్నంలో ఆటంకం లేదా కఠిన ఫలితంగా source చూడమంటుంది.',
      inspection: 'D3 లగ్నంలో పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: 'Sarala Jyotisham Part VII — D3, supplied “Sarala 7 final.pdf” p.2',
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static void _d4(
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final fourthSign = _houseSign(v, 4);
    final lord = _signLord(fourthSign);
    final lordPlacement = v.planets.firstWhere((p) => p.name == lord);
    final lordHouse = _houseOf(v, lordPlacement);
    const results = <int, String>{
      1: 'విద్య, ఆభరణాలు, భూమి, వాహన అంశాలకు అనుకూలత; సాధారణంగా సంతోషం.',
      2: 'ధనం, సుఖం.',
      3: 'ధైర్యం; పాప ప్రభావం ఉంటే అనుభవం కఠినంగా మారవచ్చు.',
      4: 'సంపద, విద్య, గౌరవం.',
      5: 'రాజయోగ/మంచి సంతానం layer; బలహీనత ఉంటే సంతాన అంశం పరిశీలించాలి.',
      6: 'భౌతిక సుఖంలో ఒత్తిడి; పాప ప్రభావం ఉంటే ఆరోగ్య/తల్లి అంశం జాగ్రత్త.',
      7: 'విద్య, వాహనం; ఇతర సంబంధాలను కూడా చూడాలి.',
      8: 'గృహ సుఖం తగ్గే లేదా మార్పులు వచ్చే సూచన; వృత్తి/ధన సంబంధం కూడా చూడాలి.',
      9: 'రాజయోగ/ఉన్నత విద్య layer.',
      10: 'రాజ గౌరవం / స్థాయి.',
      11: 'దాతృత్వం; పాప ప్రభావం ఉంటే చెడు ఉపదేశం/మిశ్రమ ఫలితం.',
      12: 'సుఖ లోపం/నష్టం వంటి జాగ్రత్త సూచన.',
    };
    final tone = {1, 2, 4, 5, 7, 9, 10, 11}.contains(lordHouse)
        ? VargaRuleTone.favorable
        : {6, 8, 12}.contains(lordHouse)
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'S3-D4-L4H$lordHouse',
      topic: 'D4 4వ అధిపతి స్థానం',
      result: results[lordHouse]!,
      rule: 'D4లో 4వ భావ అధిపతి ఏ భావంలో ఉన్నాడో ఆధారంగా స్థిరాస్తి/సుఖ ఫలితాన్ని source tableలో చదవాలి.',
      inspection: 'D4 4వ భావ రాశి ${fourthSign + 1}; అధిపతి $lord; D4లో $lord ${lordHouse}వ భావంలో ఉంది.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 4th-lord result table pp.1–2',
      tone: tone,
      applicable: true,
    );

    final h4 = _houseNames(v, 4);
    final ben = h4.where(_benefics.contains).toList();
    final mal = h4.where(_malefics.contains).toList();
    add(
      id: 'S3-D4-H4-BEN',
      topic: 'స్థిరాస్తి / 4వ భావ support',
      result: ben.isNotEmpty ? 'D4 4వ భావంలో శుభగ్రహ support ఉంది; స్థిరాస్తి/సుఖానికి అనుకూల layer.' : 'D4 4వ భావ శుభగ్రహ condition auto-match కాలేదు.',
      rule: 'D4 4వ భావ బలం మరియు శుభ సంబంధాన్ని స్థిరాస్తి ఫలితానికి చూడాలి.',
      inspection: 'D4 4వ భావంలో ${h4.isEmpty ? 'గ్రహాలు లేవు' : h4.join(', ')}.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 property rules pp.1–2',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'S3-D4-H4-MAL',
      topic: 'స్థిరాస్తి / జాగ్రత్త',
      result: mal.isNotEmpty ? 'D4 4వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ఆస్తి/సుఖంలో ఒత్తిడి లేదా ఆలస్యం layerగా చూడాలి.' : 'D4 4వ భావ పాపగ్రహ condition auto-match కాలేదు.',
      rule: 'D4 4వ భావం పీడితమైతే స్థిరాస్తి/సుఖ అంశంలో జాగ్రత్తగా source ఫలితం చదవాలి.',
      inspection: 'D4 4వ భావ పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: '“Saral3_nundi_Ippativaraku.pdf” — D4 property rules pp.1–2',
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static void _d7(
    AstroChartResult chart,
    VargaChartData v,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    final natal5Sign = (chart.ascendantSignIndex + 4) % 12;
    final natal5Lord = _signLord(natal5Sign);
    final natal5LordPlanet = chart.planets.firstWhere((p) => p.name == natal5Lord);
    final natal5LordHouse = ((natal5LordPlanet.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final jupiter = chart.planets.firstWhere((p) => p.name == 'Jupiter');
    final jupiterHouse = ((jupiter.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final lagnaLord = _signLord(chart.ascendantSignIndex);
    final lagnaLordPlanet = chart.planets.firstWhere((p) => p.name == lagnaLord);
    final lagnaLordHouse = ((lagnaLordPlanet.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final natalSupport = natal5LordHouse == 5 || jupiterHouse == 5 || lagnaLordHouse == 5;
    add(
      id: 'D7-SANTANA-01',
      topic: '5వ భావ బలం / సంతానం',
      result: natalSupport ? 'సంతాన వాగ్దానానికి 5వ భావ primary support కనిపిస్తోంది.' : '5వ భావ primary support ఈ simple evaluatorలో match కాలేదు; పూర్తి దృష్టి/శుభసంబంధం చూడాలి.',
      rule: 'సంతాన నిర్ణయంలో ముందుగా 5వ భావం, 5వ అధిపతి, కారకుడు గురువును పరిశీలించాలి; తరువాత D7 చూడాలి.',
      inspection: '5వ అధిపతి $natal5Lord — House $natal5LordHouse; Jupiter — House $jupiterHouse; Lagna lord $lagnaLord — House $lagnaLordHouse.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” pp.1–2',
      tone: natalSupport ? VargaRuleTone.favorable : VargaRuleTone.neutral,
      applicable: natalSupport,
    );

    final d7h5 = _houseNames(v, 5);
    final ben = d7h5.where(_benefics.contains).toList();
    final mal = d7h5.where(_malefics.contains).toList();
    add(
      id: 'D7-SANTANA-02',
      topic: 'D7 5వ భావ support',
      result: ben.isNotEmpty ? 'D7 5వ భావంలో శుభగ్రహ support ఉంది; సంతాన అంశానికి అనుకూల layer.' : 'D7 5వ భావ శుభగ్రహ condition auto-match కాలేదు.',
      rule: 'D7లో 5వ భావం, 5వ అధిపతి, పుత్రకారక/గురు బలాన్ని కలిపి చూడాలి.',
      inspection: 'D7 5వ భావంలో: ${d7h5.isEmpty ? 'గ్రహాలు లేవు' : d7h5.join(', ')}.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” + Sarala VII D7 section',
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: 'D7-SANTANA-03',
      topic: 'D7 5వ భావ జాగ్రత్త',
      result: mal.length >= 2 ? 'D7 5వ భావంపై బహుళ పాపగ్రహ ప్రభావం ఉంది; సంతాన అంశాన్ని ఇతర supportతో జాగ్రత్తగా చూడాలి.' : 'D7 5వ భావ బహుళ పాపగ్రహ condition match కాలేదు.',
      rule: '5వ భావం/5వ అధిపతి పాపగ్రహ పీడనలో ఉంటే సంతాన ఫలితంలో కష్ట/ఆలస్యం layerగా source చూడమంటుంది.',
      inspection: 'D7 5వ భావ పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: '“Saptamsha_Santana_Niyamalu.pdf” pp.1–2; Sarala VII D7 p.5',
      tone: VargaRuleTone.caution,
      applicable: mal.length >= 2,
    );
  }

  static void _d9(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 7,
      favorableId: 'S7-D9-01',
      cautionId: 'S7-D9-02',
      topic: 'వివాహ వాగ్దానం',
      favorableResult: 'D9 7వ భావంలో శుభగ్రహ support ఉంది; వివాహ/భాగస్వామ్యానికి అనుకూల layer.',
      cautionResult: 'D9 7వ భావంలో పాపగ్రహ ప్రభావం ఉంది; సంబంధాన్ని ఇతర factorsతో జాగ్రత్తగా చూడాలి.',
      rule: 'D9లో 7వ భావం, 7వ అధిపతి, దారాకారక/జ్ఞాతికారక సంబంధాన్ని వివాహానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D9, supplied “Sarala 7 final.pdf” p.6',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D9-03',
      cautionId: 'S7-D9-04',
      topic: 'ధర్మం / నైతిక దిశ',
      favorableResult: 'D9 9వ భావంలో శుభగ్రహ support ఉంది; ధర్మ/గురు/నైతికతకు అనుకూల layer.',
      cautionResult: 'D9 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ధర్మ/గురు అంశంలో జాగ్రత్త layer.',
      rule: 'D9 9వ భావం, 9వ అధిపతి, గురువును ధర్మ ఫలానికి పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D9, supplied “Sarala 7 final.pdf” pp.6–7',
      add: add,
    );
  }

  static void _d10(
    AstroChartResult chart,
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 10,
      favorableId: 'D10-CAR-01',
      cautionId: 'D10-CAR-02',
      topic: 'వృత్తి / స్థాయి',
      favorableResult: 'D10 10వ భావంలో శుభగ్రహ support ఉంది; స్థాయి/గౌరవం/వృత్తికి అనుకూల layer.',
      cautionResult: 'D10 10వ భావంలో పాపగ్రహ ప్రభావం ఉంది; వృత్తిలో ఒత్తిడి/శిక్ష/అవమానం వంటి జాగ్రత్త layer.',
      rule: 'D10 Lagna, 10వ భావం, 10వ అధిపతి, అమాత్యకారక బలం/శుభ సంబంధాన్ని స్థాయి–కీర్తికి చూడాలి; పీడ ఉంటే అవమానం/శిక్ష layer.',
      source: '“D10-dashamsha-rule-guide.pdf” + Sarala VII D10 p.7',
      add: add,
    );

    final supportHouses = [2, 4, 11, 5];
    final obstructionHouses = [12, 10, 3, 9];
    final supportCount = supportHouses.fold<int>(0, (sum, h) => sum + _houseNames(v, h).length);
    final obstructionCount = obstructionHouses.fold<int>(0, (sum, h) => sum + _houseNames(v, h).length);
    final argalaTone = supportCount > obstructionCount
        ? VargaRuleTone.favorable
        : obstructionCount > supportCount
            ? VargaRuleTone.caution
            : VargaRuleTone.neutral;
    add(
      id: 'D10-R6.1',
      topic: 'వృత్తి అర్గళ బలం',
      result: supportCount > obstructionCount
          ? 'D10లో అర్గళ support అడ్డుకంటే ఎక్కువగా ఉంది; వృత్తి నిలకడకు అనుకూల source arithmetic.'
          : obstructionCount > supportCount
              ? 'D10లో అడ్డుగ్రహ count అర్గళ supportకంటే ఎక్కువగా ఉంది; వృత్తి స్థిరత్వంలో జాగ్రత్త layer.'
              : 'D10 అర్గళ–అడ్డుగ్రహ count సమంగా ఉంది; మిశ్రమ support.',
      rule: '4, 2, 11 భావాలు అర్గళ; వాటి అడ్డులు 10, 12, 3. 5వ భావం కూడా అర్గళ; 9వ భావం అడ్డుగా చూడాలి. అర్గళ గ్రహాలు అడ్డుకంటే బలంగా/ఎక్కువగా ఉంటే వృత్తి నిలుస్తుంది.',
      inspection: 'Argala houses 2/4/11/5 = $supportCount occupants; obstruction 12/10/3/9 = $obstructionCount occupants.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.1, p.8',
      tone: argalaTone,
      applicable: supportCount != obstructionCount,
    );

    final h3Mal = _houseNames(v, 3).where(_malefics.contains).toList();
    add(
      id: 'D10-R6.2',
      topic: 'ప్రత్యేక అర్గళ',
      result: h3Mal.length >= 3 ? 'D10 3వ భావంలో 3+ పాపగ్రహాలు ఉన్నాయి; source ప్రకారం ప్రత్యేక అర్గళ layer.' : 'ప్రత్యేక అర్గళ condition match కాలేదు.',
      rule: '3వ భావంలో 3 లేదా ఎక్కువ పాపగ్రహాలు ఉంటే ప్రత్యేక అర్గళ; దీనికి అడ్డుగా source చూడదు.',
      inspection: 'D10 3వ భావ పాపగ్రహాలు: ${h3Mal.isEmpty ? 'లేవు' : h3Mal.join(', ')}.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.2, p.8',
      tone: VargaRuleTone.favorable,
      applicable: h3Mal.length >= 3,
    );

    final natal10Sign = (chart.ascendantSignIndex + 9) % 12;
    final natal10Planets = chart.planets.where((p) => p.signIndex == natal10Sign).toList();
    final natal10Lord = _signLord(natal10Sign);
    final d10Lord = v.planets.firstWhere((p) => p.name == natal10Lord);
    final d10LordHouse = _houseOf(v, d10Lord);
    final lordArgala = supportHouses.contains(d10LordHouse) || d10LordHouse == 1 || d10LordHouse == 10;
    add(
      id: 'D10-R6.9',
      topic: 'జన్మ 10వ అధిపతి × D10',
      result: lordArgala ? 'జన్మ 10వ అధిపతి D10లో ముఖ్య/అర్గళ స్థానంలో ఉంది; వృత్తి నిర్ణయానికి బలమైన confirmation layer.' : 'జన్మ 10వ అధిపతి D10లో ప్రధాన argala/Lagna/10వ స్థానానికి match కాలేదు.',
      rule: 'జన్మ 10వ అధిపతి D10లో అర్గళ ఇస్తే ముఖ్యంగా చూడాలి; D10 Lagna/10వ సంబంధం ఉంటే ఫలిత weight పెరుగుతుంది.',
      inspection: 'జన్మ 10వ రాశి ${natal10Sign + 1}; అధిపతి $natal10Lord; D10లో House $d10LordHouse. జన్మ 10వలో గ్రహాలు: ${natal10Planets.isEmpty ? 'లేవు' : natal10Planets.map((p) => p.name).join(', ')}.',
      source: '“D10-dashamsha-rule-guide.pdf” Rule 6.9, p.9',
      tone: VargaRuleTone.favorable,
      applicable: lordArgala,
    );
  }

  static void _d12(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D12-01',
      cautionId: 'S7-D12-02',
      topic: 'పూర్వీక ఆశీర్వాదం / కుటుంబ రక్షణ',
      favorableResult: 'D12 లగ్నంలో శుభగ్రహ support ఉంది; పూర్వీక/తల్లిదండ్రుల సహకారానికి అనుకూల layer.',
      cautionResult: 'D12 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; కుటుంబ/పూర్వీక అంశంలో కఠిన అనుభవ layer.',
      rule: 'D12లో కారకాంశ లగ్నం/లగ్నాధిపతి బలం మరియు శుభ/క్రూర సంబంధాన్ని పూర్వీక ఆశీర్వాదానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D12, supplied “Sarala 7 final.pdf” p.9',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 4,
      favorableId: 'S7-D12-03',
      cautionId: 'S7-D12-04',
      topic: 'తల్లి / సుఖం',
      favorableResult: 'D12 4వ భావంలో శుభగ్రహ support ఉంది; తల్లి/గృహ సౌఖ్యానికి అనుకూల layer.',
      cautionResult: 'D12 4వ భావంలో పాపగ్రహ ప్రభావం ఉంది; తల్లి/గృహసుఖ అంశంలో జాగ్రత్త layer.',
      rule: 'D12లో 4వ భావ పీడను తల్లి/కుటుంబ సుఖానికి పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D12, supplied “Sarala 7 final.pdf” p.9',
      add: add,
    );
  }

  static void _d16(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D16-01',
      cautionId: 'S7-D16-02',
      topic: 'సుఖభోగం / వాహనం',
      favorableResult: 'D16 లగ్నంలో శుభగ్రహ support ఉంది; సుఖం/వాహన యోగానికి అనుకూల layer.',
      cautionResult: 'D16 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; సుఖం/వాహన అంశంలో జాగ్రత్త layer.',
      rule: 'D16లో లగ్నం, లగ్నాధిపతి, 4వ భావం, పుత్రకారక/సంబంధిత గ్రహాలను సుఖ–వాహన ఫలానికి చూడాలి.',
      source: 'Sarala Jyotisham Part VII — D16, supplied “Sarala 7 final.pdf” p.11',
      add: add,
    );
    final h468 = [4, 6, 8].expand((h) => _houseNames(v, h)).where(_malefics.contains).toList();
    add(
      id: 'S7-D16-03',
      topic: 'వాహన జాగ్రత్త',
      result: h468.length >= 2 ? 'D16 4/6/8 సంబంధిత ప్రాంతాల్లో బహుళ పాపగ్రహ ప్రభావం ఉంది; వాహన/ప్రయాణంలో జాగ్రత్త layer.' : 'D16 accident-caution simple condition match కాలేదు.',
      rule: '4, 6, 8 సంబంధం మరియు పాప ప్రభావాన్ని వాహన ప్రమాద/దొంగతనం అంశంలో source పరిశీలిస్తుంది.',
      inspection: 'D16 4/6/8లో పాపగ్రహ count: ${h468.length} (${h468.isEmpty ? 'లేవు' : h468.join(', ')}).',
      source: 'Sarala Jyotisham Part VII — D16, supplied “Sarala 7 final.pdf” pp.11–12',
      tone: VargaRuleTone.caution,
      applicable: h468.length >= 2,
    );
  }

  static void _d20(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 5,
      favorableId: 'S7-D20-01',
      cautionId: 'S7-D20-02',
      topic: 'బుద్ధి / ఆధ్యాత్మిక సాధన',
      favorableResult: 'D20 5వ భావంలో శుభగ్రహ support ఉంది; ఆధ్యాత్మిక బుద్ధి/సాధనకు అనుకూల layer.',
      cautionResult: 'D20 5వ భావంలో పాపగ్రహ ప్రభావం ఉంది; సాధనలో దృష్టి చెదరే/అడ్డంకి layer.',
      rule: 'D20లో 5వ భావం స్వభావ/బుద్ధి సూచకంగా; పుత్రకారక యోగం/జ్ఞాతికారక సంబంధాన్ని కూడా పరిశీలించాలి.',
      source: 'Sarala Jyotisham Part VII — D20, supplied “Sarala 7 final.pdf” p.12',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D20-03',
      cautionId: 'S7-D20-04',
      topic: 'కర్మ / ధర్మ మార్గం',
      favorableResult: 'D20 9వ భావంలో శుభగ్రహ support ఉంది; కర్మ/ధర్మ సాధనకు అనుకూల layer.',
      cautionResult: 'D20 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; కర్మ/ధర్మ మార్గంలో అడ్డంకి layer.',
      rule: 'D20లో 9వ భావాన్ని కర్మవృత్తి/జ్ఞానం/విధానం సూచనగా source చూడమంటుంది.',
      source: 'Sarala Jyotisham Part VII — D20, supplied “Sarala 7 final.pdf” pp.12–13',
      add: add,
    );
  }

  static void _d24(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D24-01',
      cautionId: 'S7-D24-02',
      topic: 'విద్య వాగ్దానం',
      favorableResult: 'D24 లగ్నంలో శుభగ్రహ support ఉంది; విద్య/అభ్యాసానికి అనుకూల layer.',
      cautionResult: 'D24 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; విద్యలో ఆలస్యం/అడ్డంకి layer.',
      rule: 'D24లో లగ్న బలం విద్య వాగ్దానానికి ప్రధానంగా చూడాలి; 8వ భావం దీర్ఘ/లోతైన విద్యకు, 4వ/9వ/2వ/7వ భావాలు విద్య స్థాయిలకు source సూచిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D24, supplied “Sarala 7 final.pdf” p.13',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 8,
      favorableId: 'S7-D24-03',
      cautionId: 'S7-D24-04',
      topic: 'లోతైన విద్య / పరిశోధన',
      favorableResult: 'D24 8వ భావంలో శుభగ్రహ support ఉంది; దీర్ఘ/లోతైన విద్యకు అనుకూల layer.',
      cautionResult: 'D24 8వ భావంలో పాపగ్రహ ప్రభావం ఉంది; విద్యలో విరామం/దీర్ఘ అడ్డంకి layer.',
      rule: 'D24లో 8వ భావాన్ని విద్య ఆయుష్షు/దీర్ఘ కొనసాగింపుగా source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D24, supplied “Sarala 7 final.pdf” p.13',
      add: add,
    );
  }

  static void _d27(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    final afflictions = [6, 8]
        .expand((h) => _houseNames(v, h))
        .where(_malefics.contains)
        .toList();
    if (afflictions.isNotEmpty) {
      final severe = afflictions.length >= 2;
      add(
        id: severe ? 'S7-D27-02' : 'S7-D27-01',
        topic: 'శరీర/రోగ కారక జాగ్రత్త',
        result: severe
            ? 'D27 6/8 ప్రాంతాల్లో రెండు లేదా ఎక్కువ పాప ప్రభావాలు ఉన్నాయి; source ప్రకారం ఆరోగ్య అంశాన్ని గట్టిగా పరిశీలించాల్సిన layer.'
            : 'D27 6/8 ప్రాంతంలో ఒక పాప ప్రభావం ఉంది; చిన్న జాగ్రత్త layerగా చూడాలి.',
        rule: 'D27లో 6/8 సంబంధిత పాప ప్రభావాల సంఖ్యను రోగ/బాధ తీవ్రతకు source ఉపయోగిస్తుంది; ఒక పీడ చిన్న బాధ, రెండు లేదా ఎక్కువైతే కఠినత పెరుగుతుంది.',
        inspection: 'D27 6/8 పాపగ్రహాలు: ${afflictions.join(', ')}.',
        source: 'Sarala Jyotisham Part VII — D27, supplied “Sarala 7 final.pdf” pp.13–14',
        tone: VargaRuleTone.caution,
        applicable: true,
        remedy: 'ఈ sourceలో వైద్య పరిహారం prescription లేదు. ఆరోగ్య సమస్య ఉంటే వైద్యుడి సలహా అవసరం. జ్యోతిష్య పరిహారం ఇవ్వాలంటే separate source-supported remedy rules మాత్రమే వాడాలి.',
      );
    } else {
      add(
        id: 'S7-D27-00',
        topic: 'శరీర/రోగ కారక పరిశీలన',
        result: 'D27 6/8లో ఈ simple evaluatorకు పాపగ్రహ trigger కనిపించలేదు.',
        rule: 'D27 6/8 పాప ప్రభావాలను source రోగ కారక layerగా పరిశీలిస్తుంది.',
        inspection: 'D27 6/8 పాపగ్రహ count 0.',
        source: 'Sarala Jyotisham Part VII — D27, supplied “Sarala 7 final.pdf” pp.13–14',
        tone: VargaRuleTone.info,
        applicable: false,
      );
    }
  }

  static void _d30(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D30-01',
      cautionId: 'S7-D30-02',
      topic: 'అరిష్ట / సహనశక్తి',
      favorableResult: 'D30 లగ్నంలో శుభగ్రహ support ఉంది; కష్టాల్ని ఎదుర్కొనే resilienceకు అనుకూల layer.',
      cautionResult: 'D30 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; అరిష్ట/కష్టాల layerను ఇతర chart factorsతో జాగ్రత్తగా చూడాలి.',
      rule: 'D30లో కారకాంశ లగ్నంపై శుభ/పాప ప్రభావాన్ని శుభ జన్మ/కారక బలం/అరిష్ట అంశాలకు source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D30, supplied “Sarala 7 final.pdf” pp.14–15',
      add: add,
    );
  }

  static void _d40(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    add(
      id: 'S7-D40-SRC',
      topic: 'వృత్తి అడ్డంకులు / వృత్తి స్థాయి',
      result: 'D40 source rules ఉన్నాయి; అవి “జ్ఞాతికారక/వృత్తి అడ్డంకి గ్రహం” వంటి ప్రత్యేక karaka selectionపై ఆధారపడి ఉంటాయి. ఈ buildలో guess చేయకుండా source-onlyగా ఉంచాం.',
      rule: 'Sarala VII D40లో వృత్తి అడ్డంకి గ్రహ dignity/స్థానం ఆధారంగా వృత్తి కష్ట/స్థాయి ఫలితాలు ఉన్నాయి.',
      inspection: 'D40 chart సిద్ధంగా ఉంది; special career-obstacle karaka selection engine ఇంకా activate కాలేదు.',
      source: 'Sarala Jyotisham Part VII — D40, supplied “Sarala 7 final.pdf” pp.15–16',
      tone: VargaRuleTone.info,
      applicable: false,
      auto: false,
    );
  }

  static void _d45(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 9,
      favorableId: 'S7-D45-01',
      cautionId: 'S7-D45-02',
      topic: 'ఆధ్యాత్మికత / పితృ సంస్కారం',
      favorableResult: 'D45 9వ భావంలో శుభగ్రహ support ఉంది; ఆధ్యాత్మిక/ధర్మ దిశకు అనుకూల layer.',
      cautionResult: 'D45 9వ భావంలో పాపగ్రహ ప్రభావం ఉంది; ఆధ్యాత్మిక/పితృ సంస్కార దిశలో కఠిన అనుభవ layer.',
      rule: 'D45లో 5వ/9వ భావాలు, లగ్న/లగ్నాధిపతి, గురు త్రికోణ సంబంధాన్ని ఆధ్యాత్మిక ఫలానికి source పరిశీలిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D45, supplied “Sarala 7 final.pdf” pp.16–17',
      add: add,
    );
    _beneficMaleficHouseRule(
      v: v,
      house: 5,
      favorableId: 'S7-D45-03',
      cautionId: 'S7-D45-04',
      topic: 'పూర్వ పుణ్యం / బుద్ధి',
      favorableResult: 'D45 5వ భావంలో శుభగ్రహ support ఉంది; పూర్వపుణ్య/సంస్కారానికి అనుకూల layer.',
      cautionResult: 'D45 5వ భావంలో పాపగ్రహ ప్రభావం ఉంది; పూర్వపుణ్య/సంస్కార అంశంలో కఠిన layer.',
      rule: 'D45లో 5వ భావ పీడ/శుభ సంబంధాన్ని ఆధ్యాత్మిక అనుభవానికి source ఉపయోగిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D45, supplied “Sarala 7 final.pdf” pp.16–17',
      add: add,
    );
  }

  static void _d60(
    VargaChartData v,
    void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  ) {
    _beneficMaleficHouseRule(
      v: v,
      house: 1,
      favorableId: 'S7-D60-01',
      cautionId: 'S7-D60-02',
      topic: 'సూక్ష్మ కర్మ / కారక ఫలం',
      favorableResult: 'D60 లగ్నంలో శుభగ్రహ support ఉంది; సూక్ష్మ కర్మ layerలో అనుకూల background evidence.',
      cautionResult: 'D60 లగ్నంలో పాపగ్రహ ప్రభావం ఉంది; సూక్ష్మ కర్మ layerలో కఠిన background evidence.',
      rule: 'D60లో ప్రతి కారకుడిని విడిగా చూడాలి; శుభ సంబంధం మంచి ఫలం, పాప సంబంధం కష్ట/చివరి ఫలం layerగా source సూచిస్తుంది.',
      source: 'Sarala Jyotisham Part VII — D60, supplied “Sarala 7 final.pdf” p.18',
      add: add,
    );
    add(
      id: 'S7-D60-SRC',
      topic: 'D60 source boundary',
      result: 'D60 ఒక్కటితో final తీర్పు ఇవ్వకూడదు; source కూడా కారకాంశ/D1 layersతో కలిపి చూడమంటుంది.',
      rule: 'D60 సూక్ష్మ chart. Birth time sensitivity ఎక్కువ. ప్రతి కారకుడిని D1 మరియు ఇతర evidenceతో కలిపి చూడాలి.',
      inspection: 'D60 chart background evidenceగా మాత్రమే ఉపయోగించాలి.',
      source: 'Sarala Jyotisham Part VII — D60, supplied “Sarala 7 final.pdf” p.18',
      tone: VargaRuleTone.info,
      applicable: true,
      remedy: 'D60లో అశుభ సూచన కనిపించినందుకు మాత్రమే రత్నం/పరిహారం prescribe చేయవద్దు. ఇతర chart evidence + separate remedy source rule అవసరం.',
    );
  }

  static void _appendV50SourceRegistry(
    int factor,
    void Function({
      required String id,
      required String topic,
      required String result,
      required String rule,
      required String inspection,
      required String source,
      required VargaRuleTone tone,
      required bool applicable,
      bool auto,
      String? remedy,
    }) add,
  ) {
    void sourceOnly({
      required String id,
      required String topic,
      required String rule,
      required String source,
      String? remedy,
    }) {
      add(
        id: id,
        topic: topic,
        result: 'ఈ source rule సంబంధిత varga కింద నమోదు అయింది. Exact condition/strength inputs పూర్తిగా match అయినప్పుడు మాత్రమే positive/negative verdict ఇవ్వాలి.',
        rule: rule,
        inspection: 'ఈ chart layer లెక్కించబడింది; source-specific strength/aspect/exception inputs పూర్తిగా validate చేయకుండా auto-result ఇవ్వము.',
        source: source,
        tone: VargaRuleTone.info,
        applicable: false,
        auto: false,
        remedy: remedy,
      );
    }

    switch (factor) {
      case 1:
        sourceOnly(
          id: 'SKM-V50-BASE',
          topic: 'S.K. Mehta — జాతక rule registry',
          rule: 'భావ/గ్రహ బలం, exchange, aspect, dignity, event-wise combinations మరియు timing/synchronizationను విడివిడిగా evidence layersగా పరిశీలించాలి. Exact event result source condition match అయినప్పుడే ఇవ్వాలి.',
          source: 'sk mehatha jyotisha-niyamavali.pdf — 36 pages',
        );
        sourceOnly(
          id: 'BNN-V50-BASE',
          topic: 'Brighu Naadi — Nadi rule registry',
          rule: 'R-A, C, E, F, G, H, I, J, K seriesగా indexed Nadi rulesను D1/Nadi method కింద source IDతో నిల్వ చేసి, exact combination match అయినప్పుడు మాత్రమే resultగా చూపాలి.',
          source: 'Brighu_Naadi_Purnna_Rulebook.pdf — 21 pages',
          remedy: 'ఈ Brighu Nadi source registry entryకి ప్రత్యేక remedy rule attach కాలేదు. Sourceలో remedy స్పష్టంగా ఉన్నప్పుడు మాత్రమే link చేయాలి; ఊహించి పరిహారం ఇవ్వకూడదు.',
        );
        sourceOnly(
          id: 'MED-ORG-V50',
          topic: 'అవయవ / రోగ జ్యోతిష్య సూచికలు',
          rule: 'రాశి/భావ/గ్రహ ఆధారంగా body-part, organ, disease-location indicatorsను source orderలో పరిశీలించాలి. ఇది సంప్రదాయ జ్యోతిష్య సూచిక మాత్రమే; వైద్య నిర్ధారణ కాదు.',
          source: 'avayava_roga_niyamalu.pdf — 24 pages',
          remedy: 'ఈ health rule నుంచి మందు, చికిత్స లేదా diagnosisను app ఇవ్వదు. ఆరోగ్య సమస్య ఉంటే qualified doctor/health professionalను సంప్రదించాలి. జ్యోతిష్య పరిహారం sourceలో స్పష్టంగా ఉంటేనే విడిగా చూపాలి.',
        );
        sourceOnly(
          id: 'MED-ROGA-V50',
          topic: 'Medical Astrology — Roga rule registry',
          rule: 'Medical Astrology sourceలో chapter-wise Rule → result నిర్మాణం ఉంది. సంబంధిత భావ/గ్రహ/లగ్న factors match అయినప్పుడు source ruleను చూపాలి; medical diagnosis/treatment output చేయకూడదు.',
          source: 'medical_roga_rules_complete.pdf — 19 pages',
          remedy: 'Medical Astrology resultను వైద్య సలహాగా ఉపయోగించకూడదు. App మందులు/చికిత్స prescribe చేయదు; అవసరమైతే doctor evaluation తీసుకోవాలి.',
        );
        break;
      case 2:
        sourceOnly(
          id: 'AV-015-V50',
          topic: 'ధనం — 2వ/11వ అష్టకవర్గ support',
          rule: 'Wealth/gains ప్రశ్నలకు 2వ మరియు 11వ భావ bindusను supporting evidenceగా పోల్చాలి; standalone verdictగా ఉపయోగించకూడదు.',
          source: 'Ashtakavarga practical source — Wealth 2nd/11th support',
        );
        break;
      case 3:
        sourceOnly(
          id: 'SK-012-V50',
          topic: 'సహోదరులు / Sibling event',
          rule: '3వ/11వ భావాలు మరియు అవసరమైన derivative-house logicను source ప్రకారం పరిశీలించాలి; ఒకే భావానికి పరిమితం చేయకూడదు.',
          source: 'S.K. Mehta — New Dimensions / Synchronization',
        );
        sourceOnly(
          id: 'AV-017-V50',
          topic: '3వ భావ అష్టకవర్గ support',
          rule: 'Sibling/effort అంశాలకు 3వ భావ SAV/BAV బలం supporting evidenceగా ఉపయోగించాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
      case 4:
        sourceOnly(
          id: 'SK-009-V50',
          topic: 'స్థిరాస్తి / Property-home-vehicle',
          rule: '4వ భావం/అధిపతి conditions, strength, aspects మరియు exchangesను property/home/vehicle evidenceగా ఉపయోగించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        sourceOnly(
          id: 'AV-016-V50',
          topic: '4వ భావ అష్టకవర్గ support',
          rule: 'Property/home/vehicle/mother-related ప్రశ్నలకు 4వ భావ SAV/BAV బలం supporting layerగా ఉపయోగించాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
      case 7:
        sourceOnly(
          id: 'SK-011-V50',
          topic: 'సంతానం promise',
          rule: '5వ భావం/అధిపతి, సంబంధిత గ్రహాలు, strength, affliction/support మరియు source-specific combinationsను పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 9:
        sourceOnly(
          id: 'SK-010-V50',
          topic: 'వివాహ promise',
          rule: '7వ భావం/అధిపతి, relationship planets, strength, aspect, association, exchange మరియు source-specific exceptionsను పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 10:
        sourceOnly(
          id: 'SK-006-V50',
          topic: 'వృత్తి promise',
          rule: 'Profession-related houses/lords, relevant planets, relationships, strength మరియు source combinationsను timingకు ముందు పరిశీలించాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        break;
      case 16:
        sourceOnly(
          id: 'SK-009-X-V50',
          topic: 'వాహనం / సౌకర్యం cross-reference',
          rule: 'Property/home/vehicle ruleలో 4వ భావం/అధిపతి, strength, aspects, exchanges ప్రధాన evidence. D16ను vehicle/comfort cross-checkగా మాత్రమే చూడాలి; source rule D16ని ప్రత్యేకంగా నిర్దేశించకపోతే కొత్త rule సృష్టించరాదు.',
          source: 'S.K. Mehta — Property/home/vehicle rule',
        );
        break;
      case 24:
        sourceOnly(
          id: 'SK-005-V50',
          topic: 'విద్య promise',
          rule: 'Education-related houses/lords, relevant planets, strength, combinations మరియు exceptions పరిశీలించిన తర్వాతే timing చేయాలి.',
          source: 'S.K. Mehta — New Dimensions / New Combinations',
        );
        sourceOnly(
          id: 'AV-014-V50',
          topic: 'Higher education — 5వ/9వ support',
          rule: 'Higher-education సూచనలకు 5వ మరియు 9వ భావ bindusను supporting evidenceగా పోల్చాలి.',
          source: 'Ashtakavarga practical source',
        );
        break;
    }
  }

  static void _beneficMaleficHouseRule({
    required VargaChartData v,
    required int house,
    required String favorableId,
    required String cautionId,
    required String topic,
    required String favorableResult,
    required String cautionResult,
    required String rule,
    required String source,
    required void Function({required String id, required String topic, required String result, required String rule, required String inspection, required String source, required VargaRuleTone tone, required bool applicable, bool auto, String? remedy}) add,
  }) {
    final names = _houseNames(v, house);
    final ben = names.where(_benefics.contains).toList();
    final mal = names.where(_malefics.contains).toList();
    add(
      id: favorableId,
      topic: topic,
      result: ben.isNotEmpty ? favorableResult : '$topic శుభగ్రహ condition auto-match కాలేదు.',
      rule: rule,
      inspection: 'D${v.definition.factor} $houseవ భావంలో ${names.isEmpty ? 'గ్రహాలు లేవు' : names.join(', ')}. శుభగ్రహాలు: ${ben.isEmpty ? 'లేవు' : ben.join(', ')}.',
      source: source,
      tone: VargaRuleTone.favorable,
      applicable: ben.isNotEmpty,
    );
    add(
      id: cautionId,
      topic: topic,
      result: mal.isNotEmpty ? cautionResult : '$topic పాపగ్రహ condition auto-match కాలేదు.',
      rule: rule,
      inspection: 'D${v.definition.factor} $houseవ భావంలో పాపగ్రహాలు: ${mal.isEmpty ? 'లేవు' : mal.join(', ')}.',
      source: source,
      tone: VargaRuleTone.caution,
      applicable: mal.isNotEmpty,
    );
  }

  static int _houseSign(VargaChartData v, int house) =>
      (v.ascendantSignIndex + house - 1) % 12;

  static int _houseOf(VargaChartData v, VargaPlacement p) =>
      ((p.signIndex - v.ascendantSignIndex + 12) % 12) + 1;

  static List<String> _houseNames(VargaChartData v, int house) {
    final sign = _houseSign(v, house);
    return v.planets.where((p) => p.signIndex == sign).map((p) => p.name).toList(growable: false);
  }

  static String _signLord(int sign) => switch (sign % 12) {
        0 || 7 => 'Mars',
        1 || 6 => 'Venus',
        2 || 5 => 'Mercury',
        3 => 'Moon',
        4 => 'Sun',
        8 || 11 => 'Jupiter',
        9 || 10 => 'Saturn',
        _ => 'Sun',
      };

  static bool _isExalted(String planet, int sign) {
    const exalt = {
      'Sun': 0,
      'Moon': 1,
      'Mars': 9,
      'Mercury': 5,
      'Jupiter': 3,
      'Venus': 11,
      'Saturn': 6,
    };
    return exalt[planet] == sign;
  }

  static String _remedyText(VargaRuleTone tone) => switch (tone) {
        VargaRuleTone.favorable =>
          'ఈ sourceలో ప్రత్యేక పరిహారం అవసరం అని చెప్పలేదు. అనుకూల బలాన్ని timing/ప్రాక్టికల్ చర్యలతో ఉపయోగించండి.',
        VargaRuleTone.caution =>
          'ఈ varga sourceలో ప్రత్యేక remedy prescription లేదు. ముందుగా practical correction చేయాలి. రత్నం/గ్రహ పరిహారం ఇవ్వాలంటే supplied Gemstone Remedy rule-engine eligibilityని విడిగా పరీక్షించాలి; automatic gemstone ఇవ్వవద్దు.',
        VargaRuleTone.neutral =>
          'ఇది పరిశీలన layer. Sourceలో ప్రత్యేక పరిహారం ఇవ్వలేదు; ఇతర chart evidenceతో కలిపి నిర్ణయించాలి.',
        VargaRuleTone.info =>
          'ఈ rule source-only. Exact condition పూర్తిగా validate అయ్యే వరకు పరిహారం auto-generate చేయరాదు.',
      };
}
