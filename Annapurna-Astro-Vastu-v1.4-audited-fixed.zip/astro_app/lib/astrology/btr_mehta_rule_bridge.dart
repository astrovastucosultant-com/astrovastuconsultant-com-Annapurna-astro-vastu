import 'astro_models.dart';
import 'mehta_combination_service.dart';

/// Connects source catalog rule IDs to independently evaluated natal conditions.
/// Catalog ND records are textual and are NEVER auto-validated or scored.
/// Only a documented R### rule with a matching book:<number> evaluator can
/// contribute to the candidate comparison. Never mistake a topic link for a hit.
class BtrMehtaSourceCheck {
  final String? ruleId;
  final bool evaluated;
  final bool matched;
  final String explanation;
  final String? source;
  const BtrMehtaSourceCheck({this.ruleId, required this.evaluated,
    required this.matched, required this.explanation, this.source});
}

class BtrMehtaRuleBridge {
  static const Map<String, String> eventTopics = <String, String>{
    'M01':'marriage', 'M02':'marriage', 'M03':'other',
    'M04':'foreign', 'M05':'foreign', 'M06':'child',
    'M07':'property', 'M08':'property', 'M11':'promotion',
    'M12':'job', 'M13':'job', 'M14':'business',
  };

  static String topicForEvent(String id) => eventTopics[id] ?? 'other';

  static int? ruleNumber(String? sourceId) {
    if (sourceId == null || !RegExp(r'^R\d{3}$').hasMatch(sourceId)) return null;
    final value = int.tryParse(sourceId.substring(1));
    return value != null && value >= 1 && value <= 85 ? value : null;
  }

  /// Use one evaluated result map per candidate; avoid 291 textual rules
  /// becoming 291 imagined calculated matches.
  static Map<int, MehtaCombinationMatch> evaluatedBookRules(AstroChartResult chart) {
    final result = <int, MehtaCombinationMatch>{};
    for (final match in MehtaCombinationService.evaluateAll(chart)) {
      if (!match.rule.key.startsWith('book:') || !match.rule.autoEvaluated ||
          match.rule.sensitive) continue;
      final id = int.tryParse(match.rule.key.substring(5));
      if (id != null && id >= 1 && id <= 85) result[id] = match;
    }
    return result;
  }

  static BtrMehtaSourceCheck inspect(String? id,
      Map<int, MehtaCombinationMatch> evaluated) {
    if (id == null || id.isEmpty) {
      return const BtrMehtaSourceCheck(evaluated: false, matched: false,
        explanation:'సంఘటనకు ప్రత్యేక మూలగ్రంథ రూల్ ఎంపిక చేయలేదు.');
    }
    final number = ruleNumber(id);
    if (number == null) {
      return BtrMehtaSourceCheck(ruleId:id, evaluated:false, matched:false,
        explanation:'ఈ రూల్‌కు ధృవీకరించిన యాంత్రిక జాతక పరీక్ష లేదు. మూలగ్రంథం ఆధారంగా స్వయంగా పరిశీలించాలి.');
    }
    final row = evaluated[number];
    if (row == null) {
      return BtrMehtaSourceCheck(ruleId:id, evaluated:false, matched:false,
        explanation:'ఈ $id రూల్‌కు appలో నమ్మదగిన స్వయంచాలక పరీక్ష అందుబాటులో లేదు; నిర్ణయ సూచికలో చేర్చలేదు.');
    }
    return BtrMehtaSourceCheck(ruleId:id, evaluated:true,
      matched:row.matched, source:'SK Mehta — New Rules and Combinations',
      explanation:'${row.rule.ruleText}\nజాతక పరీక్ష: ${row.logic}\n'
        '${row.matched ? 'షరతు సరిపోయింది' : 'షరతు సరిపోలలేదు'}');
  }
}
