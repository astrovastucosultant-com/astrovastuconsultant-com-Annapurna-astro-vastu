class PlanetPosition {
  final String name;
  final String shortName;
  final double longitude;
  final double latitude;
  final double speed;

  const PlanetPosition({
    required this.name,
    required this.shortName,
    required this.longitude,
    required this.latitude,
    required this.speed,
  });

  int get signIndex => (longitude / 30).floor() % 12;
  double get degreesInSign => longitude % 30;
  bool get retrograde => speed < 0;
}

class AstroChartResult {
  final double julianDay;
  final double ayanamsaDegrees;
  final double ascendantLongitude;
  final List<PlanetPosition> planets;
  final String engineVersion;

  const AstroChartResult({
    required this.julianDay,
    required this.ayanamsaDegrees,
    required this.ascendantLongitude,
    required this.planets,
    required this.engineVersion,
  });

  int get ascendantSignIndex => (ascendantLongitude / 30).floor() % 12;
}
