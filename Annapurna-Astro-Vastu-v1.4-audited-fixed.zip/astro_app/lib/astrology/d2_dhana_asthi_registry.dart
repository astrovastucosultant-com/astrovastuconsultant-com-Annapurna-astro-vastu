class D2DhanaAsthiRule {
  final String id, groupCode, group, name, sourceChart, condition, result, note;
  final int sourcePage;
  const D2DhanaAsthiRule({required this.id, required this.groupCode, required this.group, required this.name, required this.sourceChart, required this.condition, required this.result, required this.sourcePage, this.note = ''});
}

class D2DhanaAsthiRegistry {
  static const sourceFilename = 'Dhana_Aasthi_Rules.pdf';
  static const sourcePages = 7;
  static const remedy = 'ఈ PDFలో ఈ నియమానికి ప్రత్యేక పరిహారం ఇవ్వలేదు.';
  static const sourceCaveat = 'మూల నియమాలు D1 రాశి, ఇందు లగ్నం, మండూక హోరా, D2 హోరా మరియు D4 చతుర్థాంశాన్ని ఉపయోగిస్తాయి. ప్రతి నియమాన్ని D2 planetary positions నుంచే evaluate చేయకూడదు.';
  static const calculationCaveat = 'ఈ rule browser స్వతంత్రంగా జాతకం/శాతాలు గణించదు. సంబంధిత chart engine conditionను ఖచ్చితంగా match చేసినప్పుడు మాత్రమే వ్యక్తిగత ఫలితం చూపాలి.';
  static const induAlgorithm = <String>[
    'జన్మ లగ్నం నుంచి 9వ భావాధిపతిని గుర్తించాలి',
    'చంద్ర రాశి నుంచి 9వ భావాధిపతిని గుర్తించాలి',
    'ఆ ఇద్దరి కళా విలువలను కలపాలి',
    '12తో భాగించి శేషం తీసుకోవాలి; శేషం 0 అయితే 12గా తీసుకోవాలి',
    'చంద్ర రాశి నుంచి అంత రాశులు కలుపుకొని ఇందు లగ్నం నిర్ణయించాలి',
  ];
  static const kalaValues = <String,int>{'Sun':30,'Moon':16,'Mars':6,'Mercury':8,'Jupiter':10,'Venus':12,'Saturn':1};

  static const rules = <D2DhanaAsthiRule>[
    D2DhanaAsthiRule(id:'D2-ST-001',groupCode:'ST',group:'మొత్తం ధనస్థాయి',name:'మహా కోటీశ్వర స్థాయి',sourceChart:'ఇందు లగ్నం + D1',condition:'ఇందు లగ్నంలో శుభగ్రహం ఉండి పాపగ్రహ కలయిక, పాపదృష్టి లేకపోవాలి; లేదా ఇందు లగ్నంలో ఉన్న పాపగ్రహం ఉచ్చస్థితిలో ఉండాలి. ఇందు లగ్నం నుంచి 2, 5, 9, 11 అధిపతుల్లో కనీసం ఇద్దరు బలంగా పరస్పర సంబంధం కలిగి ఉండాలి; 6, 8, 12 అధిపతుల అననుకూల సంబంధం ఉండకూడదు.',result:'మహా కోటీశ్వర స్థాయిని సూచించే సంప్రదాయ నియమం.',sourcePage:1,note:'బహుళ షరతులను కలిపి పరిశీలించాలి; వాస్తవ సంపదకు హామీ కాదు.'),
    D2DhanaAsthiRule(id:'D2-ST-002',groupCode:'ST',group:'మొత్తం ధనస్థాయి',name:'కోటీశ్వర స్థాయి',sourceChart:'ఇందు లగ్నం + D1',condition:'ఇందు లగ్నం నుంచి ధనయోగం ఉండాలి; మహా కోటీశ్వర స్థాయికి అవసరమైన ఇందు లగ్న శుభస్థితి పూర్తి కాకపోవచ్చు. లేదా రాశి ధనయోగం బలంగా ఉండాలి.',result:'కోటీశ్వర స్థాయిని సూచించే సంప్రదాయ నియమం.',sourcePage:1),
    D2DhanaAsthiRule(id:'D2-ST-003',groupCode:'ST',group:'మొత్తం ధనస్థాయి',name:'లక్షాధికారి స్థాయి',sourceChart:'ఇందు లగ్నం + D1',condition:'ఇందు లగ్నంలో పాపి ఉండి ఉచ్చస్థితిలో లేకపోవాలి; గట్టి ధనయోగం లేకపోవాలి లేదా ధనయోగ కారకగ్రహం బలహీనంగా ఉండాలి.',result:'కష్టంతో సంపాదించే స్థాయిని సూచిస్తుంది.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-ST-004',groupCode:'ST',group:'మొత్తం ధనస్థాయి',name:'ధనం నిలవని స్థాయి',sourceChart:'ఇందు లగ్నం + D1',condition:'ఇందు ధనయోగానికి 6, 8 లేదా 12వ అధిపతి అననుకూల సంబంధం ఉండాలి; లేదా ఇందు లగ్నాధిపతి 3, 6, 8, 12లో శుభ సంబంధం లేకుండా ఉండాలి. రాశిలోనూ తగిన ధనయోగం లేకపోవాలి.',result:'ఆదాయం వచ్చినా నిల్వ కష్టమయ్యే సూచన.',sourcePage:2),

    D2DhanaAsthiRule(id:'D2-IN-001',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'ఎక్కువ ధనం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నంలో శుభగ్రహం ఉండి పాపగ్రహ కలయిక, పాపదృష్టి లేకపోవాలి.',result:'మొత్తం ధనం ఎక్కువగా ఉండే సూచన.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-002',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'ఉచ్చు ధనం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నంలో పాపగ్రహం ఉచ్చస్థితిలో ఉండాలి.',result:'ఎక్కువ ధనం సూచించవచ్చు; కష్టపడాల్సి రావచ్చు.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-003',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'సామాన్య ధనం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నంలో పాపగ్రహం ఉండి ఉచ్చస్థితిలో లేకపోవాలి.',result:'సామాన్య ధనస్థాయి; శ్రమ సూచన.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-004',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'పాప దృష్టి ప్రభావం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నంపై పాపగ్రహ దృష్టి ఉండాలి.',result:'ధనసంబంధ ఇబ్బంది/తగ్గుదల సూచన; పాపగ్రహ స్థితిని కూడా చూడాలి.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-005',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'ఇందు ధనయోగం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నం నుంచి 2, 5, 9, 11 స్థానాధిపతుల్లో కనీసం ఇద్దరికి పరస్పర సంబంధం ఉండి వారు బలంగా ఉండాలి.',result:'ఇందు లగ్న ధనయోగం.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-006',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'ధనం పోవటం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు ధనయోగానికి 6, 8 లేదా 12 అధిపతి సంబంధం ఏర్పడాలి.',result:'ధన నిల్వకు ఆటంకం; అప్పు లేదా ఇతర భారం సూచన.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-007',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'ధన స్థానాల్లో గ్రహాలు',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నం నుంచి 1, 2, 4, 10 లేదా 11 స్థానాల్లో గ్రహాలుండాలి.',result:'సంబంధిత గ్రహదశల్లో ధనం సమకూరే సూచన.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-008',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'నష్ట స్థానాల్లో గ్రహాలు',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నం నుంచి 3, 6, 8 లేదా 12 స్థానాల్లో గ్రహాలుండాలి; ఇందు లగ్నాధిపతి అక్కడ ఉంటే మరింత పరిశీలన అవసరం.',result:'ఆ గ్రహదశల్లో ధన నష్టం లేదా ఆటంకం సూచన.',sourcePage:2,note:'ఇది గ్రహదశల ఫలితానికి; తేదీ గణన వేరుగా అవసరం.'),
    D2DhanaAsthiRule(id:'D2-IN-009',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'రాహు–కేతు ధనం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నంలో రాహు లేదా కేతువు ఉండాలి; వారి అధిపతుల బలం/బలహీనతను కూడా తనిఖీ చేయాలి.',result:'రాహు/కేతు దశలో ధన అవకాశం; అధిపతి బలహీనమైతే ధనం రాకపోవచ్చు.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-010',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'ఉపచయ ధనం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నం బలంగా ఉండి దాని నుంచి 3, 6, 10 లేదా 11లో గ్రహాలు ఉండాలి.',result:'ధనం వృద్ధి చెందే సూచన.',sourcePage:2),
    D2DhanaAsthiRule(id:'D2-IN-011',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'ఆదాయ మార్గ పరిశీలన',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నాధిపతి ఏ భావంలో ఉన్నాడో గుర్తించి ఆ భావార్థాన్ని చూడాలి.',result:'ఆదాయ మార్గానికి సంబంధించిన సూచన.',sourcePage:2,note:'ఇది పరిశీలనా నియమం; ఫలితాన్ని భావానుసారంగా వేరుగా నిర్వచించాలి.'),
    D2DhanaAsthiRule(id:'D2-IN-012',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'అదృష్ట ధనం',sourceChart:'ఇందు లగ్నం',condition:'ఇందు లగ్నం నుంచి 9వ భావానికి శుభసంబంధం ఉండాలి లేదా బలమైన పాపగ్రహం ఉండాలి.',result:'అదృష్ట ద్వారా ధనం సూచన.',sourcePage:3),
    D2DhanaAsthiRule(id:'D2-IN-013',groupCode:'IN',group:'ఇందు లగ్నం వివరాలు',name:'గోచార లాభం',sourceChart:'ఇందు లగ్నం + గోచారం',condition:'గోచార గ్రహాలు ఇందు లగ్నం నుంచి 3, 6, 10 లేదా 11లో ఉండాలి.',result:'ఆ గోచార కాలంలో లాభ సూచన.',sourcePage:3,note:'గోచార ఫలితం ఇచ్చేందుకు తేదీ–సమయం ఆధారిత గోచార గణన అవసరం.'),

    D2DhanaAsthiRule(id:'D2-DY-001',groupCode:'DY',group:'రాశి ధనయోగం',name:'ధనయోగం',sourceChart:'D1 రాశి',condition:'2వ అధిపతి, 11వ అధిపతికి సంబంధం ఉండాలి; లేదా 2, 5, 9, 11 స్థానాధిపతుల్లో ఇద్దరి పరస్పర సంబంధం ఉండాలి.',result:'ధనయోగం.',sourcePage:3),
    D2DhanaAsthiRule(id:'D2-DY-002',groupCode:'DY',group:'రాశి ధనయోగం',name:'బలమైన ధనయోగం',sourceChart:'D1 రాశి',condition:'2వ, 11వ అధిపతులకు పరివర్తన ఉండాలి; లేదా 2, 5, 9, 11 అధిపతుల్లో ముగ్గురు కలిసి బలంగా ఉండాలి.',result:'బలమైన ధనయోగం.',sourcePage:3),
    D2DhanaAsthiRule(id:'D2-LB-001',groupCode:'LB',group:'లాభం / మండూక హోరా',name:'లాభయోగం',sourceChart:'మండూక హోరా',condition:'మండూక హోరాలో 2వ, 11వ అధిపతులకు సంబంధం ఉండాలి; లేదా 11వ భావంలో కనీసం రెండు గ్రహాలు ఉండాలి.',result:'లాభం ఉండే సూచన.',sourcePage:3,note:'మండూక హోరా D2 పరాశరీ సూర్య–చంద్ర హోరాతో ఒకటేనని భావించకూడదు.'),
    D2DhanaAsthiRule(id:'D2-LB-002',groupCode:'LB',group:'లాభం / మండూక హోరా',name:'లాభం నిలవకపోవటం',sourceChart:'మండూక హోరా',condition:'మండూక హోరాలో 11వ అధిపతి 12వ భావంలో ఉండాలి.',result:'లాభం వచ్చినా నిల్వ కష్టమయ్యే సూచన.',sourcePage:3),

    D2DhanaAsthiRule(id:'D2-CS-001',groupCode:'CS',group:'నగదు / ధన నిల్వ',name:'నగదు నిల్వ',sourceChart:'D1 రాశి',condition:'2వ లేదా 11వ అధిపతి బలంగా ఉండి 12వ భావంలో లేకపోవాలి.',result:'నగదు నిల్వ ఉండే సూచన.',sourcePage:3),
    D2DhanaAsthiRule(id:'D2-CS-002',groupCode:'CS',group:'నగదు / ధన నిల్వ',name:'ద్రవ నగదు',sourceChart:'D1 రాశి',condition:'చంద్రుడు 2వ లేదా 11వ భావంలో ఉండి పాపదృష్టి లేకపోవాలి.',result:'ద్రవ నగదు ఉండే సూచన.',sourcePage:3),
    D2DhanaAsthiRule(id:'D2-CS-003',groupCode:'CS',group:'నగదు / ధన నిల్వ',name:'నగదు నిలవకపోవటం',sourceChart:'D1 రాశి',condition:'2వ అధిపతి 12వ భావంలో ఉండి శుభ సంబంధం లేకపోవాలి.',result:'నగదు నిల్వకు ఆటంకం.',sourcePage:3),
    D2DhanaAsthiRule(id:'D2-CS-004',groupCode:'CS',group:'నగదు / ధన నిల్వ',name:'నిల్వ బలం — చంద్ర హోరా',sourceChart:'D2 హోరా',condition:'హోరాలో 2వ అధిపతి చంద్ర హోరాలో ఉండాలి.',result:'నగదు నిల్వ బలంగా ఉండే సూచన.',sourcePage:3,note:'మూల PDFలో ఉపయోగించిన హోరా నిర్వచనాన్ని అమలులో ఎంచుకున్న హోరా పద్ధతితో నిర్ధారించాలి.'),
    D2DhanaAsthiRule(id:'D2-CS-005',groupCode:'CS',group:'నగదు / ధన నిల్వ',name:'నిల్వ బలహీనం — రవి హోరా',sourceChart:'D2 హోరా',condition:'హోరాలో 2వ అధిపతి రవి హోరాలో మాత్రమే ఉండాలి.',result:'నగదు రావచ్చు; నిల్వ బలహీనంగా ఉండే సూచన.',sourcePage:3,note:'హోరా పద్ధతి / 2వ అధిపతి అర్థం మూల నిర్వచనంతో ధృవీకరించాలి.'),

    D2DhanaAsthiRule(id:'D2-GD-001',groupCode:'GD',group:'బంగారం / వెండి / నగలు',name:'బంగారం / నగలు',sourceChart:'D1 రాశి',condition:'గురుడు 2వ భావంతో సంబంధం కలిగి ఉండాలి; లేదా రవి 2వ భావంలో బలంగా ఉండాలి.',result:'బంగారం, నగలు ఉండే సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-GD-002',groupCode:'GD',group:'బంగారం / వెండి / నగలు',name:'వెండి / ముత్యాలు',sourceChart:'D1 రాశి',condition:'చంద్రుడు 2వ భావంలో బలంగా ఉండాలి.',result:'వెండి, ముత్యాలు ఉండే సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-GD-003',groupCode:'GD',group:'బంగారం / వెండి / నగలు',name:'విలాస నగలు',sourceChart:'D1 రాశి',condition:'శుక్రుడు 2వ లేదా 4వ భావంలో బలంగా ఉండాలి.',result:'విలాసవంతమైన నగలు ఉండే సూచన.',sourcePage:4),

    D2DhanaAsthiRule(id:'D2-PR-001',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'స్థిరాస్తి',sourceChart:'D1 రాశి',condition:'4వ అధిపతి కేంద్రం లేదా త్రికోణంలో బలంగా ఉండాలి.',result:'స్థిరాస్తి ఉండే సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-002',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'సొంత ఇల్లు',sourceChart:'D1 రాశి',condition:'4వ భావంలో గురుడు, శుక్రుడు లేదా బుధుడు ఉండి పాప కలయిక లేకపోవాలి; లేదా 4వ అధిపతి కేంద్రం/త్రికోణంలో బలంగా ఉండాలి.',result:'సొంత ఇల్లు ఉండే సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-003',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'భూమి',sourceChart:'D1 రాశి',condition:'కుజుడు 4వ భావంతో సంబంధం కలిగి బలంగా ఉండాలి.',result:'భూమి ఉండే సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-004',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'పాత ఇల్లు',sourceChart:'D1 రాశి',condition:'శని 4వ భావంతో సంబంధం కలిగి బలంగా ఉండాలి.',result:'పాత ఇల్లు; ఆలస్యంతో సమకూరే సూచన.',sourcePage:4,note:'4వ భావంలో శని ఉన్నంత మాత్రాన ఇల్లు లేదని చెప్పకూడదు.'),
    D2DhanaAsthiRule(id:'D2-PR-005',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'స్థిరాస్తి లేకపోవటం',sourceChart:'D1 రాశి',condition:'4వ అధిపతి 6, 8 లేదా 12లో ఉండి శుభదృష్టి లేకపోవాలి.',result:'సొంత స్థిరాస్తి లేకపోవటం సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-006',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'ఇల్లు ఆలస్యం',sourceChart:'D4 చతుర్థాంశం',condition:'చతుర్థాంశంలో 4వ అధిపతి బలహీనంగా ఉండాలి.',result:'ఇల్లు సమకూరటంలో ఆలస్యం సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-007',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'ఆస్తి ధృవీకరణ',sourceChart:'D4 చతుర్థాంశం',condition:'చతుర్థాంశంలో 4వ అధిపతి కేంద్రం లేదా త్రికోణంలో ఉండాలి.',result:'ఇల్లు, భూమి సమకూరే సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-008',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'ఆస్తి ద్వారా ధనం',sourceChart:'D1 రాశి',condition:'4వ అధిపతి 2వ భావంలో ఉండాలి.',result:'ఇల్లు లేదా భూమి ద్వారా ధనం వచ్చే సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-009',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'ఆస్తి విడిచిపెట్టడం',sourceChart:'D1 రాశి',condition:'కేతువు 4వ భావంలో ఉండి శుభదృష్టి లేకపోవాలి.',result:'పాత ఆస్తి/ఇంటి నుంచి దూరం కావటం సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-010',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'ఇంటి తగాదాలు',sourceChart:'D1 రాశి',condition:'4వ భావంలో రాహువు ఉండి గురుదృష్టి లేకపోవాలి.',result:'ఇంటి విషయంలో తగాదాలు, అనిశ్చితి సూచన.',sourcePage:4),
    D2DhanaAsthiRule(id:'D2-PR-011',groupCode:'PR',group:'స్థిరాస్తి / ఇల్లు / భూమి',name:'ఆస్తి కొనుగోలు కాలం',sourceChart:'D1 రాశి + దశ',condition:'4, 9 లేదా 11వ అధిపతుల దశ నడుస్తూ ఉండాలి.',result:'ఇల్లు లేదా భూమి కొనుగోలుకు అవకాశమున్న కాలాన్ని పరిశీలించాలి.',sourcePage:4,note:'నిర్దిష్ట తేదీకి దశ–అంతర్దశ ఇంజిన్ మరియు D4 ధృవీకరణ అవసరం.'),

    D2DhanaAsthiRule(id:'D2-IH-001',groupCode:'IH',group:'తల్లి–తండ్రి వైపు ఆస్తి / వారసత్వం',name:'తల్లి వైపు ఆస్తి',sourceChart:'D1 రాశి + చంద్ర లగ్నం',condition:'చంద్రుడికి 4వ భావంతో సంబంధం ఉండి బలంగా ఉండాలి; లేదా చంద్రరాశి నుంచి 4వ అధిపతి కేంద్రం లేదా త్రికోణంలో ఉండాలి.',result:'తల్లి వైపు నుంచి ఆస్తి సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-IH-002',groupCode:'IH',group:'తల్లి–తండ్రి వైపు ఆస్తి / వారసత్వం',name:'తల్లి ఆస్తి తగాదా',sourceChart:'D1 రాశి',condition:'చంద్రుడు 5వ భావంలో ఉండి 4వ భావంపై పాపదృష్టి ఉండాలి.',result:'తల్లి వైపు ఆస్తి విషయంలో తగాదా సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-IH-003',groupCode:'IH',group:'తల్లి–తండ్రి వైపు ఆస్తి / వారసత్వం',name:'తండ్రి వైపు ఆస్తి',sourceChart:'D1 రాశి',condition:'9వ అధిపతికి 4వ భావంతో సంబంధం ఉండాలి; లేదా రవి 4వ భావంలో బలంగా ఉండాలి; లేదా 4వ అధిపతి 9వ భావంలో ఉండాలి.',result:'తండ్రి వైపు నుంచి ఆస్తి సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-IH-004',groupCode:'IH',group:'తల్లి–తండ్రి వైపు ఆస్తి / వారసత్వం',name:'తండ్రి ఆస్తి ఆలస్యం',sourceChart:'D1 రాశి',condition:'9వ అధిపతి 8 లేదా 12లో ఉండి శుభదృష్టి లేకపోవాలి.',result:'తండ్రి వైపు ఆస్తి సమకూరటంలో ఆలస్యం సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-IH-005',groupCode:'IH',group:'తల్లి–తండ్రి వైపు ఆస్తి / వారసత్వం',name:'వారసత్వ ధనం',sourceChart:'D1 రాశి + ఇందు లగ్నం',condition:'ఇందు లగ్నం నుంచి 8వ అధిపతికి ఇందు లగ్నం నుంచి 2, 5, 9 లేదా 11వ అధిపతితో సంబంధం ఉండాలి.',result:'వారసత్వ ధన అవకాశం.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-IH-006',groupCode:'IH',group:'తల్లి–తండ్రి వైపు ఆస్తి / వారసత్వం',name:'వారసత్వ ఇల్లు',sourceChart:'D1 రాశి + ఇందు లగ్నం',condition:'ఇందు లగ్నం బలంగా ఉండి ఇందు లగ్నం నుంచి 8వ అధిపతికి 4వ భావంతో సంబంధం ఉండాలి. చంద్రసంబంధం ఉంటే తల్లి వైపు; రవి లేదా 9వ అధిపతితో సంబంధం ఉంటే తండ్రి వైపు పరిశీలించాలి.',result:'వారసత్వంగా ఇల్లు/ఆస్తి సూచన.',sourcePage:5),

    D2DhanaAsthiRule(id:'D2-VH-001',groupCode:'VH',group:'వాహనాలు',name:'విలాసవంతమైన వాహనం',sourceChart:'D1 రాశి',condition:'శుక్రుడు 4వ భావంలో ఉచ్చ/స్వక్షేత్రంలో ఉండాలి; 4వ అధిపతి కూడా బలంగా ఉండాలి.',result:'విలాసవంతమైన వాహన సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-VH-002',groupCode:'VH',group:'వాహనాలు',name:'సాధారణ వాహనం',sourceChart:'D1 రాశి',condition:'శుక్రుడికి 4వ భావంతో సంబంధం ఉండి మధ్యస్థ బలం ఉండాలి.',result:'సాధారణ వాహన సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-VH-003',groupCode:'VH',group:'వాహనాలు',name:'ఎక్కువ వాహనాలు',sourceChart:'D1 రాశి',condition:'4వ భావంలో రెండు లేదా అంతకంటే ఎక్కువ గ్రహాలు ఉండాలి; లేదా శుక్రుడు బలంగా ఉండి 11వ భావంతో సంబంధం ఉండాలి.',result:'ఒకటికంటే ఎక్కువ వాహనాల సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-VH-004',groupCode:'VH',group:'వాహనాలు',name:'వేగవంతమైన వాహనం',sourceChart:'D1 రాశి',condition:'కుజుడు 4వ భావంలో బలంగా ఉండాలి.',result:'వేగవంతమైన వాహనం; జాగ్రత్త అవసరమని సంప్రదాయ సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-VH-005',groupCode:'VH',group:'వాహనాలు',name:'పాత వాహనం',sourceChart:'D1 రాశి',condition:'శనికి 4వ భావంతో సంబంధం ఉండి బలహీనంగా ఉండాలి.',result:'పాత వాహనం లేదా ఆలస్యంగా వాహనం సమకూరే సూచన.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-VH-006',groupCode:'VH',group:'వాహనాలు',name:'వాహనం లేకపోవటం',sourceChart:'D1 రాశి',condition:'4వ అధిపతి 6, 8 లేదా 12లో ఉండి శుక్రుడు బలహీనంగా ఉండాలి.',result:'సొంత వాహనం లేకపోవటాన్ని సూచించే సంప్రదాయ నియమం.',sourcePage:5),
    D2DhanaAsthiRule(id:'D2-VH-007',groupCode:'VH',group:'వాహనాలు',name:'వాహన ఆలస్యం',sourceChart:'D16 షోడశాంశం (user-corrected confirmation layer)',condition:'D16 షోడశాంశంలో శుక్రుడు బలహీనంగా ఉండాలి; D1లోని 4వ భావం/శుక్ర vehicle promiseతో కలిపి పరిశీలించాలి.',result:'వాహనం సమకూరటంలో ఆలస్యం సూచన.',sourcePage:5,note:'మూల transcriptionలో D4గా నమోదైంది; user correction ప్రకారం vehicle confirmationను D16లో అమలు చేస్తున్నాం. D4ను స్థిరాస్తి/ఇల్లు/భూమికి ఉంచాలి.'),

    D2DhanaAsthiRule(id:'D2-OT-001',groupCode:'OT',group:'ఇతర ధన–ఆస్తి సూచనలు',name:'వ్యాపార చొరవ',sourceChart:'D1 రాశి',condition:'7వ లేదా 10వ అధిపతికి బుధుడితో సంబంధం ఉండాలి.',result:'వ్యాపార చొరవ సూచన.',sourcePage:6),
    D2DhanaAsthiRule(id:'D2-OT-002',groupCode:'OT',group:'ఇతర ధన–ఆస్తి సూచనలు',name:'పెట్టుబడి లాభం',sourceChart:'D1 రాశి',condition:'5వ అధిపతి 11వ భావంలో బలంగా ఉండాలి.',result:'పెట్టుబడి లాభ అవకాశం.',sourcePage:6,note:'ఫలితం పేరు “పెట్టుబడి లాభం” మాత్రమే ఉంచాలి.'),
    D2DhanaAsthiRule(id:'D2-OT-003',groupCode:'OT',group:'ఇతర ధన–ఆస్తి సూచనలు',name:'పెట్టుబడి నష్టం',sourceChart:'D1 రాశి',condition:'5వ అధిపతి 8 లేదా 12లో ఉండి పాపదృష్టి కలిగి ఉండాలి.',result:'పెట్టుబడి నష్ట సూచన.',sourcePage:6),
    D2DhanaAsthiRule(id:'D2-OT-004',groupCode:'OT',group:'ఇతర ధన–ఆస్తి సూచనలు',name:'విదేశ ఇల్లు',sourceChart:'D1 రాశి',condition:'4వ అధిపతి 9 లేదా 12వ భావంలో రాహువుతో కలిసి ఉండాలి.',result:'విదేశంలో ఇల్లు సమకూరే సూచన.',sourcePage:6),
    D2DhanaAsthiRule(id:'D2-OT-005',groupCode:'OT',group:'ఇతర ధన–ఆస్తి సూచనలు',name:'విదేశ నగదు',sourceChart:'D1 రాశి',condition:'11వ అధిపతి 12వ భావంలో బలంగా ఉండాలి.',result:'విదేశ సంబంధిత నగదు సూచన.',sourcePage:6),
  ];
}
