import 'astro_models.dart';
import 'ashtakavarga_service.dart';

enum AvFindingTone { favorable, unfavorable, neutral, pending }

class AvJatakaFinding {
  final int order;
  final String category;
  final String item;
  final String result;
  final String rule;
  final String inspection;
  final String ruleId;
  final String source;
  final AvFindingTone tone;

  const AvJatakaFinding({
    required this.order,
    required this.category,
    required this.item,
    required this.result,
    required this.rule,
    required this.inspection,
    required this.ruleId,
    required this.source,
    required this.tone,
  });
}

/// Source-driven Ashtakavarga interpretation layer.
///
/// The arithmetic uses the verified BAV/SAV engine.  The interpretive rules
/// below are restricted to conditions that can be evaluated exactly from the
/// currently available SAV/BAV data.  Rules that need Shodhana/Pinda/current
/// transit engines are intentionally not guessed here.
class AshtakavargaInterpretationService {
  static const List<String> _houseTopics = [
    'లగ్నం / జాతకుడు',
    'ధనం / కుటుంబం',
    'విక్రమం / సోదరులు',
    'స్థిరాస్తి / సుఖం',
    'విద్య / సంతానం',
    'సేవ / ఋణ-రోగ సూచన',
    'వివాహం / భాగస్వామ్యం',
    'మార్పులు / ఆయుర్దాయ సూచన',
    'భాగ్యం / ధర్మం',
    'వృత్తి / స్థానం',
    'లాభం / ఆదాయం',
    'వ్యయం / విదేశం',
  ];

  static List<AvJatakaFinding> evaluate({
    required AstroChartResult chart,
    required AshtakavargaResult av,
  }) {
    final lagna = chart.ascendantSignIndex;
    int h(int house) => av.sarva[(lagna + house - 1) % 12];
    int sum(Iterable<int> houses) => houses.fold(0, (s, x) => s + h(x));

    final out = <AvJatakaFinding>[];
    var order = 0;

    void add({
      required String category,
      required String item,
      required String result,
      required String rule,
      required String inspection,
      required String ruleId,
      required String source,
      required AvFindingTone tone,
    }) {
      out.add(AvJatakaFinding(
        order: order++,
        category: category,
        item: item,
        result: result,
        rule: rule,
        inspection: inspection,
        ruleId: ruleId,
        source: source,
        tone: tone,
      ));
    }

    // 1) Core verification.
    add(
      category: 'గణన ధృవీకరణ',
      item: 'SAV మొత్తం',
      result: av.totalsValid
          ? 'SAV/BAV స్థిర మొత్తాల ధృవీకరణ సరైంది.'
          : 'SAV/BAV స్థిర మొత్తాల ధృవీకరణలో తేడా ఉంది; ఫలితాలను ఉపయోగించే ముందు గణనను చెక్ చేయాలి.',
      rule: '7 BAV rows మొత్తం SAV; classical fixed grand total = 337. ప్రతి గ్రహ BAV స్థిర మొత్తం కూడా తన expected totalతో సరిపోవాలి.',
      inspection: 'ఈ జాతకంలో SAV grand total = ${av.grandTotal}.',
      ruleId: 'W1.5 / Core validation',
      source: 'Ashtakavarga rule-based source — BAV/PAV/SAV verification section',
      tone: av.totalsValid ? AvFindingTone.favorable : AvFindingTone.unfavorable,
    );

    // 2) Every house, in order. The source uses 30+ as strong and below 25 as weak
    // in multiple SAV result/yoga rules; 25-29 is therefore shown as middle.
    for (var house = 1; house <= 12; house++) {
      final score = h(house);
      final tone = score >= 30
          ? AvFindingTone.favorable
          : score < 25
              ? AvFindingTone.unfavorable
              : AvFindingTone.neutral;
      final result = score >= 30
          ? 'ఈ భావం బలంగా ఉంది; అనుకూల ఫలితాలకు మద్దతు ఎక్కువ.'
          : score < 25
              ? 'ఈ భావం బలహీనంగా ఉంది; సంబంధిత విషయాలలో జాగ్రత్త/మిశ్రమ ఫలిత సూచన.'
              : 'ఈ భావం మధ్యస్థ బలంలో ఉంది; ఇతర గ్రహ/భావ ఆధారాలతో కలిపి చూడాలి.';
      add(
        category: 'భావ బలం — వరుసగా 1 నుండి 12',
        item: '$house. ${_houseTopics[house - 1]}',
        result: result,
        rule: 'SAV house score 30+ అయితే బలమైన భావం; 25 కంటే తక్కువైతే బలహీన భావంగా పరిగణించే source thresholdsను వర్తింపజేశాం.',
        inspection: '$houseవ భావ SAV = $score. లగ్న రాశి సంఖ్య = ${lagna + 1}. ఈ score రాశి పేరు ఉపయోగించకుండా భావ సంఖ్య ఆధారంగా తీసుకోబడింది.',
        ruleId: 'W4.1–W4.2 / SAV house strength',
        source: 'Ashtakavarga second source — SAV strength/result rules',
        tone: tone,
      );
    }

    // 3) Source-summary yogas that are exactly computable from SAV.
    final incomeGroup = sum([1, 2, 4, 9, 10, 11]);
    final expenseGroup = sum([6, 8, 12]);
    final incomeRule = incomeGroup > 164 && expenseGroup < 76;
    add(
      category: 'ధనం / ఆదాయం / వ్యయం',
      item: 'ఆదాయాధిక్య యోగం',
      result: incomeRule
          ? 'ఆదాయం వ్యయం కంటే బలంగా ఉండే సంపద సూచన వర్తిస్తోంది.'
          : 'ఆదాయాధిక్య యోగం పూర్తి ప్రమాణంతో వర్తించడం లేదు.',
      rule: '1+2+4+9+10+11 > 164 మరియు 6+8+12 < 76 అయితే ఆదాయం > వ్యయం.',
      inspection: 'అనుకూల గుంపు = $incomeGroup; వ్యయ/అడ్డంకి గుంపు = $expenseGroup.',
      ruleId: 'R14.15–R14.16 / W6.5–W6.6',
      source: 'Summary yoga table + second source yoga summary',
      tone: incomeRule ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final poshakaA = sum([3, 7, 11]);
    final poshakaB = sum([4, 8, 12]);
    final poshaka = poshakaA > poshakaB;
    add(
      category: 'ధనం / సహాయం',
      item: 'పోషక యోగం',
      result: poshaka
          ? 'పోషణ/సహాయం/లాభాలకు అనుకూల సూచన ఉంది.'
          : 'పోషక యోగం ప్రమాణం నెరవేరలేదు.',
      rule: '(3+7+11) > (4+8+12).',
      inspection: '3+7+11 = $poshakaA; 4+8+12 = $poshakaB.',
      ruleId: 'R14.18 / W6.3',
      source: 'Samudaya Ashtakavarga yoga summary',
      tone: poshaka ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final independentA = sum([1, 5, 9]);
    final independentB = sum([2, 6, 10]);
    final independent = independentA > independentB;
    add(
      category: 'జీవన విధానం',
      item: 'స్వతంత్ర యోగం',
      result: independent
          ? 'స్వయం ఉపాధి/స్వతంత్ర జీవన ధోరణికి అనుకూల సూచన.'
          : 'స్వతంత్ర యోగం source ప్రమాణం నెరవేరలేదు.',
      rule: '(1+5+9) > (2+6+10).',
      inspection: '1+5+9 = $independentA; 2+6+10 = $independentB.',
      ruleId: 'R14.18 / W6.3',
      source: 'Samudaya Ashtakavarga yoga summary',
      tone: independent ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final innerA = sum([1, 4, 5, 7, 9, 10]);
    final innerB = sum([2, 3, 6, 8, 11, 12]);
    final inner = innerA > innerB;
    add(
      category: 'వ్యక్తిత్వం / ధర్మం',
      item: 'అంతరంగ బలం',
      result: inner
          ? 'అంతరంగ బలం, జ్ఞానం/ధర్మం వైపు మద్దతు సూచన.'
          : 'అంతరంగ-బాహ్య సమూహ పోలికలో ప్రత్యేక ఆధిక్యం లేదు.',
      rule: '(1+4+5+7+9+10) > (2+3+6+8+11+12).',
      inspection: 'అంతరంగ గుంపు = $innerA; ఇతర గుంపు = $innerB.',
      ruleId: 'W6.7',
      source: 'Ashtakavarga second source — yoga summary',
      tone: inner ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final dhanGaurava = h(1) >= 30 && h(11) >= 30;
    add(
      category: 'ధనం / గౌరవం',
      item: 'ధన-గౌరవ యోగం',
      result: dhanGaurava
          ? 'ధనం మరియు గౌరవానికి అనుకూల సమూహ బలం ఉంది.'
          : 'లగ్నం మరియు 11వ భావం రెండూ 30+ ప్రమాణం చేరలేదు.',
      rule: 'లగ్నం మరియు 11వ భావం రెండూ 30+.',
      inspection: 'లగ్న భావం = ${h(1)}; 11వ భావం = ${h(11)}.',
      ruleId: 'R14.28 / SAV summary',
      source: 'Samudaya Ashtakavarga yoga summary',
      tone: dhanGaurava ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final raja = [1, 9, 10, 11].every((x) => h(x) >= 30);
    add(
      category: 'రాజయోగ / స్థానం',
      item: 'రాజసమాన యోగ సూచన',
      result: raja
          ? 'స్థానం, గౌరవం, నాయకత్వానికి బలమైన సమూహ సూచన ఉంది.'
          : 'లగ్నం, 9, 10, 11 భావాలన్నీ 30+ కావాల్సిన ప్రమాణం పూర్తి కాలేదు.',
      rule: 'లగ్నం, 9, 10, 11 భావాలు 30+.',
      inspection: '1=${h(1)}, 9=${h(9)}, 10=${h(10)}, 11=${h(11)}.',
      ruleId: 'R14.43 / SAV yoga summary',
      source: 'Samudaya Ashtakavarga yoga summary',
      tone: raja ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final bahuRajya = [2, 9, 10, 11].every((x) => h(x) >= 30);
    add(
      category: 'రాజయోగ / బాధ్యత',
      item: 'బహు-రాజ్య యోగ సూచన',
      result: bahuRajya
          ? 'పెద్ద బాధ్యతలు/నాయకత్వ పాత్రలకు అనుకూల బలం ఉంది.'
          : '2, 9, 10, 11 భావాల 30+ సమూహ ప్రమాణం పూర్తి కాలేదు.',
      rule: '2, 9, 10, 11 భావాలు 30+.',
      inspection: '2=${h(2)}, 9=${h(9)}, 10=${h(10)}, 11=${h(11)}.',
      ruleId: 'R14.46 / SAV summary',
      source: 'Samudaya Ashtakavarga yoga summary',
      tone: bahuRajya ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final kubera = [4, 5, 6, 7, 8, 9].every((x) => h(x) >= 25);
    add(
      category: 'ధనం / ఆస్తి',
      item: 'కుబేర యోగ సూచన',
      result: kubera
          ? '4వ నుండి 9వ భావాల వరుస బలం సంపద/ఆస్తి సూచనకు మద్దతిస్తోంది.'
          : '4వ నుండి 9వ భావాలన్నీ కనీసం 25 చేరలేదు.',
      rule: '4వ భావం నుండి 9వ భావం వరకు వరుసగా కనీస బల ప్రమాణం (25+).',
      inspection: '4=${h(4)}, 5=${h(5)}, 6=${h(6)}, 7=${h(7)}, 8=${h(8)}, 9=${h(9)}.',
      ruleId: 'R14.25 / SAV yoga summary',
      source: 'Samudaya Ashtakavarga yoga summary',
      tone: kubera ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final triBhava = [1, 4, 11].every((x) => h(x) >= 30);
    add(
      category: 'ధనం / స్థిరాస్తి / లాభం',
      item: 'త్రిభావ బల యోగం',
      result: triBhava
          ? 'లగ్నం-4-11 భావాల సమిష్టి బలం ధనం/స్థిరాస్తి/లాభాలకు అనుకూలం.'
          : 'లగ్నం, 4, 11 అన్నీ 30+ ప్రమాణం చేరలేదు.',
      rule: 'లగ్నం, 4, 11 భావాలు 30+.',
      inspection: '1=${h(1)}, 4=${h(4)}, 11=${h(11)}.',
      ruleId: 'R14.24 / SAV summary',
      source: 'Samudaya Ashtakavarga yoga summary',
      tone: triBhava ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final kendraKona = [1, 4, 7, 10, 5, 9].where((x) => h(x) >= 30).length;
    add(
      category: 'సామగ్రిక సుఖం',
      item: 'కేంద్ర-కోణ బలం',
      result: kendraKona >= 4
          ? 'కేంద్ర/కోణ భావాలలో బలమైన SAV మద్దతు ఉంది.'
          : 'కేంద్ర/కోణాలలో 30+ బలమైన భావాల సంఖ్య పరిమితంగా ఉంది.',
      rule: '1,4,7,10 మరియు 5,9 భావాలలో ఎక్కువ భాగం 30+ అయితే సమగ్ర సుఖానికి మద్దతు.',
      inspection: '30+ ఉన్న కేంద్ర/కోణ భావాలు = $kendraKona / 6. Scores: 1=${h(1)},4=${h(4)},5=${h(5)},7=${h(7)},9=${h(9)},10=${h(10)}.',
      ruleId: 'SAV summary — Kendra/Kona strength',
      source: 'Ashtakavarga yoga summary tables',
      tone: kendraKona >= 4 ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final education = h(5) >= 30 && h(9) >= 30;
    add(
      category: 'విద్య',
      item: 'ఉన్నత విద్య బలం',
      result: education
          ? '5వ మరియు 9వ భావాల బలం ఉన్నత విద్య/జ్ఞానానికి అనుకూల సూచన.'
          : '5వ, 9వ భావాలు రెండూ 30+ కావాల్సిన బల ప్రమాణం పూర్తి కాలేదు.',
      rule: 'విద్య/ఉన్నత విద్యకు 5వ మరియు 9వ భావాల SAV బలాన్ని కలిసి పరిశీలించాలి.',
      inspection: '5వ భావం = ${h(5)}; 9వ భావం = ${h(9)}.',
      ruleId: 'W5.15 / education summary',
      source: 'Ashtakavarga second source — education result rules',
      tone: education ? AvFindingTone.favorable : AvFindingTone.neutral,
    );

    final partnerCaution = h(7) <= 20;
    add(
      category: 'వివాహం / భాగస్వామ్యం',
      item: '7వ భావ బలం',
      result: partnerCaution
          ? '7వ భావ SAV చాలా తక్కువగా ఉంది; భాగస్వామ్య విషయాలలో జాగ్రత్తగా ఇతర సూచనలతో కలిపి పరిశీలించాలి.'
          : '7వ భావం అత్యల్ప (≈20 లేదా తక్కువ) హెచ్చరిక ప్రమాణంలో లేదు.',
      rule: '7వ భావానికి చాలా తక్కువ SAV (source summaryలో సుమారు 20) ఉంటే భాగస్వామ్య ఫలితంలో బలహీనత సూచన.',
      inspection: '7వ భావ SAV = ${h(7)}.',
      ruleId: 'W5.9',
      source: 'Ashtakavarga second source — unfavorable result summary',
      tone: partnerCaution ? AvFindingTone.unfavorable : AvFindingTone.favorable,
    );

    final motherCaution = h(4) < 25 && h(4) < h(1);
    add(
      category: 'తల్లి / గృహ సుఖం',
      item: '4వ భావ హెచ్చరిక',
      result: motherCaution
          ? '4వ భావ బలం తక్కువగా ఉంది; తల్లి/గృహ సుఖం అంశాన్ని ఇతర సూచనలతో కలిసి పరిశీలించాలి.'
          : '4వ భావం sourceలోని తీవ్రమైన బలహీనత ప్రమాణంలో లేదు.',
      rule: '4వ భావ SAV < 25 మరియు లగ్న SAV కంటే తక్కువగా ఉంటే బలహీనత సూచన.',
      inspection: '4వ భావం = ${h(4)}; లగ్నం = ${h(1)}.',
      ruleId: 'W5.7',
      source: 'Ashtakavarga second source — unfavorable result summary',
      tone: motherCaution ? AvFindingTone.unfavorable : AvFindingTone.favorable,
    );

    final lossPattern = h(11) < h(10);
    add(
      category: 'లాభం / వృత్తి',
      item: '11వ–10వ భావ పోలిక',
      result: lossPattern
          ? 'లాభ భావం వృత్తి భావం కంటే తక్కువగా ఉంది; సంపాదన నిల్వ/లాభంలో ఒత్తిడి సూచనగా source పరిగణిస్తుంది.'
          : '11వ భావం 10వ భావం కంటే తక్కువగా లేదు.',
      rule: '11వ భావ SAV < 10వ భావ SAV అయితే నష్టం/లాభ ఒత్తిడి సూచన.',
      inspection: '11వ భావం = ${h(11)}; 10వ భావం = ${h(10)}.',
      ruleId: 'W5.18',
      source: 'Ashtakavarga second source — unfavorable result summary',
      tone: lossPattern ? AvFindingTone.unfavorable : AvFindingTone.favorable,
    );

    // 4) Planet-wise arithmetic: all seven BAV rows are evaluated at the
    // natal position of the same planet. This is the arithmetic base for the
    // source's Sun -> Saturn result tables.
    for (final planet in AshtakavargaService.planetOrder) {
      final score = av.arithmetic.natalBavScore[planet]!;
      final house = av.arithmetic.natalHouse[planet]!;
      final tri = av.arithmetic.afterTrikona[planet]!
          .fold<int>(0, (sum, value) => sum + value);
      final eka = av.arithmetic.afterEkadhipatya[planet]!
          .fold<int>(0, (sum, value) => sum + value);
      final pinda = av.arithmetic.practicalPindas[planet]!;
      final position = chart.planets.firstWhere((p) => p.name == planet);
      final kakshya = AshtakavargaService.kakshyaIndex(position.longitude);
      final tone = score >= 5
          ? AvFindingTone.favorable
          : score <= 3
              ? AvFindingTone.unfavorable
              : AvFindingTone.neutral;
      add(
        category: 'గ్రహవారీ అష్టకవర్గ గణితం — $planet',
        item: '$planet జన్మ BAV / శోధన / పిండం',
        result: 'జన్మస్థాన BAV = $score/8; భావం = $house; Kakshya = $kakshya/8.',
        rule: 'ఆ గ్రహం యొక్క స్వీయ BAVలో, ఆ గ్రహం జన్మ రాశిలో ఉన్న bindu సంఖ్యను తీసుకుని, త్రికోణ శోధన → ఏకాధిపత్య శోధన → రాశి/గ్రహ పిండ గణితం వరుసగా audit చేయాలి.',
        inspection: 'Raw BAV total=${av.totalFor(planet)}; Trikona total=$tri; Ekadhipatya total=$eka; Rasi Pinda=${pinda.rashiPinda}; Graha Pinda=${pinda.grahaPinda}; Shodhya Pinda=${pinda.shodhyaPinda}.',
        ruleId: 'AV-PLANET-$planet / W1–W2 arithmetic',
        source: 'Uploaded Ashtakavarga source + verified arithmetic engine',
        tone: tone,
      );
    }

    // 5) The formerly gated Shodhana/Pinda arithmetic is now active.
    final practicalTotal = AshtakavargaService.planetOrder.fold<int>(
      0,
      (sum, planet) => sum + av.arithmetic.practicalPindas[planet]!.shodhyaPinda,
    );
    final pvrTotal = AshtakavargaService.planetOrder.fold<int>(
      0,
      (sum, planet) => sum + av.arithmetic.pvrPindas[planet]!.shodhyaPinda,
    );
    add(
      category: 'పూర్తి arithmetic audit',
      item: 'త్రికోణ + ఏకాధిపత్య శోధన',
      result: av.arithmetic.auditValid
          ? 'ఏడు గ్రహాల raw BAV నుంచి రెండు శోధన దశలు negative/overflow లేకుండా పూర్తయ్యాయి.'
          : 'శోధన auditలో mismatch ఉంది; result ఉపయోగించే ముందు గణనను చెక్ చేయాలి.',
      rule: 'ప్రతి BAV rowపై Trikona Shodhana చేసి, తరువాత dual-lord sign pairsపై occupancy ఆధారంగా Ekadhipatya Shodhana వర్తించాలి.',
      inspection: 'Arithmetic audit = ${av.arithmetic.auditValid ? 'PASS' : 'FAIL'}.',
      ruleId: 'AV-SHODHANA-COMPLETE',
      source: 'Classical Ashtakavarga reduction arithmetic',
      tone: av.arithmetic.auditValid
          ? AvFindingTone.favorable
          : AvFindingTone.unfavorable,
    );
    add(
      category: 'పూర్తి arithmetic audit',
      item: 'రాశి పిండం / గ్రహ పిండం / శోధ్య పిండం',
      result: 'ఏడు గ్రహాలకు పిండ గణితం పూర్తైంది. Practical-profile మొత్తం=$practicalTotal; PVR-profile మొత్తం=$pvrTotal.',
      rule: 'Ekadhipatya తర్వాత మిగిలిన bindus × Rāśi multipliers = Rāśi Pinda; గ్రహాలు ఉన్న రాశుల reduced bindus × Graha multipliers = Graha Pinda; రెండింటి మొత్తం = Shodhya Pinda.',
      inspection: 'Profileలను mix చేయకుండా రెండు multiplier traditions విడిగా నిల్వ చేశాం. Default practical profileలో Virgo multiplier=5; PVR profileలో Virgo=6.',
      ruleId: 'AV-PINDA-COMPLETE',
      source: 'Classical Pinda arithmetic; dual multiplier profiles kept separate',
      tone: AvFindingTone.favorable,
    );

    // 6) Transit/Dasha interpretation still needs the requested date/time input,
    // but the arithmetic lookup itself is now available in the engine.
    add(
      category: 'గోచార arithmetic సిద్ధం',
      item: 'BAV/SAV longitude lookup + Kakshya',
      result: 'ఏ longitudeకైనా sign SAV, గ్రహ BAV మరియు 1–8 Kakshya indexను engine లెక్కించగలదు.',
      rule: 'రాశి 30°ను 8 సమ భాగాలుగా విభజిస్తే ఒక్క Kakshya = 3°45′. Transit longitudeకు సంబంధిత sign BAV/SAV bindusను lookup చేయాలి.',
      inspection: 'ప్రస్తుత buildలో arithmetic API active; prediction layerలో user-selected transit dateను తరువాతి rule mapping ఉపయోగిస్తుంది.',
      ruleId: 'AV-KAKSHYA-LOOKUP',
      source: 'Uploaded Ashtakavarga source — Kakshya/transit arithmetic section',
      tone: AvFindingTone.favorable,
    );

    return List.unmodifiable(out);
  }
}
