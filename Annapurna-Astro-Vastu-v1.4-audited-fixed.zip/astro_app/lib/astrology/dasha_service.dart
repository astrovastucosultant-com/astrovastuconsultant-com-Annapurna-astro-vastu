import 'astro_models.dart';

class DashaPeriod {
  final String lord;
  final DateTime start;
  final DateTime end;
  final double years;

  const DashaPeriod({
    required this.lord,
    required this.start,
    required this.end,
    required this.years,
  });

  bool contains(DateTime dt) => !dt.isBefore(start) && dt.isBefore(end);
}

class VimshottariResult {
  final int moonNakshatraIndex;
  final String moonNakshatraLord;
  final double nakshatraFractionElapsed;
  final List<DashaPeriod> mahadashas;
  final DashaPeriod currentMahadasha;
  final List<DashaPeriod> currentAntardashas;

  const VimshottariResult({
    required this.moonNakshatraIndex,
    required this.moonNakshatraLord,
    required this.nakshatraFractionElapsed,
    required this.mahadashas,
    required this.currentMahadasha,
    required this.currentAntardashas,
  });
}

class DashaService {
  static const List<String> lordOrder = [
    'Ketu',
    'Venus',
    'Sun',
    'Moon',
    'Mars',
    'Rahu',
    'Jupiter',
    'Saturn',
    'Mercury',
  ];

  static const Map<String, double> years = {
    'Ketu': 7,
    'Venus': 20,
    'Sun': 6,
    'Moon': 10,
    'Mars': 7,
    'Rahu': 18,
    'Jupiter': 16,
    'Saturn': 19,
    'Mercury': 17,
  };

  static const double _nakshatraSize = 360.0 / 27.0;
  static const double _daysPerYear = 365.2425;

  static VimshottariResult vimshottari({
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    final moon = chart.planets.firstWhere((p) => p.name == 'Moon');
    final normalized = ((moon.longitude % 360.0) + 360.0) % 360.0;
    final nakIndex = (normalized / _nakshatraSize).floor().clamp(0, 26).toInt();
    final withinNak = normalized - nakIndex * _nakshatraSize;
    final fractionElapsed = (withinNak / _nakshatraSize).clamp(0.0, 1.0).toDouble();
    final lordIndex = nakIndex % lordOrder.length;
    final firstLord = lordOrder[lordIndex];
    final firstYears = years[firstLord]!;

    final elapsedDays = firstYears * fractionElapsed * _daysPerYear;
    var cursor = birthDateTime.subtract(Duration(seconds: (elapsedDays * 86400).round()));

    final mahadashas = <DashaPeriod>[];
    var idx = lordIndex;
    // Generate enough periods to cover a full 120-year Vimshottari cycle.
    for (var i = 0; i < 18; i++) {
      final lord = lordOrder[idx % lordOrder.length];
      final y = years[lord]!;
      final end = cursor.add(Duration(seconds: (y * _daysPerYear * 86400).round()));
      mahadashas.add(DashaPeriod(lord: lord, start: cursor, end: end, years: y));
      cursor = end;
      idx++;
    }

    final current = mahadashas.firstWhere(
      (p) => p.contains(birthDateTime),
      orElse: () => mahadashas.first,
    );

    final currentAntardashas = antardashas(current);

    return VimshottariResult(
      moonNakshatraIndex: nakIndex,
      moonNakshatraLord: firstLord,
      nakshatraFractionElapsed: fractionElapsed,
      mahadashas: mahadashas,
      currentMahadasha: current,
      currentAntardashas: currentAntardashas,
    );
  }

  static DashaPeriod? periodAt(
    List<DashaPeriod> periods,
    DateTime dateTime,
  ) {
    for (final period in periods) {
      if (period.contains(dateTime)) return period;
    }
    return null;
  }

  /// Vimshottari sub-periods at any level use the same 120-year
  /// proportional sequence, starting from the parent lord.
  static List<DashaPeriod> subPeriods(DashaPeriod parent) {
    final startIndex = lordOrder.indexOf(parent.lord);
    var cursor = parent.start;
    final result = <DashaPeriod>[];
    for (var i = 0; i < lordOrder.length; i++) {
      final lord = lordOrder[(startIndex + i) % lordOrder.length];
      final subYears = parent.years * years[lord]! / 120.0;
      final end = cursor.add(
        Duration(seconds: (subYears * _daysPerYear * 86400).round()),
      );
      result.add(
        DashaPeriod(
          lord: lord,
          start: cursor,
          end: end,
          years: subYears,
        ),
      );
      cursor = end;
    }
    return result;
  }

  static List<DashaPeriod> antardashas(DashaPeriod mahadasha) {
    return subPeriods(mahadasha);
  }
}
