import 'astro_models.dart';

class DashaPeriod {
  final String lord;
  final DateTime start;
  final DateTime end;
  final double years;

  const DashaPeriod({
    required this.lord,
    required this.start,
    required this.end,
    required this.years,
  });

  bool contains(DateTime dt) => !dt.isBefore(start) && dt.isBefore(end);
}

class VimshottariResult {
  final int moonNakshatraIndex;
  final String moonNakshatraLord;
  final double nakshatraFractionElapsed;
  final List<DashaPeriod> mahadashas;
  final DashaPeriod currentMahadasha;
  final List<DashaPeriod> currentAntardashas;

  const VimshottariResult({
    required this.moonNakshatraIndex,
    required this.moonNakshatraLord,
    required this.nakshatraFractionElapsed,
    required this.mahadashas,
    required this.currentMahadasha,
    required this.currentAntardashas,
  });
}

enum DashaSystemKind {
  tribhagi,
  vimshottari,
  khanda,
  yogini,
}

extension DashaSystemKindLabel on DashaSystemKind {
  String get teluguLabel => switch (this) {
        DashaSystemKind.tribhagi => 'త్రిభాగి 80',
        DashaSystemKind.vimshottari => 'వింశోత్తరి 120',
        DashaSystemKind.khanda => 'ఖండ 40',
        DashaSystemKind.yogini => 'యోగిని 36',
      };
}

class DashaSystemResult {
  final DashaSystemKind kind;
  final String label;
  final String sourceNote;
  final int moonNakshatraIndex;
  final double nakshatraFractionElapsed;
  final String startingLord;
  final double birthBalanceYears;
  final double cycleYears;
  final List<String> sequence;
  final Map<String, double> weights;
  final List<DashaPeriod> mahadashas;

  const DashaSystemResult({
    required this.kind,
    required this.label,
    required this.sourceNote,
    required this.moonNakshatraIndex,
    required this.nakshatraFractionElapsed,
    required this.startingLord,
    required this.birthBalanceYears,
    required this.cycleYears,
    required this.sequence,
    required this.weights,
    required this.mahadashas,
  });
}

class DashaPath {
  final DashaPeriod mahadasha;
  final DashaPeriod antardasha;
  final DashaPeriod pratyantardasha;
  final DashaPeriod sukshma;
  final DashaPeriod prana;

  const DashaPath({
    required this.mahadasha,
    required this.antardasha,
    required this.pratyantardasha,
    required this.sukshma,
    required this.prana,
  });

  List<DashaPeriod> get levels => [
        mahadasha,
        antardasha,
        pratyantardasha,
        sukshma,
        prana,
      ];
}

class DashaService {
  static const List<String> lordOrder = [
    'Ketu',
    'Venus',
    'Sun',
    'Moon',
    'Mars',
    'Rahu',
    'Jupiter',
    'Saturn',
    'Mercury',
  ];

  static const Map<String, double> years = {
    'Ketu': 7,
    'Venus': 20,
    'Sun': 6,
    'Moon': 10,
    'Mars': 7,
    'Rahu': 18,
    'Jupiter': 16,
    'Saturn': 19,
    'Mercury': 17,
  };

  // Source-supported Yogini sequence used by the earlier Annapurna engine.
  static const List<String> yoginiOrder = [
    'Mangala (Moon)',
    'Pingala (Sun)',
    'Dhanya (Jupiter)',
    'Bhramari (Mars)',
    'Bhadrika (Mercury)',
    'Ulka (Saturn)',
    'Siddha (Venus)',
    'Sankata (Rahu)',
  ];

  static const Map<String, double> yoginiYears = {
    'Mangala (Moon)': 1,
    'Pingala (Sun)': 2,
    'Dhanya (Jupiter)': 3,
    'Bhramari (Mars)': 4,
    'Bhadrika (Mercury)': 5,
    'Ulka (Saturn)': 6,
    'Siddha (Venus)': 7,
    'Sankata (Rahu)': 8,
  };

  static const double _nakshatraSize = 360.0 / 27.0;
  static const double _daysPerYear = 365.2425;

  static double _normalize(double longitude) =>
      ((longitude % 360.0) + 360.0) % 360.0;

  static ({int index, double fractionElapsed}) _moonNakshatra(
    AstroChartResult chart,
  ) {
    final moon = chart.planets.firstWhere((p) => p.name == 'Moon');
    final normalized = _normalize(moon.longitude);
    final index = (normalized / _nakshatraSize).floor().clamp(0, 26).toInt();
    final within = normalized - index * _nakshatraSize;
    final fraction = (within / _nakshatraSize).clamp(0.0, 1.0).toDouble();
    return (index: index, fractionElapsed: fraction);
  }

  static DateTime _addYears(DateTime start, double yearsValue) {
    return start.add(
      Duration(seconds: (yearsValue * _daysPerYear * 86400).round()),
    );
  }

  static VimshottariResult vimshottari({
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    final generic = system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birthDateTime,
    );
    final current = periodAt(generic.mahadashas, birthDateTime) ??
        generic.mahadashas.first;
    return VimshottariResult(
      moonNakshatraIndex: generic.moonNakshatraIndex,
      moonNakshatraLord: generic.startingLord,
      nakshatraFractionElapsed: generic.nakshatraFractionElapsed,
      mahadashas: generic.mahadashas,
      currentMahadasha: current,
      currentAntardashas: subPeriodsFor(generic, current),
    );
  }

  static DashaSystemResult system({
    required DashaSystemKind kind,
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    final moonNak = _moonNakshatra(chart);

    switch (kind) {
      case DashaSystemKind.vimshottari:
        return _vimshottariFamily(
          kind: kind,
          label: kind.teluguLabel,
          scale: 1.0,
          cycleYears: 120.0,
          cycleCount: 2,
          moonNakshatraIndex: moonNak.index,
          fractionElapsed: moonNak.fractionElapsed,
          birthDateTime: birthDateTime,
          sourceNote:
              'Vimshottari proportional sequence. Nested periods use parent duration × planet years ÷ 120.',
        );
      case DashaSystemKind.tribhagi:
        return _vimshottariFamily(
          kind: kind,
          label: kind.teluguLabel,
          scale: 2.0 / 3.0,
          cycleYears: 80.0,
          cycleCount: 3,
          moonNakshatraIndex: moonNak.index,
          fractionElapsed: moonNak.fractionElapsed,
          birthDateTime: birthDateTime,
          sourceNote:
              'S.K. Mehta Tribhagi: corresponding Vimshottari duration × 2/3. Timing engine exposes levels 2–5: Antardasha, Pratyantardasha, Sukshma, Prana.',
        );
      case DashaSystemKind.khanda:
        return _vimshottariFamily(
          kind: kind,
          label: kind.teluguLabel,
          scale: 1.0 / 3.0,
          cycleYears: 40.0,
          cycleCount: 5,
          moonNakshatraIndex: moonNak.index,
          fractionElapsed: moonNak.fractionElapsed,
          birthDateTime: birthDateTime,
          sourceNote:
              'Khanda: corresponding Vimshottari duration × 1/3. Nested periods retain the same proportional planet sequence.',
        );
      case DashaSystemKind.yogini:
        return _yogini(
          moonNakshatraIndex: moonNak.index,
          fractionElapsed: moonNak.fractionElapsed,
          birthDateTime: birthDateTime,
        );
    }
  }

  static List<DashaSystemResult> allSystems({
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    return DashaSystemKind.values
        .map(
          (kind) => system(
            kind: kind,
            chart: chart,
            birthDateTime: birthDateTime,
          ),
        )
        .toList(growable: false);
  }

  static DashaSystemResult _vimshottariFamily({
    required DashaSystemKind kind,
    required String label,
    required double scale,
    required double cycleYears,
    required int cycleCount,
    required int moonNakshatraIndex,
    required double fractionElapsed,
    required DateTime birthDateTime,
    required String sourceNote,
  }) {
    final startIndex = moonNakshatraIndex % lordOrder.length;
    final firstLord = lordOrder[startIndex];
    final scaledWeights = <String, double>{
      for (final lord in lordOrder) lord: years[lord]! * scale,
    };
    final firstYears = scaledWeights[firstLord]!;
    final elapsedYears = firstYears * fractionElapsed;
    var cursor = _addYears(birthDateTime, -elapsedYears);

    final periods = <DashaPeriod>[];
    final totalPeriods = lordOrder.length * cycleCount;
    for (var i = 0; i < totalPeriods; i++) {
      final lord = lordOrder[(startIndex + i) % lordOrder.length];
      final y = scaledWeights[lord]!;
      final end = _addYears(cursor, y);
      periods.add(DashaPeriod(lord: lord, start: cursor, end: end, years: y));
      cursor = end;
    }

    return DashaSystemResult(
      kind: kind,
      label: label,
      sourceNote: sourceNote,
      moonNakshatraIndex: moonNakshatraIndex,
      nakshatraFractionElapsed: fractionElapsed,
      startingLord: firstLord,
      birthBalanceYears: firstYears * (1.0 - fractionElapsed),
      cycleYears: cycleYears,
      sequence: List.unmodifiable(lordOrder),
      weights: Map.unmodifiable(scaledWeights),
      mahadashas: List.unmodifiable(periods),
    );
  }

  static DashaSystemResult _yogini({
    required int moonNakshatraIndex,
    required double fractionElapsed,
    required DateTime birthDateTime,
  }) {
    final startIndex = moonNakshatraIndex % yoginiOrder.length;
    final firstLord = yoginiOrder[startIndex];
    final firstYears = yoginiYears[firstLord]!;
    final elapsedYears = firstYears * fractionElapsed;
    var cursor = _addYears(birthDateTime, -elapsedYears);

    final periods = <DashaPeriod>[];
    // Five 36-year cycles cover 180 years from birth.
    for (var i = 0; i < yoginiOrder.length * 5; i++) {
      final lord = yoginiOrder[(startIndex + i) % yoginiOrder.length];
      final y = yoginiYears[lord]!;
      final end = _addYears(cursor, y);
      periods.add(DashaPeriod(lord: lord, start: cursor, end: end, years: y));
      cursor = end;
    }

    return DashaSystemResult(
      kind: DashaSystemKind.yogini,
      label: DashaSystemKind.yogini.teluguLabel,
      sourceNote:
          'Yogini 36-year sequence: Mangala 1, Pingala 2, Dhanya 3, Bhramari 4, Bhadrika 5, Ulka 6, Siddha 7, Sankata 8. Nested periods divide proportionally by 36.',
      moonNakshatraIndex: moonNakshatraIndex,
      nakshatraFractionElapsed: fractionElapsed,
      startingLord: firstLord,
      birthBalanceYears: firstYears * (1.0 - fractionElapsed),
      cycleYears: 36.0,
      sequence: List.unmodifiable(yoginiOrder),
      weights: Map.unmodifiable(yoginiYears),
      mahadashas: List.unmodifiable(periods),
    );
  }

  static DashaPeriod? periodAt(
    List<DashaPeriod> periods,
    DateTime dateTime,
  ) {
    for (final period in periods) {
      if (period.contains(dateTime)) return period;
    }
    return null;
  }

  /// Legacy Vimshottari helper retained for existing UI/tests.
  static List<DashaPeriod> subPeriods(DashaPeriod parent) {
    final startIndex = lordOrder.indexOf(parent.lord);
    if (startIndex < 0) return const [];
    var cursor = parent.start;
    final result = <DashaPeriod>[];
    for (var i = 0; i < lordOrder.length; i++) {
      final lord = lordOrder[(startIndex + i) % lordOrder.length];
      final subYears = parent.years * years[lord]! / 120.0;
      final end = _addYears(cursor, subYears);
      result.add(
        DashaPeriod(
          lord: lord,
          start: cursor,
          end: end,
          years: subYears,
        ),
      );
      cursor = end;
    }
    return result;
  }

  static List<DashaPeriod> antardashas(DashaPeriod mahadasha) {
    return subPeriods(mahadasha);
  }

  /// Generic subdivision for Vimshottari, Tribhagi, Khanda and Yogini.
  /// Using system weights / system cycle preserves each parent duration.
  static List<DashaPeriod> subPeriodsFor(
    DashaSystemResult system,
    DashaPeriod parent,
  ) {
    final startIndex = system.sequence.indexOf(parent.lord);
    if (startIndex < 0) return const [];

    var cursor = parent.start;
    final result = <DashaPeriod>[];
    for (var i = 0; i < system.sequence.length; i++) {
      final lord = system.sequence[(startIndex + i) % system.sequence.length];
      final subYears =
          parent.years * system.weights[lord]! / system.cycleYears;
      final end = _addYears(cursor, subYears);
      result.add(
        DashaPeriod(
          lord: lord,
          start: cursor,
          end: end,
          years: subYears,
        ),
      );
      cursor = end;
    }
    return result;
  }

  static DashaPath? pathAt(
    DashaSystemResult system,
    DateTime dateTime,
  ) {
    final md = periodAt(system.mahadashas, dateTime);
    if (md == null) return null;

    final ads = subPeriodsFor(system, md);
    final ad = periodAt(ads, dateTime);
    if (ad == null) return null;

    final pds = subPeriodsFor(system, ad);
    final pd = periodAt(pds, dateTime);
    if (pd == null) return null;

    final suks = subPeriodsFor(system, pd);
    final suk = periodAt(suks, dateTime);
    if (suk == null) return null;

    final pranas = subPeriodsFor(system, suk);
    final prana = periodAt(pranas, dateTime);
    if (prana == null) return null;

    return DashaPath(
      mahadasha: md,
      antardasha: ad,
      pratyantardasha: pd,
      sukshma: suk,
      prana: prana,
    );
  }

  static String sourceYmd360(double yearsValue) {
    var totalDays = yearsValue * 360.0;
    var yearsPart = (totalDays ~/ 360);
    totalDays -= yearsPart * 360;
    var monthsPart = (totalDays ~/ 30);
    totalDays -= monthsPart * 30;
    var daysPart = totalDays.round();

    if (daysPart >= 30) {
      daysPart -= 30;
      monthsPart += 1;
    }
    if (monthsPart >= 12) {
      monthsPart -= 12;
      yearsPart += 1;
    }
    return '$yearsPart-$monthsPart-$daysPart';
  }
}
