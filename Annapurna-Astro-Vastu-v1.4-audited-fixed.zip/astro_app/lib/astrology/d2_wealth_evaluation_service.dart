import 'astro_models.dart';
import 'd2_dhana_asthi_registry.dart';
import 'varga_service.dart';


class D2WealthMatch {
  final String ruleId;
  final int percent;
  final String evidence;
  final bool caution;
  const D2WealthMatch({required this.ruleId, required this.percent, required this.evidence, this.caution = false});
}

/// Build89: reproducible D2 wealth/assets horoscope evaluator.
///
/// It only auto-evaluates rules whose conditions can be derived from the
/// current D1/D4/D16 placements + the source-defined Indu Lagna arithmetic.
/// Manduka Hora and date-sensitive Dasha/Gochar rules remain source-only until
/// their exact source construction/timing algorithm is supplied.
class D2WealthEvaluationService {
  static const _signLords = <String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  static const _benefics = {'Moon','Mercury','Jupiter','Venus'};
  static const _malefics = {'Sun','Mars','Saturn','Rahu','Ketu'};
  static const _exaltSign = <String,int>{
    'Sun':0,'Moon':1,'Jupiter':3,'Mercury':5,'Saturn':6,'Mars':9,'Venus':11,
  };

  static int _norm(int x) => ((x % 12) + 12) % 12;
  static int _houseFrom(int sign, int ref) => _norm(sign - ref) + 1;
  static int _houseSign(int ref, int house) => _norm(ref + house - 1);
  static String _lordOfSign(int sign) => _signLords[_norm(sign)];
  static String _lordOfHouse(int ref, int house) => _lordOfSign(_houseSign(ref, house));

  static PlanetPosition? _planet(AstroChartResult c, String name) {
    for (final p in c.planets) {
      if (p.name == name) return p;
    }
    return null;
  }

  static VargaPlacement? _vp(VargaChartData c, String name) {
    for (final p in c.planets) {
      if (p.name == name) return p;
    }
    return null;
  }

  static bool _aspects(String planet, int from, int to) {
    final d = _norm(to - from);
    if (d == 6) return true;
    if (planet == 'Mars' && (d == 3 || d == 7)) return true;
    if (planet == 'Jupiter' && (d == 4 || d == 8)) return true;
    if (planet == 'Saturn' && (d == 2 || d == 9)) return true;
    return false;
  }

  static bool _relationD1(AstroChartResult c, String a, String b) {
    final pa = _planet(c, a), pb = _planet(c, b);
    if (pa == null || pb == null) return false;
    if (pa.signIndex == pb.signIndex) return true;
    final mutualAspect = _aspects(a, pa.signIndex, pb.signIndex) &&
        _aspects(b, pb.signIndex, pa.signIndex);
    if (mutualAspect) return true;
    // Parivartana / sign exchange.
    return _lordOfSign(pa.signIndex) == b && _lordOfSign(pb.signIndex) == a;
  }

  static bool _planetRelatesSign(AstroChartResult c, String planet, int sign) {
    final p = _planet(c, planet);
    if (p == null) return false;
    return p.signIndex == sign || _aspects(planet, p.signIndex, sign);
  }

  static bool _hasAspectFrom(AstroChartResult c, Set<String> planets, int sign) {
    for (final name in planets) {
      final p = _planet(c, name);
      if (p != null && _aspects(name, p.signIndex, sign)) return true;
    }
    return false;
  }

  static bool _hasConjunctionWith(AstroChartResult c, String planet, Set<String> others) {
    final p = _planet(c, planet);
    if (p == null) return false;
    return c.planets.any((x) => x.name != planet && others.contains(x.name) && x.signIndex == p.signIndex);
  }

  static bool _isOwn(String planet, int sign) => _lordOfSign(sign) == planet;
  static bool _isExalted(String planet, int sign) => _exaltSign[planet] == sign;

  static bool _strongD1(AstroChartResult c, String planet, {int? refSign}) {
    final p = _planet(c, planet);
    if (p == null) return false;
    final ref = refSign ?? c.ascendantSignIndex;
    final h = _houseFrom(p.signIndex, ref);
    return _isOwn(planet, p.signIndex) || _isExalted(planet, p.signIndex) ||
        const {1,4,5,7,9,10}.contains(h);
  }

  static bool _strongVarga(VargaChartData c, String planet) {
    final p = _vp(c, planet);
    if (p == null) return false;
    final h = _houseFrom(p.signIndex, c.ascendantSignIndex);
    return _isOwn(planet, p.signIndex) || _isExalted(planet, p.signIndex) ||
        const {1,4,5,7,9,10}.contains(h);
  }

  static bool _weakVarga(VargaChartData c, String planet) => !_strongVarga(c, planet);

  static int induLagnaSign(AstroChartResult c) {
    final moon = _planet(c, 'Moon');
    if (moon == null) return c.ascendantSignIndex;
    final asc9Lord = _lordOfHouse(c.ascendantSignIndex, 9);
    final moon9Lord = _lordOfHouse(moon.signIndex, 9);
    final a = D2DhanaAsthiRegistry.kalaValues[asc9Lord] ?? 0;
    final b = D2DhanaAsthiRegistry.kalaValues[moon9Lord] ?? 0;
    var rem = (a + b) % 12;
    if (rem == 0) rem = 12;
    return _norm(moon.signIndex + rem - 1); // inclusive count
  }

  static String _signName(int s) => const [
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం'
  ][_norm(s)];

  static List<D2WealthMatch> evaluate(AstroChartResult chart) {
    final out = <D2WealthMatch>[];
    final d4 = VargaService.calculate(chart, 4);
    final d16 = VargaService.calculate(chart, 16);
    final indu = induLagnaSign(chart);

    D2DhanaAsthiRule rule(String id) => D2DhanaAsthiRegistry.rules.firstWhere((x) => x.id == id);

    void hit(String id, int percent, String evidence, {bool caution = false}) {
      out.add(D2WealthMatch(
        ruleId: id,
        percent: percent.clamp(1, 100),
        evidence: evidence,
        caution: caution,
      ));
    }


    int h(String planet, {int? ref}) {
      final p = _planet(chart, planet);
      return p == null ? 0 : _houseFrom(p.signIndex, ref ?? chart.ascendantSignIndex);
    }

    bool beneficRelationToSign(int sign) => chart.planets.any((p) =>
      _benefics.contains(p.name) && (p.signIndex == sign || _aspects(p.name, p.signIndex, sign)));
    bool maleficRelationToSign(int sign) => chart.planets.any((p) =>
      _malefics.contains(p.name) && (p.signIndex == sign || _aspects(p.name, p.signIndex, sign)));

    // Indu Lagna source rules.
    final induPlanets = chart.planets.where((p) => p.signIndex == indu).toList();
    final induBenefics = induPlanets.where((p) => _benefics.contains(p.name)).toList();
    final induMalefics = induPlanets.where((p) => _malefics.contains(p.name)).toList();
    final malAspectIndu = _hasAspectFrom(chart, _malefics, indu);
    if (induBenefics.isNotEmpty && induMalefics.isEmpty && !malAspectIndu) {
      hit('D2-IN-001', 100, 'Indu Lagna=${_signName(indu)} • benefic=${induBenefics.map((e)=>e.name).join(', ')} • malefic conjunction/aspect లేదు');
    }
    final exaltedMal = induMalefics.where((p) => _isExalted(p.name, p.signIndex)).toList();
    if (exaltedMal.isNotEmpty) {
      hit('D2-IN-002', 100, 'Indu Lagna=${_signName(indu)} • exalted malefic=${exaltedMal.map((e)=>e.name).join(', ')}');
    }
    final ordinaryMal = induMalefics.where((p) => !_isExalted(p.name, p.signIndex)).toList();
    if (ordinaryMal.isNotEmpty) {
      hit('D2-IN-003', 100, 'Indu Lagna=${_signName(indu)} • non-exalted malefic=${ordinaryMal.map((e)=>e.name).join(', ')}', caution: true);
    }
    if (malAspectIndu) hit('D2-IN-004', 100, 'Indu Lagna=${_signName(indu)}పై classical malefic aspect match', caution: true);
    if (induPlanets.any((p) => p.name == 'Rahu' || p.name == 'Ketu')) {
      hit('D2-IN-009', 80, 'Indu Lagna=${_signName(indu)}లో ${induPlanets.where((p)=>p.name=='Rahu'||p.name=='Ketu').map((e)=>e.name).join(', ')} • dispositor strength separate auditలో చూడాలి');
    }
    final wealthHousePlanets = chart.planets.where((p) => const {1,2,4,10,11}.contains(_houseFrom(p.signIndex, indu))).toList();
    if (wealthHousePlanets.isNotEmpty) {
      hit('D2-IN-007', 80, 'Indu Lagna నుంచి 1/2/4/10/11లో ${wealthHousePlanets.map((e)=>e.name).join(', ')}');
    }
    final lossHousePlanets = chart.planets.where((p) => const {3,6,8,12}.contains(_houseFrom(p.signIndex, indu))).toList();
    if (lossHousePlanets.isNotEmpty) {
      hit('D2-IN-008', 80, 'Indu Lagna నుంచి 3/6/8/12లో ${lossHousePlanets.map((e)=>e.name).join(', ')}', caution: true);
    }

    // D1 dhanayoga.
    final wealthLords = [2,5,9,11].map((x) => _lordOfHouse(chart.ascendantSignIndex, x)).toSet().toList();
    bool anyPairRelated = false;
    for (var i=0;i<wealthLords.length;i++) for (var j=i+1;j<wealthLords.length;j++) {
      if (_relationD1(chart, wealthLords[i], wealthLords[j])) anyPairRelated = true;
    }
    final l2 = _lordOfHouse(chart.ascendantSignIndex, 2), l11 = _lordOfHouse(chart.ascendantSignIndex, 11);
    if (_relationD1(chart, l2, l11) || anyPairRelated) {
      hit('D2-DY-001', _relationD1(chart,l2,l11) ? 100 : 80, '2L=$l2 • 11L=$l11 • 2/5/9/11 lords=${wealthLords.join(', ')} • source-defined relation matched');
    }
    final p2 = _planet(chart,l2), p11 = _planet(chart,l11);
    final exchange211 = p2 != null && p11 != null && _lordOfSign(p2.signIndex)==l11 && _lordOfSign(p11.signIndex)==l2;
    final signCounts = <int,int>{};
    for (final l in wealthLords) { final p=_planet(chart,l); if(p!=null) signCounts[p.signIndex]=(signCounts[p.signIndex]??0)+1; }
    final triple = signCounts.values.any((x)=>x>=3);
    if (exchange211 || triple) hit('D2-DY-002', 100, '2L↔11L exchange=${exchange211?'✓':'—'} • three wealth lords together=${triple?'✓':'—'}');

    // Cash / jewellery.
    if ((_strongD1(chart,l2) && h(l2)!=12) || (_strongD1(chart,l11) && h(l11)!=12)) {
      hit('D2-CS-001', 90, '2L=$l2 house=${h(l2)} strong=${_strongD1(chart,l2)} • 11L=$l11 house=${h(l11)} strong=${_strongD1(chart,l11)}');
    }
    final moon = _planet(chart,'Moon');
    if (moon != null && const {2,11}.contains(h('Moon')) && !_hasAspectFrom(chart,_malefics,moon.signIndex)) {
      hit('D2-CS-002', 100, 'Moon house=${h('Moon')} • malefic aspect లేదు');
    }
    if (h(l2)==12 && !beneficRelationToSign(_planet(chart,l2)?.signIndex ?? -1)) {
      hit('D2-CS-003', 100, '2L=$l2 12Hలో • benefic support లేదు', caution: true);
    }
    final sign2 = _houseSign(chart.ascendantSignIndex,2);
    if ((_planetRelatesSign(chart,'Jupiter',sign2)) || (h('Sun')==2 && _strongD1(chart,'Sun'))) {
      hit('D2-GD-001', 90, 'Jupiter↔2H=${_planetRelatesSign(chart,'Jupiter',sign2)} • Sun 2H strong=${h('Sun')==2 && _strongD1(chart,'Sun')}');
    }
    if (h('Moon')==2 && _strongD1(chart,'Moon')) hit('D2-GD-002', 100, 'Moon 2Hలో బలంగా ఉంది');
    if (const {2,4}.contains(h('Venus')) && _strongD1(chart,'Venus')) hit('D2-GD-003', 100, 'Venus house=${h('Venus')} • strong ✓');

    // Property + D4 confirmation.
    final l4 = _lordOfHouse(chart.ascendantSignIndex,4);
    final l4h = h(l4);
    final d4L4 = _lordOfHouse(d4.ascendantSignIndex,4);
    final d4L4p = _vp(d4,d4L4);
    final d4L4h = d4L4p==null ? 0 : _houseFrom(d4L4p.signIndex,d4.ascendantSignIndex);
    final d4Support = d4L4p != null && const {1,4,5,7,9,10}.contains(d4L4h);
    if (const {1,4,5,7,9,10}.contains(l4h) && _strongD1(chart,l4)) {
      hit('D2-PR-001', d4Support?100:75, 'D1 4L=$l4 house=$l4h strong ✓ • D4 4L=$d4L4 house=$d4L4h support=${d4Support?'✓':'—'}');
    }
    final house4Sign = _houseSign(chart.ascendantSignIndex,4);
    final beneficIn4 = chart.planets.where((p)=>_benefics.contains(p.name)&&p.signIndex==house4Sign).toList();
    final malIn4 = chart.planets.any((p)=>_malefics.contains(p.name)&&p.signIndex==house4Sign);
    if ((beneficIn4.isNotEmpty && !malIn4) || (const {1,4,5,7,9,10}.contains(l4h)&&_strongD1(chart,l4))) {
      hit('D2-PR-002', d4Support?100:80, 'D1 benefic 4H=${beneficIn4.map((e)=>e.name).join(', ')} • malefic conjunction=${malIn4?'ఉంది':'లేదు'} • 4L support ✓ • D4 confirmation=${d4Support?'✓':'—'}');
    }
    if (_planetRelatesSign(chart,'Mars',house4Sign) && _strongD1(chart,'Mars')) hit('D2-PR-003', d4Support?100:80, 'Mars 4H relation + strength ✓ • D4 support=${d4Support?'✓':'—'}');
    if (_planetRelatesSign(chart,'Saturn',house4Sign) && _strongD1(chart,'Saturn')) hit('D2-PR-004', d4Support?100:80, 'Saturn 4H relation + strength ✓ • D4 support=${d4Support?'✓':'—'}');
    if (const {6,8,12}.contains(l4h) && !_hasAspectFrom(chart,_benefics,_planet(chart,l4)?.signIndex ?? -1)) hit('D2-PR-005', 90, '4L=$l4 house=$l4h • benefic aspect లేదు',caution:true);
    if (d4L4p != null && !_strongVarga(d4,d4L4)) hit('D2-PR-006', 100, 'D4 4L=$d4L4 • house=$d4L4h • weak/unsupported', caution: true);
    if (d4Support) hit('D2-PR-007', 100, 'D4 4L=$d4L4 • house=$d4L4h Kendra/Trikona confirmation ✓');
    if (l4h==2) hit('D2-PR-008', d4Support?100:75, 'D1 4L=$l4 2Hలో ✓ • D4 support=${d4Support?'✓':'—'}');
    if (h('Ketu')==4 && !beneficRelationToSign(_planet(chart,'Ketu')?.signIndex ?? -1)) hit('D2-PR-009', 100, 'Ketu 4Hలో • benefic support లేదు', caution:true);
    if (h('Rahu')==4 && !_planetRelatesSign(chart,'Jupiter',house4Sign)) hit('D2-PR-010', 100, 'Rahu 4Hలో • Jupiter aspect/relation లేదు',caution:true);

    // Inheritance / parental property.
    final moonSign = moon?.signIndex ?? chart.ascendantSignIndex;
    final moon4L = _lordOfHouse(moonSign,4);
    final moon4p = _planet(chart,moon4L);
    final moon4h = moon4p==null?0:_houseFrom(moon4p.signIndex,moonSign);
    if ((_planetRelatesSign(chart,'Moon',house4Sign) && _strongD1(chart,'Moon')) || (const {1,4,5,7,9,10}.contains(moon4h) && _strongD1(chart,moon4L,refSign:moonSign))) {
      hit('D2-IH-001', d4Support?100:80, 'Moon↔4H=${_planetRelatesSign(chart,'Moon',house4Sign)} • Moon-lagna 4L=$moon4L house=$moon4h • D4 support=${d4Support?'✓':'—'}');
    }
    if (h('Moon')==5 && maleficRelationToSign(house4Sign)) hit('D2-IH-002', 100, 'Moon 5Hలో • 4Hపై malefic influence ✓', caution:true);
    final l9 = _lordOfHouse(chart.ascendantSignIndex,9);
    if (_planetRelatesSign(chart,l9,house4Sign) || (h('Sun')==4&&_strongD1(chart,'Sun')) || l4h==9) {
      hit('D2-IH-003', d4Support?100:80, '9L=$l9↔4H=${_planetRelatesSign(chart,l9,house4Sign)} • Sun 4H strong=${h('Sun')==4&&_strongD1(chart,'Sun')} • 4L in9=${l4h==9}');
    }
    if (const {8,12}.contains(h(l9)) && !_hasAspectFrom(chart,_benefics,_planet(chart,l9)?.signIndex ?? -1)) hit('D2-IH-004', 100, '9L=$l9 house=${h(l9)} • benefic aspect లేదు',caution:true);

    // Vehicles — D1 promise + D16 confirmation (user-approved layer).
    final d16Venus = _vp(d16,'Venus');
    final d16VenusStrong = d16Venus != null && _strongVarga(d16,'Venus');
    final d16VenusWeak = d16Venus != null && _weakVarga(d16,'Venus');
    final venus4 = h('Venus')==4;
    final venusRel4 = _planetRelatesSign(chart,'Venus',house4Sign);
    if (venus4 && (_isOwn('Venus', _planet(chart,'Venus')!.signIndex) || _isExalted('Venus',_planet(chart,'Venus')!.signIndex)) && _strongD1(chart,l4)) {
      hit('D2-VH-001', d16VenusStrong?100:75, 'D1 Venus 4H own/exalted ✓ • 4L strong ✓ • D16 Venus strong=${d16VenusStrong?'✓':'—'}');
    }
    if (venusRel4 && !_strongD1(chart,'Venus')) hit('D2-VH-002', d16VenusStrong?85:65, 'D1 Venus↔4H ✓ • medium/ordinary strength • D16 support=${d16VenusStrong?'✓':'—'}');
    final count4 = chart.planets.where((p)=>p.signIndex==house4Sign).length;
    if (count4>=2 || (_strongD1(chart,'Venus') && _planetRelatesSign(chart,'Venus',_houseSign(chart.ascendantSignIndex,11)))) hit('D2-VH-003', d16VenusStrong?100:75, '4H planet count=$count4 • Venus strong+11H relation=${_strongD1(chart,'Venus')&&_planetRelatesSign(chart,'Venus',_houseSign(chart.ascendantSignIndex,11))} • D16 support=${d16VenusStrong?'✓':'—'}');
    if (h('Mars')==4 && _strongD1(chart,'Mars')) hit('D2-VH-004', d16VenusStrong?90:70, 'Mars 4H strong ✓ • D16 Venus support=${d16VenusStrong?'✓':'—'}');
    if (_planetRelatesSign(chart,'Saturn',house4Sign) && !_strongD1(chart,'Saturn')) hit('D2-VH-005', d16VenusWeak?100:75, 'Saturn↔4H + weak ✓ • D16 Venus weak=${d16VenusWeak?'✓':'—'}', caution:true);
    if (const {6,8,12}.contains(l4h) && !_strongD1(chart,'Venus')) hit('D2-VH-006', d16VenusWeak?100:80, '4L=$l4 house=$l4h • Venus weak ✓ • D16 Venus weak=${d16VenusWeak?'✓':'—'}', caution:true);
    if (d16VenusWeak) hit('D2-VH-007', 100, 'D16 Venus sign=${_signName(d16Venus!.signIndex)} • vehicle/comfort confirmation layer weak', caution:true);

    // Other wealth/property indications.
    final l7 = _lordOfHouse(chart.ascendantSignIndex,7), l10 = _lordOfHouse(chart.ascendantSignIndex,10);
    if (_relationD1(chart,l7,'Mercury') || _relationD1(chart,l10,'Mercury')) hit('D2-OT-001', 100, '7L=$l7 / 10L=$l10 relation with Mercury matched');
    final l5 = _lordOfHouse(chart.ascendantSignIndex,5);
    if (h(l5)==11 && _strongD1(chart,l5)) hit('D2-OT-002', 100, '5L=$l5 11Hలో + strong ✓');
    if (const {8,12}.contains(h(l5)) && _hasAspectFrom(chart,_malefics,_planet(chart,l5)?.signIndex ?? -1)) hit('D2-OT-003', 100, '5L=$l5 house=${h(l5)} • malefic aspect ✓',caution:true);
    if (const {9,12}.contains(l4h) && _hasConjunctionWith(chart,l4,{'Rahu'})) hit('D2-OT-004', 100, '4L=$l4 house=$l4h • Rahu conjunction ✓');
    if (h(l11)==12 && _strongD1(chart,l11)) hit('D2-OT-005', 100, '11L=$l11 12Hలో + strong ✓');

    return out;
  }
}
