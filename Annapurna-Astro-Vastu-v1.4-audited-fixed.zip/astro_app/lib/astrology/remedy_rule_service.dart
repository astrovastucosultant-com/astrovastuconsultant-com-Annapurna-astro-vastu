/// Source-bound remedy selector for Annapurna Astro Vastu.
///
/// Primary source: user supplied `remidi.pdf` (Compendium of Remedial Measures,
/// 150 scanned pages).  This service does not claim that a remedy changes a
/// guaranteed outcome.  It selects the safest source-backed remedy family that
/// corresponds to the chart/rule context.  Hazardous ritual instructions are
/// intentionally not reproduced; Homa/temple rites are shown only as
/// priest/temple-supervised options.
class RemedyRuleService {
  static const source = 'remidi.pdf — Compendium of Remedial Measures';

  static const _planetDevata = <String, String>{
    'Sun': 'Surya / Agni; Pratyadhi Devata: Shiva',
    'Moon': 'Chandra / Apas; Pratyadhi Devata: Gauri',
    'Mars': 'Kuja / Prithvi; Pratyadhi Devata: Kshetrapala',
    'Mercury': 'Budha / Vishnu; Pratyadhi Devata: Narayana',
    'Jupiter': 'Guru / Indramarutvan; Pratyadhi Devata: Prajapati',
    'Venus': 'Shukra / Indrani; Pratyadhi Devata: Indra',
    'Saturn': 'Shani / Prajapati; Pratyadhi Devata: Dharmaraja',
    'Rahu': 'Rahu / Gomata; Pratyadhi Devata: Nairriti',
    'Ketu': 'Ketu / Brahma; Pratyadhi Devata: Chitragupta',
  };

  static const _vargaSupport = <int, String>{
    10: 'D10: వృత్తి సమస్యలో D10 లగ్నం, 10వ అధిపతి, దశాధిపతి Devataలను పరిశీలించి అనుకూల Devata upasana/ప్రార్థనను supportగా ఎంచుకోవాలి.',
    12: 'D12: వంశ/పితృ–మాతృ సమస్యలో D12లో బలహీన Sun/Moon లేదా దశాధిపతి Devataను source ప్రకారం పరిశీలించాలి.',
    16: 'D16: వాహనం/సౌఖ్యం సమస్యలో Venus నుంచి 5వ స్థానం మరియు D16 Devata (Brahma/Vishnu/Shiva/Surya)ను పరిశీలించి support remedy ఎంచుకోవాలి.',
    20: 'D20: Upasana/Ishta Devata కోసం D20లో Lagna/Moon/Jupiter నుంచి 5వ స్థానం మరియు Atmakaraka సంబంధాన్ని పరిశీలించాలి.',
    24: 'D24: విద్య/ఉన్నత సాధన సమస్యలో Lagna/Moon/Jupiter/AK నుంచి 5వ స్థానంలోని బలమైన గ్రహ Devataను supportగా ఎంచుకోవాలి.',
    27: 'D27: బలహీన/బాధిత గ్రహానికి సంబంధిత D27 Nakshatramsa Devataను ప్రార్థన/ఉపాసన రూపంలో supportగా ఉపయోగించాలి.',
    30: 'D30: దుర్ఘటన/ఋణం/దురదృష్టం వంటి afflictionలో బాధిత గ్రహ D30 Devataను source ప్రకారం శాంతి/ప్రార్థనకు ఎంచుకోవాలి.',
  };

  static String forContext({
    required int factor,
    required String topic,
    required String result,
    required String rule,
    required String tone,
  }) {
    final text = '$topic $result $rule'.toLowerCase();
    final adverse = tone == 'caution' || _containsAny(text, const [
      'నష్టం', 'లేకపోవ', 'ఆలస్యం', 'తగాద', 'బలహీన', 'జాగ్రత్త', 'afflict',
      'weak', 'loss', 'delay', 'obstacle', 'problem', 'disease', 'రోగ', 'పాప',
      '6, 8', '8 లేదా 12', '12వ', 'dusthana', 'maraka', 'badhaka',
    ]);

    final parts = <String>[];

    // Bhava-based safe source selection.
    final houses = _housesFrom(text);
    for (final h in houses) {
      final remedy = _houseRemedy(h);
      if (remedy.isNotEmpty && !parts.contains(remedy)) parts.add(remedy);
    }

    // Planet + Devata layer.
    for (final e in _planetDevata.entries) {
      if (_mentionsPlanet(text, e.key)) {
        parts.add('${_tePlanet(e.key)} బాధిత/బలహీనంగా ఉంటే: ${e.value}. Source ప్రకారం direct appeasement + Adhi/Pratyadhi Devata worshipను పరిశీలించాలి.');
      }
    }

    // Common dosha families explicitly present in the uploaded source.
    if (_containsAny(text, const ['rahu', 'ketu', 'రాహు', 'కేతు', 'sarpa', 'సర్ప'])) {
      parts.add('Rahu/Ketu–Sarpa సంబంధం ఉంటే: Sarpa Shanti / Naga Devata ప్రార్థనను temple/priest-supervised spiritual supportగా పరిశీలించాలి.');
    }
    if (_containsAny(text, const ['pitru', 'పితృ', 'father', 'తండ్రి', '9వ'])) {
      parts.add('Pitru/9H affliction ఉంటే: Pitru ప్రార్థన, Tila-based charity/ritual లేదా సంబంధిత kshetra worshipను కుటుంబ సంప్రదాయం/qualified priest guidanceతో మాత్రమే చేయాలి.');
    }
    if (_containsAny(text, const ['matru', 'మాతృ', 'mother', 'తల్లి', '4వ'])) {
      parts.add('Matru/4H affliction ఉంటే: తల్లి ఆశీర్వాదం, పవిత్ర స్నానం/ప్రార్థన వంటి source-backed supportive measuresను పరిశీలించాలి.');
    }
    if (_containsAny(text, const ['marriage', 'వివాహ', 'kalatra', '7వ'])) {
      parts.add('Kalatra/7H afflictionలో: Devi/Uma-Maheshwara ప్రార్థన, afflicted planet appeasement మరియు relationship conduct correctionను supportగా చూడాలి.');
    }
    if (_containsAny(text, const ['health', 'రోగ', 'disease', '6వ', '8వ'])) {
      parts.add('Health/6H–8H afflictionలో: Dhanvantari/Mrityunjaya/Rudra ప్రార్థన sourceలో spiritual supportగా ఉంది. వైద్య పరీక్షలు/చికిత్సకు ఇది ప్రత్యామ్నాయం కాదు.');
    }
    if (_containsAny(text, const ['education', 'విద్య', '5వ'])) {
      parts.add('5H/విద్య afflictionలో: Deva Upasana మరియు సంబంధిత గ్రహ/Devata ప్రార్థనను supportగా పరిశీలించాలి.');
    }
    if (_containsAny(text, const ['career', 'వృత్తి', 'job', 'business', '10వ'])) {
      parts.add('10H/వృత్తి afflictionలో: బాధిత గ్రహ దినంలో దానం/సేవ మరియు D10 Devata supportను source ప్రకారం పరిశీలించాలి.');
    }
    if (_containsAny(text, const ['ధనం', 'wealth', 'cash', 'నగదు', '2వ', '11వ'])) {
      parts.add('ధన/2H–11H సమస్యలో: బాధిత గ్రహానికి సంబంధించిన mantra/ప్రార్థన, మృదువైన వాక్కు, ఆహార/దాన సహాయం వంటి source-backed measuresను పరిశీలించాలి.');
    }
    if (_containsAny(text, const ['property', 'house', 'land', 'ఆస్తి', 'ఇల్లు', 'భూమి'])) {
      parts.add('4H/ఆస్తి సమస్యలో: 4H lord + occupant + Karaka ఎవరు బాధితులో వారిని ముందుగా గుర్తించి, వారి planetary/Devata remedyని మాత్రమే link చేయాలి.');
    }
    if (_containsAny(text, const ['vehicle', 'వాహన'])) {
      parts.add('వాహన సమస్యలో D1 4H/Venusతో పాటు D16 confirmation తీసుకుని, D16 Venus నుంచి 5వ Devata layerను support remedyగా ఉపయోగించాలి.');
    }

    final varga = _vargaSupport[factor];
    if (varga != null) parts.add(varga);

    if (!adverse && parts.isEmpty) {
      parts.add('ఈ ఫలితం అనుకూలంగా ఉంటే తప్పనిసరి శాంతి అవసరం అని source చెప్పదు. బలమైన గ్రహ/Devataను Ishta Devata రూపంలో ప్రార్థన, దానం లేదా సాత్విక ఆచరణతో గౌరవించవచ్చు.');
    } else if (parts.isEmpty) {
      parts.add('Remedy selection rule: బాధిత Bhava + Bhava lord + occupant + సంబంధిత Karakaను గుర్తించి, ఆ గ్రహ/భావానికి sourceలో ఇచ్చిన mantra/Devata/dana/temple supportలో సరిపోయేదాన్ని మాత్రమే ఎంచుకోవాలి.');
    }

    parts.add('Gemstoneను automaticగా prescribe చేయవద్దు; separate Gem Remedy eligibility (lordship, strength, bhava/varga support, maraka/badhaka/dusthana safeguards) pass అయితేనే చూపాలి.');
    parts.add('Source: $source. పరిహారం సంప్రదాయ ఆధ్యాత్మిక support మాత్రమే; ఫలితానికి హామీ కాదు.');
    return parts.join('\n\n');
  }

  static bool _containsAny(String text, List<String> needles) =>
      needles.any((n) => text.contains(n.toLowerCase()));

  static bool _mentionsPlanet(String text, String planet) {
    final keys = <String, List<String>>{
      'Sun': ['sun', 'surya', 'రవి', 'సూర్య'],
      'Moon': ['moon', 'chandra', 'చంద్ర'],
      'Mars': ['mars', 'kuja', 'కుజ', 'అంగారక'],
      'Mercury': ['mercury', 'budha', 'బుధ'],
      'Jupiter': ['jupiter', 'guru', 'గురు', 'బృహస్పతి'],
      'Venus': ['venus', 'shukra', 'శుక్ర'],
      'Saturn': ['saturn', 'shani', 'శని'],
      'Rahu': ['rahu', 'రాహు'],
      'Ketu': ['ketu', 'కేతు'],
    };
    return keys[planet]!.any(text.contains);
  }

  static String _tePlanet(String p) => const {
        'Sun': 'సూర్యుడు', 'Moon': 'చంద్రుడు', 'Mars': 'కుజుడు',
        'Mercury': 'బుధుడు', 'Jupiter': 'గురుడు', 'Venus': 'శుక్రుడు',
        'Saturn': 'శని', 'Rahu': 'రాహు', 'Ketu': 'కేతు',
      }[p] ?? p;

  static Set<int> _housesFrom(String text) {
    final out = <int>{};
    for (var h = 1; h <= 12; h++) {
      if (text.contains('${h}వ') || text.contains('${h}th ') || text.contains('${h}h')) out.add(h);
    }
    return out;
  }

  static String _houseRemedy(int h) => switch (h) {
        1 => '1H/Lagna affliction: Surya/Gayatri లేదా Lagna lord Devata ప్రార్థనను source సూచిస్తుంది.',
        2 => '2H affliction: mantra, sweet/constructive speech, బాధిత గ్రహానికి సంబంధించిన food donationను source సూచిస్తుంది.',
        3 => '3H affliction: service, Pranayama మరియు సరైన counsel/supportను source సూచిస్తుంది.',
        4 => '4H affliction: medicinal/holy bath, mother blessings మరియు బాధిత గ్రహ remedyను source సూచిస్తుంది.',
        5 => '5H affliction: Deva Upasana; context సరిపోతే 5H-specific mantra/pujaను source సూచిస్తుంది.',
        6 => '6H affliction: Dhanvantari prayer, Shatru-samhara prayer; health అయితే medical careతో పాటు spiritual support మాత్రమే.',
        7 => '7H affliction: Devi/Uma-Maheshwara prayer మరియు afflicted planet appeasementను source సూచిస్తుంది.',
        8 => '8H affliction: Mrityunjaya/Ayush/Rudra prayerను source సూచిస్తుంది; health/safety concernలో practical/medical safeguards తప్పనిసరి.',
        9 => '9H affliction: spiritual pilgrimage/prayer, Tila-based charity/ritual వంటి source measuresను qualified guidanceతో పరిశీలించాలి.',
        10 => '10H affliction: బాధిత గ్రహ దినంలో benevolent acts/serviceను source సూచిస్తుంది.',
        11 => '11H affliction: Sankirtan/Bhajan మరియు gain-network conduct correctionను supportగా చూడాలి.',
        12 => '12H affliction: donations, holy/medicinal bath మరియు బాధిత గ్రహ appeasementను source సూచిస్తుంది.',
        _ => '',
      };
}
