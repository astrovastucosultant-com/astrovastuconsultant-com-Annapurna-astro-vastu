import 'ashtakavarga_service.dart';
import 'astro_models.dart';
import 'planet_detail_service.dart';
import 'vedic_calculation_service.dart';

/// Source-bound gemstone evaluator for the supplied "Gem remidy rools.pdf".
///
/// IMPORTANT: the supplied remedy pages define *conditions* using Grahashakti
/// and Bhavabala, but do not provide the full classical Shadbala/Bhava-Bala
/// arithmetic. Therefore this app uses two already-verified chart inputs as
/// transparent strength indicators:
///   - Grahashakti input: Shodashavarga Vimshopaka Bala (0..20)
///   - Bhava strength input: Sarvashtakavarga points of the relevant house
/// These thresholds are app decision thresholds, not numeric cut-offs quoted
/// by the source. They are shown in the UI so the user can audit the decision.
enum GemDecisionStatus { eligible, conditional, restricted, notIndicated }

class GemAppliedRule {
  final String id;
  final String title;
  final String source;
  final String inspection;
  final bool matched;
  final bool blocking;
  final bool conditional;

  const GemAppliedRule({
    required this.id,
    required this.title,
    required this.source,
    required this.inspection,
    required this.matched,
    this.blocking = false,
    this.conditional = false,
  });
}

class GemHouseStrength {
  final int house;
  final int savPoints;
  final bool deficient;

  const GemHouseStrength({
    required this.house,
    required this.savPoints,
    required this.deficient,
  });
}

class GemStrengthSnapshot {
  final double shadVimsopaka;
  final double saptaVimsopaka;
  final double dashaVimsopaka;
  final double shodashaVimsopaka;
  final List<int> shodashaSupport;
  final bool grahaDeficient;
  final List<GemHouseStrength> ownedHouseStrengths;
  final double ownedHouseAverage;
  final int placementHouse;

  const GemStrengthSnapshot({
    required this.shadVimsopaka,
    required this.saptaVimsopaka,
    required this.dashaVimsopaka,
    required this.shodashaVimsopaka,
    required this.shodashaSupport,
    required this.grahaDeficient,
    required this.ownedHouseStrengths,
    required this.ownedHouseAverage,
    required this.placementHouse,
  });
}

class GemEvaluation {
  final String planet;
  final String gemEnglish;
  final String gemTelugu;
  final GemDecisionStatus status;
  final String summary;
  final GemStrengthSnapshot strength;
  final List<GemAppliedRule> rules;
  final List<String> safeguards;

  const GemEvaluation({
    required this.planet,
    required this.gemEnglish,
    required this.gemTelugu,
    required this.status,
    required this.summary,
    required this.strength,
    required this.rules,
    required this.safeguards,
  });
}

class GemRemedyService {
  static const double grahaDeficientCutoff = 10.0;
  static const int bhavaDeficientCutoff = 28;

  static const List<String> selectablePlanets = [
    'Sun',
    'Moon',
    'Mars',
    'Mercury',
    'Jupiter',
    'Venus',
    'Saturn',
    'Rahu',
    'Ketu',
  ];

  static const Map<String, (String, String)> gemNames = {
    'Sun': ('Ruby', 'మాణిక్యం'),
    'Moon': ('Pearl', 'ముత్యం'),
    'Mars': ('Red Coral', 'పగడం'),
    'Mercury': ('Emerald', 'పచ్చ'),
    'Jupiter': ('Yellow Sapphire', 'పుష్యరాగం'),
    'Venus': ('Diamond / White Sapphire', 'వజ్రం / శ్వేత పుష్యరాగం'),
    'Saturn': ('Blue Sapphire', 'నీలం'),
    'Rahu': ('Hessonite', 'గోమేధికం'),
    'Ketu': ("Cat's Eye", 'వైడూర్యం'),
  };

  static const List<String> _signLords = [
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];

  static const Set<String> _naturalBenefics = {
    'Jupiter', 'Venus', 'Moon', 'Mercury',
  };
  static const Set<String> _naturalMalefics = {'Sun', 'Mars', 'Saturn'};

  static String lordOfHouse(AstroChartResult chart, int house) {
    final sign = (chart.ascendantSignIndex + house - 1) % 12;
    return _signLords[sign];
  }

  static List<int> housesOwnedBy(AstroChartResult chart, String planet) {
    final out = <int>[];
    for (var house = 1; house <= 12; house++) {
      if (lordOfHouse(chart, house) == planet) out.add(house);
    }
    return out;
  }

  static int placementHouse(AstroChartResult chart, String planet) {
    final p = chart.planets.firstWhere((x) => x.name == planet);
    return VedicCalculationService.wholeSignHouse(
      p.signIndex,
      chart.ascendantSignIndex,
    );
  }

  static int badhakaHouse(AstroChartResult chart) {
    // Source page 5: Chara = 11th, Sthira = 9th, Dwiswabhava = 7th.
    final sign = chart.ascendantSignIndex;
    final movable = const {0, 3, 6, 9}.contains(sign);
    final fixed = const {1, 4, 7, 10}.contains(sign);
    if (movable) return 11;
    if (fixed) return 9;
    return 7;
  }

  static GemEvaluation evaluate({
    required AstroChartResult chart,
    required AshtakavargaResult ashtakavarga,
    required String planet,
  }) {
    final gem = gemNames[planet] ?? (planet, planet);
    final p = chart.planets.firstWhere((x) => x.name == planet);
    final detail = PlanetDetailService.forPlanet(chart, p);
    final v = detail.vargaStrength;
    final owned = housesOwnedBy(chart, planet);
    final strengths = owned
        .map((house) {
          final points = ashtakavarga.arithmetic.savHouse(house);
          return GemHouseStrength(
            house: house,
            savPoints: points,
            deficient: points < bhavaDeficientCutoff,
          );
        })
        .toList(growable: false);
    final avg = strengths.isEmpty
        ? 0.0
        : strengths.fold<int>(0, (s, x) => s + x.savPoints) / strengths.length;
    final grahaDef = v.shodashaVimsopaka < grahaDeficientCutoff;
    final placement = placementHouse(chart, planet);
    final snapshot = GemStrengthSnapshot(
      shadVimsopaka: v.shadVimsopaka,
      saptaVimsopaka: v.saptaVimsopaka,
      dashaVimsopaka: v.dashaVimsopaka,
      shodashaVimsopaka: v.shodashaVimsopaka,
      shodashaSupport: v.shodashaSupport,
      grahaDeficient: grahaDef,
      ownedHouseStrengths: strengths,
      ownedHouseAverage: avg,
      placementHouse: placement,
    );

    bool houseWeak(int h) =>
        ashtakavarga.arithmetic.savHouse(h) < bhavaDeficientCutoff;
    bool houseStrong(int h) => !houseWeak(h);
    bool owns(int h) => owned.contains(h);
    final rules = <GemAppliedRule>[];
    final safeguards = <String>[];

    void add({
      required String id,
      required String title,
      required int page,
      required bool matched,
      required String inspection,
      bool blocking = false,
      bool conditional = false,
    }) {
      rules.add(
        GemAppliedRule(
          id: id,
          title: title,
          source: 'Gem remidy rools.pdf — source page $page',
          inspection: inspection,
          matched: matched,
          blocking: blocking,
          conditional: conditional,
        ),
      );
    }

    // PRINCIPLE 1 — Lagna Lord.
    final lagnaLord = lordOfHouse(chart, 1);
    final p1 = planet == lagnaLord && (grahaDef || houseWeak(1));
    add(
      id: 'GEM-P1',
      title: 'Principle 1 — Lagna Lord',
      page: 2,
      matched: p1,
      inspection: planet == lagnaLord
          ? 'ఈ గ్రహం లగ్నాధిపతి. Varga Bala ${v.shodashaVimsopaka.toStringAsFixed(2)}/20; 1వ భావ SAV ${ashtakavarga.arithmetic.savHouse(1)}.'
          : 'ఈ గ్రహం లగ్నాధిపతి కాదు (లగ్నాధిపతి: $lagnaLord).',
    );

    // PRINCIPLE 2 — Trikona Lords.
    final triHouses = <int>[if (owns(5)) 5, if (owns(9)) 9];
    final p2 = triHouses.any((h) => grahaDef || houseWeak(h));
    add(
      id: 'GEM-P2',
      title: 'Principle 2 — Trikona Lords',
      page: 3,
      matched: p2,
      inspection: triHouses.isEmpty
          ? 'ఈ గ్రహం 5వ/9వ అధిపతి కాదు.'
          : 'Trikona houses ${triHouses.join(', ')}; Varga Bala ${v.shodashaVimsopaka.toStringAsFixed(2)}/20; SAV ${triHouses.map((h) => '$h=${ashtakavarga.arithmetic.savHouse(h)}').join(', ')}.',
    );

    // PRINCIPLE 3 — strong lord but weak Kendra/Trikona bhava.
    final p3Houses = <int>[
      if (owns(4)) 4,
      if (owns(10)) 10,
      if (owns(5)) 5,
      if (owns(9)) 9,
    ];
    final p3 = !grahaDef && p3Houses.any(houseWeak);
    add(
      id: 'GEM-P3',
      title: 'Principle 3 — Bhavabala deficient despite planet strength',
      page: 4,
      matched: p3,
      inspection: p3Houses.isEmpty
          ? '4/10 Kendra లేదా 5/9 Trikona lordship లేదు.'
          : 'Graha strength ${v.shodashaVimsopaka.toStringAsFixed(2)}/20; relevant SAV ${p3Houses.map((h) => '$h=${ashtakavarga.arithmetic.savHouse(h)}').join(', ')}.',
    );

    // PRINCIPLE 4 — natural benefic Kendra-lord restriction.
    final p4 = _naturalBenefics.contains(planet) &&
        (owns(4) || owns(7) || owns(10)) &&
        grahaDef;
    add(
      id: 'GEM-P4',
      title: 'Principle 4 — Natural benefic Kendra lord restriction',
      page: 4,
      matched: p4,
      blocking: p4,
      inspection: _naturalBenefics.contains(planet)
          ? 'Natural benefic; Kendra ownership: ${[4, 7, 10].where(owns).join(', ')}; Varga Bala ${v.shodashaVimsopaka.toStringAsFixed(2)}/20.'
          : 'ఈ గ్రహం source listలో natural benefic కాదు.',
    );

    // PRINCIPLE 5 — natural malefic 4/10 Kendra lord can be strengthened.
    final p5 = _naturalMalefics.contains(planet) &&
        (owns(4) || owns(10)) &&
        grahaDef;
    add(
      id: 'GEM-P5',
      title: 'Principle 5 — Natural malefic Kendra lord',
      page: 5,
      matched: p5,
      inspection: _naturalMalefics.contains(planet)
          ? 'Natural malefic; 4/10 ownership: ${[4, 10].where(owns).join(', ')}; Varga Bala ${v.shodashaVimsopaka.toStringAsFixed(2)}/20.'
          : 'ఈ గ్రహం source listలో natural malefic కాదు.',
    );

    // PRINCIPLE 6 — Maraka/Badhaka caution.
    final badhaka = badhakaHouse(chart);
    final marakaOrBadhaka = owns(2) || owns(7) || owns(badhaka);
    add(
      id: 'GEM-P6',
      title: 'Principle 6 — Maraka / Badhaka caution',
      page: 6,
      matched: marakaOrBadhaka,
      conditional: marakaOrBadhaka,
      inspection: marakaOrBadhaka
          ? 'ఈ గ్రహం 2/7 Maraka లేదా $badhaka Badhaka house lordship కలిగి ఉంది: ${owned.where((h) => h == 2 || h == 7 || h == badhaka).join(', ')}.'
          : 'Maraka/Badhaka lordship లేదు.',
    );

    // PRINCIPLE 7 — Trikona lord placed in Maraka/Badhaka, weak support.
    final isTriLord = owns(5) || owns(9);
    final p7 = isTriLord &&
        (placement == 2 || placement == 7 || placement == badhaka) &&
        ([if (owns(5)) 5, if (owns(9)) 9].any(houseWeak));
    add(
      id: 'GEM-P7',
      title: 'Principle 7 — Trikona lord in Maraka/Badhaka',
      page: 6,
      matched: p7,
      inspection: isTriLord
          ? 'Trikona lord; placement house $placement; relevant Bhava SAV ${[if (owns(5)) 5, if (owns(9)) 9].map((h) => '$h=${ashtakavarga.arithmetic.savHouse(h)}').join(', ')}.'
          : 'Trikona lord కాదు.',
    );

    // PRINCIPLE 8 — Dushthana conditional remedy with Trikona/Lagna support.
    final dush = <int>[if (owns(6)) 6, if (owns(8)) 8, if (owns(12)) 12];
    final dualBeneficOwnership = owns(1) || owns(5) || owns(9);
    final trikonaLords = {lordOfHouse(chart, 5), lordOfHouse(chart, 9)};
    final conjoinedTrikona = chart.planets.any(
      (other) => other.name != planet &&
          trikonaLords.contains(other.name) &&
          other.signIndex == p.signIndex,
    );
    final p8 = dush.any((h) => grahaDef && houseStrong(h)) &&
        (dualBeneficOwnership || conjoinedTrikona);
    add(
      id: 'GEM-P8',
      title: 'Principle 8 — Dushthana Lord conditional remedy',
      page: 9,
      matched: p8,
      conditional: p8,
      inspection: dush.isEmpty
          ? '6/8/12 lordship లేదు.'
          : 'Dushthana ownership ${dush.join(', ')}; Varga Bala ${v.shodashaVimsopaka.toStringAsFixed(2)}/20; SAV ${dush.map((h) => '$h=${ashtakavarga.arithmetic.savHouse(h)}').join(', ')}; Lagna/Trikona dual ownership=$dualBeneficOwnership; Trikona conjunction=$conjoinedTrikona.',
    );
    if (p8) {
      final safeguard = lordOfHouse(chart, 9);
      if (safeguard != planet) safeguards.add('Trikona support gem: ${gemNames[safeguard]?.$1 ?? safeguard} ($safeguard)');
    }

    // PRINCIPLE 9 — Maraka, safeguarded. Intent still must be established.
    final marakaStrong = (owns(2) && houseStrong(2)) || (owns(7) && houseStrong(7));
    final p9 = (owns(2) || owns(7)) && grahaDef && marakaStrong;
    add(
      id: 'GEM-P9',
      title: 'Principle 9 — Maraka safeguarded remedy',
      page: 11,
      matched: p9,
      conditional: p9,
      inspection: (owns(2) || owns(7))
          ? 'Maraka lord; Varga Bala ${v.shodashaVimsopaka.toStringAsFixed(2)}/20; 2వ SAV ${ashtakavarga.arithmetic.savHouse(2)}, 7వ SAV ${ashtakavarga.arithmetic.savHouse(7)}. Beneficial 2nd/7th outcome అవసరం user intentగా establish చేయాలి.'
          : '2వ/7వ lordship లేదు.',
    );
    if (p9) {
      final safeLord = lagnaLord == planet ? lordOfHouse(chart, 9) : lagnaLord;
      safeguards.add('Principle 9 safeguard: ${gemNames[safeLord]?.$1 ?? safeLord} ($safeLord)');
    }

    // PRINCIPLE 10 — only explicit source safe rule for Chara Lagna 11th lord.
    final movable = const {0, 3, 6, 9}.contains(chart.ascendantSignIndex);
    final p10 = movable && owns(11) && grahaDef && houseStrong(11);
    add(
      id: 'GEM-P10',
      title: 'Principle 10 — Chara Lagna Badhaka safeguarded remedy',
      page: 12,
      matched: p10,
      conditional: p10,
      inspection: movable
          ? 'Chara Lagna; 11వ lordship=${owns(11)}; Varga Bala ${v.shodashaVimsopaka.toStringAsFixed(2)}/20; 11వ SAV ${ashtakavarga.arithmetic.savHouse(11)}. Source-listed beneficial outcome అవసరం establish చేయాలి.'
          : 'లగ్నం Chara కాదు; Principle 10 auto-apply చేయలేదు.',
    );
    if (p10) {
      final safeLord = lagnaLord == planet ? lordOfHouse(chart, 9) : lagnaLord;
      safeguards.add('Principle 10 safeguard: ${gemNames[safeLord]?.$1 ?? safeLord} ($safeLord)');
    }

    if (planet == 'Rahu' || planet == 'Ketu') {
      add(
        id: 'GEM-RK1',
        title: 'Rahu–Ketu Principle 1 — Never combine both node gems',
        page: 13,
        matched: true,
        conditional: true,
        inspection: 'ఈ node gemను ఇతర node gemతో ఒకేసారి combine చేయకూడదు.',
      );
      final rk2 = placement == 8 || placement == 12;
      add(
        id: 'GEM-RK2',
        title: 'Rahu–Ketu Principle 2 — 8th / 12th restriction',
        page: 14,
        matched: rk2,
        blocking: rk2,
        inspection: 'ఈ node $placementవ భావంలో ఉంది.',
      );
      add(
        id: 'GEM-RK3',
        title: 'Rahu–Ketu Principle 3 — Gulika / Mandi association',
        page: 14,
        matched: false,
        inspection: 'ఈ build chart modelలో Gulika/Mandi input లేదు; ఈ restrictionను auto-clear చేయము.',
        conditional: true,
      );
      final sunMoonAssoc = chart.planets.any(
        (x) => (x.name == 'Sun' || x.name == 'Moon') && x.signIndex == p.signIndex,
      );
      add(
        id: 'GEM-RK4',
        title: 'Rahu–Ketu Principle 4 — Sun / Moon association',
        page: 15,
        matched: sunMoonAssoc,
        conditional: sunMoonAssoc,
        inspection: sunMoonAssoc
            ? 'Node Sun/Moonతో అదే రాశిలో conjunction/associationగా ఉంది; Sun/Moon gem effect restriction sourceలో ఉంది.'
            : 'Sun/Moonతో same-sign conjunction లేదు.',
      );
    }

    final matched = rules.where((r) => r.matched).toList(growable: false);
    final blocked = matched.any((r) => r.blocking);
    final conditional = matched.any((r) => r.conditional);
    final positive = matched.any((r) =>
        !r.blocking && !r.conditional &&
        const {'GEM-P1', 'GEM-P2', 'GEM-P3', 'GEM-P5', 'GEM-P7'}.contains(r.id));

    final GemDecisionStatus status;
    final String summary;
    if (blocked) {
      status = GemDecisionStatus.restricted;
      summary = '${gem.$1} ప్రస్తుతం source restrictionలో ఉంది. Applied ruleను టచ్ చేసి కారణం చూడండి.';
    } else if (conditional) {
      status = GemDecisionStatus.conditional;
      summary = positive
          ? '${gem.$1}కు అనుకూల rule ఉంది, కానీ safeguard/restriction condition కూడా ఉంది. Final use ముందు applied rules అన్నీ చూడండి.'
          : '${gem.$1} source ప్రకారం conditional. అవసరమైన safeguard/intent/exception పూర్తిగా match అయిన తర్వాత మాత్రమే consider చేయాలి.';
    } else if (positive) {
      status = GemDecisionStatus.eligible;
      summary = '${gem.$1}కు source-backed eligibility condition match అయింది.';
    } else {
      status = GemDecisionStatus.notIndicated;
      summary = '${gem.$1}కు ఈ chartలో source-backed strengthening condition ప్రస్తుతం match కాలేదు.';
    }

    return GemEvaluation(
      planet: planet,
      gemEnglish: gem.$1,
      gemTelugu: gem.$2,
      status: status,
      summary: summary,
      strength: snapshot,
      rules: matched,
      safeguards: safeguards.toSet().toList(growable: false),
    );
  }
}
