/// Western Timing & BTR foundation, separate from Vedic dasha engines.
/// Calculations require trustworthy ephemeris longitude inputs at requested
/// dates (including times before birth for converse techniques).
/// No claimed precision beyond supplied ephemeris; no invented Primary Directions.

enum WesternMethod {
  secondaryProgression,
  solarArc,
  tertiaryProgression,
  minorProgression,
  naibodDirection,
  symbolicOneDegree,
  primaryDirections,
  converseProgression,
  annualProfection,
}

class WesternTimingEngine {
  static const double tropicalYearDays = 365.2425;
  static const double synodicMonthDays = 29.530588853;
  static const double siderealMonthDays = 27.321661;
  static const double naibodDegreesPerYear = 0.98564736;

  /// Returns fractional civil years since birth, not rounded birthdays.
  static double ageYears(DateTime birth, DateTime event) {
    final micros = event.toUtc().difference(birth.toUtc()).inMicroseconds;
    return micros / Duration.microsecondsPerDay / tropicalYearDays;
  }

  /// Day-for-year; for event 30y later, natal ephemeris sampled 30d later.
  static DateTime secondaryDate(DateTime birth, DateTime event,
      {bool converse = false}) {
    final days = ageYears(birth, event) * (converse ? -1.0 : 1.0);
    return birth.add(Duration(microseconds:
        (days * Duration.microsecondsPerDay).round()));
  }

  /// Tertiary-I convention: one day of ephemeris corresponds to one
  /// synodic lunar month of lived time; other schools use alternatives.
  static DateTime tertiaryDate(DateTime birth, DateTime event) {
    final elapsedDays = event.toUtc().difference(birth.toUtc()).inMicroseconds /
        Duration.microsecondsPerDay;
    final ephemerisDays = elapsedDays / synodicMonthDays;
    return birth.add(Duration(microseconds:
        (ephemerisDays * Duration.microsecondsPerDay).round()));
  }

  /// Minor convention: one sidereal lunar month in ephemeris per life year.
  static DateTime minorDate(DateTime birth, DateTime event) => birth.add(
    Duration(microseconds: (ageYears(birth, event) * siderealMonthDays *
        Duration.microsecondsPerDay).round()));

  static double normalize(double x) => (x % 360 + 360) % 360;
  static double signedShortestArc(double destination, double origin) =>
      ((normalize(destination - origin) + 540) % 360) - 180;

  /// Solar Arc: forward arc is the signed distance natal Sun -> progressed
  /// Sun. Add this arc to *natal* body/angle longitude. Do not identify
  /// Solar Arc with symbolic 1 degree per year.
  static double solarArcPosition({required double natalBody,
    required double natalSun, required double progressedSun}) => normalize(
      natalBody + signedShortestArc(progressedSun, natalSun));

  static double symbolicPosition(double natalLongitude, double ageYears,
      {double degreesPerYear = 1.0, bool converse = false}) => normalize(
      natalLongitude + (converse ? -1 : 1) * ageYears * degreesPerYear);

  static double naibodPosition(double natalLongitude, double age,
      {bool converse = false}) => symbolicPosition(natalLongitude, age,
        degreesPerYear: naibodDegreesPerYear, converse: converse);

  /// Standard whole-sign annual profection. 0 means birth sign; 1 means
  /// next sign. Requires sign index 0=Aries to 11=Pisces.
  static int annualProfectionSign(int natalAscendantSign, int completedYears) {
    if (natalAscendantSign < 0 || natalAscendantSign > 11) {
      throw ArgumentError('natalAscendantSign must be 0..11');
    }
    if (completedYears < 0) throw ArgumentError('completedYears cannot be negative');
    return (natalAscendantSign + completedYears) % 12;
  }

  /// Returns orb distance from the nearest exact aspect. Empty for invalid
  /// inputs; does not claim an event occurred.
  static double? aspectOrb(double a, double b, double aspect) {
    if (![0.0,60.0,90.0,120.0,180.0].contains(aspect) ||
        !a.isFinite || !b.isFinite) return null;
    final separation = signedShortestArc(a, b).abs();
    return (separation - aspect).abs();
  }

  /// Full primary directions need astronomical right ascension/declination,
  /// geographical latitude, oblique ascensions, promissor/significator,
  /// direction key and house system; never fake them from ecliptic longitude.
  static Never primaryDirectionsNotReady() => throw UnsupportedError(
      'Full Primary Directions require an astronomical direction engine');
}

class WesternMethodStatus {
  final WesternMethod method;
  final String methodName;
  final String status;
  final String constraint;
  const WesternMethodStatus(this.method, this.methodName, this.status, this.constraint);
}

const westernMethodCoverage = <WesternMethodStatus>[
  WesternMethodStatus(WesternMethod.secondaryProgression, 'Secondary Progression',
      'date mapping implemented', 'Exact positions require an ephemeris at progressed date'),
  WesternMethodStatus(WesternMethod.solarArc, 'Solar Arc', 'longitude transform implemented',
      'Requires natal Sun and progressed Sun ephemeris positions'),
  WesternMethodStatus(WesternMethod.tertiaryProgression, 'Tertiary',
      'Tertiary-I date mapping implemented', 'Synodic-month convention; verify preferred school'),
  WesternMethodStatus(WesternMethod.minorProgression, 'Minor',
      'date mapping implemented', 'Sidereal lunar-month convention; verify preferred school'),
  WesternMethodStatus(WesternMethod.naibodDirection, 'Naibod',
      'symbolic longitude transform implemented', 'Not equivalent to full Primary Directions'),
  WesternMethodStatus(WesternMethod.symbolicOneDegree, '1° Symbolic',
      'symbolic longitude transform implemented', 'Not a separate astronomical direction'),
  WesternMethodStatus(WesternMethod.primaryDirections, 'Primary Directions',
      'not implemented', 'Needs complete celestial-coordinate directions algorithm'),
  WesternMethodStatus(WesternMethod.converseProgression, 'Converse',
      'secondary converse mapping implemented', 'Converse for every direction system not implemented'),
  WesternMethodStatus(WesternMethod.annualProfection, 'Annual Profection',
      'whole-sign profected sign implemented', 'Requires ascendant sign and sign-ruler attribution'),
];
