import 'bpd_pada_dasa_service.dart';
import 'btr_macro_context_service.dart';
import 'mehta_btr_service.dart';

/// Transparent, non-scoring cross-method audit of ONE observed historical event.
/// Status is not an astrological probability, and contextual sign matches do
/// not constitute independent evidence of a birth second. This module DOES NOT
/// influence the original ranking, chart calculation, or dasha calculations.
enum BtrAuditStatus {
  sourceRuleMatched,
  sourceRuleNotMet,
  contextAligned,
  contextNotAligned,
  needsVerification,
}

extension BtrAuditStatusText on BtrAuditStatus {
  String get label => switch (this) {
    BtrAuditStatus.sourceRuleMatched => '✅ గణించిన మూల రూల్ సరిపోయింది',
    BtrAuditStatus.sourceRuleNotMet => '❌ ఎంపిక చేసిన రూల్ షరతు సరిపోలలేదు',
    BtrAuditStatus.contextAligned => '◉ సందర్భ సంబంధం కనిపించింది',
    BtrAuditStatus.contextNotAligned => '○ ఈ సందర్భ సంబంధం కనిపించలేదు',
    BtrAuditStatus.needsVerification => '⚪ పూర్తి పరీక్ష అందుబాటులో లేదు',
  };
}

class BtrMethodFinding {
  final String method;
  final String sourceRule;
  final BtrAuditStatus status;
  final String details;
  /// True ONLY for actual book-rule evaluator matches, not progression links.
  bool get isSourceRuleMatched => status == BtrAuditStatus.sourceRuleMatched;
  const BtrMethodFinding(this.method, this.sourceRule, this.status, this.details);
}

class BtrIntegratedMethodService {
  static const disclaimer =
      'BNN, BPD, BCP సందర్భ సూచనలు మాత్రమే. ఒకే జాతక/భావ సంబంధాన్ని '
      'మళ్లీ మళ్లీ స్వతంత్ర ఓట్లుగా లెక్కించవద్దు. KP పూర్తి Cusp/Sub-Lord '
      'ఫలిత గణన లేకుండా సంఘటనకు ✅/❌ ప్రకటించరాదు. '
      'ఈ పట్టిక BTR స్కోరును, జనన సెకను ఖచ్చితత్వాన్ని పెంచదు.';

  static BtrMethodFinding bnn(
      BtrMacroContext? macro, List<int> houses) {
    if (macro == null) {
      return const BtrMethodFinding('BNN', 'N12-01 / N12-02 / N12-03',
          BtrAuditStatus.needsVerification, 'జన్మ గురు రాశి లభించలేదు.');
    }
    int house(int sign) => (sign - macro.natalAscSignIndex + 12) % 12 + 1;
    final majorHouse = house(macro.jupiterMajorSignIndex);
    final minorHouse = house(macro.jupiterMinorSignIndex);
    final matched = houses.contains(majorHouse) || houses.contains(minorHouse);
    return BtrMethodFinding('BNN', 'N12-01 / N12-02',
        matched ? BtrAuditStatus.contextAligned : BtrAuditStatus.contextNotAligned,
        'గురు Major ${BtrMacroContext.signs[macro.jupiterMajorSignIndex]} '
        '(లగ్నం నుంచి $majorHouse), Minor '
        '${BtrMacroContext.signs[macro.jupiterMinorSignIndex]} '
        '(లగ్నం నుంచి $minorHouse). సంఘటన భావాలు: ${houses.join(', ')}. '
        'ఇది సరళ రాశి–భావ పోలిక మాత్రమే; N12-03 పూర్తి జన్మగ్రహ/కారక సంబంధ '
        'నియమ పరిశీలన కాదు.');
  }

  static BtrMethodFinding bcp(
      BtrMacroContext? macro, List<int> houses) {
    if (macro == null) {
      return const BtrMethodFinding('BCP', 'BCP-01 / BCP-02',
          BtrAuditStatus.needsVerification, 'జనన/సంఘటన తేదీ గణన లభించలేదు.');
    }
    final aligned = houses.contains(macro.bcpHouse);
    return BtrMethodFinding('BCP', 'BCP-01 / BCP-02',
        aligned ? BtrAuditStatus.contextAligned : BtrAuditStatus.contextNotAligned,
        'పూర్తి వయస్సు ${macro.completedAge} • క్రియాశీల భావం ${macro.bcpHouse}. '
        'ఈ సంఘటన భావాలు ${houses.join(', ')}. '
        'భావం సరిపోకపోవడం సంఘటన జరగలేదనే నిర్ధారణ కాదు.');
  }

  static BtrMethodFinding bpd(
      BpdEventContext? context, List<int> houses) {
    if (context == null) {
      return const BtrMethodFinding('BPD', 'BPD_VAANI / NADI_PRAVESHIKA',
          BtrAuditStatus.needsVerification, 'పాద దశ గణన లభించలేదు.');
    }
    final byPlanet = {for (final step in context.progressions) step.planet: step};
    final linked = <String>[];
    final checked = <String>[];
    // Use the EXACT same P-house relation as the existing BPD context engine.
    // It is a descriptive link only; absence is not a predictive contradiction.
    for (final h in houses.toSet()) {
      if (h < 1 || h > 12) continue;
      final pada = context.arudhaSigns[h];
      if (pada == null) continue;
      final planet = BpdPadaDasaService.signLords[pada];
      final progress = byPlanet[planet];
      if (progress == null) continue;
      final target = (context.natalAscSignIndex + h - 1) % 12;
      final sign = progress.progressedSign;
      final relation = sign == target || sign == pada ||
          BpdPadaDasaService.kendra(target, sign);
      final detail = 'P$h $planet → ${BpdPadaDasaService.signs[sign]}';
      checked.add(detail);
      if (relation) linked.add(detail);
    }
    final summary = 'ప్రొఫైల్: ${context.profile.label}. '
        'పరీక్షించిన పాదాలు: ${checked.isEmpty ? 'లేవు' : checked.join(' • ')}. '
        'రాశి/కేంద్ర సంబంధం: ${linked.isEmpty ? 'లేదు' : linked.join(' • ')}. '
        '23 Dictumsలో ఇతర సందర్భ సూచనలు ఇక్కడ ఆటోమేటిక్ సంఘటన రుజువులు కావు.';
    return BtrMethodFinding('BPD', context.profile.reference,
        checked.isEmpty ? BtrAuditStatus.needsVerification
            : (linked.isNotEmpty ? BtrAuditStatus.contextAligned
                : BtrAuditStatus.contextNotAligned), summary);
  }

  static BtrMethodFinding mehta(MehtaBtrEventEvidence evidence) {
    final source = evidence.sourceCheck;
    if (!source.evaluated) {
      return BtrMethodFinding('SK Mehta', source.ruleId ?? 'M timing',
        BtrAuditStatus.needsVerification,
        '${source.explanation} '
        'దశా పోలిక సూచిక ${(evidence.combinedShare * 100).toStringAsFixed(1)}% '
        '(జనన సమయ సంభావ్యత కాదు).');
    }
    return BtrMethodFinding('SK Mehta', source.ruleId ?? 'source',
      source.matched ? BtrAuditStatus.sourceRuleMatched
          : BtrAuditStatus.sourceRuleNotMet,
      '${source.explanation} '
      'దశా పోలిక సూచిక ${(evidence.combinedShare * 100).toStringAsFixed(1)}%. '
      'రూల్ సరిపోకపోవడం వల్ల సంఘటన జరగలేదని నిర్ధారించరాదు.');
  }

  static BtrMethodFinding kp(String signature) {
    return BtrMethodFinding('KP', 'KP-01 / KP-02',
      BtrAuditStatus.needsVerification,
      'లగ్న Sign/Star/Sub/Sub-Sub మరియు వర్గలగ్న fingerprint: $signature. '
      'ఇది జనన సమయం మారినప్పుడు చక్ర సరిహద్దుల గుర్తింపు మాత్రమే. '
      'సంఘటన-సంబంధిత KP cusp significators / sub-lord promise '
      'ఇంకా పూర్తి పరీక్ష కాలేదు.');
  }

  /// Raw record counts for display only. Correlated events are NOT re-scored.
  static List<String> overview(
      List<MehtaBtrEventEvidence> evidence, String kpSignature) {
    final findings = <BtrMethodFinding>[
      for (final event in evidence) ...forEvent(event, kpSignature),
    ];
    const methods = ['BNN', 'BPD', 'BCP', 'SK Mehta', 'KP'];
    final output = <String>[];
    for (final method in methods) {
      final items = findings.where((finding) => finding.method == method).toList();
      final sourceMatches = items.where((f) =>
          f.status == BtrAuditStatus.sourceRuleMatched).length;
      final sourceNotMet = items.where((f) =>
          f.status == BtrAuditStatus.sourceRuleNotMet).length;
      final contextual = items.where((f) =>
          f.status == BtrAuditStatus.contextAligned).length;
      final notAligned = items.where((f) =>
          f.status == BtrAuditStatus.contextNotAligned).length;
      final pending = items.where((f) =>
          f.status == BtrAuditStatus.needsVerification).length;
      output.add('$method: గ్రంథ రూల్ మ్యాచ్ $sourceMatches, '
          'రూల్ షరతు సరిపోలనివి $sourceNotMet, '
          'సందర్భ సంబంధం $contextual, సందర్భ సంబంధం లేనివి $notAligned, '
          'మాన్యువల్/పూర్తికాని పరీక్ష $pending (మొత్తం ${items.length} రికార్డులు)');
    }
    return output;
  }

  static List<BtrMethodFinding> forEvent(
      MehtaBtrEventEvidence evidence, String kpSignature) {
    final houses = MehtaBtrService.ruleFor(evidence.event.ruleId).ascHouses;
    return <BtrMethodFinding>[
      bnn(evidence.macroContext, houses),
      bpd(evidence.bpdContext, houses),
      bcp(evidence.macroContext, houses),
      mehta(evidence),
      kp(kpSignature),
    ];
  }
}
