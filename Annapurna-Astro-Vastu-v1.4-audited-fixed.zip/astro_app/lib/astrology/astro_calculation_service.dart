import 'package:sweph/sweph.dart';

import '../models/birth_data.dart';
import 'astro_models.dart';

class AstroCalculationService {
  static bool _initialized = false;
  static Object? _initError;
  static Future<void>? _initializing;

  static bool get isInitialized => _initialized;
  static String? get initError => _initError?.toString();

  static Future<void> initialize() {
    if (_initialized) return Future<void>.value();
    return _initializing ??= _initializeOnce();
  }

  static Future<void> _initializeOnce() async {
    try {
      // Moshier mode is used for the displayed planets, so separate .se1
      // planetary files are not required for the current calculation scope.
      await Sweph.init();
      _initialized = true;
      _initError = null;
    } catch (e) {
      _initError = e;
    } finally {
      _initializing = null;
    }
  }

  static Future<AstroChartResult> calculate(BirthData data) async {
    if (!_initialized) {
      await initialize();
    }
    if (!_initialized) {
      throw StateError(
        'Swiss Ephemeris initialize కాలేదు: ${_initError ?? 'unknown error'}',
      );
    }

    final utc = data.utcDateTime;
    final hour = utc.hour + utc.minute / 60.0 + utc.second / 3600.0;
    final jd = Sweph.swe_julday(
      utc.year,
      utc.month,
      utc.day,
      hour,
      CalendarType.SE_GREG_CAL,
    );

    Sweph.swe_set_sid_mode(
      _siderealModeFor(data.ayanamsa),
      SiderealModeFlag.SE_SIDBIT_NONE,
      0.0,
      0.0,
    );

    final flags = SwephFlag.SEFLG_MOSEPH |
        SwephFlag.SEFLG_SIDEREAL |
        SwephFlag.SEFLG_SPEED;

    final bodyMap = <HeavenlyBody, (String, String)>{
      HeavenlyBody.SE_SUN: ('Sun', 'Su'),
      HeavenlyBody.SE_MOON: ('Moon', 'Mo'),
      HeavenlyBody.SE_MARS: ('Mars', 'Ma'),
      HeavenlyBody.SE_MERCURY: ('Mercury', 'Me'),
      HeavenlyBody.SE_JUPITER: ('Jupiter', 'Ju'),
      HeavenlyBody.SE_VENUS: ('Venus', 'Ve'),
      HeavenlyBody.SE_SATURN: ('Saturn', 'Sa'),
      HeavenlyBody.SE_TRUE_NODE: ('Rahu', 'Ra'),
    };

    final positions = <PlanetPosition>[];
    for (final entry in bodyMap.entries) {
      final pos = Sweph.swe_calc_ut(jd, entry.key, flags);
      positions.add(
        PlanetPosition(
          name: entry.value.$1,
          shortName: entry.value.$2,
          longitude: _norm(pos.longitude),
          latitude: pos.latitude,
          speed: pos.speedInLongitude,
        ),
      );
    }

    final rahu = positions.firstWhere((p) => p.name == 'Rahu');
    positions.add(
      PlanetPosition(
        name: 'Ketu',
        shortName: 'Ke',
        longitude: _norm(rahu.longitude + 180.0),
        latitude: -rahu.latitude,
        speed: rahu.speed,
      ),
    );

    final houseData = Sweph.swe_houses_ex(
      jd,
      SwephFlag.SEFLG_SIDEREAL,
      data.latitude,
      data.longitude,
      Hsys.P,
    );
    final ascendant = _norm(houseData.ascmc[AscmcIndex.SE_ASC.index]);
    final ayanamsa = Sweph.swe_get_ayanamsa_ut(jd);

    return AstroChartResult(
      julianDay: jd,
      ayanamsaDegrees: ayanamsa,
      ascendantLongitude: ascendant,
      planets: List<PlanetPosition>.unmodifiable(positions),
      engineVersion: Sweph.swe_version(),
    );
  }

  static SiderealMode _siderealModeFor(AyanamsaType ayanamsa) {
    return switch (ayanamsa) {
      AyanamsaType.lahiri => SiderealMode.SE_SIDM_LAHIRI,
      AyanamsaType.raman => SiderealMode.SE_SIDM_RAMAN,
      AyanamsaType.krishnamurti => SiderealMode.SE_SIDM_KRISHNAMURTI,
    };
  }

  static double _norm(double value) {
    var result = value % 360.0;
    if (result < 0) result += 360.0;
    return result;
  }
}
