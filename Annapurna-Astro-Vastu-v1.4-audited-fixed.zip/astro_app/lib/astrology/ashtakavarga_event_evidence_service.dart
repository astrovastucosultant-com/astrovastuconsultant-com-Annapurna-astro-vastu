import '../models/birth_data.dart';
import 'ashtakavarga_service.dart';
import 'ashtakavarga_timing_service.dart';
import 'astro_models.dart';
import 'dasha_service.dart';

class AvEventEvidence {
  final String key;
  final String title;
  final List<int> houses;
  final List<String> planets;
  final AvTimingTone tone;
  final String finalResult;
  final String houseEvidence;
  final String dashaEvidence;
  final String transitEvidence;
  final String timingEvidence;
  final String ruleIds;
  final int evidenceLayersPassed;
  final int evidenceLayersTotal;

  const AvEventEvidence({
    required this.key,
    required this.title,
    required this.houses,
    required this.planets,
    required this.tone,
    required this.finalResult,
    required this.houseEvidence,
    required this.dashaEvidence,
    required this.transitEvidence,
    required this.timingEvidence,
    required this.ruleIds,
    required this.evidenceLayersPassed,
    required this.evidenceLayersTotal,
  });
}

/// Cross-evidence layer for AV-007 and AV-022/AV-023.
///
/// This deliberately avoids converting bindus straight to a percentage.
/// It combines: (1) relevant house SAV evidence, (2) Vimshottari/Tribhagi
/// period relevance, and (3) the relevant planet's current transit BAV+SAV.
/// The final label is an app evidence label, not a classical probability.
class AshtakavargaEventEvidenceService {
  static const List<({
    String key,
    String title,
    List<int> houses,
    List<String> planets,
    String rules,
  })> _definitions = [
    (
      key: 'career',
      title: 'వృత్తి / ఉద్యోగం / వ్యాపారం',
      houses: [6, 10, 11, 12],
      planets: ['Mercury', 'Saturn'],
      rules: 'AV-013 + AV-007 + AV-020/021 + AV-022',
    ),
    (
      key: 'education',
      title: 'విద్య / ఉన్నత విద్య',
      houses: [5, 9],
      planets: ['Mercury', 'Jupiter'],
      rules: 'AV-014 + AV-007 + AV-020/021 + AV-022',
    ),
    (
      key: 'wealth',
      title: 'ధనం / లాభం',
      houses: [2, 11],
      planets: ['Jupiter', 'Mercury'],
      rules: 'AV-015 + AV-007 + AV-020/021 + AV-022',
    ),
    (
      key: 'property',
      title: 'ఇల్లు / స్థిరాస్తి / వాహనం',
      houses: [4],
      planets: ['Mars', 'Venus'],
      rules: 'AV-016 + AV-007 + AV-020/021 + AV-022',
    ),
    (
      key: 'siblings',
      title: 'సోదరులు / ప్రయత్నం',
      houses: [3],
      planets: ['Mars'],
      rules: 'AV-017 + AV-007 + AV-020/021 + AV-022',
    ),
    (
      key: 'marriage',
      title: 'వివాహం / భాగస్వామ్యం',
      houses: [7],
      planets: ['Venus', 'Jupiter'],
      rules: 'AV-018 + R11.21 + AV-007 + AV-022',
    ),
    (
      key: 'children',
      title: 'సంతానం',
      houses: [5],
      planets: ['Jupiter'],
      rules: 'R10.18–R10.20 + AV-007 + AV-022',
    ),
  ];

  static String _normalizeDashaLord(String lord) {
    for (final planet in const [
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    ]) {
      if (lord.contains(planet)) return planet;
    }
    return lord;
  }

  static AvTimingTone _houseTone(List<int> values) {
    final average = values.fold<int>(0, (a, b) => a + b) / values.length;
    if (average >= 28) return AvTimingTone.favorable;
    if (average < 25) return AvTimingTone.unfavorable;
    return AvTimingTone.neutral;
  }

  static ({AvTimingTone tone, String text}) _transitEvidence({
    required AstroChartResult transitChart,
    required AshtakavargaResult av,
    required List<String> planets,
  }) {
    var good = 0;
    var weak = 0;
    final parts = <String>[];
    for (final planet in planets) {
      final p = transitChart.planets.firstWhere((x) => x.name == planet);
      final bav = AshtakavargaService.bavAtLongitude(av, planet, p.longitude);
      final sav = AshtakavargaService.savAtLongitude(av, p.longitude);
      final positive = bav >= 5 && sav >= 28;
      final negative = bav <= 3 || sav < 25;
      if (positive) good++;
      if (negative) weak++;
      parts.add('$planet: ${p.signIndex + 1}లో BAV $bav/8, SAV $sav');
    }
    final tone = good > 0
        ? AvTimingTone.favorable
        : weak == planets.length
            ? AvTimingTone.unfavorable
            : AvTimingTone.neutral;
    return (tone: tone, text: parts.join(' • '));
  }

  static ({bool supportive, String text}) _dashaEvidence({
    required AstroChartResult natalChart,
    required BirthData birthData,
    required DateTime asOfLocal,
    required List<String> planets,
  }) {
    final results = <String>[];
    var supportive = false;
    for (final kind in const [
      DashaSystemKind.vimshottari,
      DashaSystemKind.tribhagi,
    ]) {
      final system = DashaService.system(
        kind: kind,
        chart: natalChart,
        birthDateTime: birthData.localDateTime,
      );
      final path = DashaService.pathAt(system, asOfLocal);
      if (path == null) {
        results.add('${system.label}: period unavailable');
        continue;
      }
      final md = _normalizeDashaLord(path.mahadasha.lord);
      final ad = _normalizeDashaLord(path.antardasha.lord);
      final pd = _normalizeDashaLord(path.pratyantardasha.lord);
      final hit = planets.contains(md) || planets.contains(ad) || planets.contains(pd);
      supportive = supportive || hit;
      results.add('${system.label}: $md / $ad / $pd${hit ? ' ✓' : ''}');
    }
    return (supportive: supportive, text: results.join(' • '));
  }

  static List<AvEventEvidence> evaluate({
    required BirthData birthData,
    required AstroChartResult natalChart,
    required AstroChartResult transitChart,
    required AshtakavargaResult av,
    required DateTime asOfLocal,
  }) {
    final out = <AvEventEvidence>[];
    for (final def in _definitions) {
      final houseValues = def.houses.map(av.arithmetic.savHouse).toList();
      final houseTone = _houseTone(houseValues);
      final dasha = _dashaEvidence(
        natalChart: natalChart,
        birthData: birthData,
        asOfLocal: asOfLocal,
        planets: def.planets,
      );
      final transit = _transitEvidence(
        transitChart: transitChart,
        av: av,
        planets: def.planets,
      );

      var passed = 0;
      if (houseTone == AvTimingTone.favorable) passed++;
      if (dasha.supportive) passed++;
      if (transit.tone == AvTimingTone.favorable) passed++;

      final tone = passed >= 3
          ? AvTimingTone.favorable
          : passed == 0 &&
                  (houseTone == AvTimingTone.unfavorable ||
                      transit.tone == AvTimingTone.unfavorable)
              ? AvTimingTone.unfavorable
              : AvTimingTone.neutral;
      final finalResult = switch (tone) {
        AvTimingTone.favorable => 'బలమైన సమిష్టి మద్దతు',
        AvTimingTone.unfavorable => 'ప్రస్తుతం బలహీన/జాగ్రత్త మద్దతు',
        _ => 'మధ్యస్థ / మిశ్రమ మద్దతు',
      };

      final timingProfile = AshtakavargaTimingService.evaluate(
        chart: natalChart,
        av: av,
      ).where((p) => def.planets.contains(p.planet)).toList();
      final timingParts = <String>[];
      for (final profile in timingProfile) {
        final top = profile.monthSupport.take(3).map((m) => m.monthNumber).join(', ');
        timingParts.add('${profile.planet}: top indices $top; దిక్కు ${profile.strongestDirections.join('/')}');
      }

      out.add(
        AvEventEvidence(
          key: def.key,
          title: def.title,
          houses: List<int>.unmodifiable(def.houses),
          planets: List<String>.unmodifiable(def.planets),
          tone: tone,
          finalResult: finalResult,
          houseEvidence: '${def.houses.join(', ')} భావాల SAV = ${houseValues.join(', ')}',
          dashaEvidence: dasha.text,
          transitEvidence: transit.text,
          timingEvidence: timingParts.join(' • '),
          ruleIds: def.rules,
          evidenceLayersPassed: passed,
          evidenceLayersTotal: 3,
        ),
      );
    }
    return List<AvEventEvidence>.unmodifiable(out);
  }
}
