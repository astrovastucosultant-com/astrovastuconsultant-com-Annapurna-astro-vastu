import '../models/birth_data.dart';
import 'ashtakavarga_event_evidence_service.dart';
import 'ashtakavarga_service.dart';
import 'ashtakavarga_timing_service.dart';
import 'astro_models.dart';
import 'dasha_service.dart';
import 'planet_detail_service.dart';

/// Client-facing consultation summaries.
///
/// This layer deliberately does not invent new astrology rules. It turns
/// calculations already available in the app into a speaking order that is
/// easier to use during a consultation. Labels such as Strong / Mixed /
/// Caution are app evidence labels, not probability percentages.
class ConsultationService {
  static const Map<String, String> planetThemes = {
    'Sun': 'అధికారం • పదవి • నాయకత్వం • తండ్రి సంబంధ అంశాలు',
    'Moon': 'మనస్సు • తల్లి • ప్రజలు • భావోద్వేగ స్పందన',
    'Mars': 'చర్య • ధైర్యం • సోదరులు • భూమి/ఆస్తి',
    'Mercury': 'విద్య • మాట • వ్యాపారం • లెక్కలు/కమ్యూనికేషన్',
    'Jupiter': 'జ్ఞానం • సంతానం • ధనం • గురుత్వం',
    'Venus': 'వివాహం • భాగస్వామ్యం • సుఖాలు • కళ/సంబంధాలు',
    'Saturn': 'ఉద్యోగం • శ్రమ • బాధ్యత • దీర్ఘకాల స్థిరత్వం',
    'Rahu': 'అసాధారణ దృష్టి • వేగమైన మార్పులు • విదేశీ/కొత్త పద్ధతులు',
    'Ketu': 'విముఖత • లోతైన పరిశీలన • అంతర్ముఖ దృష్టి',
  };

  static ConsultationPlanetSummary planetSummary({
    required AstroChartResult chart,
    required PlanetPosition planet,
  }) {
    final detail = PlanetDetailService.forPlanet(chart, planet);
    final score = detail.vargaStrength.shodashaVimsopaka;
    final tone = score >= 13.5
        ? ConsultationTone.strong
        : score < 9.5
            ? ConsultationTone.caution
            : ConsultationTone.moderate;
    final label = switch (tone) {
      ConsultationTone.strong => 'వర్గ బలం బలంగా ఉంది',
      ConsultationTone.moderate => 'వర్గ బలం మధ్యస్థంగా ఉంది',
      ConsultationTone.caution => 'వర్గ బలం జాగ్రత్తగా పరిశీలించాలి',
      ConsultationTone.info => 'సాంకేతిక సమాచారం',
    };

    final d60Note = detail.amsaDevata.nature.contains('అశుభ')
        ? 'D60లో ${detail.amsaDevata.teluguName} అశుభ nature ఉంది; దీనిని ఒక్కదానితో final judgment చేయకుండా secondary evidenceగా మాత్రమే చూడాలి.'
        : 'D60లో ${detail.amsaDevata.teluguName} (${detail.amsaDevata.nature}) ఉంది; D1/D9/దశ evidenceతో కలిపి చదవాలి.';

    return ConsultationPlanetSummary(
      planet: planet.name,
      shortName: planet.shortName,
      theme: planetThemes[planet.name] ?? 'గ్రహ సంబంధ అంశాలు',
      tone: tone,
      strength: score,
      strengthLabel: label,
      starLord: detail.kp.starLord,
      subLord: detail.kp.subLord,
      amsaDevata: detail.amsaDevata.teluguName,
      amsaNature: detail.amsaDevata.nature,
      sayThis:
          '${planet.name} సంబంధ అంశాల్లో $label. Star Lord ${detail.kp.starLord}, Sub Lord ${detail.kp.subLord}. పూర్తి ఫలితం కోసం భావాధిపత్యం, సంబంధిత వర్గం, దశ మరియు గోచారాన్ని కలిసి చూడాలి.',
      technicalNote: d60Note,
    );
  }

  static List<ConsultationEventSummary> eventSummaries(
    List<AvEventEvidence> evidence,
  ) {
    return evidence.map((item) {
      final tone = switch (item.tone) {
        AvTimingTone.favorable => ConsultationTone.strong,
        AvTimingTone.unfavorable => ConsultationTone.caution,
        _ => ConsultationTone.moderate,
      };
      return ConsultationEventSummary(
        key: item.key,
        title: item.title,
        tone: tone,
        result: item.finalResult,
        sayThis: _sayThis(item.key, tone),
        practicalAdvice: _advice(item.key, tone),
        houseEvidence: item.houseEvidence,
        dashaEvidence: item.dashaEvidence,
        transitEvidence: item.transitEvidence,
        timingEvidence: item.timingEvidence,
        ruleIds: item.ruleIds,
        evidencePassed: item.evidenceLayersPassed,
        evidenceTotal: item.evidenceLayersTotal,
      );
    }).toList(growable: false);
  }

  static String _sayThis(String key, ConsultationTone tone) {
    final subject = <String, String>{
          'career': 'వృత్తి/ఉద్యోగం',
          'education': 'విద్య',
          'wealth': 'ధనం/లాభం',
          'property': 'ఇల్లు/స్థిరాస్తి',
          'siblings': 'సోదరులు/ప్రయత్నం',
          'marriage': 'వివాహం/భాగస్వామ్యం',
          'children': 'సంతానం',
        }[key] ??
        key;
    return switch (tone) {
      ConsultationTone.strong =>
        '$subject విషయంలో ప్రస్తుతం chart evidence సహాయకంగా ఉంది. ప్రయత్నం చేయడానికి మద్దతు కనిపిస్తోంది; ఖచ్చితమైన కాలాన్ని దశ–గోచార windowతో నిర్ధారించాలి.',
      ConsultationTone.caution =>
        '$subject విషయంలో ప్రస్తుతం evidence బలహీనంగా/జాగ్రత్తగా ఉంది. పెద్ద నిర్ణయం ముందు timing, సంబంధిత దశ మరియు ఇతర chart factorsను మళ్లీ పరిశీలించడం మంచిది.',
      _ =>
        '$subject విషయంలో మిశ్రమ మద్దతు ఉంది. అవకాశం ఉన్నా, timing మరియు ఇతర supporting factors సరిపోతేనే బలమైన ఫలితంగా చెప్పాలి.',
    };
  }

  static String _advice(String key, ConsultationTone tone) {
    final base = <String, String>{
          'career': 'ఉద్యోగ మార్పు/వ్యాపార నిర్ణయంలో offer, బాధ్యతలు, ఆర్థిక స్థితి వంటి practical factorsను కూడా verify చేయండి.',
          'education': 'కోర్సు, సమయం, ఖర్చు, ఆసక్తి—ఈ నాలుగు practical అంశాలను కలిసి చూసి నిర్ణయం తీసుకోండి.',
          'wealth': 'పెట్టుబడి/ఋణ నిర్ణయాలను జ్యోతిష్య సూచన ఒక్కదానిపై ఆధారపెట్టకుండా ఆర్థిక వివరాలు పరిశీలించండి.',
          'property': 'ఆస్తి విషయంలో documents, title, loan burden, locationను తప్పనిసరిగా verify చేయండి.',
          'siblings': 'సంబంధం/ప్రయత్నంలో communication clearగా ఉంచడం మరియు తొందరపాటు తగ్గించడం ఉపయోగకరం.',
          'marriage': 'సంబంధంలో పరస్పర సంభాషణ, విలువలు, కుటుంబ పరిస్థితులు, consent వంటి practical అంశాలకు ప్రధాన ప్రాధాన్యం ఇవ్వాలి.',
          'children': 'కుటుంబ నిర్ణయాల్లో వ్యక్తిగత పరిస్థితులు, వైద్య/ఆర్థిక సలహాలు అవసరమైతే సంబంధిత నిపుణులను సంప్రదించాలి.',
        }[key] ??
        'ప్రధాన నిర్ణయాల్లో practical evidenceను కూడా కలిపి చూడండి.';
    if (tone == ConsultationTone.caution) {
      return 'ప్రస్తుతం తొందరపడకుండా $base';
    }
    return base;
  }

  static ConsultationDashaSummary dashaSummary({
    required BirthData birthData,
    required AstroChartResult chart,
    required DateTime asOfLocal,
  }) {
    String pathFor(DashaSystemKind kind) {
      final system = DashaService.system(
        kind: kind,
        chart: chart,
        birthDateTime: birthData.localDateTime,
      );
      final path = DashaService.pathAt(system, asOfLocal);
      if (path == null) return '${system.label}: కాలం అందుబాటులో లేదు';
      return '${system.label}: ${path.mahadasha.lord} / ${path.antardasha.lord} / ${path.pratyantardasha.lord}';
    }

    return ConsultationDashaSummary(
      vimshottari: pathFor(DashaSystemKind.vimshottari),
      tribhagi: pathFor(DashaSystemKind.tribhagi),
    );
  }

  static ConsultationOverallSummary overall(
    List<ConsultationEventSummary> events,
  ) {
    final strong = events.where((x) => x.tone == ConsultationTone.strong).length;
    final caution = events.where((x) => x.tone == ConsultationTone.caution).length;
    final mixed = events.length - strong - caution;
    final tone = strong >= 4 && caution <= 1
        ? ConsultationTone.strong
        : caution >= 3
            ? ConsultationTone.caution
            : ConsultationTone.moderate;
    final headline = switch (tone) {
      ConsultationTone.strong => 'ప్రస్తుతం సహాయక అంశాలు ఎక్కువగా కనిపిస్తున్నాయి',
      ConsultationTone.caution => 'ప్రస్తుతం జాగ్రత్తగా ఎంపికలు చేయాల్సిన దశ',
      _ => 'ప్రస్తుతం మిశ్రమ ఫలితాలు — అంశాలవారీగా చూడాలి',
    };
    return ConsultationOverallSummary(
      tone: tone,
      headline: headline,
      strongCount: strong,
      mixedCount: mixed,
      cautionCount: caution,
    );
  }
}

enum ConsultationTone { strong, moderate, caution, info }

class ConsultationPlanetSummary {
  final String planet;
  final String shortName;
  final String theme;
  final ConsultationTone tone;
  final double strength;
  final String strengthLabel;
  final String starLord;
  final String subLord;
  final String amsaDevata;
  final String amsaNature;
  final String sayThis;
  final String technicalNote;

  const ConsultationPlanetSummary({
    required this.planet,
    required this.shortName,
    required this.theme,
    required this.tone,
    required this.strength,
    required this.strengthLabel,
    required this.starLord,
    required this.subLord,
    required this.amsaDevata,
    required this.amsaNature,
    required this.sayThis,
    required this.technicalNote,
  });
}

class ConsultationEventSummary {
  final String key;
  final String title;
  final ConsultationTone tone;
  final String result;
  final String sayThis;
  final String practicalAdvice;
  final String houseEvidence;
  final String dashaEvidence;
  final String transitEvidence;
  final String timingEvidence;
  final String ruleIds;
  final int evidencePassed;
  final int evidenceTotal;

  const ConsultationEventSummary({
    required this.key,
    required this.title,
    required this.tone,
    required this.result,
    required this.sayThis,
    required this.practicalAdvice,
    required this.houseEvidence,
    required this.dashaEvidence,
    required this.transitEvidence,
    required this.timingEvidence,
    required this.ruleIds,
    required this.evidencePassed,
    required this.evidenceTotal,
  });
}

class ConsultationDashaSummary {
  final String vimshottari;
  final String tribhagi;

  const ConsultationDashaSummary({
    required this.vimshottari,
    required this.tribhagi,
  });
}

class ConsultationOverallSummary {
  final ConsultationTone tone;
  final String headline;
  final int strongCount;
  final int mixedCount;
  final int cautionCount;

  const ConsultationOverallSummary({
    required this.tone,
    required this.headline,
    required this.strongCount,
    required this.mixedCount,
    required this.cautionCount,
  });
}
