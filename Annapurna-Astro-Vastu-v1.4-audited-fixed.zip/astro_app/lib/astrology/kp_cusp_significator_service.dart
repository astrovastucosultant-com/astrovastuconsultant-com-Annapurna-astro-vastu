import 'astro_models.dart';
import 'kp_service.dart';

/// A separate KP/Placidus analysis. No BPD/BNN/BCP rules are used here.
/// The four levels are deliberately kept visible rather than collapsed into
/// an invented single 'KP certainty' score.
class KpCuspRow {
  final int house;
  final KpStellarPosition stellar;
  const KpCuspRow(this.house, this.stellar);
}

class KpPlanetSignification {
  final String planet;
  final String starLord;
  final int occupiedHouse;
  final List<int> starLordOccupied; // constellation-lord occupation
  final List<int> occupied;         // direct occupation
  final List<int> starLordOwned;    // constellation-lord ownership
  final List<int> owned;            // direct cusp sign ownership
  final bool isNode;
  const KpPlanetSignification({
    required this.planet,
    required this.starLord,
    required this.occupiedHouse,
    required this.starLordOccupied,
    required this.occupied,
    required this.starLordOwned,
    required this.owned,
    required this.isNode,
  });

  List<int> get houses {
    final all = <int>{
      ...starLordOccupied, ...occupied, ...starLordOwned, ...owned,
    }.toList()..sort();
    return all;
  }

  String get fourLevels => 'A నక్షత్రాధిపతి స్థానం: ${starLordOccupied.join(', ')}; '
      'B గ్రహస్థానం: ${occupied.join(', ')}; '
      'C నక్షత్రాధిపతి స్వామిత్వం: ${starLordOwned.join(', ')}; '
      'D గ్రహ స్వామిత్వం: ${owned.join(', ')}'
      '${isNode ? ' • రాహు/కేతు ప్రతినిధి/సంయోగ/దృష్టి ఇంకా మాన్యువల్' : ''}';
}

class KpEventAudit {
  final String label;
  final int primaryHouse;
  final List<int> favourableHouses;
  final List<int> contraryHouses;
  final KpCuspRow primaryCusp;
  final KpPlanetSignification subLord;
  final List<String> eventSignificators;
  final List<int> matchingHouses;
  final List<int> contraryMatches;
  final bool qualified;
  final String note;
  const KpEventAudit({
    required this.label,
    required this.primaryHouse,
    required this.favourableHouses,
    required this.contraryHouses,
    required this.primaryCusp,
    required this.subLord,
    required this.eventSignificators,
    required this.matchingHouses,
    required this.contraryMatches,
    required this.qualified,
    required this.note,
  });

  /// Context evidence, not a proven event-promise verdict.
  bool get hasFavourableLink => matchingHouses.isNotEmpty;
  String get detail => '$label: Cusp $primaryHouse '
      '${primaryCusp.stellar.longitude.toStringAsFixed(6)}° '
      'Star ${primaryCusp.stellar.starLord} / '
      'Sub ${primaryCusp.stellar.subLord} / '
      'Sub-Sub ${primaryCusp.stellar.subSubLord}. '
      'Sub Lord ${subLord.planet} → ${subLord.fourLevels}. '
      'అనుకూల భావ సంబంధం: ${matchingHouses.isEmpty ? 'లేదు' : matchingHouses.join(', ')}; '
      'వ్యతిరేక భావ సంబంధం: ${contraryMatches.isEmpty ? 'లేదు' : contraryMatches.join(', ')}. '
      'సూచక గ్రహాలు: ${eventSignificators.isEmpty ? 'లేవు' : eventSignificators.join(', ')}. '
      '$note';
}

class KpCuspSignificatorResult {
  final List<KpCuspRow> cusps;
  final Map<String, KpPlanetSignification> planets;
  final String? warning;
  const KpCuspSignificatorResult({
    required this.cusps, required this.planets, this.warning,
  });

  bool get available => warning == null && cusps.length == 12;
  String get signature => available
    ? cusps.map((row) => '${row.house}:${row.stellar.signIndex}/'
        '${row.stellar.nakshatraIndex}/${row.stellar.starLord}/'
        '${row.stellar.subLord}/${row.stellar.subSubLord}').join('|')
    : 'UNAVAILABLE';

  /// The KP house groups are independent of the S.K. Mehta rule's houses.
  KpEventAudit? forEvent(String mehtaEventId) {
    if (!available) return null;
    final config = KpCuspSignificatorService.eventMap[mehtaEventId];
    if (config == null) return null;
    final (label, primary, favourable, contrary) = config;
    final cusp = cusps[primary - 1];
    final lord = planets[cusp.stellar.subLord];
    if (lord == null) return null;
    final favourableLink = lord.houses.toSet().intersection(favourable.toSet()).toList()..sort();
    final contraryLink = lord.houses.toSet().intersection(contrary.toSet()).toList()..sort();
    final actors = planets.values.where((p) => p.houses.any(favourable.contains))
        .map((p) => p.planet).toList()..sort();
    final qualified = lord.isNode || contraryLink.isNotEmpty;
    return KpEventAudit(
      label: label, primaryHouse: primary, favourableHouses: favourable,
      contraryHouses: contrary, primaryCusp: cusp, subLord: lord,
      eventSignificators: actors, matchingHouses: favourableLink,
      contraryMatches: contraryLink, qualified: qualified,
      note: 'KP Cusp/Sub-lord, constellation occupation/ownership స్థాయిల పరిశీలన. '
          'రాహు/కేతు ప్రతినిధిత్వం, వక్రత్వం, గ్రహదృష్టులు, Dasha/Bhukti '
          'ఫలిత నిర్ణయం పూర్తిగా స్వయంచాలకంగా ధృవీకరించలేదు; '
          'ఈ సంబంధాన్ని జనన సెకను రుజువుగా పరిగణించవద్దు.',
    );
  }
}

class KpCuspSignificatorService {
  /// Source: the user's KP source rulebook (Cusp -> Star -> Sub ->
  /// Signification -> event houses). Application mapping from Mehta event ID
  /// to KP houses is explicit; never reuse Mehta ascHouses automatically.
  static const Map<String, (String, int, List<int>, List<int>)> eventMap = {
    'M01': ('Marriage', 7, [2, 7, 11], [1, 6, 10, 12]),
    'M02': ('Higher education / profession', 9, [4, 9, 11], <int>[]),
    'M03': ('Wealth', 2, [2, 6, 10, 11], [5, 8, 12]),
    'M04': ('Foreign travel', 12, [3, 9, 12], <int>[]),
    'M05': ('Foreign travel', 12, [3, 9, 12], <int>[]),
    'M06': ('Childbirth', 5, [2, 5, 11], [1, 4, 10]),
    'M07': ('Property', 4, [4, 11, 12], <int>[]),
    'M08': ('Vehicle', 4, [4, 11], <int>[]),
    'M11': ('Government service/promotion', 10, [2, 6, 10, 11], <int>[]),
    'M12': ('Private service/change', 10, [2, 6, 10, 11], <int>[]),
    'M13': ('Appointment', 10, [2, 6, 10, 11], <int>[]),
    'M14': ('Business', 7, [2, 7, 10, 11], <int>[]),
  };

  static KpCuspSignificatorResult compute(AstroChartResult chart) {
    if (chart.houseCuspLongitudes.length != 12) {
      return const KpCuspSignificatorResult(cusps: [], planets: {},
          warning: '12 Placidus KP house cusps లభించలేదు. గణనను ఊహించవద్దు.');
    }
    final values = chart.houseCuspLongitudes;
    if (values.any((x) => !x.isFinite)) {
      return const KpCuspSignificatorResult(cusps: [], planets: {},
          warning: 'Invalid cusp longitude; KP audit నిలిపివేశాం.');
    }
    double norm(double x) => (x % 360 + 360) % 360;
    final normalized = values.map(norm).toList(growable: false);
    final arcs = <double>[];
    for (var h = 0; h < 12; h++) {
      final arc = norm(normalized[(h + 1) % 12] - normalized[h]);
      if (arc < 1e-7) {
        return const KpCuspSignificatorResult(cusps: [], planets: {},
            warning: 'Degenerate house cusps; KP audit నిలిపివేశాం.');
      }
      arcs.add(arc);
    }
    // Normal order is mandatory; otherwise planets could be assigned to two
    // overlapping cuspal arcs, e.g. unsupported high-latitude cases.
    final arcSum = arcs.fold<double>(0, (a, b) => a + b);
    if ((arcSum - 360).abs() > 0.001) {
      return const KpCuspSignificatorResult(cusps: [], planets: {},
          warning: 'Cusps cyclic ordering invalid; KP audit నిలిపివేశాం.');
    }
    int houseOf(double longitude) {
      final p = norm(longitude);
      for (var i = 0; i < 12; i++) {
        if (norm(p - normalized[i]) < arcs[i]) return i + 1;
      }
      throw StateError('KP house boundary was not resolved');
    }
    final rows = <KpCuspRow>[
      for (var h = 0; h < 12; h++)
        KpCuspRow(h + 1, KpService.forLongitude('Cusp ${h + 1}', normalized[h])),
    ];
    final occupied = <String, int>{};
    final stars = <String, KpStellarPosition>{};
    for (final p in chart.planets) {
      occupied[p.name] = houseOf(p.longitude);
      stars[p.name] = KpService.forLongitude(p.name, p.longitude);
    }
    final owners = <String, List<int>>{};
    for (final row in rows) {
      owners.putIfAbsent(row.stellar.signLord, () => []).add(row.house);
    }
    final planets = <String, KpPlanetSignification>{};
    for (final p in chart.planets) {
      final lord = stars[p.name]!.starLord;
      final starOccupied = occupied.containsKey(lord) ? <int>[occupied[lord]!] : <int>[];
      planets[p.name] = KpPlanetSignification(
        planet: p.name, starLord: lord, occupiedHouse: occupied[p.name]!,
        starLordOccupied: starOccupied,
        occupied: [occupied[p.name]!],
        starLordOwned: owners[lord] ?? <int>[],
        owned: owners[p.name] ?? <int>[],
        isNode: p.name == 'Rahu' || p.name == 'Ketu',
      );
    }
    return KpCuspSignificatorResult(cusps: List.unmodifiable(rows),
        planets: Map.unmodifiable(planets));
  }
}
