import 'astro_models.dart';
import 'dasha_service.dart';

class SkMehtaEventRule {
  final String id;
  final String event;
  final String combination;
  final bool ascCheck;
  final bool moonAscCheck;
  final String primaryPeriodCheck;
  final String microSynchronization;
  final String tribhagi;
  final String timingAdjustment;
  final String replacement;
  final String appOutput;
  final List<int> ascHouses;
  final List<int> moonAscHouses;
  final List<String> fixedPlanets;
  final String source;
  final int requiredPrimaryMatches;

  const SkMehtaEventRule({
    required this.id,
    required this.event,
    required this.combination,
    required this.ascCheck,
    required this.moonAscCheck,
    required this.primaryPeriodCheck,
    required this.microSynchronization,
    required this.tribhagi,
    required this.timingAdjustment,
    required this.replacement,
    required this.appOutput,
    required this.ascHouses,
    this.moonAscHouses = const [],
    this.fixedPlanets = const [],
    required this.source,
    this.requiredPrimaryMatches = 0,
  });
}

class SkMehtaSyncResult {
  final DashaSystemResult system;
  final DashaPath? path;
  final List<String> expectedLords;
  final List<String> primaryPlaces;
  final int matchedCount;
  final int requiredMatchCount;

  const SkMehtaSyncResult({
    required this.system,
    required this.path,
    required this.expectedLords,
    required this.primaryPlaces,
    required this.matchedCount,
    required this.requiredMatchCount,
  });

  bool get fullPrimaryMatch =>
      expectedLords.isNotEmpty && matchedCount >= requiredMatchCount;
}

class SkMehtaChartEvidence {
  final SkMehtaEventRule rule;
  final List<String> ascLords;
  final List<String> moonAscLords;
  final SkMehtaSyncResult vimshottari;
  final SkMehtaSyncResult tribhagi;

  const SkMehtaChartEvidence({
    required this.rule,
    required this.ascLords,
    required this.moonAscLords,
    required this.vimshottari,
    required this.tribhagi,
  });
}

class SkMehtaService {
  // Aries..Pisces standard sign lords. This is used only to identify the
  // house lords required by the supplied Mehta event-combination table.
  static const List<String> _signLords = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];

  static const List<SkMehtaEventRule> events = [
    SkMehtaEventRule(
      id: 'M01',
      event: 'Marriage',
      combination: '1st + 7th + 12th Lords',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: '5th/6th only if needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Vimshottari >4–5 months disregard; Tribhagi >3–4 months disregard',
      replacement: 'Rahu/Ketu only for 1/7/12',
      appOutput: 'Final event window',
      ascHouses: [1, 7, 12],
      moonAscHouses: [1, 7, 12],
      source: 'SK Mehta Master App Command Table V2 — M01',
      requiredPrimaryMatches: 3,
    ),
    SkMehtaEventRule(
      id: 'M02',
      event: "Parents' Marriage",
      combination: 'Father: 9th+10th+4th; Mother: 3rd+4th+10th',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'If needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Source adjustment rules',
      replacement: 'Source-specific',
      appOutput: 'Final event window',
      ascHouses: [9, 10, 4, 3],
      moonAscHouses: [9, 10, 4, 3],
      source: 'SK Mehta Master App Command Table V2 — M02',
      requiredPrimaryMatches: 3,
    ),
    SkMehtaEventRule(
      id: 'M03',
      event: 'Economic Gain',
      combination: '2nd Lord strength; ASC + Moon ASC',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'Strong case may reach 4th → 5th',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Strength-based adjustment',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Money/gain window',
      ascHouses: [2],
      moonAscHouses: [2],
      source: 'SK Mehta Master App Command Table V2 — M03',
      requiredPrimaryMatches: 1,
    ),
    SkMehtaEventRule(
      id: 'M04',
      event: 'Foreign Tour — 12th + 4th',
      combination: '12th + 4th',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd',
      microSynchronization: '3rd→4th or 4th→5th when strength requires',
      tribhagi: 'Cross-check',
      timingAdjustment: '12th strong + 4th weak shifts later',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Departure window',
      ascHouses: [12, 4],
      moonAscHouses: [12, 4],
      source: 'SK Mehta Master App Command Table V2 — M04',
      requiredPrimaryMatches: 2,
    ),
    SkMehtaEventRule(
      id: 'M05',
      event: 'Foreign Tour — 12th + 7th',
      combination: '12th + 7th',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd',
      microSynchronization: '3rd→4th if strength requires',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Strength-based adjustment',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Departure window',
      ascHouses: [12, 7],
      moonAscHouses: [12, 7],
      source: 'SK Mehta Master App Command Table V2 — M05',
      requiredPrimaryMatches: 2,
    ),
    SkMehtaEventRule(
      id: 'M06',
      event: 'Child Birth',
      combination: '5th + 9th + 1st Lords',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: '5th/6th only if needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Source adjustment rules',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Birth window',
      ascHouses: [5, 9, 1],
      moonAscHouses: [5, 9, 1],
      source: 'SK Mehta Master App Command Table V2 — M06',
      requiredPrimaryMatches: 3,
    ),
    SkMehtaEventRule(
      id: 'M07',
      event: 'Property / House / Land',
      combination: '4th Lord strong; Mars portfolio for land',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'If needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Strength-based',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Purchase window',
      ascHouses: [4],
      moonAscHouses: [4],
      source: 'SK Mehta Master App Command Table V2 — M07',
      requiredPrimaryMatches: 1,
    ),
    SkMehtaEventRule(
      id: 'M08',
      event: 'Vehicle',
      combination: '4th Lord strong; Venus portfolio for vehicle',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'If needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Strength-based',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Purchase window',
      ascHouses: [4],
      moonAscHouses: [4],
      source: 'SK Mehta Master App Command Table V2 — M08',
      requiredPrimaryMatches: 1,
    ),
    SkMehtaEventRule(
      id: 'M10',
      event: 'Accident — source risk analysis',
      combination: 'Rahu + Ketu + 4th Lord; alternative 6th-lord combination',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'If needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Source adjustment rules',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Risk/source-condition window only — not a certainty prediction',
      ascHouses: [4],
      moonAscHouses: [4],
      fixedPlanets: ['Rahu', 'Ketu'],
      source: 'SK Mehta Master App Command Table V2 — M10',
      requiredPrimaryMatches: 3,
    ),
    SkMehtaEventRule(
      id: 'M15',
      event: 'Father-related death-event — source analysis only',
      combination: 'Native 12th + 3rd relationship in source',
      ascCheck: true,
      moonAscCheck: false,
      primaryPeriodCheck: 'Synchronization',
      microSynchronization: 'Only as source requires',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Do not infer individual certainty/date',
      replacement: 'Source-specific',
      appOutput: 'Source analysis only — no personal death-date prediction',
      ascHouses: [12, 3],
      source: 'SK Mehta Master App Command Table V2 — M15',
      requiredPrimaryMatches: 2,
    ),
    SkMehtaEventRule(
      id: 'M16',
      event: 'Mother-related death-event — source analysis only',
      combination: 'Native 6th + 9th relationship in source',
      ascCheck: true,
      moonAscCheck: false,
      primaryPeriodCheck: 'Synchronization',
      microSynchronization: 'Only as source requires',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Do not infer individual certainty/date',
      replacement: 'Source-specific',
      appOutput: 'Source analysis only — no personal death-date prediction',
      ascHouses: [6, 9],
      source: 'SK Mehta Master App Command Table V2 — M16',
      requiredPrimaryMatches: 2,
    ),
    SkMehtaEventRule(
      id: 'M11',
      event: 'Government Job / Promotion',
      combination: '9th+10th OR 10th+11th strong',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'If needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Strength-based',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Joining/promotion window',
      ascHouses: [9, 10, 11],
      moonAscHouses: [9, 10, 11],
      source: 'SK Mehta Master App Command Table V2 — M11',
      requiredPrimaryMatches: 2,
    ),
    SkMehtaEventRule(
      id: 'M12',
      event: 'Private Job / Promotion / Change',
      combination: '7th+9th OR 7th+11th',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'If needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Strength-based',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Job window',
      ascHouses: [7, 9, 11],
      moonAscHouses: [7, 9, 11],
      source: 'SK Mehta Master App Command Table V2 — M12',
      requiredPrimaryMatches: 2,
    ),
    SkMehtaEventRule(
      id: 'M13',
      event: 'New Appointment',
      combination: 'Same combination as private job change/promotion',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'If needed',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Strength-based',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Appointment window',
      ascHouses: [7, 9, 11],
      moonAscHouses: [7, 9, 11],
      source: 'SK Mehta Master App Command Table V2 — M13',
      requiredPrimaryMatches: 2,
    ),
    SkMehtaEventRule(
      id: 'M14',
      event: 'Business Start',
      combination: '7th + 11th Lords; strong 11th emphasized',
      ascCheck: true,
      moonAscCheck: true,
      primaryPeriodCheck: '2nd → 3rd → 4th',
      microSynchronization: 'Some strong cases extend later',
      tribhagi: 'Cross-check',
      timingAdjustment: 'Strength-based',
      replacement: 'General Mehta replacement rules',
      appOutput: 'Business-start window',
      ascHouses: [7, 11],
      moonAscHouses: [7, 11],
      source: 'SK Mehta Master App Command Table V2 — M14',
      requiredPrimaryMatches: 2,
    ),
  ];

  static const List<String> guardrails = [
    'Mehta-only: Parashara, Jaimini, KP, Ashtakavarga rulesను ఈ tabలో mix చేయకూడదు.',
    'Exact scan/table glyph స్పష్టంగా లేకపోతే ఊహించకూడదు.',
    "Timingను 'Mahadasha lord = event'గా తగ్గించకూడదు; period synchronization అవసరం.",
    'Primary hierarchy: 2nd → 3rd → 4th places; 5th/6th micro-synchronization అవసరమైతే మాత్రమే.',
    'Reverse calculation Ascendantను మార్చకూడదు.',
    'Valid Mehta combination mere repetition కంటే priority.',
    'Accident/death source materialను risk/source analysisగా మాత్రమే చూపాలి; certainty లేదా వ్యక్తిగత death-date prediction ఇవ్వకూడదు.',
  ];

  static String houseLordFromAsc(int ascSignIndex, int house) {
    final sign = (ascSignIndex + house - 1) % 12;
    return _signLords[sign];
  }

  static List<String> _lordsFor(
    int ascSignIndex,
    List<int> houses,
  ) {
    return houses
        .map((house) => houseLordFromAsc(ascSignIndex, house))
        .toList(growable: false);
  }

  static int _moonAscSign(AstroChartResult chart) =>
      chart.planets.firstWhere((p) => p.name == 'Moon').signIndex;

  static SkMehtaSyncResult _sync({
    required DashaSystemKind kind,
    required AstroChartResult chart,
    required DateTime birthDateTime,
    required DateTime at,
    required List<String> expectedLords,
    required int requiredMatchCount,
  }) {
    final system = DashaService.system(
      kind: kind,
      chart: chart,
      birthDateTime: birthDateTime,
    );
    final path = DashaService.pathAt(system, at);
    final primary = path == null
        ? const <String>[]
        : <String>[
            path.antardasha.lord,
            path.pratyantardasha.lord,
            path.sukshma.lord,
          ];
    final expected = expectedLords.toSet();
    final matched = expected.where(primary.contains).length;
    return SkMehtaSyncResult(
      system: system,
      path: path,
      expectedLords: expectedLords,
      primaryPlaces: primary,
      matchedCount: matched,
      requiredMatchCount: requiredMatchCount == 0 ? expected.length : requiredMatchCount,
    );
  }

  static SkMehtaChartEvidence evaluate({
    required SkMehtaEventRule rule,
    required AstroChartResult chart,
    required DateTime birthDateTime,
    DateTime? at,
  }) {
    final now = at ?? DateTime.now();
    final ascLords = _lordsFor(chart.ascendantSignIndex, rule.ascHouses);
    final moonAscLords = rule.moonAscCheck
        ? _lordsFor(_moonAscSign(chart),
            rule.moonAscHouses.isEmpty ? rule.ascHouses : rule.moonAscHouses)
        : const <String>[];
    // Mehta primary synchronization is evaluated from the ASC combination;
    // Moon ASC remains a confirmation layer and is shown separately in the UI.
    final expected = <String>{...ascLords, ...rule.fixedPlanets}.toList();
    return SkMehtaChartEvidence(
      rule: rule,
      ascLords: ascLords,
      moonAscLords: moonAscLords,
      vimshottari: _sync(
        kind: DashaSystemKind.vimshottari,
        chart: chart,
        birthDateTime: birthDateTime,
        at: now,
        expectedLords: expected,
        requiredMatchCount: rule.requiredPrimaryMatches,
      ),
      tribhagi: _sync(
        kind: DashaSystemKind.tribhagi,
        chart: chart,
        birthDateTime: birthDateTime,
        at: now,
        expectedLords: expected,
        requiredMatchCount: rule.requiredPrimaryMatches,
      ),
    );
  }
}
