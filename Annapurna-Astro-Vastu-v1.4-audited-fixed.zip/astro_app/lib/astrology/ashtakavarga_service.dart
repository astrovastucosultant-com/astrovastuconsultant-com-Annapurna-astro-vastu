import 'astro_models.dart';

class AshtakavargaResult {
  final Map<String, List<int>> bhinna;
  final List<int> sarva;
  final Map<String, Map<String, List<int>>> prastara;
  final Map<String, int> expectedPlanetTotals;
  final bool totalsValid;

  const AshtakavargaResult({
    required this.bhinna,
    required this.sarva,
    required this.prastara,
    required this.expectedPlanetTotals,
    required this.totalsValid,
  });

  int get grandTotal => sarva.fold(0, (sum, value) => sum + value);
  int totalFor(String planet) =>
      bhinna[planet]?.fold<int>(0, (sum, value) => sum + value) ?? 0;
}

/// Classical Parashari Bhinna Ashtakavarga (BAV) and Sarvashtakavarga (SAV).
/// Rahu and Ketu are excluded from the seven standard BAV rows.
class AshtakavargaService {
  static const List<String> planetOrder = [
    'Sun',
    'Moon',
    'Mars',
    'Mercury',
    'Jupiter',
    'Venus',
    'Saturn',
  ];

  static const Map<String, int> expectedTotals = {
    'Sun': 48,
    'Moon': 49,
    'Mars': 39,
    'Mercury': 54,
    'Jupiter': 56,
    'Venus': 52,
    'Saturn': 39,
  };

  static const Map<String, Map<String, List<int>>> _rules = {
    'Sun': {
      'Sun': [1, 2, 4, 7, 8, 9, 10, 11],
      'Moon': [3, 6, 10, 11],
      'Mars': [1, 2, 4, 7, 8, 9, 10, 11],
      'Mercury': [3, 5, 6, 9, 10, 11, 12],
      'Jupiter': [5, 6, 9, 11],
      'Venus': [6, 7, 12],
      'Saturn': [1, 2, 4, 7, 8, 9, 10, 11],
      'Lagna': [3, 4, 6, 10, 11, 12],
    },
    'Moon': {
      'Sun': [3, 6, 7, 8, 10, 11],
      'Moon': [1, 3, 6, 7, 10, 11],
      'Mars': [2, 3, 5, 6, 9, 10, 11],
      'Mercury': [1, 3, 4, 5, 7, 8, 10, 11],
      'Jupiter': [1, 4, 7, 8, 10, 11, 12],
      'Venus': [3, 4, 5, 7, 9, 10, 11],
      'Saturn': [3, 5, 6, 11],
      'Lagna': [3, 6, 10, 11],
    },
    'Mars': {
      'Sun': [3, 5, 6, 10, 11],
      'Moon': [3, 6, 11],
      'Mars': [1, 2, 4, 7, 8, 10, 11],
      'Mercury': [3, 5, 6, 11],
      'Jupiter': [6, 10, 11, 12],
      'Venus': [6, 8, 11, 12],
      'Saturn': [1, 4, 7, 8, 9, 10, 11],
      'Lagna': [1, 3, 6, 10, 11],
    },
    'Mercury': {
      'Sun': [5, 6, 9, 11, 12],
      'Moon': [2, 4, 6, 8, 10, 11],
      'Mars': [1, 2, 4, 7, 8, 9, 10, 11],
      'Mercury': [1, 3, 5, 6, 9, 10, 11, 12],
      'Jupiter': [6, 8, 11, 12],
      'Venus': [1, 2, 3, 4, 5, 8, 9, 11],
      'Saturn': [1, 2, 4, 7, 8, 9, 10, 11],
      'Lagna': [1, 2, 4, 6, 8, 10, 11],
    },
    'Jupiter': {
      'Sun': [1, 2, 3, 4, 7, 8, 9, 10, 11],
      'Moon': [2, 5, 7, 9, 11],
      'Mars': [1, 2, 4, 7, 8, 10, 11],
      'Mercury': [1, 2, 4, 5, 6, 9, 10, 11],
      'Jupiter': [1, 2, 3, 4, 7, 8, 10, 11],
      'Venus': [2, 5, 6, 9, 10, 11],
      'Saturn': [3, 5, 6, 12],
      'Lagna': [1, 2, 4, 5, 6, 7, 9, 10, 11],
    },
    'Venus': {
      'Sun': [8, 11, 12],
      'Moon': [1, 2, 3, 4, 5, 8, 9, 11, 12],
      'Mars': [3, 4, 6, 8, 9, 11, 12],
      'Mercury': [3, 5, 6, 9, 11],
      'Jupiter': [5, 8, 9, 10, 11],
      'Venus': [1, 2, 3, 4, 5, 8, 9, 10, 11],
      'Saturn': [3, 4, 5, 8, 9, 10, 11],
      'Lagna': [1, 2, 3, 4, 5, 8, 9],
    },
    'Saturn': {
      'Sun': [1, 2, 4, 7, 8, 10, 11],
      'Moon': [3, 6, 11],
      'Mars': [3, 5, 6, 10, 11, 12],
      'Mercury': [6, 8, 9, 10, 11, 12],
      'Jupiter': [5, 6, 11, 12],
      'Venus': [6, 11, 12],
      'Saturn': [3, 5, 6, 11],
      'Lagna': [1, 3, 4, 6, 10, 11],
    },
  };

  static AshtakavargaResult calculate(AstroChartResult result) {
    final referenceSigns = <String, int>{
      for (final planet in result.planets)
        if (planetOrder.contains(planet.name)) planet.name: planet.signIndex,
      'Lagna': result.ascendantSignIndex,
    };

    final bhinna = <String, List<int>>{};
    final prastara = <String, Map<String, List<int>>>{};
    for (final target in planetOrder) {
      final values = List<int>.filled(12, 0);
      final rows = <String, List<int>>{};
      final targetRules = _rules[target]!;
      for (final entry in targetRules.entries) {
        final row = List<int>.filled(12, 0);
        final referenceSign = referenceSigns[entry.key];
        if (referenceSign != null) {
          for (final house in entry.value) {
            final sign = (referenceSign + house - 1) % 12;
            row[sign] = 1;
            values[sign] += 1;
          }
        }
        rows[entry.key] = List<int>.unmodifiable(row);
      }
      bhinna[target] = List<int>.unmodifiable(values);
      prastara[target] = Map<String, List<int>>.unmodifiable(rows);
    }

    final sarva = List<int>.generate(
      12,
      (sign) => planetOrder.fold(
        0,
        (sum, planet) => sum + bhinna[planet]![sign],
      ),
      growable: false,
    );

    var totalsValid = sarva.fold(0, (sum, value) => sum + value) == 337;
    for (final planet in planetOrder) {
      final total = bhinna[planet]!.fold(0, (sum, value) => sum + value);
      if (total != expectedTotals[planet]) totalsValid = false;
    }

    return AshtakavargaResult(
      bhinna: Map.unmodifiable(bhinna),
      sarva: List<int>.unmodifiable(sarva),
      prastara: Map<String, Map<String, List<int>>>.unmodifiable(prastara),
      expectedPlanetTotals: expectedTotals,
      totalsValid: totalsValid,
    );
  }
}
