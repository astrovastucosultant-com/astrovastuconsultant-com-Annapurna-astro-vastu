import 'astro_models.dart';


enum AshtakavargaPindaProfile { practical, pvr }

class AshtakavargaPinda {
  final int rashiPinda;
  final int grahaPinda;
  final int shodhyaPinda;

  const AshtakavargaPinda({
    required this.rashiPinda,
    required this.grahaPinda,
    required this.shodhyaPinda,
  });
}

class AshtakavargaArithmeticSnapshot {
  final List<int> savByHouse;
  final Map<String, List<int>> bavByHouse;
  final Map<String, List<int>> afterTrikona;
  final Map<String, List<int>> afterEkadhipatya;
  final Map<String, AshtakavargaPinda> practicalPindas;
  final Map<String, AshtakavargaPinda> pvrPindas;
  final Map<String, int> natalBavScore;
  final Map<String, int> natalHouse;
  final Map<String, int> groupSums;
  final bool auditValid;

  const AshtakavargaArithmeticSnapshot({
    required this.savByHouse,
    required this.bavByHouse,
    required this.afterTrikona,
    required this.afterEkadhipatya,
    required this.practicalPindas,
    required this.pvrPindas,
    required this.natalBavScore,
    required this.natalHouse,
    required this.groupSums,
    required this.auditValid,
  });

  int savHouse(int house) => savByHouse[house - 1];
  int bavHouse(String planet, int house) => bavByHouse[planet]![house - 1];

  AshtakavargaPinda pinda(
    String planet, {
    AshtakavargaPindaProfile profile = AshtakavargaPindaProfile.practical,
  }) => profile == AshtakavargaPindaProfile.pvr
      ? pvrPindas[planet]!
      : practicalPindas[planet]!;
}

class AshtakavargaResult {
  final Map<String, List<int>> bhinna;
  final List<int> sarva;
  final Map<String, Map<String, List<int>>> prastara;
  final Map<String, int> expectedPlanetTotals;
  final bool totalsValid;
  final AshtakavargaArithmeticSnapshot arithmetic;

  const AshtakavargaResult({
    required this.bhinna,
    required this.sarva,
    required this.prastara,
    required this.expectedPlanetTotals,
    required this.totalsValid,
    required this.arithmetic,
  });

  int get grandTotal => sarva.fold(0, (sum, value) => sum + value);
  int totalFor(String planet) =>
      bhinna[planet]?.fold<int>(0, (sum, value) => sum + value) ?? 0;
}

/// Classical Parashari Bhinna Ashtakavarga (BAV) and Sarvashtakavarga (SAV).
/// Rahu and Ketu are excluded from the seven standard BAV rows.
class AshtakavargaService {
  static const List<String> planetOrder = [
    'Sun',
    'Moon',
    'Mars',
    'Mercury',
    'Jupiter',
    'Venus',
    'Saturn',
  ];

  static const Map<String, int> expectedTotals = {
    'Sun': 48,
    'Moon': 49,
    'Mars': 39,
    'Mercury': 54,
    'Jupiter': 56,
    'Venus': 52,
    'Saturn': 39,
  };

  static const Map<String, Map<String, List<int>>> _rules = {
    'Sun': {
      'Sun': [1, 2, 4, 7, 8, 9, 10, 11],
      'Moon': [3, 6, 10, 11],
      'Mars': [1, 2, 4, 7, 8, 9, 10, 11],
      'Mercury': [3, 5, 6, 9, 10, 11, 12],
      'Jupiter': [5, 6, 9, 11],
      'Venus': [6, 7, 12],
      'Saturn': [1, 2, 4, 7, 8, 9, 10, 11],
      'Lagna': [3, 4, 6, 10, 11, 12],
    },
    'Moon': {
      'Sun': [3, 6, 7, 8, 10, 11],
      'Moon': [1, 3, 6, 7, 10, 11],
      'Mars': [2, 3, 5, 6, 9, 10, 11],
      'Mercury': [1, 3, 4, 5, 7, 8, 10, 11],
      'Jupiter': [1, 4, 7, 8, 10, 11, 12],
      'Venus': [3, 4, 5, 7, 9, 10, 11],
      'Saturn': [3, 5, 6, 11],
      'Lagna': [3, 6, 10, 11],
    },
    'Mars': {
      'Sun': [3, 5, 6, 10, 11],
      'Moon': [3, 6, 11],
      'Mars': [1, 2, 4, 7, 8, 10, 11],
      'Mercury': [3, 5, 6, 11],
      'Jupiter': [6, 10, 11, 12],
      'Venus': [6, 8, 11, 12],
      'Saturn': [1, 4, 7, 8, 9, 10, 11],
      'Lagna': [1, 3, 6, 10, 11],
    },
    'Mercury': {
      'Sun': [5, 6, 9, 11, 12],
      'Moon': [2, 4, 6, 8, 10, 11],
      'Mars': [1, 2, 4, 7, 8, 9, 10, 11],
      'Mercury': [1, 3, 5, 6, 9, 10, 11, 12],
      'Jupiter': [6, 8, 11, 12],
      'Venus': [1, 2, 3, 4, 5, 8, 9, 11],
      'Saturn': [1, 2, 4, 7, 8, 9, 10, 11],
      'Lagna': [1, 2, 4, 6, 8, 10, 11],
    },
    'Jupiter': {
      'Sun': [1, 2, 3, 4, 7, 8, 9, 10, 11],
      'Moon': [2, 5, 7, 9, 11],
      'Mars': [1, 2, 4, 7, 8, 10, 11],
      'Mercury': [1, 2, 4, 5, 6, 9, 10, 11],
      'Jupiter': [1, 2, 3, 4, 7, 8, 10, 11],
      'Venus': [2, 5, 6, 9, 10, 11],
      'Saturn': [3, 5, 6, 12],
      'Lagna': [1, 2, 4, 5, 6, 7, 9, 10, 11],
    },
    'Venus': {
      'Sun': [8, 11, 12],
      'Moon': [1, 2, 3, 4, 5, 8, 9, 11, 12],
      'Mars': [3, 4, 6, 8, 9, 11, 12],
      'Mercury': [3, 5, 6, 9, 11],
      'Jupiter': [5, 8, 9, 10, 11],
      'Venus': [1, 2, 3, 4, 5, 8, 9, 10, 11],
      'Saturn': [3, 4, 5, 8, 9, 10, 11],
      'Lagna': [1, 2, 3, 4, 5, 8, 9],
    },
    'Saturn': {
      'Sun': [1, 2, 4, 7, 8, 10, 11],
      'Moon': [3, 6, 11],
      'Mars': [3, 5, 6, 10, 11, 12],
      'Mercury': [6, 8, 9, 10, 11, 12],
      'Jupiter': [5, 6, 11, 12],
      'Venus': [6, 11, 12],
      'Saturn': [3, 5, 6, 11],
      'Lagna': [1, 3, 4, 6, 10, 11],
    },
  };


  // Classical two-stage BAV reduction and Pinda arithmetic.
  // Practical profile uses the multiplier set commonly used by software and
  // the supplied practical material. PVR profile is retained explicitly
  // because the Virgo rasi multiplier differs in a published tradition.
  static const List<int> practicalRashiMultipliers = [
    7, 10, 8, 4, 10, 5, 7, 8, 9, 5, 11, 12,
  ];
  static const List<int> pvrRashiMultipliers = [
    7, 10, 8, 4, 10, 6, 7, 8, 9, 5, 11, 12,
  ];
  static const Map<String, int> grahaMultipliers = {
    'Sun': 5,
    'Moon': 5,
    'Mars': 8,
    'Mercury': 5,
    'Jupiter': 10,
    'Venus': 7,
    'Saturn': 5,
  };

  static const List<(int, int)> _dualSignPairs = [
    (0, 7), // Mars: 1 & 8
    (1, 6), // Venus: 2 & 7
    (2, 5), // Mercury: 3 & 6
    (8, 11), // Jupiter: 9 & 12
    (9, 10), // Saturn: 10 & 11
  ];

  static List<int> trikonaShodhana(List<int> raw) {
    final out = List<int>.from(raw);
    for (var r = 0; r < 4; r++) {
      final a = r;
      final b = r + 4;
      final c = r + 8;
      final av = out[a], bv = out[b], cv = out[c];
      if (av == 0 || bv == 0 || cv == 0) continue;
      if (av == bv && bv == cv) {
        out[a] = 0;
        out[b] = 0;
        out[c] = 0;
        continue;
      }
      final m = [av, bv, cv].reduce((x, y) => x < y ? x : y);
      out[a] -= m;
      out[b] -= m;
      out[c] -= m;
    }
    return List<int>.unmodifiable(out);
  }

  static List<int> ekadhipatyaShodhana(
    List<int> afterTrikona,
    Set<int> occupiedSigns,
  ) {
    final out = List<int>.from(afterTrikona);
    for (final pair in _dualSignPairs) {
      final a = pair.$1, b = pair.$2;
      if (out[a] == 0 || out[b] == 0) continue;
      final aOcc = occupiedSigns.contains(a);
      final bOcc = occupiedSigns.contains(b);
      if (aOcc && bOcc) continue;

      if (!aOcc && !bOcc) {
        if (out[a] == out[b]) {
          out[a] = 0;
          out[b] = 0;
        } else {
          final m = out[a] < out[b] ? out[a] : out[b];
          out[a] = m;
          out[b] = m;
        }
        continue;
      }

      final occupied = aOcc ? a : b;
      final empty = aOcc ? b : a;
      if (out[empty] <= out[occupied]) {
        out[empty] = 0;
      } else {
        out[empty] = out[occupied];
      }
    }
    return List<int>.unmodifiable(out);
  }

  static AshtakavargaPinda _calculatePinda({
    required List<int> reduced,
    required Map<String, int> planetSigns,
    required List<int> rashiMultipliers,
  }) {
    var rashi = 0;
    for (var sign = 0; sign < 12; sign++) {
      rashi += reduced[sign] * rashiMultipliers[sign];
    }
    var graha = 0;
    for (final planet in planetOrder) {
      final sign = planetSigns[planet]!;
      graha += reduced[sign] * grahaMultipliers[planet]!;
    }
    return AshtakavargaPinda(
      rashiPinda: rashi,
      grahaPinda: graha,
      shodhyaPinda: rashi + graha,
    );
  }

  static List<int> _toHouseOrder(List<int> signValues, int lagnaSign) =>
      List<int>.generate(12, (h) => signValues[(lagnaSign + h) % 12], growable: false);

  static int _houseOfSign(int sign, int lagnaSign) =>
      ((sign - lagnaSign + 12) % 12) + 1;

  static int kakshyaIndex(double longitude) {
    final inSign = ((longitude % 30.0) + 30.0) % 30.0;
    final index = (inSign / 3.75).floor() + 1;
    return index.clamp(1, 8).toInt();
  }

  static ({double start, double end}) kakshyaRange(int index) {
    final safe = index.clamp(1, 8).toInt();
    return (start: (safe - 1) * 3.75, end: safe * 3.75);
  }

  static int savAtLongitude(AshtakavargaResult av, double longitude) {
    final normalized = ((longitude % 360.0) + 360.0) % 360.0;
    return av.sarva[(normalized / 30.0).floor() % 12];
  }

  static int bavAtLongitude(
    AshtakavargaResult av,
    String planet,
    double longitude,
  ) {
    final normalized = ((longitude % 360.0) + 360.0) % 360.0;
    return av.bhinna[planet]![(normalized / 30.0).floor() % 12];
  }

  static AshtakavargaArithmeticSnapshot _buildArithmetic({
    required AstroChartResult chart,
    required Map<String, List<int>> bhinna,
    required List<int> sarva,
  }) {
    final lagna = chart.ascendantSignIndex;
    final planetSigns = <String, int>{
      for (final p in chart.planets)
        if (planetOrder.contains(p.name)) p.name: p.signIndex,
    };
    final occupied = planetSigns.values.toSet();

    final afterTrikona = <String, List<int>>{};
    final afterEkadhipatya = <String, List<int>>{};
    final practicalPindas = <String, AshtakavargaPinda>{};
    final pvrPindas = <String, AshtakavargaPinda>{};
    final bavByHouse = <String, List<int>>{};
    final natalBavScore = <String, int>{};
    final natalHouse = <String, int>{};

    var audit = true;
    for (final target in planetOrder) {
      final raw = bhinna[target]!;
      final tri = trikonaShodhana(raw);
      final eka = ekadhipatyaShodhana(tri, occupied);
      afterTrikona[target] = tri;
      afterEkadhipatya[target] = eka;
      bavByHouse[target] = List<int>.unmodifiable(_toHouseOrder(raw, lagna));
      final natalSign = planetSigns[target]!;
      natalBavScore[target] = raw[natalSign];
      natalHouse[target] = _houseOfSign(natalSign, lagna);
      practicalPindas[target] = _calculatePinda(
        reduced: eka,
        planetSigns: planetSigns,
        rashiMultipliers: practicalRashiMultipliers,
      );
      pvrPindas[target] = _calculatePinda(
        reduced: eka,
        planetSigns: planetSigns,
        rashiMultipliers: pvrRashiMultipliers,
      );
      for (var i = 0; i < 12; i++) {
        if (tri[i] < 0 || eka[i] < 0 || tri[i] > raw[i] || eka[i] > tri[i]) {
          audit = false;
        }
      }
      if (practicalPindas[target]!.shodhyaPinda !=
          practicalPindas[target]!.rashiPinda + practicalPindas[target]!.grahaPinda) {
        audit = false;
      }
    }

    final savByHouse = List<int>.unmodifiable(_toHouseOrder(sarva, lagna));
    int sumH(Iterable<int> houses) =>
        houses.fold(0, (s, h) => s + savByHouse[h - 1]);

    final groups = <String, int>{
      'Kendra 1+4+7+10': sumH([1, 4, 7, 10]),
      'Kona 1+5+9': sumH([1, 5, 9]),
      'Panaphara 2+5+8+11': sumH([2, 5, 8, 11]),
      'Apoklima 3+6+9+12': sumH([3, 6, 9, 12]),
      'Upachaya 3+6+10+11': sumH([3, 6, 10, 11]),
      'Dusthana 6+8+12': sumH([6, 8, 12]),
      'Dhana 2+11': sumH([2, 11]),
      'Education 5+9': sumH([5, 9]),
      'Career 6+10+11+12': sumH([6, 10, 11, 12]),
      'Income set 1+2+4+9+10+11': sumH([1, 2, 4, 9, 10, 11]),
      'Expense set 6+8+12': sumH([6, 8, 12]),
      'Poshaka A 3+7+11': sumH([3, 7, 11]),
      'Poshaka B 4+8+12': sumH([4, 8, 12]),
      'Independent A 1+5+9': sumH([1, 5, 9]),
      'Independent B 2+6+10': sumH([2, 6, 10]),
      'Inner A 1+4+5+7+9+10': sumH([1, 4, 5, 7, 9, 10]),
      'Outer B 2+3+6+8+11+12': sumH([2, 3, 6, 8, 11, 12]),
    };

    return AshtakavargaArithmeticSnapshot(
      savByHouse: savByHouse,
      bavByHouse: Map.unmodifiable(bavByHouse),
      afterTrikona: Map.unmodifiable(afterTrikona),
      afterEkadhipatya: Map.unmodifiable(afterEkadhipatya),
      practicalPindas: Map.unmodifiable(practicalPindas),
      pvrPindas: Map.unmodifiable(pvrPindas),
      natalBavScore: Map.unmodifiable(natalBavScore),
      natalHouse: Map.unmodifiable(natalHouse),
      groupSums: Map.unmodifiable(groups),
      auditValid: audit,
    );
  }

  static AshtakavargaResult calculate(AstroChartResult result) {
    final referenceSigns = <String, int>{
      for (final planet in result.planets)
        if (planetOrder.contains(planet.name)) planet.name: planet.signIndex,
      'Lagna': result.ascendantSignIndex,
    };

    final bhinna = <String, List<int>>{};
    final prastara = <String, Map<String, List<int>>>{};
    for (final target in planetOrder) {
      final values = List<int>.filled(12, 0);
      final rows = <String, List<int>>{};
      final targetRules = _rules[target]!;
      for (final entry in targetRules.entries) {
        final row = List<int>.filled(12, 0);
        final referenceSign = referenceSigns[entry.key];
        if (referenceSign != null) {
          for (final house in entry.value) {
            final sign = (referenceSign + house - 1) % 12;
            row[sign] = 1;
            values[sign] += 1;
          }
        }
        rows[entry.key] = List<int>.unmodifiable(row);
      }
      bhinna[target] = List<int>.unmodifiable(values);
      prastara[target] = Map<String, List<int>>.unmodifiable(rows);
    }

    final sarva = List<int>.generate(
      12,
      (sign) => planetOrder.fold(
        0,
        (sum, planet) => sum + bhinna[planet]![sign],
      ),
      growable: false,
    );

    var totalsValid = sarva.fold(0, (sum, value) => sum + value) == 337;
    for (final planet in planetOrder) {
      final total = bhinna[planet]!.fold(0, (sum, value) => sum + value);
      if (total != expectedTotals[planet]) totalsValid = false;
    }

    final arithmetic = _buildArithmetic(chart: result, bhinna: bhinna, sarva: sarva);

    return AshtakavargaResult(
      bhinna: Map.unmodifiable(bhinna),
      sarva: List<int>.unmodifiable(sarva),
      prastara: Map<String, Map<String, List<int>>>.unmodifiable(prastara),
      expectedPlanetTotals: expectedTotals,
      totalsValid: totalsValid,
      arithmetic: arithmetic,
    );
  }
}
