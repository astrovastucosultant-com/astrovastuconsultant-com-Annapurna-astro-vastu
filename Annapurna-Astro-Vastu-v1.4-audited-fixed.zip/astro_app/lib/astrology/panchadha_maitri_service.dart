import 'astro_models.dart';
import 'varga_service.dart';

enum PanchadhaRelation {
  own,
  adhimitra,
  mitra,
  sama,
  shatru,
  adhishatru,
}

class PanchadhaPairResult {
  final String fromPlanet;
  final String toPlanet;
  final String naturalRelation;
  final String temporaryRelation;
  final PanchadhaRelation finalRelation;

  const PanchadhaPairResult({
    required this.fromPlanet,
    required this.toPlanet,
    required this.naturalRelation,
    required this.temporaryRelation,
    required this.finalRelation,
  });
}

class PanchadhaVargaStrength {
  final int factor;
  final String planet;
  final int signIndex;
  final String signLord;
  final PanchadhaRelation relationToSignLord;
  final double strength;

  const PanchadhaVargaStrength({
    required this.factor,
    required this.planet,
    required this.signIndex,
    required this.signLord,
    required this.relationToSignLord,
    required this.strength,
  });
}

/// User-approved Panchadha Maitri common engine.
///
/// IMPORTANT IMPLEMENTATION RULE:
/// The temporary relationship table is calculated ONCE from D1/Rasi planet
/// positions. That D1 compound (Panchadha) relationship is then used when a
/// planet is judged against the lord of the sign occupied in every varga.
/// This prevents a different friendship table being silently rebuilt inside
/// each divisional chart.
class PanchadhaMaitriService {
  static const List<String> classicalPlanets = <String>[
    'Sun',
    'Moon',
    'Mars',
    'Mercury',
    'Jupiter',
    'Venus',
    'Saturn',
  ];

  static const List<String> signNamesTe = <String>[
    'మేషం',
    'వృషభం',
    'మిథునం',
    'కర్కాటకం',
    'సింహం',
    'కన్య',
    'తుల',
    'వృశ్చికం',
    'ధనుస్సు',
    'మకరం',
    'కుంభం',
    'మీనం',
  ];

  // Aries..Pisces sign lords.
  static const List<String> _signLords = <String>[
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];

  // Directional natural friendship. A→B need not equal B→A.
  static const Map<String, Set<String>> _naturalFriends = <String, Set<String>>{
    'Sun': {'Moon', 'Mars', 'Jupiter'},
    'Moon': {'Sun', 'Mercury'},
    'Mars': {'Sun', 'Moon', 'Jupiter'},
    'Mercury': {'Sun', 'Venus'},
    'Jupiter': {'Sun', 'Moon', 'Mars'},
    'Venus': {'Mercury', 'Saturn'},
    'Saturn': {'Mercury', 'Venus'},
  };

  static const Map<String, Set<String>> _naturalEnemies = <String, Set<String>>{
    'Sun': {'Venus', 'Saturn'},
    'Moon': <String>{},
    'Mars': {'Mercury'},
    'Mercury': {'Moon'},
    'Jupiter': {'Mercury', 'Venus'},
    'Venus': {'Sun', 'Moon'},
    'Saturn': {'Sun', 'Moon', 'Mars'},
  };

  static const Map<PanchadhaRelation, double> strengthValues = {
    PanchadhaRelation.own: 30.0,
    PanchadhaRelation.adhimitra: 22.5,
    PanchadhaRelation.mitra: 15.0,
    PanchadhaRelation.sama: 7.5,
    PanchadhaRelation.shatru: 3.75,
    PanchadhaRelation.adhishatru: 1.875,
  };

  static String relationTelugu(PanchadhaRelation relation) => switch (relation) {
        PanchadhaRelation.own => 'స్వరాశి',
        PanchadhaRelation.adhimitra => 'అధిమిత్రుడు',
        PanchadhaRelation.mitra => 'మిత్రుడు',
        PanchadhaRelation.sama => 'సముడు',
        PanchadhaRelation.shatru => 'శత్రువు',
        PanchadhaRelation.adhishatru => 'అధిశత్రువు',
      };

  static String shortCode(PanchadhaRelation relation) => switch (relation) {
        PanchadhaRelation.own => 'స్వ',
        PanchadhaRelation.adhimitra => 'అమి',
        PanchadhaRelation.mitra => 'మి',
        PanchadhaRelation.sama => 'స',
        PanchadhaRelation.shatru => 'శ',
        PanchadhaRelation.adhishatru => 'అశ',
      };

  static Map<String, int> d1Signs(AstroChartResult chart) => <String, int>{
        for (final p in chart.planets)
          if (classicalPlanets.contains(p.name)) p.name: p.signIndex,
      };

  static PanchadhaPairResult pairFromChart(
    AstroChartResult chart,
    String fromPlanet,
    String toPlanet,
  ) =>
      pairFromSigns(d1Signs(chart), fromPlanet, toPlanet);

  static PanchadhaPairResult pairFromSigns(
    Map<String, int> d1PlanetSigns,
    String fromPlanet,
    String toPlanet,
  ) {
    if (fromPlanet == toPlanet) {
      return PanchadhaPairResult(
        fromPlanet: fromPlanet,
        toPlanet: toPlanet,
        naturalRelation: 'Self',
        temporaryRelation: 'Self',
        finalRelation: PanchadhaRelation.own,
      );
    }

    final fromSign = d1PlanetSigns[fromPlanet];
    final toSign = d1PlanetSigns[toPlanet];
    if (fromSign == null || toSign == null) {
      throw ArgumentError('D1 sign missing for $fromPlanet or $toPlanet');
    }

    final natural = _naturalRelation(fromPlanet, toPlanet);
    final houseFromFromPlanet = ((toSign - fromSign + 12) % 12) + 1;
    final tempFriend = const <int>{2, 3, 4, 10, 11, 12}.contains(houseFromFromPlanet);
    final temporary = tempFriend ? 'Friend' : 'Enemy';

    return PanchadhaPairResult(
      fromPlanet: fromPlanet,
      toPlanet: toPlanet,
      naturalRelation: natural,
      temporaryRelation: temporary,
      finalRelation: _compound(natural, tempFriend),
    );
  }

  static Map<String, Map<String, PanchadhaPairResult>> matrix(AstroChartResult chart) {
    final signs = d1Signs(chart);
    return <String, Map<String, PanchadhaPairResult>>{
      for (final a in classicalPlanets)
        a: <String, PanchadhaPairResult>{
          for (final b in classicalPlanets) b: pairFromSigns(signs, a, b),
        },
    };
  }

  static List<PanchadhaVargaStrength> evaluateVarga({
    required AstroChartResult chart,
    required int factor,
  }) {
    final d1 = d1Signs(chart);
    final varga = VargaService.calculate(chart, factor);
    final out = <PanchadhaVargaStrength>[];

    for (final planetName in classicalPlanets) {
      final placement = varga.planets.firstWhere((p) => p.name == planetName);
      final signLord = _signLords[placement.signIndex];
      final relation = planetName == signLord
          ? PanchadhaRelation.own
          : pairFromSigns(d1, planetName, signLord).finalRelation;
      out.add(
        PanchadhaVargaStrength(
          factor: factor,
          planet: planetName,
          signIndex: placement.signIndex,
          signLord: signLord,
          relationToSignLord: relation,
          strength: strengthValues[relation]!,
        ),
      );
    }
    return out;
  }

  static String _naturalRelation(String a, String b) {
    if (_naturalFriends[a]?.contains(b) ?? false) return 'Friend';
    if (_naturalEnemies[a]?.contains(b) ?? false) return 'Enemy';
    return 'Neutral';
  }

  static PanchadhaRelation _compound(String natural, bool tempFriend) {
    if (natural == 'Friend' && tempFriend) return PanchadhaRelation.adhimitra;
    if (natural == 'Neutral' && tempFriend) return PanchadhaRelation.mitra;
    if (natural == 'Enemy' && tempFriend) return PanchadhaRelation.sama;
    if (natural == 'Friend' && !tempFriend) return PanchadhaRelation.sama;
    if (natural == 'Neutral' && !tempFriend) return PanchadhaRelation.shatru;
    return PanchadhaRelation.adhishatru;
  }
}
