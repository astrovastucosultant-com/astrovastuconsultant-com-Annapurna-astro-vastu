class D24EducationRuleSpec {
  final String id;
  final String topic;
  final String rule;
  final String result;
  final String source;
  final String layer;
  final bool autoCapable;

  const D24EducationRuleSpec({
    required this.id,
    required this.topic,
    required this.rule,
    required this.result,
    required this.source,
    required this.layer,
    required this.autoCapable,
  });
}

/// Rule catalogue extracted from the user-supplied `Education.pdf`
/// (Astrology of Education). The catalogue keeps source methodology separate
/// from app/user-configured sign classification so that the source is not
/// silently altered.
class D24EducationRegistry {
  static const technicalSigns = <int>{0, 7, 9, 10}; // Aries, Scorpio, Capricorn, Aquarius
  static const semiTechnicalSigns = <int>{2, 4, 5}; // Gemini, Leo, Virgo
  static const nonTechnicalSigns = <int>{1, 3, 6, 8, 11}; // Taurus, Cancer, Libra, Sagittarius, Pisces


  static const outputSections = <String>[
    'Education Desire',
    'Learning Capacity',
    'Concentration',
    'School Education',
    'Graduation',
    'Education Nature',
    'Primary Field',
    'Secondary Field',
    'Higher Studies',
    'Research / PhD',
    'Hostel / Away from Home',
    'Foreign Education',
    'Break in Education',
    'Resume after Break',
    'Formal Education End Stage',
    'Matched Rule IDs',
    'Source Pages',
    'Evidence Level',
  ];

  static const educationWarnings = <String>[
    'D24 is birth-time sensitive. The source notes that even a two-minute change can alter D24 Lagna and 5th-house indications.',
    'Do not decide the exact course from sign classification alone.',
    'Do not treat a case-supported subject pattern as a universal rule unless the source explicitly states it as such.',
  ];

  static String userConfiguredNatureForSign(int sign) {
    if (technicalSigns.contains(sign)) return 'Technical';
    if (semiTechnicalSigns.contains(sign)) return 'Semi-technical';
    return 'Non-technical';
  }

  static const rules = <D24EducationRuleSpec>[
    D24EducationRuleSpec(
      id: 'EDU-MASTER-01',
      topic: 'విద్య పరిశీలన క్రమం',
      rule: 'Source మొదట Jaimini/Navamsha ద్వారా PK, AK మరియు AK నుండి విద్య స్థాయిలను పరిశీలించి, తరువాత Parashari fifth-cusp/Navamsha stream సూచనను, చివరగా Chaturvimshamsha (D24) ద్వారా desire, fulfilment, dedication, mind, school/graduation/higher-study/research layersను పరిశీలిస్తుంది.',
      result: 'D24 ఒక్కటే standalone verdict కాదు; D9/Jaimini + fifth-cusp stream + D24 confirmationను కలిపి చదవాలి.',
      source: 'Education.pdf pp.1–2',
      layer: 'Master Framework',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-JAI-01', topic: 'PK — విద్యా బుద్ధి',
      rule: 'PKను Navamshaలో చూడాలి. Exaltation/own sign/benefic relation లేదా sign-lord relation ఉంటే study intelligence/support మెరుగ్గా ఉంటుంది; opposite condition poor-study tendency చూపిస్తుంది.',
      result: 'PK బలం విద్యా గ్రహణశక్తి/విద్యార్థి సామర్థ్యానికి supporting evidence.',
      source: 'Education.pdf p.1 and case examples', layer: 'Jaimini / D9', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-JAI-02', topic: 'AK నుండి 2వ భావం',
      rule: 'Navamshaలో AK నుండి 2వ భావం family sanskar / early education / habitsకు చూడాలి.',
      result: 'AK-2 early learning environment మరియు family sanskar సూచిస్తుంది.',
      source: 'Education.pdf pp.1–2', layer: 'Jaimini / D9', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-JAI-03', topic: 'AK నుండి 4వ భావం',
      rule: 'AK నుండి 4వ భావం home/school-level educationకు చూడాలి.',
      result: 'AK-4 schooling/home-education పరిస్థితులను సూచిస్తుంది.',
      source: 'Education.pdf pp.1–2', layer: 'Jaimini / D9', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-JAI-04', topic: 'AK నుండి 5వ భావం',
      rule: 'AK నుండి 5వ భావం graduation-level educationకు చూడాలి.',
      result: 'AK-5 graduation continuity/completionకు supporting layer.',
      source: 'Education.pdf pp.1–2', layer: 'Jaimini / D9', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-JAI-05', topic: 'AK నుండి 9వ భావం',
      rule: 'AK నుండి 9వ భావం post-graduation/higher educationకు చూడాలి.',
      result: 'AK-9 higher/post-graduate studiesకు supporting layer.',
      source: 'Education.pdf pp.1–2', layer: 'Jaimini / D9', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-JAI-06', topic: 'AK నుండి 8వ భావం',
      rule: 'AK నుండి 8వ భావం research/deeper knowledgeకు చూడాలి.',
      result: 'AK-8 research/occult/deep-study supportను సూచిస్తుంది.',
      source: 'Education.pdf p.2', layer: 'Jaimini / D9', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-JAI-07', topic: 'Rahu/Ketu — విద్య ముగింపు/విరామం',
      rule: 'Education-level houseకు Rahu/Ketu association వచ్చినప్పుడు ఆ levelలో end/interruptionను source పరిశీలిస్తుంది.',
      result: 'Rahu/Ketu level-house involvement ఉన్నప్పుడు interruption/end caution చూపాలి; ఇతర supportతో cross-check అవసరం.',
      source: 'Education.pdf pp.1–2 and multiple examples', layer: 'Jaimini / D9', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-JAI-08', topic: 'Hostel / Foreign Study',
      rule: 'Relevant education houseకు 12th-lord association hostel/stay-away indication; 9th+12th association foreign-study/foreign-stay indicationగా source ఉపయోగిస్తుంది.',
      result: '12th-only support → hostel/stay away; 9th+12th support → foreign study/stay stronger.',
      source: 'Education.pdf p.2 and case examples', layer: 'Jaimini / D9', autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-PAR-01', topic: '5వ cusp Nakshatra Lord — Stream',
      rule: 'Birth horoscope fifth-house cusp degrees/minutesకు source-specified adjustment చేసి cusp nakshatra lordను తీసుకుని, ఆ lord Navamsha sign/relations ద్వారా education streamను నిర్ణయించాలి.',
      result: 'Exact stream verdictకు fifth cusp degree + nakshatra lord + D9 placement అవసరం.',
      source: 'Education.pdf p.2', layer: 'Parashari / Cusp Stream', autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-01', topic: 'D24 లగ్నం — చదువుపై కోరిక',
      rule: 'Chaturvimshamsha Lagnaను desire to studyగా source ఉపయోగిస్తుంది. Benefic support desireను సహాయపడుతుంది; malefic/papakartari/affliction desireను తగ్గించవచ్చు లేదా compulsion/delay చూపవచ్చు.',
      result: 'D24 Lagna = education desire/interest layer.',
      source: 'Education.pdf p.2 and D24 case examples', layer: 'D24 Core', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-02', topic: 'D24 లగ్నాధిపతి — కోరిక నెరవేర్చే మార్గం',
      rule: 'Lagna lord strength, dignity, placement, conjunction/affliction ద్వారా desire ఎంత సులభంగా fulfil అవుతుందో పరిశీలించాలి.',
      result: 'Strong Lagna lord → easier fulfilment; afflicted/weak lord → obstacles/delay/self-effort required.',
      source: 'Education.pdf p.2 and D24 case examples', layer: 'D24 Core', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-03', topic: 'సూర్యుడు — dedication / inner urge',
      rule: 'D24 Sun ద్వారా soul/dedication/inner urge for studyను చూడాలి. Benefic/sattwik support dedicationను, harder/malefic relations fighting/aggressive effortను సూచించవచ్చు.',
      result: 'Sun = dedication/inner urge layer.',
      source: 'Education.pdf p.2 and D24 examples', layer: 'D24 Core', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-04', topic: 'చంద్రుడు — మానసిక ధోరణి',
      rule: 'D24 Moon mental inclination, learning attitude, independence/stability/aggression/delay వంటి mental-study patternకు చూడాలి.',
      result: 'Moon = study mind/mental inclination layer.',
      source: 'Education.pdf p.2 and D24 examples', layer: 'D24 Core', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-05', topic: '2వ భావం — Sanskar / Early Learning',
      rule: 'D24 2H family sanskar, habits and early-learning supportను repeated examplesలో ఉపయోగిస్తుంది.',
      result: '2H support → good sanskar/learning base; affliction → habit/distraction caution.',
      source: 'Education.pdf D24 case examples pp.8 onward', layer: 'D24 Levels', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-06', topic: '4వ భావం — Schooling',
      rule: 'D24 4H and 4L schooling/school-level educationకు చూడాలి. Affliction/6-8-12/Rahu-Ketu patterns school change, delay, hostel or interruptionను examplesలో సూచిస్తాయి.',
      result: '4H = school-level continuity / school environment.',
      source: 'Education.pdf D24 case examples', layer: 'D24 Levels', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-07', topic: '5వ భావం — Graduation',
      rule: 'D24 5H/5L graduation/formal educationకు repeated examplesలో ఉపయోగిస్తారు. Strong benefic/lord support completion; affliction/Rahu-Ketu/6L involvement obstacles or endకు caution.',
      result: '5H = graduation/formal education layer.',
      source: 'Education.pdf D24 case examples', layer: 'D24 Levels', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-08', topic: '9వ భావం — Higher / PG',
      rule: 'D24 9H/9L higher/post-graduate educationకు చూడాలి. Strong support continuation; 9H with 12th/foreign patterns overseas studyకు support.',
      result: '9H = higher/post-graduate education layer.',
      source: 'Education.pdf p.2 and D24 case examples', layer: 'D24 Levels', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-09', topic: '8వ భావం — Research / Deeper Knowledge',
      rule: 'D24 8Hను research, occult or deeper knowledgeకు source guidelineలో పేర్కొంటుంది.',
      result: '8H support → research/deep-study inclination.',
      source: 'Education.pdf p.2', layer: 'D24 Levels', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-10', topic: '12వ భావం — Hostel / Away from Home',
      rule: 'D24 examplesలో 12th/12L links school/college away from home, hostel లేదా foreign environmentను support చేయవచ్చు.',
      result: '12H support → stay-away/hostel layer; foreign verdictకు 9H/12H cross-confirmation అవసరం.',
      source: 'Education.pdf case examples', layer: 'D24 Levels', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-11', topic: 'Dual Sign — రెండు streams',
      rule: '5H/stream indicator dual sign involvementను examplesలో two streams/subject combinationతో అనుసంధానించారు.',
      result: 'Dual-sign education indicator → multiple/two-stream study possibility.',
      source: 'Education.pdf case examples', layer: 'D24 Stream', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-12', topic: 'Rahu/Ketu axis — interruption / end',
      rule: '4H/5H/9H లేదా వాటి lordsపై Rahu-Ketu axis repeated examplesలో change, interruption, end of formal education లేదా shiftను సూచిస్తుంది.',
      result: 'Rahu/Ketu on education level = caution; exact outcome other supportతో నిర్ణయించాలి.',
      source: 'Education.pdf multiple examples', layer: 'D24 Continuity', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-13', topic: 'Jupiter — knowledge / law / higher study support',
      rule: 'Examplesలో Jupiter strong relation education, higher learning, law/knowledge మరియు continuationకు repeated supportగా వస్తుంది.',
      result: 'Jupiter prominence → higher knowledge/teaching/law-type learning support; exact subject requires stream evidence.',
      source: 'Education.pdf case examples', layer: 'Subject Support', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-14', topic: 'Mercury — mathematics/accounts/computer/language',
      rule: 'Examplesలో Mercury intelligence, mathematics, accounts, computer/communication-type study supportగా repeatedly used.',
      result: 'Mercury prominence → maths/accounts/computer/language shortlist support.',
      source: 'Education.pdf case examples', layer: 'Subject Support', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-15', topic: 'Mars — engineering / technical',
      rule: 'Examplesలో Mars technical/engineering/electronics inclination, aggressive effort and hands-on studyతో repeated association కలిగి ఉంది.',
      result: 'Mars prominence → engineering/technical/hands-on shortlist support.',
      source: 'Education.pdf case examples', layer: 'Subject Support', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-16', topic: 'Saturn — mechanical / depth / delay',
      rule: 'Examplesలో Saturn mechanical/automation/depth/hard-work/delay లేదా slow-learning contextలో repeated evidenceగా కనిపిస్తుంది.',
      result: 'Saturn prominence → mechanical/structured technical/deep-study support with possible delay.',
      source: 'Education.pdf case examples', layer: 'Subject Support', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-17', topic: 'Sun — political/electronic/dedication support',
      rule: 'Examplesలో Sun political-science/electronics and dedication/inner urge contextsలో ఉపయోగించబడింది.',
      result: 'Sun prominence → authority/political/electronic subject support; exact result needs other indicators.',
      source: 'Education.pdf case examples', layer: 'Subject Support', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-18', topic: 'Moon — biology/environment/mental learning support',
      rule: 'Examplesలో Moon biology/environmental or mind-dependent learning contextsలో ఇతర planetsతో కలిసి subject supportగా కనిపిస్తుంది.',
      result: 'Moon prominence → life/environment/mind-oriented subjects as secondary shortlist only.',
      source: 'Education.pdf case examples', layer: 'Subject Support', autoCapable: true,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-19', topic: 'User-configured రాశి వర్గీకరణ',
      rule: 'App master classification: Technical = Aries, Scorpio, Capricorn, Aquarius; Semi-technical = Gemini, Leo, Virgo; Non-technical = Taurus, Cancer, Libra, Sagittarius, Pisces. ఇది user-configured classification; PDF example wordingను replace చేయదు.',
      result: 'Stream shortlistలో source evidenceతో పాటు ఈ user-configured sign categoryని విడిగా చూపాలి.',
      source: 'User-configured Annapurna Astro Vastu D24 rule + Education.pdf stream framework', layer: 'App Configuration', autoCapable: true,
    ),
    // Exact/case-supported field rules from the source-grounded master JSON.
    D24EducationRuleSpec(
      id: 'EDU-FIELD-001',
      topic: 'Foreign Languages',
      rule: '5th cusp nakshatra lord Ketu in a non-technical context/sign; use associations for refinement',
      result: 'Foreign-language study',
      source: 'Education.pdf pp.7, 10',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-002',
      topic: 'Law',
      rule: 'Law-supporting 5th-house pattern with Saturn and/or Sun plus logical/argumentative Mars support; source cases also use Jupiter and Sagittarius/law context',
      result: 'Law / legal studies',
      source: 'Education.pdf pp.4, 5, 10',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-003',
      topic: 'Political Science',
      rule: 'Strong Sun influence on the 5th-house graduation pattern',
      result: 'Political Science / political studies',
      source: 'Education.pdf pp.8',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-004',
      topic: 'Mathematics',
      rule: 'Mercury/intellectual factors strong, with technical or semi-technical 5th influence; Jupiter/Saturn/Mars may deepen or strengthen mathematical ability',
      result: 'Mathematics / strong mathematical proficiency',
      source: 'Education.pdf pp.22, 28, 67',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-005',
      topic: 'Accounts / Commerce / CA',
      rule: '5th-cusp Jupiter in dual Gemini with Venus, or Rahu/Jupiter case pattern connected to accounts',
      result: 'Accounts / Commerce / CA inclination',
      source: 'Education.pdf pp.25, 31',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-006',
      topic: 'Computer',
      rule: 'Jupiter in Gemini with Venus, or Sun placed in a Venus-sign context in the 5th-cusp analysis',
      result: 'Computer-related study',
      source: 'Education.pdf pp.31, 58',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-007',
      topic: 'Electronics / Communication Engineering',
      rule: 'Technical 5th-house sign with Sun as key 5th-cusp factor; Rahu/Ketu/Moon technical support may appear',
      result: 'Electronics / Communication Engineering',
      source: 'Education.pdf pp.34',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-008',
      topic: 'Biotechnology',
      rule: '5th-cusp Moon in dual Jupiter context with Ketu and technical support from Saturn/Mars',
      result: 'Biotechnology',
      source: 'Education.pdf pp.37',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-009',
      topic: 'Medicine / Specialization',
      rule: 'Technical 5th-cusp pattern with Venus in Aries and Saturn aspect in the source case',
      result: 'Medical/technical study; source case specialized in Nephrology',
      source: 'Education.pdf pp.49',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-010',
      topic: 'Environmental Science / Research',
      rule: 'Mixed science pattern; Moon with malefic gives chemistry in the source case, followed by environmental science; Jupiter/Ketu supported higher study/research',
      result: 'Environmental Science / advanced research',
      source: 'Education.pdf pp.52, 53',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-011',
      topic: 'Mechanical Engineering',
      rule: '5th cusp nakshatra lord Sun in technical sign with Ketu and Jupiter; strong Sun',
      result: 'Mechanical Engineering',
      source: 'Education.pdf pp.55',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-012',
      topic: 'Chemistry',
      rule: '5th lord Venus with Sun and Mars influence; Mars aspect on Mercury noted in source',
      result: 'Chemistry',
      source: 'Education.pdf pp.62',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-013',
      topic: 'Actuarial Studies',
      rule: 'Sun + Mercury pattern',
      result: 'Actuarial degree/studies',
      source: 'Education.pdf pp.67',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-014',
      topic: 'Instrumentation / Automation',
      rule: 'Technical education pattern with strong mathematics/depth; source case studied B.Tech in instrumentation and automation',
      result: 'Instrumentation / Automation',
      source: 'Education.pdf pp.67',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-FIELD-015',
      topic: 'MBA / Management',
      rule: 'Source case completed MBA under a strong 5th-house/Jupiter-Rahu-Saturn pattern',
      result: 'Management studies may occur',
      source: 'Education.pdf pp.43, 44',
      layer: 'Field / Course',
      autoCapable: false,
    ),
    D24EducationRuleSpec(
      id: 'EDU-D24-20', topic: 'Birth-time sensitivity',
      rule: 'Source exampleలో birth time రెండు నిమిషాలు మారితే D24 Lagna/5H మరియు main-subject indication మారవచ్చని స్పష్టంగా చూపించారు.',
      result: 'D24 education verdict birth-time sensitive; rectified time ఉంటే recalculation తప్పనిసరి.',
      source: 'Education.pdf p.32 of uploaded PDF', layer: 'Validation', autoCapable: false,
    ),
  ];
}
