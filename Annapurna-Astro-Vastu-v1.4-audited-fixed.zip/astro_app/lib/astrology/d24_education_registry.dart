class D24EducationRuleSpec {
  final String id;
  final String topic;
  final String rule;
  final String result;
  final String source;
  const D24EducationRuleSpec({required this.id, required this.topic, required this.rule, required this.result, required this.source});
}

class D24EducationRegistry {
  static const technicalSigns = <int>{0, 7, 9, 10};
  static const semiTechnicalSigns = <int>{2, 4, 5};
  static String natureForSign(int sign) {
    if (technicalSigns.contains(sign)) return 'Technical';
    if (semiTechnicalSigns.contains(sign)) return 'Semi-technical';
    return 'Non-technical';
  }

  /// Broad client-guidance layer requested for D24. These are advisory
  /// education directions, not universal course predictions from Education.pdf.
  static const educationBySign = <int, List<String>>{
    0: ['Mechanical Engineering', 'Civil Engineering', 'Electrical Engineering', 'Electronics', 'Defence Technology', 'Surgery / Medical Technology'],
    1: ['Commerce / Finance', 'Arts / Design', 'Fashion / Interior Design', 'Food / Agriculture', 'Hospitality / Hotel Management'],
    2: ['Computer / IT', 'Electronics / Communication', 'Mathematics / Statistics', 'Commerce / Accounting', 'Languages / Media'],
    3: ['Psychology', 'Nutrition / Food Science', 'Hotel / Hospitality Management', 'Social Sciences', 'Teaching / Child Development'],
    4: ['Public Administration', 'Political Science', 'Management', 'Law', 'Media / Communication', 'Health Administration'],
    5: ['Computer / IT', 'Mathematics / Statistics', 'Accounting / Commerce', 'Analytics / Data', 'Pharmacy / Lab-oriented Studies'],
    6: ['Law', 'Commerce / Finance', 'Design / Architecture', 'Fashion / Fine Arts', 'HR / Diplomacy'],
    7: ['Medicine / Surgery', 'Biotechnology', 'Chemistry', 'Forensic Science', 'Research', 'Engineering / Technical'],
    8: ['Law', 'Teaching / Education', 'Philosophy', 'Finance / Management', 'Languages', 'Travel / Tourism Studies'],
    9: ['Civil Engineering', 'Mechanical Engineering', 'Industrial Engineering', 'Mining / Geology', 'Construction', 'Manufacturing Technology'],
    10: ['Electrical / Electronics', 'Computer Science / IT', 'Instrumentation / Automation', 'Telecommunication', 'Data / Networks', 'Engineering Research'],
    11: ['Psychology / Counselling', 'Teaching / Education', 'Literature / Languages', 'Management / Finance', 'Hospitality / Travel', 'Traditional / Spiritual Studies'],
  };

  static List<String> educationForSign(int sign) =>
      List<String>.unmodifiable(educationBySign[sign % 12] ?? const <String>[]);

  /// User-requested D24 guidance layer for education significations of planets.
  /// These labels are intentionally broad advisory fields used only for the
  /// suitability scorer; they are not presented as universal source rules.
  static const educationByPlanet = <String, List<String>>{
    'Sun': ['Public Administration', 'Political Science', 'Management', 'Law', 'Health Administration', 'Medicine / Surgery'],
    'Moon': ['Psychology', 'Psychology / Counselling', 'Nutrition / Food Science', 'Hotel / Hospitality Management', 'Teaching / Child Development', 'Social Sciences'],
    'Mars': ['Mechanical Engineering', 'Civil Engineering', 'Electrical Engineering', 'Defence Technology', 'Surgery / Medical Technology', 'Medicine / Surgery', 'Engineering / Technical'],
    'Mercury': ['Computer / IT', 'Computer Science / IT', 'Electronics / Communication', 'Mathematics / Statistics', 'Commerce / Accounting', 'Accounting / Commerce', 'Analytics / Data', 'Languages / Media'],
    'Jupiter': ['Law', 'Teaching / Education', 'Philosophy', 'Finance / Management', 'Management / Finance', 'Traditional / Spiritual Studies', 'Research'],
    'Venus': ['Arts / Design', 'Fashion / Interior Design', 'Design / Architecture', 'Fashion / Fine Arts', 'Hospitality / Hotel Management', 'HR / Diplomacy'],
    'Saturn': ['Civil Engineering', 'Mechanical Engineering', 'Industrial Engineering', 'Mining / Geology', 'Construction', 'Manufacturing Technology', 'Engineering Research', 'Research'],
    'Rahu': ['Computer Science / IT', 'Electrical / Electronics', 'Instrumentation / Automation', 'Telecommunication', 'Data / Networks', 'Engineering Research'],
    'Ketu': ['Research', 'Biotechnology', 'Forensic Science', 'Traditional / Spiritual Studies', 'Philosophy', 'Engineering Research'],
  };

  static List<String> educationForPlanet(String planet) =>
      List<String>.unmodifiable(educationByPlanet[planet] ?? const <String>[]);

  static Set<String> educationAllowedForNature(String nature) {
    final signs = switch (nature) {
      'Technical' => technicalSigns,
      'Semi-technical' => semiTechnicalSigns,
      _ => <int>{1, 3, 6, 8, 11},
    };
    final out = <String>{};
    for (final sign in signs) {
      out.addAll(educationForSign(sign));
    }
    return out;
  }
  static const rules = <D24EducationRuleSpec>[
    D24EducationRuleSpec(
      id: "EDU-D24-001",
      topic: "Core • EDU-D24-001",
      rule: "D24 Lagna supported by benefics",
      result: "Desire to study is present/strong",
      source: "Education.pdf pp. 23, 35, 38, 50, 59",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-002",
      topic: "Core • EDU-D24-002",
      rule: "D24 Lagna under malefic influence without benefic support",
      result: "Study desire is weak, average, delayed, or under compulsion",
      source: "Education.pdf pp. 5, 8, 20, 23",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-003",
      topic: "Core • EDU-D24-003",
      rule: "D24 Lagna lord strong / in Kendra or Trikona / own or exalted / benefic-supported",
      result: "Desires are fulfilled more easily; education progresses",
      source: "Education.pdf pp. 8, 23, 26, 38, 62",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-004",
      topic: "Core • EDU-D24-004",
      rule: "D24 Lagna lord afflicted, debilitated, or strongly malefic-influenced",
      result: "Delay, obstacles, effort, or slow progress",
      source: "Education.pdf pp. 5, 20, 44, 56",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-005",
      topic: "Core • EDU-D24-005",
      rule: "Sun strong/benefic-supported in D24",
      result: "Dedication and inner urge toward education",
      source: "Education.pdf pp. 2, 8, 26, 59, 65",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-006",
      topic: "Core • EDU-D24-006",
      rule: "Moon strong / benefic-supported / with Jupiter or Mercury",
      result: "Good mental inclination, concentration, intelligence, or learning capacity",
      source: "Education.pdf pp. 2, 5, 20, 23, 59",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-007",
      topic: "Core • EDU-D24-007",
      rule: "Moon afflicted by malefics",
      result: "Slow learning, distraction, mental pressure, or aggressive learning style",
      source: "Education.pdf pp. 35, 44, 47",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-008",
      topic: "Core • EDU-D24-008",
      rule: "2nd house / 2nd lord benefic-supported",
      result: "Good family sanskar and supportive study habits",
      source: "Education.pdf pp. 26, 35, 59",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-009",
      topic: "Core • EDU-D24-009",
      rule: "2nd house afflicted by Rahu/Ketu/malefics",
      result: "Bad habits, family-side obstacles, or study disturbance may occur",
      source: "Education.pdf pp. 20, 32, 44, 65",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-010",
      topic: "Core • EDU-D24-010",
      rule: "4th house / 4th lord strong and benefic-supported",
      result: "Schooling/basic education is smooth and supported",
      source: "Education.pdf pp. 1, 26, 35, 59",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-011",
      topic: "Core • EDU-D24-011",
      rule: "4th house / 4th lord afflicted by Rahu/Ketu/malefics",
      result: "School change, schooling obstacles, home-environment disturbance, or interruption",
      source: "Education.pdf pp. 20, 32, 44, 47",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-012",
      topic: "Core • EDU-D24-012",
      rule: "5th house / 5th lord strong",
      result: "Graduation-level education is supported",
      source: "Education.pdf pp. 1, 8, 26, 50",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-013",
      topic: "Core • EDU-D24-013",
      rule: "5th house / relevant education house associated with Rahu or Ketu",
      result: "Possible break, interruption, or end of education at that level; must be cross-checked with benefic support",
      source: "Education.pdf pp. 2, 20, 28, 31, 47",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-014",
      topic: "Core • EDU-D24-014",
      rule: "9th house / 9th lord strong",
      result: "Higher studies / postgraduate education supported",
      source: "Education.pdf pp. 1, 2, 38, 43",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-015",
      topic: "Core • EDU-D24-015",
      rule: "8th house strong / relevant to education",
      result: "Research, occult, or deeper knowledge",
      source: "Education.pdf pp. 2, 22, 23",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-016",
      topic: "Core • EDU-D24-016",
      rule: "Education house connected with 12th lord",
      result: "Hostel / study away from home",
      source: "Education.pdf pp. 2",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-017",
      topic: "Core • EDU-D24-017",
      rule: "Education house connected with both 9th and 12th lords",
      result: "Foreign study indication",
      source: "Education.pdf pp. 2, 38",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-018",
      topic: "Core • EDU-D24-018",
      rule: "Use 5th cusp nakshatra lord, then inspect that lord in Navamsa and its sign/aspects/associations",
      result: "Primary stream/subject selection",
      source: "Education.pdf pp. 2, 4, 7, 10",
    ),
    D24EducationRuleSpec(
      id: "EDU-D24-019",
      topic: "Core • EDU-D24-019",
      rule: "Check Navamsa PK for intelligence/hand-work/subject grasp and AK-relative houses for education stages",
      result: "Cross-check D24 result",
      source: "Education.pdf pp. 1, 2",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-001",
      topic: "Subject • Foreign Languages",
      rule: "5th cusp nakshatra lord Ketu in a non-technical context/sign; use associations for refinement [Evidence: Explicit statement in source]",
      result: "Foreign-language study",
      source: "Education.pdf pp. 7, 10",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-002",
      topic: "Subject • Law",
      rule: "Law-supporting 5th-house pattern with Saturn and/or Sun plus logical/argumentative Mars support; source cases also use Jupiter and Sagittarius/law context [Evidence: Case-supported pattern; not a single universal formula]",
      result: "Law / legal studies",
      source: "Education.pdf pp. 4, 5, 10",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-003",
      topic: "Subject • Political Science",
      rule: "Strong Sun influence on the 5th-house graduation pattern [Evidence: Case-supported pattern]",
      result: "Political Science / political studies",
      source: "Education.pdf pp. 8",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-004",
      topic: "Subject • Mathematics",
      rule: "Mercury/intellectual factors strong, with technical or semi-technical 5th influence; Jupiter/Saturn/Mars may deepen or strengthen mathematical ability [Evidence: Repeated case-supported pattern]",
      result: "Mathematics / strong mathematical proficiency",
      source: "Education.pdf pp. 22, 28, 67",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-005",
      topic: "Subject • Accounts / Commerce / CA",
      rule: "5th-cusp Jupiter in dual Gemini with Venus, or Rahu/Jupiter case pattern connected to accounts [Evidence: Case-supported pattern]",
      result: "Accounts / Commerce / CA inclination",
      source: "Education.pdf pp. 25, 31",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-006",
      topic: "Subject • Computer",
      rule: "Jupiter in Gemini with Venus, or Sun placed in a Venus-sign context in the 5th-cusp analysis [Evidence: Explicit case statements]",
      result: "Computer-related study",
      source: "Education.pdf pp. 31, 58",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-007",
      topic: "Subject • Electronics / Communication Engineering",
      rule: "Technical 5th-house sign with Sun as key 5th-cusp factor; Rahu/Ketu/Moon technical support may appear [Evidence: Case-supported; source explicitly calls Sun a karaka of electronics]",
      result: "Electronics / Communication Engineering",
      source: "Education.pdf pp. 34",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-008",
      topic: "Subject • Biotechnology",
      rule: "5th-cusp Moon in dual Jupiter context with Ketu and technical support from Saturn/Mars [Evidence: Explicit case statement]",
      result: "Biotechnology",
      source: "Education.pdf pp. 37",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-009",
      topic: "Subject • Medicine / Specialization",
      rule: "Technical 5th-cusp pattern with Venus in Aries and Saturn aspect in the source case [Evidence: Case-supported only; do not use as standalone medical formula]",
      result: "Medical/technical study; source case specialized in Nephrology",
      source: "Education.pdf pp. 49",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-010",
      topic: "Subject • Environmental Science / Research",
      rule: "Mixed science pattern; Moon with malefic gives chemistry in the source case, followed by environmental science; Jupiter/Ketu supported higher study/research [Evidence: Case-supported pattern]",
      result: "Environmental Science / advanced research",
      source: "Education.pdf pp. 52, 53",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-011",
      topic: "Subject • Mechanical Engineering",
      rule: "5th cusp nakshatra lord Sun in technical sign with Ketu and Jupiter; strong Sun [Evidence: Explicit case statement]",
      result: "Mechanical Engineering",
      source: "Education.pdf pp. 55",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-012",
      topic: "Subject • Chemistry",
      rule: "5th lord Venus with Sun and Mars influence; Mars aspect on Mercury noted in source [Evidence: Explicit case statement]",
      result: "Chemistry",
      source: "Education.pdf pp. 62",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-013",
      topic: "Subject • Actuarial Studies",
      rule: "Sun + Mercury pattern [Evidence: Explicit case statement]",
      result: "Actuarial degree/studies",
      source: "Education.pdf pp. 67",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-014",
      topic: "Subject • Instrumentation / Automation",
      rule: "Technical education pattern with strong mathematics/depth; source case studied B.Tech in instrumentation and automation [Evidence: Case-supported; source does not give one standalone formula]",
      result: "Instrumentation / Automation",
      source: "Education.pdf pp. 67",
    ),
    D24EducationRuleSpec(
      id: "EDU-FIELD-015",
      topic: "Subject • MBA / Management",
      rule: "Source case completed MBA under a strong 5th-house/Jupiter-Rahu-Saturn pattern [Evidence: Case observation only; insufficient for a universal rule]",
      result: "Management studies may occur",
      source: "Education.pdf pp. 43, 44",
    ),
  ];
}
