import 'dart:math' as math;

/// Equatorial geometry used by astronomical Primary Directions.
/// This is a *coordinate/audit layer*, not a full mundane primary direction
/// engine. A complete engine additionally needs horizon intersections,
/// semi-arcs, house cusps, latitude of every body and a selected direction key.
class WesternEquatorialPoint {
  final double rightAscension;
  final double declination;
  final double? obliqueAscension;
  const WesternEquatorialPoint(this.rightAscension, this.declination,
      this.obliqueAscension);
}

class WesternPrimaryDirections {
  static double _rad(double v) => v * math.pi / 180.0;
  static double _deg(double v) => v * 180.0 / math.pi;
  static double _norm(double v) => (v % 360 + 360) % 360;

  /// Transform geocentric ecliptic longitude/latitude into equatorial RA/Dec.
  /// epsilon is the obliquity at the epoch (mean/true selection belongs to the
  /// ephemeris configuration). Never approximate lunar latitude as zero.
  static WesternEquatorialPoint fromEcliptic({required double longitude,
      required double latitude, required double obliquity,
      required double geographicLatitude}) {
    if (![longitude,latitude,obliquity,geographicLatitude]
        .every((e) => e.isFinite)) {
      throw ArgumentError('Non-finite astronomical coordinate');
    }
    if (geographicLatitude.abs() >= 90) {
      throw ArgumentError('Polar geographic latitude requires separate treatment');
    }
    final lon=_rad(longitude),lat=_rad(latitude),eps=_rad(obliquity);
    final x=math.cos(lat)*math.cos(lon);
    final y=math.cos(lat)*math.sin(lon)*math.cos(eps)-math.sin(lat)*math.sin(eps);
    final z=math.cos(lat)*math.sin(lon)*math.sin(eps)+math.sin(lat)*math.cos(eps);
    final ra=_norm(_deg(math.atan2(y,x)));
    final dec=_deg(math.asin(z.clamp(-1.0,1.0)));
    final p=math.tan(_rad(geographicLatitude))*math.tan(_rad(dec));
    // OA is defined for rising/setting points; circumpolar points have
    // no real horizon crossing and MUST NOT receive a fabricated OA.
    final oa=p.abs()>1.0 ? null : _norm(ra-_deg(math.asin(p)));
    return WesternEquatorialPoint(ra,dec,oa);
  }

  /// Meridian RA contact arc, not a full Placidus/Regiomontanus direction.
  static double meridianArc(double significatorRa,double promissorRa) =>
      _norm(promissorRa-significatorRa);

  static double obliqueAscensionArc(WesternEquatorialPoint significator,
      WesternEquatorialPoint promissor) {
    final a=significator.obliqueAscension,b=promissor.obliqueAscension;
    if(a==null||b==null) throw StateError('Circumpolar point: no horizon arc');
    return _norm(b-a);
  }
}
