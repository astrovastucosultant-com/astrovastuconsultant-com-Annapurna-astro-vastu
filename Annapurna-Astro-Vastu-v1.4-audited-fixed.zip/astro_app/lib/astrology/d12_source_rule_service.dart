import 'astro_models.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';

/// Rules transcribed/translated from the user's scanned "D12.pdf", Ch. 9,
/// Saral Jyotish Part VII, uploaded PDF pp. 1–51 (book pp. 293–340).
///
/// A `matched` row requires a reproducible current-chart condition. Rules
/// depending on undefined KL/cyclical mapping, subjective strength, or birth-
/// event case-study inference stay source-only. This intentionally does NOT
/// turn historical case studies into general laws or predict a death date.
class D12SourceRuleHit {
  final String id;
  final String category;
  final String topic;
  final String condition;
  final String sourceResult;
  final String inspection;
  final String source;
  final bool? matched;
  final bool caution;

  const D12SourceRuleHit({
    required this.id,
    required this.category,
    required this.topic,
    required this.condition,
    required this.sourceResult,
    required this.inspection,
    required this.source,
    required this.matched,
    required this.caution,
  });
}

class D12SourceRuleService {
  static const sourceFilename = 'D12.pdf';
  static const sections = <String>[
    'పూర్వీకుల ఆశీర్వాదం / Blessings of ancestors',
    'బాల్య సుఖదుఃఖాలు / Stressful or easy childhood',
    'తల్లిదండ్రులు–బిడ్డ అనుబంధం / Parent and child relation',
    'తల్లిదండ్రులకు సహాయం / Are you helpful to parents',
    'వారసత్వం / Inheritance and legacy',
    'తల్లిదండ్రుల ఆయుర్దాయం / Longevity of parents',
    'దశా విశ్లేషణ / Dasha analysis',
    'గ్రంథ ఉదాహరణలు / Case-study source audit',
  ];
  static const _harmful = {'Mars', 'Saturn', 'Rahu', 'Ketu', 'Sun'};
  static const _classicalHarmful = {'Mars', 'Saturn', 'Sun'};
  static const _planets = <String>[
    'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu',
  ];

  static List<D12SourceRuleHit> evaluate(AstroChartResult chart, VargaChartData d12) {
    final rows = <D12SourceRuleHit>[];
    final byName = {for (final p in d12.planets) p.name: p};
    final lagna = d12.ascendantSignIndex;
    int houseSign(int h) => (lagna + h - 1) % 12;
    String lord(int sign) => switch (sign % 12) {
      0 || 7 => 'Mars', 1 || 6 => 'Venus', 2 || 5 => 'Mercury',
      3 => 'Moon', 4 => 'Sun', 8 || 11 => 'Jupiter',
      9 || 10 => 'Saturn', _ => 'Sun',
    };
    String houseLord(int h) => lord(houseSign(h));
    int? signOf(String p) => byName[p]?.signIndex;
    int? houseOf(String p) {
      final sign = signOf(p);
      return sign == null ? null : ((sign - lagna + 12) % 12) + 1;
    }
    List<String> occupants(int h) => byName.values.where((p) => p.signIndex == houseSign(h)).map((p) => p.name).toList();
    bool together(String a, String b) => a != b && signOf(a) != null && signOf(a) == signOf(b);
    bool aspects(String p, int? targetSign) {
      final s = signOf(p);
      if (s == null || targetSign == null || s == targetSign) return false;
      final houseDistance = ((targetSign - s + 12) % 12) + 1;
      if (houseDistance == 7 && !_isNode(p)) return true;
      if (p == 'Mars' && (houseDistance == 4 || houseDistance == 8)) return true;
      if (p == 'Jupiter' && (houseDistance == 5 || houseDistance == 9)) return true;
      if (p == 'Saturn' && (houseDistance == 3 || houseDistance == 10)) return true;
      // Nodes' special aspects are deliberately not invented.
      return false;
    }
    bool mutualAspect(String a, String b) => a != b && aspects(a,signOf(b)) && aspects(b,signOf(a));
    bool associated(String a, String b) => together(a,b) || aspects(a,signOf(b)) || aspects(b,signOf(a));
    List<String> afflictersOfSign(int s, {String? exclude}) => [
      for (final p in _planets)
        if (p != exclude && _harmful.contains(p) &&
          (signOf(p) == s || (_classicalHarmful.contains(p) && aspects(p,s)))) p,
    ];
    List<String> afflictersOfHouse(int h) => afflictersOfSign(houseSign(h));
    List<String> afflictersOfPlanet(String p) {
      final s = signOf(p); return s == null ? [] : afflictersOfSign(s, exclude:p);
    }
    bool nodeAssociated(String p) => associated(p,'Rahu') || associated(p,'Ketu');
    String planetAt(String p) => '$p D12 H${houseOf(p) ?? "?"}';
    String houseAt(int h) => 'D12 $h H: ${occupants(h).isEmpty ? "గ్రహాలు లేవు" : occupants(h).join(", ")}; lord ${houseLord(h)} H${houseOf(houseLord(h)) ?? "?"}';
    final jaimini = JaiminiService.calculate(chart);
    final karakas = {for (final k in jaimini.charaKarakas) k.code:k.planet};
    String karaka(String code) => karakas[code] ?? '—';
    final snapshot = 'Parashari D12 lagna=${lagna+1}; AK=${karaka("AK")}, AmK=${karaka("AmK")}, BK=${karaka("BK")}, MK=${karaka("MK")}, PK=${karaka("PK")}, GK=${karaka("GK")}, DK=${karaka("DK")}. '
      'D12 classical graha aspects: 7th, Mars 4/8, Saturn 3/10, Jupiter 5/9; nodes conjunction only.';

    void add({
      required String id, required String group, required String topic,
      required int page, required String condition, required String result,
      bool? matched, String evidence = '', bool caution = false,
    }) {
      rows.add(D12SourceRuleHit(
        id:id, category:group, topic:topic, condition:condition,
        sourceResult:result,
        inspection: '$snapshot\n${evidence.isEmpty ? (matched == null ? "KL/Cyclical/strength/case-specific source condition: గణన పూర్తిగా నిర్ధారించలేదు." : "పరిశీలించిన Parashari D12 స్థానాలు.") : evidence}',
        source:'$sourceFilename • PDF page $page (Chapter 9, Saral Jyotish Part VII)',
        matched:matched, caution:caution,
      ));
    }

    const anc = 'పూర్వీకుల ఆశీర్వాదం';
    add(id:'D12-ANC-01',group:anc,topic:'D12 రాజయోగం ద్వారా స్థాయి',page:2,
      condition:'D12లో రాజయోగం ఉన్నప్పుడు జాతకుని స్థాయి పెరుగుతుందని గ్రంథం చెబుతోంది. Rajayoga నిర్మాణాన్ని స్వతంత్రంగా పరిశీలించాలి.',
      result:'రాజయోగం ఉంటే వ్యక్తికి స్థాయి/పదవి; ఇది తల్లిదండ్రులు ధనికులనే నిర్ణయం కాదు.');
    add(id:'D12-ANC-02',group:anc,topic:'D12 ధనయోగం ద్వారా సంపద',page:2,
      condition:'D12లో ధనయోగాన్ని పరిశీలించాలి; ఉదాహరణ పేజీలు 3, 5, 7లో వేర్వేరు combinations ఉన్నాయి.',
      result:'D12లో ధనయోగం ధనసూచిక; తల్లిదండ్రుల సంపదను స్వయంగా నిర్ధారించదు.');
    add(id:'D12-ANC-03',group:anc,topic:'KL లగ్నం/అధిపతి బలం – పూర్వీక ఆశీస్సులు',page:2,
      condition:'KL లగ్నం లేదా KL లగ్నాధిపతి బలంగా ఉన్నప్పుడే ancestral blessing support; బలహీనతలో మద్దతు తగ్గుతుందని గ్రంథం.',
      result:'పూర్వీకుల ఆశీస్సుల మద్దతు KL బలాన్నిబట్టి పరిశీలించాలి; KL నిర్మాణం/బల లెక్క ధృవీకరణ పెండింగ్.');
    add(id:'D12-ANC-04',group:anc,topic:'పూర్వీకుల ఆశీస్సులు – జీవన స్థితి, రక్షణ',page:2,
      condition:'పూర్వీకుల ఆశీర్వాదం జీవిత స్థితి, ప్రతికూల సమయంలో రక్షణకు సంబంధించినదని మూల వివరణ.',
      result:'ఇది గ్రంథ సిద్ధాంత వ్యాఖ్య; ఒక్క జన్మగ్రహస్థితితో boolean match కాదు.');
    add(id:'D12-ANC-05',group:anc,topic:'KLతో GK/త్రికాధిపతి సంబంధం – ఆటంకం',page:2,
      condition:'GK లేదా త్రికాధిపతులు KL లేదా KL లగ్నాధిపతితో సంబంధిస్తే కష్టాలు; KL బలంగా ఉంటే ఎదుర్కోగల శక్తి.',
      result:'అడ్డంకులు/అధిగమించే సామర్థ్యాన్ని కలిపి చూడాలి; KL తెలియకుండా తీర్పు ఇవ్వము.',caution:true);
    add(id:'D12-ANC-06',group:anc,topic:'ఉదాహరణ: 11L–9L పరస్పర దృష్టి ధనయోగం',page:3,
      condition:'D12 11వ భావాధిపతి మరియు 9వ భావాధిపతి పరస్పర దృష్టి (Ram Krishna ఉదాహరణ).',
      result:'ఈ ఉదాహరణలో ధనయోగంగా వివరించారు; case example మాత్రమే.',
      matched:mutualAspect(houseLord(11),houseLord(9)),evidence:'11L=${houseLord(11)}, 9L=${houseLord(9)}; mutual aspects ${mutualAspect(houseLord(11),houseLord(9))}.');
    add(id:'D12-ANC-07',group:anc,topic:'ఉదాహరణ: 11L–2L పరస్పర దృష్టి',page:5,
      condition:'D12 11వ భావాధిపతి–2వ భావాధిపతి పరస్పర దృష్టి (Vivekananda ఉదాహరణ).',
      result:'మూల ఉదాహరణ ధనయోగం; ఇతర పరిస్థితులు/ఫలితాన్ని విడిగా పరిశీలించాలి.',
      matched:mutualAspect(houseLord(11),houseLord(2)),evidence:'11L=${houseLord(11)}, 2L=${houseLord(2)}.');
    add(id:'D12-ANC-08',group:anc,topic:'ఉదాహరణ: 2L–5L కలయిక',page:7,
      condition:'D12 2వ అధిపతి–5వ అధిపతి ఒకే రాశి/భావంలో (Modi ఉదాహరణ).',
      result:'ఈ ఉదాహరణలో ధనయోగ సూచనగా ఉపయోగించారు.',
      matched:together(houseLord(2),houseLord(5)),evidence:'2L=${houseLord(2)}, 5L=${houseLord(5)}.');
    add(id:'D12-ANC-09',group:anc,topic:'KL ఉదాహరణ – 9L–10L యోగం, GK ప్రభావం',page:8,
      condition:'KL నుంచి 9/10 lords కలిసిన యోగం; GK/nodes ప్రభావం, KL బలం కూడా చూడాలి.',
      result:'KL బలంతో ఎదురయ్యే కష్టాలు, అనుకూలతలను ఉదాహరణతో గ్రంథం పోల్చింది.');

    const childhood='బాల్య సుఖదుఃఖాలు';
    final a2=afflictersOfHouse(2), a2L=afflictersOfPlanet(houseLord(2));
    final a4=afflictersOfHouse(4), a4L=afflictersOfPlanet(houseLord(4));
    add(id:'D12-CHILD-01',group:childhood,topic:'2వ భావానికి పాప ప్రభావం – బాల్యం',page:9,
      condition:'D12 2వ భావం malefic afflictionకు లోనైతే బాల్యంలో ఆటంకాల సూచన.',
      result:'గ్రంథం ప్రకారం ప్రారంభ బాల్యంలో అననుకూల పరిస్థితుల సూచిక (వైద్య నిర్ధారణ కాదు).',matched:a2.isNotEmpty,
      caution:true,evidence:'${houseAt(2)}; 2H afflicters=$a2.');
    add(id:'D12-CHILD-02',group:childhood,topic:'2వ భావాధిపతి పాప ప్రభావం',page:9,
      condition:'D12 2L పై పాపగ్రహ కలయిక/గ్రహదృష్టి.',result:'బాల్య వాతావరణంలో సమస్యల సూచనగా గ్రంథం పరిగణిస్తుంది.',
      matched:a2L.isNotEmpty,caution:true,evidence:'2L ${planetAt(houseLord(2))}; afflicters=$a2L.');
    add(id:'D12-CHILD-03',group:childhood,topic:'4వ భావానికి పాప ప్రభావం – బాల్య సౌఖ్యం',page:9,
      condition:'D12 4వ భావం పాప ప్రభావితమైతే తల్లిదండ్రుల పరిరక్షణ/సౌఖ్యంపై గ్రంథ సూచన.',
      result:'మూలంలో చిన్ననాటి ఆనందం/పరిరక్షణను పరిశీలించమని పేర్కొన్నారు.',matched:a4.isNotEmpty,
      caution:true,evidence:'${houseAt(4)}; 4H afflicters=$a4.');
    add(id:'D12-CHILD-04',group:childhood,topic:'4వ భావాధిపతిపై పాప ప్రభావం',page:9,
      condition:'D12 4L పై పాపగ్రహ కలయిక లేదా గ్రహదృష్టి.',
      result:'బాల్యంలో parental-care కష్టాలను పరిశీలించే సూచన.',matched:a4L.isNotEmpty,caution:true,
      evidence:'4L ${planetAt(houseLord(4))}; afflicters=$a4L.');
    add(id:'D12-CHILD-05',group:childhood,topic:'Parashar vs KL D12 – బాల్యం పోలిక',page:9,
      condition:'Parashar D12 ప్రస్తుతం అనుభవించేది; KL D12 విధి సూచన — రెండు పోల్చాలి.',
      result:'KL నిర్మాణ సూత్రం లభించేవరకు exact comparison auto-fire కాదు.');
    add(id:'D12-CHILD-06',group:childhood,topic:'ఉదాహరణ: 2H Moon, GK–2H అంశం',page:10,
      condition:'D12 2వ భావంలో చంద్రుడు; GK కూడా, 2Lపై ఇతర గ్రహాల ప్రభావం వేరుగా చూడాలి.',
      result:'Oprah ఉదాహరణలో బాల్య అసౌఖ్యం పరిశీలించబడింది; వ్యక్తిగత నిర్ణయం కాదు.',
      matched:houseOf('Moon')==2 && karaka('GK')=='Moon',evidence:'Moon=${planetAt("Moon")}; GK=${karaka("GK")}.');
    add(id:'D12-CHILD-07',group:childhood,topic:'ఉదాహరణ: AK సూర్యుడు 2Hలో, శుభ దృష్టి',page:16,
      condition:'D12 2వ భావంలో AK Sun, రెండు శుభ దృష్టులు ఉన్న chart-specific example.',
      result:'బాల్యం/తల్లి తండ్రుల మద్దతును ఇతర షరతులతోనే సమీక్షించాలి.',
      matched:karaka('AK')=='Sun' && houseOf('Sun')==2 && ['Jupiter','Venus','Mercury'].where((p)=>aspects(p,houseSign(2))).length>=2,
      evidence:'AK=${karaka("AK")}; Sun H${houseOf("Sun")}.');

    const relation='తల్లి–తండ్రి–సంతాన సంబంధం';
    add(id:'D12-REL-01',group:relation,topic:'సూర్యుడు–తండ్రి, చంద్రుడు–తల్లి; D1 9H/4H',page:18,
      condition:'గ్రంథం: Sun father, Moon mother; birth chart 9H father / 4H mother; D12 lagna child feeling.',
      result:'ఇది కారక గ్రహాల పరిచయం; గ్రహ శుభాశుభ బలం విడిగా లెక్కించాలి.');
    add(id:'D12-REL-02',group:relation,topic:'D12 లగ్నం – తల్లిదండ్రులపై మనోభావం',page:18,
      condition:'D12 లగ్నం పిల్లల భావన, లగ్నాధిపతి ఆ భావన వ్యక్తీకరణగా వివరించారు.',
      result:'D12 లగ్నాన్ని parental-feeling indicatorగా పరిశీలించాలి; అది ఒక్కటే తీర్పు కాదు.');
    add(id:'D12-REL-03',group:relation,topic:'చంద్రుడిపై పాపప్రభావం – మాతృ అనుబంధం',page:18,
      condition:'D12 చంద్రుడిపై పాపగ్రహ కలయిక/దృష్టి.',
      result:'గ్రంథం ప్రకారం తల్లితో అనుబంధ ఒత్తిడి సూచిక; నిజజీవిత బంధాన్ని ఖచ్చితంగా నిర్ణయించదు.',
      matched:afflictersOfPlanet('Moon').isNotEmpty,caution:true,
      evidence:'${planetAt("Moon")}; affected by ${afflictersOfPlanet("Moon")}.');
    add(id:'D12-REL-04',group:relation,topic:'సూర్యుడిపై పాపప్రభావం – పితృ అనుబంధం',page:18,
      condition:'D12 సూర్యుడిపై ఇతర పాపగ్రహ కలయిక/దృష్టి.',
      result:'గ్రంథం ప్రకారం తండ్రితో అనుబంధ ఒత్తిడి సూచిక.',
      matched:afflictersOfPlanet('Sun').isNotEmpty,caution:true,
      evidence:'${planetAt("Sun")}; affected by ${afflictersOfPlanet("Sun")}.');
    add(id:'D12-REL-05',group:relation,topic:'PK తండ్రి, MK తల్లి; AK/KL బిడ్డ',page:18,
      condition:'ఈ విభాగంలో Jaimini PK=father, MK=mother, AK/KL=child; GK/nodes affliction చూడాలి.',
      result:'కారకాల పాత్రలు source ఆధారంగా నమోదు. కాలిక/విధాన భేదం గ్రంథం నుంచి నిర్ధారించాలి.',
      evidence:'PK=${karaka("PK")}, MK=${karaka("MK")}, AK=${karaka("AK")}.');
    add(id:'D12-REL-06',group:relation,topic:'కారక బలం – సంయోగ సంఖ్య, రాశి బలం',page:18,
      condition:'Two karakas together -> sign lord & stronger karaka; common sign strongest > fixed > movable అని రచయిత పేర్కొన్నారు.',
      result:'ఈ ప్రత్యేక strength rankingకు source-specific full formula లేకుండా తుది dominancy స్కోరు వద్దు.');
    add(id:'D12-REL-07',group:relation,topic:'లగ్నంలో శుభగ్రహ/పాపగ్రహ కలయిక',page:19,
      condition:'Example of parental feeling: లగ్నం/లగ్నాధిపతి గ్రహ సంబంధాలు చూడాలి.',
      result:'చార్ట్‌లో లగ్న స్థితిని evidenceగా మాత్రమే చూపాలి.',
      matched:occupants(1).isNotEmpty,evidence:'${houseAt(1)}; లగ్నం నిండిన స్థితి మాత్రమే matched; relationship verdict కాదు.');
    add(id:'D12-REL-08',group:relation,topic:'PK–AK పరస్పర సంబంధం (ఉదాహరణ)',page:20,
      condition:'Father/child example: PK planet and AK planet are in aspect/association.',
      result:'ఈ ఉదాహరణలో parental supportకు ఒక సూచికగా ఉపయోగించారు.',
      matched:associated(karaka('PK'),karaka('AK')),
      evidence:'PK=${karaka("PK")} ${planetAt(karaka("PK"))}; AK=${karaka("AK")} ${planetAt(karaka("AK"))}.');
    add(id:'D12-REL-09',group:relation,topic:'MK–AK సంబంధం (ఉదాహరణ)',page:20,
      condition:'Mother/child example: MK with AK or their mutual influence and nodes; judge strength separately.',
      result:'ఇది case-based mother–child relational evidence.',
      matched:associated(karaka('MK'),karaka('AK')),
      evidence:'MK=${karaka("MK")}, AK=${karaka("AK")}, nodes on MK=${nodeAssociated(karaka("MK"))}.');

    const care='తల్లిదండ్రులకు సేవ';
    add(id:'D12-CARE-01',group:care,topic:'D12లో బిడ్డ కారకుడు – లగ్నాధిపతి/AK',page:25,
      condition:'Child represented by birth lagna lord or AK; D12లో వారిని చూడాలి.',
      result:'కారక గ్రహ సూచిక నమోదు; ఒక్కటే సేవ/అసేవ నిర్ణయం కాదు.',
      evidence:'D1 asc lord=${lord(chart.ascendantSignIndex)}, AK=${karaka("AK")}.');
    final birthLord = lord(chart.ascendantSignIndex);
    add(id:'D12-CARE-02',group:care,topic:'D12లో జన్మలగ్నాధిపతి పాప ప్రభావం',page:25,
      condition:'Birth lagna lord affliction in D12: source describes difficulty caring for parents.',
      result:'గ్రంథంలోని సంబంధ ఒత్తిడి సూచిక; వాస్తవ ప్రవర్తనను నిర్ధారించదు.',
      matched:afflictersOfPlanet(birthLord).isNotEmpty,caution:true,
      evidence:'Birth lagna lord=${birthLord}; ${planetAt(birthLord)}; afflicters=${afflictersOfPlanet(birthLord)}.');
    add(id:'D12-CARE-03',group:care,topic:'D12 AK పాప ప్రభావం, GK/నోడ్స్',page:25,
      condition:'AK afflicted by GK/nodes -> care difficulties, per author.',
      result:'పెద్దలతో సంబంధం పరిశీలించే గ్రంథ సూచిక; నిర్ధారణగా చూపవద్దు.',
      matched:karaka('AK')!=karaka('GK') && (associated(karaka('AK'),karaka('GK')) || nodeAssociated(karaka('AK'))),
      caution:true,evidence:'AK=${karaka("AK")} ${planetAt(karaka("AK"))}; GK=${karaka("GK")}; nodes related=${nodeAssociated(karaka("AK"))}.');
    add(id:'D12-CARE-04',group:care,topic:'MK తల్లి, BK తండ్రి (ఈ విభాగం)',page:25,
      condition:'Care chapter: MK=mother, BK=father; compare parent-child karakas. Earlier relationship chapter p.18 states PK=father.',
      result:'గ్రంథంలో తండ్రి కారకానికి PK/BK అనే భిన్న ఉపయోగాలు ఉన్నాయి; రెండు విడిగా రికార్డు.',
      evidence:'MK=${karaka("MK")}; BK=${karaka("BK")}; PK=${karaka("PK")}.');
    add(id:'D12-CARE-05',group:care,topic:'AK/లగ్నాధిపతిపై GK ప్రభావం',page:25,
      condition:'Source specifically checks GK influence on AK or birth lagna lord.',
      result:'ఈ ఉదాహరణలో కుటుంబ సేవపై ప్రతికూల సంకేతానికి పాత్ర.',
      matched:associated(karaka('GK'), karaka('AK')) || associated(karaka('GK'),birthLord),caution:true,
      evidence:'GK=${karaka("GK")}, AK=${karaka("AK")}, D1 lord=$birthLord.');
    add(id:'D12-CARE-06',group:care,topic:'తల్లిదండ్రులతో గ్రహసంబంధాల్లో పాప ప్రభావం అధికం',page:25,
      condition:'More malefic influence on child significator may indicate resentment; strength comparison required.',
      result:'గ్రంథంలోని సంబంధ సూచిక, స్వభావం/నైతికతపై తీర్పు కాదు.');
    add(id:'D12-CARE-07',group:care,topic:'AK శుభ/పాప దృష్టులు – ఉదాహరణ',page:29,
      condition:'Source example AK Moon in own sign with exalted Jupiter and Venus aspect.',
      result:'తల్లిదండ్రుల మద్దతును ఉదాహరణలో విశ్లేషించారు; అన్ని షరతులు ఒకేసారి చూడాలి.',
      matched:karaka('AK')=='Moon' && signOf('Moon')==3 && signOf('Jupiter')==3 && aspects('Venus',signOf('Moon')),
      evidence:'AK=${karaka("AK")}; Moon sign=${signOf("Moon")}; Jupiter=${signOf("Jupiter")}; Venus aspect=${aspects("Venus",signOf("Moon"))}.');

    const estate='వారసత్వం / ఆస్తి';
    add(id:'D12-EST-01',group:estate,topic:'8వ భావం – వారసత్వము/పూర్వీకుల సంపద',page:34,
      condition:'8H/8L association depicts inheritance/legacy according to source; do not infer exact amount.',
      result:'8వ భావం, అధిపతి, సంబంధ గ్రహాలను పరిశీలించాలి.',
      evidence:'${houseAt(8)}.');
    add(id:'D12-EST-02',group:estate,topic:'Parashari D12 inheritance vs Cyclical D12 legacy',page:34,
      condition:'Text distinguishes inheritances received from predecessors and legacy passed down; Parashari D12 vs Cyclical D12.',
      result:'Cyclical D12 నిర్మాణం ఈ మూల excerptలో లేదు; fake cyclic chart లేదు.');
    add(id:'D12-EST-03',group:estate,topic:'PK (Parashari), MK (Cyclical) కారకుల ఉపయోగం',page:34,
      condition:'Source explicitly notes PK important for Parashari D12 and MK for Cyclical D12.',
      result:'రెండు mapping modes వేరు. Cyclical mapping verified అయ్యాక మాత్రమే రెండో ఫలితం.');
    add(id:'D12-EST-04',group:estate,topic:'8L–KL/2H/11H సంబంధం ద్వారా వారసత్వం',page:34,
      condition:'Eighth lord connected with KL, 2nd or 11th from KL indicates ancestral receiving; verify all relations.',
      result:'KL anchor ఇంకా ధృవీకరించలేదు; D12 lagnaను KLకు substitute చేయము.',
      evidence:'D12 8L=${houseLord(8)} ${planetAt(houseLord(8))}; 2L=${houseLord(2)}, 11L=${houseLord(11)}.');
    add(id:'D12-EST-05',group:estate,topic:'8వ అధిపతి–2వ అధిపతి సంబంధం (case evidence)',page:41,
      condition:'Page 41 case examines 8L in second and associations in a legacy analysis.',
      result:'ఇది case-based source relationship; KL + Cyclical D12 final judgement pending.',
      matched:associated(houseLord(8),houseLord(2)),
      evidence:'8L=${houseLord(8)} ${planetAt(houseLord(8))}, 2L=${houseLord(2)} ${planetAt(houseLord(2))}.');
    add(id:'D12-EST-06',group:estate,topic:'8వ అధిపతి 2వ లేదా 11వ భావంలో (case evidence)',page:41,
      condition:'Book inheritance examples check 8L in 2H and links to 11H; requires KL context for full source match.',
      result:'ఇది ఒక్కటే inheritance promise కాదు; KL/మూల అంశాలతో కలిపి చదవాలి.',
      matched:{2,11}.contains(houseOf(houseLord(8))),
      evidence:'8L=${houseLord(8)} in H${houseOf(houseLord(8))}; D12 only, KL pending.');
    add(id:'D12-EST-07',group:estate,topic:'GK/రాహు కేతు సంబంధం – వారసత్వ వినియోగ ఆటంకం',page:35,
      condition:'Association of nodes or GK with eighth lord can indicate negative legacy, impeded benefit, debts.',
      result:'గ్రంథం ప్రకారం వారసత్వ వినియోగంలో ఆటంక సూచిక; అసలు ఆస్తి వివాదం/మోసంపై తుది తీర్పు కాదు.',
      matched:nodeAssociated(houseLord(8)) || associated(karaka('GK'),houseLord(8)),caution:true,
      evidence:'8L=${houseLord(8)}; node relation=${nodeAssociated(houseLord(8))}; GK=${karaka("GK")}.');
    add(id:'D12-EST-08',group:estate,topic:'Cyclical D12లో 8L తనిఖీ – legacy ఎలా ఉపయోగించారు',page:37,
      condition:'Eighth lord, occupancy, GK, node relationships in cyclical D12 to judge handed-down assets.',
      result:'Cyclical D12 mapping source-dependent; పూర్తి formula లభించకపోతే auto-prediction నిలిపివేత.');
    add(id:'D12-EST-09',group:estate,topic:'KL లగ్నాధిపతి–8L–11L సంబంధం (ఉదాహరణలు)',page:38,
      condition:'D12 with KL as lagna / cyclical examples connect eighth and eleventh lords.',
      result:'అనుకూలం/అననుకూలం రెండు outcomes ఉదాహరణల్లో ఉన్నాయి; cross-check pending.');

    const longevity='తల్లిదండ్రుల ఆయుర్దాయం — గ్రంథ పరిశీలన';
    add(id:'D12-LONG-01',group:longevity,topic:'KL 4వ భావం తల్లి; 11వది తల్లి ఆయుర్ భావం',page:43,
      condition:'Mother=4th from KL; 8th from that=11th from KL.',
      result:'మాతృ ఆయుర్దాయ భావాల సూచన మాత్రమే; వ్యక్తిగత జీవితకాలం/మరణ తేదీ చెప్పదు.');
    add(id:'D12-LONG-02',group:longevity,topic:'KL 9వ భావం తండ్రి; 4వది పితృ ఆయుర్ భావం',page:43,
      condition:'Father=9th from KL; 8th from that=4th from KL.',
      result:'పితృ ఆయుర్దాయ భావాల సూచన మాత్రమే; వ్యక్తిగత జీవితకాలం/మరణ తేదీ చెప్పదు.');
    add(id:'D12-LONG-03',group:longevity,topic:'ఆయుర్ భావం/అధిపతి బలం, దృష్టులు',page:43,
      condition:'Inspect lords, strengths, aspects to both relevant 8th-derived houses.',
      result:'KL, గ్రహబల, శుభ/పాప దృష్టి పూర్తి అనుసంధానం లేనందున తుది longevity verdict లేదు.');
    add(id:'D12-LONG-04',group:longevity,topic:'GK పాపసంబంధం, ఆయుర్ భావాలు',page:43,
      condition:'Author regards GK association/aspect as serious affliction.',
      result:'మూలంలోని హెచ్చరిక నమోదు; మరణ అంచనా తయారు చేయదు.');
    add(id:'D12-LONG-05',group:longevity,topic:'DK / AmK దశలు – ఆయుర్ సూచిక',page:43,
      condition:'Book studies DK/AmK in dasha or sign dasha when linked to longevity houses.',
      result:'ఈ గ్రంథ నియమం sensitive; పూర్తిగా ధృవీకరించిన దశ/భావ ఆధారం లేక వ్యక్తిగత తేదీలు ఇవ్వము.');
    add(id:'D12-LONG-06',group:longevity,topic:'నోడ్స్ ఫలితం – రాశ్యాధిపతి/సంయుక్త గ్రహం',page:43,
      condition:'Nodes can act as lords of signs occupied or planets associated.',
      result:'Rahu/Ketu co-representation rule auditలో నమోదు; deterministic death prediction లేదు.');

    const periods='దశా విశ్లేషణ';
    add(id:'D12-PER-01',group:periods,topic:'Vimshottari + Chara దశా cross-check',page:45,
      condition:'Examples compare Vimshottari maha/antara dasha and Chara sign dasha; verify relevant houses and KL.',
      result:'మూలంలోని birth chart examples నుంచి ఒకే universal event-year formula తీసుకోలేం.');
    add(id:'D12-PER-02',group:periods,topic:'తల్లిదండ్రుల ఆయుర్ కేస్-studiesలో దశా అంశాలు',page:47,
      condition:'Examples pp.45,47,49,51 examine different event timings and rulership/strength.',
      result:'కేస్-స్టడీల దశా ఉదాహరణలు source auditలో ఉన్నాయి; ఆటో తేదీ చెప్పడం లేదు.');

    const cases='గ్రంథ ఉదాహరణలు';
    final examples = <(String,int,String)>[
      ('రామకృష్ణ పరమహంస — D12 11L–9L ధనయోగం, KL ఆశీర్వాద పరిశీలన',3,'birth/D12 chart, p.3 and KL reading p.4'),
      ('వివేకానంద — 11L–2L దృష్టి; AK/PK/AmK/KL role',5,'birth/D12 chart p.5; KL p.6'),
      ('మోదీ — 2L–5L యోగం; KL 9/10L, గురుబలం',7,'birth/D12 chart p.7; KL p.8'),
      ('ఓప్రా విన్‌ఫ్రీ — రెండో/నాలుగో భావం, బాల్యం; KL పోలిక',9,'source case p.9–11'),
      ('1945 April 30 జన్మ ఉదాహరణ — 2L, చంద్రుడు, 4H; KL',12,'source case p.12–13'),
      ('1973 May 11 జన్మ ఉదాహరణ — AK సూర్యుడు, 4H, KL',14,'source case duplicated pp.14–17; retain as distinct source material'),
      ('1975 August 14 జన్మ ఉదాహరణ — తల్లిదండ్రుల అనుబంధం',19,'case p.19–20'),
      ('1984 August 9 జన్మ ఉదాహరణ — లగ్నంలో గ్రహాలు, తల్లి/తండ్రి తులన',21,'case p.21–22'),
      ('1995 January 4 జన్మ ఉదాహరణ — లగ్న/చంద్ర/సూర్య సంబంధం',23,'case p.23–24'),
      ('1972 September 28 జన్మ ఉదాహరణ — తల్లిదండ్రులకు సహాయం',26,'source case p.26–27'),
      ('1967 March 31 జన్మ ఉదాహరణ — AK/MK/GK, సాయం',28,'source case p.28–29'),
      ('1975 August 14 జన్మ ఉదాహరణ — AK/BK, తల్లిదండ్రులకు సేవ',30,'source case p.30–31'),
      ('1977 November 21 జన్మ ఉదాహరణ — MK/BK, పితృ సంరక్షణ',32,'source case p.32–33'),
      ('1917 November 19 జన్మ ఉదాహరణ — వారసత్వం, 8H, Cyclical D12',35,'source case p.35–37'),
      ('1960 December 25 జన్మ ఉదాహరణ — వారసత్వ పాప ప్రభావం',38,'source case p.38–40'),
      ('1962 June 24 జన్మ ఉదాహరణ — 8L, BK/PK, legacy',40,'source case p.40–42'),
      ('1917 November 19 జన్మ ఉదాహరణ — తల్లి ఆయుర్దాయ దశలు',44,'source case p.44–45'),
      ('1950 September 17 జన్మ ఉదాహరణ — తల్లి దీర్ఘాయుష్షు దశలు',46,'source case p.46–47'),
      ('1944 August 20 జన్మ ఉదాహరణ — తండ్రి మధ్యాయువు దశలు',48,'source case p.48–49'),
      ('1942 October 11 జన్మ ఉదాహరణ — తల్లిదండ్రుల దీర్ఘాయుష్షు',50,'source case p.50–51'),
    ];
    for (var i=0; i<examples.length; i++) {
      final entry=examples[i];
      add(id:'D12-CASE-${(i+1).toString().padLeft(2,'0')}',
        group:cases,topic:entry.$1,page:entry.$2,
        condition:'Case study only: ${entry.$3}. Original printed horoscope, karakas, D12, and KL/Cyclical charts are in the source.',
        result:'మూల గ్రంథంలోని ఉదాహరణ — ఈ కేస్ గ్రహస్థితులను ప్రతి జాతకానికి వర్తించే స్వతంత్ర IF–THEN రూల్‌గా మార్చలేదు.');
    }
    return rows;
  }

  static bool _isNode(String p) => p=='Rahu'||p=='Ketu';
}
