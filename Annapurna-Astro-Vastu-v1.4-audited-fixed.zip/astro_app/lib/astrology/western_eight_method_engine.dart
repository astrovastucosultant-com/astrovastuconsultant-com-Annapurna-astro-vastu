import 'dart:math' as math;
import 'package:sweph/sweph.dart';
import '../models/birth_data.dart';
import 'astro_calculation_service.dart';
import 'western_progression_service.dart';
import 'naibod_axes.dart';

/// Isolated tropical Western calculation layer. Does not call Vedic dashas,
/// KP, Jaimini, or event-prediction engines.
enum WesternMethod {
  secondary, tertiary, minor, solarArc, naibod, oneDegree,
  primary, converseSecondary, annualProfection,
}

class WesternMethodSnapshot {
  final WesternMethod method;
  final DateTime date;
  final Map<String, double> positions;
  final List<String> aspects;
  final String note;
  final bool implemented;
  const WesternMethodSnapshot(this.method, this.date, this.positions,
      this.aspects, this.note, {this.implemented = true});
}

class WesternEightMethodEngine {
  static const double tropicalYear = 365.2421904;
  static const double siderealMonth = 27.321661;
  static double norm(double x) => (x % 360 + 360) % 360;

  static Future<WesternMethodSnapshot> calculate(
      BirthData birth, DateTime eventDate, WesternMethod method,
      {double orb = 0.5}) async {
    if (orb <= 0 || orb > 5) throw ArgumentError('Orb 0–5° required');
    await AstroCalculationService.initialize();
    if (!AstroCalculationService.isInitialized) {
      throw StateError('Swiss Ephemeris unavailable');
    }
    final eventUtc = DateTime.utc(eventDate.year, eventDate.month, eventDate.day, 12);
    final age = eventUtc.difference(birth.utcDateTime).inMicroseconds /
        (Duration.microsecondsPerDay * tropicalYear);
    if (age < 0) throw ArgumentError('Event date precedes birth');
    final natalJd = WesternProgressionService.julian(birth.utcDateTime);
    final natal = WesternProgressionService.positions(natalJd);
    final house = Sweph.swe_houses_ex(natalJd, SwephFlag.SEFLG_MOSEPH,
        birth.latitude, birth.longitude, Hsys.P);
    final asc = norm(house.ascmc[AscmcIndex.SE_ASC.index]);
    final mc = norm(house.ascmc[AscmcIndex.SE_MC.index]);
    final targets = <String,double>{...natal,'ASC':asc,'DESC':norm(asc+180),
      'MC':mc,'IC':norm(mc+180)};
    Map<String,double> positions = {};
    String note = '';
    switch (method) {
      case WesternMethod.secondary:
        positions = WesternProgressionService.positions(natalJd + age);
        note = 'Day for a tropical year; tropical geocentric longitudes';
        break;
      case WesternMethod.tertiary:
        // Tertiary-I: one ephemeris day per sidereal lunar month of life.
        positions = WesternProgressionService.positions(
            natalJd + age * tropicalYear / siderealMonth);
        note = 'Tertiary-I: 1 ephemeris day = 27.321661 life days';
        break;
      case WesternMethod.minor:
        // Minor: one sidereal lunar month of ephemeris time per life year.
        positions = WesternProgressionService.positions(natalJd + age * siderealMonth);
        note = 'Minor: 27.321661 ephemeris days per life year';
        break;
      case WesternMethod.solarArc:
        final progressed = WesternProgressionService.positions(natalJd + age);
        final arc = WesternProgressionService.distance(
            progressed['Sun']!, natal['Sun']!);
        positions = {for(final p in targets.entries) p.key:norm(p.value+arc)};
        note = 'True secondary solar arc, applied to natal longitudes';
        break;
      case WesternMethod.naibod:
        final eps = 23.4392911 * math.pi / 180;
        final mcRad = mc * math.pi / 180;
        final ramc = norm(math.atan2(math.sin(mcRad)*math.cos(eps),
            math.cos(mcRad))*180/math.pi);
        final axes = NaibodAxes.calculate(birthUtc:birth.utcDateTime,
            targetUtc:eventUtc, natalRamcDegrees:ramc,
            latitudeDegrees:birth.latitude);
        final arc = age * NaibodAxes.arcPerYear;
        positions = {for(final p in natal.entries) p.key:norm(p.value+arc),
          'ASC':axes.asc,'MC':axes.mc,'DESC':axes.dsc,'IC':axes.ic};
        note = 'Naibod mean arc: angles calculated from directed RAMC';
        break;
      case WesternMethod.oneDegree:
        positions = {for(final p in targets.entries) p.key:norm(p.value+age)};
        note = 'Symbolic 1°/year longitude directions; not primary directions';
        break;
      case WesternMethod.primary:
        // Primary directions require a documented mundane position and
        // semi-arc/key convention; never substitute zodiacal 1° directions.
        return WesternMethodSnapshot(method,eventDate,{},[],
          'NOT IMPLEMENTED: requires full mundane primary direction engine, '
          'latitude, RA/declination, semi-arcs, and direction key.',
          implemented:false);
      case WesternMethod.converseSecondary:
        positions = WesternProgressionService.positions(natalJd - age);
        note = 'Converse secondary: 1 ephemeris day backward per life year';
        break;
      case WesternMethod.annualProfection:
        final years = _completedBirthdays(birth.localDateTime,eventDate);
        final sign = ((asc / 30).floor() + years) % 12;
        positions = {'ProfectedSignIndex':sign.toDouble(),
          'ProfectedSignStart':sign*30.0};
        note = 'Whole-sign annual profection; age $years; zero-based Aries sign index';
        break;
    }
    final contacts = method == WesternMethod.annualProfection
        ? <String>[] : WesternProgressionService.contacts(
          positions,targets,orb,method.name,skipSelf:true);
    return WesternMethodSnapshot(method,eventDate,positions,contacts,note);
  }

  static int _completedBirthdays(DateTime birth,DateTime date) {
    var age = date.year-birth.year;
    if (date.month<birth.month ||
        (date.month==birth.month && date.day<birth.day)) age--;
    return age<0?0:age;
  }

  static Future<List<WesternMethodSnapshot>> allMethods(
      BirthData birth, DateTime date, {double orb=0.5}) async {
    final result=<WesternMethodSnapshot>[];
    for (final method in WesternMethod.values) {
      result.add(await calculate(birth,date,method,orb:orb));
    }
    return result;
  }
}
