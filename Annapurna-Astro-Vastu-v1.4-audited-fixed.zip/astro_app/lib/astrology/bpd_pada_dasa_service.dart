import 'dart:math' as math;
import 'astro_models.dart';

/// Two source-defined Bhrigu Pada Dasa profiles. NEVER combine their Saturn
/// cycles or Arudha conventions within a single candidate evaluation.
enum BpdProfile { vaaniSeven, nadiPraveshikaEight }

extension BpdProfileLabel on BpdProfile {
  String get label => this == BpdProfile.vaaniSeven
      ? 'Dr. K.P. Vaani — 7 గ్రహాలు (శని 30 సం.)'
      : 'Nādi Praveshikā — 8 గ్రహాలు (శని 29 సం., రాహు 93 సం.)';
  String get reference => this == BpdProfile.vaaniSeven
      ? 'K.P. Vaani, Bhrigu Pada Dasa System, Saptarishis Astrology Vol 7, pp.753–761'
      : 'Nādi Praveshikā, Bhrigu Pada Dasha, pp.214–221';
}

class BpdPlanetStep {
  final String planet;
  final int natalSign;
  final int progressedSign;
  final int cycle;
  final int signPosition; // 1..12, counting initial sign
  final int totalYears;
  final int? antardashaSign;
  final int? antardashaPosition;
  const BpdPlanetStep({required this.planet, required this.natalSign,
    required this.progressedSign, required this.cycle,
    required this.signPosition, required this.totalYears,
    this.antardashaSign, this.antardashaPosition});
}

class BpdDictum {
  final int number;
  final String summary;
  /// Calculated with source-defined, complete inputs; otherwise requires review.
  final bool supportedAutomatically;
  const BpdDictum(this.number, this.summary, this.supportedAutomatically);
  String get id => 'NP-BPD-${number.toString().padLeft(2, '0')}';
}

class BpdObservation {
  final String ruleId;
  final bool? matched; // null: not evaluated, never imply failure.
  final String details;
  const BpdObservation(this.ruleId, this.matched, this.details);
}

class BpdEventContext {
  final BpdProfile profile;
  final int natalAscSignIndex;
  final double elapsedYears;
  final Map<int,int> arudhaSigns;
  final List<BpdPlanetStep> progressions;
  final List<BpdObservation> observations;
  final List<String> notes;
  const BpdEventContext({required this.profile, required this.natalAscSignIndex, required this.elapsedYears,
    required this.arudhaSigns, required this.progressions,
    required this.observations, required this.notes});
  String get shortDisplay => '${profile.label} • వయస్సు ${elapsedYears.toStringAsFixed(2)} • '
      '${progressions.map((p) => '${p.planet}: ${BpdPadaDasaService.signs[p.progressedSign]}').join(' • ')}';
}

/// Source tables are 12 equal sign periods, starting at natal sign at age zero;
/// whole natal first-sign duration, never longitude-proportional balance.
/// Elapsed solar years = civil days/365.2425 is an *app approximation* of
/// source's year/month tables, NOT a claim of precision to the second.
class BpdPadaDasaService {
  static const List<String> signs = [
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];
  static const Map<String,int> vaaniCycles = {
    'Sun':19,'Moon':45,'Mars':14,'Mercury':46,
    'Jupiter':83,'Venus':27,'Saturn':30,
  };
  static const Map<String,int> nadiCycles = {
    'Sun':19,'Moon':45,'Mars':14,'Mercury':46,
    'Jupiter':83,'Venus':27,'Saturn':29,'Rahu':93,
  };
  static const List<String> signLords = [
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  static const List<BpdDictum> nadiDictums = [
    BpdDictum(1,'జన్మస్థితికి కేంద్ర ప్రోగ్రెషన్: ఫలితాలు క్రియాశీలం',true),
    BpdDictum(2,'జన్మస్థితికి 7వ స్థానంలో, ముఖ్యంగా శని/రాహు',true),
    BpdDictum(3,'A8 పాదాధిపతి జన్మస్థితికి కేంద్రం',true),
    BpdDictum(4,'A8 అధిపతి లగ్నం నుంచి 3/5/9/11/12',true),
    BpdDictum(5,'శని/గురు/రాహు/కుజ ప్రోగ్రెషన్ ప్రభావాల సవరణ',false),
    BpdDictum(6,'భావ అరూఢాధిపతి అదే భావంలో ప్రోగ్రెస్',true),
    BpdDictum(7,'AL/A2 అధిపతులు లగ్నానికి 6/8/12',true),
    BpdDictum(8,'జన్మ, ప్రోగ్రెషన్ దృష్టి ఒకే భావంపై',false),
    BpdDictum(9,'AL అధిపతి కేంద్రంలో రక్షణ; 6/8/12 మినహాయింపు',true),
    BpdDictum(10,'AL అధిపతి లగ్నం నుంచి 6/8/12',true),
    BpdDictum(11,'భావాధిపతి, అరూఢాధిపతి పరస్పర కేంద్రం',true),
    BpdDictum(12,'సాయన–నిరయణ ఒకే ప్రోగ్రెషన్ రాశి',false),
    BpdDictum(13,'కుజ 4వ చక్రం (42–56 ఏళ్లు)',true),
    BpdDictum(14,'గురు 6వ, 9వ రాశి పీరియడ్లు',true),
    BpdDictum(15,'శని 3వ చక్రపు ప్రారంభ సంవత్సరం',true),
    BpdDictum(16,'గ్రహం కొత్త నక్షత్రంలో ప్రవేశం',false),
    BpdDictum(17,'వింశోత్తరి MD–AD లార్డులు ప్రోగ్రెషన్‌లో కేంద్రాలు',false),
    BpdDictum(18,'జన్మ అస్తంగత గ్రహ ప్రోగ్రెషన్ ప్రభావం',false),
    BpdDictum(19,'రాహు దశలో రాహు–రాశ్యధిపతి 1–7',false),
    BpdDictum(20,'రాహు/రవి PAC–సింహం సంబంధ షరతులు',false),
    BpdDictum(21,'రాహు/చంద్ర PAC–కర్కాటకం సంబంధ షరతులు',false),
    BpdDictum(22,'రాహు/కుజ PAC–మేషం/వృశ్చికం షరతులు',false),
    BpdDictum(23,'11వ భావ ప్రోగ్రెషన్: వక్రత్వం, అర్గళ పరీక్షతో',false),
  ];

  static int _mod(int x) => (x % 12 + 12) % 12;
  /// Counting signs inclusively from 'from' to 'to'.
  static int houseFrom(int from, int to) => _mod(to-from)+1;
  static bool kendra(int from, int to) => const [1,4,7,10].contains(houseFrom(from,to));
  static bool dusthana(int from, int to) => const [6,8,12].contains(houseFrom(from,to));

  /// Returns sign index (0=Aries). Profiles deliberately disagree on
  /// the classical Arudha Kendra exception.
  static int arudha(int houseSign, int lordSign, BpdProfile profile) {
    final distance = _mod(lordSign-houseSign);
    var reflected = _mod(lordSign+distance);
    if (profile == BpdProfile.vaaniSeven && kendra(houseSign,reflected)) {
      reflected = _mod(reflected+9); // 10th inclusive from preliminary pada
    }
    return reflected;
  }

  static BpdPlanetStep progression({required String planet,
    required int natalSign, required double elapsedYears,
    required BpdProfile profile}) {
    final cycles = profile == BpdProfile.vaaniSeven ? vaaniCycles : nadiCycles;
    final years = cycles[planet];
    if (years == null) throw ArgumentError('Planet $planet not in ${profile.name}');
    if (elapsedYears < 0 || !elapsedYears.isFinite) {
      throw ArgumentError('Elapsed age invalid');
    }
    final periodsPassed = (elapsedYears*12/years).floor();
    // In the Nadi variant Rahu alone follows reverse zodiacal order.
    final direction = planet=='Rahu' ? -1 : 1;
    final progressed = _mod(natalSign + direction*(periodsPassed%12));
    final fractional = (elapsedYears*12/years)-periodsPassed;
    final subIndex = math.min(11, (fractional*12).floor());
    final adaSign = _mod(progressed + direction*subIndex);
    return BpdPlanetStep(planet:planet,natalSign:natalSign,
      progressedSign:progressed,cycle:periodsPassed~/12+1,
      signPosition:periodsPassed%12+1,totalYears:years,
      // Source introduces antardasha specifically for long signs,
      // never present sub-sign as an exact transit or birth second.
      antardashaSign: (profile==BpdProfile.nadiPraveshikaEight &&
          (planet=='Jupiter'||planet=='Rahu')) ? adaSign : null,
      antardashaPosition:(profile==BpdProfile.nadiPraveshikaEight &&
          (planet=='Jupiter'||planet=='Rahu')) ? subIndex+1 : null);
  }

  static BpdEventContext compute({required AstroChartResult chart,
    required DateTime birthDate,required DateTime eventDate,
    required BpdProfile profile, List<int> eventHouses = const []}) {
    if (eventDate.isBefore(birthDate)) {
      throw ArgumentError('Event precedes birth');
    }
    final years = eventDate.difference(birthDate).inMicroseconds /
        (365.2425*86400*1000000);
    final all = {for(final p in chart.planets) p.name:p.signIndex};
    final asc = chart.ascendantSignIndex;
    final padas=<int,int>{};
    for (var house=1;house<=12;house++) {
      final sign=_mod(asc+house-1);
      final lord=signLords[sign];
      final signOfLord=all[lord];
      if (signOfLord!=null) padas[house]=arudha(sign,signOfLord,profile);
    }
    final cycles=profile==BpdProfile.vaaniSeven?vaaniCycles:nadiCycles;
    final steps=[for(final e in cycles.entries) if (all[e.key]!=null)
      progression(planet:e.key,natalSign:all[e.key]!,elapsedYears:years,
        profile:profile)];
    final byName={for(final p in steps) p.planet:p};
    int? progressedPadaLord(int house) {
      final pada=padas[house];
      if(pada==null)return null;
      return byName[signLords[pada]]?.progressedSign;
    }
    final rules=<BpdObservation>[];
    if(profile==BpdProfile.nadiPraveshikaEight) {
      // These checks are *descriptive position flags*. Negatives cannot be
      // treated as negating an event; related strength/affliction details
      // belong to explicit clinical/practitioner review, not an opaque score.
      for (final r in nadiDictums) {
        final al=padas[1];final a2=padas[2];final a8=padas[8];
        final alLord=al==null?null:byName[signLords[al]];
        final a2Lord=a2==null?null:byName[signLords[a2]];
        final a8Lord=a8==null?null:byName[signLords[a8]];
        bool? value;
        String description='పూర్తి గ్రంథ షరతులు / అవసరమైన జాతక సమాచారం లేక మాన్యువల్ పరిశీలన.';
        switch(r.number) {
          case 1:
            value=steps.any((p)=>kendra(p.natalSign,p.progressedSign));
            description='ఏదైనా గ్రహం జన్మస్థితికి కేంద్రంలో ఉందా (సాధారణ పీరియడ్ సూచన)';
            break;
          case 2:
            value=steps.any((p)=>houseFrom(p.natalSign,p.progressedSign)==7);
            description='జన్మస్థితి నుంచి 7వ స్థానం; ఫలిత నిర్ధారణ కాదు';break;
          case 3:
            if(a8Lord!=null) value=kendra(a8Lord.natalSign,a8Lord.progressedSign);
            description='A8 అధిపతి జన్మస్థితికి కేంద్రం; మరణ సూచన ప్రకటించరాదు';break;
          case 4:
            if(a8Lord!=null) value=const [3,5,9,11,12].contains(houseFrom(asc,a8Lord.progressedSign));
            description='A8 అధిపతి ప్రోగ్రెషన్ లగ్నానికి 3/5/9/11/12';break;
          case 6:
            value=false;
            for(var h=1;h<=12;h++){
              final s=progressedPadaLord(h);
              if(s==_mod(asc+h-1)){value=true;break;}
            }
            description='సంబంధిత అరూఢాధిపతి తత్సంబంధ భావ రాశిలో';break;
          case 7:
            if(alLord!=null&&a2Lord!=null)value=dusthana(asc,alLord.progressedSign)||dusthana(asc,a2Lord.progressedSign);
            description='AL లేదా A2 అధిపతి లగ్నానికి 6/8/12';break;
          case 9:
            if(alLord!=null)value=kendra(alLord.natalSign,alLord.progressedSign)&&!dusthana(asc,alLord.progressedSign);
            description='AL అధిపతి కేంద్రం మరియు లగ్న 6/8/12 మినహాయింపు';break;
          case 10:
            if(alLord!=null)value=dusthana(asc,alLord.progressedSign);
            description='AL అధిపతి లగ్నానికి 6/8/12';break;
          case 11:
            value=false;
            for(var h=1;h<=12;h++) {
              final natalHouse=_mod(asc+h-1);
              final houseLord=byName[signLords[natalHouse]];
              final padaLordSign=progressedPadaLord(h);
              if(houseLord!=null && padaLordSign!=null &&
                  kendra(houseLord.progressedSign,padaLordSign)){value=true;break;}
            }
            description='ఏదైనా భావాధిపతి–అరూఢాధిపతి పరస్పర కేంద్రం';break;
          case 13:
            value=years>=42 && years<56;
            description='కుజ 4వ పూర్తి 14 సంవత్సరాల చక్రం';break;
          case 14:
            final j=byName['Jupiter'];
            if(j!=null)value=j.signPosition==6||j.signPosition==9;
            description='గురు 83 సంవత్సరాల చక్రంలో 6వ/9వ రాశి దశ';break;
          case 15:
            final s=byName['Saturn'];
            if(s!=null)value=s.cycle==3 && years>=58 && years<59;
            description='శని మూడవ చక్రం మొదటి సంవత్సరం (29-సంవత్సర చక్రం)';break;
          default: break;
        }
        rules.add(BpdObservation(r.id,value,description));
      }
    }
    final eventCrossing=<String>[];
    for (final h in eventHouses.toSet()) {
      if(h<1||h>12)continue;
      final pada=padas[h];
      if(pada==null)continue;
      final padaLord=signLords[pada];
      final progressive=byName[padaLord];
      if(progressive==null)continue;
      final targetSign=_mod(asc+h-1);
      final related= progressive.progressedSign==targetSign ||
          progressive.progressedSign==pada ||
          kendra(targetSign,progressive.progressedSign);
      eventCrossing.add('P$h $padaLord → ${signs[progressive.progressedSign]} • '
        '${related?'కేంద్ర/భావ సంబంధం':'సంబంధం కనిపించలేదు'}');
    }
    return BpdEventContext(profile:profile,natalAscSignIndex:asc,elapsedYears:years,
      arudhaSigns:padas,progressions:steps,observations:rules,
      notes: [
        ...eventCrossing,
        'BPD సందర్భ పరిశీలన మాత్రమే; BTR సెకన్ల ర్యాంకింగ్‌లో స్వతంత్ర ఓటు కాదు.',
        'వయస్సు రోజుల/365.2425 సౌర సంవత్సరాల ఆధారంగా సమీపీకరణ; మూల పట్టికలో నెలలు వాడారు.',
        if(profile==BpdProfile.nadiPraveshikaEight)
          'రాహు ప్రతిగమన రాశి క్రమం ప్రొఫైల్ కన్వెన్షన్; అసలు Appendixతో ఇంకా పోల్చాలి.',
      ]);
  }
}
