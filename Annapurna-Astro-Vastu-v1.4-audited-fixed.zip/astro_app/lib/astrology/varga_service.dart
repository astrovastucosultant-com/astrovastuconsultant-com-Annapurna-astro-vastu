import 'astro_models.dart';

class VargaDefinition {
  final int factor;
  final String name;
  final String teluguName;
  final String domain;

  const VargaDefinition({
    required this.factor,
    required this.name,
    required this.teluguName,
    required this.domain,
  });

  String get code => 'D$factor';
}

class VargaPlacement {
  final String name;
  final String shortName;
  final int signIndex;
  final bool retrograde;

  const VargaPlacement({
    required this.name,
    required this.shortName,
    required this.signIndex,
    required this.retrograde,
  });
}

class VargaChartData {
  final VargaDefinition definition;
  final int ascendantSignIndex;
  final List<VargaPlacement> planets;

  const VargaChartData({
    required this.definition,
    required this.ascendantSignIndex,
    required this.planets,
  });
}

/// Classical Parashari Shodashavarga sign mapping.
///
/// The source longitudes are already sidereal longitudes from Swiss Ephemeris.
/// This service remaps those longitudes into the 16 classical varga signs.
class VargaService {
  static const List<VargaDefinition> definitions = [
    VargaDefinition(factor: 1, name: 'Rasi', teluguName: 'రాశి', domain: 'మూల జాతకం'),
    VargaDefinition(factor: 2, name: 'Hora', teluguName: 'హోరా', domain: 'ధనం / సంపద'),
    VargaDefinition(factor: 3, name: 'Drekkana', teluguName: 'ద్రెక్కాణ', domain: 'సహోదరులు / ధైర్యం'),
    VargaDefinition(factor: 4, name: 'Chaturthamsha', teluguName: 'చతుర్థాంశ', domain: 'స్థిరాస్తి / భాగ్యం'),
    VargaDefinition(factor: 7, name: 'Saptamsha', teluguName: 'సప్తాంశ', domain: 'సంతానం'),
    VargaDefinition(factor: 9, name: 'Navamsha', teluguName: 'నవాంశ', domain: 'వివాహం / ధర్మం / బలం'),
    VargaDefinition(factor: 10, name: 'Dashamsha', teluguName: 'దశాంశ', domain: 'వృత్తి / ప్రతిష్ఠ'),
    VargaDefinition(factor: 12, name: 'Dwadashamsha', teluguName: 'ద్వాదశాంశ', domain: 'తల్లిదండ్రులు / వంశం'),
    VargaDefinition(factor: 16, name: 'Shodashamsha', teluguName: 'షోడశాంశ', domain: 'వాహనాలు / సౌఖ్యం'),
    VargaDefinition(factor: 20, name: 'Vimshamsha', teluguName: 'వింశాంశ', domain: 'ఆధ్యాత్మిక సాధన'),
    VargaDefinition(factor: 24, name: 'Chaturvimshamsha', teluguName: 'చతుర్వింశాంశ', domain: 'విద్య / అభ్యాసం'),
    VargaDefinition(factor: 27, name: 'Bhamsa', teluguName: 'భాంశ', domain: 'బలం / బలహీనతలు'),
    VargaDefinition(factor: 30, name: 'Trimshamsha', teluguName: 'త్రింశాంశ', domain: 'అరిష్ట / కష్టాలు'),
    VargaDefinition(factor: 40, name: 'Khavedamsha', teluguName: 'ఖవేదాంశ', domain: 'మాతృ వంశ ప్రభావం'),
    VargaDefinition(factor: 45, name: 'Akshavedamsha', teluguName: 'అక్షవేదాంశ', domain: 'పితృ వంశ ప్రభావం'),
    VargaDefinition(factor: 60, name: 'Shashtiamsha', teluguName: 'షష్ట్యాంశ', domain: 'సూక్ష్మ కర్మ ఫలితాలు'),
  ];

  static VargaDefinition definitionFor(int factor) =>
      definitions.firstWhere((d) => d.factor == factor);

  static VargaChartData calculate(AstroChartResult result, int factor) {
    final definition = definitionFor(factor);
    final planets = result.planets
        .map(
          (p) => VargaPlacement(
            name: p.name,
            shortName: p.shortName,
            signIndex: signForLongitude(p.longitude, factor),
            retrograde: p.retrograde,
          ),
        )
        .toList(growable: false);

    return VargaChartData(
      definition: definition,
      ascendantSignIndex: signForLongitude(result.ascendantLongitude, factor),
      planets: planets,
    );
  }

  /// Exact D24 longitude inside the derived Chaturvimshamsha sign.
  /// Each 1°15′ natal segment expands to 30° in D24. This keeps the existing
  /// D24 sign mapping but also preserves the fractional position needed for
  /// the user-defined 5th-house-start + 15° education selection rule.
  static double d24LongitudeForLongitude(double longitude) {
    final normalized = _norm(longitude);
    final degree = normalized % 30.0;
    const partSize = 30.0 / 24.0;
    final part = (degree / partSize).floor().clamp(0, 23).toInt();
    final fraction = (degree - (part * partSize)) / partSize;
    final sign = signForLongitude(normalized, 24);
    return _norm(sign * 30.0 + fraction * 30.0);
  }

  /// Exact D27 longitude inside the derived Bhamsa sign.
  /// Each 1°06′40″ natal segment expands to 30° in D27.
  static double d27LongitudeForLongitude(double longitude) {
    final normalized = _norm(longitude);
    final degree = normalized % 30.0;
    const partSize = 30.0 / 27.0;
    final part = (degree / partSize).floor().clamp(0, 26).toInt();
    final fraction = (degree - (part * partSize)) / partSize;
    final sign = signForLongitude(normalized, 27);
    return _norm(sign * 30.0 + fraction * 30.0);
  }

  /// Exact D10 longitude inside the derived Dashamsha sign.
  /// Each natal 3° segment expands to 30° in D10. This preserves the
  /// fractional position needed for the user-approved D10 10L-nakshatra rule.
  static double d10LongitudeForLongitude(double longitude) {
    final normalized = _norm(longitude);
    final degree = normalized % 30.0;
    const partSize = 3.0;
    final part = (degree / partSize).floor().clamp(0, 9).toInt();
    final fraction = (degree - (part * partSize)) / partSize;
    final sign = signForLongitude(normalized, 10);
    return _norm(sign * 30.0 + fraction * 30.0);
  }

  static int signForLongitude(double longitude, int factor) {
    final normalized = _norm(longitude);
    final sign = (normalized / 30.0).floor() % 12;
    final degree = normalized % 30.0;

    switch (factor) {
      case 1:
        return sign;
      case 2:
        return _hora(sign, degree);
      case 3:
        return _normSign(sign + _equalPart(degree, 3) * 4);
      case 4:
        return _normSign(sign + _equalPart(degree, 4) * 3);
      case 7:
        final start = _isOddRasi(sign) ? sign : sign + 6;
        return _normSign(start + _equalPart(degree, 7));
      case 9:
        final start = switch (_modality(sign)) {
          0 => sign,
          1 => sign + 8,
          _ => sign + 4,
        };
        return _normSign(start + _equalPart(degree, 9));
      case 10:
        final start = _isOddRasi(sign) ? sign : sign + 8;
        return _normSign(start + _equalPart(degree, 10));
      case 12:
        return _normSign(sign + _equalPart(degree, 12));
      case 16:
        final start = switch (_modality(sign)) {
          0 => 0, // Aries for movable signs
          1 => 4, // Leo for fixed signs
          _ => 8, // Sagittarius for dual signs
        };
        return _normSign(start + _equalPart(degree, 16));
      case 20:
        final start = switch (_modality(sign)) {
          0 => 0, // Aries
          1 => 8, // Sagittarius
          _ => 4, // Leo
        };
        return _normSign(start + _equalPart(degree, 20));
      case 24:
        final start = _isOddRasi(sign) ? 4 : 3; // Leo / Cancer
        return _normSign(start + _equalPart(degree, 24));
      case 27:
        final start = switch (_element(sign)) {
          0 => 0, // Fire -> Aries
          1 => 3, // Earth -> Cancer
          2 => 6, // Air -> Libra
          _ => 9, // Water -> Capricorn
        };
        return _normSign(start + _equalPart(degree, 27));
      case 30:
        return _trimshamsha(sign, degree);
      case 40:
        final start = _isOddRasi(sign) ? 0 : 6; // Aries / Libra
        return _normSign(start + _equalPart(degree, 40));
      case 45:
        final start = switch (_modality(sign)) {
          0 => 0, // Aries
          1 => 4, // Leo
          _ => 8, // Sagittarius
        };
        return _normSign(start + _equalPart(degree, 45));
      case 60:
        return _normSign(sign + _equalPart(degree, 60));
      default:
        throw ArgumentError('Unsupported varga D$factor');
    }
  }

  static int _hora(int sign, double degree) {
    final firstHalf = degree < 15.0;
    if (_isOddRasi(sign)) {
      return firstHalf ? 4 : 3; // Leo then Cancer
    }
    return firstHalf ? 3 : 4; // Cancer then Leo
  }

  static int _trimshamsha(int sign, double degree) {
    if (_isOddRasi(sign)) {
      if (degree < 5.0) return 0; // Mars -> Aries
      if (degree < 10.0) return 10; // Saturn -> Aquarius
      if (degree < 18.0) return 8; // Jupiter -> Sagittarius
      if (degree < 25.0) return 2; // Mercury -> Gemini
      return 6; // Venus -> Libra
    }

    if (degree < 5.0) return 1; // Venus -> Taurus
    if (degree < 12.0) return 5; // Mercury -> Virgo
    if (degree < 20.0) return 11; // Jupiter -> Pisces
    if (degree < 25.0) return 9; // Saturn -> Capricorn
    return 7; // Mars -> Scorpio
  }

  static int _equalPart(double degree, int divisions) {
    final size = 30.0 / divisions;
    final value = (degree / size).floor();
    if (value < 0) return 0;
    if (value >= divisions) return divisions - 1;
    return value;
  }

  /// 1-based odd zodiac signs correspond to zero-based even indices.
  static bool _isOddRasi(int sign) => sign.isEven;

  /// 0 = movable, 1 = fixed, 2 = dual.
  static int _modality(int sign) => sign % 3;

  /// 0 = fire, 1 = earth, 2 = air, 3 = water.
  static int _element(int sign) => sign % 4;

  static int _normSign(int sign) => ((sign % 12) + 12) % 12;

  static double _norm(double value) {
    var result = value % 360.0;
    if (result < 0) result += 360.0;
    return result;
  }
}
