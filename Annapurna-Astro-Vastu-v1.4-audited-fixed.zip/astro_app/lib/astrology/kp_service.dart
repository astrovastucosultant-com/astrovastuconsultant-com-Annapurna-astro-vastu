import 'astro_models.dart';
import 'dasha_service.dart';

class KpStellarPosition {
  final String body;
  final int signIndex;
  final String signLord;
  final int nakshatraIndex;
  final String starLord;
  final String subLord;
  final double longitude;

  const KpStellarPosition({
    required this.body,
    required this.signIndex,
    required this.signLord,
    required this.nakshatraIndex,
    required this.starLord,
    required this.subLord,
    required this.longitude,
  });
}

class KpEventGroup {
  final String event;
  final List<int> favourableHouses;
  final List<int> contraryHouses;
  final String primaryCusp;

  const KpEventGroup({
    required this.event,
    required this.favourableHouses,
    this.contraryHouses = const [],
    required this.primaryCusp,
  });
}

class KpService {
  static const List<String> signLords = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];

  static const List<KpEventGroup> eventGroups = [
    KpEventGroup(
      event: 'Marriage',
      favourableHouses: [2, 7, 11],
      contraryHouses: [1, 6, 10, 12],
      primaryCusp: '7th cusp',
    ),
    KpEventGroup(
      event: 'Employment / Service',
      favourableHouses: [2, 6, 10, 11],
      primaryCusp: '10th cusp',
    ),
    KpEventGroup(
      event: 'Finance / Wealth',
      favourableHouses: [2, 6, 10, 11],
      primaryCusp: '2nd cusp',
    ),
    KpEventGroup(
      event: 'Profit / Fulfilment',
      favourableHouses: [2, 6, 11],
      primaryCusp: '11th cusp',
    ),
    KpEventGroup(
      event: 'Loss',
      favourableHouses: [5, 8, 12],
      primaryCusp: '12th cusp',
    ),
    KpEventGroup(
      event: 'Foreign matters',
      favourableHouses: [3, 9, 12],
      primaryCusp: '9th / 12th cusp',
    ),
    KpEventGroup(
      event: 'Accident',
      favourableHouses: [6, 8, 12],
      primaryCusp: '8th cusp',
    ),
  ];

  static List<KpStellarPosition> planetaryTable(AstroChartResult chart) {
    return chart.planets.map((p) => forLongitude(p.name, p.longitude)).toList(growable: false);
  }

  static KpStellarPosition forLongitude(String body, double longitude) {
    const nakSize = 360.0 / 27.0;
    final normalized = ((longitude % 360.0) + 360.0) % 360.0;
    final sign = (normalized / 30.0).floor() % 12;
    final nak = (normalized / nakSize).floor().clamp(0, 26).toInt();
    final starLordIndex = nak % DashaService.lordOrder.length;
    final starLord = DashaService.lordOrder[starLordIndex];
    final withinStar = normalized - nak * nakSize;
    final subLord = _subLord(starLordIndex, withinStar, nakSize);
    return KpStellarPosition(
      body: body,
      signIndex: sign,
      signLord: signLords[sign],
      nakshatraIndex: nak,
      starLord: starLord,
      subLord: subLord,
      longitude: normalized,
    );
  }

  static String _subLord(int starLordIndex, double withinStar, double nakSize) {
    var cursor = 0.0;
    for (var i = 0; i < DashaService.lordOrder.length; i++) {
      final lord = DashaService.lordOrder[(starLordIndex + i) % DashaService.lordOrder.length];
      final length = nakSize * DashaService.years[lord]! / 120.0;
      if (withinStar < cursor + length || i == DashaService.lordOrder.length - 1) {
        return lord;
      }
      cursor += length;
    }
    // Defensive fallback: the loop above always returns on its final item.
    // Keep an explicit valid value here so release compilation succeeds.
    return DashaService.lordOrder[starLordIndex];
  }
}
