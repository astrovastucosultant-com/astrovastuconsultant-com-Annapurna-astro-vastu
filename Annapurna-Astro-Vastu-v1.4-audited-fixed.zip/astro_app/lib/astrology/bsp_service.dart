import 'dart:math' as math;

import 'astro_models.dart';

class BspRule {
  final String id;
  final int? bspNo;
  final int year;
  final String planet;
  final String implementation;
  final List<int> primaryOffsets;
  final List<int> optionalOffsets;
  final Map<int, double> weightedOffsets;
  final String source;
  final String sourceNote;
  final bool exactArithmeticAvailable;

  const BspRule({
    required this.id,
    required this.bspNo,
    required this.year,
    required this.planet,
    required this.implementation,
    this.primaryOffsets = const [],
    this.optionalOffsets = const [],
    this.weightedOffsets = const {},
    required this.source,
    this.sourceNote = '',
    this.exactArithmeticAvailable = true,
  });
}

class BspActivation {
  final BspRule rule;
  final int natalSign;
  final int natalHouse;
  final List<int> targetSigns;
  final List<int> targetHouses;
  final List<int> optionalTargetSigns;
  final List<int> optionalTargetHouses;
  final List<int> lordshipHouses;
  final List<String> resultLines;
  final String reason;

  const BspActivation({
    required this.rule,
    required this.natalSign,
    required this.natalHouse,
    required this.targetSigns,
    required this.targetHouses,
    required this.optionalTargetSigns,
    required this.optionalTargetHouses,
    required this.lordshipHouses,
    required this.resultLines,
    required this.reason,
  });
}

class BspYearResult {
  final int year;
  final DateTime start;
  final DateTime end;
  final List<BspActivation> activations;
  final Bsp37Result? bsp37;

  const BspYearResult({
    required this.year,
    required this.start,
    required this.end,
    required this.activations,
    this.bsp37,
  });
}

class Bsp37Result {
  final bool matched;
  final String relation;
  final int moonHouse;
  final int marsHouse;
  final List<int> moonLordshipHouses;
  final List<int> marsLordshipHouses;
  final List<String> resultLines;

  const Bsp37Result({
    required this.matched,
    required this.relation,
    required this.moonHouse,
    required this.marsHouse,
    required this.moonLordshipHouses,
    required this.marsLordshipHouses,
    required this.resultLines,
  });
}

/// Bhrigu Saral Paddhati (BSP) year-activation engine built only from the
/// supplied 27-page "B S P" source.
///
/// The appendix gives the year -> planet -> implementation point. The worked
/// example (uploaded PDF pp.2-14) interprets that point through the native's
/// houses, lordships and planetary context. This service reproduces that
/// transparent pipeline and keeps unclear scan text flagged instead of guessed.
class BspService {
  static const List<int> sourceYearOrder = [
    10,
    18,
    20,
    22,
    24,
    25,
    27,
    28,
    30,
    32,
    33, // BSP 37 Moon-Mars special activation
    35,
    36,
    37,
    38,
    40,
    48,
    51,
    66,
    69,
  ];

  static const List<BspRule> rules = [
    BspRule(id: 'BSP23-Y10', bspNo: 23, year: 10, planet: 'Sun', implementation: '6th from its Natal Position', primaryOffsets: [5], source: 'B S P — Appendix-1, uploaded p.23; worked example pp.2–3'),
    BspRule(id: 'BSP-Y18-MOON', bspNo: null, year: 18, planet: 'Moon', implementation: 'Vibrates at its Natal Position', primaryOffsets: [0], source: 'B S P — Appendix-1, uploaded p.23; worked example p.3'),
    BspRule(id: 'BSP13-Y20', bspNo: 13, year: 20, planet: 'Saturn', implementation: '3rd Aspect', primaryOffsets: [2], source: 'B S P — Appendix-1, uploaded p.23; worked example pp.3–4'),
    BspRule(id: 'BSP19-Y22', bspNo: 19, year: 22, planet: 'Jupiter', implementation: '9th Aspect', primaryOffsets: [8], source: 'B S P — Appendix-1, uploaded p.23; worked example p.4'),
    BspRule(id: 'BSP21-Y22', bspNo: 21, year: 22, planet: 'Rahu', implementation: '5th Aspect', primaryOffsets: [4], source: 'B S P — Appendix-1, uploaded p.23; worked example p.4'),
    BspRule(id: 'BSP35-Y22', bspNo: 35, year: 22, planet: 'Mercury', implementation: 'Natal Position OR 2nd from its Natal Position', primaryOffsets: [0], optionalOffsets: [1], source: 'B S P — Appendix-1, uploaded p.23', sourceNote: 'Source prints an OR condition; both candidate implementation points are displayed.'),
    BspRule(id: 'BSP09-Y24', bspNo: 9, year: 24, planet: 'Ketu', implementation: '12th from its Natal Position', primaryOffsets: [11], source: 'B S P — Appendix-1, uploaded p.23; worked example p.5'),
    BspRule(id: 'BSP27-Y24', bspNo: 27, year: 24, planet: 'Saturn', implementation: '4th from its Natal Position', primaryOffsets: [3], source: 'B S P — Appendix-1, uploaded p.23; worked example p.5'),
    BspRule(id: 'BSP28-Y24', bspNo: 28, year: 24, planet: 'Mercury', implementation: '10th from its Natal Position', primaryOffsets: [9], source: 'B S P — Appendix-1, uploaded p.23; worked example p.5'),
    BspRule(id: 'BSP23-Y25', bspNo: 23, year: 25, planet: 'Sun', implementation: 'Natal Position', primaryOffsets: [0], source: 'B S P — Appendix-1, uploaded p.23; worked example pp.5–6'),
    BspRule(id: 'BSP06-Y27', bspNo: 6, year: 27, planet: 'Mars', implementation: '10th from its Natal Position', primaryOffsets: [9], source: 'B S P — Appendix-1, uploaded p.23; worked example p.6'),
    BspRule(id: 'BSP22-Y28', bspNo: 22, year: 28, planet: 'Saturn', implementation: '6th from its Natal Position', primaryOffsets: [5], source: 'B S P — Appendix-1, uploaded p.23; worked example pp.6–7'),
    BspRule(id: 'BSP-Y28-MERCURY', bspNo: null, year: 28, planet: 'Mercury', implementation: 'Vibrates in 5th from its Natal Position', primaryOffsets: [4], source: 'B S P — Appendix-1, uploaded p.23; worked example pp.6–7'),
    BspRule(id: 'BSP30-Y30', bspNo: 30, year: 30, planet: 'Rahu', implementation: 'Natal Position', primaryOffsets: [0], source: 'B S P — Appendix-1, uploaded p.23; worked example p.7'),
    BspRule(id: 'BSP11-Y32', bspNo: 11, year: 32, planet: 'Jupiter', implementation: '5th Aspect + Sometimes (1st + 7th)', primaryOffsets: [4], optionalOffsets: [0, 6], source: 'B S P — Appendix-1, uploaded p.24; worked example p.8', sourceNote: '5th aspect is the primary appendix entry; 1st/7th are printed as “sometimes” and are shown as optional candidates.'),
    BspRule(id: 'BSP29-Y32', bspNo: 29, year: 32, planet: 'Mars', implementation: '4th Aspect', primaryOffsets: [3], source: 'B S P — Appendix-1, uploaded p.24; worked example p.8'),
    BspRule(id: 'BSP-Y32-SUN', bspNo: null, year: 32, planet: 'Sun', implementation: 'Natal Position', primaryOffsets: [0], source: 'B S P — Appendix-1, uploaded p.24; worked example p.8'),
    BspRule(id: 'BSP33-Y32', bspNo: 33, year: 32, planet: 'Mercury', implementation: '8th from its Natal Position', primaryOffsets: [7], source: 'B S P — Appendix-1, uploaded p.24; worked example p.8'),
    BspRule(id: 'BSP34-Y32', bspNo: 34, year: 32, planet: 'Saturn', implementation: 'Natal Position OR 10th House from its Natal Position', primaryOffsets: [0], optionalOffsets: [9], source: 'B S P — Appendix-1, uploaded p.24; worked example p.8', sourceNote: 'Source prints an OR condition; both candidate implementation points are displayed.'),
    BspRule(id: 'BSP-Y35-JUPITER', bspNo: null, year: 35, planet: 'Jupiter', implementation: 'Natal Position + “1/4?5th” from its Natal Position (scan unclear)', primaryOffsets: [0], source: 'B S P — Appendix-1, uploaded p.24; worked example p.9', sourceNote: 'The secondary notation in the supplied scan is not reliably legible. Natal-position implementation is verified; the unclear secondary point is not guessed.', exactArithmeticAvailable: false),
    BspRule(id: 'BSP31-Y36', bspNo: 31, year: 36, planet: 'Mars', implementation: '8th Aspect', primaryOffsets: [7], source: 'B S P — Appendix-1, uploaded p.24; worked example pp.9–10'),
    BspRule(id: 'BSP17-Y37', bspNo: 17, year: 37, planet: 'Rahu', implementation: 'Natal Position + 9th Aspect', primaryOffsets: [0, 8], source: 'B S P — Appendix-1, uploaded p.24; worked example pp.10–11'),
    BspRule(id: 'BSP32-Y37', bspNo: 32, year: 37, planet: 'Jupiter', implementation: 'Natal Position', primaryOffsets: [0], source: 'B S P — Appendix-1, uploaded p.24; worked example pp.10–11'),
    BspRule(id: 'BSP08-Y38', bspNo: 8, year: 38, planet: 'Rahu', implementation: '6th from its Natal Position', primaryOffsets: [5], source: 'B S P — Appendix-1, uploaded p.24; worked example p.11'),
    BspRule(id: 'BSP10-Y40', bspNo: 10, year: 40, planet: 'Jupiter', implementation: '9th Aspect + Natal Position', primaryOffsets: [8, 0], source: 'B S P — Appendix-1, uploaded p.24; worked example pp.11–12'),
    BspRule(id: 'BSP24-Y40', bspNo: 24, year: 40, planet: 'Mercury', implementation: '7th from its Natal Position', primaryOffsets: [6], source: 'B S P — Appendix-1, uploaded p.24; worked example pp.11–12'),
    BspRule(id: 'BSP36-Y40', bspNo: 36, year: 40, planet: 'Jupiter', implementation: '8th from its Natal Position', primaryOffsets: [7], source: 'B S P — Appendix-1, uploaded p.24; worked example pp.11–12'),
    BspRule(id: 'BSP27-Y48', bspNo: 27, year: 48, planet: 'Saturn', implementation: '4th from its Natal Position', primaryOffsets: [3], source: 'B S P — Appendix-1, uploaded p.24; worked example pp.12–13'),
    BspRule(id: 'BSP26-Y51', bspNo: 26, year: 51, planet: 'Saturn', implementation: 'Natal Position + 25% 3rd Aspect', primaryOffsets: [0], weightedOffsets: {2: 0.25}, source: 'B S P — Appendix-1, uploaded p.24; worked example p.13', sourceNote: 'The appendix explicitly qualifies the 3rd aspect as 25%; the natal position remains the primary implementation.'),
    BspRule(id: 'BSP-Y66-SATURN', bspNo: null, year: 66, planet: 'Saturn', implementation: 'Natal Position', primaryOffsets: [0], source: 'B S P — Appendix-1, uploaded p.24; worked example pp.13–14'),
    BspRule(id: 'BSP18-Y69', bspNo: 18, year: 69, planet: 'Jupiter', implementation: 'Natal Position', primaryOffsets: [0], source: 'B S P — Appendix-1, uploaded p.24; note on p.14'),
  ];

  static const Map<int, String> houseThemes = {
    1: 'స్వయం, శరీరం, వ్యక్తిత్వం, ఆరోగ్యం',
    2: 'కుటుంబం, ధనం, వాక్కు, పోషణ',
    3: 'ధైర్యం, కమ్యూనికేషన్, రచన, సహోదరులు, చిన్న ప్రయాణాలు',
    4: 'తల్లి, ఇల్లు, విద్య, ఆస్తి, సౌఖ్యం, వాహనం',
    5: 'విద్య, సంతానం, సృజన, ప్రేమ, ప్రతిభ',
    6: 'ఉద్యోగం/సేవ, పోటీ, రుణం, రోగం, విభేదాలు',
    7: 'వివాహం, భాగస్వామ్యం, ప్రజాసంబంధాలు',
    8: 'మార్పు, పరిశోధన, రహస్యాలు, ఆకస్మిక పరిణామాలు',
    9: 'భాగ్యం, తండ్రి/గురు, ఉన్నత విద్య, ధర్మం, దీర్ఘ ప్రయాణం',
    10: 'వృత్తి, స్థానం, కీర్తి, బాధ్యత, అధికార సంబంధాలు',
    11: 'లాభాలు, కోరికల నెరవేర్పు, మిత్రులు, పెద్ద సోదరులు',
    12: 'వ్యయం, విదేశం, ఆసుపత్రి, విరామం, విడిపోవడం/త్యాగం',
  };

  static const Map<String, String> naturalThemes = {
    'Sun': 'అధికారం, ప్రతిష్ఠ, తండ్రి, ప్రభుత్వం, నాయకత్వం',
    'Moon': 'మనస్సు, తల్లి, ప్రజలు, గృహం, భావోద్వేగ స్పందన',
    'Mars': 'చర్య, ధైర్యం, భూమి, సాంకేతిక/శస్త్ర సంబంధ విషయాలు',
    'Mercury': 'విద్య, రచన, కమ్యూనికేషన్, వ్యాపారం, విశ్లేషణ',
    'Jupiter': 'జ్ఞానం, గురువు, భాగ్యం, సంతానం, విస్తరణ',
    'Venus': 'వివాహం, సంబంధాలు, సౌఖ్యం, కళ, వాహనం',
    'Saturn': 'పని, సేవ, బాధ్యత, ఆలస్యం, క్రమశిక్షణ, స్థిరత్వం',
    'Rahu': 'ఆకస్మిక మార్పు, పరిశోధన, విదేశీ/అసాధారణ విషయాలు, ఆకాంక్ష',
    'Ketu': 'విరక్తి, విరామం, పరిశోధన, ఆధ్యాత్మిక/అంతర్ముఖ దృష్టి',
  };

  // Aries..Pisces sign lords; nodes intentionally not assigned as standard lords.
  static const List<String> _signLords = [
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];

  static List<int> years() => List<int>.unmodifiable(sourceYearOrder);

  static List<BspYearResult> evaluateAll({
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    return sourceYearOrder
        .map((year) => evaluateYear(
              chart: chart,
              birthDateTime: birthDateTime,
              year: year,
            ))
        .toList(growable: false);
  }

  static BspYearResult evaluateYear({
    required AstroChartResult chart,
    required DateTime birthDateTime,
    required int year,
  }) {
    final yearRules = rules.where((r) => r.year == year).toList(growable: false);
    final activations = yearRules
        .map((r) => _evaluateRule(chart, r))
        .whereType<BspActivation>()
        .toList(growable: false);
    final bsp37 = (year == 32 || year == 33) ? _evaluateBsp37(chart) : null;
    return BspYearResult(
      year: year,
      start: _anniversary(birthDateTime, year - 1),
      end: _anniversary(birthDateTime, year),
      activations: activations,
      bsp37: bsp37,
    );
  }

  static int currentBspYear(DateTime birthDateTime, DateTime now) {
    var age = now.year - birthDateTime.year;
    final birthdayThisYear = _anniversary(birthDateTime, age);
    if (now.isBefore(birthdayThisYear)) age -= 1;
    return math.max(1, age + 1).toInt();
  }

  static BspActivation? _evaluateRule(AstroChartResult chart, BspRule rule) {
    final planet = _planet(chart, rule.planet);
    if (planet == null) return null;
    final asc = chart.ascendantSignIndex;
    final natalSign = planet.signIndex;
    final natalHouse = _houseFromSign(asc, natalSign);
    final primarySigns = rule.primaryOffsets
        .map((o) => (natalSign + o) % 12)
        .toSet()
        .toList(growable: false);
    final optionalSigns = rule.optionalOffsets
        .map((o) => (natalSign + o) % 12)
        .toSet()
        .toList(growable: false);
    final weightedSigns = rule.weightedOffsets.keys
        .map((o) => (natalSign + o) % 12)
        .toSet()
        .toList(growable: false);
    final targetSigns = <int>{...primarySigns, ...weightedSigns}.toList(growable: false);
    final targetHouses = targetSigns.map((s) => _houseFromSign(asc, s)).toList(growable: false);
    final optionalHouses = optionalSigns.map((s) => _houseFromSign(asc, s)).toList(growable: false);
    final lordships = _lordshipHouses(asc, rule.planet);

    final lines = <String>[];
    if (targetHouses.isNotEmpty) {
      for (final h in targetHouses) {
        lines.add('$hవ భావం activate అవుతుంది — ${houseThemes[h]}.');
      }
    }
    if (optionalHouses.isNotEmpty) {
      for (final h in optionalHouses) {
        lines.add('Source optional/OR point: $hవ భావం — ${houseThemes[h]}.');
      }
    }
    if (lordships.isNotEmpty) {
      lines.add('${rule.planet} ఈ లగ్నానికి ${lordships.join(', ')} భావాధిపత్య విషయాలను కూడా తీసుకువస్తుంది.');
      for (final h in lordships) {
        lines.add('అధిపత్య $hవ భావం: ${houseThemes[h]}.');
      }
    }
    final nTheme = naturalThemes[rule.planet];
    if (nTheme != null) lines.add('${rule.planet} సహజ కారకత్వం: $nTheme.');
    if (!rule.exactArithmeticAvailable) {
      lines.add('⚠ Source scanలో secondary notation స్పష్టంగా లేదు; verified natal-position result మాత్రమే auto-calculate చేశాం.');
    }
    if (rule.weightedOffsets.isNotEmpty) {
      for (final entry in rule.weightedOffsets.entries) {
        final sign = (natalSign + entry.key) % 12;
        final house = _houseFromSign(asc, sign);
        lines.add('${(entry.value * 100).round()}% qualified implementation: $houseవ భావం (${houseThemes[house]}).');
      }
    }

    final reason = '${rule.planet} natal house $natalHouse నుండి source “${rule.implementation}” rule apply చేసి implementation house(s) ${targetHouses.join(', ')} నిర్ణయించాం.';
    return BspActivation(
      rule: rule,
      natalSign: natalSign,
      natalHouse: natalHouse,
      targetSigns: targetSigns,
      targetHouses: targetHouses,
      optionalTargetSigns: optionalSigns,
      optionalTargetHouses: optionalHouses,
      lordshipHouses: lordships,
      resultLines: lines,
      reason: reason,
    );
  }

  static Bsp37Result _evaluateBsp37(AstroChartResult chart) {
    final moon = _planet(chart, 'Moon');
    final mars = _planet(chart, 'Mars');
    if (moon == null || mars == null) {
      return const Bsp37Result(
        matched: false,
        relation: 'Moon/Mars data unavailable',
        moonHouse: 0,
        marsHouse: 0,
        moonLordshipHouses: [],
        marsLordshipHouses: [],
        resultLines: [],
      );
    }
    final diff = (moon.signIndex - mars.signIndex).abs();
    final opposition = diff == 6;
    final conjunction = moon.signIndex == mars.signIndex;
    final matched = conjunction || opposition;
    final asc = chart.ascendantSignIndex;
    final moonHouse = _houseFromSign(asc, moon.signIndex);
    final marsHouse = _houseFromSign(asc, mars.signIndex);
    final moonLords = _lordshipHouses(asc, 'Moon');
    final marsLords = _lordshipHouses(asc, 'Mars');
    final lines = <String>[];
    if (matched) {
      lines.add('BSP 37 source condition match: Moon & Mars ${conjunction ? 'conjunction' : 'opposition'}; 32వ మరియు/లేదా 33వ సంవత్సరంలో activation చూడాలి.');
      lines.add('Moon $moonHouseవ భావంలో — ${houseThemes[moonHouse]}.');
      lines.add('Mars $marsHouseవ భావంలో — ${houseThemes[marsHouse]}.');
      if (moonLords.isNotEmpty) lines.add('Moon అధిపత్యం: ${moonLords.join(', ')} భావాలు.');
      if (marsLords.isNotEmpty) lines.add('Mars అధిపత్యం: ${marsLords.join(', ')} భావాలు.');
      lines.add('ఫలితాన్ని source examplesలాగే Moon/Mars ఉన్న భావాలు + వారి అధిపత్య భావాలు + సంబంధిత గ్రహ సంబంధాల సమ్మిళితంగా చదవాలి.');
    } else {
      lines.add('BSP 37 condition match కాలేదు: Moon–Mars conjunction/opposition లేదు. కాబట్టి ఈ ప్రత్యేక ruleను resultగా fire చేయము.');
    }
    return Bsp37Result(
      matched: matched,
      relation: conjunction ? 'Conjunction' : opposition ? 'Opposition' : 'No conjunction/opposition',
      moonHouse: moonHouse,
      marsHouse: marsHouse,
      moonLordshipHouses: moonLords,
      marsLordshipHouses: marsLords,
      resultLines: lines,
    );
  }

  static PlanetPosition? _planet(AstroChartResult chart, String name) {
    for (final p in chart.planets) {
      if (p.name.toLowerCase() == name.toLowerCase()) return p;
    }
    return null;
  }

  static int _houseFromSign(int ascSign, int sign) => ((sign - ascSign + 12) % 12) + 1;

  static List<int> _lordshipHouses(int ascSign, String planet) {
    final houses = <int>[];
    for (var sign = 0; sign < 12; sign++) {
      if (_signLords[sign] == planet) houses.add(_houseFromSign(ascSign, sign));
    }
    houses.sort();
    return houses;
  }

  static DateTime _anniversary(DateTime birth, int yearsAfterBirth) {
    final year = birth.year + yearsAfterBirth;
    final maxDay = DateTime(year, birth.month + 1, 0).day;
    final day = math.min(birth.day, maxDay);
    return DateTime(year, birth.month, day, birth.hour, birth.minute, birth.second);
  }
}
