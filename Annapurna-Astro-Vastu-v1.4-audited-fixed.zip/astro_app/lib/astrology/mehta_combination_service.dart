import 'astro_models.dart';
enum MehtaComboTone { favorable, caution, mixed, info }
class MehtaCombinationRule {
  final String key; final String id; final String folder; final String folderLabel; final String no; final String title; final String ruleText; final String phalaText; final bool autoEvaluated; final bool sensitive;
  const MehtaCombinationRule({required this.key,required this.id,required this.folder,required this.folderLabel,required this.no,required this.title,required this.ruleText,required this.phalaText,required this.autoEvaluated,this.sensitive=false});
}
class MehtaReferenceChoice {
  final int signIndex; final String label; final String reason; final bool janmaStrong; final bool moonStrong;
  const MehtaReferenceChoice({required this.signIndex,required this.label,required this.reason,required this.janmaStrong,required this.moonStrong});
}
class MehtaCombinationMatch {
  final MehtaCombinationRule rule; final bool matched; final MehtaComboTone tone; final String logic; final String sourceResult; final String evidence; final int? affectedSignIndex; final int? affectedHouse; final int janmaHouse; final int moonHouse; final MehtaReferenceChoice reference;
  const MehtaCombinationMatch({required this.rule,required this.matched,required this.tone,required this.logic,required this.sourceResult,required this.evidence,required this.affectedSignIndex,required this.affectedHouse,required this.janmaHouse,required this.moonHouse,required this.reference});
}
class MehtaCombinationService {
  static const List<String> signNamesTe = ['మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య','తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం'];
  static const Map<String,String> _alias = {'Su':'Sun','Mo':'Moon','Ma':'Mars','Me':'Mercury','Ju':'Jupiter','Ve':'Venus','Sa':'Saturn','Ra':'Rahu','Ke':'Ketu'};
  static const Map<String,List<int>> _ex = {'Su':[0,4,8],'Sa':[6,10,2],'Ma':[9,1,5],'Ju':[3,7,11],'Ve':[11,3,7],'Me':[10,2,6],'Mo':[1,5,9]};
  static const Map<String,List<int>> _fall = {'Su':[6,10,2],'Sa':[0,4,8],'Ma':[3,7,11],'Ju':[9,1,5],'Ve':[5,9,1],'Me':[4,8,0],'Mo':[3,7,11]};
  static const Map<String,List<int>> _own = {'Su':[4],'Mo':[3],'Ma':[0,7],'Me':[2,5],'Ju':[8,11],'Ve':[1,6],'Sa':[9,10]};
  static const List<MehtaCombinationRule> rules = [
    MehtaCombinationRule(key:"1:mula:F1:మూ-1",id:"F1",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"మూ-1",title:"ఉచ్చ గ్రహానికి శని సంయోగం/దృష్టి",ruleText:"గ్రహం ఉచ్చంలో ఉండి శనితో కలిస్తే లేదా శని దృష్టి పడితే, మొదటి అర్ధ జీవితంలో నీచ ఫలం; రెండవ అర్ధంలో ఉచ్చ ఫలం.",phalaText:"ఆ గ్రహం యొక్క భావాలు మొదట తీసివేయబడి తర్వాత తిరిగి ఇవ్వబడతాయి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"2:mula:F2:మూ-2",id:"F2",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"మూ-2",title:"నీచ గ్రహానికి శని సంయోగం/దృష్టి",ruleText:"నీచ గ్రహానికి శని కలిస్తే/చూస్తే మొదట ఉచ్చ ఫలం, రెండవ అర్ధ జీవితంలో నీచ ఫలం.",phalaText:"ముందు సౌకర్యాలు, తర్వాత తగ్గుదల.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"3:mula:F3:మూ-3",id:"F3",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"మూ-3",title:"నీచ శనిని స్వామి బలం ఓడించడం",ruleText:"శని మేష/సింహ/ధనుస్సులో నీచం అయితే ఆ రాశి స్వామి స్వగృహం/ఉచ్చం అయితే శని ఉచ్చంలా పనిచేస్తాడు.",phalaText:"శని భావాలు (సాధారణంగా 10-11) రక్షితం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"4:mula:F4:మూ-4",id:"F4",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"మూ-4",title:"ఉచ్చ శనితో రవి — శని నీచం",ruleText:"శని తుల/కుంభ/మిథున ఉచ్చంలో రవితో కలిస్తే శని నీచంలా, రవి ఉచ్చంలా.",phalaText:"రవి భావాలు పెరుగుతాయి; శని భావాలు తగ్గుతాయి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"5:mula:F5:మూ-5",id:"F5",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"మూ-5",title:"రవి+బుధం కలిస్తే స్వభావం తిరగడం",ruleText:"మేష/సింహ/ధనుస్సులో రవి+బుధం: బుధం ఉచ్చం, రవి నీచం. మిథున/తుల/కుంభలో విరుద్ధం.",phalaText:"బలవంతుడైన వాడి భావాలు పెరుగుతాయి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"6:mula:F6:మూ-6",id:"F6",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"మూ-6",title:"రవి-శని పరివర్తనం అనిష్టం",ruleText:"రవి-శని పరివర్తనం మిగతా పరివర్తనాల్లా ఫలించదు; మొదట ఇచ్చి తీసేస్తుంది.",phalaText:"ఉద్యోగ/గౌరవంలో ఎదుగుదల తర్వాత విచారణలు, నష్టం సాధ్యం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"7:mula:F7:మూ-7",id:"F7",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"మూ-7",title:"పాప/శుభ — జీవ/నిర్జీవ",ruleText:"పాప గ్రహం భావంలో జీవులకు హాని, నిర్జీవాలకు లాభం. శుభం విరుద్ధం.",phalaText:"ఉదా: 4వలో పాపం — తల్లికి కష్టం, ఆస్తి/వాహనం పెరుగుదల.",autoEvaluated:false,sensitive:false),
    MehtaCombinationRule(key:"8:mula:F8:మూ-8",id:"F8",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"మూ-8",title:"పరివర్తనం భావాలను బలపరుస్తుంది",ruleText:"A రాశిలో B, B రాశిలో A అయితే ఇరువురి భావాలు బలం (రవి-శని మినహా).",phalaText:"పరివర్తన భావాల ఫలం జీవితంలో కనిపిస్తుంది.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"9:vivaha:C1:1",id:"C1",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"1",title:"కర్కాటక/వృశ్చిక/మీన లగ్నం — గురువు 3/11 నీచం",ruleText:"ఈ మూడు లగ్నాల్లో గురువు 3వ లేదా 11వలో నీచం అయితే 7వకు నీచ దృష్టి.",phalaText:"దాంపత్యం దెబ్బతింటుంది; విడాకులు/రెండవ పెళ్లి సాధ్యం. శని కలిస్తే మరింత. గురువు స్వయం/ఉచ్చం అయితే తగ్గుతుంది.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"10:vivaha:C1c:1-గ",id:"C1c",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"1-గ",title:"అదే లగ్నాలు — గురువు లగ్నం/7వ నీచం",ruleText:"గురువు లగ్నం లేదా 7వలో నీచం.",phalaText:"కలహం ఉంటుంది కాని విడాకులు తక్కువ. <10° అయితే విడాకులు ఎక్కువ.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"11:vivaha:C6:6-అ",id:"C6",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"6-అ",title:"సింహ లగ్నం — శని 6/7/8",ruleText:"సింహ లగ్నంలో శని 6,7,8 భావాల్లో.",phalaText:"మొదటి పెళ్లి నిలవదు; రెండవది కూడా సుఖంగా ఉండకపోవచ్చు. 7వలో ఒంటరిగా ఉంటే మరింత.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"12:vivaha:C7:7",id:"C7",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"7",title:"మేష లగ్నం — శుక్రుడు 2/6/7",ruleText:"మేష లగ్నంలో శుక్రుడు 2,6,7లో.",phalaText:"దాంపత్యం కష్టం; బలం/డిగ్రీల బట్టి విడాకులు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"13:vivaha:C18:18",id:"C18",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"18",title:"7వ నీచం / నీచ దృష్టి",ruleText:"7వాధిపతి నీచం లేదా 7వకు నీచ దృష్టి లేదా 7వలో నీచ గ్రహం.",phalaText:"మధుమేహం, మూత్రపిండం, ప్రోస్టేట్/గర్భాశయ సమస్యలు; దాంపత్య కష్టం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"14:vivaha:C19:19",id:"C19",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"19",title:"2-5-7 సంబంధం — ప్రేమ వివాహం",ruleText:"2,5,7 భావాలు/ఆధిపతులు బలమైన సంబంధం.",phalaText:"ప్రేమ, వివాహం ఒకే చోట. 7 బలహీనం అయితే ప్రేమ నిలవదు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"15:vivaha:C20:20",id:"C20",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"20",title:"7-12 సంబంధం — అంతర్జాతి/వెలుపలి పెళ్లి",ruleText:"7,12 బలమైన సంబంధం. ఒకే స్వామి 12లో ఉంటే ఈ ఫలం రాదు. 7వలో శని/కుజ/రాహువులో ఇద్దరు అయితే కూడా.",phalaText:"కులం/సమూహం బయట పెళ్లి సాధ్యం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"16:vivaha:C43:43",id:"C43",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"43",title:"ఉచ్చ గురువు (7వాధిపతి)పై శని దృష్టి",ruleText:"7వాధిపతి గురువు ఉచ్చంలో, శని దృష్టి.",phalaText:"ఉచ్చం తిరగబడుతుంది. <10° అయితే విడాకులు; >20° అయితే విడిపోవడం మాత్రమే.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"17:vivaha:C53:53",id:"C53",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"53",title:"7వాధిపతి గురువు నీచం 2/6/10",ruleText:"గురువు 7వాధిపతి, వృషభ/కన్య/మకరంలో నీచం.",phalaText:"దాంపత్యం కలవరం. బలం+వక్రం అయితే విడాకులు/రెండవ పెళ్లి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"18:vivaha:C69:69",id:"C69",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"69",title:"మకర లగ్నం — చంద్రుడు 9వలో కన్య",ruleText:"మకర లగ్నం, 7వాధిపతి చంద్రుడు 9వలో కన్యలో ఒంటరి.",phalaText:"రెండు పెళ్లిలు. శని కలిస్తే/చూస్తే విడాకులు రాకపోవచ్చు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"19:vivaha:C85:85",id:"C85",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"85",title:"వృషభ/తుల లగ్నం — 10వ రాశిలో కుజ+గురువు",ruleText:"వృషభ లేదా తుల లగ్నంలో మకరంలో కుజుడు+గురువు.",phalaText:"వివాహం విడాకులతో ముగుస్తుంది.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"20:dasha_ev:SYNC_M:సమ-పెళ్లి",id:"SYNC_M",folder:"dasha_ev",folderLabel:"దశా సమకాలీకరణ",no:"సమ-పెళ్లి",title:"పెళ్లి దశా కాంబినేషన్",ruleText:"1,7,12 ఆధిపతులు 2-3-4 స్థానాల్లో. రాహు/కేతువు మాత్రమే వారిని మార్చగలరు. శుక్రుడు/తులలో శని అరుదు.",phalaText:"త్రిభాగి లేదా విమ్శోత్తరిలో ఆ గ్రహాల అంతర్/ప్రత్యంతర కాలంలో పెళ్లి కాలం.",autoEvaluated:false,sensitive:false),
    MehtaCombinationRule(key:"21:santana:C14:14",id:"C14",folder:"santana",folderLabel:"సంతానం / విద్య",no:"14",title:"5వకు గురువు నీచ దృష్టి",ruleText:"5వ భావానికి గురువు నీచ దృష్టి.",phalaText:"ఉద్దేశపూర్వక గర్భస్రావం సాధ్యం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"22:santana:C51:51",id:"C51",folder:"santana",folderLabel:"సంతానం / విద్య",no:"51",title:"5వాధిపతి 6/8/12లో ఉచ్చం",ruleText:"5వాధిపతి (6/8/12 మినహా ఇతరులు) 6,8,12లో ఉచ్చం.",phalaText:"చదువులో విరామం/వైఫల్యం. పరివర్తనం ఉంటే కాపాడుతుంది.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"23:santana:C60:60",id:"C60",folder:"santana",folderLabel:"సంతానం / విద్య",no:"60",title:"సింహ లగ్నం — గురువు లగ్నంలో",ruleText:"సింహ లగ్నంలో గురువు లగ్నంలో.",phalaText:"మొదట 2-3 కూతుర్లు, తర్వాత కొడుకు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"24:udyoga:C32:32",id:"C32",folder:"udyoga",folderLabel:"ఉద్యోగం / వృత్తి",no:"32",title:"5-6 సంబంధం + శని — న్యాయం",ruleText:"5,6 ఆధిపతులు బలమైన సంబంధం, శని కూడా పాల్గొంటే.",phalaText:"న్యాయశాస్త్రం/న్యాయమూర్తి మార్గం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"25:udyoga:C33:33",id:"C33",folder:"udyoga",folderLabel:"ఉద్యోగం / వృత్తి",no:"33",title:"5-6 + 10/11 — వైద్యం",ruleText:"5-6 సంబంధం, 6వాధిపతి 10/11తో సంబంధం, శని 5/6ను చూడకపోతే.",phalaText:"వైద్య విద్య / వైద్య వృత్తి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"26:dhana:C17:17",id:"C17",folder:"dhana",folderLabel:"ధనం / వ్యాపారం",no:"17",title:"2వ భావం చాలా బలం",ruleText:"2వాధిపతి ఉచ్చం లేదా పరివర్తనం, 2వ బలం.",phalaText:"డబ్బు జాగ్రత్త అధికం; లోభం వరకు పోవచ్చు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"27:dhana:C21:21",id:"C21",folder:"dhana",folderLabel:"ధనం / వ్యాపారం",no:"21",title:"కుంభ లగ్నం — 2వాధిపతి గురువు 5వలో",ruleText:"కుంభ లగ్నం, గురువు 5వలో.",phalaText:"పెద్ద వ్యాపారి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"28:dhana:C22:22",id:"C22",folder:"dhana",folderLabel:"ధనం / వ్యాపారం",no:"22",title:"2వాధిపతి శని కన్యలో",ruleText:"2వాధిపతి శని, కన్య రాశిలో.",phalaText:"వ్యాపారంలో పెద్ద స్థాయి సాధ్యం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"29:dhana:C48:48",id:"C48",folder:"dhana",folderLabel:"ధనం / వ్యాపారం",no:"48",title:"2వాధిపతి ఉచ్చం/స్వగృహం — నీచ దృష్టి లేదు",ruleText:"2వాధిపతి ఉచ్చం లేదా స్వగృహం, నీచ దృష్టి లేదు.",phalaText:"ధనం సమృద్ధి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"30:dhana:C49:49",id:"C49",folder:"dhana",folderLabel:"ధనం / వ్యాపారం",no:"49",title:"2వాధిపతి 8వలో",ruleText:"2వాధిపతి 8వ భావంలో.",phalaText:"వంశపారంపర్య ఆస్తి రాదు లేదా నిలవదు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"31:dhana:C50:50",id:"C50",folder:"dhana",folderLabel:"ధనం / వ్యాపారం",no:"50",title:"11వ బలహీనం + 2వ బలం — అనుచిత ధనం",ruleText:"11వాధిపతి నీచం లేదా 11వలో నీచం; 2వ బలం.",phalaText:"అనుచిత మార్గంలో సంపాదన; 2వ బలం లేకపోతే నిలవదు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"32:dhana:C59:59",id:"C59",folder:"dhana",folderLabel:"ధనం / వ్యాపారం",no:"59",title:"7వకు పాపం + 2వ బలం — వ్యాపారం",ruleText:"7వ పాప గ్రహాలతో బాధితం, 2వ బలం.",phalaText:"వ్యాపారం పెరుగుతుంది (నిర్జీవ 7వ ఫలం).",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"33:arogya:C5:5",id:"C5",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"5",title:"2వాధిపతిపై శని దృష్టి — కుక్క కాటు",ruleText:"2వాధిపతికి శని దృష్టి.",phalaText:"కుక్క లేదా జంతువు కాటు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"34:arogya:C11:11",id:"C11",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"11",title:"కుజుని నీచ దృష్టి — కాలిన గాయం",ruleText:"భావానికి కుజుని నీచ దృష్టి.",phalaText:"ఆ భావ బంధువుకు కాలిన గాయం.",autoEvaluated:true,sensitive:true),
    MehtaCombinationRule(key:"35:arogya:C36:36",id:"C36",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"36",title:"1వ+7వ చాలా బలహీనం",ruleText:"1,7 రెండూ నీచ గ్రహం/నీచ దృష్టి/నీచాధిపతి.",phalaText:"ఆత్మహత్య ప్రయత్న సూచన — జాగ్రత్త, వైద్య/కుటుంబ సహాయం తీసుకోండి. ఖచ్చిత నిర్ణయం కాదు.",autoEvaluated:false,sensitive:true),
    MehtaCombinationRule(key:"36:arogya:C40:40",id:"C40",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"40",title:"రవి+బుధం జల రాశిలో + కుజ/శని",ruleText:"కర్కాటక/వృశ్చిక/మీనంలో రవి+బుధం, కుజ లేదా శని దృష్టి/సంయోగం.",phalaText:"మోకాలి కింది భాగంలో తీవ్ర వ్యాధి సాధ్యం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"37:arogya:C42:42",id:"C42",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"42",title:"6వాధిపతి 8వలో",ruleText:"6వాధిపతి 8వ భావంలో.",phalaText:"క్యాన్సర్ లాంటి తీవ్ర వ్యాధి సూచన — వైద్య పరీక్ష తప్పనిసరి, జ్యోతిషం నిర్ధారణ కాదు.",autoEvaluated:true,sensitive:true),
    MehtaCombinationRule(key:"38:arogya:C58:58",id:"C58",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"58",title:"లగ్నం నీచం / నీచ దృష్టి",ruleText:"లగ్నాధిపతి నీచం లేదా లగ్నంలో నీచం లేదా నీచ దృష్టి.",phalaText:"పక్షవాతం లాంటి నాడీ సమస్యలు సాధ్యం.",autoEvaluated:true,sensitive:true),
    MehtaCombinationRule(key:"39:arogya:C8:8+జు",id:"C8",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"8+జు",title:"గురువు+కుజ సంయుక్త దృష్టి",ruleText:"గురువు, కుజుడు ఒకే భావాన్ని చూస్తే లేదా ఎదురెదురు.",phalaText:"ఆ భావానికి అగ్ని/గాయం ఫలం.",autoEvaluated:true,sensitive:true),
    MehtaCombinationRule(key:"40:bandhu:C10:10",id:"C10",folder:"bandhu",folderLabel:"బంధువులు / కుటుంబం",no:"10",title:"సింహ లగ్నం — కుజుడు 1/10",ruleText:"సింహ లగ్నంలో కుజుడు లగ్నం లేదా 10వలో.",phalaText:"బాల్యంలోనే జన్మస్థలం వదిలి వెళ్తారు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"41:bandhu:C37:37",id:"C37",folder:"bandhu",folderLabel:"బంధువులు / కుటుంబం",no:"37",title:"శని లగ్నం/5వ లేదా దృష్టి — కుటిలత",ruleText:"శని లగ్నం లేదా 5వలో, లేదా వాటిని చూస్తే.",phalaText:"స్వార్థం/కుటిలత ఎక్కువ. ఉచ్చ శని అయితే మరింత.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"42:bandhu:C16:16",id:"C16",folder:"bandhu",folderLabel:"బంధువులు / కుటుంబం",no:"16",title:"ధనుస్సులో ఒంటరి గురువు",ruleText:"గురువు స్వగృహం ధనుస్సులో ఒంటరి.",phalaText:"ఆ భావం బలహీనం — కళ్లు/2వ సమస్యలు కూడా చూడాలి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"43:bandhu:C77:77",id:"C77",folder:"bandhu",folderLabel:"బంధువులు / కుటుంబం",no:"77",title:"లగ్నాధిపతి 12వలో",ruleText:"లగ్నాధిపతి 12వ భావంలో.",phalaText:"ఖర్చు ఎక్కువ, నిర్లక్ష్య స్వభావం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"44:santana:C75:75",id:"C75",folder:"santana",folderLabel:"సంతానం / విద్య",no:"75",title:"12-5 సంబంధం — దూర చదువు",ruleText:"12,5 ఆధిపతుల పరివర్తనం లేదా సంబంధం.",phalaText:"జన్మస్థలం దూరంగా/హాస్టల్‌లో చదువు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"45:santana:C76:76",id:"C76",folder:"santana",folderLabel:"సంతానం / విద్య",no:"76",title:"5వాధిపతి-2వ సంబంధం — స్కాలర్‌షిప్",ruleText:"5వాధిపతి 2వతో బలమైన సంబంధం.",phalaText:"చదువులో ఉపకారవేతనం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"46:dasha_ev:SYNC_C:సమ-సంతానం",id:"SYNC_C",folder:"dasha_ev",folderLabel:"దశా సమకాలీకరణ",no:"సమ-సంతానం",title:"సంతానం దశా కాంబినేషన్",ruleText:"1,5,9 ఆధిపతులు 2-3-4 స్థానాల్లో. 7-11-3 భార్య దృష్టి — 10-20% కేసులు.",phalaText:"ఆ కాలంలో గర్భం/ప్రసవం.",autoEvaluated:false,sensitive:false),
    MehtaCombinationRule(key:"47:dasha_ev:SYNC_F:సమ-విదేశం",id:"SYNC_F",folder:"dasha_ev",folderLabel:"దశా సమకాలీకరణ",no:"సమ-విదేశం",title:"విదేశ యాత్ర దశా కాంబినేషన్",ruleText:"12+4 ఆధిపతులు 2-3 స్థానాల్లో. 12 బలం 4 బలహీనం అయితే 3-4 స్థానం.",phalaText:"దేశం విడిచిన తేదీ ఆ కాలంలో.",autoEvaluated:false,sensitive:false),
    MehtaCombinationRule(key:"48:dasha_ev:SYNC_G:సమ-ప్రభుత్వం",id:"SYNC_G",folder:"dasha_ev",folderLabel:"దశా సమకాలీకరణ",no:"సమ-ప్రభుత్వం",title:"ప్రభుత్వ ఉద్యోగం",ruleText:"9+10 బలం లేదా 10+11 బలం.",phalaText:"ప్రభుత్వం/రాజకీయ స్థాయి.",autoEvaluated:false,sensitive:false),
    MehtaCombinationRule(key:"49:dasha_ev:SYNC_P:సమ-ప్రైవేట్",id:"SYNC_P",folder:"dasha_ev",folderLabel:"దశా సమకాలీకరణ",no:"సమ-ప్రైవేట్",title:"ప్రైవేట్ ఉద్యోగం",ruleText:"7+9 ఆధిపతులు, 11 కూడా.",phalaText:"ప్రైవేట్ ఉద్యోగం/ప్రమోషన్.",autoEvaluated:false,sensitive:false),
    MehtaCombinationRule(key:"50:sanyoga:SJ1:2",id:"SJ1",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"2",title:"శని + గురువు కలిస్తే ఆ స్థానం దెబ్బతింటుంది",ruleText:"గురువు మేష/సింహ/ధనుస్సులో ఉండి శని కలిస్తే లేదా నీచ దృష్టి పెడితే గురువు రెండు భావాలు దెబ్బతింటాయి. మిథున/తుల/కుంభలో శని ఉచ్చ దృష్టి అయినా కొంత కలత.",phalaText:"ఆ స్థానం + గురువు భావాలు బలహీనం. దాంపత్యం, ఆరోగ్యం, తండ్రి సూచనలు చూడాలి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"51:sanyoga:SJ2:12",id:"SJ2",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"12",title:"గురువు ఉచ్చం/స్వగృహం + శని త్రికోణం",ruleText:"గురువు ఉచ్చం లేదా స్వగృహంలో, శనికి త్రికోణంలో.",phalaText:"గురువు భావాలు నష్టం. గురువు తన భావంలో/దృష్టిలో ఉంటే ఆ ఒక్క భావం రక్షితం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"52:sanyoga:SM1:34",id:"SM1",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"34",title:"రవి + బుధుడు మీనంలో — ఆ భావం దెబ్బతింటుంది",ruleText:"మీన రాశిలో రవి+బుధం కలిస్తే ఆ భావం చాలా బలహీనం. కన్యలో కలిసి మీనాన్ని చూసినా ఇదే.",phalaText:"మీనం ఉన్న భావం నష్టం. 4/7/10లో ఉంటే ఆ భావ బంధువులకు కూడా.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"53:sanyoga:SM2:5",id:"SM2",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"5",title:"రవి + బుధుడు మేష/సింహ/ధనుస్సులో — స్వభావం తిరగడం",ruleText:"ఈ రాశుల్లో రవి ఉచ్చం, బుధం నీచం. కలిస్తే బుధం ఉచ్చం, రవి నీచం.",phalaText:"రవి భావాలు తగ్గుతాయి; బుధం భావాలు పెరుగుతాయి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"54:sanyoga:SM3:5బ",id:"SM3",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"5బ",title:"రవి + బుధుడు మిథున/తుల/కుంభలో — తిరగడం",ruleText:"ఇక్కడ బుధం ఉచ్చం, రవి నీచం. కలిస్తే రవి ఉచ్చం, బుధం నీచం.",phalaText:"రవి భావాలు పెరుగుతాయి; బుధం భావాలు తగ్గుతాయి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"55:sanyoga:S3:3",id:"S3",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"3",title:"శని నీచ దృష్టి చంద్ర/కుజ/శుక్రంపై",ruleText:"శని చంద్రుడు లేదా కుజుడు లేదా శుక్రునిపై నీచ దృష్టి/సంయోగం.",phalaText:"ఆ గ్రహం ఒక భావం దెబ్బతింటుంది.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"56:sanyoga:S31:31",id:"S31",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"31",title:"శని కర్కాటక/వృశ్చిక/మీనంలో — స్వభావాలు బలహీనం",ruleText:"శని 4,8,12 రాశుల్లో ఉంటే స్వగృహ ఫలం బాగుండదు.",phalaText:"శని స్వంత భావాల్లో ఒకటి బలహీనం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"57:sanyoga:S44:44",id:"S44",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"44",title:"శని 3వ దృష్టి మధ్య భావం బలహీనం",ruleText:"శని 3వ దృష్టికి మధ్యన ఉన్న భావం/గ్రహం బలహీనం.",phalaText:"ఆ భావం ఫలం తగ్గుతుంది.",autoEvaluated:false,sensitive:false),
    MehtaCombinationRule(key:"58:vivaha:C2b:1బ",id:"C2b",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"1బ",title:"గురువు నీచం 3/11 + శని — విడాకులు తగ్గుతాయి",ruleText:"కర్కాటక/వృశ్చిక/మీన లగ్నంలో గురువు 3/11 నీచం, శని కలిస్తే/చూస్తే.",phalaText:"దాంపత్యం కలతే తప్ప విడాకులు తక్కువ.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"59:sanyoga:C23v:23-26",id:"C23v",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"23-26",title:"శుక్రుడు కుంభ/మిథున/తులలో — ఒక భావం నష్టం",ruleText:"శుక్రుడు మిథున/తుల/కుంభలో ఉంటే శుక్రుని రెండు భావాల్లో ఒకటి దెబ్బతింటుంది.",phalaText:"2 లేదా 7 భావాల్లో ఒకటి బలహీనం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"60:sanyoga:C25b:25",id:"C25b",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"25",title:"కుజుడు మిథున/తుల/కుంభలో — ఒక భావం నష్టం",ruleText:"కుజుడు ఈ రాశుల్లో ఉంటే కుజుని రెండు భావాల్లో ఒకటి దెబ్బతింటుంది.",phalaText:"1 లేదా 8 భావం బలహీనం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"61:sanyoga:C27b:27",id:"C27b",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"27",title:"గురువు మిథున/తుల/కుంభలో — ఒక భావం నష్టం",ruleText:"గురువు ఈ రాశుల్లో ఉంటే గురువు రెండు భావాల్లో ఒకటి దెబ్బతింటుంది.",phalaText:"9 లేదా 12 భావం బలహీనం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"62:sanyoga:C67b:67",id:"C67b",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"67",title:"చంద్రుడు మేష/సింహ/ధనుస్సులో — స్వభావం బలహీనం",ruleText:"చంద్రుడు 1/5/9 రాశుల్లో ఉంటే స్వగృహ ఫలం బాగుండదు. శని కలిస్తే మరింత.",phalaText:"4వ సూచనలు బలహీనం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"63:sanyoga:C4sun:4",id:"C4sun",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"4",title:"రవి మకరంలో — కళ్లు",ruleText:"రవి మకర రాశిలో (నీచం) ఉంటే 2వ సూచనలు చూడాలి.",phalaText:"కళ్ల సమస్య / శస్త్రచికిత్స సూచన — వైద్య పరీక్ష తప్పనిసరి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"64:arogya:C55:55",id:"C55",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"55",title:"6వ భావం చాలా బలం",ruleText:"6వాధిపతి ఉచ్చం/స్వగృహం లేదా 6వ బలం.",phalaText:"శత్రువులపై గెలుపు; ఉద్యోగులు/సేవకులు లభిస్తారు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"65:bandhu:C64:64",id:"C64",folder:"bandhu",folderLabel:"బంధువులు / కుటుంబం",no:"64",title:"జల లగ్నం — శరీరం",ruleText:"లగ్నం కర్కాటక/వృశ్చిక/మీనం లేదా లగ్నాధిపతి జల రాశిలో.",phalaText:"శరీరం లావుగా ఉండే అవకాశం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"66:udyoga:C66:66",id:"C66",folder:"udyoga",folderLabel:"ఉద్యోగం / వృత్తి",no:"66",title:"కన్య లగ్నం — ఉచ్చ గురువు + శని దృష్టి",ruleText:"కన్య లగ్నం, గురువు 11వలో కర్కాటక ఉచ్చం, శని 2 నుంచి చూస్తే.",phalaText:"సైన్య/రక్షణ ఉద్యోగం సాధ్యం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"67:vivaha:C68:68",id:"C68",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"68",title:"వృశ్చిక లగ్నం — శుక్రుడు 3వలో",ruleText:"వృశ్చిక లగ్నంలో శుక్రుడు 3వ భావంలో.",phalaText:"అన్న/అక్క దాంపత్యం రెండు పెళ్లిలు సాధ్యం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"68:vivaha:C71:71",id:"C71",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"71",title:"లగ్నం నీచం — జీవిత భాగస్వామి స్వభావం",ruleText:"లగ్నంలో నీచం లేదా లగ్నాధిపతి నీచం లేదా నీచ దృష్టి.",phalaText:"భాగస్వామి స్వభావం ప్రశ్నార్థకం కావచ్చు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"69:bandhu:C74:74",id:"C74",folder:"bandhu",folderLabel:"బంధువులు / కుటుంబం",no:"74",title:"గురువు నీచం 2/4/6/8/10/12",ruleText:"గురువు ఈ భావాల్లో నీచం.",phalaText:"ఒక మేనమామ/పిన్ని వైపు సమస్య.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"70:vivaha:C81:81",id:"C81",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"81",title:"కన్య లగ్నం — గురువు లగ్నంలో",ruleText:"కన్య లగ్నంలో గురువు లగ్నంలో.",phalaText:"జీవిత భాగస్వామి పొడవు, అందం, తెల్లని వర్ణం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"71:udyoga:C82:82",id:"C82",folder:"udyoga",folderLabel:"ఉద్యోగం / వృత్తి",no:"82",title:"3వాధిపతి లగ్నంలో / లగ్నాధిపతి 3వలో",ruleText:"3-1 పరస్పర సంబంధం.",phalaText:"తండ్రి సైన్య/ఫోర్స్‌లో ఉండే అవకాశం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"72:arogya:C8:8",id:"C8",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"8",title:"కుజుడు+గురువు ఒక భావం / కలిసి దృష్టి — కాలిన గాయం",ruleText:"కుజుడు-గురువు ఒకే భావంలో లేదా ఒక భావంపై కలిసి దృష్టి. రెండూ అగ్ని గ్రహాలు.",phalaText:"ఆ భావపు శరీర భాగం/బంధువుకు కాలిన గాయం. 7వలో ఉంటే జీవిత భాగస్వామి; 4వలో తల్లి.",autoEvaluated:true,sensitive:true),
    MehtaCombinationRule(key:"73:arogya:C9:9",id:"C9",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"9",title:"రవి-కుజుడు మధ్య భావం — కాలిన గాయం",ruleText:"ఒక భావం రెండు వైపుల రవి, కుజుడు (sandwich).",phalaText:"ఆ భావపు బంధువుకు కాలిన గాయం. 3వ అయితే తమ్ముళ్లు.",autoEvaluated:true,sensitive:true),
    MehtaCombinationRule(key:"74:bandhu:C10:10",id:"C10",folder:"bandhu",folderLabel:"బంధువులు / కుటుంబం",no:"10",title:"సింహ లగ్నం — కుజుడు 1/10 — జన్మస్థలం విడువడం",ruleText:"సింహ లగ్నంలో కుజుడు లగ్నం లేదా 10వ.",phalaText:"బాల్యంలో జన్మస్థలం విడుస్తారు. 4వలో ఉంటే 35-40 తర్వాత. T-జంక్షన్ ప్రమాదం — వాహనం నష్టం, శరీరం తక్కువ.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"75:arogya:C11:11",id:"C11",folder:"arogya",folderLabel:"ఆరోగ్య సూచనలు",no:"11",title:"కుజుడు నీచ దృష్టి — కాలిన గాయం",ruleText:"భావానికి కుజుని నీచ దృష్టి (7వ దృష్టి నీచ రాశిపై).",phalaText:"ఆ భావపు వ్యక్తికి కాలిన గాయం.",autoEvaluated:true,sensitive:true),
    MehtaCombinationRule(key:"76:mula:C13:13",id:"C13",folder:"mula",folderLabel:"మూల సూత్రాలు",no:"13",title:"గురువు లగ్నం/లగ్నాధిపతిని చూస్తే — శాకాహారి",ruleText:"గురువు లగ్నంలో లేదా లగ్నం/లగ్నాధిపతిని చూస్తే, పాప గ్రహ పీడ లేకుంటే.",phalaText:"మద్యం వద్దు, శాకాహారం, సరళ స్వభావం.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"77:dhana:C15:15",id:"C15",folder:"dhana",folderLabel:"ధనం / వ్యాపారం",no:"15",title:"గురువు మకర నీచం + శని సింహ నీచం — ఎత్తు-పతనం-మళ్లీ ఎత్తు",ruleText:"గురువు 10వ రాశిలో నీచం, శని 5వ రాశిలో నీచం; 6/8/12 కాకుండా.",phalaText:"సున్నా నుంచి ఎత్తు 8-10 ఏళ్లు, తర్వాత పతనం, 4-5 ఏళ్లకు మళ్లీ లేస్తారు.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"78:sanyoga:C16:16",id:"C16",folder:"sanyoga",folderLabel:"గ్రహ సంయోగాలు",no:"16",title:"గురువు ఒంటరిగా ధనుస్సులో — భావం బలహీనం",ruleText:"గురువు ఒంటరిగా 9వ రాశి ధనుస్సులో.",phalaText:"ఆ భావం బలహీనం; గురువు కూడా బలహీనంలా.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"79:vivaha:C6b:6-ఆ",id:"C6b",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"6-ఆ",title:"కర్కాటక లగ్నం — శని 2/6/8/9 — విడాకులు",ruleText:"కర్కాటక లగ్నంలో శని 2,6,8,9 భావాల్లో (సింహ/ధనుస్సు/కుంభ/మీనం).",phalaText:"దాంపత్యం పాడు, విడాకులు, రెండో పెళ్లి. శని-గురు పరివర్తన ఉంటే తగ్గుతుంది.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"80:vivaha:C6c:6-ఇ",id:"C6c",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"6-ఇ",title:"కర్కాటక లగ్నం — శుక్రుడు లగ్నంలో ఉచ్చం",ruleText:"కర్కాటక లగ్నంలో శుక్రుడు లగ్నంలో ఉచ్చం (మీనం).",phalaText:"7వకు నీచ దృష్టి — దాంపత్యం పాడు, రెండో పెళ్లి.",autoEvaluated:true,sensitive:false),
    MehtaCombinationRule(key:"81:vivaha:C6d:6-ఈ",id:"C6d",folder:"vivaha",folderLabel:"వివాహం / దాంపత్యం",no:"6-ఈ",title:"సింహ లగ్నం — శని 3/11 ఉచ్చం",ruleText:"సింహ లగ్నంలో శని 3వ (తుల) లేదా 11వ (మిథునం) ఉచ్చం.",phalaText:"జీవిత భాగస్వామి స్వభావం ప్రశ్న, అదనపు సంబంధాలు.",autoEvaluated:true,sensitive:false),
  ];

  static PlanetPosition? _planet(AstroChartResult chart, String id) {
    final name = _alias[id] ?? id;
    for (final p in chart.planets) { if (p.name == name) return p; }
    return null;
  }
  static int _rasi(AstroChartResult c,String id)=>_planet(c,id)?.signIndex ?? -99;
  static int _houseFrom(int refSign,int sign)=>((sign-refSign+12)%12)+1;
  static int _house(AstroChartResult c,String id,int refSign)=>_houseFrom(refSign,_rasi(c,id));
  static String _lordOfSign(int s)=> switch(s%12){0||7=>'Ma',1||6=>'Ve',2||5=>'Me',3=>'Mo',4=>'Su',8||11=>'Ju',_=>'Sa'};
  static String _lordOfHouse(int refSign,int h)=>_lordOfSign((refSign+h-1)%12);
  static bool _isEx(AstroChartResult c,String id)=>(_ex[id]??const[]).contains(_rasi(c,id));
  static bool _isFall(AstroChartResult c,String id)=>(_fall[id]??const[]).contains(_rasi(c,id));
  static bool _isOwn(AstroChartResult c,String id)=>(_own[id]??const[]).contains(_rasi(c,id));
  static bool _same(AstroChartResult c,String a,String b)=>_rasi(c,a)==_rasi(c,b);
  static bool _aspect7(AstroChartResult c,String a,String b)=>((_rasi(c,b)-_rasi(c,a)+12)%12)==6;
  static bool _saAspects(AstroChartResult c,String id){final d=(_rasi(c,id)-_rasi(c,'Sa')+12)%12;return d==2||d==6||d==9;}
  static bool _strongLord(AstroChartResult c,String id)=>_isOwn(c,id)||_isEx(c,id);
  static int _moonSign(AstroChartResult c)=>_rasi(c,'Mo');

  static int _sourceStrengthScore(AstroChartResult c,String id){
    var score=0;
    if(_isEx(c,id)) score+=3;
    if(_isOwn(c,id)) score+=2;
    for(final other in const ['Su','Mo','Ma','Me','Ju','Ve','Sa']){
      if(other!=id && _exchange(c,id,other)){score+=2;break;}
    }
    return score;
  }

  static MehtaReferenceChoice referenceChoice(AstroChartResult c){
    final a=c.ascendantSignIndex, m=_moonSign(c);
    final al=_lordOfSign(a), ml=_lordOfSign(m);
    final ascore=_sourceStrengthScore(c,al), mscore=_sourceStrengthScore(c,ml);
    final as=ascore>0, ms=mscore>0;
    if(mscore>ascore){return MehtaReferenceChoice(signIndex:m,label:'చంద్ర లగ్నం',reason:'Source-strength indicators (స్వ/ఉచ్చ/పరివర్తన) పోలికలో చంద్ర లగ్నాధిపతి బలం $mscore, జన్మ లగ్నాధిపతి బలం $ascore. అందువల్ల ఈ result mappingలో చంద్ర లగ్నాన్ని referenceగా తీసుకున్నాం.',janmaStrong:as,moonStrong:ms);}
    if(ascore>mscore){return MehtaReferenceChoice(signIndex:a,label:'జన్మ లగ్నం',reason:'Source-strength indicators (స్వ/ఉచ్చ/పరివర్తన) పోలికలో జన్మ లగ్నాధిపతి బలం $ascore, చంద్ర లగ్నాధిపతి బలం $mscore. అందువల్ల జన్మ లగ్నాన్ని referenceగా తీసుకున్నాం.',janmaStrong:as,moonStrong:ms);}
    return MehtaReferenceChoice(signIndex:a,label:'జన్మ లగ్నం (Primary) + చంద్ర లగ్నం Confirmation',reason:'రెండు references source-strength indicatorsలో సమంగా ఉన్నాయి ($ascore : $mscore). Mehta registryలో ASC primary, Moon ASC confirmationగా ఉన్నందున ఇక్కడ జన్మ లగ్నాన్ని primaryగా ఉంచాం.',janmaStrong:as,moonStrong:ms);
  }

  static bool _exchange(AstroChartResult c,String a,String b){return (_own[b]??const[]).contains(_rasi(c,a))&&(_own[a]??const[]).contains(_rasi(c,b));}
  static bool _anyOtherInSign(AstroChartResult c,String id,int sign){for(final p in c.planets){if(p.name!=(_alias[id]??id)&&p.signIndex==sign)return true;}return false;}

  static bool _match(MehtaCombinationRule r,AstroChartResult c,int ref){
    final h=(String id)=>_house(c,id,ref);
    final lord=(int n)=>_lordOfHouse(ref,n);
    final lag=ref;
    final index=int.tryParse(r.key.split(':').first) ?? -1;
    bool related(String a,String b)=>h(a)==h(b)||_same(c,a,b)||_aspect7(c,a,b);
    switch(index){
      case 1:
        return const ['Su','Mo','Ma','Me','Ju','Ve'].any((x)=>_isEx(c,x)&&(_same(c,'Sa',x)||_saAspects(c,x)));
      case 2:
        return const ['Su','Mo','Ma','Me','Ju','Ve'].any((x)=>_isFall(c,x)&&(_same(c,'Sa',x)||_saAspects(c,x)));
      case 3:
        if(!_isFall(c,'Sa')) return false;
        final l=_lordOfSign(_rasi(c,'Sa')); return _isOwn(c,l)||_isEx(c,l);
      case 4: return _isEx(c,'Sa')&&_same(c,'Sa','Su');
      case 5: return _same(c,'Su','Me');
      case 6: return (_rasi(c,'Su')==9&&_rasi(c,'Sa')==4)||_exchange(c,'Su','Sa');
      case 7: return false; // structural/source principle; no single natal trigger
      case 8:
        const ids=['Su','Mo','Ma','Me','Ju','Ve','Sa'];
        for(var i=0;i<ids.length;i++){for(var j=i+1;j<ids.length;j++){if(_exchange(c,ids[i],ids[j])) return true;}}
        return false;
      case 9: return const [3,7,11].contains(lag)&&_isFall(c,'Ju')&&const [3,11].contains(h('Ju'));
      case 10:return const [3,7,11].contains(lag)&&_isFall(c,'Ju')&&const [1,7].contains(h('Ju'));
      case 11:return lag==4&&const [6,7,8].contains(h('Sa'));
      case 12:return lag==0&&const [2,6,7].contains(h('Ve'));
      case 13:return _isFall(c,lord(7));
      case 14:{final l2=lord(2),l5=lord(5),l7=lord(7);return h(l2)==5||h(l5)==2||h(l2)==7||h(l7)==2||h(l5)==7||h(l7)==5;}
      case 15:{final l7=lord(7),l12=lord(12);if(l7==l12)return h(l7)!=12;final s7=(lag+6)%12;final n=[_rasi(c,'Sa'),_rasi(c,'Ma'),_rasi(c,'Ra')].where((x)=>x==s7).length;return h(l7)==12||h(l12)==7||n>=2;}
      case 16:return lord(7)=='Ju'&&_isEx(c,'Ju')&&_saAspects(c,'Ju');
      case 17:return lord(7)=='Ju'&&_isFall(c,'Ju');
      case 18:return lag==9&&h('Mo')==9&&_rasi(c,'Mo')==5;
      case 19:return const [1,6].contains(lag)&&_rasi(c,'Ma')==9&&_rasi(c,'Ju')==9;
      case 20:return false; // timing rule evaluated in SkMehtaService
      case 21:{final fifth=(lag+4)%12,js=_rasi(c,'Ju');if(!_isFall(c,'Ju'))return false;final d=(fifth-js+12)%12;return d==4||d==6||d==8;}
      case 22:{final l=lord(5);return _isEx(c,l)&&const [6,8,12].contains(h(l));}
      case 23:return lag==4&&h('Ju')==1;
      case 24:{final l5=lord(5),l6=lord(6);final rel=h(l5)==6||h(l6)==5||_same(c,l5,l6);final sa=const [5,6].contains(h('Sa'))||_saAspects(c,l5)||_saAspects(c,l6);return rel&&sa;}
      case 25:{final l6=lord(6);return const [10,11].contains(h(l6));}
      case 26:{final l=lord(2);return _isEx(c,l)||_isOwn(c,l);}
      case 27:return lag==10&&h('Ju')==5;
      case 28:return lord(2)=='Sa'&&_rasi(c,'Sa')==5;
      case 29:{final l=lord(2);return _isEx(c,l)||_isOwn(c,l);}
      case 30:return h(lord(2))==8;
      case 31:return _isFall(c,lord(11));
      case 32:return const [6,8,12].contains(h('Sa'))||h('Ma')==7||h('Ra')==7;
      case 33:return _saAspects(c,lord(2));
      case 34:return _isFall(c,'Ma');
      case 35:return false; // sensitive source-only; no individual auto-prediction
      case 36:return _same(c,'Su','Me')&&const [3,7,11].contains(_rasi(c,'Su'));
      case 37:return h(lord(6))==8;
      case 38:return _isFall(c,lord(1));
      case 39:return _aspect7(c,'Ju','Ma')||_same(c,'Ju','Ma');
      case 40:return lag==4&&const [1,10].contains(h('Ma'));
      case 41:return const [1,5].contains(h('Sa'));
      case 42:return _rasi(c,'Ju')==8&&!_anyOtherInSign(c,'Ju',8);
      case 43:return h(lord(1))==12;
      case 44:{final l5=lord(5),l12=lord(12);return h(l5)==12||h(l12)==5||_same(c,l5,l12);}
      case 45:{final l5=lord(5),l2=lord(2);return h(l5)==2||h(l2)==5||_same(c,l5,l2);}
      case 46:case 47:case 48:case 49:return false; // period synchronization handled in dedicated Mehta timing engine
      case 50:return _same(c,'Sa','Ju')||_saAspects(c,'Ju');
      case 51:{final d=(_rasi(c,'Ju')-_rasi(c,'Sa')+12)%12;return (_isEx(c,'Ju')||_isOwn(c,'Ju'))&&(d==4||d==8);}
      case 52:return _same(c,'Su','Me')&&const [11,5].contains(_rasi(c,'Su'));
      case 53:return _same(c,'Su','Me')&&const [0,4,8].contains(_rasi(c,'Su'));
      case 54:return _same(c,'Su','Me')&&const [2,6,10].contains(_rasi(c,'Su'));
      case 55:return const ['Mo','Ma','Ve'].any((x)=>_same(c,'Sa',x)||_saAspects(c,x));
      case 56:return const [3,7,11].contains(_rasi(c,'Sa'));
      case 57:return false; // source principle needs exact target-house evaluation
      case 58:return const [3,7,11].contains(lag)&&_isFall(c,'Ju')&&const [3,11].contains(h('Ju'))&&(_same(c,'Sa','Ju')||_saAspects(c,'Ju'));
      case 59:return const [2,6,10].contains(_rasi(c,'Ve'));
      case 60:return const [2,6,10].contains(_rasi(c,'Ma'));
      case 61:return const [2,6,10].contains(_rasi(c,'Ju'));
      case 62:return const [0,4,8].contains(_rasi(c,'Mo'));
      case 63:return _rasi(c,'Su')==9;
      case 64:{final l=lord(6);return _isEx(c,l)||_isOwn(c,l);}
      case 65:return const [3,7,11].contains(lag);
      case 66:return lag==5&&h('Ju')==11&&_isEx(c,'Ju')&&_saAspects(c,'Ju');
      case 67:return lag==7&&h('Ve')==3;
      case 68:return _isFall(c,lord(1));
      case 69:return _isFall(c,'Ju')&&const [2,4,6,8,10,12].contains(h('Ju'));
      case 70:return lag==5&&h('Ju')==1;
      case 71:return h(lord(3))==1||h(lord(1))==3;
      case 72:return _same(c,'Ma','Ju')||_aspect7(c,'Ma','Ju');
      case 73:{final a=h('Su'),b=h('Ma'),d=(a-b).abs();return d==2||d==10;}
      case 74:return lag==4&&const [1,10,4].contains(h('Ma'));
      case 75:return (_fall['Ma']??const[]).contains((_rasi(c,'Ma')+6)%12);
      case 76:{final l1=lord(1);return h('Ju')==1||h(l1)==h('Ju')||_aspect7(c,'Ju',l1);}
      case 77:return _rasi(c,'Ju')==9&&_rasi(c,'Sa')==4&&!const [6,8,12].contains(h('Ju'))&&!const [6,8,12].contains(h('Sa'));
      case 78:return _rasi(c,'Ju')==8&&!_anyOtherInSign(c,'Ju',8);
      case 79:return lag==3&&const [2,6,8,9].contains(h('Sa'));
      case 80:return lag==3&&h('Ve')==1&&_isEx(c,'Ve');
      case 81:return lag==4&&_isEx(c,'Sa')&&const [3,11].contains(h('Sa'));
      default:return false;
    }
  }
  static MehtaComboTone _tone(MehtaCombinationRule r){
    const favorable={'F3','F8','C19','C20','C32','C33','C21','C22','C48','C55','C64','C66','C75','C76','C81','C82'};
    const mixed={'F1','F2','F4','F5','F6','F7','SJ2','SM2','SM3','C2b','C17','C59','C13','C15'};
    if(r.folder=='dasha_ev') return MehtaComboTone.info;
    if(favorable.contains(r.id)) return MehtaComboTone.favorable;
    if(mixed.contains(r.id)) return MehtaComboTone.mixed;
    return MehtaComboTone.caution;
  }
  static int? _affectedSign(MehtaCombinationRule r,AstroChartResult c,int ref){
    final lord=(int h)=>_lordOfHouse(ref,h);
    switch(r.id){
      case 'SJ1': case 'SJ2': case 'C27b': case 'C16': case 'C1': case 'C1c': case 'C43': case 'C53': case 'C2b': case 'C14': case 'C60': case 'C66': case 'C74': case 'C81': return _rasi(c,'Ju');
      case 'SM1': case 'SM2': case 'SM3': case 'C4sun': return _rasi(c,'Su');
      case 'S31': case 'C6': case 'C6b': case 'C6d': case 'C37': return _rasi(c,'Sa');
      case 'C23v': case 'C7': case 'C68': case 'C6c': return _rasi(c,'Ve');
      case 'C25b': case 'C9': case 'C10': case 'C11': return _rasi(c,'Ma');
      case 'C67b': case 'C69': return _rasi(c,'Mo');
      case 'C17': case 'C48': case 'C49': return _rasi(c,lord(2));
      case 'C50': return _rasi(c,lord(11));
      case 'C42': return _rasi(c,lord(6));
      case 'C58': case 'C71': case 'C77': return _rasi(c,lord(1));
      case 'C55': return _rasi(c,lord(6));
      case 'C51': return _rasi(c,lord(5));
      case 'C22': return _rasi(c,'Sa');
      case 'C21': return _rasi(c,'Ju');
      case 'C85': return 9;
      case 'S3':
        for(final p in const ['Mo','Ma','Ve']){if(_same(c,'Sa',p)||_saAspects(c,p))return _rasi(c,p);} return null;
      case 'F4': return _rasi(c,'Sa');
      case 'F5': return _rasi(c,'Su');
      case 'F1':
        for(final p in const ['Su','Mo','Ma','Me','Ju','Ve']){if(_isEx(c,p)&&(_same(c,'Sa',p)||_saAspects(c,p)))return _rasi(c,p);} return null;
      case 'F2':
        for(final p in const ['Su','Mo','Ma','Me','Ju','Ve']){if(_isFall(c,p)&&(_same(c,'Sa',p)||_saAspects(c,p)))return _rasi(c,p);} return null;
    }
    return null;
  }
  static String houseTopics(int h)=>switch(h){
    1=>'స్వయం, శరీరం, వ్యక్తిత్వం, జీవన దిశ',
    2=>'కుటుంబం, ధనం, వాక్కు, ఆహారం',
    3=>'సహోదరులు, ధైర్యం, ప్రయత్నం, కమ్యూనికేషన్',
    4=>'తల్లి, ఇల్లు, స్థిరాస్తి, విద్య, మానసిక సౌఖ్యం',
    5=>'సంతానం, విద్య, బుద్ధి, సృజనాత్మకత',
    6=>'రోగ/ఋణ/వివాద/సేవ అంశాలు',
    7=>'వివాహం, భాగస్వామ్యం, ఒప్పందాలు',
    8=>'ఆకస్మిక మార్పులు, సంయుక్త వనరులు, గూఢ అంశాలు',
    9=>'తండ్రి/గురు, భాగ్యం, ధర్మం, ఉన్నత విద్య, దీర్ఘ ప్రయాణం',
    10=>'వృత్తి, హోదా, కర్మ, ప్రజా ప్రతిష్ఠ',
    11=>'లాభాలు, కోరికల నెరవేర్పు, నెట్‌వర్క్, పెద్ద సహోదరులు',
    12=>'వ్యయం, విదేశం, నిద్ర/విముక్తి, దూర నివాసం',
    _=>'సంబంధిత భావ అంశాలు'};

  static String _resultSummary(MehtaCombinationRule r,int? h){
    const healthLike={'C18','C4sun','C5','C11','C36','C40','C42','C58','C8','C9'};
    if(r.sensitive || r.folder=='arogya' || healthLike.contains(r.id)){
      final housePart=h==null?'':' ప్రభావిత $hవ భావ అంశాలు: ${houseTopics(h)}.';
      return 'ఈ source health/safety-sensitive condition match అయింది.$housePart ఇది సంప్రదాయ జ్యోతిష్య సూచన మాత్రమే; వైద్య నిర్ధారణ లేదా ఖచ్చిత ఘటన prediction కాదు.';
    }
    final housePart=h==null?'':' ప్రభావిత $hవ భావ అంశాలు: ${houseTopics(h)}.';
    return '${r.phalaText}$housePart';
  }

  static String _logicSummary(MehtaCombinationRule r)=>switch(r.id){
    'SJ1'=>'శని–గురు సంయోగం/శని దృష్టి గురువుపై ఉన్నదా పరిశీలన.',
    'SJ2'=>'గురువు స్వ/ఉచ్చ source-strengthలో ఉండి శనితో త్రికోణ సంబంధమా పరిశీలన.',
    'SM1'=>'రవి–బుధ సంయోగం మీనం/కన్య axis source conditionలో ఉందా పరిశీలన.',
    'SM2'=>'రవి–బుధ సంయోగం మేష/సింహ/ధనుస్సు groupలో ఉందా పరిశీలన.',
    'SM3'=>'రవి–బుధ సంయోగం మిథున/తుల/కుంభ groupలో ఉందా పరిశీలన.',
    'F1'=>'ఉచ్చ source-conditionలో ఉన్న గ్రహానికి శని సంయోగం/దృష్టి ఉందా.',
    'F2'=>'నీచ source-conditionలో ఉన్న గ్రహానికి శని సంయోగం/దృష్టి ఉందా.',
    'F8'=>'రెండు గ్రహాలు పరస్పరం ఒకరి స్వరాశిలో మరొకరు ఉన్నారా (exchange).',
    _ => r.ruleText,
  };

  static List<MehtaCombinationMatch> evaluateAll(AstroChartResult chart){
    final ref=referenceChoice(chart); final moon=_moonSign(chart); final out=<MehtaCombinationMatch>[];
    for(final r in rules){
      final matched=r.autoEvaluated?_match(r,chart,ref.signIndex):false;
      final sign=matched?_affectedSign(r,chart,ref.signIndex):null;
      final jh=sign==null?0:_houseFrom(chart.ascendantSignIndex,sign);
      final mh=sign==null?0:_houseFrom(moon,sign);
      final ah=sign==null?null:_houseFrom(ref.signIndex,sign);
      out.add(MehtaCombinationMatch(rule:r,matched:matched,tone:_tone(r),logic:_logicSummary(r),sourceResult:_resultSummary(r,ah),evidence: sign==null?'Source rule condition chart dataతో పరిశీలించబడింది.':'ప్రభావిత రాశి ${signNamesTe[sign]} • జన్మలగ్నం నుంచి $jhవ భావం • చంద్రలగ్నం నుంచి $mhవ భావం.',affectedSignIndex:sign,affectedHouse:ah,janmaHouse:jh,moonHouse:mh,reference:ref));
    }
    return out;
  }
}
