import 'package:sweph/sweph.dart';
import '../models/birth_data.dart';
import 'astro_calculation_service.dart';

/// On-device, tropical Western progressions using Swiss Ephemeris Moshier.
/// Diagnostic contacts, NOT scientifically validated event predictions.
class WesternProgressionService {
  static const bodies = <String, HeavenlyBody>{
    'Sun': HeavenlyBody.SE_SUN, 'Moon': HeavenlyBody.SE_MOON,
    'Mercury': HeavenlyBody.SE_MERCURY, 'Venus': HeavenlyBody.SE_VENUS,
    'Mars': HeavenlyBody.SE_MARS, 'Jupiter': HeavenlyBody.SE_JUPITER,
    'Saturn': HeavenlyBody.SE_SATURN,
  };
  static double norm(double v) => (v % 360 + 360) % 360;
  static double distance(double a, double b) => ((a-b+540)%360)-180;
  static double julian(DateTime dt) {
    final d=dt.toUtc();
    return Sweph.swe_julday(d.year,d.month,d.day,
      d.hour+d.minute/60+d.second/3600+d.millisecond/3600000,
      CalendarType.SE_GREG_CAL);
  }
  static Map<String,double> positions(double jd) {
    final result=<String,double>{};
    for (final e in bodies.entries) {
      result[e.key]=norm(Sweph.swe_calc_ut(jd,e.value,SwephFlag.SEFLG_MOSEPH).longitude);
    }
    return result;
  }
  static List<String> contacts(Map<String,double> sources,Map<String,double> targets,
      double orb,String method,{bool skipSelf=false}) {
    const aspects={'Conjunction':0.0,'Sextile':60.0,'Square':90.0,'Trine':120.0,'Opposition':180.0};
    final found=<({double error,String label})>[];
    for (final s in sources.entries) {
      for (final t in targets.entries) {
        if (skipSelf && s.key==t.key) continue;
        final arc=distance(s.value,t.value).abs();
        for(final a in aspects.entries) {
          final error=(arc-a.value).abs();
          final allowed=method=='Secondary' && s.key=='Moon' ? 1.0 : orb;
          if(error<=allowed) found.add((error:error,label:'${s.key} → ${t.key}: ${a.key} (orb ${error.toStringAsFixed(3)}°)'));
        }
      }
    }
    found.sort((a,b)=>a.error.compareTo(b.error));
    return found.take(35).map((e)=>e.label).toList();
  }
  static Future<WesternProgressionResult> calculate(BirthData birth,DateTime eventDate) async {
    await AstroCalculationService.initialize();
    if (!AstroCalculationService.isInitialized) throw StateError('Swiss Ephemeris initialize కాలేదు');
    final born=birth.utcDateTime;
    final eventUtc=DateTime.utc(eventDate.year,eventDate.month,eventDate.day,12);
    final age=eventUtc.difference(born).inMinutes/(365.2421904*1440);
    if(age<0) throw ArgumentError('జననానికి ముందు తేదీ ఎంచుకోరాదు');
    final natalJd=julian(born);
    final progressedJd=natalJd+age; // one day after birth per year of life
    final natal=positions(natalJd);
    final progressed=positions(progressedJd);
    final natalHouses=Sweph.swe_houses_ex(natalJd,SwephFlag.SEFLG_MOSEPH,
      birth.latitude,birth.longitude,Hsys.P);
    final asc=norm(natalHouses.ascmc[AscmcIndex.SE_ASC.index]);
    final mc=norm(natalHouses.ascmc[AscmcIndex.SE_MC.index]);
    final targets=<String,double>{...natal,'ASC':asc,'DESC':norm(asc+180),'MC':mc,'IC':norm(mc+180)};
    final sec={for(final n in ['Sun','Moon','Mercury','Venus','Mars']) n:progressed[n]!};
    final secondary=contacts(sec,targets,0.5,'Secondary',skipSelf:true);
    final arc=norm(progressed['Sun']!-natal['Sun']!);
    final directed=<String,double>{for(final e in natal.entries)e.key:norm(e.value+arc),
      'ASC':norm(asc+arc),'MC':norm(mc+arc)};
    final solar=contacts(directed,targets,0.5,'Solar Arc');
    // Naibod axes need a separate sidereal-time/obliquity model; never
    // misrepresent a solar-arc angle as a Naibod direction.
    return WesternProgressionResult(age,arc,progressed['Moon']!,secondary,solar);
  }
}
class WesternProgressionResult {
  final double ageYears,solarArc,progressedMoon;
  final List<String> secondaryContacts,solarArcContacts;
  const WesternProgressionResult(this.ageYears,this.solarArc,this.progressedMoon,
    this.secondaryContacts,this.solarArcContacts);
}
