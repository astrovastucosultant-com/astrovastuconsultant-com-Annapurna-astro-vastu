import 'package:sweph/sweph.dart';

import '../models/birth_data.dart';
import 'astro_calculation_service.dart';

/// Tropical Western secondary progressions (1 day after birth = 1 year
/// of life) and solar-arc directions. Uses the on-device Swiss Ephemeris
/// Moshier engine; no remote service, Python runtime, or sidereal offsets.
/// Contacts are historical/interpretive chart evidence, not predictions.
class WesternProgressionService {
  static const bodies = <String, HeavenlyBody>{
    'Sun': HeavenlyBody.SE_SUN,
    'Moon': HeavenlyBody.SE_MOON,
    'Mercury': HeavenlyBody.SE_MERCURY,
    'Venus': HeavenlyBody.SE_VENUS,
    'Mars': HeavenlyBody.SE_MARS,
    'Jupiter': HeavenlyBody.SE_JUPITER,
    'Saturn': HeavenlyBody.SE_SATURN,
  };
  static const aspects = <String, double>{
    'Conjunction': 0.0,
    'Sextile': 60.0,
    'Square': 90.0,
    'Trine': 120.0,
    'Opposition': 180.0,
  };
  static const double daysPerYear = 365.2421904;

  static double norm(double value) => (value % 360.0 + 360.0) % 360.0;
  static double distance(double a, double b) => (a - b + 540.0) % 360.0 - 180.0;

  static double julian(DateTime date) {
    final utc = date.toUtc();
    return Sweph.swe_julday(
      utc.year, utc.month, utc.day,
      utc.hour + utc.minute / 60.0 + utc.second / 3600.0 +
          utc.millisecond / 3600000.0,
      CalendarType.SE_GREG_CAL,
    );
  }

  static Map<String, double> positions(double jd) {
    final result = <String, double>{};
    for (final entry in bodies.entries) {
      result[entry.key] = norm(Sweph.swe_calc_ut(
        jd, entry.value, SwephFlag.SEFLG_MOSEPH,
      ).longitude);
    }
    return result;
  }

  /// Only applies a configured angular orb; an aspect doesn't imply an event.
  static List<String> contacts(
    Map<String, double> sources,
    Map<String, double> targets,
    double orb,
    String method, {
    bool skipSelf = false,
  }) {
    final found = <({double error, String label})>[];
    for (final source in sources.entries) {
      for (final target in targets.entries) {
        if (skipSelf && source.key == target.key) continue;
        final separation = distance(source.value, target.value).abs();
        for (final aspect in aspects.entries) {
          final error = (separation - aspect.value).abs();
          if (error <= orb) {
            found.add((
              error: error,
              label: '${source.key} → ${target.key}: ${aspect.key} '
                  '(orb ${error.toStringAsFixed(3)}°)',
            ));
          }
        }
      }
    }
    found.sort((a, b) => a.error.compareTo(b.error));
    return found.take(40).map((e) => e.label).toList();
  }

  static Future<void> _ensureReady() async {
    await AstroCalculationService.initialize();
    if (!AstroCalculationService.isInitialized) {
      throw StateError('Swiss Ephemeris initialize కాలేదు: '
          '${AstroCalculationService.initError ?? 'unknown'}');
    }
  }

  static DateTime _eventAtNoon(DateTime date) =>
      DateTime.utc(date.year, date.month, date.day, 12);

  static double _ageYears(BirthData birth, DateTime eventUtc) =>
      eventUtc.difference(birth.utcDateTime).inMilliseconds /
          (daysPerYear * Duration.millisecondsPerDay);

  static Map<String, double> _progressed(double natalJd, double age) =>
      positions(natalJd + age);

  static Map<String, double> _solarDirected(
      Map<String, double> natal, Map<String, double> progressed,
      double asc, double mc) {
    final arc = norm(progressed['Sun']! - natal['Sun']!);
    return <String, double>{
      for (final entry in natal.entries) entry.key: norm(entry.value + arc),
      'ASC': norm(asc + arc),
      'MC': norm(mc + arc),
    };
  }

  /// Computes natal targets once and keeps unrelated systems' ayanamsas
  /// unchanged. Swiss Ephemeris house angles are tropical Placidus.
  static _NatalReference _natal(BirthData birth) {
    final jd = julian(birth.utcDateTime);
    final natal = positions(jd);
    final houses = Sweph.swe_houses_ex(
      jd, SwephFlag.SEFLG_MOSEPH, birth.latitude, birth.longitude, Hsys.P,
    );
    final asc = norm(houses.ascmc[AscmcIndex.SE_ASC.index]);
    final mc = norm(houses.ascmc[AscmcIndex.SE_MC.index]);
    final targets = <String, double>{
      ...natal,
      'ASC': asc,
      'DESC': norm(asc + 180),
      'MC': mc,
      'IC': norm(mc + 180),
    };
    return _NatalReference(jd, natal, targets, asc, mc);
  }

  static Future<WesternProgressionResult> calculate(
      BirthData birth, DateTime eventDate, {double orb = 0.5}) async {
    await _ensureReady();
    if (orb <= 0 || orb > 5) throw ArgumentError('Orb must be 0–5 degrees');
    final event = _eventAtNoon(eventDate);
    final age = _ageYears(birth, event);
    if (age < 0) throw ArgumentError('జననానికి ముందు తేదీ ఎంచుకోరాదు');
    final ref = _natal(birth);
    final prog = _progressed(ref.jd, age);
    final secondary = <String, double>{
      for (final name in <String>['Sun', 'Moon', 'Mercury', 'Venus', 'Mars'])
        name: prog[name]!,
    };
    final arc = norm(prog['Sun']! - ref.planets['Sun']!);
    final directed = _solarDirected(ref.planets, prog, ref.asc, ref.mc);
    return WesternProgressionResult(
      age,
      arc,
      prog['Moon']!,
      contacts(secondary, ref.targets, orb, 'Secondary', skipSelf: true),
      contacts(directed, ref.targets, orb, 'Solar Arc', skipSelf: true),
    );
  }

  /// Locates *exact angular aspect dates*, not guaranteed event dates.
  /// Checks a +/- six-month interval around the selected event. Roots are
  /// refined with bisection so no invented exact date is returned.
  static Future<List<WesternExactContact>> exactContacts(
    BirthData birth,
    DateTime eventDate, {
    int windowDays = 180,
    int maxResults = 24,
  }) async {
    await _ensureReady();
    if (windowDays < 1 || windowDays > 365) {
      throw ArgumentError('Invalid search window');
    }
    final center = _eventAtNoon(eventDate);
    if (_ageYears(birth, center) < 0) {
      throw ArgumentError('జననానికి ముందు తేదీ ఎంచుకోరాదు');
    }
    final ref = _natal(birth);
    final start = center.subtract(Duration(days: windowDays));
    final end = center.add(Duration(days: windowDays));
    final first = start.isBefore(birth.utcDateTime)
        ? birth.utcDateTime.add(const Duration(minutes: 1))
        : start;
    if (!first.isBefore(end)) return <WesternExactContact>[];
    final samples = <_ProgressionSample>[];
    var moment = first;
    while (true) {
      final sample = _sample(ref, birth, moment);
      samples.add(sample);
      if (!moment.isBefore(end)) break;
      final next = moment.add(const Duration(days: 10));
      moment = next.isAfter(end) ? end : next;
      if (samples.length % 8 == 0) {
        await Future<void>.delayed(Duration.zero);
      }
    }
    final found = <WesternExactContact>[];
    for (final method in <String>['Secondary', 'Solar Arc']) {
      final names = method == 'Secondary'
          ? <String>['Sun', 'Moon', 'Mercury', 'Venus', 'Mars']
          : <String>[...ref.planets.keys, 'ASC', 'MC'];
      for (final source in names) {
        for (final target in ref.targets.entries) {
          if (source == target.key) continue;
          for (final aspect in aspects.entries) {
            final sides = aspect.value == 0 || aspect.value == 180
                ? <double>[aspect.value]
                : <double>[aspect.value, -aspect.value];
            for (final side in sides) {
              for (var index = 0; index < samples.length - 1; index++) {
                final left = samples[index];
                final right = samples[index + 1];
                final before = _residual(left, method, source, target.value, side);
                final after = _residual(right, method, source, target.value, side);
                if ((before > 0 && after > 0) ||
                    (before < 0 && after < 0)) continue;
                // Guard against an angular-wrap discontinuity, not a crossing.
                if (before.abs() > 30 || after.abs() > 30) continue;
                var low = left.time;
                var high = right.time;
                var signBefore = before;
                for (var step = 0; step < 18; step++) {
                  final mid = DateTime.fromMillisecondsSinceEpoch(
                    (low.millisecondsSinceEpoch + high.millisecondsSinceEpoch) ~/ 2,
                    isUtc: true,
                  );
                  final residual = _residual(
                    _sample(ref, birth, mid),
                    method, source, target.value, side,
                  );
                  if ((signBefore <= 0 && residual <= 0) ||
                      (signBefore >= 0 && residual >= 0)) {
                    low = mid;
                    signBefore = residual;
                  } else {
                    high = mid;
                  }
                }
                final exact = DateTime.fromMillisecondsSinceEpoch(
                  (low.millisecondsSinceEpoch + high.millisecondsSinceEpoch) ~/ 2,
                  isUtc: true,
                );
                // Different oriented branches can be equivalent at 180 degrees.
                if (!found.any((e) => e.method == method &&
                    e.source == source && e.target == target.key &&
                    e.aspect == aspect.key &&
                    (e.date.difference(exact).inHours).abs() < 36)) {
                  found.add(WesternExactContact(
                    method, source, target.key, aspect.key, exact,
                  ));
                }
              }
            }
          }
        }
      }
    }
    found.sort((a, b) {
      final ad = a.date.difference(center).inMilliseconds.abs();
      final bd = b.date.difference(center).inMilliseconds.abs();
      return ad.compareTo(bd);
    });
    return found.take(maxResults).toList(growable: false);
  }

  static _ProgressionSample _sample(
      _NatalReference ref, BirthData birth, DateTime time) {
    final progressed = _progressed(ref.jd, _ageYears(birth, time));
    return _ProgressionSample(
      time,
      <String, double>{
        for (final name in <String>['Sun', 'Moon', 'Mercury', 'Venus', 'Mars'])
          name: progressed[name]!,
      },
      _solarDirected(ref.planets, progressed, ref.asc, ref.mc),
    );
  }

  static double _residual(_ProgressionSample sample, String method,
      String source, double targetLongitude, double aspectAngle) {
    final longitude = method == 'Secondary'
        ? sample.secondary[source]!
        : sample.solarArc[source]!;
    return distance(longitude, norm(targetLongitude + aspectAngle));
  }
}

class WesternProgressionResult {
  final double ageYears;
  final double solarArc;
  final double progressedMoon;
  final List<String> secondaryContacts;
  final List<String> solarArcContacts;
  const WesternProgressionResult(
    this.ageYears, this.solarArc, this.progressedMoon,
    this.secondaryContacts, this.solarArcContacts,
  );
}

class WesternExactContact {
  final String method;
  final String source;
  final String target;
  final String aspect;
  final DateTime date;
  const WesternExactContact(
    this.method, this.source, this.target, this.aspect, this.date,
  );
}

class _NatalReference {
  final double jd;
  final Map<String, double> planets;
  final Map<String, double> targets;
  final double asc;
  final double mc;
  const _NatalReference(
    this.jd, this.planets, this.targets, this.asc, this.mc,
  );
}

class _ProgressionSample {
  final DateTime time;
  final Map<String, double> secondary;
  final Map<String, double> solarArc;
  const _ProgressionSample(this.time, this.secondary, this.solarArc);
}
