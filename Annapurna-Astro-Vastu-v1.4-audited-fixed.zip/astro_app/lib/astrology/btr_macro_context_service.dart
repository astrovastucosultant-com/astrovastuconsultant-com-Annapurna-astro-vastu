import 'astro_models.dart';

/// BNN Jupiter 12-year blocks, annual minor progression and BCP yearly house.
/// All three are **context**, NOT a way to distinguish neighbouring seconds.
/// Profiles follow user-provided MacroToSeconds rulebook N12-01/N12-02/BCP-01.
/// This is the sign-level fixed-block variant only. Not a degree-balance variant.
class BtrMacroContext {
  final int completedAge;
  final int jupiterNatalSignIndex; // zero-based index, Aries = 0
  final int natalAscSignIndex; // required for event-house alignment
  final int jupiterMajorSignIndex;
  final int jupiterMinorSignIndex;
  final int bcpHouse; // 1..12

  const BtrMacroContext({
    required this.completedAge,
    required this.jupiterNatalSignIndex,
    required this.natalAscSignIndex,
    required this.jupiterMajorSignIndex,
    required this.jupiterMinorSignIndex,
    required this.bcpHouse,
  });

  static const List<String> signs = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  String get display => 'పూర్తి వయస్సు $completedAge • '
      'గురు Major: ${signs[jupiterMajorSignIndex]} (N12-01) • '
      'Minor: ${signs[jupiterMinorSignIndex]} (N12-02) • '
      'BCP: $bcpHouseవ భావం (BCP-01)';
}

class BtrMacroContextService {
  static int completedYears(DateTime birth, DateTime event) {
    final years = event.year - birth.year;
    final beforeBirthday = event.month < birth.month ||
        (event.month == birth.month && event.day < birth.day);
    return years - (beforeBirthday ? 1 : 0);
  }

  /// A chart must come from the app's current Swiss Ephemeris/ayanamsha setup.
  /// Do not use event clock time to manufacture an exact birthday year.
  static BtrMacroContext compute({
    required AstroChartResult natalChart,
    required DateTime birthDate,
    required DateTime eventDate,
  }) {
    final jupiter = natalChart.planets.firstWhere(
      (p) => p.name == 'Jupiter',
      orElse: () => throw StateError('Jupiter not found in natal chart'),
    );
    final age = completedYears(birthDate, eventDate);
    if (age < 0) throw ArgumentError('Event precedes birth date');
    final natalSign = jupiter.signIndex;
    return BtrMacroContext(
      completedAge: age,
      jupiterNatalSignIndex: natalSign,
      natalAscSignIndex: natalChart.ascendantSignIndex,
      jupiterMajorSignIndex: (natalSign + age ~/ 12) % 12,
      jupiterMinorSignIndex: (natalSign + age) % 12,
      bcpHouse: 1 + (age % 12),
    );
  }
}
