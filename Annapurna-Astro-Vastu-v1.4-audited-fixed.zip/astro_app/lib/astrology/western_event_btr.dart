import 'western_ephemeris_service.dart';
import '../models/birth_data.dart';

class WesternPastEvent {
  final String type;
  final DateTime time;
  const WesternPastEvent(this.type,this.time);
}

class WesternBtrCandidate {
  final DateTime birthTime;
  final double evidenceScore;
  final List<double> eventScores;
  const WesternBtrCandidate(this.birthTime,this.evidenceScore,this.eventScores);
}

/// Exploratory multiple-event ranking using Solar Arc angular contacts.
/// Deliberately NOT a validated birth-time rectification or event predictor.
class WesternEventBtr {
  static const _aspects = <int>[0,60,90,120,180];
  static double _eventScore(WesternCalculation c, String eventType) {
    // Evaluate only directed planetary contacts to natal ASC and MC.
    // Avoid counting self-contacts and duplicated aspects as independent proof.
    final contacts=c.contacts['Solar Arc'] ?? const <WesternContact>[];
    final relevant=contacts.where((x)=>
        (x.natal=='Asc'||x.natal=='MC') && x.moving!='Asc' && x.moving!='MC' &&
        _aspects.contains(x.aspect)).toList();
    if(relevant.isEmpty) return 0;
    relevant.sort((a,b)=>a.orb.compareTo(b.orb));
    return (1.0-relevant.first.orb).clamp(0.0,1.0);
  }

  static Future<List<WesternBtrCandidate>> search(BirthData birth,
      List<WesternPastEvent> events,{int halfWindowMinutes=30,
        int stepMinutes=5}) async {
    if(events.length<3) throw ArgumentError('At least three events required');
    if(events.map((x)=>x.time.year.toString()+'-${x.time.month}-${x.time.day}')
        .toSet().length<3) throw ArgumentError('Events on 3 distinct dates required');
    if(halfWindowMinutes<0 || halfWindowMinutes>720 || stepMinutes<1 || stepMinutes>60)
      throw ArgumentError('Invalid scan window');
    final out=<WesternBtrCandidate>[];
    for(var offset=-halfWindowMinutes;offset<=halfWindowMinutes;offset+=stepMinutes){
      final sample=birth.copyWith(localDateTime:birth.localDateTime.add(Duration(minutes:offset)));
      final scores=<double>[];
      for(final event in events){
        final calc=await WesternEphemerisService.calculate(sample,event.time,maxOrb:1);
        scores.add(_eventScore(calc,event.type));
      }
      out.add(WesternBtrCandidate(sample.localDateTime,
        scores.reduce((a,b)=>a+b)/scores.length,scores));
    }
    out.sort((a,b)=>b.evidenceScore.compareTo(a.evidenceScore));
    return out;
  }
}
