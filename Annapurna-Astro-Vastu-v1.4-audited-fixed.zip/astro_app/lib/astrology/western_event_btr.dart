import 'western_event_rules.dart';
import 'western_btr_decision.dart';
import 'western_ephemeris_service.dart';
import '../models/birth_data.dart';

class WesternPastEvent {
  final String type;
  final DateTime time;
  /// True when only the calendar day is known (e.g. marriage).
  /// In that case the stored clock is ignored by the evaluation routine.
  final bool dateOnly;
  const WesternPastEvent(this.type,this.time,{this.dateOnly=false});

  /// Samples the entire civil day at a configurable resolution, without
  /// inventing an exact event time. The endpoint (next midnight) is excluded.
  /// Even minute sampling is a grid approximation, not continuous optimization.
  List<DateTime> evaluationTimesAt({int stepMinutes = 60}) {
    if (stepMinutes < 1 || stepMinutes > 1440 || 1440 % stepMinutes != 0) {
      throw ArgumentError.value(stepMinutes, 'stepMinutes',
          'Must be a divisor of 1440 between 1 and 1440');
    }
    if (!dateOnly) return [time];
    final start = DateTime(time.year, time.month, time.day);
    return [for (var minute = 0; minute < 1440; minute += stepMinutes)
      start.add(Duration(minutes: minute))];
  }

  /// Hourly default: 24 evenly spaced samples rather than only 3.
  List<DateTime> get evaluationTimes => evaluationTimesAt();
}

class WesternBtrCandidate {
  final DateTime birthTime;
  final double evidenceScore;
  final List<double> eventScores;
  final List<Map<String,double>> methodScores;
  final int supportedEventCount;
  /// Explicit abstention decision; not a calibrated predictive probability.
  WesternBtrDecision get decision => WesternBtrDecisionEngine.assess(methodScores);
  const WesternBtrCandidate(this.birthTime,this.evidenceScore,this.eventScores,
      {this.methodScores=const [],this.supportedEventCount=0});
}

/// Exploratory multiple-event ranking using several correlated angular-contact methods.
/// Deliberately NOT a validated birth-time rectification or event predictor.
class WesternEventBtr {
  static const _aspects = <int>[0,60,90,120,180];
  static const _methods = <String>[
    'Solar Arc', 'Secondary', 'Tertiary-I', 'Minor',
    'Naibod', '1° Symbolic', 'Converse Secondary'
  ];
  static Map<String,double> _eventEvidence(WesternCalculation c, String eventType) {
    final result=<String,double>{};
    for(final method in _methods) {
      final contacts=c.contacts[method] ?? const <WesternContact>[];
      final relevant=contacts.where((x)=>
        WesternEventRuleBook.matchesAngularContact(
            eventType:eventType,moving:x.moving,natal:x.natal) &&
        _aspects.contains(x.aspect)).toList();
      if(relevant.isEmpty) { result[method]=0; continue; }
      relevant.sort((a,b)=>a.orb.compareTo(b.orb));
      result[method]=(1.0-relevant.first.orb).clamp(0.0,1.0);
    }
    return result;
  }

  /// Preserve date-only uncertainty instead of silently inventing midnight.
  /// Taking the strongest sampled contact is optimistic and must be labelled
  /// exploratory; an hourly grid can miss contacts between samples.
  static Future<Map<String,double>> _evidenceForEvent(
      BirthData birth, WesternPastEvent event) async {
    final strongest=<String,double>{};
    for(final instant in event.evaluationTimes) {
      final calc=await WesternEphemerisService.calculate(
          birth,instant,maxOrb:1);
      final scores=_eventEvidence(calc,event.type);
      for(final entry in scores.entries) {
        if(entry.value>(strongest[entry.key]??0)) {
          strongest[entry.key]=entry.value;
        }
      }
    }
    return strongest;
  }

  /// Heuristic method agreement, not statistical independence or accuracy.
  static double _aggregate(Map<String,double> scores) {
    final bestByFamily=<String,double>{};
    for(final entry in scores.entries) {
      final family=WesternBtrDecisionEngine.familyOf(entry.key);
      if(family=='unknown') continue;
      if(entry.value>(bestByFamily[family]??0)) bestByFamily[family]=entry.value;
    }
    final supported=bestByFamily.values.where((v)=>v>0).toList()..sort((a,b)=>b.compareTo(a));
    if(supported.length<2) return 0;
    final top=supported.take(3).toList();
    return (top.reduce((a,b)=>a+b)/top.length).clamp(0.0,1.0);
  }

  /// Two-pass exploratory refinement: coarse minute scan followed by a
  /// bounded seconds scan around the strongest coarse candidates. This does
  /// NOT imply birth-time precision to the second; it only refines the grid.
  static Future<List<WesternBtrCandidate>> refineSeconds(
      BirthData birth, List<WesternPastEvent> events, {
      int halfWindowMinutes=30, int topCandidates=3,
      int halfWindowSeconds=60, int stepSeconds=10,
  }) async {
    if (events.length<3) throw ArgumentError('At least three events required');
    if (halfWindowMinutes<0 || halfWindowMinutes>720 ||
        events.any((e)=>WesternEventRuleBook.find(e.type)==null) ||
        events.map((e)=>'${e.time.year}-${e.time.month}-${e.time.day}').toSet().length<3) {
      throw ArgumentError('Invalid event set or scan window');
    }
    if (topCandidates<1 || topCandidates>10 ||
        halfWindowSeconds<0 || halfWindowSeconds>120 ||
        stepSeconds<1 || stepSeconds>60) {
      throw ArgumentError('Invalid seconds refinement parameters');
    }
    final coarse=await search(birth,events,
        halfWindowMinutes:halfWindowMinutes,stepMinutes:1);
    final output=<WesternBtrCandidate>[];
    final seen=<int>{};
    for (final candidate in coarse.take(topCandidates)) {
      for(var seconds=-halfWindowSeconds;
          seconds<=halfWindowSeconds;seconds+=stepSeconds) {
        final date=candidate.birthTime.add(Duration(seconds:seconds));
        if(!seen.add(date.microsecondsSinceEpoch)) continue;
        final shifted=birth.copyWith(localDateTime:date);
        final scores=<double>[];
        final methodScores=<Map<String,double>>[];
        for(final event in events) {
          final evidence=await _evidenceForEvent(shifted,event);
          methodScores.add(evidence);
          scores.add(_aggregate(evidence));
        }
        output.add(WesternBtrCandidate(date,
            scores.reduce((a,b)=>a+b)/scores.length,scores,
            methodScores:methodScores,
            supportedEventCount:scores.where((v)=>v>0).length));
      }
    }
    output.sort((a,b) {
      final n=b.supportedEventCount.compareTo(a.supportedEventCount);
      return n!=0?n:b.evidenceScore.compareTo(a.evidenceScore);
    });
    return output;
  }

  static Future<List<WesternBtrCandidate>> search(BirthData birth,
      List<WesternPastEvent> events,{int halfWindowMinutes=30,
        int stepMinutes=1}) async {
    if(events.length<3) throw ArgumentError('At least three events required');
    if(events.any((e)=>WesternEventRuleBook.find(e.type)==null)) {
      throw ArgumentError('Unknown event type; no matching Western event profile');
    }
    if(events.map((x)=>x.time.year.toString()+'-${x.time.month}-${x.time.day}')
        .toSet().length<3) throw ArgumentError('Events on 3 distinct dates required');
    if(halfWindowMinutes<0 || halfWindowMinutes>720 || stepMinutes<1 || stepMinutes>60)
      throw ArgumentError('Invalid scan window');
    final out=<WesternBtrCandidate>[];
    for(var offset=-halfWindowMinutes;offset<=halfWindowMinutes;offset+=stepMinutes){
      final sample=birth.copyWith(localDateTime:birth.localDateTime.add(Duration(minutes:offset)));
      final scores=<double>[];
      final methodScores=<Map<String,double>>[];
      for(final event in events){
        final evidence=await _evidenceForEvent(sample,event);
        methodScores.add(evidence);
        scores.add(_aggregate(evidence));
      }
      out.add(WesternBtrCandidate(sample.localDateTime,
        scores.reduce((a,b)=>a+b)/scores.length,scores,
        methodScores:methodScores,
        supportedEventCount:scores.where((v)=>v>0).length));
    }
    out.sort((a,b){
      final count=b.supportedEventCount.compareTo(a.supportedEventCount);
      return count!=0 ? count : b.evidenceScore.compareTo(a.evidenceScore);
    });
    return out;
  }
}
