# Build130 — GitHub APK workflow source update (v1.4.130+130)

Base: Build129 SK Mehta + Nadi BTR source.

## Changes
- `.github/workflows/build-android-apk.yml`: GitHub Actions now runs on changes in `assets/**`, `test/**`, `pubspec.lock`, and `analysis_options.yaml`, as well as original `lib/**`, `android/**`, `pubspec.yaml` and the workflow file. A rulebook data-only update therefore requests a fresh build.
- `pubspec.yaml`: version `1.4.130+130`.
- Added this release note. All existing 206 + 85 Mehta catalog entries and 46 BTR catalog rules, source attribution, UI drill-down, Mehta scoring and historical BTR logic are unchanged from Build129.
- The full source archive contains the Flutter project root files at ZIP root, including hidden `.github` folder, to reduce a mistaken nested `astro_app/` upload.

## Verification
- ZIP integrity, source tree, JSON counts/IDs, source file preservation and workflow trigger paths checked locally.
- Flutter/Dart SDK unavailable in this container. Flutter analyze, flutter test and APK build NOT verified. This is a source ZIP, not an installable APK.

## Correct GitHub upload
GitHub's Add file > Upload files does NOT unpack a ZIP. Unzip locally, upload the extracted project files/folders to the existing repository root, then commit. Ensure `.github/workflows/build-android-apk.yml` is also committed and `lib/`, `assets/`, `android/`, and `pubspec.yaml` remain in root. Afterwards inspect Actions > Build Android APK > latest run.

## Notes
Rule Match Index is not a scientifically calibrated probability of accurate birth time. Do not assume the new progression context alone can determine a birth second.
