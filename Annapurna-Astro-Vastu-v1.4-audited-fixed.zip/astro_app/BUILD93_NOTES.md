# Build93 — D20 Mahavidya / Upasana UI Polish

- Preserves all Build92 engines and rules.
- D20 result cards now auto-expand; no ellipsis/max-line truncation.
- Primary deity, secondary deity and full Mahavidya correspondence remain visible on the card.
- D20 cards use chevron affordance; tap opens complete Result → Rule/Source → Guidance flow.
- User-facing text explicitly labels Mahavidya mapping as later Jyotisha/Tantric correspondence, not a classical BPHS prescription.
- Formal initiation-based Tantra is not prescribed by the app; only general devotional support is displayed.
