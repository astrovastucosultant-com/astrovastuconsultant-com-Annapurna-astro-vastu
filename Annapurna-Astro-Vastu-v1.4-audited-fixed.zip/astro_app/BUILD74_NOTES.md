# Build 74 — D10 Career Report Consolidation (08 Oct 2026)

Source: Build73 v1.4.73. No chart mathematics or supplied source rules changed.

- D10 header displays Saturn Gocharastha as Business/Self employment, Agocharastha as Service/Job, or Mixed when unproven; shows D1/D9/D10 separately.
- Business List and Job List expand separately, derived from the existing final D10 profession family engine. Professions are translated into corresponding business/job *forms*, **not** new astrology predictions. D10 compatibility numbers are evidence coverage, never probability.
- Rise, Fall and Middle rows expand by year; tapping a year reveals actual source-computed Vimshottari MD/AD date intervals, planets, reasons and rule IDs. Middle contains only `career_change` and `transfer`; gaps are not labeled neutral.
- Yoga list merged into a single expandable section, matched conditions visible; other rules preserved inside existing D10 audit/detail drawers.
- Old long list of cards moved into optional collapsed Detailed D10 section; D24 and other vargas unchanged.
- No synthetic sample year, profession, or historical event is inserted.

## Verification still needed

The runtime container does not have Flutter/Dart SDK. Compile and widget tests must run in Flutter/Android build workflow. In particular, test Telugu font shaping, narrow 320px screen, and year-sheet scrolling after installing the new APK.
