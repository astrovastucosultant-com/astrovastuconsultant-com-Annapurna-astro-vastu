# Build85 — Health Problem → Rule → Remedy UI

- Preserves Build84 health logic and all prior features.
- Main health problem list now shows problem/body-region + Final Astrology Evidence %.
- Tap problem → detailed Rule dialog (D1+D3, D27, Khara/22D/64N, Natural Karaka, Internal/External, nutrient support).
- Tap Rule content → Remedy dialog.
- Medical treatment remains mandatory; astrological remedies are support only.
- Version: 1.4.85+85.
