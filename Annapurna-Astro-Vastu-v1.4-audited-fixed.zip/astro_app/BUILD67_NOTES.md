# Build 67 — D24 User Master Education Flow

Version: `1.4.67+67`

## D24 education level
- 4th house → up to Intermediate
- 9th house → up to Degree / B.Tech
- 2nd house → up to PG
- 7th house → up to Post-PG
- Empty/directly untriggered level is never interpreted as “no education”.

## D24 stream-selection rule
1. Calculate exact D24 ascendant degree.
2. Take 5th-house starting point.
3. Add 15°.
4. Find the Nakshatra at that point.
5. Take the Nakshatra lord and its D24 sign.
6. Classify that sign using the user master Technical / Semi-technical / Non-technical mapping.
7. Collect education fields of that sign.
8. Add education fields of planets occupying that sign.
9. Add education fields of planets aspecting the Nakshatra lord using the app classical graha-drishti scheme.
10. Keep fields compatible with the sign nature.
11. Rank all compatible fields by evidence-match score: sign 40% + same-sign planets 35% + aspecting planets 25%.

The percentage is an evidence/suitability score, not a probability.

## UI / audit
- Final Education Summary shows all four education levels.
- Shows 5H +15° selection chain, Education Nature, favorable education list with percentages, and sign-lord career guidance.
- Tapping `ఫలితం` shows Rule ID → Result → Source.
- `Rule / పరిశీలన వివరాలు` shows the complete calculation/evidence chain.
