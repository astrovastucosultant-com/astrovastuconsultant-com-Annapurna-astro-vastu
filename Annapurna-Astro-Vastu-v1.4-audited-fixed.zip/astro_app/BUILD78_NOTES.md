# Build78 — Mandatory Panchadha Maitri for Every Varga

Version: 1.4.78+78

## User-approved change
- Added COMMON-PANCHADHA-MAITRI engine for all 16 vargas in the app.
- Panchadha temporary relationship is built from D1/Rasi positions once.
- The same D1 compound relationship is used to judge each planet against the lord of the sign occupied in D1/D2/D3/D4/D7/D9/D10/D12/D16/D20/D24/D27/D30/D40/D45/D60.
- Direction is preserved: A→B may differ from B→A.
- Varga screen now includes a common Panchadha Maitri strength panel before source-rule results.

## Strength values
- Own sign: 30
- Adhimitra: 22.5
- Mitra: 15
- Sama: 7.5
- Shatru: 3.75
- Adhishatru: 1.875

## Boundary
This is a mandatory strength modifier, not a standalone prediction engine. Existing varga-specific source rules remain unchanged.
