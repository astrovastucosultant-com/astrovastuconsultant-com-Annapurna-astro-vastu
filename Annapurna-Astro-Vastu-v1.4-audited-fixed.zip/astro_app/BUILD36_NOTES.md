# Build 36 — Marriage Matching + Gem Remedy Tabs

- Added top-level `వివాహ పొంతన` tab.
  - Current chart + a second Saved Chart can be selected.
  - Two-chart supplied marriage source rules are surfaced by rule/page.
  - No invented matching score is produced where the supplied handwritten rule is not yet machine-validated.
- Added top-level `Gem Remedy` tab based on supplied `Gem remidy rools.pdf` Principle 1–10 and Rahu–Ketu restrictions.
- Gem selector produces a chart-specific status: Eligible / Conditional / Restricted / Not Indicated.
- Tapping the gem result opens only the rules that actually matched, with source page and chart inspection.
- Strength inputs shown in the tab:
  - Shadvarga / Saptavarga / Dashavarga / Shodashavarga Vimshopaka Bala.
  - Shodashavarga support list.
  - House strength using verified SAV house points.
- Source transparency: the supplied remedy rule pages require Grahashakti/Bhavabala but do not specify complete classical Shadbala/Bhava-Bala arithmetic. Build 36 therefore labels the numeric inputs as Vimshopaka/SAV support inputs and does not claim they are full classical Shadbala/Bhava Bala.
- Removed the technical marriage-registry status card from D9 result display.
- Version: 2.22.0+36.
