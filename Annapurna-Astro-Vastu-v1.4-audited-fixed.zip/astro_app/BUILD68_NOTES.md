# Build 68 — D24 Education Split Engines

Version: 1.4.68+68

## D24 Master Rule presentation

A. Education Continuity / విద్య సాగే స్థాయి
- 4H → Intermediate వరకు
- 9H → Degree / B.Tech వరకు
- 2H → PG వరకు
- 7H → Post-PG వరకు
- This engine only answers how far/how education continues; it does not choose the subject/course.

B. Education Field / చదవవలసిన విద్య
- D24 5th-house starting point + 15°
- Find Nakshatra and Nakshatra Lord
- Take the Nakshatra Lord's D24 sign and its Technical / Semi-technical / Non-technical nature
- Combine sign education + planets occupying that sign + planets aspecting Nakshatra Lord
- Retain education fields fitting the sign nature and rank with suitability evidence score

Result-tap audit remains Rule ID → Result → Source.
