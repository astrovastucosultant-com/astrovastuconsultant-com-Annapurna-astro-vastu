# Build 15 — Scrollable system drawer + system detail pages

- Adds a left-side hamburger (☰) navigation drawer on the chart screen.
- Scrollable system menu in the requested order: Dasha, Jamakola, Jaimini, Tajik, BCP, BSP, BNN, KP.
- Selecting a system opens its own dedicated scroll page.
- Vimshottari page now shows birth Mahadasha, full schedule, current MD/AD/PD and Antardasha dates.
- Jaimini page keeps source-backed Chara Karaka, Karakamsa, Rashi Drishti and Argala core.
- KP page keeps verified Planet → Sign Lord → Star Lord → Sub Lord calculations and event house groups.
- Jamakola/Tajik/BCP/BSP/BNN have complete UI section structure but do not fabricate calculations; exact results stay source-gated until verified source arithmetic is available.
- Existing Build 12+ D1/varga/ashtakavarga chart rendering remains unchanged.
- Version: 2.1.0+15.
