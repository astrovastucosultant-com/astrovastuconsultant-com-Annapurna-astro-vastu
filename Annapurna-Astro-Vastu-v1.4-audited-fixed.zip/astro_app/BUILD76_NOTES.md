# Build 76 — D10 Dynamic Work-Mode + Transformed Career Result (09 Oct 2026)

Base: Build75 v1.4.75. Existing D10 grouped layout and source registries are preserved.

## User-locked D1 → D10 work-mode sequence

- D1 Gocharastha → D10 Agocharastha = first Business/Self Employment, later Job/Service.
- D1 Agocharastha → D10 Gocharastha = first Job/Service, later Business/Self Employment.
- D1 + D10 both Gocharastha = Business/Self Employment continuation.
- D1 + D10 both Agocharastha = Job/Service continuation.
- D9 is audit/support only and no longer overrides the D1 → D10 sequence.

The Business and Job panels are now dynamic: inactive mode no longer duplicates the same profession list. When a transition is present, both panels show their correct stage (first/later).

## D10 factors routed into the active D10 mode

The current D10 mode panel now carries the relevant D10 supporting results:
- D10 Lagna — work interest/intention
- D10 4th house — professional comfort/work environment
- D10 Sun result
- D10 Moon result
- Saturn relation
- PP-planet supporting result

Thus these results appear inside Gocharastha when D10 is Gocharastha, and inside Agocharastha when D10 is Agocharastha.

## Profession transformation

Each shortlisted profession now visibly combines:
Profession family + Evidence Match % + 10L Nakshatra profession evidence + Amsha Devata work-flow + BPHS Balaadi Avastha.

Example: Job/Service + Indra + Yuva => administrative/authority responsibility with energetic execution and team-leading expression.

The 27 Nakshatra profession profiles remain an independent profession-evidence block.

## BPHS Balaadi Avastha

Added actual Bala/Kumara/Yuva/Vriddha/Mrita calculation for the D10 10th lord from its D10 longitude.
- Odd signs: Bala → Kumara → Yuva → Vriddha → Mrita
- Even signs: reverse order
- 6° bands; Yuva = full expression

Balaadi modifies work expression; it does not create a profession or alter Career Evidence Match %.

## Rise / Fall / Middle %

Rise, Fall and Middle cards now display a relative Timing Evidence % calculated from the existing source-derived MD/AD window scores. It is explicitly not an event probability.

## Verification

No Flutter/Dart SDK is installed in the local runtime. Source structure, references and ZIP integrity are checked here; APK compile remains verified by the existing GitHub Actions workflow.
