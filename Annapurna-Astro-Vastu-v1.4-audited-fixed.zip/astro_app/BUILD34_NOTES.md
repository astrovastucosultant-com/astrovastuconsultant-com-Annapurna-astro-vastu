# Build 34 — Chart degree layout cleanup

- Planet degrees are displayed directly inside D1 and all varga chart sign cells.
- Removed the separate D1 planet-position list below the chart.
- Removed the separate varga planet-position list below each divisional chart.
- Planet labels inside chart remain tappable for full detail sheet.
- Unmatched source-rule library rows are hidden from the main varga result view.
- When no validated rule applies, the UI shows only: “ఈ జాతకానికి ప్రస్తుతం వర్తించిన source rule లేదు.”
- Version bumped to 2.20.0+34.
