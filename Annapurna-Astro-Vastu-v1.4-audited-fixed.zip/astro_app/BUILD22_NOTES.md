# Build 22 — Complete Ashtakavarga Arithmetic Engine

- Keeps verified BAV, SAV and Prastara calculations.
- Adds Lagna-relative 1–12 house vectors for SAV and every BAV.
- Adds full Trikona Shodhana for all seven planetary BAVs.
- Adds full Ekadhipatya Shodhana using natal seven-planet occupancy.
- Adds Rashi Pinda, Graha Pinda and Shodhya Pinda for all seven planets.
- Keeps two Rashi multiplier profiles separate: practical (Virgo=5) and PVR (Virgo=6).
- Adds natal BAV bindu score and natal house for Sun through Saturn.
- Adds Kakshya index/range arithmetic (8 x 3°45′) and direct longitude BAV/SAV lookup APIs.
- Adds SAV grouped arithmetic used by supplied source rules (Kendra, Kona, Upachaya, Dusthana, Dhana, Education, Career, income/expense, Poshaka, Swatantra, inner/outer groups).
- Adds arithmetic audit panel in the Ashtakavarga screen and activates previously pending Shodhana/Pinda output cards.
- Adds regression tests for BAV/SAV invariants, Trikona, Ekadhipatya, Pinda consistency and Kakshya.
- Version 2.8.0+22.
