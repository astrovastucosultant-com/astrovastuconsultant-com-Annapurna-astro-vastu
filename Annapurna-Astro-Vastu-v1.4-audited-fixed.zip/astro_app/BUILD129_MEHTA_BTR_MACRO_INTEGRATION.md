# Build129 — S.K. Mehta + BNN/BCP/BPD/KP BTR integration (v1.4.129)

**Base:** User's saved Build128 v1.4.128 source ZIP (462+ files) from Library. Existing S.K. Mehta AD/PD/Sukshma scoring, LAGNA/MOON percentages, and BTR ranking logic remain unchanged except for adding separately labeled non-scoring context. No unrelated D4/D7/D9/D10/D12/KP formulas were edited.

## Actual source changes

- `lib/astrology/btr_macro_context_service.dart` (new): natal Jupiter's sign from existing chart positions; completed age; source-specified **fixed-block 12-year major**, **1-sign-per-year minor**, and **BCP running-year house**. No degree-balance variant, Saturn/Rahu/BPD calculations or invented predictions.
- `lib/astrology/mehta_btr_service.dart`: each observed event now carries `macroContext` beside pre-existing Mehta timing evidence. Macro context is **not used to increase the evidenceShare**, rank or birth-second certainty. Chart stubs without Jupiter remain supported (`null` context).
- `lib/screens/mehta_btr_screen.dart`: event details and copyable report display Jupiter Major/Minor/BCP context and a link to the separate BTR RuleBook.
- `lib/screens/mehta_btr_rulebook_screen.dart` (new): user-given 206 New Dimensions entries, 85 New Rules entries and 46 macro-to-seconds BTR rules. Rule search, group filter, mandated result → rule → inspection → remedy drill-down. No automatic match claims or invented remedies.
- `lib/screens/chart_screen.dart`: adds the BTR RuleBook button directly inside the Mehta view, preserving its existing Mehta-only analysis.
- `assets/btr/*`: three distinct provenance-preserving JSON rulepacks plus topic links. `pubspec.yaml` registers these assets.
- `test/btr_macro_context_service_test.dart`: birthday-boundary and age-12/26 examples (requires Flutter SDK).

## Audit: BTR rulebook rule count

- S.K. Mehta, *New Dimensions*: 206 **editorial entries**, not author-numbered rules.
- S.K. Mehta, *New Rules and Combinations*: 85 book combinations.
- BTR macro-to-seconds user RuleBook: 46 design/sourced rules.

## Critical separation

BNN / BCP / BPD / KP are NOT recast as authentic S.K. Mehta textbook formulas. New BTR rulebook is cross-linked in the interface while Mehta-only calculations remain Mehta-only. BPD, Naisargika, KP sub-lord second discrimination and D-varghas must be implemented and validated separately before their scores enter rectification. The existing search still uses its pre-existing coarse plus 30-second refinement; this release does not claim it has magically become a true 1-second engine.

## Build verification

Static asset/route/import, JSON uniqueness and ZIP-integrity checks performed. Flutter/Dart SDK not available in this container; `flutter analyze`, `flutter test`, Android APK build, device testing and CI release are **NOT performed**. Do not call this a green Android build until GitHub Actions compiles it.

## Source handling

Existing Mehta author rules were not rewritten. Source-extraction and software-design entries retain distinct source labels. No traditional remedy is supplied if the attached material did not support it. This implementation is a cultural/astrological rules workflow, not scientifically validated birth-time identification.

## Final UI audit

Titles for source entries `LAGNA-01` and `RANK-11` are editorial display labels only; their supplied IF/THEN conditions and results are unchanged.
