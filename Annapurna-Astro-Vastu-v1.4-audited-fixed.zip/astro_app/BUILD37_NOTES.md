# Build 37 — S.K. Mehta System Tab

- Added a top-level `S.K. Mehta` tab to the main chart screen.
- Uses only the uploaded S.K. Mehta Master App Command Table / Synchronization rules; no Parashara, Jaimini, KP or Ashtakavarga rules are mixed into this tab.
- Event selector includes source-supported user-facing Mehta event combinations such as Marriage, Economic Gain, Foreign Tour, Child Birth, Property, Vehicle, Government Job/Promotion, Private Job/Change, New Appointment and Business Start.
- For each event the tab shows:
  - Source rule ID and Mehta event combination.
  - ASC and Moon-ASC responsible house lords.
  - Current Vimshottari and S.K. Mehta Tribhagi MD→AD→PD→Sukshma→Prana path.
  - Primary 2nd→3rd→4th-place synchronization count.
  - Rule detail sheet with timing adjustment, replacement and source trail.
- Source guardrails are visible inside the tab: Mehta-only, no guessing, synchronization before final timing, 2nd/3rd/4th priority, 5th/6th only for micro-sync, and combination priority over mere repetition.
- Sensitive death/accident event rules from the source are not exposed as personal prediction options.
- Version: 2.23.0+37.
