# Build79 — D27 Health Final Summary + Gender + Evidence %

Version: 1.4.79+79

## User-approved changes
- Added Birth Profile gender option: పురుషుడు / స్త్రీ. Saved chart JSON now preserves gender; older saved charts remain unspecified rather than being guessed.
- Added D27 Health Final Summary above the matched source-rule cards.
- D27 output now shows: primary D27 health-trigger planet, D27 house/sign/nakshatra, source body-region illustration, Internal/External indication, disease-nature modifiers, Panchadha Maitri strength and strength %, Bhamsa/Nakshatramsa presiding Devata, age/timing windows, and remedy boundary.
- Added 12 body-region illustration assets for Aries→Pisces region mapping. These are illustrative only, not medical/anatomical diagnosis.
- Added D27 exact fractional longitude helper so D27 nakshatra can be derived without discarding the fractional position.

## Percentages
- Roga Evidence Match % = matched astrology evidence blocks / available evidence blocks.
- Panchadha Strength % = user-approved Panchadha score / 30 × 100.
- Timing Evidence % = affected D27 planet active as Vimshottari Mahadasha (50%) + affected D27 planet active as Antardasha (50%).
- Percentages are astrology evidence coverage, not disease probability or medical-risk percentages.

## D27 source logic used
- D27 6/8 health trigger layer.
- D1 6/8/12 cross-confirmation block.
- Drekkana half: first half → internal; second half → external.
- Saturn/Rahu → chronic tendency modifier; Mars/Ketu → surgery/intervention caution modifier.
- Timing from affected/disease-giving planet dasha activation.
- Bhamsa Devata is displayed as a contextual symbolic modifier only; it does not create a diagnosis or add a medical percentage.

## Safety/source boundary
The D27 module is traditional astrology guidance only. It does not diagnose disease, prescribe medicine, or replace qualified medical care. Source-backed remedies can be added later when a verified remedy mapping is supplied.
