# Build 55 — Build54 Save/Reopen/Birth-Time + D10 Government/Vipareet Rules

Carries forward Build54:
- Save / Update Chart
- Save as New
- Saved Charts search and reopen
- Original birth time preserved separately from rectified/current birth time
- Edit Birth Time -> Apply & Recalculate
- Use Original & Recalculate
- Saved-chart migration support

New D10 source integrations:
- D10-GOV-01: Government Service promise — D1 5L Navamsha sign in D1 5/9 trine
- D10-GOV-02: Government Service/support — D1 9L Navamsha sign in D1 5/9 trine
- D10-GOV-03: D9 promise -> D10 authority/supporting confirmation
- D10-GOV-04: Senior Government / Government-linked consultant-advisor-contractor presentation
- D10-VRY-01: Harsha structural/full source support
- D10-VRY-02: Sarala structural/full source support
- D10-VRY-03: Vimala structural/full source support
- D10-VRY-04: Super Strong Vipareet structural/full auto-check (debilitation branch only; enemy-sign branch remains source-only)
- D10-VRY-05: D10 career effect / dasha timing note

Source boundaries:
- Government Service chapter itself says D9 promise is not final and Dashamsha must be referred to. The uploaded 8-page source does not give a complete D10 Government formula, so the app uses already-supplied D10 Sun/10H/10L/Indra authority evidence only as supporting confirmation.
- Vipareet source requires dusthana placement plus source-specific relation conditions. The app separates structural candidate from stronger/full source support.
- Enemy-sign friendship for Super Strong Vipareet is not imported from outside the uploaded source; only the explicit debilitation branch is auto-confirmed.
