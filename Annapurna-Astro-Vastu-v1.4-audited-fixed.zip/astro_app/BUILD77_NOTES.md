# Build77 — D9 Final Marriage Report

Version: `1.4.77+77`

## D9 point-wise final report

A new D9 marriage report is shown directly under the Navamsha/D9 section.
It includes:

1. Marriage Promise / D9 Lagna-Lagna Lord + 7H/7L evidence
2. 7th-house / spouse-stability layer
3. Before-marriage obstacles (Saturn ↔ 3H/3L source rule)
4. Before-marriage relationship evidence
5. Timing of Marriage — year list + Evidence Match % + MD/AD dates
6. After-marriage quality — D9 2H (first experience) + 2L (later events)
7. Affair-after-marriage source combinations
8. Multiple/repeated relationship evidence
9. D7 Ketu Divorce confirmation — Marriage Rules Sutra 35
10. Final Separation / Divorce Evidence Match %

## D7 Ketu Sutra 35

Added source registry entry `MM-D7-DIV-35`.
Software confirmation checks Ketu relation with:
- D7 6th house
- D7 6th lord
- D7 Lagna
- D7 Lagna lord

This is only an independent confirmation block. It never produces a stand-alone deterministic divorce verdict.

## Affairs source layer

The supplied D9 source combinations are used as independent evidence blocks:
- 5H/5L influenced by Vipreet-house lords
- 5L ↔ 7L relation
- Mars ↔ Venus relation
- 6L influence on Venus
- 6L influence on 7H/7L
- Venus + Ketu
- 8L influence on 4H/4L (secrecy layer)

Multiple-affair output is shown as an Evidence Match % only; it is not a certainty statement.

## Timing

Build77 supplies a visible year list from machine-calculable Vimshottari + D9 evidence blocks.
The percentage is evidence coverage, not event probability.
V.P. Goel Saturn-transit rules and handwritten marriage-year/transit arithmetic remain source-only until exact transit arithmetic is connected; the UI states this explicitly instead of inventing a result.

## Source discipline

- `D9 chatgpt.pdf` — Navamsha marriage promise, quality, obstacles before marriage, after-marriage 2H/2L, affair combinations.
- `Marrage rules ok.pdf` — D7 Ketu divorce confirmation, Sutra 35 and marriage timing source catalog.
- No unsupported deterministic affair/divorce claim is generated.

## Verification

Source references and ZIP structure were checked locally. Flutter/Dart compiler is not installed in this runtime; APK compile remains verified by the existing GitHub Actions workflow.
