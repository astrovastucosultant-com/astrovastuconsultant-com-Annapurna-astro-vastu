# Build61 — D24 Matched-Only Result Fix

Base: Build60 / v1.4.60.

Fixes:
- D24 final result now shows only auto-evaluated rules whose conditions actually match.
- Removes visible “condition auto-match కాలేదు” placeholder cards from D24 results.
- For the same D24 topic/house, favorable + caution evidence is consolidated into one mixed/net-result card instead of simultaneous green/red cards.
- Source-only Education.pdf catalog remains in the rule registry for audit/reference but is not presented as a chart-specific prediction.
- D24 sign-nature classification remains visible as an applicable informational result.
- Rule tap still exposes Rule / Inspection / Source.

Version: 1.4.61+61
