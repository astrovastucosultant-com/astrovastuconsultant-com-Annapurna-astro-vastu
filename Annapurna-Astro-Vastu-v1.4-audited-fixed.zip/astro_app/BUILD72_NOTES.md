# Build72 — D10 Pre-Deep-Audit Final Master Formation Restored

Version: `1.4.72+72`

## Purpose
This build intentionally restores the D10 Profession Module behavior and rule formation from Build70 — the "Final Master Rule Formation" used before the later deep-audit refinements — so it can be checked in the app as requested.

## Restored D10 master flow
- D10 10th-lord planet professions
- D10 10th-lord D10-nakshatra professions
- D10 10th-lord D10-sign professions
- professions of planets conjoined the D10 10th lord
- profession-family merge
- independent evidence coverage % (Career Suitability; not a probability)
- Technical / Semi-Technical / Non-Technical nature filter
- Dashamsha Amsha Devata modifier/support in the same pre-deep-audit flow
- 27 Nakshatra profession support registry
- BPHS Graha-Avastha / Shayanadi strength layer kept separate from Career Suitability %
- Brihat Jataka result-quality layer kept separate from Career Suitability %
- existing exact source-gate cards remain available for audit

## Important
This build is based on Build70 logic, not the Build71 Devata-workflow-only ranking separation. It is a deliberate comparison build.
