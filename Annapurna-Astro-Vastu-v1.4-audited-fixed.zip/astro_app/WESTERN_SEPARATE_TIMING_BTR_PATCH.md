Western Independent Timing & BTR — patch audit
- Corrected malformed Dart list delimiter in progression_analysis_screen.dart.
- Western Timing and BTR remain separate screens; no Vedic dasha dependency introduced.
- BTR accepts event category plus historical date, and displays category in evidence.
- Date picker limits events to today, rather than future events.
- Existing retrospective BTR score is raw contact count; it does NOT perform event-specific weighting or prove birth time.
- Eight fully validated calculation methods NOT claimed: tertiary/minor/primary/converse/profection remain incomplete.
- Flutter compile and APK build NOT run; source ZIP integrity checked.
