# Annapurna Astro Vastu v1.5 — Calculation Upgrade Notes

## Purpose
This update expands the existing Swiss Ephemeris based birth-chart screen into four working sections:
1. Jataka / Rasi chart
2. Shodasha Varga charts
3. Ashtakavarga
4. Calculation details

The feature organization was informed by publicly described capabilities of established Vedic astrology apps. No proprietary source code, private algorithms, copied layouts, or app assets were used.

## Calculation engine kept from the existing app
- Swiss Ephemeris through the `sweph` Flutter package.
- Sidereal calculation.
- Selectable Lahiri, Raman, and KP/Krishnamurti ayanamsa.
- Moshier planetary mode so separate `.se1` files are not required for the current build.
- Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, True Rahu and opposite Ketu.
- Ascendant from Swiss Ephemeris house calculation.
- Whole-sign house number is shown as a clearly labelled derived value.

## Jataka section
- South Indian fixed-sign Rasi chart.
- Lagna highlight.
- Planet longitude in sign.
- Nakshatra and pada.
- Whole-sign house number.
- Retrograde indicator.
- Copy, save and share report actions retained.

## Shodasha Varga section
The following 16 classical divisions are available from one tab:
- D1 Rasi
- D2 Hora
- D3 Drekkana
- D4 Chaturthamsha
- D7 Saptamsha
- D9 Navamsha
- D10 Dashamsha
- D12 Dwadashamsha
- D16 Shodashamsha
- D20 Vimshamsha
- D24 Chaturvimshamsha
- D27 Bhamsa
- D30 Trimshamsha
- D40 Khavedamsha
- D45 Akshavedamsha
- D60 Shashtiamsha

The source longitude remains the sidereal longitude from Swiss Ephemeris; each varga service applies the classical sign-remapping rule for that division. D30 uses unequal classical portions rather than equal 1-degree pieces.

## Ashtakavarga section
- Seven standard Bhinna Ashtakavarga (BAV) tables: Sun through Saturn.
- Eight contributors for each BAV: Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn and Lagna.
- Rahu and Ketu are not used as standard BAV recipients/contributors in this implementation.
- Sarvashtakavarga (SAV) = sign-wise sum of the seven BAV tables.
- South Indian style display plus numeric sign grid.
- Prastara display for the selected BAV as an 8 x 12 contributor matrix.
- Built-in checksum validation:
  - Sun 48
  - Moon 49
  - Mars 39
  - Mercury 54
  - Jupiter 56
  - Venus 52
  - Saturn 39
  - SAV 337

## Calculation tab
- Panchanga-derived values from natal Sun/Moon longitude: Paksha, Tithi, Moon Nakshatra/Pada, Yoga and Karana.
- Swiss Ephemeris version, Julian Day UT, ayanamsa and ayanamsa value.
- Planet table: Rasi, longitude, Nakshatra, Pada, whole-sign house and motion.
- Quick Varga matrix for D1, D9, D10 and D60.

## Deliberately not guessed in v1.5
The following are useful professional modules but are not added until their exact rule source and validation cases are fixed for this project:
- Shadbala
- Bhava Bala
- Trikona Shodhana
- Ekadhipatya Shodhana
- Shodhya Pinda
- Kaksha transit scoring

This prevents mixing different schools or silently inserting unverified formulas.

## Validation added
Automated tests were added for:
- Varga mapping boundaries and all supported factors.
- D30 unequal portions.
- BAV fixed totals and SAV = 337.
- Prastara rows reconstructing BAV.
- Nakshatra/Pada boundaries.
- Panchanga Tithi/Karana sanity case.

Version: `1.5.0+7`
