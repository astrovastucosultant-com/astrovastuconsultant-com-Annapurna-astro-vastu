# Build99 — D7 Source-Based Completion (partial, auditable)

Source baseline: `Build98-v1.4.98-D7-Full-Rule-Engine-Source.zip`, recovered from user's Library. PDF reference: `Saptamsha_Santana_Niyamalu(1).pdf` (29 scanned pages), user `remidi.pdf` (367 scanned pages).

## Additional implementation

- `D7-SANTANA-017`: Beeja Sphuta BS = (Jupiter + Venus + Sun) mod 360, inspected against odd-numbered signs in D1/D9/D7. Exact numerical evidence shown; only pass is a green matched result. **Male-chart traditional method**, not an assertion of the person's sex.
- `D7-SANTANA-018`: Kshetra Sphuta KS = (Jupiter + Mars + Moon) mod 360, and its sign dispositor inspected against even-numbered signs in D1/D9/D7. Only pass appears as a matched result. **Female-chart traditional method**. No medically meaningful fertility guarantee.
- `D7-SANTANA-019`: D7 ascendant lord lookup for seven planets, matched to only the chart's actual ascendant lord (page 9). Traditional literary indication, not a diagnosis or hard judgment.
- `D7-HOUSE-01` ... `D7-HOUSE-12`: 12 D7 house domain cards sourced to pp.8–9. Only *occupied* houses appear as chart-inspection matches. Empty house domains remain in the rule/audit catalog.
- `D7-SANTANA-020`: exact Guru BAV bindu count in 5th sign from natal Jupiter (page 27) if BAV audit totals validate. No invented threshold or child-count prediction.
- Green matched-only / result -> actual match + rule + source -> remedy navigation remains the existing screen flow.

## Important boundaries

These **do not claim** that all 29 pages were translated into automatic IF–THEN predictions. Unimplemented rows remain explicit in audit: extra BS/KS conjunction/trine/dusthana, source 12 signs × 7 amsa (84-row) result lookup (pp.9–15), child count/order, BAV child-order specifics, fetal-sex predictions, denial/longevity determinations. They are not silently auto-fired. `remidi.pdf` remedy-family selector is retained; **per-page, per-rule exact remedy matching remains unverified** and must not be described as complete.

## Build status

The environment has no `flutter` or `dart` SDK, and the connected GitHub account exposes no repositories. Therefore this deliverable is **updated Flutter source**, not a compiled/verified APK. Source contains the existing `.github/workflows/build-android-apk.yml` to build once uploaded to an accessible GitHub repository with CI enabled.
