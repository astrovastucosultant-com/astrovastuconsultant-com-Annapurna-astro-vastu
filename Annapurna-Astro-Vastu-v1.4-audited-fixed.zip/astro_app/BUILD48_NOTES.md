# Build 48 — D10 Master Career Rule Engine

Version: 2.33.0+48

Source basis: user-supplied `D10 special.pdf` (Predict with Dashamsha excerpts), with the existing Annapurna D10 profession catalog retained only where it already existed in the app.

## New source-linked D10 rules

- Gocharastha / Agocharastha Saturn states and Job ↔ Business sequence across D1/D9/D10.
- PP planets corrected to Sun, Moon, Mars and Rahu; birth Lagna/10H/1L/10L influence check.
- Five-planets independence rule (7–12 or wrapping 10–3 sector, minimum two PP planets).
- 10th-lord-in-house profession nature layer.
- Kendra–Trikona Rajayoga repetition in Birth + D10 (conjunction/classical aspect/sign exchange auto-check).
- Mahabhagya source rule stored with parity evidence; final auto verdict withheld because the current birth form does not store sex and astronomical day/night state.
- Dashamsha Devata mapping (Indra through Ananta) and source-backed profession meaning used as a supporting layer in profession ranking.
- Primary Profession + ranked alternatives via evidence convergence. This score is an app index, not a classical probability.
- Career Start / First Earning timing windows.
- Career Rise / Fame timing windows.
- Career Graph milestone windows.
- Foreign Job promise + timing.
- Promotion / higher post / salary rise timing.
- Downfall / Loss of Job promise + caution timing.
- Transfer / location change timing.
- Retirement candidate windows; source distinction for forced retirement via 5th-lord involvement.

## Timing boundary

The source lists Vimshottari, Progress Yogini and Chara Dasha for dynamic career timing. Build 48 implements source-linked Vimshottari MD/AD windows in D10. Chara Dasha remains available in the separate Jaimini module; Progress Yogini is not silently substituted without its complete source calculation/verification in this D10 engine.

## Safety / interpretation boundary

Career dates are displayed as source-rule windows, not guaranteed real-world outcomes. Job-loss/downfall and retirement entries are explicitly labelled as caution/candidate windows. The app does not invent a missing Nakshatra→profession table; that row remains source-only until such a table is supplied.
