# Build 11
- Unique package: com.annapurna.astrovastu.build11
- JKS RSA/SHA256 test signing with APK v1 + v2 signatures enabled.
- Version 1.8.0+11.
- Supplied Annapurna galaxy artwork used as the home banner.
- South Indian D1/varga/Ashtakavarga chart layout retained.
- Test/private sideload signing only; not a Play Store production key.
