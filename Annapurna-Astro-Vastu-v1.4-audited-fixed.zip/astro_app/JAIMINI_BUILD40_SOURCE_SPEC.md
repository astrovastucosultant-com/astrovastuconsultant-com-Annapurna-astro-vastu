# Jaimini Chara Dasha — Build 40 Source Spec

## Source discipline
- Supplied Jaimini source only for classical calculation rules.
- Do not invent a hidden numerical Rashi-strength coefficient for unresolved Scorpio/Aquarius co-lord ties.
- Method variants are explicit in the UI.
- The 100-point score is an app decision-support score, not a classical probability.

## CD-01–CD-07
- CD-01: Start from Lagna by default; Custom can override start sign.
- CD-02: Method A = ordinary odd/even direction; Method B = supplied Vishama/Sama grouping with Taurus/Scorpio and Leo/Aquarius special-direction handling; Custom exposes direction.
- CD-03: Dasa years = directional sign-step count from Dasa sign to selected lord sign.
- CD-04: Own-sign duration default 12; exalted lord +1; debilitated lord -1.
- CD-05: Scorpio Mars/Ketu and Aquarius Saturn/Rahu are configurable. Auto applies source-resolved cases and exposes unresolved strength ties.
- CD-06: Generate 12 Mahadasha signs in the selected sequence and actual calendar dates from birth.
- CD-07: Divide each Mahadasha into 12 equal Antardashas; first AD is the MD sign, then follow the selected source sequence.

## App decision-support score — 100 points
- Mahadasha sign: 20
- Antardasha: 15
- Relevant Karaka: 15
- Arudha / Upapada: 15
- Rashi Drishti: 10
- Sign-lord strength: 10
- Varga confirmation: 10
- Repeated confirmation: 5

Bands:
- 0–29 Weak
- 30–49 Possible
- 50–69 Moderate
- 70–84 Strong
- 85–100 Very Strong

## Event IDs
- Marriage: M-01…M-06
- Career: C-01…C-05
- Children: CH-01…CH-04
- Wealth: W-01…W-04
- Property: P-01…P-03
- Education: E-01…E-03
- Foreign: F-01…F-03

## Required audit flow
Result → Rule audit → Source/remedy note

Every event rule exposes:
Rule ID → Input condition → Matched/Not Matched → Reason → Source.
Score components separately expose awarded/max score.

## Consultation overlap
Favorable AV transit window is split at exact boundaries for:
- Vimshottari supportive PD intervals
- Tribhagi supportive PD intervals
- Jaimini Chara MD/AD event-reference intervals

A consultation candidate requires Chara MD/AD support plus at least one of Vimshottari/Tribhagi, with favorable transit BAV/SAV.
