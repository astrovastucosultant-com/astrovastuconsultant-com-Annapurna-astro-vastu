# Build 65 — D24 matched-only summary cleanup

- Final Education Summary now hides unmatched fallback rows.
- No more “strong auto-match evidence లేదు / auto-match కాలేదు” lines in the final summary.
- Only chart-matched D24 items appear as summary results.
- Education Nature and Primary Field group remain when sign classification is available.
- Secondary Field is hidden unless a future source-safe subject rule is actually auto-matched.
- Education timing stays informational until a source-supported timing engine matches.
- D24 matched rule cards keep: Result tap → Rule ID → Result → Source.
- Version: 1.4.65+65.
