# Build135 — సమగ్ర BTR పద్ధతి–వారీ నివేదిక

Version `1.4.135+135`; base Build134. Adds **five separately attributed method assessments to the existing BTR results**, without changing candidate search, existing Mehta ranking score, or birth-time calculations.

## Display and export

- BNN (Jupiter major/minor): compares progressed Jupiter signs with event-relevant natal houses as a simple **contextual alignment**, clearly **not** a full source-specific rule N12-03 result.
- BPD: uses the already computed selected Vaani/Nādi profile and only event-linked P-house Arudha-lord positions. Keeps the 23 general Nādi dictums in their existing independent rulebook. No duplicate score.
- BCP: compares 12-year activated house with the selected event's required houses; match is contextual, lack of match is not a contradiction to a historical event.
- SK Mehta: only a demonstrably evaluated `R###` rule can produce a green/red *condition match*. `ND-###` or unimplemented rules stay manual. Existing separate dasha index remains labelled an *index*, not a probability.
- KP: shows the candidate's lagna Star/Sub/Sub-Sub and varga fingerprint; **event-specific KP cusps, significators and sub-lord promises are not fully implemented**, so this is never shown as proved event agreement.

Each dated observed event has five lines with status, source ID and explanation. The same content appears in the `BTR Report Copy` export. The fifth-method display is **non-scoring**; no fabricated cross-method percentage and no extra vote for correlated astrological evidence.

## Known limits

- Do not interpret contextual match as independently confirming adjacent birth seconds.
- BPD/KP incomplete source rules are not marked as applied; user must verify unimplemented sources.
- The existing BTR seconds search remains experimental, not an evidence-based clock correction.
- Flutter/Dart SDK unavailable locally: integration tests authored but were **not** run; APK compile not confirmed.
