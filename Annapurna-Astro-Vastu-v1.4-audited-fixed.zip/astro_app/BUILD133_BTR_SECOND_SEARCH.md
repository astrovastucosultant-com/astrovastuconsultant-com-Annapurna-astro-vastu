# Build133 — Auditable second-resolution Birth Time Rectification

Version: `1.4.133+133`.

## Implemented

1. Existing historical-event entry, local Save/Restore, optional Mehta R### rule selection, Vimshottari/Tribhagi timing, BNN Jupiter 12-year and BCP context remain intact.
2. Separate event evidence quality (verified/reported/uncertain); repeated consequences of one event may use a correlation group. Evidence aggregation reduces duplicated weights, and at least three independent event groups are needed.
3. Candidate time diagnostic fingerprint: KP ascendant sign, star, sub, **sub-sub** and event-relevant D1/D4/D7/D9/D10/D16/D12/D24 varga ascendants. KP uses the chart's selected sidereal ayanamsa, not a silently changed one. Varga/KP fingerprints reveal a changed chart state; they are **not** independently positive event evidence without source-defined event-promise rules.
4. Search broad user-selected windows (±30/60/120/360/720 minutes) with coarse samples, transition bisection, 15-second and 1-second local sweeps. These broad windows are **not** claimed to be globally exhaustive to 1 second.
5. NEW full-exhaustive every-second scan for ±1, ±2, ±5 or ±10 minutes. `searchCenter` allows rerun around a leading candidate (from broad search). For example ±5 minutes tests **601 distinct candidate birth times**, inclusive.
6. Both mode types report HH:MM:SS, correction from recorded original time, number of candidate times checked, 1s samples, coverage warning, score plateaus and alternative windows. Distinguishability requires multiple independently discriminating verified events plus exhaustive second sweep. Candidate score is a *Rule Match Index*, NOT probability of actual birth time.
7. Display separate lagna/Moon-lagna *event rule-match indices* (not objectively measured strength), event-specific source rule statuses, and a manual apply/recalculate confirmation when automatic uniqueness cannot be justified.
8. Multi-region candidate comparison; refine any candidate with full ±5-minute second search; preserve original birth time before manual apply.

## Source exclusions — not fabricated

- 46 entries in `assets/btr/btr_macro_seconds_46.json` are a **design register**. They are not 46 fully executable timing formulas. BNN 12-year major/minor and BCP years are context. BPD concurrent planetary cycles, unverified Naisargika 84-year source table, independently defined KP house cusp/sub-lord significators, complete divisional event-promise scoring, independent holdout validation, and chart sensitivity to historical DST are not implemented as definitive second-level evidence. Additional verified author-specific tables/algorithms would be required.
- SK Mehta ND-206 narrative rules are never auto-labelled as matched unless there is a validated executable evaluator. Only eligible evaluated 85-book rules influence an individual event score.
- Astrology BTR cannot scientifically demonstrate actual birth-time accuracy to a second. Even full grid search evaluates a *model*, not biological proof of an original clock instant.

## Validation limits

Static checks: version, 46/206/85 catalog sizes, local imports, lexical bracket balance, data links and source archive integrity. Tests added: `test/btr_second_sweep_test.dart` (121 second inclusive sweep, movable search center, KP signature boundary, correlation-group validation). **Dart/Flutter tests, compile, Android install and live natal/event chart cross-validation not run here because the Flutter SDK is not installed.** GitHub Actions APK success is required before calling this tested APK.
