# Build84 — Full D27 Health Audit + Internal/External + Natural Karaka/Nutrition Support

## Preserved
- D1 + D3 organ/body-region matching and consolidated organ cards.
- D27 severity confirmation.
- 22nd Drekkana, 64th Navamsa and Khara direct-organ confirmation.
- Panchadha Maitri, Bhamsa Devata, Vimshottari age/timing and source-backed remedies.
- Full-body visual and gender-aware report shell.
- Medical disclaimer and treatment-first wording.

## Audit fixes/additions
- Audited Drekkana half logic: within each 10° Drekkana, first 5° = Internal; second 5° = External. Exact per-planet degree-within-Drekkana is now displayed.
- Same body region is consolidated even when supporting planets fall in different Drekkana halves; the card preserves each planet's Internal/External detail and can show Internal + External together.
- D27 Severity no longer double-counts 22D/64N; Khara remains a separate evidence layer.
- Added Natural Karaka confirmation as a separate mandatory support layer.
- Added user-approved vitamin/mineral support map. Rahu/Ketu receive no vitamin/mineral assignment.
- Added Strong/Moderate/Weak/Low label beside Final Astrology Evidence.
- Nutrient output is explicitly a check/support indicator only; blood test/doctor evaluation is required and horoscope-based supplement prescription is prohibited.

## Final evidence weighting
- D1+D3 Organ Match: 45%
- D27 Severity: 30%
- Direct Khara/22D/64N link: 10%
- Natural Karaka Confirmation: 15%

Percentages are astrology evidence coverage, not disease probability or medical risk.
