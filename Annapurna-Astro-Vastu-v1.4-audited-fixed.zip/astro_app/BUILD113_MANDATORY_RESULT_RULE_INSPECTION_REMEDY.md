# Build 113 — mandatory four-stage result navigation

Source baseline: Annapurna Astro Vastu **v1.4.112+112** (SK Mehta All Rules). New version **1.4.113+113**.

## Mandatory UI contract

**Tap Result → Rule → Chart/hand inspection → Source-backed Remedy**.

1. Result: topic, result/status, Rule ID; source-only cases never masquerade as matched predictions.
2. Rule: IF/THEN condition, exact source and page when available.
3. Chart inspection: chart placements/reasons, reference lagna and evidence already provided by the module. Never invent absent inputs.
4. Remedy: module's existing supported remedy only. If absent, explicitly say source remedy is unavailable.

The user can tap the content panel or the explicit bottom button to advance; Back returns to the previous stage. Rule ID and module label remain in the header.

## Common, source-preserving widget

`lib/widgets/mandatory_result_flow.dart`: `MandatoryResultEntry` and `MandatoryResultFlow.open(...)`. Central contract is reusable in subsequent modules.

## Wired entry points

- All standard VargaRuleHit panels, including D2, D3, D4, D7, D9, D10, D12, D20, D24 and any other factor routed through `_VargaRulePanel`.
- D24 result details; D10 overview's existing VargaRuleHit tap callback.
- S.K. Mehta combinations and event synchronization (including C1–C85 source catalog).
- Gem Remedy evaluation / applied-rule evidence and safeguards (not fabricated prescriptions).
- Jaimini matched yoga rules and Jaimini Chara Dasha individual rule audits.
- BSP activation rule details.
- Ashtakavarga Jataka individual result details.
- D12 complete source book rule catalog, with source page images preserved.
- Hasta Samudrika individual rules (manual markings are **not** computer-vision verification).

**Not asserted as migrated:** independent result viewers in consultation, BTR, KP, Tajik, some Ashtakavarga timing tables, older independent D9/D10 or standalone reports that do not use these routed entry points. Those need their own `MandatoryResultEntry` adapters and separate UI regression checks. This is a shared mandatory presentation policy for migrated flows, not proof that every screen in the app has been manually visited.

## Safety and source discipline

- No new Jyotisha rule, scoring formula, chart calculation or remedy invented.
- Unmatched/source-only state remains unverified.
- No source remedy → honest message, not an inferred gem/homa.
- D12 source scans remain accessible from the rule/inspection stages.
- Existing percent calculations are unaffected.

## Testing status

- `test/mandatory_result_flow_test.dart` added; it checks stage order, fallback remedy, unverified rule, and missing analysis data.
- Static checks and archive integrity are run during packaging.
- **Flutter SDK is not installed in this runtime.** No claim of compiled APK or passed Flutter widget tests before a GitHub Actions build completes.
