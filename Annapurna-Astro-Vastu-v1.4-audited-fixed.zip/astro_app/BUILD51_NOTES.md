# Build 51 — D10 Foundation Results

Adds six D10 result cards before the profession list:

1. D10 Lagna — work desire / interest, including direct malefic and Papakartari audit.
2. D10 Lagna lord — self-created professional difficulty audit using house, conjunctions and Papakartari.
3. D10 4th house — professional comfort / acceptance / work-location layer.
4. D10 7th house — 10th-from-10th, public image / profession-strength layer.
5. D10 Sun — guide/support-person layer with transparent operational association check.
6. D10 Moon — work-mind / emotional-state reflection from house + associations; explicitly not a diagnosis.

Sources: supplied `D10 special.pdf` Chapter 02 Basics (printed pp.11–23) plus the user's explicit D10 interpretation. Papakartari is operationalized transparently as malefics occupying both adjacent houses so the app can reproduce the result.

Existing Build 50 exact-profession registry and all prior D10 career/timing features are retained.
