# Western Timing & BTR — implementation status

This is an **engine foundation update**, not a complete eight-method Timing/BTR engine. It has NOT been connected to the app navigation, production ephemeris, or multi-event rectification search. Do not display calculated timings or 100% match claims from this foundation alone.

| Priority | Method | Actual implementation | Remaining work |
|---|---|---|---|
| 1 | Secondary | Date mapping day-for-year | Ephemeris, progressed angles, aspects, event evaluation |
| 2 | Solar Arc | Natal longitude plus true progressed-Sun arc | Obtain Sun positions, aspects, time windows |
| 3 | Tertiary | Tertiary-I synodic-month date mapping | Convention selection, ephemeris, evaluation |
| 4 | Minor | Sidereal-month/year mapping | Convention verification, ephemeris, evaluation |
| 5 | Naibod / 1° | Separate symbolic transforms | Directional aspects and angle rules |
| 6 | Primary | Explicitly unimplemented | Right ascension, declination, latitude, chosen key, promissors etc. |
| 7 | Converse | Converse secondary mapping | Converse other methods and comparisons |
| 8 | Profection | Whole-sign sign index | House, annual lord, annual chart / events |

## Safety and provenance
Ephemeris date is not an event prediction. BTR needs multiple dated events, candidate-birthtime recomputation of angles, distinct aspects, time tolerances, and held-out validation. A ranking score is not proven predictive probability. No natal or ephemeris longitudes should be substituted with guesses.

No existing Vedic rule code was modified. This ZIP preserves all source from v1.4.154 and includes the new Dart foundation and tests.

## v1.4.156
WesternTimingTab is connected to the main chart tab bar (11th tab; adjacent to S.K. Mehta). It provides selectable event date and foundational date mappings, not event predictions. Western BTR is shown explicitly as not implemented. Only chart_screen.dart, pubspec.yaml and new western_timing_tab.dart have been modified/added on top of v1.4.155.
