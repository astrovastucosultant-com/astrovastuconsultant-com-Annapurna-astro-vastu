# Build89 — D2 Matched Horoscope Results + Evidence %

- D2 main screen now shows only source rules that actually match reproducible horoscope conditions.
- Each matched result shows App Evidence Match % (not probability).
- Indu Lagna is calculated from the source kala algorithm.
- D1 wealth/cash/jewellery/property/inheritance rules are auto-checked where the supplied condition is reproducible.
- D4 is used as property confirmation.
- D16 is used as vehicle/comfort confirmation per user correction.
- Manduka Hora, Dasha and Gochar rules remain source-only when their exact source calculation/timing algorithm is unavailable.
- Unmatched/source-only D2 rules are moved to a collapsed Source Rules / Audit section.
- Result tap continues to Rule Inspection; rule detail continues to remidi.pdf-backed remedy support.
