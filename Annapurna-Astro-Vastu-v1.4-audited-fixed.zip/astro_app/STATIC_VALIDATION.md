# Static validation notes — v1.4

- Flutter target: 3.47.5
- Dart target: 3.13.4
- App version: 1.4.0+5
- Swiss Ephemeris wrapper: `sweph 4.1.0+2.10.3`
- Sharing: `share_plus 13.3.0`
- Preferences: `shared_preferences 2.5.5`

Checked in source:

- Android INTERNET permission exists.
- Android package/application id is `com.annapurna.astrovastu.consultancy`.
- App startup no longer depends on successful Swiss Ephemeris initialization.
- Swiss Ephemeris initialization is single-flight guarded.
- Birth timezone conversion uses explicit offset minutes.
- Sidereal mode is selected using `SiderealMode` constants.
- Moshier + sidereal + speed flags are used for planetary positions.
- Sidereal houses are used for Ascendant calculation.
- Longitude DMS output carries correctly across sign boundaries.
- Timezone display supports fractional offsets in HH:MM form.
- Place-search failure has a manual-coordinate fallback.
- New Place entries persist locally and can be selected later.
- Event Timing accepts place search, Saved Places and New Place.
- Event Timing report can be copied, stored locally and shared.
- Tests cover the main screen, timezone conversion, saved-place persistence, longitude formatting and timezone formatting.

The local repair environment does not contain the Flutter SDK, so `flutter analyze`, `flutter test`, and `flutter build apk` could not be executed here. The included GitHub Actions workflow performs those steps when GitHub service access is available.
