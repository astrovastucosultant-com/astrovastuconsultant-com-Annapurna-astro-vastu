# Build 24

Ashtakavarga usability update.

- Added a global “అష్టకవర్గ timing — ఎలా ఉపయోగించాలి” guide.
- Added per-planet “ఎలా ఉపయోగించాలి” button.
- Guide explains event-promise → dasha → BAV/SAV → transit → direction → Kakshya → source-arithmetic workflow.
- Shows current strongest/weakest direction and current Top-3 1–12 support indices dynamically.
- Added planet-wise practical usage context for Sun, Moon, Mars, Mercury, Jupiter, Venus and Saturn.
- Added Green/Amber/Red/Blue/Grey legend.
- No core Ashtakavarga arithmetic formulas changed.
