# Build 26 — AV-008/AV-009 Source-Disciplined Event-Year Trace

## Added

- AV-008 / AV-009 Event Year / Age layer is no longer a blank source-pending card.
- For Sun through Saturn the app now shows, only to the extent supported by the supplied source summary:
  - Lagna sign number and natal planet sign number,
  - Lagna → planet zodiacal audit path,
  - planet → Lagna zodiacal audit path,
  - the selected planet's raw BAV plus SAV at every sign on both paths.
- The app clearly separates **source-supported inputs** from the still-missing **final age operator/conversion**.
- AV-009 repeat windows remain disabled until the final AV-008 age arithmetic and recurrence convention are explicitly supplied/verified.

## Source discipline

- No final age/year is guessed.
- No recurrence interval is guessed.
- The path values are an audit trace of available BAV/SAV source inputs, not a claim that a particular subtotal formula is classical.

## Version

- 2.12.0+26
