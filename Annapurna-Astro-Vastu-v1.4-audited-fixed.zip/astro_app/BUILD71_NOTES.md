# Build71 — D10 Amsha Devata Work-Flow Modifier

Version: `1.4.71+71`

## User-final correction
- Amsha Devata does **not** create a new profession.
- Amsha Devata does **not** add points to Career Suitability %.
- Amsha Devata does **not** change profession ranking/ties.
- Amsha Devata modifies the **flow of work** of profession families already selected by the D10 evidence engine.

## UI
- Career Suitability card now shows only profession families + Evidence Match %.
- Nature + Amsha Devata card now shows the Devata-specific Work Flow modifier.
- Added `FINAL — వృత్తి + పని విధానం / Career Interpretation` card combining top matched professions with Devata work-flow.

## Work-flow mapping
- Indra: authority/public responsibility/command.
- Agni: energy/initiative/fast action/active execution/operations.
- Yama: discipline/rules/accountability/compliance.
- Rakshash: private/unconventional/investigative/secrecy.
- Varuna: external/foreign connections/movement/networks.
- Vayu: mobile/communicative/flexible/knowledge-sharing.
- Kubera: resource/money/calculation/financial management.
- Ishana: knowledge/guidance/advisory/values/mentoring.
- Brahma: creation/foundation-building/development.
- Ananta: expansion/scalability/wide/global reach.
