# Build 21 — Ashtakavarga Jataka Results

- Adds source-driven Ashtakavarga interpretation cards.
- Results are grouped in order; tap Result to open Rule → Jataka inspection → Source.
- Green/red/amber/grey status.
- Adds 1–12 house SAV strength, income-expense, Poshaka, Swatantra, Raja/wealth/education/relationship caution rules that are exactly computable from the current SAV engine.
- Advanced Shodhana/Pinda/Transit/Ayurdaya rules are source-gated and not fabricated until their arithmetic modules are implemented.
- Version 2.7.0+21.
