# Build 33 — V49 + V50 Native Integration

- Kept Build32 source-linked Varga Result → Rule → Remedy flow (V49 behavior).
- Added V50 source-rulebook registry directly into the Flutter Varga module.
- Added D1 source registry for S.K. Mehta, Brighu Nadi, Avayava Roga, and Medical Roga rulebooks.
- Added topic-wise source-only cross-links under D2/D3/D4/D7/D9/D10/D16/D24.
- Source-only entries never fabricate positive/negative verdicts when source-specific strength/aspect arithmetic is not implemented.
- Health rules are displayed only as traditional astrology indicators; no diagnosis, medicine, or treatment is generated.
- V49 and V50 HTML reference files are bundled under assets/source_reference for audit/reference.
- App version bumped to 2.19.0+33 so Android can install it as an update over Build32.
