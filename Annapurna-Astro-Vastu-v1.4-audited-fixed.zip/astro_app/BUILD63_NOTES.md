# Build 63 — D24 Full Education Summary

Version: 1.4.63+63

Changes:
- Keeps the already-working Saved Charts card-tap + Open/Edit flow from Build61.
- Adds D24 Final Education Summary with overall result, desire, dedication, learning capacity, early learning, schooling, graduation/stream, education nature, primary/secondary field handling, higher studies, research, hostel/away, foreign study, break, resume, formal education end caution and timing boundary.
- Adds source-safe Sun and Moon conjunction checks.
- Adds Rahu/Ketu 5H break/resume checks.
- Adds conservative 12L education-lord association check for hostel/away and 9L+12L direct link check for foreign education.
- Keeps subject case-patterns source-only where Education.pdf does not provide a universal formula.
- Detailed D24 result cards display Rule ID and Source.
- Matched-only policy remains; unmatched/source-only rules do not appear as final predictions.
- Education timing is not invented from D24 alone; Dasha/Antardasha/Transit is required.
