# Build 16

- Keeps Build 15 verified calculations unchanged.
- Makes Jamakola, Tajik, BCP, BSP and BNN section cards interactive.
- Every pending-system section now expands on tap and shows working status.
- Birth-chart calculation context is loaded in each system and can be copied.
- No unverified astrological rules or fabricated results are added.
- Exact Rule → Calculation → Result engines will be activated after supplied source rules are verified.
