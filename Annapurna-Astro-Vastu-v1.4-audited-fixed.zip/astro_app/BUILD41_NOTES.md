# Build 41

- Added tap-to-result flow for every Jaimini Chara Mahadasha and Antardasha period.
- Tapping a Mahadasha evaluates all 12 Antardashas for Marriage, Career, Children, Property, Wealth, Education, and Foreign events, showing strongest AD score and supportive AD count.
- Tapping an Antardasha evaluates all seven event groups for that specific AD and shows score/band.
- Tapping an event result continues to the existing 100-point Rule audit; tapping a rule shows condition, matched/not matched, reason, remedy note, and source.
- Period summaries remain app decision-support scores, not classical probabilities.
- No new Jaimini remedy or unsupported source rule was invented.
