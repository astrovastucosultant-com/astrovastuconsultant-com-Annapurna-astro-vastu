# Annapurna Astro Vastu — Flutter app

This updated project is built from the supplied `Annapurna-current.zip` and fixes the main missing/broken paths that were present in that archive.

## Included now

- Birth name, date and exact time input including **seconds**
- Timezone offset input (India default: **UTC +5.5**)
- Village/place search using OpenStreetMap Nominatim
- Android internet permission required by place search
- **New Place** manual entry for village name + latitude + longitude
- **Saved Places** persistence, selection and deletion for custom places
- Editable latitude / longitude fields
- Ayanamsa selector: Lahiri, Raman, KP/Krishnamurti
- Swiss Ephemeris Flutter integration through the `sweph` package
- Sidereal planetary positions for Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu and Ketu
- Sidereal Ascendant / Lagna calculation
- Rasi grid and readable planetary-position report
- Exact local and UTC birth time handling
- Event Timing window with Start/End date, time and seconds
- Place search + Saved Places + **New Place** are also available inside Event Timing
- Exact event-window duration in hours/minutes/seconds
- Event Timing report with Copy, Save and Share
- Swiss Ephemeris boundary calculations for Event Start and Event End
- Local report Save, Saved Reports list, Copy and Share

## Important rule-engine note

The ZIP supplied for this repair did **not** contain the previously described verified Jaimini / Parashara / S.K. Mehta / KP event-rule database. The old README mentioned those modules, but the actual files were absent. Therefore this build does not invent event probabilities or favorable percentages. It shows real astronomical calculations and leaves rule-derived percentages unavailable until the verified rules are added.

## Calculation mode

The app uses the Swiss Ephemeris C engine through `sweph`. The current calculation service deliberately uses **Moshier ephemeris mode** inside Swiss Ephemeris so that planetary calculation does not depend on separately downloaded `.se1` data files. Sidereal mode and the selected ayanamsa are applied.

## Version

Current repaired package: **1.4.0+5**

## Android build

From the project folder:

```bash
flutter clean
flutter pub get
flutter run
```

For a release APK:

```bash
flutter build apk --release
```

The Flutter SDK path in `android/local.properties` is machine-specific, so that file is intentionally not included in the cleaned archive. Flutter recreates it for the local build environment.

## Licensing

Swiss Ephemeris and the `sweph` package use the AGPL open-source path unless an applicable Swiss Ephemeris Professional License is held. Review `LICENSE-ANNAPURNA-AGPL-NOTICE.md` and the package/upstream license before distribution.

## v1.4 audit improvements

- App UI now starts immediately; Swiss Ephemeris initializes lazily when a chart calculation is requested.
- Swiss Ephemeris initialization is guarded so duplicate simultaneous initialization is avoided.
- Zodiac degree/minute/second formatting now correctly carries 29°59′59.5″ into the next sign.
- Timezone display uses `UTC±HH:MM` formatting.
- Event Timing now includes New Place, saved custom place persistence, and Copy/Save/Share report actions.
- Added formatter tests for sign-boundary rounding and fractional timezone offsets.
