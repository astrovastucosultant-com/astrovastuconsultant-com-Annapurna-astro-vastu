# Build 13 — Systems Hub

- Added Systems tab.
- Vimshottari Mahadasha + Antardasha core from Moon nakshatra.
- Jaimini core: 7 Chara Karakas, Karakamsa, Rashi Drishti, Lagna Argala/Virodha.
- KP core: planetary Sign Lord / Star Lord / Sub Lord and source-based event house groups.
- Jamakola and Tajik module slots are visible but do not invent prediction rules without verified source material.
- Existing D1–D60, Ashtakavarga, branding and Build 12 chart UI retained.
