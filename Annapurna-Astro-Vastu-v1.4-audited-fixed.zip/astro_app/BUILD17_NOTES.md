# Build 17

- Keeps Build 16 system menu and verified calculations unchanged.
- Removes zodiac/rashi names from user-facing chart and system displays.
- Uses rashi numbers 1-12 instead.
- Keeps Lg, planets, degrees and house numbers visible.
- Internal zodiac indexing and all calculation logic remain unchanged.
- Jamakola, Tajik, BCP, BSP and BNN remain interactive/source-gated until the user supplies verified rules.
