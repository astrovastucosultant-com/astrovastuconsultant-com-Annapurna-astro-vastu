# Build83 — D1+D3 Organ Consolidation + Layered Health Evidence

- Consolidates duplicate D1+D3 organ cards into one client-facing organ card.
- Multiple contributing planets/signs are shown as supporting evidence instead of duplicate cards.
- Separates D1+D3 Organ Match %, D27 Severity Confirmation %, Khara/22D/64N direct-organ %, and Final Astrology Evidence %.
- 22nd Drekkana and 64th Navamsa affect an organ card only when there is a direct planet/sign-lord link to that organ evidence.
- Global Khara context remains visible for audit but does not inflate an unrelated organ score.
- Existing D27 visual, timing, Panchadha Maitri, Bhamsa Devata and source-backed remedies are preserved.
- Astrology evidence percentages are not medical probabilities; medical treatment remains primary.
