# Build 69 — D24 Stage-wise Education Environment

Version: 1.4.69+69

## D24 Education changes
- Education Continuity remains a separate engine from Education Field selection.
- 4H = School / Intermediate stage.
- 9H = Degree / B.Tech stage.
- 2H = PG stage.
- 7H = Post-PG stage.
- Hostel / away from home, Foreign Education, Break / Interruption, and Resume-after-break are now evaluated and displayed inside the relevant education stage instead of as detached global cards.
- Research / deeper study remains a separate supporting layer.
- Education Field remains the user-defined 5H start +15° -> Nakshatra -> Nakshatra lord -> D24 lord sign -> sign/occupant/aspect education evidence -> nature filter -> suitability % flow.
- Result tap continues to expose Rule ID -> Result -> Source; Rule/inspection shows the calculation chain.
