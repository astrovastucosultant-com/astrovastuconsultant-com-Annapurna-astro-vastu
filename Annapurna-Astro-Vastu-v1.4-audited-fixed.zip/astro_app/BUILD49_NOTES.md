# Build 49 — D10 Profession Coverage Expansion

Version: 2.34.0+49

## Added
- Dedicated D10 result cards for Astrologer / Jyotisha Practitioner.
- Astrology Consultant, General Consultant / Advisor, Priest / Spiritual Consultant.
- Skilled trades / plumber-electrician service category.
- Skilled manual/service work, daily-wage/manual worker and farm/agricultural worker categories.
- Ishana Dashamsha Devata now supports consultant and astrology-consultant categories.

## Source boundary
- Astrologer categories reuse the existing supplied Profession Rules entries for Jupiter/Ketu astrology occupations.
- Consultant categories use the D10 special source description of Ishana as supporting priests, consultants, teachers and bankers.
- Skilled/manual worker categories use the D10 special Sixth House “service and servitude” examples plus the existing Saturn manual/service profession catalog.
- “Daily-wage / Manual Worker” is explicitly labelled as an app-derived source synthesis, not a verbatim standalone classical rule.
