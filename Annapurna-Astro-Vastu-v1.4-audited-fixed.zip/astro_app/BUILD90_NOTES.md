# Build90 — D2 Rule Evidence Audit (from Build89)

- All 58 supplied Dhana_Aasthi_Rules.pdf records retained in the D2 registry.
- Verified matched rules appear in client results; unmatched and unverified rules remain visible in the audit catalog with **different reasons**. No claim that a source rule is absent.
- Added seven D1/Indu rules for calculation: IN-005, IN-006, IN-010, IN-011, IN-012, IH-005 and IH-006. For IN-011, only the lord's house is shown, not an invented income career.
- 47 out of 58 source rules have a conservative horoscope condition checker (41 previous - 1 vague VH-002 + 7 new = 47); 11 source entries remain pending a verified formula/qualification. Check script `tools/verify_d2_catalog.py` for the current exact audited counts.
- Guarded debilitation, distinguished unclassified versus explicitly weak D4/D16 placements. Stopped treating Venus-not-strong as medium strength (VH-002).
- For DY-002, requires the three conjoined lords to be strong. PR-002 recognizes Jupiter/Venus/Mercury specifically and correctly prints branch-level evidence. PR-010 tests Jupiter **aspect**, not conjunction.
- Vehicle D16 confirmation requires natal vehicle/4th-house context; D4 stays property confirmation.
- Wealth-status labels (crorepati etc.), Manduka Hora construction, D2 Sun/Moon Hora definition, Gochar/Dasha timing are NOT fabricated.
- Existing remidi.pdf remedy routing is retained. Remedial suggestions are optional traditional practices, not empirical guarantees.
- Evidence match percentages are app rule/confirmation coverage indicators, not wealth probabilities.

## Notes on validation

This is a Dart/Flutter **source ZIP**, not an already compiled APK. The runtime environment does not include a Flutter SDK, so no successful Flutter build is claimed. Compile with Flutter 3.47.5, run the included tests, then create an APK using the project's BUILD_APK.md instructions.
