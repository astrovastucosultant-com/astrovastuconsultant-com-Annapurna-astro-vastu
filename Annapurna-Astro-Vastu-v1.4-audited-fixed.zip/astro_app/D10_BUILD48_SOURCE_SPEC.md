# D10 Build 48 Source Rule Specification

Primary source: user-supplied `D10 special.pdf`.

## Self-employed / Service
- D10-SE01 Gocharastha Saturn: exalted/own sign and not Trika-related -> self-employment tendency.
- D10-SE02 Agocharastha Saturn: debilitated / Rahu-Ketu / combust / planetary-war defeat / Trika relation -> service tendency.
- D10-SE03 Birth Ago -> D9/D10 Go: service to self-employment.
- D10-SE04 Birth Go -> D9/D10 Ago: self-employment to service.
- D10-SE05 Same state in D1/D9/D10: same stream continues.
- D10-SE06 Strong Saturn with Trika relation: source note for government/administrative-level job.
- D10-SE07 PP planets = Sun, Moon, Mars, Rahu; at least two influence Lagna/10H/1L/10L.
- D10-SE08 Five-planets sector rule with at least two PP planets.
- D10-SE09 3H/3L relation to 10H/10L supports independent profession.
Source: Chapter 04, printed pp.50-52 (uploaded PDF pages 1-3).

## Status
- D10-ST01 Kendra-Trikona lord relation via conjunction/aspect/exchange; repetition in D10 strengthens status.
- D10-ST02 Mahabhagya source conditions retained; final auto verdict requires sex + true day/night input.
- D10-ST03 Panch Mahapurusha is a status support layer when source conditions are available.
Source: Chapter 05, printed pp.93-96 (uploaded pages 6-9).

## Rise / Fame
- D10-R01 Promise: Birth status + D10 status.
- D10-R02 D10 Rajayoga.
- D10-R03 Upachaya 3/6/10/11 strength.
- D10-R04 Argala support.
- D10-R05 Capricorn emphasis.
- D10-R06 Vimshottari MD/AD repetition through D1/D9/D16/D10.
- D10-R07 Progress Yogini is source-listed but not auto-expanded without complete verified arithmetic.
- D10-R08 Chara Dasha is source-listed; Jaimini module remains the dedicated Chara engine.
Source: Chapter 06, printed pp.97-107 (uploaded pages 10-21).

## Career Graph / Timing
- D10-CS01 First earning promise in D1 and D10.
- D10-CS02 MD/AD links to 2/10/11; D10 adds Lagna.
- D10-FJ01 Foreign-job promise across D1+D10: 8L, 10H/10L, 9/12 and 3H change.
- D10-FJ02 Foreign timing: Dasha links to 9/10/12.
- D10-PR01 Promotion: higher post and/or higher salary; 10/11 plus 2, with D10 Lagna important.
- D10-JL01 Job-loss promise: 3/9/12 lords influencing 10H/10L.
- D10-JL02 Job-loss duration is shorter when MD supports job and adverse AD changes; longer when MD itself does not assure job.
- D10-TR01 Transfer: 3/9 change axis plus career/gain houses; D10 12H can indicate profession change.
- D10-RT01 Retirement: 3/9/12 activation.
- D10-RT02 5th lord can indicate forced retirement.
Source: Chapter 10, printed pp.173-205 (uploaded pages 22-53).

## Dashamsha Deities / Profession Support
- Ten deities: Indra, Agni, Yama, Rakshash, Varuna, Vayu, Kubera, Ishana, Brahma, Ananta.
- Odd/even sign degree order reverses.
- Lagna gives basic professional nature; 10th lord gives approach/career.
- Source profession meanings are used as supporting evidence, not a standalone deterministic occupation rule.
Source: printed pp.6-9 (uploaded pages 53-57).

## D10 Houses and 10th-lord placement
- 1H through 12H profession meanings and 10L placement examples are used as the profession-nature layer.
- Career rise/fall is read from D10 10H/10L and related support/obstruction.
Source: printed pp.11-35 (uploaded pages 58-82).

## Deliberate source boundaries
- The supplied D10 source does not provide a complete Nakshatra -> profession lookup table, so Build 48 does not invent one.
- Combustion / planetary-war status is not auto-used in Gocharastha/Agocharastha unless the calculation model supplies it.
- Mahabhagya is not given a final YES/NO without sex and true day/night state.
- Timing windows are source-rule windows, not guaranteed events.
