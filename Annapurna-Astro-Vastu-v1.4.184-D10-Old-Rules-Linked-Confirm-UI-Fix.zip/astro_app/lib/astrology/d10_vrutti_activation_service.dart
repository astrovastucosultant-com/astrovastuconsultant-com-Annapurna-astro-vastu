import '../models/birth_data.dart';
import 'astro_models.dart';
import 'astro_calculation_service.dart';
import 'd10_career_service.dart';
import 'd10_vrutti_rule_registry.dart';
import 'dasha_service.dart';
import 'varga_service.dart';

/// Strict, auditable monthly convergence of (1) natal D1->D10 profession
/// confirmation, (2) Vimshottari mahadasha, (3) antardasha, and (4) actual
/// sidereal Jupiter AND Saturn transit. The month is an approximate sampling
/// window, not a promised appointment date or an empirically validated event.
class D10VruttiActivation {
  final DateTime month;
  final int ageYears;
  final String mahadasha;
  final String antardasha;
  final int jupiterSign;
  final int saturnSign;
  final List<String> evidence;
  const D10VruttiActivation({
    required this.month,
    required this.ageYears,
    required this.mahadasha,
    required this.antardasha,
    required this.jupiterSign,
    required this.saturnSign,
    required this.evidence,
  });
}

class D10VruttiActivationService {
  // Identical transit month + ayanamsa across rules is computed only once.
  static final Map<String, Future<({int guru, int shani})>> _transitCache = {};

  static int ageOn(DateTime born, DateTime date) {
    var age = date.year - born.year;
    if (date.month < born.month ||
        (date.month == born.month && date.day < born.day)) age--;
    return age;
  }

  static bool _aspectsSign(String planet, int from, int target) {
    final diff = (target - from + 12) % 12;
    if (diff == 0 || diff == 6) return true;
    if (planet == 'Jupiter') return diff == 4 || diff == 8;
    if (planet == 'Saturn') return diff == 2 || diff == 9;
    return false;
  }

  static bool transitReachesCareerSign(String planet, int sign,
      Set<int> targets) =>
      targets.any((target) => _aspectsSign(planet, sign, target));

  /// Source says the dasha must include the natal confirmed planet. The other
  /// dasha level must also have a D10 profession role (not just any planet).
  static bool dashaSupports({
    required String mainPlanet,
    required List<String> professionPlanets,
    required String d1TenthLord,
    required String d10TenthLord,
    required String mahadasha,
    required String antardasha,
  }) {
    if (mainPlanet.isEmpty) return false;
    if (mahadasha != mainPlanet && antardasha != mainPlanet) return false;
    final careerLords = <String>{mainPlanet, d1TenthLord, d10TenthLord,
      ...professionPlanets};
    return careerLords.contains(mahadasha) && careerLords.contains(antardasha);
  }

  static Future<({int guru, int shani})> _transitAtMonth(
      BirthData data, DateTime sample) {
    final key = '${data.ayanamsa.name}-${sample.year}-${sample.month}';
    return _transitCache.putIfAbsent(key, () async {
      // Swiss Sidereal mode is global; deliberately calculate sequentially.
      final guru = await AstroCalculationService.calculatePlanetAtUtc(
        utc: DateTime.utc(sample.year, sample.month, 15, 6),
        planetName: 'Jupiter', ayanamsa: data.ayanamsa,
      );
      final shani = await AstroCalculationService.calculatePlanetAtUtc(
        utc: DateTime.utc(sample.year, sample.month, 15, 6),
        planetName: 'Saturn', ayanamsa: data.ayanamsa,
      );
      return (guru: guru.signIndex, shani: shani.signIndex);
    });
  }

  static Future<List<D10VruttiActivation>> findWindows({
    required AstroChartResult chart,
    required BirthData birthData,
    required D10VruttiRule rule,
    required bool professionConfirmed,
    DateTime? fromDate,
    int yearsAhead = 20,
    int maxWindows = 5,
  }) async {
    if (!professionConfirmed || rule.planets.isEmpty ||
        yearsAhead <= 0 || maxWindows <= 0) {
      return const <D10VruttiActivation>[];
    }
    final primary = rule.planets.first;
    // A confirmed profession must have its OWN main planet in natal tenth.
    if (!chart.planets.any((p) => p.name == primary) ||
        D10CareerService.d1House(chart, primary) != 10) {
      return const <D10VruttiActivation>[];
    }
    final birth = birthData.localDateTime;
    final d10 = VargaService.calculate(chart, 10);
    final d1Lord = D10CareerService.signLord(
        (chart.ascendantSignIndex + 9) % 12);
    final d10Lord = D10CareerService.signLord(
        (d10.ascendantSignIndex + 9) % 12);
    final birthPlanetSign = chart.planets.firstWhere(
      (p) => p.name == primary).signIndex;
    final targets = <int>{
      birthPlanetSign,
      (chart.ascendantSignIndex + 9) % 12,
      (d10.ascendantSignIndex + 9) % 12,
    };
    final system = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birth,
    );
    final now = fromDate ?? DateTime.now();
    final first = DateTime(now.year, now.month, 15);
    final output = <D10VruttiActivation>[];
    // One clearly disclosed midpoint sample per month; never invent days.
    for (var i = 0; i < yearsAhead * 12; i++) {
      final sample = DateTime(first.year, first.month + i, 15);
      if (sample.isBefore(now)) continue;
      if (ageOn(birth, sample) < 16 || ageOn(birth, sample) > 85) continue;
      final md = DashaService.periodAt(system.mahadashas, sample);
      if (md == null) continue;
      final ad = DashaService.periodAt(
          DashaService.subPeriodsFor(system, md), sample);
      if (ad == null || !dashaSupports(
          mainPlanet: primary,
          professionPlanets: rule.planets,
          d1TenthLord: d1Lord,
          d10TenthLord: d10Lord,
          mahadasha: md.lord,
          antardasha: ad.lord)) continue;
      final transit = await _transitAtMonth(birthData, sample);
      final guruOk = transitReachesCareerSign(
          'Jupiter', transit.guru, targets);
      final shaniOk = transitReachesCareerSign(
          'Saturn', transit.shani, targets);
      // Strict 3-way gate: MD + AD + corroborating Jupiter & Saturn transit.
      if (!guruOk || !shaniOk) continue;
      // Consecutive sample months in the same MD/AD are one activation window.
      if (output.isNotEmpty) {
        final previous = output.last;
        final prevMonthIndex = previous.month.year * 12 + previous.month.month;
        final thisMonthIndex = sample.year * 12 + sample.month;
        if (thisMonthIndex - prevMonthIndex == 1 &&
            previous.mahadasha == md.lord &&
            previous.antardasha == ad.lord) continue;
      }
      output.add(D10VruttiActivation(
        month: sample,
        ageYears: ageOn(birth, sample),
        mahadasha: md.lord,
        antardasha: ad.lord,
        jupiterSign: transit.guru,
        saturnSign: transit.shani,
        evidence: <String>[
          'జనన 10వ ప్రధాన గ్రహం: $primary → D10 వృత్తి Confirm',
          'వింశోత్తరి మహాదశ: ${md.lord} (${D10CareerService.formatDate(md.start)}–${D10CareerService.formatDate(md.end)})',
          'అంతర్దశ: ${ad.lord} (${D10CareerService.formatDate(ad.start)}–${D10CareerService.formatDate(ad.end)})',
          'గురు గోచార రాశి ${transit.guru + 1} → వృత్తి సంబంధిత రాశికి దృష్టి/యుతి',
          'శని గోచార రాశి ${transit.shani + 1} → వృత్తి సంబంధిత రాశికి దృష్టి/యుతి',
          'గోచారం నెల 15న గణించబడింది; నెల/వయసు సుమారు సూచన మాత్రమే.',
        ],
      ));
      if (output.length >= maxWindows) break;
    }
    return List<D10VruttiActivation>.unmodifiable(output);
  }
}
