import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/jaimini_complete_sutra_service.dart';
import 'package:astro_app/astrology/jaimini_extended_rule_engine.dart';

PlanetPosition planet(String name, double longitude) => PlanetPosition(
  name:name, shortName:name.substring(0, 2), longitude:longitude,
  latitude:0, speed:1,
);

double natalLongitudeForD9(int sign) {
  for (var degree=0.0;degree<360;degree+=0.5) {
    if (VargaService.signForLongitude(degree,9)==sign) return degree;
  }
  throw StateError('Missing Navamsa sign $sign');
}

JaiminiResult snapshot({int kl=0,int al=0,int a7=6,int ul=1}) {
  final padas=<JaiminiPadaRow>[
    for (var i=1;i<=12;i++) JaiminiPadaRow(
      padaNumber:i, sourceSignIndex:i-1, lord:'Sun',
      lordSignIndex:0, distance:1,
      padaSignIndex:i==1?al:i==7?a7:i==12?ul:i-1,
    ),
  ];
  final target=<int,List<int>>{
    for (var i=0;i<12;i++) i:
      (i%3==0?[4,7,10]:i%3==1?[3,6,9]:[2,5,8])
        .map((j)=>(i+j)%12).toList(),
  };
  return JaiminiResult(
    charaKarakas:const [JaiminiKaraka(code:'AK',planet:'Sun',effectiveDegree:12)],
    atmakaraka:'Sun', karakamsaSignIndex:kl, rashiDrishti:target,
    argalaFromLagna:const [], arudhaPadas:padas,
    applicableRules:const [], hasDegreeTie:false,
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('source-specific stone/brick house branches do not require one-planet confirmation', () {
    final mars=natalLongitudeForD9(3);
    final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[
        planet('Sun',2),planet('Mars',mars),planet('Ketu',mars+0.5),
        planet('Saturn',38),planet('Rahu',132),
      ]);
    final r=JaiminiExtendedRuleEngine.check('3.51',chart,snapshot());
    expect(r, isNotNull);
    expect(r!.calculated,isTrue);
    expect(r.matched,isNull);
    expect(r.evidence,contains('కుజ+కేతు: ఇటుక ఇల్లు'));
    expect(r.evidence,isNot(contains('శని+రాహు: రాతి ఇల్లు')));
  });

  test('relative UL and AL calculations use distinct reference signs', () {
    final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[planet('Sun',12)]);
    final r=JaiminiExtendedRuleEngine.check('6.11',chart,
      snapshot(al:0,a7:7,ul:2));
    expect(r!.matched,isTrue);
    expect(r.evidence,contains('సాపేక్ష స్థానం 8'));
  });

  test('conception predicates never use natal chart as conception chart', () {
    final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[planet('Sun',12)]);
    expect(JaiminiExtendedRuleEngine.check('13.10',chart,snapshot()),isNull);
    const rule=JaiminiCompleteSutraRule(id:'13.10',major:'ఆధాన',section:'13B',
      condition:'ఆధాన లగ్నం నుంచి 2వలో రవి',result:'గర్భ సూత్రం',
      source:'4.3',page:38,sourceKind:'సూత్రం');
    final audit=JaiminiCompleteSutraService.check(
      rule:rule,chart:chart,jaimini:snapshot());
    expect(audit.matched,isNull);
    expect(audit.evidence,contains('ఆధాన'));
  });

  test('KL seventh rule reports the observed planet sign in Telugu', () {
    final rahu = natalLongitudeForD9(5);
    final chart = AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[
        planet('Sun',12),planet('Rahu',rahu),
      ]);
    final result = JaiminiExtendedRuleEngine.check('3.63',chart,snapshot(kl:0));
    expect(result, isNotNull);
    expect(result!.matched, isFalse);
    expect(result.evidence, contains('7వ రాశి'));
    expect(result.evidence, contains('కాదు'));
    expect(result.evidence, isNot(contains('false')));
  });

  test('only Ketu in KL twelfth is a distinct measured deity branch', () {
    final ketu = natalLongitudeForD9(11);
    final chart = AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[
        planet('Sun',natalLongitudeForD9(1)),
        planet('Moon',natalLongitudeForD9(2)),
        planet('Mars',natalLongitudeForD9(3)),
        planet('Mercury',natalLongitudeForD9(4)),
        planet('Jupiter',natalLongitudeForD9(5)),
        planet('Venus',natalLongitudeForD9(6)),
        planet('Saturn',natalLongitudeForD9(7)),
        planet('Rahu',natalLongitudeForD9(8)),
        planet('Ketu',ketu),
      ]);
    final result = JaiminiExtendedRuleEngine.check('3.74',chart,snapshot(kl:0));
    expect(result, isNotNull);
    expect(result!.calculated, isTrue);
    expect(result.matched, isNull);
    expect(result.evidence, contains('కేవలం కేతువు'));
    expect(result.evidence, contains('AmK'));
  });

  test('Rahu plus Ketu never counts as Ketu-only', () {
    final twelfth = natalLongitudeForD9(11);
    final chart = AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[
        planet('Sun',natalLongitudeForD9(1)),
        planet('Rahu',twelfth),planet('Ketu',twelfth + 0.1),
      ]);
    final result = JaiminiExtendedRuleEngine.check('3.74',chart,snapshot(kl:0));
    expect(result!.evidence, contains('రాహువు →'));
    expect(result.evidence, isNot(contains('కేవలం కేతువు →')));
  });

  test('missing planets never establish Ketu-only', () {
    final chart = AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[
        planet('Sun',natalLongitudeForD9(1)),
        planet('Ketu',natalLongitudeForD9(11)),
      ]);
    final result = JaiminiExtendedRuleEngine.check('3.74',chart,snapshot(kl:0));
    expect(result!.matched,isNull);
    expect(result.evidence, contains('పూర్తి D9 గ్రహ సమాచారం లేదు'));
    expect(result.evidence, isNot(contains('కేవలం కేతువు →')));
  });

  test('JAI 8.5 must remain pending without all three longevity pairs', () {
    final chart = AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[planet('Sun',12)]);
    const rule = JaiminiCompleteSutraRule(id:'8.5',major:'ఆయుర్దాయం',
      section:'కక్ష్య నిర్ణయం',condition:'మూడు జతలు',result:'పట్టిక',
      source:'2.1 వ్యా',page:25,sourceKind:'వ్యాఖ్యానం');
    final result = JaiminiCompleteSutraService.check(rule:rule,
      chart:chart,jaimini:snapshot());
    expect(result.matched,isNull);
    expect(result.evidence,contains('హోరా లగ్నం'));
    expect(result.evidence,contains('96/64/32'));
  });

  test('all 514 source catalog rows remain intact', () async {
    final records=await JaiminiCompleteSutraService.load();
    expect(records.length,514);
    expect(records.map((r)=>r.id).toSet().length,514);
  });
}
