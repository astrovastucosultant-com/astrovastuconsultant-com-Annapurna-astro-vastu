import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../astrology/astro_models.dart';
import '../astrology/jaimini_service.dart';
import '../astrology/jaimini_complete_sutra_service.dart';

/// Dedicated, searchable 50-page Jaimini IF/THEN reference catalog.
/// All rules are visible; only explicitly implemented predicates may show a
/// chart match. Other source rules remain pending, never false confirmations.
class JaiminiCompleteSutraScreen extends StatefulWidget {
  final AstroChartResult chart;
  final JaiminiResult jaimini;

  const JaiminiCompleteSutraScreen({
    super.key,
    required this.chart,
    required this.jaimini,
  });

  @override
  State<JaiminiCompleteSutraScreen> createState() =>
      _JaiminiCompleteSutraScreenState();
}

class _JaiminiCompleteSutraScreenState extends State<JaiminiCompleteSutraScreen> {
  late final Future<List<JaiminiCompleteSutraRule>> _future;
  String _query = '';
  String _category = 'అన్ని అంశాలు';
  String _statusFilter = 'all';
  double? _minutesSinceLocalSunrise;
  final Map<String, JaiminiRuleCheck> _cachedChecks = {};
  final Set<String> _reviewedRuleIds = <String>{};
  bool _onlyUnchecked = false;
  bool _reviewReady = false;

  String get _reviewStorageKey => 'jaimini_review_v213_'
      '${widget.chart.julianDay.toStringAsFixed(6)}_'
      '${widget.chart.ascendantLongitude.toStringAsFixed(3)}';

  Future<void> _loadReviewChecklist() async {
    final key = _reviewStorageKey;
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getStringList(key) ?? <String>[];
    if (!mounted || key != _reviewStorageKey) return;
    setState(() {
      _reviewedRuleIds
        ..clear()
        ..addAll(saved);
      _reviewReady = true;
    });
  }

  Future<void> _setRuleReviewed(String id, bool reviewed) async {
    setState(() {
      if (reviewed) {
        _reviewedRuleIds.add(id);
      } else {
        _reviewedRuleIds.remove(id);
      }
    });
    final key = _reviewStorageKey;
    final snapshot = _reviewedRuleIds.toList()..sort();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(key, snapshot);
  }


  @override
  void initState() {
    super.initState();
    _future = JaiminiCompleteSutraService.load();
    _loadReviewChecklist();
  }

  JaiminiRuleCheck _check(JaiminiCompleteSutraRule rule) =>
      _cachedChecks.putIfAbsent(rule.id, () =>
          JaiminiCompleteSutraService.check(
            rule: rule,
            chart: widget.chart,
            jaimini: widget.jaimini,
            minutesSinceLocalSunrise: _minutesSinceLocalSunrise,
          ));

  @override
  void didUpdateWidget(covariant JaiminiCompleteSutraScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.chart != widget.chart ||
        oldWidget.jaimini != widget.jaimini) {
      _cachedChecks.clear();
      _reviewedRuleIds.clear();
      _reviewReady = false;
      _loadReviewChecklist();
    }
  }

  void _showRule(JaiminiCompleteSutraRule rule, JaiminiRuleCheck audit) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (context) => DefaultTabController(
        length: 3,
        child: SafeArea(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.85,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 12),
                Center(child: Container(
                  height: 4, width: 44,
                  decoration: BoxDecoration(
                    color: const Color(0xFF806F73),
                    borderRadius: BorderRadius.circular(4),
                  ),
                )),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 4),
                  child: Text('JAI-${rule.id} · ${rule.section}',
                    maxLines: 3, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                ),
                const TabBar(
                  labelColor: Color(0xFF832E46),
                  tabs: [
                    Tab(text: 'ఫలితం'),
                    Tab(text: 'పరిశీలన'),
                    Tab(text: 'పరిహారం'),
                  ],
                ),
                Expanded(child: TabBarView(children: [
                  ListView(padding: const EdgeInsets.all(20), children: [
                    Text(_statusText(audit),
                      style: TextStyle(fontWeight: FontWeight.w800,
                        color: _statusColor(audit), fontSize: 16)),
                    const SizedBox(height: 18),
                    if (audit.matched == true && !audit.calculated) ...[
                      const Text('ప్రాథమిక షరతుకు సంబంధించిన సాధ్యమైన ఫలితం',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 8),
                      Text(rule.result, style: const TextStyle(height: 1.55, fontSize: 17)),
                      const SizedBox(height: 12),
                      const Text('ఇది ప్రాథమిక షరతు సరిపోలిక మాత్రమే. ఇతర సూచికలు, దృష్టి, '
                          'బలం, దశలు పరిశీలించకుండా ఖచ్చితంగా జరిగే ఫలితంగా చెప్పరాదు.',
                        style: TextStyle(color: Color(0xFF226847), height: 1.45)),
                    ] else if (audit.calculated) ...[
                      const Text('జాతకం నుంచి లభించిన గణన',
                        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 8),
                      Text(audit.evidence, style: const TextStyle(height: 1.55)),
                      const SizedBox(height: 12),
                      const Text('గణన లభించింది; ఇది సంఘటన లేదా శుభ/అశుభ ఫలిత నిర్ధారణ కాదు.',
                        style: TextStyle(color: Color(0xFF316D87))),
                    ] else if (audit.matched == false) ...[
                      const Text('పరీక్షించిన షరతు ఈ జాతకానికి సరిపోలలేదు.',
                        style: TextStyle(color: Color(0xFF92505C),
                          fontWeight: FontWeight.w700, height: 1.5)),
                      const SizedBox(height: 8),
                      const Text('కాబట్టి మూలగ్రంథంలోని THEN ఫలితాన్ని జాతక ఫలితంగా చూపించడం లేదు. '
                          'ఇతర ప్రత్యామ్నాయ శాఖలు పూర్తిగా పరీక్షించకపోతే ఇంకా నిర్ణయం పెండింగ్ ఉండవచ్చు.',
                        style: TextStyle(height: 1.5)),
                    ] else ...[
                      const Text('వ్యక్తిగత ఫలితాన్ని ఇంకా గణించలేదు.',
                        style: TextStyle(fontWeight: FontWeight.bold, height: 1.5)),
                      const SizedBox(height: 8),
                      const Text('పరిశీలన ట్యాబ్‌లో మూల నియమం, ఇంకా కావలసిన ఆధారాలు చూడండి. '
                          'మూల IF–THENని నేరుగా ఈ జాతక ఫలితంగా చూపించడం లేదు.',
                        style: TextStyle(height: 1.5)),
                    ],
                  ]),
                  ListView(padding: const EdgeInsets.all(20), children: [
                    const Text('జాతక పరిశీలన',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                    const SizedBox(height: 10),
                    Text(audit.evidence, style: const TextStyle(height: 1.55)),
                    const SizedBox(height: 18),
                    const Text('PDFలోని మూల IF–THEN నియమం',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    Text('IF: ${rule.condition}',
                      style: const TextStyle(height: 1.5)),
                    const SizedBox(height: 10),
                    Text('THEN (గ్రంథంలోని ఫలితం): ${rule.result}',
                      style: const TextStyle(height: 1.5)),
                    const SizedBox(height: 10),
                    const Text('గ్రంథంలోని THEN అంటే ఈ జాతకంలో అది తప్పకుండా సంభవించిందని కాదు.',
                      style: TextStyle(color: Color(0xFF855E21), height: 1.45)),
                    const SizedBox(height: 20),
                    const Text('మూల ప్రమాణం',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text('అధ్యాయం.పాదం.సూత్రం (PDF సూచిక): ${rule.source}'),
                    Text('అంశం: ${rule.major}'),
                    Text('విభాగం: ${rule.section}'),
                    Text('అందించిన PDF పేజీ: ${rule.page} / 50'),
                    Text('వర్గం: ${rule.sourceKind}'),
                    const SizedBox(height: 14),
                    const Text('ఈ PDF తెలుగు IF–THEN సమాహారం. అసలు సంస్కృత '
                        'శ్లోకం, వ్యాఖ్యాన భేదాల స్వతంత్ర ధృవీకరణ ఇంకా పెండింగ్.',
                        style: TextStyle(color: Color(0xFF7B5A35))),
                  ]),
                  ListView(padding: const EdgeInsets.all(20), children: const [
                    Text('పరిహారం / మూలం',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                    SizedBox(height: 10),
                    Text('మీరు ఇచ్చిన 50 పేజీల జైమిని IF–THEN PDFలో '
                         'ఈ నియమానికి ప్రత్యేకంగా ధృవీకరించిన పరిహారం ఇవ్వలేదు. '
                         'అందువల్ల కల్పిత మంత్రం, పూజ లేదా రత్న పరిహారం ఇవ్వడం లేదు.',
                         style: TextStyle(height: 1.5)),
                    SizedBox(height: 12),
                    Text('ప్రత్యేక పరిహార మూలగ్రంథం అనుసంధానించినప్పుడు '
                         'మూలం, షరతు, పరిహార విధానం చూపించవచ్చు.',
                         style: TextStyle(height: 1.5)),
                  ]),
                ])),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _statusText(JaiminiRuleCheck check) =>
      check.calculated ? 'గణన / ఆధార పరిశీలన మాత్రమే · తుది ఫలితం కాదు' :
      check.matched == null ? 'పూర్తి షరతుల పరిశీలన పెండింగ్' :
      check.matched! ? 'పరీక్షించిన ప్రాథమిక షరతు సరిపోయింది · తుది ఫలితం కాదు' :
      'పరీక్షించిన షరతు సరిపోలేదు · ఇతర సూచికలు వేరుగా పరిశీలించాలి';

  Color _statusColor(JaiminiRuleCheck check) =>
      check.calculated ? const Color(0xFF316D87) :
      check.matched == null ? const Color(0xFF806356) :
      check.matched! ? const Color(0xFF117349) :
      const Color(0xFF92505C);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('జైమిని సంపూర్ణ నియమాలు')),
      body: FutureBuilder<List<JaiminiCompleteSutraRule>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text(
            'నియమాల జాబితాను తెరవలేకపోయాం: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final all = snapshot.data!;
          final categories = ['అన్ని అంశాలు',
            ...{for (final rule in all) rule.major}];
          final q = _query.trim().toLowerCase();
          final filtered = all.where((rule) {
            if (_category != 'అన్ని అంశాలు' && rule.major != _category) return false;
            if (q.isNotEmpty && !('${rule.id} ${rule.major} '
                 '${rule.section} ${rule.condition} ${rule.result} ${rule.source}')
                   .toLowerCase().contains(q)) return false;
            final check = _check(rule);
            if (_onlyUnchecked && _reviewedRuleIds.contains(rule.id)) return false;
            switch (_statusFilter) {
              case 'matched':
                if (check.calculated || check.matched != true) return false;
                break;
              case 'notMatched':
                if (check.calculated || check.matched != false) return false;
                break;
              case 'calculated':
                if (!check.calculated) return false;
                break;
              case 'pending':
                if (check.calculated || check.matched != null) return false;
                break;
            }
            return true;
          }).toList(growable: false);
          int displayRank(JaiminiRuleCheck c) {
            if (c.matched == true && !c.calculated) return 0; // green first
            if (c.matched == false && !c.calculated) return 1; // pink next
            if (c.calculated) return 2; // calculations
            return 3; // pending
          }
          filtered.sort((a, b) {
            final first = displayRank(_check(a)).compareTo(displayRank(_check(b)));
            if (first != 0) return first;
            final aKey = a.id.split('.').map((n) => int.tryParse(n) ?? 0).toList();
            final bKey = b.id.split('.').map((n) => int.tryParse(n) ?? 0).toList();
            for (var i = 0; i < aKey.length && i < bKey.length; i++) {
              final d = aKey[i].compareTo(bKey[i]);
              if (d != 0) return d;
            }
            return a.id.compareTo(b.id);
          });
          final checks = {for (final r in all) r.id: _check(r)};
          final matchedCount = checks.values.where((c) => c.matched == true && !c.calculated).length;
          final notMatchedCount = checks.values.where((c) => c.matched == false && !c.calculated).length;
          final calculatedCount = checks.values.where((c) => c.calculated).length;
          final pendingCount = all.length - matchedCount - notMatchedCount - calculatedCount;
          final reviewedCount = all.where((r) => _reviewedRuleIds.contains(r.id)).length;
          final reviewPercent = all.isEmpty ? 0 : (reviewedCount * 100 / all.length).round();
          final reviewedMatches = all.where((r) =>
            _reviewedRuleIds.contains(r.id) && _check(r).matched == true && !_check(r).calculated).length;
          final reviewedNonMatches = all.where((r) =>
            _reviewedRuleIds.contains(r.id) && _check(r).matched == false && !_check(r).calculated).length;
          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
              child: TextField(
                onChanged: (s) => setState(() => _query = s),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'అంశం / గ్రహం / ఫలితం / సూత్రం వెతకండి',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: DropdownButtonFormField<String>(
                value: _category,
                isExpanded: true,
                items: categories.map((name) => DropdownMenuItem(
                  value: name,
                  child: Text(name, overflow: TextOverflow.ellipsis),
                )).toList(),
                onChanged: (v) => setState(() => _category = v ?? 'అన్ని అంశాలు'),
                decoration: const InputDecoration(labelText: 'అంశాలవారీ విభాగం'),
              ),
            ),
            ExpansionTile(
              title: const Text('ప్రత్యేక లగ్నాలకు సూర్యోదయ సమాచారం (ఐచ్ఛికం)',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
              subtitle: Text(_minutesSinceLocalSunrise == null
                  ? 'స్థానిక సూర్యోదయం తెలియకపోతే 2.8–2.12, 2.15 పెండింగ్‌లో ఉంటాయి'
                  : 'సూర్యోదయం తర్వాత $_minutesSinceLocalSunrise నిమిషాలు · ఈ సంఖ్యను ధృవీకరించండి',
                style: const TextStyle(fontSize: 11)),
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
                  child: TextField(
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'జననానికి ముందు స్థానిక సూర్యోదయం నుంచి నిమిషాలు',
                      hintText: 'ఉదా: సూర్యోదయం 06:00, జననం 09:00 → 180',
                    ),
                    onChanged: (raw) {
                      final parsed = double.tryParse(raw.trim());
                      final valid = parsed != null && parsed.isFinite &&
                          parsed >= 0 && parsed < 1440 ? parsed : null;
                      setState(() {
                        _minutesSinceLocalSunrise = valid;
                        _cachedChecks.clear();
                      });
                    },
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: Text('సూర్యోదయం = జన్మస్థలానికి వర్తించే స్థానిక సూర్యోదయం. '
                    'జనన సమయం లేదా సూర్యోదయం ఊహించి ఇవ్వవద్దు. '
                    'సాధారణ సూర్యోదయ గణన లేకపోతే ఖాళీగా ఉంచండి. '
                    'ఈ లెక్కలు తుది సంఘటనల సమయం కావు.',
                    style: TextStyle(fontSize: 11, height: 1.4)),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
              child: Text(
                'నమోదైన నియమాలు ${all.length} · సరిపోయిన ప్రాథమిక షరతులు $matchedCount · '
                'సరిపోని పరీక్షలు $notMatchedCount\n'
                'గణన/ఆధారం మాత్రమే $calculatedCount · ఇంకా పెండింగ్ $pendingCount\n'
                'వ్యక్తిగత ఫలితాల సంపూర్ణ ధృవీకరణ ఇంకా పెండింగ్',
                style: const TextStyle(fontSize: 12.5, height: 1.5,
                  fontWeight: FontWeight.w600),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
              child: DropdownButtonFormField<String>(
                value: _statusFilter,
                isExpanded: true,
                decoration: InputDecoration(
                  labelText: 'పరిశీలన స్థితి · కనిపిస్తున్నవి ${filtered.length}/${all.length}',
                  border: const OutlineInputBorder(),
                ),
                items: [
                  DropdownMenuItem(value: 'all', child: Text('అన్ని నియమాలు (${all.length})')),
                  DropdownMenuItem(value: 'matched', child: Text('ప్రాథమిక షరతు సరిపోయినవి ($matchedCount)')),
                  DropdownMenuItem(value: 'notMatched', child: Text('షరతు సరిపోనివి ($notMatchedCount)')),
                  DropdownMenuItem(value: 'calculated', child: Text('గణన / ఆధార పరిశీలన మాత్రమే ($calculatedCount)')),
                  DropdownMenuItem(value: 'pending', child: Text('పెండింగ్ ($pendingCount)')),
                ],
                onChanged: (value) =>
                    setState(() => _statusFilter = value ?? 'all'),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 8),
              child: Card(
                margin: EdgeInsets.zero,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('✓ చెక్‌లిస్ట్ · పరిశీలించినవి $reviewedCount/${all.length} · $reviewPercent%',
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                    const SizedBox(height: 6),
                    LinearProgressIndicator(value: all.isEmpty ? 0.0 : reviewedCount / all.length,
                      minHeight: 6, backgroundColor: const Color(0xFFE7E3E3),
                      color: const Color(0xFF237349)),
                    const SizedBox(height: 7),
                    Text('ఆకుపచ్చ: $reviewedMatches/$matchedCount పరిశీలించారు   ·   '
                      'పింక్: $reviewedNonMatches/$notMatchedCount పరిశీలించారు',
                      style: const TextStyle(fontSize: 12, height: 1.45)),
                    Row(children: [
                      const Expanded(child: Text('చెక్ చేయనివి మాత్రమే చూపించు',
                        style: TextStyle(fontSize: 12))),
                      Switch(value: _onlyUnchecked,
                        onChanged: (value) => setState(() => _onlyUnchecked = value)),
                    ]),
                    const Text('ఈ % మీరు పరిశీలించిన నియమాల పురోగతి మాత్రమే; '
                      'జాతక ఫలితం సంభవించే అవకాశం కాదు. చెక్ పెట్టడం అంటే నియమాన్ని చదివానని మాత్రమే.',
                      style: TextStyle(fontSize: 11, color: Color(0xFF765F60), height: 1.4)),
                  ]),
                ),
              ),
            ),
            Expanded(child: ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (context, index) {
                final rule = filtered[index];
                final check = _check(rule);
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
                  decoration: BoxDecoration(
                    color: check.calculated ? const Color(0xFFF1F6F8) :
                      check.matched == true ? const Color(0xFFE9F7EE) :
                      check.matched == false ? const Color(0xFFFCECF2) :
                      const Color(0xFFF5F4F2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                  leading: Icon(
                    check.calculated ? Icons.calculate_outlined :
                    check.matched == true ? Icons.check_circle_outline :
                    check.matched == false ? Icons.cancel_outlined : Icons.menu_book_outlined,
                    color: _statusColor(check),
                  ),
                  title: Text('JAI-${rule.id} • ${rule.result}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${rule.section}\n${_statusText(check)} · PDF పేజీ ${rule.page}'),
                  isThreeLine: true,
                   trailing: Tooltip(
                     message: 'ఈ నియమం పరిశీలించాను (ఫలితం నిర్ధారణ కాదు)',
                     child: Checkbox(
                      value: _reviewedRuleIds.contains(rule.id),
                      onChanged: !_reviewReady ? null : (value) {
                        _setRuleReviewed(rule.id, value ?? false);
                      },
                     ),
                  ),
                  onTap: () => _showRule(rule, check),
                ));
              },
            )),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Text('✓ = పరీక్షించిన ప్రాథమిక సూచిక సరిపోయింది; × = పరీక్షించిన సూచిక సరిపోలేదు; '
                'కాలిక్యులేటర్ = గణన మాత్రమే; పుస్తకం = పెండింగ్; చెక్‌బాక్స్ = చదివిన నియమం. '
                'ఏ గుర్తూ తుది వ్యక్తిగత ఫలిత ధృవీకరణ కాదు.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, color: Color(0xFF755C62))),
            ),
          ]);
        },
      ),
    );
  }
}
