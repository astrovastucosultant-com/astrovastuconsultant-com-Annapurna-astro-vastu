import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_fresh_engine.dart';
import '../models/birth_data.dart';

class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  const BnnMasterPanel({super.key, required this.chart, required this.birthData});
  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

class _BnnBundle {
  final BnnFreshRelease release;
  final List<Map<String, dynamic>> catalog;
  const _BnnBundle(this.release, this.catalog);
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<_BnnBundle> _loading;
  bool _showBook = false;
  String _query = '';
  int _visible = 25;

  Future<_BnnBundle> _load() async {
    final release = await BnnFreshRelease.load();
    final raw = await rootBundle.loadString('assets/bnn/bnn_master_462_registry.json');
    final root = jsonDecode(raw) as Map<String, dynamic>;
    if (root['schema_version'] != 'BNN-462-REGISTRY-1.0' || root['total_rules'] != 462) {
      throw const FormatException('BNN source registry metadata mismatch');
    }
    final catalog = (root['rules'] as List).map((item) =>
      (item as Map).cast<String, dynamic>()).toList(growable: false);
    if (catalog.length != 462 ||
      catalog.map((r) => r['id']).toSet().length != 462) {
      throw const FormatException('BNN source registry entries mismatch');
    }
    return _BnnBundle(release, catalog);
  }

  @override
  void initState() {
    super.initState();
    _loading = _load();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<_BnnBundle>(
    future: _loading,
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return const _BnnInfo('BNN మూలసంపుటిని చదవలేకపోయాము. ఊహించిన ఫలితాలు చూపించడం లేదు.');
      }
      if (!snapshot.hasData) {
        return const Padding(padding: EdgeInsets.all(18), child: LinearProgressIndicator());
      }
      final bundle = snapshot.data!;
      final hits = BnnFreshEngine.evaluate(bundle.release, widget.chart);
      final topics = <String, List<BnnFreshHit>>{};
      for (final h in hits) {
        topics.putIfAbsent(h.rule.topic, () => <BnnFreshHit>[]).add(h);
      }
      final q = _query.trim().toLowerCase();
      final filtered = bundle.catalog.where((r) {
        if (q.isEmpty) return true;
        return ['id','original_id','topic','if_text','then_text','source']
            .any((field) => (r[field]?.toString().toLowerCase() ?? '').contains(q));
      }).toList(growable: false);
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Card(
          color: const Color(0xFFF3F5F8),
          child: Padding(
            padding: const EdgeInsets.all(13),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('BNN — కొత్త మూలాధార Rule Engine',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              Text('మూల నియమాలు ${bundle.catalog.length} • పూర్తి IF గుంపులు '
                '${bundle.release.rules.length} • జాతకానికి సరిపోయినవి ${hits.length}',
                style: const TextStyle(fontWeight: FontWeight.w600)),
              const SizedBox(height: 5),
              const Text('మూల నియమాల జాబితా, జాతకానికి వర్తించిన ఫలితాలు వేరు. '
                'గణనకు సరిపోయిన మూల నియమాలనే ఫలితాలుగా చూపుతున్నాం; ఇతర మూల రికార్డులు శోధన సూచికలో ఉంటాయి.',
                style: TextStyle(fontSize: 12.5, height: 1.45)),
              const SizedBox(height: 10),
              Wrap(spacing: 8, runSpacing: 4, children: [
                ChoiceChip(label: const Text('వర్తించిన ఫలితాలు'),
                  selected: !_showBook, onSelected: (_) => setState(() => _showBook = false)),
                ChoiceChip(label: const Text('మొత్తం 462 మూల నియమాలు'),
                  selected: _showBook, onSelected: (_) => setState(() => _showBook = true)),
              ]),
            ])),
        if (!_showBook) ...[
          if (hits.isEmpty)
            const _BnnInfo('ఈ జాతకానికి విడుదలైన పూర్తి IF షరతుల్లో ఫలితం లేదు. '
              'దీన్ని వ్యతిరేక ఫలితంగా భావించవద్దు.'),
          for (final group in topics.entries) ...[
            Padding(padding: const EdgeInsets.fromLTRB(9, 12, 9, 4),
              child: Text('${group.key} (${group.value.length})',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
            for (final hit in group.value) _ResultTile(hit: hit),
          ],
        ] else ...[
          Padding(padding: const EdgeInsets.fromLTRB(6, 10, 6, 6),
            child: TextField(
              decoration: const InputDecoration(
                hintText: 'Rule ID / గ్రహం / అంశం వెతకండి',
                prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
              onChanged: (value) => setState(() { _query = value; _visible = 25; }),
            )),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 9),
            child: Text('మూల సూచిక: ${filtered.length} రికార్డులు. 160 పేజీల కొత్త మూలంతో 119 పుటల మ్యాపింగ్ చేరింది. '
              'మూలం నిర్ధారణ కాని వాక్యాలు ఫలితాలుగా ప్రకటించబడవు.',
              style: const TextStyle(fontSize: 12, height: 1.4))),
          for (final record in filtered.take(_visible)) _SourceTile(record: record),
          if (filtered.length > _visible)
            OutlinedButton(
              onPressed: () => setState(() => _visible += 25),
              child: Text('ఇంకా చూపించండి (${filtered.length - _visible})'),
            ),
        ],
      ]);
    },
  );
}

class _SourceTile extends StatelessWidget {
  final Map<String, dynamic> record;
  const _SourceTile({required this.record});
  @override
  Widget build(BuildContext context) {
    final book = record['source']?.toString() ?? '';
    final page = record['pdf_page'];
    final ifText = record['if_text']?.toString() ?? '';
    final thenText = record['then_text']?.toString() ?? '';
    final printed = record['book_page'];
    final sourcePageLabel = '$book • PDF పుట ${page ?? 'లభించలేదు'}'
        '${printed is int ? ' • ముద్రిత పుట $printed' : ''}';
    return Card(
      child: ExpansionTile(
        title: Text(record['topic']?.toString() ?? '',
          style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('Rule: ${record['id']} • ${record['original_id']}'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        children: [
          ListTile(title: const Text('మూల IF'), subtitle: Text(ifText)),
          ListTile(title: const Text('మూల వాక్యంలో THEN'), subtitle: Text(thenText)),
          ListTile(title: const Text('మూలం / పుట'),
            subtitle: Text(sourcePageLabel)),
          if (record['source_collection'] == 'BNN_N_119')
            const ListTile(title: Text('160 పేజీల మూలగ్రంథం'),
              subtitle: Text('మూల పేజీ గుర్తించబడింది. అసలు వాక్యం, గ్రహ సంబంధ పద్ధతి '
                'పూర్తిగా ధృవీకరించి గణనలో చేర్చేవరకు ఇది పుస్తక సూచికలోనే ఉంటుంది.')),
          const ListTile(
            title: Text('గమనిక'),
            subtitle: Text('ఇది మూల నియమాల సూచిక. జాతక గణన ధృవీకరణ '
              'ఉన్న నియమం మాత్రమే వర్తించిన ఫలితాల ట్యాబ్‌లో కనిపిస్తుంది.')),
        ],
      ),
    );
  }
}

class _ResultTile extends StatelessWidget {
  final BnnFreshHit hit;
  const _ResultTile({required this.hit});
  @override
  Widget build(BuildContext context) {
    final rule = hit.rule;
    final bg = switch (rule.tone) {
      'adverse' => const Color(0xFFFCE8EE),
      'favorable' => const Color(0xFFE6F4E9),
      _ => const Color(0xFFFFF5E0),
    };
    return Card(
      color: bg,
      child: ExpansionTile(
        key: ValueKey('bnn-new-${rule.id}'),
        title: Text(rule.thenText, style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('${rule.title} • Rule ${rule.id}'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
        children: [
          ListTile(title: const Text('1. మూల నియమం / IF'),
            subtitle: Text('${rule.sourceIfText}\n'
              '${rule.source} • PDF పుట ${rule.pdfPage}\n'
              'మూల IDలు: ${rule.sourceIds.join(', ')}')),
          ListTile(title: const Text('2. జాతక పరిశీలన'), subtitle: Text(hit.evidence)),
          ListTile(title: const Text('3. ఫలితం'), subtitle: Text(rule.thenText)),
          if (rule.remedy.trim().isNotEmpty)
            ListTile(title: const Text('4. మూలాధారిత పరిహారం'),
              subtitle: Text(rule.remedy)),
        ],
      ),
    );
  }
}

class _BnnInfo extends StatelessWidget {
  final String text;
  const _BnnInfo(this.text);
  @override
  Widget build(BuildContext context) => Card(
    color: const Color(0xFFF6F1E9),
    child: Padding(padding: const EdgeInsets.all(18),
      child: Text(text, style: const TextStyle(height: 1.5))),
  );
}
