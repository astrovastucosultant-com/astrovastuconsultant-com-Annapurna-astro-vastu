# v1.4.381 — Automatic source matching

## ఉపయోగించడం
BNN → అంశం → వయస్సు/పరిధి → సూచనలు చూపించండి. సరిపోలిన నియమాలకు మూల గ్రహం, శని–గురు సాఫల్య పరిశీలన ఆటోమేటిక్‌గా కనిపిస్తాయి. Rule ID, గ్రహం, మూలపేజీ టైప్ చేయడం, ధృవీకరణ చెక్‌బాక్స్, ప్రత్యేక Calculate బటన్ తొలగించాం. ఇప్పటికే ఉన్న జీవితస్థితి ఎంపికలు ఎంచుకున్న కాలానికి సంబంధించినవే.

## అమలైన పరిధి
Existing 84 natal planet/sign rules still run through BnnRashiRuleService, preserving suppressed/OCR-sensitive rules, sanitized clauses and Mercury-only subconditions. The new JSON adds 20 explicit event/clause links from 13 of those rules: house/land, wealth/profit, business and education interruption. Links check source ID, source-predicate planet AND exact surviving clause; no keyword-only timing or arbitrary planet selection. Other natal source findings remain visible through the existing natal results and combinations. Existing nine Jupiter-relative entries and the independent Saturn-first-cycle/Rahu rule retain their existing evaluators; the new cross-reading does not manufacture timing anchors for them.

The natal rule's sole predicate planet is selected automatically as the calculation reference. Applying the supplied p31 safalya table to that reference is explicitly labelled an application cross-reading, NOT a newly authenticated event-month IF–THEN from the book. The source quality remains the existing user transcription, not a new claim of verbatim scan verification. The model does not establish empirical probabilities.

Post-marriage clauses are retained with a context note when marriage is unknown or not yet occurred; no transit score is produced for the unmet condition. They are NOT converted into wedding predictions. Existing approximate event age minima are context guards, not newly claimed book sutras. Static spouse appearance/nature is not assigned a date by the new links. Sensitive topics remain caution only. Positive clauses are green, education-interruption clauses pink; high fruition is not automatically favorable.

The source registry contains natal descriptions and case examples, not a complete authenticated event timing formula for all 29 topics. This release automates the rules and links described above; it does not claim complete autonomous event/month prediction for every topic. Source coverage gaps display without asking the user to invent a Rule ID or yoga planet.

## Performance / invalidation
One transit future per calendar checkpoint is shared across source findings/topics. Failed futures are evicted so retry can recalculate. Native findings, transit cache and automatic cards reset on chart/birth/context/age changes. Monthly checkpoints are start-inclusive/end-exclusive samples; labels are year-month, not event months. No percentile cutoff removes low support. BCP/BSP and Sun/Moon/event-lagna percentages are not invented or averaged into a total.

## Validation
168 new automatic source-link checks; 885 p31 table/boundary/catalog checks; 144 existing pure Dart checks: all 1,197 pass. New Flutter widget tests cover automatic scoring with no manual fields, missing context, and the complete actual planet/sign predicate → source link → transit UI pipeline including a false-IF control. Local Flutter SDK unavailable: widget tests/APK have not been run locally. Build workflow includes these tests plus prior BNN/D2/BCP/BSP/Jamakola regressions and builds APK only after they pass.

Full source and workflow extraction parity verified. v380 Jamakola hidden rashi-name rendering is preserved. Upload only build-bnn-v381.yml into .github/workflows; the workflow uses the existing v375 Delivery baseline. Full ZIP is for backup/manual builds.
