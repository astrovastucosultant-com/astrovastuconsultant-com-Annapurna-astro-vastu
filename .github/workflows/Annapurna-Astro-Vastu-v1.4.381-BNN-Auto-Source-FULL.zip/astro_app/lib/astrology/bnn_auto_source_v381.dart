import 'astro_models.dart';

/// An already evaluated, displayable source finding. The existing natal
/// evaluator owns OCR suppression and Mercury-only subconditions.
class BnnAutoFinding381 {
  final String id, planet, text, source, originalIf;
  const BnnAutoFinding381(
    this.id,
    this.planet,
    this.text,
    this.source,
    this.originalIf,
  );
}

class BnnAutoLink381 {
  final String ruleId, eventId, clause, reference, tone;
  final bool requiresMarried;
  const BnnAutoLink381(
    this.ruleId,
    this.eventId,
    this.clause,
    this.reference,
    this.requiresMarried,
    this.tone,
  );
  static List<BnnAutoLink381> parse(Map<String, dynamic> data) {
    if (data['schema'] != 'AAV-BNN-AUTO-SOURCE-381') {
      throw const FormatException('Invalid automatic source catalog');
    }
    final result = <BnnAutoLink381>[];
    final keys = <String>{};
    for (final row in data['links'] as List) {
      if (row['reference_policy'] != 'single_planet_source_predicate' ||
          row['kind'] != 'app_cross_reading_not_new_book_timing_sutra') {
        throw const FormatException('Unsupported source reference policy');
      }
      final r = BnnAutoLink381(
        row['rule_id'] as String,
        row['event_id'] as String,
        row['clause'] as String,
        row['reference_planet'] as String,
        row['requires_married'] as bool,
        row['tone'] as String,
      );
      if (!{'favorable', 'unfavorable', 'neutral'}.contains(r.tone) ||
          r.clause.trim().isEmpty ||
          !keys.add('${r.ruleId}/${r.eventId}/${r.clause}')) {
        throw const FormatException('Empty or duplicate source link');
      }
      result.add(r);
    }
    return List.unmodifiable(result);
  }
}

class BnnAutoMatch381 {
  final BnnAutoFinding381 finding;
  final BnnAutoLink381 link;
  final String? contextNote;
  const BnnAutoMatch381(this.finding, this.link, this.contextNote);
  bool get canSample => contextNote == null;
}

class BnnAutoSource381 {
  static List<BnnAutoMatch381> match({
    required List<BnnAutoFinding381> findings,
    required List<BnnAutoLink381> links,
    required String eventId,
    required double age,
    required double eventAgeFrom,
    required bool? married,
    required bool sensitive,
  }) {
    if (!age.isFinite || age < 0 || age > 120)
      throw ArgumentError('Invalid age');
    if (sensitive) return const [];
    final byId = {for (final f in findings) f.id: f};
    if (byId.length != findings.length)
      throw ArgumentError('Duplicate source findings');
    final result = <BnnAutoMatch381>[];
    for (final link in links.where((r) => r.eventId == eventId)) {
      final f = byId[link.ruleId];
      if (f == null ||
          f.planet != link.reference ||
          !f.text.contains(link.clause))
        continue;
      // An unmatched source / missing exact clause cannot be activated by age,
      // BCP/BSP coverage, a topic keyword or an arbitrary selected planet.
      final note = age < eventAgeFrom
          ? 'ఈ వయస్సులో జన్మ సూచన మాత్రమే; సంఘటన కాలంగా ప్రకటించలేదు.'
          : link.requiresMarried && married != true
          ? married == false
                ? 'వివాహానంతర షరతు వర్తించలేదు; జన్మ సూచనను ఉంచాం.'
                : 'వివాహానంతర షరతుకు జీవితస్థితి తెలియదు; జన్మ సూచనను ఉంచాం.'
          : null;
      result.add(BnnAutoMatch381(f, link, note));
    }
    return List.unmodifiable(result);
  }

  static void validateReferences(
    AstroChartResult chart,
    Iterable<BnnAutoMatch381> matches,
  ) {
    for (final reference in matches.map((m) => m.link.reference).toSet()) {
      final positions = chart.planets
          .where((p) => p.name == reference)
          .toList();
      if (positions.length != 1 ||
          !positions.single.longitude.isFinite ||
          positions.single.longitude < 0 ||
          positions.single.longitude >= 360) {
        throw ArgumentError('Invalid natal source reference $reference');
      }
    }
  }
}
