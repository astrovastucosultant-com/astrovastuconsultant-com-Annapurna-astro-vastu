import 'astro_models.dart';

/// JSON-backed source table, validated to this reviewed transcription.
class BnnSafalyaRules379 {
  final List<({String id, Set<int> positions, int percent, bool retrograde})>
  rows;
  const BnnSafalyaRules379._(this.rows);
  factory BnnSafalyaRules379.fromJson(Map<String, dynamic> raw) {
    if (raw['schema'] != 'AAV-BNN-SAFALYA-379' ||
        raw['source']?['printed_page'] != 31) {
      throw const FormatException('Invalid source catalog');
    }
    final rows = [
      for (final row in raw['rules'] as List)
        (
          id: row['id'] as String,
          positions: (row['positions'] as List).cast<int>().toSet(),
          percent: row['percent'] as int,
          retrograde: row['requires_retrograde'] as bool,
        ),
    ];
    final expected = [
      ({1}, 100, false),
      ({2, 5, 9}, 75, false),
      ({3, 7, 11}, 50, false),
      ({12}, 25, true),
    ];
    if (rows.length != 4 || rows.map((r) => r.id).toSet().length != 4) {
      throw const FormatException('Incomplete or duplicate source rules');
    }
    for (var i = 0; i < rows.length; i++) {
      final e = expected[i], r = rows[i];
      if (r.percent != e.$2 ||
          r.retrograde != e.$3 ||
          r.positions.length != e.$1.length ||
          !r.positions.containsAll(e.$1)) {
        throw const FormatException('Unreviewed source table change');
      }
    }
    return BnnSafalyaRules379._(List.unmodifiable(rows));
  }
}

/// User-supplied scan, printed p31. Percentages describe source-defined
/// yoga fruition strength, not calibrated event probabilities.
/// Never infer a yoga-giving planet from a keyword or a house-coverage ratio.
class BnnSafalya379 {
  final int relativeSign;
  final int? percent;
  final String explanation;
  const BnnSafalya379(this.relativeSign, this.percent, this.explanation);

  static BnnSafalya379 evaluate({
    required int yogaSign,
    required BnnSafalyaRules379 rules,
    required PlanetPosition transit,
  }) {
    if (yogaSign < 0 ||
        yogaSign > 11 ||
        !transit.longitude.isFinite ||
        transit.longitude < 0 ||
        transit.longitude >= 360 ||
        !transit.speed.isFinite) {
      throw ArgumentError('Invalid yoga reference or transit position/speed');
    }
    if (!{'Saturn', 'Jupiter'}.contains(transit.name)) {
      throw ArgumentError('This reviewed implementation covers Saturn/Jupiter');
    }
    final relative = (transit.signIndex - yogaSign + 12) % 12 + 1;
    for (final rule in rules.rows) {
      if (rule.positions.contains(relative) &&
          (!rule.retrograde || transit.retrograde)) {
        return BnnSafalya379(
          relative,
          rule.percent,
          relative == 1
              ? 'ప్రధాన యోగమిచ్చే గ్రహరాశిలో సంచారం'
              : relative == 12
              ? '12వ స్థానంలో వక్ర సంచారం'
              : 'యోగగ్రహం నుంచి $relativeవ స్థానంలో సంచారం',
        );
      }
    }
    return BnnSafalya379(
      relative,
      null,
      relative == 12
          ? '12వ స్థానంలో వక్రత షరతు వర్తించలేదు; ఈ పట్టిక నుంచి శాతం ఇవ్వలేదు'
          : '$relativeవ స్థానానికి ఈ పట్టికలో శాతం పేర్కొనలేదు',
    );
  }
}

class BnnAgeContext379 {
  static String theme(double age) {
    if (!age.isFinite || age < 0 || age > 120) {
      throw ArgumentError('Invalid age');
    }
    if (age < 12) return 'బాల్యం • ఆధార జీవనం • పెరుగుదల';
    if (age < 24)
      return 'విద్య • యౌవనం • స్నేహాలు • తగిన సందర్భంలో వివాహ పరిశీలన';
    if (age < 36) return 'వృత్తి • జీవితంలో స్థిరపడటం • సంపాదన';
    if (age < 48) return 'కుటుంబ నిర్వహణ • హోదా • గౌరవం';
    if (age < 60) return 'అనుభవం • ఆర్థిక స్థిరత్వం • కుటుంబ బాధ్యతలు';
    return 'వయోధిక నేపథ్యం • ఆరోగ్య జాగ్రత్త • ఆధ్యాత్మికత • సందర్భానుసారం కొత్త వృత్తి';
  }
}

/// Calendar checkpoints only. These are not ingress times or event months.
/// Include the window start and subsequent local month starts, end exclusive.
List<DateTime> bnnMonthSamples379(DateTime start, DateTime end) {
  if (!end.isAfter(start) || end.difference(start).inDays > 367) {
    throw ArgumentError('Expected an age window of at most one year');
  }
  final result = <DateTime>[start];
  var next = DateTime(start.year, start.month + 1);
  while (next.isBefore(end)) {
    result.add(next);
    next = DateTime(next.year, next.month + 1);
  }
  return List.unmodifiable(result);
}
