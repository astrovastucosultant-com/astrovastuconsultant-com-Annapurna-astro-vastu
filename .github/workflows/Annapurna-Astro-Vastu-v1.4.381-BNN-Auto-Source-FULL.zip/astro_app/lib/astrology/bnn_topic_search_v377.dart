import 'bnn_unified_evidence_v376.dart';

class BnnAgeRange377 {
  final int from, to;
  const BnnAgeRange377(this.from, this.to);

  /// Inclusive completed-age labels: 1–50 means ages 1 through 50.
  static BnnAgeRange377? parse(String text) {
    final match = RegExp(
      r'^\s*(\d{1,3})(?:\s*(?:-|–|—|to|నుంచి)\s*(\d{1,3}))?\s*$',
      caseSensitive: false,
    ).firstMatch(text);
    if (match == null) return null;
    final a = int.parse(match[1]!), b = int.parse(match[2] ?? match[1]!);
    return a < 0 || b > 100 || a > b ? null : BnnAgeRange377(a, b);
  }
}

/// Search vocabulary only. These labels are not new event predicates.
class BnnTopicSearch377 {
  static const aliases = <String, String>{
    'CHILD-HEALTH': 'ఆరోగ్యం health child childhood',
    'CHILD-EDU': 'విద్య చదువు education study school vidya chaduvu',
    'EDU-HIGHER': 'విద్య చదువు education study degree college vidya chaduvu',
    'EDU-BREAK': 'విద్య చదువు education study break gap vidya chaduvu',
    'EDU-FOREIGN':
        'విద్య చదువు విదేశం విదేశీ education study foreign vidya chaduvu',
    'CAREER-ENTRY': 'ఉద్యోగం ఉద్యోగ job career service udyogam',
    'CAREER-PROMOTION': 'ఉద్యోగం ఉద్యోగ పదోన్నతి job career promotion udyogam',
    'CAREER-CHANGE': 'ఉద్యోగం ఉద్యోగ బదిలీ job career transfer change udyogam',
    'CAREER-BUSINESS': 'వ్యాపారం business self employment vyaparam',
    'CAREER-RETIRE': 'ఉద్యోగం ఉద్యోగ job career retire retirement udyogam',
    'MARRIAGE': 'వివాహం పెళ్లి పెళ్ళి marriage wedding pelli vivaham',
    'MARRIAGE-REL': 'వివాహం పెళ్లి పెళ్ళి marriage relationship pelli vivaham',
    'CHILDREN': 'సంతానం పిల్లలు children childbirth santanam',
    'MOTHER': 'తల్లి mother amma',
    'FATHER': 'తండ్రి father nanna',
    'GRANDPARENTS': 'బంధువులు grandparents relatives',
    'RELATIVE-BEREAVEMENT': 'బంధువులు relatives caution',
    'WEALTH': 'ధనం డబ్బు wealth money dhanam',
    'PROFIT': 'ధనం డబ్బు లాభం profit income money dhanam',
    'SAVINGS': 'ధనం డబ్బు పొదుపు savings money dhanam',
    'LOSS': 'ధనం డబ్బు నష్టం అప్పులు loss debt money dhanam',
    'LAND': 'ఇల్లు భూమి ఆస్తి land property house illu',
    'HOUSE': 'ఇల్లు గృహం ఆస్తి house home property illu',
    'VEHICLE': 'వాహనం vehicle car',
    'FOREIGN-JOB': 'విదేశం విదేశీ ఉద్యోగం ఉద్యోగ foreign job career udyogam',
    'FOREIGN-TRAVEL': 'విదేశం విదేశీ ప్రయాణం foreign travel abroad',
    'HEALTH-ADULT': 'ఆరోగ్యం health caution',
    'ACCIDENT': 'ప్రమాదం accident caution',
    'LONGEVITY': 'ఆయుర్దాయం longevity caution',
  };
  static bool matches(UnifiedEvent376 event, String query) {
    final tokens = query
        .toLowerCase()
        .trim()
        .split(RegExp(r'\s+'))
        .where((s) => s.isNotEmpty);
    final haystack = '${event.title} ${event.id} ${aliases[event.id] ?? ""}'
        .toLowerCase();
    return tokens.every(haystack.contains);
  }

  // Conservative literal text lookup in chart-matched natal readings. It
  // does not prove an event, date, actor, or generalize a case-specific rule.
  static const resultTerms = <String, List<String>>{
    'CHILD-EDU': ['విద్య', 'చదువు'],
    'EDU-HIGHER': ['విద్య', 'చదువు'],
    'EDU-BREAK': ['విద్యలో విరామ', 'చదువులో ఆటంక'],
    'EDU-FOREIGN': ['విదేశీ విద్య', 'విదేశంలో చదువు'],
    'CAREER-ENTRY': ['ఉద్యోగ', 'వృత్తి'],
    'CAREER-PROMOTION': ['పదోన్నతి', 'ప్రమోష'],
    'CAREER-CHANGE': ['ఉద్యోగ మార్పు', 'బదిలీ'],
    'CAREER-BUSINESS': ['వ్యాపార'],
    'CAREER-RETIRE': ['పదవీ విరమణ'],
    'MARRIAGE': ['వివాహ', 'పెళ్లి', 'పెళ్ళి'],
    'MARRIAGE-REL': ['వివాహ', 'భార్య', 'భర్త'],
    'CHILDREN': ['సంతాన', 'పిల్లలు'],
    'MOTHER': ['తల్లి'],
    'FATHER': ['తండ్రి'],
    'GRANDPARENTS': ['తాత', 'అమ్మమ్మ', 'నాయనమ్మ'],
    'WEALTH': ['ధన', 'సంపాదన'],
    'PROFIT': ['లాభ', 'ఆదాయ'],
    'SAVINGS': ['పొదుపు', 'ధన నిల్వ'],
    'LOSS': ['ధన నష్ట', 'అప్పు'],
    'LAND': ['భూమి', 'ఆస్తి'],
    'HOUSE': ['ఇల్లు', 'ఇండ్లు', 'గృహ'],
    'VEHICLE': ['వాహన'],
    'FOREIGN-JOB': ['విదేశీ ఉద్యోగ'],
    'FOREIGN-TRAVEL': ['విదేశ', 'ప్రయాణ'],
  };
  static List<String> natalSentences(
    String text,
    Iterable<UnifiedEvent376> events,
  ) {
    final terms = {
      for (final event in events)
        if (!event.sensitive) ...?resultTerms[event.id],
    };
    return text
        .split(RegExp(r'[.।\n]'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty && terms.any(s.contains))
        .toSet()
        .toList();
  }

  static String summary(UnifiedEventEvidence376 e) {
    if (e.event.sensitive) return 'జాగ్రత్త అవసరం అనే పరిశీలన మాత్రమే.';
    if (e.sourceRules.isNotEmpty &&
        e.cautions.any((c) => c.contains('వయస్సు') || c.contains('ఇప్పటికే'))) {
      return 'మూల సూచన ఉంది; వయస్సు/గత సంఘటన సందర్భం వల్ల ఈ కాలాన్ని సంఘటన ఫలితంగా ప్రకటించలేదు.';
    }
    if (e.sourceRules.isNotEmpty)
      return 'మూల సూచన: ${e.sourceRules.map((s) => s.split("\n").last).toSet().join(" ")}';
    if (e.bothRelated)
      return 'శని–గురు ఇద్దరికీ ఈ అంశంతో భావసంబంధం ఉంది. పూర్తి సంఘటన ఫలితం నిర్ధారణ కాలేదు.';
    final names = [
      for (final c in [e.saturn, e.jupiter, e.bcp, e.bsp])
        if (c.available && c.hits(e.event).isNotEmpty) c.name,
    ];
    return names.isEmpty
        ? 'ఈ కాలానికి సంబంధం సరిపోలలేదు. తక్కువ స్కోరు కారణంగా సూచనను దాచలేదు.'
        : '${names.join(", ")} సంబంధం ఉంది; శని–గురు ఉమ్మడి సంబంధం సరిపోలలేదు. సంఘటన ఫలితం నిర్ధారణ కాలేదు.';
  }
}
