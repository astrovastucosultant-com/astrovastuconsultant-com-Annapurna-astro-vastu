import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_source_safalya_v379.dart';
import '../astrology/bnn_auto_source_v381.dart';
import '../astrology/bnn_unified_evidence_v376.dart';

class BnnSourceSafalyaPanel379 extends StatefulWidget {
  final AstroChartResult chart;
  final DateTime start, end;
  final UnifiedEvent376 event;
  final double age;
  final bool? married;
  final Future<List<BnnAutoFinding381>> findings;
  final Future<List<PlanetPosition>> Function(DateTime) loadTransits;
  final Future<Map<String, dynamic>>? catalog;
  final Future<BnnSafalyaRules379>? safalyaRules;
  const BnnSourceSafalyaPanel379({
    super.key,
    required this.chart,
    required this.start,
    required this.end,
    required this.event,
    required this.age,
    required this.findings,
    required this.loadTransits,
    this.married,
    this.catalog,
    this.safalyaRules,
  });
  @override
  State<BnnSourceSafalyaPanel379> createState() => _AutoSafalyaState381();
}

class _AutoResult381 {
  final List<BnnAutoMatch381> matches;
  final BnnSafalyaRules379 rules;
  final List<(DateTime, List<PlanetPosition>)> samples;
  const _AutoResult381(this.matches, this.rules, this.samples);
}

class _AutoSafalyaState381 extends State<BnnSourceSafalyaPanel379> {
  late Future<_AutoResult381> _future;
  int _generation = 0;
  static Future<Map<String, dynamic>> _json(String asset) async =>
      jsonDecode(await rootBundle.loadString(asset)) as Map<String, dynamic>;
  static const _names = {
    'Sun': 'సూర్యుడు',
    'Moon': 'చంద్రుడు',
    'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు',
    'Jupiter': 'గురు',
    'Venus': 'శుక్రుడు',
    'Saturn': 'శని',
    'Rahu': 'రాహువు',
    'Ketu': 'కేతువు',
  };
  @override
  void initState() {
    super.initState();
    _restart();
  }

  void _restart() {
    _future = _prepare(++_generation);
  }

  @override
  void didUpdateWidget(covariant BnnSourceSafalyaPanel379 old) {
    super.didUpdateWidget(old);
    if (!identical(old.chart, widget.chart) ||
        old.start != widget.start ||
        old.end != widget.end ||
        old.event.id != widget.event.id ||
        old.age != widget.age ||
        old.married != widget.married ||
        !identical(old.findings, widget.findings) ||
        !identical(old.catalog, widget.catalog) ||
        !identical(old.safalyaRules, widget.safalyaRules))
      _restart();
  }

  @override
  void dispose() {
    _generation++;
    super.dispose();
  }

  Future<_AutoResult381> _prepare(int generation) async {
    final target = widget;
    final data =
        await (target.catalog ??
            _json('assets/bnn/bnn_auto_source_links_v381.json'));
    final rules =
        await (target.safalyaRules ??
            _json('assets/bnn/bnn_safalya_source_v379.json')
                .then(BnnSafalyaRules379.fromJson));
    final matches = BnnAutoSource381.match(
      findings: await target.findings,
      links: BnnAutoLink381.parse(data),
      eventId: target.event.id,
      age: target.age,
      eventAgeFrom: target.event.ageFrom,
      married: target.married,
      sensitive: target.event.sensitive,
    );
    BnnAutoSource381.validateReferences(target.chart, matches);
    final samples = <(DateTime, List<PlanetPosition>)>[];
    if (matches.any((m) => m.canSample)) {
      for (final date in bnnMonthSamples379(target.start, target.end)) {
        if (!mounted || generation != _generation) break;
        final positions = await target.loadTransits(date);
        for (final name in ['Saturn', 'Jupiter']) {
          final row = positions.where((p) => p.name == name).toList();
          if (row.length != 1)
            throw StateError('Missing or duplicate transit $name');
          // Validate immediately; do not display partial or fabricated scores.
          BnnSafalya379.evaluate(
            yogaSign: 0,
            transit: row.single,
            rules: rules,
          );
        }
        samples.add((date, positions));
      }
    }
    return _AutoResult381(matches, rules, samples);
  }

  Widget _sample(
    _AutoResult381 result,
    BnnAutoMatch381 match,
    (DateTime, List<PlanetPosition>) sample,
  ) {
    final natal = widget.chart.planets.singleWhere(
      (p) => p.name == match.link.reference,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            '${sample.$1.year}-${sample.$1.month.toString().padLeft(2, '0')}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          for (final name in ['Saturn', 'Jupiter'])
            Builder(
              builder: (context) {
                final score = BnnSafalya379.evaluate(
                  yogaSign: natal.signIndex,
                  rules: result.rules,
                  transit: sample.$2.singleWhere((p) => p.name == name),
                );
                return Text(
                  '${_names[name]}: ${score.percent == null ? 'శాతం పేర్కొనలేదు' : '${score.percent}% సాఫల్య సూచిక'} • ${score.explanation}',
                );
              },
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.event.sensitive) return const SizedBox.shrink();
    return FutureBuilder<_AutoResult381>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError)
          return Row(
            children: [
              const Expanded(
                child: Text(
                  'ఆటో పరిశీలన పూర్తి కాలేదు; మూల డేటా లేదా గోచార గణనను మళ్లీ ప్రయత్నించండి.',
                ),
              ),
              IconButton(
                onPressed: () => setState(_restart),
                icon: const Icon(Icons.refresh),
              ),
            ],
          );
        if (!snapshot.hasData)
          return const Padding(
            padding: EdgeInsets.all(8),
            child: Text(
              'మూల నియమాలు–గ్రహస్థితులు ఆటోమేటిక్‌గా పరిశీలిస్తున్నాం…',
            ),
          );
        final result = snapshot.data!;
        if (result.matches.isEmpty)
          return const Padding(
            padding: EdgeInsets.all(8),
            child: Text(
              'ఈ అంశానికి ఆటో సాఫల్యం గణించగల జన్మ మూల నియమం సరిపోలలేదు. '
              'పైన వర్తించిన జన్మ సూచనలు, కింది స్వతంత్ర సైకిల్ ఆధారాలు చూడండి.',
            ),
          );
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            for (final match in result.matches)
              Card(
                color: match.link.tone == 'unfavorable'
                    ? const Color(0xFFFBE6ED)
                    : match.link.tone == 'favorable'
                    ? const Color(0xFFE1F2E8)
                    : null,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(
                        match.link.clause,
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        'ఆటో సరిపోలిక • మూల గ్రహం: ${_names[match.link.reference]}',
                      ),
                      if (match.contextNote != null) Text(match.contextNote!),
                      if (match.canSample && result.samples.isNotEmpty) ...[
                        _sample(result, match, result.samples.first),
                        ExpansionTile(
                          title: Text(
                            'మిగిలిన ${result.samples.length - 1} నెలల పరిశీలన',
                          ),
                          children: [
                            for (final sample in result.samples.skip(1))
                              _sample(result, match, sample),
                          ],
                        ),
                      ],
                      ExpansionTile(
                        title: const Text('మూల నియమం • జాతక పరిశీలన'),
                        children: [
                          Text(
                            '${match.finding.id}\n${match.finding.originalIf}\n${match.finding.source}',
                          ),
                          Text('పూర్తి జన్మ సూచన: ${match.finding.text}'),
                          const Text(
                            'ఈ జన్మ నియమంలోని ఒక్క గ్రహాన్ని గణన ఆధారంగా తీసుకుని పేజీ 31 సాఫల్య పట్టికతో యాప్ కలిపిన పరిశీలన. '
                            'ఇది పుస్తకంలో విడిగా ఇచ్చిన సంఘటన–నెల సూత్రం కాదు. ఎక్కువ శాతం శుభఫలితానికి హామీ కాదు. '
                            'నెలలు ఒక సమయానికి గోచార నమూనాలు; సంఘటన జరిగే నెల నిర్ధారణ కాదు. శాతాలు కలపలేదు.',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}
