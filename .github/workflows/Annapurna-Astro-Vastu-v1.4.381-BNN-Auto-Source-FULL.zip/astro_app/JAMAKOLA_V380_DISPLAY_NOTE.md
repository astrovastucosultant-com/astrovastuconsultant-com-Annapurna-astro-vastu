# v1.4.380 — Jamakola chart labels

రాశి చక్రాల గడుల్లో రాశి పేర్లు దాచాం. పై Jama Grahas, కింది Inner Grahas రెండింటికీ వర్తిస్తుంది. గ్రహాలు–డిగ్రీలు, U/ARU/KAV/L/Md గుర్తులు, రంగులు, రాశి గడుల క్రమం, స్థాన గణనలు మారలేదు. Bhava modeలో భావ సంఖ్యల గుర్తులు ఉంటాయి. వివరాల పట్టికల్లో రాశి పేర్లు తొలగించలేదు.

Repositoryలోని v379 workflow update నుంచి పూర్వ BNN మార్పులను పునరుద్ధరించి చేర్చాం. Janma/యోగగ్రహం manual source inspection పరిమితి v379లో ఉన్నట్లే ఉంటుంది; ఈ విడుదల automatic event timing పరిష్కారంగా చెప్పడం లేదు.

Validation: chart-label rendering diff reviewed; planet positions/mapping/markers unchanged; generated workflow source extraction and ZIP parity checked. Local Flutter SDK లేదు; UI rendering/APK tests స్థానికంగా నడపలేదు. Workflowలో existing Jamakola service/rule tests + v379 regression tests, తరువాత APK build ఉన్నాయి.

Upload: build-bnn-v380.yml మాత్రమే .github/workflows/లో upload చేయండి. Full ZIP backup/manual build కోసం.
