import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_planet_combination_service.dart';
import '../astrology/bnn_sensitive_result_display.dart';
import '../astrology/bnn_house_relation_service.dart';
import '../astrology/bnn_rashi_rule_service.dart';

/// BNN-only result-first combination view. No unverified result is labeled
/// a direct quote from R.G. Rao or a verified ancient source rule.
class BnnPlanetCombinationsPanel extends StatefulWidget {
  final AstroChartResult chart;
  const BnnPlanetCombinationsPanel({super.key,required this.chart});
  @override
  State<BnnPlanetCombinationsPanel> createState()=>
      _BnnPlanetCombinationsPanelState();
}

class _BnnPlanetCombinationsPanelState extends State<BnnPlanetCombinationsPanel> {
  late final Future<List<BnnCombinationMeaning>> catalog=
    BnnPlanetCombinationService.load();
  bool expanded=true;
  @override
  Widget build(BuildContext context) => FutureBuilder<List<BnnCombinationMeaning>>(
    future:catalog,builder:(context,snapshot) {
      if (snapshot.hasError) return Card(child:Padding(padding:const EdgeInsets.all(12),
        child:Text('BNN కాంబినేషన్ డేటా సమస్య: ${snapshot.error}')));
      if (!snapshot.hasData) return const Center(child:CircularProgressIndicator());
      final findings=BnnPlanetCombinationService.evaluate(
        chart:widget.chart,rules:snapshot.data!);
      final groups=BnnPlanetCombinationService.groups(
        chart:widget.chart,readings:findings);
      return Card(
        key:const ValueKey('bnn-combination-panel'),
        margin:const EdgeInsets.symmetric(vertical:10),
        color:const Color(0xFFF0F6F3),
        child:Padding(padding:const EdgeInsets.all(12),child:Column(
          crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          ListTile(contentPadding:EdgeInsets.zero,
            title:const Text('BNN — గ్రహ కాంబినేషన్లు & ఫలిత సూచనలు',
              style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),
            subtitle:Text('${findings.length} ప్రత్యేక గ్రహసంబంధాలు • '
              '${groups.length} త్రిగ్రహ/సమూహ కాంబినేషన్లు'),
            trailing:Icon(expanded?Icons.expand_less:Icons.expand_more),
            onTap:()=>setState(()=>expanded=!expanded)),
          const Text('ప్రతి సంబంధానికి అనుకూల, ప్రతికూల వ్యాఖ్యానాలు ఉంటాయి. '
            'ఇవి కారకత్వ ఆధారిత సంప్రదాయ సూచనలు; మూలగ్రంథంలోని '
            'పూర్తి IF–THEN శ్లోకంగా లేదా ఖచ్చిత సంఘటనగా పరిగణించరాదు.',
            style:TextStyle(fontSize:12,color:Color(0xFF52626B))),
          if (expanded) ...[
            if (groups.isNotEmpty) ...[
              const SizedBox(height:12),
              const Text('మూడు లేదా ఎక్కువ గ్రహాల సమూహాలు',
                style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
              for(final group in groups) _GroupTile(group:group),
            ],
            const SizedBox(height:12),
            const Text('ప్రతి ద్విగ్రహ సంబంధం — ఫలితం ముందుగా',
              style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
            if (findings.isEmpty)
              const Text('ఈ పద్ధతుల్లో అనుసంధానమైన గ్రహ జంటలు లేవు.'),
            for (final reading in findings)
              _CombinationReadingTile(key:ValueKey('combo-${reading.id}'),
                finding:reading),
          ],
        ])),
      );
    });
}

String _name(PlanetPosition p)=>
  BnnHouseRelationService.planetLabels[p.name]??p.name;
String _location(PlanetPosition p)=>
  '${_name(p)} ${BnnRashiRuleService.signs[p.signIndex]} '
  '${BnnRashiRuleService.dms(p.longitude)}';
String _relationLabel(BnnCombinationRelation type) {
  switch(type) {
    case BnnCombinationRelation.sameSign:return 'ఒకే రాశి సంయోగం';
    case BnnCombinationRelation.sameTrine:return '1–5–9 త్రికోణ సంబంధం';
    case BnnCombinationRelation.seventh:return 'ఎదురెదురు 7వ స్థానం';
    case BnnCombinationRelation.adjacent:return 'పక్క రాశి 2–12';
    case BnnCombinationRelation.thirdEleventh:return '3–11 సంబంధం';
  }
}

class _PositiveNegativeText extends StatelessWidget {
  final String text;
  final bool positive;
  const _PositiveNegativeText({required this.text,required this.positive});
  @override
  Widget build(BuildContext context) => Container(
    width:double.infinity,
    margin:const EdgeInsets.only(top:7),
    padding:const EdgeInsets.all(11),
    decoration:BoxDecoration(
      color:positive?const Color(0xFFDFF4E5):const Color(0xFFFDE8E8),
      border:Border.all(color:positive?const Color(0xFF6CA57A):const Color(0xFFC96C70)),
      borderRadius:BorderRadius.circular(10)),
    child:Text('${positive?'శుభ సూచన':'ప్రతికూల సూచన'}: '
      '${positive ? text : BnnSensitiveResultDisplay.publicResult(text)}',
      style:TextStyle(fontWeight:FontWeight.bold,fontSize:14.5,
        color:positive?const Color(0xFF155D37):const Color(0xFF9C2222))),
  );
}

class _CombinationReadingTile extends StatelessWidget {
  final BnnCombinationFinding finding;
  const _CombinationReadingTile({super.key, required this.finding});

  @override
  Widget build(BuildContext context) {
    final a = finding.first, b = finding.second;
    final m = finding.meaning;
    final relation = _relationLabel(finding.relation);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      color: Colors.white,
      child: ExpansionTile(
        key: ValueKey('combo-rule-${finding.id}'),
        tilePadding: const EdgeInsets.fromLTRB(11, 8, 11, 7),
        title: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('${_name(a)} + ${_name(b)} • $relation',
            style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          // Both traditional possibilities are ALWAYS shown, by design.
          _PositiveNegativeText(text: m.favorable, positive: true),
          _PositiveNegativeText(text: m.unfavorable, positive: false),
        ]),
        subtitle: const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Text('రెండు సూచనలు • టచ్ చేస్తే రూల్, పరిశీలన, ఫలితం, పరిహారం',
            style: TextStyle(fontSize: 11.5)),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 13),
        children: [
          _detail('1. రూల్ (IF–THEN)',
            'సూచన ID: ${finding.id}\n'
            'IF: జన్మ జాతకంలో ${_name(a)} మరియు ${_name(b)} '
            '$relationలో ఉంటే\n'
            'THEN: ఆ రెండు గ్రహాల కారకత్వాలకు అనుకూల, ప్రతికూల '
            'అంశాలను విడివిడిగా పరిశీలించాలి. '
            'ఇది సంబంధ-గుర్తింపు నియమం; వ్యక్తిగత సంఘటన-నిర్ధారణ నియమం కాదు.'),
          _detail('2. జాతక పరిశీలన',
            '${_location(a)}\n${_location(b)}\n'
            '${_name(a)} నుంచి ${_name(b)} ${finding.forwardHouse}వ రాశి. '
            'రాశి వ్యత్యాసం: ${finding.forwardDegrees.toStringAsFixed(2)}°.\n'
            'సంబంధం: ${finding.natalRelationMatched ? 'వర్తించింది (TRUE)' : 'వర్తించలేదు (FALSE)'}. '
            'ఈ TRUE సంబంధానికి మాత్రమే వర్తిస్తుంది; శుభం/అశుభం తప్పనిసరిగా '
            'జరుగుతుందని కాదు.'),
          _detail('3. ఫలితం — రెండు సూచనలు కొనసాగుతాయి',
            'పై ఆకుపచ్చ బాక్స్‌లో శుభ సూచన, ఎరుపు బాక్స్‌లో ప్రతికూల సూచన '
            'రెండూ ఉన్నాయి. రెండింటి కోసం ప్రత్యేకంగా ధృవీకరించిన '
            'జాతక IF–THEN షరతులు ప్రస్తుత డేటాలో లేవు; '
            'ఏది ప్రధానమో నిర్ధారించలేదు.'),
          _detail('4. పరిహారం',
            BnnSensitiveResultDisplay.spiritualRemedyFor(m.unfavorable)
              ?? 'ఈ వ్యాఖ్యానానికి మూలాధారంతో నిర్ధారించిన వ్యక్తిగత '
                 'పరిహార నియమం అనుసంధానించలేదు. కల్పిత పరిహారం చూపరు.'),
          _detail('5. డిగ్రీల క్రమం & మూలం',
            '${a.longitude <= b.longitude ? _name(a) : _name(b)} → '
            '${a.longitude <= b.longitude ? _name(b) : _name(a)} '
            '(రాశిచక్ర దీర్ఘాంశ క్రమం మాత్రమే; సంఘటనల కాలక్రమం కాదు).\n'
            '${m.sourceNote}. పేజీ-ప్రత్యేక మూల IF–THEN సూత్రం '
            'ఈ ఫలితానికి ధృవీకరించబడలేదు.\n'
            'సంబంధ పద్ధతి సూచనలు: ${m.sourceRefs.join(' ; ')}'),
        ],
      ),
    );
  }
}


/// One green and one red box per 3+ planet group. Each box shows all matching
/// pair-source indications; no new three-planet prediction is invented.
class _GroupOutcomeBox extends StatelessWidget {
  final List<BnnCombinationFinding> readings;
  final bool positive;
  const _GroupOutcomeBox({super.key, required this.readings,
    required this.positive});

  @override
  Widget build(BuildContext context) {
    final color = positive ? const Color(0xFF155D37) : const Color(0xFF9C2222);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 7),
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: positive ? const Color(0xFFDFF4E5) : const Color(0xFFFDE8E8),
        border: Border.all(color: positive
          ? const Color(0xFF6CA57A) : const Color(0xFFC96C70)),
        borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(positive ? 'శుభ సూచనలు' : 'ప్రతికూల సూచనలు',
            style: TextStyle(color: color, fontSize: 14.5,
              fontWeight: FontWeight.bold)),
          for (final r in readings) Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              '${_name(r.first)} + ${_name(r.second)}: '
              '${positive ? r.meaning.favorable : BnnSensitiveResultDisplay.publicResult(r.meaning.unfavorable)}',
              style: TextStyle(color: color, fontSize: 13,
                fontWeight: FontWeight.w600, height: 1.30)),
          ),
        ]),
    );
  }
}

class _GroupTile extends StatelessWidget {
  final BnnCombinationGroup group;
  const _GroupTile({required this.group});

  @override
  Widget build(BuildContext context) {
    final names = group.planets.map(_name).join(' + ');
    final desc = group.sameSignIndex == null
      ? '1–5–9 త్రికోణ సమూహం'
      : '${BnnRashiRuleService.signs[group.sameSignIndex!]} రాశిలో సంయోగం';
    final readings = group.links;
    final groupKey = group.sameSignIndex == null
      ? 'trine-${group.trineIndex}' : 'sign-${group.sameSignIndex}';
    return Card(
      key: ValueKey('bnn-group-$groupKey'),
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        title: Column(crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('$names • $desc',
              style: const TextStyle(fontWeight: FontWeight.bold)),
            if (readings.isNotEmpty) ...[
              const SizedBox(height: 6),
              // Both possibilities appear BEFORE expanding, just like pair cards.
              _GroupOutcomeBox(
                key: ValueKey('bnn-group-positive-$groupKey'),
                readings: readings, positive: true),
              _GroupOutcomeBox(
                key: ValueKey('bnn-group-negative-$groupKey'),
                readings: readings, positive: false),
            ],
          ]),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 7),
          child: Text('${readings.length} జంట సంబంధాలు • '
            'టచ్ చేస్తే రూల్, జాతక పరిశీలన, ఫలితం, పరిహారం',
            style: const TextStyle(fontSize: 11.5))),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: [
          _detail('1. గ్రూప్ సంబంధ నియమం',
            'IF: మూడు లేదా ఎక్కువ గ్రహాలు $descలో ఉంటే, '
            'THEN: గ్రూప్‌లోని అన్ని గుర్తించిన జంటల శుభ మరియు '
            'ప్రతికూల అంశాలను కలిసి పరిశీలించాలి. '
            'స్వతంత్ర త్రిగ్రహ సంఘటన సూత్రం నిర్ధారించలేదు.'),
          _detail('2. జాతక పరిశీలన — డిగ్రీల క్రమం',
            '${group.planets.map(_location).join(' → ')}\n'
            'సమూహ సంబంధం వర్తించింది (TRUE). '
            'గణితపరంగా గుర్తించిన జంటలు: ${readings.length}; '
            'వాటిలో సంబంధం TRUE అయినవి: '
            '${readings.where((r) => r.natalRelationMatched).length}.\n'
            'ఇది రాశిచక్ర క్రమం మాత్రమే; సంఘటనల టైమింగ్ కాదు. '
            'గ్రహసంబంధం TRUE అయినంత మాత్రాన శుభ/అశుభ సంఘటన '
            'నిర్ధారణ జరిగినట్లు కాదు.'),
          if (readings.isEmpty)
            const Text('గుర్తించిన జంటల వ్యాఖ్యానాలు లేవు.',
              style: TextStyle(color: Colors.black54)),
          if (readings.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Text('3. ఫలితాలు — ప్రతి జంటకు శుభం + ప్రతికూలం',
              style: TextStyle(fontWeight: FontWeight.bold)),
            for (final r in readings) ...[
              const SizedBox(height: 10),
              Text('${_name(r.first)} + ${_name(r.second)} • ${r.id}',
                style: const TextStyle(fontWeight: FontWeight.w600,
                  fontSize: 12)),
              Text('సంబంధం: ${_relationLabel(r.relation)} • '
                'వర్తింపు: ${r.natalRelationMatched ? 'TRUE' : 'FALSE'}',
                style: const TextStyle(fontSize: 12, color: Color(0xFF52626B))),
            ],
          ],
          _detail('4. పరిహారం',
            readings.any((r)=>BnnSensitiveResultDisplay.isMortalityIndicator(
                r.meaning.unfavorable))
              ? BnnSensitiveResultDisplay.mrityunjayaRemedy
              : 'ఈ సమూహానికి ధృవీకరించిన స్వతంత్ర పరిహార IF–THEN '
                  'ప్రస్తుతం లేదు; కల్పిత పరిహారం చూపరు.'),
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('గమనిక: ఈ సమూహం జంటల వ్యాఖ్యానాల సమిష్టి మాత్రమే; '
              'శుభం మరియు అశుభం రెండూ తప్పనిసరిగా జరుగుతాయనే నిర్ధారణ కాదు.',
              style: TextStyle(fontSize: 12, color: Color(0xFF52626B))),
          ),
        ],
      ),
    );
  }
}

Widget _detail(String title,String body) => Padding(
  padding:const EdgeInsets.only(top:10),child:Column(
    crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Text(title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:13)),
      const SizedBox(height:3),Text(body,style:const TextStyle(height:1.35)),
    ]));
