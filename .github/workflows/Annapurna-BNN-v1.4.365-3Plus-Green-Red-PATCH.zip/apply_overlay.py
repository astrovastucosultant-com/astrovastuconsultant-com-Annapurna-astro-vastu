#!/usr/bin/env python3
"""Apply v365 3+ planet dual-display patch ONLY to complete v364 Flutter source.
Does not replace unrelated project files. Verifies expected bytes before replacing.
"""
import argparse,hashlib,re,stat,sys
from pathlib import Path,PurePosixPath
from zipfile import ZipFile,BadZipFile,ZIP_DEFLATED
ROOT=Path(__file__).resolve().parent
FILES=('lib/screens/bnn_planet_combinations_panel.dart',
       'test/bnn_planet_combinations_v359_test.dart')
HASHES={
 'lib/screens/bnn_planet_combinations_panel.dart':'b2f350d46274aa7db82f8f182b46508d2b61f2001e05938a0b10e0ce956cfa5f',
 'test/bnn_planet_combinations_v359_test.dart':'87448925ea9892dcb6a4669c8d47c3d5e28b59dc8033fc6985de463e1651697a',
}
def apply(source,output):
    source=Path(source).resolve();output=Path(output).resolve()
    if source==output: raise ValueError('Output must not overwrite source')
    with ZipFile(source) as zin:
        members=zin.infolist(); names=[i.filename for i in members]
        if len(names)!=len(set(names)): raise ValueError('Duplicate source filenames')
        for i in members:
            p=PurePosixPath(i.filename)
            if p.is_absolute() or '..' in p.parts or '\\' in i.filename or stat.S_ISLNK(i.external_attr>>16):
                raise ValueError('Unsafe ZIP path: '+i.filename)
        if zin.testzip(): raise ValueError('Invalid source ZIP CRC')
        pref=[n[:-len('pubspec.yaml')] for n in names if n.endswith('pubspec.yaml')
            and all(n[:-len('pubspec.yaml')]+f in names for f in FILES)
            and n[:-len('pubspec.yaml')]+'lib/main.dart' in names]
        if len(pref)!=1: raise ValueError('Expected one full Flutter source project')
        prefix=pref[0]
        orig=zin.read(prefix+'pubspec.yaml').decode()
        if not re.search(r'(?m)^version:\s*1\.4\.364\+364\s*$',orig):
            raise ValueError('Expected v1.4.364+364 full source')
        changes={}
        for f in FILES:
            before=zin.read(prefix+f)
            if hashlib.sha256(before).hexdigest()!=HASHES[f]:
                raise ValueError('Source changed unexpectedly: '+f)
            changes[prefix+f]=(ROOT/'astro_app'/f).read_bytes()
        changes[prefix+'pubspec.yaml']=re.sub(r'(?m)^(version:\s*)1\.4\.364\+364\s*$',
            r'\g<1>1.4.365+365',orig,count=1).encode()
        doc=prefix+'docs/BNN_V365_GROUP_GREEN_RED_TELUGU.md'
        if doc in names: raise ValueError('v365 patch already installed')
        with ZipFile(output,'w') as zout:
            for info in members:
                zout.writestr(info,changes.get(info.filename,
                    zin.read(info) if not info.is_dir() else b''))
            zout.writestr(doc,(ROOT/'astro_app/docs/BNN_V365_GROUP_GREEN_RED_TELUGU.md').read_bytes(),compress_type=ZIP_DEFLATED)
    with ZipFile(output) as z:
        if z.testzip(): raise ValueError('New ZIP CRC failure')
        assert b'1.4.365+365' in z.read(prefix+'pubspec.yaml')
        for f in FILES:assert z.read(prefix+f)==changes[prefix+f]
    print('PASS: complete v365 source ZIP',output,'size',output.stat().st_size)
    print('SHA256:',hashlib.sha256(output.read_bytes()).hexdigest())

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True)
    p.add_argument('--output',required=True)
    args=p.parse_args()
    try:apply(args.source,args.output)
    except (OSError,BadZipFile,ValueError) as e:sys.exit('ERROR: '+str(e))
if __name__=='__main__':main()
