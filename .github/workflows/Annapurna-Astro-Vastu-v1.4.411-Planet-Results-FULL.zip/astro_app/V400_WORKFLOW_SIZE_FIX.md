# v400 compact upload workflow

The v399 workflow was 512987 bytes, above GitHub's 500 KiB (512000 byte) workflow-file limit. Run 43559083900 failed without creating any jobs. The old workflow copies succeeded only as no-ops.

The cumulative update ZIP is now stored with ZIP_STORED and compressed as one LZMA envelope before base64 encoding. Python's standard library decompresses it before the existing ZIP checksum, path, symlink and corruption checks. Cross-file compression reduces workflow size while preserving every prior source entry. Only the app version and this note are added/changed. The v399 modal-scroll test correction and the complete test suite remain.

The packaging validator requires the final UTF-8 YAML to stay below 450000 bytes, parses the YAML, round-trips every source entry, runs the exact baseline-extraction script, checks every emitted source hash and CI test path. This verifies packaging, not a completed GitHub APK build.

GitHub source: https://docs.github.com/en/actions/reference/limits#workflow-file-size
