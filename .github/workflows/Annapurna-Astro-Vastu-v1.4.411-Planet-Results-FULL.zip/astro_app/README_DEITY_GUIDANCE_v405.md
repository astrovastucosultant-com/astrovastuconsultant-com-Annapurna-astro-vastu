v405 deity guidance. Preserves v404 body maps and all earlier integrations.
Named tradition: P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach.
https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf
34.5/Table78 printed pp457-458/PDF pp469-470: divisional lagna lord -> associated deities for relevant purpose; strongest occupant/owner/aspector of 12th from AK in D9 -> deity for liberation. Names are alternatives, not an exclusive prescription.
13.2/Table30 printed pp166-167/PDF pp178-179: six single-planet yogakarakas. No seventh manufactured. The yoga-planet to deity link and D1 H9 dharma guide are explicitly APP synthesis, not a newly quoted auspicious-yoga rule.
D1: yoga ownership and H9 dharma reference separately; no single yoga-karaka does not mean no other yogas.
D9: shared Jaimini AK/Karakamsa, 12th relative sign; all occupants, owner, Parashari planetary aspect candidates traced. Node aspects are not invented. Occupant list is a display group, not a strength ranking. No full strength -> no definitive primary Ishta deity. Existing AK tie blocks candidate assertions but does not block independent D20 calculation.
D20: actual lagna lord for spiritual practice. D24: actual lagna lord for learning, not a liberation deity. Each chart gets a visible summary and source checks.
No event-success guarantee, unsupported probability, invented mantra or count; family/guru tradition can select a listed form. Original spirituality grade unchanged: new checks contextual.
Pure Dart tests passed locally; Flutter widget tests and APK build are validated by GitHub CI after upload.
