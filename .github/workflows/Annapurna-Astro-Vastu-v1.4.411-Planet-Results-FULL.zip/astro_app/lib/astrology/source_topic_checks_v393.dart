import 'astro_models.dart';
import 'varga_service.dart';
import 'marriage_chrome_if_then_engine.dart';

/// Individually checked source clauses, not a complete life-event prediction.
class SourceTopicCheck393 {
  final String id, condition, result, evidence, source;
  final bool? matched;
  final bool adverse;
  const SourceTopicCheck393(
    this.id,
    this.condition,
    this.result,
    this.evidence,
    this.source,
    this.matched, {
    this.adverse = false,
  });
}

class SourceTopicChecks393 {
  static List<SourceTopicCheck393> evaluate(
    AstroChartResult chart,
    String topic,
    int factor,
  ) {
    const names = {
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    };
    if (!chart.ascendantLongitude.isFinite ||
        !chart.planets.map((p) => p.name).toSet().containsAll(names) ||
        chart.planets.any((p) => !p.longitude.isFinite))
      return const [];
    if (topic == 'వివాహం') {
      // These exact source clauses are independent of gender and life status.
      // Gender-specific C02-02, composite strength rules and source exceptions
      // must not be silently simplified or treated as completed here.
      final ids = factor == 1
          ? ['C15-01']
          : factor == 9
          ? ['C01-02', 'C01-03', 'C16-01', 'C16-02']
          : factor == 7
          ? ['C02-02']
          : <String>[];
      return [
        for (final id in ids) _marriage(chart, id),
        if (factor == 9)
          const SourceTopicCheck393(
            'S7-D9-COMPOSITE',
            '7వ భావ బలం AND దారాకారక బలం AND జ్ఞాతికారక పీడ లేకపోవడం',
            'వివాహ వాగ్దానానికి సమగ్ర బల పరిశీలన.',
            'సరళ VII మూలంలో సమగ్ర నియమం ఉంది. ఒక్క శుభగ్రహ స్థితిని ఈ మొత్తం AND పరీక్షగా లెక్కించలేదు; బలం/పీడ ప్రమాణాలను వేరుగా పరిశీలించాలి.',
            'Sarala 7 final.pdf • పేజీ 6 • వివాహ వాగ్దానం',
            null,
          ),
      ];
    }
    if (topic != 'సంతానం' || (factor != 1 && factor != 7)) return const [];
    return childrenChart(VargaService.calculate(chart, factor));
  }

  static SourceTopicCheck393 _marriage(AstroChartResult chart, String id) {
    final rule = MarriageChromeIfThenEngine.rules.singleWhere(
      (r) => r.id == id,
    );
    final read = MarriageChromeIfThenEngine.evaluate(rule, chart);
    return SourceTopicCheck393(
      id,
      rule.ifText,
      rule.thenText,
      read.examination,
      '${MarriageChromeIfThenEngine.source} • పేజీ ${rule.page}',
      read.isComputed ? read.matches : null,
      adverse: id != 'C01-03',
    );
  }

  /// Public chart-level evaluator enables exact boundary tests of the printed
  /// clauses. D1 chapter conditions are never copied to D7 or D9 by inference.
  static List<SourceTopicCheck393> childrenChart(VargaChartData v) {
    const lords = [
      'Mars',
      'Venus',
      'Mercury',
      'Moon',
      'Sun',
      'Mercury',
      'Venus',
      'Mars',
      'Jupiter',
      'Saturn',
      'Saturn',
      'Jupiter',
    ];
    final byName = {for (final p in v.planets) p.name: p.signIndex};
    final fifth = (v.ascendantSignIndex + 4) % 12;
    final lagnaLord = lords[v.ascendantSignIndex];
    final fifthLord = lords[fifth];
    int? house(String name) => byName[name] == null
        ? null
        : (byName[name]! - v.ascendantSignIndex + 12) % 12 + 1;
    bool? touchesFifth(String name) {
      final sign = byName[name];
      if (sign == null) return null;
      final diff = (fifth - sign + 12) % 12;
      return diff == 0 ||
          diff == 6 ||
          (name == 'Mars' && (diff == 3 || diff == 7)) ||
          (name == 'Jupiter' && (diff == 4 || diff == 8)) ||
          (name == 'Saturn' && (diff == 2 || diff == 9));
    }

    if (v.definition.factor == 1) {
      return [
        for (final pair in <List<String>>[
          [
            'SAP-P01-5L',
            fifthLord,
            '5వ అధిపతి 5వ భావంలో ఉండటం లేదా 5వ భావాన్ని చూడటం',
          ],
          [
            'SAP-P01-1L',
            lagnaLord,
            'లగ్నాధిపతి 5వ భావంలో ఉండటం లేదా 5వ భావాన్ని చూడటం',
          ],
          [
            'SAP-P01-JUP',
            'Jupiter',
            'గురువు 5వ భావంలో ఉండటం లేదా 5వ భావాన్ని చూడటం',
          ],
        ])
          SourceTopicCheck393(
            pair[0],
            pair[2],
            'సంతాన అంశానికి మంచి మద్దతు: 5వ భావ బలం.',
            'D1: ${pair[1]} → ${house(pair[1]) ?? "డేటా లేదు"}వ భావం; 5వ భావ స్థితి/పారాశరీ దృష్టి పరీక్ష.',
            'Saptamsha_Santana_Niyamalu.pdf • పేజీ 1 • జన్మకుండలి అధ్యాయం',
            touchesFifth(pair[1]),
          ),
      ];
    }
    if (v.definition.factor != 7) return const [];
    final h = house(fifthLord);
    final a = byName[lagnaLord], b = byName[fifthLord];
    return [
      const SourceTopicCheck393(
        'S7-D7-COMPOSITE',
        '5వ భావ బలం AND పుత్రకారక బలం; జ్ఞాతికారక పీడను వేరుగా పరిశీలించాలి',
        'సంతాన వాగ్దానానికి సమగ్ర బల పరిశీలన.',
        'సరళ VII సమగ్ర నియమం; కింది స్వతంత్ర PDF క్లాజులలో ఒక్కటి సరిపోవడం దీనిలోని అన్ని షరతులు సరిపోయినట్లు కాదు.',
        'Sarala 7 final.pdf • పేజీ 5 • సంతానం / పూర్వకర్మ',
        null,
      ),
      SourceTopicCheck393(
        'SAP-P15-5L-TRIKA',
        'D7లో 5వ అధిపతి 6, 8 లేదా 12వ భావంలో ఉంటే',
        'సంతాన అంశంలో జాగ్రత్త అవసరం — 5వ అధిపతి త్రికస్థాన సూచన.',
        'D7: 5వ అధిపతి $fifthLord → $hవ భావం.',
        'Saptamsha_Santana_Niyamalu.pdf • పేజీ 15 • BPHS–2',
        h == null ? null : [6, 8, 12].contains(h),
        adverse: true,
      ),
      SourceTopicCheck393(
        'SAP-P15-1L5L-CONJ',
        'D7 లగ్నాధిపతి, 5వ అధిపతి వేర్వేరు గ్రహాలై కలిసి ఉంటే',
        'సంతాన అంశానికి మంచి మద్దతు — లగ్నాధిపతి/5వ అధిపతి సంయోగం.',
        'D7: లగ్నాధిపతి $lagnaLord; 5వ అధిపతి $fifthLord; రాశి స్థానాలు $a / $b. పరస్పర దృష్టి వేరే పరిశీలన.',
        'Saptamsha_Santana_Niyamalu.pdf • పేజీ 15 • ఫలదీపిక–2, సంయోగ ప్రత్యామ్నాయం',
        a == null || b == null || lagnaLord == fifthLord
            ? null
            : a == b
            ? true
            : null,
      ),
    ];
  }
}
