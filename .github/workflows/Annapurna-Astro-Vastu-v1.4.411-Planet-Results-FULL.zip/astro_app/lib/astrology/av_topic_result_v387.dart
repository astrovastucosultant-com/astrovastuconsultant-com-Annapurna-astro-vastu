enum AvRating387 { good, bad, medium }

class AvTopic387 {
  final String key, title;
  final List<int> houses;
  final List<String> planets;
  const AvTopic387(this.key, this.title, this.houses, this.planets);
  static const values = [
    AvTopic387('wealth', 'ధనం / లాభం', [2, 11], ['Jupiter', 'Mercury']),
    AvTopic387(
      'career',
      'వృత్తి / ఉద్యోగం',
      [6, 10, 11, 12],
      ['Mercury', 'Saturn'],
    ),
    AvTopic387(
      'education',
      'విద్య / ఉన్నత విద్య',
      [5, 9],
      ['Mercury', 'Jupiter'],
    ),
    AvTopic387(
      'property',
      'ఇల్లు / స్థిరాస్తి / వాహనం',
      [4],
      ['Mars', 'Venus'],
    ),
    AvTopic387('siblings', 'సోదరులు / ప్రయత్నం', [3], ['Mars']),
    AvTopic387('marriage', 'వివాహం / భాగస్వామ్యం', [7], ['Venus', 'Jupiter']),
    AvTopic387('children', 'సంతానం', [5], ['Jupiter']),
  ];
}

class AvTopicResult387 {
  final AvTopic387 topic;
  final List<int> scores;
  final AvRating387 rating;
  const AvTopicResult387._(this.topic, this.scores, this.rating);
  static const source37 =
      'ఫలదీపిక • అధ్యాయం 24 • శ్లోకం 37 • ముద్రిత పేజీ 275. '
      'V. Subrahmanya Sastri ఆంగ్ల అనువాదంలో 30+ అధికం, 25–29 మధ్యస్థం, 25 కంటే తక్కువ అల్పం.';
  static const source38 =
      'ఫలదీపిక • అధ్యాయం 24 • శ్లోకం 38 • ముద్రిత పేజీలు 275–276.';
  static const sourceUrl =
      'https://www.wisdomlib.org/hinduism/book/phaladeepika-by-mantreswara-text-and-translation/ocr/1621570/312';
  static String label(AvRating387 value) => switch (value) {
    AvRating387.good => 'మంచి',
    AvRating387.bad => 'చెడు',
    AvRating387.medium => 'మధ్యస్థం',
  };
  static AvRating387 scoreBand(int score) => score >= 30
      ? AvRating387.good
      : score < 25
      ? AvRating387.bad
      : AvRating387.medium;
  factory AvTopicResult387.evaluate(AvTopic387 topic, List<int> savByHouse) {
    if (savByHouse.length != 12 || savByHouse.any((s) => s < 0 || s > 56)) {
      throw ArgumentError('Expected twelve raw SAV house scores in 0–56.');
    }
    final scores = [for (final h in topic.houses) savByHouse[h - 1]];
    // App presentation of the individual source-37 bands: mixed houses stay
    // mixed. A high total/average never conceals a weak relevant house.
    final rating = scores.every((s) => s >= 30)
        ? AvRating387.good
        : scores.every((s) => s < 25)
        ? AvRating387.bad
        : AvRating387.medium;
    return AvTopicResult387._(topic, List.unmodifiable(scores), rating);
  }
  String get result => '${topic.title} — ${label(rating)}';
  int get total => scores.fold(0, (a, b) => a + b);
  double get average => total / scores.length;
  String get reason {
    final low = [
      for (var i = 0; i < scores.length; i++)
        if (scores[i] < 25) '${topic.houses[i]}వ భావం ${scores[i]}',
    ];
    final high = [
      for (var i = 0; i < scores.length; i++)
        if (scores[i] >= 30) '${topic.houses[i]}వ భావం ${scores[i]}',
    ];
    return switch (rating) {
      AvRating387.good =>
        'సంబంధిత భావాలన్నింటిలో 30 లేదా ఎక్కువ బిందువులు ఉన్నాయి.',
      AvRating387.bad =>
        'సంబంధిత భావాలన్నింటిలో 25 కంటే తక్కువ బిందువులు ఉన్నాయి; జాగ్రత్త అవసరం.',
      AvRating387.medium => [
        if (high.isNotEmpty) 'బలం: ${high.join(', ')}.',
        if (low.isNotEmpty) 'బలహీనత: ${low.join(', ')}.',
        'సంబంధిత భావాల బలం సమానంగా లేదు లేదా మధ్యస్థ పరిధిలో ఉంది.',
      ].join(' '),
    };
  }

  static List<({String condition, bool matched})> wealthChecks(List<int> sav) =>
      [
        (
          condition: '11వ భావం ${sav[10]} > 10వ భావం ${sav[9]}',
          matched: sav[10] > sav[9],
        ),
        (
          condition: '12వ భావం ${sav[11]} < 11వ భావం ${sav[10]}',
          matched: sav[11] < sav[10],
        ),
        (
          condition: 'లగ్నం ${sav[0]} > 12వ భావం ${sav[11]}',
          matched: sav[0] > sav[11],
        ),
      ];
}
