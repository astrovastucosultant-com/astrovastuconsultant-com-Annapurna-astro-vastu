/// Traditional zodiac/body reference; not clinical organ-risk assessment.
class BodyArea404 {
  final int sign;
  final List<String> evidence;
  const BodyArea404(this.sign, this.evidence);
  String get name => ChartBodyAreas404.regions[sign];
}

class ChartBodyAreas404 {
  final int factor;
  final List<BodyArea404> areas;
  const ChartBodyAreas404(this.factor, this.areas);
  static const regions = [
    'తల',
    'ముఖం',
    'భుజాలు / చేతులు',
    'హృదయ ప్రాంతం',
    'కడుపు',
    'తుంటి ప్రాంతం',
    'నాభి దిగువ ప్రాంతం',
    'జననాంగ ప్రాంతం',
    'తొడలు',
    'మోకాళ్లు',
    'చీలమండలు',
    'పాదాలు',
  ];
  static const source =
      'P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach • '
      'printed p.21 / PDF p.33 • https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf';
  String get heading =>
      factor == 12 ? 'కుటుంబ కారకుల శరీరపటం' : 'శ్రద్ధ కోసం శరీర ప్రాంతాల పటం';
  String get note => factor == 12
      ? 'కుటుంబ కారకుల స్థానాల సంప్రదాయ పటం మాత్రమే; వారసత్వ వ్యాధి సూచన కాదు.'
      : 'సంప్రదాయ రాశి–శరీర పటం మాత్రమే; వైద్య నిర్ధారణ లేదా అవయవ ప్రమాద అంచనా కాదు.';
  String get selection => factor == 12
      ? 'APP-BODY-404: సూర్య, చంద్ర, 4వ/9వ అధిపతుల స్థానాలు — కుటుంబ సందర్భం మాత్రమే.'
      : factor == 27
      ? 'APP-BODY-404: ఏడు ప్రధాన గ్రహాల్లో నీచం/శత్రు మైత్రి లేదా ఇతర పాప సంబంధం; 22D/64N ఒక్కటే ప్రాంతాన్ని ఎంపిక చేయదు.'
      : factor == 30
      ? 'APP-BODY-404: లగ్నాధిపతి 6/8/12 లేదా ఇతర పాప సంబంధం; లగ్నంపై పాప సంబంధం — అనుబంధం మాత్రమే.'
      : 'APP-BODY-404: లగ్న/6వ అధిపతుల్లో 6/8/12 స్థానం లేదా ఇతర పాప సంబంధం. వర్గ రాశికి శరీరపటం అన్వయం యాప్ పరిశీలన.';
  String get empty =>
      'ఈ పరీక్షల్లో ప్రత్యేక ప్రాంతం ఎంపిక కాలేదు; వైద్య సమస్య లేదనే నిర్ధారణ కాదు.';
}
