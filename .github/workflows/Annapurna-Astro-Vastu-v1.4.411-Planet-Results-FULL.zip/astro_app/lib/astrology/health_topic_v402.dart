import 'astro_models.dart';
import 'health_body_areas_v404.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';
import 'panchadha_maitri_service.dart';
import 'd12_source_rule_service.dart';
import 'd27_health_service.dart';

/// Health-topic integration. These are traditional/app chart observations,
/// never clinical diagnoses, inherited-disease predictions or risk scores.
class HealthTopic402 {
  static const factors = [1, 6, 27, 12, 30];
  static const source =
      'P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach '
      '• Table 11, printed pp.60–61 / PDF pp.72–73 • '
      'https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf';
  static const medical =
      'NIH / MedlinePlus Genetics • '
      'https://medlineplus.gov/genetics/understanding/inheritance/familyhistory/';
  static const note =
      'USER-HEALTH-EXTENSION-402: అసలు VARGA-CROSS-007 క్రమం '
      'D1/D6/D30; మీ సూచనతో D27 బల–బలహీనతలు, D12 కుటుంబ/వంశ అనుబంధం '
      'జతచేశాం. D1/D6/D27లో నమోదైన స్పష్టమైన మద్దతు, జాగ్రత్త రెండూ ఉంటే '
      'మిశ్రమం; ఏకపక్షంగా ఉంటే ఆ సూచన; రెండూ లేకపోతే మధ్యస్థం. ఇది '
      'APP-HEALTH-402 నిర్ణయ విధానం, గ్రంథ శ్లోకం లేదా వైద్య ఆరోగ్య గ్రేడ్ కాదు. '
      'D12, D30, D3 శరీర పటం, 22వ ద్రెక్కాణ/64వ నవాంశ గణనలు అనుబంధం; '
      'వాటిని వ్యాధి లేదా వైద్య తీవ్రత శాతంగా మార్చలేదు. D27 స్వ/ఉచ్చం లేదా '
      'పంచధా మైత్రి ఒక్కటే పూర్తి షడ్బలం కాదు. D6 ఐచ్ఛిక P.V.R. Narasimha Rao '
      'నిర్మాణం. ఖచ్చిత వ్యాధి, అవయవ నష్టం, మరణం, రోగం వచ్చే తేదీ, '
      'విటమిన్ లోపం లేదా మందు/సప్లిమెంట్ మోతాదు ఈ నివేదిక నుంచి ఇవ్వలేదు. '
      'పరిహారం: ఈ సమగ్ర విధానానికి ప్రత్యేక మూల పరిహారం నమోదు కాలేదు.';

  static TopicReport398 evaluate(AstroChartResult chart) {
    if (!TopicResults398.valid(chart))
      return const TopicReport398(
        'ఆరోగ్యం / బల–బలహీనతలు',
        'VARGA-CROSS-007',
        [],
        TopicGrade398.missing,
        'లగ్నం, తొమ్మిది గ్రహాల పూర్తి స్థానాలు కావాలి.',
        note,
      );
    final stages =
        [
              coreStage(chart, 1),
              coreStage(chart, 6),
              strengthStage(chart),
              familyStage(chart),
              obstacleStage(chart),
            ]
            .map(
              (s) => TopicStage398(
                s.factor,
                s.checks,
                bodyAreas: bodyMap(chart, s.factor),
              ),
            )
            .toList();
    final grade = TopicResults398.grade(
      stages
          .where((s) => const {1, 6, 27}.contains(s.factor))
          .expand((s) => s.checks),
    );
    return TopicReport398(
      'ఆరోగ్యం / బల–బలహీనతలు',
      'VARGA-CROSS-007',
      stages,
      grade,
      switch (grade) {
        TopicGrade398.supportive =>
          'పరిశీలించిన సంప్రదాయ నియమాల్లో బలం/మద్దతు '
              'సూచనలు ప్రధానంగా ఉన్నాయి. ఇది వ్యాధులు లేవనే వైద్య నిర్ధారణ కాదు.',
        TopicGrade398.caution =>
          'పరిశీలించిన సంప్రదాయ నియమాల్లో శ్రద్ధ అవసరమనే '
              'సూచనలు ప్రధానంగా ఉన్నాయి. ఇవి రోగ నిర్ధారణ కాదు.',
        _ =>
          'బలం/మద్దతు, జాగ్రత్త సూచనలు కలిశాయి లేదా ఏకపక్ష ఆధారం లేదు. '
              'D27 బలం, D12 కుటుంబ అనుబంధాన్ని కింద విడిగా పరిశీలించండి.',
      },
      '$note కుటుంబంలో వ్యాధులు కనిపించడం మాత్రమే వారసత్వ నిర్ధారణ కాదు. '
          'కుటుంబ వైద్య చరిత్ర, అవసరమైన వైద్య పరిశీలన ఆధారంగా దాని అర్థం తెలుసుకోవాలి. '
          '$medical',
    );
  }

  /// Explicit application selection, independent of the existing health grade.
  static ChartBodyAreas404 bodyMap(AstroChartResult chart, int factor) {
    final v = TopicGeometry398(VargaService.calculate(chart, factor));
    final selected = <int, Set<String>>{};
    void add(String p, String reason) {
      selected
          .putIfAbsent(v.sign(p), () => <String>{})
          .add('${v.placement(p)}; $reason');
    }

    String pressure(String p) =>
        v.touching(v.sign(p), TopicGeometry398.malefics.difference({p}));
    if (factor == 12) {
      for (final role in <String, String>{
        'మాతృ కారకుడు': 'Moon',
        'పితృ కారకుడు': 'Sun',
        '4వ అధిపతి': v.lord(4),
        '9వ అధిపతి': v.lord(9),
      }.entries) {
        add(role.value, '${role.key} — కుటుంబ సందర్భం');
      }
    } else if (factor == 27) {
      for (final strength in PanchadhaMaitriService.evaluateVarga(
        chart: chart,
        factor: 27,
      )) {
        final p = strength.planet;
        final why = <String>[];
        if (v.dignity(p) == 'నీచం') why.add('నీచ రాశి');
        if ({
          PanchadhaRelation.shatru,
          PanchadhaRelation.adhishatru,
        }.contains(strength.relationToSignLord)) {
          why.add(
            'పంచధా మైత్రి: ${PanchadhaMaitriService.relationTelugu(strength.relationToSignLord)}',
          );
        }
        if (pressure(p).isNotEmpty)
          why.add('ఇతర పాప యుతి/దృష్టి: ${pressure(p)}');
        if (why.isNotEmpty) add(p, why.join('; '));
      }
    } else {
      final roles = <String, String>{
        'లగ్నాధిపతి': v.lord(1),
        if (factor != 30) '6వ అధిపతి': v.lord(6),
      };
      for (final r in roles.entries) {
        final why = <String>[];
        if ({6, 8, 12}.contains(v.house(r.value))) why.add('6/8/12 స్థానం');
        if (pressure(r.value).isNotEmpty)
          why.add('ఇతర పాప యుతి/దృష్టి: ${pressure(r.value)}');
        if (why.isNotEmpty) add(r.value, '${r.key}; ${why.join("; ")}');
      }
      if (factor == 30) {
        final contact = v.touching(v.asc, TopicGeometry398.malefics);
        if (contact.isNotEmpty)
          selected
              .putIfAbsent(v.asc, () => <String>{})
              .add('లగ్న రాశి ${v.asc + 1}; పాప యుతి/దృష్టి: $contact');
      }
    }
    return ChartBodyAreas404(factor, [
      for (final sign in selected.keys.toList()..sort())
        BodyArea404(sign, selected[sign]!.toList()),
    ]);
  }

  static TopicStage398 coreStage(AstroChartResult chart, int factor) {
    final v = TopicGeometry398(VargaService.calculate(chart, factor));
    final l1 = v.lord(1), l6 = v.lord(6);
    final target = factor == 1 ? l1 : l6;
    final bad = TopicGeometry398.malefics.difference({target});
    final touch = v.touching(v.sign(target), bad);
    final ben = v.touching(
      v.sign(target),
      {'Jupiter', 'Venus'}.difference({target}),
    );
    final checks = <TopicCheck398>[
      TopicCheck398(
        'APP-HEALTH-D$factor-SUPPORT',
        'D$factor ${factor == 1 ? "లగ్నాధిపతి" : "6వ అధిపతి"}కి గురు/శుక్ర ప్రత్యక్ష యుతి లేదా పరాశరి దృష్టి',
        '${v.placement(target)}; మద్దతు గ్రహాలు: ${none(ben)}',
        'APP-HEALTH-402 • నిర్వచించిన శుభ సంబంధ పరిశీలన • $source',
        '${factor == 1 ? "లగ్నాధిపతి" : "6వ అధిపతి"}కి శుభ సంబంధ మద్దతు నమోదు.',
        ben.isNotEmpty,
      ),
      TopicCheck398(
        'APP-HEALTH-D$factor-PRESSURE',
        'D$factor ${factor == 1 ? "లగ్నాధిపతి" : "6వ అధిపతి"}పై ఇతర సూర్య/కుజ/శని యుతి/దృష్టి లేదా నోడ్స్ యుతి',
        '${v.placement(target)}; ఇతర పాప సంబంధాలు: ${none(touch)}',
        'APP-HEALTH-402 • పరిమితి స్పష్టమైన యాప్ పరిశీలన; సమగ్ర బల రూల్ కాదు',
        '${factor == 1 ? "లగ్నాధిపతి" : "6వ అధిపతి"}పై ఒత్తిడి సూచన; ఆరోగ్య విషయాల్లో శ్రద్ధ అవసరం.',
        touch.isNotEmpty,
        adverse: true,
      ),
      TopicCheck398(
        'APP-HEALTH-D$factor-PLACEMENTS',
        'లగ్నం, 6వ భావం, 6వ అధిపతి స్థానాలను నమోదు',
        'D$factor లగ్న రాశి ${v.asc + 1}; ${v.placement(l1)}; ${v.placement(l6)}; '
            '6వ భావంలోని గ్రహాలు: ${occupants(v, 6)}',
        factor == 1
            ? 'VARGA-CROSS-042 • Mallikarjuna 255 Rules PDF పేజీ 25 • చార్ట్ పరిశీలన'
            : 'VARGA-CROSS-043 • Mallikarjuna 255 Rules PDF పేజీ 25; ఐచ్ఛిక D6 నిర్మాణం',
        '6వ అధిపతి $l6 → ${v.house(l6)}వ భావం; లగ్నాధిపతి $l1 → ${v.house(l1)}వ భావం.',
        true,
        contextual: true,
      ),
    ];
    if (factor == 6)
      checks.addAll([
        TopicCheck398(
          'VARGA-D6-006',
          'D6లో కుజుడు AND రాహువు ఇద్దరూ 6వ భావంలో',
          '${v.placement("Mars")}; ${v.placement("Rahu")}',
          'Mallikarjuna 255 Rules PDF • D6 పేజీ 6',
          'ఈ మూల క్లాజు ప్రకారం అదనపు జాగ్రత్త సూచన; ప్రమాదం/శస్త్రచికిత్సను ఖరారు చేయలేదు.',
          v.house('Mars') == 6 && v.house('Rahu') == 6,
          adverse: true,
        ),
        TopicCheck398(
          'VARGA-D6-001',
          '6వ అధిపతి బలహీనంగా ఉండటం AND పాప యుతి',
          '${v.placement(l6)}; పాప యుతులు: ${none(v.v.planets.where((p) => bad.contains(p.name) && v.sign(p.name) == v.sign(l6)).map((p) => p.name).join(", "))}. '
              'పూర్తి బలహీనత ప్రమాణానికి షడ్బల/మూల నిర్వచనం అవసరం.',
          'Mallikarjuna 255 Rules PDF • D6 పేజీ 6',
          'స్థాన సూచనను పూర్తి పునరావృత రోగ నిర్ధారణగా మార్చలేదు.',
          null,
          contextual: true,
        ),
      ]);
    return TopicStage398(factor, checks);
  }

  static TopicStage398 strengthStage(AstroChartResult chart) {
    final v = TopicGeometry398(VargaService.calculate(chart, 27));
    final strengths = PanchadhaMaitriService.evaluateVarga(
      chart: chart,
      factor: 27,
    );
    final l1 = v.lord(1);
    final selected = strengths.singleWhere((s) => s.planet == l1);
    final checks = <TopicCheck398>[
      TopicCheck398(
        'APP-D27-L1-SUPPORT',
        'D27 లగ్నాధిపతి స్వ/ఉచ్చ రాశి OR పంచధా మైత్రిలో మిత్ర/అధిమిత్ర రాశి',
        '${v.placement(l1)}; ${v.dignity(l1)}; '
            '${PanchadhaMaitriService.relationTelugu(selected.relationToSignLord)}. '
            'తాత్కాలిక మైత్రి D1 నుంచే తీసుకున్నాం.',
        'APP-HEALTH-402 • ఉన్న పంచధా మైత్రి ఇంజిన్; VARGA-D27-001 పూర్తి బల పరీక్షకు ప్రత్యామ్నాయం కాదు',
        'లగ్నాధిపతి రాశి స్థాయిలో బల మద్దతు; ఓర్పు పరిశీలనకు అనుబంధం.',
        v.dignity(l1) == 'ఉచ్చం' ||
            const {
              PanchadhaRelation.own,
              PanchadhaRelation.mitra,
              PanchadhaRelation.adhimitra,
            }.contains(selected.relationToSignLord),
      ),
      TopicCheck398(
        'APP-D27-L1-CAUTION',
        'D27 లగ్నాధిపతి నీచ రాశి OR పంచధాలో శత్రు/అధిశత్రు రాశి',
        '${v.placement(l1)}; ${v.dignity(l1)}; ${PanchadhaMaitriService.relationTelugu(selected.relationToSignLord)}',
        'APP-HEALTH-402 • రాశి స్థాయి బల–బలహీనత పరిశీలన',
        'లగ్నాధిపతి రాశి స్థాయిలో బలహీనత సూచన; ఓర్పు విషయంలో శ్రద్ధ.',
        v.dignity(l1) == 'నీచం' ||
            const {
              PanchadhaRelation.shatru,
              PanchadhaRelation.adhishatru,
            }.contains(selected.relationToSignLord),
        adverse: true,
      ),
      TopicCheck398(
        'VARGA-D27-002',
        'D27 లగ్నంలో గురువు AND కుజుడు యుతి',
        '${v.placement("Jupiter")}; ${v.placement("Mars")}',
        'Mallikarjuna 255 Rules PDF • D27 పేజీ 17',
        'కష్టాలను తట్టుకునే మనోబలానికి సంప్రదాయ మద్దతు.',
        v.house('Jupiter') == 1 && v.house('Mars') == 1,
      ),
      TopicCheck398(
        'VARGA-D27-003',
        'D27లో అన్ని గ్రహాల స్థితులు, బల–బలహీనతలను వేరు నమోదు',
        strengths
            .map(
              (s) =>
                  '${v.placement(s.planet)}; ${v.dignity(s.planet)}; '
                  '${PanchadhaMaitriService.relationTelugu(s.relationToSignLord)}',
            )
            .join('\n'),
        'Mallikarjuna 255 Rules PDF • పేజీ 17 • బల పరిశీలన; $source',
        'ఏడు ప్రధాన గ్రహాల రాశి గౌరవం/మైత్రి నమోదు; రాహు–కేతువులకు పంచధా స్కోరు కల్పించలేదు.',
        true,
        contextual: true,
      ),
      const TopicCheck398(
        'VARGA-D27-001',
        'D27 లగ్నాధిపతి పూర్తి బలం',
        'స్వ/ఉచ్చ రాశి, మైత్రి వేరు చూపాం; అవే పూర్తి షడ్బల నిర్ధారణ కావు.',
        'Mallikarjuna 255 Rules PDF • పేజీ 17',
        'మిగిలిన మూల బల నిర్వచనం వేరు.',
        null,
        contextual: true,
      ),
    ];
    final khara = D27HealthService.kharaReference(chart);
    checks.add(
      TopicCheck398(
        'APP-KHARA-REFERENCE-402',
        'లగ్నం నుంచి 22వ ద్రెక్కాణం; చంద్రుని నుంచి 64వ నవాంశం — సూచిక అధిపతులు',
        '22D అధిపతి ${khara.drekkana22Lord}; 64N అధిపతి ${khara.navamsa64Lord}. '
            'ఉన్న గణన పద్ధతినే ఉపయోగించాం; మూల సూచికల ప్రారంభ బిందువులను వేరు పేర్కొన్నాం.',
        'USER-HEALTH-METHOD • ప్రస్తుత D27 ఖర సూచిక గణన',
        '22D: ${khara.drekkana22Lord}; 64N: ${khara.navamsa64Lord}. '
            'ఇవి రోగం లేదా మరణ సూచనకు స్వతంత్ర నిర్ణయం కాదు.',
        true,
        contextual: true,
      ),
    );
    checks.add(
      TopicCheck398(
        'APP-D1-D3-LOCATION-402',
        'D1 రాశి, D3 స్థానం, ద్రెక్కాణంలోని తొలి/రెండవ 5°లను నమోదు',
        chart.planets
            .map((p) {
              final deg = p.degreesInSign % 10;
              return '${p.name}: D1 రాశి ${p.signIndex + 1}; '
                  'D3 రాశి ${VargaService.signForLongitude(p.longitude, 3) + 1}; '
                  '${p.degreesInSign.toStringAsFixed(3)}°; ${deg < 5 ? "తొలి 5°: అంతరంగ పటం" : "రెండవ 5°: బాహ్య పటం"}';
            })
            .join('\n'),
        'USER-HEALTH-METHOD • ఉన్న D1/D3 శరీర పట పద్ధతి',
        'D1/D3 శరీర పట గణన ఉంది; అవయవానికి వ్యాధి ఉందని అర్థం కాదు.',
        true,
        contextual: true,
      ),
    );
    return TopicStage398(27, checks);
  }

  static TopicStage398 familyStage(AstroChartResult chart) {
    final data = VargaService.calculate(chart, 12), v = TopicGeometry398(data);
    final sourceRows = D12SourceRuleService.evaluate(chart, data);
    return TopicStage398(12, [
      TopicCheck398(
        'APP-D12-LINEAGE-402',
        'D12 తల్లి/తండ్రి కారకులు, 4/9 భావాధిపతుల స్థానాలు',
        '${v.placement("Moon")}; ${v.placement("Sun")}; '
            '4L ${v.placement(v.lord(4))}; 9L ${v.placement(v.lord(9))}',
        '$source • వంశ/తల్లిదండ్రుల విభాగం; Sarala 7 final.pdf PDF pp.9–10',
        'మాతృ కారక చంద్రుడు ${v.house("Moon")}వ భావం; పితృ కారక రవి ${v.house("Sun")}వ భావం. '
            'వంశ అనుబంధ గణన నమోదు.',
        true,
        contextual: true,
      ),
      for (final r in sourceRows.where(
        (r) => const {'D12-REL-03', 'D12-REL-04'}.contains(r.id),
      ))
        TopicCheck398(
          r.id,
          r.condition,
          r.inspection,
          r.source,
          '${r.sourceResult} ఇది తల్లిదండ్రుల సంబంధ క్లాజు; వారసత్వ వ్యాధిగా మార్చలేదు.',
          r.matched,
          adverse: r.caution,
          contextual: true,
        ),
      for (final n in {'Sun', 'Moon', v.lord(4), v.lord(9)})
        TopicCheck398(
          'APP-D12-TRIKA-$n',
          'D12లో కుటుంబ కారక $n 6/8/12లో ఉన్నాడా?',
          v.placement(n),
          'APP-HEALTH-402 • వంశ అనుబంధ స్థానం నమోదు; వ్యాధి రూల్ కాదు',
          '$n: ${v.house(n)}వ భావం. వంశ సంబంధ అనుబంధ సూచన మాత్రమే.',
          [6, 8, 12].contains(v.house(n)),
          contextual: true,
        ),
      const TopicCheck398(
        'FAMILY-MEDICAL-HISTORY-402',
        'నిజమైన కుటుంబ వైద్య చరిత్ర, అవసరమైన వైద్య పరిశీలన ఆధారంగా వంశపారంపర్య అంశం చూడాలి',
        'ఈ జాతక డేటాలో కుటుంబ సభ్యుల నిర్ధారిత వ్యాధుల వివరాలు లేవు. '
            'D12 గ్రహస్థితిని ఆ సమాచారం స్థానంలో ఉపయోగించలేదు.',
        medical,
        'కుటుంబ వైద్య చరిత్ర ఆధారంగా మాత్రమే వంశపారంపర్య ఆరోగ్య అంశాన్ని సమీక్షించాలి.',
        null,
        contextual: true,
      ),
    ]);
  }

  static TopicStage398 obstacleStage(AstroChartResult chart) {
    final v = TopicGeometry398(VargaService.calculate(chart, 30));
    final pap = v.touching(v.asc, TopicGeometry398.malefics);
    return TopicStage398(30, [
      TopicCheck398(
        'APP-D30-HEALTH-CONTEXT-402',
        'D30 లగ్నంపై ప్రత్యక్ష గ్రహ సంబంధం, లగ్నాధిపతి స్థానం నమోదు',
        'లగ్నంపై పాప సంబంధం: ${none(pap)}; ${v.placement(v.lord(1))}; '
            'గురు/శుక్ర మద్దతు: ${none(v.touching(v.asc, {"Jupiter", "Venus"}))}',
        'APP-HEALTH-402 • VARGA-CROSS-044 ఆటంక అనుబంధం • $source',
        'D30 లగ్నంపై పాప సంబంధం ${pap.isEmpty ? "లేదు" : "ఉంది"}; '
            'లగ్నాధిపతి ${v.house(v.lord(1))}వ భావం. అదనపు సందర్భం మాత్రమే.',
        true,
        contextual: true,
      ),
    ]);
  }

  static String none(String s) => s.isEmpty ? 'లేవు' : s;
  static String occupants(TopicGeometry398 v, int h) => none(
    v.v.planets
        .where((p) => v.house(p.name) == h)
        .map((p) => p.name)
        .join(', '),
  );
}
