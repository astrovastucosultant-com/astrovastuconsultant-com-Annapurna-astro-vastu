import 'astro_models.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';

class GoelHoraReading410 {
  final String planet;
  final int natalSign, horaSign, part;
  final double elapsed;
  final bool sunCamp;
  const GoelHoraReading410(
    this.planet,
    this.natalSign,
    this.horaSign,
    this.part,
    this.elapsed,
    this.sunCamp,
  );
  bool get sunHora => horaSign == 4;
  String get result {
    final nature = sunHora
        ? 'సూర్య హోరా: దశలో కృషి, శ్రమ, పరుగు ఎక్కువ'
        : 'చంద్ర హోరా: దశలో సౌమ్యంగా, తక్కువ శ్రమతో పరిష్కారం';
    final camp = sunCamp ? 'సూర్య క్యాంప్' : 'చంద్ర క్యాంప్';
    final band = part == 0
        ? 'మొదటి 5° — ప్రభావం అధిక భాగం'
        : part == 1
        ? 'మధ్య 5° — మధ్య భాగం'
        : 'చివరి 5° — ప్రభావం తగ్గే భాగం';
    final synthesis = part == 0 && sunCamp && sunHora
        ? 'క్లాస్ ఉదాహరణ: గరిష్ట శ్రమ/పరుగు'
        : part == 0 && !sunCamp && !sunHora
        ? 'క్లాస్ ఉదాహరణ: అధిక సౌమ్యత/తక్కువ ఇబ్బంది'
        : 'హోరా స్వభావం, క్యాంప్, గడిచిన భాగం కలిపి చూడాలి; క్లాస్‌లో ఈ కలయికకు సంఖ్యాత్మక సూత్రం ఇవ్వలేదు';
    return '$nature. $camp. $band. $synthesis.';
  }
}

class GoelHoraClass410 {
  static const source =
      'యూజర్ అందించిన V.P. Goel హోరా క్లాస్ సారాంశం • 2026-11-14 • పాయింట్లు 1–6';
  static const sunCamps = {4, 5, 6, 7, 8, 9};
  static const text =
      'పరాశర షడ్వర్గాలు D1/D2/D3/D9/D12/D30. పరాశర D2 దశ స్వభావం: సూర్య హోరా కృషి/పరుగు; చంద్ర హోరా సౌమ్యత/తక్కువ శ్రమ. '
      'ప్రతి హోరా 15°. మొదట గరిష్ట ప్రభావం, ముగింపులో కనిష్టం; 0–5/5–10/10–15° మూడు భాగాలు. '
      'సూర్య క్యాంప్: సింహ, కన్య, తుల, వృశ్చిక, ధనుస్సు, మకర. చంద్ర క్యాంప్: కర్కాటక, మిథున, వృషభ, మేష, మీన, కుంభ. '
      'సూర్య క్యాంప్+సూర్య హోరా+మొదటి5° గరిష్ట శ్రమ; చంద్ర క్యాంప్+చంద్ర హోరా+మొదటి5° అధిక సౌమ్యత. '
      'లాభ–మండూక: మొదటి15° అదే రాశి, రెండో15° D1 నుంచి11వ రాశి. 3వ భావం/అధిపతికి లగ్నం/అధిపతి సంబంధం స్వశక్తి సంపాదన; 9వ సంబంధం అదృష్ట సంపాదన. '
      'లాభ–మండూక 2L శుభుడై బాగా స్థితమైతే ఆకర్షణీయ ముఖం/రూపం/మాటతీరు; మాట నిలబెట్టుకోవడం/సంస్కారం పరిశీలన. 2వ భావం సంపద/మాట/కుటుంబం; 12వది ఖర్చు. '
      'ఈ సారాంశంలో ఇందు లగ్నం ధనస్థాయి సూత్రాలు లేవు; వాటికి పాత ధన–ఆస్తి డేటానే మూలం. వీడియో స్వయంగా పరిశీలించినట్లు కాదు.';
  static GoelHoraReading410 reading(String planet, double longitude) {
    if (!longitude.isFinite) throw ArgumentError('finite longitude');
    final lon = longitude % 360,
        sign = (lon / 30).floor(),
        within = lon % 30,
        elapsed = within % 15;
    final hora = VargaService.signForLongitude(lon, 2);
    return GoelHoraReading410(
      planet,
      sign,
      hora,
      (elapsed / 5).floor(),
      elapsed,
      sunCamps.contains(sign),
    );
  }

  static List<TopicCheck398> checks(AstroChartResult chart) {
    if (!TopicResults398.valid(chart)) return const [];
    return [
      for (final p in chart.planets)
        (() {
          final r = reading(p.name, p.longitude);
          return TopicCheck398(
            'GOEL-HORA-${p.name}-410',
            'D1 క్యాంప్ + పరాశర హోరా + హోరా అంతర్గత 5° భాగం',
            '${p.name}: D1 రాశి ${r.natalSign + 1}; రాశి డిగ్రీ ${(p.longitude % 30).toStringAsFixed(4)}°; ${r.sunHora ? "సూర్య" : "చంద్ర"} హోరా; హోరాలో గడిచింది ${r.elapsed.toStringAsFixed(4)}° /15°; భాగం ${r.part + 1}. 15° సరిహద్దు కొత్త హోరా ప్రారంభం.',
            source,
            r.result,
            true,
            contextual: true,
          );
        })(),
    ];
  }
}
