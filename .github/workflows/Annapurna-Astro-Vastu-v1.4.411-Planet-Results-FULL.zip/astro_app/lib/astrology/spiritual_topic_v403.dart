import 'astro_models.dart';
import 'deity_guidance_v405.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';
import 'jaimini_service.dart';
import 'education_result_v395.dart';

/// Source-bound spirituality review; sign observations are not a claim about
/// someone's faith, character, initiation, siddhi or liberation.
class SpiritualTopic403 {
  static const factors = [1, 9, 20, 24];
  static const pvr =
      'P.V.R. Narasimha Rao • Vedic Astrology: An Integrated Approach '
      '• section 7.3.6, printed p.72 / PDF p.84 • '
      'https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf';
  static const sarala = 'Sarala 7 final.pdf • PDF పేజీ 12 • D20 ఉపాసన';
  static const policy =
      'APP-SPIRIT-REVIEW-403: మూల క్రమం D1/D9/D20/D24. '
      'D20 ప్రధాన సాధన/ఉపాసన పరిశీలన; D1/D9 అనుబంధం, D24 అధ్యయన మద్దతు. '
      'D20 APP సంబంధ పరీక్షలు D20 లగ్నం ఆధారితం; సరళ PDF కారకాంశ పద్ధతికి '
      'వాటిని సమానంగా లెక్కించలేదు. నిర్వచించిన గురు/శుక్ర యుతి లేదా పరాశరి దృష్టిని శుభ సంబంధ శాఖగా; '
      'సూర్య/కుజ/శని దృష్టి/యుతి, నోడ్స్ యుతిని ఇతర పాప సంబంధ శాఖగా '
      'APP IDలతో వేరు చూపాం. గ్రహం తనతో తానే యుతి కాదు; నోడ్స్ ప్రత్యేక '
      'దృష్టులు కల్పించలేదు. చంద్ర/బుధులను ఎప్పుడూ శుభులుగా ఊహించలేదు. '
      'D20లో మద్దతు–జాగ్రత్త రెండూ ఉంటే లేదా రెండూ లేకపోతే మిశ్రమం; '
      'D20 ఏకపక్ష సూచనకు D1/D9లో ఏకపక్ష విరుద్ధ గ్రేడ్ ఉంటే సమగ్రం మిశ్రమం. D24 '
      'విద్యా సూచన సాధనసిద్ధిగా లేదా మోక్ష హిట్‌గా కలపలేదు. ఇది యాప్ '
      'సమగ్ర విధానం, గ్రంథ శ్లోకం కాదు. భక్తి స్థాయి, మతం, నైతిక విలువ '
      'లేదా మంత్రసిద్ధి/సమాధి/మోక్షం ఖాయమని, వాటి సమయం/శాతాన్ని ప్రకటించలేదు. '
      'పూర్తి రాజయోగ/షడ్బల షరతును ఒక్క స్వ/ఉచ్చ రాశితో భర్తీ చేయలేదు. '
      'దేవత సూచనలు PVR §34.5 / Table 78 ప్రకారం వేరు చూపాం; '
      'కుటుంబ/గురు సంప్రదాయానికి అనుగుణంగా స్వరూపం ఎంచుకోవాలి. మంత్రం/జపసంఖ్య కల్పించలేదు.';

  static TopicGrade398 combine(
    TopicGrade398 principal,
    Iterable<TopicGrade398> support,
  ) {
    if (principal == TopicGrade398.missing) return principal;
    if (principal == TopicGrade398.mixed || principal == TopicGrade398.context)
      return TopicGrade398.mixed;
    final opposite = principal == TopicGrade398.supportive
        ? TopicGrade398.caution
        : TopicGrade398.supportive;
    return support.contains(opposite) ? TopicGrade398.mixed : principal;
  }

  static TopicReport398 evaluate(AstroChartResult chart) {
    if (!TopicResults398.valid(chart))
      return const TopicReport398(
        'ఆధ్యాత్మికత',
        'VARGA-CROSS-013',
        [],
        TopicGrade398.missing,
        'లగ్నం, తొమ్మిది గ్రహాల పూర్తి స్థానాలు కావాలి.',
        policy,
      );
    final d1 = foundation(chart),
        d9 = navamsa(chart),
        d20 = practice(chart),
        d24 = study(chart);
    final grade = combine(d20.grade, [d1.grade, d9.grade]);
    final focus = TopicGeometry398(VargaService.calculate(chart, 20));
    final j = JaiminiService.calculate(chart);
    final v9 = TopicGeometry398(VargaService.calculate(chart, 9));
    final ka12 = (j.karakamsaSignIndex + 11) % 12;
    final refs = j.hasDegreeTie
        ? 'కారక డిగ్రీ సమానత్వం — కారకాంశ ఎంపికకు ఖచ్చితత్వం అవసరం'
        : v9.v.planets
              .where((p) => p.signIndex == ka12)
              .map((p) => p.name)
              .join(', ');
    String aspect(Iterable<TopicCheck398> cs) {
      final x = cs.where((c) => c.matched == true && !c.contextual);
      final a = x.any((c) => !c.adverse), b = x.any((c) => c.adverse);
      return a && b
          ? 'మద్దతు, శ్రద్ధ రెండూ'
          : a
          ? 'మద్దతు సూచన'
          : b
          ? 'శ్రద్ధ అవసరమనే సూచన'
          : 'ఏకపక్ష సూచన లేదు';
    }

    final general = switch (grade) {
      TopicGrade398.supportive =>
        'ప్రధాన D20 పరీక్షల్లో సాధనకు అనుకూల సూచనలు ఉన్నాయి.',
      TopicGrade398.caution =>
        'ప్రధాన D20 పరీక్షల్లో సాధన కొనసాగింపుపై అదనపు శ్రద్ధ సూచనలు ఉన్నాయి.',
      _ => 'సాధనకు మద్దతు, ఆటంక సూచనలు కలిశాయి లేదా ఏకపక్ష ఆధారం లేదు.',
    };
    final deity = DeityGuidance405.evaluate(chart);
    final conclusion =
        '${deity.conclusion}\n\n$general\n'
        'ఉపాసన / క్రమబద్ధత: ${aspect(d20.checks.where((c) => c.id.contains("H5") || c.id.contains("H4")))}.\n'
        'గురుమార్గం: ${aspect(d20.checks.where((c) => c.id.contains("9L")))}.\n'
        'వైరాగ్యం: ${aspect([...d20.checks.where((c) => c.id == "VARGA-D20-003"), ...d9.checks.where((c) => c.id == "PVR-KA12-KETU")])}.\n'
        'అధ్యయనం: D24లో నమోదైన విద్యా మద్దతు / ఆటంకాలు అనుబంధంగా ఉన్నాయి.';
    return TopicReport398(
      'ఆధ్యాత్మికత',
      'VARGA-CROSS-013',
      [
        for (final s in [d1, d9, d20, d24])
          TopicStage398(s.factor, [
            ...s.checks,
            if (!(s.factor == 9 && j.hasDegreeTie))
              ...deity.checks[s.factor] ?? <TopicCheck398>[],
          ], deitySummary: deity.summaries[s.factor] ?? ''),
      ],
      grade,
      conclusion,
      '$policy\nD20 ఉపాసన సూచిక: 5L ${focus.lord(5)}, 9L ${focus.lord(9)}. '
          'D9 కారకాంశం నుంచి 12వ స్థానంలోని గ్రహాలు: ${refs.isEmpty ? "లేవు" : refs}. '
          'PVR Table 78 దేవత పేర్లు జతచేశాం; ఇష్టదేవత తుది బల నిర్ణయం వేరు.',
    );
  }

  static TopicStage398 foundation(AstroChartResult chart) {
    final v = TopicGeometry398(VargaService.calculate(chart, 1));
    return TopicStage398(1, [
      ...contacts(
        v,
        9,
        v.lord(9),
        prefix: 'APP-SPIRIT-D1',
        title: 'ధర్మ / మార్గదర్శకత్వం',
        source:
            'VARGA-CROSS-061 • Mallikarjuna 255 Rules PDF పేజీ 28; నిర్దిష్ట సంబంధం APP-SPIRIT-403',
      ),
      TopicCheck398(
        'APP-SPIRIT-D1-REFERENCES',
        'D1 గురు, కేతు, 9/12వ అధిపతుల స్థానాలు నమోదు',
        '${v.placement("Jupiter")}; ${v.placement("Ketu")}; '
            '9L ${v.placement(v.lord(9))}; 12L ${v.placement(v.lord(12))}',
        'VARGA-CROSS-061 • Mallikarjuna 255 Rules PDF పేజీ 28 • చార్ట్ పరిశీలన',
        'గురువు ${v.house("Jupiter")}వ భావం; కేతువు ${v.house("Ketu")}వ భావం; '
            'ధర్మ–వైరాగ్య స్థాన సూచికలు నమోదు.',
        true,
        contextual: true,
      ),
    ]);
  }

  /// A branch with an exact stated contact is fully testable. It is not a
  /// substitute for a source's undefined "strong" or "Rajayoga" conjunction.
  static List<TopicCheck398> contacts(
    TopicGeometry398 v,
    int h,
    String lord, {
    required String prefix,
    required String title,
    required String source,
  }) {
    final good = {'Jupiter', 'Venus'}.difference({lord});
    final bad = TopicGeometry398.malefics.difference({lord});
    final benefic = v.touching(v.sign(lord), good);
    final malefic = v.touching(v.sign(lord), bad);
    return [
      TopicCheck398(
        '$prefix-H$h-SUPPORT',
        'D${v.v.definition.factor} $hవ అధిపతికి గురు/శుక్ర యుతి లేదా పరాశరి దృష్టి',
        '${v.placement(lord)}; మద్దతు: ${none(benefic)}',
        source,
        '$title: అధిపతికి శుభ సంబంధ మద్దతు.',
        benefic.isNotEmpty,
      ),
      TopicCheck398(
        '$prefix-H$h-CAUTION',
        'D${v.v.definition.factor} $hవ అధిపతికి ఇతర సూర్య/కుజ/శని యుతి/దృష్టి లేదా రాహు/కేతు యుతి',
        '${v.placement(lord)}; ఒత్తిడి: ${none(malefic)}',
        '$source • పాప సంబంధ విరుద్ధ పరీక్ష APP-SPIRIT-403',
        '$title: క్రమబద్ధమైన ప్రయత్నం, మార్గదర్శకత్వంపై శ్రద్ధ సూచన.',
        malefic.isNotEmpty,
        adverse: true,
      ),
    ];
  }

  static TopicStage398 practice(AstroChartResult chart) {
    final v = TopicGeometry398(VargaService.calculate(chart, 20));
    final rows = <TopicCheck398>[
      ...contacts(
        v,
        5,
        v.lord(5),
        prefix: 'APP-SPIRIT-D20',
        title: 'ఉపాసన / అవగాహన',
        source:
            'APP-SPIRIT-403 • D20 లగ్న 5L పరీక్ష; $sarala కారకాంశ క్లాజుకు ప్రత్యామ్నాయం కాదు',
      ),
      ...contacts(
        v,
        4,
        v.lord(4),
        prefix: 'APP-SPIRIT-D20',
        title: 'సాధనలో స్థిరత్వం',
        source:
            'APP-SPIRIT-403 • D20 లగ్న 4L స్థిరత్వ పరిశీలన; $sarala నేపథ్యం',
      ),
      ...contacts(
        v,
        9,
        v.lord(9),
        prefix: 'APP-SPIRIT-D20-9L',
        title: 'ధర్మ / గురుమార్గం',
        source: 'APP-SPIRIT-403 • D20 లగ్న 9L సంబంధ పరిశీలన; $sarala నేపథ్యం',
      ),
      TopicCheck398(
        'VARGA-D20-003',
        'D20లో కేతువు లగ్నం OR 12వ స్థానంలో ఉన్న ప్రత్యక్ష శాఖ',
        v.placement('Ketu'),
        'Mallikarjuna 255 Rules PDF • పేజీ 16 • కేతు ప్రత్యక్ష స్థాన శాఖ',
        'వైరాగ్య చింతన / అంతర్ముఖ దృష్టికి సంప్రదాయ సూచన.',
        v.house('Ketu') == 1 || v.house('Ketu') == 12,
      ),
      TopicCheck398(
        'APP-SPIRIT-D20-DIGNITY',
        'D20 లగ్న, 5వ, 9వ అధిపతుల రాశి గౌరవాలు నమోదు',
        {
          v.lord(1),
          v.lord(5),
          v.lord(9),
        }.map((n) => '${v.placement(n)}; ${v.dignity(n)}').join('\n'),
        'APP-SPIRIT-403 • VARGA-D20-001/002 పూర్తి బల నిర్ణయానికి అనుబంధం',
        '5L ${v.lord(5)}: ${v.dignity(v.lord(5))}; 9L ${v.lord(9)}: ${v.dignity(v.lord(9))}.',
        true,
        contextual: true,
      ),
      TopicCheck398(
        'VARGA-D20-001',
        'గురు లేదా కేతువు లగ్నం/9వ స్థానంలో AND పూర్తి బలం',
        '${v.placement("Jupiter")}; ${v.placement("Ketu")}; పూర్తి గ్రహబల ప్రమాణాన్ని ఒక్క రాశి స్థానంతో భర్తీ చేయలేదు.',
        'Mallikarjuna 255 Rules PDF • పేజీ 16',
        'ఉపాసన ఫలం / మంత్రసిద్ధి అనే పూర్తి మూల షరతు వేరు.',
        null,
        contextual: true,
      ),
      TopicCheck398(
        'VARGA-D20-002',
        'D20 9వ అధిపతికి పూర్తి బలం',
        '9L ${v.placement(v.lord(9))}; ${v.dignity(v.lord(9))}. పూర్తి బల పరిమితి వేరు.',
        'Mallikarjuna 255 Rules PDF • పేజీ 16',
        'గురువు లభ్యత ఖచ్చితమని ఒక్క సంబంధంతో నిర్ణయించలేదు.',
        null,
        contextual: true,
      ),
      TopicCheck398(
        'APP-SPIRIT-D20-PLANETS',
        'D20 గురు/కేతు మరియు 6/8వ అధిపతి స్థానాల పరిశీలన',
        '${v.placement("Jupiter")}; ${v.placement("Ketu")}; '
            '6L ${v.placement(v.lord(6))}; 8L ${v.placement(v.lord(8))}',
        '$sarala • సాధన, అభ్యాసం, అంతర్ముఖ అనుభవాల సందర్భం',
        'గురువు ${v.house("Jupiter")}వ భావం; కేతువు ${v.house("Ketu")}వ భావం. '
            'అభ్యాస/అంతర్ముఖ స్థానాలు నమోదు.',
        true,
        contextual: true,
      ),
    ];
    return TopicStage398(20, rows);
  }

  static TopicStage398 navamsa(AstroChartResult chart) {
    final j = JaiminiService.calculate(chart),
        v = TopicGeometry398(VargaService.calculate(chart, 9));
    final ka = j.karakamsaSignIndex, k12 = (ka + 11) % 12, k9 = (ka + 8) % 12;
    final items = v.v.planets
        .where((p) => p.signIndex == k12)
        .map((p) => p.name)
        .join(', ');
    if (j.hasDegreeTie)
      return const TopicStage398(9, [
        TopicCheck398(
          'SPIRIT-D9-AK-TIE',
          'ఆత్మకారక/కారకాంశ గణనలో డిగ్రీ సమానత్వం లేకపోవాలి',
          'జైమిని ఏడు గ్రహాల రాశి డిగ్రీల్లో సమానత్వం ఉంది. కారకాంశ ఆధారిత ఆధ్యాత్మిక రూల్ హిట్ నమోదు చేయలేదు.',
          'ప్రస్తుత JaiminiService • ఖచ్చితత్వ పరిమితి',
          'కారకాంశ పరిశీలనకు మరింత ఖచ్చితమైన గ్రహ డిగ్రీలు అవసరం.',
          null,
          contextual: true,
        ),
      ]);
    return TopicStage398(9, [
      karakamsaKetu(v.v, ka),
      TopicCheck398(
        'APP-SPIRIT-KA9-JUPITER',
        'D9 కారకాంశం నుంచి 9వ రాశిలో గురువు',
        'AK ${j.atmakaraka}; కారకాంశ రాశి ${ka + 1}; 9వ రాశి ${k9 + 1}; ${v.placement("Jupiter")}',
        'ప్రస్తుత జైమిని J1Q1-C23 • పాండిత్య సూచన; స్థానం ఆధారిత శాఖ',
        'శాస్త్ర/వేదాంత అధ్యయన ఆసక్తికి సంప్రదాయ మద్దతు.',
        v.sign('Jupiter') == k9,
      ),
      TopicCheck398(
        'APP-SPIRIT-KA9-CAUTION',
        'D9 కారకాంశం నుంచి 9వ రాశిలో శని OR రాహువు',
        'కారకాంశం ${ka + 1}; ${v.placement("Saturn")}; ${v.placement("Rahu")}',
        'ప్రస్తుత జైమిని J1Q1-C19 • గురు/ధర్మ మార్గ పరిశీలన',
        'గురు మార్గదర్శకత్వం, ఆచరణ కొనసాగింపుపై అదనపు శ్రద్ధ సూచన.',
        v.sign('Saturn') == k9 || v.sign('Rahu') == k9,
        adverse: true,
      ),
      TopicCheck398(
        'SPIRIT-KARAKAMSA-REFERENCE',
        'D1 ఆత్మకారకుడి D9 రాశినే కారకాంశంగా తీసుకోవాలి',
        'AK ${j.atmakaraka}; D9 కారకాంశం ${ka + 1}; 12వ రాశి ${k12 + 1}; గ్రహాలు ${none(items)}',
        pvr,
        'ఇష్టదేవత పరిశీలనకు 12వ స్థాన సూచికలు: ${none(items)}. '
            'బలమైన గ్రహం/దేవత ఎంపికకు అదనపు మూల పరీక్ష అవసరం.',
        true,
        contextual: true,
      ),
    ]);
  }

  /// Public chart-level clause for exact relative-position tests. The
  /// caller must resolve the AK, degree ties and D9 Karakamsa first.
  static TopicCheck398 karakamsaKetu(VargaChartData d9, int ka) {
    if (d9.definition.factor != 9 || ka < 0 || ka > 11) {
      throw ArgumentError('D9 chart and a valid Karakamsa sign are required');
    }
    final v = TopicGeometry398(d9), target = (ka + 11) % 12;
    return TopicCheck398(
      'PVR-KA12-KETU',
      'D9లో కారకాంశం నుంచి 12వ రాశిలో కేతువు',
      'కారకాంశ రాశి ${ka + 1}; 12వ రాశి ${target + 1}; కేతు రాశి ${v.sign("Ketu") + 1}',
      pvr,
      'అంతర్ముఖత / వైరాగ్య దిశకు సంప్రదాయ మద్దతు; మోక్ష నిర్ధారణ కాదు.',
      v.sign('Ketu') == target,
    );
  }

  static TopicStage398 study(AstroChartResult chart) {
    final e = EducationResult395.evaluate(
      chart,
    ).stages.singleWhere((s) => s.factor == 24);
    const ids = {'EDU-D24-003', 'EDU-D24-004', 'EDU-D24-012', 'EDU-D24-014'};
    return TopicStage398(24, [
      for (final c in e.checks.where((c) => ids.contains(c.id)))
        TopicCheck398(
          c.id,
          c.condition,
          c.evidence,
          c.source,
          '${c.outcome} ఇది విద్యా/గ్రంథ అధ్యయన అనుబంధం; ఆధ్యాత్మిక సిద్ధి కాదు.',
          c.matched,
          adverse: c.adverse,
          contextual: true,
        ),
      const TopicCheck398(
        'SPIRIT-D24-SCOPE',
        'శాస్త్ర అధ్యయనాన్ని సాధన/అనుభూతి ఫలితంతో వేరు చూడాలి',
        'ఉన్న D24 విద్యా ఇంజిన్‌లోని లగ్న, పంచమ, నవమాధిపతి పరీక్షలను అధ్యయన సందర్భంలోనే చూపాం.',
        'VARGA-CROSS-064 • Mallikarjuna 255 Rules PDF పేజీ 28',
        'గ్రంథ అధ్యయన మద్దతు వేరు; సాధనలో అనుభవం వేరు.',
        true,
        contextual: true,
      ),
    ]);
  }

  static String none(String s) => s.isEmpty ? 'లేవు' : s;
}
