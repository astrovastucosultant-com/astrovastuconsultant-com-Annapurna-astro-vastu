import 'astro_models.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';
import 'deity_guidance_v405.dart';
import 'client_guidance_model_v406.dart';

/// User-priority client guidance for health and children. Does not rank deities
/// by medical efficacy, alter rule grades, or prescribe initiated practices.
class ClientGuidance406 {
  static const healthId = 'VARGA-CROSS-007', childId = 'VARGA-CROSS-005';
  static const dhanvantari =
      'TTD • Dhanwantari Puja, 13 Dec 2020 • https://news.tirumala.org/karthika-masa-deeksha-pujas-concludes-with-sri-dhanwantari-puja/';
  static const gopala =
      'సంతానగోపాల స్తోత్ర పాఠం • https://sanskritdocuments.org/doc_vishhnu/santaanagopaala.html';
  static const medical =
      'WHO infertility evaluation, Chapter 3 • https://www.ncbi.nlm.nih.gov/books/NBK620430/';
  static const prayer =
      'శృంగేరి ఆచార్యుల భక్తి/అభ్యాస బోధన • https://vijayayatra.sringeri.net/archiveyatra/mahadanapuram-june-9-10-2012/';
  static const healthForms = <String, String>{
    'Sun': 'శివుడు',
    'Moon': 'గౌరీదేవి',
    'Mars': 'సుబ్రహ్మణ్యుడు',
    'Mercury': 'శ్రీమన్నారాయణుడు',
    'Jupiter': 'దత్తాత్రేయుడు',
    'Venus': 'పార్వతీదేవి',
    'Saturn': 'శ్రీమహావిష్ణువు',
    'Rahu': 'దుర్గాదేవి',
    'Ketu': 'గణపతి',
  };
  static const childForms = <String, String>{
    'Sun': 'శ్రీరాముడు',
    'Moon': 'శ్రీకృష్ణుడు',
    'Mars': 'సుబ్రహ్మణ్యుడు',
    'Mercury': 'శ్రీమన్నారాయణుడు',
    'Jupiter': 'శ్రీమహావిష్ణువు',
    'Venus': 'పార్వతీదేవి',
    'Saturn': 'శ్రీమహావిష్ణువు',
    'Rahu': 'దుర్గాదేవి',
    'Ketu': 'గణపతి',
  };
  static TopicReport398 attach(AstroChartResult chart, TopicReport398 base) {
    final health = base.sourceId == healthId;
    if (!health && base.sourceId != childId) return base;
    if (base.clientGuidance != null ||
        base.grade == TopicGrade398.missing ||
        !TopicResults398.valid(chart))
      return base;
    final factor = health ? 6 : 7;
    final v = TopicGeometry398(VargaService.calculate(chart, factor));
    final lord = v.lord(1),
        primary = (health ? healthForms : childForms)[v.lord(1)]!;
    final selection =
        'APP-CLIENT-406: PVR Table 78లోని ప్రత్యామ్నాయ స్వరూపాల్లో ఒకదాన్ని చూపే యాప్ ప్రాధాన్య క్రమం; ఒక్కటే సరైన దేవత అనే తీర్పు కాదు.';
    final active = base.stages
        .where(
          (s) => health
              ? {1, 6, 27}.contains(s.factor)
              : {1, 7}.contains(s.factor),
        )
        .expand((s) => s.checks)
        .where((c) => c.matched == true && !c.contextual)
        .toList();
    final support = active.where((c) => !c.adverse).map((c) => c.id).join(', ');
    final caution = active.where((c) => c.adverse).map((c) => c.id).join(', ');
    final guide = ClientGuidanceData406(
      topicId: base.sourceId,
      title: health ? 'ఆరోగ్యం — ఆరాధన / ఆచరణ' : 'సంతానం — ఆరాధన / ఆచరణ',
      factor: factor,
      primary: primary,
      reason:
          'D$factor లగ్న రాశి ${v.asc + 1}; లగ్నాధిపతి $lord. ${v.placement(lord)}. '
          'సంబంధిత వర్గ లగ్నాధిపతి దేవతను ఆ అంశానికి ఆరాధన సూచనగా పరిశీలించే PVR §34.5 పద్ధతి. $selection',
      alternative: health
          ? 'ధన్వంతరి ప్రార్థన — ఆరోగ్య సందర్భంలోని సాధారణ సంప్రదాయ ప్రత్యామ్నాయం; జాతకం నుంచి కొత్తగా తేలిన గ్రహదేవత కాదు.'
          : 'సంతానగోపాలకృష్ణ ప్రార్థన — సంతాన సందర్భంలోని సాధారణ సంప్రదాయ ప్రత్యామ్నాయం; జాతకం నుంచి కొత్తగా తేలిన గ్రహదేవత కాదు.',
      practice:
          'కుటుంబ/గురు సంప్రదాయానికి అనుగుణంగా ఒక స్వరూపాన్ని ఎంచుకుని, మీకు అనుకూలమైన సమయంలో సరళ ప్రార్థన లేదా నామస్మరణ. '
          'స్తోత్రం చదవాలనుకుంటే సరైన పాఠం నేర్చుకోండి. బీజమంత్రం, న్యాసం, దీక్షా సాధనకు గురు మార్గదర్శకత్వం. జపసంఖ్య/గడువు లేదా ఖరీదైన పూజ తప్పనిసరి కాదు.',
      action: health
          ? 'లక్షణాలు/సమస్యలను వైద్యునికి తెలియజేసి, సూచించిన పరిశీలన/చికిత్స కొనసాగించండి. ప్రార్థన కోసం చికిత్సను ఆపకండి లేదా ఆలస్యం చేయకండి.'
          : 'గర్భధారణ ఆలస్యం లేదా ఇతర సంతాన సంబంధ వైద్య సమస్య ఉంటే దంపతులిద్దరూ వైద్య సలహా పొందండి. పిల్లల పెంపకం/సంబంధ సమస్య అయితే పరస్పర సంభాషణ, అవసరమైన సహాయం తీసుకోండి. ఎవరికీ నింద మోపవద్దు.',
      limit: health
          ? 'ఆరాధన ఆధ్యాత్మిక మద్దతు కోసం. వ్యాధి నిర్ధారణ, నయం హామీ, అవయవ ప్రమాద శాతం లేదా మందుల సిఫారసు కాదు. D12 నుంచి వారసత్వ వ్యాధి నిర్ణయించలేదు.'
          : 'ఆరాధన ఆధ్యాత్మిక మద్దతు కోసం. గర్భధారణ, పిల్లల సంఖ్య/లింగం, సంతానలేమి నిర్ధారణ లేదా ఫలితం వచ్చే తేదీని హామీ ఇవ్వలేదు.',
      evidence: [
        'APP-CLIENT-D$factor-L1-DEITY-406: ${v.placement(lord)}',
        'వర్తించిన మద్దతు నియమాలు: ${support.isEmpty ? "ఈ పరీక్షల్లో నమోదు కాలేదు" : support}',
        'వర్తించిన జాగ్రత్త నియమాలు: ${caution.isEmpty ? "ఈ పరీక్షల్లో నమోదు కాలేదు" : caution}',
        'మద్దతు/జాగ్రత్త రూల్స్ దేవత ఫలసిద్ధికి ఆధారం కాదు; జాతక పరిశీలనను వేరు చూపే జాబితా మాత్రమే.',
      ],
      sources: [
        DeityGuidance405.source,
        health ? dhanvantari : gopala,
        prayer,
        if (!health) medical,
      ],
    );
    final stages = <TopicStage398>[];
    for (final stage in base.stages) {
      final eligible = health
          ? {1, 6, 27}.contains(stage.factor)
          : {1, 7}.contains(stage.factor);
      if (!eligible) {
        stages.add(
          TopicStage398(
            stage.factor,
            stage.checks,
            bodyAreas: stage.bodyAreas,
            deitySummary: health
                ? 'D${stage.factor}: కుటుంబ/అనుబంధ పరిశీలన మాత్రమే; ఈ దశ నుంచి వ్యాధి లేదా కొత్త ఆరాధనా దేవతను నిర్ణయించలేదు.'
                : 'D9: పంచమాధిపతి/గురువు అనుబంధ పరిశీలన; ప్రధాన సంతాన ఆరాధనా సూచన D7 ఆధారితం.',
          ),
        );
        continue;
      }
      final x = TopicGeometry398(VargaService.calculate(chart, stage.factor));
      final p = x.lord(1);
      final deity = (health ? healthForms : childForms)[p]!;
      final summary =
          '${stage.factor == factor ? "ప్రధాన సూచన" : "అనుబంధ సూచన"}: $deity. ఆధారం: D${stage.factor} లగ్నాధిపతి $p; ${x.placement(p)}. ఒక స్వరూపం చాలు; అన్నీ ఆరాధించాలనే నియమం కాదు.';
      stages.add(
        TopicStage398(
          stage.factor,
          [
            ...stage.checks,
            TopicCheck398(
              'APP-CLIENT-D${stage.factor}-L1-DEITY-406',
              'సంబంధిత వర్గ లగ్నాధిపతి → PVR Table 78 దేవత స్వరూపం',
              '${x.placement(p)}; $selection',
              DeityGuidance405.source,
              summary,
              true,
              contextual: true,
            ),
          ],
          bodyAreas: stage.bodyAreas,
          deitySummary: summary,
        ),
      );
    }
    return TopicReport398(
      base.topic,
      base.sourceId,
      stages,
      base.grade,
      base.conclusion,
      '${base.note}\nAPP-CLIENT-406 ఆరాధన మార్గదర్శకత్వం వేరు జతచేశాం; అసలు రూల్‌కు నిర్దిష్ట పరిహారం లేనప్పుడు దాన్ని కల్పించలేదు. '
      'ప్రధాన సూచిక D$factor లగ్నాధిపతి; ఇది యాప్ అంశ ప్రాధాన్యం. నిర్దిష్ట మహావిద్య/దీక్షా పద్ధతిని సాధారణ దేవతకు సమానంగా ఊహించలేదు.',
      clientGuidance: guide,
    );
  }
}
