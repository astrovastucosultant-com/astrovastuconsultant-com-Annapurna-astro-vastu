import 'astro_models.dart';
import 'varga_service.dart';
import 'd24_education_registry.dart';
import 'vedic_calculation_service.dart';
import 'jaimini_service.dart';

enum EducationGrade395 { good, bad, medium, missing }

extension EducationGradeText395 on EducationGrade395 {
  String get label => switch (this) {
    EducationGrade395.good => 'మంచి',
    EducationGrade395.bad => 'చెడు',
    EducationGrade395.medium => 'మధ్యస్థం',
    EducationGrade395.missing => 'గణనకు సమాచారం లేదు',
  };
}

class EducationCheck395 {
  final String id, condition, evidence, source, outcome;
  final bool matched;
  final bool adverse;
  final bool contextual;
  const EducationCheck395(
    this.id,
    this.condition,
    this.evidence,
    this.source,
    this.outcome,
    this.matched, {
    this.adverse = false,
    this.contextual = false,
  });
}

class EducationStage395 {
  final int factor;
  final List<EducationCheck395> checks;
  final EducationGrade395? principalGrade;
  const EducationStage395(this.factor, this.checks, {this.principalGrade});
  EducationGrade395 get grade =>
      principalGrade ?? EducationResult395.gradeChecks(checks);
  String get result {
    final hits = checks.where((c) => c.matched && !c.contextual).toList();
    final good = hits.where((c) => !c.adverse).take(1).map((c) => c.outcome);
    final bad = hits.where((c) => c.adverse).take(1).map((c) => c.outcome);
    return [
      'విద్య — ${grade.label}',
      if (hits.isEmpty)
        'ఈ పరీక్షల్లో బలమైన మంచి లేదా చెడు ప్రభావం వేరుగా కనిపించలేదు.',
      if (good.isNotEmpty) 'మద్దతు: ${good.first}',
      if (bad.isNotEmpty) 'జాగ్రత్త: ${bad.first}',
    ].join('\n');
  }
}

class EducationReport395 {
  final List<EducationStage395> stages;
  final EducationGrade395 grade;
  final List<String> levels, courses;
  final String fieldAudit, note;
  const EducationReport395({
    required this.stages,
    required this.grade,
    this.levels = const [],
    this.courses = const [],
    this.fieldAudit = '',
    this.note = '',
  });
  String get caution {
    final principal = stages.where((s) => s.factor == 24);
    if (principal.isEmpty) return '';
    return principal.first.checks
        .where((c) => c.matched && c.adverse && !c.contextual)
        .map((c) => c.outcome)
        .take(2)
        .join(' ');
  }

  String get conclusion {
    if (grade == EducationGrade395.good)
      return 'విద్య కొనసాగింపుకు మంచి మద్దతు ఉంది. క్రింద చూపిన విద్యా దశలు, రంగాలను పరిశీలించవచ్చు.';
    if (grade == EducationGrade395.bad)
      return 'విద్యలో ఆటంకం, ఆలస్యం లేదా మార్పులకు ప్రధాన ప్రతికూల సూచనలు ఉన్నాయి. చదువు పూర్తికాదని తీర్పు కాదు; అదనపు శ్రద్ధ అవసరం.';
    if (grade == EducationGrade395.missing)
      return 'లగ్నం లేదా అవసరమైన గ్రహస్థితులు పూర్తిగా లేవు. వాటిని నమోదు చేసి మళ్లీ గణించాలి.';
    final principal = stages.where((s) => s.factor == 24);
    if (principal.isEmpty) return 'విద్యా మద్దతును గ్రహస్థితులతో పరిశీలించాలి.';
    if (principal.first.grade == EducationGrade395.good)
      return 'D24లో మంచి విద్యా మద్దతు ఉంది; అనుబంధ చక్రంలో ప్రతికూల సూచన ఉండడంతో సమగ్ర ఫలితం మధ్యస్థం.';
    if (principal.first.grade == EducationGrade395.bad)
      return 'D24లో ప్రధాన విద్యా ఆటంకం ఉంది; అనుబంధ చక్రంలో మంచి మద్దతు కూడా ఉండడంతో సమగ్ర ఫలితం మధ్యస్థం.';
    final checks = principal.first.checks;
    bool hit(String id) => checks.any((c) => c.id == id && c.matched);
    final positive =
        (hit('EDU-D24-003') && !hit('EDU-D24-004')) ||
        hit('EDU-D24-012') ||
        hit('EDU-D24-014');
    return positive
        ? 'D24లో ప్రధాన విద్యా మద్దతు, ప్రధాన ఆటంకం రెండూ కలిసి ఉన్నాయి. అందువల్ల మధ్యస్థం; కొనసాగింపుకు క్రమమైన ప్రయత్నం అవసరం.'
        : 'ఈ పరీక్షల్లో విద్య కొనసాగింపుకు ప్రధాన మంచి లేదా ప్రధాన చెడు యుక్త షరతులు స్పష్టంగా సరిపోలలేదు. అందువల్ల మధ్యస్థం; కింది నిర్దిష్ట సహాయక సూచనలను పరిశీలించండి.';
  }
}

class EducationResult395 {
  static const signNames = [
    'మేషం',
    'వృషభం',
    'మిథునం',
    'కర్కాటకం',
    'సింహం',
    'కన్య',
    'తుల',
    'వృశ్చికం',
    'ధనుస్సు',
    'మకరం',
    'కుంభం',
    'మీనం',
  ];
  static const policy =
      'USER-EDU-REVIEW-395: స్వ/ఉచ్చం నిర్దిష్ట బల ప్రమాణం మాత్రమే; సంపూర్ణ షడ్బలం కాదు. శుభ సంబంధం = గురు/శుక్ర యుతి లేదా పారాశరీ దృష్టి; పాప సంబంధం = సూర్య/కుజ/శని/రాహు/కేతు (స్వయాన్ని మినహాయించి). రాహు/కేతు దృష్టులు ఊహించలేదు. అనుబంధ చక్రాల్లో మంచి/చెడు రెండూ ఉంటే మధ్యస్థం. D24 ప్రధాన మద్దతు = లగ్నాధిపతి మద్దతు (003) ఉండి పీడ పరీక్ష (004) లేకపోవడం OR 5వ/9వ అధిపతి స్వ/ఉచ్చ మద్దతు (012/014). ప్రధాన ఆటంకం = మూల CORE-05 పూర్తి యుక్త షరతు OR లగ్న శుభమద్దతు లేని పాప ప్రభావం (002) AND లగ్నాధిపతి పీడ (004). ప్రధాన మద్దతు, ఆటంకం రెండూ ఉంటే లేదా రెండూ లేకపోతే మధ్యస్థం; ఒక్కొక్కటే ఉంటే మంచి/చెడు. మిగిలిన హెచ్చరికలు విడిగా చూపుతాం; ఓట్లు/శాతాలు కలపలేదు. D24 ప్రధాన నిర్ణయం; D1/D4/D9లో వ్యతిరేక గ్రేడ్ ఉంటే సమగ్ర ఫలితం మధ్యస్థం. ఇది యాప్ సమగ్రత విధానం; గ్రంథ శ్లోకం కాదు.';
  static EducationGrade395 gradeChecks(List<EducationCheck395> checks) {
    final hits = checks.where((c) => c.matched && !c.contextual);
    final positive = hits.any((c) => !c.adverse),
        negative = hits.any((c) => c.adverse);
    return positive == negative
        ? EducationGrade395.medium
        : negative
        ? EducationGrade395.bad
        : EducationGrade395.good;
  }

  static EducationGrade395 primaryGrade(List<EducationCheck395> checks) {
    bool hit(String id) => checks.any((c) => c.id == id && c.matched);
    // Transparent app synthesis, not a source-text score. An incidental
    // warning does not erase stronger educational support. All contrary
    // observations remain visible with their own exact conditions.
    final positive =
        (hit('EDU-D24-003') && !hit('EDU-D24-004')) ||
        hit('EDU-D24-012') ||
        hit('EDU-D24-014');
    final negative =
        hit('D24-VIDYA-CORE-05') || (hit('EDU-D24-002') && hit('EDU-D24-004'));
    return positive == negative
        ? EducationGrade395.medium
        : negative
        ? EducationGrade395.bad
        : EducationGrade395.good;
  }

  static EducationGrade395 combine(
    EducationGrade395 principal,
    Iterable<EducationGrade395> support,
  ) {
    if (principal == EducationGrade395.missing) return principal;
    if (principal == EducationGrade395.medium) return principal;
    if (support.any(
      (g) =>
          g == EducationGrade395.missing ||
          (principal == EducationGrade395.good && g == EducationGrade395.bad) ||
          (principal == EducationGrade395.bad && g == EducationGrade395.good),
    ))
      return EducationGrade395.medium;
    return principal;
  }

  static EducationReport395 evaluate(AstroChartResult chart) {
    const needed = {
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    };
    if (!chart.ascendantLongitude.isFinite ||
        !chart.planets.map((p) => p.name).toSet().containsAll(needed) ||
        chart.planets.any((p) => !p.longitude.isFinite)) {
      return const EducationReport395(
        stages: [],
        grade: EducationGrade395.missing,
      );
    }
    final contexts = {
      for (final factor in [1, 4, 24, 9])
        factor: _Edu395(VargaService.calculate(chart, factor)),
    };
    final stages = <EducationStage395>[];
    for (final factor in [1, 4, 24, 9]) {
      final v = contexts[factor]!, out = <EducationCheck395>[];
      void add(
        String id,
        String condition,
        String evidence,
        String source,
        String outcome,
        bool matched, {
        bool adverse = false,
        bool contextual = false,
      }) => out.add(
        EducationCheck395(
          id,
          condition,
          evidence,
          source,
          outcome,
          matched,
          adverse: adverse,
          contextual: contextual,
        ),
      );
      if (factor == 24) {
        void master(
          int n,
          String condition,
          String evidence,
          String outcome,
          bool met, {
          bool adverse = false,
          bool contextual = false,
        }) {
          final spec = D24EducationRegistry.rules.singleWhere(
            (r) => r.id == 'EDU-D24-${n.toString().padLeft(3, '0')}',
          );
          add(
            spec.id,
            '$condition\nమూల IF: ${spec.rule}',
            evidence,
            '${spec.source} (మాస్టర్ రిజిస్ట్రీలోని పేజీ సూచనలు); d24_education_master_rules.json. నిర్వచనాలు: USER-EDU-REVIEW-395.',
            outcome,
            met,
            adverse: adverse,
            contextual: contextual,
          );
        }

        master(
          1,
          'D24 లగ్నంపై శుభ సంబంధం',
          v.houseAudit(1),
          'చదువుపై ఆసక్తికి మంచి మద్దతు.',
          v.benHouse(1),
        );
        master(
          2,
          'D24 లగ్నంపై పాప సంబంధం AND శుభ సంబంధం లేకపోవడం',
          v.houseAudit(1),
          'చదువుపై ఆసక్తి / నిరంతరతలో జాగ్రత్త అవసరం.',
          v.malHouse(1) && !v.benHouse(1),
          adverse: true,
        );
        final l = v.lord(1);
        master(
          3,
          'D24 లగ్నాధిపతి కేంద్ర/త్రికోణంలో OR స్వ/ఉచ్చంలో OR శుభ సంబంధంతో',
          v.audit(l),
          'విద్య కొనసాగింపుకు లగ్నాధిపతి మద్దతు ఉంది.',
          v.strong(l) ||
              [1, 4, 5, 7, 9, 10].contains(v.house(l)) ||
              v.benPlanet(l),
        );
        master(
          4,
          'D24 లగ్నాధిపతి నీచంలో OR ప్రత్యక్ష పాప సంబంధంతో',
          v.audit(l),
          'విద్యలో ఆలస్యం / అదనపు కృషి సూచన.',
          v.debil(l) || v.malPlanet(l),
          adverse: true,
        );
        master(
          5,
          'D24 సూర్యుడు స్వ/ఉచ్చంలో OR శుభ సంబంధంతో',
          v.audit('Sun'),
          'అభ్యసనంలో అంకితభావానికి మద్దతు.',
          v.strong('Sun') || v.benPlanet('Sun'),
        );
        master(
          6,
          'D24 చంద్రుడు స్వ/ఉచ్చంలో OR శుభ సంబంధంతో OR గురు/బుధ యుతితో',
          v.audit('Moon'),
          'గ్రహణశక్తి, ఏకాగ్రతకు మంచి మద్దతు.',
          v.strong('Moon') ||
              v.benPlanet('Moon') ||
              v.joined('Moon', 'Mercury') ||
              v.joined('Moon', 'Jupiter'),
        );
        master(
          7,
          'D24 చంద్రుడిపై ప్రత్యక్ష పాప సంబంధం',
          v.audit('Moon'),
          'ఏకాగ్రతలో ఒత్తిడి / ఆటంక సూచన.',
          v.malPlanet('Moon'),
          adverse: true,
        );
        master(
          8,
          'D24 2వ భావం OR అధిపతిపై శుభ సంబంధం',
          v.houseAudit(2),
          'కుటుంబం / అధ్యయన అలవాట్లకు మద్దతు.',
          v.benHouse(2) || v.benPlanet(v.lord(2)),
        );
        master(
          9,
          'D24 2వ భావంపై పాప సంబంధం',
          v.houseAudit(2),
          'కుటుంబ / అధ్యయన వాతావరణంలో ఆటంక సూచన.',
          v.malHouse(2),
          adverse: true,
        );
        master(
          10,
          'D24 4వ అధిపతి స్వ/ఉచ్చం AND 4వ భావం/అధిపతికి శుభ సంబంధం',
          v.houseAudit(4),
          'పాఠశాల విద్యకు మంచి మద్దతు.',
          v.strong(v.lord(4)) && (v.benHouse(4) || v.benPlanet(v.lord(4))),
        );
        master(
          11,
          'D24 4వ భావం OR అధిపతిపై పాప సంబంధం',
          v.houseAudit(4),
          'ప్రాథమిక విద్య / చదివే వాతావరణంలో ఆటంకం.',
          v.malHouse(4) || v.malPlanet(v.lord(4)),
          adverse: true,
        );
        master(
          12,
          'D24 5వ అధిపతి స్వ/ఉచ్చ స్థితి',
          v.houseAudit(5),
          'డిగ్రీ స్థాయి విద్యకు నిర్దిష్ట బల మద్దతు.',
          v.strong(v.lord(5)),
        );
        final nodes = [2, 4, 5, 9].where((h) => v.nodes(h)).toList();
        master(
          13,
          'D24 విద్యాభావంలో రాహు/కేతు యుతి; శుభ మద్దతును కూడా చూపించాలి',
          'రాహు/కేతు ఉన్న విద్యాభావాలు: $nodes; శుభ మద్దతు: ${nodes.where((h) => v.benHouse(h) || v.benPlanet(v.lord(h))).toList()}',
          'చదువులో విరామం / మార్పుపై జాగ్రత్త; శుభ మద్దతు ఉంటే కొనసాగింపు ఆధారం కూడా ఉంది.',
          nodes.isNotEmpty,
          adverse: true,
        );
        master(
          14,
          'D24 9వ అధిపతి స్వ/ఉచ్చ స్థితి',
          v.houseAudit(9),
          'ఉన్నత విద్యకు నిర్దిష్ట బల మద్దతు.',
          v.strong(v.lord(9)),
        );
        master(
          15,
          'D24 8వ అధిపతి స్వ/ఉచ్చ స్థితి',
          v.houseAudit(8),
          'పరిశోధన / లోతైన అధ్యయనానికి బల సూచన.',
          v.strong(v.lord(8)),
          contextual: true,
        );
        // Context indicators never vote for an adverse/favorable academic outcome.
        final away = [
          4,
          9,
          2,
          7,
        ].where((h) => v.linkHouse(v.lord(12), h)).toList();
        final foreign = away.where((h) => v.linkHouse(v.lord(9), h)).toList();
        master(
          16,
          'విద్యాభావానికి 12వ అధిపతి సంబంధం',
          '12వ అధిపతి ${v.audit(v.lord(12))}; సంబంధిత భావాలు $away',
          'హాస్టల్ / ఇంటికి దూరంగా చదివే సూచన.',
          away.isNotEmpty,
          contextual: true,
        );
        master(
          17,
          'అదే విద్యాభావానికి 9వ AND 12వ అధిపతుల సంబంధం',
          'ఒకే భావానికి రెండు అధిపతుల సంబంధం: $foreign',
          'విదేశీ విద్యకు అనుబంధ సూచన.',
          foreign.isNotEmpty,
          contextual: true,
        );
        final d1 = contexts[1]!;
        final reasons = [
          for (final h in [4, 5])
            if ([6, 8, 12].contains(v.house(d1.lord(h))) &&
                v.malJoined(d1.lord(h)))
              'D1 $hవ అధిపతి ${v.audit(d1.lord(h))}',
        ];
        add(
          'D24-VIDYA-CORE-05',
          'D1 4వ/5వ అధిపతి D24లో 6/8/12లో AND మరో పాపగ్రహంతో యుతి',
          reasons.isEmpty
              ? 'రెండు షరతులు ఒకే అధిపతికి కలిపి సరిపోలలేదు.'
              : reasons.join('\n'),
          'విద్యా జ్యోతిష నియమాలు – D24.docx, పేజీ 4; ప్రస్తుతం ఉన్న D24 మూల రిజిస్ట్రీ.',
          'విద్యలో ఆటంకం / మార్పుకు మూల నియమం వర్తించింది.',
          reasons.isNotEmpty,
          adverse: true,
        );
      } else if (factor == 9) {
        final j = JaiminiService.calculate(chart);
        if (!j.hasDegreeTie) {
          final pk = j.charaKarakas.singleWhere((k) => k.code == 'PK').planet;
          final support =
              v.strong(pk) ||
              v.benPlanet(pk) ||
              v.joined(pk, v.signLord(v.signs[pk]!));
          final adverse = v.debil(pk) || v.malPlanet(pk);
          add(
            'EDU-D9-PK-SUPPORT',
            'D9 పుత్రకారకుడు స్వ/ఉచ్చంలో OR శుభ సంబంధం OR రాశి అధిపతితో యుతి',
            'PK=$pk; ${v.audit(pk)}',
            'Education.pdf PDF పేజీ 1, ముద్రిత పేజీ 3; జైమిని విధానం.',
            'విద్యా గ్రహణం / అధ్యయన కొనసాగింపుకు PK మద్దతు.',
            support,
          );
          add(
            'USER-EDU-D9-PK-CAUTION',
            'D9 PK నీచంలో OR పాప సంబంధంతో; గ్రంథంలోని విరుద్ధ స్థితికి యాప్ నిర్దిష్ట పరీక్ష',
            v.audit(pk),
            'Education.pdf PDF పేజీ 1; కార్యరూప నిర్వచనం USER-EDU-REVIEW-395.',
            'విద్యా గ్రహణం / కొనసాగింపులో జాగ్రత్త అవసరం.',
            adverse,
            adverse: true,
          );
        } else {
          add(
            'EDU-D9-PK-TIE',
            'కారక డిగ్రీ సమానత్వం ఉన్నప్పుడు PKను ఊహించకూడదు',
            'జైమిని కారక డిగ్రీ సమానత్వం ఉంది; ఈ ప్రత్యేక PK పరీక్షను గ్రేడ్‌లో కలపలేదు.',
            'Education.pdf PDF పేజీ 1; కారక గణన పరిమితి.',
            'PK నిర్ణయానికి అధిక ఖచ్చితత్వం అవసరం.',
            true,
            contextual: true,
          );
        }
      } else {
        final houses = factor == 1 ? [4, 5, 9] : [4];
        for (final h in houses) {
          final lord = v.lord(h);
          add(
            'USER-EDU-D$factor-H$h-GOOD',
            'D$factor $hవ అధిపతి స్వ/ఉచ్చంలో OR శుభ సంబంధం OR భావంపై శుభ సంబంధం',
            v.houseAudit(h),
            'VARGA-CROSS-006/038/039 పరిశీలన క్రమం మాత్రమే; ఈ స్థితి పరీక్ష USER-EDU-REVIEW-395 యాప్ అనుబంధ నిర్వచనం.',
            'D$factor $hవ భావ పరిశీలనలో విద్యకు మంచి మద్దతు.',
            v.strong(lord) || v.benPlanet(lord) || v.benHouse(h),
          );
          add(
            'USER-EDU-D$factor-H$h-BAD',
            'D$factor $hవ అధిపతి నీచం OR పాప సంబంధం OR భావంపై పాప సంబంధం',
            v.houseAudit(h),
            'యాప్ అనుబంధ స్థితి పరీక్ష USER-EDU-REVIEW-395; ప్రత్యేక గ్రంథ IFగా ప్రకటించలేదు.',
            'D$factor $hవ భావ పరిశీలనలో విద్యకు ఆటంక సూచన.',
            v.debil(lord) || v.malPlanet(lord) || v.malHouse(h),
            adverse: true,
          );
        }
      }
      stages.add(
        EducationStage395(
          factor,
          List.unmodifiable(out),
          principalGrade: factor == 24 ? primaryGrade(out) : null,
        ),
      );
    }
    final d24 = contexts[24]!;
    final levels = [
      for (final pair in const {
        4: 'పాఠశాల / ఇంటర్',
        9: 'డిగ్రీ / B.Tech',
        2: 'PG',
        7: 'Post-PG',
      }.entries)
        _level(d24, pair.key, pair.value),
    ];
    final field = _field(chart, contexts[9]!);
    final principal = stages.singleWhere((s) => s.factor == 24).grade;
    final grade = combine(
      principal,
      stages.where((s) => s.factor != 24).map((s) => s.grade),
    );
    return EducationReport395(
      stages: List.unmodifiable(stages),
      grade: grade,
      levels: levels,
      courses: field.$2,
      fieldAudit: field.$1,
      note: policy,
    );
  }

  static String _level(_Edu395 v, int h, String label) {
    final good = v.strong(v.lord(h)) || v.benHouse(h) || v.benPlanet(v.lord(h));
    final bad = v.debil(v.lord(h)) || v.malHouse(h) || v.malPlanet(v.lord(h));
    final grade = good == bad
        ? 'మధ్యస్థం'
        : good
        ? 'మంచి'
        : 'చెడు';
    final away = v.linkHouse(v.lord(12), h),
        foreign = away && v.linkHouse(v.lord(9), h);
    return '$label — $grade${v.nodes(h) ? "; విరామం/మార్పు జాగ్రత్త" : ""}${v.nodes(h) && good ? "; కొనసాగింపు మద్దతు కూడా ఉంది" : ""}${foreign
        ? "; విదేశీ విద్య సూచన"
        : away
        ? "; ఇంటికి దూరంగా చదువు సూచన"
        : ""}';
  }

  static (String, List<String>) _field(AstroChartResult chart, _Edu395 d9) {
    // Education.pdf p2 explicitly starts in the birth chart, then inspects the
    // nakshatra lord in D1 and D9. Do NOT start from remapped D24 longitude.
    final point = (chart.ascendantLongitude + 120 + 15) % 360;
    final nak = VedicCalculationService.nakshatra(point);
    const lords = [
      'Ketu',
      'Venus',
      'Sun',
      'Moon',
      'Mars',
      'Rahu',
      'Jupiter',
      'Saturn',
      'Mercury',
    ];
    final lord = lords[nak.index % 9], sign = d9.signs[lord]!;
    final nature = D24EducationRegistry.natureForSign(sign);
    final allowed = D24EducationRegistry.educationAllowedForNature(nature);
    final signFields = D24EducationRegistry.educationForSign(sign);
    final joined = d9.signs.keys
        .where((p) => p != lord && d9.joined(p, lord))
        .toList();
    final aspecting = d9.signs.keys
        .where((p) => p != lord && d9.aspect(p, d9.signs[lord]!))
        .toList();
    final fields = <String>{
      ...signFields,
      for (final p in [...joined, ...aspecting])
        ...D24EducationRegistry.educationForPlanet(p),
    }.where(allowed.contains);
    final scored = <MapEntry<String, double>>[];
    for (final f in fields) {
      final score =
          (signFields.contains(f) ? 40.0 : 0.0) +
          (joined.isEmpty
              ? 0
              : 35 *
                    joined
                        .where(
                          (p) => D24EducationRegistry.educationForPlanet(
                            p,
                          ).contains(f),
                        )
                        .length /
                    joined.length) +
          (aspecting.isEmpty
              ? 0
              : 25 *
                    aspecting
                        .where(
                          (p) => D24EducationRegistry.educationForPlanet(
                            p,
                          ).contains(f),
                        )
                        .length /
                    aspecting.length);
      if (score > 0) scored.add(MapEntry(f, score));
    }
    scored.sort((a, b) {
      final n = b.value.compareTo(a.value);
      return n != 0 ? n : a.key.compareTo(b.key);
    });
    return (
      'EDU-D24-018 / USER-EDU-FIELD-395: D1 ఐదవ భావ ప్రారంభం +15° = ${point.toStringAsFixed(4)}°; నక్షత్రం ${VedicCalculationService.nakshatraNamesTe[nak.index]}, అధిపతి $lord; D9 ${EducationResult395.signNames[sign]}, $nature; యుతి=$joined; దృష్టి=$aspecting. Education.pdf PDF పేజీ 2, ముద్రిత పేజీ 4. రంగాల పేర్లు/40–35–25 సరిపోలిక యాప్ సూచన విధానం; కోర్సు లేదా ప్రవేశం ఖచ్చితమనే ఫలితం కాదు.',
      scored.take(5).map((x) => x.key).toList(),
    );
  }
}

class _Edu395 {
  final VargaChartData data;
  late final Map<String, int> signs = {
    for (final p in data.planets) p.name: p.signIndex,
  };
  _Edu395(this.data);
  static const rulers = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];
  static const exalt = {
    'Sun': 0,
    'Moon': 1,
    'Mars': 9,
    'Mercury': 5,
    'Jupiter': 3,
    'Venus': 11,
    'Saturn': 6,
  };
  static const mal = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'},
      ben = {'Jupiter', 'Venus'};
  String signLord(int sign) => rulers[sign];
  int houseSign(int h) => (data.ascendantSignIndex + h - 1) % 12;
  String lord(int h) => rulers[houseSign(h)];
  int house(String p) => (signs[p]! - data.ascendantSignIndex + 12) % 12 + 1;
  bool strong(String p) => rulers[signs[p]!] == p || exalt[p] == signs[p];
  bool debil(String p) =>
      exalt.containsKey(p) && (exalt[p]! + 6) % 12 == signs[p];
  bool joined(String a, String b) => a != b && signs[a] == signs[b];
  bool aspect(String p, int target) {
    if (p == 'Rahu' || p == 'Ketu') return false;
    final diff = (target - signs[p]! + 12) % 12;
    return diff == 6 ||
        (p == 'Mars' && (diff == 3 || diff == 7)) ||
        (p == 'Jupiter' && (diff == 4 || diff == 8)) ||
        (p == 'Saturn' && (diff == 2 || diff == 9));
  }

  bool relation(String a, String b) =>
      a != b && (joined(a, b) || aspect(a, signs[b]!) || aspect(b, signs[a]!));
  bool benPlanet(String p) =>
      ben.any((x) => x != p && (joined(x, p) || aspect(x, signs[p]!)));
  bool malPlanet(String p) =>
      mal.any((x) => x != p && (joined(x, p) || aspect(x, signs[p]!)));
  bool malJoined(String p) => mal.any((x) => x != p && joined(x, p));
  bool benHouse(int h) =>
      ben.any((p) => signs[p] == houseSign(h) || aspect(p, houseSign(h)));
  bool malHouse(int h) =>
      mal.any((p) => signs[p] == houseSign(h) || aspect(p, houseSign(h)));
  bool nodes(int h) => ['Rahu', 'Ketu'].any((p) => signs[p] == houseSign(h));
  bool linkHouse(String p, int h) =>
      signs[p] == houseSign(h) ||
      aspect(p, houseSign(h)) ||
      relation(p, lord(h));
  String audit(String p) =>
      '$p: ${EducationResult395.signNames[signs[p]!]}, ${house(p)}వ భావం; స్వ/ఉచ్చం=${strong(p)}, నీచం=${debil(p)}; శుభ సంబంధం=${benPlanet(p)}, పాప సంబంధం=${malPlanet(p)}';
  String houseAudit(int h) =>
      '$hవ భావం: ${signs.keys.where((p) => signs[p] == houseSign(h)).join(", ")}; అధిపతి ${audit(lord(h))}; భావానికి శుభ సంబంధం=${benHouse(h)}, పాప సంబంధం=${malHouse(h)}';
}
