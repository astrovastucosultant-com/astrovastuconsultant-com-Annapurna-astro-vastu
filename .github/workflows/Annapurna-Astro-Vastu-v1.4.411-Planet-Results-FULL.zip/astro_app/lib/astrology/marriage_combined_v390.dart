import 'astro_models.dart';
import 'dasha_service.dart';
import 'marriage_chrome_if_then_engine.dart';
import 'varga_service.dart';

enum MarriageEvent390 { opportunity, quality, stability }

enum MarriageContext390 { unknown, unmarried, married }

enum MarriageGrade390 { good, bad, medium }

class MarriageEvidence390 {
  final MarriageChromeRule rule;
  final MarriageChromeEvaluation evaluation;
  final Set<String> participants;
  final bool favorable;
  final bool dashaActive;
  const MarriageEvidence390(
    this.rule,
    this.evaluation,
    this.participants,
    this.favorable,
    this.dashaActive,
  );
}

class MarriageCombinedResult390 {
  final MarriageGrade390 grade;
  final String reason, dasha, transit, context;
  final List<MarriageEvidence390> evidence;
  final bool transitLinked;
  final Set<String> activatedRuleIds;
  final int sav7;
  const MarriageCombinedResult390({
    required this.grade,
    required this.reason,
    required this.dasha,
    required this.transit,
    required this.context,
    required this.evidence,
    required this.transitLinked,
    required this.activatedRuleIds,
    required this.sav7,
  });
  static String label(MarriageGrade390 g) => switch (g) {
    MarriageGrade390.good => 'మంచి',
    MarriageGrade390.bad => 'చెడు',
    MarriageGrade390.medium => 'మధ్యస్థం',
  };
}

/// Policy APP-MARRIAGE-JOIN-390 joins existing evaluated source predicates
/// with period and transit activation; it is an app policy, not a book sutra.
/// SAV never creates a source hit, supplies its polarity or vetoes a result.
class MarriageCombined390 {
  static const titles = {
    MarriageEvent390.opportunity: 'వివాహ కాల అనుకూలత',
    MarriageEvent390.quality: 'దాంపత్య సౌఖ్యం',
    MarriageEvent390.stability: 'సంబంధ స్థిరత్వం',
  };
  static const rulers = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];
  static const _positive = {'C01-03', 'C02-02'};
  static Set<String> idsFor(MarriageEvent390 event) => switch (event) {
    MarriageEvent390.opportunity => {
      'C01-03',
      'C02-02',
      'C01-02',
      'C08-01',
      'C15-01',
    },
    MarriageEvent390.quality => {'C01-03', 'C16-01', 'C16-02'},
    MarriageEvent390.stability => {'C01-03', 'C16-01', 'C16-02', 'C06-01'},
  };
  static int ageAt(DateTime birth, DateTime at) {
    var age = at.year - birth.year;
    if (at.month < birth.month || at.month == birth.month && at.day < birth.day)
      age--;
    return age;
  }

  static bool touches(String planet, int from, int target) {
    final d = (target - from + 12) % 12;
    return (planet == 'Jupiter' ? {0, 4, 6, 8} : {0, 2, 6, 9}).contains(d);
  }

  static MarriageGrade390 join({
    required bool allowed,
    required bool positive,
    required bool negative,
    required bool transitLinked,
  }) {
    if (!allowed || !transitLinked || positive == negative)
      return MarriageGrade390.medium;
    return positive ? MarriageGrade390.good : MarriageGrade390.bad;
  }

  static bool periodMatches(
    String maha,
    String antar,
    Set<String> participants,
    Set<String> eventLords,
  ) {
    final targets = {...participants, ...eventLords};
    return participants.isNotEmpty &&
        targets.contains(maha) &&
        targets.contains(antar) &&
        (participants.contains(maha) || participants.contains(antar));
  }

  static MarriageCombinedResult390 evaluate({
    required AstroChartResult chart,
    required DateTime birth,
    required DateTime at,
    required String gender,
    required MarriageEvent390 event,
    required MarriageContext390 maritalContext,
    required int sav7,
    AstroChartResult? transit,
  }) {
    final d9 = VargaService.calculate(chart, 9);
    final seventh = (chart.ascendantSignIndex + 6) % 12;
    final lords = {rulers[seventh], rulers[(d9.ascendantSignIndex + 6) % 12]};
    final system = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birth,
    );
    final path = DashaService.pathAt(system, at);
    final md = path?.mahadasha.lord ?? '', ad = path?.antardasha.lord ?? '';
    final dashaText = path == null
        ? 'ఈ తేదీకి దశ కాలం అందుబాటులో లేదు.'
        : 'వింశోత్తరి: $md / $ad / ${path.pratyantardasha.lord}';
    final evidence = <MarriageEvidence390>[];
    for (final rule in MarriageChromeIfThenEngine.rules.where(
      (r) => idsFor(event).contains(r.id),
    )) {
      final result = MarriageChromeIfThenEngine.evaluate(
        rule,
        chart,
        gender: gender,
      );
      final refs = MarriageChromeIfThenEngine.activationPlanets(
        rule.id,
        chart,
        gender: gender,
      );
      evidence.add(
        MarriageEvidence390(
          rule,
          result,
          Set.unmodifiable(refs),
          _positive.contains(rule.id),
          result.matches && periodMatches(md, ad, refs, lords),
        ),
      );
    }
    final j = transit?.planets.where((p) => p.name == 'Jupiter').firstOrNull;
    final s = transit?.planets.where((p) => p.name == 'Saturn').firstOrNull;
    // Both real transits must contact the SAME natal event target. Separate
    // unrelated contacts cannot pass this join; a contact is not a good omen.
    final targets = <int>{seventh};
    for (final hit in evidence.where((e) => e.dashaActive)) {
      for (final p in chart.planets.where(
        (p) => hit.participants.contains(p.name),
      )) {
        targets.add(p.signIndex);
      }
    }
    final common = j == null || s == null
        ? <int>[]
        : targets
              .where(
                (target) =>
                    touches('Jupiter', j.signIndex, target) &&
                    touches('Saturn', s.signIndex, target),
              )
              .toList();
    final transitText = j == null || s == null
        ? 'గురు / శని గోచార సమాచారం అందుబాటులో లేదు.'
        : 'గురు రాశి ${j.signIndex + 1}; శని రాశి ${s.signIndex + 1}; '
              'ఉమ్మడి సంఘటన లక్ష్య రాశులు: ${common.isEmpty ? 'సరిపోలలేదు' : common.map((v) => v + 1).join(', ')}.';
    final linkedIds = <String>{};
    if (j != null && s != null) {
      for (final hit in evidence.where((e) => e.dashaActive)) {
        final ownTargets = {
          seventh,
          for (final p in chart.planets)
            if (hit.participants.contains(p.name)) p.signIndex,
        };
        if (ownTargets.any(
          (target) =>
              touches('Jupiter', j.signIndex, target) &&
              touches('Saturn', s.signIndex, target),
        ))
          linkedIds.add(hit.rule.id);
      }
    }
    final active = evidence
        .where((e) => linkedIds.contains(e.rule.id))
        .toList();
    var positive = active.any((e) => e.favorable);
    var negative = active.any((e) => !e.favorable);
    if (event == MarriageEvent390.stability) {
      // D7 Ketu alone must never establish separation, nor may the absence
      // of a caution condition establish good marital stability.
      negative =
          active.any((e) => e.rule.id == 'C06-01') &&
          active.any((e) => {'C16-01', 'C16-02'}.contains(e.rule.id));
      if (active.any((e) => !e.favorable) && !negative) positive = false;
    }
    final age = ageAt(birth, at);
    final allowed =
        age >= 18 &&
        (event == MarriageEvent390.opportunity
            ? maritalContext == MarriageContext390.unmarried
            : maritalContext == MarriageContext390.married);
    final grade = join(
      allowed: allowed,
      positive: positive,
      negative: negative,
      transitLinked: linkedIds.isNotEmpty,
    );
    final reason = switch (grade) {
      MarriageGrade390.good =>
        'అనుకూల జన్మయోగం, సంబంధిత మహాదశ–అంతర్దశ, గురు–శని ఉమ్మడి గోచార సంబంధం కలిసి ఉన్నాయి.',
      MarriageGrade390.bad =>
        'ప్రతికూల మూల నియమానికి సంబంధిత మహాదశ–అంతర్దశ, గురు–శని గోచార సంబంధం కలిసి ఉన్నాయి; జాగ్రత్త అవసరం.',
      MarriageGrade390.medium =>
        !allowed
            ? 'వయస్సు / వివాహ స్థితికి అనుగుణంగా జన్మ సూచనలను మాత్రమే పరిశీలించాలి.'
            : positive && negative
            ? 'అనుకూల, ప్రతికూల ఆధారాలు రెండూ కలిసి ఉన్నాయి.'
            : 'జన్మయోగం, ప్రస్తుత దశ, ఉమ్మడి గోచార సంబంధం మిశ్రమంగా ఉన్నాయి.',
    };
    return MarriageCombinedResult390(
      grade: grade,
      reason: reason,
      dasha: dashaText,
      transit: transitText,
      evidence: List.unmodifiable(evidence),
      activatedRuleIds: Set.unmodifiable(linkedIds),
      transitLinked: linkedIds.isNotEmpty,
      sav7: sav7,
      context: 'వయస్సు $age; వివాహ స్థితి: ${maritalContext.name}.',
    );
  }
}
