import 'astro_models.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';
import 'jaimini_service.dart';

/// One explicitly named PVR tradition, not an exclusive religious prescription.
class DeityGuide405 {
  final Map<int, List<TopicCheck398>> checks;
  final Map<int, String> summaries;
  final String conclusion;
  const DeityGuide405(this.checks, this.summaries, this.conclusion);
}

class DeityGuidance405 {
  static const source =
      'P.V.R. Narasimha Rao • Vedic Astrology: An Integrated Approach • '
      '§34.5, Table 78, printed pp.457–458 / PDF pp.469–470 • '
      'https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf';
  static const yogaSource =
      'PVR §13.2, Table 30, printed pp.166–167 / PDF pp.178–179';
  static const deities = <String, List<String>>{
    'Sun': ['శివుడు', 'శ్రీరాముడు'],
    'Moon': ['గౌరి', 'లలిత', 'సరస్వతి', 'శ్రీకృష్ణుడు'],
    'Mars': ['హనుమంతుడు', 'రుద్రుడు', 'సుబ్రహ్మణ్యుడు', 'నరసింహుడు'],
    'Mercury': ['విష్ణువు', 'నారాయణుడు', 'బుద్ధుడు'],
    'Jupiter': [
      'హయగ్రీవుడు',
      'విష్ణువు',
      'పరమేశ్వరుడు',
      'దత్తాత్రేయుడు',
      'గురు స్వరూపం',
    ],
    'Venus': ['లక్ష్మీదేవి', 'పార్వతీదేవి'],
    'Saturn': ['విష్ణువు', 'బ్రహ్మ'],
    'Rahu': ['దుర్గాదేవి', 'నరసింహుడు'],
    'Ketu': ['గణపతి'],
  };
  static String names(String p) => deities[p]!.join(' / ');
  static String? yogakaraka(int asc) => const <int, String>{
    1: 'Saturn',
    3: 'Mars',
    4: 'Mars',
    6: 'Saturn',
    9: 'Venus',
    10: 'Venus',
  }[asc];
  static DeityGuide405 evaluate(AstroChartResult chart) {
    if (!TopicResults398.valid(chart))
      return const DeityGuide405(
        {},
        {},
        'గణనకు సమాచారం లేదు: పూర్తి లగ్న/గ్రహ స్థానాలు కావాలి.',
      );
    final rows = <int, List<TopicCheck398>>{};
    final summaries = <int, String>{};
    final v1 = TopicGeometry398(VargaService.calculate(chart, 1));
    final y = yogakaraka(v1.asc);
    final yoga = y == null
        ? 'ఏకగ్రహ కేంద్ర–త్రికోణ యోగకారకుడు ఈ లగ్నానికి లేడు. ఇతర యోగాలు లేవని అర్థం కాదు.'
        : '$y — ${names(y)}. కేంద్ర–త్రికోణ అధిపత్యం మాత్రమే; యోగ ఫలితం ఖాయమనే తీర్పు కాదు.';
    final dharma = v1.lord(9);
    summaries[1] =
        'యోగకారక దేవత: $yoga\nధర్మమార్గ సహాయక సూచన: $dharma — ${names(dharma)}; ఇది యోగకారక ఎంపిక కాదు.';
    rows[1] = [
      TopicCheck398(
        'PVR-YOGAKARAKA-405',
        'D1లో ఒకే గ్రహానికి కేంద్రం (4/7/10), త్రికోణం (5/9) అధిపత్యం',
        'లగ్న రాశి ${v1.asc + 1}; ${y == null ? "ఈ వర్గీకరణ వర్తించలేదు" : v1.placement(y)}',
        '$yogaSource; దేవత సంబంధం: $source • APP కలయిక',
        yoga,
        y != null,
        contextual: true,
      ),
      TopicCheck398(
        'APP-DHARMA-DEITY-405',
        'D1 నవమాధిపతి దేవత సంబంధాన్ని ధర్మమార్గ అనుబంధంగా నమోదు',
        v1.placement(dharma),
        '$source • APP నవమాధిపతి అన్వయం; ఇష్టదేవత/యోగకారక నిర్ధారణ కాదు',
        'ధర్మమార్గ సహాయక సూచన: $dharma — ${names(dharma)}.',
        true,
        contextual: true,
      ),
    ];
    for (final factor in [20, 24]) {
      final v = TopicGeometry398(VargaService.calculate(chart, factor));
      final lord = v.lord(1);
      final purpose = factor == 20 ? 'సాధన / ఉపాసన' : 'విద్య / శాస్త్ర అధ్యయనం';
      summaries[factor] =
          '$purpose కోసం దేవత సూచన: ${names(lord)}. ఆధారం: D$factor లగ్నాధిపతి $lord.';
      rows[factor] = [
        TopicCheck398(
          'PVR-D$factor-L1-DEITY-405',
          'సంబంధిత వర్గ లగ్నాధిపతి దేవతలను ఆ అంశంలో ఉపాసనకు పరిశీలించాలి',
          'D$factor లగ్న రాశి ${v.asc + 1}; ${v.placement(lord)}',
          source,
          summaries[factor]!,
          true,
          contextual: true,
        ),
      ];
    }
    final j = JaiminiService.calculate(chart);
    final v9 = TopicGeometry398(VargaService.calculate(chart, 9));
    final target = (j.karakamsaSignIndex + 11) % 12;
    if (j.hasDegreeTie) {
      summaries[9] = 'ఇష్టదేవత: ఆత్మకారక డిగ్రీ సమానత్వం వల్ల ఎంపిక పెండింగ్.';
      rows[9] = [
        TopicCheck398(
          'PVR-ISHTA-DEITY-405',
          'AK → D9 కారకాంశం → 12వ స్థానం; బలమైన సంబంధ గ్రహం',
          'కారక డిగ్రీ సమానత్వం; అస్పష్ట కారకాంశంపై దేవత పేరు ఖరారు చేయలేదు.',
          source,
          summaries[9]!,
          null,
          contextual: true,
        ),
      ];
    } else {
      final owner = TopicGeometry398.lords[target];
      final candidates = <String, List<String>>{};
      for (final p in deities.keys) {
        final reasons = <String>[];
        if (v9.sign(p) == target) reasons.add('12వ స్థానంలో ఉంది');
        if (p == owner) reasons.add('12వ రాశి అధిపతి');
        if (v9.aspects(p, target)) reasons.add('12వ రాశిపై పరాశరి గ్రహదృష్టి');
        if (reasons.isNotEmpty) candidates[p] = reasons;
      }
      final occupancy = v9.v.planets
          .where((p) => p.signIndex == target)
          .map((p) => p.name)
          .toList();
      final focus = occupancy.isNotEmpty ? occupancy : candidates.keys.toList();
      summaries[9] =
          'ఇష్టదేవత పరిశీలన — ${occupancy.isNotEmpty ? "12వ స్థాన గ్రహాల దేవతలు" : "సంబంధ గ్రహాల దేవతలు"}: ' +
          focus.map((p) => '$p: ${names(p)}').join('; ') +
          '. పూర్తి బల పోలిక లేక ఒక్క ప్రధాన ఇష్టదేవతను ఖరారు చేయలేదు.';
      rows[9] = [
        for (final entry in candidates.entries)
          TopicCheck398(
            'PVR-ISHTA-${entry.key.toUpperCase()}-405',
            'D9 కారకాంశం నుంచి 12వ రాశిలో ఉండటం/అధిపత్యం/దృష్టి; తుది ఎంపికకు బల పోలిక',
            'AK ${j.atmakaraka}; కారకాంశ రాశి ${j.karakamsaSignIndex + 1}; 12వ రాశి ${target + 1}; ' +
                '${v9.placement(entry.key)}; ${entry.value.join("; ")}',
            '$source • దృష్టి: పరాశరి గ్రహదృష్టి; నోడ్స్‌కు అదనపు దృష్టి కల్పించలేదు',
            'ఇష్టదేవత అభ్యర్థి: ${entry.key} — ${names(entry.key)}; ఇది తుది బల ఎంపిక కాదు.',
            true,
            contextual: true,
          ),
        const TopicCheck398(
          'PVR-ISHTA-STRENGTH-405',
          'సంబంధ గ్రహాల్లో బలమైన గ్రహానికి దేవత సంబంధం తుది పరిశీలన',
          'ఉచ్చ/స్వస్థానం ఒక్కటే పూర్తి గ్రహబల పోలిక కాదు; APP స్కోరుతో దేవతను ర్యాంక్ చేయలేదు.',
          source,
          'ఒక్క ప్రధాన ఇష్టదేవత నిర్ణయానికి పూర్తి బల ప్రమాణం / గురుసంప్రదాయ నిర్ణయం అవసరం.',
          null,
          contextual: true,
        ),
      ];
    }
    return DeityGuide405(
      rows,
      summaries,
      '${summaries[20]}\n${summaries[1]}\n${summaries[9]}\n'
      'ఇవి PVR మూలంలోని ప్రత్యామ్నాయ దేవత స్వరూపాలు. కుటుంబ/గురు సంప్రదాయం ప్రకారం ఒక స్వరూపాన్ని ఎంచుకోవచ్చు; '
      'యోగం, సంపద, సిద్ధి లేదా మోక్షం ఖాయమనే హామీ కాదు.',
    );
  }
}
