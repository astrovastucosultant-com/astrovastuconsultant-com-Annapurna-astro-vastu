/// Devotional support, separate from medical outcomes and astrology grades.
class ClientGuidanceData406 {
  final String topicId,
      title,
      primary,
      reason,
      alternative,
      practice,
      action,
      limit;
  final int factor;
  final List<String> evidence, sources;
  const ClientGuidanceData406({
    required this.topicId,
    required this.title,
    required this.factor,
    required this.primary,
    required this.reason,
    required this.alternative,
    required this.practice,
    required this.action,
    required this.limit,
    required this.evidence,
    required this.sources,
  });
}
