import 'astro_models.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';
import 'd16_source_predicate_v408.dart';
import 'deity_guidance_v405.dart';
import 'client_guidance_model_v406.dart';

class VehicleTopic408 {
  static const id = 'VARGA-CROSS-015';
  static const original =
      'Mallikarjuna 255 Rules PDF • D16 పేజీ 15; CROSS-068/069/070 పేజీ 29';
  static const pvr =
      'P.V.R. Narasimha Rao • Vedic Astrology: An Integrated Approach • https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf';
  static const road =
      'WHO Road traffic injuries • https://www.who.int/news-room/fact-sheets/detail/road-traffic-injuries';
  static const note =
      'APP-VEHICLE-408: మూల క్రమం D1 → D4 → D16. D16 ప్రధాన వాహన/సౌకర్య పరిశీలన; D1 పునాది; D4 నేపథ్య అనుబంధం. '
      'స్వ/ఉచ్చ రాశి లేదా గురు/శుక్ర సంబంధం మద్దతు; నీచం/6/8/12 స్థానం లేదా ఇతర పాప సంబంధం జాగ్రత్తగా నిర్వచించిన APP శాఖలు. '
      'ఇవి పూర్తి షడ్బలం, VARGA-D16-001/002 పూర్తి బలానికి ప్రత్యామ్నాయం కావు. చంద్రుని అనుకూల/ప్రతికూల పూర్తి నిర్వచనం లేక మానసిక ఆరోగ్య నిర్ధారణ కల్పించలేదు. '
      'D16 ప్రధాన గ్రేడ్‌కు D1 ఏకపక్ష విరుద్ధ సూచన ఉంటే మిశ్రమం; D4ను ప్రధాన హిట్‌గా కలపలేదు. '
      'మూల VARGA-D16-005ను పాత రూల్ ఇంజిన్‌తో ఒకే predicate ద్వారా పరీక్షించాం. నోడ్స్ ప్రత్యేక దృష్టులు లేవు; స్వయుతి లేదు. '
      'వాహనం ఇప్పటికే ఉందని, కొనుగోలు ఖాయమని, రకం/ధర/తేదీ, ప్రమాదం లేదా మరణం ఖాయమని, ప్రమాద శాతం ప్రకటించలేదు. '
      'D16 ఇక్కడ కనిపించే పరాశర గణన పద్ధతితోనే పరిశీలించాం. భద్రతా సూచనలు అందరికీ వర్తిస్తాయి; జాతకం వాటికి ప్రత్యామ్నాయం కాదు.';
  static TopicGrade398 combine(
    TopicGrade398 principal,
    TopicGrade398 foundation,
  ) {
    if (principal == TopicGrade398.missing) return principal;
    if (principal == TopicGrade398.mixed || principal == TopicGrade398.context)
      return TopicGrade398.mixed;
    final opposite = principal == TopicGrade398.supportive
        ? TopicGrade398.caution
        : TopicGrade398.supportive;
    return foundation == opposite ? TopicGrade398.mixed : principal;
  }

  static TopicReport398 evaluate(AstroChartResult chart) {
    if (!TopicResults398.valid(chart))
      return const TopicReport398(
        'వాహన సుఖం / సౌకర్యాలు',
        id,
        [],
        TopicGrade398.missing,
        'లగ్నం, తొమ్మిది గ్రహాల పూర్తి స్థానాలు కావాలి.',
        note,
      );
    final d1 = stage(chart, 1), d4 = stage(chart, 4), d16 = stage(chart, 16);
    final grade = combine(d16.grade, d1.grade);
    final active = d16.checks
        .where((c) => c.matched == true && !c.contextual)
        .toList();
    String aspect(Iterable<TopicCheck398> rows) {
      final x = rows.where((c) => c.matched == true && !c.contextual);
      final good = x.any((c) => !c.adverse), bad = x.any((c) => c.adverse);
      return good && bad
          ? 'మద్దతు, జాగ్రత్త రెండూ ఉన్నాయి'
          : good
          ? 'మద్దతు సూచనలు ఉన్నాయి'
          : bad
          ? 'శ్రద్ధ అవసరమనే సూచనలు ఉన్నాయి'
          : 'ఈ పరీక్షల్లో ఏకపక్ష సూచన లేదు';
    }

    final conclusion =
        'వాహన సమకూర్పు పరిశీలన: ${aspect(d16.checks.where((c) => c.id.contains("H4") || c.id.contains("L4")))}. కొనుగోలు హామీ/తేదీ కాదు.\n'
        'సౌకర్యం / సంతృప్తి: ${aspect(d16.checks.where((c) => c.id.contains("Venus") || c.id.contains("Moon") || c.id.contains("L1")))}.\n'
        'నిర్వహణ / అదనపు శ్రద్ధ: ${active.any((c) => c.adverse) ? "నమోదైన ఒత్తిడి సూచనల నేపథ్యంలో వాహన స్థితి, నిర్వహణ ఖర్చులు, ప్రయాణ అలవాట్లపై శ్రద్ధ పెట్టండి." : "ప్రత్యేక ఒత్తిడి ఈ పరీక్షల్లో నమోదు కాలేదు; సాధారణ నిర్వహణ, ప్రయాణ భద్రత కొనసాగించండి."}\n'
        'D1: ${d1.grade.label}; D16: ${d16.grade.label}. D4 నేపథ్య అనుబంధం మాత్రమే. ప్రమాదం జరుగుతుందనే తీర్పు కాదు.';
    final v = TopicGeometry398(VargaService.calculate(chart, 16));
    final lord = v.lord(1), forms = DeityGuidance405.deities[v.lord(1)]!;
    final guide = ClientGuidanceData406(
      topicId: id,
      title: 'వాహన సుఖం — ఆరాధన / ఆచరణ',
      factor: 16,
      primary: forms.first,
      reason:
          'D16 లగ్న రాశి ${v.asc + 1}; లగ్నాధిపతి $lord. ${v.placement(lord)}. PVR §34.4–34.5లో సౌకర్యాలకు D16 లగ్నాధిపతి ఆరాధన సూచించారు. '
          'Table 78 ప్రత్యామ్నాయాల్లో మొదటి స్వరూపం చూపడం APP ఎంపిక; ఒక్కటే సరైన దేవత అని కాదు.',
      alternative: forms.length > 1
          ? 'అదే గ్రహానికి ఇతర మూల స్వరూపాలు: ${forms.skip(1).join(" / ")}. కుటుంబ/గురు సంప్రదాయానికి అనుగుణంగా ఒకటి ఎంచుకోవచ్చు.'
          : 'ఇప్పటికే అనుసరించే కుటుంబ/గురు సంప్రదాయ ప్రార్థనను కొనసాగించవచ్చు.',
      practice:
          'సరళ ప్రార్థన, నామస్మరణ లేదా తెలిసిన స్తోత్రం. దీక్షా మంత్రసాధనకు గురు మార్గదర్శకత్వం. ఖరీదైన పూజ, జపసంఖ్య/గడువు లేదా ప్రయాణ తేదీని తప్పనిసరి చేయలేదు.',
      action:
          'కొనుగోలు ముందు వాహన స్థితి, పత్రాలు, నిర్వహణ అవసరాలు పరిశీలించండి. వాహనాన్ని సకాలంలో సర్వీస్ చేయించండి. హెల్మెట్/సీట్‌బెల్ట్, పిల్లలకు తగిన రక్షణ ఉపయోగించండి. వేగం నియంత్రించండి; మద్యం సేవించి లేదా ఫోన్ వాడుతూ డ్రైవ్ చేయవద్దు.',
      limit:
          'ఆరాధన ప్రయాణ భద్రతకు ప్రత్యామ్నాయం కాదు. అనుకూల జాతక సూచన ఉన్నా జాగ్రత్తలు అవసరమే. ప్రమాదం, నష్టం లేదా మరణం ఖాయం/శాతం అనే ఫలితం ఇవ్వలేదు.',
      evidence: [
        for (final c in active) '${c.id}: ${c.evidence}',
        if (active.isEmpty) 'ప్రధాన D16 హిట్ ఈ పరీక్షల్లో నమోదు కాలేదు.',
      ],
      sources: [
        DeityGuidance405.source,
        '$pvr • §34.4 printed p.454/PDF p.466; §9.4 printed pp.89–90/PDF pp.101–102',
        original,
        road,
      ],
    );
    return TopicReport398(
      'వాహన సుఖం / సౌకర్యాలు',
      id,
      [d1, d4, d16],
      grade,
      conclusion,
      note,
      clientGuidance: guide,
    );
  }

  static TopicStage398 stage(AstroChartResult chart, int factor) {
    final v = TopicGeometry398(VargaService.calculate(chart, factor));
    final checks = <TopicCheck398>[];
    final context = factor == 4;
    final targets = <String, Set<String>>{};
    void role(String name, String p) =>
        targets.putIfAbsent(p, () => <String>{}).add(name);
    role('L4', v.lord(4));
    role('Venus', 'Venus');
    if (factor == 16) {
      role('L1', v.lord(1));
      role('Moon', 'Moon');
    }
    if (factor == 4) role('L1', v.lord(1));
    for (final e in targets.entries) {
      final p = e.key, label = e.value.join('/'), token = e.value.join('_');
      final good = v.touching(v.sign(p), {'Jupiter', 'Venus'}.difference({p}));
      final bad = v.touching(
        v.sign(p),
        TopicGeometry398.malefics.difference({p}),
      );
      final dignity = v.dignity(p);
      final evidence =
          '${v.placement(p)}; $dignity; పాత్ర $label; శుభ సంబంధం ${good.isEmpty ? "లేదు" : good}; ఇతర పాప సంబంధం ${bad.isEmpty ? "లేదు" : bad}';
      checks.add(
        TopicCheck398(
          'APP-VEHICLE-D$factor-$token-$p-SUPPORT-408',
          'స్వ/ఉచ్చ రాశి OR ఇతర గురు/శుక్ర యుతి/పరాశరి దృష్టి',
          evidence,
          'APP-VEHICLE-408 • $original; నిర్దిష్ట రాశి గౌరవం/సంబంధ శాఖ, పూర్తి బల నిర్వచనం కాదు',
          'D$factor $label $p: ${context ? "సౌకర్యాల నేపథ్యానికి అనుబంధం" : "వాహన సౌకర్యం/సంతృప్తి పరిశీలనకు మద్దతు"}.',
          {'స్వరాశి', 'ఉచ్చం'}.contains(dignity) || good.isNotEmpty,
          contextual: context,
        ),
      );
      checks.add(
        TopicCheck398(
          'APP-VEHICLE-D$factor-$token-$p-CAUTION-408',
          'నీచ రాశి OR 6/8/12 స్థానం OR ఇతర పాప యుతి/దృష్టి',
          evidence,
          'APP-VEHICLE-408 • ఒత్తిడి అనుబంధం; ప్రమాద నిర్ధారణ కాదు',
          'D$factor $label $p: సౌకర్యం, నిర్వహణ, ప్రయాణ అలవాట్లపై శ్రద్ధ సూచన.',
          dignity == 'నీచం' ||
              {6, 8, 12}.contains(v.house(p)) ||
              bad.isNotEmpty,
          adverse: true,
          contextual: context,
        ),
      );
    }
    checks.add(
      TopicCheck398(
        factor == 1
            ? 'VARGA-CROSS-068'
            : factor == 4
            ? 'VARGA-CROSS-069'
            : 'VARGA-CROSS-070',
        'D$factor వాహన సుఖం మూల పరిశీలన క్రమం',
        '4వ భావం రాశి ${v.houseSign(4) + 1}; ${v.placement(v.lord(4))}; ${v.placement("Venus")}',
        original,
        factor == 4
            ? 'D4 స్థిరాస్తి/సౌకర్య నేపథ్యం వాహన సమకూర్పుకు స్వతంత్ర తీర్పు కాదు.'
            : 'మూల పరిశీలన క్రమం అమలైంది; workflowను శుభఫల హిట్‌గా లెక్కించలేదు.',
        true,
        contextual: true,
      ),
    );
    if (factor == 16) {
      final fourth = v.v.planets
          .where((p) => p.signIndex == v.houseSign(4))
          .map((p) => p.name)
          .toSet();
      checks.add(
        TopicCheck398(
          'PVR-D16-H4-BENEFIC-408',
          'D16 నాలుగో రాశికి గురు OR శుక్ర యుతి/పరాశరి దృష్టి — శుభ ప్రభావంలోని స్పష్టమైన శాఖ',
          '4వ రాశి ${v.houseSign(4) + 1}; గురు/శుక్ర సంబంధం: ${v.touching(v.houseSign(4), {"Jupiter", "Venus"})}',
          '$pvr • §9.4 printed pp.89–90/PDF pp.101–102; పరాశరి గ్రహదృష్టి శాఖ స్పష్టంగా నిర్వచించాం',
          'వాహన వినియోగంలో సౌకర్యం/సంతృప్తికి సంప్రదాయ మద్దతు.',
          v.influenced(v.houseSign(4), {'Jupiter', 'Venus'}),
        ),
      );
      checks.add(
        TopicCheck398(
          'VARGA-D16-005',
          'D16 నాలుగో భావంలో కుజుడు లేదా రాహువు AND కనీసం మరో పాపగ్రహ యుతి',
          '4వ భావంలోని గ్రహాలు: ${fourth.isEmpty ? "లేవు" : fourth.join(", ")}; పాపగ్రహాలు: ${fourth.intersection(D16SourcePredicate408.malefics).join(", ")}',
          '$original • పాత/కొత్త ఇంజిన్ ఒకే D16SourcePredicate408ను ఉపయోగిస్తాయి',
          'వాహన నిర్వహణ/ప్రయాణ జాగ్రత్తలకు మూల సూచన; ప్రమాదం ఖాయమని కాదు.',
          D16SourcePredicate408.fourthConjunction(fourth),
          adverse: true,
        ),
      );
      checks.add(
        const TopicCheck398(
          'VARGA-D16-001',
          'D16 నాలుగో భావం OR నాలుగో అధిపతి పూర్తి బలం',
          'రాశి గౌరవం, సంబంధం APP శాఖల్లో నమోదయ్యాయి; అవే పూర్తి బలం కాదు.',
          original,
          'సొంత వాహన సమకూర్పు మూల బల షరతుకు అదనపు స్పష్టత అవసరం.',
          null,
          contextual: true,
        ),
      );
      checks.add(
        TopicCheck398(
          'VARGA-D16-002',
          'D16 లగ్నంలో శుక్రుడు AND పూర్తి బలం',
          v.placement('Venus'),
          original,
          'శుక్ర లగ్నస్థితి వేరు; పూర్తి బలాన్ని స్వరాశి ఒక్కటితో నిర్ణయించలేదు.',
          v.house('Venus') == 1 ? null : false,
          contextual: true,
        ),
      );
      for (final entry in {
        'VARGA-D16-003': 'అనుకూల',
        'VARGA-D16-004': 'ప్రతికూల',
      }.entries) {
        checks.add(
          TopicCheck398(
            entry.key,
            'D16 లగ్నంలో చంద్రుడు AND ${entry.value} పూర్తి స్థితి',
            v.placement('Moon'),
            original,
            'చంద్రుని రాశి/సంబంధం APP శాఖల్లో వేరు నమోదు; ఇది మానసిక ఆరోగ్య నిర్ధారణ కాదు.',
            v.house('Moon') == 1 ? null : false,
            contextual: true,
          ),
        );
      }
    }
    final deity = DeityGuidance405.names(v.lord(1));
    return TopicStage398(
      factor,
      checks,
      deitySummary: factor == 16
          ? 'ప్రధాన ఆరాధన సూచిక: D16 లగ్నాధిపతి ${v.lord(1)} — $deity. కుటుంబ/గురు సంప్రదాయం ప్రకారం ఒక స్వరూపం చాలు.'
          : 'D$factor ${factor == 4 ? "సౌకర్యాల నేపథ్య అనుబంధం" : "వాహన సుఖానికి పునాది"}; ప్రధాన ఆరాధనా సూచన D16 ఆధారితం.',
    );
  }
}
