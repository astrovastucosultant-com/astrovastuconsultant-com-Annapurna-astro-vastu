import 'astro_models.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';
import 'd2_dhana_asthi_registry.dart';
import 'dasha_service.dart';
import 'goel_hora_class_v410.dart';
import 'money_flow_source_v410.dart';
import 'mahavastu_wealth_sources_v410.dart';
import 'tantra_wealth_sources_v411.dart';

class WealthSection410 {
  final String key, title, note;
  final List<TopicCheck398> checks;
  const WealthSection410(this.key, this.title, this.checks, [this.note = '']);
}

class WealthPair410 {
  final String a, b;
  final bool strong;
  final String evidence;
  const WealthPair410(this.a, this.b, this.strong, this.evidence);
  String get key => ([a, b]..sort()).join('|');
}

class WealthDetail410 {
  final String level, summary, provenance;
  final int yogaCount, uniquePairCount, d1PairCount, induPairCount;
  final List<WealthSection410> sections;
  final List<WealthPair410> d1Pairs, induPairs;
  const WealthDetail410({
    required this.level,
    required this.summary,
    required this.provenance,
    required this.yogaCount,
    required this.uniquePairCount,
    required this.d1PairCount,
    required this.induPairCount,
    required this.sections,
    required this.d1Pairs,
    required this.induPairs,
  });
}

/// Preserves source wording; every positional-strength/channel policy is explicit.
/// No monetary thresholds are invented for the traditional level names.
class WealthAnalysis410 {
  static const userSource =
      'Dhana_Aasthi_Rules.pdf • యూజర్ ఇచ్చిన క్లాస్ పునర్వ్యాఖ్యానం';
  static const pvr =
      'P.V.R. Narasimha Rao • Vedic Astrology: An Integrated Approach • §11.9 / §11.10 • https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf';
  static const phala =
      'Mantreswara • Phaladeepika • Ch.5.1–8 / Ch.6.19,21 • https://lakshminarayanlenasia.com/articles/phaldipika.pdf';
  static const provenance =
      'మూలంలోని స్థాయి పేర్లు/ఫలితాలు యథాతథంగా చూపాం. కోటీశ్వర/లక్షాధికారి పదాలకు నేటి కరెన్సీ మొత్తం లేదా హామీ నిర్ధారించలేదు. '
      'V.P. Goel క్లాస్‌గా మీరు గుర్తించిన డేటా పునర్వ్యాఖ్యానం ఉపయోగించాం; అసలు వీడియో/టైమ్‌స్టాంప్ అందుబాటులో లేక ప్రతి వాక్యాన్ని స్వతంత్రంగా Goel మూలంతో ధృవీకరించినట్లు చూపలేదు. '
      'వెబ్ అదనాలు PVR/ఫలదీపిక పేర్లతో వేరు. APP అన్వయాల్లో బలం = నీచం కాకుండా స్వ/ఉచ్చ/కేంద్ర/త్రికోణ స్థానం; ఇది పూర్తి షడ్బల గణన కాదు. '
      'ST-001లో అననుకూల సంబంధానికి ఈ APP పరీక్షలో ధనయోగ గ్రహానికి వేరే 6/8/12 అధిపతి యుతి/పరస్పర దృష్టి/పరివర్తనను తీసుకున్నాం; ద్వంద్వ అధిపత్యం మాత్రమే సంబంధంగా లెక్కించలేదు. '
      'బలం/అననుకూలతకు మూలంలోని అస్పష్ట పదాలపై ఈ కార్యనిర్వాహక అన్వయాన్ని స్పష్టంగా చూపాం. '
      'ఒకే గ్రహజంటను వేర్వేరు భావాధిపత్యాల వల్ల రెండుసార్లు లెక్కించలేదు; D1–ఇందు ఒకే జంటకు మొత్తం ఒక్క జంట, ఆధారాలు విడిగా. '
      'నగదు/ఆస్తి/వారసత్వం/లాభం/ఖర్చు వేర్వేరు. ఇందు లగ్నం నుంచే నగలు లేదా ఇంటి రకం తేల్చలేదు. '
      'ఎవరి ద్వారా అనే భవార్థ అన్వయం సంబంధిత వ్యవహారాన్ని సూచిస్తుంది; నిర్దిష్ట వ్యక్తి తప్పు చేశాడని లేదా చేయబోతున్నాడని నిర్ధారణ కాదు. '
      'దశ పట్టికలో తేదీలు ప్రస్తుత DashaService 365.2425 రోజుల సంవత్సరం ప్రకారం; గోచారం కలపక సంఘటనకు తుది తేదీ ఇవ్వలేదు.';
  static const names = [
    'Sun',
    'Moon',
    'Mars',
    'Mercury',
    'Jupiter',
    'Venus',
    'Saturn',
    'Rahu',
    'Ketu',
  ];
  static const people = {
    'Sun': 'తండ్రి',
    'Moon': 'తల్లి',
    'Mars': 'శత్రువు/ప్రత్యర్థి',
    'Mercury': 'స్నేహితుడు',
    'Jupiter': 'సోదరుడు',
    'Venus': 'భార్య',
    'Saturn': 'సేవకుడు',
  };
  static const work = {
    'Sun': 'లోహాలు, వైద్యం, రాజసేవ',
    'Moon': 'జల ఉత్పత్తులు, వ్యవసాయం, వస్త్ర వ్యాపారం',
    'Mars': 'లోహాలు, భూమి, వంట, సాహస కార్యాలు',
    'Mercury': 'రచన, లెక్కలు, జ్యోతిషం, పౌరోహిత్యం',
    'Jupiter': 'శాస్త్రబోధన, ధర్మబోధన, రుణ వ్యాపారం',
    'Venus': 'కళలు, నగలు, సుగంధాలు, విలాస వస్తువులు',
    'Saturn': 'శ్రమ, వ్యవసాయ ఉత్పత్తులు, చెక్క పనులు',
  };
  // These are explicitly application bhava interpretations, not new Goel quotes.
  static const channels = {
    1: 'స్వప్రయత్నం, వ్యక్తిగత నైపుణ్యం',
    2: 'కుటుంబ వనరులు, పొదుపు, వాక్కు',
    3: 'సోదరులు, స్వప్రయత్నం, సమాచార/రచనా పనులు',
    4: 'తల్లి, ఇల్లు, భూమి, వాహన వ్యవహారాలు',
    5: 'విద్య, సృజన, సంతానం, పెట్టుబడి వ్యవహారాలు',
    6: 'ఉద్యోగ సేవ, రుణాలు, పోటీ/వివాద వ్యవహారాలు',
    7: 'జీవితభాగస్వామి, వ్యాపార భాగస్వాములు, కస్టమర్లు',
    8: 'ఉమ్మడి వనరులు, వారసత్వ/బీమా వ్యవహారాలు',
    9: 'తండ్రి, గురువు, బోధన, దూరప్రాంత సంబంధాలు',
    10: 'వృత్తి, ఉద్యోగం, సంస్థలు, అధికార వ్యవహారాలు',
    11: 'లాభం, స్నేహ వర్గం, నెట్‌వర్క్, పెద్ద తోబుట్టువులు',
    12: 'విదేశ/దూర నివాసం, ఖర్చు, దానం',
  };
  static bool own(TopicGeometry398 v, String p) =>
      TopicGeometry398.lords[v.sign(p)] == p;
  static bool exalt(TopicGeometry398 v, String p) =>
      TopicGeometry398.exalts[p] == v.sign(p);
  static bool debilitated(TopicGeometry398 v, String p) =>
      TopicGeometry398.exalts.containsKey(p) &&
      (TopicGeometry398.exalts[p]! + 6) % 12 == v.sign(p);
  static bool strong(TopicGeometry398 v, String p) =>
      !debilitated(v, p) &&
      (own(v, p) || exalt(v, p) || {1, 4, 5, 7, 9, 10}.contains(v.house(p)));
  static bool weak(TopicGeometry398 v, String p) =>
      debilitated(v, p) ||
      (!(own(v, p) || exalt(v, p)) && {6, 8, 12}.contains(v.house(p)));
  static bool relation(TopicGeometry398 v, String a, String b) =>
      a != b &&
      (v.conj(a, b) ||
          (v.aspects(a, v.sign(b)) && v.aspects(b, v.sign(a))) ||
          v.exchange(a, b));
  static List<WealthPair410> pairs(TopicGeometry398 v) {
    final lords = [
      for (final h in [2, 5, 9, 11]) v.lord(h),
    ].toSet().toList()..sort();
    return [
      for (var a = 0; a < lords.length; a++)
        for (var b = a + 1; b < lords.length; b++)
          if (relation(v, lords[a], lords[b]))
            WealthPair410(
              lords[a],
              lords[b],
              strong(v, lords[a]) && strong(v, lords[b]),
              '${v.placement(lords[a])}; ${v.placement(lords[b])}; యుతి ${v.conj(lords[a], lords[b])}; పరస్పర దృష్టి ${v.aspects(lords[a], v.sign(lords[b])) && v.aspects(lords[b], v.sign(lords[a]))}; పరివర్తన ${v.exchange(lords[a], lords[b])}; బల అన్వయం ${strong(v, lords[a])}/${strong(v, lords[b])}',
            ),
    ];
  }

  static String positions(TopicGeometry398 v) => [
    for (final p in names)
      '${v.placement(p)}; ${v.dignity(p)}; APP బలం ${strong(v, p)}',
  ].join('\n');
  static TopicCheck398 app(
    String id,
    String condition,
    String evidence,
    String result,
    bool? hit, {
    bool adverse = false,
    bool context = false,
    String source = 'APP భవార్థ అన్వయం; మూల ఉల్లేఖనం కాదు',
  }) => TopicCheck398(
    id,
    condition,
    evidence,
    source,
    result,
    hit,
    adverse: adverse,
    contextual: context,
  );
  static TopicCheck398 sourceRule(
    String id,
    bool? hit,
    String evidence, {
    bool adverse = false,
    bool context = false,
  }) {
    final r = D2DhanaAsthiRegistry.rules.singleWhere((r) => r.id == id);
    return TopicCheck398(
      r.id,
      r.condition,
      evidence,
      '$userSource • పేజీ ${r.sourcePage}; ${r.sourceChart}',
      r.result,
      hit,
      adverse: adverse,
      contextual: context,
    );
  }

  static WealthDetail410 evaluate(
    AstroChartResult chart, {
    required VargaChartData d1,
    required VargaChartData indu,
    required VargaChartData labha,
    required Set<String> benefics,
  }) {
    if (!TopicResults398.valid(chart))
      throw ArgumentError('complete chart required');
    final a = TopicGeometry398(d1),
        i = TopicGeometry398(indu),
        v4 = TopicGeometry398(VargaService.calculate(chart, 4));
    final mal = TopicGeometry398.malefics, ben = benefics;
    final d1Pairs = pairs(a), induPairs = pairs(i);
    final d1Strong = d1Pairs.where((p) => p.strong).toList(),
        indStrong = induPairs.where((p) => p.strong).toList();
    final participants = {
      for (final p in indStrong) ...[p.a, p.b],
    };
    final interferences = <String>[];
    for (final dh in [6, 8, 12])
      for (final p in participants)
        if (relation(i, p, i.lord(dh)))
          interferences.add('$dh L ${i.lord(dh)} ↔ $p');
    final oc = indu.planets
        .where((p) => p.signIndex == i.asc)
        .map((p) => p.name)
        .toSet();
    final cleanBen =
        oc.intersection(ben).isNotEmpty &&
        oc.intersection(mal).isEmpty &&
        i.aspectSenders(i.asc, mal).isEmpty;
    final exaltBad = oc.intersection(mal).any((p) => exalt(i, p));
    final ordinaryBad = oc
        .intersection(mal)
        .any((p) => TopicGeometry398.exalts.containsKey(p) && !exalt(i, p));
    final ilLord = i.lord(1);
    final illordRisk =
        {3, 6, 8, 12}.contains(i.house(ilLord)) &&
        i.touching(i.sign(ilLord), ben.difference({ilLord})).isEmpty;
    final levelHits = <String, bool>{
      'D2-ST-001':
          (cleanBen || exaltBad) &&
          indStrong.isNotEmpty &&
          interferences.isEmpty,
      'D2-ST-002': indStrong.isNotEmpty || d1Strong.isNotEmpty,
      'D2-ST-003': ordinaryBad && indStrong.isEmpty,
      'D2-ST-004': (interferences.isNotEmpty || illordRisk) && d1Pairs.isEmpty,
    };
    final levelEvidence =
        'ఇందు శుభస్థితి $cleanBen; ఉచ్చపాపి $exaltBad; సాధారణ పాపి $ordinaryBad; బలమైన ఇందు జంటలు ${indStrong.length}; D1 బలజంటలు ${d1Strong.length}; వేరే 6/8/12 అధిపతి సంబంధం ${interferences.join(", ")}; ఇందు అధిపతి ${i.placement(ilLord)}; బల నిర్వచనం APP అన్వయం.';
    final levels = [
      for (final e in levelHits.entries)
        sourceRule(
          e.key,
          e.value,
          levelEvidence,
          adverse: e.key == 'D2-ST-004',
        ),
    ];
    final matchedNames = [
      for (final e in levelHits.entries)
        if (e.value)
          D2DhanaAsthiRegistry.rules.singleWhere((r) => r.id == e.key).name,
    ];
    final level = matchedNames.isEmpty
        ? 'ఈ నాలుగు మూల స్థాయి నియమాలు వర్తించలేదు'
        : matchedNames.join(' • ');
    bool touch(TopicGeometry398 v, String p, int house) =>
        v.sign(p) == v.houseSign(house) || v.aspects(p, v.houseSign(house));
    bool strongHouse(TopicGeometry398 v, int h) =>
        {1, 4, 5, 7, 9, 10}.contains(v.house(v.lord(h))) &&
        strong(v, v.lord(h));
    final wealthLords = [
      for (final h in [2, 5, 9, 11]) a.lord(h),
    ].toSet();
    final strongTriple = List.generate(
      12,
      (s) => wealthLords.where((p) => a.sign(p) == s && strong(a, p)).length,
    ).any((n) => n >= 3);
    final n9 = TopicGeometry398(VargaService.calculate(chart, 9));
    final moonRef = TopicGeometry398(
      VargaChartData(
        definition: d1.definition,
        ascendantSignIndex: a.sign('Moon'),
        planets: d1.planets,
      ),
    );
    final rules = <String, TopicCheck398>{};
    void add(
      String id,
      bool? hit, {
      String? evidence,
      bool adverse = false,
      bool context = false,
    }) {
      rules[id] = sourceRule(
        id,
        hit,
        evidence ??
            positions(
              id.startsWith('D2-IN') || id == 'D2-IH-005' || id == 'D2-IH-006'
                  ? i
                  : a,
            ),
        adverse: adverse,
        context: context,
      );
    }

    for (final row in levels) rules[row.id] = row;
    add('D2-IN-001', cleanBen);
    add('D2-IN-002', exaltBad);
    add('D2-IN-003', ordinaryBad);
    add('D2-IN-004', i.aspectSenders(i.asc, mal).isNotEmpty, adverse: true);
    add(
      'D2-IN-005',
      indStrong.isNotEmpty,
      evidence: indStrong.map((p) => p.evidence).join('\n'),
    );
    add(
      'D2-IN-006',
      interferences.isNotEmpty,
      adverse: true,
      evidence: interferences.isEmpty
          ? 'బలమైన ఇందు ధనయోగ జంటలకు వేరే 6/8/12 అధిపతి సంబంధం లేదు'
          : interferences.join('\n'),
    );
    add(
      'D2-IN-007',
      indu.planets.any((p) => {1, 2, 4, 10, 11}.contains(i.house(p.name))),
      context: true,
    );
    add(
      'D2-IN-008',
      indu.planets.any((p) => {3, 6, 8, 12}.contains(i.house(p.name))),
      adverse: true,
      context: true,
    );
    final nodes = oc.intersection({'Rahu', 'Ketu'});
    add(
      'D2-IN-009',
      nodes.isNotEmpty,
      evidence: [
        for (final p in nodes)
          '$p: అధిపతి ${TopicGeometry398.lords[i.sign(p)]}; APP బలం ${strong(i, TopicGeometry398.lords[i.sign(p)])}',
      ].join('\n'),
      context: true,
    );
    add(
      'D2-IN-010',
      strong(i, ilLord) &&
          indu.planets.any((p) => {3, 6, 10, 11}.contains(i.house(p.name))),
      evidence: 'ఇందు అధిపతి APP బలం ${strong(i, ilLord)}\n${positions(i)}',
    );
    add(
      'D2-IN-011',
      true,
      context: true,
      evidence:
          '${i.placement(ilLord)}; భవార్థ అన్వయం: ${channels[i.house(ilLord)]}',
    );
    add(
      'D2-IN-012',
      i.touching(i.houseSign(9), ben).isNotEmpty ||
          indu.planets.any(
            (p) =>
                mal.contains(p.name) &&
                i.house(p.name) == 9 &&
                strong(i, p.name),
          ),
    );
    add(
      'D2-IN-013',
      null,
      context: true,
      evidence:
          'ఈ నివేదికకు తేదీతో గోచార చార్ట్ ఇవ్వలేదు; జన్మ గ్రహాలనే గోచారంగా ఉపయోగించలేదు.',
    );
    add(
      'D2-DY-001',
      d1Pairs.isNotEmpty,
      evidence: d1Pairs.map((p) => p.evidence).join('\n'),
    );
    add(
      'D2-DY-002',
      a.exchange(a.lord(2), a.lord(11)) || strongTriple,
      evidence:
          '2L/11L పరివర్తన ${a.exchange(a.lord(2), a.lord(11))}; కనీసం ముగ్గురు వేర్వేరు బలమైన ధనాధిపతుల యుతి $strongTriple',
    );
    for (final id in ['D2-LB-001', 'D2-LB-002'])
      add(
        id,
        null,
        context: true,
        evidence:
            'మూలం మండూక నిర్మాణాన్ని ఖరారు చేయలేదు. మీరు ఎంచుకున్న లాభ–మండూక అన్వయం ప్రత్యేక APP-LABHA రూల్స్‌గా చక్రంలో చూపాం.',
      );
    add(
      'D2-CS-001',
      [a.lord(2), a.lord(11)].any((p) => strong(a, p) && a.house(p) != 12),
    );
    add(
      'D2-CS-002',
      {2, 11}.contains(a.house('Moon')) &&
          a.aspectSenders(a.sign('Moon'), mal).isEmpty,
    );
    add(
      'D2-CS-003',
      a.house(a.lord(2)) == 12 &&
          a.touching(a.sign(a.lord(2)), ben.difference({a.lord(2)})).isEmpty,
      adverse: true,
    );
    for (final id in ['D2-CS-004', 'D2-CS-005'])
      add(
        id,
        null,
        context: true,
        evidence:
            'మూలంలో రెండో అధిపతి/హోరా నిర్వచనం స్పష్టంకాలేదు; APP D1 ధనాధిపతి D2 హోరా వేరు చూపాం.',
      );
    add(
      'D2-GD-001',
      touch(a, 'Jupiter', 2) || (a.house('Sun') == 2 && strong(a, 'Sun')),
    );
    add('D2-GD-002', a.house('Moon') == 2 && strong(a, 'Moon'));
    add('D2-GD-003', {2, 4}.contains(a.house('Venus')) && strong(a, 'Venus'));
    add('D2-PR-001', strongHouse(a, 4));
    add(
      'D2-PR-002',
      (d1.planets.any(
                (p) =>
                    {'Jupiter', 'Venus', 'Mercury'}.contains(p.name) &&
                    a.house(p.name) == 4,
              ) &&
              !d1.planets.any(
                (p) => mal.contains(p.name) && a.house(p.name) == 4,
              )) ||
          strongHouse(a, 4),
    );
    add('D2-PR-003', touch(a, 'Mars', 4) && strong(a, 'Mars'));
    add('D2-PR-004', touch(a, 'Saturn', 4) && strong(a, 'Saturn'));
    add(
      'D2-PR-005',
      {6, 8, 12}.contains(a.house(a.lord(4))) &&
          a
              .aspectSenders(a.sign(a.lord(4)), ben.difference({a.lord(4)}))
              .isEmpty,
      adverse: true,
    );
    add(
      'D2-PR-006',
      weak(v4, v4.lord(4)),
      adverse: true,
      evidence:
          'D4 ${v4.placement(v4.lord(4))}; APP బలహీనత ${weak(v4, v4.lord(4))}',
    );
    add(
      'D2-PR-007',
      {1, 4, 5, 7, 9, 10}.contains(v4.house(v4.lord(4))),
      evidence: 'D4 ${v4.placement(v4.lord(4))}',
    );
    add('D2-PR-008', a.house(a.lord(4)) == 2);
    add(
      'D2-PR-009',
      a.house('Ketu') == 4 && a.aspectSenders(a.sign('Ketu'), ben).isEmpty,
      adverse: true,
    );
    add(
      'D2-PR-010',
      a.house('Rahu') == 4 && !a.aspects('Jupiter', a.sign('Rahu')),
      adverse: true,
    );
    add(
      'D2-PR-011',
      null,
      context: true,
      evidence:
          'కొనుగోలు సంఘటన నిర్ణయానికి ఎంచుకున్న పరిశీలన తేదీ/గోచారం అవసరం; దిగువ దశ పట్టిక జన్మ సూచికల అనుబంధం.',
    );
    add(
      'D2-IH-001',
      (touch(a, 'Moon', 4) && strong(a, 'Moon')) ||
          {1, 4, 5, 7, 9, 10}.contains(moonRef.house(moonRef.lord(4))),
    );
    add(
      'D2-IH-002',
      a.house('Moon') == 5 && a.aspectSenders(a.houseSign(4), mal).isNotEmpty,
      adverse: true,
    );
    add(
      'D2-IH-003',
      touch(a, a.lord(9), 4) ||
          (a.house('Sun') == 4 && strong(a, 'Sun')) ||
          a.house(a.lord(4)) == 9,
    );
    add(
      'D2-IH-004',
      {8, 12}.contains(a.house(a.lord(9))) &&
          a
              .aspectSenders(a.sign(a.lord(9)), ben.difference({a.lord(9)}))
              .isEmpty,
      adverse: true,
    );
    add(
      'D2-IH-005',
      [2, 5, 9, 11].any((h) => relation(i, i.lord(8), i.lord(h))),
    );
    add(
      'D2-IH-006',
      strong(i, ilLord) && touch(i, i.lord(8), 4),
      evidence:
          '${i.placement(ilLord)}; ${i.placement(i.lord(8))}; 4వ సంబంధం ${touch(i, i.lord(8), 4)}; తల్లి చంద్రసంబంధం ${relation(i, i.lord(8), 'Moon')}; తండ్రి రవి/9L సంబంధం ${relation(i, i.lord(8), 'Sun') || relation(i, i.lord(8), i.lord(9))}; నిర్దిష్ట ఆస్తికి D1/D4నూ చూడాలి.',
    );
    add(
      'D2-VH-001',
      a.house('Venus') == 4 &&
          (own(a, 'Venus') || exalt(a, 'Venus')) &&
          strong(a, a.lord(4)),
    );
    add(
      'D2-VH-002',
      touch(a, 'Venus', 4) ? null : false,
      context: true,
      evidence:
          'శుక్ర 4వ సంబంధం ${touch(a, "Venus", 4)}; మధ్యస్థ బలానికి మూలంలో ఖచ్చిత పరిమితి లేదు.',
    );
    add(
      'D2-VH-003',
      d1.planets.where((p) => a.house(p.name) == 4).length >= 2 ||
          (strong(a, 'Venus') && touch(a, 'Venus', 11)),
    );
    add('D2-VH-004', a.house('Mars') == 4 && strong(a, 'Mars'));
    add('D2-VH-005', touch(a, 'Saturn', 4) && weak(a, 'Saturn'), adverse: true);
    add(
      'D2-VH-006',
      {6, 8, 12}.contains(a.house(a.lord(4))) && weak(a, 'Venus'),
      adverse: true,
    );
    add(
      'D2-VH-007',
      weak(v4, 'Venus'),
      adverse: true,
      evidence: 'D4 ${v4.placement("Venus")}; APP బలహీనత ${weak(v4, "Venus")}',
    );
    add(
      'D2-OT-001',
      relation(a, a.lord(7), 'Mercury') || relation(a, a.lord(10), 'Mercury'),
    );
    add('D2-OT-002', a.house(a.lord(5)) == 11 && strong(a, a.lord(5)));
    add(
      'D2-OT-003',
      {8, 12}.contains(a.house(a.lord(5))) &&
          a
              .aspectSenders(a.sign(a.lord(5)), mal.difference({a.lord(5)}))
              .isNotEmpty,
      adverse: true,
    );
    add(
      'D2-OT-004',
      {9, 12}.contains(a.house(a.lord(4))) && a.conj(a.lord(4), 'Rahu'),
    );
    add('D2-OT-005', a.house(a.lord(11)) == 12 && strong(a, a.lord(11)));
    assert(rules.length == D2DhanaAsthiRegistry.rules.length);
    final extras = <TopicCheck398>[
      app(
        'PVR-DHANA-EXALT2-410',
        'D1 రెండో భావంలో చంద్ర/బుధ/గురు/శుక్ర ఉచ్చస్థితి',
        positions(a),
        'అత్యధిక ధనయోగం — మూల సంప్రదాయ ఫలితం',
        [
          'Moon',
          'Mercury',
          'Jupiter',
          'Venus',
        ].any((p) => a.house(p) == 2 && exalt(a, p)),
        source: pvr,
      ),
      app(
        'PHALA-LAKSHMI-410',
        'శుక్రుడు మరియు 9వ అధిపతి ఇద్దరూ స్వ/ఉచ్చ కేంద్ర/త్రికోణాల్లో',
        positions(a),
        'లక్ష్మీ యోగం — చాలా ధనవంతుడు అనే మూల ఫలితం',
        ['Venus', a.lord(9)].every(
          (p) =>
              (own(a, p) || exalt(a, p)) &&
              {1, 4, 5, 7, 9, 10}.contains(a.house(p)),
        ),
        source: phala,
      ),
      app(
        'APP-PHALA-VASUMATI-410',
        'బుధ/గురు/శుక్రులు లగ్నం లేదా చంద్రుని నుంచి ఉపచయాల్లో — APP శుభ సమూహ నిర్వచనం',
        positions(a),
        'వసుమతి యోగం — అత్యధిక ధన సంప్రదాయ ఫలితం',
        ([
              'Mercury',
              'Jupiter',
              'Venus',
            ].every((p) => {3, 6, 10, 11}.contains(a.house(p))) ||
            [
              'Mercury',
              'Jupiter',
              'Venus',
            ].every((p) => {3, 6, 10, 11}.contains(moonRef.house(p)))),
        source:
            '$phala • శుభులు అనే పదానికి APP సమూహం బుధ/గురు/శుక్ర; చంద్రుని చేర్చే ఇతర వ్యాఖ్యానంతో ఒకటిగా కలపలేదు.',
      ),
    ];
    // Ch.6.19 wording differs in the inclusion of Moon; disclose chosen complete set.
    final losses = <TopicCheck398>[
      app(
        'PVR-LOSS-MARS-SATURN2-410',
        'D1 రెండో భావంలో కుజ–శని; బుధ దృష్టి ఉండకూడదు',
        positions(a),
        'దారిద్ర్య/ధననష్ట యోగం — మూల ఫలితం',
        a.house('Mars') == 2 &&
            a.house('Saturn') == 2 &&
            !a.aspects('Mercury', a.houseSign(2)),
        adverse: true,
        source: pvr,
      ),
      app(
        'PVR-EXCEPTION-MERCURY2-410',
        'అదే కుజ–శని రెండో భావంలో ఉండి బుధ దృష్టి ఉంటే అపవాదం',
        positions(a),
        'అపవాదం: గొప్ప ధనం కలిగే సూచన',
        a.house('Mars') == 2 &&
            a.house('Saturn') == 2 &&
            a.aspects('Mercury', a.houseSign(2)),
        source: pvr,
      ),
      app(
        'PVR-LOSS-SUN-SATURN2-410',
        'రెండో భావ రవిపై శని దృష్టి',
        positions(a),
        'దారిద్ర్య/ధననష్ట యోగం — మూల ఫలితం',
        a.house('Sun') == 2 && a.aspects('Saturn', a.sign('Sun')),
        adverse: true,
        source: pvr,
      ),
    ];
    final named = [
      rules['D2-DY-001']!,
      rules['D2-DY-002']!,
      rules['D2-IN-005']!,
      ...extras,
    ];
    final yogaCount = named.where((r) => r.matched == true).length;
    final unique = {
      ...d1Pairs.map((p) => p.key),
      ...induPairs.map((p) => p.key),
    };
    final pairRows = <TopicCheck398>[
      for (final e in {'D1': d1Pairs, 'ఇందు': induPairs}.entries)
        for (final p in e.value)
          app(
            'PAIR-410-${e.key}-${p.key}',
            '${e.key} 2/5/9/11 అధిపతుల్లో వేర్వేరు గ్రహజంట',
            p.evidence,
            '${p.a} ↔ ${p.b}: ${p.strong ? "బలమైన ధనయోగ జంట" : "సంబంధం ఉంది; ఇద్దరికీ బల షరతు పూర్తి కాలేదు"}',
            true,
            context: true,
            source: userSource,
          ),
    ];
    final personRows = <TopicCheck398>[];
    // Original Ch.5.1 person mapping, two unranked branches: no fake stronger reference.
    for (final ref in {'D1': a, 'చంద్ర': moonRef}.entries)
      for (final p in people.keys) {
        if (ref.value.house(p) == 10)
          personRows.add(
            app(
              'PHALA-PERSON-${ref.key}-$p-410',
              'బలమైన లగ్నం/చంద్ర ఆధారం నుంచి 10వ భావంలో గ్రహం',
              '${ref.key}: ${ref.value.placement(p)}; బలమైన ఆధారాన్ని పూర్తి భావబలంతో ఎంపిక చేయాలి.',
              '${people[p]} ద్వారా ధనం — ఫలదీపిక మూల శాఖ; ప్రస్తుతం ${ref.key} ఆధారం',
              true,
              context: true,
              source: phala,
            ),
          );
      }
    // Source Ch.5.2–8: navamsa dispositor of tenth lord, all references labelled.
    for (final ref in {
      'D1': a,
      'చంద్ర': moonRef,
      'రవి': TopicGeometry398(
        VargaChartData(
          definition: d1.definition,
          ascendantSignIndex: a.sign('Sun'),
          planets: d1.planets,
        ),
      ),
    }.entries) {
      final lord = ref.value.lord(10),
          dispositor = TopicGeometry398.lords[n9.sign(lord)];
      personRows.add(
        app(
          'PHALA-INCOME-${ref.key}-410',
          '10వ అధిపతి ఉన్న నవాంశ రాశి అధిపతి వృత్తి సూచన',
          '${ref.key} 10L $lord; D9 రాశి ${n9.sign(lord) + 1}; నవాంశ అధిపతి $dispositor; బలమైన ఆధారం ఎంపిక పెండింగ్.',
          work[dispositor]!,
          true,
          context: true,
          source: phala,
        ),
      );
    }
    final channelRows = <TopicCheck398>[];
    for (final h in [2, 11]) {
      final p = a.lord(h), dest = a.house(p);
      channelRows.add(
        app(
          'APP-GAIN-CHANNEL-$h-410',
          'D1 $h అధిపతి ఉన్న భావార్థం ద్వారా ధన వనరు పరిశీలన',
          a.placement(p),
          '${channels[dest]} ద్వారా ధన సంబంధం; ఆధారం D1 $h L. ${strong(a, p) ? "APP బల మద్దతు ఉంది" : "APP బల షరతు పూర్తి కాలేదు"}',
          true,
          context: true,
        ),
      );
    }
    final expense = a.lord(12), dest = a.house(expense);
    channelRows.add(
      app(
        'APP-EXPENSE-CHANNEL-410',
        'D1 వ్యయాధిపతి ఉన్న భావార్థం ద్వారా ఖర్చు వ్యవహారం పరిశీలన',
        a.placement(expense),
        '${channels[dest]} సంబంధిత ఖర్చు/బాధ్యతలు; దీనినే దొంగతనం లేదా ఆ వ్యక్తి మోసం అని తేల్చలేదు.',
        true,
        adverse: true,
        context: true,
      ),
    );
    final ilDest = i.house(ilLord);
    channelRows.add(
      app(
        'APP-INDU-CHANNEL-410',
        'ఇందు అధిపతి ఉన్న భావార్థం — IN-011 అన్వయం',
        i.placement(ilLord),
        '${channels[ilDest]} ద్వారా ఆదాయ మార్గ పరిశీలన; ఆస్తి రకానికి D1/D4 ఆధారం వేరు.',
        true,
        context: true,
        source: '$userSource • IN-011 + APP భవార్థ అన్వయం',
      ),
    );
    final periods = <TopicCheck398>[];
    for (final p in names) {
      final h = i.house(p),
          gain = {1, 2, 4, 10, 11}.contains(h),
          loss = {3, 6, 8, 12}.contains(h);
      final node = nodes.contains(p), disp = TopicGeometry398.lords[i.sign(p)];
      periods.add(
        app(
          'INDU-DASHA-$p-410',
          'ఇందు నుంచి గ్రహస్థానం ఆధారంగా దశలో లాభం/నష్టం',
          '${i.placement(p)}; ఇందు అధిపతి ${p == ilLord}; నోడ్ అధిపతి $disp బలం ${strong(i, disp)}',
          '${gain ? "ధనం సమకూరే శాఖ" : ""}${loss ? "ధన నష్టం/ఆటంక శాఖ" : ""}${!gain && !loss ? "IN-007/008లో ఈ స్థానం వర్గీకరించలేదు" : ""}${node ? "; IN-009 ప్రకారం అధిపతి బలాన్ని బట్టి ఫలితం" : ""}',
          true,
          adverse: loss,
          context: true,
          source: '$userSource • IN-007/008/009; తేదీలు DashaService',
        ),
      );
    }
    // JD is UTC astronomical time; dates are displayed with explicit IST offset.
    if (chart.julianDay.isFinite &&
        chart.julianDay >= 2000000 &&
        chart.julianDay <= 3000000) {
      final birth = DateTime.fromMillisecondsSinceEpoch(
        ((chart.julianDay - 2440587.5) * 86400000).round(),
        isUtc: true,
      );
      final ds = DashaService.system(
        kind: DashaSystemKind.vimshottari,
        chart: chart,
        birthDateTime: birth,
      );
      String date(DateTime dt) => dt
          .add(const Duration(minutes: 330))
          .toIso8601String()
          .substring(0, 10);
      for (final md in ds.mahadashas.take(9)) {
        final marker = periods.singleWhere(
          (r) => r.id == 'INDU-DASHA-${md.lord}-410',
        );
        periods.add(
          app(
            'INDU-MD-${md.lord}-410',
            'జన్మ చంద్ర నక్షత్రం నుంచి వింశోత్తరి మహాదశ',
            '${date(md.start)} → ${date(md.end)} IST; ప్రారంభం కలుపుకొని, ముగింపు మినహాయింపు; జన్మకు ముందు భాగం మొదటి దశలో ఉండవచ్చు.',
            '${md.lord}: ${marker.outcome}',
            true,
            adverse: marker.adverse,
            context: true,
            source:
                'DashaService • 365.2425 రోజులు/సంవత్సరం + $userSource IN-007/008/009',
          ),
        );
      }
    }
    final lab = TopicGeometry398(labha);
    final labhaClass = <TopicCheck398>[
      app(
        'GOEL-LABHA-SELF-410',
        'లాభ–మండూక 3వ భావం/అధిపతికి లగ్నం/లగ్నాధిపతి సంబంధం',
        '${lab.placement(lab.lord(1))}; ${lab.placement(lab.lord(3))}; లగ్నాధిపతి3వ సంబంధం ${touch(lab, lab.lord(1), 3)}; 3L లగ్న సంబంధం ${touch(lab, lab.lord(3), 1)}',
        'స్వశక్తి, కృషి, నైపుణ్యం, అంకితభావం ద్వారా సంపద',
        relation(lab, lab.lord(1), lab.lord(3)) ||
            touch(lab, lab.lord(1), 3) ||
            touch(lab, lab.lord(3), 1),
        source: GoelHoraClass410.source,
      ),
      app(
        'GOEL-LABHA-LUCK-410',
        'లాభ–మండూక 9వ భావం/అధిపతికి లగ్నం/లగ్నాధిపతి సంబంధం',
        '${lab.placement(lab.lord(1))}; ${lab.placement(lab.lord(9))}; లగ్నాధిపతి9వ సంబంధం ${touch(lab, lab.lord(1), 9)}; 9L లగ్న సంబంధం ${touch(lab, lab.lord(9), 1)}',
        'అదృష్టం ద్వారా సంపద',
        relation(lab, lab.lord(1), lab.lord(9)) ||
            touch(lab, lab.lord(1), 9) ||
            touch(lab, lab.lord(9), 1),
        source: GoelHoraClass410.source,
      ),
      app(
        'GOEL-LABHA-SPEECH-410',
        'లాభ–మండూక 2L శుభగ్రహమై బాగా స్థితమై ఉండాలి',
        '${lab.placement(lab.lord(2))}; శుభగ్రహం ${ben.contains(lab.lord(2))}; APP స్థానబలం ${strong(lab, lab.lord(2))}',
        'ఆకర్షణీయ ముఖం, మంచి రూపం, మంచి మాటతీరు; మాట నిలబెట్టుకోవటం/సంస్కారం పరిశీలన',
        ben.contains(lab.lord(2)) && strong(lab, lab.lord(2)),
        source: '${GoelHoraClass410.source}; బాగా స్థితము = APP స్థానబల అన్వయం',
      ),
      app(
        'GOEL-LABHA-EXPENSE-410',
        'లాభ–మండూక 2వ సంపద/కుటుంబం; 12వ ఖర్చు',
        '${lab.placement(lab.lord(2))}; ${lab.placement(lab.lord(12))}',
        '2L: ${channels[lab.house(lab.lord(2))]}; 12L: ${channels[lab.house(lab.lord(12))]}. ఇవి APP భావార్థ మార్గాలు.',
        true,
        context: true,
        source: '${GoelHoraClass410.source} + APP భావార్థ పట్టిక',
      ),
    ];
    final sections = <WealthSection410>[
      WealthSection410(
        'kbperception',
        'బన్సల్ క్లాస్ — ఐదు పరిశీలనా అంశాలు',
        TantraWealthSources411.secondOrientation,
        TantraWealthSources411.secondNote,
      ),
      WealthSection410(
        'tantrawealth',
        'ధనానికి ఉపాసన / తాంత్రిక యంత్ర మార్గాలు',
        TantraWealthSources411.practices,
        TantraWealthSources411.note,
      ),
      WealthSection410(
        'kbtranscript',
        'బన్సల్ క్లాస్ — నవదుర్గ / మహావిద్య ఎంపిక',
        TantraWealthSources411.orientation,
        TantraWealthSources411.orientationNote,
      ),
      WealthSection410(
        'mahavastu',
        'మహావాస్తు — ధన మార్గదర్శనం / దేవత జోన్ మూలాలు',
        MahaVastuWealthSources410.checks,
        MahaVastuWealthSources410.note,
      ),
      WealthSection410(
        'activation',
        'ధన ప్రవాహానికి మార్గదర్శనం',
        MoneyFlowSource410.checks(d1),
        MoneyFlowSource410.text,
      ),
      WealthSection410(
        'goelhora',
        'గోయల్ క్లాస్ — D2లో దశ శ్రమ / సౌమ్యత',
        GoelHoraClass410.checks(chart),
        GoelHoraClass410.text,
      ),
      WealthSection410(
        'goellabha',
        'గోయల్ క్లాస్ — స్వశక్తి / అదృష్ట సంపాదన',
        labhaClass,
        'భావ సంబంధం = ఆ భావంలో ఉండటం/ఆ భావంపై పరాశరి దృష్టి. అధిపతుల సంబంధం = యుతి/పరస్పర దృష్టి/పరివర్తన. ఈ OR అన్వయం APP అమలు నిర్వచనం.',
      ),
      WealthSection410(
        'levels',
        'ధన స్థాయి — మూలంలోని నాలుగు ఫలితాలు',
        levels,
        'మూలం యథాతథం; బలం/అననుకూల సంబంధపు APP అన్వయం ప్రతి పరీక్షలో ఉంది. ఒకటి కంటే ఎక్కువ స్థాయులు వర్తిస్తే అన్నీ చూపాం.',
      ),
      WealthSection410(
        'yogas',
        'ఎన్ని ధనయోగాలు? ఏ గ్రహాల వల్ల?',
        [...named, ...pairRows],
        '$yogaCount / ${named.length} మూల/అదనపు యోగ పరీక్షలు వర్తించాయి. D1 జంటలు ${d1Pairs.length}; ఇందు జంటలు ${induPairs.length}; రెండింటిలో కలిపి వేర్వేరు జంటలు ${unique.length}. యోగ పరీక్షల సంఖ్య, గ్రహజంటల సంఖ్య వేరు; అన్ని గ్రంథాల్లోని మొత్తం యోగాల సంఖ్య అని కాదు.',
      ),
      WealthSection410('indu', 'ఇందు లగ్నం — మొత్తం ధనం, వృద్ధి, నష్టం', [
        for (final r in D2DhanaAsthiRegistry.rules)
          if (r.groupCode == 'IN') rules[r.id]!,
      ]),
      WealthSection410(
        'forms',
        'ఏ రూపంలో ధనం / ఆస్తి వస్తుంది?',
        [
          for (final r in D2DhanaAsthiRegistry.rules)
            if ({'CS', 'GD', 'PR', 'VH', 'OT'}.contains(r.groupCode))
              rules[r.id]!,
        ],
        'నగదు, బంగారం, వెండి, నగలు, భూమి, ఇల్లు, వాహనాలు, పెట్టుబడి, విదేశ ఆదాయం విడివిడిగా; జాతక షరతులు ఉన్నప్పుడే వర్తించింది.',
      ),
      WealthSection410(
        'people',
        'ఎవరి ద్వారా? ఏ మార్గం ద్వారా?',
        [
          for (final r in D2DhanaAsthiRegistry.rules)
            if (r.groupCode == 'IH') rules[r.id]!,
          ...personRows,
          ...channelRows,
        ],
        'ఫలదీపిక సంబంధాలు మూలపదాలతో; బలమైన లగ్నం/చంద్ర ఆధారాన్ని తేల్చకుండా రెండు శాఖలను వేరుగా చూపాం. APP భవార్థాలు వేరే పేరుతో.',
      ),
      WealthSection410(
        'loss',
        'ధన నష్టం, నిల్వ ఆటంకాలు, అపవాదాలు',
        [
          ...losses,
          for (final r in rules.values)
            if (r.adverse && r.id != 'D2-ST-004') r,
        ],
        'మంచి ధనయోగం ఉన్నా నష్ట నియమాలు దాచలేదు. ఖర్చు, పెట్టుబడి నష్టం, ఆస్తి తగాదా, అప్పు వేర్వేరు; వ్యయాన్ని మొత్తంగా నష్టం అని కలపలేదు.',
      ),
      WealthSection410(
        'periods',
        'ఏ గ్రహదశలో రావచ్చు / పోవచ్చు?',
        periods,
        'జన్మస్థితి సూచికలు + వింశోత్తరి మహాదశ తేదీలు. పూర్తి గోచారంతో కలిపిన తుది సంఘటన నిర్ణయం కాదు; గ్రహానికి లాభ/నష్ట మూల షరతు లేనప్పుడు లేదనే చూపాం.',
      ),
      WealthSection410('hora', 'హోరా మూల నిర్వచనాలు / ప్రత్యేక పద్ధతి', [
        rules['D2-LB-001']!,
        rules['D2-LB-002']!,
        rules['D2-CS-004']!,
        rules['D2-CS-005']!,
      ]),
    ];
    final activeLoss = [
      ...losses,
      for (final r in rules.values)
        if (r.adverse) r,
    ].where((r) => r.matched == true).length;
    return WealthDetail410(
      level: level,
      summary:
          'మూల ధనస్థాయి పరీక్ష: $level.\nధనయోగ పరీక్షలు $yogaCount; వేర్వేరు గ్రహజంటలు ${unique.length}.\nవర్తించిన నష్టం/ఆటంక పరీక్షలు $activeLoss. వచ్చే ధనం, నిలిచే ధనం, ఆస్తి, ఖర్చు వివరాలు కింద వేరు.',
      provenance: provenance,
      yogaCount: yogaCount,
      uniquePairCount: unique.length,
      d1PairCount: d1Pairs.length,
      induPairCount: induPairs.length,
      sections: sections,
      d1Pairs: d1Pairs,
      induPairs: induPairs,
    );
  }
}
