import 'astro_models.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';
import 'jaimini_service.dart';
import 'deity_guidance_v405.dart';
import 'client_guidance_model_v406.dart';

/// Reputation observations are not proof of misconduct or guaranteed publicity.
class FameTopic407 {
  static const id = 'VARGA-CROSS-014';
  static const pvr =
      'P.V.R. Narasimha Rao • Vedic Astrology: An Integrated Approach • https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf';
  static const source =
      'Mallikarjuna 255 Rules • VARGA-CROSS-065/066 పేజీ 28; 067 పేజీ 29 • పరిశీలన క్రమం';
  static const note =
      'APP-FAME-407: D1 → D10 → D9 మూల క్రమం. D1లో సూర్యుడు/దశమాధిపతి; D10లో లగ్న/దశమాధిపతులు, సూర్యుడు. '
      'స్వ/ఉచ్చ రాశి లేదా గురు/శుక్ర యుతి/పరాశరి దృష్టి మద్దతు; నీచ రాశి, 6/8/12 స్థానం లేదా ఇతర సూర్య/కుజ/శని సంబంధం, నోడ్స్ యుతి జాగ్రత్తగా APP పరీక్షలు. '
      'ఇవి పూర్తి షడ్బలం లేదా అపకీర్తి సంఘటనకు గ్రంథ నిర్ధారణ కావు. D9 రాశి గౌరవం అనుబంధమే. '
      'D1 అమలయోగం మాత్రం PVR మూలపు ప్రత్యేక IF; అది వర్తించకపోవడం అపకీర్తి కాదు. '
      'మద్దతు, జాగ్రత్త రెండూ ఉంటే మిశ్రమం; రెండూ లేకపోయినా మధ్యస్థం. D9/ఆరూఢ సందర్భాలను ప్రధాన హిట్‌గా కలపలేదు. '
      'విమర్శ లేదా ఇతరుల అభిప్రాయం నిజమైన తప్పిదం/నేరం/అవినీతి అని తేల్చదు. కీర్తి లేదా అపకీర్తి ఖాయం, సంఘటన తేదీ/శాతం ప్రకటించలేదు.';
  static TopicReport398 evaluate(AstroChartResult chart) {
    if (!TopicResults398.valid(chart))
      return const TopicReport398(
        'కీర్తి / అపకీర్తి',
        id,
        [],
        TopicGrade398.missing,
        'లగ్నం, తొమ్మిది గ్రహాల పూర్తి స్థానాలు కావాలి.',
        note,
      );
    final d1 = stage(chart, 1), d10 = stage(chart, 10), d9 = stage(chart, 9);
    final stages = [d1, d10, d9];
    final active = [
      ...d1.checks,
      ...d10.checks,
    ].where((c) => !c.contextual && c.matched == true).toList();
    final good = active.where((c) => !c.adverse).toList(),
        bad = active.where((c) => c.adverse).toList();
    final grade = TopicResults398.grade([...d1.checks, ...d10.checks]);
    final conclusion =
        'కీర్తి / గుర్తింపు: ${good.isEmpty ? "ఈ పరీక్షల్లో స్పష్టమైన మద్దతు నమోదు కాలేదు; గుర్తింపు రాదని అర్థం కాదు." : good.map((c) => c.outcome).join(" ")}\n'
        'అపకీర్తి / ప్రతిష్ఠ జాగ్రత్తలు: ${bad.isEmpty ? "ఈ పరీక్షల్లో ప్రత్యేక ఒత్తిడి నమోదు కాలేదు; సమస్య ఎప్పటికీ రాదనే హామీ కాదు." : bad.map((c) => c.outcome).join(" ")}\n'
        'D9లో నమోదైన స్థిరత్వ సందర్భాన్ని విడిగా చూడండి. ఇతరుల అభిప్రాయం, వ్యక్తి నిజమైన ప్రవర్తన ఒకటే కావు.';
    final v = TopicGeometry398(VargaService.calculate(chart, 10));
    final lord = v.lord(1);
    final forms = DeityGuidance405.deities[lord]!;
    final guide = ClientGuidanceData406(
      topicId: id,
      title: 'కీర్తి / అపకీర్తి — ఆరాధన / ఆచరణ',
      factor: 10,
      primary: forms.first,
      reason:
          'D10 లగ్న రాశి ${v.asc + 1}; లగ్నాధిపతి $lord. ${v.placement(lord)}. '
          'PVR §34.5 ప్రకారం సంబంధిత వర్గ లగ్నాధిపతి దేవతను పరిశీలించాం. ప్రత్యామ్నాయాల్లో మొదటి స్వరూపం చూపడం APP ఎంపిక; ఒక్కటే సరైన దేవత అని కాదు.',
      alternative: forms.skip(1).isEmpty
          ? 'ఇప్పటికే అనుసరించే కుటుంబ/గురు సంప్రదాయ ప్రార్థనను కొనసాగించవచ్చు.'
          : 'అదే గ్రహానికి మూలంలో ఉన్న ఇతర స్వరూపాలు: ${forms.skip(1).join(" / ")}. ఒక స్వరూపం చాలు.',
      practice:
          'కుటుంబ/గురు సంప్రదాయానికి అనుగుణంగా సరళ ప్రార్థన, నామస్మరణ లేదా తెలిసిన స్తోత్రం. దీక్షా మంత్రసాధనకు గురు మార్గదర్శకత్వం. ఖరీదైన పూజ లేదా నిర్దిష్ట జపసంఖ్య తప్పనిసరి కాదు.',
      action:
          'మాట–పని సారూప్యత, ఇచ్చిన మాట నిలబెట్టుకోవడం, పని వివరాలు/ఆధారాలు భద్రపరచడం, గోప్యత పాటించడం. నిర్ధారణలేని ఆరోపణలను పంచుకోకండి; విమర్శకు ప్రశాంతంగా వాస్తవాలతో స్పందించండి.',
      limit:
          'ఇది ఆధ్యాత్మిక మద్దతు మాత్రమే; ప్రచారం, పదవి, గౌరవం లేదా వివాద విజయం హామీ కాదు. ఇతరులకు హాని/వశీకరణ పద్ధతులు సూచించలేదు.',
      evidence: [
        for (final s in stages)
          for (final c in s.checks)
            if (c.matched == true && !c.contextual) '${c.id}: ${c.evidence}',
        if (active.isEmpty) 'ఈ పరీక్షల్లో ప్రధాన హిట్ నమోదు కాలేదు.',
      ],
      sources: [
        DeityGuidance405.source,
        source,
        '$pvr • అమలయోగం printed p.125/PDF p.137; సహజ గ్రహస్వభావం printed p.28/PDF p.40',
      ],
    );
    return TopicReport398(
      'కీర్తి / అపకీర్తి',
      id,
      stages,
      grade,
      conclusion,
      note,
      clientGuidance: guide,
    );
  }

  static TopicStage398 stage(AstroChartResult chart, int factor) {
    final v = TopicGeometry398(VargaService.calculate(chart, factor));
    final v1 = TopicGeometry398(VargaService.calculate(chart, 1));
    final targets = factor == 1
        ? {'Sun', v.lord(10)}
        : factor == 10
        ? {v.lord(1), v.lord(10), 'Sun'}
        : {'Sun', v1.lord(10)};
    final checks = <TopicCheck398>[];
    if (factor == 1) {
      for (final ref in ['LAGNA', 'MOON']) {
        final target = ((ref == 'LAGNA' ? v.asc : v.sign('Moon')) + 9) % 12;
        final occupants = v.v.planets
            .where((p) => p.signIndex == target)
            .map((p) => p.name)
            .toList();
        final sun = chart.planets.singleWhere((p) => p.name == 'Sun').longitude,
            moon = chart.planets.singleWhere((p) => p.name == 'Moon').longitude;
        final phase = (moon - sun) % 360;
        checks.add(
          TopicCheck398(
            'PVR-AMALA-$ref-407',
            'D1లో ${ref == "LAGNA" ? "లగ్నం" : "చంద్రుడు"} నుంచి 10వ రాశిలో కనీసం ఒక గ్రహం AND ఉన్నవన్నీ సహజ శుభగ్రహాలు',
            '10వ రాశి ${target + 1}; గ్రహాలు ${occupants.isEmpty ? "లేవు" : occupants.join(", ")}; చంద్ర–సూర్య దూరం ${phase.toStringAsFixed(4)}°. '
                'శుక్లపక్ష చంద్రుడు శుభుడు; బుధుడు ఒంటరిగా/శుభులతో శుభుడు, పాపగ్రహ యుతి ఉంటే ఈ అమల షరతు విఫలం.',
            '$pvr • అమలయోగం printed p.125/PDF p.137; సహజ స్వభావం printed p.28/PDF p.40 • యుతి రాశి స్థాయిలో',
            'అమలయోగం ${ref == "LAGNA" ? "లగ్న" : "చంద్ర"} శాఖ: గౌరవం/గుర్తింపుకు సంప్రదాయ మద్దతు; ఫలితం ఖాయం కాదు.',
            amalaForSign(chart, target),
          ),
        );
      }
    }
    for (final p in targets) {
      final good = v.touching(v.sign(p), {'Jupiter', 'Venus'}.difference({p}));
      final bad = v.touching(
        v.sign(p),
        TopicGeometry398.malefics.difference({p}),
      );
      if (factor == 9) {
        checks.add(
          TopicCheck398(
            'APP-FAME-D9-$p-407',
            'D1 కీర్తి సూచిక గ్రహం D9 రాశి గౌరవం నమోదు; పూర్తి బలం వేరు',
            '${v.placement(p)}; ${v.dignity(p)}',
            source,
            'D9 $p: ${v.dignity(p)}. ఇది దీర్ఘకాలిక కీర్తికి స్వతంత్ర తీర్పు కాదు.',
            true,
            contextual: true,
          ),
        );
        continue;
      }
      final dignity = v.dignity(p);
      checks.add(
        TopicCheck398(
          'APP-FAME-D$factor-$p-SUPPORT-407',
          'స్వ/ఉచ్చ రాశి OR ఇతర గురు/శుక్ర యుతి/పరాశరి దృష్టి',
          '${v.placement(p)}; $dignity; శుభ సంబంధం: ${good.isEmpty ? "లేదు" : good}',
          'APP-FAME-407 • $source; రాశి గౌరవం/నిర్వచించిన సంబంధ శాఖ; పూర్తి బలం కాదు',
          'D$factor $p: గుర్తింపు/గౌరవం నిలుపుకోవడానికి మద్దతు సూచన.',
          {'స్వరాశి', 'ఉచ్చం'}.contains(dignity) || good.isNotEmpty,
        ),
      );
      checks.add(
        TopicCheck398(
          'APP-FAME-D$factor-$p-CAUTION-407',
          'నీచ రాశి OR 6/8/12 స్థానం OR ఇతర పాప యుతి/దృష్టి',
          '${v.placement(p)}; $dignity; ఇతర పాప సంబంధం: ${bad.isEmpty ? "లేదు" : bad}',
          'APP-FAME-407 • నిర్వచించిన ఒత్తిడి శాఖ; అపకీర్తి జరిగే గ్రంథ హామీ కాదు',
          'D$factor $p: మాటలు, వృత్తి బాధ్యతలు, ప్రజాసంబంధాల్లో శ్రద్ధ సూచన; అపవాదు నిజమనే నిర్ధారణ కాదు.',
          dignity == 'నీచం' ||
              {6, 8, 12}.contains(v.house(p)) ||
              bad.isNotEmpty,
          adverse: true,
        ),
      );
    }
    checks.add(
      TopicCheck398(
        factor == 1
            ? 'VARGA-CROSS-065'
            : factor == 10
            ? 'VARGA-CROSS-066'
            : 'VARGA-CROSS-067',
        factor == 1
            ? 'D1లో 10వ భావం/సూర్య పరిశీలన'
            : factor == 10
            ? 'వృత్తిపర కీర్తికి D10 ప్రధాన పరిశీలన'
            : 'D9 స్థిరత్వానికి సంబంధిత గ్రహ పూర్తి వర్గబలం',
        'D$factor లగ్నం ${v.asc + 1}; 10వ అధిపతి ${v.placement(v.lord(10))}; సూర్యుడు ${v.placement("Sun")}',
        source,
        factor == 9
            ? 'D9 రాశి గౌరవం నమోదైంది; పూర్తి గ్రహ/షడ్వర్గ బలాన్ని ఒక్క స్వ/ఉచ్చంతో భర్తీ చేయలేదు.'
            : 'మూల పరిశీలన క్రమం అమలైంది; ఈ workflowను కీర్తి శుభ ఫల హిట్‌గా లెక్కించలేదు.',
        factor == 9 ? null : true,
        contextual: true,
      ),
    );
    if (factor == 1) {
      final al = JaiminiService.calculate(
        chart,
      ).arudhaPadas.singleWhere((p) => p.padaNumber == 1).padaSignIndex;
      final planets = v.v.planets
          .where((p) => p.signIndex == al)
          .map((p) => p.name)
          .join(', ');
      checks.add(
        TopicCheck398(
          'APP-FAME-AL-407',
          'ప్రస్తుత పంచాంగ/జైమిని ఇంజిన్ ఆరూఢ లగ్న స్థానాన్ని ప్రజల అభిప్రాయ సందర్భంగా నమోదు',
          'D1 ఆరూఢ లగ్న రాశి ${al + 1}; గ్రహాలు ${planets.isEmpty ? "లేవు" : planets}',
          pvr + ' • §9.3 printed p.89/PDF p.101; ప్రస్తుత JaiminiService గణన',
          'ప్రజల అభిప్రాయం, నిజమైన ప్రవర్తన వేరు; ఆరూఢ స్థానం అనుబంధంగా నమోదైంది.',
          true,
          contextual: true,
        ),
      );
    }
    return TopicStage398(factor, checks);
  }

  /// Empty houses never create a yoga. Mercury and Moon are not unconditionally
  /// benefic; this occupancy rule needs no invented node aspects or point score.
  static bool amalaForSign(AstroChartResult chart, int target) {
    if (!TopicResults398.valid(chart) || target < 0 || target > 11)
      throw ArgumentError('valid D1 and sign required');
    final ps = chart.planets
        .where(
          (p) =>
              p.signIndex == target &&
              {
                'Sun',
                'Moon',
                'Mars',
                'Mercury',
                'Jupiter',
                'Venus',
                'Saturn',
                'Rahu',
                'Ketu',
              }.contains(p.name),
        )
        .toList();
    if (ps.isEmpty) return false;
    final sun = chart.planets.singleWhere((p) => p.name == 'Sun').longitude;
    final moon = chart.planets.singleWhere((p) => p.name == 'Moon').longitude;
    final phase = (moon - sun) % 360;
    return ps.every(
      (p) =>
          {'Jupiter', 'Venus', 'Mercury'}.contains(p.name) ||
          (p.name == 'Moon' && phase > 0 && phase <= 180),
    );
  }
}
