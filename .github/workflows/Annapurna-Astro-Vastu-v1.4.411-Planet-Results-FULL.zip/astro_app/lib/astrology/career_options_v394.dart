import 'astro_models.dart';
import 'd10_business_catalog.dart';
import 'd10_career_service.dart';
import 'd10_final_profession_engine.dart';
import 'varga_service.dart';

/// Presentation of the existing D10 family evidence, without changing its
/// score, ranking, Saturn mode, source predicates or any event coverage.
class CareerOption394 {
  final D10ProfessionCandidate candidate;
  final String title;
  final List<String> examples;
  const CareerOption394(this.candidate, this.title, this.examples);
}

class CareerOptions394 {
  final D10FinalProfessionResult? calculation;
  final String mode;
  final List<CareerOption394> options;
  const CareerOptions394(this.calculation, this.mode, this.options);

  bool get hasPrimary => options.any((o) => primary(o.candidate));
  List<CareerOption394> get preview =>
      (hasPrimary ? options.where((o) => primary(o.candidate)) : options)
          .take(4)
          .toList();
  static bool primary(D10ProfessionCandidate c) =>
      c.natureCompatibility.endsWith('Match') && c.matchedEvidence.length >= 2;

  static CareerOptions394 forChart(AstroChartResult chart) {
    const required = {
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    };
    if (!chart.ascendantLongitude.isFinite ||
        !chart.planets.map((p) => p.name).toSet().containsAll(required) ||
        chart.planets.any((p) => !p.longitude.isFinite)) {
      return const CareerOptions394(null, 'MIXED', []);
    }
    final result = D10FinalProfessionEngine.evaluate(
      chart: chart,
      d10: VargaService.calculate(chart, 10),
    );
    final mode = D10CareerService.saturnStream(chart).dashamsaState;
    return fromResult(result, mode);
  }

  static CareerOptions394 fromResult(
    D10FinalProfessionResult result,
    String mode,
  ) {
    return CareerOptions394(result, mode, [
      for (final c in result.candidates)
        CareerOption394(
          c,
          titles[c.profession] ?? c.profession,
          mode == 'GOCHARASHTHA'
              ? D10BusinessCatalog.optionsByFamily[c.profession] ??
                    jobs[c.profession] ??
                    [c.profession]
              : jobs[c.profession] ?? [c.profession],
        ),
    ]);
  }

  static const titles = <String, String>{
    'Government / Administration': 'ప్రభుత్వం / పరిపాలన',
    'Management / High Position': 'నిర్వహణ / మేనేజ్‌మెంట్',
    'Banking / Finance': 'బ్యాంకింగ్ / ఆర్థిక రంగం',
    'Accounting / Audit / Tax': 'అకౌంట్స్ / ఆడిట్ / పన్నులు',
    'Teaching / Education': 'బోధన / విద్య',
    'Law / Judiciary / Compliance': 'న్యాయం / నిబంధనల పర్యవేక్షణ',
    'Engineering / Technical': 'ఇంజినీరింగ్ / సాంకేతిక రంగం',
    'IT / Software / Data': 'ఐటీ / సాఫ్ట్‌వేర్ / డేటా',
    'Electronics / Communication Technology': 'ఎలక్ట్రానిక్స్ / కమ్యూనికేషన్',
    'Architecture / Design': 'నిర్మాణ రూపకల్పన / డిజైన్',
    'Medicine / Healthcare': 'వైద్యం / ఆరోగ్య సేవలు',
    'Research / R&D / Investigation': 'పరిశోధన / విశ్లేషణ',
    'Defence / Police / Security': 'రక్షణ / పోలీస్ / భద్రత',
    'Journalism / Writing / Media': 'రచన / జర్నలిజం / మీడియా',
    'Communication / Languages': 'భాషలు / కమ్యూనికేషన్',
    'Travel / Tourism / Logistics': 'ప్రయాణం / పర్యాటకం / లాజిస్టిక్స్',
    'Hospitality / Food / Nutrition': 'ఆతిథ్యం / ఆహార రంగం',
    'Music / Arts / Performance': 'సంగీతం / కళలు',
    'Fashion / Beauty / Creative Design': 'ఫ్యాషన్ / అందం / సృజనాత్మక డిజైన్',
    'Manufacturing / Industry / Skilled Technical Work':
        'తయారీ / పరిశ్రమ / సాంకేతిక పనులు',
    'Aviation / Transport': 'విమానయానం / రవాణా',
    'Import / Export / Foreign Relations': 'దిగుమతి / ఎగుమతి / విదేశీ సంబంధాలు',
    'Agriculture / Environment / Natural Resources': 'వ్యవసాయం / పర్యావరణం',
    'Commercial / Business / Entrepreneurship': 'వాణిజ్యం / వ్యాపారం',
    'Consulting / Advisory': 'కన్సల్టింగ్ / సలహా సేవలు',
    'Social / Community Service': 'సామాజిక / ప్రజాసేవ',
    'Occult / Astrology / Traditional Studies': 'జ్యోతిషం / సంప్రదాయ అధ్యయనం',
  };

  /// Occupation examples explain a selected family; they are not new yogas,
  /// individual suitability scores, qualifications or promised appointments.
  static const jobs = <String, List<String>>{
    'Government / Administration': [
      'పరిపాలనా సహాయకుడు',
      'ప్రభుత్వ కార్యాలయ నిర్వహణ',
      'రెవెన్యూ శాఖ ఉద్యోగాలు',
    ],
    'Management / High Position': [
      'ఆపరేషన్స్ మేనేజర్',
      'ప్రాజెక్ట్ కోఆర్డినేటర్',
      'ఆఫీస్ మేనేజర్',
    ],
    'Banking / Finance': [
      'బ్యాంకు ఉద్యోగి',
      'ఫైనాన్స్ ఎగ్జిక్యూటివ్',
      'ఆర్థిక రికార్డుల నిర్వహణ',
    ],
    'Accounting / Audit / Tax': [
      'అకౌంటెంట్',
      'ఆడిట్ అసిస్టెంట్',
      'పన్ను సంబంధిత సేవలు',
    ],
    'Teaching / Education': [
      'ఉపాధ్యాయుడు',
      'విద్యా శిక్షకుడు',
      'విద్యాసంస్థ నిర్వహణ',
    ],
    'Law / Judiciary / Compliance': [
      'న్యాయవాది',
      'లీగల్ అసిస్టెంట్',
      'కంప్లయన్స్ ఉద్యోగాలు',
    ],
    'Engineering / Technical': [
      'ఇంజినీర్',
      'టెక్నీషియన్',
      'నిర్వహణ / మరమ్మత్తు ఉద్యోగాలు',
    ],
    'IT / Software / Data': [
      'సాఫ్ట్‌వేర్ డెవలపర్',
      'డేటా అనలిస్ట్',
      'ఐటీ సపోర్ట్',
    ],
    'Electronics / Communication Technology': [
      'ఎలక్ట్రానిక్స్ టెక్నీషియన్',
      'నెట్‌వర్క్ సపోర్ట్',
      'టెలికాం ఉద్యోగాలు',
    ],
    'Architecture / Design': ['ఆర్కిటెక్ట్', 'డ్రాఫ్ట్స్‌మన్', 'డిజైనర్'],
    'Medicine / Healthcare': [
      'ల్యాబ్ టెక్నీషియన్',
      'ఫార్మసీ ఉద్యోగాలు',
      'ఆసుపత్రి నిర్వహణ',
    ],
    'Research / R&D / Investigation': [
      'పరిశోధన సహాయకుడు',
      'డేటా పరిశోధకుడు',
      'నాణ్యత పరీక్షల ఉద్యోగాలు',
    ],
    'Defence / Police / Security': [
      'పోలీస్ ఉద్యోగాలు',
      'రక్షణ శాఖ ఉద్యోగాలు',
      'భద్రతా పర్యవేక్షకుడు',
    ],
    'Journalism / Writing / Media': ['రచయిత', 'జర్నలిస్ట్', 'ఎడిటర్'],
    'Communication / Languages': [
      'అనువాదకుడు',
      'భాషా శిక్షకుడు',
      'కమ్యూనికేషన్ ఉద్యోగాలు',
    ],
    'Travel / Tourism / Logistics': [
      'ట్రావెల్ కోఆర్డినేటర్',
      'టూర్ మేనేజర్',
      'లాజిస్టిక్స్ ఉద్యోగాలు',
    ],
    'Hospitality / Food / Nutrition': [
      'హోటల్ ఉద్యోగాలు',
      'కేటరింగ్ నిర్వహణ',
      'ఆహార ఉత్పత్తుల ఉద్యోగాలు',
    ],
    'Music / Arts / Performance': [
      'సంగీత ఉపాధ్యాయుడు',
      'ప్రదర్శన కళాకారుడు',
      'కళా కార్యక్రమాల నిర్వహణ',
    ],
    'Fashion / Beauty / Creative Design': [
      'ఫ్యాషన్ డిజైనర్',
      'బ్యూటీషియన్',
      'క్రియేటివ్ డిజైనర్',
    ],
    'Manufacturing / Industry / Skilled Technical Work': [
      'ఉత్పత్తి పర్యవేక్షకుడు',
      'మెషిన్ ఆపరేటర్',
      'పరిశ్రమ టెక్నీషియన్',
    ],
    'Aviation / Transport': [
      'ఎయిర్‌పోర్ట్ సిబ్బంది',
      'రవాణా కోఆర్డినేటర్',
      'వాహన నిర్వహణ ఉద్యోగాలు',
    ],
    'Import / Export / Foreign Relations': [
      'ఎగుమతి డాక్యుమెంటేషన్',
      'అంతర్జాతీయ సేల్స్',
      'షిప్పింగ్ ఉద్యోగాలు',
    ],
    'Agriculture / Environment / Natural Resources': [
      'వ్యవసాయ క్షేత్ర సహాయకుడు',
      'ఫార్మ్ నిర్వహణ',
      'పర్యావరణ సంబంధిత ఉద్యోగాలు',
    ],
    'Commercial / Business / Entrepreneurship': [
      'సేల్స్ ఎగ్జిక్యూటివ్',
      'కొనుగోలు విభాగం',
      'వ్యాపార నిర్వహణ',
    ],
    'Consulting / Advisory': [
      'సలహాదారు',
      'బిజినెస్ కన్సల్టెంట్',
      'కన్సల్టెన్సీ సంస్థలో పని',
    ],
    'Social / Community Service': [
      'సామాజిక కార్యకర్త',
      'సంక్షేమ ప్రాజెక్టు సహాయకుడు',
      'ఎన్‌జీవో ఉద్యోగాలు',
    ],
    'Occult / Astrology / Traditional Studies': [
      'జ్యోతిష్య సలహాదారు',
      'సంప్రదాయ విద్యా బోధన',
      'జ్యోతిష్య పరిశోధన',
    ],
  };
}
