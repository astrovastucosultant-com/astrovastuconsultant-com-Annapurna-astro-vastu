import 'astro_models.dart';
import 'varga_service.dart';
import 'jaimini_service.dart';
import 'marriage_chrome_if_then_engine.dart';

enum StabilityGrade397 { good, bad, medium, missing }

extension StabilityGradeText397 on StabilityGrade397 {
  String get label => switch (this) {
    StabilityGrade397.good => 'మంచి',
    StabilityGrade397.bad => 'చెడు',
    StabilityGrade397.medium => 'మధ్యస్థం',
    StabilityGrade397.missing => 'గణనకు సమాచారం లేదు',
  };
}

class StabilityCheck397 {
  final String id, condition, evidence, source, outcome;
  final bool? matched;
  final bool adverse, contextual;
  const StabilityCheck397(
    this.id,
    this.condition,
    this.evidence,
    this.source,
    this.outcome,
    this.matched, {
    this.adverse = false,
    this.contextual = false,
  });
}

class StabilityStage397 {
  final int factor;
  final List<StabilityCheck397> checks;
  const StabilityStage397(this.factor, this.checks);
  StabilityGrade397 get grade => MaritalStability397.grade(checks);
  String get result {
    final hits = checks.where((c) => c.matched == true && !c.contextual);
    final good = hits.where((c) => !c.adverse),
        bad = hits.where((c) => c.adverse);
    return [
      'దాంపత్య సూచనలు — ${grade.label}',
      if (good.isNotEmpty) 'మద్దతు: ${good.first.outcome}',
      if (bad.isNotEmpty) 'జాగ్రత్త: ${bad.first.outcome}',
      if (hits.isEmpty)
        'ఈ పరీక్షల్లో స్పష్టమైన ఏకపక్ష సూచన లేదు; సమస్య లేదా విడాకులు ఉన్నాయని అర్థం కాదు.',
    ].join('\n');
  }
}

class StabilityReport397 {
  final List<StabilityStage397> stages;
  final List<StabilityCheck397> additional;
  final StabilityGrade397 grade;
  final String note;
  const StabilityReport397(this.stages, this.additional, this.grade, this.note);
  String get conclusion => switch (grade) {
    StabilityGrade397.good =>
      'దాంపత్య నాణ్యతకు అనుకూల జన్మస్థితి మద్దతు ఉంది. ఇది సమస్యలు ఎప్పుడూ రావని హామీ కాదు.',
    StabilityGrade397.bad =>
      'D9, D30 రెండింటిలో ప్రతికూల సూచనలు కలిసి ఉన్నాయి. దాంపత్యంలో సమస్యలు, దూరం లేదా ఒత్తిడిపై జాగ్రత్త అవసరం; విడాకులు ఖాయమనే తీర్పు కాదు.',
    StabilityGrade397.medium =>
      'అనుకూల, ప్రతికూల ఆధారాలు కలిశాయి లేదా ప్రధాన యుక్త షరతులు ఏకపక్షంగా సరిపోలలేదు. అందువల్ల దాంపత్య సూచనలు మధ్యస్థం.',
    StabilityGrade397.missing =>
      'లగ్నం, అవసరమైన గ్రహస్థితులు పూర్తిగా లేవు. వాటితో మళ్లీ గణించాలి.',
  };
  String get d7Observation {
    final r = additional.where((c) => c.id == 'C06-01');
    if (r.isEmpty || r.first.matched != true)
      return 'D7 కేతు అనుబంధం: వర్తించిన ఆధారం చూపలేదు; దీనిని శుభ నిర్ధారణగా తీసుకోలేదు.';
    return 'D7 కేతు అనుబంధ సూచన ఉంది; ఒక్కటే విడాకుల నిర్ధారణ కాదు.';
  }
}

class MaritalStability397 {
  static const policy =
      'USER-MARITAL-REVIEW-397: ఇది జన్మస్థితి దాంపత్య నాణ్యత/ఒత్తిడి సూచనల యాప్ సమగ్ర విధానం. ప్రధాన ప్రతికూల సమ్మేళనం = D9 C01-02 లేదా C16-01/02 ప్రతికూల ఆధారం AND D30 C12-01 లేదా C12-03 ప్రతికూల ఆధారం. మంచి = (DK స్వ/ఉచ్చం C01-03 AND (D30 యాప్ అనుకూల పరీక్ష OR D1 స్వరాశి 7వ పాపగ్రహానికి ఫలదీపిక 10.6 అనుకూల మినహాయింపు)) OR నిర్వచించిన D9+D30+కారకాంశ మద్దతు; మంచి మద్దతు, D9–D30 ప్రతికూల సమ్మేళనం రెండూ ఉంటే మధ్యస్థం. ఒక్క ప్రతికూల చక్రాన్ని రెండో ప్రతికూల చక్రంగా లెక్కించలేదు; విడి హెచ్చరికలను దాచలేదు. ఇతర కలయికలు మధ్యస్థం. D1 అనుబంధం విడిగా చూపాం; ఒకే క్రాస్‌చార్ట్ రూల్‌ను రెండుసార్లు లెక్కించలేదు. D7 కేతువు ఒక్కటే చెడు/విడాకుల తీర్పు ఇవ్వదు. C18-03ను C12/C16 వంటి ఇతర నియమాలకు సార్వత్రిక రద్దుగా వాడలేదు. శాతం/ఓట్ల గణన లేదు; ఇది గ్రంథ శ్లోకం కాదు. వివాహిత/అవివాహిత స్థితిని, నిజ జీవిత వివాదాన్ని ఊహించలేదు; విడాకుల సంఘటన లేదా తేదీని ప్రకటించలేదు.';
  static StabilityGrade397 grade(Iterable<StabilityCheck397> checks) {
    final hits = checks.where((c) => c.matched == true && !c.contextual);
    final good = hits.any((c) => !c.adverse), bad = hits.any((c) => c.adverse);
    return good == bad
        ? StabilityGrade397.medium
        : bad
        ? StabilityGrade397.bad
        : StabilityGrade397.good;
  }

  static StabilityGrade397 combine({
    required bool positive,
    required bool d9Adverse,
    required bool d30Adverse,
  }) {
    final negative = d9Adverse && d30Adverse;
    if (positive && negative) return StabilityGrade397.medium;
    if (negative) return StabilityGrade397.bad;
    if (positive) return StabilityGrade397.good;
    return StabilityGrade397.medium;
  }

  static StabilityReport397 evaluate(AstroChartResult chart) {
    const names = {
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    };
    if (!chart.ascendantLongitude.isFinite ||
        !chart.planets.map((p) => p.name).toSet().containsAll(names) ||
        chart.planets.any((p) => !p.longitude.isFinite))
      return const StabilityReport397(
        [],
        [],
        StabilityGrade397.missing,
        policy,
      );
    final d1 = _Stable397(VargaService.calculate(chart, 1)),
        d9 = _Stable397(VargaService.calculate(chart, 9)),
        d30 = _Stable397(VargaService.calculate(chart, 30));
    StabilityCheck397 source(
      String id, {
      bool adverse = false,
      bool contextual = false,
    }) {
      final rule = MarriageChromeIfThenEngine.rules.singleWhere(
            (r) => r.id == id,
          ),
          value = MarriageChromeIfThenEngine.evaluate(rule, chart);
      final safe = switch (id) {
        'C12-03' =>
          'D30 7వ, 8వ భావాల్లో ప్రతికూల మూల సూచన; వివాహ నిరాకరణ/విడాకులు అని ఈ జాతకానికి ఖరారు చేయలేదు.',
        'C12-01' =>
          'D1–D30 లగ్న క్రాస్‌చార్ట్ ప్రతికూల సూచన; వివాహ ఆలస్యం/ఆటంకానికి మూల సూచన.',
        'C06-01' => 'D7 కేతు అనుబంధ సూచన మాత్రమే; విడాకులు తప్పనిసరి కాదు.',
        'C18-03' =>
          'మూల మినహాయింపు నమోదైంది; C12/C16 ప్రతికూల సూచనలను దీనితో ఆటోమేటిక్‌గా రద్దు చేయలేదు.',
        _ => rule.thenText,
      };
      return StabilityCheck397(
        id,
        rule.ifText,
        '${value.examination}\nమూల THEN (సూచన మాత్రమే): ${rule.thenText}',
        '${MarriageChromeIfThenEngine.source} • పేజీ ${rule.page}',
        safe,
        value.isComputed ? value.matches : null,
        adverse: adverse,
        contextual: contextual,
      );
    }

    StabilityCheck397 app(String id, _Stable397 v, bool adverse) {
      final met = adverse ? v.harmful() : v.supportive();
      return StabilityCheck397(
        id,
        adverse
            ? '7వ భావం లేదా 7వ అధిపతిపై సూర్య/కుజ/శని/నోడ్ యుతి లేదా పరీక్షించిన గ్రహదృష్టి; D1లో 7వ స్వరాశి పాపగ్రహానికి PD10.6 మినహాయింపు వర్తిస్తుంది'
            : '7వ భావం/అధిపతికి గురు/శుక్ర మద్దతు OR 7వ అధిపతి స్వ/ఉచ్చ స్థితి; ప్రత్యక్ష పాప ప్రభావం ఉండకూడదు',
        v.audit(),
        'USER-MARITAL-REVIEW-397 యాప్ నిర్దిష్ట అనుబంధ నిర్వచనం; ప్రత్యేక గ్రంథ IFగా ప్రకటించలేదు.',
        adverse
            ? '7వ భావం / అధిపతిపై ఒత్తిడి సూచన.'
            : '7వ భావం / అధిపతికి అనుకూల మద్దతు.',
        met,
        adverse: adverse,
      );
    }

    final stages = [
      StabilityStage397(1, [
        app('USER-REL-D1-SUPPORT', d1, false),
        app('USER-REL-D1-CAUTION', d1, true),
        StabilityCheck397(
          'PD-10-06-OWN7',
          'D1 7వ భావంలో సూర్య/కుజ/శని స్వరాశిలో ఉండటం',
          '7వ రాశి ${d1.seventh + 1}; స్వరాశి 7వ పాపగ్రహం=${d1.ownMalefic7()}. ${d1.audit()}',
          'ఫలదీపిక, అధ్యాయం 10, శ్లోకం 6; V. Subrahmanya Sastri, 1950 ముద్రిత పేజీ 107. https://www.wisdomlib.org/uploads/ocr/essays/phaladeepika/phaladeepika-2nd-ed-1950-by-v-subrahmanya-sastri-text.pdf',
          '7వ భావంలో స్వరాశి పాపగ్రహం ఉన్నప్పటికీ మూలం అనుకూల ఫలితం చెప్పిన మినహాయింపు. ఇతర సంబంధాలన్నీ రద్దు కావు.',
          d1.ownMalefic7(),
        ),
      ]),
      StabilityStage397(9, [
        source('C01-02', adverse: true),
        source('C01-03'),
        source('C16-01', adverse: true),
        source('C16-02', adverse: true),
      ]),
      StabilityStage397(30, [
        source('C12-01', adverse: true),
        source('C12-02', contextual: true),
        source('C12-03', adverse: true),
        app('USER-REL-D30-SUPPORT', d30, false),
      ]),
    ];
    final jaimini = JaiminiService.calculate(chart),
        kl = jaimini.karakamsaSignIndex;
    final klTarget = (kl + 6) % 12;
    final klGood =
        !jaimini.hasDegreeTie &&
        d9.beneficsOn(klTarget).isNotEmpty &&
        d9.maleficsOn(klTarget).isEmpty;
    final operational = d9.supportive() && d30.supportive() && klGood;
    final qualityRule = MarriageChromeIfThenEngine.rules.singleWhere(
      (r) => r.id == 'C10-01',
    );
    final additional = [
      StabilityCheck397(
        'C10-01',
        qualityRule.ifText,
        'మూలంలో “రెండూ శుభం”, కారకాంశ మద్దతు అనే సమగ్ర ప్రమాణం ఉంది; కింద యాప్ నిర్దిష్ట నిర్వచనాన్ని వేరుగా పరీక్షించాం. ఈ మూల రూల్ మొత్తం ధృవీకరించామని చెప్పలేదు.',
        '${MarriageChromeIfThenEngine.source} • పేజీ 3',
        qualityRule.thenText,
        null,
        contextual: true,
      ),
      StabilityCheck397(
        'USER-C10-OP-397',
        'D9 7H/7L యాప్ మద్దతు AND D30 7H/7L యాప్ మద్దతు AND AK నవాంశ రాశి నుంచి 7వదానికి గురు/శుక్ర మద్దతు, పాప ప్రభావం లేకపోవడం',
        'D9: ${d9.audit()}\nD30: ${d30.audit()}\nకారకాంశ రాశి ${jaimini.karakamsaSignIndex + 1}; కారక డిగ్రీ సమానత్వం=${jaimini.hasDegreeTie}; KL 7వ శుభగ్రహాలు=${d9.beneficsOn(klTarget)}, పాపగ్రహాలు=${d9.maleficsOn(klTarget)}.',
        'C10-01 ప్రేరణతో USER-MARITAL-REVIEW-397 యాప్ ఆచరణ నిర్వచనం; మూలంలోని సంపూర్ణ “శుభం”కు సమానమని ప్రకటించలేదు.',
        'నిర్వచించిన D9–D30–కారకాంశ యాప్ విధానంలో నాణ్యతకు మద్దతు.',
        jaimini.hasDegreeTie ? null : operational,
      ),
      source('C06-01', adverse: true, contextual: true),
      source('C18-03', contextual: true),
    ];
    bool hit(String id) => stages
        .expand((s) => s.checks)
        .any((c) => c.id == id && c.matched == true);
    final bad9 = ['C01-02', 'C16-01', 'C16-02'].any(hit),
        bad30 = ['C12-01', 'C12-03'].any(hit);
    final positive =
        (hit('C01-03') && (d30.supportive() || d1.ownMalefic7())) ||
        operational;
    return StabilityReport397(
      List.unmodifiable(stages),
      List.unmodifiable(additional),
      combine(positive: positive, d9Adverse: bad9, d30Adverse: bad30),
      policy,
    );
  }
}

class _Stable397 {
  final VargaChartData chart;
  late final signs = {for (final p in chart.planets) p.name: p.signIndex};
  _Stable397(this.chart);
  static const lords = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];
  static const ex = {
    'Sun': 0,
    'Moon': 1,
    'Mars': 9,
    'Mercury': 5,
    'Jupiter': 3,
    'Venus': 11,
    'Saturn': 6,
  };
  int get seventh => (chart.ascendantSignIndex + 6) % 12;
  String get lord7 => lords[seventh];
  bool aspect(String p, int target) {
    if (p == 'Rahu' || p == 'Ketu') return false;
    final d = (target - signs[p]! + 12) % 12;
    return d == 6 ||
        (p == 'Mars' && (d == 3 || d == 7)) ||
        (p == 'Jupiter' && (d == 4 || d == 8)) ||
        (p == 'Saturn' && (d == 2 || d == 9));
  }

  List<String> on(int target, Iterable<String> planets, {String? exclude}) => [
    for (final p in planets)
      if (p != exclude && (signs[p] == target || aspect(p, target))) p,
  ];
  List<String> beneficsOn(int sign, {String? exclude}) =>
      on(sign, ['Jupiter', 'Venus'], exclude: exclude);
  List<String> maleficsOn(int sign, {String? exclude}) =>
      on(sign, ['Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'], exclude: exclude);
  bool ownMalefic7() => [
    'Sun',
    'Mars',
    'Saturn',
  ].any((p) => signs[p] == seventh && lords[seventh] == p);
  bool harmful() =>
      maleficsOn(seventh)
          .where(
            (p) =>
                !(chart.definition.factor == 1 &&
                    signs[p] == seventh &&
                    lords[seventh] == p),
          )
          .isNotEmpty ||
      maleficsOn(signs[lord7]!, exclude: lord7).isNotEmpty;
  bool supportive() =>
      !harmful() &&
      (beneficsOn(seventh).isNotEmpty ||
          beneficsOn(signs[lord7]!, exclude: lord7).isNotEmpty ||
          lords[signs[lord7]!] == lord7 ||
          ex[lord7] == signs[lord7]);
  String audit() =>
      'D${chart.definition.factor}: 7వ రాశి ${seventh + 1}; 7వ అధిపతి $lord7 రాశి ${signs[lord7]! + 1}; భావంపై శుభ=${beneficsOn(seventh)}, పాప=${maleficsOn(seventh)}; అధిపతిపై శుభ=${beneficsOn(signs[lord7]!, exclude: lord7)}, పాప=${maleficsOn(signs[lord7]!, exclude: lord7)}. D1 స్వరాశి 7వ పాపగ్రహానికి PD10.6 మినహాయింపు వర్తిస్తుందా=${chart.definition.factor == 1 && ownMalefic7()}; ఆ ఒక్క గ్రహాన్ని మాత్రమే ఆ పీడ పరీక్ష నుంచి మినహాయించాం. చంద్ర/బుధులను స్వయంచాలక శుభ/పాపంగా ఊహించలేదు; నోడ్ దృష్టులు ఊహించలేదు.';
}
