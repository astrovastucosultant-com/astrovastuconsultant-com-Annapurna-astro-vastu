import 'astro_models.dart';
import 'client_guidance_model_v406.dart';
import 'health_body_areas_v404.dart';
import 'varga_service.dart';
import 'source_topic_checks_v393.dart';
import 'd10_career_service.dart';
import 'd2_dhana_asthi_registry.dart';
import 'd2_wealth_evaluation_service.dart';

enum TopicGrade398 { supportive, caution, mixed, context, missing }

extension TopicGradeLabel398 on TopicGrade398 {
  String get label => switch (this) {
    TopicGrade398.supportive => 'అనుకూల సూచనలు',
    TopicGrade398.caution => 'జాగ్రత్త సూచనలు',
    TopicGrade398.mixed => 'మిశ్రమ / మధ్యస్థ సూచనలు',
    TopicGrade398.context => 'అనుబంధ పరిశీలన',
    TopicGrade398.missing => 'గణనకు సమాచారం లేదు',
  };
}

class TopicCheck398 {
  final String id, condition, evidence, source, outcome;
  final bool? matched;
  final bool adverse, contextual;
  const TopicCheck398(
    this.id,
    this.condition,
    this.evidence,
    this.source,
    this.outcome,
    this.matched, {
    this.adverse = false,
    this.contextual = false,
  });
  String get status => matched == null
      ? 'మూల ఉపషరతు / ప్రత్యేక సమాచారం అవసరం'
      : matched!
      ? 'వర్తించింది'
      : 'వర్తించలేదు';
}

class TopicStage398 {
  final int factor;
  final List<TopicCheck398> checks;
  final ChartBodyAreas404? bodyAreas;
  final String deitySummary;
  const TopicStage398(
    this.factor,
    this.checks, {
    this.bodyAreas,
    this.deitySummary = '',
  });
  TopicGrade398 get grade => TopicResults398.grade(checks);
  String get result => [
    'D$factor — ${grade.label}',
    ...checks
        .where((c) => c.matched == true && !c.contextual)
        .map((c) => '${c.adverse ? "జాగ్రత్త" : "మద్దతు"}: ${c.outcome}'),
    ...checks
        .where((c) => c.matched == true && c.contextual)
        .map((c) => 'అనుబంధం: ${c.outcome}'),
    if (!checks.any((c) => c.matched == true && !c.contextual))
      grade == TopicGrade398.context
          ? 'ఈ చక్రం అనుబంధ ఆధారం; స్వతంత్ర సంఘటన నిర్ణయం చేయలేదు.'
          : 'ఈ పరీక్షల్లో ఏకపక్ష సూచన లేదు; సంఘటన లేదని అర్థం కాదు.',
  ].join('\n');
}

class TopicReport398 {
  final String topic, sourceId, conclusion, note;
  final List<TopicStage398> stages;
  final TopicGrade398 grade;
  final ClientGuidanceData406? clientGuidance;
  const TopicReport398(
    this.topic,
    this.sourceId,
    this.stages,
    this.grade,
    this.conclusion,
    this.note, {
    this.clientGuidance,
  });
}

/// Printed clauses stay distinct from explicitly labelled application reviews.
/// No number of available charts is an event probability or a source-rule hit.
class TopicResults398 {
  static const phala =
      'Phaladeepika • Mantreswara • '
      'https://lakshminarayanlenasia.com/articles/phaldipika.pdf';
  static const policy =
      'APP-TOPIC-REVIEW-398: వర్తించిన మద్దతు, జాగ్రత్త '
      'రెండూ ఉంటే మిశ్రమం; రెండూ లేకపోయినా మధ్యస్థం. మూల షరతు పూర్తికాని '
      'లేదా అనుబంధ పరీక్షలను ప్రధాన హిట్‌గా లెక్కించలేదు. D9, D6, D30 '
      'యాప్ అనుబంధ పరిశీలనలకు APP ID ఉంది; గ్రంథ నియమాలుగా చూపలేదు. '
      'చక్రాల సంఖ్య నుంచి సంఘటన శాతం లేదు. జన్మస్థితి నివేదికలో దశా/గోచార '
      'సమయం, సంతాన వైద్య నిర్ధారణ, కోర్టు తీర్పు, వీసా లేదా శాశ్వత నివాస '
      'అనుమతి నిర్ణయించలేదు. పరిహారం: ప్రత్యేక మూల పరిహారం నమోదు కాలేదు.';

  static TopicGrade398 grade(Iterable<TopicCheck398> checks) {
    final active = checks.where((c) => !c.contextual).toList();
    if (active.isEmpty) return TopicGrade398.context;
    final hits = active.where((c) => c.matched == true);
    final good = hits.any((c) => !c.adverse), bad = hits.any((c) => c.adverse);
    return good == bad
        ? TopicGrade398.mixed
        : bad
        ? TopicGrade398.caution
        : TopicGrade398.supportive;
  }

  static bool valid(AstroChartResult chart) {
    const names = {
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    };
    return chart.ascendantLongitude.isFinite &&
        chart.planets.map((p) => p.name).toSet().containsAll(names) &&
        names.every(
          (n) => chart.planets.where((p) => p.name == n).length == 1,
        ) &&
        chart.planets.every((p) => p.longitude.isFinite);
  }

  static TopicReport398 evaluate(AstroChartResult chart, String sourceId) {
    final name = switch (sourceId) {
      'VARGA-CROSS-005' => 'సంతానం',
      'VARGA-CROSS-011' => 'విదేశీ ప్రయాణం / నివాసం',
      'VARGA-CROSS-012' => 'కోర్టు కేసులు',
      _ => throw ArgumentError.value(sourceId),
    };
    if (!valid(chart))
      return TopicReport398(
        name,
        sourceId,
        const [],
        TopicGrade398.missing,
        'లగ్నం, తొమ్మిది గ్రహాల పూర్తి స్థానాలు కావాలి.',
        policy,
      );
    return sourceId == 'VARGA-CROSS-005'
        ? _children(chart)
        : sourceId == 'VARGA-CROSS-011'
        ? _foreign(chart)
        : _court(chart);
  }

  static TopicReport398 _children(AstroChartResult chart) {
    final d1 = SourceTopicChecks393.evaluate(chart, 'సంతానం', 1);
    final s1 = TopicStage398(1, [
      for (final c in d1)
        TopicCheck398(
          c.id,
          c.condition,
          c.evidence,
          c.source,
          c.result,
          c.matched,
          adverse: c.adverse,
        ),
    ]);
    final s7 = TopicStage398(7, childrenD7(VargaService.calculate(chart, 7)));
    final v9 = TopicGeometry398(VargaService.calculate(chart, 9));
    final d1v = TopicGeometry398(VargaService.calculate(chart, 1));
    final s9 = TopicStage398(9, [
      for (final n in {'Jupiter', d1v.lord(5)})
        TopicCheck398(
          'APP-CHILD-D9-$n',
          'D1 సంతాన కారక $n యొక్క D9 స్వరాశి/ఉచ్చ/నీచ స్థానం నమోదు',
          v9.placement(n),
          'APP-CHILD-D9-398 • అనుబంధ రాశి గౌరవ పరిశీలన',
          '$n: ${v9.dignity(n)}. D7 ప్రధాన ఫలితాన్ని ఇది ఒంటరిగా మార్చదు.',
          true,
          contextual: true,
        ),
    ]);
    final stages = [s1, s7, s9];
    final g = grade([...s1.checks, ...s7.checks]);
    final conclusion = switch (g) {
      TopicGrade398.supportive =>
        'సంతాన అంశానికి అనుకూల సంప్రదాయ ఆధారాలు ఉన్నాయి. '
            'సంతానంతో అనుబంధం, పంచమ భావ మద్దతు కింద విడిగా ఉన్నాయి.',
      TopicGrade398.caution =>
        'సంతాన అంశంలో ఆలస్యం లేదా సంబంధ ఒత్తిడి సూచనలు '
            'ప్రధానంగా ఉన్నాయి; శ్రద్ధ, సహకారం అవసరం.',
      _ =>
        'సంతాన అంశంలో మద్దతు, జాగ్రత్త రెండూ ఉన్నాయి లేదా ఏకపక్ష ఆధారం లేదు. '
            'అంశాలవారీ ఫలితం మధ్యస్థం.',
    };
    return TopicReport398(
      'సంతానం',
      'VARGA-CROSS-005',
      stages,
      g,
      conclusion,
      '$policy పిల్లల లింగం, సంఖ్య లేదా గర్భస్రావం/సంతానలేమి వైద్య నిర్ధారణ ఇవ్వలేదు. '
          'D7 స్వతంత్ర క్లాజుల మద్దతును సరళ VII పూర్తి బల పరీక్షతో సమానం చేయలేదు.',
    );
  }

  /// Source p15: the conjunction, mutual aspect and exchange alternatives are
  /// all tested. A single lord shared by lagna and fifth is not self-conjunction.
  static List<TopicCheck398> childrenD7(VargaChartData chart) {
    final v = TopicGeometry398(chart),
        l1 = vLord(chart, 1),
        l5 = vLord(chart, 5);
    const src = 'Saptamsha_Santana_Niyamalu.pdf • పేజీ 15';
    final audit =
        '${v.placement(l1)}; ${v.placement(l5)}; ${v.placement("Jupiter")}';
    return [
      TopicCheck398(
        'SAP-P15-1L5L-REL',
        'వేర్వేరు లగ్నాధిపతి, 5వ అధిపతి యుతి OR పరస్పర దృష్టి OR పరివర్తన',
        audit,
        '$src • ఫలదీపిక–2',
        'లగ్న–పంచమాధిపతుల పరస్పర మద్దతు.',
        l1 == l5
            ? false
            : v.conj(l1, l5) ||
                  (v.aspects(l1, v.sign(l5)) && v.aspects(l5, v.sign(l1))) ||
                  v.exchange(l1, l5),
      ),
      TopicCheck398(
        'SAP-P15-5L-TRIKA',
        '5వ అధిపతి 6/8/12వ భావంలో',
        audit,
        '$src • BPHS–2',
        'సంతాన అంశంలో ఆలస్యం/అదనపు శ్రద్ధ సూచన.',
        [6, 8, 12].contains(v.house(l5)),
        adverse: true,
      ),
      TopicCheck398(
        'SAP-P15-LAGNA-BENEFIC',
        'D7 లగ్నానికి గురు/శుక్ర యుతి లేదా పరాశరి దృష్టి',
        '${v.touching(v.asc, {"Jupiter", "Venus"})}; $audit',
        '$src • సరళ పద్ధతి–1 • శుభ సంబంధ ప్రత్యామ్నాయం',
        'D7 లగ్నానికి శుభ మద్దతు; పిల్లల పట్ల అనుకూల ధోరణి సూచన.',
        v.influenced(v.asc, {'Jupiter', 'Venus'}),
      ),
      TopicCheck398(
        'SAP-P15-LAGNA-MALEFIC',
        'D7 లగ్నానికి సూర్య/కుజ/శని యుతి లేదా దృష్టి; రాహు/కేతు యుతి',
        v.touching(v.asc, TopicGeometry398.malefics),
        '$src • సరళ పద్ధతి–1b • నిర్వచించిన ప్రత్యక్ష పాప సంబంధం',
        'సంతాన సంబంధ వ్యవహారాల్లో సహనం, అదనపు ప్రయత్నం అవసరమనే సూచన.',
        v.influenced(v.asc, TopicGeometry398.malefics),
        adverse: true,
      ),
      TopicCheck398(
        'VARGA-D7-004',
        'గురువుపై శుభగ్రహ దృష్టి',
        '${v.placement("Jupiter")}; దృష్టి: ${v.aspectSenders(v.sign("Jupiter"), {"Venus"})}',
        'Mallikarjuna 255 Rules PDF • D7 • పేజీ 7 • స్థిర శుభగ్రహ క్లాజు',
        'సంతానంతో ప్రేమానురాగానికి మద్దతు.',
        // Moon/Mercury need phase/association classification; a Venus hit is
        // sufficient, absence alone cannot falsify the entire source rule.
        v.aspects('Venus', v.sign('Jupiter')) ? true : null,
      ),
      TopicCheck398(
        'VARGA-D7-005',
        'గురువుపై పాపగ్రహ దృష్టి',
        '${v.placement("Jupiter")}; ${v.aspectSenders(v.sign("Jupiter"), {"Sun", "Mars", "Saturn"})}',
        'Mallikarjuna 255 Rules PDF • D7 • పేజీ 7',
        'సంతానంతో విభేదాలు/దూరం నివారించేందుకు సంభాషణపై శ్రద్ధ సూచన.',
        v.aspectSenders(v.sign('Jupiter'), {'Sun', 'Mars', 'Saturn'}).isNotEmpty
            ? true
            : null,
        adverse: true,
      ),
      TopicCheck398(
        'APP-D7-PIIDA-398',
        'D7 పంచమ భావం AND గురువు — ఇద్దరికీ నిర్వచించిన పాప యుతి/దృష్టి',
        '5వ భావం: ${v.touching(v.houseSign(5), TopicGeometry398.malefics)}; '
            'గురువు: ${v.touching(v.sign("Jupiter"), TopicGeometry398.malefics)}',
        'APP-D7-PIIDA-398 • VARGA-D7-006 విస్తృత పీడ పదానికి యాప్ పరిశీలన',
        'సంతాన ప్రణాళికలో శ్రద్ధ అవసరం; గర్భస్రావం లేదా వైద్య సమస్య నిర్ధారణ కాదు.',
        v.influenced(v.houseSign(5), TopicGeometry398.malefics) &&
            v.influenced(v.sign('Jupiter'), TopicGeometry398.malefics),
        adverse: true,
      ),
      const TopicCheck398(
        'S7-D7-COMPOSITE',
        '5వ భావ బలం AND పుత్రకారక బలం; జ్ఞాతికారక పీడ పరిశీలన',
        'ఈ స్వతంత్ర క్లాజులు పూర్తి షడ్బల/కారక పీడ నిర్వచనాన్ని భర్తీ చేయవు.',
        'Sarala 7 final.pdf • పేజీ 5',
        'సమగ్ర మూల బల పరీక్ష వేరు.',
        null,
        contextual: true,
      ),
    ];
  }

  static String vLord(VargaChartData v, int h) =>
      TopicGeometry398.lords[(v.ascendantSignIndex + h - 1) % 12];

  static TopicReport398 _foreign(AstroChartResult chart) {
    final d1 = TopicGeometry398(VargaService.calculate(chart, 1));
    final d9 = TopicGeometry398(VargaService.calculate(chart, 9));
    final d4 = TopicGeometry398(VargaService.calculate(chart, 4));
    final foreign = D10CareerService.foreignEvidence(chart);
    final l10 = d1.lord(10), own = d1.influenced(d1.houseSign(10), {l10});
    final others = d1.touching(
      d1.houseSign(10),
      {
        'Sun',
        'Moon',
        'Mars',
        'Mercury',
        'Jupiter',
        'Venus',
        'Saturn',
      }.difference({l10}),
    );
    final fixed = {1, 4, 7, 10}.contains(d9.sign(l10));
    final rule = D2DhanaAsthiRegistry.rules.singleWhere(
      (r) => r.id == 'D2-OT-004',
    );
    final hits = D2WealthEvaluationService.evaluate(chart);
    final stages = [
      TopicStage398(1, [
        TopicCheck398(
          'PHALA-5-9-AWAY',
          'D1 దశమ రాశికి అధిపతి కాకుండా ఇతర గ్రహ స్థితి/దృష్టి',
          '10వ అధిపతి $l10; ఇతర గ్రహ ప్రభావం: $others',
          '$phala • అధ్యాయం 5.9 • ముద్రిత పేజీ 53',
          'జన్మస్థలానికి దూరంగా ఆదాయ మార్గం సూచన; అంతర్జాతీయ ప్రయాణం తప్పనిసరి కాదు.',
          others.isNotEmpty,
        ),
        TopicCheck398(
          'PHALA-5-9-HOME',
          'D1 దశమ రాశికి దాని అధిపతి స్థితి/దృష్టి',
          '${d1.placement(l10)}; దశమ రాశిపై స్వామి ప్రభావం: $own',
          '$phala • అధ్యాయం 5.9 • ముద్రిత పేజీ 53',
          'స్వదేశ ఆదాయానికి మద్దతు; విదేశీ సూచనకు విరుద్ధ ఆధారం కూడా ఉంది.',
          own,
          adverse: true,
        ),
        const TopicCheck398(
          'KP-005',
          'సంబంధిత CSL ద్వారా 3/9/12 సూచనలు AND మద్దతు సిగ్నిఫికేటర్లు',
          'జన్మ రాశి స్థానాలు KP cusp sub-lord/significator డేటాకు ప్రత్యామ్నాయం కావు.',
          'kp_rules_rule_based.html • KP-005 • మూల పేజీ 5 సూచన',
          'KP విదేశీ ప్రయాణ పరీక్షకు cusp/sub-lord వివరాలు అవసరం.',
          null,
          contextual: true,
        ),
      ]),
      TopicStage398(9, [
        TopicCheck398(
          'PHALA-5-9-FIXED-NAVAMSA',
          'D1 దశమాధిపతి D9లో స్థిర రాశిలో',
          'D1 10L $l10 → ${d9.placement(l10)}',
          '$phala • అధ్యాయం 5.9 • ముద్రిత పేజీ 53',
          'స్వదేశ ఆదాయ సూచన; ఇతర దూరప్రాంత సూచనలతో కలిపి చూడాలి.',
          fixed,
          adverse: true,
        ),
      ]),
      TopicStage398(10, [
        TopicCheck398(
          'D10-FOREIGN-ALL7',
          foreign.checks.map((c) => c.label).join(' AND '),
          foreign.audit,
          'D10 special.pdf • విదేశీ ఉద్యోగం • ఇప్పటికే ఉన్న 7-షరతుల ఇంజిన్',
          'D1–D10 పూర్తి విదేశీ ఉద్యోగ మూల షరతుల మద్దతు.',
          foreign.fullRuleMatched,
        ),
      ]),
      TopicStage398(4, [
        TopicCheck398(
          'D2-OT-004',
          rule.condition,
          '${d1.placement(d1.lord(4))}; ${d1.placement("Rahu")}; '
              'D4 4L: ${d4.placement(d4.lord(4))}. రూల్ అసలు IF D1లోనే పరీక్షించాం.',
          '${D2DhanaAsthiRegistry.sourceFilename} • పేజీ ${rule.sourcePage}',
          'విదేశంలో గృహ సంబంధ అవకాశం సూచన; శాశ్వత నివాస అనుమతి నిర్ధారణ కాదు.',
          hits.any((r) => r.ruleId == 'D2-OT-004'),
        ),
      ]),
    ];
    final g = grade(stages.expand((s) => s.checks));
    return TopicReport398(
      'విదేశీ ప్రయాణం / నివాసం',
      'VARGA-CROSS-011',
      stages,
      g,
      g == TopicGrade398.supportive
          ? 'దూరప్రాంత ఆదాయం / విదేశ సంబంధానికి మద్దతు ఉంది. ఉద్యోగం, గృహం, స్వదేశ ఆధారాలు విడిగా కింద ఉన్నాయి.'
          : g == TopicGrade398.caution
          ? 'ప్రస్తుత పరీక్షల్లో స్వదేశ ఆదాయ సూచనలు ప్రధానంగా ఉన్నాయి. విదేశీ అవకాశం లేదనే తీర్పు కాదు.'
          : 'దూరప్రాంత, స్వదేశ సూచనలు కలిశాయి లేదా పూర్తి విదేశీ షరతులు సరిపోలలేదు. ప్రయాణం, ఉద్యోగం, నివాసాన్ని విడిగా పరిశీలించాలి.',
      '$policy విదేశానికి శాతం, దేశం లేదా బయలుదేరే తేదీ ఊహించలేదు. '
          'PHALA-5-9లో దూరప్రాంత ఆదాయం అంతర్జాతీయ వలసతో సమానం కాదు. '
          'D2-OT-004 D4 కార్డులో గృహ అంశంగా కనిపించినా మూల IF D1దే.',
    );
  }

  static List<TopicCheck398> courtD1(VargaChartData chart) {
    final v = TopicGeometry398(chart),
        l6 = vLord(chart, 6),
        l1 = vLord(chart, 1);
    return [
      TopicCheck398(
        'PHALA-16-16-L1H6',
        'లగ్నాధిపతి 6వ భావంలో',
        v.placement(l1),
        '$phala • అధ్యాయం 16.16(3) • ముద్రిత పేజీ 158',
        'ప్రత్యర్థులు/వివాదాల వల్ల ఒత్తిడికి సంప్రదాయ సూచన.',
        v.house(l1) == 6,
        adverse: true,
      ),
      TopicCheck398(
        'PHALA-16-16-L6KENDRA',
        '6వ అధిపతి కేంద్ర భావంలో (1/4/7/10)',
        v.placement(l6),
        '$phala • అధ్యాయం 16.16(4) • ముద్రిత పేజీ 158',
        'వివాద ఒత్తిడిని జాగ్రత్తగా నిర్వహించాల్సిన సూచన.',
        [1, 4, 7, 10].contains(v.house(l6)),
        adverse: true,
      ),
      TopicCheck398(
        'PHALA-6-63-STRICT',
        '6/8/12 అధిపతులు ముగ్గురూ 6వ భావంలో — కఠిన సంయుక్త పఠనం',
        [6, 8, 12].map((h) => v.placement(v.lord(h))).join('; '),
        '$phala • అధ్యాయం 6.63 • ముద్రిత పేజీ 79 • పాఠాంతరాన్ని ORగా మార్చలేదు',
        'ప్రత్యర్థులను ఎదుర్కొనే అనుకూల సంప్రదాయ యోగ మద్దతు; కోర్టు గెలుపు తీర్పు కాదు.',
        [6, 8, 12].every((h) => v.house(v.lord(h)) == 6),
      ),
      TopicCheck398(
        'APP-COURT-6L-OWN',
        'D1 6వ అధిపతి తన 6వ భావంలో',
        v.placement(l6),
        'APP-COURT-398 • Phaladeepika అధ్యాయం 6 పేజీలు 76,80–81 వ్యాఖ్యలతో అనుబంధ పరిశీలన',
        'ప్రత్యర్థి వ్యవహారాలను ఎదుర్కొనే మద్దతు. పూర్తి హర్షయోగమని లేదా చట్టబద్ధ విజయం అని లెక్కించలేదు.',
        v.house(l6) == 6,
        contextual: true,
      ),
      const TopicCheck398(
        'KP-012',
        'లిటిగేషన్ CSL సూచనలు 6/9/10/11 AND విజయ/నెరవేర్పు మద్దతు',
        'అప్పీల్ వివరాలు, cusp sub-lord/significator డేటా ఈ జన్మస్థితి నివేదికలో లేవు.',
        'kp_rules_rule_based.html • KP-012 • మూల పేజీ 9 సూచన',
        'అప్పీల్ అడ్మిషన్ పరీక్ష; మొత్తం కేసు విజయం అనే రూల్ కాదు.',
        null,
        contextual: true,
      ),
    ];
  }

  static TopicReport398 _court(AstroChartResult chart) {
    final d6 = TopicGeometry398(VargaService.calculate(chart, 6));
    final d30 = TopicGeometry398(VargaService.calculate(chart, 30));
    final stages = [
      TopicStage398(1, courtD1(VargaService.calculate(chart, 1))),
      TopicStage398(6, [
        TopicCheck398(
          'APP-COURT-D6-398',
          'ఎంచుకున్న D6లో లగ్నం/లగ్నాధిపతి పాప సంబంధ నమోదు',
          '${d6.placement(d6.lord(1))}; లగ్నం: ${d6.touching(d6.asc, TopicGeometry398.malefics)}; '
              'లగ్నాధిపతి: ${d6.touching(d6.sign(d6.lord(1)), TopicGeometry398.malefics.difference({d6.lord(1)}))}',
          'APP-COURT-D6-398 • ఐచ్ఛిక P.V.R. Narasimha Rao D6 నిర్మాణం • కోర్టు గ్రంథ నియమం కాదు',
          'లగ్నంపై పాప సంబంధం ${d6.influenced(d6.asc, TopicGeometry398.malefics) ? "ఉంది" : "లేదు"}; '
              'లగ్నాధిపతిపై ఇతర పాప సంబంధం ${d6.influenced(d6.sign(d6.lord(1)), TopicGeometry398.malefics.difference({d6.lord(1)})) ? "ఉంది" : "లేదు"}. '
              'ఇది ఆటంక సందర్భం మాత్రమే.',
          true,
          contextual: true,
        ),
      ]),
      TopicStage398(30, [
        TopicCheck398(
          'APP-COURT-D30-398',
          'D30 లగ్నం, 6వ భావం, శని–రాహు యుతి సంబంధ నమోదు',
          'లగ్నం: ${d30.touching(d30.asc, TopicGeometry398.malefics)}; '
              '6వ భావం: ${d30.touching(d30.houseSign(6), TopicGeometry398.malefics)}; '
              'శని–రాహు యుతి: ${d30.conj("Saturn", "Rahu")}',
          'APP-COURT-D30-398 • VARGA-CROSS-060 అనుబంధ ఆటంక పరిశీలన',
          'లగ్నంపై పాప సంబంధం ${d30.influenced(d30.asc, TopicGeometry398.malefics) ? "ఉంది" : "లేదు"}; '
              '6వ భావంపై పాప సంబంధం ${d30.influenced(d30.houseSign(6), TopicGeometry398.malefics) ? "ఉంది" : "లేదు"}; '
              'శని–రాహు యుతి ${d30.conj("Saturn", "Rahu") ? "ఉంది" : "లేదు"}. '
              'ఈ సందర్భం ఒక్కటే కేసు ఫలితం కాదు.',
          true,
          contextual: true,
        ),
      ]),
    ];
    final g = grade(stages.first.checks);
    return TopicReport398(
      'కోర్టు కేసులు',
      'VARGA-CROSS-012',
      stages,
      g,
      g == TopicGrade398.caution
          ? 'ప్రత్యర్థులు/వివాదాల ఒత్తిడిపై జాగ్రత్త సూచనలు ఉన్నాయి. వ్యవహారాలను సహనంతో నిర్వహించాలి.'
          : g == TopicGrade398.supportive
          ? 'ప్రత్యర్థులను ఎదుర్కొనే అనుకూల సంప్రదాయ మద్దతు ఉంది.'
          : 'వివాద అంశానికి ఏకపక్ష తీర్పు ఇచ్చే ఆధారం లేదు లేదా మద్దతు–ఒత్తిడి కలిశాయి; మధ్యస్థ పరిశీలన.',
      '$policy D6/D30 సందర్భాన్ని D1 చట్టబద్ధ తీర్పుకు అదనపు ఓట్లుగా కలపలేదు. '
          'కేసు ఉందని, ఏ పక్షం గెలుస్తుందని, శిక్ష/జైలు లేదా తీర్పు తేదీని ఊహించలేదు. '
          'అసలు కేసు ఫలితానికి పత్రాలు, సాక్ష్యాలు, న్యాయ ప్రక్రియ ఆధారాలు అవసరం.',
    );
  }
}

/// Whole-sign geometry with ordinary Parashari aspects. Nodes have conjunction
/// only; no fabricated node aspects. Moon/Mercury are not unconditionally benign.
class TopicGeometry398 {
  final VargaChartData v;
  TopicGeometry398(this.v);
  static const lords = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];
  static const malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};
  static const exalts = {
    'Sun': 0,
    'Moon': 1,
    'Mars': 9,
    'Mercury': 5,
    'Jupiter': 3,
    'Venus': 11,
    'Saturn': 6,
  };
  int get asc => v.ascendantSignIndex;
  int sign(String n) => v.planets.singleWhere((p) => p.name == n).signIndex;
  int houseSign(int h) => (asc + h - 1) % 12;
  int house(String n) => (sign(n) - asc + 12) % 12 + 1;
  String lord(int h) => lords[houseSign(h)];
  bool conj(String a, String b) => a != b && sign(a) == sign(b);
  bool aspects(String p, int target) {
    if (p == 'Rahu' || p == 'Ketu') return false;
    final d = (target - sign(p) + 12) % 12;
    return d == 6 ||
        (p == 'Mars' && [3, 7].contains(d)) ||
        (p == 'Jupiter' && [4, 8].contains(d)) ||
        (p == 'Saturn' && [2, 9].contains(d));
  }

  bool exchange(String a, String b) =>
      a != b && lords[sign(a)] == b && lords[sign(b)] == a;
  bool influenced(int s, Set<String> ps) =>
      ps.any((p) => sign(p) == s || aspects(p, s));
  String touching(int s, Set<String> ps) =>
      ps.where((p) => sign(p) == s || aspects(p, s)).join(', ');
  String aspectSenders(int s, Set<String> ps) =>
      ps.where((p) => aspects(p, s)).join(', ');
  String placement(String p) => '$p: రాశి ${sign(p) + 1}, ${house(p)}వ భావం';
  String dignity(String p) => exalts[p] == sign(p)
      ? 'ఉచ్చం'
      : exalts[p] != null && (exalts[p]! + 6) % 12 == sign(p)
      ? 'నీచం'
      : lords[sign(p)] == p
      ? 'స్వరాశి'
      : 'ఇతర రాశి';
}
