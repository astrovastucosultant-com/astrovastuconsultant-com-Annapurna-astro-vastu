class SaturnRoundInfo382 {
  final int round, from, to;
  final String title, summary;
  final List<String> sourceIds;
  const SaturnRoundInfo382(
    this.round,
    this.from,
    this.to,
    this.title,
    this.summary,
    this.sourceIds,
  );
}

class SaturnReviewTemplate382 {
  final String id, topic, title, favorable, unfavorable, neutral;
  final int round;
  const SaturnReviewTemplate382(
    this.id,
    this.round,
    this.topic,
    this.title,
    this.favorable,
    this.unfavorable,
    this.neutral,
  );
}

/// Background/review only; never publishes event predictions or timing.
class BnnSaturnRounds382 {
  final List<SaturnRoundInfo382> rounds;
  final List<SaturnReviewTemplate382> reviews;
  final Map<String, String> sources;
  const BnnSaturnRounds382._(this.rounds, this.reviews, this.sources);
  static const missing = 'గణనకు సమాచారం లేదు';
  static const unsupported = 'ఈ రౌండ్‌కు ధ్రువీకరించిన డేటా లేదు';
  static const topics = {
    'education',
    'employment',
    'business',
    'finance',
    'marriage',
    'children',
    'family',
    'property',
    'travel',
    'health',
    'disputes',
    'spirituality',
  };
  factory BnnSaturnRounds382.fromJson(Map<String, dynamic> data) {
    if (data['module_id'] != 'BNN_SATURN_THREE_ROUNDS' ||
        data['schema_version'] != '1.0.0' ||
        data['package_type'] != 'data_catalog_not_app_patch')
      throw const FormatException('Invalid round catalog');
    final policy = data['render_policy'] as Map;
    if (policy['round_only_prediction'] != false ||
        policy['templates_in_review_tab_only'] != true ||
        policy['require_external_sourced_rule_for_prediction'] != true ||
        policy['never_infer_missing_date_or_percentage'] != true)
      throw const FormatException('Invalid review policy');
    final health = policy['health_policy'] as Map;
    if (health['do_not_predict_death'] != true ||
        health['do_not_diagnose'] != true)
      throw const FormatException('Invalid health policy');
    final model = data['cycle_model'] as Map;
    if (model['type'] != 'symbolic_30_year' ||
        model['years_per_round'] != 30 ||
        model['supported_age_max_exclusive'] != 90)
      throw const FormatException('Invalid age model');
    final sources = <String, String>{};
    for (final row in data['sources'] as List) {
      final id = row['id'] as String;
      if (sources.containsKey(id))
        throw const FormatException('Duplicate source');
      sources[id] = '${row['author']} • ${row['title']} • ${row['pages']}';
    }
    final rounds = <SaturnRoundInfo382>[];
    for (final row in data['rounds'] as List) {
      final r = row['round'] as int,
          from = row['age_min_inclusive'] as int,
          to = row['age_max_exclusive'] as int;
      final ids = (row['source_ids'] as List).cast<String>();
      if (r < 1 ||
          r > 3 ||
          from != (r - 1) * 30 ||
          to != r * 30 ||
          row['prediction_enabled'] != false ||
          row['content_type'] != 'source_summary' ||
          ids.isEmpty ||
          ids.any((id) => !sources.containsKey(id)))
        throw const FormatException('Invalid round summary');
      rounds.add(
        SaturnRoundInfo382(
          r,
          from,
          to,
          row['title_te'] as String,
          row['summary_te'] as String,
          List.unmodifiable(ids),
        ),
      );
    }
    if (rounds.length != 3 || rounds.map((r) => r.round).toSet().length != 3)
      throw const FormatException('Three rounds required');
    rounds.sort((a, b) => a.round.compareTo(b.round));
    final reviews = <SaturnReviewTemplate382>[],
        ids = <String>{},
        slots = <String>{};
    for (final row in data['review_templates'] as List) {
      final r = row['round'] as int, topic = row['topic'] as String;
      if (r < 1 ||
          r > 3 ||
          !topics.contains(topic) ||
          row['prediction_enabled'] != false ||
          row['content_type'] != 'editorial_review_template' ||
          row['source_status'] != 'not_verified_as_round_specific_rule' ||
          (row['source_ids'] as List).isNotEmpty ||
          (row['required_evidence'] as Map).values.any((v) => v != null) ||
          !ids.add(row['id'] as String) ||
          !slots.add('$r/$topic'))
        throw const FormatException('Invalid review template');
      final text = row['result_templates_te'] as Map;
      reviews.add(
        SaturnReviewTemplate382(
          row['id'] as String,
          r,
          topic,
          row['title_te'] as String,
          text['favorable'] as String,
          text['unfavorable'] as String,
          text['neutral'] as String,
        ),
      );
    }
    if (reviews.length != 36 || slots.length != 36)
      throw const FormatException('36 reviews required');
    return BnnSaturnRounds382._(
      List.unmodifiable(rounds),
      List.unmodifiable(reviews),
      Map.unmodifiable(sources),
    );
  }
  static int? completedAgeAt(DateTime? birth, DateTime at) {
    if (birth == null) return null;
    DateTime wall(DateTime d) => DateTime.utc(
      d.year,
      d.month,
      d.day,
      d.hour,
      d.minute,
      d.second,
      d.millisecond,
      d.microsecond,
    );
    final born = wall(birth), moment = wall(at);
    if (moment.isBefore(born)) return null;
    var age = moment.year - born.year;
    final anniversary = DateTime.utc(
      moment.year,
      born.month,
      born.day,
      born.hour,
      born.minute,
      born.second,
      born.millisecond,
      born.microsecond,
    );
    if (moment.isBefore(anniversary)) age--;
    return age < 0 ? null : age;
  }

  SaturnRoundInfo382? forCompletedAge(int? age) =>
      age == null || age < 0 || age >= 90 ? null : rounds[age ~/ 30];
  String? statusForAge(int? age) => age == null || age < 0
      ? missing
      : age >= 90
      ? unsupported
      : null;
  static Set<String> topicsForEvent(String id) {
    if (id.startsWith('EDU-') || id == 'CHILD-EDU') return {'education'};
    if (id == 'CAREER-BUSINESS') return {'business'};
    if (id.startsWith('CAREER-')) return {'employment'};
    if (id.startsWith('MARRIAGE')) return {'marriage'};
    if (id == 'CHILDREN') return {'children'};
    if ({
      'MOTHER',
      'FATHER',
      'GRANDPARENTS',
      'RELATIVE-BEREAVEMENT',
    }.contains(id))
      return {'family'};
    if ({'WEALTH', 'PROFIT', 'SAVINGS', 'LOSS'}.contains(id))
      return {'finance'};
    if ({'HOUSE', 'LAND'}.contains(id)) return {'property'};
    if (id == 'FOREIGN-JOB') return {'employment', 'travel'};
    if (id == 'FOREIGN-TRAVEL') return {'travel'};
    if ({'CHILD-HEALTH', 'HEALTH-ADULT', 'ACCIDENT', 'LONGEVITY'}.contains(id))
      return {'health'};
    return {};
  }

  List<SaturnReviewTemplate382> reviewFor(
    SaturnRoundInfo382 round, {
    String? eventId,
  }) {
    final selected = eventId == null ? topics : topicsForEvent(eventId);
    return List.unmodifiable(
      reviews.where(
        (r) => r.round == round.round && selected.contains(r.topic),
      ),
    );
  }
}
