import 'astro_models.dart';
import 'wealth_detail_v410.dart';
import 'goel_hora_class_v410.dart';
import 'varga_service.dart';
import 'topic_results_v398.dart';
import 'd2_dhana_asthi_registry.dart';
import 'd2_wealth_evaluation_service.dart';
import 'deity_guidance_v405.dart';
import 'client_guidance_model_v406.dart';

class WealthView409 {
  final String key, title, scope;
  final VargaChartData data;
  final List<TopicCheck398> checks;
  const WealthView409(this.key, this.title, this.scope, this.data, this.checks);
  TopicGrade398 get grade => TopicResults398.grade(checks);
  String get result => [
    grade.label,
    for (final c in checks.where((c) => c.matched == true && !c.contextual))
      '${c.adverse ? "జాగ్రత్త" : "మద్దతు"}: ${c.outcome}',
    for (final c in checks.where((c) => c.matched == true && c.contextual))
      'అనుబంధం: ${c.outcome}',
    if (!checks.any((c) => c.matched == true && !c.contextual))
      'ఈ పరీక్షల్లో ప్రధాన ఏకపక్ష సూచన లేదు; ధనం లేదనే తీర్పు కాదు.',
  ].join('\n');
}

class WealthReport409 {
  final WealthView409? foundation;
  final List<WealthView409> views;
  final TopicGrade398 grade;
  final String conclusion, note;
  final ClientGuidanceData406? guidance;
  final WealthDetail410? detail;
  const WealthReport409(
    this.foundation,
    this.views,
    this.grade,
    this.conclusion,
    this.note,
    this.guidance, {
    this.detail,
  });
}

class WealthTopic409 {
  static const id = 'USER-WEALTH-409';
  static const source =
      'Dhana_Aasthi_Rules.pdf • ఇచ్చిన 58 నియమాల పునర్వ్యాఖ్యానం • pp.1–7';
  static const labhaSource =
      'PJC • Mihira Hora, Brihat Jataka 1.12½ table • https://pjc2.parasarahora.in/varga/hora-d2/mihira-hora/';
  static const rbi =
      'RBI Financial Awareness Messages • https://www.rbi.org.in/FinancialEducation/fame.aspx';
  static const note =
      'D1 ఉమ్మడి పునాది; పరాశర D2 దశ స్వభావం, లాభ–మండూక సంపద/లాభాలు, ఇందు మొత్తం ధనం పరిశీలనలు వేరు. '
      '2026-11-14 యూజర్ అందించిన V.P. Goel క్లాస్ సారాంశమే పరాశర హోరా క్యాంప్/5° భాగాలు, లాభ–మండూక స్వశక్తి/అదృష్ట సంపాదనకు మూలం. '
      'లాభ–మండూక మొదటి15° అదే రాశి; రెండో15° నుంచి11వ రాశి. ఈ గణనకు వినియోగదారు క్లాస్‌లో నిర్వచనం ఉంది. '
      'ఇందు గ్రహస్థానాలు D1వే; ప్రత్యేక సూచన లగ్నం మాత్రమే. ధనస్థాయి మూలపదాలు, ధనయోగాలు, ధనం వచ్చే రూపాలు/వ్యక్తులు/నష్టాలు విడిగా చూపాం. '
      'పాత58 నియమాలు కొత్త పూర్తి పరిశీలనలో ఉన్నాయి. మూలానికి అస్పష్టమైన CS004/005, మధ్యస్థ బలం, గోచార తేదీలను కల్పించలేదు. '
      'వేర్వేరు గ్రహాల సంబంధాలకే జంటల లెక్క; నోడ్స్ ప్రత్యేక దృష్టి/ఉచ్చరాశి కల్పించలేదు. మూలం, APP బల/భవార్థ అన్వయం వివరాల్లో స్పష్టంగా ఉన్నాయి.';
  static int labhaSign(double longitude) {
    if (!longitude.isFinite)
      throw ArgumentError('finite sidereal longitude required');
    final lon = longitude % 360, sign = (lon / 30).floor();
    return (sign + (lon % 30 < 15 ? 0 : 10)) % 12;
  }

  static VargaChartData labhaChart(AstroChartResult chart) {
    if (!TopicResults398.valid(chart))
      throw ArgumentError('Complete chart required');
    return VargaChartData(
      definition: const VargaDefinition(
        factor: 2,
        name: 'Labha-Manduka/Mihira',
        teluguName: 'లాభ–మండూక',
        domain: 'ఎంచుకున్న ప్రత్యామ్నాయ హోరా',
      ),
      ascendantSignIndex: labhaSign(chart.ascendantLongitude),
      planets: [
        for (final p in chart.planets)
          VargaPlacement(
            name: p.name,
            shortName: p.shortName,
            signIndex: labhaSign(p.longitude),
            retrograde: p.speed < 0,
          ),
      ],
    );
  }

  static VargaChartData induChart(AstroChartResult chart) {
    if (!TopicResults398.valid(chart))
      throw ArgumentError('Complete chart required');
    final d1 = VargaService.calculate(chart, 1);
    return VargaChartData(
      definition: const VargaDefinition(
        factor: 1,
        name: 'Indu reference',
        teluguName: 'ఇందు లగ్నం',
        domain: 'D1 గ్రహస్థానాలపై ప్రత్యేక లగ్న సూచిక',
      ),
      ascendantSignIndex: D2WealthEvaluationService.induLagnaSign(chart),
      planets: d1.planets,
    );
  }

  static Set<String> benefics(AstroChartResult chart) {
    final sun = chart.planets.singleWhere((p) => p.name == 'Sun').longitude,
        moon = chart.planets.singleWhere((p) => p.name == 'Moon').longitude;
    final phase = (moon - sun) % 360;
    return {
      'Mercury',
      'Jupiter',
      'Venus',
      if (phase > 0 && phase <= 180) 'Moon',
    };
  }

  static String none(String s) => s.isEmpty ? 'లేదు' : s;
  static bool relation(TopicGeometry398 v, String a, String b) =>
      a != b &&
      (v.conj(a, b) ||
          (v.aspects(a, v.sign(b)) && v.aspects(b, v.sign(a))) ||
          v.exchange(a, b));
  static TopicCheck398 rule(
    String id,
    TopicGeometry398 v,
    String evidence,
    bool? matched, {
    bool adverse = false,
    bool contextual = false,
    String? outcome,
  }) {
    final r = D2DhanaAsthiRegistry.rules.singleWhere((r) => r.id == id);
    return TopicCheck398(
      id,
      r.condition,
      evidence,
      '${D2DhanaAsthiRegistry.sourceFilename} • పేజీ ${r.sourcePage}',
      outcome ?? r.result,
      matched,
      adverse: adverse,
      contextual: contextual,
    );
  }

  static WealthReport409 evaluate(AstroChartResult chart) {
    if (!TopicResults398.valid(chart))
      return const WealthReport409(
        null,
        [],
        TopicGrade398.missing,
        'లగ్నం, తొమ్మిది గ్రహాల పూర్తి స్థానాలు కావాలి.',
        note,
        null,
      );
    final d1 = VargaService.calculate(chart, 1),
        d2 = VargaService.calculate(chart, 2),
        labha = labhaChart(chart),
        indu = induChart(chart);
    final a = TopicGeometry398(d1),
        h = TopicGeometry398(d2),
        l = TopicGeometry398(labha),
        i = TopicGeometry398(indu);
    final ben = benefics(chart), bad = TopicGeometry398.malefics;
    final l2 = a.lord(2), l11 = a.lord(11);
    final wealthLords = {
      for (final n in [2, 5, 9, 11]) a.lord(n),
    }.toList();
    final pairs = <String>[];
    for (var x = 0; x < wealthLords.length; x++)
      for (var y = x + 1; y < wealthLords.length; y++)
        if (relation(a, wealthLords[x], wealthLords[y]))
          pairs.add('${wealthLords[x]} ↔ ${wealthLords[y]}');
    final d1Checks = <TopicCheck398>[
      rule(
        'D2-DY-001',
        a,
        '2L ${a.placement(l2)}; 11L ${a.placement(l11)}; వేర్వేరు 2/5/9/11 అధిపతి సంబంధాలు: ${none(pairs.join(", "))}',
        relation(a, l2, l11) || pairs.isNotEmpty,
      ),
      TopicCheck398(
        'D2-DY-002-EXCHANGE-409',
        'D1 2వ, 11వ వేర్వేరు అధిపతుల పరివర్తన — మూలంలోని స్వతంత్ర శాఖ',
        '${a.placement(l2)}; ${a.placement(l11)}',
        source,
        'ధన నిల్వ/లాభ సంబంధానికి పరివర్తన శాఖ మద్దతు.',
        a.exchange(l2, l11),
      ),
      rule(
        'D2-CS-003',
        a,
        '${a.placement(l2)}; ఇతర శుభ సంబంధం: ${none(a.touching(a.sign(l2), ben.difference({l2})))}',
        a.house(l2) == 12 &&
            a.touching(a.sign(l2), ben.difference({l2})).isEmpty,
        adverse: true,
      ),
      rule(
        'D2-CS-002',
        a,
        '${a.placement("Moon")}; చంద్రునిపై పాప దృష్టి ${none(a.aspectSenders(a.sign("Moon"), bad))}',
        {2, 11}.contains(a.house('Moon')) &&
            a.aspectSenders(a.sign('Moon'), bad).isEmpty,
      ),
      const TopicCheck398(
        'APP-WEALTH-D1-SCOPE-409',
        'D1 2/5/9/11 ధనయోగాలు, నగదు నిల్వను వేరు చూడాలి',
        'D1 ఉమ్మడి పునాదిగా ఒక్కసారి చూపాం; మూడు హోరా/లగ్న పరిశీలనలు దానితో కలిపి అర్థం చేసుకోవాలి.',
        source,
        'నగదు, వృత్తి ఆదాయం, స్థిరాస్తి, వారసత్వం, పెట్టుబడి ఫలితాలను ఒకటిగా కలపలేదు.',
        true,
        contextual: true,
      ),
    ];
    final d1View = WealthView409(
      'd1',
      'D1 — ఉమ్మడి ధన పునాది',
      'మిగిలిన మూడు పరిశీలనలకు D1 పునాది.',
      d1,
      d1Checks,
    );
    final d2Checks = <TopicCheck398>[
      TopicCheck398(
        'APP-HORA-MAP-409',
        'పరాశర D2: 15° భాగాలు; బేసి రాశి రవి→చంద్ర, సరి రాశి చంద్ర→రవి',
        'D2 లగ్న రాశి ${h.asc + 1}; రవి హోరా: ${d2.planets.where((p) => p.signIndex == 4).map((p) => p.name).join(", ")}; చంద్ర హోరా: ${d2.planets.where((p) => p.signIndex == 3).map((p) => p.name).join(", ")}',
        'ప్రస్తుత VargaService పరాశర D2; PVR Vedic Astrology • D2 wealth chart',
        'రవి/చంద్ర హోరా స్థానాలు నమోదయ్యాయి; గ్రహాల సంఖ్య సంపద శాతం కాదు.',
        true,
        contextual: true,
      ),
      for (final e in {3: 'చంద్ర', 4: 'రవి'}.entries)
        TopicCheck398(
          'APP-CS-D1L2-${e.key}-409',
          'D1 రెండో అధిపతి $l2 ఎంచుకున్న పరాశర D2 ${e.value} హోరాలో — APP అనుబంధ అన్వయం',
          'D1: ${a.placement(l2)}; D2: ${h.placement(l2)}',
          '$source • D2-CS-004/005 భావాన్ని D1 ధనాధిపతికి అన్వయించిన APP సూచిక; పూర్తి మూల రూల్ కాదు',
          '$l2 ${e.value} హోరా స్థానం: నగదు నిల్వ పరిశీలనకు అనుబంధం మాత్రమే.',
          h.sign(l2) == e.key,
          contextual: true,
        ),
      for (final id in ['D2-CS-004', 'D2-CS-005'])
        rule(
          id,
          h,
          'మూలంలో 2వ అధిపతి అర్థం/హోరా పద్ధతి స్పష్టంకాలేదు; ఎంచుకున్న D1 2L అన్వయాన్ని APP IDతో వేరు చూపాం.',
          null,
          contextual: true,
        ),
    ];
    final relationLabha = relation(l, l.lord(2), l.lord(11));
    final eleven = labha.planets.where((p) => l.house(p.name) == 11).toList();
    final labhaChecks = <TopicCheck398>[
      TopicCheck398(
        'APP-LABHA-LB001-409',
        'ఎంచుకున్న లాభ–మండూకలో 2L/11L సంబంధం OR 11వ భావంలో కనీసం రెండు గ్రహాలు',
        '${l.placement(l.lord(2))}; ${l.placement(l.lord(11))}; సంబంధం $relationLabha; 11వ భావం ${eleven.map((p) => p.name).join(", ")}',
        '$source • D2-LB-001 + ${GoelHoraClass410.source}; APP సంబంధ నిర్వచనం',
        'ఎంచుకున్న లాభ–మండూక పద్ధతిలో లాభ సంబంధ మద్దతు; నిర్దిష్ట ఆదాయం హామీ కాదు.',
        relationLabha || eleven.length >= 2,
      ),
      TopicCheck398(
        'APP-LABHA-LB002-409',
        'ఎంచుకున్న లాభ–మండూకలో 11వ అధిపతి 12వ భావంలో',
        l.placement(l.lord(11)),
        '$source • D2-LB-002 అన్వయం; పద్ధతి స్పష్టమైన APP పరీక్ష',
        'లాభం వచ్చినా నిల్వ/ఖర్చుల నియంత్రణపై శ్రద్ధ సూచన.',
        l.house(l.lord(11)) == 12,
        adverse: true,
      ),
      const TopicCheck398(
        'LABHA-METHOD-409',
        '0°–15° అదే రాశి; 15°–30° ఆ రాశి నుంచి 11వ రాశి',
        'లాభ–మండూక/మిహిర పద్ధతి గణించాం. సాధారణ మండూకలో రెండో భాగానికి వేరే గణన ఉంటుంది; రెండింటిని కలపలేదు.',
        labhaSource,
        'యూజర్ ఇచ్చిన గోయల్ క్లాస్ ప్రకారం ఈ హోరా సంపద/లాభాలకు; పరాశర D2 దశ స్వభావానికి వేరుగా చూడాలి.',
        true,
        contextual: true,
      ),
    ];
    final occupants = indu.planets
        .where((p) => p.signIndex == i.asc)
        .map((p) => p.name)
        .toSet();
    final malOcc = occupants.intersection(bad),
        benOcc = occupants.intersection(ben);
    final malAspect = i.aspectSenders(i.asc, bad);
    final elevated = malOcc
        .where((p) => TopicGeometry398.exalts[p] == i.sign(p))
        .toList();
    final ordinary = malOcc
        .where(
          (p) =>
              TopicGeometry398.exalts.containsKey(p) &&
              TopicGeometry398.exalts[p] != i.sign(p),
        )
        .toList();
    final asc9 = a.lord(9),
        moon9 = TopicGeometry398.lords[(a.sign('Moon') + 8) % 12];
    final k1 = D2DhanaAsthiRegistry.kalaValues[asc9]!,
        k2 = D2DhanaAsthiRegistry.kalaValues[moon9]!;
    final rem = (k1 + k2) % 12, count = rem == 0 ? 12 : rem;
    final induChecks = <TopicCheck398>[
      TopicCheck398(
        'INDU-CALC-409',
        'D1 లగ్న/చంద్ర 9L కళలు; శేషం 0 అయితే 12; చంద్రుని నుంచి కలుపుకొని లెక్క',
        '$asc9=$k1; $moon9=$k2; మొత్తం ${k1 + k2}; శేషం $rem → లెక్క $count; చంద్ర రాశి ${a.sign("Moon") + 1} → ఇందు ${i.asc + 1}',
        '${D2DhanaAsthiRegistry.sourceFilename} • కళల పట్టిక/ఇందు సూత్రం',
        'ఇందు లగ్న రాశి ${i.asc + 1}; గ్రహాల స్థానాలు D1వే.',
        true,
        contextual: true,
      ),
      rule(
        'D2-IN-001',
        i,
        'ఇందులో శుభులు ${benOcc.join(", ")}; పాపులు ${malOcc.join(", ")}; పాప దృష్టి ${none(malAspect)}',
        benOcc.isNotEmpty && malOcc.isEmpty && malAspect.isEmpty,
      ),
      rule(
        'D2-IN-002',
        i,
        'ఉచ్చ ప్రధాన పాపగ్రహాలు ${elevated.join(", ")}; నోడ్స్ ఉచ్చరాశి కల్పించలేదు.',
        elevated.isNotEmpty,
      ),
      rule(
        'D2-IN-003',
        i,
        'ఉచ్చం కాని ప్రధాన పాపగ్రహాలు ${ordinary.join(", ")}; నోడ్స్ సాధారణ వర్గీకరణలో కలపలేదు.',
        ordinary.isNotEmpty,
        adverse: true,
      ),
      rule(
        'D2-IN-004',
        i,
        'పరాశరి పాప దృష్టి: ${none(malAspect)}; నోడ్స్ ప్రత్యేక దృష్టులు కల్పించలేదు.',
        malAspect.isNotEmpty,
        adverse: true,
      ),
      for (final e in {
        'D2-IN-007': {1, 2, 4, 10, 11},
        'D2-IN-008': {3, 6, 8, 12},
      }.entries)
        rule(
          e.key,
          i,
          'సంబంధిత స్థానాల్లో గ్రహాలు ${indu.planets.where((p) => e.value.contains(i.house(p.name))).map((p) => "${p.name} (${i.house(p.name)}వ భావం)").join(", ")}',
          indu.planets.any((p) => e.value.contains(i.house(p.name))),
          contextual: true,
          outcome:
              'ఈ స్థానాల్లోని గ్రహదశల ఫలానికి జన్మస్థితి అనుబంధం; నడుస్తున్న దశ/తేదీ ఇక్కడ నిర్ణయించలేదు.',
        ),
      rule(
        'D2-IN-011',
        i,
        i.placement(i.lord(1)),
        true,
        contextual: true,
        outcome:
            'ఇందు అధిపతి స్థానం నమోదైంది; దాని నుంచే నిర్దిష్ట వృత్తి/ఆస్తి రకాన్ని తేల్చలేదు.',
      ),
    ];
    final views = [
      WealthView409(
        'd2',
        'D2 — పరాశర హోరా',
        'దశలో శ్రమ/సౌమ్యత; క్యాంప్, హోరా భాగం వేరు పరిశీలన.',
        d2,
        d2Checks,
      ),
      WealthView409(
        'labha',
        'లాభ–మండూక హోరా',
        'మిహిర / JHora లాభ–మండూక. మీ ధన రూల్స్ అన్వయం APP IDతో.',
        labha,
        labhaChecks,
      ),
      WealthView409(
        'indu',
        'ఇందు లగ్నం',
        'D1 గ్రహాలు; ఇందు లగ్నం కొత్త సూచన బిందువు మాత్రమే.',
        indu,
        induChecks,
      ),
    ];
    final all = [...d1Checks, ...labhaChecks, ...induChecks];
    final detail = WealthAnalysis410.evaluate(
      chart,
      d1: d1,
      indu: indu,
      labha: labha,
      benefics: ben,
    );
    d2Checks.addAll(GoelHoraClass410.checks(chart));
    labhaChecks.addAll(
      detail.sections.singleWhere((s) => s.key == 'goellabha').checks,
    );
    for (final row
        in detail.sections.singleWhere((s) => s.key == 'indu').checks) {
      if (!induChecks.any((c) => c.id == row.id)) induChecks.add(row);
    }
    final grade = TopicResults398.grade([
      ...d1Checks,
      ...labhaChecks,
      ...induChecks,
    ]);
    final forms = DeityGuidance405.deities[h.lord(1)]!;
    final guide = ClientGuidanceData406(
      topicId: id,
      title: 'ధనం — ఆరాధన / ఆచరణ',
      factor: 2,
      primary: forms.first,
      reason:
          'పరాశర D2 లగ్నాధిపతి ${h.lord(1)}; ${h.placement(h.lord(1))}. PVR §34.5/Table 78 దేవత సంబంధం. మొదటి స్వరూపం చూపడం APP ఎంపిక; ధనం ఖాయమనే హామీ కాదు.',
      alternative:
          'లక్ష్మీ/కమలాత్మిక ప్రార్థన ధన సందర్భంలోని సాధారణ సంప్రదాయ ప్రత్యామ్నాయం; జాతకం నుంచి ఖరారైన ఇష్టదేవత అని కాదు.',
      practice:
          'కుటుంబ/గురు సంప్రదాయం ప్రకారం ఒక స్వరూపం, సరళ ప్రార్థన/నామస్మరణ. ప్రత్యేక బీజమంత్ర దీక్షకు గురు మార్గదర్శకత్వం. ఖరీదైన పూజ/జపసంఖ్య/గడువు తప్పనిసరి కాదు.',
      action:
          'ఆదాయం, అవసరమైన ఖర్చులు, పొదుపు, అప్పుల చెల్లింపుల లెక్క ఉంచండి. బాధ్యతాయుత రుణ వినియోగం, ఆర్థిక ప్రణాళిక పాటించండి. పెద్ద ఆర్థిక నిర్ణయాలకు అర్హతగల నిపుణుల సలహా తీసుకోండి.',
      limit:
          'జాతకం పెట్టుబడి/లాభ హామీ కాదు. కోటీశ్వర స్థాయి, ఖచ్చిత మొత్తం, లాభ శాతం లేదా అప్పు తీరే తేదీ ప్రకటించలేదు.',
      evidence: [
        for (final c in all)
          if (c.matched == true && !c.contextual) '${c.id}: ${c.evidence}',
      ],
      sources: [
        source,
        GoelHoraClass410.source,
        DeityGuidance405.source,
        'కమలాత్మిక సంప్రదాయం • https://www.drikpanchang.com/hindu-goddesses/parvati/mahavidya/kamala/goddess-kamala.html',
        rbi,
      ],
    );
    return WealthReport409(
      d1View,
      views,
      grade,
      detail.summary,
      note,
      guide,
      detail: detail,
    );
  }
}
