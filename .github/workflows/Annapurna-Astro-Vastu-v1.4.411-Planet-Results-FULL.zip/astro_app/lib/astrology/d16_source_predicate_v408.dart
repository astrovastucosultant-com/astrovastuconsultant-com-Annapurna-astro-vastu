/// Shared exact source predicate for catalog and topic result.
class D16SourcePredicate408 {
  static const malefics = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};
  static bool fourthConjunction(Set<String> fourth) =>
      fourth.any((p) => p == 'Mars' || p == 'Rahu') &&
      fourth.intersection(malefics).length >= 2;
}
