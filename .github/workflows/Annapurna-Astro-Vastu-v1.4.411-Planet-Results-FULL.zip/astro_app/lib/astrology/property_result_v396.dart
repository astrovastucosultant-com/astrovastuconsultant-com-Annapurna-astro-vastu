import 'astro_models.dart';
import 'varga_service.dart';
import 'd2_dhana_asthi_registry.dart';
import 'd2_wealth_evaluation_service.dart';
import 'd12_kl_service.dart';

enum PropertyGrade396 { good, bad, medium, missing }

extension PropertyGradeText396 on PropertyGrade396 {
  String get label => switch (this) {
    PropertyGrade396.good => 'మంచి',
    PropertyGrade396.bad => 'చెడు',
    PropertyGrade396.medium => 'మధ్యస్థం',
    PropertyGrade396.missing => 'గణనకు సమాచారం లేదు',
  };
}

class PropertyCheck396 {
  final String id, title, condition, evidence, source, outcome;
  final bool? matched;
  final bool adverse, contextual, conditional;
  const PropertyCheck396({
    required this.id,
    required this.title,
    required this.condition,
    required this.evidence,
    required this.source,
    required this.outcome,
    required this.matched,
    this.adverse = false,
    this.contextual = false,
    this.conditional = false,
  });
}

class PropertyStage396 {
  final int factor;
  final List<PropertyCheck396> checks;
  const PropertyStage396(this.factor, this.checks);
  PropertyGrade396 get grade => PropertyResult396.grade(checks);
  String get result {
    final hits = checks.where((c) => c.matched == true && !c.contextual);
    final good = hits.where((c) => !c.adverse).take(1),
        bad = hits.where((c) => c.adverse).take(1);
    return [
      'ఆస్తి పరిశీలన — ${grade.label}',
      if (factor == 12) 'KL పద్ధతికి లోబడి అనుబంధ సూచన మాత్రమే.',
      if (good.isNotEmpty) 'మద్దతు: ${good.first.outcome}',
      if (bad.isNotEmpty) 'జాగ్రత్త: ${bad.first.outcome}',
      if (hits.isEmpty)
        'ఈ పరీక్షల్లో స్పష్టమైన ఏకపక్ష మద్దతు లేదు; ఆస్తి లేదనే అర్థం కాదు.',
    ].join('\n');
  }
}

class PropertyAspect396 {
  final String title;
  final PropertyGrade396 grade;
  final String text;
  const PropertyAspect396(this.title, this.grade, this.text);
}

class PropertyReport396 {
  final List<PropertyStage396> stages;
  final List<PropertyAspect396> aspects;
  final PropertyGrade396 grade;
  final String note;
  const PropertyReport396(this.stages, this.aspects, this.grade, this.note);
  String get conclusion => switch (grade) {
    PropertyGrade396.good =>
      'స్థిరాస్తి / సొంత ఇల్లు సమకూరేందుకు మంచి జన్మస్థితి మద్దతు ఉంది.',
    PropertyGrade396.bad =>
      'స్థిరాస్తి విషయంలో ఆటంకం, ఆలస్యం లేదా వివాద సూచనలు ప్రధానంగా ఉన్నాయి. ఆస్తి ఎప్పటికీ రాదనే తీర్పు కాదు.',
    PropertyGrade396.medium =>
      'స్థిరాస్తికి మద్దతు, ఆటంకం రెండూ ఉన్నాయి లేదా ప్రధాన షరతులు ఏకపక్షంగా సరిపోలలేదు. అంశాలవారీ ఫలితాలు కింద ఉన్నాయి.',
    PropertyGrade396.missing =>
      'లగ్నం లేదా అవసరమైన గ్రహస్థితులు పూర్తిగా లేవు; వాటితో మళ్లీ గణించాలి.',
  };
}

class PropertyResult396 {
  static const policy =
      'USER-PROPERTY-REVIEW-396: D1 ఆస్తి మూల సూచనలు, D4 ధృవీకరణ వేరు. ఒకే అంశంలో మంచి/చెడు రెండూ ఉంటే లేదా రెండూ లేకపోతే మధ్యస్థం. D1 ప్రధాన స్థిరాస్తి గ్రేడ్‌కు విరుద్ధ D4 గ్రేడ్ ఉంటే సమగ్ర ఫలితం మధ్యస్థం. D12 KL సూచనలు అనుబంధం మాత్రమే; వాటిని D1 ఆస్తి రూల్ హిట్‌గా లేదా ఆస్తి హక్కు నిర్ధారణగా కలపలేదు. శాతం/ఓట్ల మొత్తం ఉపయోగించలేదు. ఇది యాప్ సమగ్ర నిర్ణయ విధానం; గ్రంథ శ్లోకం కాదు. “సొంత ఇల్లు” అంటే స్వార్జితమని లేదా ఇప్పటికే నమోదైన ఆస్తి అని ఊహించలేదు.';
  static PropertyGrade396 grade(Iterable<PropertyCheck396> checks) {
    final hits = checks.where((c) => c.matched == true && !c.contextual);
    final positive = hits.any((c) => !c.adverse),
        negative = hits.any((c) => c.adverse);
    return positive == negative
        ? PropertyGrade396.medium
        : negative
        ? PropertyGrade396.bad
        : PropertyGrade396.good;
  }

  static PropertyGrade396 confirm(PropertyGrade396 d1, PropertyGrade396 d4) {
    if (d1 == PropertyGrade396.missing || d4 == PropertyGrade396.missing)
      return PropertyGrade396.missing;
    if ((d1 == PropertyGrade396.good && d4 == PropertyGrade396.bad) ||
        (d1 == PropertyGrade396.bad && d4 == PropertyGrade396.good))
      return PropertyGrade396.medium;
    return d1;
  }

  static PropertyReport396 evaluate(AstroChartResult chart) {
    const names = {
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    };
    if (!chart.ascendantLongitude.isFinite ||
        !chart.planets.map((p) => p.name).toSet().containsAll(names) ||
        chart.planets.any((p) => !p.longitude.isFinite))
      return const PropertyReport396([], [], PropertyGrade396.missing, policy);
    final matched = {
      for (final hit in D2WealthEvaluationService.evaluate(chart))
        hit.ruleId: hit,
    };
    const caution = {
      'D2-PR-005',
      'D2-PR-006',
      'D2-PR-009',
      'D2-PR-010',
      'D2-IH-002',
      'D2-IH-004',
    };
    final d1 = VargaService.calculate(chart, 1),
        d4 = VargaService.calculate(chart, 4);
    const rulers = [
      'Mars',
      'Venus',
      'Mercury',
      'Moon',
      'Sun',
      'Mercury',
      'Venus',
      'Mars',
      'Jupiter',
      'Saturn',
      'Saturn',
      'Jupiter',
    ];
    String placement(VargaChartData v, String name) {
      final sign = v.planets.singleWhere((p) => p.name == name).signIndex;
      return '$name: ${D12KlService.signNames[sign]}, ${(sign - v.ascendantSignIndex + 12) % 12 + 1}వ భావం';
    }

    final l4 = rulers[(d1.ascendantSignIndex + 3) % 12],
        l9 = rulers[(d1.ascendantSignIndex + 8) % 12];
    final d4l4 = rulers[(d4.ascendantSignIndex + 3) % 12];
    final indu = D2WealthEvaluationService.induLagnaSign(chart);
    final d1Checks = <PropertyCheck396>[], d4Checks = <PropertyCheck396>[];
    for (final rule in D2DhanaAsthiRegistry.rules.where(
      (r) => r.groupCode == 'PR' || r.groupCode == 'IH' || r.id == 'D2-OT-004',
    )) {
      final hit = matched[rule.id];
      final timing = rule.id == 'D2-PR-011';
      final d4Rule = rule.sourceChart.startsWith('D4');
      final audit = d4Rule
          ? 'D4 4వ అధిపతి: ${placement(d4, d4l4)}.'
          : 'D1 4వ అధిపతి: ${placement(d1, l4)}; 9వ అధిపతి: ${placement(d1, l9)}; ${placement(d1, "Moon")}; ఇందు లగ్నం ${D12KlService.signNames[indu]}.';
      final check = PropertyCheck396(
        id: rule.id,
        title: rule.name,
        condition: rule.condition,
        evidence: timing
            ? 'ఈ నివేదిక జన్మస్థితి ఫలితం. కొనుగోలు కాలానికి 4/9/11 అధిపతుల నడిచే దశ, D4 నిర్ధారణను విడిగా గణించాలి.'
            : hit == null
            ? '$audit\n${D2WealthEvaluationService.auditReason(rule.id, matched: false)}'
            : '$audit\n${hit.evidence}',
        source:
            '${D2DhanaAsthiRegistry.sourceFilename} • పేజీ ${rule.sourcePage} • ${rule.sourceChart}',
        outcome: caution.contains(rule.id)
            ? _cautionOutcome(rule.id, rule.result)
            : rule.result,
        matched: timing ? null : hit != null,
        adverse: caution.contains(rule.id),
        contextual: timing || rule.id == 'D2-OT-004',
      );
      (d4Rule ? d4Checks : d1Checks).add(check);
    }
    final kl = D12KlService.analyze(chart, VargaService.calculate(chart, 12));
    final d12Checks = [
      for (final c in kl.checks.where(
        (c) => c.ruleId == 'D12-KL-EST-04' || c.ruleId == 'D12-KL-EST-07',
      ))
        PropertyCheck396(
          id: c.ruleId,
          title: c.title,
          condition: c.condition,
          evidence:
              '${c.evidence}\nKL=${D12KlService.signNames[kl.klSign]}; D12 లగ్నం=${D12KlService.signNames[kl.d12Sign]}; AK=${kl.atmakaraka}. KLను AK నవాంశ రాశిగా తీసుకునే యాప్ పద్ధతి. D12 లగ్నాన్ని KLగా మార్చలేదు.${kl.degreeTie ? " కారక డిగ్రీ సమానత్వం వల్ల ఈ పరీక్షను మ్యాచ్‌గా చూపలేదు." : ""}',
          source:
              'సరళ జ్యోతిష్యం VII, అధ్యాయం 9 • ముద్రిత పేజీలు ${c.printedPage}; KL నిర్మాణం ఈ యాప్‌లో స్పష్టంగా ఎంచుకున్న పద్ధతి.',
          outcome: c.caution
              ? 'ఎంచుకున్న KL పద్ధతిలో వారసత్వ వినియోగంలో ఆటంక సూచన.'
              : 'ఎంచుకున్న KL పద్ధతిలో వారసత్వ స్వీకరణకు సంబంధ సూచన.',
          matched: c.matched,
          adverse: c.caution,
          conditional: true,
        ),
    ];
    final stages = [
      PropertyStage396(1, List.unmodifiable(d1Checks)),
      PropertyStage396(4, List.unmodifiable(d4Checks)),
      PropertyStage396(12, List.unmodifiable(d12Checks)),
    ];
    PropertyGrade396 selected(List<String> ids) =>
        grade(d1Checks.where((c) => ids.contains(c.id)));
    final property = confirm(
      selected([
        'D2-PR-001',
        'D2-PR-002',
        'D2-PR-003',
        'D2-PR-004',
        'D2-PR-008',
        'D2-PR-005',
        'D2-PR-009',
        'D2-PR-010',
      ]),
      stages[1].grade,
    );
    PropertyAspect396 aspect(
      String title,
      List<String> ids, {
      bool confirmation = false,
    }) {
      final checks = d1Checks.where((c) => ids.contains(c.id)).toList();
      var g = grade(checks);
      if (confirmation) g = confirm(g, stages[1].grade);
      final hits = checks.where((c) => c.matched == true && !c.contextual);
      return PropertyAspect396(
        title,
        g,
        hits.isEmpty
            ? 'ఈ ప్రత్యేక మూల షరతులు సరిపోలలేదు; అంశం లేదనే తీర్పు కాదు.'
            : hits.map((c) => c.outcome).toSet().join(' '),
      );
    }

    final aspects = [
      PropertyAspect396(
        'సొంత ఇల్లు / స్థిరాస్తి',
        property,
        'D1 మూల సూచనలకు D4 ధృవీకరణను కలిపిన సమగ్ర గ్రేడ్.',
      ),
      aspect('భూమి', [
        'D2-PR-003',
        'D2-PR-005',
        'D2-PR-010',
      ], confirmation: true),
      aspect('తల్లి వైపు ఆస్తి', ['D2-IH-001', 'D2-IH-002']),
      aspect('తండ్రి వైపు ఆస్తి', ['D2-IH-003', 'D2-IH-004']),
      aspect('వారసత్వ ధనం / ఇల్లు (D1)', [
        'D2-IH-005',
        'D2-IH-006',
        'D2-IH-002',
        'D2-IH-004',
      ]),
    ];
    return PropertyReport396(
      List.unmodifiable(stages),
      List.unmodifiable(aspects),
      property,
      '$policy\nబలాన్ని స్వ/ఉచ్చం, కేంద్ర/త్రికోణ స్థితి వంటి ప్రస్తుత D2/D4 ఇంజిన్ నిర్వచనాలతో పరీక్షించాం; సంపూర్ణ షడ్బలం కాదు. శుభ/పాప దృష్టి పద్ధతులు రూల్ పరిశీలనలో ఉన్నాయి. Cyclical D12ను గణించినట్లు ప్రకటించలేదు. ఆస్తి మొత్తం, హక్కు లేదా కొనుగోలు తేదీని ఈ గ్రేడ్ చెప్పదు.',
    );
  }

  static String _cautionOutcome(String id, String source) => switch (id) {
    'D2-PR-005' =>
      'స్థిరాస్తి సమకూరటంలో ప్రతికూల సూచన; శాశ్వత నిరాకరణగా భావించకూడదు.',
    'D2-PR-009' => 'ఆస్తి / ఇంటికి దూరమయ్యే లేదా మార్పు సూచన.',
    _ => source,
  };
}
