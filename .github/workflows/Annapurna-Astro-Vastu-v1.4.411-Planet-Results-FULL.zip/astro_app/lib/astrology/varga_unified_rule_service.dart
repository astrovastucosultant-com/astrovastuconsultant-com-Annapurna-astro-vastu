import 'dart:convert';
import 'd16_source_predicate_v408.dart';

import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'varga_service.dart';

/// Status reflects rule-condition verification, not certainty of an event.
enum UnifiedVargaRuleStatus { matched, notMatched, pending, method }

/// Match truth and result nature are separate: a matched adverse rule is pink.
enum UnifiedVargaRuleTone { favorable, adverse, neutral }

class UnifiedVargaRule {
  final String id;
  final String group;
  final String groupTitle;
  final String topic;
  final String condition;
  final String outcome;
  final String source;
  final String evidence;
  final UnifiedVargaRuleStatus status;
  final UnifiedVargaRuleTone tone;

  const UnifiedVargaRule({
    required this.id,
    required this.group,
    required this.groupTitle,
    required this.topic,
    required this.condition,
    required this.outcome,
    required this.source,
    required this.evidence,
    required this.status,
    required this.tone,
  });
}

/// User-provided 42-page varga IF–THEN catalog (247 source rules + 8 strength
/// rules). Only reproducible conditions are marked matched. Qualitative,
/// incomplete and cross-chart rules remain pending/method, without fake green.
class VargaUnifiedRuleService {
  static const asset = 'assets/varga/mallikarjuna_255_rules.json';
  static const _benefics = <String>{'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = <String>{'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};
  static const _lords = <String>[
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];
  static const _exaltSigns = <String, int>{
    'Sun': 0,
    'Moon': 1,
    'Mars': 9,
    'Mercury': 5,
    'Jupiter': 3,
    'Venus': 11,
    'Saturn': 6,
  };
  static const _names = <String>[
    'మేషం',
    'వృషభం',
    'మిథునం',
    'కర్కాటకం',
    'సింహం',
    'కన్య',
    'తుల',
    'వృశ్చికం',
    'ధనుస్సు',
    'మకరం',
    'కుంభం',
    'మీనం',
  ];

  static Future<List<UnifiedVargaRule>> evaluate(AstroChartResult chart) async {
    final data =
        jsonDecode(await rootBundle.loadString(asset)) as Map<String, dynamic>;
    final rawRules = data['rules'] as List<dynamic>;
    final charts = <int, VargaChartData>{};
    for (final def in VargaService.definitions) {
      charts[def.factor] = VargaService.calculate(chart, def.factor);
    }
    final output = <UnifiedVargaRule>[];
    for (final item in rawRules) {
      final row = item as Map<String, dynamic>;
      final id = row['id'] as String;
      final group = row['group'] as String;
      final mode = row['mode'] as String? ?? '';
      final sourceInfo = row['source'] as Map<String, dynamic>?;
      final pages =
          (sourceInfo?['pages'] as List<dynamic>?)
              ?.map((p) => p.toString())
              .join(', ') ??
          '—';
      final check = _verify(id, charts, chart);
      final status =
          (group == 'STRENGTH' ||
              const {'VARGA-D7-002', 'VARGA-D7-003'}.contains(id) ||
              (mode == 'workflow' && check.$1 == null))
          ? UnifiedVargaRuleStatus.method
          : check.$1 == true
          ? UnifiedVargaRuleStatus.matched
          : check.$1 == false
          ? UnifiedVargaRuleStatus.notMatched
          : UnifiedVargaRuleStatus.pending;
      output.add(
        UnifiedVargaRule(
          id: id,
          group: group,
          groupTitle: (row['group_title'] as String?) ?? group,
          topic: (row['topic'] as String?) ?? group,
          condition: _stripPrefix((row['IF'] as String?) ?? '', 'IF'),
          outcome: id == 'VARGA-D7-007'
              ? 'పంచమ–వ్యయ సంబంధ సంప్రదాయ సూచన; దత్తత నిర్ణయం లేదా సంఘటనను ఒంటరిగా నిర్ధారించదు.'
              : _stripPrefix((row['THEN'] as String?) ?? '', 'THEN'),
          source:
              '${sourceInfo?['document'] ?? 'Mallikarjuna PDF'} · పేజీ $pages',
          evidence: check.$2,
          status: status,
          tone: _toneFor(id),
        ),
      );
    }
    return output;
  }

  /// Explicit source-outcome classification, never derived from a matched flag.
  /// Source-only, profession-type, marriage-type and mixed rules stay neutral.
  static UnifiedVargaRuleTone _toneFor(String id) {
    const adverse = <String>{
      'VARGA-D2-005',
      'VARGA-D2-006',
      'VARGA-D7-005',
      'VARGA-D12-008',
      'VARGA-D12-012',
      'VARGA-D16-005',
      'VARGA-D30-003',
    };
    const favorable = <String>{
      'VARGA-D2-001',
      'VARGA-D2-002',
      'VARGA-D2-003',
      'VARGA-D2-004',
      'VARGA-D3-003',
      'VARGA-D7-004',
      'VARGA-D10-006',
      'VARGA-D12-005',
      'VARGA-D12-006',
      'VARGA-D12-007',
      'VARGA-D27-002',
      'VARGA-D45-002',
      'VARGA-CROSS-016',
      'VARGA-CROSS-017',
      'VARGA-CROSS-019',
      'VARGA-CROSS-021',
      'VARGA-CROSS-022',
    };
    if (adverse.contains(id)) return UnifiedVargaRuleTone.adverse;
    if (favorable.contains(id)) return UnifiedVargaRuleTone.favorable;
    return UnifiedVargaRuleTone.neutral;
  }

  static String _stripPrefix(String value, String prefix) =>
      value.replaceFirst(RegExp('^$prefix\\s*:?\\s*'), '').trim();

  static bool _isSupport(Map<int, VargaChartData> charts, int factor) =>
      charts.containsKey(factor);

  /// Returns (condition verified yes/no/unknown, chart evidence).
  /// Unknown is deliberately NOT equivalent to false.
  static (bool?, String) _verify(
    String id,
    Map<int, VargaChartData> charts,
    AstroChartResult natal,
  ) {
    if (id == 'VARGA-STRENGTH-001') {
      final planetCount = natal.planets
          .where(
            (p) =>
                p.longitude.isFinite &&
                p.degreesInSign >= 0 &&
                p.degreesInSign < 30,
          )
          .length;
      if (planetCount == 0) return (null, 'జన్మగ్రహ డిగ్రీలు అందుబాటులో లేవు.');
      return (
        true,
        'గ్రహాల రాశి-అంతర్గత డిగ్రీలు లభించాయి: $planetCount. '
            'కస్టమ్ సూచిక = (30 − రాశిలోని డిగ్రీ) / 30 × 100. '
            'ఇది సాపేక్ష పోలిక మాత్రమే; సంఘటన సంభావ్యత కాదు.',
      );
    }
    if (id == 'VARGA-STRENGTH-002') {
      if (natal.planets.length < 2)
        return (null, 'రెండు గ్రహాల డిగ్రీలు కావాలి.');
      final ordered = [...natal.planets]
        ..sort((a, b) => a.degreesInSign.compareTo(b.degreesInSign));
      return (
        true,
        'తక్కువ డిగ్రీ: ${ordered.first.name} ${ordered.first.degreesInSign.toStringAsFixed(2)}°; '
            'ఎక్కువ డిగ్రీ: ${ordered.last.name} ${ordered.last.degreesInSign.toStringAsFixed(2)}°. '
            'ఇది వినియోగదారు నిర్దేశించిన డిగ్రీ-బల పోలిక మాత్రమే.',
      );
    }

    // Explicit, fully calculable user-supplied CROSS rules. Workflow-only
    // rows remain unverified; never promote a chart-order instruction to a hit.
    if (id == 'VARGA-CROSS-016' ||
        id == 'VARGA-CROSS-017' ||
        id == 'VARGA-CROSS-019' ||
        id == 'VARGA-CROSS-021' ||
        id == 'VARGA-CROSS-022' ||
        id == 'VARGA-CROSS-028') {
      const signRulers = <String>[
        'Mars',
        'Venus',
        'Mercury',
        'Moon',
        'Sun',
        'Mercury',
        'Venus',
        'Mars',
        'Jupiter',
        'Saturn',
        'Saturn',
        'Jupiter',
      ];
      (bool?, String) fiveNine(int d, {bool exchangeOnly = false}) {
        final c = charts[d];
        if (c == null) return (null, 'D$d చక్రం అందుబాటులో లేదు.');
        final p = {for (final x in c.planets) x.name: x.signIndex};
        final l5 = signRulers[(c.ascendantSignIndex + 4) % 12];
        final l9 = signRulers[(c.ascendantSignIndex + 8) % 12];
        final h5 = p[l5] == null
            ? null
            : (p[l5]! - c.ascendantSignIndex + 12) % 12 + 1;
        final h9 = p[l9] == null
            ? null
            : (p[l9]! - c.ascendantSignIndex + 12) % 12 + 1;
        final evidence =
            'D$d: 5L $l5 = ${h5 ?? 'తెలియదు'} భావం; '
            '9L $l9 = ${h9 ?? 'తెలియదు'} భావం.';
        if (h5 == null || h9 == null) return (null, evidence);
        return (
          exchangeOnly ? (h5 == 9 && h9 == 5) : (h5 == 9 || h9 == 5),
          evidence,
        );
      }

      if (id == 'VARGA-CROSS-016') return fiveNine(1);
      if (id == 'VARGA-CROSS-017') return fiveNine(1, exchangeOnly: true);
      if (id == 'VARGA-CROSS-019') {
        final one = fiveNine(1);
        final nine = fiveNine(9);
        return (
          one.$1 == null || nine.$1 == null ? null : one.$1! && nine.$1!,
          '${one.$2} ${nine.$2}',
        );
      }
      if (id == 'VARGA-CROSS-022') {
        final d1 = charts[1];
        if (d1 == null) return (null, 'D1 చక్రం అందుబాటులో లేదు.');
        final positions = {for (final p in d1.planets) p.name: p.signIndex};
        final lord10 = signRulers[(d1.ascendantSignIndex + 9) % 12];
        final p10 = positions[lord10];
        if (p10 == null) return (null, 'D1 10వ భావాధిపతి స్థానం తెలియదు.');
        final h10 = (p10 - d1.ascendantSignIndex + 12) % 12 + 1;
        const exalt = <String, int>{
          'Sun': 0,
          'Moon': 1,
          'Mars': 9,
          'Mercury': 5,
          'Jupiter': 3,
          'Venus': 11,
          'Saturn': 6,
        };
        final strong10 =
            <int>{1, 4, 7, 10}.contains(h10) && exalt[lord10] == p10;
        final yoga59 = fiveNine(1);
        final evidence =
            '${yoga59.$2} D1 10L $lord10 = $h10 భావం '
            '(${_names[p10]}), ఉచ్చ + కేంద్రం = $strong10.';
        // A required AND clause is demonstrably false; other forms of 5–9
        // raja yoga are not silently treated as absent when not evaluated.
        if (!strong10) return (false, evidence);
        if (yoga59.$1 == true) return (true, evidence);
        return (null, '$evidence ఇతర 5–9 రాజయోగ రూపాలు ఇంకా పరీక్షించాలి.');
      }
      if (id == 'VARGA-CROSS-028') {
        final d10 = charts[10];
        if (d10 == null) return (null, 'D10 చక్రం అందుబాటులో లేదు.');
        final positions = {for (final p in d10.planets) p.name: p.signIndex};
        final l10 = signRulers[(d10.ascendantSignIndex + 9) % 12];
        final s10 = positions[l10];
        if (s10 == null) return (null, 'D10 10వ అధిపతి గ్రహస్థితి లేదు.');
        final inMercuryVenusSign = <int>{1, 2, 5, 6}.contains(s10);
        final conjoint = <String>[
          'Mercury',
          'Venus',
        ].any((other) => other != l10 && positions[other] == s10);
        return (
          inMercuryVenusSign || conjoint,
          'D10 10L $l10 ${_names[s10]}; బుధ/శుక్ర రాశి: '
              '$inMercuryVenusSign; ఇతర గ్రహంతో నిజమైన యుతి: $conjoint. '
              'గ్రహం తనతో తానే యుతి అయినట్లు లెక్కించలేదు.',
        );
      }
      final d10 = charts[10];
      if (d10 == null) return (null, 'D10 చక్రం అందుబాటులో లేదు.');
      final sunSign = [
        for (final p in d10.planets)
          if (p.name == 'Sun') p.signIndex,
      ];
      if (sunSign.isEmpty) return (null, 'D10లో సూర్యస్థానం తెలియదు.');
      return (
        sunSign.first == 0 || sunSign.first == 4,
        'D10 సూర్యుడు ${_names[sunSign.first]}; ఉచ్చ = మేషం, స్వరాశి = సింహం. '
            'ఇది ఉన్నత పదవికి అదనపు ఆధారం మాత్రమే.',
      );
    }

    final pieces = id.split('-');
    if (pieces.length < 3)
      return (null, 'మూల నియమం ఉంది; ఆటోమేటిక్ పరీక్ష నిర్వచించలేదు.');
    final factor = int.tryParse(pieces[1].replaceFirst('D', ''));
    if (factor == null) {
      return (
        null,
        'ఈ నియమం బహువర్గ/దశ/గోచార/షడ్వర్గ సమగ్ర పరిశీలన. '
            'అన్ని IF ఉపషరతులకు స్వతంత్ర గణనలు అందుబాటులో లేవు.',
      );
    }
    if (!_isSupport(charts, factor)) {
      return (
        null,
        'D$factor గణన ప్రస్తుత VargaServiceలో లేదు. '
            'నియమం PDFలో భద్రపరచబడింది; చార్ట్‌ను ఊహించి గ్రీన్ చూపడం లేదు.',
      );
    }
    final chart = charts[factor]!;
    final asc = chart.ascendantSignIndex;
    final placements = <String, int>{
      for (final p in chart.planets) p.name: p.signIndex,
    };
    int? at(String name) => placements[name];
    int house(int sign) => (sign - asc + 12) % 12 + 1;
    int? houseOf(String name) {
      final sign = at(name);
      return sign == null ? null : house(sign);
    }

    String signName(int sign) => _names[sign % 12];
    String houseText(String name) {
      final s = at(name);
      return s == null
          ? '$name స్థానం లేదు'
          : '$name ${signName(s)} (${house(s)}వ భావం)';
    }

    int signOfHouse(int n) => (asc + n - 1) % 12;
    String lord(int h) => _lords[signOfHouse(h)];
    int? lordHouse(int h) => houseOf(lord(h));
    bool occupant(String name, int h) => houseOf(name) == h;
    bool hasAny(int h, Set<String> names) =>
        names.any((name) => occupant(name, h));
    bool sameSign(String p, String q) => at(p) != null && at(p) == at(q);
    bool kendraTrikona(int? h) =>
        h != null && const <int>{1, 4, 5, 7, 9, 10}.contains(h);
    bool dusthana(int? h) => h != null && const <int>{6, 8, 12}.contains(h);
    bool grahaAspects(String p, int? targetSign) {
      if (targetSign == null) return false;
      final s = at(p);
      // The classical Parashari planet-specific graha-drishthi option. This
      // is not a Jaimini sign aspect; unspecified node aspects remain unknown.
      if (s == null || p == 'Rahu' || p == 'Ketu') return false;
      final offset = (targetSign - s + 12) % 12 + 1;
      if (offset == 7) return true;
      if (p == 'Mars' && (offset == 4 || offset == 8)) return true;
      if (p == 'Jupiter' && (offset == 5 || offset == 9)) return true;
      if (p == 'Saturn' && (offset == 3 || offset == 10)) return true;
      return false;
    }

    bool exchange(String p, String q) =>
        p != q &&
        at(p) != null &&
        at(q) != null &&
        _lords[at(p)!] == q &&
        _lords[at(q)!] == p;
    // A single planet is NOT conjunct or in aspect with itself. Check
    // conjunction, planetary aspect and explicit two-lord exchange only.
    bool relation(String p, String q) =>
        p != q &&
        (sameSign(p, q) ||
            grahaAspects(p, at(q)) ||
            grahaAspects(q, at(p)) ||
            exchange(p, q));
    bool receivesFrom(String target, Set<String> senders) =>
        at(target) != null && senders.any((p) => grahaAspects(p, at(target)));
    (bool?, String) checked(bool predicate, String evidence) =>
        (predicate, evidence);
    (bool?, String) possible(bool predicate, String evidence) => predicate
        ? (true, evidence)
        : (
            null,
            '$evidence ఇతర ప్రత్యామ్నాయ సంబంధాలు/బల పరీక్షలు ఇంకా పూర్తికాలేదు.',
          );

    switch (id) {
      // Source IF conditions that can be checked entirely using D5/D6/D8
      // placements. Preserve their original IDs, wording and source pages.
      case 'VARGA-D5-003':
        return checked(
          relation('Jupiter', 'Sun'),
          'D5 ${houseText('Jupiter')}; ${houseText('Sun')}; '
          'గురు–సూర్య యుతి లేదా పరాశరి దృష్టి.',
        );
      case 'VARGA-D6-002':
        return checked(
          occupant('Mars', 6),
          'D6 ${houseText('Mars')}; 6వ భావంలో కుజుడు ఉన్నాడా?',
        );
      case 'VARGA-D6-003':
        return checked(
          occupant('Rahu', 6),
          'D6 ${houseText('Rahu')}; 6వ భావంలో రాహువు ఉన్నాడా?',
        );
      case 'VARGA-D6-006':
        return checked(
          occupant('Mars', 6) && occupant('Rahu', 6),
          'D6 ${houseText('Mars')}; ${houseText('Rahu')}; '
          'ఇద్దరూ 6వ భావంలో యుతిగా ఉన్నారా?',
        );
      case 'VARGA-D8-002':
        {
          // The complete literal source IF is simply 8th-house occupation.
          // It does not require an invented strength or transit threshold.
          final occupants = placements.entries
              .where((entry) => house(entry.value) == 8)
              .map((entry) => entry.key)
              .toList(growable: false);
          return checked(
            occupants.isNotEmpty,
            'D8 8వ భావంలో ఉన్న గ్రహాలు: '
            '${occupants.isEmpty ? 'లేవు' : occupants.join(', ')}.',
          );
        }
      case 'VARGA-D8-003':
        return checked(
          occupant('Rahu', 8) || occupant('Ketu', 8),
          'D8 ${houseText('Rahu')}; ${houseText('Ketu')}; '
          '8వ భావంలో రాహు/కేతు స్థానం.',
        );
      case 'VARGA-D8-004':
        return checked(
          hasAny(8, _benefics),
          'D8 8వ భావంలో శుభగ్రహాల యుతి: '
          '${placements.entries.where((e) => _benefics.contains(e.key) && house(e.value) == 8).map((e) => e.key).join(', ')}.',
        );
      case 'VARGA-D11-003':
        return checked(
          hasAny(11, _benefics),
          'D11 11వ భావంలోని శుభగ్రహాలు: '
          '${placements.entries.where((e) => _benefics.contains(e.key) && house(e.value) == 11).map((e) => e.key).join(', ')}.',
        );
      case 'VARGA-D11-004':
        return checked(
          occupant('Rahu', 11) && occupant('Jupiter', 11),
          'D11 ${houseText('Rahu')}; ${houseText('Jupiter')}; '
          '11వ భావంలో రాహు–గురు యుతి.',
        );
      case 'VARGA-D2-001':
        return checked(asc == 4, 'D2 లగ్నం: ${signName(asc)}. సూర్యహోర సింహం.');
      case 'VARGA-D2-002':
        return checked(
          asc == 3,
          'D2 లగ్నం: ${signName(asc)}. చంద్రహోర కర్కాటకం.',
        );
      case 'VARGA-D2-003':
        return checked(
          placements.entries.any(
            (p) => p.value == 4 && _benefics.contains(p.key),
          ),
          'సూర్యహోరలో శుభగ్రహాలు: ${placements.entries.where((p) => p.value == 4 && _benefics.contains(p.key)).map((p) => p.key).join(', ')}.',
        );
      case 'VARGA-D2-004':
        return checked(
          kendraTrikona(lordHouse(2)) && kendraTrikona(lordHouse(11)),
          'D2 2వ అధిపతి ${lord(2)}: ${lordHouse(2)}వ భావం; 11వ అధిపతి ${lord(11)}: ${lordHouse(11)}వ భావం.',
        );
      case 'VARGA-D2-005':
        return checked(
          hasAny(2, _malefics) || hasAny(11, _malefics),
          'D2 2/11 భావాల్లో పాపగ్రహాలు: ${placements.entries.where((e) => _malefics.contains(e.key) && (house(e.value) == 2 || house(e.value) == 11)).map((e) => e.key).join(', ')}.',
        );
      case 'VARGA-D2-006':
        return checked(
          dusthana(lordHouse(2)) || dusthana(lordHouse(11)),
          'D2 2వ అధిపతి ${lord(2)}: ${lordHouse(2)}వ భావం; 11వ అధిపతి ${lord(11)}: ${lordHouse(11)}వ భావం.',
        );
      case 'VARGA-D3-003':
        return checked(
          receivesFrom(lord(3), _benefics),
          'D3 3వ అధిపతి ${lord(3)}: ${lordHouse(3)}వ భావం. శుభగ్రహ దృష్టి (పరాశరి).',
        );
      case 'VARGA-D7-001':
        {
          final names = {lord(5), 'Jupiter'};
          final audit = <String>[];
          for (final n in names) {
            final degree = natal.planets.where((p) => p.name == n);
            audit.add(
              '$n: ${degree.isEmpty ? "డిగ్రీ లేదు" : degree.first.degreesInSign.toStringAsFixed(3)}°; '
              '${[1, 2, 3, 9, 12, 30].map((f) {
                final ps = charts[f]?.planets.where((p) => p.name == n);
                if (ps == null || ps.isEmpty) return 'D$f సమాచారం లేదు';
                final sign = ps.first.signIndex;
                return 'D$f ${_names[sign]} (${_exaltSigns[n] == sign
                    ? "ఉచ్చం"
                    : _lords[sign] == n
                    ? "స్వం"
                    : "ఇతర రాశి"})';
              }).join("; ")}',
            );
          }
          return (
            null,
            '${audit.join("\n")}\nగ్రహ డిగ్రీలు/షడ్వర్గ రాశి గౌరవాలు గణించాం. '
                'ఈ మూలంలోని “బలంగా” అనే పూర్తి పరిమితి నమోదు కాలేదు; '
                'స్వ/ఉచ్చం ఒక్కటే సమగ్ర బల నిర్ధారణ కాదు. సంతానం సమగ్ర కార్డులో స్వతంత్ర PDF క్లాజుల ఫలితం ఉంది.',
          );
        }
      case 'VARGA-D7-002':
      case 'VARGA-D7-003':
        {
          final names = id == 'VARGA-D7-002'
              ? {'Sun', 'Mars'}
              : {'Moon', 'Venus'};
          final contacts = names
              .where((p) => occupant(p, 5) || grahaAspects(p, signOfHouse(5)))
              .join(', ');
          return (
            null,
            'D7 పంచమానికి నిర్వచించిన స్థితి/దృష్టి: $contacts. '
                '“ఎక్కువ ప్రభావం” పరిమితి మూలంలో సంఖ్యాత్మకంగా లేదు. '
                'చారిత్రక మూల సూచన మాత్రమే; పిల్లల లింగ ఫలితంగా ఉపయోగించలేదు.',
          );
        }
      case 'VARGA-D7-006':
        {
          final ps = {'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};
          bool afflicted(int? target) =>
              target != null &&
              ps.any((p) => at(p) == target || grahaAspects(p, target));
          return (
            null,
            'D7 నిర్వచించిన ప్రత్యక్ష పాప యుతి/దృష్టి: '
                '5వ భావం ${afflicted(signOfHouse(5))}; గురువు ${afflicted(at("Jupiter"))}. '
                'ఈ AND ఉపపరీక్ష సమగ్ర సంతాన కార్డులో APP-D7-PIIDA-398గా ఉంది. '
                'మూలంలోని పూర్తి పీడ/బల నిర్వచనం లేకుండా VARGA-D7-006 మొత్తాన్ని '
                'ధృవీకరించలేదు; గర్భస్రావం లేదా వైద్య సమస్యను నిర్ధారించలేదు.',
          );
        }
      case 'VARGA-D7-004':
        return possible(
          receivesFrom('Jupiter', {'Venus'}),
          'D7 ${houseText('Jupiter')}; గురువుపై శుక్ర దృష్టి పరీక్ష. '
          'చంద్ర పక్షబలం/బుధ పాప సంబంధ వర్గీకరణ లేకుండా ఇద్దరినీ శుభగ్రహాలుగా ఊహించలేదు.',
        );
      case 'VARGA-D7-005':
        return possible(
          receivesFrom('Jupiter', _malefics),
          'D7 ${houseText('Jupiter')}; పాపగ్రహ దృష్టి (రాహు/కేతు ప్రత్యేక దృష్టి ధృవీకరించలేదు).',
        );
      case 'VARGA-D7-007':
        return possible(
          occupant(lord(5), 12) || relation(lord(5), lord(12)),
          'D7 5వ అధిపతి ${lord(5)} (${lordHouse(5)}వ భావం); 12వ అధిపతి ${lord(12)}.',
        );
      case 'VARGA-D9-001':
        return checked(
          const <int>{5, 7, 11}.contains(houseOf('Venus')) &&
              placements.keys.any((p) => p != 'Venus' && sameSign('Venus', p)),
          'D9 ${houseText('Venus')}; శుక్ర యుతి: ${placements.keys.where((p) => p != 'Venus' && sameSign('Venus', p)).join(', ')}.',
        );
      case 'VARGA-D9-002':
        return checked(
          relation(lord(7), 'Sun') || relation(lord(7), 'Moon'),
          'D9 7L ${lord(7)} (${lordHouse(7)}వ భావం); ${houseText('Sun')}; '
          '${houseText('Moon')}; నిజమైన యుతి/పరాశరి దృష్టి/పరివర్తన పరీక్ష.',
        );
      case 'VARGA-D9-004':
        return possible(
          occupant(lord(7), 12) ||
              occupant('Venus', 12) ||
              relation(lord(7), 'Rahu') ||
              relation('Venus', 'Rahu'),
          'D9 7వ అధిపతి ${lord(7)} (${lordHouse(7)}వ భావం); ${houseText('Venus')}; ${houseText('Rahu')}.',
        );
      case 'VARGA-D10-001':
        return checked(
          relation(lord(10), 'Mercury'),
          'D10 10L ${lord(10)} (${lordHouse(10)}వ భావం); '
          '${houseText('Mercury')}; యుతి/పరాశరి దృష్టి/పరివర్తన. '
          'ఒక గ్రహం తనతో తానే సంబంధమని లెక్కించలేదు.',
        );
      case 'VARGA-D10-002':
        return checked(
          relation(lord(10), 'Mars'),
          'D10 10L ${lord(10)} (${lordHouse(10)}వ భావం); '
          '${houseText('Mars')}; యుతి/పరాశరి దృష్టి/పరివర్తన. '
          'ఒక గ్రహం తనతో తానే సంబంధమని లెక్కించలేదు.',
        );
      case 'VARGA-D10-006':
        return checked(
          kendraTrikona(lordHouse(10)) && _exaltSigns[lord(10)] == at(lord(10)),
          'D10 10వ అధిపతి ${lord(10)}: ${lordHouse(10)}వ భావం, రాశి ${at(lord(10)) == null ? '—' : signName(at(lord(10))!)}; ఉచ్చ రాశి పరీక్ష.',
        );
      case 'VARGA-D10-008':
        {
          final l10 = lord(10);
          final l12 = lord(12);
          final yes =
              occupant(l10, 12) ||
              occupant(l12, 10) ||
              relation(l10, l12) ||
              occupant('Rahu', 10) ||
              sameSign(l10, 'Rahu');
          return possible(
            yes,
            'D10 10L $l10 ${lordHouse(10)}వ భావం; 12L $l12 '
            '${lordHouse(12)}వ భావం; ${houseText('Rahu')}; '
            '10–12 భావాధిపతుల యుతి/దృష్టి/పరివర్తన, రాహు ప్రత్యక్ష '
            'యుతి/స్థానం పరీక్ష. రాహు ప్రత్యేక దృష్టి ఊహించలేదు.',
          );
        }
      case 'VARGA-D12-005':
        return checked(
          receivesFrom('Sun', _benefics) || receivesFrom('Moon', _benefics),
          'D12 ${houseText('Sun')}; ${houseText('Moon')}; శుభగ్రహ దృష్టి పరీక్ష.',
        );
      case 'VARGA-D12-006':
        {
          final bhava = _benefics.any(
            (p) => occupant(p, 4) || grahaAspects(p, signOfHouse(4)),
          );
          final owner = _benefics.any((p) => relation(lord(4), p));
          return possible(
            bhava && owner,
            'D12 4వ భావానికి శుభ యుతి/దృష్టి: $bhava; '
            '4వ అధిపతి ${lord(4)}కి స్వతంత్ర శుభ సంబంధం: $owner. '
            'మూలంలోని రెండు షరతులూ అవసరం.',
          );
        }
      case 'VARGA-D12-007':
        {
          final bhava = _benefics.any(
            (p) => occupant(p, 9) || grahaAspects(p, signOfHouse(9)),
          );
          final owner = _benefics.any((p) => relation(lord(9), p));
          return possible(
            bhava && owner,
            'D12 9వ భావానికి శుభ యుతి/దృష్టి: $bhava; '
            '9వ అధిపతి ${lord(9)}కి స్వతంత్ర శుభ సంబంధం: $owner. '
            'మూలంలోని రెండు షరతులూ అవసరం.',
          );
        }
      case 'VARGA-D12-008':
        return possible(
          hasAny(4, _malefics) ||
              hasAny(9, _malefics) ||
              _malefics.any(
                (p) => relation(lord(4), p) || relation(lord(9), p),
              ),
          'D12 4/9 భావాలు, వాటి అధిపతులపై పాప ప్రభావం పరిశీలన.',
        );
      case 'VARGA-D12-012':
        {
          final sunSaturn = receivesFrom('Sun', {'Saturn'});
          final moonSaturn = receivesFrom('Moon', {'Saturn'});
          // The source asks for Sun–Moon affliction by aspect. Rahu's node
          // aspects are not configured, so Rahu conjunction alone is NOT an
          // assumed verified match. Only both explicit Saturn aspects qualify.
          return possible(
            sunSaturn && moonSaturn,
            'D12 సూర్యునిపై శని దృష్టి: $sunSaturn; '
            'చంద్రునిపై శని దృష్టి: $moonSaturn. '
            'రాహు ప్రత్యేక దృష్టి పూర్తి పద్ధతి లేక పెండింగ్.',
          );
        }
      case 'VARGA-D16-005':
        final fourth = placements.entries
            .where((p) => house(p.value) == 4)
            .map((p) => p.key)
            .toSet();
        return checked(
          D16SourcePredicate408.fourthConjunction(fourth),
          'D16 నాలుగో భావంలోని గ్రహాలు: ${fourth.join(', ')}; పాపగ్రహ యుతి అవసరం.',
        );
      case 'VARGA-D20-003':
        return possible(
          occupant('Ketu', 1) || occupant('Ketu', 12),
          'D20 ${houseText('Ketu')}. ఇతర కేతు దృష్టి/ప్రభావాలు పూర్తి కావాలి.',
        );
      case 'VARGA-D24-002':
        {
          final l4 = lord(4);
          final l9 = lord(9);
          final l12 = lord(12);
          final yes =
              occupant(l4, 12) ||
              occupant(l9, 12) ||
              occupant(l12, 4) ||
              occupant(l12, 9) ||
              relation(l4, l12) ||
              relation(l9, l12) ||
              occupant('Rahu', 4) ||
              occupant('Rahu', 9) ||
              sameSign(l4, 'Rahu') ||
              sameSign(l9, 'Rahu');
          return possible(
            yes,
            'D24 4L $l4 ${lordHouse(4)}వ భావం; 9L $l9 '
            '${lordHouse(9)}వ భావం; 12L $l12 ${lordHouse(12)}వ భావం; '
            '${houseText('Rahu')}; 4/9–12 సంబంధాలు, రాహు ప్రత్యక్ష '
            'స్థానం/యుతి మాత్రమే పరీక్షించాం.',
          );
        }
      case 'VARGA-D27-002':
        return checked(
          occupant('Jupiter', 1) && occupant('Mars', 1),
          'D27 ${houseText('Jupiter')}; ${houseText('Mars')}.',
        );
      case 'VARGA-D30-003':
        return possible(
          sameSign('Saturn', 'Rahu') &&
              (occupant('Saturn', 6) || grahaAspects('Saturn', signOfHouse(6))),
          'D30 శని–రాహు యుతి, 6వ భావ సంబంధం పరిశీలన.',
        );
      case 'VARGA-D45-002':
        return checked(
          occupant('Jupiter', 1) || grahaAspects('Jupiter', asc),
          'D45 ${houseText('Jupiter')}; లగ్నానికి గురు యుతి '
          'లేదా 5/7/9వ పరాశరి దృష్టి పరీక్ష.',
        );
      default:
        return (
          null,
          'మూల IF–THEN భద్రంగా ఉంది; పూర్తి గ్రహబలం, షడ్వర్గ, '
              'దశ/గోచార లేదా ఇతర ఉపషరతుల గణన ఇంకా అమలు చేయాలి.',
        );
    }
  }
}
