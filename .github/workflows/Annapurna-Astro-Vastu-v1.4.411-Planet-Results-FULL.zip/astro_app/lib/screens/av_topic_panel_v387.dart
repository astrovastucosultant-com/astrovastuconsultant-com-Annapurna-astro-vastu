import 'marriage_combined_panel_v390.dart';
import '../astrology/marriage_combined_v390.dart';
import 'package:flutter/material.dart';
import '../astrology/av_topic_result_v387.dart';
import '../astrology/ashtakavarga_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/astro_calculation_service.dart';
import '../astrology/dasha_service.dart';
import '../models/birth_data.dart';

class AvTopicPanel387 extends StatefulWidget {
  final AshtakavargaResult av;
  final AstroChartResult chart;
  final BirthData birth;
  final Future<AstroChartResult> Function(BirthData)? transitLoader;
  final DateTime? asOf;
  const AvTopicPanel387({
    super.key,
    required this.av,
    required this.chart,
    required this.birth,
    this.transitLoader,
    this.asOf,
  });
  @override
  State<AvTopicPanel387> createState() => _AvTopicPanel387State();
}

class _AvTopicPanel387State extends State<AvTopicPanel387> {
  String _topic = 'wealth';
  MarriageContext390 _maritalContext = MarriageContext390.unknown;
  late DateTime _at;
  late Future<AstroChartResult> _transit;
  int _generation = 0;
  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant AvTopicPanel387 old) {
    super.didUpdateWidget(old);
    if (old.chart != widget.chart || old.birth != widget.birth) {
      _maritalContext = MarriageContext390.unknown;
    }
    if (old.chart != widget.chart ||
        old.birth != widget.birth ||
        old.asOf != widget.asOf ||
        old.transitLoader != widget.transitLoader)
      _load();
  }

  void _load() {
    final offset = (widget.birth.timezoneOffsetHours * 60).round();
    final now =
        widget.asOf ?? DateTime.now().toUtc().add(Duration(minutes: offset));
    _at = DateTime(
      now.year,
      now.month,
      now.day,
      now.hour,
      now.minute,
      now.second,
    );
    _generation++;
    _transit = Future.sync(
      () => (widget.transitLoader ?? AstroCalculationService.calculate)(
        widget.birth.copyWith(localDateTime: _at),
      ),
    );
    // The detail tile starts collapsed; attach an error listener immediately.
    _transit.then<void>((_) {}, onError: (Object _, StackTrace __) {});
  }

  Color _color(AvRating387 rating) => switch (rating) {
    AvRating387.good => const Color(0xFF1B713B),
    AvRating387.bad => const Color(0xFFA52E50),
    AvRating387.medium => const Color(0xFF795D18),
  };
  List<String> _dasha(AvTopic387 topic) {
    final lines = <String>[];
    for (final kind in [
      DashaSystemKind.vimshottari,
      DashaSystemKind.tribhagi,
    ]) {
      try {
        final system = DashaService.system(
          kind: kind,
          chart: widget.chart,
          birthDateTime: widget.birth.localDateTime,
        );
        final path = DashaService.pathAt(system, _at);
        if (path == null) {
          lines.add('${system.label}: ఈ తేదీకి కాలం అందుబాటులో లేదు.');
          continue;
        }
        lines.add(
          '${system.label}: ${path.mahadasha.lord} / '
          '${path.antardasha.lord} / ${path.pratyantardasha.lord}',
        );
        for (final period in [
          path.mahadasha,
          path.antardasha,
          path.pratyantardasha,
        ]) {
          final positions = widget.chart.planets.where(
            (p) => period.lord.contains(p.name),
          );
          if (positions.isEmpty) continue;
          final p = positions.first;
          final house =
              (p.signIndex - widget.chart.ascendantSignIndex + 12) % 12 + 1;
          lines.add(
            '${period.lord}: జన్మ భావం $house; '
            '${topic.houses.contains(house) ? 'ఎంచుకున్న భావంతో సంబంధం ఉంది' : 'ఎంచుకున్న భావంలో లేదు'}; '
            '${topic.planets.contains(p.name) ? 'అంశ కారక గ్రహం' : 'ఇతర దశాధిపతి'}.',
          );
        }
      } catch (_) {
        lines.add('దశ గణనకు అవసరమైన సమాచారం అందుబాటులో లేదు.');
      }
    }
    return lines;
  }

  Widget _section(String title, List<Widget> children, {Key? key}) => Card(
    child: ExpansionTile(
      key: key,
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      childrenPadding: const EdgeInsets.all(12),
      expandedCrossAxisAlignment: CrossAxisAlignment.stretch,
      children: children,
    ),
  );
  Widget _text(String text) =>
      Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(text));

  @override
  Widget build(BuildContext context) {
    final topic = AvTopic387.values.firstWhere((t) => t.key == _topic);
    final scores = widget.av.arithmetic.savByHouse;
    if (!widget.av.totalsValid || !widget.av.arithmetic.auditValid) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Text('అష్టకవర్గ గణనలో తేడా ఉంది; మళ్లీ లెక్కించండి.'),
        ),
      );
    }
    final reading = AvTopicResult387.evaluate(topic, scores);
    final color = _color(reading.rating);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text(
          'అష్టకవర్గ ఫలితాలు',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        Text(
          _topic == 'marriage'
              ? 'జన్మయోగం • దశ • ప్రస్తుత గోచారం'
              : 'జన్మ జాతకంలోని అంశ బలం',
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          key: const ValueKey('av-topic-picker-387'),
          value: _topic,
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'అంశం ఎంచుకోండి',
            border: OutlineInputBorder(),
          ),
          items: [
            for (final t in AvTopic387.values)
              DropdownMenuItem(value: t.key, child: Text(t.title)),
          ],
          onChanged: (v) {
            if (v != null) setState(() => _topic = v);
          },
        ),
        const SizedBox(height: 10),
        if (_topic == 'marriage')
          MarriageCombinedPanel390(
            chart: widget.chart,
            birth: widget.birth,
            at: _at,
            transit: _transit,
            generation: _generation,
            sav7: scores[6],
            maritalContext: _maritalContext,
            onContextChanged: (v) => setState(() => _maritalContext = v),
            onRetry: () => setState(_load),
          ),
        if (_topic != 'marriage')
          Card(
            color: color.withOpacity(.08),
            child: ExpansionTile(
              key: ValueKey('av-result-${topic.key}'),
              title: Text(
                reading.result,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: color,
                ),
              ),
              subtitle: Text(
                '${reading.reason}\nకారణాలు / మూల నియమం కోసం టచ్ చేయండి',
              ),
              childrenPadding: const EdgeInsets.all(14),
              expandedCrossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (var i = 0; i < topic.houses.length; i++)
                  _text(
                    '${topic.houses[i]}వ భావం: ${reading.scores[i]} బిందువులు — '
                    '${AvTopicResult387.label(AvTopicResult387.scoreBand(reading.scores[i]))}',
                  ),
                _text(
                  'మొత్తం ${reading.total}; భావాలు ${topic.houses.length}; '
                  'సగటు ${reading.average.toStringAsFixed(2)}. సగటు గణితం కోసం మాత్రమే.',
                ),
                _text('మూల నియమం: PD-24-37. ${AvTopicResult387.source37}'),
                _text(
                  'అంశానికి భావాలను ఎంచుకోవడం, విడి భావాలు మిశ్రమంగా ఉంటే మధ్యస్థంగా '
                  'చూపించడం యాప్ ప్రదర్శన విధానం. బిందువులను సంఘటన శాతంగా మార్చలేదు.',
                ),
                _text(
                  'PD-24-39/40: 6, 8, 12 భావాల్లో ఎక్కువ బిందువులను మాత్రమే చూసి '
                  'శుభ గోచార ఫలితం అనకూడదు. మూలం: ముద్రిత పేజీ 276.',
                ),
                SelectableText(AvTopicResult387.sourceUrl),
                if (_topic == 'wealth') ...[
                  const Divider(),
                  const Text(
                    'సంపద యోగం — PD-24-38',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  _text(
                    AvTopicResult387.wealthChecks(
                          scores,
                        ).every((c) => c.matched)
                        ? 'మూలంలోని మూడు సంపద యోగ షరతులూ సరిపోలాయి.'
                        : 'ఈ ప్రత్యేక సంపద యోగానికి మూడు షరతులూ సరిపోలలేదు.',
                  ),
                  for (final check in AvTopicResult387.wealthChecks(scores))
                    _text('${check.matched ? '✓' : '—'} ${check.condition}'),
                  _text(AvTopicResult387.source38),
                ],
                const Divider(),
                const Text(
                  'పరిహారం',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                _text('ఈ నియమానికి మూలంలో ప్రత్యేక పరిహారం జతకాలేదు.'),
              ],
            ),
          ),
        _section('దశ / అంతర్దశ / ప్రత్యంతర్దశ', [
          _text('పరిశీలన తేదీ: ${_at.day}-${_at.month}-${_at.year}'),
          ..._dasha(topic).map(_text),
          _text(
            'దశాధిపతి, జన్మ భావం, అంశ కారకత్వాన్ని విడిగా చూపించాం. '
            'వయస్సు, కుటుంబం/వృత్తి స్థితితో కలిపి పరిశీలించాలి.',
          ),
        ], key: ValueKey('av-dasha-${topic.key}')),
        _section('ప్రస్తుత గోచారం — BAV / SAV', [
          FutureBuilder<AstroChartResult>(
            key: ValueKey(_generation),
            future: _transit,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Text('ప్రస్తుత గోచారాన్ని లెక్కిస్తున్నాం…');
              }
              if (snap.hasError || !snap.hasData)
                return Column(
                  children: [
                    const Text('గోచార గణన అందుబాటులో లేదు.'),
                    TextButton(
                      key: const ValueKey('av-transit-retry-387'),
                      onPressed: () => setState(_load),
                      child: const Text('మళ్లీ లెక్కించండి'),
                    ),
                  ],
                );
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _text(
                    'తేదీ: ${_at.day}-${_at.month}-${_at.year} • ${widget.birth.place}',
                  ),
                  for (final name in topic.planets)
                    ...snap.data!.planets.where((p) => p.name == name).map((p) {
                      final bav = AshtakavargaService.bavAtLongitude(
                        widget.av,
                        name,
                        p.longitude,
                      );
                      final sav = AshtakavargaService.savAtLongitude(
                        widget.av,
                        p.longitude,
                      );
                      final house =
                          (p.signIndex - widget.chart.ascendantSignIndex + 12) %
                              12 +
                          1;
                      return _text(
                        '$name: జన్మలగ్నం నుంచి $houseవ భావం; BAV $bav/8; SAV $sav; '
                        'కక్ష్య ${AshtakavargaService.kakshyaIndex(p.longitude)}/8.',
                      );
                    }),
                  _text(
                    'పై తేదీ గోచార పరిశీలన తేదీ. 1–12 రాశి సూచికలను క్యాలెండర్ నెలలుగా మార్చలేదు.',
                  ),
                ],
              );
            },
          ),
        ], key: ValueKey('av-transit-${topic.key}')),
      ],
    );
  }
}
