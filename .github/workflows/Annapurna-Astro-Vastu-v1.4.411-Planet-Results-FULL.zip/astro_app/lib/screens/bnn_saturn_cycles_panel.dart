import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_saturn_cycle_service.dart';
import '../astrology/bnn_cycle_result_service.dart';
import 'bnn_cycle_result_card.dart';
import 'bnn_saturn_round_info_v382.dart';
import '../astrology/bnn_saturn_round_catalog_v382.dart';
import '../models/birth_data.dart';
import '../astrology/bnn_rashi_rule_service.dart';
import '../astrology/bnn_house_relation_service.dart';

/// Saturn's four cycles: verified focus + approximate contacts; no invented events.
class BnnSaturnCyclesPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData? birthData;
  const BnnSaturnCyclesPanel({super.key, required this.chart, this.birthData});
  @override
  State<BnnSaturnCyclesPanel> createState() => _BnnSaturnCyclesPanelState();
}

class _BnnSaturnCyclesPanelState extends State<BnnSaturnCyclesPanel> {
  late final Future<
    (List<BnnSaturnCycleTheme>, BnnCycleResultCatalog, BnnSaturnRounds382)
  >
  _data = _load();
  Future<(List<BnnSaturnCycleTheme>, BnnCycleResultCatalog, BnnSaturnRounds382)>
  _load() async => (
    await BnnSaturnCycleService.loadThemes(),
    await BnnCycleResultService.load(),
    await loadSaturnRounds382(),
  );

  String _age(double n) =>
      n == n.roundToDouble() ? n.toStringAsFixed(0) : n.toStringAsFixed(1);

  @override
  Widget build(BuildContext context) =>
      FutureBuilder<
        (List<BnnSaturnCycleTheme>, BnnCycleResultCatalog, BnnSaturnRounds382)
      >(
        future: _data,
        builder: (context, snap) {
          if (snap.hasError)
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text('శని సైకిల్ డేటా లోపం: ${snap.error}'),
              ),
            );
          if (!snap.hasData)
            return const Center(child: CircularProgressIndicator());
          final birth = widget.birthData;
          final offset = birth?.timezoneOffsetHours;
          final age =
              birth == null ||
                  offset == null ||
                  !offset.isFinite ||
                  offset.abs() > 14
              ? null
              : BnnSaturnRounds382.completedAgeAt(
                  birth.localDateTime,
                  DateTime.now().toUtc().add(
                    Duration(minutes: (offset * 60).round()),
                  ),
                );
          final active = snap.data!.$3.forCompletedAge(age);
          final cycles = BnnSaturnCycleService.calculate(
            chart: widget.chart,
            themes: snap.data!.$1,
          );
          final displayCycles = cycles.isNotEmpty
              ? cycles
              : [
                  for (final theme in snap.data!.$1.where((t) => t.round <= 3))
                    BnnSaturnCycle(theme: theme, windows: const []),
                ];
          return Card(
            key: const ValueKey('bnn-saturn-three-rounds-panel'),
            color: const Color(0xFFEDF3FA),
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: ExpansionTile(
              title: const Text(
                'BNN — శని మూడు రౌండ్లు',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              subtitle: Text(
                age == null
                    ? '3 మూల సారాంశాలు • 36 పరిశీలన నమూనాలు'
                    : active == null
                    ? 'వయస్సు $age • ${BnnSaturnRounds382.unsupported}'
                    : 'ప్రస్తుత వయస్సు $age • శని ${active.round}వ రౌండ్ • 36 పరిశీలన నమూనాలు',
              ),
              childrenPadding: const EdgeInsets.fromLTRB(10, 0, 10, 12),
              children: [
                const Text(
                  'శని సుమారు 2½ ఏళ్లకు ఒక రాశి; 30 ఏళ్లకు ఒక రౌండ్. '
                  'ఇవి సరళ నాడీ వయస్సు గణనలు; వాస్తవ గోచార తేదీలు కావు.',
                  style: TextStyle(fontSize: 12.5, height: 1.5),
                ),
                const SizedBox(height: 6),
                const Text(
                  'మూలం: Dr. N. Srinivasan Shastry, Brighu Naadi Sangraha, '
                  'Principles of Naadi, ముద్రిత పేజీలు xiii–xiv. '
                  '4వ రౌండ్‌కు స్వతంత్ర సాధారణ ఫలితం ఈ మూలంలో లేదు.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF64717C)),
                ),
                for (final cycle in displayCycles.where(
                  (c) => c.theme.round <= 3,
                ))
                  Card(
                    color: Colors.white,
                    child: ExpansionTile(
                      key: ValueKey('bnn-saturn-cycle-${cycle.theme.round}'),
                      title: Text(
                        '${cycle.theme.round}వ సైకిల్ • '
                        '${_age(cycle.theme.ageStart)}–${_age(cycle.theme.ageEnd)} ఏళ్లు${active?.round == cycle.theme.round ? ' • ప్రస్తుతం' : ''}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      subtitle: Text(
                        cycle.theme.round == 3
                            ? 'ఆరోగ్య విషయంలో జాగ్రత్త అవసరం — ఇది ఖచ్చితమైన సంఘటన కాదు'
                            : (cycle.theme.focus ??
                                  'ప్రత్యేక రౌండ్ ఫలితం లేదు — కారకత్వ సూచనలు మాత్రమే'),
                      ),
                      childrenPadding: const EdgeInsets.fromLTRB(9, 0, 9, 10),
                      children: [
                        BnnSaturnRoundInfo382(
                          catalog: snap.data!.$3,
                          completedAge: cycle.theme.ageStart.toInt(),
                        ),
                        const Text(
                          'ఇది పరిశీలన అంశం మాత్రమే. జాతకానికి నిర్దిష్ట '
                          'సంఘటన జరిగిందని, ఆరోగ్య ప్రమాదం లేదా మరణ సమయమని తీర్పు కాదు.',
                          style: TextStyle(
                            fontSize: 12,
                            color: Color(0xFF526475),
                          ),
                        ),
                        const SizedBox(height: 8),
                        for (final window in cycle.windows)
                          _SaturnCycleWindowRow(
                            window: window,
                            catalog: snap.data!.$2,
                            roundFocus: cycle.theme.focus,
                          ),
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      );
}

class _SaturnCycleWindowRow extends StatelessWidget {
  final BnnSaturnContactWindow window;
  final BnnCycleResultCatalog catalog;
  final String? roundFocus;
  const _SaturnCycleWindowRow({
    required this.window,
    required this.catalog,
    this.roundFocus,
  });

  String _age(double n) =>
      n == n.roundToDouble() ? n.toStringAsFixed(0) : n.toStringAsFixed(1);

  @override
  Widget build(BuildContext context) {
    final readings = BnnCycleResultService.forSaturn(
      cycle: window.round,
      ageStart: window.ageStart,
      natalContacts: window.natalContacts,
      catalog: catalog,
      roundTopic: roundFocus,
    );
    final names = window.natalContacts
        .map((p) => BnnHouseRelationService.planetLabels[p.name] ?? p.name)
        .join(', ');
    return Container(
      padding: const EdgeInsets.all(9),
      margin: const EdgeInsets.only(bottom: 5),
      decoration: BoxDecoration(
        color: window.natalContacts.isNotEmpty
            ? const Color(0xFFF0F3F6)
            : const Color(0xFFF5F6F7),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${_age(window.ageStart)}–${_age(window.ageEnd)} ఏళ్లు '
            '• ${BnnRashiRuleService.signs[window.signIndex]}',
            style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold),
          ),
          if (window.natalContacts.isNotEmpty)
            Text(
              'జన్మగ్రహస్పర్శ: $names',
              style: const TextStyle(fontSize: 12),
            ),
          if (window.natalContacts.isEmpty)
            const Text(
              'ఈ రాశిలో జన్మగ్రహం లేదు',
              style: TextStyle(fontSize: 11.5, color: Color(0xFF65727D)),
            ),
          for (final r in readings)
            BnnCycleResultCard(
              reading: r,
              inspection:
                  'శని ${window.round}వ సైకిల్ • '
                  '${_age(window.ageStart)}–${_age(window.ageEnd)} ఏళ్లు • '
                  '${BnnRashiRuleService.signs[window.signIndex]} • '
                  'జన్మ గ్రహస్పర్శ: $names',
            ),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(
              'గణన ID: ${window.calculationId}',
              style: const TextStyle(fontSize: 10.5, color: Color(0xFF66727D)),
            ),
          ),
        ],
      ),
    );
  }
}
