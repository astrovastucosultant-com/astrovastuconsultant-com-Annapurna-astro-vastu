import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../astrology/bnn_saturn_round_catalog_v382.dart';

Future<BnnSaturnRounds382> loadSaturnRounds382() async =>
    BnnSaturnRounds382.fromJson(
      jsonDecode(
        await rootBundle.loadString(
          'assets/bnn/bnn_saturn_three_rounds_te_v382.json',
        ),
      ) as Map<String, dynamic>,
    );

class BnnSaturnRoundInfo382 extends StatelessWidget {
  final BnnSaturnRounds382 catalog;
  final int? completedAge;
  final String? eventId;
  const BnnSaturnRoundInfo382({
    super.key,
    required this.catalog,
    required this.completedAge,
    this.eventId,
  });
  @override
  Widget build(BuildContext context) {
    final round = catalog.forCompletedAge(completedAge);
    if (round == null)
      return Padding(
        padding: const EdgeInsets.all(8),
        child: Text('శని రౌండ్: ${catalog.statusForAge(completedAge)}'),
      );
    final reviews = catalog.reviewFor(round, eventId: eventId);
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'శని ${round.round}వ రౌండ్ • ${round.from}–${round.to} ఏళ్లు',
            key: ValueKey('saturn-auto-round-${round.round}'),
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(round.summary),
          const Text(
            '30 ఏళ్ల సరళ వయస్సు నేపథ్యం; సంఘటన ఫలితం లేదా నిజ గోచార తేదీ కాదు.',
            style: TextStyle(fontSize: 12),
          ),
          ExpansionTile(
            title: const Text('శని రౌండ్ మూలం / వివరాలు'),
            children: [
              for (final id in round.sourceIds) Text(catalog.sources[id]!),
              const Text(
                'రౌండ్ మాత్రమే చూసి సంఘటన, నెల లేదా శాతం నిర్ణయించలేదు. జాతకానికి సరిపోలిన ప్రత్యేక నియమం ఆధారంగా ఫలితాల పరిశీలన వేరుగా కొనసాగుతుంది.',
              ),
            ],
          ),
          if (reviews.isNotEmpty)
            ExpansionTile(
              title: Text('శని పరిశీలన నమూనాలు (${reviews.length})'),
              subtitle: const Text(
                'రచనా నమూనాలు మాత్రమే; మీ జాతక ఫలితాలు కావు',
              ),
              children: [
                const Text(
                  'ప్రత్యేక మూల నియమం, జాతక సరిపోలిక, కాల ఆధారం జతచేసే ముందు ఈ వాక్యాలను ఫలితంగా ప్రకటించరాదు.',
                ),
                for (final item in reviews)
                  ExpansionTile(
                    title: Text(item.title),
                    children: [
                      Text('అనుకూల వాక్య నమూనా: ${item.favorable}'),
                      Text('ప్రతికూల వాక్య నమూనా: ${item.unfavorable}'),
                      Text('తటస్థ వాక్య నమూనా: ${item.neutral}'),
                      const Text(
                        'ఈ నమూనాకు సంఘటన మూల నియమం, పరిహారం జతకాలేదు.',
                      ),
                    ],
                  ),
              ],
            ),
        ],
      ),
    );
  }
}
