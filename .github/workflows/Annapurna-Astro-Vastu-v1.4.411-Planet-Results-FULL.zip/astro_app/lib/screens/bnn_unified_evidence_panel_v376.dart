import 'dart:convert';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../astrology/astro_models.dart';
import '../astrology/astro_calculation_service.dart';
import '../astrology/bnn_unified_evidence_v376.dart';
import '../astrology/bnn_topic_search_v377.dart';
import '../astrology/bnn_rashi_rule_service.dart';
import '../astrology/bnn_source_safalya_v379.dart';
import '../astrology/bnn_auto_source_v381.dart';
import 'bnn_source_safalya_panel_v379.dart';
import 'bnn_saturn_round_info_v382.dart';
import '../astrology/bnn_saturn_round_catalog_v382.dart';
import '../models/birth_data.dart';

class UnifiedCatalog376 {
  final List<UnifiedEvent376> events;
  final List<Map<String, dynamic>> sources;
  const UnifiedCatalog376(this.events, this.sources);
  static Future<UnifiedCatalog376> load() async {
    final raw = await Future.wait([
      rootBundle.loadString(
        'assets/life_events/bnn_unified_event_mapping_v376.json',
      ),
      rootBundle.loadString(
        'assets/bnn/bnn_cycle_contact_interpretations_v357.json',
      ),
    ]);
    final data = jsonDecode(raw[0]) as Map<String, dynamic>;
    if (data['schema'] != 'AAV-BNN-UNIFIED-376')
      throw const FormatException('Invalid unified catalog');
    return UnifiedCatalog376(
      [
        for (final e in data['events'] as List)
          UnifiedEvent376(
            id: e['id'],
            title: e['title'],
            mainHouse: e['main_house'],
            houses: (e['houses'] as List).cast<int>().toSet(),
            ageFrom: (e['age_from'] as num).toDouble(),
            ageTo: (e['age_to'] as num).toDouble(),
            sensitive: e['sensitive'],
          ),
      ],
      (jsonDecode(raw[1])['source_rules'] as List).cast<Map<String, dynamic>>(),
    );
  }
}

class BnnUnifiedEvidencePanel376 extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birth;
  final Future<UnifiedCatalog376>? catalog;
  final Future<List<BnnRashiRule>>? natalRules;
  final Future<List<PlanetPosition>> Function(DateTime)? transitLoader;
  const BnnUnifiedEvidencePanel376({
    super.key,
    required this.chart,
    required this.birth,
    this.catalog,
    this.natalRules,
    this.transitLoader,
  });
  @override
  State<BnnUnifiedEvidencePanel376> createState() => _UnifiedState376();
}

class _UnifiedState376 extends State<BnnUnifiedEvidencePanel376> {
  late Future<UnifiedCatalog376> _catalog;
  late final Future<BnnSaturnRounds382> _saturnRounds = loadSaturnRounds382();
  late Future<List<BnnRashiRule>> _natal;
  late Future<List<BnnAutoFinding381>> _autoFindings;
  final Map<String, Future<List<PlanetPosition>>> _sampleCache = {};
  Future<List<BnnAutoFinding381>> _findingsForAuto() async {
    final target = widget;
    final rules = await _natal;
    return [
      for (final f in BnnRashiRuleService.evaluate(
        rules: rules,
        chart: target.chart,
        gender: target.birth.gender,
      ))
        if (f.canDisplayEffect)
          BnnAutoFinding381(
            f.rule.id,
            f.rule.planet,
            f.displayEffect!,
            '${f.rule.transcriptionFile} • ముద్రిత పేజీ ${f.rule.printedPage}',
            f.rule.originalIf,
          ),
    ];
  }

  late TextEditingController _age;
  final TextEditingController _search = TextEditingController();
  late BnnAgeRange377 _range;
  String _query = '', _role = 'unknown';
  String? _eventId, _error;
  bool _all = false, _open = false;
  bool _ageDirty = false;
  bool? _job, _married;
  int _limit = 10;
  final Map<String, Future<List<PlanetPosition>>> _transits = {};
  int _initialAge() {
    final offset = widget.birth.timezoneOffsetHours;
    final now = DateTime.now().toUtc().add(
      Duration(minutes: offset.isFinite ? (offset * 60).round() : 0),
    );
    return (BnnSaturnRounds382.completedAgeAt(
              widget.birth.localDateTime,
              now,
            ) ??
            0)
        .clamp(0, 100)
        .toInt();
  }

  @override
  void initState() {
    super.initState();
    _catalog = widget.catalog ?? UnifiedCatalog376.load();
    _natal = widget.natalRules ?? BnnRashiRuleService.load();
    _autoFindings = _findingsForAuto();
    _sampleCache.clear();
    final age = _initialAge();
    _range = BnnAgeRange377(age, age);
    _age = TextEditingController(text: '$age');
  }

  @override
  void didUpdateWidget(covariant BnnUnifiedEvidencePanel376 old) {
    super.didUpdateWidget(old);
    if (!identical(old.chart, widget.chart) ||
        !identical(old.birth, widget.birth) ||
        !identical(old.catalog, widget.catalog) ||
        !identical(old.natalRules, widget.natalRules) ||
        !identical(old.transitLoader, widget.transitLoader)) {
      _catalog = widget.catalog ?? UnifiedCatalog376.load();
      _natal = widget.natalRules ?? BnnRashiRuleService.load();
      _autoFindings = _findingsForAuto();
      _sampleCache.clear();
      final age = _initialAge();
      _range = BnnAgeRange377(age, age);
      _age.text = '$age';
      _transits.clear();
      _role = 'unknown';
      _job = null;
      _married = null;
      _error = null;
      _ageDirty = false;
      _eventId = null;
    }
  }

  @override
  void dispose() {
    _age.dispose();
    _search.dispose();
    super.dispose();
  }

  void _setQuery(String value) {
    setState(() {
      _query = value;
      _all = false;
      _eventId = null;
      _limit = 10;
    });
  }

  void _apply() {
    final parsed = BnnAgeRange377.parse(_age.text);
    setState(() {
      if (parsed == null) {
        _error = 'ఉదా: 25 లేదా 1-50 ఇవ్వండి (0–100; చిన్నది ముందు)';
        return;
      }
      _range = parsed;
      _error = null;
      _ageDirty = false;
      _limit = 10;
      _transits.clear();
    });
  }

  static String date(DateTime d) => '${d.day}-${d.month}-${d.year}';
  Future<List<PlanetPosition>> _loadTransits(DateTime local) async {
    final key = local.toIso8601String();
    final pending = _sampleCache.putIfAbsent(
      key,
      () => _loadTransitUncached(local),
    );
    try {
      return await pending;
    } catch (_) {
      if (identical(_sampleCache[key], pending)) _sampleCache.remove(key);
      rethrow;
    }
  }

  Future<List<PlanetPosition>> _loadTransitUncached(DateTime local) async {
    if (widget.transitLoader != null) return widget.transitLoader!(local);
    final b = widget.birth;
    if (!b.timezoneOffsetHours.isFinite || b.timezoneOffsetHours.abs() > 14)
      throw StateError('Invalid timezone');
    final utc =
        DateTime.utc(
          local.year,
          local.month,
          local.day,
          local.hour,
          local.minute,
          local.second,
          local.millisecond,
          local.microsecond,
        ).subtract(
          Duration(microseconds: (b.timezoneOffsetHours * 3600000000).round()),
        );
    return Future.wait([
      for (final name in ['Saturn', 'Jupiter', 'Sun', 'Moon'])
        AstroCalculationService.calculatePlanetAtUtc(
          utc: utc,
          planetName: name,
          ayanamsa: b.ayanamsa,
        ),
    ]);
  }

  Widget _history() => ExpansionTile(
    title: const Text('జీవిత స్థితి / గత సంఘటనలు — అవసరమైతే ఎంచుకోండి'),
    children: [
      DropdownButton<String>(
        isExpanded: true,
        value: _role,
        items: const [
          DropdownMenuItem(value: 'unknown', child: Text('పాత్ర: తెలియదు')),
          DropdownMenuItem(value: 'student', child: Text('విద్యార్థి')),
          DropdownMenuItem(value: 'employee', child: Text('ఉద్యోగి')),
          DropdownMenuItem(
            value: 'business',
            child: Text('వ్యాపారి / స్వయం ఉపాధి'),
          ),
          DropdownMenuItem(value: 'other', child: Text('ఇతర స్థితి')),
        ],
        onChanged: (v) {
          if (v != null)
            setState(() {
              _role = v;
            });
        },
      ),
      DropdownButton<String>(
        isExpanded: true,
        value: _job == null
            ? 'unknown'
            : _job!
            ? 'yes'
            : 'no',
        items: const [
          DropdownMenuItem(
            value: 'unknown',
            child: Text('మొదటి ఉద్యోగం జరిగిందా? తెలియదు'),
          ),
          DropdownMenuItem(
            value: 'yes',
            child: Text('మొదటి ఉద్యోగం ఇప్పటికే జరిగింది'),
          ),
          DropdownMenuItem(
            value: 'no',
            child: Text('మొదటి ఉద్యోగం ఇంకా జరగలేదు'),
          ),
        ],
        onChanged: (v) {
          setState(() {
            _job = v == 'unknown' ? null : v == 'yes';
          });
        },
      ),
      DropdownButton<String>(
        isExpanded: true,
        value: _married == null
            ? 'unknown'
            : _married!
            ? 'yes'
            : 'no',
        items: const [
          DropdownMenuItem(
            value: 'unknown',
            child: Text('వివాహ స్థితి తెలియదు'),
          ),
          DropdownMenuItem(value: 'yes', child: Text('వివాహం జరిగింది')),
          DropdownMenuItem(value: 'no', child: Text('వివాహం జరగలేదు')),
        ],
        onChanged: (v) {
          setState(() {
            _married = v == 'unknown' ? null : v == 'yes';
          });
        },
      ),
      const Text(
        'ఈ స్థితులు ఎంచుకున్న వయస్సు/పరిధికి సంబంధించినవి. పరిధిలో స్థితి మారితే చిన్న పరిధులుగా పరిశీలించండి. ఎంపికలు ఈ స్క్రీన్‌కే; సేవ్ చేసిన జాతకాన్ని మార్చవు.',
      ),
    ],
  );
  Widget _natalResults(
    List<UnifiedEvent376> events,
  ) => FutureBuilder<List<BnnRashiRule>>(
    future: _natal,
    builder: (context, snapshot) {
      if (snapshot.hasError)
        return const Text('జన్మ BNN మూల వాక్యాలు చదవడం పూర్తి కాలేదు.');
      if (!snapshot.hasData) return const LinearProgressIndicator();
      final findings = BnnRashiRuleService.evaluate(
        rules: snapshot.data!,
        chart: widget.chart,
        gender: widget.birth.gender,
      ).where((f) => f.canDisplayEffect).toList();
      final related = [
        for (final f in findings)
          if (BnnTopicSearch377.natalSentences(
            f.displayEffect!,
            events,
          ).isNotEmpty)
            f,
      ];
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'జాతకానికి వర్తించిన BNN జన్మ సూచనలు',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
          ),
          const Text(
            'వీటిలో ఎంచుకున్న అంశానికి సంబంధించిన మూల వాక్యాలు మాత్రమే చూపుతున్నాం. ఇవి జన్మ సూచనలు; ఎంచుకున్న వయస్సులో సంఘటన జరిగే నిర్ధారణ కాదు.',
          ),
          if (related.isEmpty)
            const Text(
              'ఈ అంశానికి సంబంధించిన ప్రదర్శించగల BNN జన్మ వాక్యం ప్రస్తుత జాతకంలో లభించలేదు. కింది భావసంబంధ స్కోర్లను పూర్తి ఫలితంగా పరిగణించవద్దు.',
            ),
          for (final f in related)
            Material(
              color: const Color(0xFFF1F5F8),
              child: ExpansionTile(
                title: Text(
                  BnnTopicSearch377.natalSentences(
                    f.displayEffect!,
                    events,
                  ).join('. '),
                ),
                subtitle: const Text('మూల నియమం–జాతక పరిశీలన కోసం టచ్ చేయండి'),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(10),
                    child: Text(
                      '${f.rule.id} • ${f.rule.originalIf}\n${f.rule.title}; జన్మ భావం ${f.house}\n'
                      'మూలం: ${f.rule.transcriptionFile} • PDF పేజీ ${f.rule.pdfPage}\n'
                      '${f.displayEffect}\n${f.annotation ?? ""}\n'
                      'మూలవాక్యంలో తండ్రి/తల్లి/జాతకుడు ఎవరి గురించి ఉందో అదే సందర్భంలో చదవాలి. పరిహారం ఈ కార్డుకు జతకాలేదు.',
                    ),
                  ),
                ],
              ),
            ),
        ],
      );
    },
  );
  Widget _windowRow(
    UnifiedAgeWindow376 w,
    UnifiedEventEvidence376 e,
  ) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Material(
      color: const Color(0xFFF4F6F9),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'వయస్సు ${w.ageFrom}–${w.ageTo}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 17,
                  ),
                ),
                Text(BnnTopicSearch377.summary(e)),
                for (final c in e.cautions.where(
                  (c) =>
                      c.contains('బాల్య') ||
                      c.contains('ఇప్పటికే') ||
                      c.contains('వయస్సు'),
                ))
                  Text(c, style: const TextStyle(color: Color(0xFF9C2252))),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              'వయస్సు నేపథ్యం: ${BnnAgeContext379.theme(w.ageFrom)}. మూలం: ముద్రిత పేజీలు 54–55; ఇది సంఘటనలపై నిషేధం కాదు.',
            ),
          ),
          FutureBuilder<BnnSaturnRounds382>(
            future: _saturnRounds,
            builder: (context, snapshot) {
              if (snapshot.hasError)
                return const Text('శని రౌండ్ సమాచారం చదవడం పూర్తి కాలేదు.');
              if (!snapshot.hasData)
                return const Text('శని రౌండ్ సమాచారం చదువుతున్నాం…');
              return BnnSaturnRoundInfo382(
                catalog: snapshot.data!,
                completedAge: w.ageFrom.floor(),
                eventId: e.event.id,
              );
            },
          ),
          BnnSourceSafalyaPanel379(
            key: ValueKey(
              'safalya-${e.event.id}-${w.ageFrom}-$_role-$_job-$_married',
            ),
            chart: widget.chart,
            event: e.event,
            age: w.ageFrom,
            married: _married,
            findings: _autoFindings,
            start: w.start,
            end: w.end,
            loadTransits: _loadTransits,
          ),
          ExpansionTile(
            title: const Text('భావసంబంధాలు • మూల నియమాలు • పరిశీలన'),
            children: [
              Text(
                'పరిశీలన పరిధి: ${w.start.year}-${w.start.month.toString().padLeft(2, "0")} నుంచి ${w.end.year}-${w.end.month.toString().padLeft(2, "0")} వరకు; ముగింపు హద్దు మినహాయింపు. సంఘటన నెల నిర్ధారణ కాదు.',
              ),
              Text(
                'శని సైకిల్ ${w.saturnCycle}; గురు సైకిల్ ${w.jupiterCycle}; నడుస్తున్న సంవత్సరం ${w.runningYear}',
              ),
              UnifiedEventCard376(evidence: e, initiallyExpanded: true),
              TextButton(
                onPressed: () {
                  final key = w.sampledLocal.toIso8601String();
                  final pending = Completer<List<PlanetPosition>>();
                  setState(() {
                    _transits[key] = pending.future;
                  });
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (!mounted) return;
                    pending.complete(
                      Future<List<PlanetPosition>>.sync(
                        () => _loadTransits(w.sampledLocal),
                      ),
                    );
                  });
                },
                child: const Text('ఈ కాలంలోని వాస్తవ గోచార నమూనా'),
              ),
              if (_transits[w.sampledLocal.toIso8601String()] != null)
                FutureBuilder<List<PlanetPosition>>(
                  future: _transits[w.sampledLocal.toIso8601String()],
                  builder: (context, snap) {
                    if (snap.hasError)
                      return const Text(
                        'గోచార గణన పూర్తి కాలేదు; మళ్లీ ప్రయత్నించండి.',
                      );
                    if (!snap.hasData) return const LinearProgressIndicator();
                    return Text(
                      'నమూనా ${date(w.sampledLocal)}\n${snap.data!.map((p) => '${p.name}: రాశి ${p.signIndex + 1} • ${p.longitude.toStringAsFixed(2)}°').join("\n")}',
                    );
                  },
                ),
              const Text(
                'పై ఆటో పరిశీలనలో సరిపోలిన జన్మ నియమంలోని గ్రహం ఆధారం. ఇక్కడి భావసంబంధాలు జన్మలగ్నం ఆధారం. సూర్య–చంద్ర–సంఘటన లగ్నానికి ప్రత్యేక సంఘటన నియమాలు జతకాలేదు.',
              ),
            ],
          ),
        ],
      ),
    ),
  );
  @override
  Widget build(BuildContext context) => Card(
    key: const ValueKey('bnn-unified-evidence-v376'),
    child: ExpansionTile(
      title: const Text(
        'BNN — అంశం ఎంచుకొని సూచనలు చూడండి',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: const Text('సెర్చ్ → వయస్సు పరిధి → జన్మ సూచనలు, కాల పరిశీలన'),
      onExpansionChanged: (v) {
        setState(() {
          _open = v;
        });
      },
      childrenPadding: const EdgeInsets.all(12),
      children: [
        if (_open) ...[
          TextField(
            key: const ValueKey('bnn-topic-search'),
            controller: _search,
            decoration: InputDecoration(
              labelText: 'ఏ అంశం కావాలి?',
              hintText: 'విద్య / ఉద్యోగం / వివాహం / ధనం',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(
                onPressed: () {
                  _search.clear();
                  _setQuery('');
                },
                icon: const Icon(Icons.clear),
              ),
            ),
            onChanged: _setQuery,
          ),
          Wrap(
            spacing: 6,
            children: [
              for (final title in [
                'విద్య',
                'ఉద్యోగం',
                'వివాహం',
                'ధనం',
                'ఇల్లు',
              ])
                ActionChip(
                  label: Text(title),
                  onPressed: () {
                    _search.text = title;
                    _setQuery(title);
                  },
                ),
              ActionChip(
                label: const Text('అన్ని అంశాలు'),
                onPressed: () {
                  setState(() {
                    _all = true;
                    _query = '';
                    _search.clear();
                    _eventId = null;
                    _limit = 10;
                  });
                },
              ),
            ],
          ),
          TextField(
            key: const ValueKey('bnn-age-range'),
            controller: _age,
            onChanged: (_) {
              setState(() {
                _ageDirty = true;
              });
            },
            keyboardType: TextInputType.text,
            decoration: InputDecoration(
              labelText: 'వయస్సు లేదా పరిధి',
              hintText: 'ఉదా: 25 లేదా 1-50',
              errorText: _error,
            ),
          ),
          OutlinedButton(
            onPressed: _apply,
            child: const Text('సూచనలు చూపించండి'),
          ),
          _history(),
          FutureBuilder<UnifiedCatalog376>(
            future: _catalog,
            builder: (context, snap) {
              if (snap.hasError)
                return const Text('మూల డేటా చదవడం పూర్తి కాలేదు.');
              if (!snap.hasData) return const LinearProgressIndicator();
              if (_ageDirty || _error != null)
                return const Text(
                  'వయస్సు లేదా పరిధిని సరిచేసి “సూచనలు చూపించండి” నొక్కండి.',
                );
              if (!_all && _query.trim().isEmpty)
                return const Text(
                  'ముందుగా పై సెర్చ్‌లో అంశం రాయండి లేదా అంశం బటన్ నొక్కండి.',
                );
              final matches = snap.data!.events
                  .where((e) => _all || BnnTopicSearch377.matches(e, _query))
                  .toList();
              if (matches.isEmpty)
                return const Text(
                  'ఈ సెర్చ్‌కు అంశం దొరకలేదు. తెలుగు లేదా English పదంతో ప్రయత్నించండి.',
                );
              final selected = matches
                  .where((e) => _eventId == null || e.id == _eventId)
                  .toList();
              List<UnifiedAgeWindow376> windows;
              try {
                windows = [
                  for (var age = _range.from; age <= _range.to; age++)
                    ...BnnUnifiedEvidenceService376.evaluate(
                      chart: widget.chart,
                      birth: widget.birth.localDateTime,
                      completedAge: age,
                      events: selected,
                      cycleSourceRules: snap.data!.sources,
                      context: UnifiedLifeContext376(
                        role: _role,
                        hadFirstJob: _job,
                        married: _married,
                      ),
                    ),
                ];
              } catch (_) {
                return const Text(
                  'గణనకు సమాచారం లేదు: పూర్తి చెల్లుబాటు అయ్యే జన్మ డేటా అవసరం.',
                );
              }
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  DropdownButton<String>(
                    key: const ValueKey('bnn-topic-select'),
                    isExpanded: true,
                    value: _eventId ?? '__matching__',
                    items: [
                      const DropdownMenuItem(
                        value: '__matching__',
                        child: Text('సెర్చ్‌కు సరిపోయిన అన్ని అంశాలు'),
                      ),
                      for (final e in matches)
                        DropdownMenuItem(value: e.id, child: Text(e.title)),
                    ],
                    onChanged: (v) {
                      setState(() {
                        _eventId = v == '__matching__' ? null : v;
                        _limit = 10;
                      });
                    },
                  ),
                  Text(
                    'ఎంచుకున్న పూర్తి వయస్సులు: ${_range.from}–${_range.to} • అంశాలు: ${selected.length}',
                    key: const ValueKey('bnn-result-scope'),
                  ),
                  _natalResults(selected),
                  const Divider(),
                  const Text(
                    'వయస్సు ఆధారంగా కాల పరిశీలన',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                  ),
                  const Text(
                    'భావసంబంధం మాత్రమే ఉన్నచోట సంఘటనను నిర్ధారించలేదు. సరిపోలిన మూల నియమాలకు సాఫల్యం ఆటోమేటిక్‌గా కనిపిస్తుంది. తక్కువ మద్దతు ఉన్న కాలాలు కూడా కనిపిస్తాయి.',
                  ),
                  for (final event in selected) ...[
                    if (event.sensitive)
                      Padding(
                        padding: const EdgeInsets.all(8),
                        child: Text(
                          '${event.title}: జాగ్రత్త అవసరం అనే పరిశీలన మాత్రమే; తేదీ/వయస్సు/శాతం ఇవ్వలేదు.',
                        ),
                      ),
                    if (!event.sensitive)
                      ExpansionTile(
                        key: ValueKey('topic-results-${event.id}'),
                        initiallyExpanded: selected.length == 1,
                        title: Text(
                          event.title,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          '${windows.length} కాలాలు • టచ్ చేసి చూడండి',
                        ),
                        children: [
                          if (windows.any(
                            (w) => w.events
                                .firstWhere((e) => e.event.id == event.id)
                                .sourceRules
                                .isNotEmpty,
                          )) ...[
                            const Text(
                              'మూల నియమ సూచన కనిపించిన కాలాలు:',
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                            Text(
                              windows
                                  .where(
                                    (w) => w.events
                                        .firstWhere(
                                          (e) => e.event.id == event.id,
                                        )
                                        .sourceRules
                                        .isNotEmpty,
                                  )
                                  .map((w) => '${w.ageFrom}–${w.ageTo}')
                                  .join(', '),
                            ),
                          ],
                          for (final w in windows.take(_limit))
                            _windowRow(
                              w,
                              w.events.firstWhere(
                                (e) => e.event.id == event.id,
                              ),
                            ),
                          if (windows.length > _limit)
                            TextButton(
                              onPressed: () {
                                setState(() {
                                  _limit += 10;
                                });
                              },
                              child: Text(
                                'మరిన్ని కాలాలు (${windows.length - _limit})',
                              ),
                            ),
                        ],
                      ),
                  ],
                  ExpansionTile(
                    title: const Text('శాతాల అర్థం'),
                    children: const [
                      Text(
                        'భావసంబంధాల సంఖ్యను శాతంగా చూపడం తొలగించాం. పేజీ 31లోని సాఫల్య శాతం ప్రత్యేక యోగగ్రహం–గోచార సంబంధానికి మాత్రమే. అది సంఘటన జరిగే గణాంక సంభావ్యత కాదు. మూల నియమం ఇవ్వని సంబంధాన్ని 0%గా మార్చలేదు.',
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ],
      ],
    ),
  );
}

class UnifiedEventCard376 extends StatelessWidget {
  final UnifiedEventEvidence376 evidence;
  final bool initiallyExpanded;
  const UnifiedEventCard376({
    super.key,
    required this.evidence,
    this.initiallyExpanded = false,
  });
  @override
  Widget build(BuildContext context) {
    final e = evidence, event = e.event;
    if (event.sensitive)
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text(
          '${event.title}: జాగ్రత్త అవసరం అనే పరిశీలన మాత్రమే; సంఘటన వయస్సు/శాతం ప్రకటించలేదు.',
        ),
      );
    String score(UnifiedChannel376 c) => !c.available
        ? 'మూల గణన అందుబాటులో లేదు'
        : '${c.hits(event).length}/${event.houses.length} భావసంబంధాలు';
    return Material(
      color: e.bothRelated ? const Color(0xFFEAF0F8) : const Color(0xFFF5F5F5),
      child: ExpansionTile(
        key: ValueKey('unified-event-${event.id}'),
        initiallyExpanded: initiallyExpanded,
        title: Text(event.title),
        subtitle: Text(
          'శని ${score(e.saturn)} • గురు ${score(e.jupiter)}\nBCP ${score(e.bcp)} • BSP ${score(e.bsp)}',
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'ప్రధాన భావం ${event.mainHouse}; అనుసంధాన భావాలు ${event.houses.difference({event.mainHouse}).join(", ")}. ఇది యాప్ పరిశీలన మ్యాపింగ్; స్వతంత్ర సంఘటన సూత్రం కాదు.',
                ),
                Text(
                  e.bothRelated
                      ? 'రెండింటికీ ఈ సంఘటన భావసంబంధం ఉంది; ఉమ్మడి భావాలు: ${e.commonHouses.isEmpty ? "వేర్వేరు ప్రధాన/అనుసంధాన భావాలు" : e.commonHouses.join(", ")}'
                      : 'రెండింటికీ ఉమ్మడి సంఘటన సంబంధం ఇప్పటికి సరిపోలలేదు; విడి సూచనలను తొలగించలేదు.',
                ),
                for (final channel in [e.saturn, e.jupiter, e.bcp, e.bsp]) ...[
                  Text(
                    '${channel.name}: ప్రత్యక్ష భావాలు ${channel.directHouses.join(", ")}; అనుసంధాన భావాలు ${channel.linkedHouses.join(", ")}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  for (final trace in channel.traces) Text(trace),
                ],
                for (final source in e.sourceRules)
                  Container(
                    padding: const EdgeInsets.all(8),
                    color: const Color(0xFFE1F2E8),
                    child: Text(source),
                  ),
                for (final warning in e.cautions)
                  Text(
                    warning,
                    style: const TextStyle(color: Color(0xFF9C2252)),
                  ),
                const Text(
                  'ఒకే భావం పలుమార్లు వచ్చినా ఒక్కసారి మాత్రమే కవరేజ్‌లో లెక్కించాం. పద్ధతుల శాతాలు కలిపి మొత్తం చేయలేదు. '
                  'భావసంబంధం తక్కువగా ఉన్నా ప్రత్యేక మూల నియమం కనిపిస్తే దాన్ని దాచలేదు. '
                  'జన్మ మూల సంఘటన నియమం, సందర్భం, గోచారం కలవకుండా సంఘటన జరిగిందని/జరుగుతుందని నిర్ణయించలేదు. '
                  'మంచి–చెడు BNN జన్మ సూచనలు కింది గ్రహ కలయికల కార్డుల్లో విడిగానే ఉంటాయి. పరిహారం కల్పించలేదు.',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
