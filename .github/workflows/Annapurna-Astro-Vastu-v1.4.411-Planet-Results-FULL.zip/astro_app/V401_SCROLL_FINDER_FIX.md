# v401 modal scroll finder correction

GitHub v400 run 43560297880 reached the widget suite and passed 191 tests. Its three remaining failures were StateError: Too many elements in scrollUntilVisible. The keyed ListView contains SelectableText widgets, which create their own nested Scrollables.

The test now chooses the first vertical Scrollable under the keyed modal ListView, so scrollUntilVisible receives exactly the outer list instead of all nested text scroll areas. The below-chart result assertions, modal/conclusion assertions, real footer scrolling and footer visibility assertion are all retained. No tests or rule checks are disabled. Product rule logic is byte-for-byte unchanged.

The compact LZMA packaging and workflow size guard are retained. Local validation covers Dart parsing/formatting, cumulative ZIP extraction/checksums and every CI path. Flutter is unavailable locally; the corrected widget tests and APK compilation must run on GitHub.
