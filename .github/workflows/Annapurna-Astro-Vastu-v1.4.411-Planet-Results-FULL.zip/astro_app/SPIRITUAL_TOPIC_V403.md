# v403 - spirituality results in the four-chart review

The existing spirituality topic now connects D1 / D9 / D20 / D24 to calculated reports. Each chart has its own visible result and rule/source/placement inspection. The combined card separates practice/consistency, guru guidance, detachment and study. No 0/4 chart-presence percentage is presented as an event probability.

D20 is the principal practice chart. D1 and D9 are supporting contexts. D24 uses selected existing education-engine checks strictly as study context, without counting them as attainment or liberation. All contrary observations remain visible.

## Sources and condition scope

- Supplied Mallikarjuna 255 Rules catalog: original spirituality chart order and D20 IDs retained. The directly computable Ketu-in-lagna-or-twelfth branch is evaluated. The complete strength requirements in D20-001/002 remain disclosed; no invented Shadbala or Rajayoga threshold replaces them.
- Supplied Sarala 7 final.pdf, PDF page 12: visually checked. The text discusses achievement/practice, the fifth from Karakamsa, ninth-house guidance and fourth-house steadiness. Its Karakamsa-based statements are not silently equated with D20 lagna-based app contact checks. The latter have APP IDs and explicit reference labels.
- Existing JaiminiService supplies the exact seven-classical-planet AK and D9 Karakamsa. Degree ties block the Karakamsa-dependent report. Existing J1Q1-C19/C23 position branches are labelled as registry-derived guidance/study indications; the outputs do not judge a person's morality or actual beliefs.
- P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach, section 7.3.6, printed page 72 / PDF page 84: visually verified against the author's PDF. The precise Ketu-in-the-twelfth-from-D9-Karakamsa clause is evaluated. The twelfth-house occupants are displayed as devotional reference planets; no deity, mantra count or strongest-planet prescription is invented.
  https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf

The summary classification is APP-SPIRIT-REVIEW-403. Mixed/absent principal indications stay mixed. An opposite one-sided D1/D9 grade makes the summary mixed. D24 context does not override the principal report. No certainty of mantra siddhi, samadhi, initiation, liberation or a date is asserted.

## Validation

New spiritual verifier: 2,264 checks passed, including D20 mapping, every relative Karakamsa/Ketu placement, AK degree ties, full-strength unknowns, missing input, D24 scope and principal/support convergence. Existing health, multi-topic, marital stability, property, education and source-bridge pure verifiers passed. Flutter tests reuse the working scoped outer-scroll pattern and check all four below-chart results, taps, sources and narrow-screen Telugu text. Flutter is unavailable locally; widget tests and APK compilation run in GitHub.

The cumulative workflow remains below the 450,000-byte local guard. Source extraction, checksums and CI paths are verified. All earlier features and source files outside this change remain unchanged.
