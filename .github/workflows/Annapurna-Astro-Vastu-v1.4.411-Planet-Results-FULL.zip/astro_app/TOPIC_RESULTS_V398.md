# Annapurna v1.4.398 - children, foreign links, court/dispute review

## Delivered behavior

- Children: D1 / D7 / D9 cards now use the source-linked report. The separate Saptamsha PDF page 15 alternatives (conjunction, mutual aspect, exchange) are tested individually. Fifth-lord 6/8/12 and D7 lagna support/pressure are recorded. D9 dignity is explicitly contextual, never a borrowed marriage/progeny prediction.
- Foreign links: D1 / D9 / D10 / D4 preserve their order. The existing complete seven-condition D10 foreign-employment gate is reused. Phaladeepika 5.9 separates away-from-birthplace income from home-country indications. D1 tenth-lord navamsa in a fixed sign is checked. D2-OT-004 is a D1 property predicate displayed under the housing context, not silently rewritten as a D4 IF. International tourism, work, home ownership and permanent immigration permission are not equated.
- Court/disputes: D1 clauses from Phaladeepika 16.16 and a conservative conjunctive reading of 6.63 produce an attributed natal dispute review. D6 and D30 show calculated contacts with APP IDs as context, not independent book-derived legal victory votes. D6 uses the already selected optional P.V.R. Narasimha Rao construction.
- Every chart has a visible result. Tap opens the original condition, actual placements, match/non-match, source, counter-indications, and remedy-source status. The compact summary opens the same inspection.
- No chart-count percentage is displayed for these reports. A context check marked recorded is not counted as a favorable event promise.

## Sources checked

1. Supplied Saptamsha_Santana_Niyamalu.pdf: page 15 was rendered and visually checked; pages 16-20 were inspected for surrounding context. Earlier page-1 D1 clauses remain in their original D1 chapter scope.
2. Supplied Mallikarjuna 255 Rules catalog: D7 IDs retained. D7-001 now shows natal degrees and six-varga dignity audit while leaving the undefined complete strength threshold honest. D7-002/003 are historical reference rows and do not predict a child's sex. D7-006 exposes the computed conjunction/aspect AND subcheck separately under an APP ID without presenting pregnancy-risk diagnosis. D7-004 no longer treats every Moon/Mercury as unconditionally benefic.
3. Supplied D10 special.pdf: existing audited seven-check evaluator reused without an OR shortcut.
4. Supplied D2 property registry: D2-OT-004 retained with its complete original condition.
5. Supplied kp_rules_rule_based.html: KP-005 and KP-012 were read. Their cusp/sub-lord and supporting-significator prerequisites cannot be supplied by ordinary sign placements, and their missing special inputs remain visible. KP-012 is appeal admission, not a whole-case winning rule.
6. Mantreswara, Phaladeepika, chapter 5.9 (printed page 53), chapter 6.63 (printed page 79), chapter 16.16 (printed page 158). The last two were checked against rendered pages, including the cautionary commentary on Harsha. Source: https://lakshminarayanlenasia.com/articles/phaldipika.pdf

## Scope and verification

The combined good/caution/mixed classification is explicitly APP-TOPIC-REVIEW-398, not an invented classical verse. An unfulfilled supportive IF is not converted into an adverse result. Unknown strength or KP inputs do not become confirmed positives. Court verdicts, visa decisions, fertility diagnoses and unborn-child sex are not inferred.

Local pure Dart verification: new v398 verifier 5,925 checks, plus existing v397 / v396 / v395 / v394 / v393 / v390 regression verifiers passed. Added Flutter tests cover routing, source-only D7 rows, below-chart results, tap inspection, and narrow-screen Telugu text. Flutter is unavailable locally; the upload workflow runs these widget tests and the Android build on GitHub.

The workflow contains the full cumulative update over the verified v375 baseline and retains the previous BNN, financial, education, property, marriage and career work. It requires the existing root baseline ZIP; it is not a separately prebuilt APK.
