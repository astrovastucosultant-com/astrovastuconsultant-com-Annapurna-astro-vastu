# v399 build correction

GitHub v398 run 43542714108 compiled the Flutter test suite and passed 191 tests. Three topic-result tests failed because they searched for a footer before scrolling the lazily built inspection ListView. The APK build step was therefore skipped. The separate old (5).yml workflow was a successful no-op with no artifacts.

The correction gives the modal inspection ListView a stable topic-specific key. Each of the three tests verifies the opened modal and initial conclusion, scrolls the correct modal Scrollable until its footer is built, and then asserts that the footer is visible. Existing source rules, below-chart result assertions and the full regression suite are retained. No tests are removed or bypassed.

Local checks: Dart syntax formatted, cumulative source/checksum extraction verified. Local Flutter is unavailable; corrected widget tests and APK compilation must run in GitHub.
