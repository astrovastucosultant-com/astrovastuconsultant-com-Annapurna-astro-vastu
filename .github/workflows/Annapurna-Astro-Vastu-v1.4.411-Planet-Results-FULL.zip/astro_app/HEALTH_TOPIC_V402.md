# v402 - D27 and D12 in the health review

## Visible behavior

The health topic now uses D1, D6, D27, D12, D30 in that order. Each chart has a visible assessment and tap-to-rule inspection. The original 255-rule workflow remains unchanged in its source catalog; D27/D12 are explicitly USER-HEALTH-EXTENSION-402, requested by the user. No chart-count event/illness probability is shown.

- D1: lagna lord, sixth house/lord, defined Jupiter/Venus support and other-planet pressure contacts.
- D6: the selected optional P.V.R. Narasimha Rao construction, sixth-lord context, and the complete Mars AND Rahu sixth-house clause. The source's undefined complete weakness prerequisite remains a separately disclosed condition.
- D27: existing common Panchadha Maitri engine with temporary friendship derived from D1; own/exaltation/debilitation observations; all seven classical planets; the source Jupiter AND Mars in lagna clause. Partial sign-dignity observations are explicitly APP checks, not a fabricated complete Shadbala match. Nodes receive no invented Panchadha values.
- D27 inspection also includes D1/D3 placement and the existing first/second five-degree location convention, plus 22nd Drekkana from lagna and 64th Navamsa from Moon reference lords. These do not declare organ disease, severity, clinical risk or dates.
- D12: parental/lineage placements, fourth/ninth lords, and existing source clauses about Sun/Moon parental relationships. Contextual 6/8/12 placements are recorded. These relationship clauses are NOT rewritten into genetic-disease predicates. Missing actual family medical history is disclosed independently of the completed chart calculations.
- D30: computed pressure/support contacts as additional context; no case count or severity vote.

## Source review

1. Supplied Sarala 7 final.pdf: visually inspected PDF pp.9-10 (D12) and pp.13-14 (D27). The D12 passage addresses parents, childhood, relationships and legacy. The D27 passage discusses traditional significators and affliction; undefined dominance/strength terms were not assigned invented numeric thresholds.
2. Supplied D12.pdf: PDF p.18 / printed p.307 visually verified. The Sun/Moon affliction clause concerns parental affection; it is not a hereditary-disease rule. Existing D12-REL-03/04 evaluations were reused in that original relationship scope.
3. Supplied Annapurna_D12_Corrected_16Rules_4Step_Reviewed_v2.zip: the structured rule facts were read. They concern ancestry, parents and legacy and do not establish a clinical hereditary-disease rule.
4. Existing Mallikarjuna 255 catalog D27 pp.17 and D6 p.6: exact conjunction clauses used, broad strength qualifiers retained as source conditions.
5. P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach, Table 11, printed pp.60-61 / PDF pp.72-73; PDF p.73 visually checked. D12 is parents/blood relatives; D27 is strengths/weaknesses. D27 construction checked against section 6.2.16.
   https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf
6. NIH MedlinePlus Genetics, Family Health History / diagnosis. Family health history and relevant medical evaluation are needed to assess inherited conditions. A chart placement is not a substitute for that information.
   https://medlineplus.gov/genetics/understanding/inheritance/familyhistory/
   https://medlineplus.gov/genetics/understanding/consult/diagnosis/

## Verification

New pure-Dart health verifier: 2,813 checks passed. Existing v398 topics, v397 marital stability, v396 property, v395 education and v393 source checks passed. Added Flutter tests verify all five chart results, D27/D12 routing, result tap, the correct outer modal scroll and large Telugu text. Local Flutter is unavailable; widget tests and APK compilation run on GitHub. The v401 nested-scroll fix remains.

The compact cumulative workflow has a local size guard below 450,000 bytes and verified source extraction/checksums. No existing rule engine or feature is removed.
