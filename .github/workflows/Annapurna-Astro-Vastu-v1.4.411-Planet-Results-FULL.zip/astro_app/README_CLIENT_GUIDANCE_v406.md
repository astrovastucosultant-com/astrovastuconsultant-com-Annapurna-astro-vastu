v406 - User priority: health and children topic-specific devotional support.
Scope: VARGA-CROSS-007 and VARGA-CROSS-005. All other topics remain as v405.
PVR section34.5/Table78 associates deities with divisional lagna lords for the related life domain. https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf
Primary D6 for health and D7 for children is explicit APP topic prioritization. One form from Table78 alternatives is displayed using an APP purpose-based preference, not a claim that it is the exclusive or clinically effective deity. No planet strength/risk ranking is invented.
Original report grades, original conclusions, original checks, body-region maps and v405 spirituality guidance are preserved. Added deity checks are contextual only. In health D12/D30 do not generate disease/deity prescriptions. Missing chart data produces no chart-derived recommendation. Attachment is idempotent.
Dhanvantari general health prayer tradition: TTD 13Dec2020 https://news.tirumala.org/karthika-masa-deeksha-pujas-concludes-with-sri-dhanwantari-puja/
Santana Gopala general children prayer tradition: https://sanskritdocuments.org/doc_vishhnu/santaanagopaala.html
Both are labeled common cultural alternatives, not chart-derived primary planets. No raw initiatory mantras, nyasa, counts, costly rituals, outcome deadline, child sex/number prediction, blame, hereditary diagnosis, or cure guarantee.
Prayer/regular practice teaching: https://vijayayatra.sringeri.net/archiveyatra/mahadanapuram-june-9-10-2012/
Medical action is separate: ongoing health care; both partners seek fertility advice for conception concerns. WHO2025 Chapter3 https://www.ncbi.nlm.nih.gov/books/NBK620430/
Priority card appears before the original grade/conclusion inside each topic, with rule/source examination on tap. Each chart separately carries deity guidance/context. It is not the final D9 Ishta Devata decision and it does not add a new unverified Mahavidya-to-planet table.
Pure Dart checks passed locally. Flutter tests and APK require GitHub CI after workflow upload.
