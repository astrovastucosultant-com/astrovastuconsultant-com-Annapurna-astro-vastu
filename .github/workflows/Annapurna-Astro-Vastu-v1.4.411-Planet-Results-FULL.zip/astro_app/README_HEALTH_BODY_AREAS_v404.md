v404: Per-chart traditional zodiac/body reference for D1,D6,D27,D12,D30.
Source: P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach, printed p21/PDF p33.
https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf
Mapping Aries..Pisces: head,face,arms,heart,stomach,hip,below navel,private parts,thighs,knees,ankles,feet.
Divisional use and selection are APP-BODY-404 application rules, not a medical inference or quoted disease rule.
D1/D6: L1/L6 in H6/8/12 or other malefic contact. D27: seven classical planets with debility, enemy compound relation or other malefic contact. Nodes conjunction only; no self affliction.
D12: Sun/Moon/4L/9L symbolic family context, never inherited disease. D30: L1 trika/contact and malefic lagna contacts, context only.
Groups use occupied SIGN, never HOUSE, deduplicated with actual placement trace. No percentage, disease severity, clinical organ-risk assessment, vitamin or medication advice. No change to v402 health grade.
Local: Dart pure verifiers passed. Flutter widget/build validation deferred to GitHub CI.
