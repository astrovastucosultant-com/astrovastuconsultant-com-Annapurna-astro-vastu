# Annapurna Wealth v410

User priorities: keep original wealth-level terminology and results, show applied yoga counts, money forms, people/channels for gains and losses, dasha indications and guidance. Preserve D1 common foundation plus separate Parashara D2 / Labha-Manduka / Indu views.

## Source preservation
The source registry actually has 58 distinct rules, not the historically stated 59. All 58 exact conditions and results are available in the detailed review; the validator compares every original string. Four traditional level names remain literal, with all matching conditions visible. Level terms are not converted into present currency thresholds. Strength and adverse-association operational tests are explicitly labelled APP screening, not full Shadbala or newly verified Goel quotations.

D1 and Indu each enumerate distinct 2/5/9/11-lord pairs; repeated house roles do not create self-pairs. A global union counts the same pair once across references. Six named source/application yoga tests are counted separately from graha pairs; this is not a count of every yoga in all texts. Gains, holdings, inheritance, property, vehicles, investment, foreign income and losses retain separate source rows. Unknown Hora second-lord semantics, medium strength and undated transits remain unresolved.

## New user class material (2026-11-14)
Goel Hora summary: Parashara D2 gives dasha effort/softness; 15-degree intra-Hora positions are split into three five-degree bands, resets at15 degrees. No fabricated linear strength percentages. Exact Sun camp Leo/Virgo/Libra/Scorpio/Sagittarius/Capricorn; remaining signs Moon camp. Direct maximum-effort and soft examples are preserved. Labha-Manduka construction same sign / eleventh sign is now explicitly supplied by user class. Self-effort3 and luck9 links, benefic well-placed second lord and 2/12 finance/expenses are displayed in their own source section and corresponding chart inspections. Relationship OR and positional-strength implementations are disclosed.

Money-flow summary is separately attributed to user with timestamps29:41–31:33,1:13:03–1:14:45,1:50:36–1:50:46. Identify actual D1 second-lord/occupants/aspect senders. Mars-South only for Mars candidates. No invented planet objects, generic directions or principal-claimant ranking formula; source examples are not automatically applied to everyone.

## Additional web sources
- PVR official freely shared textbook, sections11.9/11.10: exalted benefic second-house result, Mars/Saturn second-house loss with Mercury-aspect exception and Sun/Saturn second-house loss. https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf
- Phaladeepika5.1–8: person mappings and tenth-lord Navamsa dispositor livelihood. Lagna/Moon/Sun branches stay separate when stronger reference is uncomputed; no invented reference ranking. Ch6 Lakshmi and Vasumati (the latter with explicit APP Mercury/Jupiter/Venus set). https://lakshminarayanlenasia.com/articles/phaldipika.pdf
- MahaVastu official2022 Deepawali PDF, PDF page4: North silver horses/green scenery, East property-document/village-picture suggestions, SE golden Lakshmi idol after the2022puja. Context preserved, historical timing not reused; idol never silently becomes Mahavidya photo. https://mahavastu.com/wp-content/uploads/2022/10/MahaVastu-Deepawali22-Remedies-English_Generic_V2.pdf
- Official Mahaversity Tantra page mentions Mahavidya framework but does not expose complete ten-photo zone allocations. https://mahaversity.mahavastu.com/course/tantra-mahavastu-remedies
- User supplied https://www.youtube.com/watch?v=LUnzz9kYp5c ; direct fetch throttled, alternate retrieval unavailable, exact ID searches empty. Content not claimed watched. Its ten-deity/photo/zone mapping remains pending transcript/timestamp evidence; unrelated web tables not substituted.

Dasha dates reuse existing DashaService Vimshottari and natal JulianDay UTC (365.2425-day year), display IST date boundaries. Per-planet Indu gain/loss indicators and first nine Mahadashas are disclosed as birth-chart indications, not transit-confirmed final event dates.

## UI
Top full wealth report replaces blanket mixed-only summary;12 separate sections open exact rule/examination/result/source. Existing four chart inspections retained; chart previews shortened, narrow mobile uses one column. Source-only guidance is labelled separately from applied main predicates.

## Validation
New pure Dart validator:87172 checks; all four ST levels exercised, including highest and retention-risk cases. Prior wealth409:10884checks; vehicle408:6637; fame407:4875; guidance406:10483; deity405:3331; topics398:5925 pass. New pure module analysis: no issues. Flutter tests for every source section,320px large text and prior chart navigation included in CI. Local Flutter unavailable; widget tests and APK remain pending GitHubActions.
