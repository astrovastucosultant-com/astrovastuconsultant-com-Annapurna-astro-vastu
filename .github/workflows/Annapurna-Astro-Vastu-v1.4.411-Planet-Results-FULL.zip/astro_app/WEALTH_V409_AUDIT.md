# Wealth v409

D1 is one common foundation; three separate reviews are Parashara D2, Labha-Manduka/Mihira Hora and Indu Lagna. Indu reuses original D1 positions with an independently calculated reference ascendant. No fictitious varga factors, chart voting or wealth probability.

Labha calculation: first 15 degrees same sign; second half eleventh sign (index +10). PJC Mihira Hora table explicitly distinguishes this from ordinary Manduka and notes the JHora Labha-Manduka name: https://pjc2.parasarahora.in/varga/hora-d2/mihira-hora/ . This teacher does NOT endorse using that variant for wealth. Application of the user's LB001/002 to this requested variant is therefore separately labelled APP-LABHA, not source-verified classical confirmation. The original 59-rule registry and its unresolved-method flags remain intact.

D2-CS-004/005 remain unresolved because the original second lord/hora definition is ambiguous. The D1 second lord in selected Parashara D2 is separately contextual APP evidence. No missing conditions become true. No nodal exaltations or node aspects invented. Moon benefic membership requires waxing phase. No self relationships.

Indu formula uses ninth lords from D1 ascendant and Moon, source kala values, zero remainder as twelve, inclusive counting from Moon. Source Indu rules are separately evaluated; current dasha dates and specific asset types are not inferred.

D2 deity association uses existing PVR section34.5/Table78 mapping, with first-form selection explicitly APP preference. General Lakshmi/Kamalatmika prayer is an optional cultural alternative, not a computed personal Ishta deity. Practical budgeting/saving/responsible borrowing source: https://www.rbi.org.in/FinancialEducation/fame.aspx . No profit, amount, investment or ritual guarantees.

Validation: verify_wealth_topic_v409.dart passes 10884 checks including all 144 ascendant/Moon combinations and source boundaries. Existing v408,407,406,405,398 pure Dart regressions pass (6637/4875/10483/3331/5925). Flutter UI tests (four separate inspections, 320px/large Telugu text, 17-topic integration) are included in CI; local Flutter unavailable, so UI/APK validation remains pending GitHub Actions.
