# BNN Life Event Timing v1.4.371 — Phase 2

This release does **not** promise that a planetary period is a confirmed
life-event date. It adds traceable, distinct crosschecks for five event types:
Higher education (D24), career entry (D10), marriage (D9), children (D7),
and house/property (D4). The remaining 23 catalog topics are unchanged.

## Conditions and traceability

1. The existing source-backed varga rule evaluator must yield a genuinely
   applicable, favorable, *auto-evaluated* rule with an event-specific ID.
2. D1 event house lord and the corresponding varga house lord are calculated
   from actual chart signs. A running Vimshottari MD and AD must contain an
   event lord and relevant karakas; MD/AD dates come from the existing DashaService.
3. At sampled MD/AD checkpoints, actual sidereal transit longitudes of Jupiter
   and Saturn are queried through existing Swiss Ephemeris/Moshier
   AstroCalculationService using the birth-data ayanamsa. Classical sign-level
   conjunction/Parashari aspects are checked against the D1 event house sign.
4. A sample that passes all three layers can be shown as a PRIMARY
   *astrological review date/age*, with up to two further candidates and
   explicit source rule, dasha lords, transit signs. It is not a validated
   prediction and not an exact ingress/egress window.
5. We do not calculate Moon day triggers or source-specific dasha timing beyond
   these checks in v371. There is no prediction for longevity, death,
   accident, severe illness, or relatives' bereavement.

## Important limitations

- Three checkpoints per qualifying MD/AD; the search is a *sample*, not an
  exhaustive transit scan. A negative result does not imply an event cannot
  happen. The window is still a future work item.
- D1/Dn house placement plus one supporting source rule is necessary but does
  not scientifically demonstrate predictive validity. Results must be
  evaluated on known historical event dates and held-out charts.
- As originally requested, use the full chain: actual verified event IF-THEN,
  multi-varga audit, dasha, real transit, Moon's final trigger. v371 implements
  only the first operational crosscheck and leaves uncovered topics pending.
- All supplied original source files remain in the archive. No invented
  remedies or survival/death ages have been inserted.
