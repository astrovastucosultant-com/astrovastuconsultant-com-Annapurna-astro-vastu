# BNN v1.4.370 — Life Event Evidence Gate and Age Display Audit

## Scope
* 28 events remain the original v369 review catalog; no new unsupported event predictions.
* Jupiter and Saturn age intersections are **technical contact observations**, NOT event results.
* Every event's headline says timing is pending unless an independently traceable event source, natal/varga rule, dasha and real ephemeris transit corroboration are available.
* Event-scope review ages are purely editorial display focus, never an inference that events cannot occur outside that range.
* Only the current technical window list is filtered; raw candidates retained with provenance in the service.
* Sensitive domains stay without age predictions (accident, bereavement, longevity, health).
* Existing v369 regression tests must continue to pass; new v370 tests exercise evidence gate and collapsed timing UI.

## Example issues fixed
* Higher education 0–1 no longer rendered as a highlighted life-event age; raw coincidence retained only as an audit record outside the UI focus.
* Career change at 92 no longer highlighted in main life-event interface. This exclusion is not a scientific or astrological impossibility claim.
* Same Jupiter/Saturn contact cannot automatically become validated age for 10 unrelated events.

## Technical limitations (not completed)
* D10, D24 and other varga IF–THEN evaluation is not integrated into event-age inference.
* Dasha layers and Swiss Ephemeris real transit date matching are not connected to the new evidence gate.
* No birth date to real-calendar-date event conversion is asserted.
* There is NO verified final event age prediction from this version. A pending status is intentional.

## Files changed
- lib/astrology/bnn_life_event_timing_service.dart
- lib/screens/bnn_life_events_panel.dart
- assets/life_events/life_event_review_catalog_v369.json
- test/bnn_life_event_evidence_gate_v370_test.dart
- pubspec.yaml

## Build
Run `flutter test --no-pub` (selected BNN test list) and `flutter build apk --release` via build-bnn-v370.yml. Local environment does not have Flutter SDK, so no local compile assertion is made.
