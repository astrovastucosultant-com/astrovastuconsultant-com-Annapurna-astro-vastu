import 'package:flutter/material.dart';

import '../astrology/bnn_financial_evidence_v373.dart';
import '../astrology/bnn_financial_timing_v374.dart';
import 'bnn_financial_timing_panel_v374.dart';

class BnnFinancialCardV373 extends StatelessWidget {
  final BnnFinancialAssessment assessment;
  final Future<FinancialTimingResult> Function()? loadTiming;
  const BnnFinancialCardV373({
    super.key,
    required this.assessment,
    this.loadTiming,
  });

  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white,
    margin: const EdgeInsets.symmetric(vertical: 4),
    child: ExpansionTile(
      key: ValueKey('bnn-life-${assessment.eventId}'),
      title: Text(
        BnnFinancialEvidenceServiceV373.titles[assessment.eventId]!,
        style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
      ),
      subtitle: Text(
        '${assessment.statusText} • దశ–గోచార పరిశీలన',
        style: const TextStyle(fontSize: 11.5),
      ),
      childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 13),
      children: [
        const Text(
          'మూల రూల్‌కు అవసరమైన D1, ఇందు లగ్నం, హోరా ఆధారాలను '
          'వాటి వాటి షరతుల ప్రకారం పరిశీలించాలి. D2 ఒక్కటితో తుది నిర్ణయం చేయరాదు.',
          style: TextStyle(fontSize: 12.5, height: 1.45),
        ),
        for (final hit in assessment.matches) _rule(hit),
        if (assessment.matches.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text(assessment.statusText),
          ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text(
            loadTiming == null
                ? assessment.timingText
                : 'వర్తించిన రూల్ గ్రహాలకు దశ–గోచార కాల పరిశీలన క్రింద అందుబాటులో ఉంది. '
                      'మూల షరతు సరిపోవడం మాత్రమే తేదీ నిర్ధారణ కాదు.',
            key: ValueKey('bnn-finance-timing-${assessment.eventId}'),
            style: const TextStyle(
              fontSize: 12.5,
              height: 1.45,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        if (loadTiming != null && assessment.matches.isNotEmpty)
          BnnFinancialTimingPanelV374(
            key: ValueKey(assessment),
            load: loadTiming!,
          ),
        if (assessment.hasRequiredInputs &&
            assessment.unmatchedRuleIds.isNotEmpty)
          Text(
            'వర్తించలేదు: ${assessment.unmatchedRuleIds.join(', ')}',
            style: const TextStyle(fontSize: 11.5),
          ),
        if (assessment.pendingRules.isNotEmpty)
          ExpansionTile(
            title: const Text(
              'పూర్తి గణనకు కావలసిన ఆధారాలు',
              style: TextStyle(fontSize: 12.5),
            ),
            children: [
              for (final entry in assessment.pendingRules.entries)
                ListTile(
                  dense: true,
                  title: Text(entry.key),
                  subtitle: Text('గణనకు సమాచారం లేదు: ${entry.value}'),
                ),
            ],
          ),
      ],
    ),
  );

  Widget _rule(BnnFinancialEvidence hit) {
    final color = switch (hit.tone) {
      BnnFinancialTone.favorable => const Color(0xFFE1F2E8),
      BnnFinancialTone.unfavorable => const Color(0xFFFCE4EC),
      BnnFinancialTone.neutral => const Color(0xFFF1F4F7),
    };
    return Padding(
      key: ValueKey('bnn-finance-${assessment.eventId}-${hit.rule.id}'),
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Material(
        color: color,
        borderRadius: BorderRadius.circular(9),
        clipBehavior: Clip.antiAlias,
        child: ExpansionTile(
          title: Text(
            '1. రూల్: ${hit.rule.id} • ${hit.rule.name}',
            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
          ),
          childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
          children: [
            Text(
              'IF: ${hit.rule.condition}\nTHEN: ${hit.rule.result}',
              style: const TextStyle(fontSize: 12.5, height: 1.45),
            ),
            Text(
              'మూలం: Dhana_Aasthi_Rules.pdf • page ${hit.rule.sourcePage}\n'
              'పరిశీలన చక్రం: ${hit.rule.sourceChart}',
              style: const TextStyle(fontSize: 11.5),
            ),
            ExpansionTile(
              title: const Text('2. జాతక పరిశీలన'),
              children: [
                Text(hit.inspection, style: const TextStyle(fontSize: 12.5)),
                ExpansionTile(
                  title: const Text('3. హైలైట్ ఫలితం'),
                  children: [
                    Text(
                      hit.rule.result,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const Text(
                      'ఇది జాతక మూల షరతు సూచన; సంఘటన జరిగినట్లు '
                      'లేదా జరిగే తేదీగా నిర్ధారించలేదు.',
                    ),
                    if (hit.rule.note.isNotEmpty) Text(hit.rule.note),
                    const ExpansionTile(
                      title: Text('4. పరిహారం'),
                      children: [
                        Padding(
                          padding: EdgeInsets.all(8),
                          child: Text(
                            'ఈ మూల PDFలో ప్రత్యేక పరిహారం ఇవ్వలేదు. '
                            'ఈ రూల్‌కు ధృవీకరించిన పరిహారం జతకాలేదు.',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
