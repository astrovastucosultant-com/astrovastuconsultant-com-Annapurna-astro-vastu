import 'dart:convert';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../astrology/astro_models.dart';
import '../astrology/astro_calculation_service.dart';
import '../astrology/bnn_unified_evidence_v376.dart';
import '../models/birth_data.dart';

class UnifiedCatalog376 {
  final List<UnifiedEvent376> events;
  final List<Map<String, dynamic>> sources;
  const UnifiedCatalog376(this.events, this.sources);
  static Future<UnifiedCatalog376> load() async {
    final raw = await Future.wait([
      rootBundle.loadString(
        'assets/life_events/bnn_unified_event_mapping_v376.json',
      ),
      rootBundle.loadString(
        'assets/bnn/bnn_cycle_contact_interpretations_v357.json',
      ),
    ]);
    final data = jsonDecode(raw[0]) as Map<String, dynamic>;
    if (data['schema'] != 'AAV-BNN-UNIFIED-376')
      throw const FormatException('Invalid unified catalog');
    return UnifiedCatalog376(
      [
        for (final e in data['events'] as List)
          UnifiedEvent376(
            id: e['id'],
            title: e['title'],
            mainHouse: e['main_house'],
            houses: (e['houses'] as List).cast<int>().toSet(),
            ageFrom: (e['age_from'] as num).toDouble(),
            ageTo: (e['age_to'] as num).toDouble(),
            sensitive: e['sensitive'],
          ),
      ],
      (jsonDecode(raw[1])['source_rules'] as List).cast<Map<String, dynamic>>(),
    );
  }
}

class BnnUnifiedEvidencePanel376 extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birth;
  final Future<UnifiedCatalog376>? catalog;
  const BnnUnifiedEvidencePanel376({
    super.key,
    required this.chart,
    required this.birth,
    this.catalog,
  });
  @override
  State<BnnUnifiedEvidencePanel376> createState() => _UnifiedState376();
}

class _UnifiedState376 extends State<BnnUnifiedEvidencePanel376> {
  late Future<UnifiedCatalog376> _catalog;
  late TextEditingController _age;
  late int _selectedAge;
  String _role = 'unknown';
  bool? _job, _married;
  String? _error;
  bool _open = false;
  Future<List<PlanetPosition>>? _transits;
  int _initialAge() {
    final offset = widget.birth.timezoneOffsetHours;
    final now = DateTime.now().toUtc().add(
      Duration(minutes: offset.isFinite ? (offset * 60).round() : 0),
    );
    final birth = widget.birth.localDateTime;
    var n = now.year - birth.year;
    if (now.isBefore(BnnUnifiedEvidenceService376.anniversary(birth, n))) n--;
    return n.clamp(0, 100).toInt();
  }

  @override
  void initState() {
    super.initState();
    _catalog = widget.catalog ?? UnifiedCatalog376.load();
    _selectedAge = _initialAge();
    _age = TextEditingController(text: '$_selectedAge');
  }

  @override
  void didUpdateWidget(covariant BnnUnifiedEvidencePanel376 old) {
    super.didUpdateWidget(old);
    if (!identical(old.chart, widget.chart) ||
        !identical(old.birth, widget.birth) ||
        !identical(old.catalog, widget.catalog)) {
      _catalog = widget.catalog ?? UnifiedCatalog376.load();
      _selectedAge = _initialAge();
      _age.text = '$_selectedAge';
      _transits = null;
      _role = 'unknown';
      _job = null;
      _married = null;
      _error = null;
    }
  }

  @override
  void dispose() {
    _age.dispose();
    super.dispose();
  }

  static String date(DateTime d) => '${d.day}-${d.month}-${d.year}';
  void _apply() {
    final value = int.tryParse(_age.text.trim());
    setState(() {
      if (value == null || value < 0 || value > 100) {
        _error = '0 నుంచి 100 మధ్య పూర్తి వయస్సు ఇవ్వండి';
        return;
      }
      _selectedAge = value;
      _error = null;
      _transits = null;
    });
  }

  Future<List<PlanetPosition>> _loadTransits(DateTime local) async {
    final b = widget.birth;
    if (!b.timezoneOffsetHours.isFinite || b.timezoneOffsetHours.abs() > 14)
      throw StateError('Invalid timezone');
    final utc =
        DateTime.utc(
          local.year,
          local.month,
          local.day,
          local.hour,
          local.minute,
          local.second,
          local.millisecond,
          local.microsecond,
        ).subtract(
          Duration(microseconds: (b.timezoneOffsetHours * 3600000000).round()),
        );
    return Future.wait([
      for (final name in ['Saturn', 'Jupiter', 'Sun', 'Moon'])
        AstroCalculationService.calculatePlanetAtUtc(
          utc: utc,
          planetName: name,
          ayanamsa: b.ayanamsa,
        ),
    ]);
  }

  @override
  Widget build(BuildContext context) => Card(
    key: const ValueKey('bnn-unified-evidence-v376'),
    child: ExpansionTile(
      title: const Text(
        'BNN సంఘటన పరిశీలన — శని • గురు • BCP • BSP',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: const Text('వయస్సు ఎంచుకోండి • ఒకే సంఘటనకు విడివిడి ఆధారాలు'),
      onExpansionChanged: (v) {
        setState(() {
          _open = v;
        });
      },
      childrenPadding: const EdgeInsets.all(12),
      children: [
        if (_open) ...[
          const Text(
            'ప్రతి స్కోరు = సంఘటనకు సూచించిన భావాల్లో సంబంధం ఉన్న భావాల నిష్పత్తి. '
            'ఇది యాప్ భావ కవరేజ్ గణన; మూలగ్రంథం ఇచ్చిన బరువు లేదా సంఘటన జరిగే సంభావ్యత కాదు. '
            'తక్కువ/సున్నా స్కోరు ఉన్న సూచనలూ కనిపిస్తాయి. ఒక మొత్తం శాతం లేదా తుది తేదీ ఇవ్వము.',
          ),
          TextField(
            controller: _age,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: 'పరిశీలించాల్సిన పూర్తి వయస్సు (0–100)',
              errorText: _error,
            ),
          ),
          OutlinedButton(
            onPressed: _apply,
            child: const Text('ఈ వయస్సు పరిశీలించండి'),
          ),
          DropdownButton<String>(
            isExpanded: true,
            value: _role,
            items: const [
              DropdownMenuItem(value: 'unknown', child: Text('పాత్ర: తెలియదు')),
              DropdownMenuItem(value: 'student', child: Text('విద్యార్థి')),
              DropdownMenuItem(value: 'employee', child: Text('ఉద్యోగి')),
              DropdownMenuItem(
                value: 'business',
                child: Text('వ్యాపారి / స్వయం ఉపాధి'),
              ),
              DropdownMenuItem(value: 'other', child: Text('ఇతర స్థితి')),
            ],
            onChanged: (v) {
              if (v != null)
                setState(() {
                  _role = v;
                });
            },
          ),
          DropdownButton<String>(
            isExpanded: true,
            value: _job == null
                ? 'unknown'
                : _job!
                ? 'yes'
                : 'no',
            items: const [
              DropdownMenuItem(
                value: 'unknown',
                child: Text('మొదటి ఉద్యోగం జరిగిందా? తెలియదు'),
              ),
              DropdownMenuItem(
                value: 'yes',
                child: Text('మొదటి ఉద్యోగం ఇప్పటికే జరిగింది'),
              ),
              DropdownMenuItem(
                value: 'no',
                child: Text('మొదటి ఉద్యోగం ఇంకా జరగలేదు'),
              ),
            ],
            onChanged: (v) {
              setState(() {
                _job = v == 'unknown' ? null : v == 'yes';
              });
            },
          ),
          DropdownButton<String>(
            isExpanded: true,
            value: _married == null
                ? 'unknown'
                : _married!
                ? 'yes'
                : 'no',
            items: const [
              DropdownMenuItem(
                value: 'unknown',
                child: Text('వివాహ స్థితి తెలియదు'),
              ),
              DropdownMenuItem(value: 'yes', child: Text('వివాహం జరిగింది')),
              DropdownMenuItem(value: 'no', child: Text('వివాహం జరగలేదు')),
            ],
            onChanged: (v) {
              setState(() {
                _married = v == 'unknown' ? null : v == 'yes';
              });
            },
          ),
          const Text(
            'స్థానం: ఇచ్చిన జన్మస్థలం–లగ్నం ఆధారంగా D1 భావాలు. '
            'పై స్థితులు ఎంచుకున్న వయస్సులో పరిస్థితికి సంబంధించినవి; ప్రస్తుతం ఉన్న స్థితిని గత వయస్సుకు ఆటోమేటిక్‌గా పెట్టలేదు. '
            'ఈ ఎంపికలు ఈ స్క్రీన్ సెషన్‌కే; సేవ్ చేసిన జాతకాన్ని మార్చవు.',
          ),
          FutureBuilder<UnifiedCatalog376>(
            future: _catalog,
            builder: (context, snapshot) {
              if (snapshot.hasError)
                return const Text(
                  'మూల డేటా చదవలేకపోయాం; పరిశీలన పూర్తి కాలేదు.',
                );
              if (!snapshot.hasData)
                return const Padding(
                  padding: EdgeInsets.all(12),
                  child: CircularProgressIndicator(),
                );
              List<UnifiedAgeWindow376> windows;
              try {
                windows = BnnUnifiedEvidenceService376.evaluate(
                  chart: widget.chart,
                  birth: widget.birth.localDateTime,
                  completedAge: _selectedAge,
                  events: snapshot.data!.events,
                  cycleSourceRules: snapshot.data!.sources,
                  context: UnifiedLifeContext376(
                    role: _role,
                    hadFirstJob: _job,
                    married: _married,
                  ),
                );
              } catch (_) {
                return const Text(
                  'గణనకు సమాచారం లేదు: పూర్తి చెల్లుబాటు అయ్యే జన్మ డేటా అవసరం',
                );
              }
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  for (final w in windows) ...[
                    const Divider(),
                    Text(
                      'వయస్సు ${w.ageFrom}–${w.ageTo} • ${date(w.start)} నుంచి ${date(w.end)} వరకు',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      'శని సైకిల్ ${w.saturnCycle} / రాశి ${w.saturnSign + 1} • గురు సైకిల్ ${w.jupiterCycle} / రాశి ${w.jupiterSign + 1} • నడుస్తున్న సంవత్సరం ${w.runningYear}',
                    ),
                    const Text(
                      'వాస్తవంగా కలిసే వయస్సు పరిధి మాత్రమే. ఒకే సైకిల్ సంఖ్య కావాలని నిర్బంధించలేదు.',
                    ),
                    for (final e in w.events) UnifiedEventCard376(evidence: e),
                  ],
                  OutlinedButton(
                    onPressed: () {
                      final pending = Completer<List<PlanetPosition>>();
                      final sample = windows.first.sampledLocal;
                      setState(() {
                        _transits = pending.future;
                      });
                      WidgetsBinding.instance.addPostFrameCallback((_) {
                        if (!mounted) return;
                        pending.complete(
                          Future<List<PlanetPosition>>.sync(
                            () => _loadTransits(sample),
                          ),
                        );
                      });
                    },
                    child: const Text('ఈ వయస్సులో వాస్తవ గోచార నమూనా చూడండి'),
                  ),
                  Text(
                    'నమూనా తేదీ: ${date(windows.first.sampledLocal)}. ఇది పరిధిలోని మధ్య నమూనా మాత్రమే; సంఘటన తేదీ కాదు.',
                  ),
                  if (_transits != null)
                    FutureBuilder<List<PlanetPosition>>(
                      future: _transits,
                      builder: (context, snap) {
                        if (snap.hasError)
                          return const Text(
                            'వాస్తవ గోచార గణన పూర్తి కాలేదు; మళ్లీ ప్రయత్నించండి.',
                          );
                        if (!snap.hasData)
                          return const LinearProgressIndicator();
                        return Text(
                          snap.data!
                              .map(
                                (p) =>
                                    '${p.name}: రాశి ${p.signIndex + 1} • ${p.longitude.toStringAsFixed(2)}°',
                              )
                              .join('\n'),
                        );
                      },
                    ),
                  const Text(
                    'గోచారం / సూర్యుడు / చంద్రుడు: ఈ ఏకీకృత కార్డులకు సంఘటన ప్రత్యేక మూల IF–THEN జతకాలేదు; శాతం కల్పించలేదు. '
                    'లగ్నం: జన్మలగ్నమే భావాల ప్రామాణికం; సంఘటన సమయ లగ్నం గణించలేదు. '
                    'వాస్తవ గ్రహస్థితులు మాత్రమే తుది సంఘటనకు మద్దతుగా లెక్కించలేదు.',
                  ),
                ],
              );
            },
          ),
        ],
      ],
    ),
  );
}

class UnifiedEventCard376 extends StatelessWidget {
  final UnifiedEventEvidence376 evidence;
  const UnifiedEventCard376({super.key, required this.evidence});
  @override
  Widget build(BuildContext context) {
    final e = evidence, event = e.event;
    if (event.sensitive)
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text(
          '${event.title}: జాగ్రత్త అవసరం అనే పరిశీలన మాత్రమే; సంఘటన వయస్సు/శాతం ప్రకటించలేదు.',
        ),
      );
    String score(UnifiedChannel376 c) => c.coverage(event) == null
        ? 'మూల గణన అందుబాటులో లేదు'
        : '${c.coverage(event)!.toStringAsFixed(0)}% (${c.hits(event).length}/${event.houses.length})';
    return Material(
      color: e.bothRelated ? const Color(0xFFEAF0F8) : const Color(0xFFF5F5F5),
      child: ExpansionTile(
        key: ValueKey('unified-event-${event.id}'),
        title: Text(event.title),
        subtitle: Text(
          'శని ${score(e.saturn)} • గురు ${score(e.jupiter)}\nBCP ${score(e.bcp)} • BSP ${score(e.bsp)}',
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'ప్రధాన భావం ${event.mainHouse}; అనుసంధాన భావాలు ${event.houses.difference({event.mainHouse}).join(", ")}. ఇది యాప్ పరిశీలన మ్యాపింగ్; స్వతంత్ర సంఘటన సూత్రం కాదు.',
                ),
                Text(
                  e.bothRelated
                      ? 'రెండింటికీ ఈ సంఘటన భావసంబంధం ఉంది; ఉమ్మడి భావాలు: ${e.commonHouses.isEmpty ? "వేర్వేరు ప్రధాన/అనుసంధాన భావాలు" : e.commonHouses.join(", ")}'
                      : 'రెండింటికీ ఉమ్మడి సంఘటన సంబంధం ఇప్పటికి సరిపోలలేదు; విడి సూచనలను తొలగించలేదు.',
                ),
                for (final channel in [e.saturn, e.jupiter, e.bcp, e.bsp]) ...[
                  Text(
                    '${channel.name}: ప్రత్యక్ష భావాలు ${channel.directHouses.join(", ")}; అనుసంధాన భావాలు ${channel.linkedHouses.join(", ")}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  for (final trace in channel.traces) Text(trace),
                ],
                for (final source in e.sourceRules)
                  Container(
                    padding: const EdgeInsets.all(8),
                    color: const Color(0xFFE1F2E8),
                    child: Text(source),
                  ),
                for (final warning in e.cautions)
                  Text(
                    warning,
                    style: const TextStyle(color: Color(0xFF9C2252)),
                  ),
                const Text(
                  'ఒకే భావం పలుమార్లు వచ్చినా ఒక్కసారి మాత్రమే కవరేజ్‌లో లెక్కించాం. పద్ధతుల శాతాలు కలిపి మొత్తం చేయలేదు. '
                  'భావసంబంధం తక్కువగా ఉన్నా ప్రత్యేక మూల నియమం కనిపిస్తే దాన్ని దాచలేదు. '
                  'జన్మ మూల సంఘటన నియమం, సందర్భం, గోచారం కలవకుండా సంఘటన జరిగిందని/జరుగుతుందని నిర్ణయించలేదు. '
                  'మంచి–చెడు BNN జన్మ సూచనలు కింది గ్రహ కలయికల కార్డుల్లో విడిగానే ఉంటాయి. పరిహారం కల్పించలేదు.',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
