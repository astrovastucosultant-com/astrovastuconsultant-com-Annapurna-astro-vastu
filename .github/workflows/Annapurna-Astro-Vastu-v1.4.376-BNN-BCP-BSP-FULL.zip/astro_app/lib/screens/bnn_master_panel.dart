import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_rashi_rule_service.dart';
import '../astrology/bnn_house_relation_service.dart';
import 'bnn_jupiter_cycles_panel.dart';
import 'bnn_unified_evidence_panel_v376.dart';
import 'bnn_saturn_cycles_panel.dart';
import 'bnn_planet_combinations_panel.dart';
import '../astrology/bphs_lagna_bhava_lord_service.dart';
import '../models/birth_data.dart';
import '../settings/app_font_size_controls.dart';

/// BNN only: Result first, tap for rule + Lagna/Jupiter house checks + source.
/// Does not restore the retired 462 registry.
class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

enum _BnnTone { green, pink, neutral }

class _BnnToneStyle {
  final Color background;
  final Color border;
  final Color text;
  const _BnnToneStyle(this.background, this.border, this.text);
}

_BnnToneStyle _toneStyle(_BnnTone tone) {
  switch (tone) {
    case _BnnTone.green:
      return const _BnnToneStyle(
        Color(0xFFD9F3E0),
        Color(0xFF68AA7A),
        Color(0xFF176A36),
      );
    case _BnnTone.pink:
      return const _BnnToneStyle(
        Color(0xFFFBE6ED),
        Color(0xFFD48AA0),
        Color(0xFF9F3458),
      );
    case _BnnTone.neutral:
      return const _BnnToneStyle(
        Color(0xFFF0F3F5),
        Color(0xFFBDC5CE),
        Color(0xFF344655),
      );
  }
}

// Only explicitly reviewed single-direction texts are color-coded.
// Mixed, ambiguous and OCR-sensitive texts stay neutral — never guessed.
const _greenRashiIds = <String>{
  '001',
  '004',
  '006',
  '008',
  '011',
  '013',
  '014',
  '015',
  '018',
  '019',
  '020',
  '021',
  '032',
  '034',
  '035',
  '036',
  '037',
  '039',
  '040',
  '042',
  '046',
  '049',
  '063',
  '075',
  '078',
};
const _pinkRashiIds = <String>{'051', '052'};
_BnnTone _toneForRashi(String id) {
  final suffix = id.substring(id.length - 3);
  if (_greenRashiIds.contains(suffix)) return _BnnTone.green;
  if (_pinkRashiIds.contains(suffix)) return _BnnTone.pink;
  return _BnnTone.neutral;
}

_BnnTone _toneForSource(String tone) {
  if (tone == 'favorable') return _BnnTone.green;
  if (tone == 'unfavorable') return _BnnTone.pink;
  return _BnnTone.neutral;
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnRashiRule>> _rashiRules =
      BnnRashiRuleService.load();
  late final Future<List<BnnJupiterRelativeRule>> _jupiterRules =
      BnnHouseRelationService.loadVerifiedJupiterRules();
  late final Future<List<BnnLagnaRelativeRule>> _lagnaRules =
      BnnHouseRelationService.loadVerifiedLagnaRules();
  late final Future<List<BphsBhavaLordRule>> _bphsRules =
      BphsLagnaBhavaLordService.loadVerifiedRules();
  bool _showAll = false;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BnnRashiRule>>(
      future: _rashiRules,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Text(
                'BNN రాశి నియమాల డేటా చదవడంలో సమస్య: ${snapshot.error}',
              ),
            ),
          );
        }
        if (!snapshot.hasData) {
          return const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Center(child: CircularProgressIndicator()),
            ),
          );
        }
        final findings = BnnRashiRuleService.evaluate(
          rules: snapshot.data!,
          chart: widget.chart,
          gender: widget.birthData.gender,
        );
        final matching = findings.where((f) => f.matched).toList();
        final results = matching.where((f) => f.canDisplayEffect).toList()
          ..sort(
            (a, b) =>
                _toneForRashi(a.rule.id).index
                    .compareTo(_toneForRashi(b.rule.id).index),
          );
        final locations = BnnHouseRelationService.positions(widget.chart);
        final unused = findings.where((f) => !f.canDisplayEffect).toList();

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              color: const Color(0xFFF2F7F4),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'BNN రాశి ఫలం • BPHS లగ్నం • BNN గురు స్థానఫలం • గురు సైకిల్స్',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '84 రాశి మూల నియమాలు • IF TRUE ${matching.length} • '
                      'ప్రదర్శించగల రాశి ఫలితాలు ${results.length}',
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'ప్రతి గ్రహం వద్ద: ① BNN రాశి ఫలితం ② BPHS భావాధిపతి స్థానం '
                      '③ BNN గురువు నుంచి IF–THEN ఫలితం. ఫలితాన్ని టచ్ చేస్తే రూల్, '
                      'జాతక పరిశీలన, మూలపేజీ కనిపిస్తాయి.',
                      style: TextStyle(fontSize: 12.5, height: 1.45),
                    ),
                    const SizedBox(height: 7),
                    const Text(
                      'Green: అనుకూలం • Pink: ప్రతికూలం • '
                      'Neutral: మిశ్రమం. మూల IF–THEN లేని స్థానాలకు '
                      'రాశి/భావ గణన మాత్రమే; ఫలితం కల్పించము.',
                      style: TextStyle(fontSize: 12.5, height: 1.45),
                    ),
                    const SizedBox(height: 9),
                    const Text(
                      'BNN గురు-ఆధార నియమాలు, BPHS Chapter 24 భావాధిపతి నియమాలు '
                      'వేర్వేరు మూలాలవి. BPHSలో భావాధిపత్యం మరియు గ్రహస్థానం రెండూ పరీక్షించాలి.',
                      style: TextStyle(
                        fontSize: 12.5,
                        height: 1.45,
                        color: Color(0xFF6F5960),
                      ),
                    ),
                    const SizedBox(height: 9),
                    OutlinedButton.icon(
                      onPressed: () => setState(() => _showAll = !_showAll),
                      icon: Icon(
                        _showAll ? Icons.visibility_off : Icons.list_alt,
                      ),
                      label: Text(
                        _showAll
                            ? 'మిగతా నియమాల జాబితా మూసివేయి'
                            : 'మొత్తం 84 రాశి నియమాలు',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const AnnapurnaFontSizeControls(),
            BnnUnifiedEvidencePanel376(
              chart: widget.chart,
              birth: widget.birthData,
            ),
            BnnJupiterCyclesPanel(chart: widget.chart),
            BnnSaturnCyclesPanel(chart: widget.chart),
            _HousePositionsCard(locations: locations),
            BnnPlanetCombinationsPanel(chart: widget.chart),
            FutureBuilder<List<BnnJupiterRelativeRule>>(
              future: _jupiterRules,
              builder: (context, snap) {
                if (snap.hasError) {
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(
                        'గురు సంబంధ మూల డేటా చదవడంలో సమస్య: ${snap.error}',
                      ),
                    ),
                  );
                }
                if (!snap.hasData) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(12),
                      child: CircularProgressIndicator(),
                    ),
                  );
                }
                final jupiterMatched =
                    BnnHouseRelationService.evaluateVerifiedJupiterRules(
                      chart: widget.chart,
                      rules: snap.data!,
                    );
                return FutureBuilder<List<BnnLagnaRelativeRule>>(
                  future: _lagnaRules,
                  builder: (context, lagnaSnap) {
                    if (!lagnaSnap.hasData && !lagnaSnap.hasError) {
                      return const Center(
                        child: Padding(
                          padding: EdgeInsets.all(12),
                          child: CircularProgressIndicator(),
                        ),
                      );
                    }
                    final lagnaMatched = lagnaSnap.data == null
                        ? <BnnLagnaRelativeFinding>[]
                        : BnnHouseRelationService.evaluateVerifiedLagnaRules(
                            chart: widget.chart,
                            rules: lagnaSnap.data!,
                          );
                    final byPlanet = <String, BnnRashiFinding>{
                      for (final f in results) f.rule.planet: f,
                    };
                    return FutureBuilder<List<BphsBhavaLordRule>>(
                      future: _bphsRules,
                      builder: (context, bphsSnap) {
                        if (!bphsSnap.hasData && !bphsSnap.hasError) {
                          return const Center(
                            child: Padding(
                              padding: EdgeInsets.all(12),
                              child: CircularProgressIndicator(),
                            ),
                          );
                        }
                        final bphsMatched = bphsSnap.data == null
                            ? <BphsBhavaLordFinding>[]
                            : BphsLagnaBhavaLordService.evaluate(
                                chart: widget.chart,
                                rules: bphsSnap.data!,
                              );
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            if (lagnaSnap.hasError)
                              Card(
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Text(
                                    'లగ్న సంబంధ మూల డేటా చదవడంలో సమస్య: ${lagnaSnap.error}',
                                  ),
                                ),
                              ),
                            if (bphsSnap.hasError)
                              Card(
                                child: Padding(
                                  padding: const EdgeInsets.all(12),
                                  child: Text(
                                    'BPHS నియమాల డేటా సమస్య: ${bphsSnap.error}',
                                  ),
                                ),
                              ),
                            for (final position in locations)
                              _BnnGrahaTripleCard(
                                key: ValueKey(
                                  'bnn-three-results-${position.name}',
                                ),
                                location: position,
                                chart: widget.chart,
                                rashiFinding: byPlanet[position.name],
                                lagnaFindings: lagnaMatched
                                    .where(
                                      (f) => f.rule.target == position.name,
                                    )
                                    .toList(),
                                bphsFindings: bphsMatched
                                    .where((f) => f.lordPlanet == position.name)
                                    .toList(),
                                jupiterFindings: jupiterMatched
                                    .where(
                                      (f) => f.rule.target == position.name,
                                    )
                                    .toList(),
                              ),
                            if (_showAll) ...[
                              const Padding(
                                padding: EdgeInsets.fromLTRB(8, 20, 8, 7),
                                child: Text(
                                  'ఇతర రాశి నియమాల మూల జాబితా (ఫలితం కాదు)',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              for (final f in unused)
                                _RashiResultCard(
                                  key: ValueKey('bnn-all-${f.rule.id}'),
                                  finding: f,
                                  chart: widget.chart,
                                ),
                            ],
                          ],
                        );
                      },
                    );
                  },
                );
              },
            ),
          ],
        );
      },
    );
  }
}

/// BNN only: for each graha keep the three distinct evidence channels.
/// A whole-sign house count is NOT itself a prediction.
class _BnnGrahaTripleCard extends StatelessWidget {
  final BnnHousePosition location;
  final AstroChartResult chart;
  final BnnRashiFinding? rashiFinding;
  final List<BnnLagnaRelativeFinding> lagnaFindings;
  final List<BphsBhavaLordFinding> bphsFindings;
  final List<BnnJupiterRelativeFinding> jupiterFindings;
  const _BnnGrahaTripleCard({
    super.key,
    required this.location,
    required this.chart,
    required this.rashiFinding,
    required this.lagnaFindings,
    required this.bphsFindings,
    required this.jupiterFindings,
  });

  @override
  Widget build(BuildContext context) {
    final p = location.position;
    final label =
        BnnHouseRelationService.planetLabels[location.name] ?? location.name;
    final sign = BnnRashiRuleService.signs[p.signIndex];
    final hasRashiResult = rashiFinding?.canDisplayEffect ?? false;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      color: const Color(0xFFF4F8F7),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 14, 12, 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              '$label • $sign ${BnnRashiRuleService.dms(p.longitude)}'
              '${p.retrograde ? ' • వక్రం' : ''}',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 7),
            Text(
              'లగ్నం నుంచి ${location.lagnaHouse}వ భావం • '
              '${location.jupiterHouse == null ? 'గురు స్థానం అందలేదు' : 'గురువు నుంచి ${location.jupiterHouse}వ స్థానం'}',
              style: const TextStyle(fontSize: 12.5, color: Color(0xFF536674)),
            ),
            const SizedBox(height: 13),
            const Text(
              '1. రాశి ఆధారంగా ఫలితం',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            if (hasRashiResult)
              _RashiResultCard(
                key: ValueKey('bnn-triple-rashi-${location.name}'),
                finding: rashiFinding!,
                chart: chart,
              )
            else
              _BnnPositionOnlyTile(
                label: '$label $sign రాశిలో ఉన్నాడు.',
                detail:
                    'రాశి స్థానం గణించాం. ఈ గ్రహానికి ప్రచురించదగిన '
                    '84 రాశి IF–THEN ఫలితం ఈ జాబితాలో లేదు.',
              ),
            const SizedBox(height: 12),
            Text(
              '2. లగ్నం నుంచి ${location.lagnaHouse}వ భావం • BPHS భావాధిపతి ఫలితం',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            if (bphsFindings.isNotEmpty)
              for (final finding in bphsFindings)
                _BphsLagnaLordCard(
                  key: ValueKey(
                    'bphs-lagna-${finding.rule.id}-${location.name}',
                  ),
                  finding: finding,
                ),
            if (lagnaFindings.isNotEmpty)
              for (final finding in lagnaFindings)
                _LagnaResultCard(
                  key: ValueKey('bnn-triple-lagna-${finding.rule.id}'),
                  finding: finding,
                  chart: chart,
                ),
            if (lagnaFindings.isEmpty && bphsFindings.isEmpty)
              _BnnPositionOnlyTile(
                label:
                    'భావ స్థానం: ${BnnHouseRelationService.houseTopics[location.lagnaHouse - 1]}',
                detail:
                    '$label $signలో ${BnnRashiRuleService.dms(p.longitude)}. '
                    'జన్మలగ్నం నుంచి ${location.lagnaHouse}వ భావం లెక్క మాత్రమే. '
                    'BPHS Chapter 24లో భావాధిపతి-స్థానం నియమం ఈ గ్రహానికి '
                    'ఈ విడత కేటలాగ్‌లో లేదు. ఇది భావస్థాన గణన మాత్రమే.',
              ),
            const SizedBox(height: 12),
            Text(
              location.jupiterHouse == null
                  ? '3. గురువు నుంచి స్థానం — లెక్కించలేదు'
                  : '3. గురువు నుంచి ${location.jupiterHouse}వ స్థానం',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
            ),
            if (jupiterFindings.isNotEmpty)
              for (final finding in jupiterFindings)
                _JupiterResultCard(
                  key: ValueKey('bnn-triple-jupiter-${finding.rule.id}'),
                  finding: finding,
                  chart: chart,
                )
            else
              _BnnPositionOnlyTile(
                label: location.jupiterHouse == null
                    ? 'గురుగ్రహ స్థానం అందలేదు'
                    : 'గురువు నుంచి ${location.jupiterHouse}వ స్థానం',
                detail: location.jupiterHouse == null
                    ? 'గురుగ్రహ స్థితి లేక స్థానం గణించలేకపోయాం.'
                    : 'ఈ గ్రహం–స్థానం కలయికకు ప్రస్తుతం మూలపేజీతో నిర్ధారించిన '
                          'BNN IF–THEN ఫలితం లేదు. రాశి ఫలితాన్ని ఇక్కడ కాపీ చేయము.',
              ),
          ],
        ),
      ),
    );
  }
}

/// BPHS Chapter 24 result, not BNN: show source and lordship clearly.
class _BphsLagnaLordCard extends StatelessWidget {
  final BphsBhavaLordFinding finding;
  const _BphsLagnaLordCard({super.key, required this.finding});

  @override
  Widget build(BuildContext context) {
    final rule = finding.rule;
    final p = finding.planetPosition;
    final name =
        BnnHouseRelationService.planetLabels[finding.lordPlanet] ??
        finding.lordPlanet;
    final color = _toneStyle(_toneForSource(rule.tone));
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: ExpansionTile(
        key: ValueKey('bphs-lagna-lord-${rule.id}'),
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              '$name — ${rule.lordOfHouse}వ భావాధిపతి; '
              '${rule.placedInHouse}వ భావంలో',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: color.text,
                fontSize: 13.5,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(
                color: color.background,
                border: Border.all(color: color.border),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                rule.resultTelugu,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15.5,
                  color: color.text,
                ),
              ),
            ),
          ],
        ),
        subtitle: const Padding(
          padding: EdgeInsets.only(top: 6),
          child: Text(
            'BPHS • ఫలితం టచ్ → రూల్ / పరిశీలన / అధ్యాయం–శ్లోకం',
            style: TextStyle(fontSize: 12),
          ),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: [
          _BnnInfoSection('1. రూల్ — ${rule.id}', rule.ifTelugu),
          const SizedBox(height: 6),
          _BnnInfoSection(
            '2. జాతక పరిశీలన',
            'లగ్నం ${BnnRashiRuleService.signs[finding.lagnaSign]}. '
                '$name ${BnnRashiRuleService.signs[p.signIndex]} '
                '${BnnRashiRuleService.dms(p.longitude)} వద్ద ఉన్నాడు. '
                '${rule.lordOfHouse}వ భావాధిపతి; జన్మలగ్నం నుంచి '
                '${rule.placedInHouse}వ భావం — IF TRUE.',
          ),
          const SizedBox(height: 6),
          _BnnInfoSection(
            '3. ఫలితం — సంక్షిప్త తెలుగు భావసారాంశం',
            '${rule.resultTelugu}. ఇది సంప్రదాయ మూలగ్రంథ సూచన; '
                'ఒక్క నియమంతో పూర్తి జీవిత తీర్పు కాదు.',
          ),
          const SizedBox(height: 6),
          _BnnInfoSection(
            '4. మూలాధారం',
            'బృహత్ పరాశర హోరా శాస్త్రం (BPHS), అధ్యాయం 24, '
                'శ్లోక/నియమ సంఖ్య ${rule.verse}. '
                'మూలపాఠం: ${rule.sourceUrl} '
                'ఇది భావాధిపతి స్థానం నియమం, కేవలం గ్రహం–భావం నియమం కాదు. '
                'వివిధ సంచికల్లో అధ్యాయ సంఖ్యలు మారవచ్చు.',
          ),
        ],
      ),
    );
  }
}

class _BnnPositionOnlyTile extends StatelessWidget {
  final String label;
  final String detail;
  const _BnnPositionOnlyTile({required this.label, required this.detail});
  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(top: 6),
    padding: const EdgeInsets.all(11),
    decoration: BoxDecoration(
      color: const Color(0xFFF2F3F5),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: const Color(0xFFCCD2D7)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
            color: Color(0xFF455363),
          ),
        ),
        const SizedBox(height: 5),
        Text(
          detail,
          style: const TextStyle(
            fontSize: 12.5,
            height: 1.45,
            color: Color(0xFF56616E),
          ),
        ),
      ],
    ),
  );
}

class _HousePositionsCard extends StatelessWidget {
  final List<BnnHousePosition> locations;
  const _HousePositionsCard({required this.locations});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFF6F7FA),
      child: ExpansionTile(
        key: const ValueKey('bnn-nine-planet-house-positions'),
        initiallyExpanded: false,
        title: const Text(
          'అన్ని 9 గ్రహాలు — లగ్నం & గురు నుంచి స్థానాలు',
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        subtitle: const Text('టచ్ చేసి రాశి, డిగ్రీలు, 1–12 స్థానాలు చూడండి'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: [
          const Text(
            'స్థానం మొత్తం రాశుల ఆధారంగా గణించబడింది. '
            'భావ విషయాలు సూచిక మాత్రమే; అవి స్వతంత్ర ఫలితాలు కావు.',
            style: TextStyle(fontSize: 12.5, color: Color(0xFF59616B)),
          ),
          for (final location in locations)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${BnnHouseRelationService.planetLabels[location.name] ?? location.name} • '
                      '${BnnRashiRuleService.signs[location.position.signIndex]} '
                      '${BnnRashiRuleService.dms(location.position.longitude)}'
                      '${location.position.retrograde ? ' (వక్రం)' : ''}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'లగ్నం నుంచి ${location.lagnaHouse}వ భావం — '
                      '${BnnHouseRelationService.houseTopics[location.lagnaHouse - 1]}',
                    ),
                    Text(
                      location.jupiterHouse == null
                          ? 'గురువు నుంచి స్థానం: గణనకు గురుగ్రహం స్థితి లేదు'
                          : 'గురువు నుంచి ${location.jupiterHouse}వ స్థానం',
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _RashiResultCard extends StatelessWidget {
  final BnnRashiFinding finding;
  final AstroChartResult chart;
  const _RashiResultCard({
    super.key,
    required this.finding,
    required this.chart,
  });

  @override
  Widget build(BuildContext context) {
    final rule = finding.rule;
    final p = finding.position;
    final matched = finding.matched;
    final showResult = finding.canDisplayEffect;
    final tone = _toneForRashi(rule.id);
    final style = _toneStyle(tone);
    final jupiterList = chart.planets.where((p) => p.name == 'Jupiter');
    final jupiter = jupiterList.isNotEmpty ? jupiterList.first : null;
    final int? fromJupiter = p == null || jupiter == null
        ? null
        : BnnHouseRelationService.houseFrom(
            originSign: jupiter.signIndex,
            targetSign: p.signIndex,
          );
    final label =
        BnnHouseRelationService.planetLabels[rule.planet] ?? rule.planet;
    final relationLine = finding.house == null
        ? ''
        : 'లగ్నం నుంచి ${finding.house}వ భావం • '
              '${fromJupiter == null ? 'గురు స్థానం లేదు' : 'గురు నుంచి ${fromJupiter}వ స్థానం'}';
    final Text resultTitle = Text(
      showResult ? finding.displayEffect! : '${rule.id} • ${rule.title}',
      softWrap: true,
      style: TextStyle(
        fontWeight: FontWeight.bold,
        fontSize: 16,
        height: 1.5,
        color: showResult ? style.text : null,
      ),
    );
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      color: const Color(0xFFF2F8F6),
      child: ExpansionTile(
        key: ValueKey('bnn-outcome-${rule.id}'),
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        title: showResult && p != null
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '$label ${BnnRashiRuleService.signs[p.signIndex]}లో '
                    '${BnnRashiRuleService.dms(p.longitude)} వద్ద ఉన్నందున',
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: style.text,
                      fontSize: 14.5,
                      height: 1.45,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    key: ValueKey('bnn-result-highlight-${rule.id}'),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 13,
                    ),
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: style.background,
                      border: Border.all(color: style.border, width: 1.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: resultTitle,
                  ),
                ],
              )
            : resultTitle,
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 7),
          child: Text(
            showResult
                ? '$relationLine • ఫలితం టచ్ చేస్తే రూల్ / పరిశీలన / మూలపేజీ'
                : (p == null
                      ? 'గణనకు సమాచారం లేదు'
                      : matched
                      ? 'మూల వాక్య పరిశీలన'
                      : 'వర్తించలేదు'),
            style: TextStyle(
              fontSize: 12.5,
              color: showResult ? style.text : const Color(0xFF64707C),
            ),
          ),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(15, 0, 15, 15),
        children: [
          _BnnInfoSection('1. రూల్ — ${rule.id}', rule.originalIf),
          const SizedBox(height: 9),
          _BnnInfoSection(
            '2. జాతక పరిశీలన',
            p == null
                ? 'ఈ గ్రహానికి జన్మస్ఫుటం అందలేదు.'
                : '$label: ${BnnRashiRuleService.signs[p.signIndex]} '
                      '${BnnRashiRuleService.dms(p.longitude)}'
                      '${p.retrograde ? ' (వక్రం)' : ''}. '
                      '${matched ? 'IF TRUE — గ్రహం చెప్పిన రాశిలో ఉంది' : 'IF FALSE — ఆ రాశిలో లేదు'}.',
          ),
          if (matched && finding.house != null) ...[
            const SizedBox(height: 6),
            _BnnInfoSection(
              'లగ్నం ఆధారంగా',
              'జన్మలగ్నం నుంచి ${finding.house}వ భావం. '
                  '${BnnHouseRelationService.houseTopics[finding.house! - 1]} '
                  '(భావ సూచిక; స్వతంత్ర ఫలితం కాదు).',
            ),
          ],
          if (p != null) ...[
            const SizedBox(height: 6),
            _BnnInfoSection(
              'గురు ఆధారంగా',
              fromJupiter == null
                  ? 'గురుగ్రహ స్థితి లేక స్థానాన్ని గణించలేకపోయాం.'
                  : 'గురువు నుంచి ${fromJupiter}వ స్థానం. '
                        'ఈ రాశి ఫలితం గురువు నుంచి వచ్చిన నియమఫలితం కాదు.',
            ),
          ],
          if (matched) ...[
            const SizedBox(height: 9),
            _BnnInfoSection(
              '3. మూలంలోని పూర్తి THEN వాక్యం',
              rule.originalThen,
            ),
            if (finding.annotation != null && finding.annotation!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    finding.annotation!,
                    style: const TextStyle(
                      fontSize: 12.5,
                      color: Color(0xFF8A4D2E),
                    ),
                  ),
                ),
              ),
          ],
          const SizedBox(height: 9),
          _BnnInfoSection(
            '4. మూలాధారం',
            '${rule.transcriptionFile}\n'
                'BNN మూల స్కాన్: PDF పేజీ ${rule.pdfPage}, '
                'ముద్రిత పేజీ ${rule.printedPage}. '
                'పేజీలో రాశి పట్టిక ఉన్న స్థానం పరిశీలించారు; '
                'THEN వాక్యం అక్షరాలవారీ ధృవీకరణ ఇంకా జరగలేదు.',
          ),
        ],
      ),
    );
  }
}

class _LagnaResultCard extends StatelessWidget {
  final BnnLagnaRelativeFinding finding;
  final AstroChartResult chart;
  const _LagnaResultCard({
    super.key,
    required this.finding,
    required this.chart,
  });
  @override
  Widget build(BuildContext context) {
    final rule = finding.rule;
    final p = finding.targetPosition;
    final style = _toneStyle(_toneForSource(rule.tone));
    final label =
        BnnHouseRelationService.planetLabels[rule.target] ?? rule.target;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ExpansionTile(
        key: ValueKey('bnn-lagna-${rule.id}'),
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'లగ్నం నుంచి ${rule.lagnaHouse}వ భావంలో $label ఉన్నందున',
              style: TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w600,
                color: style.text,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: style.background,
                border: Border.all(color: style.border),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                rule.originalThen,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: style.text,
                ),
              ),
            ),
          ],
        ),
        subtitle: const Padding(
          padding: EdgeInsets.only(top: 7),
          child: Text(
            'ఫలితాన్ని టచ్ చేస్తే రూల్ • పరిశీలన • పేజీ',
            style: TextStyle(fontSize: 12.5),
          ),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: [
          _BnnInfoSection(
            '1. రూల్ — ${rule.id} (మూల ${rule.sourceId})',
            rule.originalIf,
          ),
          const SizedBox(height: 8),
          _BnnInfoSection(
            '2. జాతక పరిశీలన',
            '$label ${BnnRashiRuleService.signs[p.signIndex]} '
                '${BnnRashiRuleService.dms(p.longitude)}. '
                'లగ్నం నుంచి ${rule.lagnaHouse}వ భావం — IF TRUE.',
          ),
          const SizedBox(height: 8),
          _BnnInfoSection('3. మూలంలోని THEN వాక్యం', rule.originalThen),
          const SizedBox(height: 8),
          _BnnInfoSection(
            '4. మూలాధారం',
            '${rule.sourceFile} • PDF పేజీ ${rule.pdfPage} • '
                'మూల రూల్ ${rule.sourceId}.',
          ),
        ],
      ),
    );
  }
}

class _JupiterResultCard extends StatelessWidget {
  final BnnJupiterRelativeFinding finding;
  final AstroChartResult chart;
  const _JupiterResultCard({
    super.key,
    required this.finding,
    required this.chart,
  });

  @override
  Widget build(BuildContext context) {
    final rule = finding.rule;
    final p = finding.targetPosition;
    final tone = _toneForSource(rule.tone);
    final style = _toneStyle(tone);
    final int lagnaHouse = BnnHouseRelationService.houseFrom(
      originSign: chart.ascendantSignIndex,
      targetSign: p.signIndex,
    );
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ExpansionTile(
        key: ValueKey('bnn-relative-${rule.id}'),
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'గురువు నుంచి ${rule.jupiterHouse}వ స్థానంలో '
              '${BnnHouseRelationService.planetLabels[rule.target] ?? rule.target} '
              '${BnnRashiRuleService.dms(p.longitude)} వద్ద ఉన్నందున',
              style: TextStyle(
                fontSize: 14.5,
                fontWeight: FontWeight.w600,
                color: style.text,
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(12),
              width: double.infinity,
              decoration: BoxDecoration(
                color: style.background,
                border: Border.all(color: style.border),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                rule.originalThen,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: style.text,
                ),
              ),
            ),
          ],
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 7),
          child: Text(
            rule.sourceScope == 'case_example'
                ? 'R.G. Rao గ్రంథ ఉదాహరణ • టచ్ → రూల్, పరిశీలన, మూలపేజీ'
                : 'ఫలితాన్ని టచ్ చేస్తే రూల్ • పరిశీలన • పేజీ',
            style: const TextStyle(fontSize: 12.5),
          ),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: [
          _BnnInfoSection(
            '1. రూల్ — ${rule.id} (మూల ${rule.sourceId})',
            rule.originalIf,
          ),
          const SizedBox(height: 8),
          _BnnInfoSection(
            '2. జాతక పరిశీలన',
            '${BnnHouseRelationService.planetLabels[rule.target]} '
                '${BnnRashiRuleService.signs[p.signIndex]} '
                '${BnnRashiRuleService.dms(p.longitude)}. '
                'గురుడు ${BnnRashiRuleService.signs[finding.jupiterPosition.signIndex]}. '
                'గురువు నుంచి ${rule.jupiterHouse}వ స్థానం — IF TRUE. '
                'లగ్నం నుంచి ${lagnaHouse}వ భావం.',
          ),
          const SizedBox(height: 8),
          _BnnInfoSection('3. మూలంలోని ఫలిత భావసారాంశం', rule.originalThen),
          const SizedBox(height: 8),
          _BnnInfoSection(
            '4. మూలాధారం',
            rule.sourceUrl == null
                ? '${rule.sourceFile} • PDF పేజీ ${rule.pdfPage} • మూల రూల్ ${rule.sourceId}. '
                      'IF TRUE అంటే గ్రహస్థానం సరిపోయిందని మాత్రమే; '
                      'THEN వాక్యం సంప్రదాయ సూచన, జీవిత సంఘటనకు నిర్ధారణ కాదు.'
                : '${rule.sourceFile} • ఆన్‌లైన్ పేజీ ${rule.pdfPage}'
                      '${rule.printedPage == null ? '' : ' • ముద్రిత పేజీ ${rule.printedPage}'}'
                      ' • అంతర్గత ఆధార ID ${rule.sourceId}. మూల లింక్: ${rule.sourceUrl}. '
                      '${rule.sourceNote ?? ''} గ్రహస్థానం TRUE అయినప్పటికీ, '
                      'ఇది ఒక పుస్తక ఉదాహరణ నుంచి తీసుకున్న సూచన మాత్రమే.',
          ),
        ],
      ),
    );
  }
}

class _BnnInfoSection extends StatelessWidget {
  final String title;
  final String body;
  const _BnnInfoSection(this.title, this.body);
  @override
  Widget build(BuildContext context) => Align(
    alignment: Alignment.centerLeft,
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(body, style: const TextStyle(height: 1.45)),
      ],
    ),
  );
}
