import 'dart:async';

import 'package:flutter/material.dart';

import '../astrology/bnn_financial_evidence_v373.dart';
import '../astrology/bnn_financial_timing_v374.dart';
import '../astrology/goel_transit_support_v375.dart';

class BnnFinancialTimingPanelV374 extends StatefulWidget {
  final Future<FinancialTimingResult> Function() load;
  const BnnFinancialTimingPanelV374({super.key, required this.load});
  @override
  State<BnnFinancialTimingPanelV374> createState() => _FinancialTimingState();
}

class _FinancialTimingState extends State<BnnFinancialTimingPanelV374> {
  Future<FinancialTimingResult>? _future;
  void _startCalculation() {
    final pending = Completer<FinancialTimingResult>();
    setState(() {
      _future = pending.future;
    });
    // Subscribe FutureBuilder first, then forward success or error unchanged.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      pending.complete(Future<FinancialTimingResult>.sync(widget.load));
    });
  }

  int _limit = 10;
  String _filter = 'all';
  static const names = {
    'Sun': 'రవి',
    'Moon': 'చంద్రుడు',
    'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు',
    'Jupiter': 'గురువు',
    'Venus': 'శుక్రుడు',
    'Saturn': 'శని',
    'Rahu': 'రాహువు',
    'Ketu': 'కేతువు',
  };
  static String date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';
  static String label(String p) => names[p] ?? p;
  static String when(FinancialTimingWindow w, DateTime now) =>
      w.periodEnd.isBefore(now)
      ? 'past'
      : w.periodStart.isAfter(now)
      ? 'future'
      : 'present';
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const Text(
        'దశ–అంతర్దశ / గోచార సమయ పరిశీలన',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      const Text(
        'వర్తించిన ధన మూల రూల్ గ్రహదశల్లో V.P. Goel 85, 86 శని గోచార నియమాలను పరిశీలిస్తాం. '
        'శాతం = సరిపోలిన పూర్తి రూల్స్ / పరీక్షించగల పూర్తి రూల్స్. సంఘటన సంభావ్యత కాదు. '
        'సంపద/పొదుపు/నష్టం: 2వ భావం; లాభం: 11వ భావం — ఇది యాప్ అంశ–భావ ఎంపిక. '
        '85 సంఘటన సంబంధం; 86 ప్రతికూల సూచన. రెండింటినీ విడిగా చూపిస్తాం. '
        'గణనలో నియమ వాక్యంలోని త్రికోణ స్థితి లేదా ఉదాహరణల్లోని శని 3/7/10 దృష్టిని తీసుకుంటాం. '
        'గురు గోచార శాతం: మూల రూల్ జతకాలేదు. జన్మ గురువును గోచార గురువుగా లెక్కించము. '
        '45 రోజుల విరామంతో నమూనా తేదీలు; ఖచ్చిత సంఘటన తేదీలు కావు. '
        'వ్యక్తిగత ఆర్థిక పరిశీలన పరిధి 14–85 ఏళ్లు; ఇది స్క్రీన్ పరిధి మాత్రమే.',
        style: TextStyle(fontSize: 12, height: 1.4),
      ),
      if (_future == null)
        OutlinedButton(
          key: const ValueKey('financial-run-timing'),
          onPressed: _startCalculation,
          child: const Text('దశ–గోచార కాలాలు పరిశీలించండి'),
        ),
      if (_future != null)
        FutureBuilder<FinancialTimingResult>(
          future: _future,
          builder: (context, snapshot) {
            if (snapshot.hasError)
              return Column(
                children: [
                  const Text(
                    'గోచార గణన పూర్తి కాలేదు; కాల ఫలితం నిర్ధారించలేదు.',
                  ),
                  TextButton(
                    onPressed: _startCalculation,
                    child: const Text('మళ్లీ పరిశీలించండి'),
                  ),
                ],
              );
            if (!snapshot.hasData)
              return const Padding(
                padding: EdgeInsets.all(12),
                child: Row(
                  children: [
                    SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'మూల గ్రహాలు, దశలు, వాస్తవ గోచారం పరిశీలిస్తున్నాం…',
                      ),
                    ),
                  ],
                ),
              );
            final r = snapshot.data!;
            if (r.missingInput != null)
              return Text('గణనకు సమాచారం లేదు: ${r.missingInput}');
            final now = DateTime.now();
            final visible = r.windows
                .where((w) => _filter == 'all' || when(w, now) == _filter)
                .toList();
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'పరీక్షించిన దశా కాలాలు: ${r.periodsExamined} • '
                  'గోచార నమూనాలు: ${r.checkpointsExamined} • మద్దతున్న నమూనాలు: ${r.windows.length}',
                  key: const ValueKey('financial-timing-counts'),
                  style: const TextStyle(fontSize: 12),
                ),
                if (r.windows.isEmpty)
                  const Text(
                    'పరీక్షించిన రూల్ గ్రహదశల్లో Goel 85/86 శని '
                    'సంబంధ నమూనా లభించలేదు. సంఘటన జరగదని దీని అర్థం కాదు.',
                  ),
                if (r.rulesWithoutPlanets.isNotEmpty)
                  Text(
                    'సమయ గ్రహ ఎంపిక ఇంకా జతకాలేదు: ${r.rulesWithoutPlanets.join(', ')}',
                  ),
                if (r.windows.isNotEmpty)
                  DropdownButton<String>(
                    value: _filter,
                    isExpanded: true,
                    items: const [
                      DropdownMenuItem(
                        value: 'all',
                        child: Text('అన్ని కాలాలు'),
                      ),
                      DropdownMenuItem(value: 'past', child: Text('గత కాలాలు')),
                      DropdownMenuItem(
                        value: 'present',
                        child: Text('ప్రస్తుత దశా కాలం'),
                      ),
                      DropdownMenuItem(
                        value: 'future',
                        child: Text('భవిష్యత్తు కాలాలు'),
                      ),
                    ],
                    onChanged: (v) {
                      if (v != null)
                        setState(() {
                          _filter = v;
                          _limit = 10;
                        });
                    },
                  ),
                for (final w in visible.take(_limit))
                  Container(
                    key: ValueKey(
                      'financial-window-${w.sampledLocal.toIso8601String()}-${w.links.first.ruleId}',
                    ),
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F4F7),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${label(w.maha)} మహాదశ / ${label(w.antar)} అంతర్దశ',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Text(
                          'పరిశీలించిన దశా పరిధి: ${date(w.periodStart)} నుంచి ${date(w.periodEnd)} వరకు',
                        ),
                        Text(
                          'గోచార మద్దతు నమూనా తేదీ: ${date(w.sampledLocal)}',
                        ),
                        if (w.sampledAge != null)
                          Text(
                            'నమూనా వయస్సు: సుమారు ${w.sampledAge!.toStringAsFixed(1)} సంవత్సరాలు',
                          ),
                        Text(
                          'గురు రాశి: ${w.jupiterSign + 1} • శని రాశి: ${w.saturnSign + 1}',
                          style: const TextStyle(fontSize: 12),
                        ),
                        if (w.goelSupport != null)
                          GoelTransitSupportCardV375(support: w.goelSupport!),
                        for (final link in w.links)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text(
                              '${link.ruleId} • ${link.tone == BnnFinancialTone.unfavorable
                                  ? 'ప్రతికూల'
                                  : link.tone == BnnFinancialTone.favorable
                                  ? 'అనుకూల'
                                  : 'తటస్థ'} సూచన\n'
                              'మూల గ్రహాలు: ${link.sourcePlanets.map(label).join(', ')}\n'
                              'దశ సంబంధం: ${link.activePlanets.map(label).join(', ')}\n'
                              '${w.goelSupport == null ? "గురు–శని ఉమ్మడి మద్దతు" : "వేరుగా సాధారణ గురు–శని సంబంధం (Goel శాతంలో లేదు)"}: '
                              '${link.transitTargets.isEmpty ? "వర్తించలేదు" : link.transitTargets.entries.map((e) => '${label(e.key)} జన్మ రాశి ${e.value + 1}').join(', ')}',
                              style: TextStyle(
                                fontSize: 12,
                                color: link.tone == BnnFinancialTone.unfavorable
                                    ? const Color(0xFF9C2252)
                                    : link.tone == BnnFinancialTone.favorable
                                    ? const Color(0xFF18613A)
                                    : const Color(0xFF455A64),
                              ),
                            ),
                          ),
                        const Text(
                          'ఈ తేదీ సంఘటన జరిగిందని లేదా జరుగుతుందని నిర్ధారణ కాదు.',
                          style: TextStyle(fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                if (visible.length > _limit)
                  TextButton(
                    onPressed: () => setState(() => _limit += 10),
                    child: const Text('మరిన్ని కాలాలు'),
                  ),
              ],
            );
          },
        ),
    ],
  );
}

class GoelTransitSupportCardV375 extends StatelessWidget {
  final GoelTransitSupport support;
  const GoelTransitSupportCardV375({super.key, required this.support});
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const Text(
        'గురు గోచార శాతం: మూల రూల్ జతకాలేదు',
        style: TextStyle(fontSize: 12),
      ),
      for (final adverse in [false, true])
        Material(
          color: adverse ? const Color(0xFFFCE8EF) : const Color(0xFFEAF0F7),
          child: ExpansionTile(
            tilePadding: const EdgeInsets.symmetric(horizontal: 8),
            title: Text(
              'శని ${adverse ? "ప్రతికూల సూచన" : "సంఘటన సంబంధం"}: '
              '${support.percent(adverse: adverse)?.toStringAsFixed(0) ?? "సమాచారం లేదు"}'
              '${support.percent(adverse: adverse) == null ? "" : "%"}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold),
            ),
            children: [
              for (final c in support.checks.where((c) => c.adverse == adverse))
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    '${c.id} • ${c.statusTe}\n'
                    'మూలం: gocharam v p goel.pdf • PDF పేజీ ${c.pdfPage}\n'
                    'దృష్టి ఉదాహరణలు: PDF పేజీలు ${c.adverse ? "7, 8, 10" : "3, 4"}\n'
                    '${c.title}\n${c.inspection}\n'
                    'పూర్తి రూల్: ${c.state == GoelTransitState.matched
                        ? "1/1"
                        : c.state == GoelTransitState.unmatched
                        ? "0/1"
                        : "పరీక్షించలేదు"}. '
                    'ఇది సంఘటన సంభావ్యత కాదు. పరిహారం ఈ నియమంలో ఇవ్వలేదు.',
                    style: const TextStyle(fontSize: 12, height: 1.5),
                  ),
                ),
            ],
          ),
        ),
    ],
  );
}
