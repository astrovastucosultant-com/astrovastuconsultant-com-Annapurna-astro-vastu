import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_house_relation_service.dart';
import '../astrology/bnn_life_event_timing_service.dart';
import '../astrology/bnn_life_event_convergence_v371.dart';
import '../models/birth_data.dart';
import '../astrology/bnn_financial_evidence_v373.dart';
import 'bnn_financial_card_v373.dart';
import '../astrology/bnn_financial_timing_v374.dart';
import '../astrology/astro_calculation_service.dart';

/// Evidence-first life-event index. This is NOT an event prediction widget:
/// no date, probability, or mortality age is fabricated from cycle contacts.
class BnnLifeEventsPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData? birthData;
  final Future<List<BnnLifeEventReview>>? reviewFuture;
  const BnnLifeEventsPanel({
    super.key,
    required this.chart,
    this.birthData,
    this.reviewFuture,
  });

  @override
  State<BnnLifeEventsPanel> createState() => _BnnLifeEventsPanelState();
}

class _BnnLifeEventsPanelState extends State<BnnLifeEventsPanel> {
  late Future<List<BnnLifeEventReview>> _reviews =
      widget.reviewFuture ??
      BnnLifeEventTimingService.build(chart: widget.chart);
  late Future<Map<String, BnnEventTimingAssessmentV371>> _convergence =
      widget.birthData == null
      ? Future.value(<String, BnnEventTimingAssessmentV371>{})
      : BnnEventConvergenceServiceV371.examine(
          chart: widget.chart,
          birth: widget.birthData!,
        );
  late Map<String, BnnFinancialAssessment> _financial =
      BnnFinancialEvidenceServiceV373.evaluate(widget.chart);
  Future<FinancialTimingResult> _loadFinancial(
    BnnFinancialAssessment assessment,
  ) => BnnFinancialTimingServiceV374.examine(
    useGoelRules: true,
    chart: widget.chart,
    birth: widget.birthData,
    assessment: assessment,
    planetAtUtc: (planet, utc) => AstroCalculationService.calculatePlanetAtUtc(
      utc: utc,
      planetName: planet,
      ayanamsa: widget.birthData!.ayanamsa,
    ),
  );
  @override
  void didUpdateWidget(covariant BnnLifeEventsPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.chart, widget.chart) ||
        !identical(oldWidget.birthData, widget.birthData) ||
        !identical(oldWidget.reviewFuture, widget.reviewFuture)) {
      _reviews =
          widget.reviewFuture ??
          BnnLifeEventTimingService.build(chart: widget.chart);
      _convergence = widget.birthData == null
          ? Future.value(<String, BnnEventTimingAssessmentV371>{})
          : BnnEventConvergenceServiceV371.examine(
              chart: widget.chart,
              birth: widget.birthData!,
            );
      _financial = BnnFinancialEvidenceServiceV373.evaluate(widget.chart);
    }
  }

  bool _expanded = false;
  String _category = 'all';
  static String age(double n) =>
      n == n.roundToDouble() ? n.toStringAsFixed(0) : n.toStringAsFixed(1);

  @override
  Widget build(BuildContext context) => Card(
    key: const ValueKey('bnn-life-events-v370-panel'),
    color: const Color(0xFFF3F6FA),
    margin: const EdgeInsets.symmetric(vertical: 8),
    child: ExpansionTile(
      initiallyExpanded: false,
      onExpansionChanged: (value) => setState(() => _expanded = value),
      title: const Text(
        'జీవిత సంఘటనలు • వయస్సుల పరిశీలన',
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
      ),
      subtitle: const Text(
        'ధన అంశాలకు మూల రూల్ పరిశీలన • 5 ముఖ్య సంఘటనలకు కాల పరిశీలన',
        style: TextStyle(fontSize: 12),
      ),
      childrenPadding: const EdgeInsets.fromLTRB(10, 0, 10, 14),
      children: [
        if (_expanded) ...[
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text(
              'మొదటి ఐదు సంఘటనలకు జాతకానికి వర్తించిన వర్గ మూల రూల్, '
              'వింశోత్తరి మహాదశ/అంతర్దశ, Swiss Ephemeris గురు–శని నిజమైన '
              'గోచారాన్ని విడివిడిగా పరీక్షిస్తుంది. కనిపించే తేదీ గోచార '
              'నమూనా బిందువు మాత్రమే; సుమారు 45 రోజుల విరామంలో పరిశీలన, సంఘటన తప్పక జరిగే తేదీ కాదు. '
              'చంద్రుని రోజు స్థాయి Trigger, అన్ని వ్యవస్థల తుది ఏకీకరణ ఇంకా పెండింగ్.',
              style: TextStyle(height: 1.45, fontSize: 12.5),
            ),
          ),
          FutureBuilder<List<BnnLifeEventReview>>(
            future: _reviews,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Text('జీవిత సంఘటనల డేటా సమస్య: ${snapshot.error}');
              }
              if (!snapshot.hasData) {
                return const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              final all = snapshot.data!;
              final categories = <String, String>{'all': 'అన్ని అంశాలు'};
              for (final r in all) {
                categories[r.event.category] = r.event.categoryTe;
              }
              final visible = all
                  .where(
                    (r) => _category == 'all' || r.event.category == _category,
                  )
                  .toList();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: DropdownButton<String>(
                      value: _category,
                      items: [
                        for (final c in categories.entries)
                          DropdownMenuItem(value: c.key, child: Text(c.value)),
                      ],
                      onChanged: (v) {
                        if (v != null) setState(() => _category = v);
                      },
                    ),
                  ),
                  Text(
                    'సంఘటన అంశాలు: ${visible.length} • '
                    'సంఘటనల సమయ ఆధారాలు: అంశాలవారీగా పరిశీలించండి',
                    style: const TextStyle(
                      fontSize: 12,
                      color: Color(0xFF526477),
                    ),
                  ),
                  FutureBuilder<Map<String, BnnEventTimingAssessmentV371>>(
                    future: _convergence,
                    builder: (context, checks) {
                      if (checks.hasError) {
                        return Column(
                          children: [
                            Text(
                              'కాల గణనలో సమస్య: ${checks.error}',
                              style: const TextStyle(color: Colors.red),
                            ),
                            for (final result in visible)
                              if (_financial.containsKey(result.event.id))
                                BnnFinancialCardV373(
                                  assessment: _financial[result.event.id]!,
                                  loadTiming: () => _loadFinancial(
                                    _financial[result.event.id]!,
                                  ),
                                )
                              else
                                _LifeEventReviewCard(result: result),
                          ],
                        );
                      }
                      final evidence =
                          checks.data ??
                          const <String, BnnEventTimingAssessmentV371>{};
                      return Column(
                        children: [
                          if (!checks.hasData && widget.birthData != null)
                            const Text(
                              'D1/D-చక్రం, దశ, Swiss గోచార పరిశీలన జరుగుతోంది…',
                              style: TextStyle(fontSize: 12),
                            ),
                          for (final result in visible)
                            if (_financial.containsKey(result.event.id))
                              BnnFinancialCardV373(
                                assessment: _financial[result.event.id]!,
                                loadTiming: () => _loadFinancial(
                                  _financial[result.event.id]!,
                                ),
                              )
                            else
                              _LifeEventReviewCard(
                                result: result,
                                assessment: evidence[result.event.id],
                              ),
                        ],
                      );
                    },
                  ),
                ],
              );
            },
          ),
        ],
      ],
    ),
  );
}

class _LifeEventReviewCard extends StatelessWidget {
  final BnnLifeEventReview result;
  final BnnEventTimingAssessmentV371? assessment;
  const _LifeEventReviewCard({required this.result, this.assessment});

  static String names(List<String> planets) => planets
      .map((p) => BnnHouseRelationService.planetLabels[p] ?? p)
      .join(' + ');

  static String age(double number) => number == number.roundToDouble()
      ? number.toStringAsFixed(0)
      : number.toStringAsFixed(1);

  @override
  Widget build(BuildContext context) {
    final e = result.event;
    final ages = result.displayReviewContacts;
    final rawCount = result.candidates.length;
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ExpansionTile(
        key: ValueKey('bnn-life-${e.id}'),
        title: Text(
          e.titleTe,
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
        ),
        subtitle: Text(
          result.datesWithheldForSafety
              ? 'సంప్రదాయ నియమాల పరిశీలన మాత్రమే • వయస్సు / తేదీ అంచనా ఇవ్వము'
              : (assessment?.hasScreenedWindow ?? false)
              ? 'జ్యోతిష్య కాల సూచన ఉంది • ${ages.length} సాంకేతిక స్పర్శకాలాలు'
              : 'సంఘటన సమయం పెండింగ్ • ${ages.length} సాంకేతిక స్పర్శకాలాలు',
          style: const TextStyle(fontSize: 11.5),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 13),
        children: [
          const Divider(height: 14),
          _label(
            assessment?.hasEventSpecificRule ?? false
                ? '1. రూల్ (IF–THEN) — మూల వర్గ నియమం వర్తించింది'
                : '1. రూల్ (IF–THEN) — మూల నియమం పెండింగ్',
          ),
          Text(
            (assessment?.hasEventSpecificRule ?? false)
                ? '${assessment!.sourceRuleId}: ${assessment!.sourceRuleText} '
                      'ఈ మూల వర్గ సూచన సంఘటన జరిగే తేదీకి స్వతంత్ర నిర్ధారణ కాదు.'
                : 'LE-V370-${e.id} అనేది సంఘటన పరిశీలన ID మాత్రమే; '
                      'ధృవీకరించిన సంఘటన IF–THEN రూల్ కాదు. '
                      'గురు–శని స్పర్శలను IF–THEN ఫలితాలుగా ఉపయోగించరాదు.',
            style: const TextStyle(fontSize: 12.5, height: 1.45),
          ),
          const SizedBox(height: 7),
          _label('2. జాతక పరిశీలన'),
          Text(
            'పరిశీలన వర్గాలు: ${e.reviewVargas.join(' + ')}. '
            'పరిశీలించాల్సిన భావాలు: ${e.reviewHouses}. '
            'గ్రహ కారకత్వ సూచిక: ${names(e.reviewPlanets)}. '
            '${assessment?.matchedInspection ?? 'ఈ అంశానికి కొత్త వర్గ Rule Match ఇంకా లేదు.'}',
            style: const TextStyle(fontSize: 12.5, height: 1.45),
          ),
          const SizedBox(height: 7),
          _label('3. సంఘటన సమయం / ఫలితం'),
          if (result.datesWithheldForSafety)
            const Text(
              'ఈ అంశానికి ఖచ్చిత మరణ, ఆయుర్దాయ, వ్యాధి లేదా '
              'ప్రమాద వయస్సు/తేదీ ఇవ్వడం లేదు. సంబంధిత చారిత్రక '
              'నియమాలు ఆధారాలతో పరిశీలించాల్సి ఉంది.',
              style: TextStyle(fontSize: 12.5, height: 1.45),
            ),
          if (!result.datesWithheldForSafety) ...[
            if (assessment?.hasScreenedWindow ?? false) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFFE1F2E8),
                  border: Border.all(color: const Color(0xFF72AA83)),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'ప్రధాన జ్యోతిష్య కాల సూచన — నమూనా గోచార మద్దతు',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 12.5,
                      ),
                    ),
                    Text(
                      'వయస్సు ${assessment!.windows.first.ageAtSample.toStringAsFixed(1)} • '
                      '${assessment!.windows.first.sampledLocal.toIso8601String().substring(0, 10)}',
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 17,
                      ),
                    ),
                    Text(
                      'దశ: ${assessment!.windows.first.mahaLord} / '
                      '${assessment!.windows.first.antarLord}',
                      style: const TextStyle(fontSize: 12.5),
                    ),
                    Text(
                      '${assessment!.windows.first.jupiterTransit} • '
                      '${assessment!.windows.first.saturnTransit}',
                      style: const TextStyle(fontSize: 11.5),
                    ),
                    if (assessment!.windows.length > 1)
                      Text(
                        'ఇతర పరిశీలన వయస్సులు: '
                        '${assessment!.windows.skip(1).map((w) => w.ageAtSample.toStringAsFixed(1)).join(', ')}',
                        style: const TextStyle(fontSize: 11.5),
                      ),
                    const Text(
                      'ఇవి దశా–గోచార నమూనా ఆధారాలున్న జ్యోతిష్య కాల సూచనలు. '
                      'సంఘటన ధృవీకరణ/హామీ కాదు; చంద్రుని స్వల్పకాల ట్రిగ్గర్ '
                      'ఇంకా గణించలేదు.',
                      style: TextStyle(fontSize: 11.5, height: 1.4),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 7),
              Text(
                'మూల రూల్: ${assessment!.sourceRuleId} • '
                '${assessment!.sourceCitation}',
                style: const TextStyle(fontSize: 11.5),
              ),
              Text(
                '${assessment!.natalInspection}',
                style: const TextStyle(fontSize: 11.5),
              ),
            ] else ...[
              const Text(
                'తుది సంఘటన వయస్సు: నిర్ణయించలేదు. '
                'సంబంధిత మూలనియమం, వర్గ రూల్, దశ మరియు వాస్తవ గోచారం '
                'కలిసి సరిపోలిన కాలం ఇంకా లభించలేదు.',
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w600,
                  height: 1.45,
                ),
              ),
              if (assessment != null)
                Text(
                  'D${assessment!.factor} మూలనియమం: '
                  '${assessment!.sourceRuleId ?? 'వర్తించలేదు'} • '
                  'పరీక్షించిన దశా కాలాలు: ${assessment!.dashaCandidatesExamined}',
                  style: const TextStyle(fontSize: 11.5),
                ),
              if (assessment == null)
                Text(
                  'పెండింగ్ ఆధారాలు: '
                  '${result.evidenceGate.missingChecks.join(' • ')}',
                  style: const TextStyle(
                    fontSize: 11.5,
                    color: Color(0xFF576B7C),
                  ),
                ),
            ],
            if (rawCount > 0)
              ExpansionTile(
                key: ValueKey('bnn-v370-technical-${e.id}'),
                title: const Text(
                  'టెక్నికల్ గ్రహస్పర్శలు (సంఘటన వయస్సులు కావు)',
                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  '${ages.length} పరిశీలన ఫోకస్‌లో • '
                  '${result.outsideDisplayFocusCount} ఫోకస్ బయట',
                  style: const TextStyle(fontSize: 11),
                ),
                childrenPadding: const EdgeInsets.only(bottom: 6),
                children: [
                  Text(
                    'డిస్‌ప్లే వయస్సు పరిధి: '
                    '${age(e.reviewAgeFrom)}–${age(e.reviewAgeTo)}. '
                    'ఇది కేవలం స్క్రీన్ ఫిల్టర్; సంఘటన జరగదనే '
                    'నియమం కాదు. అన్ని గణన స్పర్శలు ${rawCount}.',
                    style: const TextStyle(fontSize: 11.5, height: 1.4),
                  ),
                  for (final c in ages.take(5))
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(9),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF1F4F7),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'గ్రహస్పర్శ వయస్సు ${age(c.ageFrom)}–${age(c.ageTo)}',
                              style: const TextStyle(
                                fontSize: 12.5,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              'గురు: ${names(c.jupiterContacts)} '
                              '(${c.jupiterCalculationId})',
                              style: const TextStyle(fontSize: 11.5),
                            ),
                            Text(
                              'శని: ${names(c.saturnContacts)} '
                              '(${c.saturnCalculationId})',
                              style: const TextStyle(fontSize: 11.5),
                            ),
                            if (c.hasTraditionalSourceExample)
                              Text(
                                'ఉదాహరణ ఆధారం: ${c.sourceRuleIds.join(', ')} '
                                '— ఈ సంఘటన తుది నియమం కాదు',
                                style: const TextStyle(fontSize: 11.5),
                              ),
                          ],
                        ),
                      ),
                    ),
                  if (ages.length > 5)
                    Text(
                      'ఇంకా ${ages.length - 5} ఫోకస్ స్పర్శకాలాలు ఉన్నాయి.',
                      style: const TextStyle(fontSize: 11.5),
                    ),
                  if (ages.isEmpty)
                    const Text(
                      'ఈ డిస్‌ప్లే ఫోకస్‌లో స్పర్శలు లేవు; '
                      'దీనివల్ల సంఘటన జరగదని అర్థం కాదు.',
                      style: TextStyle(fontSize: 11.5),
                    ),
                ],
              ),
          ],
          const SizedBox(height: 7),
          _label('4. పరిహారం'),
          const Text(
            'ధృవీకరించిన ప్రత్యేక పరిహార మూల నియమం జత కాలేదు.',
            style: TextStyle(fontSize: 12.5),
          ),
          const SizedBox(height: 7),
          _label('5. మూలాధారం / స్థితి'),
          Text(
            e.sourceNoteTe,
            style: const TextStyle(
              fontSize: 11.5,
              height: 1.45,
              color: Color(0xFF536778),
            ),
          ),
          Text(
            (assessment?.hasScreenedWindow ?? false)
                ? 'v371లో వర్తించిన D${assessment!.factor} మూల నియమం, '
                      'వింశోత్తరి మహాదశ/అంతర్దశ, Swiss Ephemeris గురు–శని '
                      'వాస్తవ గోచార నమూనాలు పోల్చబడ్డాయి. చంద్రుని చివరి '
                      'రోజు స్థాయి ట్రిగ్గర్ పెండింగ్. ఇది హామీ కాదు.'
                : 'BNN గురు/శని సరళ ప్రోగ్రెషన్ = గణన ఆధారం మాత్రమే. '
                      'మిగతా స్వతంత్ర రూల్, దశ–గోచార ఆధారాలు ఇంకా సరిపోలలేదు. '
                      'స్పర్శ వయస్సు = సంఘటన వయస్సు కాదు.',
            style: const TextStyle(fontSize: 11.5, height: 1.45),
          ),
        ],
      ),
    );
  }

  Widget _label(String label) => Align(
    alignment: Alignment.centerLeft,
    child: Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(
        label,
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12.5),
      ),
    ),
  );
}
