import 'astro_models.dart';
import 'd2_dhana_asthi_registry.dart';
import 'd2_wealth_evaluation_service.dart';

enum BnnFinancialTone { favorable, unfavorable, neutral }

class BnnFinancialEvidence {
  final D2DhanaAsthiRule rule;
  final String inspection;
  final BnnFinancialTone tone;
  const BnnFinancialEvidence(this.rule, this.inspection, this.tone);
}

class BnnFinancialAssessment {
  final String eventId;
  final List<BnnFinancialEvidence> matches;
  final Map<String, String> pendingRules;
  final List<String> unmatchedRuleIds;
  final bool hasRequiredInputs;
  const BnnFinancialAssessment({
    required this.eventId,
    required this.matches,
    required this.pendingRules,
    required this.unmatchedRuleIds,
    required this.hasRequiredInputs,
  });

  // A natal rule match contains no timing proof. Cycle ages never enter
  // this assessment, including when both favorable and adverse rules match.
  String get timingText =>
      'సంఘటన సమయం: నిర్ణయించలేదు. '
      'వర్తించిన రూల్‌కు సంబంధించిన దశ–అంతర్దశ, వాస్తవ గోచారం కలిపి '
      'ధృవీకరించాలి. గ్రహస్పర్శ వయస్సు సంపాదన/నష్ట తేదీ కాదు.';
  String get statusText => !hasRequiredInputs
      ? 'గణనకు సమాచారం లేదు'
      : matches.isNotEmpty
      ? 'జాతకంలో మూల షరతులు సరిపోలాయి'
      : 'పరీక్షించిన రూల్స్ వర్తించలేదు';
}

/// Presentation mapping of existing source evaluations; no new astrology,
/// amounts, percentages, exact dates, or inferred outcomes are introduced.
class BnnFinancialEvidenceServiceV373 {
  static const eventRules = <String, List<String>>{
    'WEALTH': [
      'D2-DY-001',
      'D2-DY-002',
      'D2-IN-001',
      'D2-IN-002',
      'D2-IN-003',
      'D2-IN-005',
      'D2-IN-007',
      'D2-IN-009',
      'D2-IN-012',
      'D2-OT-005',
    ],
    'PROFIT': ['D2-OT-002', 'D2-LB-001'],
    'SAVINGS': [
      'D2-CS-001',
      'D2-CS-002',
      'D2-CS-003',
      'D2-LB-002',
      'D2-IN-006',
    ],
    'LOSS': ['D2-IN-004', 'D2-IN-006', 'D2-IN-008', 'D2-CS-003', 'D2-OT-003'],
  };
  static const titles = <String, String>{
    'WEALTH': 'ధన సంపాదన / ఆర్థిక ఎదుగుదల',
    'PROFIT': 'లాభాలు',
    'SAVINGS': 'ధన నిల్వ',
    'LOSS': 'ధన నష్టం / ఆటంకాలు',
  };

  static bool supports(String eventId) => eventRules.containsKey(eventId);

  static bool hasInputs(AstroChartResult chart) {
    const requiredNames = {
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    };
    return chart.ascendantLongitude.isFinite &&
        requiredNames.every(
          (name) =>
              chart.planets.any((p) => p.name == name && p.longitude.isFinite),
        );
  }

  static Map<String, BnnFinancialAssessment> evaluate(AstroChartResult chart) =>
      fromMatches(
        hasInputs(chart) ? D2WealthEvaluationService.evaluate(chart) : [],
        hasRequiredInputs: hasInputs(chart),
      );

  static Map<String, BnnFinancialAssessment> fromMatches(
    List<D2WealthMatch> evaluated, {
    bool hasRequiredInputs = true,
  }) {
    final registry = {for (final r in D2DhanaAsthiRegistry.rules) r.id: r};
    final valid = <String, D2WealthMatch>{};
    if (hasRequiredInputs) {
      for (final hit in evaluated) {
        if (registry.containsKey(hit.ruleId) &&
            !D2WealthEvaluationService.pendingReason.containsKey(hit.ruleId)) {
          valid.putIfAbsent(hit.ruleId, () => hit);
        }
      }
    }
    return Map.unmodifiable({
      for (final event in eventRules.entries)
        event.key: _assessment(
          event.key,
          event.value,
          valid,
          registry,
          hasRequiredInputs,
        ),
    });
  }

  static BnnFinancialAssessment _assessment(
    String id,
    List<String> ids,
    Map<String, D2WealthMatch> hits,
    Map<String, D2DhanaAsthiRule> registry,
    bool complete,
  ) {
    final matches = <BnnFinancialEvidence>[];
    final pending = <String, String>{};
    final unmatched = <String>[];
    for (final ruleId in ids) {
      final reason = D2WealthEvaluationService.pendingReason[ruleId];
      if (reason != null) {
        pending[ruleId] = reason;
        continue;
      }
      final hit = hits[ruleId];
      if (hit == null) {
        if (complete) unmatched.add(ruleId);
        continue;
      }
      // Ordinary non-exalted malefic means modest wealth/effort in the
      // source, not a loss result. Preserve the original source wording.
      final tone = ruleId == 'D2-IN-003'
          ? BnnFinancialTone.neutral
          : hit.caution
          ? BnnFinancialTone.unfavorable
          : BnnFinancialTone.favorable;
      matches.add(BnnFinancialEvidence(registry[ruleId]!, hit.evidence, tone));
    }
    matches.sort((a, b) => a.tone.index.compareTo(b.tone.index));
    return BnnFinancialAssessment(
      eventId: id,
      matches: List.unmodifiable(matches),
      pendingRules: Map.unmodifiable(pending),
      unmatchedRuleIds: List.unmodifiable(unmatched),
      hasRequiredInputs: complete,
    );
  }
}
