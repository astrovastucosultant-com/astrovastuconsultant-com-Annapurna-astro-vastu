import '../models/birth_data.dart';
import 'astro_models.dart';
import 'bnn_financial_evidence_v373.dart';
import 'd2_wealth_evaluation_service.dart';
import 'dasha_service.dart';
import 'goel_transit_support_v375.dart';

typedef FinancialPlanetAtUtc = Future<PlanetPosition> Function(
  String planet,
  DateTime utc,
);

class FinancialDashaPair {
  final DashaPeriod maha, antar;
  const FinancialDashaPair(this.maha, this.antar);
}

class FinancialRuleTimingLink {
  final String ruleId;
  final BnnFinancialTone tone;
  final Set<String> sourcePlanets;
  final Set<String> activePlanets;
  final Map<String, int> transitTargets;
  const FinancialRuleTimingLink({
    required this.ruleId,
    required this.tone,
    required this.sourcePlanets,
    required this.activePlanets,
    required this.transitTargets,
  });
}

class FinancialTimingWindow {
  final double? sampledAge;
  final GoelTransitSupport? goelSupport;
  final DateTime periodStart, periodEnd, sampledLocal;
  final String maha, antar;
  final int jupiterSign, saturnSign;
  final List<FinancialRuleTimingLink> links;
  const FinancialTimingWindow({
    this.sampledAge,
    this.goelSupport,
    required this.periodStart,
    required this.periodEnd,
    required this.sampledLocal,
    required this.maha,
    required this.antar,
    required this.jupiterSign,
    required this.saturnSign,
    required this.links,
  });
}

class FinancialTimingResult {
  final String eventId;
  final List<FinancialTimingWindow> windows;
  final int periodsExamined, checkpointsExamined;
  final Set<String> rulesWithoutPlanets;
  final bool complete;
  final String? missingInput;
  const FinancialTimingResult({
    required this.eventId,
    required this.windows,
    required this.periodsExamined,
    required this.checkpointsExamined,
    required this.rulesWithoutPlanets,
    this.complete = true,
    this.missingInput,
  });
}

/// App timing cross-check, separate from the original PDF's natal rules.
/// A 45-day sign-level Swiss checkpoint is evidence, NOT an event date.
/// No raw BNN cycle ages, probabilities, invented remedies or observed events.
class BnnFinancialTimingServiceV374 {
  static List<FinancialDashaPair> periodsFor(
    AstroChartResult chart,
    BirthData birth,
  ) {
    final system = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birth.localDateTime,
    );
    return [
      for (final md in system.mahadashas)
        for (final ad in DashaService.subPeriodsFor(system, md))
          FinancialDashaPair(md, ad),
    ];
  }

  static bool hasTransitContact(String planet, int from, int target) {
    if (from < 0 || from > 11 || target < 0 || target > 11) return false;
    final offset = (target - from + 12) % 12;
    return planet == 'Jupiter'
        ? const {0, 4, 6, 8}.contains(offset)
        : planet == 'Saturn' && const {0, 2, 6, 9}.contains(offset);
  }

  static DateTime localToUtc(DateTime local, double offset) => DateTime.utc(
    local.year,
    local.month,
    local.day,
    local.hour,
    local.minute,
    local.second,
    local.millisecond,
    local.microsecond,
  ).subtract(Duration(microseconds: (offset * 3600000000).round()));

  static List<DateTime> checkpoints(DateTime start, DateTime end) {
    if (!end.isAfter(start)) return const [];
    final result = <DateTime>[];
    for (
      var day = start;
      day.isBefore(end);
      day = day.add(const Duration(days: 45))
    )
      result.add(day);
    final last = end.subtract(const Duration(microseconds: 1));
    if (result.last != last) result.add(last);
    return result;
  }

  static Future<FinancialTimingResult> examine({
    required AstroChartResult chart,
    required BirthData? birth,
    required BnnFinancialAssessment assessment,
    required FinancialPlanetAtUtc planetAtUtc,
    List<FinancialDashaPair>? periods,
    bool useGoelRules = false,
  }) async {
    FinancialTimingResult empty({String? missing}) => FinancialTimingResult(
      eventId: assessment.eventId,
      windows: const [],
      periodsExamined: 0,
      checkpointsExamined: 0,
      rulesWithoutPlanets: const {},
      missingInput: missing,
    );
    if (!assessment.hasRequiredInputs ||
        !BnnFinancialEvidenceServiceV373.hasInputs(chart)) {
      return empty(missing: 'పూర్తి జన్మ గ్రహస్థితులు అవసరం');
    }
    if (birth == null ||
        !birth.timezoneOffsetHours.isFinite ||
        birth.timezoneOffsetHours.abs() > 14)
      return empty(missing: 'జన్మ తేదీ, సమయం, టైమ్‌జోన్ అవసరం');
    if (assessment.matches.isEmpty) return empty();
    if (useGoelRules &&
        (GoelTransitSupportV375.financialHouse(assessment.eventId) == null ||
            chart.planets.any((p) => !p.longitude.isFinite) ||
            chart.planets.map((p) => p.name).toSet().length !=
                chart.planets.length)) {
      return empty(
        missing: 'Goel పరిశీలనకు చెల్లుబాటు అయ్యే ప్రత్యేక గ్రహస్థితులు, అంశ భావ ఎంపిక అవసరం',
      );
    }
    // The lower bound is a display focus for personal earnings, not a natal
    // astrology rule or a claim that financial events cannot occur earlier.
    final from = DateTime(
      birth.localDateTime.year + 14,
      birth.localDateTime.month,
      birth.localDateTime.day,
    );
    final until = DateTime(
      birth.localDateTime.year + 86,
      birth.localDateTime.month,
      birth.localDateTime.day,
    );
    final relevant = <String, Set<String>>{};
    final unsupported = <String>{};
    for (final hit in assessment.matches) {
      final names = D2WealthEvaluationService.timingPlanets(chart, hit.rule.id);
      if (names.isEmpty)
        unsupported.add(hit.rule.id);
      else
        relevant[hit.rule.id] = names;
    }
    final windows = <FinancialTimingWindow>[];
    var checked = 0, snapshots = 0;
    final cache = <String, Future<PlanetPosition>>{};
    Future<PlanetPosition> at(String planet, DateTime day) {
      final utc = localToUtc(day, birth.timezoneOffsetHours);
      return cache.putIfAbsent(
        '$planet:${utc.microsecondsSinceEpoch}',
        () => planetAtUtc(planet, utc),
      );
    }

    final pairs = List<FinancialDashaPair>.of(
      periods ?? periodsFor(chart, birth),
    )..sort((a, b) => a.antar.start.compareTo(b.antar.start));
    for (final pair in pairs) {
      final start = pair.antar.start.isBefore(from) ? from : pair.antar.start;
      final end = pair.antar.end.isAfter(until) ? until : pair.antar.end;
      if (!end.isAfter(start)) continue;
      final active = {pair.maha.lord, pair.antar.lord};
      final linked = assessment.matches
          .where((h) => relevant[h.rule.id]?.any(active.contains) ?? false)
          .toList();
      if (linked.isEmpty) continue;
      checked++;
      // One representative supported checkpoint per rule per AD. Favorable
      // and adverse rules are both retained; they are never majority-voted.
      final remaining = {for (final h in linked) h.rule.id};
      final seenSourcePatterns = <String>{};
      for (final day in checkpoints(start, end)) {
        final j = await at('Jupiter', day), s = await at('Saturn', day);
        if (!j.longitude.isFinite ||
            !s.longitude.isFinite ||
            j.name != 'Jupiter' ||
            s.name != 'Saturn') {
          throw StateError('Invalid transit snapshot');
        }
        snapshots++;
        final eventHouse = GoelTransitSupportV375.financialHouse(
          assessment.eventId,
        );
        final goel = useGoelRules && eventHouse != null
            ? GoelTransitSupportV375.evaluate(
                chart: chart,
                eventHouse: eventHouse,
                saturnSign: s.signIndex,
              )
            : null;
        final found = <FinancialRuleTimingLink>[];
        for (final hit in linked.where(
          (h) => useGoelRules || remaining.contains(h.rule.id),
        )) {
          final planets = relevant[hit.rule.id]!;
          final firing = planets.intersection(active);
          final targets = <String, int>{};
          for (final name in firing) {
            final p = chart.planets.firstWhere((p) => p.name == name);
            if (hasTransitContact('Jupiter', j.signIndex, p.signIndex) &&
                hasTransitContact('Saturn', s.signIndex, p.signIndex))
              targets[name] = p.signIndex;
          }
          if (useGoelRules) {
            if (goel == null || !goel.hasMatch) continue;
            final pattern =
                '${hit.rule.id}:${goel.checks.map((c) => c.state.name).join(":")}';
            if (!seenSourcePatterns.add(pattern)) continue;
          } else if (targets.isEmpty) {
            continue;
          }
          found.add(
            FinancialRuleTimingLink(
              ruleId: hit.rule.id,
              tone: hit.tone,
              sourcePlanets: planets,
              activePlanets: Set.unmodifiable(firing),
              transitTargets: Map.unmodifiable(targets),
            ),
          );
          remaining.remove(hit.rule.id);
        }
        if (found.isNotEmpty)
          windows.add(
            FinancialTimingWindow(
              sampledAge:
                  day.difference(birth.localDateTime).inMicroseconds /
                  (365.2425 * 86400000000),
              goelSupport: goel,
              periodStart: start,
              periodEnd: end,
              sampledLocal: day,
              maha: pair.maha.lord,
              antar: pair.antar.lord,
              jupiterSign: j.signIndex,
              saturnSign: s.signIndex,
              links: List.unmodifiable(found),
            ),
          );
        if (!useGoelRules && remaining.isEmpty) break;
      }
    }
    windows.sort((a, b) => a.sampledLocal.compareTo(b.sampledLocal));
    return FinancialTimingResult(
      eventId: assessment.eventId,
      windows: List.unmodifiable(windows),
      periodsExamined: checked,
      checkpointsExamined: snapshots,
      rulesWithoutPlanets: Set.unmodifiable(unsupported),
    );
  }
}
