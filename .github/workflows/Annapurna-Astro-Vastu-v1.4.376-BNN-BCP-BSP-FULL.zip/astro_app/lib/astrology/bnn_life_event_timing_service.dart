import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'bnn_cycle_result_service.dart';
import 'bnn_jupiter_cycle_service.dart';
import 'bnn_saturn_cycle_service.dart';

/// Event names, review karakas and vargas are PROJECT REVIEW METADATA,
/// not independently sourced rules for predicting a person's life events.
class BnnLifeEventDefinition {
  final String id;
  final String titleTe;
  final String category;
  final String categoryTe;
  final List<String> reviewVargas;
  final String reviewHouses;
  final List<String> reviewPlanets;
  final bool reviewOnly;
  final String sourceStatus;
  final String sourceNoteTe;
  /// Optional USER-INTERFACE life-stage focus, not an astrological event rule.
  final double reviewAgeFrom;
  final double reviewAgeTo;

  const BnnLifeEventDefinition({required this.id, required this.titleTe,
    required this.category, required this.categoryTe,
    required this.reviewVargas, required this.reviewHouses,
    required this.reviewPlanets, required this.reviewOnly,
    required this.sourceStatus, required this.sourceNoteTe,
    this.reviewAgeFrom=0, this.reviewAgeTo=100});

  factory BnnLifeEventDefinition.fromJson(Map<String, dynamic> data) {
    final id = data['id'] as String;
    final planets = (data['review_planets'] as List).cast<String>();
    if (id.isEmpty || planets.isEmpty ||
        data['source_status'] != 'METHOD_ONLY') {
      throw const FormatException('Life event review catalog must not assert unverified source rules');
    }
    final scope=data['review_age_scope'] as Map<String,dynamic>?;
    final minAge=(scope?['from'] as num?)?.toDouble() ?? 0;
    final maxAge=(scope?['to'] as num?)?.toDouble() ?? 100;
    if (!minAge.isFinite || !maxAge.isFinite ||
        minAge < 0 || maxAge > 120 || minAge >= maxAge) {
      throw const FormatException('Invalid editorial review age scope');
    }
    return BnnLifeEventDefinition(
      id:id, titleTe:data['title_te'] as String,
      category:data['category'] as String,
      categoryTe:data['category_te'] as String,
      reviewVargas:List.unmodifiable(
        (data['review_vargas'] as List).cast<String>()),
      reviewHouses:data['review_houses'] as String,
      reviewPlanets:List.unmodifiable(planets),
      reviewOnly:data['review_only'] as bool,
      sourceStatus:data['source_status'] as String,
      sourceNoteTe:data['source_note_te'] as String,
      reviewAgeFrom:minAge, reviewAgeTo:maxAge,
    );
  }
}

/// Intersection of two APPROXIMATE age progressions. It is neither a
/// Swiss-Ephemeris transit nor a probability or a confirmed event date.
class BnnLifeEventAgeCandidate {
  final double ageFrom;
  final double ageTo;
  final String jupiterCalculationId;
  final String saturnCalculationId;
  final List<String> jupiterContacts;
  final List<String> saturnContacts;
  final List<String> sourceRuleIds;

  const BnnLifeEventAgeCandidate({required this.ageFrom,
    required this.ageTo, required this.jupiterCalculationId,
    required this.saturnCalculationId, required this.jupiterContacts,
    required this.saturnContacts, required this.sourceRuleIds});

  bool get hasTraditionalSourceExample => sourceRuleIds.isNotEmpty;
}

class BnnLifeEventReview {
  final BnnLifeEventDefinition event;
  final List<BnnLifeEventAgeCandidate> candidates;
  const BnnLifeEventReview({required this.event, required this.candidates});

  /// No ages for death/longevity/serious health and accident predictions.
  bool get datesWithheldForSafety => event.reviewOnly;
  /// Source/dasha/varga/real-transit event matching is NOT wired in this phase.
  /// Therefore candidates must NEVER be re-labelled as confirmed life events.
  bool get hasVerifiedIndividualEventTiming => false;
  bool get hasConfirmedEventAge => false;

  /// Editor's viewing focus only. Never interpret it as a predictive cutoff.
  List<BnnLifeEventAgeCandidate> get displayReviewContacts => List.unmodifiable(
    candidates.where((candidate) =>
      candidate.ageFrom < event.reviewAgeTo &&
      candidate.ageTo > event.reviewAgeFrom));
  int get outsideDisplayFocusCount => candidates.length-displayReviewContacts.length;

  BnnLifeEventEvidenceGate get evidenceGate =>
    BnnLifeEventEvidenceGate.pending(eventId:event.id,
      isSensitive:event.reviewOnly);
}

/// Independent event-specific IF-THEN, D1/varga, dasha and actual transit
/// traces must exist before narrowing to a supported review window. The
/// contact cycles and age-scope metadata NEVER satisfy any of these gates.
class BnnLifeEventEvidenceGate {
  final String eventId;
  final bool isSensitive;
  final String? sourceRuleId;
  final String? natalAndVargaMatchId;
  final String? dashaMatchId;
  final String? actualTransitMatchId;
  const BnnLifeEventEvidenceGate({required this.eventId,
    this.isSensitive=false, this.sourceRuleId,
    this.natalAndVargaMatchId, this.dashaMatchId,
    this.actualTransitMatchId});

  const BnnLifeEventEvidenceGate.pending({required this.eventId,
    this.isSensitive=false}) : sourceRuleId=null,
    natalAndVargaMatchId=null, dashaMatchId=null,
    actualTransitMatchId=null;

  static bool _present(String? reference) =>
    reference != null && reference.trim().isNotEmpty;
  List<String> get missingChecks => List.unmodifiable([
    if(!_present(sourceRuleId)) 'EVENT_SOURCE_RULE',
    if(!_present(natalAndVargaMatchId)) 'NATAL_VARGA_MATCH',
    if(!_present(dashaMatchId)) 'DASHA_MATCH',
    if(!_present(actualTransitMatchId)) 'REAL_TRANSIT_MATCH',
  ]);
  /// Even a fully traced gate is an astrological CROSS-CHECK, not a guarantee.
  bool get readyForTimingReview => !isSensitive && missingChecks.isEmpty;
}

class BnnLifeEventTimingService {
  const BnnLifeEventTimingService._();

  static Future<List<BnnLifeEventDefinition>> loadCatalog() async {
    final json = jsonDecode(await rootBundle.loadString(
      'assets/life_events/life_event_review_catalog_v369.json'))
        as Map<String, dynamic>;
    if (json['schema'] != 'ANNAPURNA-LIFE-EVENT-REVIEW-CATALOG-1.0') {
      throw const FormatException('Unexpected life event review catalog schema');
    }
    final entries = (json['events'] as List)
        .map((value) => BnnLifeEventDefinition.fromJson(
          value as Map<String, dynamic>)).toList(growable:false);
    if (entries.length < 25 ||
        entries.map((e) => e.id).toSet().length != entries.length) {
      throw const FormatException('Life event IDs must be complete and unique');
    }
    return List.unmodifiable(entries);
  }

  static Future<List<BnnLifeEventReview>> build({
    required AstroChartResult chart, double maximumAge = 100,
  }) async {
    final events = await loadCatalog();
    final jThemes = await BnnJupiterCycleService.loadThemes();
    final sThemes = await BnnSaturnCycleService.loadThemes();
    final sourceCatalog = await BnnCycleResultService.load();
    return evaluate(chart:chart, events:events,
      jupiterCycles:BnnJupiterCycleService.calculate(chart:chart,themes:jThemes),
      saturnCycles:BnnSaturnCycleService.calculate(chart:chart,themes:sThemes),
      sourceCatalog:sourceCatalog, maximumAge:maximumAge);
  }

  /// Evidence-only overlapping windows. Source-backed status is NEVER inferred
  /// from mere Jupiter/Saturn contacts or from an unverified event catalog.
  static List<BnnLifeEventReview> evaluate({
    required AstroChartResult chart,
    required List<BnnLifeEventDefinition> events,
    required List<BnnJupiterCycle> jupiterCycles,
    required List<BnnSaturnCycle> saturnCycles,
    required BnnCycleResultCatalog sourceCatalog,
    double maximumAge = 100,
  }) {
    if (maximumAge <= 0 || maximumAge > 120) {
      throw RangeError('maximumAge must be >0 and <=120');
    }
    final years = [for (final cycle in jupiterCycles) ...cycle.years];
    final windows = [for (final cycle in saturnCycles) ...cycle.windows];
    return List.unmodifiable([
      for (final event in events)
        BnnLifeEventReview(event:event,
          candidates:event.reviewOnly ? const [] : List.unmodifiable(
            _intersections(event,years,windows,sourceCatalog,maximumAge))),
    ]);
  }

  static List<BnnLifeEventAgeCandidate> _intersections(
    BnnLifeEventDefinition event,
    List<BnnJupiterCycleYear> jYears,
    List<BnnSaturnContactWindow> sWindows,
    BnnCycleResultCatalog sources,
    double maxAge,
  ) {
    final selected=event.reviewPlanets.toSet();
    final results=<BnnLifeEventAgeCandidate>[];
    for (final j in jYears) {
      if (j.ageStart >= maxAge) continue;
      final jContacts = [for (final p in j.natalSignContacts)
        if (selected.contains(p.name)) p.name];
      if (jContacts.isEmpty) continue;
      for (final s in sWindows) {
        final from=math.max(j.ageStart.toDouble(),s.ageStart);
        final until=math.min(math.min(j.ageEndExclusive.toDouble(),s.ageEnd),maxAge);
        if (from >= until) continue;
        final sContacts=[for(final p in s.natalContacts)
          if(selected.contains(p.name)) p.name];
        if (sContacts.isEmpty) continue;
        // The only independently traced traditional Saturn cycle example
        // in the current BNN data: first-cycle Saturn contact with Rahu
        // as a potential profession ENTRY indicator (not a certainty).
        final namedSource=event.id=='CAREER-ENTRY' &&
          s.firstRoundRahuProfessionIndicator &&
          sources.sourceRules.any((rule) =>
            rule['id']=='BNN-SAT-R1-RAHU' &&
            rule['moving_planet']=='Saturn' &&
            rule['natal_planet']=='Rahu' && rule['cycle']==s.round);
        results.add(BnnLifeEventAgeCandidate(
          ageFrom:from,ageTo:until,
          jupiterCalculationId:j.calculationId,
          saturnCalculationId:s.calculationId,
          jupiterContacts:List.unmodifiable(jContacts),
          saturnContacts:List.unmodifiable(sContacts),
          sourceRuleIds:namedSource
              ? const ['BNN-SAT-R1-RAHU'] : const [],
        ));
      }
    }
    results.sort((a,b) {
      final sourceOrder = (b.hasTraditionalSourceExample ? 1 : 0)
        .compareTo(a.hasTraditionalSourceExample ? 1 : 0);
      return sourceOrder != 0 ? sourceOrder : a.ageFrom.compareTo(b.ageFrom);
    });
    return results;
  }
}
