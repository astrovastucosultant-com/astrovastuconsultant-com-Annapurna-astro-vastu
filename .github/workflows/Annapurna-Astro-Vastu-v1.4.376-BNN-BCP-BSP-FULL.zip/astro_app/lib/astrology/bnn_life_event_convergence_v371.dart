import 'dart:math' as math;

import '../models/birth_data.dart';
import 'astro_calculation_service.dart';
import 'astro_models.dart';
import 'dasha_service.dart';
import 'varga_rule_service.dart';
import 'varga_service.dart';

/// Phase-2: event-specific source evidence + D1/Dn sign lords + real
/// Vimshottari MD/AD + Swiss-Ephemeris transit checkpoints. This is an
/// ASTROLOGICAL SCREENING RESULT, not an observed event or a guarantee.
/// Raw BNN Jupiter/Saturn age cycles do not satisfy these independent gates.
class BnnEventTimingWindowV371 {
  final DateTime sampledLocal;
  final double ageAtSample;
  final String mahaLord;
  final String antarLord;
  final String d1Lord;
  final String vargaLord;
  final String jupiterTransit;
  final String saturnTransit;
  const BnnEventTimingWindowV371({
    required this.sampledLocal,
    required this.ageAtSample,
    required this.mahaLord,
    required this.antarLord,
    required this.d1Lord,
    required this.vargaLord,
    required this.jupiterTransit,
    required this.saturnTransit,
  });
}

class BnnEventTimingAssessmentV371 {
  final String eventId;
  final int factor;
  final String? sourceRuleId;
  final String? sourceCitation;
  final String? sourceRuleText;
  final String? matchedInspection;
  final String? natalInspection;
  final List<BnnEventTimingWindowV371> windows;
  final int dashaCandidatesExamined;
  const BnnEventTimingAssessmentV371({
    required this.eventId,
    required this.factor,
    required this.sourceRuleId,
    required this.sourceCitation,
    required this.sourceRuleText,
    required this.matchedInspection,
    required this.natalInspection,
    required this.windows,
    required this.dashaCandidatesExamined,
  });

  bool get hasEventSpecificRule => sourceRuleId != null;
  bool get hasScreenedWindow => windows.isNotEmpty;
}

class _EventSpecV371 {
  final String eventId;
  final int factor;
  final int natalHouse;
  final int vargaHouse;
  final double minAge;
  final double maxAge;
  final List<String> ruleIds;
  final List<String> karakas;
  const _EventSpecV371(this.eventId, this.factor, this.natalHouse,
    this.vargaHouse, this.minAge, this.maxAge, this.ruleIds, this.karakas);
}

/// The event-specific rule IDs come from ALREADY IMPLEMENTED, supplied-text
/// rule evaluations. Broad metadata and auto-generated event IDs are excluded.
class BnnEventConvergenceServiceV371 {
  const BnnEventConvergenceServiceV371._();
  static const List<String> _rulers = [
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  static const List<_EventSpecV371> _priority = [
    _EventSpecV371('EDU-HIGHER',24,9,9,12,60,
      ['EDU-D24-LEVEL-DEGREE','EDU-D24-LEVEL-PG','EDU-D24-LEVEL-POSTPG'],
      ['Mercury','Jupiter']),
    _EventSpecV371('CAREER-ENTRY',10,10,10,15,80,
      ['D10-CAREER-START'],['Saturn','Sun','Mercury']),
    _EventSpecV371('MARRIAGE',9,7,7,16,80,
      ['S7-D9-01'],['Venus','Jupiter']),
    _EventSpecV371('CHILDREN',7,5,5,16,70,
      ['D7-SANTANA-002'],['Jupiter','Moon']),
    _EventSpecV371('HOUSE',4,4,4,18,85,
      ['S3-D4-H4-BEN'],['Mars','Venus']),
  ];

  static List<String> get priorityIds =>
    List.unmodifiable(_priority.map((x)=>x.eventId));

  static int _targetHouseSign(int ascendantSign, int house) =>
    (ascendantSign + house - 1) % 12;

  static String houseLord(int ascendantSign, int house) =>
    _rulers[_targetHouseSign(ascendantSign,house)];

  static bool _hasRashiDrishti(int transiting, int target, String planet) {
    final offset=(target-transiting+12)%12;
    // Sidereal sign-level conjunction and standard Parashari sign aspects.
    // This is NOT the exact degree/orb or a birth-chart event rule.
    return switch(planet){
      'Jupiter' => const {0,4,6,8}.contains(offset),
      'Saturn' => const {0,2,6,9}.contains(offset),
      _ => false,
    };
  }

  static bool supportsDashaPair({
    required String maha,
    required String antar,
    required Set<String> eventHouseLords,
    required Set<String> eventKarakas,
  }) {
    final triggers={...eventHouseLords,...eventKarakas};
    return (eventHouseLords.contains(maha) || eventHouseLords.contains(antar)) &&
      triggers.contains(maha) && triggers.contains(antar);
  }

  static bool supportsTransitSnapshot({
    required int jupiterSign,
    required int saturnSign,
    required int targetSign,
  }) => _hasRashiDrishti(jupiterSign,targetSign,'Jupiter') &&
        _hasRashiDrishti(saturnSign,targetSign,'Saturn');

  /// Search a qualifying Vimshottari AD across its span, not just three
  /// arbitrary instants. Regular ~45-day checks reduce omitted sign contacts.
  /// These are checkpoints only, not exact ingress or event dates.
  static List<DateTime> transitCheckpoints(DashaPeriod period) {
    if (!period.end.isAfter(period.start)) return const <DateTime>[];
    final checkpoints=<DateTime>[];
    final finalDay=period.end.subtract(const Duration(days:1));
    var current=period.start;
    while (current.isBefore(period.end) && checkpoints.length<30) {
      checkpoints.add(current);
      current=current.add(const Duration(days:45));
    }
    // Include the end only when the period was short enough to scan fully.
    if (finalDay.isAfter(checkpoints.last) &&
        checkpoints.length<31) checkpoints.add(finalDay);
    return List.unmodifiable(checkpoints);
  }

  static DateTime _toUtc(DateTime local, double timezone) => DateTime.utc(
    local.year, local.month, local.day, local.hour,
    local.minute, local.second, local.millisecond,
  ).subtract(Duration(minutes:(timezone*60).round()));

  static double _age(DateTime birth, DateTime at) =>
    at.difference(birth).inHours / (365.2425*24.0);

  static Future<Map<String,BnnEventTimingAssessmentV371>> examine({
    required AstroChartResult chart,
    required BirthData birth,
    int maxPeriodsPerEvent=18,
  }) async {
    if(maxPeriodsPerEvent<1 || maxPeriodsPerEvent>40){
      throw RangeError.range(maxPeriodsPerEvent,1,40,'maxPeriodsPerEvent');
    }
    final vim=DashaService.system(kind:DashaSystemKind.vimshottari,
      chart:chart,birthDateTime:birth.localDateTime);
    final result=<String,BnnEventTimingAssessmentV371>{};
    // One cache per chart, so different events at the same checkpoint do not
    // perform the same Swiss-Ephemeris calculation repeatedly.
    final planetCache=<String,Future<PlanetPosition>>{};
    Future<PlanetPosition> at(String planet,DateTime day){
      final key='$planet:${day.millisecondsSinceEpoch}';
      return planetCache.putIfAbsent(key,()=>
        AstroCalculationService.calculatePlanetAtUtc(
          utc:_toUtc(day,birth.timezoneOffsetHours),
          planetName:planet,ayanamsa:birth.ayanamsa));
    }
    for(final spec in _priority){
      final matched=VargaRuleService.applicableFor(
        chart:chart,factor:spec.factor,birthDateTime:birth.localDateTime);
      final applicable=matched.where((h)=>
        spec.ruleIds.contains(h.ruleId) &&
        h.tone==VargaRuleTone.favorable &&
        h.autoEvaluated && h.applicable).toList();
      final hit=applicable.isEmpty ? null : applicable.first;
      final dn=VargaService.calculate(chart,spec.factor);
      final natalLord=houseLord(chart.ascendantSignIndex,spec.natalHouse);
      final vargaLord=houseLord(dn.ascendantSignIndex,spec.vargaHouse);
      final inspection='D1 ${spec.natalHouse}వ అధిపతి $natalLord; '
        'D${spec.factor} ${spec.vargaHouse}వ అధిపతి $vargaLord; '
        'పరిశీలించిన మూల రూల్ ${hit?.ruleId ?? 'వర్తించలేదు'}.';
      if(hit==null){
        result[spec.eventId]=BnnEventTimingAssessmentV371(
          eventId:spec.eventId,factor:spec.factor,
          sourceRuleId:null,sourceCitation:null,
          sourceRuleText:null,matchedInspection:null,
          natalInspection:inspection,windows:const [],
          dashaCandidatesExamined:0);
        continue;
      }
      final lords={natalLord,vargaLord};
      final qualifying=<({DashaPeriod maha,DashaPeriod antar})>[];
      for(final maha in vim.mahadashas){
        for(final antar in DashaService.subPeriodsFor(vim,maha)){
          final ageFrom=_age(birth.localDateTime,antar.start);
          final ageTo=_age(birth.localDateTime,antar.end);
          if(ageTo<spec.minAge || ageFrom>spec.maxAge)continue;
          // One lord has to be directly connected to D1/Dn house rulers,
          // not merely a generic BNN Jupiter/Saturn progression contact.
          if(!supportsDashaPair(maha:maha.lord,antar:antar.lord,
            eventHouseLords:lords,eventKarakas:spec.karakas.toSet()))continue;
          qualifying.add((maha:maha,antar:antar));
        }
      }
      qualifying.sort((a,b)=>a.antar.start.compareTo(b.antar.start));
      final found=<BnnEventTimingWindowV371>[];
      // Examine regular dates across AD, not three isolated points.
      // A snapshot is NOT an exact ingress, event date or Moon-day trigger.
      for(final p in qualifying.take(maxPeriodsPerEvent)){
        for(final day in transitCheckpoints(p.antar)){
          final age=_age(birth.localDateTime,day);
          if(age<spec.minAge || age>spec.maxAge)continue;
          final j=await at('Jupiter',day);
          final s=await at('Saturn',day);
          final target=_targetHouseSign(chart.ascendantSignIndex,spec.natalHouse);
          if(!supportsTransitSnapshot(jupiterSign:j.signIndex,
            saturnSign:s.signIndex,targetSign:target))continue;
          found.add(BnnEventTimingWindowV371(
            sampledLocal:day,ageAtSample:age,
            mahaLord:p.maha.lord,antarLord:p.antar.lord,
            d1Lord:natalLord,vargaLord:vargaLord,
            jupiterTransit:'Jupiter ${j.signIndex+1} → D1 target ${target+1}',
            saturnTransit:'Saturn ${s.signIndex+1} → D1 target ${target+1}',
          ));
          break; // A source/dasha period is one timing candidate, not 3 votes.
        }
        if(found.length>=3)break;
      }
      result[spec.eventId]=BnnEventTimingAssessmentV371(
        eventId:spec.eventId,factor:spec.factor,
        sourceRuleId:hit.ruleId,sourceCitation:hit.source,
        sourceRuleText:hit.rule,matchedInspection:hit.inspection,
        natalInspection:inspection,
        windows:List.unmodifiable(found),
        dashaCandidatesExamined:math.min(qualifying.length,maxPeriodsPerEvent),
      );
    }
    return Map.unmodifiable(result);
  }
}
