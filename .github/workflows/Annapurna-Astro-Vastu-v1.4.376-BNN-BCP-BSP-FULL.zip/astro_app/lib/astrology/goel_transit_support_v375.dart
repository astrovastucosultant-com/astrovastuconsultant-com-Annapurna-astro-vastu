import 'astro_models.dart';
import 'varga_service.dart';

enum GoelTransitState { matched, unmatched, missing }

/// One complete source rule is one check. Its OR alternatives are not votes.
class GoelTransitCheck {
  final String id, title, inspection;
  final int pdfPage;
  final bool adverse;
  final GoelTransitState state;
  const GoelTransitCheck({
    required this.id,
    required this.title,
    required this.pdfPage,
    required this.adverse,
    required this.state,
    required this.inspection,
  });
  String get statusTe => switch (state) {
    GoelTransitState.matched => 'వర్తించింది',
    GoelTransitState.unmatched => 'వర్తించలేదు',
    GoelTransitState.missing => 'గణనకు సమాచారం లేదు',
  };
}

class GoelTransitSupport {
  final int eventHouse;
  final List<GoelTransitCheck> checks;
  const GoelTransitSupport(this.eventHouse, this.checks);
  bool get hasMatch => checks.any((c) => c.state == GoelTransitState.matched);

  /// Null means no evaluable source rule; it must not be displayed as zero.
  double? percent({required bool adverse}) {
    final unique = {
      for (final c in checks.where((c) => c.adverse == adverse)) c.id: c,
    };
    final evaluated = unique.values
        .where((c) => c.state != GoelTransitState.missing)
        .toList();
    if (evaluated.isEmpty) return null;
    return 100 *
        evaluated.where((c) => c.state == GoelTransitState.matched).length /
        evaluated.length;
  }
}

/// Verified against user-supplied gocharam v p goel.pdf, pages 1, 3–5, 7–8, 10.
/// 85: event-house lord -> its D9 sign + sign lord -> natal chart -> Saturn trinal occupancy or direct aspect (see source examples).
/// 86: eighth lord FROM the event house; same procedure for adverse indication.
/// Chapter 85 indicates activation, not necessarily a favorable outcome.
/// Percent is an app rule-match ratio, never an empirical event probability.
class GoelTransitSupportV375 {
  static const lords = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];
  // Explicit app event-to-house mapping; the source supplies the house method.
  static int? financialHouse(String eventId) => switch (eventId) {
    'WEALTH' || 'SAVINGS' || 'LOSS' => 2,
    'PROFIT' => 11,
    _ => null,
  };
  static int eighthFrom(int house) => ((house - 1 + 7) % 12) + 1;
  static bool trine(int a, int b) =>
      a >= 0 && a < 12 && b >= 0 && b < 12 && (a - b).abs() % 4 == 0;
  // Examples: p3 Gemini->Leo (3rd), p4 Aquarius->Leo (7th),
  // p10 Pisces->Sagittarius (10th). These direct aspects accompany the
  // rule text's trinal occupancy. Do not aspect every trine recursively.
  static bool aspect(int from, int target) =>
      from >= 0 &&
      from < 12 &&
      target >= 0 &&
      target < 12 &&
      const {2, 6, 9}.contains((target - from + 12) % 12);
  static bool relation(int from, int target) =>
      trine(from, target) || aspect(from, target);

  static GoelTransitSupport evaluate({
    required AstroChartResult chart,
    required int eventHouse,
    required int? saturnSign,
  }) {
    GoelTransitCheck check(bool adverse) {
      final chapter = adverse ? 86 : 85;
      final title = adverse
          ? 'భావానికి ప్రతికూల శని సూచన'
          : 'భావ సంఘటనకు శని సంబంధం';
      GoelTransitCheck result(GoelTransitState state, String text) =>
          GoelTransitCheck(
            id: 'GOEL-$chapter',
            title: title,
            pdfPage: adverse ? 5 : 1,
            adverse: adverse,
            state: state,
            inspection: text,
          );
      if (eventHouse < 1 ||
          eventHouse > 12 ||
          !chart.ascendantLongitude.isFinite ||
          saturnSign == null ||
          saturnSign < 0 ||
          saturnSign > 11) {
        return result(
          GoelTransitState.missing,
          'భావం, జన్మ లగ్నం, శని గోచార రాశి అవసరం',
        );
      }
      final byName = <String, PlanetPosition>{};
      for (final p in chart.planets) {
        if (!p.longitude.isFinite || byName.containsKey(p.name)) {
          return result(
            GoelTransitState.missing,
            'చెల్లుబాటు అయ్యే ప్రత్యేక గ్రహస్థితులు అవసరం',
          );
        }
        byName[p.name] = p;
      }
      final selectedHouse = adverse ? eighthFrom(eventHouse) : eventHouse;
      final sign =
          ((chart.ascendantLongitude / 30).floor() + selectedHouse - 1) % 12;
      final lord = lords[sign];
      if (!byName.containsKey(lord))
        return result(GoelTransitState.missing, '$lord జన్మస్థితి అవసరం');
      final d9 = VargaService.calculate(chart, 9);
      final navSign = d9.planets.firstWhere((p) => p.name == lord).signIndex;
      final navLord = lords[navSign];
      final natal = byName[navLord];
      if (natal == null)
        return result(GoelTransitState.missing, '$navLord జన్మస్థితి అవసరం');
      final signMatch = relation(saturnSign, navSign);
      final lordMatch = relation(saturnSign, natal.signIndex);
      return result(
        signMatch || lordMatch
            ? GoelTransitState.matched
            : GoelTransitState.unmatched,
        'సంఘటన భావం $eventHouse; పరిశీలన భావం $selectedHouse; అధిపతి $lord; '
        'D9 రాశి ${navSign + 1}; D9 రాశి అధిపతి $navLord జన్మ రాశి ${natal.signIndex + 1}; '
        'గోచార శని రాశి ${saturnSign + 1}. '
        'D9 రాశి త్రికోణ స్థితి: ${trine(saturnSign, navSign) ? "అవును" : "కాదు"}; '
        'D9 రాశిపై శని 3/7/10 దృష్టి: ${aspect(saturnSign, navSign) ? "అవును" : "కాదు"}; '
        'అధిపతి జన్మ రాశి త్రికోణ స్థితి: ${trine(saturnSign, natal.signIndex) ? "అవును" : "కాదు"}; '
        'అధిపతిపై శని 3/7/10 దృష్టి: ${aspect(saturnSign, natal.signIndex) ? "అవును" : "కాదు"}. '
        'ఈ రెండింటిలో ఏదైనా ఒకటి సరిపోతే పూర్తి రూల్ వర్తిస్తుంది.',
      );
    }

    return GoelTransitSupport(
      eventHouse,
      List.unmodifiable([check(false), check(true)]),
    );
  }
}
