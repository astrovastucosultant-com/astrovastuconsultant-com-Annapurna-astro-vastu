import 'astro_models.dart';
import 'bcp_app_adapter.dart';
import 'bcp_master_engine.dart';
import 'bsp_service.dart';

/// Application event/house mapping, not a newly discovered classical sutra.
class UnifiedEvent376 {
  final String id, title;
  final int mainHouse;
  final Set<int> houses;
  final double ageFrom, ageTo;
  final bool sensitive;
  const UnifiedEvent376({
    required this.id,
    required this.title,
    required this.mainHouse,
    required this.houses,
    this.ageFrom = 0,
    this.ageTo = 120,
    this.sensitive = false,
  });
}

class UnifiedLifeContext376 {
  final String role;
  final bool? hadFirstJob;
  final bool? married;
  const UnifiedLifeContext376({
    this.role = 'unknown',
    this.hadFirstJob,
    this.married,
  });
}

/// These are STRUCTURAL HOUSE COVERAGE scores. They are not IF-THEN event
/// probabilities, source weights, or a calibration from observed outcomes.
class UnifiedChannel376 {
  final String name;
  final Set<int> directHouses, linkedHouses;
  final List<String> traces;
  final bool available;
  const UnifiedChannel376(
    this.name,
    this.directHouses,
    this.linkedHouses,
    this.traces, {
    this.available = true,
  });
  Set<int> get houses => {...directHouses, ...linkedHouses};
  Set<int> hits(UnifiedEvent376 event) => houses.intersection(event.houses);
  double? coverage(UnifiedEvent376 event) => !available || event.houses.isEmpty
      ? null
      : 100 * hits(event).length / event.houses.length;
}

class UnifiedEventEvidence376 {
  final UnifiedEvent376 event;
  final UnifiedChannel376 saturn, jupiter, bcp, bsp;
  final Set<int> commonHouses;
  final List<String> sourceRules, cautions;
  const UnifiedEventEvidence376({
    required this.event,
    required this.saturn,
    required this.jupiter,
    required this.bcp,
    required this.bsp,
    required this.commonHouses,
    required this.sourceRules,
    required this.cautions,
  });
  bool get bothRelated =>
      saturn.hits(event).isNotEmpty && jupiter.hits(event).isNotEmpty;
  // House intersection and BCP/BSP support cannot manufacture a natal promise.
  bool get confirmedEvent => false;
}

class UnifiedAgeWindow376 {
  final double ageFrom, ageTo;
  final DateTime start, end, sampledLocal;
  final int saturnCycle, jupiterCycle, saturnSign, jupiterSign, runningYear;
  final List<UnifiedEventEvidence376> events;
  const UnifiedAgeWindow376({
    required this.ageFrom,
    required this.ageTo,
    required this.start,
    required this.end,
    required this.sampledLocal,
    required this.saturnCycle,
    required this.jupiterCycle,
    required this.saturnSign,
    required this.jupiterSign,
    required this.runningYear,
    required this.events,
  });
}

class BnnUnifiedEvidenceService376 {
  static const lords = [
    'Mars',
    'Venus',
    'Mercury',
    'Moon',
    'Sun',
    'Mercury',
    'Venus',
    'Mars',
    'Jupiter',
    'Saturn',
    'Saturn',
    'Jupiter',
  ];
  static int house(int asc, int sign) => (sign - asc + 12) % 12 + 1;
  static DateTime anniversary(DateTime birth, int age) => DateTime(
    birth.year + age,
    birth.month,
    birth.day,
    birth.hour,
    birth.minute,
    birth.second,
    birth.millisecond,
    birth.microsecond,
  );
  static DateTime ageDate(DateTime birth, double age) {
    final years = age.floor();
    final a = anniversary(birth, years), b = anniversary(birth, years + 1);
    return a.add(
      Duration(
        microseconds: ((b.difference(a).inMicroseconds) * (age - years))
            .round(),
      ),
    );
  }

  static void validateChart(AstroChartResult chart) {
    const required = {
      'Sun',
      'Moon',
      'Mars',
      'Mercury',
      'Jupiter',
      'Venus',
      'Saturn',
      'Rahu',
      'Ketu',
    };
    if (!chart.ascendantLongitude.isFinite ||
        chart.planets.any(
          (p) => !p.longitude.isFinite || p.longitude < 0 || p.longitude >= 360,
        ) ||
        chart.planets.map((p) => p.name).toSet().length !=
            chart.planets.length ||
        !required.every((name) => chart.planets.any((p) => p.name == name))) {
      throw ArgumentError(
        'పూర్తి, చెల్లుబాటు అయ్యే ప్రత్యేక జన్మ గ్రహస్థితులు అవసరం',
      );
    }
  }

  static List<UnifiedAgeWindow376> evaluate({
    required AstroChartResult chart,
    required DateTime birth,
    required int completedAge,
    required List<UnifiedEvent376> events,
    required List<Map<String, dynamic>> cycleSourceRules,
    UnifiedLifeContext376 context = const UnifiedLifeContext376(),
  }) {
    validateChart(chart);
    if (completedAge < 0 || completedAge > 100)
      throw RangeError('Age must be 0–100');
    final ids = <String>{};
    for (final e in events) {
      if (!ids.add(e.id) ||
          e.mainHouse < 1 ||
          e.mainHouse > 12 ||
          !e.houses.contains(e.mainHouse) ||
          e.houses.any((h) => h < 1 || h > 12))
        throw ArgumentError('Invalid event mapping');
    }
    final asc = chart.ascendantSignIndex;
    final natal = {for (final p in chart.planets) p.name: p};
    final edges = <double>{completedAge.toDouble(), completedAge + 1.0};
    for (var n = 1; n <= 48; n++) {
      final boundary = n * 2.5;
      if (boundary > completedAge && boundary < completedAge + 1)
        edges.add(boundary);
    }
    final cuts = edges.toList()..sort();
    final result = <UnifiedAgeWindow376>[];
    for (var i = 0; i < cuts.length - 1; i++) {
      final from = cuts[i], to = cuts[i + 1], mid = (from + to) / 2;
      final jc = (mid / 12).floor() + 1, sc = (mid / 30).floor() + 1;
      final js = (natal['Jupiter']!.signIndex + mid.floor() % 12) % 12;
      final so = ((mid % 30) / 2.5).floor(),
          ss = (natal['Saturn']!.signIndex + so) % 12;
      UnifiedChannel376 progression(String name, int sign, String id) {
        final contacts = chart.planets
            .where((p) => p.signIndex == sign)
            .toList();
        final linked = <int>{};
        for (final p in contacts) {
          for (var h = 1; h <= 12; h++) {
            if (lords[(asc + h - 1) % 12] == p.name) linked.add(h);
          }
        }
        return UnifiedChannel376(
          name,
          {house(asc, sign)},
          linked,
          [
            '$id • గణన ID; సంఘటన మూల Rule ID కాదు',
            'ప్రోగ్రెషన్ రాశి ${sign + 1}; ప్రత్యక్ష భావం ${house(asc, sign)}; '
                'తాకిన జన్మ గ్రహాలు: ${contacts.map((p) => p.name).join(", ")}; '
                'అనుసంధాన భావాలు = ఆ గ్రహాల జన్మ అధిపత్య భావాలు.',
            name == 'శని'
                ? 'assets/bnn/bnn_saturn_cycles_v356.json • సరళ 2.5 ఏళ్లు/రాశి; నిజ గోచారం కాదు'
                : 'assets/bnn/bnn_jupiter_cycles_v355.json • సరళ ఏడాదికి ఒక రాశి; నిజ గోచారం కాదు',
          ],
        );
      }

      final s = progression('శని', ss, 'BNN-SAT-C$sc-S${so + 1}');
      final j = progression('గురు', js, 'BNN-JUP-C$jc-AGE${mid.floor()}');
      final sample = ageDate(birth, mid);
      final activation = BcpEngine.activations(
        chart: BcpAppAdapter.fromAstroChart(chart),
        birthDate: birth,
        onDate: sample,
      ).single;
      final bcp = UnifiedChannel376(
        'BCP',
        {activation.activatedNatalHouse},
        {},
        [
          '${activation.methodRuleId} • running year ${activation.runningYear}; భావం ${activation.activatedNatalHouse}',
          'assets/bcp/bcp_rule_catalog.json • జన్మలగ్న ఆధారం మాత్రమే; వేరియంట్లు కలపలేదు',
        ],
      );
      final bspYear = BspService.evaluateYear(
        chart: chart,
        birthDateTime: birth,
        year: activation.runningYear,
      );
      final bspHouses = <int>{};
      final bspTrace = <String>[];
      final seenBsp = <String>{};
      for (final a in bspYear.activations) {
        if (!seenBsp.add(a.rule.id)) continue;
        // Optional and 25%-qualified points remain visible but are not promoted
        // into a full-strength match. Scan-unclear rules are not scored.
        if (a.rule.exactArithmeticAvailable) {
          for (final offset in a.rule.primaryOffsets) {
            bspHouses.add(house(asc, (a.natalSign + offset) % 12));
          }
        }
        bspTrace.add(
          '${a.rule.id} • ${a.rule.source}\n${a.reason}\n'
          'OR/optional భావాలు: ${a.optionalTargetHouses.join(", ")}; '
          'qualified offsets: ${a.rule.weightedOffsets}; ${a.rule.sourceNote}',
        );
      }
      if (bspYear.bsp37 != null) {
        bspTrace.add(
          'BSP37 ఉపపరిశీలన: ${bspYear.bsp37!.matched}; '
          'స్వతంత్ర ఖచ్చిత భావ activationగా స్కోర్ చేయలేదు',
        );
      }
      final hasExact = BspService.rules.any(
        (r) => r.year == activation.runningYear && r.exactArithmeticAvailable,
      );
      final bsp = UnifiedChannel376(
        'BSP',
        bspHouses,
        {},
        bspTrace,
        available: hasExact,
      );
      final reviews = <UnifiedEventEvidence376>[];
      for (final event in events) {
        final common = s.hits(event).intersection(j.hits(event));
        final traces = <String>[];
        final seen = <String>{};
        // Only the independently traced first-round Saturn/Rahu career rule.
        // No generic house or karaka match is relabelled an event sutra.
        for (final rule in cycleSourceRules) {
          final id = rule['id'];
          if (id != 'BNN-SAT-R1-RAHU' ||
              !seen.add(id as String) ||
              !{'CAREER-ENTRY', 'CAREER-BUSINESS'}.contains(event.id) ||
              rule['moving_planet'] != 'Saturn' ||
              rule['natal_planet'] != 'Rahu' ||
              rule['cycle'] != sc ||
              natal['Rahu']!.signIndex != ss)
            continue;
          traces.add(
            '$id • ${rule["source"]} • ${rule["page"]}\n'
            '${rule["if_te"]}\n${rule["then_te"]}',
          );
        }
        final cautions = <String>[];
        if (context.role == 'unknown')
          cautions.add('పాత్ర/ప్రస్తుత స్థితి తెలియదు; ఊహించలేదు.');
        if (from < event.ageFrom || from >= event.ageTo)
          cautions.add(
            'సాధారణ వయస్సు పరిశీలన పరిధికి బయట ఉంది; సూచనను తొలగించలేదు.',
          );
        if (event.id.startsWith('MARRIAGE') && from < 18)
          cautions.add('బాల్య భావసంబంధాన్ని వివాహ సంఘటనగా అర్థం చేసుకోరాదు.');
        if (event.id == 'CAREER-ENTRY' && context.hadFirstJob == true)
          cautions.add(
            'మొదటి ఉద్యోగం ఇప్పటికే జరిగింది; ఈ కాలాన్ని మొదటి ఉద్యోగ వయస్సుగా ప్రకటించరాదు.',
          );
        if (event.id == 'MARRIAGE' && context.married == true)
          cautions.add(
            'వివాహం ఇప్పటికే జరిగింది; మళ్లీ వివాహమని ఈ సంబంధంతో నిర్ణయించరాదు.',
          );
        if (event.sensitive)
          cautions.add(
            'జాగ్రత్త అవసరం అనే పరిశీలన మాత్రమే; మరణ/వ్యాధి/ప్రమాద తేదీ లేదా శాతం ఇవ్వలేదు.',
          );
        reviews.add(
          UnifiedEventEvidence376(
            event: event,
            saturn: s,
            jupiter: j,
            bcp: bcp,
            bsp: bsp,
            commonHouses: Set.unmodifiable(common),
            sourceRules: List.unmodifiable(traces),
            cautions: List.unmodifiable(cautions),
          ),
        );
      }
      // Retain ALL events, including low/zero, contradictory and incomplete
      // coverage. No threshold, count-based winner or first-window prediction.
      result.add(
        UnifiedAgeWindow376(
          ageFrom: from,
          ageTo: to,
          start: ageDate(birth, from),
          end: ageDate(birth, to),
          sampledLocal: sample,
          saturnCycle: sc,
          jupiterCycle: jc,
          saturnSign: ss,
          jupiterSign: js,
          runningYear: activation.runningYear,
          events: List.unmodifiable(reviews),
        ),
      );
    }
    return List.unmodifiable(result);
  }
}
