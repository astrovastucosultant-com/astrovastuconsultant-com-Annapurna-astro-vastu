# v1.4.375 — user-supplied Goel Saturn source rules

Implemented scope: four financial cards (WEALTH, PROFIT, SAVINGS, LOSS), preserving existing natal D2 rules and matched-rule Vimshottari MD/AD selection.

Verified source: user-uploaded `gocharam v p goel.pdf`, chapter 85 on PDF page 1 (examples pp2–4); chapter 86 on PDF page 5 (examples pp6–10). Read source images are included in docs/goel_transit_source_v375. PDF numbering differs from printed book numbering. These are the source's two separate rules; no Jupiter transit rule is inferred from them.

85: select event house, find its natal lord's Navamsa sign and the lord of that sign; map sign and dispositor to D1. The rule text describes trinal relation; examples also use direct Saturn aspects. The app accepts trinal occupancy (same/5th/9th sign) OR a direct Saturn 3rd/7th/10th aspect to EITHER the D9 sign OR its dispositor's natal sign. This computational interpretation is disclosed in the UI. It does not recursively aspect every sign of every trine. It signifies activation, not automatically a beneficial event.

86: use the eighth lord counted FROM the selected event house, then the same D9-sign/dispositor procedure. Keep its adverse indication separate from chapter 85. Both may match. No subtraction or majority vote.

Explicit app mapping (not claimed as a table in the source): WEALTH/SAVINGS/LOSS → house 2; PROFIT → house 11. Earnings are shown in the existing age 14–85 display focus. This focus is not a rule excluding earlier events.

Production financial panel calls source mode. Legacy generic Jupiter/Saturn same-target method remains a separately labelled comparison, excluded from source percentages and not required by Goel 85/86. Legacy service default remains for older callers and regression fixtures. The five other life-event cards retain their existing v371 method; they are not labelled Goel-integrated.

Each full source rule counts once. OR branches never count as separate evidence. Display ratio = matched/evaluable whole rules. With one chapter in each channel, 0% or 100% is expected; 100% means 1/1 rule matched, NOT certainty. No empirical calibration or book-supplied numerical weights exist. Missing inputs are null, not 0%; source, inspection and status are visible on tapping the score. No final event probability is calculated.

Source scan samples every 45 days plus AD's final instant, retains the first occurrence of each distinct 85/86 status pattern per natal rule per AD (including adverse patterns), and shows sample age/date. Those dates are neither exact ingress boundaries nor predicted event dates. Retrograde sign returns can have unshown repeated checkpoints. Whole AD is context, not a claim that support holds throughout it.

Guru transit percentage is unavailable until a verified Guru transit source rule is implemented. Natal Jupiter in chapters 89/90 must not be counted as transit Jupiter. Chapters 87–90 and 91 onward are not implemented here; Chara-dasha configuration and influence definitions need verification before coding. Do not label this release a complete implementation of the PDF.

No remedy has been invented. Missing source rule, evaluated nonmatch, missing input are distinct statuses.

Validation: Dart pure source tests 43, including all four chapter-85 worked examples and a chapter-86 house-relative example; existing financial evidence checks 25; existing timing checks 20. Targeted Dart analyzer clean. Flutter widget tests and APK build require the supplied GitHub workflow; they have NOT been run locally (no Flutter SDK). New widget cases test score expansion/source text/Material ancestry and missing score; old lazy/retry tests remain enabled.

No signing keys, observed personal events or external uploads were added to the app.
