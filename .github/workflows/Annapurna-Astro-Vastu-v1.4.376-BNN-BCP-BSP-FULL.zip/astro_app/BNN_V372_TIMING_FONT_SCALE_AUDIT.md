# Annapurna Astro Vastu v1.4.372 — BNN Timing Review + Font Size

## Applied
- App-wide accessible text-size multiplier, 90%–150%, 10% increments.
- BNN page A− / A+ / reset controls; preference stored by shared_preferences.
- Retains Android/system accessibility font scale while applying user preference.
- Qualifying Vimshottari ADs screened at ~45-day checkpoints (up to 30 + tail) instead of three isolated dates.
- Existing D1/Dn applicable source-rule gate, MD/AD, and Swiss transit checks retained; no speculative dates.
- Prior BNN and life event flows preserved; five event categories remain the current supported scope.

## Limits / testing
- No actual Flutter/Gradle compiler is installed in the offline packaging environment. The GitHub workflow must run Flutter tests and assemble the APK.
- Sample transit checkpoint is **not** an event time or exact ingress; cannot alone establish the event age.
- More D9/D24/D7/D10/D4 verified rule matching, exact entry/exit transit search, and Moon triggers remain separate future work.
- Increasing text size can expose legacy fixed-size layouts; verify on phones and tablets at 150% after APK build.
