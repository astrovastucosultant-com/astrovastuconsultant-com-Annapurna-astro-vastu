# BNN v1.4.369 — Unified Life Events: Phase 1

## Implemented
- 28 distinct life-event review topics, in JSON with stable IDs, Telugu labels, prospective D1/D-varga and bhava review targets, and preliminary graha karakatwas.
- One BNN-tab expansion panel with category selector, candidate age intervals, source calculation IDs, and explicit source status.
- Age intervals = intersections of *approximate*, chart-specific natal-sign Jupiter and Saturn progressions. Two independently modeled sign cycles need not describe a real event.
- First-round Saturn-on-natal-Rahu traditional profession-entry *indication* is preserved as a traceable BNN-SAT-R1-RAHU rule **only when** the existing source catalog has that ID and the exact cycle guard matches.
- No particular personal event is marked confirmed: event-specific classical IF–THEN + varga, dasha + real Swiss Ephemeris transits are NOT implemented by this module.
- Sensitive conditions (relative's death, accidents, illness, lifespan) are *review-only* and never output personal event ages/dates.

## Not yet implemented (not claimed)
1. Varga-specific event IF–THEN matching; existing module files unchanged.
2. Swiss Ephemeris transit search and the Sun/Moon day trigger; retrograde movement and time-zone handling.
3. BNN/BSP/BCP/BPD/Yogini/Jaimini source-based evidence integration with historical event validation.
4. Final unified predictive timing windows and calibrated confidence/accuracy measurements.

## Test/audit notes
- `test/bnn_life_event_timing_v369_test.dart` (five tests) for schema, intersections, sensitive review-only, missing planets and source-guard.
- Tests bundled but **Flutter SDK is not installed in this working runtime**; run with GitHub Actions before publishing APK.
- JSON is explicitly labeled `METHOD_ONLY`/not a classical source rule. Age candidate ≠ event occurred; no invented remedies or percentages.
- Base: `Annapurna-Astro-Vastu-v1.4.368-UI-ListTile-Fix-FULL.zip`; prior files retained except BNN master panel insertion and pubspec version/assets declaration.
