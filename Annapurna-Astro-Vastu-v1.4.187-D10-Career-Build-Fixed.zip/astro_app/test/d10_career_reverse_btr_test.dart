import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_career_reverse_service.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';
import 'package:astro_app/astrology/astro_models.dart';

void main() {
  const sampleChart = AstroChartResult(
    julianDay: 2451545, ayanamsaDegrees: 23.5,
    ascendantLongitude: 0, engineVersion: 'unit-test',
    planets: [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 1, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 2, latitude: 0, speed: 1),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 3, latitude: 0, speed: 1),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 4, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 5, latitude: 0, speed: 1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 6, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 7, latitude: 0, speed: 1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 8, latitude: 0, speed: 1),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 9, latitude: 0, speed: 1),
    ],
  );

  test('reverse search exposes real source rules including gas agency', () {
    final all = D10VruttiMatchEngine.evaluate(sampleChart);
    expect(all.length, 336);
    final results = D10CareerReverseLookup.search('గ్యాస్ ఏజెన్సీ', all);
    expect(results, isNotEmpty);
    expect(results.any((x) => x.match != null), isTrue);
    expect(results.any((x) => x.id == 'VR-069'), isTrue);
    expect(results.first.relevance, greaterThanOrEqualTo(2));
  });

  test('manual unmatched events must not invent BTR source predicates', () {
    final event = D10CareerEvent(
      id: 'e-1', occupation: 'Unlisted new profession', ruleId: '',
      date: DateTime(2025, 1, 1), type: 'వృత్తి ప్రారంభం');
    final actual = D10CareerReverseLookup.rulesForEvent(
        event, D10VruttiMatchEngine.evaluate(sampleChart));
    expect(actual, isEmpty);
  });

  test('Career Events serialize date, occupation, source id and notes', () {
    final event = D10CareerEvent(
      id: '123', occupation: 'టీచర్', ruleId: 'VR-190',
      date: DateTime(2020, 8, 12), type: 'పదోన్నతి', notes: 'verified date');
    final restored = D10CareerEvent.fromJson(event.toJson());
    expect(restored.date, DateTime(2020, 8, 12));
    expect(restored.ruleId, 'VR-190');
    expect(restored.notes, 'verified date');
  });

  test('candidate search symmetric, bounded and chronological', () {
    final center = DateTime(1990, 5, 3, 11, 15);
    final times = D10CareerBtrService.candidateTimes(center, rangeMinutes: 3);
    expect(times.length, 7);
    expect(times.first, DateTime(1990, 5, 3, 11, 12));
    expect(times.last, DateTime(1990, 5, 3, 11, 18));
    expect(() => D10CareerBtrService.candidateTimes(center, rangeMinutes: 11),
        throwsArgumentError);
  });

  test('event comparison gate count never exceeds five', () {
    final e = D10CareerEvent(id: 'one', occupation: 'టీచర్',
      ruleId: '', date: DateTime(2010), type: 'వృత్తి ప్రారంభం');
    final evidence = D10CareerEventEvidence(event: e,
      matchedRuleId: 'test-rule', hasRule: true,
      natalConfirmed: true, ruleConditions: true,
      mahadashaSupport: false, antardashaSupport: true,
      transitSupport: false, mahadasha: 'Moon',
      antardasha: 'Mercury', reasons: const []);
    expect(evidence.gatesMatched, 3);
    expect(evidence.allAligned, isFalse);
  });
}
