import 'package:flutter/material.dart';

/// D10 percentage presentation, shared by profession catalog and reverse search.
/// A green score means a *D1→D10 confirmed evidence index* exists;
/// it is not a promise of career success or a fully satisfied IF–THEN rule.
class D10PercentVisual {
  static const Color green = Color(0xFF16743A);
  static const Color greenSurface = Color(0xFFEAF7EE);
  static const Color grey = Color(0xFF636B73);
  static const Color greySurface = Color(0xFFF4F5F6);
  static const Color pending = Color(0xFF9B5A00);
  static const Color pendingSurface = Color(0xFFFFF5E8);

  static Color foreground(bool confirmed) => confirmed ? green : grey;
  static Color background(bool confirmed) => confirmed ? greenSurface : greySurface;
  static String percentLabel(bool confirmed, int percent) =>
      confirmed ? '$percent%' : 'నిర్ధారణ లేదు';
}
