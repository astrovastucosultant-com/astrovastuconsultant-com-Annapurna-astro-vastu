import 'astro_models.dart';
import 'bnn_master_service.dart';
import '../models/birth_data.dart';

/// Study-only timing bands explicitly traceable to existing BNN catalog
/// rounds. These are not calculated transits or verified event forecasts.
class BnnEventWindow {
  final String name;
  final String sourceId;
  final int fromAge;
  final int toAge;
  final String prerequisite;
  const BnnEventWindow(this.name, this.sourceId, this.fromAge,
      this.toAge, this.prerequisite);

  int firstYear(BirthData birth) => birth.localDateTime.year + fromAge;
  int lastYear(BirthData birth) => birth.localDateTime.year + toAge + 1;
  String get sourceStatus => 'అధ్యయన పరిధి మాత్రమే • సంఘటన నిర్ధారణ కాదు';
}

class BnnEventRelations {
  /// A03 states six Jupiter rounds with subject domains. A04 describes
  /// Saturn rounds. A chart must still satisfy a source-specific IF predicate
  /// and transit/nakshatra evidence before timing an actual event.
  static const List<BnnEventWindow> studyWindows = [
    BnnEventWindow('జీవన ప్రారంభం / వ్యక్తిగత అభివృద్ధి', 'BNN-BOOK-R-A03', 0, 11,
        'గురు మొదటి చక్రం; నిర్దిష్ట వ్యక్తిగత సంఘటన నిర్ధారణ కాదు'),
    BnnEventWindow('కుటుంబం, ఆర్థికం, వివాహం', 'BNN-BOOK-R-A03', 12, 23,
        'గురు రెండవ చక్రం; శుక్ర నక్షత్రం/రవాణా ధృవీకరణ అవసరం (R-A06)'),
    BnnEventWindow('ప్రయాణాలు / సోదర సంబంధాలు', 'BNN-BOOK-R-A03', 24, 35,
        'గురు మూడవ చక్రం; సంబంధిత గ్రహ రవాణా ధృవీకరణ అవసరం'),
    BnnEventWindow('ఇల్లు / స్థిరాస్తి కొనుగోలు', 'BNN-BOOK-C19', 36, 47,
        'గురు నాలుగవ చక్రం; గురు నుండి నాలుగవ రాశిలో కుజుడు ఉండే షరతు అవసరం'),
    BnnEventWindow('సంతానం / సంతాన బాధ్యతలు', 'BNN-BOOK-R-A03', 48, 59,
        'గురు ఐదవ చక్రం; సంతాన కారకత్వం, దృష్టులు, రవాణా చూడాలి'),
    BnnEventWindow('తీర్థయాత్ర', 'BNN-BOOK-C07', 24, 35,
        'గురు మూడవ రౌండ్‌లో కేతును తాకే రవాణా షరతు అవసరం'),
    BnnEventWindow('సోదరుల ద్వారా ధనం', 'BNN-BOOK-C18', 24, 35,
        'మూడవ అధిపతి గురుకి 2లో, కుజ/శుక్ర రవాణా అవసరం'),
    BnnEventWindow('వృత్తి ప్రారంభానికి శని–రాహు సంబంధం', 'BNN-BOOK-R-A05', 0, 29,
        'శని మొదటి చక్రం; రాశి దూరం × 2.5 సూత్రం; శని–రాహు/శుక్ర స్పర్శను ధృవీకరించాలి'),
    BnnEventWindow('వృత్తి ప్రారంభానికి శని చక్ర పరిశీలన', 'BNN-BOOK-R-A04', 0, 29,
        'శని మొదటి చక్రం; శని–రాహు స్పర్శను ధృవీకరించాలి (R-A05)'),
  ];

  static BnnMasterRule? findRule(List<BnnMasterRule> rules, String id) {
    for (final rule in rules) {
      if (rule.id == id) return rule;
    }
    return null;
  }

  static bool? placementCondition(BnnEventWindow window, AstroChartResult chart) {
    if (window.sourceId != 'BNN-BOOK-C19') return null;
    for (final planet in chart.planets) {
      if (planet.name == 'Mars') {
        return BnnMasterAnalysis.houseOfPlanet(planet, chart) == 4;
      }
    }
    return null;
  }

  static String period(BnnEventWindow w, BirthData birth, DateTime now) {
    final age = BnnMasterAnalysis.completedAge(birth.localDateTime, now);
    if (age > w.toAge) return 'గత అధ్యయన కాలం';
    if (age < w.fromAge) return 'భవిష్యత్ అధ్యయన కాలం';
    return 'ప్రస్తుత అధ్యయన కాలం';
  }

  static const List<BnnRelationGroup> relations = [
    BnnRelationGroup('తల్లి', 'Moon', 4, ['తల్లి', 'మాతృ', 'అమ్మ']),
    BnnRelationGroup('తండ్రి', 'Sun', 9, ['తండ్రి', 'పితృ', 'నాన్న']),
    BnnRelationGroup('భార్య / జీవిత భాగస్వామి', 'Venus', 7,
        ['భార్య', 'వివాహ', 'కళత్ర', 'దాంపత్య']),
    BnnRelationGroup('భర్త / జీవిత భాగస్వామి', 'Mars', 7,
        ['భర్త', 'పతి', 'వివాహ', 'కళత్ర', 'దాంపత్య']),
    BnnRelationGroup('అన్న / తమ్ముడు', 'Mars', 3,
        ['సోదర', 'అన్న', 'తమ్ముడు']),
    BnnRelationGroup('అక్క / చెల్లెలు', 'Venus', 3,
        ['సోదరి', 'అక్క', 'చెల్లెల']),
    BnnRelationGroup('కుమారుడు / కుమార్తె', 'Jupiter', 5,
        ['సంతాన', 'పుత్ర', 'కుమార', 'బిడ్డ', 'పిల్ల']),
    BnnRelationGroup('పెద్ద సోదరులు', 'Mars', 11,
        ['పెద్దన్న', 'అన్న', 'పెద్ద సోదర']),
    BnnRelationGroup('తాత / నానమ్మ', 'Sun', 9,
        ['తాత', 'నానమ్మ', 'పితామహ', 'వంశ']),
    BnnRelationGroup('అమ్మమ్మ / తల్లి తరపు పెద్దలు', 'Moon', 4,
        ['అమ్మమ్మ', 'మాతామహ', 'తల్లి']),
    BnnRelationGroup('మామ / అత్త', 'Venus', 7,
        ['మామ', 'అత్త', 'వియ్యంక', 'బావమరిది']),
    BnnRelationGroup('మేనమామ / మేనత్త', 'Moon', 6,
        ['మేనమామ', 'మేనత్త', 'మాతుల']),
    BnnRelationGroup('మనవలు / మనవరాళ్లు', 'Jupiter', 5,
        ['మనవ', 'సంతాన', 'పుత్ర']),
    BnnRelationGroup('స్నేహితులు', 'Mercury', 11,
        ['స్నేహిత', 'మిత్ర', 'సహచర']),
    BnnRelationGroup('గురువు / ఉపాధ్యాయులు', 'Jupiter', 9,
        ['గురువు', 'ఉపాధ్యాయ']),
    BnnRelationGroup('బంధువులు / దాయాదులు', 'Moon', 2,
        ['బంధువ', 'దాయాద', 'కుటుంబ', 'వంశ']),
  ];

  /// Relationship classification MUST describe the person named by the
  /// THEN outcome. Planet names in IF, generic topic tags, and words like
  /// "కుటుంబం" are NOT proof a rule predicts a specific relative.
  /// This remains an *index*, not an IF-predicate evaluator.
  static const Map<String, List<String>> _resultMentions = {
    'తల్లి': ['తల్లి', 'మాతృబంధ', 'అమ్మ'],
    'తండ్రి': ['తండ్రి', 'పితృ', 'నాన్న'],
    'భార్య / జీవిత భాగస్వామి': ['భార్య', 'కళత్ర', 'దాంపత్య'],
    'భర్త / జీవిత భాగస్వామి': ['భర్త', 'భార్యాభర్త', 'పతి'],
    'అన్న / తమ్ముడు': ['సోదరుడు', 'సోదరుల', 'సోదర సంఖ్య', 'అన్న', 'తమ్ముడు'],
    'అక్క / చెల్లెలు': ['సోదరి', 'సోదరీ', 'చెల్లెల', 'అక్క'],
    'కుమారుడు / కుమార్తె': ['సంతాన', 'పుత్ర', 'కుమార', 'పిల్లలు', 'బిడ్డ'],
    'పెద్ద సోదరులు': ['పెద్దన్న', 'పెద్ద సోదర', 'అన్నయ్య'],
    'తాత / నానమ్మ': ['తాత', 'నానమ్మ', 'పితామహ'],
    'అమ్మమ్మ / తల్లి తరపు పెద్దలు': ['అమ్మమ్మ', 'మాతామహ'],
    'మామ / అత్త': ['మామ', 'అత్త', 'వియ్యంక', 'బావమరిది'],
    'మేనమామ / మేనత్త': ['మేనమామ', 'మేనత్త', 'మాతుల'],
    'మనవలు / మనవరాళ్లు': ['మనవ', 'మనుమ'],
    'స్నేహితులు': ['స్నేహిత', 'మిత్ర', 'సహచర'],
    'గురువు / ఉపాధ్యాయులు': ['జాతకుని గురువు', 'జాతకుడి గురువు', 'ఉపాధ్యాయులు'],
    'బంధువులు / దాయాదులు': ['బంధువ', 'దాయాద'],
  };

  static bool resultIsAboutRelation(BnnRelationGroup group, BnnMasterRule rule) {
    final terms = _resultMentions[group.name];
    if (terms == null || terms.isEmpty) return false;
    final result = rule.result.trim();
    if (!terms.any(result.contains)) return false;
    // 'తల్లి భర్త' is the mother's husband, not the user's spouse.
    if (group.name == 'తల్లి' && result.contains('మాతృభాష') &&
        !result.contains('తల్లి') && !result.contains('అమ్మ')) {
      return false;
    }
    if (group.name == 'భర్త / జీవిత భాగస్వామి' &&
        (result.contains('తల్లి భర్త') || result.contains('తండ్రి భర్త'))) {
      return false;
    }
    // These broad kinship tabs do not inherit every rule about 'family',
    // 'marriage', or planetary Jupiter simply because of a shared word.
    return true;
  }

  static List<BnnMasterRule> sourceRulesFor(
    BnnRelationGroup group, List<BnnMasterRule> rules,
  ) => rules.where((r) => resultIsAboutRelation(group, r))
      .toList(growable: false);

  /// Observable same-sign chain *and* an explicit relative in the THEN.
  /// This is only a preliminary contact; do not state a person's health,
  /// relationships or fate as verified without full IF evaluation.
  static List<BnnMasterRule> tentativeRelationsFor(
    BnnRelationGroup group, List<BnnMasterRule> rules,
    AstroChartResult chart,
  ) => sourceRulesFor(group, rules).where((r) =>
      BnnMasterAnalysis.hasSingleSignPlacement(r, chart))
      .toList(growable: false);

  static String natalReference(BnnRelationGroup group, AstroChartResult chart) {
    final house = group.relatedHouse;
    final sign = (BnnMasterAnalysis.bnnReferenceSignIndex(chart) + house - 1) % 12;
    final contacts = BnnMasterAnalysis.planetsInHouse(chart, house);
    final karaka = chart.planets.where((p) => p.name == group.karaka);
    final karakaText = karaka.isEmpty
        ? 'కారకగ్రహం అందుబాటులో లేదు'
        : '${group.karaka}: ${BnnMasterAnalysis.signNames[karaka.first.signIndex]} '
          '${karaka.first.degreesInSign.toStringAsFixed(2)}° • '
          'గురు నుంచి ${BnnMasterAnalysis.houseOfPlanet(karaka.first, chart)}వ భావం';
    final contactText = contacts.isEmpty
        ? 'ఆ భావంలో గ్రహాలు లేవు'
        : contacts.map((p) => '${p.name} ${p.degreesInSign.toStringAsFixed(2)}°').join(', ');
    return 'సంబంధిత పరిశీలన భావం $house (${BnnMasterAnalysis.signNames[sign]}) • '
        '$karakaText • భావంలోని గ్రహాలు: $contactText';
  }

  static const List<String> favorableWords = [
    'లాభ', 'శుభ', 'సంతోష', 'మంచి', 'ఆభివృద్ధి', 'అభివృద్ధి', 'ధనవంత', 'సహకార', 'ప్రతిష్ఠ', 'ఉపకార',
  ];
  static const List<String> adverseWords = [
    'ఆలస్య', 'నష్టం', 'కష్టం', 'అడ్డంక', 'వివాద', 'కలహ', 'అనారోగ', 'దురదృష్ట', 'సమస్య', 'విడాక', 'అపకీర్త', 'మోస',
  ];

  /// Return neutral without an observable catalog predicate match.
  static int polarity(BnnMasterRule rule, AstroChartResult chart) {
    if (rule.status != 'FACTS_REQUIRED' ||
        BnnMasterAnalysis.tentativeNatalPlacement(rule, chart) == null) {
      return 0;
    }
    final positive = favorableWords.any(rule.result.contains);
    final negative = adverseWords.any(rule.result.contains);
    if (positive == negative) return 0;
    return positive ? 1 : -1;
  }
}

class BnnRelationGroup {
  final String name;
  final String karaka;
  final int relatedHouse;
  final List<String> keywords;
  const BnnRelationGroup(this.name, this.karaka, this.relatedHouse, this.keywords);
}
