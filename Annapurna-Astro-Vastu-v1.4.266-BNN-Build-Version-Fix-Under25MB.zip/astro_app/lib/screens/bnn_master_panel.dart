import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_master_service.dart';
import '../astrology/bnn_bhava_topics.dart';
import '../astrology/bnn_event_relations.dart';
import '../models/birth_data.dart';

class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnMasterRule>> _catalog = BnnMasterCatalog.load();
  int _selectedHouse = 1;
  int _mainTab = 0; // 0 bhava, 1 event study, 2 relations
  int _selectedRelation = 0;
  int _selectedSubTab = 0; // 0 results, 1 yogas, 2 past, 3 present, 4 future
  String _search = '';
  int _resultsLimit = 8;
  int _yogaLimit = 5;
  bool _showAllTopics = false;
  int _topicLimit = 4;
  bool _showExpandedContacts = false;

  static const _burgundy = Color(0xFF7B1E2B);
  static const _muted = Color(0xFF62666D);
  static const _panelBg = Color(0xFFF7F8FA);
  static const _cardBg = Colors.white;

  // Distinct but coordinated colors for the twelve bhava selectors.
  // Pastel backgrounds remain readable; selected cards use their deeper accent.
  static const _bhavaColors = <Color>[
    Color(0xFF00796B), Color(0xFF2055A6), Color(0xFF7746A0),
    Color(0xFF3A7D44), Color(0xFFC16C1B), Color(0xFFAD3768),
    Color(0xFF3D5CBB), Color(0xFF93613D), Color(0xFF7148BD),
    Color(0xFF087E9E), Color(0xFF58802C), Color(0xFF99354F),
  ];
  static const _subTabColors = <Color>[
    Color(0xFF00796B), // జాతక పరిశీలన
    Color(0xFF6E45AA), // యోగాలు
    Color(0xFF4569AF), // భూతం
    Color(0xFFB96D1D), // వర్తమానం
    Color(0xFF1F8062), // భవిష్యత్తు
  ];
  static const _subTabIcons = <IconData>[
    Icons.fact_check_outlined, Icons.auto_awesome_outlined,
    Icons.history, Icons.today_outlined, Icons.event_available_outlined,
  ];

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BnnMasterRule>>(
      future: _catalog,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _panel(
            child: Text('BNN నియమాలను లోడ్ చేయలేకపోయాం: ${snapshot.error}'),
          );
        }
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          );
        }

        final rules = snapshot.data!;
        final age = BnnMasterAnalysis.completedAge(
          widget.birthData.localDateTime,
          DateTime.now(),
        );
        final houseRules = rules.where(_matchesSearch).where(
          (r) => BnnMasterAnalysis.housesForRule(r).contains(_selectedHouse),
        ).toList(growable: false);
        final allCandidates = _matchedRulesForHouse(houseRules);
        // Keep sign-link evidence separate from an observed conjunction.
        // Neither tier constitutes a confirmed life event.
        final matchedResults = allCandidates.where((hit) =>
            BnnMasterAnalysis.hasSingleSignPlacement(hit.rule, widget.chart))
            .toList(growable: false);
        final expandedContacts = allCandidates.where((hit) =>
            !BnnMasterAnalysis.hasSingleSignPlacement(hit.rule, widget.chart))
            .toList(growable: false);
        final yogaMatches = matchedResults
            .where((hit) => BnnMasterAnalysis.looksLikeYogaRule(hit.rule))
            .toList(growable: false);

        if (_mainTab != 0) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _mainModePicker(),
              if (_mainTab == 1) _eventPanel(rules, age)
              else _relationPanel(rules),
            ],
          );
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _mainModePicker(),
            _panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'BNN — భావాలవారీ నియమాలు',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'గురు రాశి మొదటి భావం • ప్రతి భావంలో 5 ప్రత్యేక ట్యాబ్‌లు • మూల నియమాల పరిశీలన',
                    style: TextStyle(fontSize: 12.5, color: _muted),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _countPill('${matchedResults.length} సంయోగ ఫలిత సూచనలు'),
                      _countPill('${expandedContacts.length} ఇతర సంబంధ పరిశీలనలు'),
                      _countPill('${yogaMatches.length} యోగ సూచనలు'),
                      _countPill('144 అంశాల సూచిక (ఫలితాలు కావు)'),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: 'పలితం / గ్రహం / నియమం / ID వెతకండి',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: (value) => setState(() => _search = value.trim()),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    '12 భావాలు',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  GridView.builder(
                    itemCount: 12,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      childAspectRatio: 1.55,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemBuilder: (context, index) {
                      final house = index + 1;
                      final selected = house == _selectedHouse;
                      final accent = _bhavaColors[index];
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() {
                          _selectedHouse = house;
                          _resultsLimit = 8;
                          _yogaLimit = 5;
                          _selectedSubTab = 0;
                          _showAllTopics = true;
                          _topicLimit = 4;
                          _showExpandedContacts = false;
                        }),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          curve: Curves.easeInOut,
                          decoration: BoxDecoration(
                            color: selected
                                ? accent
                                : Color.lerp(Colors.white, accent, 0.105),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected
                                  ? accent
                                  : Color.lerp(Colors.white, accent, 0.50)!,
                              width: selected ? 2.0 : 1.2,
                            ),
                            boxShadow: selected ? [
                              BoxShadow(
                                color: accent.withAlpha(60),
                                blurRadius: 8,
                                offset: const Offset(0, 3),
                              ),
                            ] : null,
                          ),
                          padding: const EdgeInsets.fromLTRB(10, 7, 7, 7),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(children: [
                                Expanded(child: Text(
                                  '${house} భావం',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 16,
                                    color: selected ? Colors.white : accent,
                                  ),
                                )),
                                if (selected)
                                  const Icon(Icons.check_circle, color: Colors.white, size: 16),
                              ]),
                              const SizedBox(height: 4),
                              Text(
                                BnnMasterAnalysis.houseTheme(house),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 11.5,
                                  height: 1.25,
                                  color: selected ? Colors.white : const Color(0xFF454A54),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    BnnMasterAnalysis.houseLabel(_selectedHouse),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    BnnMasterAnalysis.houseTheme(_selectedHouse),
                    style: const TextStyle(fontSize: 12.5, color: _muted),
                  ),
                  const SizedBox(height: 10),
                  _infoBox(
                    title: 'జన్మ చక్రంలోని గ్రహాలు',
                    body: BnnMasterAnalysis.houseOccupancyText(widget.chart, _selectedHouse),
                  ),
                  const SizedBox(height: 10),
                  const Text('BNN భావ క్రమం: గురు ఉన్న రాశి 1వ భావం; అక్కడి నుండి రాశుల వారీగా 2–12.',
                    style: TextStyle(fontSize: 12, color: _muted, height: 1.45)),
                  const SizedBox(height: 14),
                  _subTabPicker(),
                  const SizedBox(height: 14),
                  if (_selectedSubTab == 0) ...[
                    _topicExplorer(rules),
                    const SizedBox(height: 16),
                    _sectionTitle('జాతకంలో కనిపించిన సంయోగ సూచనలు (${matchedResults.length})'),
                    const SizedBox(height: 5),
                    const Text(
                      'జన్మ చక్రంలో ఒకే రాశిలో ఉన్న గ్రహాల ఆధారంగా వచ్చిన మూలగ్రంథ సూచనలు మాత్రమే. '
                      'సంఘటన నిజంగా జరిగిందని లేదా తప్పక జరుగుతుందని నిర్ధారణ కాదు. '
                      'పలితం టచ్ చేస్తే IF నియమం, గ్రహస్థితులు, పరిశీలన కనిపిస్తాయి.',
                      style: TextStyle(color: _muted, fontSize: 12.5, height: 1.45),
                    ),
                    const SizedBox(height: 8),
                    if (matchedResults.isEmpty)
                      _emptyMessage('ఈ భావానికి ఒకే రాశి సంయోగం ఆధారంగా ప్రాథమిక ఫలిత సూచనలు కనిపించలేదు. '
                          'మిగతా గ్రహ సంబంధాలు కింద పరిశీలించవచ్చు.')
                    else ...[
                      for (final hit in matchedResults.take(_resultsLimit))
                        _candidateRuleTile(hit.rule, hit.evidence),
                      if (matchedResults.length > _resultsLimit)
                        TextButton(
                          onPressed: () => setState(() => _resultsLimit += 6),
                          child: Text('ఇంకా ${matchedResults.length - _resultsLimit} ఫలిత సూచనలు'),
                        ),
                    ],
                    const SizedBox(height: 15),
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => setState(() =>
                          _showExpandedContacts = !_showExpandedContacts),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 9),
                        child: Row(children: [
                          const Icon(Icons.account_tree_outlined,
                              color: _burgundy),
                          const SizedBox(width: 8),
                          Expanded(child: Text(
                            'ఇతర రాశి సంబంధాల పరిశీలన (${expandedContacts.length})',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          )),
                          Icon(_showExpandedContacts
                              ? Icons.expand_less : Icons.expand_more),
                        ]),
                      ),
                    ),
                    if (_showExpandedContacts) ...[
                      const Text(
                        'త్రికోణం, 2/7/12 సంబంధాలను ఫలితాలుగా చూపించలేదు. '
                        'గ్రహసంబంధం నిజంగా ఏ విధంగా వర్తిస్తుందో నాడీ పద్ధతితో పరిశీలించాలి.',
                        style: TextStyle(color: _muted, fontSize: 12.3,
                            height: 1.45),
                      ),
                      const SizedBox(height: 8),
                      if (expandedContacts.isEmpty)
                        _emptyMessage('వేరుగా పరిశీలించాల్సిన సంబంధాలు లేవు.')
                      else
                        for (final hit in expandedContacts)
                          _contactReviewTile(hit.rule, hit.evidence),
                    ],
                  ] else if (_selectedSubTab == 1) ...[
                    _sectionTitle('ఈ భావానికి సంబంధించిన యోగ సూచనలు'),
                    const SizedBox(height: 6),
                    const Text('ఒకే రాశి సంయోగ సూచనలు మాత్రమే. పూర్తి యోగ నిర్ధారణ కాలేదు; ఇతర రాశి సంబంధాలు ఫలితాల్లో కలపలేదు.',
                      style: TextStyle(color: _muted, fontSize: 12, height: 1.45)),
                    const SizedBox(height: 10),
                    if (yogaMatches.isEmpty)
                      _emptyMessage('ఈ జాతకంలో ఈ భావానికి ప్రాథమిక సంయోగ సూచనలు కనిపించలేదు.')
                    else
                      for (final hit in yogaMatches.take(_yogaLimit))
                        _candidateRuleTile(hit.rule, hit.evidence),
                    if (yogaMatches.length > _yogaLimit)
                      TextButton(
                        onPressed: () => setState(() => _yogaLimit += 10),
                        child: Text('ఇంకా ${yogaMatches.length - _yogaLimit} యోగాలు చూపించు'),
                      ),
                  ] else ...[
                    _sectionTitle(_periodTitle),
                    const SizedBox(height: 8),
                    _infoBox(title: _periodHeading(age), body: _periodDescription(age)),
                    const SizedBox(height: 12),
                    _sectionTitle('వయస్సు / గురు–శని చక్ర పరిశీలన'),
                    const SizedBox(height: 8),
                    ..._periodBandWidgets(age),
                    const SizedBox(height: 10),
                    _emptyMessage('ఈ కాలంలోని సంఘటన ఖచ్చితంగా జరిగిందా లేదా జరగబోతుందా అని నిర్ణయించే పూర్తి BNN కాలగణన ఇంకా ధృవీకరించలేదు.'),
                  ],
                  const SizedBox(height: 15),
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 6),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.library_books_outlined),
                    label: const Text('మూల గ్రంథ నియమాలు — విడిగా చూడండి'),
                    onPressed: () => _openSourceLibrary(rules),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }


  Widget _mainModePicker() => _panel(child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('BNN ప్రధాన విభాగాలు',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      const SizedBox(height: 9),
      Wrap(spacing: 8, runSpacing: 8, children: [
        _modeChoice(0, '12 భావాలు', Icons.grid_view_rounded,
            const Color(0xFF00796B)),
        _modeChoice(1, 'సంఘటనల సమయం', Icons.event_note_outlined,
            const Color(0xFF3656A6)),
        _modeChoice(2, 'బంధుత్వాలు', Icons.people_alt_outlined,
            const Color(0xFF8B408B)),
      ]),
    ],
  ));

  Widget _modeChoice(int index, String name, IconData icon, Color accent) =>
      ChoiceChip(
        avatar: Icon(icon, size: 18, color: _mainTab == index ? Colors.white : accent),
        label: Text(name),
        selected: _mainTab == index,
        showCheckmark: false,
        selectedColor: accent,
        backgroundColor: Color.lerp(Colors.white, accent, 0.09),
        side: BorderSide(color: accent.withAlpha(110)),
        labelStyle: TextStyle(
          fontWeight: FontWeight.w800,
          color: _mainTab == index ? Colors.white : accent,
        ),
        onSelected: (_) => setState(() => _mainTab = index),
      );

  Widget _eventPanel(List<BnnMasterRule> catalog, int age) {
    final today = DateTime.now();
    final windows = BnnEventRelations.studyWindows.toList()
      ..sort((a, b) => a.fromAge.compareTo(b.fromAge));
    final timeRules = catalog.where(BnnMasterAnalysis.looksLikeTimingRule).toList();
    return _panel(child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('సంఘటనలు — గతం, వర్తమానం, భవిష్యత్తు',
          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
        const SizedBox(height: 6),
        Text('ప్రస్తుత వయస్సు: $age • జన్మ సంవత్సరం: ${widget.birthData.localDateTime.year}',
          style: const TextStyle(color: _muted, fontSize: 13)),
        const SizedBox(height: 10),
        _infoBox(
          title: 'కాల సూచనలు — నిర్ధారిత సంఘటనలు కావు',
          body: 'మూల BNN R-A03 / R-A04లో ఉన్న గురు (12 సంవత్సరాలు), '
              'శని (30 సంవత్సరాలు) చక్రాల అంశాలను వయస్సు–క్యాలెండర్ '
              'పరిధిగా చూపుతున్నాం. నిజమైన సంఘటనకు కారకగ్రహ సంబంధం, '
              'గ్రహస్పర్శ, గోచారం/నక్షత్రం మరియు మూల OCR ధృవీకరణ అవసరం. '
              'రోజు, నెల, సంవత్సరం ఖచ్చితంగా నిర్ణయించలేదు.'),
        const SizedBox(height: 10),
        for (final item in windows) ...[
          Builder(builder: (context) {
            final placement = BnnEventRelations.placementCondition(item, widget.chart);
            final source = BnnEventRelations.findRule(catalog, item.sourceId);
            final label = BnnEventRelations.period(item, widget.birthData, today);
            return Card(
              color: placement == false
                  ? const Color(0xFFF4F4F4) : const Color(0xFFFAFBFF),
              margin: const EdgeInsets.only(bottom: 9), elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(color: placement == false
                    ? const Color(0xFFD5D5D5) : const Color(0xFFC9D4EC))),
              child: ListTile(
                contentPadding: const EdgeInsets.all(12),
                leading: const Icon(Icons.access_time_filled, color: Color(0xFF3656A6)),
                title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 7),
                  child: Text(
                    '$label • వయస్సు ${item.fromAge}–${item.toAge}\n'
                    'సంవత్సర పరిధి సుమారు ${item.firstYear(widget.birthData)}–${item.lastYear(widget.birthData)}\n'
                    '${placement == false ? 'గ్రహస్థితి షరతు సరిపోలలేదు • ' : placement == true ? 'గ్రహస్థితి ప్రారంభ షరతు సరిపోయింది • ' : ''}'
                    'ధృవీకరణ పెండింగ్ • ${item.sourceId}',
                    style: const TextStyle(color: _muted, fontSize: 12.5, height: 1.5),
                  ),
                ),
                trailing: const Icon(Icons.chevron_right, color: _burgundy),
                onTap: () {
                  if (source != null) {
                    _showRuleSheet(source,
                      'సంఘటన కాల అధ్యయనం: ${item.name}. '
                      'వయస్సు ${item.fromAge}–${item.toAge} సూత్రంలోని '
                      'చక్ర పరిధి మాత్రమే. ${item.prerequisite}. '
                      'సంఘటన నిజంగా జరిగిందని/జరుగుతుందని నిర్ధారించలేదు.');
                  }
                },
              ),
            );
          }),
        ],
        const SizedBox(height: 12),
        Text('కాల సంబంధ మూల నియమాలు (${timeRules.length})',
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        const Text('మిగిలిన కాలసూత్రాలు కూడా గ్రంథాలయంలో ఉన్నాయి. '
            'వాటికి పూర్తి IF–THEN / గ్రహ రవాణా ధృవీకరణ లేకుండా సంఘటన తేదీలు చూపించము.',
            style: TextStyle(color: _muted, fontSize: 12.5)),
        const SizedBox(height: 6),
        OutlinedButton.icon(
          icon: const Icon(Icons.library_books_outlined),
          label: const Text('కాల మూల నియమాలు చూడండి'),
          onPressed: () => _openSourceLibrary(timeRules),
        ),
      ],
    ));
  }

  Widget _relationPanel(List<BnnMasterRule> catalog) {
    final selected = BnnEventRelations.relations[_selectedRelation];
    // Index ONLY the relationship actually named in the rule's THEN text.
    // This prevents e.g. "native lives away from family" from appearing in
    // the relatives tab as though it described an aunt or uncle.
    final rules = BnnEventRelations.sourceRulesFor(selected, catalog);
    final tentative = BnnEventRelations.tentativeRelationsFor(
        selected, catalog, widget.chart);
    return _panel(child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('BNN — బంధుత్వాల పరిశీలన',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('వ్యక్తిని ఎంపిక చేస్తే ఆ వ్యక్తి గురించి THEN వాక్యం ఉన్న మూల '
            'నియమాలనే చూస్తాం. కుటుంబం అనే పదం ఉన్న ప్రతి నియమాన్ని కలపము.',
            style: TextStyle(fontSize: 12.5, color: _muted)),
        const SizedBox(height: 14),
        const Text('బంధుత్వాలు ఎంచుకోవడానికి పక్కకు జరపండి →',
            style: TextStyle(color: _muted, fontSize: 11.8)),
        const SizedBox(height: 6),
        SizedBox(
          height: 52,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: BnnEventRelations.relations.length,
            separatorBuilder: (_, __) => const SizedBox(width: 7),
            itemBuilder: (ctx, index) {
              final isActive = index == _selectedRelation;
              return InkWell(
                onTap: () => setState(() => _selectedRelation = index),
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  constraints: const BoxConstraints(minWidth: 82),
                  decoration: BoxDecoration(
                    color: isActive ? const Color(0xFF8B408B) : const Color(0xFFF8EFF8),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFB789B6)),
                  ),
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  child: Text(BnnEventRelations.relations[index].name,
                    maxLines: 2, textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w700,
                      fontSize: 12.6,
                      color: isActive ? Colors.white : const Color(0xFF743C72))),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 14),
        Text(selected.name,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        Text('ఈ సంబంధం గురించి మూల IF–THEN నియమాలు: ${rules.length} • '
             'ప్రాథమిక సంయోగ పరిశీలనలు: ${tentative.length}',
             style: const TextStyle(color: _muted, fontSize: 12.6)),
        const SizedBox(height: 11),
        if (tentative.isEmpty)
          _emptyMessage(rules.isEmpty
              ? 'ఈ సంబంధాన్ని నేరుగా ప్రస్తావించే THEN వాక్యం ప్రస్తుత 462 '
                'నియమాల్లో గుర్తించబడలేదు. ఫలితం కల్పించడం లేదు.'
              : 'ఈ సంబంధానికి ${rules.length} మూల IF–THEN నియమాలు ఉన్నాయి. '
                'వాటిలో ఏ నియమానికీ ఇప్పటి ఆటో గణనలో పూర్తి IF ధృవీకరణ లేదు. '
                'అందువల్ల అనుకూలం/ప్రతికూలం అని నిర్ణయించలేదు.')
        else ...[
          const Text('ప్రాథమిక గ్రహసంయోగ సూచనలు — నిర్ధారిత ఫలితాలు కావు',
            style: TextStyle(fontWeight: FontWeight.w800, color: _burgundy)),
          const SizedBox(height: 7),
          for (final rule in tentative.take(12)) _relationRuleTile(rule),
        ],
        const SizedBox(height: 10),
        if (rules.isNotEmpty)
          OutlinedButton.icon(
            icon: const Icon(Icons.library_books_outlined),
            label: Text('ఈ బంధుత్వానికి సంబంధించిన ${rules.length} మూల నియమాలు'),
            onPressed: () => _openSourceLibrary(rules),
          ),
        const SizedBox(height: 6),
        ExpansionTile(
          initiallyExpanded: false,
          tilePadding: EdgeInsets.zero,
          title: const Text('కారకగ్రహం, భావస్థానం — టచ్ చేసి పరిశీలించండి',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
          children: [
            _infoBox(title: 'జన్మగ్రహ పరిశీలన (ఫలితం కాదు)',
                body: BnnEventRelations.natalReference(selected, widget.chart)),
            const SizedBox(height: 6),
            const Text('కారకగ్రహ స్థానం ఒక్కటితో ఆ బంధువు ఆరోగ్యం, '
                'ఆయుష్షు, స్వభావం లేదా సంఘటనను నిర్ధారించలేము.',
                style: TextStyle(fontSize: 12, color: _muted)),
          ],
        ),
      ],
    ));
  }

  Widget _relationRuleTile(BnnMasterRule rule) {
    // IF verification is incomplete; neutral colour is intentional.
    const bg = Color(0xFFF2F4F7);
    const outline = Color(0xFFCBD0D8);
    return Card(
      elevation: 0, color: bg,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(13),
        side: BorderSide(color: outline),
      ),
      child: ListTile(
        title: Text('${BnnMasterAnalysis.shortPlanetChain(rule.condition)} — ${rule.result}',
          maxLines: 3, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
        subtitle: Padding(padding: const EdgeInsets.only(top: 5),
          child: const Text('గ్రహసంయోగ ప్రారంభ సూచన మాత్రమే • పూర్తి IF ధృవీకరణ లేదు',
            style: TextStyle(fontSize: 12))),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showRuleSheet(rule,
          'ఈ సంబంధానికి ప్రాథమిక గ్రహసంయోగ పరిశీలన మాత్రమే సరిపోయింది. '
          'మొత్తం నాడీ నియమం, గ్రహక్రమం, రవాణా ఇంకా పరిశీలించాలి.'),
      ),
    );
  }

  /// Topic labels are navigation only, NOT generated BNN rules or results.
  /// Only direct matches in the user-provided 462 IF-THEN source catalog appear.
  List<BnnMasterRule> _sourceRulesForTopic(
      BnnBhavaTopic topic, List<BnnMasterRule> catalog) {
    return catalog.where((rule) {
      if (!BnnMasterAnalysis.housesForRule(rule).contains(topic.house)) {
        return false;
      }
      final sourceText = '${rule.topic} ${rule.condition} ${rule.result}';
      return sourceText.contains(topic.name);
    }).toList(growable: false);
  }

  Widget _topicExplorer(List<BnnMasterRule> catalog) {
    final topics = BnnBhavaTopicService.forHouse(_selectedHouse)
        .where((topic) => _search.isEmpty ||
            topic.name.toLowerCase().contains(_search.toLowerCase()))
        .toList(growable: false);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        InkWell(
          onTap: () => setState(() => _showAllTopics = !_showAllTopics),
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [
              const Icon(Icons.grid_view_outlined, color: _burgundy),
              const SizedBox(width: 8),
              Expanded(child: Text(
                'ఈ భావంలోని 12 అంశాల సూచిక (${topics.length}/12)',
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
              )),
              Icon(_showAllTopics ? Icons.expand_less : Icons.expand_more),
            ]),
          ),
        ),
        if (_showAllTopics) ...[
          const Text(
            'ఇవి ఫలితాలు కావు; అంశాల పేర్లు మాత్రమే. ఇక్కడ స్వయంగా సృష్టించిన '
            '144 వ్యాఖ్యానాలు, IF నియమాలు తొలగించబడ్డాయి. మూల 462 నియమాల్లో '
            'నేరుగా ఈ అంశం ప్రస్తావించిన నియమాలనే తెరచి చూడవచ్చు.',
            style: TextStyle(color: _muted, fontSize: 12.2, height: 1.45),
          ),
          const SizedBox(height: 9),
          for (final topic in topics.take(_topicLimit))
            Builder(builder: (context) {
              final matches = _sourceRulesForTopic(topic, catalog);
              return Card(
                margin: const EdgeInsets.only(bottom: 7),
                color: const Color(0xFFFFFEFC),
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                  side: const BorderSide(color: Color(0xFFD7E6DE)),
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.fromLTRB(14, 9, 10, 10),
                  leading: const Icon(Icons.menu_book_outlined,
                      color: Color(0xFF16806A)),
                  title: Text(topic.name,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text(
                    matches.isEmpty
                        ? 'ఈ పేరుతో ప్రత్యక్ష మూల IF–THEN నియమం లేదు'
                        : '${matches.length} మూల IF–THEN నియమాలు • జాతక మ్యాచ్ కాదు',
                    style: const TextStyle(fontSize: 12.2, color: _muted),
                  ),
                  trailing: const Icon(Icons.chevron_right, color: _burgundy),
                  onTap: () => _showTopicSheet(topic, matches),
                ),
              );
            }),
          if (topics.length > _topicLimit)
            Align(
              alignment: Alignment.centerLeft,
              child: TextButton.icon(
                icon: const Icon(Icons.expand_more),
                onPressed: () => setState(() => _topicLimit += 4),
                label: Text(
                  'మరో ${topics.length - _topicLimit >= 4 ? 4 : topics.length - _topicLimit} అంశాలు చూపించు',
                ),
              ),
            ),
        ],
      ],
    );
  }

  void _showTopicSheet(BnnBhavaTopic topic, List<BnnMasterRule> sourceRules) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF8FAFC),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.70,
          minChildSize: 0.45,
          maxChildSize: 0.94,
          builder: (ctx, scrollController) => ListView(
            controller: scrollController,
            padding: const EdgeInsets.fromLTRB(22, 18, 22, 32),
            children: [
              Text('${topic.house} భావం — ${topic.name}',
                  style: const TextStyle(fontSize: 20,
                      fontWeight: FontWeight.w900)),
              const SizedBox(height: 14),
              const Text('జన్మ గ్రహస్థితులు (సమాచారం మాత్రమే)',
                  style: TextStyle(fontWeight: FontWeight.w800,
                      color: _burgundy)),
              const SizedBox(height: 6),
              Text(BnnMasterAnalysis.houseOccupancyText(widget.chart,
                      topic.house),
                  style: const TextStyle(fontSize: 14, height: 1.5)),
              const SizedBox(height: 15),
              Text('మూల IF–THEN నియమాలు (${sourceRules.length})',
                  style: const TextStyle(fontWeight: FontWeight.w800,
                      color: _burgundy)),
              const SizedBox(height: 6),
              const Text('ఇవి అంశపు పదం ఆధారంగా గుర్తించిన మూల నియమాలు. '
                  'IF షరతు మొత్తం జాతకానికి సరిపోయిందని నిర్ధారణ కాదు.',
                  style: TextStyle(fontSize: 12, color: _muted)),
              const SizedBox(height: 8),
              if (sourceRules.isEmpty)
                _emptyMessage('ఈ అంశానికి నేరుగా గుర్తించగల IF–THEN మూల నియమం '
                    'లేదు. సాధారణ ఫలితాన్ని సృష్టించలేదు.'),
              for (final rule in sourceRules) _sourceRuleTile(rule),
            ],
          ),
        ),
      ),
    );
  }

  static const _subTabNames = <String>[
    'ఫలితాలు', 'యోగాలు', 'భూతం', 'వర్తమానం', 'భవిష్యత్తు',
  ];

  String get _periodTitle => _subTabNames[_selectedSubTab];

  Widget _subTabPicker() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('భావ విశ్లేషణ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Wrap(
        spacing: 7,
        runSpacing: 7,
        children: [
          for (var i = 0; i < _subTabNames.length; i++)
            ChoiceChip(
              avatar: Icon(
                _subTabIcons[i], size: 17,
                color: _selectedSubTab == i ? Colors.white : _subTabColors[i],
              ),
              label: Text(_subTabNames[i]),
              selected: _selectedSubTab == i,
              showCheckmark: false,
              selectedColor: _subTabColors[i],
              backgroundColor: Color.lerp(Colors.white, _subTabColors[i], 0.105),
              side: BorderSide(
                color: _subTabColors[i].withAlpha(115),
                width: _selectedSubTab == i ? 1.5 : 1,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
              labelStyle: TextStyle(
                color: _selectedSubTab == i ? Colors.white : _subTabColors[i],
                fontWeight: _selectedSubTab == i ? FontWeight.w900 : FontWeight.w700,
              ),
              onSelected: (_) => setState(() {
                _selectedSubTab = i;
              }),
            ),
        ],
      ),
    ],
  );

  bool _matchesSearch(BnnMasterRule rule) {
    if (_search.isEmpty) return true;
    final hay = '${rule.id} ${rule.topic} ${rule.condition} ${rule.result} ${rule.source}'.toLowerCase();
    return hay.contains(_search.toLowerCase());
  }

  List<_HouseRuleHit> _matchedRulesForHouse(List<BnnMasterRule> houseRules) {
    final hits = <_HouseRuleHit>[];
    for (final rule in houseRules) {
      final evidence = BnnMasterAnalysis.tentativeHouseMatch(
        rule,
        widget.chart,
        _selectedHouse,
      );
      if (evidence != null) {
        hits.add(_HouseRuleHit(rule, evidence));
      }
    }
    return hits;
  }

  List<Widget> _periodBandWidgets(int age) {
    final range = _periodRange(age);
    final bands = BnnMasterAnalysis.jupiterStudyBands(range.$1, range.$2);
    if (bands.isEmpty) {
      return [_emptyMessage('ఈ కాల పరిధికి గురు చక్ర అధ్యయన భాగాలు లేవు.')];
    }
    return [
      Text(
        BnnMasterAnalysis.roundInfo(_referenceAge(age)),
        style: const TextStyle(fontSize: 12.5, color: _muted),
      ),
      const SizedBox(height: 8),
      for (final band in bands)
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Text(
            'గురు ${band.round}వ చక్రం • ${band.fromAge}–${band.toAge} వయస్సు • ${band.sourceTheme}',
            style: const TextStyle(fontSize: 12.5, height: 1.45),
          ),
        ),
      const Text(
        'గమనిక: ఇవి BNN-BOOK-R-A03 ఆధారంగా అధ్యయన విభాగాలు మాత్రమే; ఖచ్చిత సంఘటన నిర్ధారణ కాదు.',
        style: TextStyle(fontSize: 12, color: _muted),
      ),
    ];
  }

  (int, int) _periodRange(int age) {
    switch (_selectedSubTab) {
      case 2:
        return (0, age < 1 ? 0 : age - 1);
      case 3:
        return (age < 0 ? 0 : age, age < 0 ? 0 : age);
      case 4:
        final start = age < 0 ? 0 : age + 1;
        return (start, start + 12);
      default:
        return (age < 0 ? 0 : age, age < 0 ? 0 : age + 5);
    }
  }

  int _referenceAge(int age) {
    switch (_selectedSubTab) {
      case 2:
        return age < 1 ? 0 : age - 1;
      case 3:
        return age < 0 ? 0 : age;
      case 4:
        return age < 0 ? 0 : age + 1;
      default:
        return age < 0 ? 0 : age;
    }
  }

  String _periodHeading(int age) {
    final range = _periodRange(age);
    return '$_periodTitle — వయస్సు ${range.$1} నుండి ${range.$2}';
  }

  String _periodDescription(int age) {
    switch (_selectedSubTab) {
      case 2:
        return 'జననం నుండి ${age < 1 ? 0 : age - 1} వయస్సు వరకు ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన గత అధ్యయన కాలచక్ర అంశాలు మాత్రమే.';
      case 3:
        return 'ప్రస్తుత వయస్సు $age వద్ద ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన వర్తమాన అధ్యయన కాలచక్రం.';
      case 4:
        return 'ప్రస్తుత వయస్సు తరువాత ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన భవిష్యత్ అధ్యయన కాలచక్రం. ఇది సంఘటన తేదీ కాదు.';
      default:
        return '${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన కాల పరిశీలన.';
    }
  }

  Widget _sectionTitle(String text) => Text(
        text,
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
      );

  Widget _countPill(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0xFFEDF0F5),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(text, style: const TextStyle(fontSize: 12.5)),
      );

  Widget _panel({required Widget child}) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _panelBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFE4E7EC)),
        ),
        child: child,
      );

  Widget _infoBox({required String title, required String body}) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFFDF5E6),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE8D8B2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(body, style: const TextStyle(fontSize: 12.5, height: 1.45)),
          ],
        ),
      );

  Widget _emptyMessage(String message) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF3F4F6),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(message, style: const TextStyle(fontSize: 12.5, color: _muted, height: 1.45)),
      );

  // On the main BNN screen: CONDITION + RESULT ONLY. Other rule evidence is
  // exclusively inside the onTap sheet, never underneath every card.
  Widget _candidateRuleTile(BnnMasterRule rule, String evidence) {
    final combination = BnnMasterAnalysis.shortPlanetChain(rule.condition);
    final polarity = BnnEventRelations.polarity(rule, widget.chart);
    final bg = polarity > 0 ? const Color(0xFFE5F6EB) :
        polarity < 0 ? const Color(0xFFFFE9F1) : const Color(0xFFF2F4F7);
    final outline = polarity > 0 ? const Color(0xFF92C8A2) :
        polarity < 0 ? const Color(0xFFE0A0B9) : const Color(0xFFCBD0D8);
    return Card(
      elevation: 0,
      color: bg,
      margin: const EdgeInsets.only(bottom: 9),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(13),
        side: BorderSide(color: outline),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
        title: Text('$combination — ${rule.result}',
          maxLines: 3, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800,
            height: 1.4)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(polarity > 0 ? 'అనుకూల ప్రాథమిక సూచన • టచ్ చేస్తే పరిశీలన' :
              polarity < 0 ? 'ప్రతికూల ప్రాథమిక సూచన • టచ్ చేస్తే పరిశీలన' :
              'మూలగ్రంథ సూచన మాత్రమే • టచ్ చేస్తే పరిశీలన',
            style: const TextStyle(fontSize: 11.5, color: _muted)),
        ),
        trailing: const Icon(Icons.chevron_right, color: Color(0xFF08745E)),
        onTap: () => _showRuleSheet(rule,
          '$evidence ఈ ఫలితం గ్రంథంలో సూచించబడింది; ఇతర BNN షరతులూ '
          'ధృవీకరించిన తరువాతే సంఘటనను నిర్ధారించాలి.'),
      ),
    );
  }

  /// Relations other than one-sign conjunction cannot satisfy an unstated
  /// Nadi sequence condition. Display the relationship, never a life-event
  /// assertion. Source outcome appears only after the user's tap.
  Widget _contactReviewTile(BnnMasterRule rule, String evidence) => Card(
        elevation: 0,
        color: const Color(0xFFF7F7FA),
        margin: const EdgeInsets.only(bottom: 7),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFFDCE0E7)),
        ),
        child: ListTile(
          dense: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          leading: const Icon(Icons.hub_outlined, color: Color(0xFF65738A)),
          title: Text(BnnMasterAnalysis.shortPlanetChain(rule.condition),
              style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: const Text('ప్రాథమిక గ్రహసంబంధం • ఫలిత నిర్ధారణ కాదు',
              style: TextStyle(color: _muted, fontSize: 11.8)),
          trailing: const Icon(Icons.chevron_right, color: _burgundy),
          onTap: () => _showRuleSheet(rule,
              '$evidence ఇది విస్తృత రాశి సంబంధ పరిశీలన మాత్రమే; '
              'అసలు నియమం నెరవేరిందని లేదా సంఘటన జరిగిందని చెప్పలేము.'),
        ),
      );

  // The source catalogue is clearly separated from chart-matched results.
  Widget _sourceRuleTile(BnnMasterRule rule) => Card(
        elevation: 0,
        color: const Color(0xFFF9FAFC),
        margin: const EdgeInsets.only(bottom: 5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFFDCE0E7)),
        ),
        child: ListTile(
          dense: true,
          visualDensity: VisualDensity.compact,
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
          leading: const Icon(Icons.menu_book_outlined, color: Color(0xFF64748B)),
          title: Text('IF: ${rule.condition}',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
          subtitle: Text('${rule.id} • మూల నియమం మాత్రమే • ${_statusLabel(rule.status)}',
              style: const TextStyle(fontSize: 11.5, color: _muted)),
          trailing: const Icon(Icons.chevron_right, color: Color(0xFF64748B)),
          onTap: () => _showRuleSheet(rule,
              'ఇది గ్రంథంలోని మూల నియమం మాత్రమే. జాతకానికి వర్తించినట్లు లేదా సంఘటన జరిగినట్లు ధృవీకరించలేదు.'),
        ),
      );

  void _openSourceLibrary(List<BnnMasterRule> rules) {
    var search = '';
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF8FAFC),
      builder: (sheetContext) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.84,
          child: StatefulBuilder(builder: (ctx, updateSheet) {
            final filtered = rules.where((rule) {
              final haystack = '${rule.id} ${rule.condition} ${rule.result} ${rule.topic}'.toLowerCase();
              return haystack.contains(search.toLowerCase());
            }).toList(growable: false);
            return Column(children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 18, 16, 9),
                child: Text('BNN — 462 మూల నియమాల గ్రంథాలయం',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text('ఇవి జాతకంలో మ్యాచ్ అయిన ఫలితాలు కావు. మూలగ్రంథ పరిశీలన కోసం మాత్రమే.',
                  style: TextStyle(fontSize: 12, color: _muted)),
              ),
              Padding(
                padding: const EdgeInsets.all(14),
                child: TextField(
                  onChanged: (value) => updateSheet(() => search = value.trim()),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'రూల్ ID, గ్రహం లేదా ఫలితం వెతకండి',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (ctx, index) => _sourceRuleTile(filtered[index]),
                ),
              ),
            ]);
          }),
        ),
      ),
    );
  }

  void _showRuleSheet(BnnMasterRule rule, String note) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF7ECEC),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.78,
          maxChildSize: 0.92,
          minChildSize: 0.55,
          builder: (context, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(22, 14, 22, 30),
            children: [
              Center(
                child: Container(
                  width: 52,
                  height: 6,
                  decoration: BoxDecoration(
                    color: Colors.black45,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                rule.status == 'OCR_REVIEW'
                    ? 'BNN — మూల గ్రంథ నియమ పరిశీలన'
                    : 'BNN — జాతక పరిశీలన రూల్',
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 18),
              _sheetBlock('మూలగ్రంథ ఫలిత వాక్యం (నిర్ధారణ కాదు)', rule.result),
              _sheetBlock('IF — నియమం', rule.condition),
              _sheetBlock('జాతకానికి సంబంధించిన గమనిక', note),
              _sheetBlock(
                'జన్మ గ్రహస్థితులు',
                BnnMasterAnalysis.natalPositionsForCondition(rule.condition, widget.chart),
              ),
              _sheetBlock('జాతక పరిశీలన', rule.inspection),
              _sheetBlock('ధృవీకరణ స్థితి', '${_statusLong(rule.status)} ప్రాథమిక గ్రహ సంయోగం ద్వారా సంఘటన/ఆరోగ్య సమస్య/కుటుంబ సంబంధం నిర్ధారణ కాలేదు.'),
              _sheetBlock('మూల గ్రంథం', '${rule.source} • PDF పేజీ ${rule.sourcePage} • ${rule.id}'),
              _sheetBlock('పరిహారం', rule.remedy),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sheetBlock(String title, String body) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                  color: _burgundy,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                )),
            const SizedBox(height: 6),
            Text(body, style: const TextStyle(fontSize: 15, height: 1.55)),
          ],
        ),
      );

  String _statusLabel(String status) => switch (status) {
        'FACTS_REQUIRED' => 'జాతక match అవసరం',
        'OCR_REVIEW' => 'OCR పరిశీలన',
        'REVIEW' => 'Review',
        _ => status,
      };

  String _statusLong(String status) => switch (status) {
        'FACTS_REQUIRED' => 'ఈ నియమం జాతకంలోని గ్రహస్థితులతో సరిపోతే మాత్రమే పరిశీలించాలి.',
        'OCR_REVIEW' => 'ఈ నియమం OCR నుండి వచ్చినది; మూల గ్రంథంతో మళ్లీ ధృవీకరించాలి.',
        'REVIEW' => 'ఈ నియమం చేతితో మరింత సమీక్ష అవసరం.',
        _ => status,
      };
}

class _HouseRuleHit {
  final BnnMasterRule rule;
  final String evidence;
  const _HouseRuleHit(this.rule, this.evidence);
}
