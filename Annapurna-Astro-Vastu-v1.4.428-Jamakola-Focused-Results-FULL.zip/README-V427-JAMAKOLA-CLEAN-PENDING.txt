ANNAPURNA ASTRO VASTU v1.4.427 — Jamakola Pending Rules Clarity

Changes:
- Eight Gowri alternatives are grouped under one missing fact, not displayed as 8 failures or predictions.
- One visible manual Gowri period selector in All/Gowri tabs. If unknown, evidence remains pending.
- All matched IF–THEN rules still appear with Rule ID and sources.
- Unmatched alternative rules stay collapsed and neutral.
- No changes to Swiss Ephemeris, question time/location, KP, marriage, birth chart computation, or source JSON.
- New focused regression tests for grouping and one-of-eight matching.

Note: this is a source package; APK compilation requires successful GitHub Actions build.
