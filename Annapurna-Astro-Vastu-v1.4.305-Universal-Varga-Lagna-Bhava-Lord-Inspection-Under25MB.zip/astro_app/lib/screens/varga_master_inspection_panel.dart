import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/varga_master_inspection_service.dart';
import '../astrology/varga_service.dart';

/// Shown below the chart for every one of the 16 supported vargas.
/// It displays auditable basic rules, not unverified outcome percentages.
class VargaMasterInspectionPanel extends StatelessWidget {
  final AstroChartResult natal;
  final int factor;
  final D16CalculationMethod d16Method;

  const VargaMasterInspectionPanel({
    super.key,
    required this.natal,
    required this.factor,
    this.d16Method = D16CalculationMethod.parashara,
  });

  static const green = Color(0xFF176B36);
  static const pink = Color(0xFFA33667);

  @override
  Widget build(BuildContext context) {
    VargaMasterInspection report;
    try {
      report = VargaMasterInspectionService.inspect(
        natal, factor, d16Method: d16Method);
    } catch (e) {
      return Card(child: Padding(
        padding: const EdgeInsets.all(12),
        child: Text('D$factor సాధారణ పరిశీలనకు గ్రహ సమాచారం సరిపోలేదు: $e'),
      ));
    }
    return Card(
      color: const Color(0xFFF8FAFC),
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('D$factor — లగ్నం, భావం, అధిపతి: సాధారణ పరిశీలన',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 6),
          Text('ప్రధాన అంశం: ${report.chart.definition.domain}',
              style: const TextStyle(fontSize: 12)),
          const Text('ఇవి గణించిన ఆధారాలు; స్వతంత్ర సంఘటన ఫలితాలు లేదా '
              'ధృవీకరణ శాతాలు కావు.', style: TextStyle(fontSize: 11)),
          const SizedBox(height: 5),
          _inspectionTile(report.lagna, initiallyExpanded: true),
          for (final item in report.subjects) _inspectionTile(item),
          const SizedBox(height: 8),
          Text(report.warning, style: const TextStyle(fontSize: 11,
              color: Color(0xFF665B60), height: 1.4)),
          if (factor == 2 || factor == 1) ...[
            const SizedBox(height: 7),
            const Text('ధన పరిశీలనలో 2వ భావం = నిల్వ సూచనలు; '
                '11వ భావం = లాభ సూచనలు; 12వ భావం = వ్యయ సూచనలు. '
                'మూడు పరిశీలనలను కలపకుండా విడిగా చూపిస్తున్నాం. '
                'Dhana_Aasthi_Rules మూల నియమాల పూర్తి మ్యాచ్ విడిగా అవసరం.',
                style: TextStyle(fontSize: 11, height: 1.4)),
          ],
          const SizedBox(height: 5),
          const Text('మూలం: మీ సాధారణ వర్గ పరిశీలన సూచనలు (2026-11-02). '
              'ఈ USER-VARGA IDsకు గ్రంథ పేజీలను కల్పించలేదు.',
              style: TextStyle(fontSize: 10, color: Colors.grey)),
        ]),
      ),
    );
  }

  Widget _inspectionTile(VargaHouseInspection house,
      {bool initiallyExpanded = false}) {
    return ExpansionTile(
      initiallyExpanded: initiallyExpanded,
      tilePadding: const EdgeInsets.symmetric(horizontal: 4),
      childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      title: Text('${house.number}వ భావం · ${house.title}',
          style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
      subtitle: Text('అధిపతి: ${VargaMasterInspectionService.grahaTelugu[house.lord] ?? house.lord}'
          ' · స్థానం: ${house.lordHouse == null ? 'తెలియదు' : '${house.lordHouse}వ భావం'}'
          ' · ${house.evidenceVerdict}',
          style: const TextStyle(fontSize: 11.5)),
      children: [
        Row(children: [
          _counter('అనుకూల ఆధారాలు', house.supports, green),
          const SizedBox(width: 8),
          _counter('ఆటంక ఆధారాలు', house.challenges, pink),
        ]),
        if (house.experimentalIndex != null) ...[
          const SizedBox(height: 4),
          Text('ప్రయోగాత్మక బల సూచిక: ${house.experimentalIndex} పాయింట్లు '
              '(మూల ఆధారం 100; ఒకే గ్రహాన్ని ఒకే దిశలో ఒక్కసారే +20/−20)',
              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
          const Text('ఈ సూచిక మీ ఉదాహరణ గణన మాత్రమే; మూలగ్రంథ బలం '
              'కాదు, % కాదు, ఫలితం వచ్చే అవకాశం కాదు.',
              style: TextStyle(fontSize: 10.5, color: Colors.grey)),
        ],
        const SizedBox(height: 5),
        for (final signal in house.signals) _signalTile(signal),
        const Text('ఒకే గ్రహం స్థితి, దృష్టి, మైత్రి ద్వారా పలుసార్లు కనిపించవచ్చు. '
            'అందువల్ల ఆధారాల సంఖ్యను నేరుగా కలిపి శాతంగా మార్చరు.',
            style: TextStyle(fontSize: 10.5, color: Colors.grey)),
      ],
    );
  }

  Widget _counter(String title, int count, Color color) => Expanded(
    child: Text('$title: $count', style: TextStyle(
      fontSize: 11, color: color, fontWeight: FontWeight.w600)),
  );

  Widget _signalTile(VargaInspectionSignal signal) {
    final color = switch (signal.tone) {
      VargaInspectionTone.supportive => green,
      VargaInspectionTone.challenging => pink,
      VargaInspectionTone.contextual => const Color(0xFF555B66),
    };
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Icon(switch (signal.tone) {
          VargaInspectionTone.supportive => Icons.add_circle_outline,
          VargaInspectionTone.challenging => Icons.warning_amber_outlined,
          VargaInspectionTone.contextual => Icons.info_outline,
        }, color: color, size: 17),
        const SizedBox(width: 7),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(signal.title, style: TextStyle(fontWeight: FontWeight.w600,
              fontSize: 12, color: color)),
          Text(signal.evidence, style: const TextStyle(fontSize: 11.5, height: 1.35)),
          Text(signal.id, style: const TextStyle(fontSize: 10, color: Colors.grey)),
        ])),
      ]),
    );
  }
}
