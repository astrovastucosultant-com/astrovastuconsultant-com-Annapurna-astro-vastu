import 'astro_models.dart';
import 'varga_service.dart';
import 'varga_unified_rule_service.dart';

/// Each topic uses the original VARGA-CROSS-001..015 chart order. A chart is
/// *not* counted as confirmed merely because its varga exists or was opened.
/// Percentages are chart-confirmation coverage, never event probabilities.
enum TopicStageStatus { matched, notMatched, insufficientEvidence }

enum TopicPolarity { supportive, adverse, undetermined }

class TopicStageEvidence {
  final int factor;
  final TopicStageStatus status;
  final List<String> ruleIds;
  final String details;
  final TopicPolarity polarity;

  const TopicStageEvidence({
    required this.factor,
    required this.status,
    required this.ruleIds,
    required this.details,
    this.polarity = TopicPolarity.undetermined,
  });
}

class MultiChartTopicEvidence {
  final String name;
  final String chartOrderSourceId;
  final List<TopicStageEvidence> stages;
  final String note;

  const MultiChartTopicEvidence({
    required this.name,
    required this.chartOrderSourceId,
    required this.stages,
    required this.note,
  });

  int get matchedStages => stages.where((s) => s.status == TopicStageStatus.matched).length;
  int get evaluatedStages => stages.where((s) => s.status != TopicStageStatus.insufficientEvidence).length;
  int get totalStages => stages.length;
  /// Numerator is confirmed stages, denominator is source-selected stages.
  /// Never count pending as confirmed. When 0 stages are confirmed and at
  /// least one is pending, omit 0% rather than insinuating no event promise.
  int? get confirmationPercent => matchedStages > 0 || evaluatedStages == totalStages
      ? (100 * matchedStages ~/ totalStages)
      : null;

  String get displayCoverage => confirmationPercent == null
      ? '$matchedStages/$totalStages · ${totalStages - evaluatedStages} పూర్తి పరీక్ష మిగిలింది'
      : '$confirmationPercent% · $matchedStages/$totalStages చక్రాలు'
          '${evaluatedStages < totalStages ? ' · ${totalStages - evaluatedStages} పెండింగ్' : ''}';
}

class _TopicDefinition {
  final String name;
  final String sourceId;
  final List<int> factors;
  final Map<int, List<String>> detailedRuleIds;
  const _TopicDefinition(this.name, this.sourceId, this.factors, this.detailedRuleIds);
}

class MultiChartTopicService {
  // Rules below link to exact IDs in the user-supplied 255-rule catalog;
  // they are not extra predictions or synthetic outcomes.
  static const _definitions = <_TopicDefinition>[
    _TopicDefinition('ప్రభుత్వ ఉద్యోగం', 'VARGA-CROSS-001', [1, 9, 10], {
      1: ['VARGA-CROSS-016', 'VARGA-CROSS-017', 'VARGA-CROSS-018'],
      9: ['VARGA-CROSS-019'], 10: ['VARGA-CROSS-020'],
    }),
    _TopicDefinition('ఉన్నత ప్రభుత్వ పదవి', 'VARGA-CROSS-002', [1, 9, 10, 24, 20], {
      1: ['VARGA-CROSS-022'], 9: ['VARGA-CROSS-023'],
      10: ['VARGA-CROSS-021', 'VARGA-CROSS-024'],
      24: ['VARGA-CROSS-025'], 20: ['VARGA-CROSS-026'],
    }),
    _TopicDefinition('వ్యాపారం', 'VARGA-CROSS-003', [1, 10, 2, 7], {
      1: ['VARGA-CROSS-027'], 10: ['VARGA-CROSS-028'],
      2: ['VARGA-CROSS-029'], 7: ['VARGA-CROSS-030'],
    }),
    _TopicDefinition('వివాహం', 'VARGA-CROSS-004', [1, 9, 2, 7], {
      1: ['VARGA-CROSS-031', 'VARGA-CROSS-033'],
      9: ['VARGA-CROSS-032', 'VARGA-CROSS-033'],
      2: ['VARGA-CROSS-034'], 7: ['VARGA-CROSS-034'],
    }),
    _TopicDefinition('సంతానం', 'VARGA-CROSS-005', [1, 7, 9], {
      1: ['VARGA-CROSS-035'], 7: ['VARGA-CROSS-036'], 9: ['VARGA-CROSS-037'],
    }),
    _TopicDefinition('విద్య', 'VARGA-CROSS-006', [1, 4, 24, 9], {
      1: ['VARGA-CROSS-038'], 4: ['VARGA-CROSS-039'],
      24: ['VARGA-CROSS-040'], 9: ['VARGA-CROSS-041'],
    }),
    _TopicDefinition('ఆరోగ్యం', 'VARGA-CROSS-007', [1, 6, 30], {
      1: ['VARGA-CROSS-042'], 6: ['VARGA-CROSS-043'],
      30: ['VARGA-CROSS-044'],
    }),
    _TopicDefinition('ఆయుష్షు', 'VARGA-CROSS-008', [1, 2, 3, 8], {
      1: ['VARGA-CROSS-045'], 2: ['VARGA-CROSS-046'],
      3: ['VARGA-CROSS-046'], 8: ['VARGA-CROSS-047'],
    }),
    _TopicDefinition('ఆస్తి / వారసత్వం', 'VARGA-CROSS-009', [1, 4, 12], {
      1: ['VARGA-CROSS-048'], 4: ['VARGA-CROSS-049'],
      12: ['VARGA-CROSS-050'],
    }),
    _TopicDefinition('దాంపత్య విఘాతం', 'VARGA-CROSS-010', [1, 9, 30], {
      1: ['VARGA-CROSS-051'], 9: ['VARGA-CROSS-052'],
      30: ['VARGA-CROSS-053'],
    }),
    _TopicDefinition('విదేశీ ప్రయాణం / నివాసం', 'VARGA-CROSS-011', [1, 9, 10, 4], {
      1: ['VARGA-CROSS-054'], 9: ['VARGA-CROSS-055'],
      10: ['VARGA-CROSS-056'], 4: ['VARGA-CROSS-057'],
    }),
    _TopicDefinition('కోర్టు కేసులు', 'VARGA-CROSS-012', [1, 6, 30], {
      1: ['VARGA-CROSS-058'], 6: ['VARGA-CROSS-059'],
      30: ['VARGA-CROSS-060'],
    }),
    _TopicDefinition('ఆధ్యాత్మికత', 'VARGA-CROSS-013', [1, 9, 20, 24], {
      1: ['VARGA-CROSS-061'], 9: ['VARGA-CROSS-062'],
      20: ['VARGA-CROSS-063'], 24: ['VARGA-CROSS-064'],
    }),
    _TopicDefinition('కీర్తి', 'VARGA-CROSS-014', [1, 10, 9], {
      1: ['VARGA-CROSS-065'], 10: ['VARGA-CROSS-066'],
      9: ['VARGA-CROSS-067'],
    }),
    _TopicDefinition('వాహన సుఖం', 'VARGA-CROSS-015', [1, 4, 16], {
      1: ['VARGA-CROSS-068'], 4: ['VARGA-CROSS-069'],
      16: ['VARGA-CROSS-070'],
    }),
  ];

  static List<MultiChartTopicEvidence> summarize({
    required AstroChartResult chart,
    required List<UnifiedVargaRule> evaluatedRules,
  }) {
    final byId = {for (final rule in evaluatedRules) rule.id: rule};
    return _definitions.map((definition) {
      final stages = <TopicStageEvidence>[];
      for (final factor in definition.factors) {
        final refs = definition.detailedRuleIds[factor] ?? const <String>[];
        final selected = refs.map((id) => byId[id]).whereType<UnifiedVargaRule>().toList();
        final matched = selected.where((r) => r.status == UnifiedVargaRuleStatus.matched).toList();
        final pending = selected.where((r) => r.status == UnifiedVargaRuleStatus.pending ||
            r.status == UnifiedVargaRuleStatus.method).toList();
        final allChecked = selected.isNotEmpty && pending.isEmpty;
        var status = matched.isNotEmpty
            ? TopicStageStatus.matched
            : allChecked ? TopicStageStatus.notMatched : TopicStageStatus.insufficientEvidence;
        var ids = matched.map((r) => r.id).toList();
        var details = matched.isNotEmpty
            ? matched.map((r) => '${r.id}: ${r.evidence}').join('\n')
            : 'మూల నియమం ఉంది; ఈ చక్రానికి పూర్తి IF–THEN ధృవీకరణ ఇంకా లేదు. '
              'దీనిని ప్రతికూల ఫలితంగా భావించకూడదు.';
        if (allChecked && matched.isEmpty) {
          details = selected.map((r) => '${r.id}: ${r.evidence}').join('\n');
          ids = selected.map((r) => r.id).toList();
        }

        // User-specified 5L/9L six-way OR, evaluated independently in D1/D9/D10.
        // This is clearly labelled a user-defined support check, not one of
        // the classical government's full natal-promise rules.
        if (definition.sourceId == 'VARGA-CROSS-001') {
          final extra = evaluateFiveNine(chart, factor);
          // For this specific topic the displayed percentage is ONLY the
          // complete six-OR user-defined check across D1/D9/D10. Pending
          // separate source IFs are disclosed, but don't erase a completed
          // negative six-OR test or turn it into a government-job denial.
          status = extra.status;
          ids = {...extra.ruleIds, ...ids}.toList();
          final extraSource = matched.isNotEmpty
              ? '\nఇతర వర్తించిన మూల నియమాలు: ${matched.map((r) => r.id).join(', ')}.'
              : '';
          details = '${extra.details}$extraSource'
              '\nమిగిలిన పూర్తికాని ప్రభుత్వ ఉద్యోగ రూల్స్: '
              '${pending.map((r) => r.id).join(', ')}.';
        }
        stages.add(TopicStageEvidence(
          factor: factor,
          status: status,
          ruleIds: ids,
          details: details,
          polarity: definition.sourceId == 'VARGA-CROSS-010' ||
              definition.sourceId == 'VARGA-CROSS-012'
              ? TopicPolarity.adverse : TopicPolarity.supportive,
        ));
      }
      return MultiChartTopicEvidence(
        name: definition.name,
        chartOrderSourceId: definition.sourceId,
        stages: stages,
        note: definition.sourceId == 'VARGA-CROSS-001'
          ? 'USER-GOV-5-9 అనేది మీరు చెప్పిన ఆరు ప్రత్యామ్నాయాల్లో ఏదో ఒకటి సరిపోయే సపోర్ట్ చెక్. '
            'ఉద్యోగం లేదా హై ర్యాంక్ ఖచ్చితమని కాదు. ఇతర ప్రభుత్వ ఉద్యోగ నియమాలు, దశ, గోచారం ఇంకా కావాలి.'
          : 'మూలగ్రంథంలోని చార్ట్ క్రమం చూపుతున్నాం. అన్ని IF షరతులు అమలు కాని చక్రాన్ని మ్యాచ్‌గా లెక్కించము.',
      );
    }).toList(growable: false);
  }

  /// Used only for the six user-supplied alternative conditions. The sign
  /// lord of a house is recalculated from that varga's own ascendant.
  static TopicStageEvidence evaluateFiveNine(AstroChartResult chart, int factor) {
    const rulers = <String>[
      'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
      'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
    ];
    if (!VargaService.definitions.any((d) => d.factor == factor)) {
      return TopicStageEvidence(factor: factor,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: const [], details: 'D$factor గణన అందుబాటులో లేదు.');
    }
    if (!chart.ascendantLongitude.isFinite ||
        chart.planets.any((p) => !p.longitude.isFinite)) {
      return TopicStageEvidence(factor: factor,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: const [], details: 'జన్మలగ్నం లేదా గ్రహ డిగ్రీల సమాచారం పూర్తిగా లేదు.');
    }
    final varga = VargaService.calculate(chart, factor);
    final signs = <String, int>{for (final p in varga.planets) p.name: p.signIndex};
    final l5 = rulers[(varga.ascendantSignIndex + 4) % 12];
    final l9 = rulers[(varga.ascendantSignIndex + 8) % 12];
    final s5 = signs[l5];
    final s9 = signs[l9];
    if (s5 == null || s9 == null) {
      return TopicStageEvidence(factor: factor,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: const [], details: '5వ/9వ అధిపతుల గ్రహస్థితులు లేవు.');
    }
    final house5 = (s5 - varga.ascendantSignIndex + 12) % 12 + 1;
    final house9 = (s9 - varga.ascendantSignIndex + 12) % 12 + 1;
    final own5 = rulers[s5] == l5;
    final own9 = rulers[s9] == l9;
    final found = <String>[];
    if (house5 == 9 && house9 == 5) found.add('5–9 పరివర్తన');
    if (l5 != l9 && s5 == s9) found.add('5L–9L యుతి');
    if (own5) found.add('5L స్వరాశి');
    if (own9) found.add('9L స్వరాశి');
    if (house5 == 9) found.add('5L 9వ భావంలో');
    if (house9 == 5) found.add('9L 5వ భావంలో');
    return TopicStageEvidence(
      factor: factor,
      status: found.isEmpty ? TopicStageStatus.notMatched : TopicStageStatus.matched,
      ruleIds: const ['USER-GOV-5-9'],
      details: 'D$factor: 5L $l5 = $house5 భావం; 9L $l9 = $house9 భావం. '
          '${found.isEmpty ? 'ఈ ఆరు షరతుల్లో ఏదీ సరిపోలలేదు.' : 'మ్యాచ్: ${found.join(', ')}.'}',
      polarity: TopicPolarity.supportive,
    );
  }
}
