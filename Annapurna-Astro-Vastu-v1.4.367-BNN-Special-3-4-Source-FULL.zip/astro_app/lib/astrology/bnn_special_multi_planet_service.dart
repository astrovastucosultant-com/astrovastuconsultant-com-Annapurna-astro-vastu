import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';
import 'bnn_planet_combination_service.dart';

/// Verifiable catalog of named examples, not universal predictive rules.
/// Every source example needs its own independently established IF conditions.
class BnnSpecialSourceExample {
  final String id;
  final List<String> planets;
  final String relationType;
  final Map<String, int>? exactSigns;
  final String favorable;
  final String? unfavorable;
  final String source;
  final String sourceUrl;
  final String evidenceKind;
  final String qualifier;
  const BnnSpecialSourceExample({required this.id,required this.planets,
    required this.relationType,required this.exactSigns,
    required this.favorable,required this.unfavorable,
    required this.source,required this.sourceUrl,required this.evidenceKind,
    required this.qualifier});

  factory BnnSpecialSourceExample.fromJson(Map<String, dynamic> x) {
    final ps=(x['planets'] as List).cast<String>();
    if ((ps.length!=3&&ps.length!=4)||ps.toSet().length!=ps.length||
        !ps.every(BnnPlanetCombinationService.ninePlanets.contains)) {
      throw const FormatException('BNN source example must have 3/4 unique planets');
    }
    final relation=x['type'] as String;
    if (relation!='same_sign'&&relation!='directional_trine') {
      throw const FormatException('BNN source example relation is invalid');
    }
    final rawSigns=x['exact_signs'] as Map?;
    final signs=rawSigns==null?null:rawSigns.map((key,value)=>
      MapEntry(key as String,value as int));
    if (signs!=null&&(signs.length!=ps.length||
        signs.keys.toSet().difference(ps.toSet()).isNotEmpty||
        signs.values.any((v)=>v<0||v>11))) {
      throw const FormatException('BNN source example has invalid sign guards');
    }
    final kind=x['kind'] as String;
    if (kind!='primary_book_case'&&kind!='secondary_author_example') {
      throw const FormatException('BNN source evidence class mismatch');
    }
    return BnnSpecialSourceExample(id:x['id'] as String,
      planets:List.unmodifiable(ps),relationType:relation,exactSigns:signs,
      favorable:x['positive'] as String,unfavorable:x['negative'] as String?,
      source:x['source'] as String,sourceUrl:x['url'] as String,
      evidenceKind:kind,qualifier:x['qualifier'] as String);
  }
}

class BnnSpecialSourceMatch {
  final BnnSpecialSourceExample rule;
  final List<PlanetPosition> matchedPlanets;
  /// A bigger group can contain this pattern but is not the same case.
  final bool hasExtraGroupPlanets;
  const BnnSpecialSourceMatch({required this.rule,
    required this.matchedPlanets,required this.hasExtraGroupPlanets});
}

class BnnSpecialMultiPlanetService {
  const BnnSpecialMultiPlanetService._();
  static const asset='assets/bnn/bnn_special_multi_planet_examples_v367.json';

  static Future<List<BnnSpecialSourceExample>> load() async {
    final root=jsonDecode(await rootBundle.loadString(asset)) as Map<String,dynamic>;
    if (root['schema']!='ANNAPURNA-BNN-SPECIAL-3-4-EXAMPLES-1.0') {
      throw const FormatException('BNN special source schema mismatch');
    }
    final rules=(root['rules'] as List).map((e)=>
      BnnSpecialSourceExample.fromJson(e as Map<String,dynamic>)).toList();
    if (rules.map((e)=>e.id).toSet().length!=rules.length) {
      throw const FormatException('Duplicate BNN multi-planet source IDs');
    }
    return List.unmodifiable(rules);
  }

  /// Only source-example pattern checks. A match does NOT verify life event.
  static List<BnnSpecialSourceMatch> matchingSourceExamples({
    required BnnCombinationGroup group,
    required List<BnnSpecialSourceExample> rules,
  }) {
    final byName={for(final p in group.planets) p.name:p};
    final matched=<BnnSpecialSourceMatch>[];
    for(final r in rules) {
      if (r.planets.any((name)=>!byName.containsKey(name))) continue;
      if (r.relationType=='same_sign'&&group.sameSignIndex==null) continue;
      if (r.relationType=='directional_trine'&&group.sameSignIndex!=null) continue;
      final members=r.planets.map((n)=>byName[n]!).toList();
      if (r.exactSigns!=null && members.any((p)=>
          r.exactSigns![p.name]!=p.signIndex)) continue;
      if (r.relationType=='same_sign'&&
          members.map((p)=>p.signIndex).toSet().length!=1) continue;
      if (r.relationType=='directional_trine'&&
          members.map((p)=>p.signIndex%4).toSet().length!=1) continue;
      // BNN groups already use zodiacal order; display also the intra-sign
      // degree order separately. Neither establishes event chronology.
      members.sort((a,b)=>a.longitude.compareTo(b.longitude));
      matched.add(BnnSpecialSourceMatch(rule:r,
        matchedPlanets:List.unmodifiable(members),
        hasExtraGroupPlanets:group.planets.length!=members.length));
    }
    matched.sort((a,b)=>b.rule.planets.length.compareTo(a.rule.planets.length));
    return List.unmodifiable(matched);
  }

  static int countSubgroups(int n,int k) {
    if (k<0||k>n) return 0;
    var result=1;
    for(var i=1;i<=k;i++) result=result*(n-i+1)~/i;
    return result;
  }

  static List<List<PlanetPosition>> subsets(List<PlanetPosition> ps,int k) {
    final result=<List<PlanetPosition>>[];
    void visit(int from,List<PlanetPosition> selected) {
      if (selected.length==k) {
        result.add(List.unmodifiable(selected));
        return;
      }
      for(var i=from;i<=ps.length-(k-selected.length);i++) {
        visit(i+1,[...selected,ps[i]]);
      }
    }
    visit(0,[]);
    return List.unmodifiable(result);
  }
}
