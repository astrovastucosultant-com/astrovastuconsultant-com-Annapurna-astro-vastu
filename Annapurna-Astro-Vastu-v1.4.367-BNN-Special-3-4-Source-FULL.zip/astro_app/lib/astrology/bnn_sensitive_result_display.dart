/// Public-facing BNN wording for traditional health and mortality indications.
/// The underlying textual rule is preserved as a source record; it is not a
/// validated clinical diagnosis or a reliable prediction of death.
class BnnSensitiveResultDisplay {
  const BnnSensitiveResultDisplay._();

  static const String caution = 'ఆరోగ్య విషయంలో జాగ్రత్త అవసరం';
  static const String mortalityCaution =
      'సంప్రదాయ జ్యోతిష్య నియమంలో మృత్యు సంబంధ సూచన ఉంది. '
      'ఆరోగ్య విషయంలో ప్రత్యేక జాగ్రత్త అవసరం. ఇది మరణ నిర్ధారణ కాదు.';
  static const String mrityunjayaRemedy =
      'సంప్రదాయ ఆధ్యాత్మిక పరిహారంగా మహామృత్యుంజయ హోమం '
      'చేయించుకోవాలని సలహా. ఇది విశ్వాసపరమైన సూచన మాత్రమే; '
      'ఆయుష్షు లేదా ఆరోగ్య ఫలితం ఖచ్చితమని హామీ కాదు. '
      'ఆరోగ్య సమస్యలుంటే వైద్య పరీక్షలు, చికిత్స కొనసాగించాలి.';

  static final RegExp _mortalityRisk = RegExp(
    r'(మరణ|మృత్యు|అపమృత్యు|ప్రాణాపాయ|death|fatal|mortality|life[ -]?threatening)',
    caseSensitive: false,
  );
  static final RegExp _healthRisk = RegExp(
    r'(అనారోగ్య|వ్యాధి|రోగభయ|ఆరోగ్య\s*(సమస్య|ప్రమాద|క్షీణ|హాని|ఇబ్బంది)|'
    r'illness|disease|health\s*(risk|crisis|danger))',
    caseSensitive: false,
  );
  // Negative assertions are not positive predictions of danger.
  static final RegExp _explicitNoRisk = RegExp(
    r'(మరణ|మృత్యు|అపమృత్యు|ప్రాణాపాయ|ఆరోగ్య\s*ప్రమాద).{0,18}'
    r'(లేదు|కాదు|ఉండదు|లేవు)|'
    r'(no|without)\s+(risk of\s+)?(death|mortality|fatal)',
    caseSensitive: false,
  );

  static bool isMortalityIndicator(String text) =>
      _mortalityRisk.hasMatch(text) && !_explicitNoRisk.hasMatch(text);

  static bool isHealthIndicator(String text) =>
      !isMortalityIndicator(text) &&
      _healthRisk.hasMatch(text) && !_explicitNoRisk.hasMatch(text);

  static bool needsCaution(String text) =>
      isMortalityIndicator(text) || isHealthIndicator(text);

  static String publicResult(String text) {
    if (isMortalityIndicator(text)) return mortalityCaution;
    if (isHealthIndicator(text)) return caution;
    return text;
  }

  static String? spiritualRemedyFor(String sourceResult) =>
      isMortalityIndicator(sourceResult) ? mrityunjayaRemedy : null;
}
