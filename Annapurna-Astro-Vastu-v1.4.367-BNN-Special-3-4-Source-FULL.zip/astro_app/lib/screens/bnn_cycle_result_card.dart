import 'package:flutter/material.dart';
import '../astrology/bnn_cycle_result_service.dart';
import '../astrology/bnn_sensitive_result_display.dart';

/// BNN cycle readings: source-backed favorable/caution results are colored;
/// generic karakatwa hints are always neutral, never presented as predictions.
enum BnnCycleResultTone { favorable, unfavorable, neutral }

class BnnCycleResultCard extends StatelessWidget {
  final BnnCycleReading reading;
  final String inspection;
  const BnnCycleResultCard({super.key,
    required this.reading, required this.inspection});

  static BnnCycleResultTone toneFor(BnnCycleReading reading) {
    // Planetary contacts are observations, not verified event predictions.
    if (!reading.isSourceRule) return BnnCycleResultTone.neutral;
    switch (reading.tone.trim().toLowerCase()) {
      case 'favorable':
      case 'positive':
        return BnnCycleResultTone.favorable;
      case 'unfavorable':
      case 'negative':
      case 'caution':
        return BnnCycleResultTone.unfavorable;
      default:
        return BnnCycleResultTone.neutral;
    }
  }

  static Color backgroundFor(BnnCycleResultTone tone) {
    switch (tone) {
      case BnnCycleResultTone.favorable: return const Color(0xFFDFF4E5);
      case BnnCycleResultTone.unfavorable: return const Color(0xFFFDE8E8);
      case BnnCycleResultTone.neutral: return const Color(0xFFF0F3F6);
    }
  }

  static Color foregroundFor(BnnCycleResultTone tone) {
    switch (tone) {
      case BnnCycleResultTone.favorable: return const Color(0xFF155D37);
      case BnnCycleResultTone.unfavorable: return const Color(0xFFB42318);
      case BnnCycleResultTone.neutral: return const Color(0xFF344C5D);
    }
  }

  static Color borderFor(BnnCycleResultTone tone) {
    switch (tone) {
      case BnnCycleResultTone.favorable: return const Color(0xFF8ABB9B);
      case BnnCycleResultTone.unfavorable: return const Color(0xFFE09A9A);
      case BnnCycleResultTone.neutral: return const Color(0xFFC5CED5);
    }
  }

  @override
  Widget build(BuildContext context) {
    final healthCaution=BnnSensitiveResultDisplay.needsCaution(reading.result);
    final tone=healthCaution ? BnnCycleResultTone.unfavorable : toneFor(reading);
    final foreground=foregroundFor(tone);
    final label=reading.isSourceRule ? 'ఫలితం' : 'పరిశీలన సూచన';
    return Container(
      key:ValueKey('bnn-cycle-highlight-${reading.id}'),
      margin:const EdgeInsets.only(top:7),
      decoration:BoxDecoration(
        color:backgroundFor(tone),
        border:Border.all(color:borderFor(tone),width:1.2),
        borderRadius:BorderRadius.circular(13)),
      child:Theme(
        data:Theme.of(context).copyWith(dividerColor:Colors.transparent),
        child:ExpansionTile(
          key:ValueKey(reading.id),
          tilePadding:const EdgeInsets.fromLTRB(12,7,8,6),
          childrenPadding:const EdgeInsets.fromLTRB(12,0,12,12),
          title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(label,style:TextStyle(fontSize:11.5,
              color:foreground,fontWeight:FontWeight.w700)),
            const SizedBox(height:4),
            Text(BnnSensitiveResultDisplay.publicResult(reading.result),
              style:TextStyle(fontSize:15,
              height:1.4,fontWeight:FontWeight.w700,color:foreground)),
          ]),
          subtitle:const Padding(
            padding:EdgeInsets.only(top:6),
            child:Text('ఫలితం టచ్ చేస్తే రూల్ • పరిశీలన • మూలం',
              style:TextStyle(fontSize:10.5,color:Color(0xFF586878)))),
          children:[
            const Divider(height:12),
            Align(alignment:Alignment.centerLeft,
              child:Text('1. రూల్ — ${reading.id}',
                style:const TextStyle(fontSize:12,fontWeight:FontWeight.bold))),
            const SizedBox(height:4),
            Align(alignment:Alignment.centerLeft,
              child:Text('IF: ${reading.ifText}',
                style:const TextStyle(fontSize:12,height:1.45))),
            const SizedBox(height:7),
            const Align(alignment:Alignment.centerLeft,
              child:Text('2. జాతక పరిశీలన',
                style:TextStyle(fontSize:12,fontWeight:FontWeight.bold))),
            Align(alignment:Alignment.centerLeft,
              child:Text(inspection,
                style:const TextStyle(fontSize:12,height:1.45))),
            const SizedBox(height:7),
            const Align(alignment:Alignment.centerLeft,
              child:Text('3. ఫలితం',
                style:TextStyle(fontSize:12,fontWeight:FontWeight.bold))),
            Align(alignment:Alignment.centerLeft,
              child:Text(BnnSensitiveResultDisplay.publicResult(reading.result),
                style:const TextStyle(fontSize:12,height:1.45))),
            const SizedBox(height:7),
            const Align(alignment:Alignment.centerLeft,
              child:Text('4. పరిహారం',
                style:TextStyle(fontSize:12,fontWeight:FontWeight.bold))),
            Align(alignment:Alignment.centerLeft,
              child:Text(BnnSensitiveResultDisplay.spiritualRemedyFor(reading.result)
                ?? 'ఈ సూచనకు ధృవీకరించిన ప్రత్యేక పరిహార నియమం జత కాలేదు.',
                style:const TextStyle(fontSize:12,height:1.45))),
            const SizedBox(height:7),
            const Align(alignment:Alignment.centerLeft,
              child:Text('5. మూలాధారం',
                style:TextStyle(fontSize:12,fontWeight:FontWeight.bold))),
            Align(alignment:Alignment.centerLeft,
              child:Text('${reading.source} • ${reading.page}',
                style:const TextStyle(fontSize:11.5,height:1.45))),
            const SizedBox(height:8),
            Align(alignment:Alignment.centerLeft,
              child:Text(reading.isSourceRule
                ? 'ఇది మూల నియమం ఆధారంగా ఇచ్చిన సంప్రదాయ సూచన; ఒక్క గ్రహస్పర్శతో సంఘటన ఖచ్చితమని చెప్పలేం.'
                : 'ఇది గ్రహకారకత్వ ఆధారిత పరిశీలన మాత్రమే; నిర్ధారిత సంఘటన ఫలితం కాదు.',
                style:const TextStyle(fontSize:11,color:Color(0xFF526475)))),
          ],
        ),
      ),
    );
  }
}
