import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_planet_combination_service.dart';
import '../astrology/bnn_special_multi_planet_service.dart';
import '../astrology/bnn_sensitive_result_display.dart';
import '../astrology/bnn_house_relation_service.dart';
import '../astrology/bnn_rashi_rule_service.dart';

/// BNN-only result-first combination view. No unverified result is labeled
/// a direct quote from R.G. Rao or a verified ancient source rule.
class BnnPlanetCombinationsPanel extends StatefulWidget {
  final AstroChartResult chart;
  /// Optional preloaded catalog for deterministic widget tests. When omitted,
  /// the app loads its normal bundled JSON asset without behavior changes.
  final List<BnnCombinationMeaning>? initialCatalog;
  final List<BnnSpecialSourceExample>? initialSourceExamples;
  const BnnPlanetCombinationsPanel({super.key,required this.chart,
    this.initialCatalog,this.initialSourceExamples});
  @override
  State<BnnPlanetCombinationsPanel> createState()=>
      _BnnPlanetCombinationsPanelState();
}

class _BnnPlanetCombinationsPanelState extends State<BnnPlanetCombinationsPanel> {
  late final Future<List<BnnCombinationMeaning>> catalog =
    widget.initialCatalog == null
      ? BnnPlanetCombinationService.load()
      : Future.value(widget.initialCatalog!);
  late final Future<List<BnnSpecialSourceExample>> sourceExamples =
    widget.initialSourceExamples==null
      ? BnnSpecialMultiPlanetService.load()
      : Future.value(widget.initialSourceExamples!);
  bool expanded=true;
  @override
  Widget build(BuildContext context) => FutureBuilder<List<BnnCombinationMeaning>>(
    future:catalog,initialData:widget.initialCatalog,
    builder:(context,snapshot) {
      if (snapshot.hasError) return Card(child:Padding(padding:const EdgeInsets.all(12),
        child:Text('BNN కాంబినేషన్ డేటా సమస్య: ${snapshot.error}')));
      if (!snapshot.hasData) return const Center(child:CircularProgressIndicator());
      final findings=BnnPlanetCombinationService.evaluate(
        chart:widget.chart,rules:snapshot.data!);
      final groups=BnnPlanetCombinationService.groups(
        chart:widget.chart,readings:findings);
      return FutureBuilder<List<BnnSpecialSourceExample>>(
        future:sourceExamples,initialData:widget.initialSourceExamples,
        builder:(context,sourceSnapshot) => Card(
        key:const ValueKey('bnn-combination-panel'),
        margin:const EdgeInsets.symmetric(vertical:10),
        color:const Color(0xFFF0F6F3),
        child:Padding(padding:const EdgeInsets.all(12),child:Column(
          crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          ListTile(contentPadding:EdgeInsets.zero,
            title:const Text('BNN — గ్రహ కాంబినేషన్లు & ఫలిత సూచనలు',
              style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),
            subtitle:Text('${findings.length} ప్రత్యేక గ్రహసంబంధాలు • '
              '${groups.length} త్రిగ్రహ/సమూహ కాంబినేషన్లు'),
            trailing:Icon(expanded?Icons.expand_less:Icons.expand_more),
            onTap:()=>setState(()=>expanded=!expanded)),
          const Text('ప్రతి సంబంధానికి అనుకూల, ప్రతికూల వ్యాఖ్యానాలు ఉంటాయి. '
            'ఇవి కారకత్వ ఆధారిత సంప్రదాయ సూచనలు; మూలగ్రంథంలోని '
            'పూర్తి IF–THEN శ్లోకంగా లేదా ఖచ్చిత సంఘటనగా పరిగణించరాదు.',
            style:TextStyle(fontSize:12,color:Color(0xFF52626B))),
          if (expanded) ...[
            if (groups.isNotEmpty) ...[
              const SizedBox(height:12),
              const Text('మూడు లేదా ఎక్కువ గ్రహాల సమూహాలు',
                style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
              if (sourceSnapshot.hasError)
                Text('ప్రత్యేక 3/4 గ్రహాల మూల డేటా లోడ్ కాలేదు: '
                  '${sourceSnapshot.error}',
                  style:const TextStyle(color:Color(0xFF9C2222))),
              for(final group in groups) _GroupTile(group:group,
                examples:sourceSnapshot.data ?? const <BnnSpecialSourceExample>[]),
            ],
            const SizedBox(height:12),
            const Text('ప్రతి ద్విగ్రహ సంబంధం — ఫలితం ముందుగా',
              style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
            if (findings.isEmpty)
              const Text('ఈ పద్ధతుల్లో అనుసంధానమైన గ్రహ జంటలు లేవు.'),
            for (final reading in findings)
              _CombinationReadingTile(key:ValueKey('combo-${reading.id}'),
                finding:reading),
          ],
        ])),
      ));
    });
}

String _name(PlanetPosition p)=>
  BnnHouseRelationService.planetLabels[p.name]??p.name;
String _location(PlanetPosition p)=>
  '${_name(p)} ${BnnRashiRuleService.signs[p.signIndex]} '
  '${BnnRashiRuleService.dms(p.longitude)}';
String _relationLabel(BnnCombinationRelation type) {
  switch(type) {
    case BnnCombinationRelation.sameSign:return 'ఒకే రాశి సంయోగం';
    case BnnCombinationRelation.sameTrine:return '1–5–9 త్రికోణ సంబంధం';
    case BnnCombinationRelation.seventh:return 'ఎదురెదురు 7వ స్థానం';
    case BnnCombinationRelation.adjacent:return 'పక్క రాశి 2–12';
    case BnnCombinationRelation.thirdEleventh:return '3–11 సంబంధం';
  }
}

class _PositiveNegativeText extends StatelessWidget {
  final String text;
  final bool positive;
  const _PositiveNegativeText({required this.text,required this.positive});
  @override
  Widget build(BuildContext context) => Container(
    width:double.infinity,
    margin:const EdgeInsets.only(top:7),
    padding:const EdgeInsets.all(11),
    decoration:BoxDecoration(
      color:positive?const Color(0xFFDFF4E5):const Color(0xFFFDE8E8),
      border:Border.all(color:positive?const Color(0xFF6CA57A):const Color(0xFFC96C70)),
      borderRadius:BorderRadius.circular(10)),
    child:Text('${positive?'శుభ సూచన':'ప్రతికూల సూచన'}: '
      '${positive ? text : BnnSensitiveResultDisplay.publicResult(text)}',
      style:TextStyle(fontWeight:FontWeight.bold,fontSize:14.5,
        color:positive?const Color(0xFF155D37):const Color(0xFF9C2222))),
  );
}

class _CombinationReadingTile extends StatelessWidget {
  final BnnCombinationFinding finding;
  const _CombinationReadingTile({super.key, required this.finding});

  @override
  Widget build(BuildContext context) {
    final a = finding.first, b = finding.second;
    final m = finding.meaning;
    final relation = _relationLabel(finding.relation);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      color: Colors.white,
      child: ExpansionTile(
        key: ValueKey('combo-rule-${finding.id}'),
        tilePadding: const EdgeInsets.fromLTRB(11, 8, 11, 7),
        title: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('${_name(a)} + ${_name(b)} • $relation',
            style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          // Both traditional possibilities are ALWAYS shown, by design.
          _PositiveNegativeText(text: m.favorable, positive: true),
          _PositiveNegativeText(text: m.unfavorable, positive: false),
        ]),
        subtitle: const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Text('రెండు సూచనలు • టచ్ చేస్తే రూల్, పరిశీలన, ఫలితం, పరిహారం',
            style: TextStyle(fontSize: 11.5)),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 13),
        children: [
          _detail('1. రూల్ (IF–THEN)',
            'సూచన ID: ${finding.id}\n'
            'IF: జన్మ జాతకంలో ${_name(a)} మరియు ${_name(b)} '
            '$relationలో ఉంటే\n'
            'THEN: ఆ రెండు గ్రహాల కారకత్వాలకు అనుకూల, ప్రతికూల '
            'అంశాలను విడివిడిగా పరిశీలించాలి. '
            'ఇది సంబంధ-గుర్తింపు నియమం; వ్యక్తిగత సంఘటన-నిర్ధారణ నియమం కాదు.'),
          _detail('2. జాతక పరిశీలన',
            '${_location(a)}\n${_location(b)}\n'
            '${_name(a)} నుంచి ${_name(b)} ${finding.forwardHouse}వ రాశి. '
            'కనిష్ఠ కోణదూరం: ${finding.shortestSeparationDegrees.toStringAsFixed(2)}° '
            '(ఒకే రాశిలోనూ డిగ్రీల తేడా ఉండవచ్చు).\n'
            'సంబంధం: ${finding.natalRelationMatched ? 'వర్తించింది (TRUE)' : 'వర్తించలేదు (FALSE)'}. '
            'ఈ TRUE సంబంధానికి మాత్రమే వర్తిస్తుంది; శుభం/అశుభం తప్పనిసరిగా '
            'జరుగుతుందని కాదు.'),
          _detail('3. ఫలితం — రెండు సూచనలు కొనసాగుతాయి',
            'పై ఆకుపచ్చ బాక్స్‌లో శుభ సూచన, ఎరుపు బాక్స్‌లో ప్రతికూల సూచన '
            'రెండూ ఉన్నాయి. రెండింటి కోసం ప్రత్యేకంగా ధృవీకరించిన '
            'జాతక IF–THEN షరతులు ప్రస్తుత డేటాలో లేవు; '
            'ఏది ప్రధానమో నిర్ధారించలేదు.'),
          _detail('4. పరిహారం',
            BnnSensitiveResultDisplay.spiritualRemedyFor(m.unfavorable)
              ?? 'ఈ వ్యాఖ్యానానికి మూలాధారంతో నిర్ధారించిన వ్యక్తిగత '
                 'పరిహార నియమం అనుసంధానించలేదు. కల్పిత పరిహారం చూపరు.'),
          _detail('5. డిగ్రీల క్రమం & మూలం',
            '${a.longitude <= b.longitude ? _name(a) : _name(b)} → '
            '${a.longitude <= b.longitude ? _name(b) : _name(a)} '
            '(రాశిచక్ర దీర్ఘాంశ క్రమం మాత్రమే; సంఘటనల కాలక్రమం కాదు).\n'
            '${m.sourceNote}. పేజీ-ప్రత్యేక మూల IF–THEN సూత్రం '
            'ఈ ఫలితానికి ధృవీకరించబడలేదు.\n'
            'సంబంధ పద్ధతి సూచనలు: ${m.sourceRefs.join(' ; ')}'),
        ],
      ),
    );
  }
}


/// Source-specific illustrations are shown separately from composite pair
/// readings. No extra negative outcomes are fabricated for positive-only cases.
class _SourceExampleBadge extends StatelessWidget {
  final BnnSpecialSourceMatch match;
  const _SourceExampleBadge({required this.match});
  @override
  Widget build(BuildContext context) {
    final r=match.rule;
    return Container(
      key:ValueKey('bnn-special-${r.id}'),
      margin:const EdgeInsets.only(top:7),
      padding:const EdgeInsets.all(10),
      decoration:BoxDecoration(color:const Color(0xFFE7F5EB),
        borderRadius:BorderRadius.circular(9),
        border:Border.all(color:const Color(0xFF6CA57A))),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('${r.planets.length} గ్రహాల ప్రత్యేక మూల ఉదాహరణ • ${r.id}',
          style:const TextStyle(fontSize:12,fontWeight:FontWeight.bold,
            color:Color(0xFF155D37))),
        const SizedBox(height:4),
        Text(BnnSensitiveResultDisplay.publicResult(r.favorable),
          style:const TextStyle(fontSize:13,color:Color(0xFF155D37))),
        if(r.unfavorable!=null)
          Container(margin:const EdgeInsets.only(top:6),
            padding:const EdgeInsets.all(8),
            decoration:BoxDecoration(color:const Color(0xFFFDE8E8),
              border:Border.all(color:const Color(0xFFC96C70)),
              borderRadius:BorderRadius.circular(7)),
            child:Text('ప్రతికూల మూల వ్యాఖ్యానం: '
              '${BnnSensitiveResultDisplay.publicResult(r.unfavorable!)}',
              style:const TextStyle(fontSize:12,color:Color(0xFF9C2222)))),
        if(r.unfavorable==null)
          const Padding(padding:EdgeInsets.only(top:5),
            child:Text('ప్రత్యేక ప్రతికూల ఫలితానికి మూల ఆధారం లేదు.',
              style:TextStyle(fontSize:11,color:Color(0xFF52626B)))),
        if (match.hasExtraGroupPlanets)
          const Text('గమనిక: ఈ గ్రూప్‌లో అదనపు గ్రహాలు ఉన్నాయి; '
            'ఉపసమూహ ఉదాహరణ మాత్రమే.',
            style:TextStyle(fontSize:11,color:Color(0xFF8F5C25))),
        const Text('ఇది గ్రంథ/రచయిత ఉదాహరణ మాత్రమే; సంఘటన హామీ కాదు.',
          style:TextStyle(fontSize:11,color:Color(0xFF52626B))),
      ]),
    );
  }
}

class _SpecialSourceDetail extends StatelessWidget {
  final BnnSpecialSourceMatch match;
  const _SpecialSourceDetail({required this.match});
  @override
  Widget build(BuildContext context) {
    final r=match.rule;
    final original=r.exactSigns;
    final conditions=original==null
      ? 'గ్రహాలన్నీ ఒకే రాశిలో ఉండాలి'
      : r.planets.map((p)=>'$p — '
          '${BnnRashiRuleService.signs[original[p]!]}').join('; ');
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      _detail('మూల రూల్ — ${r.id}',
        'IF: $conditions; ${r.relationType=='same_sign' ? 'ఒకే రాశి' : '1–5–9 దిశా త్రికోణం'}. '
        'THEN: మూల ఉదాహరణలో పేర్కొన్న అంశాన్ని పరిశీలించాలి; '
        'జరిగిందని నిర్ధారించరాదు.'),
      _detail('జాతక పరిశీలన',
        '${match.matchedPlanets.map(_location).join(' → ')}\n'
        'గ్రహ/రాశి నమూనా సరిపోయింది (TRUE). '
        '${match.hasExtraGroupPlanets ? 'అదనపు గ్రహాలు ఉన్నందున పూర్తిగా సమానమైన ఉదాహరణ కాదు.' : 'పూర్తి గ్రూప్ పరిమాణం సరిపోయింది.'}'),
      _detail('మూల ఉదాహరణ ఫలితం',
        '${r.favorable}\n'
        '${r.unfavorable==null ? 'ప్రత్యేక ప్రతికూల ఫలితానికి మూల ఆధారం లేదు.' : r.unfavorable!}\n'
        '${r.qualifier}'),
      _detail('పరిహారం',
        'ఈ నిర్దిష్ట మూల ఉదాహరణలో వ్యక్తిగత పరిహార IF–THEN '
        'ధృవీకరణ లేదు. కల్పిత పరిహారం ఇవ్వరు.'),
      _detail('మూలం & స్థితి',
        '${r.source}\n${r.sourceUrl}\n'
        '${r.evidenceKind=='primary_book_case' ? 'గ్రంథంలోని జాతక ఉదాహరణ' : 'ద్వితీయ రచయిత ఉదాహరణ'} '
        '— నిర్దిష్ట సందర్భం మాత్రమే.'),
    ]);
  }
}

/// One green and one red box per 3+ planet group. Each box shows all matching
/// pair-source indications; no new three-planet prediction is invented.
class _GroupOutcomeBox extends StatelessWidget {
  final List<BnnCombinationFinding> readings;
  final bool positive;
  const _GroupOutcomeBox({super.key, required this.readings,
    required this.positive});

  @override
  Widget build(BuildContext context) {
    final color = positive ? const Color(0xFF155D37) : const Color(0xFF9C2222);
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 7),
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: positive ? const Color(0xFFDFF4E5) : const Color(0xFFFDE8E8),
        border: Border.all(color: positive
          ? const Color(0xFF6CA57A) : const Color(0xFFC96C70)),
        borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(positive ? 'శుభ సూచనలు' : 'ప్రతికూల సూచనలు',
            style: TextStyle(color: color, fontSize: 14.5,
              fontWeight: FontWeight.bold)),
          for (final r in readings) Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              '${_name(r.first)} + ${_name(r.second)}: '
              '${positive ? r.meaning.favorable : BnnSensitiveResultDisplay.publicResult(r.meaning.unfavorable)}',
              style: TextStyle(color: color, fontSize: 13,
                fontWeight: FontWeight.w600, height: 1.30)),
          ),
        ]),
    );
  }
}

class _GroupTile extends StatelessWidget {
  final BnnCombinationGroup group;
  final List<BnnSpecialSourceExample> examples;
  const _GroupTile({required this.group,required this.examples});

  @override
  Widget build(BuildContext context) {
    final names = group.planets.map(_name).join(' + ');
    final desc = group.sameSignIndex == null
      ? '1–5–9 త్రికోణ సమూహం'
      : '${BnnRashiRuleService.signs[group.sameSignIndex!]} రాశిలో సంయోగం';
    final readings = group.links;
    final specialMatches=BnnSpecialMultiPlanetService.matchingSourceExamples(
      group:group,rules:examples);
    final trios=BnnSpecialMultiPlanetService.countSubgroups(group.planets.length,3);
    final quads=BnnSpecialMultiPlanetService.countSubgroups(group.planets.length,4);
    final groupKey = group.sameSignIndex == null
      ? 'trine-${group.trineIndex}' : 'sign-${group.sameSignIndex}';
    return Card(
      key: ValueKey('bnn-group-$groupKey'),
      color: Colors.white,
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        title: Column(crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('$names • $desc',
              style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height:6),
            Text('3 గ్రహాల ఉపసమూహాలు: $trios • '
              '4 గ్రహాల ఉపసమూహాలు: $quads',
              style:const TextStyle(fontSize:12,color:Color(0xFF52626B))),
            if (specialMatches.isNotEmpty) ...[
              const SizedBox(height:6),
              for (final m in specialMatches) _SourceExampleBadge(match:m),
            ] else
              const Padding(padding:EdgeInsets.only(top:7),
                child:Text('ప్రత్యేక 3/4 గ్రహాల మూల ఉదాహరణ ఈ '
                  'సమూహానికి అందుబాటులో లేదు; కిందివి జంటల వ్యాఖ్యానాలు.',
                  style:TextStyle(fontSize:12,color:Color(0xFF52626B)))),
            if (readings.isNotEmpty) ...[
              const SizedBox(height: 6),
              // Both possibilities appear BEFORE expanding, just like pair cards.
              _GroupOutcomeBox(
                key: ValueKey('bnn-group-positive-$groupKey'),
                readings: readings, positive: true),
              _GroupOutcomeBox(
                key: ValueKey('bnn-group-negative-$groupKey'),
                readings: readings, positive: false),
            ],
          ]),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 7),
          child: Text('${specialMatches.length} ప్రత్యేక మూల ఉదాహరణలు • '
            '${readings.length} జంట సంబంధాలు • టచ్ చేస్తే రూల్, పరిశీలన, ఫలితం, పరిహారం',
            style: const TextStyle(fontSize: 11.5))),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: [
          _detail('ప్రత్యేక 3/4 గ్రహాల IF–THEN మూల ఉదాహరణలు',
            specialMatches.isEmpty
              ? 'ఈ గ్రూప్‌కు మూల డేటాలో ప్రత్యేక ఫలిత నియమం లేదు. '
                'ఇది రూల్ FALSE అని కాదు; అందుబాటులోని మూల నియమం లేదు.'
              : '${specialMatches.length} మూల ఉదాహరణ(లు) '
                'గ్రహ/రాశి షరతులకు సరిపోలాయి. వ్యక్తిగత ఫలిత నిర్ధారణ కాదు.'),
          for(final match in specialMatches)
            _SpecialSourceDetail(match:match),
          _detail('1. గ్రూప్ సంబంధ నియమం',
            'IF: మూడు లేదా ఎక్కువ గ్రహాలు $descలో ఉంటే, '
            'THEN: గ్రూప్‌లోని అన్ని గుర్తించిన జంటల శుభ మరియు '
            'ప్రతికూల అంశాలను కలిసి పరిశీలించాలి. '
            'జంటల సమిష్టి మాత్రమే; ప్రత్యేక మూల ఉదాహరణలు పైన వేరుగా చూడాలి.'),
          _detail('2. జాతక పరిశీలన — డిగ్రీల క్రమం',
            '${group.planets.map(_location).join(' → ')}\n'
            'సమూహ సంబంధం వర్తించింది (TRUE). '
            'గణితపరంగా గుర్తించిన జంటలు: ${readings.length}; '
            'వాటిలో సంబంధం TRUE అయినవి: '
            '${readings.where((r) => r.natalRelationMatched).length}.\n'
            'ఇది రాశిచక్ర క్రమం మాత్రమే; సంఘటనల టైమింగ్ కాదు. '
            'గ్రహసంబంధం TRUE అయినంత మాత్రాన శుభ/అశుభ సంఘటన '
            'నిర్ధారణ జరిగినట్లు కాదు.'),
          if (readings.isEmpty)
            const Text('గుర్తించిన జంటల వ్యాఖ్యానాలు లేవు.',
              style: TextStyle(color: Colors.black54)),
          if (readings.isNotEmpty) ...[
            const SizedBox(height: 8),
            const Text('3. ఫలితాలు — ప్రతి జంటకు శుభం + ప్రతికూలం',
              style: TextStyle(fontWeight: FontWeight.bold)),
            for (final r in readings) ...[
              const SizedBox(height: 10),
              Text('${_name(r.first)} + ${_name(r.second)} • ${r.id}',
                style: const TextStyle(fontWeight: FontWeight.w600,
                  fontSize: 12)),
              Text('సంబంధం: ${_relationLabel(r.relation)} • '
                'వర్తింపు: ${r.natalRelationMatched ? 'TRUE' : 'FALSE'}',
                style: const TextStyle(fontSize: 12, color: Color(0xFF52626B))),
            ],
          ],
          _detail('4. పరిహారం',
            readings.any((r)=>BnnSensitiveResultDisplay.isMortalityIndicator(
                r.meaning.unfavorable))
              ? BnnSensitiveResultDisplay.mrityunjayaRemedy
              : 'ఈ సమూహానికి ధృవీకరించిన స్వతంత్ర పరిహార IF–THEN '
                  'ప్రస్తుతం లేదు; కల్పిత పరిహారం చూపరు.'),
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('గమనిక: ఈ సమూహం జంటల వ్యాఖ్యానాల సమిష్టి మాత్రమే; '
              'శుభం మరియు అశుభం రెండూ తప్పనిసరిగా జరుగుతాయనే నిర్ధారణ కాదు.',
              style: TextStyle(fontSize: 12, color: Color(0xFF52626B))),
          ),
        ],
      ),
    );
  }
}

Widget _detail(String title,String body) => Padding(
  padding:const EdgeInsets.only(top:10),child:Column(
    crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Text(title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:13)),
      const SizedBox(height:3),Text(body,style:const TextStyle(height:1.35)),
    ]));
