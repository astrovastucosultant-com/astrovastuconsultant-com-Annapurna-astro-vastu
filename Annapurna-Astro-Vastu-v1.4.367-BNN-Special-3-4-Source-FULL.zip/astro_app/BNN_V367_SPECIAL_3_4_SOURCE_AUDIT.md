# BNN v1.4.367: 3 / 4 planet source-evidence catalog

## Scope

- Preserve existing 35 pairs and both green/red synthesis boxes.
- Additional independent, named examples (3/4 planets) evaluated against exact planet set, same-sign/trine class and, where available, exact signs.
- **Examples do not prove event outcomes**. The labels specify source book case vs later secondary author.
- No automatic negative outcomes or invented remedies. Unavailable sourced outcomes are explicitly marked.
- In groups with more planets than the source example, label as *subset only*.
- Group list counts C(n,3) and C(n,4) without factorial duplicates.

## Book-sourced examples (historical chart cases)

- R. G. Rao *Bhrigu Nandi Nadi*, Chart 335: Sun–Mercury–Ketu same sign; discusses father's government employment. Source: https://www.scribd.com/document/348729185/Bhrigu-nandi-nadi-RG-Rao-pdf-pdf
- Chart 288: Sun–Venus–Ketu same sign; example discusses father's government service. Same source.
- Chart 327: Sun exalted in Aries, with Venus, Rahu, Mercury; example discusses high government organization role for father. Same source.
- Chart 337: Jupiter, Moon, Mercury, Venus conjunct, Jupiter debilitated in Capricorn; example discusses family background. Same source.

**Warning:** Chart text/author's inference is not a universal IF–THEN law. Additional placements in those charts have not all been modeled.

## Independent author examples (secondary commentary)

D. Shanmuga Sundaram, *Triple and Quadruple Planetary Combinations in Bhrigu Nandi Nadi*, 13 Apr 2026:
https://sitharsastrology.com/blog/triple-and-quadruple-planetary-combinations-in-bhrigu-nandi-nadi

- Jupiter Aries + Sun Leo + Moon Sagittarius.
- Venus Taurus + Rahu Virgo + Saturn Capricorn.
- Mars Cancer + Ketu Scorpio + Jupiter Pisces.

These are author illustrations, not literal R.G. Rao book rules.

## Verification needed

- Compare full supplied user original BNN rulebook against this mini-catalog when available.
- Do NOT claim 3/4 planet catalogs are exhaustive.
- Do not treat matched pattern = predicted event.
- Flutter compile and test must be run by GitHub Actions; local Flutter SDK unavailable.
