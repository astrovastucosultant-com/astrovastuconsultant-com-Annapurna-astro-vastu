# Annapurna Astro Vastu — Fresh Build377 Baseline

Origin: user-uploaded Annapurna-Astro-Vastu-D9-APK (6).zip, containing only app-release.apk.
Verified APK manifest: com.annapurna.astrovastu.build11, version 1.4.358 (code 358).
Build377 GitHub workflow log points to v1.4.358 Full Flutter Source. APK signer matches the source test keystore.

This ZIP contains the source corresponding to that verified baseline plus ONLY the BNN planet-combination changes of v1.4.359. Repackaged as version 1.4.361+361.
Do not confuse the APK artifact with source: an APK does not contain editable Dart files.

Validation: ZIP intact; main.dart, pubspec.yaml, Gradle, signing key, assets, JSON, and imported BNN combination Dart files present.
Flutter APK compile and phone installation are NOT verified in this environment.

When uploading this ZIP to GitHub, ensure 'source_zip' does not point to v1.4.325 or any PATCH zip. Enter this file's exact name, or select latest by leaving input blank if your workflow can disambiguate.

Do not uninstall a currently installed app until data is backed up. If installer still rejects an APK created from this source, use Android Package Manager/ADB to read the exact INSTALL_FAILED_* code; signature mismatch with an existing app is one possibility.
