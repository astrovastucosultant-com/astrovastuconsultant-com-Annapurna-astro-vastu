# BNN v1.4.366 — Stable widget tests; no rule/content changes

## Observed from GitHub Actions BNN v365 failed run
- 8 tests passed, 3 widget tests failed.
- The failed tests all timed out in `WidgetTester.pumpAndSettle()` while the
  BNN catalog was loaded by `FutureBuilder` in test fake async.
- This is a widget test scheduling timeout, *not* proof of a compilation error.

## Patch
1. `BnnPlanetCombinationsPanel` gains optional `initialCatalog` for tests.
   Normal production usage and the packaged JSON loading path are unchanged.
2. The widget tests preload the **real** JSON asset in `setUpAll` using the
   normal async runner, then inject that catalog into the widget.
3. Indefinite `pumpAndSettle()` calls are replaced with bounded `pump()` frames.
4. Version bumped to 1.4.366+366. No rule catalog, remedy or chart data changed.

## Verification limits
ZIP CRC, original files and source diffs verified; Flutter SDK is not installed
in this environment, so compilation, widget-test pass and APK build are **not**
claimed. Run the GitHub `build-bnn-v366.yml` workflow to confirm test status.
