import 'jaimini_rule_audit_registry.dart';

/// Conservative period-level result selection. No generic fallback predictions.
/// The caller must supply independently calculated, source-verified rule matches.
class JaiminiPeriodResult {
  final String topic;
  final String teluguText;
  final String ruleId;
  final List<String> chartEvidence;
  final String sourceBook;
  final String sutra;
  final String? remedySource;
  final DateTime start;
  final DateTime end;

  const JaiminiPeriodResult({required this.topic, required this.teluguText,
    required this.ruleId, required this.chartEvidence, required this.sourceBook,
    required this.sutra, required this.remedySource,
    required this.start, required this.end});
}

class JaiminiPeriodResultGate {
  static const allowedTopics = <String>{
    'finance', 'travel', 'property', 'career', 'health',
  };

  /// A rule is shown only if it is verified, has chart evidence, and is
  /// explicitly activated in the selected MD/AD/PD/Prana period.
  static List<JaiminiPeriodResult> select({
    required Iterable<JaiminiRuleAuditRecord> rules,
    required Map<String, String> ruleTopics,
    required Map<String, String> ruleTeluguResults,
    required Set<String> periodActivatedRuleIds,
    required DateTime periodStart,
    required DateTime periodEnd,
  }) {
    if (!periodStart.isBefore(periodEnd)) return const [];
    final results = <JaiminiPeriodResult>[];
    final seen = <String>{};
    for (final rule in const JaiminiRuleAuditRegistry().publishable(rules)) {
      final topic = ruleTopics[rule.ruleId];
      final sentence = ruleTeluguResults[rule.ruleId]?.trim();
      if (topic == null || !allowedTopics.contains(topic) ||
          sentence == null || sentence.isEmpty ||
          !periodActivatedRuleIds.contains(rule.ruleId) ||
          !seen.add(rule.ruleId)) continue;
      results.add(JaiminiPeriodResult(topic: topic, teluguText: sentence,
        ruleId: rule.ruleId, chartEvidence: rule.chartEvidence,
        sourceBook: rule.sourceBook, sutra: rule.sutra,
        remedySource: rule.remedySource,
        start: periodStart, end: periodEnd));
    }
    return results;
  }
}
