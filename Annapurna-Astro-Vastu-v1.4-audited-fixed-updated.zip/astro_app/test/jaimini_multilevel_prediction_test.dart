import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jaimini_multilevel_prediction.dart';
import 'package:astro_app/astrology/jaimini_rule_audit_registry.dart';

void main() {
  final rule = JaiminiRuleAuditRecord(ruleId: 'TEST-ONLY', category: 'finance',
    sourceBook: 'Test fixture', chapter: '1', sutra: '1', sourcePage: '1',
    originalText: 'Not a real sutra', teluguExplanation: 'Test',
    mandatoryConditions: ['test'], exceptionConditions: [],
    chartEvidence: ['P11 calculated'],
    status: JaiminiVerificationStatus.verified, matched: true);
  JaiminiPeriodEvidence period(JaiminiPeriodLevel level, {bool transit = false,
      bool evidence = true}) => JaiminiPeriodEvidence(level: level,
    start: DateTime(2026, 10, 19), end: DateTime(2026, 10, 20),
    activeSigns: ['Aries'], activatedRuleIds: {'TEST-ONLY'},
    evidenceByRuleId: evidence ? {'TEST-ONLY': ['P11 and MD verified']} : {},
    transitSupportedRuleIds: transit ? {'TEST-ONLY'} : {});
  test('all four period levels require actual evidence', () {
    for (final level in JaiminiPeriodLevel.values.where((v) => v != JaiminiPeriodLevel.daily)) {
      expect(JaiminiMultilevelPrediction.evaluate(verifiedRuleCandidates: [rule],
        topics: {'TEST-ONLY': 'finance'}, teluguResults: {'TEST-ONLY': 'Test result'},
        period: period(level, evidence: false)), isEmpty);
    }
  });
  test('daily predictions require additional transit evidence', () {
    final args = [rule];
    expect(JaiminiMultilevelPrediction.evaluate(verifiedRuleCandidates: args,
      topics: {'TEST-ONLY': 'finance'}, teluguResults: {'TEST-ONLY': 'Test result'},
      period: period(JaiminiPeriodLevel.daily)), isEmpty);
    expect(JaiminiMultilevelPrediction.evaluate(verifiedRuleCandidates: args,
      topics: {'TEST-ONLY': 'finance'}, teluguResults: {'TEST-ONLY': 'Test result'},
      period: period(JaiminiPeriodLevel.daily, transit: true)), hasLength(1));
  });
}
