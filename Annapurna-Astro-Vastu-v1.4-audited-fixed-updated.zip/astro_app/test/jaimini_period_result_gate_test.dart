import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jaimini_period_result_gate.dart';
import 'package:astro_app/astrology/jaimini_rule_audit_registry.dart';

void main() {
  test('unverified and unactivated rules never create generic results', () {
    final rule = JaiminiRuleAuditRecord(ruleId: 'JA-TEST', category: 'finance',
      sourceBook: 'Sample', chapter: '1', sutra: '1', sourcePage: '1',
      originalText: 'Sample only', teluguExplanation: 'Sample',
      mandatoryConditions: ['condition'], exceptionConditions: [],
      chartEvidence: ['P2 sign 4'], status: JaiminiVerificationStatus.pendingSourceCheck,
      matched: true);
    final start = DateTime(2026, 1, 1);
    final end = DateTime(2027, 1, 1);
    expect(JaiminiPeriodResultGate.select(rules: [rule],
      ruleTopics: {'JA-TEST': 'finance'},
      ruleTeluguResults: {'JA-TEST': 'ఆదాయం పెరిగే అవకాశాలు ఉన్నాయి.'},
      periodActivatedRuleIds: {'JA-TEST'}, periodStart: start,
      periodEnd: end), isEmpty);
  });
}
