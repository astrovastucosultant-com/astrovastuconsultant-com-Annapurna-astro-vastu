# Jaimini UI update / GitHub build instructions

Updated source: `astro_app/lib/screens/chart_screen.dart` only.

To use this archive, upload it to the repository and edit the `unzip -q` line in `.github/workflows/build-apk.yml` to the archive name. A GitHub workflow in the repository cannot automatically switch to a newly uploaded differently named archive.

Recommended long-term solution: use a fixed archive filename such as `Annapurna-Astro-Vastu-source.zip`, replace that file on each release, and point the workflow to it once. Verify repository file replacement and check the Actions log for the extracted archive.

Changes: MD/AD audit is collapsed; duplicate expanded audit removed; result cards show unsupported evidence in grey; noisy score-band paragraph removed.

Not included: full PD/sukshma/prana calculations, live transit, Flutter compile, APK test.
