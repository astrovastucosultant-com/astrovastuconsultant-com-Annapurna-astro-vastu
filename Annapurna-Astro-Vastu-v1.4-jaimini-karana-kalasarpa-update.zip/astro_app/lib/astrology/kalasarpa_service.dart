import 'astro_models.dart';

/// Modern/traditional Kalasarpa screening, NOT a verified Jaimini sutra.
/// Uses sidereal ecliptic longitudes; no event or medical predictions.
class KalasarpaResult {
  final String status;
  final String? type;
  final int? rahuHouse;
  final List<String> evidence;
  const KalasarpaResult(this.status, this.type, this.rahuHouse, this.evidence);
}

class KalasarpaService {
  static const names = <String>[
    'అనంత', 'కులిక', 'వాసుకి', 'శంఖపాల', 'పద్మ', 'మహాపద్మ',
    'తక్షక', 'కర్కోటక', 'శంఖచూడ', 'ఘాతక', 'విషధార', 'శేషనాగ',
  ];
  static const seven = <String>[
    'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn',
  ];
  static double _wrap(double x) => (x % 360 + 360) % 360;

  static KalasarpaResult evaluate(AstroChartResult chart, {double tolerance = 0.1}) {
    final byName = {for (final p in chart.planets) p.name: p};
    final rahu = byName['Rahu'];
    final ketu = byName['Ketu'];
    if (rahu == null || ketu == null || seven.any((p) => !byName.containsKey(p))) {
      return const KalasarpaResult('పరిశీలన పెండింగ్', null, null,
          ['రాహు, కేతువు మరియు సప్త గ్రహాల పూర్తి దీర్ఘాంశాలు అందుబాటులో లేవు.']);
    }
    final house = ((rahu.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final separation = _wrap(ketu.longitude - rahu.longitude);
    if ((separation - 180).abs() > tolerance) {
      return KalasarpaResult('పరిశీలన పెండింగ్', null, house,
          ['రాహు–కేతు అక్షం 180°కు సరిపోలలేదు (${separation.toStringAsFixed(3)}°).']);
    }
    var forward = 0;
    var reverse = 0;
    final boundary = <String>[];
    final evidence = <String>[];
    for (final name in seven) {
      final angle = _wrap(byName[name]!.longitude - rahu.longitude);
      evidence.add('$name: ${byName[name]!.longitude.toStringAsFixed(3)}°; రాహువు నుండి ${angle.toStringAsFixed(3)}°');
      if (angle <= tolerance || (angle - 180).abs() <= tolerance || angle >= 360 - tolerance) {
        boundary.add(name);
      } else if (angle < 180) {
        forward++;
      } else {
        reverse++;
      }
    }
    if (boundary.isNotEmpty) {
      return KalasarpaResult('సంధి పరిశీలన అవసరం', names[house - 1], house,
          [...evidence, 'అక్షానికి సమీప గ్రహాలు: ${boundary.join(', ')}; స్వయంచాలకంగా పూర్ణ దోషంగా నిర్ధారించలేదు.']);
    }
    if (forward == 7 || reverse == 7) {
      return KalasarpaResult('సప్తగ్రహాలు ఒకే అర్ధచక్రంలో ఉన్నాయి', names[house - 1], house,
          [...evidence, 'ఒక వైపు: $forward; రెండో వైపు: $reverse. ఇది స్థానాల ఆధారిత సంప్రదాయ వర్గీకరణ మాత్రమే.']);
    }
    return KalasarpaResult('పూర్ణ కాలసర్ప స్థితి లేదు', null, house,
        [...evidence, 'రెండు అర్ధచక్రాల్లో గ్రహాలు: $forward / $reverse. పాక్షిక దోషానికి ఏకాభిప్రాయ ప్రమాణం లేదు.']);
  }
}
