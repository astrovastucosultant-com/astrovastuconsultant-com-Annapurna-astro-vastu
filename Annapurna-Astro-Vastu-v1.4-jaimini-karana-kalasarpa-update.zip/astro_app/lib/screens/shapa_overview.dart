import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/shapa_match_engine.dart';
import '../astrology/kalasarpa_service.dart';

/// First-page Panchangam section, placed immediately after Karana.
/// Result -> rule -> chart evidence -> source remedy.
class ShapaOverview extends StatelessWidget {
  final AstroChartResult chart;
  const ShapaOverview({super.key,required this.chart});

  @override
  Widget build(BuildContext context) {
    final all=ShapaMatchEngine.evaluate(chart);
    final matched=all.where((a)=>a.matched==true).toList();
    final pending=all.where((a)=>a.matched==null).toList();
    return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('శాపాలు / దోషాల పరిశీలన',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        const SizedBox(height:6),
        const Text('సంప్రదాయ జ్యోతిష్య సూచనలు మాత్రమే. శాపం ఉన్నట్లు నిర్ధారణ కాదు.'),
        const Text('ఫలితం → నియమం → జాతక పరిశీలన → పరిహారం',
          style:TextStyle(fontWeight:FontWeight.w500)),
        const SizedBox(height:8),
        Text('వర్తించిన సూచనలు: ${matched.length} • పరిశీలన పెండింగ్: ${pending.length}',
          style:const TextStyle(fontWeight:FontWeight.bold)),
        if(matched.isEmpty) Padding(padding:const EdgeInsets.all(8),
          child:Text(pending.isNotEmpty && pending.length==all.length
            ? 'జాతక గణన వివరాలు అసంపూర్ణం — పరిశీలన పెండింగ్.'
            : 'పరీక్షించిన నియమాల్లో సరిపోలిక లేదు; పెండింగ్ నియమాలు విడిగా ఉన్నాయి.')),
        for(final a in matched) ExpansionTile(
          key:PageStorageKey('shapa-${a.rule.id}'),
          title:Text(a.rule.title),
          subtitle:Text('సరిపోలిన జ్యోతిష్య సూచన • ${a.rule.id}'),
          children:[
            ExpansionTile(title:const Text('1. నియమం / Rule ID'),children:[
              Padding(padding:const EdgeInsets.all(10),child:Text(
                '${a.rule.id} • ${a.rule.source} • పేజీ ${a.rule.page}\n${a.rule.condition}')),
              ExpansionTile(title:const Text('2. జాతక పరిశీలన / Evidence'),children:[
                Padding(padding:const EdgeInsets.all(10),child:Column(
                  crossAxisAlignment:CrossAxisAlignment.start,children:[
                    for(final evidence in a.evidence) Padding(
                      padding:const EdgeInsets.only(bottom:6),child:Text('• $evidence')),
                    if(a.note.isNotEmpty)Text('గణన గమనిక: ${a.note}'),
                  ])),
                ExpansionTile(title:const Text('3. పరిహారం / Remedy'),children:[
                  Padding(padding:const EdgeInsets.all(10),child:Text(
                    '${a.rule.remedy}\n\nమూలం: ${a.rule.source}, పేజీ ${a.rule.page}. '
                    'Williams/remidi.pdfలో ఈ నియమానికి నిర్దిష్ట అనుసంధానం ధృవీకరణ పెండింగ్. '
                    'పరిహారాలు సంప్రదాయ సూచనలు మాత్రమే; ఖర్చుతో కూడిన కార్యక్రమాలు తప్పనిసరి కాదు.')),
                ]),
              ]),
            ]),
          ],
        ),
        _KalasarpaPanel(chart:chart),
        ExpansionTile(title:Text('Rule Audit — సరిపోలనివి ${all.where((a)=>a.matched==false).length} / పెండింగ్ ${pending.length}'),children:[
          for(final a in all.where((a)=>a.matched!=true))
            ListTile(title:Text('${a.rule.id} • ${a.rule.title}'),
              subtitle:Text(a.matched==null?'పరిశీలన పెండింగ్: ${a.note}':
                'ఈ జాతకంలో అమలు చేసిన షరతులకు సరిపోలిక లేదు.')),
        ]),
      ])));
  }
}


class _KalasarpaPanel extends StatelessWidget {
  final AstroChartResult chart;
  const _KalasarpaPanel({required this.chart});

  @override
  Widget build(BuildContext context) {
    final result = KalasarpaService.evaluate(chart);
    final type = result.type == null ? '' : ' • ${result.type} కాలసర్పం';
    return Card(
      color: const Color(0xFFFFF1F0),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('కాలసర్ప దోష పరిశీలన',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: const Border(left: BorderSide(color: Color(0xFF8A273A), width: 4)),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('1. ఫలితం', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
              const SizedBox(height: 6),
              Text('${result.status}$type', style: const TextStyle(fontWeight: FontWeight.bold)),
              const Text('ఇది సంప్రదాయ గ్రహస్థాన పరిశీలన మాత్రమే; తప్పనిసరిగా సంఘటన జరుగుతుందనే అర్థం కాదు.'),
            ]),
          ),
          ExpansionTile(
            title: const Text('2. జాతక పరిశీలన'),
            children: [Padding(padding: const EdgeInsets.all(10),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (result.rahuHouse != null) Text('రాహువు భావం: ${result.rahuHouse}'),
                for (final item in result.evidence) Padding(
                  padding: const EdgeInsets.only(bottom: 4), child: Text('• $item')),
              ]))],
          ),
          const ExpansionTile(
            title: Text('3. Rule ID & గ్రంథ మూలం'),
            children: [Padding(padding: EdgeInsets.all(10), child: Text(
              'KS-01 నుండి KS-12 వరకు రాహువు 1–12 భావాల ప్రకారం పేర్లు. '
              'SOURCE_PENDING: ఈ 12 రకాల వర్గీకరణకు ప్రాచీన జైమిని సూత్ర మూలం ధృవీకరించబడలేదు. '
              'పాక్షిక, సవ్య/అపసవ్య నిర్వచనాలు సంప్రదాయానుసారం మారుతాయి.'))],
          ),
          const ExpansionTile(
            title: Text('4. Timing of Event'),
            children: [Padding(padding: EdgeInsets.all(10), child: Text(
              'గ్రహస్థాన వర్గీకరణ ఒక్కటితో సంఘటన తేదీ లేదా దశా ఫలితం నిర్ణయించలేం. '
              'స్వతంత్ర దశా–గోచార ఆధారాలు అవసరం.'))],
          ),
          const ExpansionTile(
            title: Text('5. పరిహారం'),
            children: [Padding(padding: EdgeInsets.all(10), child: Text(
              'సంప్రదాయ ఐచ్ఛిక ఆచారాలు: శివారాధన, రాహు–కేతు ప్రార్థన, '
              'శ్రీకాళహస్తి లేదా త్రయంబకేశ్వర్ దర్శనం. '
              'పూజలు తప్పనిసరి కావు; వైద్య/ఆర్థిక సమస్యలకు ఇవి ప్రత్యామ్నాయం కావు.'))],
          ),
        ]),
      ),
    );
  }
}
