# Jaimini result bottom sheet — compact points UI
- Main result highlighted in a pale rose panel with a colored left border.
- Five numbered areas: result, Rule ID/source, horoscope evidence, event timing, BTR/remedy.
- All detailed sections collapsed by default and expanded only on tap.
- Removed duplicated summary and repeated event prose in the detail sheet.
- With zero matched event rules, displays insufficient evidence instead of a misleading score label.
- Other app modules unchanged; no transit ephemeris or five-level calculation claims.
- Flutter SDK not available in this environment; build not validated.
