Annapurna Astro Vastu v1.4.447
S.K. Mehta: compact supporting/obstructing planets and tappable 12-topic subinvestigations.

- The Mehta FamilyAnalysis panel shows derived supportive and cautionary planets
  under each topic, with no hard-coded sample planet names.
- They come only from chart-matched MF-01..MF-10 source-condition checks.
- The same planet may appear on both sides if independent rules indicate
  support and weakness. Missing chart evidence gives neither, not speculation.
- Existing 5 self-subtopics (physical, peace, money, profession, gains) are
  presented succinctly. Opening each expansion reveals condition IDs, source,
  reference house/lord, and evidence percent.
- Existing 27 relations, 12 topics, rule trail, original D1 chart, percentages,
  and relevant source restrictions are unchanged.
- Percent = in-app evidence index, not a Mehta quotation or event probability.
- Source: the app's existing S.K. Mehta New Dimensions pp. 26–28, 87–109;
  MF IDs are app-derived, not author numbering. New UI is editorial.

Verification: Flutter compile and tests require GitHub Actions; not run locally.
