Annapurna Astro Vastu v1.4.446 — S.K. Mehta Compact Rule Investigation

1. A source-only rule is displayed as "not automatically verified", not as an applied rule.
2. The D1 natal chart with exact planetary degree-minute-second positions remains visible in each rule detail.
3. Chart-specific evidence now explicitly identifies the planet and Saturn conjunction/aspect for F1/F2; F5 includes Sun/Mercury positions.
4. The long book condition, explanation, Lagna reference, citations, and safety caveats are collapsed under a single disclosure control.
5. The remedy disclosure remains separate and is never populated with guessed remedies.
6. F5 matching now requires the Sun/Mercury conjunction in the listed sign groups, not just any same-sign conjunction.
7. No result is generated solely from an abstract/source-only S.K. Mehta principle (e.g. F7).
8. Other astrology modules and chart calculations remain unchanged.

This is a source/UI correction, not a new astrological prediction rule.
