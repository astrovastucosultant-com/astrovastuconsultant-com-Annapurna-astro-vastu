Annapurna Astro Vastu v1.4.448 — S.K. Mehta Inline % and Rule Inspection

- Keep v447 Mehta family house source conditions and editorial evidence formula unchanged.
- In the 12-topic list show the evidence balance % directly beside the topic title.
- A topic tap opens its investigation panel, not an expanded multi-page report in the list.
- Each subtopic title has an inline evidence %; tapping it reveals matched IF–THEN rules first, then chart/house/planet observations and interpretation. Unmatched rules and detailed source remain collapsed by default.
- Without matched evidence show a neutral dash, never fabricate 0%, 50%, or 100%.
- Large lagna comparison and source context remain accessible through collapsed sections.
- Percentage is NOT a statistically validated event probability; MF-01...MF-10 remain editorial app rule identifiers, not Mehta's numbered sutras.
- No D1 chart calculations, Mehta rules, 12-topic classifications, user settings, or Western systems are altered.
