Annapurna Astro Vastu 1.4.449 — S.K. Mehta rule inspection audit

Based on the 1.4.448 FIXED FULL source. Only Rule Inspection UI,
source-condition detail evidence, explicit evaluation states and regression
cases were changed. No historical events or formula outputs were hard-coded.

1. Matched cautionary IF condition displays RED and 'వర్తించింది — ప్రతికూల ఆధారం'.
   Matched supportive condition displays GREEN. A matched rule is not automatically
   a favorable outcome.
2. Not matched: 'వర్తించలేదు'. Missing essential planet input:
   'గణనకు సమాచారం లేదు'. Do not silently substitute a negative judgment.
3. Tap a rule row to show IF, THEN, observed natal chart factors,
   planet's sign, degree, relative/natal house, aspect number and source.
4. Topic percentages are editorial evidence balance, not likelihood.
   0 support / 3 caution -> (0+1)/(0+3+2)*100 = 20%.
   An overall topic % is an average of available UNIQUE subtopic indices,
   so it need not equal the displayed subtopic percentage.
5. No change to the Mehta 3-sign dignity groups, D1 chart or event prediction.
6. The book page numbers and logic are inherited from the existing v448 registry;
   this patch does not independently authenticate the original print editions.

Tests: mehta_rule_inspection_v449_test.dart + previous relevant regressions.
The Flutter SDK was unavailable for local compilation. GitHub Actions must
run the Flutter tests and build before any APK can be called verified.
