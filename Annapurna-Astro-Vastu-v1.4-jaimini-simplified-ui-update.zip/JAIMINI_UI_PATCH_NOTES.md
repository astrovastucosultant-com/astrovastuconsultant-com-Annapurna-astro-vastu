# Jaimini UI patch — 2026-10-20

- Kept the Jaimini D1 chart before Chara Dasha.
- Moved Method A/B/Custom, Scorpio and Aquarius co-lord settings into a collapsed advanced settings section to reduce visual clutter.
- Renamed the MD/AD calendar and shortened explanatory labels in Telugu.
- Retained existing MD/AD calculation and result drill-down logic; did not change unrelated app modules.
- Five-level PD/Sukshma/Prana timing and live transit computation are NOT implemented. Do not claim otherwise.
- Flutter SDK not available in this environment; compilation/APK test NOT run.
