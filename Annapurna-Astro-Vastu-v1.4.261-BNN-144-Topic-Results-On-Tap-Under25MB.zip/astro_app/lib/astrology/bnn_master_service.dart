import 'dart:convert';

import 'package:flutter/services.dart';

import 'astro_models.dart';
import '../models/birth_data.dart';

/// The source catalog is kept verbatim. A chart placement check is NOT the same
/// as a verified Nadi prediction or a timed transit match.
class BnnMasterRule {
  final String id;
  final String source;
  final int sourcePage;
  final String topic;
  final String condition;
  final String result;
  final String inspection;
  final String remedy;
  final String status;

  const BnnMasterRule({
    required this.id,
    required this.source,
    required this.sourcePage,
    required this.topic,
    required this.condition,
    required this.result,
    required this.inspection,
    required this.remedy,
    required this.status,
  });

  factory BnnMasterRule.fromJson(Map<String, dynamic> json) => BnnMasterRule(
        id: json['id'] as String,
        source: json['source'] as String,
        sourcePage: json['source_page'] as int,
        topic: json['topic'] as String,
        condition: json['condition'] as String,
        result: json['result'] as String,
        inspection: json['inspection'] as String,
        remedy: json['remedy'] as String,
        status: json['status'] as String,
      );
}

class BnnMasterCatalog {
  static Future<List<BnnMasterRule>> load() async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_master_462.json');
    final parsed = jsonDecode(raw) as Map<String, dynamic>;
    final items = (parsed['rules'] as List<dynamic>)
        .map((e) => BnnMasterRule.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
    if (items.length != 462 || items.map((r) => r.id).toSet().length != 462) {
      throw const FormatException('BNN 462 rule catalog is incomplete');
    }
    return items;
  }
}

class BnnNatalEvidence {
  final BnnMasterRule rule;
  final String placement;
  const BnnNatalEvidence(this.rule, this.placement);
}

class BnnRoundStudyBand {
  final int round;
  final int fromAge;
  final int toAge;
  final String sourceTheme;
  const BnnRoundStudyBand(this.round, this.fromAge, this.toAge,
      this.sourceTheme);
}

class BnnMasterAnalysis {
  static const Map<String, String> teluguPlanetNames = {
    'సూర్యుడు': 'Sun',
    'రవి': 'Sun',
    'చంద్రుడు': 'Moon',
    'చంద్ర': 'Moon',
    'కుజుడు': 'Mars',
    'కుజ': 'Mars',
    'బుధుడు': 'Mercury',
    'బుధ': 'Mercury',
    'గురుడు': 'Jupiter',
    'గురు': 'Jupiter',
    'శుక్రుడు': 'Venus',
    'శుక్ర': 'Venus',
    'శని': 'Saturn',
    'రాహువు': 'Rahu',
    'రాహు': 'Rahu',
    'కేతువు': 'Ketu',
    'కేతు': 'Ketu',
  };

  static const signNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం',
    'సింహం', 'కన్య', 'తుల', 'వృశ్చికం',
    'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  static const houseNames = <String>[
    '1 భావం • తనువు',
    '2 భావం • ధనం',
    '3 భావం • సహజ',
    '4 భావం • సుఖ',
    '5 భావం • పుత్ర',
    '6 భావం • షష్ట',
    '7 భావం • కళత్ర',
    '8 భావం • అష్టమ',
    '9 భావం • భాగ్య',
    '10 భావం • కర్మ',
    '11 భావం • లాభ',
    '12 భావం • వ్యయ',
  ];

  static const houseThemes = <String>[
    'శరీరం, స్వభావం, జీవన దిశ',
    'ధనం, కుటుంబం, వాక్చాతుర్యం',
    'సోదరులు, ధైర్యం, చిన్న ప్రయాణాలు',
    'ఇల్లు, తల్లి, స్థిరాస్తి, సుఖం',
    'సంతానం, విద్య, పూర్వ పుణ్యం',
    'రోగం, ఋణం, శత్రువులు, సేవ',
    'వివాహం, భాగస్వామ్యం, సంబంధాలు',
    'ఆయుష్యం, గూఢ విషయాలు, ప్రమాదాలు',
    'భాగ్యం, ధర్మం, గురువు, తీర్థయాత్ర',
    'ఉద్యోగం, కర్మ, ప్రతిష్ఠ, వృత్తి',
    'లాభం, మిత్రులు, నెరవేర్చిన ఆశలు',
    'వ్యయం, విదేశం, ఉపసంహారం, మోక్ష దృష్టి',
  ];

  static String houseLabel(int house) =>
      (house >= 1 && house <= 12) ? houseNames[house - 1] : '$house భావం';

  static String houseTheme(int house) =>
      (house >= 1 && house <= 12) ? houseThemes[house - 1] : '';

  static int houseFromSignIndex(int ascendantSignIndex, int signIndex) =>
      ((signIndex - ascendantSignIndex + 12) % 12) + 1;

  // The BNN source explicitly takes Jupiter's natal sign as 1st bhava.
  // If a chart lacks Jupiter the displayed fallback is lagna, never silently
  // mix both systems for an individual placement.
  static int bnnReferenceSignIndex(AstroChartResult chart) {
    for (final planet in chart.planets) {
      if (planet.name == 'Jupiter') return planet.signIndex;
    }
    return chart.ascendantSignIndex;
  }

  static int houseOfPlanet(PlanetPosition planet, AstroChartResult chart) =>
      houseFromSignIndex(bnnReferenceSignIndex(chart), planet.signIndex);

  static int? houseOfPlanetName(String teluguName, AstroChartResult chart) {
    final english = teluguPlanetNames[teluguName.trim()];
    if (english == null) return null;
    final found = chart.planets.where((p) => p.name == english);
    if (found.isEmpty) return null;
    return houseOfPlanet(found.first, chart);
  }

  static List<String> planetsMentioned(String text) {
    final names = <String>[];
    for (final key in teluguPlanetNames.keys) {
      if (text.contains(key) && !names.contains(key)) {
        names.add(key);
      }
    }
    return names;
  }

  /// Readable planet-chain label used on a RESULT card; original IF remains
  /// unchanged in the detail sheet.
  static String shortPlanetChain(String condition) {
    const compact = <String, String>{
      'Sun': 'రవి', 'Moon': 'చంద్ర', 'Mars': 'కుజ',
      'Mercury': 'బుధ', 'Jupiter': 'గురు', 'Venus': 'శుక్ర',
      'Saturn': 'శని', 'Rahu': 'రాహు', 'Ketu': 'కేతు',
    };
    final bits = condition.split('—').map((s) => s.trim()).toList();
    if (bits.length < 2 || bits.length > 3) return condition;
    final labels = <String>[];
    for (final bit in bits) {
      final planet = teluguPlanetNames[bit];
      if (planet == null) return condition;
      labels.add(compact[planet] ?? bit);
    }
    return labels.join(' + ');
  }

  static bool looksLikeTimingRule(BnnMasterRule rule) {
    final text = '${rule.condition} ${rule.result} ${rule.topic}';
    return text.contains('రౌండ్') ||
        text.contains('రవాణా') ||
        text.contains('గోచార') ||
        text.contains('వయస్సు') ||
        text.contains('కాల') ||
        text.contains('సంవత్సర') ||
        text.contains('నెల');
  }

  static bool looksLikeYogaRule(BnnMasterRule rule) {
    final text = '${rule.condition} ${rule.result} ${rule.topic}';
    return text.contains('+') ||
        rule.condition.contains('—') ||
        text.contains('దృష్టి') ||
        text.contains('కలిస') ||
        text.contains('తో') ||
        text.contains('యోగ');
  }

  /// Rule index uses meanings in the provided source (result/topic) and
  /// explicit Jupiter-relative locations. It is a topic index, not proof of
  /// a fully satisfied astrological IF condition.
  static Set<int> housesForRule(BnnMasterRule rule) {
    final resultText = rule.result;
    final topicText = rule.topic;
    final conditionText = rule.condition;
    final houses = <int>{};

    // Explicit positions are relative to Jupiter in BNN, not to Lagna.
    final refs = RegExp(r'గురుకి\s*(\d{1,2})\s*(?:లో|ని|వ|వ ఇంటి|వ భావం)');
    for (final match in refs.allMatches(conditionText)) {
      final number = int.tryParse(match.group(1) ?? '');
      if (number != null && number >= 1 && number <= 12) {
        houses.add(number);
      }
    }
    final text = '$resultText • $topicText';
    const meanings = <int, List<String>>{
      1: ['శరీరం', 'స్వభావ', 'వ్యక్తిత్వ', 'జాతకుడు', 'ఆరోగ్యకర', 'శక్తి', 'జీవనశైలి'],
      2: ['ధన', 'ఆర్థిక', 'కుటుంబ', 'ఆదాయం', 'వాక్చాతుర్య', 'సంపద', 'జీతం'],
      3: ['సోదర', 'ధైర్య', 'చిన్న ప్రయాణ', 'అన్న', 'తమ్ముడు', 'చెల్లెలు', 'అక్క'],
      4: ['ఇల్లు', 'గృహ', 'తల్లి', 'నివాస', 'స్థిరాస్తి', 'వాహన', 'సుఖం', 'భూమి'],
      5: ['సంతాన', 'పుత్ర', 'విద్య', 'చదువు', 'పరీక్ష', 'మంత్ర', 'పిల్లలు', 'ప్రేమ'],
      6: ['రోగ', 'ఋణ', 'శత్రు', 'వైద్య', 'చికిత్స', 'అనారోగ్య', 'వ్యాధి'],
      7: ['వివాహ', 'భార్య', 'భర్త', 'కళత్ర', 'భాగస్వామ', 'వైవాహిక', 'వివాహేతర', 'సంసర్గ'],
      8: ['ఆయుష', 'ప్రమాద', 'మరణ', 'గూఢ', 'రహస్య', 'ఆపద', 'అపాయం'],
      9: ['భాగ్య', 'దైవ', 'తీర్థ', 'ధర్మ', 'పుణ్య', 'భక్త', 'ఆధ్యాత్మిక'],
      10: ['ఉద్యోగ', 'వృత్తి', 'కర్మ', 'ప్రతిష్ఠ', 'ప్రభుత్వ', 'రాజకీయ', 'వ్యాపార'],
      11: ['లాభ', 'మిత్ర', 'నెరవేర్చ', 'పెరుగుదల', 'అభివృద్ధి', 'గౌరవం'],
      12: ['వ్యయ', 'విదేశ', 'సన్యాస', 'మోక్ష', 'నిద్ర', 'ఖర్చు', 'ప్రవాస'],
    };
    for (final entry in meanings.entries) {
      if (entry.value.any(text.contains)) houses.add(entry.key);
    }

    // General methods/timing principles do not automatically belong to
    // first bhava. Keep them in a separate full source-rule reference index.
    return houses;
  }

  static int primaryHouseForRule(BnnMasterRule rule) =>
      housesForRule(rule).isEmpty ? 0 : housesForRule(rule).first;

  /// A plain dash-separated BNN N chain can be observed in a *single sign*
  /// without guessing which other Nadi relations the dash represents.
  /// This is still only a preliminary placement observation, not proof that
  /// the source's IF or its described real-world event is satisfied.
  static bool hasSingleSignPlacement(
    BnnMasterRule rule,
    AstroChartResult chart,
  ) {
    if (rule.source != 'BNN N' || rule.status != 'FACTS_REQUIRED') {
      return false;
    }
    final parts = rule.condition.split('—').map((e) => e.trim()).toList();
    if (parts.length < 2 || parts.length > 3) return false;
    final positions = <PlanetPosition>[];
    final seen = <String>{};
    for (final name in parts) {
      final english = teluguPlanetNames[name];
      if (english == null || !seen.add(english)) return false;
      final found = chart.planets.where((p) => p.name == english);
      if (found.isEmpty) return false;
      positions.add(found.first);
    }
    return positions.every((p) => p.signIndex == positions.first.signIndex);
  }

  /// BNN candidate linkage is sign-based, not just same-sign conjunction.
  /// These relations are alternative FIRST-PASS checks; a recorded planet
  /// sequence, strength, retrograde rules and timed activation remain untested.
  static String? planetaryLink(PlanetPosition a, PlanetPosition b) {
    final distance = (b.signIndex - a.signIndex + 12) % 12;
    if (distance == 0) return 'ఒకే రాశిలో సంయోగం';
    if (distance == 4 || distance == 8) return 'త్రికోణ రాశి సంబంధం (1–5–9)';
    if (distance == 1) return 'తరువాతి రాశి సంబంధం (2వ రాశి)';
    if (distance == 11) return 'వెనుక రాశి సంబంధం (12వ రాశి)';
    if (distance == 6) return 'ఎదురు రాశి సంబంధం (7వ రాశి)';
    return null;
  }

  static BnnNatalEvidence? tentativeNatalPlacement(
    BnnMasterRule rule,
    AstroChartResult chart,
  ) {
    if (rule.source != 'BNN N' || rule.status != 'FACTS_REQUIRED') {
      return null;
    }
    final parts = rule.condition.split('—').map((p) => p.trim()).toList();
    if (parts.length < 2 || parts.length > 3 ||
        parts.any((p) => !teluguPlanetNames.containsKey(p))) {
      return null;
    }
    final positions = <PlanetPosition>[];
    for (final name in parts) {
      final english = teluguPlanetNames[name];
      final found = chart.planets.where((p) => p.name == english);
      if (found.isEmpty) return null;
      positions.add(found.first);
    }
    final links = <String>[];
    for (var i = 0; i < positions.length; i++) {
      for (var j = i + 1; j < positions.length; j++) {
        final relation = planetaryLink(positions[i], positions[j]);
        // Triples require ALL pairs to be linked. A partial chain must not
        // be promoted to a complete 3-planet match.
        if (relation == null) return null;
        links.add('${parts[i]}–${parts[j]}: $relation');
      }
    }
    final positionsText = <String>[];
    for (var i = 0; i < parts.length; i++) {
      positionsText.add('${parts[i]}: ${signNames[positions[i].signIndex]} '
          '${positions[i].degreesInSign.toStringAsFixed(2)}°');
    }
    return BnnNatalEvidence(
      rule,
      '${links.join(' • ')}. ${positionsText.join(' • ')}. '
      'ఇది గ్రహసంబంధ ప్రారంభ పరిశీలన మాత్రమే; BNN గ్రహ క్రమం, '
      'వక్రత్వం, దృష్టి, సమయం, మూలగ్రంథ ఫలిత పరిస్థితులు మరింత ధృవీకరించాలి.',
    );
  }

  /// Only natal-chain candidate checks can be called preliminary matches.
  /// The 343 OCR_REVIEW and 37 REVIEW rules are never treated as a match.
  static String? tentativeHouseMatch(
    BnnMasterRule rule,
    AstroChartResult chart,
    int house,
  ) {
    if (!housesForRule(rule).contains(house)) return null;
    final match = tentativeNatalPlacement(rule, chart);
    if (match == null) return null;
    return '${match.placement} $house వ భావానికి అనుసంధానం ఫలిత అంశం '
        'ఆధారంగా మాత్రమే. సంఘటన నిర్ధారణ కాదు.';
  }

  static List<BnnNatalEvidence> inspect(
    List<BnnMasterRule> rules,
    AstroChartResult chart,
  ) {
    final result = <BnnNatalEvidence>[];
    for (final rule in rules) {
      final hit = tentativeNatalPlacement(rule, chart);
      if (hit != null) result.add(hit);
    }
    return result;
  }

  static String natalPositionsForCondition(
    String condition,
    AstroChartResult chart,
  ) {
    final positions = <String>[];
    for (final entry in teluguPlanetNames.entries) {
      if (!condition.contains(entry.key)) continue;
      final matches = chart.planets.where((p) => p.name == entry.value);
      if (matches.isEmpty) continue;
      final planet = matches.first;
      positions.add('${entry.key}: ${signNames[planet.signIndex]} '
          '${planet.degreesInSign.toStringAsFixed(2)}°');
    }
    if (positions.isEmpty) return 'గ్రహ స్థానాలు ఈ షరతు నుంచి స్వయంగా గుర్తించలేకపోయాం.';
    return positions.join('  •  ');
  }

  static List<PlanetPosition> planetsInHouse(AstroChartResult chart, int house) =>
      chart.planets.where((p) => houseOfPlanet(p, chart) == house).toList(growable: false);

  static String houseOccupancyText(AstroChartResult chart, int house) {
    final planets = planetsInHouse(chart, house);
    if (planets.isEmpty) {
      return 'గురు రాశిని 1వ భావంగా తీసుకున్నప్పుడు $house భావంలో గ్రహాలు లేవు.';
    }
    return planets.map((p) {
      final telugu = teluguPlanetNames.entries
          .firstWhere((e) => e.value == p.name, orElse: () => const MapEntry('', ''))
          .key;
      final label = telugu.isEmpty ? p.name : telugu;
      return '$label — ${signNames[p.signIndex]} ${p.degreesInSign.toStringAsFixed(2)}°';
    }).join('  •  ');
  }

  static int completedAge(DateTime birthday, DateTime today) {
    var years = today.year - birthday.year;
    if (today.month < birthday.month ||
        (today.month == birthday.month && today.day < birthday.day)) {
      years--;
    }
    return years;
  }

  static String ageYear(BirthData birth, int age) {
    return '${birth.localDateTime.year + age}';
  }

  /// R-A03 states a list of Jupiter-round themes, but its scan text remains
  /// OCR_REVIEW. These are age-band *study topics*, not timed predictions.
  static List<BnnRoundStudyBand> jupiterStudyBands(int fromAge, int toAge) {
    const themes = <String>[
      'స్వీయ జీవితం',
      'కుటుంబం / ఆర్థికం / వివాహం',
      'ప్రయాణాలు / సోదరులు',
      'ఇల్లు / నివాసం',
      'సంతానం',
      'ప్రమాద సూచనల మూల పరిశీలన',
    ];
    if (toAge < fromAge || toAge < 0) return const [];
    final output = <BnnRoundStudyBand>[];
    for (var i = 0; i < themes.length; i++) {
      final start = i * 12;
      final end = start + 11;
      if (start > toAge || end < fromAge) continue;
      output.add(BnnRoundStudyBand(i + 1,
          start > fromAge ? start : fromAge,
          end < toAge ? end : toAge, themes[i]));
    }
    return output;
  }

  static String roundInfo(int age) {
    if (age < 0) return 'జననం ఇంకా జరగలేదు';
    final jupiter = age ~/ 12 + 1;
    final saturn = age ~/ 30 + 1;
    return 'గురు సుమారు $jupiter వ చక్రం • శని సుమారు $saturn వ చక్రం';
  }
}
