Universal Event Timing catalog patch (2026-10-18)

Expanded Telugu event selector and event-family mappings for Western Timing v2.
Added profiles: siblings, parents, vehicle, legal, recognition, debt, relationships, travel.
No invented dates: candidate results remain conditional on Solar Arc plus independent contact family.
This is NOT complete Varga/Dasha integration, automated natal promise, or Multi-Event BTR.
The patch was statically checked for archive integrity and selector mapping only.
Flutter compilation and APK build are NOT verified.
