# Jaimini source verification safety patch

The legacy M-01/C-01/W-01/F-01 event score checks are heuristic app identifiers, not authenticated classical sutras. The MD and AD result sheets previously displayed those scores as predictive cards. Those cards are now withheld until a complete source-verified rule dataset and period activation service are wired in. Existing sign-level chart evidence audit remains available.

This is a safety/correctness patch, **not** the requested complete Jaimini prediction engine. PD, Prana, daily transits, source-backed remedies and verified predictive result cards remain pending. No Flutter SDK is available in this environment; analyze/build/test were not run. Do not claim APK verification.
