# Build144 – v1.4.167 Ashtakoota Calculation Audit

Base: v1.4.166 complete source. Added `lib/astrology/ashtakoota_36_service.dart`, integrated into `_finalMarriageReport` and text/PDF sharing, added test covering 729 nakshatra pairs, upgraded pubspec version.

## Scoring
- Varna: 1 point (Moon-sign varna ordinal)
- Vashya: 2 points (degree-sensitive Sagittarius/Capricorn split; symmetric table from Gunmilan variant)
- Tara: 3 points (both directions, 1.5 each)
- Yoni: 4 points (full Maitreya 14x14 matrix)
- Graha Maitri: 5 points (natural lunar sign lord friendships; implementation-specified score convention)
- Gana: 6 points (nakshatra group pair)
- Bhakoot: 7 points (2/12,5/9,6/8 exclusions; no exceptions)
- Nadi: 8 points (identical nadi -> 0, different -> 8; no exceptions)

**Do not confuse with source teacher's 10 printed marriage rules.** Conventional alternatives differ; no guarantee of equal score across providers. Moon missing -> no invented total. PDF currently includes textual numeric tables and D1/D7/D9 sign lists, not full graphical charts. Graphical PDF charts remain pending.

References for variant decisions: https://gunmilan.com/en/vashya-koota.html ; https://saravali.github.io/astrology/koota_yoni.html ; https://getkundly.com/learn/nakshatras/ .

Verification: source-level tests written; Flutter/Dart SDK not installed here, hence **tests and APK build NOT run**. ZIP CRC checks performed separately.
