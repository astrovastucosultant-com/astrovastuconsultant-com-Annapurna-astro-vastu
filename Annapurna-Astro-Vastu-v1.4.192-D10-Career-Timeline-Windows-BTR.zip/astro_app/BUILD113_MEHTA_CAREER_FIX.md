# Build113 — S.K. Mehta career-section repair

* Combines existing registry career labels `ఉద్యోగం / వృత్తి` and `వృత్తి / ఉద్యోగం` into one heading (6 source entries preserved).
* A Mehta career combination not matching is not a conclusion that the person has no work/profession.
* Shows the independently existing D1/D10 profession engine evidence and candidate families in a clearly separated **supporting, non-Mehta** panel.
* Shows user-locked Gocharastha=business/self employment and Agocharastha=service/job labels; mixed stays mixed.
* Candidate taps expose Result, Rule, Chart Examination, Remedy/source guardrails; no fabricated Mehta remedies.
* Preserves all 85 Mehta book entries, other D7/D10/D12 modules, sources and timing layer.
* Adds `test/mehta_build113_career_fallback_test.dart` for grouping and baseline presence.
* IMPORTANT: Static archive testing only in this environment; an actual Flutter compile and on-device review must be completed in GitHub Actions and the installed APK.
