# Jaimini condition matcher — scope and limitations

Added `lib/astrology/jaimini_condition_matcher.dart` and a unit test.

This is an explicit condition evaluation primitive with mandatory-condition coverage, exception veto, source-verification gate, evidence and failure reasons. `TEST-ONLY` is a test fixture, NOT a classical Jaimini rule.

NOT COMPLETED: authentic book-by-book rule transcription and verification, mapping actual chart calculations to condition facts, period activation for all four levels, Telugu predictive prose and expandable UI integration, daily transits, Flutter analyze/test/APK. No prediction should be displayed from this matcher until all these layers are connected and independently validated.
