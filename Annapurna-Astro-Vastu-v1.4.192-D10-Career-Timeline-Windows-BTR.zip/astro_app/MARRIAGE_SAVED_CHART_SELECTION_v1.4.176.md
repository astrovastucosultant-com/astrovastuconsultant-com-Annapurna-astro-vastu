# Annapurna Astro Vastu v1.4.176 — Saved Chart Selection Fix

Reason: The source-library route opens MarriageBookTopicsScreen without a chart, resulting in zero computed checks even when saved charts exist.

Changes:
- Show Saved Charts picker directly on the book topics screen.
- Compute and show chart-specific IF–THEN subcondition results on selection.
- For matching scope, permit distinct first and second saved charts.
- Prevent selecting the same saved record as both matching charts.
- Display computation/loading errors without reporting false results.
- Preserve 62 topic records, 10 sutra conditions and all 88 original page images.

Limits: Chart conditions are NOT independently conclusive marriage predictions. Non-verified source rules remain pending. Building the APK and widget tests require the GitHub workflow / Flutter SDK.
