# Annapurna Astro Vastu v1.4.120 — Family Analysis Multi-Angle Update

## Request
For every relative and topic, show a multi-aspect interpretation rather than only a broad category like “mixed evidence”. Keep Result → Horoscope Inspection → Rule → Source/Remedy.

## Scope
- All 27 relative relationship routes × 12 main topics = 324 selectable reports.
- 63 topic-linked sub-angle definitions across those 12 topics; 7 independent evidence angles for Money / Family / Savings: family savings (2nd), profession-generated income (10th), gains (11th), property (4th), inheritance (8th), liabilities/disputes (6th), expenditure (12th).
- Each facet applies the ten existing Mehta house-strength checks to its own relative-derived house and displays matched / unmatched conditions with rule ID and printed source references.
- Separate Moon-lagna verification, not double-counted in the main result; Mehta-specific THREE-sign dignity groups synchronized with existing Mehta Combination engine.
- Clarifies the meaning of strengthened debt/expenditure houses: an activated house is not automatically an auspicious event.
- 12 topic cards display a substantive preview of sub-aspect verdicts, plus detailed inspection after tap; stage 2 shows facet-specific rule conditions.
- No new date/year, health diagnosis, mortality, guaranteed marriage or business-profit prediction invented. This is comprehensive among the **configured house-strength categories**; it is not a guarantee that every case-specific combination in all three books is evaluated.
- **No outside authors' rules** added to the Mehta tab.

## Source
S.K. Mehta: *New Dimensions in Hindu Astrology* printed pp. 87–95 (portfolios), 100–109 (strength), 143–160 (profession), 160–180 (family/marriage/children), 182–185 (foreign), plus *New Rules and Combinations* family relationships pp. 138–145 and *Synchronization of Period* period rules/house interpretation pp. 18–45, 121–158.

## Static audit
- 12 topics, 63 facet definitions, no unknown topic reference.
- Family reference arithmetic remains unchanged and father=10th preserved.
- Output order Result → Inspection → Rule → Source unchanged.
- 3 new tests (money facets, all 324 family/topic inspections, independent Moon confirmation) added to existing unit tests.
- Previous 442 files preserved; source modifications limited to 4 files. Dart delimiter balance validated.
- **Flutter compile and on-device testing not performed here:** run GitHub Actions on upload before relying on APK.
