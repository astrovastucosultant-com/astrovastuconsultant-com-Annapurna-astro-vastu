# Build108 — D12 59-rule + 20-example sourcebook merge into v1.4

**App:** Annapurna Astro Vastu `1.4.108+108`

## Starting point / non-destructive merge

Starting ZIP: `Annapurna-Astro-Vastu-Build107-v1.4.107-D12-Display-Accuracy-Source.zip` from the user's file library. It contains a complete Flutter `astro_app` source tree. No other varga engine was intentionally changed.

The existing `D12SourceRuleService` (49 source-analysis records + 20 reference cases = 69) and `VargaRuleService._d12` are **preserved unchanged**. Source-only, unmatched, and live-matched rule statuses remain distinct; existing chart results are not overwritten.

## New integrated D12 sourcebook

- `assets/d12/D12_Rules_Examples.json`: all **59 IF–THEN sourcebook rules**, **20 book examples**, **97 example explanations** (from user-supplied D12 chapter).
- `assets/d12/source_pages/`: **49 JPG scans** (title plus 48 distinct printed pages) used to inspect original charts and text. The scanned PDF has 51 image pages, including repeated pages 304 and 305; source imagery preserves distinct printed page images.
- `lib/astrology/d12_book_rule_engine.dart`: a pure Dart `when.all / when.any` matcher for verified fact sets and source-fixture checks.
- `lib/screens/d12_source_book_screen.dart`: native Flutter D12 sourcebook, searchable by topic / ID, section chips, detailed 20 examples, chart page zoom, flow **Result → Rule → Remedy availability**.
- D12 varga panel in `lib/screens/chart_screen.dart`: visible button **59 రూల్స్ + 20 ఉదాహరణలు తెరవండి**.
- `pubspec.yaml`: `assets/d12` paths and version bump.
- `test/d12_build108_full_rulebook_test.dart`: checks rule / example / observation / fixture totals.
- `docs/D12_B108_Fixture_Test.js`: offline fixture runner.

## Verified tests

- JSON model and required keys: checked.
- Sourcebook fixture assertions: **107/107 PASS**, using `node docs/D12_B108_Fixture_Test.js`.
- Source assets link check: all `source_pages` paths referenced in JSON exist.
- ZIP integrity: verified after packaging.

**Important:** 107/107 tests replay narrative facts recorded in the scanned chapter, **not ephemeris or birth-time recalculation**. This view deliberately does not auto-fire additional sourcebook rows for a live chart unless the verified inputs are passed to `D12BookRuleEngine`. Existing chart-based matches are calculated by the pre-existing `D12SourceRuleService` (and are shown in the D12 varga panel). KL and Cyclical D12 methods remain pending; source examples are not universal predictions. No unprovided remedies, alleged parent-death dates, or moral judgments are generated.

## Build / upload

This is a **full replacement Flutter source ZIP**, not an APK and not a file already committed into GitHub. The extracted `astro_app/` project contains `.github/workflows/build-android-apk.yml`. Flutter/Android compilation must run using GitHub Actions or a local Flutter SDK. No device build has been claimed here.
