# Western Timing v1.4.157 calculation audit

## Implemented
- Swiss Ephemeris (Moshier, tropical without sidereal flags), natal planet longitudes and angles.
- Secondary, Tertiary-I (synodic), Minor (sidereal lunar month), converse-secondary ephemeris sampling.
- Solar Arc based on progressed Sun displacement, directed natal planets and natal angles.
- Naibod and 1° symbolic rotations separately.
- Whole sign annual profection sign and traditional sign ruler.
- Longitude-based natal contacts at 0/60/90/120/180 with selectable angular orbs.
- Western tab position tables, contacts and settings.

## Not complete / do not use as authoritative event predictions
- Full Primary Directions, RA/declination with proper direction key.
- Progressed ASC/MC by a canonical progressed-angles method (present epoch chart angles are *not* that).
- Full converse family, validated event-rule matching and Western multi-event BTR.
- Tertiary-II convention; tertiary-I choice is explicit.
- Astrological evidence percentages and predictive validation.

Only source-level static / structural checks performed; Flutter compile/device run not verified here.
