# D10 Reverse Career Search, Timeline and BTR — v1.4.185

## New path
D10 → **ప్రస్తుతం చేస్తున్న వృత్తి వెతకండి · Career Timeline · BTR**.

- Search is over 336 existing source IF–THEN rule entries and 181 legacy professions. Search does not imply favorable results. Multiple relevant source entries are shown with their precise rule IDs.
- Tap **రూల్ / జాతక పరిశీలన** to inspect the D1→D10 confirm, D10 required planets, deity and bhava checks, and the literal source condition. Unlinked old profession labels remain available, explicitly without an invented result.
- Record *actual* career event type, occupation, source rule ID where known, event date and optional notes. Multiple events are stored in SharedPreferences per original birth-data identity; age is completed years as of the entered date. Tap an event to inspect historical Vimshottari MD and AD plus Jupiter AND Saturn sidereal transits in that month. Transit is sampled on the **15th**, not the exact event day.
- BTR compares candidate birth times at 1-minute increments within user-selectable ±2/3/5/10 minutes. Rebuilds the natal D1 and D10 chart for each candidate using the app Swiss Ephemeris and evaluates each dated event. Reports five **evidence gates** per event: natal D1→D10 confirmation, full source predicate, MD linkage, AD linkage, and combined Jupiter–Saturn transit support. Historical career changes, promotions and starts count as independent user-provided observations. Same event cannot double-score through duplicate rulebook entries (best sourced rule only).
- Candidate rankings are comparative evidence only and explicitly disclose ties, unlinked professions and failures. This module **does not edit the birth time**, does not establish BTR certainty, and does not show an empirical probability of career occurrence. Other birth-time rectification evidence should be examined separately.

## Tests
`test/d10_career_reverse_btr_test.dart` covers reverse search, unmatched events, event serialization, candidate range and evidence bounds. Source zip and syntax/reference auditing conducted, **actual Flutter compile must be performed in GitHub Actions**.

## Unchanged
Existing 517 career records, rulebook semantics, independent activation forecasts, D9/marriage and GitHub build workflow were retained. ZIP is one whole Flutter project under `astro_app/`.

## Duplicate-event control
Identical occupation+event-type+date combinations are rejected at entry, so accidentally repeated entries do not boost the comparison. Saved timeline entries may be removed with an explicit confirmation.
