# Build143 / v1.4.166 Marriage Final Report follow-up

Base: v1.4.165 complete source. Changes limited to chart_screen.dart, pubspec.yaml and this audit.

Added:
- Both birth panchanga summaries to Final Report.
- An Ashtakoota 8-koota (max 36) *placeholder with no fabricated scores*; scoring engine not available in current source.
- For each partner D1, D7, D9 expandable South Indian 4x4 sign chart on the marriage tab (6 total charts).
- The PDF's text data now contains both partners' D1/D7/D9 12-sign placements, but *not yet rendered diagram graphics*.
- Groom's birth Vimshottari MD/AD lords matched against bride D1 Lagna sign and Lagna lord's sign, with a transparent narrow definition of sign-level links. This is a partial implementation of the user-supplied Guru rule; aspects, exchange, complete source-page verification remain to be done. Treat 'past-life bond' as a traditional interpretation, not an objectively established fact.
- Existing 10 marriage matching source rules, D7-35 review, Save/Share/Print PDF retained.

Tests: Static syntax/expected markers and ZIP CRC. Flutter compilation unavailable in this environment. Manual app testing required.

Pending: True 36-point Ashtakoota algorithm including exceptions/lookup tables; actual South Indian 3-chart page layout in exported PDF; Full Guru relationship rule (all supported aspects, exchanges); interactive tap-inside-PDF unsupported (tap behavior on app cards only). Do not label these complete.
