# Annapurna Astro Vastu – GitHub APK Auto Build (v1.4.172)

ఈ ప్రాజెక్ట్‌కి Flutter 3.47.5 / Dart 3.13.4, Java 17 GitHub Actionsలో ఆటోమేటిక్‌గా ఇన్‌స్టాల్ అవుతాయి.

## ముఖ్యమైనది — రెండు ఫైల్స్ GitHubలో వేర్వేరుగా పెట్టాలి

1. **`Annapurna-Astro-Vastu-v1.4.172-GitHub-AutoBuild-Ready.zip`** ను repository లో upload చేయండి.
2. **`build-apk.yml`** ను repository root లోని **`.github/workflows/build-apk.yml`** పాత ఫైల్ స్థానంలో replace చేయండి. ZIP లోపల ఉండే `.github` GitHub Actionsకి నేరుగా కనిపించదు.
3. Actions → Build Annapurna APK → Run workflow ను వాడండి. **`source_zip` ఖాళీగా** ఉంచితే `pubspec.yaml` version+build సంఖ్య అత్యధికంగా ఉన్న ZIP ఎంపిక అవుతుంది.
4. Build Success వచ్చిన తరువాత Actions → సంబంధిత run → Artifacts → `Annapurna-Astro-Vastu-APK` download చేయండి.
5. GitHub ఇచ్చే ZIP ను Extract చేసి, అందులోని `app-release.apk` ను Downloads నుంచి install చేయండి.

## పరీక్షలు
- D9, వివాహ పొంతన, మూడు మూల గ్రంథాల 88 source images కలిగి ఉన్నాయో పరీక్ష.
- Flutter/Dart version display, `flutter pub get`.
- `flutter analyze --no-fatal-infos --no-fatal-warnings`: errors fatal; warnings logged.
- `flutter test` (అన్ని test files): ఏదైనా test fail అయితే APK ముందుకు వెళ్లదు.
- `flutter build apk --release`, APK ZIP integrity మరియు `apksigner` verification.
- Failure logs: `Annapurna-Build-Check-Logs` artifact, error detail GitHub run step logs.

## పరిమితులు / జాగ్రత్తలు
- ఇది **workflow/source సిద్ధం చేసిన ప్యాకేజ్**, ఈ చాట్‌లో Flutter SDK లేకపోవడంతో APK నిజంగా compile/test అయినట్లు చెప్పలేం.
- పాత project signing setup మారలేదు; Play Store కోసం production signing key నిర్వహణ ప్రత్యేకంగా అవసరం.
- GitHub repositoryలో పాత రెండో Android workflow ఉంటే duplicate builds రాకుండా దాన్ని నిలిపివేయండి.
- ZIP upload చేయడం మాత్రమే సరిపోదు: root `.github/workflows/build-apk.yml` ను మార్చాల్సిందే.
