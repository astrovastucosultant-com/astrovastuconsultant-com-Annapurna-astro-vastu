# D10 Confirmed percentage green UI — 1.4.186

- Rules-screen IF–THEN: any calculated percent with a D1→D10 Confirm is green, including partial rule matches.
- Older linked profession entries: confirmed percentage is green; missing source linking is amber and non-confirmed evidence is grey.
- Reverse Career Search: confirmed percentages are green; no Confirm never displays 0%.
- `complete == false` still says partial; a green percent does not claim every IF–THEN predicate passed, a job outcome, or a proven prediction.
- All numerical score calculations, rules, 517 entries, timeline and BTR engines unchanged.
- No change to GitHub workflow. Requires Flutter build validation in GitHub Actions.
