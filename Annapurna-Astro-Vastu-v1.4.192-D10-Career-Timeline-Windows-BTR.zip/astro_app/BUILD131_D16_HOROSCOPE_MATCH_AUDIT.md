# Annapurna Astro Vastu — Build131 D16 Actual Horoscope Matching

- Version: 1.4.131+131
- Based on Build130 full Flutter source; no D7, D10, D12, Mehta or BTR feature removed.
- Prior Build130 erroneously marked all 13 new D16 video-study rows applicable for every chart.
- Build131 separates 8 conditional D16 video rows (Lagna lord, 4L, Jupiter/4, Venus/4, Mars/D1 4L, 4/6/8, 4/3/12, 3/6/11 lords) from 5 contextual/source observations.
- Older vehicle/comfort/delay rows now require at least one matched support check, and vehicle caution is still conditional.
- Matched results appear first; nonmatching rules and contextual notes appear under D16 source/audit. None is discarded.
- D16 method selection still recomputes varga chart and rules together.
- Touch path: Result -> Horoscope Inspection -> Rule/Source -> Remedy/Source note.
- Pregnancy, fatal accident, injury, hospitalization, theft and exact timing cannot be guaranteed by this traditional interpretative system; no predictive accident likelihood is supplied.
- Unit tests added for unique IDs, both D16 calculation methods, contextual/source-only separation, and conditional horoscope checks.
- Static source checks and ZIP CRC integrity completed; Flutter compile/unit tests NOT executed because SDK unavailable in this environment. GitHub workflow required for compile verification.
