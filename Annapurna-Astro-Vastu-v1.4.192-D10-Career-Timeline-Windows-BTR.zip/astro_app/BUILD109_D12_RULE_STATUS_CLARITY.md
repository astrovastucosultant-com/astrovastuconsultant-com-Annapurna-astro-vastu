# Build109 — D12 status display clarity

Based on the exact v1.4.108 source ZIP matching GitHub Build #91 SHA `2bfcc9d0a7ef7094cbb1b770a7261664e06df7dc`.

- Green check = the source rule matched a live chart (not necessarily favorable).
- D12 adverse interpretation displayed separately as amber **⚠ జాగ్రత్త**; no misleading red cancel icon.
- '10 unmatched' clarified as rules whose conditions do not hold, not source/build errors.
- '36 Source/Pending' clarified as doctrine, historical commentary, KL/Cyclical calculations not verified.
- Cases are cited as historical examples only.
- No rule engine, chart computation, or other varga behavior changed.
- The 59-rule/20-example D12 sourcebook remains intact but is **not a live 59-rule computation engine**.
- User must upload this full replacement project ZIP to GitHub repository and obtain a new Actions release APK; local Flutter SDK not available here.
