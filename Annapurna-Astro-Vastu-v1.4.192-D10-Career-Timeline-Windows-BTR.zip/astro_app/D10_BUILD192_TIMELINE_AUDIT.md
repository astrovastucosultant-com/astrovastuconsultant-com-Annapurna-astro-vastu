# D10 v1.4.192 — Career event comparison / historical timing windows

- Preserve 336 sourced IF–THEN rules and 181 original profession records.
- Group adjacent month-15 Jupiter+Saturn/MD+AD matches into a start-to-end window; a missed month or MD/AD boundary opens a distinct window. Extend a last window even when display count limit is reached.
- Show historical window (since approximately age 16) separately from future windows (up to 20 years). Do not assert any date of actual occupation from astrological calculations alone.
- D10 profession card opens Career Timeline with the occupation & associated rule selected. Existing saved dates are unchanged.
- Career Timeline has an explicit action to evaluate all observed dated events using natal rule, Vimshottari MD/AD and monthly Jupiter+Saturn sample, with reason, gates and comparison status. Saved historical facts are not rewritten.
- Financial gain/loss/growth events use *one compound* BTR corroboration (rather than counting the same MD/AD/transit components independently); outcomes with no matching criterion receive no full score.
- Retain green/pink/grey sorting and the profit-loss screen unchanged; no source rules are deleted.
- Version in pubspec.yaml bumped to 1.4.192+192 to prevent ambiguity between ZIPs v1.4.190 and v1.4.191, whose internal pubspec versions were identical.
- Validations here: archive integrity, source references, structural checks. Flutter/Dart SDK unavailable in this environment; GitHub release compilation is required.
