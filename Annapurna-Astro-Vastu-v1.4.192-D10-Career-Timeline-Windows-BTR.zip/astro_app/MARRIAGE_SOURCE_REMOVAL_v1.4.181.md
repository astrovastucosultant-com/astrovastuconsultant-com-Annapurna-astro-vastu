# v1.4.181 — Marriage source cleanup

User-approved source replacement: removed exactly 88 original scanned WebP pages from:

- `assets/marriage_sources/handwritten/` (20 pages)
- `assets/marriage_sources/marriage_rules/` (39 pages)
- `assets/marriage_sources/marriage_2/` (29 pages)

Retained: `assets/marriage_chrome/page_01.webp` through `page_06.webp`,
`docs/Annapurna_Marriage_Rules_Chrome.pdf`, all 43 IF–THEN rules, checklist,
chart examination and auto-build workflow. Flutter asset manifest no longer
mentions deleted folders. Historic screens route to the latest 43-rule
checklist or latest six-page source browser to avoid broken image links.
Two-chart matching engine is not deleted, but no longer links its rules to
old pages; old source evidence cannot be shown.

This is a source cleanup, not a claim that 43 rules are all fully computed.
