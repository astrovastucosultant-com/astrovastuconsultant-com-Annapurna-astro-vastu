# Jaimini UI integration — provisional safety gate

- Existing Chara Mahadasha and Antardasha touch screens now hide event categories when no event rule condition matched.
- Antardasha cards display matched Rule IDs and an explicit source-verification warning.
- Empty periods display a no-matches explanation instead of generic predictions.
- This is NOT full source-verified prediction integration. Current scoreEvent rule checks are not automatically verified against original sutra texts.
- PD, Prana and daily-result UI wiring is not completed by this patch.
- Flutter analyze/build was not run (Flutter SDK not present in environment).
