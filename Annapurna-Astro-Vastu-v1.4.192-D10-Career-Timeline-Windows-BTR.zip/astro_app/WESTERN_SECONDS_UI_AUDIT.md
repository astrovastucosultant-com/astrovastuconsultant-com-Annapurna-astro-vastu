# Western seconds refinement UI patch

- Adds experimental seconds search button and displays top five candidates with HH:MM:SS, contact scores and supported event counts.
- Uses existing refineSeconds function, 3 coarse candidates, +/-60 seconds and 10-second steps.
- No claim of astronomical accuracy or birth-time precision.
- Full primary directions, validated event house lord rules and Flutter build remain outstanding.
- Flutter SDK is not installed in this environment; compile/APK not tested.
- Do not replace successful production build until CI passes.
