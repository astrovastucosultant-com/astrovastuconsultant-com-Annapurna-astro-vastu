# Build v1.4.179: Siddhanti Mallikarjuna - Marriage Chrome 43 IF–THEN

**Source:** `Annapurna_Marriage_Rules_Chrome.pdf`, six pages, 18 numbered sections, 43 IF/THEN clauses.

## Navigation
D9 -> Marriage IF-THEN -> D9 43 IF–THEN checklist; select a Saved Chart or use the open chart. Tap the **result** to expand the actual IF/THEN wording, inspected D1/D7/D9/D30 evidence and original PDF page. Manually tick **జాతక పరిశీలనను నేను ధృవీకరించాను** to record checklist review; that checkbox does not modify computed status.

## Matching statuses
- **matched**: a particular objectively testable subcondition was found in calculated chart data, **not** a guaranteed marriage, divorce, caste, fidelity, health, or timing outcome.
- **notMatched**: the specifically defined, testable predicate is false.
- **needsChart**: saved chart not chosen; cannot evaluate.
- **needsDefinition**: composite text involves undefined strength thresholds, rajayoga/dhanayoga, tara-lord choice, aspect/affliction convention, gender, waxing Moon/budha classification, exceptions etc. Source IF/THEN text is displayed exactly; available subchecks and actual positions are shown, but a positive/negative verdict is not fabricated.

The file provides explicit IF–THEN **text** for all clauses; it does not stipulate a machine-checkable strength/scoring definition for all predicates. Avoid substituting arbitrary hardcoded thresholds.

## Conservative calculation assumptions
- Default planetary aspects: seven-place for seven planets; 5/9 Jupiter, 4/8 Mars, 3/10 Saturn. Nodes evaluated for conjunction, not contested node aspects.
- Jaimini seven chara-karaka DK/GK determined from the seven planets ranked by degree within natal sign (equal degrees require further review).
- Sign ownership and classical exaltation/debilitation tables where defined.
- Only direct, explicit checkable predicates return a computed state. Ambiguous complementary methods yield needsDefinition when unmatched.
- VargaService reused for D1, D7, D9, D30. No duplicate calculations or replacement of original project main().
- Manual review checklist persists locally in preferences per selected Saved Chart; checked status is NOT astrological truth.

## Validation
- 43 source clauses × 18 sections verified against PDF page numbers.
- UI source images present page_01.webp to page_06.webp.
- Flutter build must be validated by connected GitHub Actions, no local Flutter SDK.
