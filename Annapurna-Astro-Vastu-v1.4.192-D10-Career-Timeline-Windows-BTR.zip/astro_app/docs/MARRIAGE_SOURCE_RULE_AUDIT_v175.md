# Siddhanti Mallikarjuna source-rule integration – v1.4.175

## Grounded sources
* `Marrage rules ok.pdf`: 39 scanned pages, *source page indexes* used here, not printed footer page numbering.
* `marriage my meterial.pdf`: 20 scanned pages.
* `Marrage -2.pdf`: 29 scanned pages.
* All 88 source page images remain packaged offline.

## What is actually computed
* All 62 legacy *topical navigation headings* stay visible. They are NOT equivalent to 62 verified IF–THEN tests.
* **10 PDF page/sutra subconditions** are newly registered in `MarriageVerifiedSutraEngine`, with stable IDs:
  * `P07-S04`: D9 Upachaya 10H minimum occupant (partial 10H check, not the entire yogas combination).
  * `P12-S10-R01`: D1 Moon in house 2 or 7.
  * `P13-S11-R01`: D1 Ketu in house 2 or 7.
  * `P13-S12-R01/R02`: D1 11L related by exact house occupancy to 7L/2L.
  * `P14-S13-R01`: D7 Jupiter in 2H or 7H.
  * `P15-S14-R01`: D7 Saturn in 2H or 7H.
  * `P16-S15-R01/R02/R03`: D7 Mars in 2,4,7,8,12 from Asc/Moon/Venus. These are **placement predicates only**; exceptional contacts/cancellations are unresolved.
* M-04 displays the audited 10H predicate, including its evidence. Missing planetary data remain explicitly uncertain.
* Additional subrules appear in the `MarriageBookTopicsScreen` in the *individual* and *all* modes, separate from the old 62 navigation headings. Tapping result → rule → chart → remedy → original page uses the existing drill-down format.

## Audit correction
Some headings in the 62-topic index were mapped historically to the wrong PDF pages or concepts (especially pages 12–16). They were **not promoted to calculated marriage predictions**. The 10 new items are instead keyed to the actual PDF page and printed sutra/subrule, preventing mistaken attribution.

## Important gaps
* **52+** topical headings and remaining subconditions do not yet have complete verified logic. This stage does not claim to finish 62 rule engines.
* Birth date/time and transit/dasha method inputs are not passed into this screen. The M19–M36 topics therefore do not invent marriage years, months, or days. The app's separate pre-existing D9 report uses a dasha-evidence ranking but is not this book-specific timing calculation.
* There is no verified remedy in the cited printed sutras; none was fabricated. Clear compatibility and personal D9 outcomes require more than one subcondition.
* Flutter and Dart SDK were not present in this authoring runtime. ZIP integrity and static source checks can be executed locally; full Flutter compile must run in GitHub Actions.
