// Run with `node D12_Test_Runner.js` inside the extracted ZIP folder.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const src = JSON.parse(fs.readFileSync(path.join(__dirname,'..','assets','d12','D12_Rules_Examples.json'),'utf8'));
function match(rule,facts){ return rule.when.all.every(k=>facts.has(k)) && (!rule.when.any.length || rule.when.any.some(k=>facts.has(k))); }
let passed=0,failed=0;const coverage=new Set();
for(const e of src.examples){
  const facts=new Set(e.fixture_facts);
  const actual=new Set(src.rules.filter(r=>match(r,facts)).map(r=>r.id));
  for(const id of e.expected_rule_ids){
    if(actual.has(id)){passed++;coverage.add(id)}else {console.error('FAIL',e.id,id);failed++;}
  }
}
for(const r of src.rules){
  assert.ok(r.id && r.title && r.when, 'Malformed rule');
  assert.ok(r.printed_pages.every(x=>x>=293&&x<=340),'Bad source page');
  const unknown=r.when.all.concat(r.when.any).filter(x=>typeof x!=='string'||!x);
  assert.equal(unknown.length,0,'Invalid fact name');
}
assert.equal(failed,0,'Expected fixture match failures');
assert.equal(src.rules.length,59);
assert.equal(src.examples.length,20);
assert.equal(passed,107);
assert.equal(src.examples.reduce((x,e)=>x+e.observations_te.length,0),97);
console.log('PASS — rules:',src.rules.length,'examples:',src.examples.length,'text observations:',97,
            'fixture assertions:',passed,'of',passed+failed,'sample-covered rules:',coverage.size);
console.log('Scope: replays source-reported case commentary; chart arithmetic and ephemerides NOT recalculated.');
