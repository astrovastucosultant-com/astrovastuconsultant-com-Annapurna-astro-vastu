# Build115 — S.K. Mehta Family Horoscope Analysis

- Added Mehta-only 27-route relative-house family analyzer inside S.K. Mehta tab.
- Source: New Dimensions printed pp.87–95 (especially 95); New Rules and Combinations printed pp.118, 138–145; Synchronization of Period printed pp.18–22.
- 12 topical derived-house selectors. Father is 10th, not 9th, per Mehta source.
- One-touch result → source rule → D1 horoscope evidence → source/remedy.
- Planet placement and aspects are observations only, not predictions. No unsourced remedies, scores, D10, or ashtakavarga added to the Mehta tab.
- No generated independent natal horoscope or medical/event certainty.
- Existing other varga/module files unchanged. Build not locally compiled: GitHub Actions verification required.
- Added Flutter test cases for 27×12 relative-house routes, source-specific father reference, and D1 aspect observations.
