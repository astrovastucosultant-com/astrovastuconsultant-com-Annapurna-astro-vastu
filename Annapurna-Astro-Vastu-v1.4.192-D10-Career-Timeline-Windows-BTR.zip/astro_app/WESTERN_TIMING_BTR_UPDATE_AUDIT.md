# Western timing update: limited source patch

Implemented: RA/declination Placidus semi-arc coordinate calculation with direct/converse arcs, Naibod/Ptolemy keys; named event-significator profiles; event-aware filter in existing Solar Arc BTR candidate ranking. Existing screen and other engines retained.

NOT complete: reference-verified 3D Placidus directions across all quadrants, zodiacal aspects, Regiomontanus/Campanus, complete primary contacts integrated into the UI, multi-method event timing search, quantitative evidence calibration, or an independently validated BTR. Current BTR still samples Solar Arc angular contacts only. Do not advertise as full or scientifically validated. No Flutter compiler available in this environment.

Sources: https://kerykeion.net/python-library/docs/v6/primary_directions_factory ; https://www.astro.com/swisseph/swephprg.htm ; https://alexeyborealis.com/blog/placidus-direction/


## UI Integration revision (2026-10-17)
- Event Timing Search now filters contact lists using a Telugu-event to Western-event profile mapping; unknown events are explicitly excluded rather than producing unrelated hits.
- BTR scan resolution changed from five minutes to one minute within the selected scan window.
- Existing multi-event BTR remains Solar Arc only. One-minute resolution does not establish second-level accuracy.
- Remaining: full Primary Directions with correct body latitude and epoch obliquity, independent reference verification, multi-method BTR, house lord/event rule validation and actual Flutter build tests.
