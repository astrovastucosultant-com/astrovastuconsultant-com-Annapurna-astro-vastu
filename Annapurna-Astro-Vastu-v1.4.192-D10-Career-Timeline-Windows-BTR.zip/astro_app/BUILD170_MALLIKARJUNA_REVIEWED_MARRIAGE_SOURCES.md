# Build 170 — Siddhanti Mallikarjuna reviewed Marriage source pages

## Actual source provenance

These *user-provided* PDF files are now available to the Android/Flutter app as local, viewable, zoomable page images. Page indexes are physical PDF page numbers, starting at 1:

| Original user PDF | Page count | App asset prefix |
|---|---:|---|
| marriage my meterial.pdf | 20 | assets/marriage_sources/handwritten/ |
| Marrage rules ok.pdf | 39 | assets/marriage_sources/marriage_rules/ |
| Marrage -2.pdf | 29 | assets/marriage_sources/marriage_2/ |

Reviewer credit (per user's instruction): **సిద్ధాంతి మల్లికార్జున పరిశీలించిన నియమాలు**. This is review attribution and does *not* overwrite authorship printed on source book pages.

## Actual integration

- **D9 → one-chart marriage source rulebook:** existing individual 43-ish D9 source catalog links every rule to its original page. For example MM-R37 opens `marriage my meterial.pdf` PDF page 17. The D7 confirmation MM-D7-DIV-35 points to `Marrage rules ok.pdf` physical page 28 as identified in registry.
- **D9 → original source library:** all three volumes and all 88 scanned pages can be viewed offline without additional app downloads.
- **Marriage matching → source library:** source image library is accessible even if no second saved chart exists. Existing 43-slot matching calculations remain separately scoped. The original printed source tables (Vedha p3, Nadi p4, Rajju p4) are linked from the corresponding evaluated checklist entries, and each additional printed source entry links to its exact recorded page.
- Existing D9 Final Marriage Report calculation, two-chart source engines, app entrypoint, and prior screens are preserved. Existing 43-slot `Marriage43RuleEngine` evaluated/pending behaviour is unchanged.

## Critical limitation (must not be concealed)

Original source pages are rendered intact as **images**, not OCR-derived automatic IF–THEN algorithms. Many handwritten rules in these PDFs are not yet manually transcribed and computationally validated; therefore they cannot be called "implemented calculations". The 43-slot match evaluator continues to mark unsupported predicates pending. Source pages contain diagrams and tables; scanned visibility is valuable but not equivalent to logical rule matching. No compatibility percentage is fabricated.

## Build / verification

- Check all 88 WebP assets exist and match `ReviewedMarriageSources.assetPath`/`pageCounts`.
- `test/marriage_reviewed_sources_test.dart` validates local scanned page coverage.
- Actual `flutter analyze`, `flutter test` and Android APK build still require the Flutter SDK/GitHub Actions; not executed in the offline environment.
