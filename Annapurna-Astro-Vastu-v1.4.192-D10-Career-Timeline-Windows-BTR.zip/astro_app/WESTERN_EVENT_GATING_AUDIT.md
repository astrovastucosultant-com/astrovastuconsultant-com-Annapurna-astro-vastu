# Western event shortlist audit

- Only up to 3 preliminary dates, not every year.
- Requires event-specific planet and angle contacts, at least 3 distinct technique families and orb <= 0.25 degrees.
- Solar Arc, Naibod and symbolic directions grouped as correlated; Secondary and Converse Secondary grouped.
- Date sampling still follows user-selected step; an exact event date is not determined.
- No house-lord implementation, validated prediction, or full primary directions.
- No Flutter SDK in this environment; compile is NOT verified.
- Retain previous successful APK until CI passes.
