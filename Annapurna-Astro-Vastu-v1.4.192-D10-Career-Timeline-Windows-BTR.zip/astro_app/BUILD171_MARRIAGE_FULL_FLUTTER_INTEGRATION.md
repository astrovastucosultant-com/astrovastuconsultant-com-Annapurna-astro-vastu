# Build 171 - Full Flutter marriage source integration

## Contents integrated into the actual existing Flutter app

1. Original **88 offline zoomable scanned PDF pages** are retained from Build170: `marriage my meterial.pdf` (20), `Marrage rules ok.pdf` (39), `Marrage -2.pdf` (29).
2. **62 indexed marriage topics** from user's prior V51 HTML source catalogue are now in `lib/astrology/marriage_rules_ok_registry.dart`, linked to the original physical scanned pages in `Marrage rules ok.pdf`. The 62 entries are *topic/source references*, not 62 verified IF-THEN formulas. They are separately filtered for personal marriage topics and two-chart matching topics.
3. The D9 personal source book shows actual D1/D7/D9/D30 chart placements (lagna, seventh sign and lord, planets) if the natal chart is available, without promoting chart availability into a rule pass. Generic placeholder titles are displayed as numbered source records, not invented descriptions.
4. Both D9 and marriage matching display the sequence **Result > Rule > Chart examination > Remedy** with nested expandable widgets, and original source-page navigation where the source link is known.
5. Both user-facing sections can open the original sources and indexed printed-book topics. The 39-page PDF viewer supports direct page selection, next/previous, and pinch-to-zoom.
6. 43-slot groom/bride rule evaluator, printed source table engine, D9 final report, existing non-marriage app features and storage are preserved.

## Architectural truth and limitations

The 43 matching **slots** are not the same as the 62 printed-book topics nor the 69 `MM-...` source records. Some predicates are implemented (printed tables, 6/8 and 2/12), and the rest remain explicitly pending. The 88 scanned pages do **not** imply 88 automatically validated rules. No marriage percentage, timing guarantee, or remedy is invented.

## Verification

Source ZIP byte-by-byte member checks and static source checks are run at packing time. `flutter analyze`, Flutter widget/unit tests, and APK compilation must be run with a Flutter SDK/GitHub Actions. The current container does not have Flutter installed; APK success is **not claimed**.
