Added traditional natal house lord lookup and audit-only event house evidence.
NOT YET DONE: calculate verified natal cusps; compute complete Primary Directions;
validate historical event dates independently; integrate new evidence into BTR and UI;
run Flutter tests/build. Do not treat a matching house lord as a prediction.
