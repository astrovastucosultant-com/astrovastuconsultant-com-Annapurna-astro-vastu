# Build116 — Mehta Family: Source-based Inspection & Findings

**Scope**: Replaces the Build115 family card's unimplemented promise of detailed inspection with a structured, source-grounded evaluation. The rest of the Flutter application and existing D7/D10/D12 and other modules are unchanged.

## New behavior

- Selected relative (27 relationship paths) + 12 topics: full topic overview displayed by default (324 possible relative/topic inspections).
- Results: a **supporting**, **cautionary**, **mixed** or **undetermined** evidence classification. This is **not** a probability, definitive life event, diagnosis or judgment of a person.
- Required touch flow **Result -> Rule -> Horoscope Inspection -> Source / Remedy**.
- Ten **Mehta-sourced conditional checks**, each with: test, match/no-match, actual chart evidence, printed source pages. IDs MF-01..MF-10 are editorial.
- Check own lord occupancy and own aspect; exalted planet in/aspecting the topic; lord's exchange and source-specific own/exaltation; lord in derived 6/8/12; fallen lord, fallen occupants, fallen aspects.
- Explicitly displays lord's own/other relevant portfolios, natal and family-reference houses, sign/dignity, retrograde marker, other planets and aspects.
- Independent Moon-ascendant **reference sign**, clearly separated from the natal-reference classification.
- Respects the Mehta source's **father=10th house** and his unusual **Mercury exalted in the 11th sign (Aquarius)** from New Dimensions printed p.28; does not mix another exaltation table.
- Keeps documented relative-house arithmetic extensions labelled separately from literal source examples.
- Does not inject generic D10 profession menus, remedies, Ashtakavarga scoring, probability percentages or invented event dates.
- When source-specific match is absent, the result is **undetermined**, not "no career" or "no children".

## Source boundaries

Only the three user-provided S.K. Mehta scanned books:
- *New Dimensions in Hindu Astrology*: printed pages 26–28, 87–95, 100–109, 129–160, 170–180, 182–185, 200–217.
- *New Rules and Combinations in Hindu Astrology*: printed pages 118, 138–145 (family-based case examples).
- *Synchronization of Period*: printed pages 12–45 and 121–158 (family, period synchronisation principles).

This module uses D1 positions; it does not reconstruct another relative's birth chart. **Full predictions require further source-specific chart/case and period verification** not present in this panel. Per-user click order is preserved. Nothing here is medical certainty or fate.

## Tests and limits

Added 8 Flutter unit test cases for all 324 combinations, the father's 10th reference, chart-derived aspects/exchanges/strength/weakness, incomplete charts, and the source-specific dignity table. The existing tests are preserved. Static ZIP/files checks are performed separately. **Flutter/Dart compilation and on-device installation must be confirmed in GitHub Actions; it is not claimed here.**
