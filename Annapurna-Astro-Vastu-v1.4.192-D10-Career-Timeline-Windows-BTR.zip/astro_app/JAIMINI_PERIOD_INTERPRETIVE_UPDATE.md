# Jaimini MD/AD interpretive results update
- Re-enabled existing JaiminiCharaDashaService.scoreEvent across all seven event topics in MD and AD views.
- MD view evaluates each AD midpoint and displays best-scoring AD and supporting AD count (threshold 50 is app-defined).
- AD view exposes evidence scores and tap-through rule checks; existing source-audit detail remains.
- Existing app conventions and heuristic IDs are explicitly labeled and never presented as verified primary sutras or event probabilities.
- Original chart calculations, all other app features and assets remain unchanged.
- No Flutter SDK available here; compile, integration and device tests NOT RUN.
- These results are interpretive, not scientific validation or guaranteed event dates.
