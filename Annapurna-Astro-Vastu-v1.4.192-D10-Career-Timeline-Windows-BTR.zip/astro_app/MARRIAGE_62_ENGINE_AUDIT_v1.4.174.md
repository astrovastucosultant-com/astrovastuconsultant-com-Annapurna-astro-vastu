# Siddhanti Mallikarjuna — Marriage Book v1.4.174 Rule Engine Audit

## Project context
- Source: `Marrage rules ok.pdf` (39 scanned pages), one of three sources (88 pages total).
- 62 catalogue items are a **topic index**, not 62 independently validated logical rules.
- Rules shown in the individual D9 screen use the open `AstroChartResult`; matching rules require two separate charts (Saved Charts).
- Every topic now displays chart-specific factor evidence from computed D1/D7/D9/D30 chart placements, or a clear no-chart/no-partner status.
- No blank/no-chart/default observations can be counted as favourable.

## Verified automated matching predicates
- `M-53`, `N-07`: Nadi categories of each natal Moon's nakshatra, using validated shared `MarriagePrintedTableEngine.MM-P04-S07` and the chart-source nadi table on page 37. **Same algorithm displayed at two distinct source-topic locations; not two independent votes**.
- `N-08`: Rajju groups of each natal Moon's nakshatra, `MarriagePrintedTableEngine.MM-P04-S08`. Title corrected from the earlier *Rashi-koota* typo, checked against the Rajju heading/table on page 37.
- `N-06`: exact adverse Vedha pairs from a separate reviewed printed source table (page 3, `MM-P03-S06`); an absent hit gives no automatic positive compatibility verdict. Diagram cross-validation against page 36 remains a follow-up task.
- These are **specific matching subchecks**, not total marriage compatibility decisions or probabilities.

## Partially decoded source
- `M-04`: page 7, rule 04: D9 upachaya houses 3/6/10/11 + separate 10th-house note. Show exact planets in these houses, **no conclusion** until entire combined predicate is validated.

## Not yet automatic
- Other individual/matching source headings, including timing, remedies, divisional chart cross-checks, unspecified exceptions, Jaimini, second marriage, etc. Need full source predicate and test chart validation.
- Remaining index-to-page mappings may be approximate (derived from historic V51 HTML). Each source index must be re-audited before declaring it a computational source rule.
- No automatic event-time or pseudo-confidence percentage is introduced.

## Integration
- `lib/astrology/marriage_book_rule_engine.dart`: typed evaluation status and computed chart placements.
- `lib/screens/marriage_book_topics_screen.dart`: result → source rule → actual chart examination → remedy, source scan page viewer, status filtering and counts.
- `lib/screens/d9_marriage_43_checklist_screen.dart`: passes groom and bride calculated charts into matching book.
- `lib/screens/chart_screen.dart`: passes active chart from matching tab, plus new two-chart entry after partner selection.
- Includes tests in `test/marriage_book_rule_engine_test.dart`.

## Validation boundary
- Text/file/static checks run in artifact environment.
- Actual Flutter/Dart SDK build is **not** run here. GitHub Actions should run `flutter test`, `flutter analyze`, `flutter build apk --release` and report status before APK is considered verified.

## Additional source checks
- `N-01`/`N-02` page 34 were historically mislabeled as Nadi; these are birth dasha/bhukti rules.
- `N-03`/`N-04` page 35 were historically mislabeled as Nadi; these are D7 Mars and auspicious/inauspicious Shashtashtaka sign-pair rules. The D7 Mars subcondition is implemented for **both charts**, recording each R01/R02/R03 evidence; absence of a hit is not a favourable marriage verdict. The pair list now matches the original six adverse pairs, and both Lagna and Moon signs are examined as the source directs.
- `N-05`/`N-06` page 36 are Vedha-related, not Nadi.
- `N-07`/`N-08` page 37 are Nadi/Rajju respectively. `N-09` page 38 is Bhuta.
- `N-03`/`N-04`, `M-53`/`N-07` can duplicate underlying conditions in separate indexes. Never total their hits as independent evidence.
