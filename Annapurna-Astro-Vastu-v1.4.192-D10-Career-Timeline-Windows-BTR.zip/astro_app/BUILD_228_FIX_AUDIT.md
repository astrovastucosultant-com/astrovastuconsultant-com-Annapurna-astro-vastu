# Annapurna Astro Vastu 1.4.173 — Build #228 Dart compile fix

Identified from screenshots of GitHub Actions #228 (21 Oct 2026):

1. `lib/screens/chart_screen.dart` near old line 2933: `_VargaRulePanel` is a `StatelessWidget` with its own `chart` field, so `widget.result` was undefined in that scope. Changed just this occurrence to `chart: chart`.
2. `lib/screens/marriage_reviewed_sources_screen.dart` near old line 151: `DropdownButton<int>` has no named `tooltip` parameter. Moved the accessibility tooltip to an outer `Tooltip(message: ..., child: DropdownButton<int>(...))` wrapper.

Preserved D9 / marriage matching / 88 source page assets and all other application files. Changed only these two Dart source files, `pubspec.yaml` version, and this audit note.

Checks available in the packaging environment: exact patch matches, asset count, archive CRC integrity, and unchanged other sources. Flutter SDK was not installed locally; real `flutter analyze`, `flutter test`, and `flutter build apk --release` must run under GitHub Actions. A passing GitHub build is not yet claimed.
