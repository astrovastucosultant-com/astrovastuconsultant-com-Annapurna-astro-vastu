# Build117 — S.K. Mehta Family Analysis: requested touch order

Changed **only the Mehta Family Analysis UI** and pubspec version number. All underlying Mehta source rules, chart calculations and remaining Flutter modules remain unchanged from Build116.

## UI order
1. Result is visible on the topic card.
2. Tap result: Horoscope Inspection (derived relative/subject house, house lord/placement, aspects, Moon-reference and evidence).
3. Tap “జాతక పరిశీలన → రూల్”: the matched and unmatched Mehta source checks with rule IDs and observations.
4. Tap “రూల్ → మూలగ్రంథం / పరిహారం”: printed source references, timing caveats and only Mehta-sourced remedy status.

The Back arrow reverses the sequence. This is a display-only change; no new deterministic prediction or event year is claimed.

## Verification
Source-level assertions and ZIP CRC checks performed. Flutter compilation / actual mobile tap test needs a successful GitHub Actions build and on-device verification.
