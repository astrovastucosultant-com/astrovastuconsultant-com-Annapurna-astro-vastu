# Western BTR incremental update — not final

Implemented: date-only event representation with three explicitly documented screening times (06:00, 12:00, 18:00) instead of treating an unknown marriage time as exact midnight. Added unit tests. Callers must set `dateOnly: true` when constructing marriage events without a known clock; existing UI does not automatically infer this. Three samples do NOT establish full-day validation and maximum-over-samples can overfit. No Flutter/Dart SDK was available for compilation or test execution.

Still pending: verified full Primary Directions, real natal house-lord event rules, independent historical validation, UI integration of dateOnly, and end-to-end final decision engine. Do not present contact-score as probability.
