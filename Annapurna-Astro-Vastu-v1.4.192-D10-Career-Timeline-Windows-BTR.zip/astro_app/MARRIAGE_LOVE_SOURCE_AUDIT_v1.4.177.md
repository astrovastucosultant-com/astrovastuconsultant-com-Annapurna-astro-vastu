# v1.4.177 — Source-first Marriage M-05–M-10 audit

Original reference: supplied scanned `Marrage rules ok.pdf`.

| Index | PDF page | Original topic | Implementation |
|---|---:|---|---|
| M-05 | 8 | వివాహ యోగము — సూత్రం 05 (రాశి) | Original title corrected; predicate pending |
| M-06 | 8 | వివాహ యోగము — సూత్రం 06 (నవాంశ) | Original title corrected; predicate pending |
| M-07 | 9 | ప్రేమ వ్యవహార యోగము — 07 and 07.1 | D1 and D9 lord/house associations tested |
| M-08 | 10 | ప్రేమ వివాహ యోగము — 08 and 08.1 | D1-lord contacts in D9 and cross D1/D9 lord tests |
| M-09 | 10 | Historical 'intercaste' label unsupported by page 10 | Explicit source-index-pending, not computed |
| M-10 | 10 | Historical 'quick marriage' label unsupported by page 10 | Explicit source-index-pending, not computed |

## Meaning of an evaluated result

M-07/M-08 inspect: same-sign conjunction, classical Parashari aspects (Mars 4/7/8, Jupiter 5/7/9, Saturn 3/7/10; other non-node planets 7), lord-to-house occupation or aspect, lord exchange. All displayed associations are supported by generated D1/D9 planetary signs.

The scanned source says `ఏ విధమైన సంబంధం`. These operational checks may not cover all associations in the original tradition. Consequently **matched** means a tested source subcondition was found, *not* that a love affair or marriage is certain. **Unmatched** does not establish absence of the yoga. Missing required lord placements remains pending.

The pre-existing 62-index screen, 88 offline source pages and GitHub workflow were preserved. One new independent test suite for source pages 9–10 and existing test guard update are included. Flutter SDK is not present in the editing environment; run the GitHub Actions `flutter analyze`, `flutter test` and APK build for compile/integration confirmation.
