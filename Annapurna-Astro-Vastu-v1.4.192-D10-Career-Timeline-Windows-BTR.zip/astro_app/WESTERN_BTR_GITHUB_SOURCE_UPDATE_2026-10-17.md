Western BTR GitHub-source update, 2026-10-17
BASE: repository-embedded Annapurna-Astro-Vastu-v1.4-audited-fixed.zip.
Implemented:
- UI prompts whether event time is known; date-only flag no longer silently lost.
- Known event time is captured via TimePicker, stored in local civil time.
- Event list shows time vs date-only status.
- Candidate ranking prioritizes conservative decision sufficient/matched events before raw heuristic scores.
- Seconds refinement candidates constrained to original BTR search window.
- Decision status visible in seconds candidate list.
NOT COMPLETE: full primary directions, verified house-lord event rules, independent historical validation, calibrated accuracy, Flutter compilation.
DO NOT replace a working production APK without successful Flutter analyze/test/build.
