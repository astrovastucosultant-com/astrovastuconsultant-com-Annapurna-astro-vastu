# Build 168 — D9 vs Marriage Matching (two-chart) integration

## Screens

- **వర్గాలు → D9 → Final Marriage Report:** Existing automatic one-chart D9 marriage report remains intact. The new **D9 వ్యక్తిగత వివాహ నియమాలు — మూల రూల్‌బుక్** button opens only single-chart D9 material entries.
- **వివాహ పొంతన → Saved Charts → 43 వివాహ పొంతన నియమాలు:** The new checklist consumes *both actual calculated* natal charts; no manually-entered lagna, nakshatra, dashas, or Kuja YES/NO. A groom/bride switch is provided inside the checklist.
- Source-only handwritten entries remain fully indexed, but do **not** silently become machine-confirmed results.

## Verifications and corrections

1. The user's snippet mistakenly places Magha in Madhya Nadi and Purva Phalguni in Antya Nadi. The verified printed-engine classification is **Magha: Antya, Purva Phalguni: Madhya**.
2. The pasted Rajju groups duplicate Makha and omit Purva Phalguni; the app reuses the existing complete 27-star Rajju classification from the printed engine.
3. Checklist 04 tests genuine 6/8 relations *between birth-Moon signs* (not a hardcoded bad-pair list); 05 tests 2/12 Moon-sign relations.
4. Checklist 06 Vedha, 07 Nadi, 08 Rajju use the existing named printed material rules with automatic Moon-nakshatra calculation. Missing Vedha **does not** automatically imply favourable verdict, since the source only establishes an adverse hit.
5. Rule 03 cannot be confirmed from `kuja == 'no'` or one D7 Mars dropdown. Underlying D7 source R01–R03 remains separately available; original source definitions and exceptions are required for complete Kuja-dosha assessment.
6. Rule 09 in the pasted code says Ghata while the material source says Bhuta; these are **not** merged as though identical.
7. Checklist 01–03 and 09–43 have no complete, audited IF–THEN conditions in the supplied snippet; display `పెండింగ్` rather than `passed` or `failed`.
8. Registry two-person rows are excluded from one-chart D9 varga rulebook evaluation. Only `requiresTwoCharts` rows are displayed under the two-chart matching source registry.
9. Duplicate source links for explicit 06/07/08 are folded into those checklist items; unrelated ID-number coincidences are not deduplicated.

## Coverage limits

- The `43` represents checklist *slots*, not 43 working IF–THEN algorithms.
- Fully interpreted positive/negative indications today: **04, 05, 07, 08**. Number **06** is evaluated for Vedha but absent source-verified adverse pairs are undecided. Other slots remain pending.
- Nadi/Rajju/6–8/2–12 are individual traditional compatibility indicators, **not** total marriage suitability, a deterministic forecast, or an objective percentage.
- Existing D9 model evidence percentages refer to rule-evidence coverage only.
- Flutter executable compilation and APK build need the Flutter SDK (unavailable in this offline workspace); included source tests must be executed via `flutter test` in GitHub Actions or a Flutter environment.

## Validation test file

`test/marriage_43_rule_engine_test.dart` (43-slot coverage, pending status, 6/8, 2/12, Nadi/Rajju corrections, scope isolation).
