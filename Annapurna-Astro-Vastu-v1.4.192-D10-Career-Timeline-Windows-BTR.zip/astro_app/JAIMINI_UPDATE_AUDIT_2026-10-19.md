# Jaimini update – 2026-10-19

## Changes made
- Preserved all existing Flutter source files and modules.
- Added `lib/astrology/jaimini_rule_audit_registry.dart` as a source-first verification and evidence gate.
- Added `test/jaimini_rule_audit_registry_test.dart` for non-publishable, unverified rule behavior.
- This registry is an independent scaffold; it is NOT yet wired into all existing Jaimini result screens.

## Inspected existing source
- `lib/astrology/jaimini_service.dart` includes seven-karaka ranking, rashi drishti, arudha, and rule-hit structures.
- `lib/astrology/jaimini_chara_dasha_service.dart` includes configurable methods and MD/AD structures.
- `lib/astrology/jaimini_activation_audit.dart` includes chart observation tracing.

## NOT verified / NOT complete
- Full textual source verification for every classical sutra and exception.
- 8-karaka alternative implementation, all method-specific exceptions, comprehensive P1–P12 predictions.
- All event timing and BTR integration and daily prediction matching.
- Full result → rule → observation → remedy UI integration for this new registry.
- Flutter analyze, unit tests, Android APK build: Flutter SDK unavailable in this environment.

Do not describe this archive as a fully completed Jaimini implementation. Existing code has been retained, not exhaustively validated.
