# Jaimini five-level combined dasha and clean interface update

## Applied to Flutter screen
- Chart first, then Chara Dasha/date, followed by a compact expandable five-level explanation.
- Detailed topical results and Arudha P1-P12 collapsed by default to reduce visual clutter.
- Existing chart, MD/AD screens, rule audit and all non-Jaimini modules preserved.

## Five-level rule specification (not yet calculated by UI)
1. MD: active rashi and supported chart evidence.
2. AD: intersection of MD and AD intervals; combined, deduplicated evidence.
3. PD: intersect MD, AD, PD; exact date segmentation depends on locked dasha method.
4. Sukshma: intersect all four periods; requires verified subperiod generator.
5. Prana: intersect all five periods; requires verified subperiod generator.
Transit: sidereal longitude at the selected instant, locked ayanamsha and ephemeris; apply rashi drishti to MD/AD, AK/AmK/DK, AL/UL, not uncalculated guesses. Clearly label transit rules as research-derived unless primary textual source is verified.
Argala: 2 vs 12, 4 vs 10, 11 vs 3, 5 vs 9; count/exception method must be selected and documented.
Age: evaluate selected date (not historical period start) for UI relevance; infant family travel is not adult career travel.
Results: Result → Rule ID & source → natal evidence → timing → BTR → remedy. App support scores are not event probabilities.

## Not implemented by this patch
- Actual PD/Sukshma/Prana calendar and on-tap result computation.
- Actual transit ephemeris integration, live daily outcome computation.
- Build verification: flutter analyze, flutter test and APK build NOT RUN.
