import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/marriage_43_rule_engine.dart';
import 'marriage_reviewed_sources_screen.dart';
import 'marriage_book_topics_screen.dart';
import 'marriage_rule_drill_down.dart';

/// Two-chart compatibility checklist. Called after both saved natal charts
/// have been calculated in Marriage Matching; no manually-entered birth data.
class D9Marriage43ChecklistScreen extends StatefulWidget {
  final AstroChartResult firstChart;
  final AstroChartResult secondChart;
  final String firstName;
  final String secondName;

  const D9Marriage43ChecklistScreen({
    super.key,
    required this.firstChart,
    required this.secondChart,
    required this.firstName,
    required this.secondName,
  });

  @override
  State<D9Marriage43ChecklistScreen> createState() =>
      _D9Marriage43ChecklistScreenState();
}

class _D9Marriage43ChecklistScreenState extends State<D9Marriage43ChecklistScreen> {
  bool firstIsGroom = true;
  bool showPending = true;

  @override
  Widget build(BuildContext context) {
    final groom = firstIsGroom ? widget.firstChart : widget.secondChart;
    final bride = firstIsGroom ? widget.secondChart : widget.firstChart;
    final groomName = firstIsGroom ? widget.firstName : widget.secondName;
    final brideName = firstIsGroom ? widget.secondName : widget.firstName;
    final results = Marriage43RuleEngine.evaluate(groom: groom, bride: bride);
    final checked = results.where((r) => r.evaluated).length;
    final favourable = results.where((r) => r.favourable == true).length;
    final adverse = results.where((r) => r.favourable == false).length;

    return Scaffold(
      appBar: AppBar(title: const Text('వివాహ పొంతన — 43 నియమాలు')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        const Text(ReviewedMarriageSources.reviewer,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        const Text('వరుడు–వధువు జాతకాల స్వయంచాలక పరిశీలన',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Text('వరుడు: $groomName  •  వధువు: $brideName',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('మొదటి జాతకం వరుడిది'),
          subtitle: const Text('వరుడు–వధువు క్రమం మారితే స్విచ్ మార్చండి.'),
          value: firstIsGroom,
          onChanged: (v) => setState(() => firstIsGroom = v),
        ),
        Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('43 నియమాల పరీక్ష స్థితి', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text('మొత్తం: 43 • గణించినవి: $checked • అనుకూల సూచనలు: $favourable • '
                'ప్రతికూల సూచనలు: $adverse • నిర్ణయం లేనివి/పెండింగ్: ${43 - favourable - adverse}'),
            const SizedBox(height: 5),
            const Text('⚠️ Rule 06లో వేధ జంట కనిపించనప్పుడు మూలం అనుకూల తీర్పు ఇవ్వదు. '
                'ఇతర పెండింగ్ నియమాలను Passed/Failedగా లెక్కించము. '
                'ఇది మొత్తం వివాహ అనుకూలత శాతం కాదు.'),
          ],
        ))),
        OutlinedButton.icon(
          onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => const MarriageReviewedSourcesScreen(),
          )),
          icon: const Icon(Icons.auto_stories_outlined),
          label: const Text('ప్రస్తుతం ఇచ్చిన వివాహ నియమాల PDF • 6 పేజీలు'),
        ),
        OutlinedButton.icon(
          onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
            builder: (_) => MarriageBookTopicsScreen(
              scope: MarriageBookTopicScope.matching,
              chart: groom, partnerChart: bride,
            ),
          )),
          icon: const Icon(Icons.menu_book_outlined),
          label: const Text('వివాహ పొంతన PDF — అంశాల వారీ మూల సూత్రాలు'),
        ),
        CheckboxListTile(
          value: showPending,
          onChanged: (v) => setState(() => showPending = v ?? true),
          title: const Text('పరీక్షించని నియమాలు కూడా చూపించండి'),
        ),
        for (final r in results)
          if (showPending || r.evaluated)
            Card(child: ExpansionTile(
              key: ValueKey('rule-${r.number}'),
              leading: Icon(
                !r.evaluated ? Icons.hourglass_empty
                    : r.favourable == true ? Icons.check_circle_outline
                    : r.favourable == false ? Icons.warning_amber_outlined
                    : Icons.info_outline,
                color: !r.evaluated ? Colors.grey
                    : r.favourable == true ? Colors.green.shade700
                    : r.favourable == false ? Colors.deepOrange.shade700
                    : Colors.blueGrey,
              ),
              title: Text('Rule-${r.number.toString().padLeft(2, '0')} — ${r.title}'),
              subtitle: Text(!r.evaluated ? 'పెండింగ్ • పూర్తి సూత్రం అవసరం'
                  : r.favourable == true ? 'అనుకూల సూచన'
                  : r.favourable == false ? 'ప్రతికూల సూచన'
                  : 'పరిశీలించబడింది • మూలం నిర్ణయం ఇవ్వలేదు'),
              childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 14),
              children: [
                MarriageRuleDrillDown(
                  resultText: !r.evaluated
                      ? 'పెండింగ్ — పూర్తి సూత్రం లేదు'
                      : r.favourable == true ? 'అనుకూల సూచన'
                      : r.favourable == false ? 'జాగ్రత్త సూచన'
                      : 'పరిశీలించబడింది; మూలం తుది తీర్పు ఇవ్వలేదు',
                  resultIsComputed: r.evaluated,
                  favourable: r.favourable,
                  ruleText: r.rule,
                  examinationText: r.examination,
                  sourceText: r.source,
                  onOpenSource: null, // Old source pages removed; no false page mapping.
                ),
              ],
            )),
      ]),
    );
  }
}
