import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Complete rulebook from the user-supplied D12.pdf (51 scan pages).
/// This is a source catalog and example browser, NOT a second automatic
/// chart matcher. Chart-matched rules remain in VargaRuleService._d12.
/// KL/Cyclical D12 and example facts are never fabricated from the birth chart.
class D12SourceBookScreen extends StatefulWidget {
  const D12SourceBookScreen({super.key});

  @override
  State<D12SourceBookScreen> createState() => _D12SourceBookScreenState();
}

class _D12SourceBookScreenState extends State<D12SourceBookScreen> {
  late final Future<Map<String, dynamic>> _book = _loadBook();
  String _filter = '';
  String? _section;

  Future<Map<String, dynamic>> _loadBook() async {
    final contents = await rootBundle.loadString('assets/d12/D12_Rules_Examples.json');
    return Map<String, dynamic>.from(jsonDecode(contents) as Map);
  }

  static List<Map<String, dynamic>> _records(dynamic value) =>
      (value as List).map((item) => Map<String, dynamic>.from(item as Map)).toList(growable: false);

  static String _str(dynamic x) => x?.toString() ?? '';
  static List<String> _strings(dynamic x) =>
      (x as List? ?? const []).map((e) => e.toString()).toList(growable: false);

  static String _pages(dynamic value) => _strings(value).join(', ');

  static String? _safeAsset(String page) {
    // Treat source data only as paths under the bundled reference folder.
    if (!RegExp(r'^source_pages/(page_\d{3}|title)\.jpg$').hasMatch(page)) return null;
    return 'assets/d12/$page';
  }

  void _showPage(String page) {
    final asset = _safeAsset(page);
    if (asset == null) return;
    showDialog<void>(
      context: context,
      builder: (dialogContext) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 8, 4, 0),
              child: Row(children: [
                Expanded(child: Text('మూలగ్రంథం — ${page.split('/').last}',
                    style: const TextStyle(fontWeight: FontWeight.w800))),
                IconButton(icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(dialogContext)),
              ]),
            ),
            Expanded(child: InteractiveViewer(
              minScale: 0.8,
              maxScale: 5.0,
              child: Center(child: Image.asset(asset, fit: BoxFit.contain)),
            )),
            const Padding(
              padding: EdgeInsets.all(10),
              child: Text('వివరాలు చూడటానికి రెండు వేళ్లతో Zoom చేయండి.',
                  style: TextStyle(fontSize: 11.5)),
            ),
          ],
        ),
      ),
    );
  }

  void _showRemedy(Map<String, dynamic> rule) {
    final remedy = Map<String, dynamic>.from(rule['remedy'] as Map? ?? const {});
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('పరిహారం — గ్రంథ మూలం'),
        content: SingleChildScrollView(child: Text(
          _str(remedy['text_te']).isNotEmpty
              ? _str(remedy['text_te'])
              : 'ఈ D12 అధ్యాయంలో ఈ నియమానికి ప్రత్యేక పరిహారం ఇవ్వలేదు.',
          style: const TextStyle(height: 1.6),
        )),
        actions: [TextButton(onPressed: () => Navigator.pop(dialogContext),
            child: const Text('మూసివేయండి'))],
      ),
    );
  }

  void _showRule(Map<String, dynamic> rule) {
    // Result → Rule → Remedy: follow the same drill-down expected elsewhere
    // in Annapurna Astro Vastu. Source-only entries never turn green merely
    // because they exist in the uploaded book.
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.78,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
            children: [
              Text('${_str(rule['id'])} — ${_str(rule['title'])}',
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 10),
              const Text('ఫలితం / మూలగ్రంథ వ్యాఖ్యానం',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(_str(rule['then_te']), style: const TextStyle(height: 1.6)),
              const SizedBox(height: 8),
              const Text('ఇది గ్రంథంలోని నియమం. ప్రస్తుత జాతకానికి సరిపోయిందని ఈ పేజీ పేర్కొనదు.',
                  style: TextStyle(color: Color(0xFF695F69), fontSize: 12)),
              const Divider(height: 26),
              ExpansionTile(
                initiallyExpanded: false,
                title: const Text('రూల్ / IF–THEN / మూలపేజీ',
                    style: TextStyle(fontWeight: FontWeight.w800)),
                childrenPadding: const EdgeInsets.fromLTRB(12, 6, 12, 12),
                children: [
                  Align(alignment: Alignment.centerLeft,
                      child: Text(_str(rule['if_te']), style: const TextStyle(height: 1.55))),
                  const SizedBox(height: 6),
                  Align(alignment: Alignment.centerLeft,
                      child: Text('Rule ID: ${_str(rule['id'])}\n'
                          'విభాగం: ${_str(rule['section'])}\n'
                          'మూల పేజీలు: ${_pages(rule['printed_pages'])}\n'
                          'నియమ రకం: ${_str(rule['source_kind'])}',
                          style: const TextStyle(fontSize: 12, height: 1.6))),
                  if (_str(rule['caution']).isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Align(alignment: Alignment.centerLeft,
                        child: Text(_str(rule['caution']),
                            style: const TextStyle(color: Color(0xFF9A5532)))),
                  ],
                  const SizedBox(height: 8),
                  Align(alignment: Alignment.centerLeft,
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.auto_awesome_outlined),
                      onPressed: () => _showRemedy(rule),
                      label: const Text('రూల్ → పరిహార స్థితి'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              const Text('అసలు పేజీలు', style: TextStyle(fontWeight: FontWeight.w800)),
              for (final page in _strings(rule['source_pages']))
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.image_outlined),
                  title: Text(page.split('/').last),
                  trailing: const Icon(Icons.zoom_in),
                  onTap: () => _showPage(page),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
    length: 2,
    child: Scaffold(
      appBar: AppBar(
        title: const Text('D12 — 59 రూల్స్ • 20 ఉదాహరణలు',
            style: TextStyle(fontSize: 17)),
        bottom: const TabBar(
          labelColor: Colors.white,
          unselectedLabelColor: Color(0xFFFFCBD3),
          indicatorColor: Colors.white,
          tabs: [
            Tab(icon: Icon(Icons.rule_folder_outlined), text: '59 నియమాలు'),
            Tab(icon: Icon(Icons.menu_book_outlined), text: '20 ఉదాహరణలు'),
          ],
        ),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _book,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('D12 మూల డేటా తెరవలేకపోయాము: ${snapshot.error}'));
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final rules = _records(snapshot.data!['rules']);
          final examples = _records(snapshot.data!['examples']);
          final sections = _strings(snapshot.data!['sections']);
          final visibleRules = rules.where((r) {
            if (_section != null && r['section'] != _section) return false;
            if (_filter.trim().isEmpty) return true;
            final q = _filter.toLowerCase().trim();
            return '${r['id']} ${r['title']} ${r['if_te']} ${r['then_te']}'
                .toLowerCase().contains(q);
          }).toList(growable: false);
          return Column(children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(12, 10, 12, 4),
              child: Text('మూలం: D12.pdf • Saral Jyotish Part VII • Chapter 9 • 51 scan pages. '
                  '59 నియమాలు, 20 చారిత్రక ఉదాహరణలు, 97 వివరణలు. '
                  'ఉదాహరణలను జన్మచక్రంపై స్వయంచాలక ఫలితంగా అమలు చేయలేదు; KL/Cyclical D12 విధానం నిర్ధారణ పెండింగ్.',
                  style: TextStyle(fontSize: 12, height: 1.4)),
            ),
            Expanded(child: TabBarView(children: [
              Column(children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
                  child: TextField(
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: 'Rule ID / తెలుగు అంశం వెతకండి',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: (q) => setState(() => _filter = q),
                  ),
                ),
                SizedBox(
                  height: 50,
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    scrollDirection: Axis.horizontal,
                    children: [
                      _sectionChip('అన్నీ', null),
                      for (final s in sections) _sectionChip(s, s),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
                  child: Align(alignment: Alignment.centerLeft,
                    child: Text('${visibleRules.length} / ${rules.length} నియమాలు • టచ్ → ఫలితం → రూల్ → పరిహారం',
                        style: const TextStyle(fontSize: 12))),
                ),
                Expanded(child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(8, 0, 8, 14),
                  itemCount: visibleRules.length,
                  itemBuilder: (context, i) {
                    final r = visibleRules[i];
                    return Card(
                      child: ListTile(
                        isThreeLine: true,
                        leading: const Icon(Icons.menu_book_outlined, color: Color(0xFF6B5B5E)),
                        title: Text('${r['id']} — ${r['title']}',
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text('${r['then_te']}\nపేజీ: ${_pages(r['printed_pages'])}',
                            style: const TextStyle(height: 1.4)),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => _showRule(r),
                      ),
                    );
                  },
                )),
              ]),
              ListView.builder(
                padding: const EdgeInsets.fromLTRB(8, 4, 8, 20),
                itemCount: examples.length,
                itemBuilder: (context, i) {
                  final ex = examples[i];
                  final notes = _strings(ex['observations_te']);
                  final matchedIds = _strings(ex['expected_rule_ids']);
                  return Card(child: ExpansionTile(
                    title: Text('${i+1}. ${_str(ex['name'])}',
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('ఉదాహరణ ID: ${ex['id']} • పేజీలు ${_pages(ex['printed_pages'])}\n'
                        '${_str(ex['birth'])}\n${notes.length} గ్రంథ వ్యాఖ్యానాలు',
                        style: const TextStyle(height: 1.4)),
                    childrenPadding: const EdgeInsets.fromLTRB(14, 4, 14, 14),
                    children: [
                      for (var n=0; n<notes.length; n++)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Align(alignment: Alignment.centerLeft,
                            child: Text('${n+1}. ${notes[n]}',
                                style: const TextStyle(height: 1.55))),
                        ),
                      const Divider(),
                      const Align(alignment: Alignment.centerLeft,
                        child: Text('ఈ కేస్‌లో పరీక్షించిన IF–THEN రూల్స్',
                            style: TextStyle(fontWeight: FontWeight.w800))),
                      for (final id in matchedIds)
                        ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(id),
                          trailing: const Text('రూల్ చూడండి'),
                          onTap: () {
                            final candidates = rules.where((r) => r['id'] == id);
                            if (candidates.isNotEmpty) _showRule(candidates.first);
                          },
                        ),
                      const Align(alignment: Alignment.centerLeft,
                        child: Text('అసలు జాతక చక్రాల పేజీలు',
                            style: TextStyle(fontWeight: FontWeight.w800))),
                      Wrap(spacing: 8, children: [
                        for (final page in _strings(ex['source_pages']))
                          TextButton.icon(
                            onPressed: () => _showPage(page),
                            icon: const Icon(Icons.image_outlined),
                            label: Text(page.split('/').last),
                          ),
                      ]),
                      const Text('ఈ గ్రంథంలోని ఉదాహరణ విశ్లేషణ మాత్రమే; '
                          'జనన వివరాల ఆధారంగా కొత్తగా D12/KL/Cyclical చక్రాలను మళ్లీ లెక్కించలేదు.',
                          style: TextStyle(fontSize: 12, color: Color(0xFF6E6262), height: 1.5)),
                    ],
                  ));
                },
              ),
            ])),
          ]);
        },
      ),
    ),
  );

  Widget _sectionChip(String name, String? value) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 3),
    child: ChoiceChip(
      label: Text(name),
      selected: _section == value,
      onSelected: (_) => setState(() => _section = value),
    ),
  );
}
