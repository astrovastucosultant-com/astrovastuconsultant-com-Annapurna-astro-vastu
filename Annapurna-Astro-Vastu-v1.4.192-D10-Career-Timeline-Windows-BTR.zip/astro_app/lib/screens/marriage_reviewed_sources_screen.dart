import 'package:flutter/material.dart';
import 'marriage_chrome_checklist_screen.dart';

/// Current, sole embedded marriage-rule source. The former 88 scanned pages
/// are intentionally absent from the ZIP and Flutter asset manifest.
class ReviewedMarriageSources {
  static const reviewer = 'సిద్ధాంతి మల్లికార్జున పరిశీలించిన నియమాలు';
  static const chrome = 'chrome';
  // Legacy IDs kept for compatibility with old call sites; they never map to
  // the new PDF page numbers or nonexistent asset paths.
  static const handwritten = 'handwritten';
  static const marriageRules = 'marriage_rules';
  static const marriage2 = 'marriage_2';
  static const Map<String,String> names = {
    chrome: 'Annapurna_Marriage_Rules_Chrome.pdf',
  };
  static const Map<String,int> pageCounts = {chrome: 6};
  static String assetPath(String sourceId,int page) {
    if (sourceId != chrome) {
      throw ArgumentError.value(sourceId,'sourceId','పాత 88 మూల పేజీలు తొలగించబడ్డాయి');
    }
    if(page < 1 || page > 6) throw RangeError.range(page,1,6,'page');
    return 'assets/marriage_chrome/page_${page.toString().padLeft(2,'0')}.webp';
  }
  static void openPage(BuildContext context,String sourceId,int page) {
    if(sourceId != chrome) {
      // Do not misrepresent a page from a retired PDF as a page of the new one.
      Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => const MarriageReviewedSourcesScreen()));
      return;
    }
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => MarriageReviewedSourcePageScreen(
        sourceId: chrome, initialPage: page)));
  }
}

class MarriageReviewedSourcesScreen extends StatelessWidget {
  const MarriageReviewedSourcesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('వివాహ నియమాల PDF • 6 పేజీలు')),
    body: ListView(padding: const EdgeInsets.all(12),children: [
      const Card(child: Padding(padding: EdgeInsets.all(14),child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,children:[
          Text(ReviewedMarriageSources.reviewer,
            style: TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
          SizedBox(height:8),
          Text('ప్రస్తుతం ఇచ్చిన Annapurna_Marriage_Rules_Chrome.pdf మాత్రమే: '
            '6 పేజీలు • 18 విభాగాలు • 43 IF–THEN నియమాలు.'),
          SizedBox(height:6),
          Text('పాత మూడు గ్రంథాల 88 పేజీలను యాప్ నుంచి తొలగించాము.'),
        ],
      ))),
      Card(child: ListTile(
        leading: const Icon(Icons.fact_check_outlined),
        title: const Text('43 IF–THEN నియమాల చెక్‌లిస్ట్'),
        subtitle: const Text('ఫలితం టచ్ → జాతక పరిశీలన → అసలు రూల్'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => const MarriageChromeChecklistScreen())),
      )),
      Card(child: ListTile(
        leading: const Icon(Icons.auto_stories_outlined),
        title: const Text('ప్రస్తుత 6 మూల PDF పేజీలు'),
        subtitle: const Text('పేజీకి వెళ్లి రెండు వేళ్లతో జూమ్ చేయండి'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => ReviewedMarriageSources.openPage(
          context,ReviewedMarriageSources.chrome,1),
      )),
    ]),
  );
}

class MarriageReviewedSourcePageScreen extends StatefulWidget {
  final String sourceId;
  final int initialPage;
  const MarriageReviewedSourcePageScreen({super.key,required this.sourceId,
    this.initialPage=1});
  @override
  State<MarriageReviewedSourcePageScreen> createState()=>_MarriageReviewedSourcePageScreenState();
}
class _MarriageReviewedSourcePageScreenState extends State<MarriageReviewedSourcePageScreen> {
  late final PageController controller;
  late int currentPage;
  @override
  void initState(){super.initState();
    currentPage=widget.initialPage.clamp(1,6).toInt();
    controller=PageController(initialPage:currentPage-1);
  }
  @override
  void dispose(){controller.dispose();super.dispose();}
  void goTo(int page){if(page<1 || page>6)return;
    controller.jumpToPage(page-1);setState(()=>currentPage=page);
  }
  @override
  Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('వివాహ నియమాలు • మూల PDF')),
    body:SafeArea(child:Column(children:[
      Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[
        IconButton(tooltip:'మునుపటి పేజీ',icon:const Icon(Icons.chevron_left),
          onPressed:currentPage==1?null:()=>goTo(currentPage-1)),
        DropdownButton<int>(value:currentPage,
          items:List.generate(6,(i)=>DropdownMenuItem<int>(value:i+1,
            child:Text('పేజీ ${i+1} / 6'))),
          onChanged:(v){if(v!=null)goTo(v);}),
        IconButton(tooltip:'తరువాతి పేజీ',icon:const Icon(Icons.chevron_right),
          onPressed:currentPage==6?null:()=>goTo(currentPage+1)),
      ]),
      const Text('రెండు వేళ్లతో జూమ్ చేయండి',style:TextStyle(fontSize:12)),
      Expanded(child:PageView.builder(
        controller:controller,itemCount:6,
        onPageChanged:(i)=>setState(()=>currentPage=i+1),
        itemBuilder:(context,i)=>InteractiveViewer(minScale:0.7,maxScale:6,
          child:Center(child:Image.asset(
            ReviewedMarriageSources.assetPath(ReviewedMarriageSources.chrome,i+1),
            fit:BoxFit.contain))),
      )),
    ])),
  );
}
