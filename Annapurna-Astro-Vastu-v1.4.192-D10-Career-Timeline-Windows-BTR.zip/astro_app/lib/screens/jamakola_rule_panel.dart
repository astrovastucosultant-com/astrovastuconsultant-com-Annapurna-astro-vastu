import 'package:flutter/material.dart';
import '../astrology/jamakola_rule_engine.dart';

class JamakolaRulePanel extends StatefulWidget {
  const JamakolaRulePanel({super.key});
  @override
  State<JamakolaRulePanel> createState() => _JamakolaRulePanelState();
}
class _JamakolaRulePanelState extends State<JamakolaRulePanel> {
  late final Future<List<JamakolaRule>> _rules = JamakolaRuleEngine.load();
  int? udhayam, arudam, kavipu;
  String? approaching, saturn, gowri;
  String module = 'all';
  static const signs = ['మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య','తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం'];
  static const planets = {'Sun':'రవి','Moon':'చంద్రుడు','Mars':'కుజుడు','Mercury':'బుధుడు','Jupiter':'గురువు','Venus':'శుక్రుడు','Saturn':'శని','Rahu':'రాహువు'};
  static const periods = {'Uthiyogam':'ఉద్యోగం','Amirtham':'అమృతం','Rogam':'రోగం','Laabam':'లాభం','Dhanam':'ధనం','Shubam':'శుభం','Choram':'చోరం','Visham':'విషం'};
  static const modules = {'all':'అన్ని నియమాలు','question_subject':'ప్రశ్న విషయం','obstruction':'అడ్డంకులు','education':'విద్య','marriage':'వివాహం','career_business':'ఉద్యోగం / వ్యాపారం','childbirth':'సంతానం','gowri':'గౌరీ కాలం'};
  Widget _choice<T>(String title, T? value, Map<T,String> options, ValueChanged<T?> change) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: DropdownButtonFormField<T>(value: value, isExpanded: true,
      decoration: InputDecoration(labelText:title, border:const OutlineInputBorder()),
      items: options.entries.map((e)=>DropdownMenuItem<T>(value:e.key,child:Text(e.value))).toList(),
      onChanged:change),
  );
  @override
  Widget build(BuildContext context) {
    final signMap = {for(var i=0;i<12;i++) i: signs[i]};
    final facts = <String,dynamic>{};
    if(approaching!=null) facts['approaching_udhayam']=approaching;
    final ah=JamakolaRuleEngine.houseFromSigns(udhayam,arudam);
    final kh=JamakolaRuleEngine.houseFromSigns(udhayam,kavipu);
    if(ah!=null) facts['arudam_house_from_udhayam']=ah;
    if(kh!=null) facts['kavipu_house_from_udhayam']=kh;
    if(saturn!=null) facts['saturn_dignity']=saturn;
    if(gowri!=null) facts['gowri_period']=gowri;
    return FutureBuilder<List<JamakolaRule>>(future:_rules,builder:(context,snapshot){
      if(snapshot.hasError) return Text('నియమాల ఫైల్ తెరవడంలో సమస్య: ${snapshot.error}');
      if(!snapshot.hasData) return const Center(child:CircularProgressIndicator());
      final rules=snapshot.data!;
      final selected=rules.where((r)=>module=='all'||r.module==module).toList();
      final matches=selected.where((r)=>JamakolaRuleEngine.matches(r,facts)).toList();
      final nonmatches=selected.where((r)=>!JamakolaRuleEngine.matches(r,facts)).toList();
      return ListView(padding:const EdgeInsets.all(14),children:[
        Text('జామకోళ ఆరూఢం — ${rules.length} మూల నియమాలు',style:Theme.of(context).textTheme.titleLarge),
        const SizedBox(height:8),
        const Text('జామకోళ ప్రశ్న చక్రంలోని ఉదయం, ఆరూఢం, కవిప్పు స్థానాలను నమోదు చేయండి. ఇవి జనన D1 లగ్నానికి ప్రత్యామ్నాయం కావు.'),
        const SizedBox(height:12),
        _choice('ఉదయం రాశి',udhayam,signMap,(v)=>setState(()=>udhayam=v)),
        _choice('ఆరూఢం రాశి',arudam,signMap,(v)=>setState(()=>arudam=v)),
        _choice('కవిప్పు రాశి',kavipu,signMap,(v)=>setState(()=>kavipu=v)),
        _choice('ఉదయాన్ని సమీపిస్తున్న గ్రహం',approaching,planets,(v)=>setState(()=>approaching=v)),
        _choice('శని స్థితి',saturn,const {'exalted':'ఉచ్చ','debilitated':'నీచ'},(v)=>setState(()=>saturn=v)),
        _choice('గౌరీ కాలం',gowri,periods,(v)=>setState(()=>gowri=v)),
        _choice('నియమాల విభాగం',module,modules,(v)=>setState(()=>module=v??'all')),
        const SizedBox(height:8),
        Text('వర్తించినవి: ${matches.length}   |   వర్తించనివి: ${nonmatches.length}',style:Theme.of(context).textTheme.titleMedium),
        const SizedBox(height:8),
        for(final r in matches) Card(child:ListTile(leading:const Icon(Icons.check_circle,color:Colors.green),title:Text(r.result),subtitle:Text('${r.id} • ${modules[r.module] ?? r.module}'),onTap:()=>showDialog<void>(context:context,builder:(ctx)=>AlertDialog(title:Text(r.id),content:SingleChildScrollView(child:Text('ఫలితం: ${r.result}\n\nనియమం: ${r.conditions}\n\nజాతక/ప్రశ్న ఆధారం: ${r.conditions.entries.map((e)=>'${e.key} = ${facts[e.key]}').join(', ')}\n\nమూలం: ${r.sourceFile}, పేజీలు ${r.sourcePage}')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('మూసివేయి'))])))),
        if(matches.isEmpty) const Padding(padding:EdgeInsets.all(12),child:Text('ఇచ్చిన స్థానాలకు వర్తించిన నియమాలు లేవు.')),
        ExpansionTile(title:Text('వర్తించలేదు (${nonmatches.length})'),children:[for(final r in nonmatches) ListTile(title:Text(r.id),subtitle:Text(r.result),trailing:const Text('వర్తించలేదు'))]),
        const SizedBox(height:14),
        const Text('గమనిక: ఈ starterలోని కొన్ని కవిప్పు నియమాలు సాధారణ అడ్డంకి సూచనలు మాత్రమే. ప్రశ్న చక్రం స్వయంచాలక ఖగోళ గణన, సంఘటన సమయ నిర్ధారణ ఈ అప్‌డేట్‌లో లేవు.'),
      ]);
    });
  }
}
