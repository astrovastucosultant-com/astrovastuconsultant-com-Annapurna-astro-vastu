import 'package:flutter/material.dart';

/// Consistent mandated navigation: ఫలితం → రూల్ → జాతక పరిశీలన → పరిహారం.
/// `resultIsComputed` controls whether a green result can ever be rendered.
class MarriageRuleDrillDown extends StatelessWidget {
  final String resultText;
  final String ruleText;
  final String examinationText;
  final String sourceText;
  final bool resultIsComputed;
  final bool? favourable;
  final VoidCallback? onOpenSource;
  final String remedyText;

  const MarriageRuleDrillDown({
    super.key,
    required this.resultText,
    required this.ruleText,
    required this.examinationText,
    required this.sourceText,
    this.resultIsComputed = false,
    this.favourable,
    this.onOpenSource,
    this.remedyText = 'మూలంలో స్పష్టంగా నిర్ధారించిన పరిహారం ఉంటేనే ఇక్కడ చూపిస్తాం.',
  });

  @override
  Widget build(BuildContext context) {
    final color = !resultIsComputed || favourable == null
        ? Colors.blueGrey
        : favourable! ? Colors.green.shade700 : Colors.deepOrange.shade700;
    return ExpansionTile(
      leading: Icon(!resultIsComputed ? Icons.pending_actions_outlined
          : favourable == true ? Icons.check_circle_outline
          : favourable == false ? Icons.warning_amber_outlined : Icons.info_outline,
          color: color),
      title: const Text('ఫలితం', style: TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(resultText, style: TextStyle(color: color)),
      childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      children: [
        ExpansionTile(
          title: const Text('రూల్ — మూల నియమం'),
          childrenPadding: const EdgeInsets.all(8),
          children: [
            Align(alignment: Alignment.centerLeft, child: Text(ruleText)),
            const SizedBox(height: 6),
            Align(alignment: Alignment.centerLeft,
                child: Text('మూలం: $sourceText', style: const TextStyle(fontSize: 12))),
            if (onOpenSource != null)
              Align(alignment: Alignment.centerLeft, child: TextButton.icon(
                onPressed: onOpenSource,
                icon: const Icon(Icons.zoom_in),
                label: const Text('అసలు మూల పేజీ చూడండి'),
              )),
            ExpansionTile(
              title: const Text('జాతక పరిశీలన'),
              childrenPadding: const EdgeInsets.all(8),
              children: [
                Align(alignment: Alignment.centerLeft,
                    child: Text(examinationText, style: const TextStyle(height: 1.5))),
                ExpansionTile(
                  title: const Text('పరిహారం'),
                  childrenPadding: const EdgeInsets.all(8),
                  children: [
                    Align(alignment: Alignment.centerLeft, child: Text(remedyText)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }
}
