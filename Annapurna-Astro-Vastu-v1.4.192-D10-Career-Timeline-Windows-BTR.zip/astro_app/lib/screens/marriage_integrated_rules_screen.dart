import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import 'marriage_chrome_checklist_screen.dart';

/// Compatibility route for older integrated marriage catalog menus. All user
/// visible rules now come from the latest 6-page Chrome PDF, not retired books.
class MarriageIntegratedRulesScreen extends StatelessWidget {
  final AstroChartResult? chart;
  const MarriageIntegratedRulesScreen({super.key, this.chart});
  @override
  Widget build(BuildContext context) => MarriageChromeChecklistScreen(chart: chart);
}
