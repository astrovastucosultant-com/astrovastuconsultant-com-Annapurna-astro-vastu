import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/shapa_match_engine.dart';
import 'kalasarpa_overview.dart';

/// First-page Panchangam section, placed immediately after Karana.
/// Result -> rule -> chart evidence -> source remedy.
class ShapaOverview extends StatelessWidget {
  final AstroChartResult chart;
  const ShapaOverview({super.key,required this.chart});

  @override
  Widget build(BuildContext context) {
    final all=ShapaMatchEngine.evaluate(chart);
    final matched=all.where((a)=>a.matched==true).toList();
    final pending=all.where((a)=>a.matched==null).toList();
    return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('శాపాలు',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        ExpansionTile(
          key:const PageStorageKey('serpent-shapa'),
          title:const Text('సర్ప శాపాలు',style:TextStyle(fontWeight:FontWeight.bold)),
          subtitle:const Text('టచ్ చేస్తే రాహు–కేతు, సప్తగ్రహాల పరిశీలన'),
          children:[KalasarpaOverview(chart:chart)],
        ),
        const SizedBox(height:6),
        const Text('సంప్రదాయ జ్యోతిష్య సూచనలు మాత్రమే. శాపం ఉన్నట్లు నిర్ధారణ కాదు.'),
        const Text('ఫలితం → నియమం → జాతక పరిశీలన → పరిహారం',
          style:TextStyle(fontWeight:FontWeight.w500)),
        const SizedBox(height:8),
        Text('వర్తించిన సూచనలు: ${matched.length} • పరిశీలన పెండింగ్: ${pending.length}',
          style:const TextStyle(fontWeight:FontWeight.bold)),
        if(matched.isEmpty) Padding(padding:const EdgeInsets.all(8),
          child:Text(pending.isNotEmpty && pending.length==all.length
            ? 'జాతక గణన వివరాలు అసంపూర్ణం — పరిశీలన పెండింగ్.'
            : 'పరీక్షించిన నియమాల్లో సరిపోలిక లేదు; పెండింగ్ నియమాలు విడిగా ఉన్నాయి.')),
        for(final a in matched) ExpansionTile(
          key:PageStorageKey('shapa-${a.rule.id}'),
          title:Text(a.rule.title),
          subtitle:Text('సరిపోలిన జ్యోతిష్య సూచన • ${a.rule.id}'),
          children:[
            ExpansionTile(title:const Text('1. నియమం / Rule ID'),children:[
              Padding(padding:const EdgeInsets.all(10),child:Text(
                '${a.rule.id} • ${a.rule.source} • పేజీ ${a.rule.page}\n${a.rule.condition}')),
              ExpansionTile(title:const Text('2. జాతక పరిశీలన / Evidence'),children:[
                Padding(padding:const EdgeInsets.all(10),child:Column(
                  crossAxisAlignment:CrossAxisAlignment.start,children:[
                    for(final evidence in a.evidence) Padding(
                      padding:const EdgeInsets.only(bottom:6),child:Text('• $evidence')),
                    if(a.note.isNotEmpty)Text('గణన గమనిక: ${a.note}'),
                  ])),
                ExpansionTile(title:const Text('3. పరిహారం / Remedy'),children:[
                  Padding(padding:const EdgeInsets.all(10),child:Text(
                    '${a.rule.remedy}\n\nమూలం: ${a.rule.source}, పేజీ ${a.rule.page}. '
                    'Williams/remidi.pdfలో ఈ నియమానికి నిర్దిష్ట అనుసంధానం ధృవీకరణ పెండింగ్. '
                    'పరిహారాలు సంప్రదాయ సూచనలు మాత్రమే; ఖర్చుతో కూడిన కార్యక్రమాలు తప్పనిసరి కాదు.')),
                ]),
              ]),
            ]),
          ],
        ),
        ExpansionTile(title:Text('Rule Audit — సరిపోలనివి ${all.where((a)=>a.matched==false).length} / పెండింగ్ ${pending.length}'),children:[
          for(final a in all.where((a)=>a.matched!=true))
            ListTile(title:Text('${a.rule.id} • ${a.rule.title}'),
              subtitle:Text(a.matched==null?'పరిశీలన పెండింగ్: ${a.note}':
                'ఈ జాతకంలో అమలు చేసిన షరతులకు సరిపోలిక లేదు.')),
        ]),
      ])));
  }
}
