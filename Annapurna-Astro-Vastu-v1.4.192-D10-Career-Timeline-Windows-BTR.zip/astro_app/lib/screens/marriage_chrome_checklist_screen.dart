import 'package:flutter/material.dart';

import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/marriage_chrome_if_then_engine.dart';
import '../services/annapurna_prefs.dart';
import '../services/chart_storage_service.dart';

/// PDF source: Annapurna_Marriage_Rules_Chrome.pdf, all 6 pages.
/// Checklist manual review is separate from computed astrological status.
/// This is a module inside the existing app: no duplicate main()/MaterialApp.
class MarriageChromeChecklistScreen extends StatefulWidget {
  final AstroChartResult? chart;
  final String? gender;
  const MarriageChromeChecklistScreen({super.key,this.chart,this.gender});
  @override
  State<MarriageChromeChecklistScreen> createState()=>_MarriageChromeChecklistScreenState();
}

class _MarriageChromeChecklistScreenState extends State<MarriageChromeChecklistScreen> {
  late final Future<List<SavedChart>> _saved=ChartStorageService.load();
  AstroChartResult? _calculated;
  String? _selectedId;
  String? _selectedGender;
  String? _error;
  bool _busy=false;
  final Set<String> _reviewed={};
  String _filter='all';

  AstroChartResult? get _activeChart => _selectedId==null?widget.chart:_calculated;
  String? get _activeGender => _selectedId==null?widget.gender:_selectedGender;
  String get _reviewKey => 'annapurna_chrome_check_v179_'
      '${_selectedId??_activeChart?.julianDay.toStringAsFixed(6)??'no_chart'}';

  @override
  void initState(){
    super.initState();
    _readChecklist();
  }
  Future<void> _readChecklist() async {
    try {
      final saved=await AnnapurnaPrefs.instance.getStringList(_reviewKey);
      if(!mounted)return;
      setState((){_reviewed..clear()..addAll(saved??const <String>[]);});
    }catch(_){ /* Checklist remains usable without persistent storage. */ }
  }
  Future<void> _markReviewed(String id,bool value) async {
    setState(() {if(value){_reviewed.add(id);}else{_reviewed.remove(id);}});
    try{await AnnapurnaPrefs.instance.setStringList(_reviewKey,_reviewed.toList()..sort());}
    catch(_){if(mounted) ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content:Text('చెక్‌లిస్ట్ సేవ్ కాలేదు; మళ్లీ ప్రయత్నించండి.')));}
  }
  Future<void> _choose(String? id,List<SavedChart> saved) async {
    if(id==null){
      setState((){_selectedId=null;_selectedGender=null;_calculated=null;_busy=false;_error=null;_reviewed.clear();});
      await _readChecklist();return;
    }
    SavedChart? item;
    for(final chart in saved){if(chart.id==id){item=chart;break;}}
    if(item==null)return;
    setState((){
      _selectedId=id;_selectedGender=item!.birthData.gender.name;
      _calculated=null;_busy=true;_error=null;_reviewed.clear();
    });
    await _readChecklist();
    try{
      final result=await AstroCalculationService.calculate(item.birthData);
      if(!mounted||_selectedId!=id)return;
      setState((){_calculated=result;_busy=false;});
    }catch(e){
      if(!mounted||_selectedId!=id)return;
      setState((){_busy=false;_error='జాతక గణన విఫలమైంది: $e';});
    }
  }

  void _showSource(int page){
    showDialog<void>(context:context,builder:(context)=>Dialog(
      insetPadding:const EdgeInsets.all(12),
      child:Column(children:[
        ListTile(title:Text('మూల PDF — పేజీ $page'),
          trailing:IconButton(icon:const Icon(Icons.close),onPressed:()=>Navigator.pop(context))),
        Expanded(child:InteractiveViewer(minScale:0.7,maxScale:5,
          child:Center(child:Image.asset(
            'assets/marriage_chrome/page_${page.toString().padLeft(2,'0')}.webp',
            fit:BoxFit.contain,
          )),
        )),
      ]),
    ));
  }

  Widget _resultCard(MarriageChromeRule rule,MarriageChromeEvaluation evaluation){
    final computed=evaluation.isComputed;
    final color=!computed?Colors.blueGrey:evaluation.matches?Colors.green.shade700:Colors.deepOrange.shade700;
    final reviewed=_reviewed.contains(rule.id);
    return Card(
      key:ValueKey(rule.id),
      child:Column(children:[
        ExpansionTile(
          leading:Icon(!computed?Icons.pending_actions_outlined:
              evaluation.matches?Icons.check_circle_outline:Icons.remove_circle_outline,color:color),
          title:Text('${rule.id} — ${rule.thenText}',
              style:const TextStyle(fontSize:14,fontWeight:FontWeight.w600)),
          subtitle:Text('ఫలితం: ${evaluation.result} • మూల పుట ${rule.page}',
              style:TextStyle(color:color,fontSize:12)),
          childrenPadding:const EdgeInsets.fromLTRB(14,4,14,12),
          children:[
            const Align(alignment:Alignment.centerLeft,
              child:Text('జాతక పరిశీలన',style:TextStyle(fontWeight:FontWeight.bold))),
            const SizedBox(height:5),
            Align(alignment:Alignment.centerLeft,child:SelectableText(evaluation.examination)),
            const Divider(height:24),
            const Align(alignment:Alignment.centerLeft,
              child:Text('మూల IF–THEN రూల్',style:TextStyle(fontWeight:FontWeight.bold))),
            const SizedBox(height:5),
            Align(alignment:Alignment.centerLeft,child:SelectableText(
                'IF ${rule.ifText}\nTHEN ${rule.thenText}')),
            const SizedBox(height:8),
            Align(alignment:Alignment.centerLeft,child:TextButton.icon(
              icon:const Icon(Icons.menu_book_outlined),
              label:Text('అసలు పేజీ ${rule.page} చూడండి'),
              onPressed:()=>_showSource(rule.page),
            )),
            const Align(alignment:Alignment.centerLeft,
              child:Text('పరిహారం: ఈ PDFలో ఈ సూత్రానికి నిర్దిష్ట పరిహారం ఇవ్వలేదు.',
                style:TextStyle(fontSize:12))),
          ],
        ),
        const Divider(height:1),
        CheckboxListTile(
          dense:true,controlAffinity:ListTileControlAffinity.leading,
          title:const Text('జాతక పరిశీలనను నేను ధృవీకరించాను',style:TextStyle(fontSize:12)),
          subtitle:const Text('ఈ టిక్ ఆటోమేటిక్ YES/NO ఫలితాన్ని మార్చదు.',style:TextStyle(fontSize:11)),
          value:reviewed,
          onChanged:(v)=>_markReviewed(rule.id,v??false),
        ),
      ]),
    );
  }

  @override
  Widget build(BuildContext context){
    final chart=_activeChart;
    final evaluations={for(final r in MarriageChromeIfThenEngine.rules)
      r.id:MarriageChromeIfThenEngine.evaluate(r,chart,gender:_activeGender)};
    final met=evaluations.values.where((e)=>e.status==MarriageChromeStatus.matched).length;
    final notMet=evaluations.values.where((e)=>e.status==MarriageChromeStatus.notMatched).length;
    final pending=43-met-notMet;
    final sectionRules=<int,List<MarriageChromeRule>>{};
    for(final r in MarriageChromeIfThenEngine.rules){
      final e=evaluations[r.id]!;
      if(_filter=='met'&&e.status!=MarriageChromeStatus.matched)continue;
      if(_filter=='pending'&&e.isComputed)continue;
      if(_filter=='reviewed'&&!_reviewed.contains(r.id))continue;
      (sectionRules[r.section]??=<MarriageChromeRule>[]).add(r);
    }
    return Scaffold(
      appBar:AppBar(title:const Text('D9 — IF–THEN 43 రూల్స్ చెక్‌లిస్ట్')),
      body:ListView(padding:const EdgeInsets.all(12),children:[
        Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('సిద్ధాంతి మల్లికార్జున పరిశీలించిన నియమాలు',
              style:TextStyle(fontWeight:FontWeight.bold)),
            const SizedBox(height:5),
            const Text('మూలం: Annapurna_Marriage_Rules_Chrome.pdf • 6 పేజీలు • '
              '18 విభాగాలు • 43 IF–THEN సూత్రాలు.'),
            const SizedBox(height:8),
            Text('నిర్దిష్ట షరతు సరిపోయింది: $met • సరిపోలలేదు: $notMet • '
              'మరింత పరిశీలన: $pending • మీరు టిక్ చేసినవి: ${_reviewed.length}/43',
              style:const TextStyle(fontWeight:FontWeight.w700)),
            const SizedBox(height:8),
            const Text('ఇవి గ్రంథంలోని జ్యోతిష ఉపషరతుల ఫలితాలు మాత్రమే. '
              'ఒక యోగం వర్తించడం వల్ల వ్యక్తి ప్రవర్తన, వివాహాల సంఖ్య, '
              'విడాకులు, ఆరోగ్యం లేదా సంఘటన తేదీ ఖచ్చితంగా నిర్ధారణ కావు.',
              style:TextStyle(fontSize:12)),
          ],
        ))),
        Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
          crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            const Text('Saved Chart ఎంచుకోండి',style:TextStyle(fontWeight:FontWeight.bold)),
            const SizedBox(height:8),
            FutureBuilder<List<SavedChart>>(future:_saved,builder:(context,snapshot){
              if(snapshot.connectionState!=ConnectionState.done){
                return const LinearProgressIndicator();
              }
              if(snapshot.hasError)return const Text('Saved Charts తెరవలేకపోయాం.');
              final saved=snapshot.data??const <SavedChart>[];
              return DropdownButtonFormField<String>(
                key:ValueKey('chrome-${_selectedId??'active'}'),
                value:_selectedId,isExpanded:true,
                decoration:const InputDecoration(border:OutlineInputBorder(),isDense:true),
                hint:Text(widget.chart==null?'సేవ్ చేసిన జాతకం ఎంచుకోండి':'ప్రస్తుత జాతకం / సేవ్ చేసిన జాతకం'),
                items:[
                  if(widget.chart!=null)const DropdownMenuItem<String>(
                    value:null,child:Text('ప్రస్తుతం తెరిచిన జాతకం')),
                  for(final s in saved)DropdownMenuItem<String>(
                    value:s.id,child:Text(s.birthData.name,overflow:TextOverflow.ellipsis)),
                ],
                onChanged:_busy?null:(v)=>_choose(v,saved),
              );
            }),
            if(_busy)const LinearProgressIndicator(),
            if(_error!=null)Text(_error!,style:const TextStyle(color:Colors.red)),
            if(chart==null&&!_busy)const Padding(
              padding:EdgeInsets.only(top:8),
              child:Text('జాతకం లేకుండా మొత్తం 43 మూల రూల్స్ చదవవచ్చు; గణనకు Saved Chart అవసరం.')),
          ],
        ))),
        Padding(padding:const EdgeInsets.symmetric(vertical:8),
          child:DropdownButtonFormField<String>(
            value:_filter,
            decoration:const InputDecoration(labelText:'చెక్‌లిస్ట్ ఫిల్టర్',border:OutlineInputBorder()),
            items:const [
              DropdownMenuItem(value:'all',child:Text('అన్ని 43 నియమాలు')),
              DropdownMenuItem(value:'met',child:Text('షరతు సరిపోయినవి')),
              DropdownMenuItem(value:'pending',child:Text('మరింత పరిశీలన అవసరమైనవి')),
              DropdownMenuItem(value:'reviewed',child:Text('నేను ధృవీకరించినవి')),
            ],onChanged:(s){if(s!=null)setState(()=>_filter=s);},
          ),
        ),
        for(var i=1;i<=18;i++)
          if(sectionRules[i]!=null&&sectionRules[i]!.isNotEmpty)
            Card(child:ExpansionTile(
              key:ValueKey('chrome-section-$i'),
              title:Text('$i. ${MarriageChromeIfThenEngine.sectionTitles[i-1]}',
                style:const TextStyle(fontWeight:FontWeight.bold)),
              subtitle:Text('${sectionRules[i]!.length} నియమాలు'),
              children:[for(final r in sectionRules[i]!) _resultCard(r,evaluations[r.id]!)],
            )),
        if(sectionRules.isEmpty)
          const Center(child:Padding(padding:EdgeInsets.all(18),
            child:Text('ఈ ఫిల్టర్‌లో నియమాలు లేవు.'))),
      ]),
    );
  }
}
