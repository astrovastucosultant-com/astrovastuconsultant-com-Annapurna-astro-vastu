import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import 'marriage_chrome_checklist_screen.dart';

enum MarriageBookTopicScope { all, individual, matching }

/// Backward-compatible route retained for existing callers; the retired
/// 62-topic index depended on 39 removed scanned pages.
class MarriageBookTopicsScreen extends StatelessWidget {
  final MarriageBookTopicScope scope;
  final AstroChartResult? chart;
  final AstroChartResult? partnerChart;
  const MarriageBookTopicsScreen({super.key, this.scope = MarriageBookTopicScope.all,
      this.chart, this.partnerChart});
  @override
  Widget build(BuildContext context) => MarriageChromeChecklistScreen(chart: chart);
}
