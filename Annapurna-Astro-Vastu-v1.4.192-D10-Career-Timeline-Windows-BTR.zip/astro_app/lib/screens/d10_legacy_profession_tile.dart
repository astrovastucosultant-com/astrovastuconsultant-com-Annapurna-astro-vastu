import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/d10_career_service.dart';
import '../astrology/d10_display_order.dart';
import '../astrology/d10_profession_registry.dart';
import '../astrology/d10_vrutti_match_engine.dart';
import '../astrology/varga_service.dart';
import 'd10_percent_visual.dart';

/// Older profession entries are a source catalog, not complete IF-THEN
/// predicates. Keep ALL 181 entries searchable and inspectable separately
/// instead of filtering out entries without a confirmed final judgement.
class D10LegacyProfessionTile extends StatelessWidget {
  final D10ProfessionRule rule;
  final AstroChartResult chart;
  final List<D10VruttiMatch> linkedRules;
  final void Function(D10VruttiMatch match)? onOpenMatchedRule;
  const D10LegacyProfessionTile({super.key, required this.rule,
    required this.chart, this.linkedRules = const <D10VruttiMatch>[],
    this.onOpenMatchedRule});

  void _details(BuildContext context) {
    final d10 = VargaService.calculate(chart, 10);
    final tenthLord = D10CareerService.signLord((d10.ascendantSignIndex + 9) % 12);
    final natal = chart.planets.where((p) => p.name == rule.planet).toList();
    final d10Planet = d10.planets.where((p) => p.name == rule.planet).toList();
    final found = natal.isNotEmpty && d10Planet.isNotEmpty;
    final d1House = found ? D10CareerService.d1House(chart, rule.planet) : null;
    final d10House = found ? D10CareerService.vargaHouse(d10, rule.planet) : null;
    final d10Linked = found && (d10House == 1 || d10House == 10 ||
        rule.planet == tenthLord ||
        D10CareerService.relatedVarga(d10, rule.planet, tenthLord));
    final confirm = d1House == 10 && d10Linked;
    // The user explicitly defined these terms as planets, NOT extra D10 deities.
    final isPlanetAlias = rule.devata == 'Sun Deity' || rule.devata == 'Venus Deity';
    final computed = found
        ? D10CareerService.devataForLongitude(natal.first.longitude).deity : null;
    final deityMatches = !isPlanetAlias && rule.devata == computed;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(child: FractionallySizedBox(
        heightFactor: 0.85,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Text('${rule.id} · ${rule.name}', style: Theme.of(ctx).textTheme.titleLarge),
          const SizedBox(height: 10),
          const Text('జాతక పరిశీలన',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          Text('ప్రధాన గ్రహం: ${rule.planet}'),
          Text('జనన చార్ట్‌లో భావం: ${d1House ?? 'డేటా లేదు'}'),
          Text('D10లో భావం: ${d10House ?? 'డేటా లేదు'}'),
          Text('D10 10వ అధిపతితో సంబంధం: ${d10Linked ? 'ఉంది' : 'లేదు'}'),
          Text('D1 10వ గ్రహం → D10 Confirm: ${confirm ? 'ఉంది' : 'లేదు'}'),
          Text('మూల దేవత/గ్రహ పదం: ${rule.devata}'),
          if (isPlanetAlias)
            const Text('సూర్య దేవత = సూర్యుడు, శుక్ర దేవత = శుక్రుడు; ప్రత్యేక అంశ దేవత కాదు.'),
          if (!isPlanetAlias)
            Text('అంశదేవత: ${computed ?? 'డేటా లేదు'} · '
                'మూల దేవత సరిపోలిక: ${deityMatches ? 'ఉంది' : 'లేదు'}'),
          const Divider(),
          const Text('పాత మూల నియమ నమోదు',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          SelectableText('గ్రహం: ${rule.planet}\nదేవత: ${rule.devata}\n'
              'అదనపు అంశాలు: ${rule.extra}'),
          Text('పాత D10 వృత్తి రిజిస్ట్రీ · మూల సూచిక పేజీ ${rule.sourcePage}'),
          const SizedBox(height: 8),
          const Text('ఈ పాత ఎంట్రీకి సమానమైన పూర్తి IF–THEN మూల సూత్రం ఇంకా గుర్తించబడలేదు. '
              'D1/D10 ఆధారం కనిపించినా మొత్తం వృత్తి నిర్ధారణ కాదు. '
              'అందువల్ల కల్పిత అనుకూలత % లేదా వయసు చూపించరు. '
              'వృత్తి జాబితా నుంచి మాత్రం తొలగించరు.'),
        ]),
      )),
    );
  }

  @override
  Widget build(BuildContext context) {
    final linked = D10DisplayOrder.strongest(linkedRules);
    final tier = D10DisplayOrder.tier(linked, missingRule: linked == null);
    return Card(
      color: D10PercentVisual.tierBackground(tier),
      child: ListTile(
      title: Text.rich(TextSpan(children: [
        TextSpan(text: rule.name),
        if (linked != null) TextSpan(
          text: '  •  ${D10PercentVisual.percentLabel(linked.confirmed, linked.percent)}',
          style: TextStyle(color: D10PercentVisual.tierForeground(tier),
              fontWeight: FontWeight.w900)),
      ]), style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(linked == null
          ? '${rule.id} · ${rule.category} · పింక్: మూల IF–THEN పెండింగ్'
          : '${rule.id} · ${rule.category} · మూల రూల్ ${linked.rule.id} · '
              '${linked.confirmed ? linked.complete ? '${linked.percent}% ఆధారాలు సరిపోయాయి' : '${linked.percent}% పాక్షిక ఆధారాలు' : tier == D10EvidenceTier.pink ? 'పాక్షిక సూచనలు · Confirm లేదు' : 'D1→D10 Confirm లేదు'}'),
      trailing: const Icon(Icons.chevron_right),
      onTap: linked == null || onOpenMatchedRule == null
          ? () => _details(context)
          : () => onOpenMatchedRule!(linked),
    ));
  }

}
