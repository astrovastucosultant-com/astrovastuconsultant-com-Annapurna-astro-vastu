import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import 'marriage_chrome_checklist_screen.dart';

/// Legacy D9 entry point. The 88 former scanned pages were removed at the
/// user's request. Show only the currently supplied 6-page, 43-rule source.
class D9MarriageSourceRulebookScreen extends StatelessWidget {
  final AstroChartResult? chart;
  const D9MarriageSourceRulebookScreen({super.key, this.chart});
  @override
  Widget build(BuildContext context) => MarriageChromeChecklistScreen(chart: chart);
}
