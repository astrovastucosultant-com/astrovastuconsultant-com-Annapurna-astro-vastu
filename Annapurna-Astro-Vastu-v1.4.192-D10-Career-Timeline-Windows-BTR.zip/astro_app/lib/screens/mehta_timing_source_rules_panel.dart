import 'package:flutter/material.dart';

import '../astrology/mehta_timing_source_rules.dart';

/// Rule-first provenance, result-first navigation. Does not invent event dates.
class MehtaTimingSourceRulesPanel extends StatelessWidget {
  final ValueChanged<String> onChooseEvent;

  const MehtaTimingSourceRulesPanel({
    super.key,
    required this.onChooseEvent,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFFAF4EE),
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Mehta — ఈ దశలో ఏ సంఘటనకు సూచన?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            const SizedBox(height: 6),
            const Text(
              'మొదట ఫలితం → టచ్ చేస్తే జాతక పరిశీలన → టచ్ చేస్తే రూల్ / మూల పేజీ. '
              'కింద ఎంచుకున్న సంఘటన కోసం ఉన్న దశల పట్టికను కూడా తెరవవచ్చు.',
              style: TextStyle(height: 1.4),
            ),
            const SizedBox(height: 10),
            ...MehtaTimingSourceRules.entries.map((entry) => Card(
                  color: Colors.white,
                  surfaceTintColor: Colors.transparent,
                  child: ExpansionTile(
                    tilePadding: const EdgeInsets.symmetric(horizontal: 12),
                    title: Text(entry.title,
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text(entry.result,
                        style: const TextStyle(fontSize: 12.5, height: 1.4)),
                    childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                    children: [
                      ExpansionTile(
                        title: const Text('జాతక పరిశీలన — టచ్ చేయండి',
                            style: TextStyle(fontWeight: FontWeight.w800)),
                        children: [
                          ...entry.checks.asMap().entries.map((row) => ListTile(
                                dense: true,
                                leading: CircleAvatar(
                                  radius: 13,
                                  child: Text('${row.key + 1}',
                                      style: const TextStyle(fontSize: 12)),
                                ),
                                title: Text(row.value),
                              )),
                          ExpansionTile(
                            title: const Text('రూల్ → మూలగ్రంథ పేజీలు',
                                style: TextStyle(fontWeight: FontWeight.w800)),
                            children: [
                              ...entry.sourceRules.map((rule) => ListTile(
                                    dense: true,
                                    leading: const Icon(Icons.menu_book_outlined),
                                    title: Text(rule),
                                  )),
                              Padding(
                                padding: const EdgeInsets.all(12),
                                child: Text('${entry.id} — ${entry.source}\n\n${entry.caveat}',
                                    style: const TextStyle(height: 1.5)),
                              ),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          icon: const Icon(Icons.manage_search),
                          label: const Text('ఈ సంఘటన దశా పరిశీలన ఎంచుకోండి'),
                          onPressed: () => onChooseEvent(entry.eventId),
                        ),
                      ),
                    ],
                  ),
                )),
            const SizedBox(height: 8),
            const Text(
              'గమనిక: ఈ కార్డులు గ్రంథంలో గుర్తించిన కాంబినేషన్ల పరిశీలన మార్గదర్శకాలు. '
              'దశల సరిపోలిక అంటే సంఘటన ఖచ్చితంగా జరుగుతుందనే హామీ కాదు. '
              'మొదటి/రెండవ సంతానానికి ప్రత్యేక స్థిర టైమింగ్ నియమం చూపించలేదు.',
              style: TextStyle(fontSize: 12, height: 1.45),
            ),
          ],
        ),
      ),
    );
  }
}
