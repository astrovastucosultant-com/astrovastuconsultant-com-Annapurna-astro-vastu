import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/kalasarpa_service.dart';

class KalasarpaOverview extends StatelessWidget {
  final AstroChartResult chart;
  const KalasarpaOverview({super.key, required this.chart});

  @override
  Widget build(BuildContext context) {
    final result = KalasarpaService.evaluate(chart);
    final active = result.status.startsWith('పూర్ణ కాలసర్ప స్థితి (');
    final absent = result.status == 'పూర్ణ కాలసర్ప స్థితి లేదు';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('సర్ప శాపాలు / కాలసర్ప దోష పరిశీలన', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: const Color(0xFFFFF0F0), borderRadius: BorderRadius.circular(12)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('1. ఫలితం', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
              const SizedBox(height: 6),
              Text(absent ? 'ఇచ్చిన నియమాల ప్రకారం సర్ప దోషం లేదు' : result.status,
                style: const TextStyle(fontWeight: FontWeight.bold)),
              if (active) Text('${result.name} కాలసర్ప దోషం • రాహువు ${result.rahuHouse}వ భావం'),
              if (result.status == 'పరిశీలన పెండింగ్' || result.status == 'సంధి పరిశీలన అవసరం')
                const Text('సమాచారం లేదా సంధి స్పష్టత లేకుండా దోషం ఉందని లేదా లేదని నిర్ధారించలేము.'),
            ]),
          ),
          ExpansionTile(title: const Text('2. జాతక పరిశీలన'), children: [
            for (final line in result.evidence) ListTile(dense: true, title: Text(line)),
          ]),
          ExpansionTile(title: const Text('3. Rule ID & మూలం'), children: [
            Padding(padding: const EdgeInsets.all(12), child: Text(
              '${result.ruleId ?? 'వర్తించే రూల్ లేదు'} • 12 రకాల ఆధునిక సంప్రదాయ వర్గీకరణ. '
              'మూల గ్రంథం/పేజీ ధృవీకరణ: SOURCE_PENDING. జైమిని సూత్రంగా పేర్కొనరాదు.')),
          ]),
          const ExpansionTile(title: Text('4. Timing of Event'), children: [
            Padding(padding: EdgeInsets.all(12), child: Text(
              'ఈ జన్మస్థితి ఒక్కటితో సంఘటన తేదీ నిర్ణయించలేము. దశ, గోచార ఆధారాలు వేరుగా పరిశీలించాలి.')),
          ]),
          const ExpansionTile(title: Text('5. పరిహారం'), children: [
            Padding(padding: EdgeInsets.all(12), child: Text(
              'సంప్రదాయ ఐచ్ఛిక ఆచారాలు: శివారాధన, రాహు–కేతు ప్రార్థన. ఖర్చుతో కూడిన పూజ తప్పనిసరి కాదు. '
              'ఆరోగ్యం, సంతానం లేదా ప్రమాదాలపై ఈ గణన వైద్యపరమైన నిర్ధారణ కాదు.')),
          ]),
          const Padding(padding: EdgeInsets.all(8), child: Text(
            'గమనిక: ఈ పరిశీలన గ్రహ దీర్ఘాంశాల ఆధారంగా మాత్రమే; పంచాంగ కరణం ఆధారంగా కాదు. '
            'పాక్షిక, సవ్య/అపసవ్య నిర్వచనాలు సంప్రదాయాలవారీగా మారుతాయి.',
            style: TextStyle(fontSize: 12))),
        ]),
      ),
    );
  }
}
