import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

/// Rasterises Flutter-shaped Telugu text into PDF pages. This deliberately uses
/// the device's Telugu font fallback instead of a PDF built-in Latin-only font.
/// No font binaries are embedded or distributed with the app source.
class MarriagePdfReportService {
  static const double _w = 1240;
  static const double _h = 1754;
  static const double _margin = 84;

  static Future<Uint8List> create(String report) async {
    final document = pw.Document(compress: true);
    final lines = report.replaceAll('\r', '').split('\n');
    final pageLines = <_TextLine>[];
    var used = 0.0;
    var pageNo = 1;

    Future<void> flush() async {
      if (pageLines.isEmpty) return;
      final png = await _render(pageLines, pageNo);
      document.addPage(pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Image(pw.MemoryImage(png), fit: pw.BoxFit.fill),
      ));
      pageLines.clear();
      used = 0;
      pageNo++;
    }

    for (final raw in lines) {
      final heading = RegExp(r'^\d+\.\s').hasMatch(raw) ||
          raw.startsWith('ANNAPURNA') || raw.startsWith('MM-');
      final style = TextStyle(
        fontSize: raw.startsWith('ANNAPURNA') ? 34 : heading ? 26 : 23,
        fontWeight: heading ? FontWeight.bold : FontWeight.normal,
        color: heading ? const Color(0xFF783040) : const Color(0xFF28242A),
        height: 1.5,
      );
      final painter = TextPainter(
        text: TextSpan(text: raw.isEmpty ? ' ' : raw, style: style),
        textDirection: TextDirection.ltr,
        maxLines: null,
      )..layout(maxWidth: _w - _margin * 2);
      final blockHeight = painter.height + 14;
      if (used + blockHeight > _h - 2 * _margin - 52 && pageLines.isNotEmpty) {
        await flush();
      }
      pageLines.add(_TextLine(raw, style, used));
      used += blockHeight;
    }
    await flush();
    return document.save();
  }

  static Future<Uint8List> _render(List<_TextLine> lines, int pageNo) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.drawRect(const Rect.fromLTWH(0, 0, _w, _h), Paint()..color = Colors.white);
    canvas.drawRect(const Rect.fromLTWH(0, 0, _w, 16), Paint()..color = const Color(0xFF842E3F));
    for (final line in lines) {
      final p = TextPainter(
        text: TextSpan(text: line.text.isEmpty ? ' ' : line.text, style: line.style),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: _w - _margin * 2);
      p.paint(canvas, Offset(_margin, _margin + line.y));
      p.dispose();
    }
    canvas.drawLine(
      const Offset(_margin, _h - 66), const Offset(_w - _margin, _h - 66),
      Paint()..color = const Color(0xFFDDCCD0)..strokeWidth = 2,
    );
    final footer = TextPainter(
      text: TextSpan(text: 'ANNAPURNA ASTRO VASTU  •  $pageNo',
          style: const TextStyle(fontSize: 18, color: Color(0xFF777777))),
      textDirection: TextDirection.ltr,
    )..layout();
    footer.paint(canvas, const Offset(_margin, _h - 53));
    footer.dispose();
    final image = await recorder.endRecording().toImage(_w.toInt(), _h.toInt());
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    image.dispose();
    if (bytes == null) throw StateError('Could not render Telugu PDF page');
    return bytes.buffer.asUint8List();
  }

  static Future<void> previewAndSave(String report) async {
    final pdf = await create(report);
    await Printing.layoutPdf(onLayout: (_) async => pdf,
      name: 'Annapurna_Marriage_Matching_Report.pdf');
  }

  static Future<void> share(String report) async {
    final pdf = await create(report);
    await Printing.sharePdf(bytes: pdf, filename: 'Annapurna_Marriage_Matching_Report.pdf');
  }
}

class _TextLine {
  final String text;
  final TextStyle style;
  final double y;
  _TextLine(this.text, this.style, this.y);
}
