import 'astro_models.dart';
import 'marriage_chart_evidence_service.dart';
import 'varga_service.dart';

/// Exact *subconditions* transcribed from the scanned user's source
/// `Marrage rules ok.pdf`, PDF pages 7, 12–16. No match here independently
/// establishes marriage, delay, divorce, or an event date.
/// IDs are tied to (PDF page, printed sutra, subrule), NOT the older M-xx
/// topical index, which has some inaccurate page-to-heading mappings.
enum MarriageSutraState { needsChart, needsPlanetData, conditionMet, conditionNotMet }

class MarriageVerifiedSutra {
  final String id;
  final int page;
  final String title;
  final String sourceCondition;
  final String interpretation;
  const MarriageVerifiedSutra(this.id, this.page, this.title,
      this.sourceCondition, this.interpretation);
}

class MarriageSutraEvaluation {
  final MarriageSutraState state;
  final String evidence;
  final String result;
  const MarriageSutraEvaluation(this.state, this.evidence, this.result);
  bool get computed => state == MarriageSutraState.conditionMet ||
      state == MarriageSutraState.conditionNotMet;
  bool get matched => state == MarriageSutraState.conditionMet;
}

class MarriageVerifiedSutraEngine {
  static const sourceName = 'Marrage rules ok.pdf';
  static const _scopeNotice =
      'ఇది మూలంలోని ఒక గ్రహస్థితి ఉపషరతు మాత్రమే. ఇతర సూత్రాలు, మినహాయింపులు, '
      'దశా–గోచార పరిశీలన లేకుండా వివాహ సంఘటన లేదా ఖచ్చితమైన కాలాన్ని ప్రకటించరాదు.';
  static const sutras = <MarriageVerifiedSutra>[
    MarriageVerifiedSutra('P07-S04',7,'D9 ఉపచయ స్థానాలు — ప్రత్యేక 10వ భావం',
      'పుట 7, సూత్రం 04: నవాంశ చక్రంలో 3,6,10,11 ఉపచయ భావాలలో గ్రహస్థితి; '
      'ముఖ్య గమనిక: 10వ భావంలో తప్పనిసరిగా ఒక గ్రహం ఉండాలి.',
      'నవాంశ పరిశీలనలో ఒక ఉపషరతు; మొత్తం వివాహయోగం కాదు.'),
    MarriageVerifiedSutra('P12-S10-R01',12,'చంద్రుడు — D1 2/7 స్థానాలు',
      'పుట 12, సూత్రం 10, R-01: D1లో చంద్రుడు 7వ భావంలో లేదా 2వ భావంలో ఉండాలి.',
      'శీఘ్ర వివాహ సూచనకు ఒక ఉపషరతు మాత్రమే.'),
    MarriageVerifiedSutra('P13-S11-R01',13,'కేతువు — D1 2/7 స్థానాలు',
      'పుట 13, సూత్రం 11, R-01: D1లో కేతువు 7వ భావంలో లేదా 2వ భావంలో ఉండాలి.',
      'కేతువు సంబంధ మూల ఉపషరతు మాత్రమే.'),
    MarriageVerifiedSutra('P13-S12-R01',13,'11వ అధిపతి — 7వ భావ సంబంధం',
      'పుట 13, సూత్రం 12, R-01: D1లో 7వ భావంలో 11వ అధిపతి లేదా '
      '11వ భావంలో 7వ అధిపతి ఉండాలి.',
      'భావాధిపతి స్థాన మార్పిడి/స్థితి ఆధారిత ఉపషరతు.'),
    MarriageVerifiedSutra('P13-S12-R02',13,'11వ అధిపతి — 2వ భావ సంబంధం',
      'పుట 13, సూత్రం 12, R-02: D1లో 2వ భావంలో 11వ అధిపతి లేదా '
      '11వ భావంలో 2వ అధిపతి ఉండాలి.',
      'భావాధిపతి స్థాన ఆధారిత ఉపషరతు.'),
    MarriageVerifiedSutra('P14-S13-R01',14,'D7 గురువు — 2వ స్థాన పరిశీలన',
      'పుట 14, సూత్రం 13, R-01: D7లో గురువు 7వ భావంలో లేదా '
      '2వ భావంలో ఉండే షరతు.',
      'మూలంలో ఆలస్య వివాహ విభాగంలో ఉంది; స్వతంత్ర కాల నిర్ణయం కాదు.'),
    MarriageVerifiedSutra('P15-S14-R01',15,'D7 శని — 2వ స్థాన పరిశీలన',
      'పుట 15, సూత్రం 14, R-01: D7లో శని 7వ భావంలో లేదా '
      '2వ భావంలో ఉండే షరతు.',
      'మూలంలో శని యోగ విభాగంలో ఉంది; స్వతంత్ర కాల నిర్ణయం కాదు.'),
    MarriageVerifiedSutra('P16-S15-R01',16,'D7 కుజుడు — లగ్నం నుంచి',
      'పుట 16, సూత్రం 15, R-01: D7 కుజుడు లగ్నం నుంచి '
      '2,4,7,8,12 భావాల్లో ఉండే ప్రాథమిక స్థాన షరతు.',
      'కుజదోషంలో గ్రహ సంబంధం/దోషభంగం ప్రత్యేకంగా పరిశీలించాలి.'),
    MarriageVerifiedSutra('P16-S15-R02',16,'D7 కుజుడు — చంద్రుని నుంచి',
      'పుట 16, సూత్రం 15, R-02: D7 కుజుడు చంద్రుని నుంచి '
      '2,4,7,8,12 భావాల్లో ఉండే ప్రాథమిక స్థాన షరతు.',
      'చంద్ర సంబంధ మినహాయింపు పరిశీలించక ముందే దోష తీర్పు ఇవ్వకూడదు.'),
    MarriageVerifiedSutra('P16-S15-R03',16,'D7 కుజుడు — శుక్రుని నుంచి',
      'పుట 16, సూత్రం 15, R-03: D7 కుజుడు శుక్రుని నుంచి '
      '2,4,7,8,12 భావాల్లో ఉండే ప్రాథమిక స్థాన షరతు.',
      'శుక్ర సంబంధ మినహాయింపులు వేరుగా పరీక్షించాలి.'),
  ];

  static String _name(String english) =>
      MarriageChartEvidenceService.planetNames[english] ?? english;
  static VargaPlacement? _p(VargaChartData v, String english) {
    for (final p in v.planets) {
      if (p.name == english) return p;
    }
    return null;
  }
  static int _h(int target, int origin) => (target-origin+12)%12+1;
  static MarriageSutraEvaluation _unknown(String message) =>
      MarriageSutraEvaluation(MarriageSutraState.needsPlanetData,
          message, 'అవసరమైన గ్రహస్థితులు లేక ఈ షరతు పరిశీలించలేదు.');
  static MarriageSutraEvaluation _answer(bool matches, String evidence) =>
      MarriageSutraEvaluation(matches ? MarriageSutraState.conditionMet :
          MarriageSutraState.conditionNotMet, evidence,
          '${matches ? "మూల గ్రహస్థితి ఉపషరతు సరిపోయింది." : "ఈ నిర్దిష్ట ఉపషరతు సరిపోలలేదు."} $_scopeNotice');

  static MarriageSutraEvaluation evaluate(String id, AstroChartResult? chart) {
    if (chart == null) {
      return const MarriageSutraEvaluation(MarriageSutraState.needsChart,
          'ముందుగా Generate/Saved Chart తెరవాలి.',
          'జాతకం లేక IF–THEN పరీక్ష జరగలేదు.');
    }
    final factor = id == 'P07-S04' || id.startsWith('P14-') ||
        id.startsWith('P15-') || id.startsWith('P16-')
        ? (id == 'P07-S04' ? 9 : 7) : 1;
    final v = VargaService.calculate(chart, factor);
    final lagna = v.ascendantSignIndex;
    if (id == 'P07-S04') {
      // An absent planet cannot certify an unoccupied 10H unless all of the
      // conventional nine planetary data are available.
      const expected = {'Sun','Moon','Mars','Mercury','Jupiter',
        'Venus','Saturn','Rahu','Ketu'};
      final found = v.planets.map((p)=>p.name).toSet();
      final occupants10 = v.planets.where((p)=>_h(p.signIndex,lagna)==10)
          .map((p)=>_name(p.name)).toList();
      final upachaya = v.planets.where((p)=>
          const {3,6,10,11}.contains(_h(p.signIndex,lagna)))
          .map((p)=>'${_name(p.name)} (${_h(p.signIndex,lagna)}వ భావం)').toList();
      final evidence = 'D9 3/6/10/11 గ్రహాలు: '
          '${upachaya.isEmpty ? "లేవు" : upachaya.join(", ")}\n'
          'D9 10వ భావం: ${occupants10.isEmpty ? "గ్రహాలు లేవు" : occupants10.join(", ")}';
      if (occupants10.isNotEmpty) return _answer(true,evidence);
      if (!found.containsAll(expected)) {
        return _unknown('$evidence\nతొమ్మిది గ్రహాల పూర్తి డేటా లేకపోవడంతో '
            '10వ భావం ఖాళీ అని నిర్ధారించలేదు.');
      }
      return _answer(false,evidence);
    }
    if (id == 'P12-S10-R01' || id == 'P13-S11-R01') {
      final name = id == 'P12-S10-R01' ? 'Moon' : 'Ketu';
      final p = _p(v,name);
      if (p == null) return _unknown('${_name(name)} సమాచారం లేదు.');
      final h = _h(p.signIndex,lagna);
      return _answer(h==2||h==7,'D1 ${_name(name)}: $h వ భావం; మూల షరతు 2 లేదా 7.');
    }
    if (id == 'P13-S12-R01' || id == 'P13-S12-R02') {
      final other = id.endsWith('R01') ? 7 : 2;
      final otherSign = (lagna+other-1)%12;
      final elevenSign = (lagna+10)%12;
      final otherLord = MarriageChartEvidenceService.lords[otherSign];
      final elevenLord = MarriageChartEvidenceService.lords[elevenSign];
      final a = _p(v, elevenLord), b = _p(v,otherLord);
      if (a == null || b == null) {
        return _unknown('D1 ${_name(elevenLord)} / ${_name(otherLord)} '
            'రెండింటి స్థితులు అవసరం.');
      }
      final ha = _h(a.signIndex,lagna), hb = _h(b.signIndex,lagna);
      return _answer(ha==other||hb==11,
          'D1 11వ అధిపతి ${_name(elevenLord)}: $ha వ భావం; '
          '${other}వ అధిపతి ${_name(otherLord)}: $hb వ భావం. '
          'పరిశీలన: 11L→$other లేదా ${other}L→11.');
    }
    if (id == 'P14-S13-R01' || id == 'P15-S14-R01') {
      final name = id.startsWith('P14-') ? 'Jupiter' : 'Saturn';
      final p = _p(v,name);
      if (p == null) return _unknown('D7 ${_name(name)} సమాచారం లేదు.');
      final h = _h(p.signIndex,lagna);
      return _answer(h==2 || h==7,'D7 ${_name(name)}: $h వ భావం. '
          'మూల R-01: 2వ లేదా 7వ భావం.');
    }
    if (id.startsWith('P16-S15-')) {
      final mars = _p(v,'Mars');
      final reference = id.endsWith('R01') ? null :
          _p(v,id.endsWith('R02')?'Moon':'Venus');
      if (mars == null || (!id.endsWith('R01') && reference == null)) {
        return _unknown('D7 కుజుడు, సంబంధిత సూచిక గ్రహం డేటా అవసరం.');
      }
      final referenceSign = reference?.signIndex ?? lagna;
      final h = _h(mars.signIndex,referenceSign);
      final name = id.endsWith('R01') ? 'లగ్నం' :
          id.endsWith('R02') ? 'చంద్రుడు' : 'శుక్రుడు';
      return _answer(const {2,4,7,8,12}.contains(h),
          'D7 $name నుంచి కుజుడు: $h వ భావం. '
          'స్థాన షరతు: 2,4,7,8,12. దృష్టి/మినహాయింపులు ఈ పరీక్షలో లేవు.');
    }
    return _unknown('తెలియని సూత్రం: $id');
  }
}
