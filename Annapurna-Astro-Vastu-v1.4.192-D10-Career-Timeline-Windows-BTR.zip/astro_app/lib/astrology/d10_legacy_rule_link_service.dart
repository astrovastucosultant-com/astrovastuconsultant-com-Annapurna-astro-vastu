import 'd10_profession_registry.dart';
import 'd10_vrutti_match_engine.dart';

/// Reuses the user's *actual* PDF IF–THEN clauses for the original D10 catalog.
/// Only a profession label (or an explicit slash-separated alias) with an
/// identical PRIMARY planet and D10 devata is eligible. No inferred conditions.
class D10LegacyRuleLinkService {
  static String _normalize(String value) => value
      .replaceAll(RegExp(r'[\u200c\u200d\s]+'), '')
      .replaceAll(RegExp(r'[.,।()]+'), '')
      .trim();

  static bool _exactProfessionAlias(String legacyName, String profession) {
    final target = _normalize(legacyName);
    return profession.split(RegExp(r'\s*/\s*'))
        .any((alias) => _normalize(alias) == target);
  }

  static bool _deityCompatible(D10ProfessionRule legacy, D10VruttiMatch match) {
    // These two legacy phrases refer to the planets, not a D10 devata.
    if (legacy.devata == 'Sun Deity') {
      return legacy.planet == 'Sun' && match.rule.deity == null;
    }
    if (legacy.devata == 'Venus Deity') {
      return legacy.planet == 'Venus' && match.rule.deity == null;
    }
    return match.rule.deity == legacy.devata;
  }

  static List<D10VruttiMatch> matchingRules(
      D10ProfessionRule legacy, List<D10VruttiMatch> evaluated) {
    final found = evaluated.where((m) =>
        m.rule.planets.isNotEmpty &&
        m.rule.planets.first == legacy.planet &&
        _deityCompatible(legacy, m) &&
        _exactProfessionAlias(legacy.name, m.rule.profession)).toList();
    found.sort((a, b) {
      // Exact label outranks an umbrella/combined profession alias.
      final ae = _normalize(a.rule.profession) == _normalize(legacy.name);
      final be = _normalize(b.rule.profession) == _normalize(legacy.name);
      if (ae != be) return ae ? -1 : 1;
      // Prefer a fully sourced individual entry over a later grouped synopsis.
      final af = a.rule.source == 'vrutti-if-then-full.pdf';
      final bf = b.rule.source == 'vrutti-if-then-full.pdf';
      if (af != bf) return af ? -1 : 1;
      return a.rule.id.compareTo(b.rule.id);
    });
    return found;
  }
}
