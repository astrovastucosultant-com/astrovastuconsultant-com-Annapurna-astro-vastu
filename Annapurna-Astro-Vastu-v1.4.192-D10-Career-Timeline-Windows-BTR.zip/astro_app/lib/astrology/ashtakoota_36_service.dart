import 'astro_models.dart';

/// Conventional 36-point Ashtakoota (not the guru's separate printed rules).
/// Uses an explicitly named reference variant: symmetric Vashya from Gunmilan,
/// Maitreya's 14x14 Yoni table, and standard Nadi/Gana/Bhakoot/Tara rules.
class KootaPoint {
  final String name, groom, bride, explanation;
  final double maxPoints, points;
  const KootaPoint(this.name,this.groom,this.bride,this.maxPoints,this.points,this.explanation);
}
class Ashtakoota36Result {
  final List<KootaPoint> points;
  const Ashtakoota36Result(this.points);
  double get total => points.fold(0.0,(v,p)=>v+p.points);
  String get totalLabel => '${total.toStringAsFixed(total%1==0?0:1)} / 36';
}
class Ashtakoota36Service {
  static const stars=['అశ్విని','భరణి','కృత్తిక','రోహిణి','మృగశిర','ఆర్ద్ర','పునర్వసు','పుష్యమి','ఆశ్లేష','మఖ','పుబ్బ','ఉత్తర','హస్త','చిత్త','స్వాతి','విశాఖ','అనూరాధ','జ్యేష్ఠ','మూల','పూర్వాషాఢ','ఉత్తరాషాఢ','శ్రవణం','ధనిష్ఠ','శతభిషం','పూర్వాభాద్ర','ఉత్తరాభాద్ర','రేవతి'];
  static const lords=['Mars','Venus','Mercury','Moon','Sun','Mercury','Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'];
  static const gana=[0,1,2,1,0,1,0,0,2,2,1,1,0,2,0,2,0,2,2,1,1,0,2,2,1,1,0];
  static const nadi=[0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,2,1,0,0,1,2,2,1,0,0,1,2];
  // Horse Elephant Sheep Snake Dog Cat Rat Cow Buffalo Tiger Deer Monkey Mongoose Lion.
  static const yonis=[0,1,2,3,3,4,5,2,5,6,6,7,8,9,8,9,10,10,4,11,12,11,13,0,13,7,1];
  static const animals=['అశ్వ','గజ','మేష','సర్ప','శ్వాన','మార్జార','మూషిక','గోవు','మహిష','వ్యాఘ్ర','మృగ','వానర','నకుల','సింహ'];
  static const yoniMatrix=<List<int>>[
    [4,2,2,3,2,2,2,1,0,1,3,3,2,1],
    [2,4,3,3,2,2,2,2,3,1,2,3,2,0],
    [2,3,4,2,1,2,1,3,3,1,2,0,3,1],
    [3,3,2,4,2,1,1,1,1,2,2,2,0,2],
    [2,2,1,2,4,2,1,2,2,1,0,2,1,1],
    [2,2,2,1,2,4,0,2,2,1,3,3,2,1],
    [2,2,1,1,1,0,4,2,2,2,2,2,1,2],
    [1,2,3,1,2,2,2,4,3,0,3,2,2,1],
    [0,3,3,1,2,2,2,3,4,1,2,2,2,1],
    [1,1,1,2,1,1,2,0,1,4,1,1,2,1],
    [1,2,2,2,0,3,2,3,2,1,4,2,2,1],
    [3,3,0,2,2,3,2,2,2,1,2,4,3,2],
    [2,2,3,0,1,2,1,2,2,2,2,3,4,2],
    [1,0,1,2,1,1,2,1,2,1,1,2,2,4]
  ];
  static const groupNames=['చతుష్పాద','ద్విపాద','జలచర','వనచర','కీట'];
  static const vashyaMatrix=<List<double>>[
    [2,1,1,0,1],[1,2,0.5,0,1],[1,0.5,2,1,1],[0,0,1,2,0],[1,1,1,0,2]
  ];
  static const signVarna=[1,2,3,0,1,2,3,0,1,2,3,0]; // fire kshatriya, earth vaishya, air shudra, water brahmin
  static const varnaNames=['బ్రాహ్మణ','క్షత్రియ','వైశ్య','శూద్ర'];
  static int vashya(double moon){final r=(moon/30).floor()%12;final deg=moon%30;
    if(r==8)return deg<15?1:0;
    if(r==9)return deg<15?0:2;
    return [0,0,1,2,3,1,1,4,1,0,1,2][r];
  }
  static const friends=<String,List<String>>{
    'Sun':['Moon','Mars','Jupiter'], 'Moon':['Sun','Mercury'],
    'Mars':['Sun','Moon','Jupiter'], 'Mercury':['Sun','Venus'],
    'Jupiter':['Sun','Moon','Mars'], 'Venus':['Mercury','Saturn'],
    'Saturn':['Mercury','Venus']
  };
  static const enemies=<String,List<String>>{
    'Sun':['Venus','Saturn'], 'Moon':[], 'Mars':['Mercury'],
    'Mercury':['Moon'], 'Jupiter':['Mercury','Venus'],
    'Venus':['Sun','Moon'], 'Saturn':['Sun','Moon','Mars']
  };
  static int relation(String a,String b){if(a==b)return 2;if(friends[a]?.contains(b)??false)return 1;if(enemies[a]?.contains(b)??false)return -1;return 0;}
  static double maitri(String a,String b){if(a==b)return 5;
    final x=relation(a,b),y=relation(b,a);
    if(x==1&&y==1)return 5;
    if((x==1&&y==0)||(x==0&&y==1))return 4;
    if(x==0&&y==0)return 3;
    if((x==1&&y==-1)||(x==-1&&y==1))return 1;
    if((x==0&&y==-1)||(x==-1&&y==0))return 0.5;
    return 0;
  }
  static double tara(int a,int b){bool ok(int from,int to){final t=((to-from+27)%27)%9+1;return t!=3&&t!=5&&t!=7;}
    return (ok(a,b)?1.5:0)+(ok(b,a)?1.5:0);
  }
  static double ganaScore(int a,int b){if(a==b)return 6;if((a==0&&b==1)||(a==1&&b==0))return 5;if((a==1&&b==2)||(a==2&&b==1))return 1;return 0;}
  static double bhakoot(int a,int b){final distance=((b-a+12)%12)+1;
    return [2,5,6,8,9,12].contains(distance)?0:7;
  }
  static Ashtakoota36Result? evaluate(AstroChartResult groom,AstroChartResult bride){
    PlanetPosition? moon(AstroChartResult c){for(final p in c.planets){if(p.name=='Moon')return p;}return null;}
    final gm=moon(groom),bm=moon(bride);if(gm==null||bm==null)return null;
    final g=gm.longitude%360,b=bm.longitude%360;
    final gs=(g/(360/27)).floor().clamp(0,26),bs=(b/(360/27)).floor().clamp(0,26);
    final gr=(g/30).floor().clamp(0,11),br=(b/30).floor().clamp(0,11);
    final gv=vashya(g),bv=vashya(b);
    final gl=lords[gr],bl=lords[br];
    final points=<KootaPoint>[
      KootaPoint('వర్ణ',varnaNames[signVarna[gr]],varnaNames[signVarna[br]],1,signVarna[gr]<=signVarna[br]?1:0,'చంద్రరాశుల వర్ణ క్రమం; వరుడి వర్ణస్థాయి వధువుకంటే తక్కువ కాకూడదు.'),
      KootaPoint('వశ్య',groupNames[gv],groupNames[bv],2,vashyaMatrix[gv][bv],'చంద్రరాశి డిగ్రీ ఆధారంగా వశ్య వర్గం; ఎంపిక చేసిన symmetric 5×5 పట్టిక.'),
      KootaPoint('తార',stars[gs],stars[bs],3,tara(gs,bs),'రెండు దిశల్లో జన్మనక్షత్ర దూరం; 3,5,7 స్థానాలకు 0; మిగతావాటికి 1.5.'),
      KootaPoint('యోని',animals[yonis[gs]],animals[yonis[bs]],4,yoniMatrix[yonis[gs]][yonis[bs]].toDouble(),'Maitreya/Saravali ప్రచురించిన 14×14 Yoni compatibility matrix.'),
      KootaPoint('గ్రహమైత్రి',gl,bl,5,maitri(gl,bl),'చంద్రరాశి అధిపతుల సహజ మైత్రి/సమ/శత్రు సంబంధం.'),
      KootaPoint('గణ', ['దేవ','మనుష్య','రాక్షస'][gana[gs]],['దేవ','మనుష్య','రాక్షస'][gana[bs]],6,ganaScore(gana[gs],gana[bs]),'నక్షత్ర గణాల జంట పోలిక.'),
      KootaPoint('భకూట', '${gr+1} రాశి','${br+1} రాశి',7,bhakoot(gr,br),'చంద్రరాశుల 2/12, 5/9, 6/8 సంబంధాలకు 0; ఇతరులకు 7. దోష మినహాయింపులు వర్తింపచేయలేదు.'),
      KootaPoint('నాడీ',['ఆది','మధ్య','అంత్య'][nadi[gs]],['ఆది','మధ్య','అంత్య'][nadi[bs]],8,nadi[gs]==nadi[bs]?0:8,'ఒకే నాడీ అయితే 0, భిన్న నాడీ అయితే 8; ప్రత్యేక మినహాయింపులు వర్తింపచేయలేదు.'),
    ];
    return Ashtakoota36Result(points);
  }
}
