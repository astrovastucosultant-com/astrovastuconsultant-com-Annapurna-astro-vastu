import 'astro_models.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';

/// D12 chart analysis taking the ATMAKARAKA NAVAMSA SIGN as a reference lagna.
/// This is an explicit application convention for the D12 source's "KL" views:
/// the supplied Ch.9 depicts KL charts, but does not spell out its construction.
/// No formula for Cyclical D12 or subjective graha bala is inferred.
/// The "percentages" are auditable counts, never probability or book authority.
class D12KlCheck {
  final String ruleId;
  final String category;
  final String title;
  final String condition;
  final String sourceResult;
  final String evidence;
  final String printedPage;
  final bool? matched;
  final bool caution;
  final bool fromKl;

  const D12KlCheck({
    required this.ruleId,
    required this.category,
    required this.title,
    required this.condition,
    required this.sourceResult,
    required this.evidence,
    required this.printedPage,
    required this.matched,
    required this.caution,
    this.fromKl = true,
  });
}

class D12KlAnalysis {
  final int d12Sign;
  final int klSign;
  final String atmakaraka;
  final String klLord;
  final bool degreeTie;
  final List<D12KlCheck> checks;
  final Map<int, List<String>> occupantsFromKl;

  const D12KlAnalysis({
    required this.d12Sign,
    required this.klSign,
    required this.atmakaraka,
    required this.klLord,
    required this.degreeTie,
    required this.checks,
    required this.occupantsFromKl,
  });

  int get testable => checks.where((x) => x.matched != null).length;
  int get tested => degreeTie ? 0 : testable;
  int get matched => degreeTie ? 0 : checks.where((x) => x.matched == true).length;
  int get favorableMatched => degreeTie ? 0 : checks.where((x) => x.matched == true && !x.caution).length;
  int get cautionMatched => degreeTie ? 0 : checks.where((x) => x.matched == true && x.caution).length;
  int get pending => checks.where((x) => x.matched == null).length + (degreeTie ? testable : 0);
  int get allChecks => checks.length;

  /// Rules evaluated as a portion of the explicitly implemented checklist.
  /// Not a fraction of all book propositions or astrology accuracy.
  int get evaluatedPercent => allChecks == 0 ? 0 : (100 * tested / allChecks).round();
  int get matchPercent => tested == 0 ? 0 : (100 * matched / tested).round();
  int? get favorableSharePercent {
    final decisive = favorableMatched + cautionMatched;
    return decisive == 0 ? null : (100 * favorableMatched / decisive).round();
  }

  int signForHouse(int house) => (klSign + house - 1) % 12;
  int houseForSign(int sign) => ((sign - klSign + 12) % 12) + 1;
}

class D12KlService {
  static const signNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];
  static const _grahas = <String>[
    'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu',
  ];
  static const _malefics = {'Sun','Mars','Saturn','Rahu','Ketu'};
  static const _classical = {'Sun','Mars','Saturn'};
  static const _benefics = {'Jupiter','Venus','Mercury','Moon'};

  static String signLord(int sign) => switch (sign % 12) {
    0 || 7 => 'Mars',
    1 || 6 => 'Venus',
    2 || 5 => 'Mercury',
    3 => 'Moon',
    4 => 'Sun',
    8 || 11 => 'Jupiter',
    9 || 10 => 'Saturn',
    _ => '—',
  };

  static D12KlAnalysis analyze(AstroChartResult chart, VargaChartData d12) {
    if (d12.definition.factor != 12) throw ArgumentError('D12 chart expected');
    final j = JaiminiService.calculate(chart);
    final kl = j.karakamsaSignIndex;
    final ak = j.atmakaraka;
    final byName = {for (final p in d12.planets) p.name : p.signIndex};
    int signFor(int house) => (kl + house - 1) % 12;
    int? planetSign(String planet) => byName[planet];
    String lord(int house) => signLord(signFor(house));
    int? houseOf(String planet) => planetSign(planet) == null ? null : ((planetSign(planet)! - kl + 12) % 12) + 1;
    bool together(String x, String y) => x != y && planetSign(x) != null && planetSign(x) == planetSign(y);
    bool aspectsSign(String planet, int? target) {
      final source = planetSign(planet);
      if (source == null || target == null || source == target || planet == 'Rahu' || planet == 'Ketu') return false;
      final distance = ((target - source + 12) % 12) + 1;
      return distance == 7 ||
        (planet == 'Mars' && (distance == 4 || distance == 8)) ||
        (planet == 'Jupiter' && (distance == 5 || distance == 9)) ||
        (planet == 'Saturn' && (distance == 3 || distance == 10));
    }
    bool associated(String p, String q) => p != q && (together(p,q) || aspectsSign(p,planetSign(q)) || aspectsSign(q,planetSign(p)));
    bool linkedToSign(String p, int s) => planetSign(p) == s || aspectsSign(p,s);
    List<String> maleficsOn(int target, {String? exclude}) => [
      for (final p in _grahas)
        if (p != exclude && _malefics.contains(p) &&
            (planetSign(p) == target || (_classical.contains(p) && aspectsSign(p,target)))) p,
    ];
    List<String> beneficsOn(int target, {String? exclude}) => [
      for (final p in _grahas)
        if (p != exclude && _benefics.contains(p) && (planetSign(p) == target || aspectsSign(p,target))) p,
    ];
    String showPlanet(String p) => '$p — KL H${houseOf(p) ?? '?'} (${planetSign(p) == null ? '—' : signNames[planetSign(p)!]})';
    String showHouse(int h) => 'KL H$h ${signNames[signFor(h)]}, lord ${lord(h)} (H${houseOf(lord(h)) ?? '?'})';
    final checks = <D12KlCheck>[];
    void add(String id, String category, String title, String condition,
        String result, String evidence, String page, bool? matched, {bool caution = false, bool fromKl = true}) {
      checks.add(D12KlCheck(
        ruleId: id, category: category, title: title, condition: condition,
        sourceResult: result, evidence: evidence, printedPage: page,
        matched: j.hasDegreeTie ? null : matched,
        caution: caution, fromKl: fromKl,
      ));
    }

    final gkPlanets = j.charaKarakas.where((k) => k.code == 'GK').map((k) => k.planet).toList();
    final String? gk = gkPlanets.isEmpty ? null : gkPlanets.first;
    final maleficKl = <String>{};
    if (gk != null && (linkedToSign(gk,kl) || associated(gk,signLord(kl)))) maleficKl.add('GK $gk');
    for (final h in [6,8,12]) {
      final p=lord(h);
      if (linkedToSign(p,kl) || associated(p,signLord(kl))) maleficKl.add('${h}L $p');
    }
    add('D12-KL-ANC-05','పూర్వీకుల ఆశీర్వాదం','KLతో GK/త్రికాధిపతి సంబంధం',
      'KL లేదా KL అధిపతితో GK లేదా 6/8/12 భావాధిపతుల కలయిక/దృష్టి.',
      'కష్టాల సూచనను ఇతర ఆశీర్వాద/బల నియమాలతో కలిపి చూడాలి.',
      'KL ${signNames[kl]}, KL lord ${signLord(kl)}; సంబంధితులు: ${maleficKl.isEmpty ? 'లేరు' : maleficKl.join(', ')}', '293',maleficKl.isNotEmpty,caution:true);
    final yoga = together(lord(9),lord(10));
    add('D12-KL-ANC-09','పూర్వీకుల ఆశీర్వాదం','9L–10L కలిసి ఉన్న యోగం',
      'KL ఆధారంగా 9వ/10వ అధిపతులు ఒకే రాశిలో ఉన్నారు.',
      'గ్రంథ ఉదాహరణలో దీనిని యోగంగా పరిశీలించారు; ఒక్క యోగంతో తుది ఫలితం కాదు.',
      '9L ${showPlanet(lord(9))}; 10L ${showPlanet(lord(10))}', '299', yoga);

    for (final h in [2,4]) {
      final harms=maleficsOn(signFor(h));
      add('D12-KL-CHILD-${h == 2 ? '02' : '04'}','బాల్యం','KL H$h పాపప్రభావం (పోలిక)',
        'KL నుంచి $h వ భావంపై సాంప్రదాయ పాపగ్రహ కలయిక లేదా దృష్టి.',
        'D12 జన్మలగ్నం ఆధారంగా చూసిన బాల్య ఫలితానికి KL నుంచి సహాయక పోలిక మాత్రమే.',
        '${showHouse(h)}; పాపప్రభావం: ${harms.isEmpty ? 'లేదు' : harms.join(', ')}', '299–300', harms.isNotEmpty,caution:true);
    }
    for (final entry in [('Sun','తండ్రి'),('Moon','తల్లి')]) {
      final p = entry.$1, parent = entry.$2;
      final s = planetSign(p);
      final harms = s == null ? <String>[] : maleficsOn(s,exclude:p);
      add('D12-KL-REL-${p == 'Sun' ? '04' : '03'}','తల్లిదండ్రుల అనుబంధం',
        '$parent కారకుడు $p — పాపసంబంధం',
        '$p పై పాపగ్రహ కలయిక లేదా గ్రహదృష్టి (జన్మ D12తో పోల్చాలి).',
        'అనుబంధంపై సాంప్రదాయ పరిశీలన మాత్రమే; నిజ జీవిత సంబంధానికి నిర్ధారణ కాదు.',
        '${showPlanet(p)}; ప్రభావం ${harms.isEmpty ? 'లేదు' : harms.join(', ')}','307',s == null ? null : harms.isNotEmpty,caution:true);
    }
    final akS=planetSign(ak);
    final akHarms=akS == null ? <String>[] : maleficsOn(akS,exclude:ak);
    add('D12-KL-CARE-02','తల్లిదండ్రులకు సేవ','AKపై పాపప్రభావం',
      'D12లో పిల్లవాడి కారకుడైన AKపై పాపగ్రహ కలయిక/దృష్టి.',
      'గ్రంథం parental-care పరీక్షలో AK ప్రభావాన్ని పరిశీలిస్తుంది; వ్యక్తి ప్రవర్తనపై తీర్పు కాదు.',
      '${showPlanet(ak)}; ప్రభావం ${akHarms.isEmpty ? 'లేదు' : akHarms.join(', ')}','314',akS == null ? null : akHarms.isNotEmpty,caution:true);
    final akBenefics=akS == null ? <String>[] : beneficsOn(akS,exclude:ak);
    add('D12-KL-CARE-03','తల్లిదండ్రులకు సేవ','AKపై శుభగ్రహ ప్రభావం',
      'AKకు శుభగ్రహ కలయిక లేదా సాంప్రదాయ గ్రహదృష్టి.',
      'తల్లిదండ్రులకు సహాయంపై గ్రంథం ఇచ్చిన అనుకూల సూచనల్లో ఇది ఒకటి.',
      '${showPlanet(ak)}; శుభగ్రహాలు ${akBenefics.isEmpty ? 'లేవు' : akBenefics.join(', ')}','314',akS == null ? null : akBenefics.isNotEmpty);
    final eighth = lord(8);
    final relatedToInheritance = linkedToSign(eighth,kl) || linkedToSign(eighth,signFor(2)) || linkedToSign(eighth,signFor(11));
    add('D12-KL-EST-04','వారసత్వం','8L–KL/2H/11H సంబంధం',
      '8వ అధిపతి KL, 2వ లేదా 11వ భావంతో కలయిక/దృష్టి సంబంధం.',
      'వారసత్వ స్వీకరణకు సంబంధించిన గ్రంథ సూచన; ఆస్తి లభిస్తుందని హామీ కాదు.',
      '8L ${showPlanet(eighth)}; KL ${signNames[kl]}; H2 ${signNames[signFor(2)]}; H11 ${signNames[signFor(11)]}', '323–324',relatedToInheritance);
    final impairers=<String>[];
    if(gk != null && (associated(eighth,gk) || together(eighth,gk))) impairers.add('GK $gk');
    for(final p in ['Rahu','Ketu']) {if(associated(eighth,p)) impairers.add(p);}
    add('D12-KL-EST-07','వారసత్వం','8వ అధిపతికి GK/నోడ్స్ సంబంధం',
      '8వ అధిపతితో GK లేదా రాహు/కేతు సంబంధం.',
      'వారసత్వం వినియోగంలో ఆటంకాలను గ్రంథం పరిశీలిస్తుంది.',
      '8L ${showPlanet(eighth)}; సంబంధితులు ${impairers.isEmpty ? 'లేరు' : impairers.join(', ')}','324',impairers.isNotEmpty,caution:true);

    add('D12-KL-ANC-03','పూర్వీకుల ఆశీర్వాదం','KL లగ్నం/అధిపతి బలం',
      'గ్రంథం KL/అధిపతి బలం కావాలంటుంది; పద్ధతి-నిర్దిష్ట బల గణన ధృవీకరించలేదు.',
      'పూర్తి గ్రహబల పరీక్ష వరకు పెండింగ్.',
      'KL ${signNames[kl]}, KL lord ${signLord(kl)}; బలం = పెండింగ్','293',null);
    add('D12-KL-EST-08','వారసత్వం','Cyclical D12 పోలిక',
      'Cyclical D12 తయారీని గ్రంథ సూచన ప్రకారం ధృవీకరించాలి.',
      'Cyclical D12 లేకుండా వారసత్వ తుది నిర్ణయం లేదు.',
      'Cyclical D12 algorithm = పెండింగ్','326–331',null);
    add('D12-KL-LONG-01','తల్లిదండ్రుల ఆయుర్దాయం','తల్లి/తండ్రి derived houses',
      'తల్లి 4వ భావం → ఆయుర్ సూచిక 11వ భావం; తండ్రి 9వ భావం → ఆయుర్ సూచిక 4వ భావం KL నుంచి.',
      'భావస్థానాలను మాత్రమే చూపుతాం; జీవితం/మరణం సంవత్సరాలు లేదా శాతం ఇవ్వము.',
      'తల్లి H4 ${signNames[signFor(4)]}; derived H11 ${signNames[signFor(11)]}; తండ్రి H9 ${signNames[signFor(9)]}; derived H4 ${signNames[signFor(4)]}', '332',null);

    final occupants = <int,List<String>>{
      for (int i=1;i<=12;i++) i: [for (final p in d12.planets) if(p.signIndex==signFor(i)) p.name],
    };
    return D12KlAnalysis(
      d12Sign: d12.ascendantSignIndex,
      klSign: kl,
      atmakaraka: ak,
      klLord: signLord(kl),
      degreeTie: j.hasDegreeTie,
      checks: checks,
      occupantsFromKl: occupants,
    );
  }
}
