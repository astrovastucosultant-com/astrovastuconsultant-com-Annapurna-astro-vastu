import 'western_event_btr.dart';

/// Descriptive historical-event checks. This is not predictive validation:
/// an event used for fitting must not also be counted as held-out evidence.
class WesternBtrValidation {
  /// A candidate is accepted only if each supplied event has sufficient
  /// evidence. Rankings are exploratory and not probabilities.
  static List<WesternBtrCandidate> eligibleCandidates(
      List<WesternBtrCandidate> candidates) {
    final eligible = candidates.where((c) => c.decision.sufficient).toList();
    eligible.sort((a, b) {
      final byEvents = b.supportedEventCount.compareTo(a.supportedEventCount);
      if (byEvents != 0) return byEvents;
      return b.evidenceScore.compareTo(a.evidenceScore);
    });
    return eligible;
  }

  /// Date-only records should be represented as a whole-day uncertainty
  /// interval. No fabricated midnight timestamp or second-level precision.
  static (DateTime, DateTime) eventDayInterval(DateTime localDay) {
    final start = DateTime(localDay.year, localDay.month, localDay.day);
    return (start, start.add(const Duration(days: 1)));
  }

  /// True held-out testing needs additional events beyond the events used
  /// to select the birth-time candidate. Three fit events are not a holdout.
  static bool hasIndependentHoldout({required int fittingEventCount,
      required int totalKnownEventCount}) =>
      fittingEventCount >= 3 && totalKnownEventCount > fittingEventCount;
}
