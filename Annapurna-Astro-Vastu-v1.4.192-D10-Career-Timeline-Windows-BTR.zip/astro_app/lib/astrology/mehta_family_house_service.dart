// Build115. Source: S.K. Mehta, New Dimensions pp. 87–95; New Rules and
// Combinations pp. 118, 138–145; Synchronization of Period pp. 18–22.
// Relative-house offsets are editorial mathematical expansions, not separate
// predictive yogas. The author's *10th-house father reference* is maintained.
import 'astro_models.dart';

class MehtaFamilyStep {
  final String label;
  final int offset;
  const MehtaFamilyStep(this.label, this.offset);
}

class MehtaFamilyRelation {
  final String id, title, source, evidenceType;
  final List<MehtaFamilyStep> steps;
  const MehtaFamilyRelation(this.id, this.title, this.steps, this.source, this.evidenceType);
}

class MehtaFamilyTopic {
  final String id, title;
  final int offset;
  const MehtaFamilyTopic(this.id, this.title, this.offset);
}

class MehtaFamilyHouseService {
  static const List<String> signs = [
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];
  static const Map<String,String> planetTelugu = {
    'Sun':'రవి','Moon':'చంద్రుడు','Mars':'కుజుడు',
    'Mercury':'బుధుడు','Jupiter':'గురువు','Venus':'శుక్రుడు',
    'Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు',
  };
  // Rashi lords on pp. 26, 96 of New Dimensions. No derived D-chart invented.
  static const List<String> signLords = [
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  // Planetary aspects from New Dimensions, printed pp. 100–101.
  static const Map<String,List<int>> aspects = {
    'Sun':[7],'Moon':[7],'Mercury':[7],'Venus':[7],
    'Mars':[4,7,8], 'Jupiter':[5,7,9], 'Saturn':[3,7,10],
    'Rahu':[], 'Ketu':[],
  };
  static const List<MehtaFamilyRelation> relations = [
    MehtaFamilyRelation('self', 'జాతకుడు', [], 'మూల లగ్నం', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('father', 'తండ్రి', [MehtaFamilyStep('తండ్రి', 10)], 'New Dimensions పు.95; Synchronization పు.18', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('mother', 'తల్లి', [MehtaFamilyStep('తల్లి', 4)], 'New Dimensions పు.95; Synchronization పు.18', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('spouse', 'భార్య / భర్త', [MehtaFamilyStep('జీవిత భాగస్వామి', 7)], 'New Dimensions పు.89, 95', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('child', 'సంతానం', [MehtaFamilyStep('సంతానం', 5)], 'New Dimensions పు.88, 95', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('younger', 'తమ్ముడు / చెల్లి', [MehtaFamilyStep('చిన్న సహోదరులు', 3)], 'New Dimensions పు.88, 95', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('elder', 'అన్న / అక్క', [MehtaFamilyStep('పెద్ద సహోదరులు', 11)], 'New Dimensions పు.90', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('maternal_y', 'తల్లి తమ్ముడు / చెల్లి', [MehtaFamilyStep('తల్లి', 4), MehtaFamilyStep('చిన్న సహోదరులు', 3)], 'New Dimensions పు.95', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('maternal_e', 'తల్లి అన్న / అక్క', [MehtaFamilyStep('తల్లి', 4), MehtaFamilyStep('పెద్ద సహోదరులు', 11)], 'New Combinations పు.140–142', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('paternal_y', 'తండ్రి తమ్ముడు / చెల్లి', [MehtaFamilyStep('తండ్రి', 10), MehtaFamilyStep('చిన్న సహోదరులు', 3)], 'New Dimensions పు.95; New Combinations పు.138', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('paternal_e', 'తండ్రి అన్న / అక్క', [MehtaFamilyStep('తండ్రి', 10), MehtaFamilyStep('పెద్ద సహోదరులు', 11)], 'New Combinations పు.138–139', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('spouse_y', 'భార్య/భర్త తమ్ముడు / చెల్లి', [MehtaFamilyStep('భార్య/భర్త', 7), MehtaFamilyStep('చిన్న సహోదరులు', 3)], 'New Dimensions పు.95; New Combinations పు.141–142', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('spouse_e', 'భార్య/భర్త అన్న / అక్క', [MehtaFamilyStep('భార్య/భర్త', 7), MehtaFamilyStep('పెద్ద సహోదరులు', 11)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('spouse_mother', 'అత్త (జీవిత భాగస్వామి తల్లి)', [MehtaFamilyStep('భార్య/భర్త', 7), MehtaFamilyStep('తల్లి', 4)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('spouse_father', 'మామ (జీవిత భాగస్వామి తండ్రి)', [MehtaFamilyStep('భార్య/భర్త', 7), MehtaFamilyStep('తండ్రి', 10)], 'Mehta X-తండ్రి నియమం ఆధారిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('child_spouse', 'కొడుకు/కూతురు జీవిత భాగస్వామి', [MehtaFamilyStep('సంతానం', 5), MehtaFamilyStep('భార్య/భర్త', 7)], 'New Combinations పు.141–142', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('grandchild', 'మనుమడు / మనుమరాలు', [MehtaFamilyStep('సంతానం', 5), MehtaFamilyStep('సంతానం', 5)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('younger_spouse', 'తమ్ముడు/చెల్లి జీవిత భాగస్వామి', [MehtaFamilyStep('చిన్న సహోదరులు', 3), MehtaFamilyStep('భార్య/భర్త', 7)], 'New Combinations పు.118, 124', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('elder_spouse', 'అన్న/అక్క జీవిత భాగస్వామి', [MehtaFamilyStep('పెద్ద సహోదరులు', 11), MehtaFamilyStep('భార్య/భర్త', 7)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('father_mother', 'తండ్రి తల్లి', [MehtaFamilyStep('తండ్రి', 10), MehtaFamilyStep('తల్లి', 4)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('father_father', 'తండ్రి తండ్రి', [MehtaFamilyStep('తండ్రి', 10), MehtaFamilyStep('తండ్రి', 10)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('mother_mother', 'తల్లి తల్లి', [MehtaFamilyStep('తల్లి', 4), MehtaFamilyStep('తల్లి', 4)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('mother_father', 'తల్లి తండ్రి', [MehtaFamilyStep('తల్లి', 4), MehtaFamilyStep('తండ్రి', 10)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('younger_child', 'తమ్ముడు/చెల్లి సంతానం', [MehtaFamilyStep('చిన్న సహోదరులు', 3), MehtaFamilyStep('సంతానం', 5)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('elder_child', 'అన్న/అక్క సంతానం', [MehtaFamilyStep('పెద్ద సహోదరులు', 11), MehtaFamilyStep('సంతానం', 5)], 'భావగణిత విస్తరణ', 'అదే భావగణితానికి చేసిన విస్తరణ'),
    MehtaFamilyRelation('spouse_y_spouse', 'భార్య/భర్త తమ్ముడు/చెల్లి జీవిత భాగస్వామి', [MehtaFamilyStep('భార్య/భర్త', 7), MehtaFamilyStep('చిన్న సహోదరులు', 3), MehtaFamilyStep('భార్య/భర్త', 7)], 'New Combinations పు.141–142', 'గ్రంథ ఉదాహరణ/సంబంధం'),
    MehtaFamilyRelation('father_y_spouse', 'తండ్రి తమ్ముడు/చెల్లి జీవిత భాగస్వామి', [MehtaFamilyStep('తండ్రి', 10), MehtaFamilyStep('చిన్న సహోదరులు', 3), MehtaFamilyStep('భార్య/భర్త', 7)], 'New Combinations పు.142', 'గ్రంథ ఉదాహరణ/సంబంధం'),
  ];
  static const List<MehtaFamilyTopic> topics = [
    MehtaFamilyTopic('self', 'ఆ వ్యక్తి స్వభావం / సాధారణ స్థితి', 1),
    MehtaFamilyTopic('money', 'ధనం / కుటుంబం / నిల్వలు', 2),
    MehtaFamilyTopic('younger', 'చిన్న సహోదరులు / ప్రయత్నాలు', 3),
    MehtaFamilyTopic('property', 'తల్లి / ఇల్లు / ఆస్తి', 4),
    MehtaFamilyTopic('children', 'విద్య / సంతానం', 5),
    MehtaFamilyTopic('service', 'సేవ / వ్యాధి / వివాదం', 6),
    MehtaFamilyTopic('marriage', 'వివాహం / భాగస్వామ్యం', 7),
    MehtaFamilyTopic('inheritance', 'వారసత్వం / సంక్షోభం', 8),
    MehtaFamilyTopic('fortune', 'భాగ్యం / ధర్మం', 9),
    MehtaFamilyTopic('profession', 'వృత్తి / ప్రభుత్వ స్థానం / తండ్రి (Mehta)', 10),
    MehtaFamilyTopic('elder', 'లాభం / పెద్ద సహోదరులు', 11),
    MehtaFamilyTopic('foreign', 'వ్యయం / విదేశీ ప్రయాణం', 12),
  ];
  // Source uses inclusive counting: selected relative house=1st.
  static int fromHouse(int base, int offset) => ((base + offset - 2) % 12) + 1;
  static int relativeHouse(MehtaFamilyRelation relation) {
    var house = 1;
    for (final step in relation.steps) {
      house = fromHouse(house, step.offset);
    }
    return house;
  }
  static int targetHouse(MehtaFamilyRelation relation, MehtaFamilyTopic topic) =>
      fromHouse(relativeHouse(relation), topic.offset);
  static int houseSign(AstroChartResult chart, int absoluteHouse) =>
      (chart.ascendantSignIndex + absoluteHouse - 1) % 12;
  static String signLord(AstroChartResult chart, int house) =>
      signLords[houseSign(chart, house)];
  static List<PlanetPosition> occupants(AstroChartResult chart, int house) =>
      chart.planets.where((p) => p.signIndex == houseSign(chart,house)).toList();
  static List<PlanetPosition> aspecting(AstroChartResult chart, int house) {
    final targetSign = houseSign(chart, house);
    return chart.planets.where((p) =>
      (aspects[p.name] ?? const <int>[])
        .contains(((targetSign - p.signIndex + 12) % 12) + 1)).toList();
  }
  static String planetsLabel(List<PlanetPosition> positions) =>
      positions.isEmpty ? 'లేరు' : positions.map((p) =>
          '${planetTelugu[p.name] ?? p.name} (${p.degreesInSign.toStringAsFixed(2)}°)').join(' • ');
}
