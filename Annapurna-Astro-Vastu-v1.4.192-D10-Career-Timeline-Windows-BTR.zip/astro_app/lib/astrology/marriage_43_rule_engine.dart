import 'astro_models.dart';
import 'marriage_printed_table_engine.dart';

/// The 43-item checklist is a separate user-provided index. It is NOT the
/// same numbering as MM-Pxx and MM-Rxx in the scanned material registry.
/// Never treat a missing predicate as a successful compatibility test.
class Marriage43RuleResult {
  final int number;
  final String title;
  final bool evaluated;
  final bool? favourable;
  final String examination;
  final String rule;
  final String source;

  const Marriage43RuleResult({
    required this.number,
    required this.title,
    required this.evaluated,
    required this.favourable,
    required this.examination,
    required this.rule,
    required this.source,
  });
}

class Marriage43RuleEngine {
  // Positions in the 27-star list agree with the documented printed material
  // registry. Centralise classifications in MarriagePrintedTableEngine to
  // prevent the duplicated-Makha/missing-Pubba error in the pasted widget.
  static const titles = <String>[
    'జనన దశా–భుక్తి సంబంధం',
    'ప్రస్తుత దశా–భుక్తి సంబంధం',
    'కుజ దోష పరిశీలన (D1/D7)',
    'షష్టాష్టక సంబంధం (చంద్రరాశులు)',
    'ద్విర్ద్వాదశ సంబంధం (చంద్రరాశులు)',
    'వేధ నక్షత్రాలు',
    'నాడీ కూటము',
    'రజ్జు కూటము',
    'భూత/ఘాత కూటము — మూల నిర్ధారణ అవసరం',
    ...<String>[
      '7వ భావం / అధిపతి — పూర్తి షరతు లేదు',
      '7వ భావం / అధిపతి — పూర్తి షరతు లేదు',
      '7వ భావం / అధిపతి — పూర్తి షరతు లేదు',
      '7వ భావం / అధిపతి — పూర్తి షరతు లేదు',
      '7వ భావం / అధిపతి — పూర్తి షరతు లేదు',
      '7వ భావం / అధిపతి — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'D1 / D7 / D9 / D30 — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'సబ్‌లార్డ్ / గ్రహ సంబంధం — పూర్తి షరతు లేదు',
      'అదనపు పొంతన నియమం — పూర్తి షరతు లేదు',
      'అదనపు పొంతన నియమం — పూర్తి షరతు లేదు',
      'అదనపు పొంతన నియమం — పూర్తి షరతు లేదు',
      'అదనపు పొంతన నియమం — పూర్తి షరతు లేదు',
      'అదనపు పొంతన నియమం — పూర్తి షరతు లేదు',
      'అదనపు పొంతన నియమం — పూర్తి షరతు లేదు',
      'అదనపు పొంతన నియమం — పూర్తి షరతు లేదు',
      'అదనపు పొంతన నియమం — పూర్తి షరతు లేదు',
    ],
  ];

  static List<Marriage43RuleResult> evaluate({
    required AstroChartResult groom,
    required AstroChartResult bride,
  }) {
    final groomMoon = MarriagePrintedTableEngine.planet(groom, 'Moon');
    final brideMoon = MarriagePrintedTableEngine.planet(bride, 'Moon');
    final groomStar = MarriagePrintedTableEngine.star(groom);
    final brideStar = MarriagePrintedTableEngine.star(bride);
    final results = <Marriage43RuleResult>[];

    for (var n = 1; n <= 43; n++) {
      bool evaluated = false;
      bool? favourable;
      var examination = 'మూల కోడ్‌లో పూర్తి IF–THEN predicate లేదు. జాతకాన్ని పరీక్షించినట్లు లెక్కించలేదు.';
      var rule = 'నియమ ID మాత్రమే అందింది. సరైన మూల సూత్రం, చక్రం, సంబంధం, మినహాయింపులు నిర్ధారణ కావాలి.';
      var source = 'యూజర్ అందించిన 43 నియమాల ముసాయిదా';
      if (n == 4 || n == 5) {
        if (groomMoon != null && brideMoon != null) {
          final forward = ((brideMoon.signIndex - groomMoon.signIndex + 12) % 12) + 1;
          final backward = ((groomMoon.signIndex - brideMoon.signIndex + 12) % 12) + 1;
          final relation = n == 4
              ? (forward == 6 && backward == 8) || (forward == 8 && backward == 6)
              : (forward == 2 && backward == 12) || (forward == 12 && backward == 2);
          evaluated = true;
          favourable = !relation;
          final names = MarriagePrintedTableEngine.signs;
          examination = 'వరుడు చంద్రరాశి ${names[groomMoon.signIndex]}, '
              'వధువు చంద్రరాశి ${names[brideMoon.signIndex]}. '
              'పరస్పర రాశి స్థానాలు $forward / $backward. '
              '${relation ? 'సూచించిన సంబంధం గుర్తించబడింది.' : 'సూచించిన సంబంధం గుర్తించబడలేదు.'}';
          rule = n == 4
              ? 'చంద్రరాశుల పరస్పర దూరం 6/8 అయితే షష్టాష్టక హెచ్చరిక. దోషభంగం, ఇతర కూటాలు విడిగా పరిశీలించాలి.'
              : 'చంద్రరాశుల పరస్పర దూరం 2/12 అయితే ద్విర్ద్వాదశ హెచ్చరిక. ఇతర ప్రమాణాలతో కలిపి చూడాలి.';
        } else {
          examination = 'ఇద్దరి చంద్రస్థితులు అందుబాటులో లేవు.';
        }
      } else if (n == 6 || n == 7 || n == 8) {
        final id = n == 6 ? 'MM-P03-S06' : n == 7 ? 'MM-P04-S07' : 'MM-P04-S08';
        final r = MarriagePrintedTableEngine.evaluate(id, groom, bride);
        examination = r.examination;
        rule = r.sourceRule;
        source = 'marriage my meterial.pdf • $id';
        // The Vedha source supports an adverse HIT only, not an automatic
        // favourable verdict for a missing hit. Keep this distinct from Nadi.
        evaluated = groomStar != null && brideStar != null;
        favourable = r.favourable;
      } else if (n == 3) {
        rule = 'D7 కుజస్థానం/దృష్టి source rules R01–R03 వేరుగా నమోదయ్యాయి. '
            'మాత్రమే “కుజ దోషం yes/no” అని manually ఇవ్వడం సరిపోదు; D1/D7 మరియు దోషభంగం అవసరం.';
      } else if (n == 9) {
        rule = 'మూల ముసాయిదాలో ఘాత కూటము, printed sourceలో భూత కూటము వేరు. '
            'పూర్తి మూలనిర్ణయం లేకుండా ఒకే నియమంగా auto-check చేయకూడదు.';
      }
      results.add(Marriage43RuleResult(
        number: n,
        title: titles[n - 1],
        evaluated: evaluated,
        favourable: favourable,
        examination: examination,
        rule: rule,
        source: source,
      ));
    }
    return results;
  }
}
