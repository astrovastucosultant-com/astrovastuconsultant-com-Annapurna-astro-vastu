import 'd10_final_profession_engine.dart';

/// Build118: concrete examples for profession *families* already selected by
/// the D10 engine. These are practical choices derived from a selected family;
/// they are NOT additional source-text yogas or guaranteed profitable ventures.
class D10BusinessIdea {
  final String nameTe;
  final String professionFamily;
  final int evidenceMatchPercent;
  final String natureCompatibility;
  final List<String> matchedEvidence;
  final String caution;

  const D10BusinessIdea({
    required this.nameTe,
    required this.professionFamily,
    required this.evidenceMatchPercent,
    required this.natureCompatibility,
    required this.matchedEvidence,
    required this.caution,
  });
}

class D10BusinessCatalog {
  D10BusinessCatalog._();

  /// Keep example options under their source profession family. No independent
  /// business "score" is assigned to an option: it inherits only the family's
  /// existing D10 evidence-coverage percentage. The UI MUST NOT label this
  /// number as a per-business match or predicted profitability.
  static const Map<String, List<String>> optionsByFamily = {
    'Fashion / Beauty / Creative Design': [
      'బట్టల బుటిక్ / డిజైనర్ దుస్తులు',
      'బ్యూటీ పార్లర్ / మేకప్ స్టూడియో',
      'ఫ్యాషన్ డిజైన్ / టైలరింగ్ యూనిట్',
      'కాస్మెటిక్స్ / ఫ్యాషన్ యాక్సెసరీస్ స్టోర్',
    ],
    'Music / Arts / Performance': [
      'సంగీత / నృత్య శిక్షణ కేంద్రం',
      'మ్యూజిక్ రికార్డింగ్ / ఆడియో స్టూడియో',
      'కళా కార్యక్రమాల నిర్వహణ సంస్థ',
    ],
    'Banking / Finance': [
      'బుక్‌కీపింగ్ / ఆర్థిక రికార్డు సేవలు',
      'ఆర్థిక ప్రణాళిక / సలహా సేవలు (అవసరమైన అనుమతులతో)',
      'పేమెంట్ / బిల్లింగ్ సేవల కేంద్రం',
    ],
    'Commercial / Business / Entrepreneurship': [
      'రిటైల్ దుకాణం / ట్రేడింగ్',
      'హోల్‌సేల్ / డిస్ట్రిబ్యూషన్',
      'ఈ-కామర్స్ / ఆన్‌లైన్ స్టోర్',
      'సేల్స్ / మార్కెటింగ్ ఏజెన్సీ',
    ],
    'Accounting / Audit / Tax': [
      'అకౌంటింగ్ / బుక్‌కీపింగ్ సేవలు',
      'GST / టాక్స్ ఫైలింగ్ సేవలు (అర్హతలకు లోబడి)',
      'పేరోల్ / వ్యాపార రికార్డు నిర్వహణ',
    ],
    'IT / Software / Data': [
      'సాఫ్ట్‌వేర్ డెవలప్‌మెంట్ సంస్థ',
      'వెబ్‌సైట్ / మొబైల్ యాప్ డెవలప్‌మెంట్',
      'డేటా అనలిటిక్స్ / ఐటీ సపోర్ట్ సేవలు',
    ],
    'Engineering / Technical': [
      'టెక్నికల్ డిజైన్ / ఇంజినీరింగ్ సేవలు',
      'ఎలక్ట్రికల్ / మెకానికల్ సర్వీస్ కేంద్రం',
      'ఇంజినీరింగ్ పరికరాల సరఫరా',
    ],
    'Electronics / Communication Technology': [
      'ఎలక్ట్రానిక్స్ రిపేర్ / సర్వీస్',
      'కమ్యూనికేషన్ పరికరాల వ్యాపారం',
      'ఎలక్ట్రానిక్ ఉపకరణాల ఇన్‌స్టాలేషన్',
    ],
    'Architecture / Design': [
      'ఆర్కిటెక్చర్ / డిజైన్ స్టూడియో (అర్హతలకు లోబడి)',
      'ఇంటీరియర్ డిజైన్ / డెకరేషన్ సేవలు',
      'డ్రాయింగ్ / 3D మోడలింగ్ సేవలు',
    ],
    'Teaching / Education': [
      'ట్యూషన్ / కోచింగ్ సెంటర్',
      'ఆన్‌లైన్ విద్య / కోర్సుల సంస్థ',
      'నైపుణ్య శిక్షణ కేంద్రం',
    ],
    'Medicine / Healthcare': [
      'ఆరోగ్య సేవల కేంద్రం (తప్పనిసరి అర్హతలు / అనుమతులతో)',
      'వైద్య పరికరాల సరఫరా',
      'ఆరోగ్య సమాచార / పరిపాలనా సేవలు',
    ],
    'Law / Judiciary / Compliance': [
      'న్యాయ సేవలు (అవసరమైన అర్హతలతో)',
      'కంప్లయన్స్ / డాక్యుమెంట్ మేనేజ్‌మెంట్',
      'వ్యాపార నియంత్రణల కన్సల్టెన్సీ',
    ],
    'Consulting / Advisory': [
      'స్వతంత్ర బిజినెస్ కన్సల్టెన్సీ',
      'ప్రాజెక్ట్ / మేనేజ్‌మెంట్ సలహా సేవలు',
      'కార్పొరేట్ శిక్షణ / మార్గదర్శకత్వం',
    ],
    'Hospitality / Food / Nutrition': [
      'రెస్టారెంట్ / టిఫిన్ సెంటర్',
      'కేటరింగ్ / ఫుడ్ డెలివరీ',
      'బేకరీ / ఫుడ్ ప్రాసెసింగ్',
    ],
    'Travel / Tourism / Logistics': [
      'ట్రావెల్ ఏజెన్సీ / టూర్ ప్లానింగ్',
      'రవాణా / లాజిస్టిక్స్ సేవలు',
      'టూరిజం సర్వీస్ నిర్వహణ',
    ],
    'Import / Export / Foreign Relations': [
      'దిగుమతి / ఎగుమతి వ్యాపారం (అనుమతులతో)',
      'ఎక్స్‌పోర్ట్ సోర్సింగ్ / ట్రేడ్ ఏజెన్సీ',
      'అంతర్జాతీయ లాజిస్టిక్స్ సేవలు',
    ],
    'Journalism / Writing / Media': [
      'డిజిటల్ మీడియా / కంటెంట్ స్టూడియో',
      'పబ్లిషింగ్ / ఎడిటింగ్ సంస్థ',
      'ప్రకటనలు / మీడియా సేవలు',
    ],
    'Communication / Languages': [
      'అనువాద / భాషా శిక్షణ సేవలు',
      'కంటెంట్ / కమ్యూనికేషన్ ఏజెన్సీ',
      'డిజిటల్ మార్కెటింగ్ / కమ్యూనికేషన్ సేవలు',
    ],
    'Manufacturing / Industry / Skilled Technical Work': [
      'చిన్న తయారీ పరిశ్రమ / వర్క్‌షాప్',
      'టెక్నికల్ స్పేర్ పార్ట్స్ తయారీ',
      'మెయింటెనెన్స్ / ఇండస్ట్రియల్ సర్వీసులు',
    ],
    'Aviation / Transport': [
      'రవాణా / ఫ్లీట్ నిర్వహణ',
      'ట్రాన్స్‌పోర్ట్ బుకింగ్ / లాజిస్టిక్స్',
      'విమానయాన సంబంధిత గ్రౌండ్ సేవలు (అనుమతులతో)',
    ],
    'Agriculture / Environment / Natural Resources': [
      'వ్యవసాయ ఉత్పత్తుల వ్యాపారం',
      'వ్యవసాయ పరికరాల / ఇన్‌పుట్స్ సరఫరా',
      'ఫార్మ్ మేనేజ్‌మెంట్ / సేవలు',
    ],
    'Occult / Astrology / Traditional Studies': [
      'జ్యోతిష్య / సంప్రదాయ కన్సల్టెన్సీ',
      'జ్యోతిష్య విద్య / కోర్సులు',
      'సంప్రదాయ ప్రచురణ / డిజిటల్ సేవలు',
    ],
    'Government / Administration': [
      'ప్రాజెక్ట్ నిర్వహణ / పరిపాలనా సేవలు',
      'డాక్యుమెంటేషన్ / ప్రక్రియ కన్సల్టెన్సీ',
    ],
    'Management / High Position': [
      'మేనేజ్‌మెంట్ కన్సల్టెన్సీ',
      'ఆపరేషన్స్ / సంస్థ నిర్వహణ సేవలు',
    ],
    'Research / R&D / Investigation': [
      'పరిశోధన / టెస్టింగ్ సేవలు',
      'మార్కెట్ రిసెర్చ్ / డేటా సేవలు',
    ],
    'Defence / Police / Security': [
      'సెక్యూరిటీ సేవల సంస్థ (లైసెన్సుతో)',
      'భద్రతా పరికరాల సరఫరా',
    ],
    'Social / Community Service': [
      'సామాజిక శిక్షణ / సహాయక సేవలు',
      'కమ్యూనిటీ ప్రాజెక్ట్ నిర్వహణ',
    ],
  };

  static List<D10BusinessIdea> suggest(List<D10ProfessionCandidate> candidates) {
    final result = <D10BusinessIdea>[];
    final seen = <String>{};
    for (final candidate in candidates) {
      final options = optionsByFamily[candidate.profession] ?? const <String>[];
      for (final title in options) {
        if (!seen.add(title)) continue;
        result.add(D10BusinessIdea(
          nameTe: title,
          professionFamily: candidate.profession,
          evidenceMatchPercent: candidate.evidenceMatchPercent,
          natureCompatibility: candidate.natureCompatibility,
          matchedEvidence: candidate.matchedEvidence,
          caution: 'ఇది ${candidate.profession} రంగానికి చెందిన ఆచరణాత్మక వ్యాపార ఎంపిక. '
              'అర్హతలు, పెట్టుబడి, మార్కెట్ డిమాండ్, అనుమతులు విడిగా పరిశీలించాలి.',
        ));
      }
    }
    return List<D10BusinessIdea>.unmodifiable(result);
  }
}
