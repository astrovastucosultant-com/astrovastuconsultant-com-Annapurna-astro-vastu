import 'jaimini_rule_audit_registry.dart';

/// Explicit, auditable condition evaluation. Source texts and their conditions
/// must be independently verified before a rule may be published.
enum JaiminiConditionOperator { equals, contains, atLeast, atMost, isTrue }

class JaiminiChartCondition {
  final String evidenceKey;
  final JaiminiConditionOperator operator;
  final Object? expected;
  const JaiminiChartCondition(this.evidenceKey, this.operator, this.expected);
}

class JaiminiEvaluatedRule {
  final JaiminiRuleAuditRecord source;
  final List<JaiminiChartCondition> conditions;
  final List<JaiminiChartCondition> exceptions;
  const JaiminiEvaluatedRule({required this.source, required this.conditions,
    this.exceptions = const []});
}

class JaiminiMatchAudit {
  final JaiminiRuleAuditRecord rule;
  final bool matched;
  final List<String> matchedEvidence;
  final List<String> failures;
  const JaiminiMatchAudit(this.rule, this.matched, this.matchedEvidence, this.failures);
}

class JaiminiConditionMatcher {
  const JaiminiConditionMatcher();

  bool _test(JaiminiChartCondition c, Map<String, Object?> facts) {
    if (!facts.containsKey(c.evidenceKey)) return false;
    final actual = facts[c.evidenceKey];
    switch (c.operator) {
      case JaiminiConditionOperator.equals:
        return actual == c.expected;
      case JaiminiConditionOperator.contains:
        return actual is Iterable && actual.contains(c.expected);
      case JaiminiConditionOperator.atLeast:
        return actual is num && c.expected is num && actual >= (c.expected as num);
      case JaiminiConditionOperator.atMost:
        return actual is num && c.expected is num && actual <= (c.expected as num);
      case JaiminiConditionOperator.isTrue:
        return actual == true;
    }
  }

  JaiminiMatchAudit evaluate(JaiminiEvaluatedRule input,
      Map<String, Object?> chartFacts) {
    final failures = <String>[];
    final evidence = <String>[];
    if (!input.source.hasTraceableSource ||
        input.source.status != JaiminiVerificationStatus.verified) {
      failures.add('Primary source not verified');
    }
    if (input.conditions.isEmpty || input.source.mandatoryConditions.isEmpty ||
        input.conditions.length != input.source.mandatoryConditions.length) {
      failures.add('Mandatory conditions missing or not fully mapped');
    }
    if (input.exceptions.length != input.source.exceptionConditions.length) {
      failures.add('Exceptions not fully mapped');
    }
    for (final condition in input.conditions) {
      if (!_test(condition, chartFacts)) {
        failures.add('Condition not satisfied: ${condition.evidenceKey}');
      } else {
        evidence.add('${condition.evidenceKey}: ${chartFacts[condition.evidenceKey]}');
      }
    }
    for (final exception in input.exceptions) {
      if (_test(exception, chartFacts)) {
        failures.add('Exception activated: ${exception.evidenceKey}');
      }
    }
    return JaiminiMatchAudit(input.source, failures.isEmpty, evidence, failures);
  }
}
