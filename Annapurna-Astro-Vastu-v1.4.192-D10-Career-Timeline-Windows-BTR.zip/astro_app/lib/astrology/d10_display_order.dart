import 'd10_profession_registry.dart';
import 'd10_vrutti_match_engine.dart';

/// Presentation only. Never turns partial evidence into a D1->D10 confirmation.
enum D10EvidenceTier { green, pink, grey }

class D10DisplayEntry {
  final D10VruttiMatch? ruleMatch;
  final D10ProfessionRule? legacy;
  final List<D10VruttiMatch> linked;

  const D10DisplayEntry.rule(D10VruttiMatch match)
      : ruleMatch = match, legacy = null, linked = const <D10VruttiMatch>[];
  const D10DisplayEntry.old(D10ProfessionRule rule,
      List<D10VruttiMatch> matches)
      : legacy = rule, ruleMatch = null, linked = matches;

  String get id => ruleMatch?.rule.id ?? legacy!.id;
  String get profession => ruleMatch?.rule.profession ?? legacy!.name;
  D10VruttiMatch? get evidence =>
      ruleMatch ?? D10DisplayOrder.strongest(linked);
  bool get missingRule => legacy != null && linked.isEmpty;
  D10EvidenceTier get tier => D10DisplayOrder.tier(evidence,
      missingRule: missingRule);
}

class D10DisplayOrder {
  /// Green: D1->D10 confirmed with a calculated percentage (including partial
  /// IF-THEN coverage). Pink: supporting clues or an unlinked source awaiting
  /// rule verification. Grey: no matching evidence. Pink never earns a %.
  static D10EvidenceTier tier(D10VruttiMatch? match,
      {bool missingRule = false}) {
    if (match?.confirmed == true) return D10EvidenceTier.green;
    if (missingRule || (match != null && match.passed.isNotEmpty)) {
      return D10EvidenceTier.pink;
    }
    return D10EvidenceTier.grey;
  }

  static int compareEvidence(D10VruttiMatch? a, D10VruttiMatch? b,
      {bool missingRuleA = false, bool missingRuleB = false,
       int relevanceA = 0, int relevanceB = 0,
       String idA = '', String idB = ''}) {
    final ta = tier(a, missingRule: missingRuleA);
    final tb = tier(b, missingRule: missingRuleB);
    if (ta != tb) return ta.index.compareTo(tb.index);
    if (ta == D10EvidenceTier.green) {
      final pct = (b?.percent ?? 0).compareTo(a?.percent ?? 0);
      if (pct != 0) return pct;
    }
    if (ta == D10EvidenceTier.pink) {
      final clues = (b?.passed.length ?? 0).compareTo(a?.passed.length ?? 0);
      if (clues != 0) return clues;
    }
    final relevance = relevanceB.compareTo(relevanceA);
    if (relevance != 0) return relevance;
    return idA.compareTo(idB);
  }

  static D10VruttiMatch? strongest(Iterable<D10VruttiMatch> matches) {
    final candidates = matches.toList(growable: false);
    if (candidates.isEmpty) return null;
    final ordered = candidates.toList()..sort((a, b) => compareEvidence(a, b,
        idA: a.rule.id, idB: b.rule.id));
    return ordered.first;
  }

  static List<D10DisplayEntry> sort(Iterable<D10DisplayEntry> source) {
    final entries = source.toList();
    entries.sort((a, b) => compareEvidence(a.evidence, b.evidence,
        missingRuleA: a.missingRule, missingRuleB: b.missingRule,
        idA: a.id, idB: b.id));
    return entries;
  }
}
