import 'jaimini_period_result_gate.dart';
import 'jaimini_rule_audit_registry.dart';

/// Input is calculated by the existing chart, arudha, argala and dasha engines.
/// This adapter never manufactures an astrological match or a date.
enum JaiminiPeriodLevel { maha, antara, pratyantara, prana, daily }

class JaiminiPeriodEvidence {
  final JaiminiPeriodLevel level;
  final DateTime start;
  final DateTime end;
  final List<String> activeSigns;
  final Set<String> activatedRuleIds;
  final Map<String, List<String>> evidenceByRuleId;
  final Set<String> transitSupportedRuleIds;

  const JaiminiPeriodEvidence({required this.level, required this.start,
    required this.end, required this.activeSigns,
    required this.activatedRuleIds, required this.evidenceByRuleId,
    this.transitSupportedRuleIds = const {}});
}

class JaiminiMultilevelPrediction {
  static List<JaiminiPeriodResult> evaluate({
    required Iterable<JaiminiRuleAuditRecord> verifiedRuleCandidates,
    required Map<String, String> topics,
    required Map<String, String> teluguResults,
    required JaiminiPeriodEvidence period,
  }) {
    if (!period.start.isBefore(period.end) || period.activeSigns.isEmpty) {
      return const [];
    }
    // A day-level claim requires independent, calculated transit/timing evidence.
    final ids = period.level == JaiminiPeriodLevel.daily
        ? period.activatedRuleIds.intersection(period.transitSupportedRuleIds)
        : period.activatedRuleIds;
    final evidenceIds = ids.where((id) =>
        period.evidenceByRuleId[id]?.any((e) => e.trim().isNotEmpty) == true).toSet();
    // Period evidence must agree with the independently audited natal evidence.
    // An unrelated MD/AD sign or generic text cannot activate a rule.
    final candidates = verifiedRuleCandidates.where((rule) {
      if (!evidenceIds.contains(rule.ruleId) || !rule.eligibleForVerifiedResult) {
        return false;
      }
      final periodEvidence = period.evidenceByRuleId[rule.ruleId]!
          .map((e) => e.trim()).where((e) => e.isNotEmpty).toSet();
      return periodEvidence.isNotEmpty &&
          rule.chartEvidence.any((e) => periodEvidence.contains(e.trim()));
    });
    return JaiminiPeriodResultGate.select(rules: candidates,
      ruleTopics: topics, ruleTeluguResults: teluguResults,
      periodActivatedRuleIds: evidenceIds,
      periodStart: period.start, periodEnd: period.end);
  }
}
