import 'astro_models.dart';
import 'marriage_chart_evidence_service.dart';
import 'marriage_love_source_engine.dart';
import 'marriage_printed_table_engine.dart';
import 'marriage_rules_ok_registry.dart';
import 'marriage_verified_sutra_engine.dart';
import 'varga_service.dart';

/// Separate a SOURCE INDEX, a computed chart observation, and an actual
/// source-verified IF/THEN verdict. A chart observation must never count as a
/// successful marriage prediction or increase a compatibility percentage.
enum MarriageBookEvaluationStatus {
  missingChart,
  missingPartner,
  sourcePredicatePending,
  chartObserved,
  ruleMatched,
  ruleNotMatched,
}

class MarriageBookEvaluation {
  final MarriageBookEvaluationStatus status;
  final bool? favourable;
  final String title;
  final String result;
  final String rule;
  final String examination;
  final String remedy;
  final List<int> factors;

  const MarriageBookEvaluation({
    required this.status,
    required this.favourable,
    required this.title,
    required this.result,
    required this.rule,
    required this.examination,
    required this.remedy,
    required this.factors,
  });

  bool get decisive => status == MarriageBookEvaluationStatus.ruleMatched ||
      status == MarriageBookEvaluationStatus.ruleNotMatched;
  bool get hasChartObservation => status == MarriageBookEvaluationStatus.chartObserved || decisive;
}

class MarriageBookRuleEngine {
  static const _noRemedy = 'ఈ మూల పేజీలో నిర్ధారించిన పరిహారం ఈ నియమంతో నమోదు కాలేదు. ఊహించి పరిహారం ఇవ్వము.';
  static const _noVerdict = 'ఇక్కడ చూపిన గ్రహస్థితులు జాతక ఆధారాలు మాత్రమే; పూర్తి మూల IF–THEN షరతులు, మినహాయింపులు ధృవీకరించకుండా వివాహ ఫలితం నిర్ణయించము.';

  /// Factors for each of the 62 *topic IDs*. No inference from mere page
  /// availability. Items not explicitly routed fall back to D1 and D9 review.
  static List<int> factorsFor(MarriageBookTopic topic) {
    const d7 = {'M-15','M-16','M-17','M-18','M-26','M-30','M-34','M-36','M-41'};
    const d9 = {'M-03','M-04','M-06','M-25','M-38','M-43'};
    const d1 = {'M-01','M-07','M-11','M-12','M-13','M-14','M-20','M-24',
      'M-29','M-32','M-33','M-37','M-46','M-50','M-51','M-53',
      'N-01','N-02','N-03','N-04','N-05','N-06','N-07','N-08','N-09'};
    if (topic.id == 'M-07' || topic.id == 'M-08') return const [1,9];
    if (topic.id == 'M-48') return const [9,30];
    if (topic.id == 'M-49') return const [1,7,9];
    if (topic.id == 'M-52') return const [1,7,9];
    if (topic.id == 'N-03') return const [7];
    if (d7.contains(topic.id)) return const [7];
    if (d9.contains(topic.id)) return const [9];
    if (d1.contains(topic.id)) return const [1];
    return const [1,9];
  }

  /// Returns selected evidence, not an invented rule match.
  static String _observations(AstroChartResult chart, List<int> factors,
      MarriageBookTopic topic) {
    final buffer = StringBuffer();
    for (final factor in factors) {
      final v = VargaService.calculate(chart, factor);
      final asc = v.ascendantSignIndex;
      final seventh = (asc + 6) % 12;
      final seventhLord = MarriageChartEvidenceService.lords[seventh];
      final fifthLord = MarriageChartEvidenceService.lords[(asc + 4) % 12];
      final venus = _placement(v, 'Venus');
      final jupiter = _placement(v, 'Jupiter');
      final moon = _placement(v, 'Moon');
      buffer.writeln('D$factor లగ్నం: ${MarriageChartEvidenceService.signs[asc]} • '
          '7వ భావం: ${MarriageChartEvidenceService.signs[seventh]} • '
          '7వ అధిపతి: ${_telugu(seventhLord)} (${_house(v,seventhLord)})');
      buffer.writeln('5వ అధిపతి: ${_telugu(fifthLord)} (${_house(v,fifthLord)}) • '
          'శుక్రుడు: ${_houseByPlacement(v,venus)} • '
          'గురువు: ${_houseByPlacement(v,jupiter)} • '
          'చంద్రుడు: ${_houseByPlacement(v,moon)}');
      if (topic.id == 'M-04') {
        final upachaya = v.planets.where((p) =>
          const {3,6,10,11}.contains(((p.signIndex - asc + 12) % 12) + 1));
        buffer.writeln('ఉపచయ (3/6/10/11) స్థానాల్లో: '
            '${upachaya.isEmpty ? "గ్రహాలు లేవు" : upachaya.map((p)=>"${_telugu(p.name)} (${((p.signIndex-asc+12)%12)+1})").join(", ")}');
      }
      if (topic.id == 'M-17' || topic.id == 'M-52') {
        buffer.writeln('కుజుడు: ${_house(v,'Mars')} • శని: ${_house(v,'Saturn')}');
      }
    }
    return buffer.toString().trimRight();
  }

  static String _telugu(String name) =>
      MarriageChartEvidenceService.planetNames[name] ?? name;
  static VargaPlacement? _placement(VargaChartData chart, String name) {
    for (final planet in chart.planets) {
      if (planet.name == name) return planet;
    }
    return null;
  }
  static String _houseByPlacement(VargaChartData v, VargaPlacement? planet) =>
      planet == null ? 'డేటా లేదు' :
          '${((planet.signIndex - v.ascendantSignIndex + 12) % 12) + 1}వ భావం';
  static String _house(VargaChartData v, String name) =>
      _houseByPlacement(v, _placement(v, name));

  static MarriageBookEvaluation evaluate(
    MarriageBookTopic topic, {
    AstroChartResult? chart,
    AstroChartResult? partnerChart,
  }) {
    final factors = factorsFor(topic);
    final ruleReference = 'మూలం: ${topic.title}. అధ్యయన అంశం: ${topic.focus}. '
        'అసలు పుట ${topic.page}ను పరిశీలించి అన్ని ఉపషరతులు, దోషభంగాలు, '
        'గ్రహసంబంధ నిర్వచనాలు నిర్ధారించాలి.';
    MarriageBookEvaluation pending(MarriageBookEvaluationStatus status,
        String result, String examination, {String? rule}) {
      return MarriageBookEvaluation(
        status: status, favourable: null, title: topic.title,
        result: result, rule: rule ?? ruleReference,
        examination: examination,
        remedy: _noRemedy, factors: factors,
      );
    }
    if (chart == null) {
      return pending(MarriageBookEvaluationStatus.missingChart,
        'ముందుగా జాతకం తెరవండి — ఈ సూచిక ఇంకా గణన చేయలేదు.',
        'D${factors.join("/D")} చక్రాన్ని Generate / Saved Chart నుంచి తెరవాలి.');
    }
    final first = _observations(chart, factors, topic);
    if (topic.requiresTwoCharts && partnerChart == null) {
      return pending(MarriageBookEvaluationStatus.missingPartner,
        'రెండో జాతకం అవసరం — పొంతనలో జాతకాలను ఎంపిక చేయండి.',
        'మొదటి జాతకం:\n$first\n\nవరుడు–వధువు రెండు జాతకాలు లేకుండా కూట ఫలితం ప్రకటించము.');
    }
    final evidence = topic.requiresTwoCharts
        ? 'మొదటి జాతకం:\n$first\n\nరెండో జాతకం:\n${_observations(partnerChart!,factors,topic)}'
        : first;
    if (topic.id == 'M-07' || topic.id == 'M-08') {
      final source = MarriageLoveSourceEngine.evaluate(topic.id, chart);
      if (!source.evaluated) {
        return pending(MarriageBookEvaluationStatus.sourcePredicatePending,
          source.summary, '$evidence\n\n${source.evidence}', rule: source.sourceRule);
      }
      if (source.matched) {
        return MarriageBookEvaluation(
          status: MarriageBookEvaluationStatus.ruleMatched,
          favourable: true, title: topic.title,
          result: source.summary, rule: source.sourceRule,
          examination: '$evidence\n\n${source.evidence}',
          remedy: _noRemedy, factors: factors,
        );
      }
      // These are four explicitly tested relationship types, NOT the exhaustive
      // definition of "any relationship" in the original Telugu source.
      return pending(MarriageBookEvaluationStatus.chartObserved,
        source.summary, '$evidence\n\n${source.evidence}',
        rule: source.sourceRule);
    }
    if (topic.id == 'N-03') {
      // Exact D7 source p35: Mars in 2/4/7/8/12 and contact from
      // Moon/Jupiter/Saturn. Match denotes a *warning subcondition*, never
      // a complete Manglik marriage verdict or a numerical risk estimate.
      final warnings = <String>[];
      final checked = <String>[];
      for (final entry in <({String label, AstroChartResult birth})>[
        (label: 'మొదటి జాతకం', birth: chart),
        (label: 'రెండో జాతకం', birth: partnerChart!),
      ]) {
        for (final id in const ['MM-P02-R01','MM-P02-R02','MM-P02-R03']) {
          final match = MarriagePrintedTableEngine.evaluate(id,entry.birth,entry.birth);
          checked.add('${entry.label} $id: ${match.examination}');
          if (match.favourable == false) warnings.add('${entry.label} $id');
        }
      }
      if (warnings.isNotEmpty) {
        return MarriageBookEvaluation(
          status: MarriageBookEvaluationStatus.ruleNotMatched,
          favourable: false, title: topic.title,
          result: 'D7 కుజ సంబంధ హెచ్చరిక ఉపషరతు సరిపోయింది (${warnings.length}). '
              'దోషభంగం, D1/D9 పరిశీలన ఇంకా అవసరం.',
          rule: 'పుట 35, సూత్రం 03 (R01–R03): D7 కుజుడు 2,4,7,8,12లో ఉండి '
              'చంద్రుడు, గురువు లేదా శని యుతి/దృష్టి పొందడం. '
              'ఇది ఒక్కటే వివాహ పొంతన తుది నిర్ణయం కాదు.',
          examination: '$evidence\n\n${checked.join("\n")}',
          remedy: _noRemedy, factors: factors,
        );
      }
      return pending(MarriageBookEvaluationStatus.chartObserved,
          'చూసిన మూడు D7 కుజ సంబంధ హెచ్చరికలు గుర్తించబడలేదు; దోషం లేదని తుది తీర్పు కాదు.',
          '$evidence\n\n${checked.join("\n")}',
          rule: 'పుట 35, సూత్రం 03: D7 కుజుడు 2,4,7,8,12లో చంద్రుడు/గురువు/శని సంబంధం. '
              'ఇతర కుజదోష నియమాలు మరియు దోషభంగం ఇంకా పరిశీలించాలి.');
    }
    if (topic.id == 'N-04') {
      // Source p35 rule 04 pairs; inspect *both* Lagna and Moon as the
      // explicit source note requires. An isolated pair is not a total verdict.
      final other = partnerChart!;
      final firstMoon = MarriagePrintedTableEngine.planet(chart, 'Moon');
      final otherMoon = MarriagePrintedTableEngine.planet(other, 'Moon');
      final checks = <String>[];
      var adverse = false;
      void inspect(String label,int a,int b) {
        final good = MarriagePrintedTableEngine.goodPairs.any(
            (pair) => MarriagePrintedTableEngine.matches(pair,a,b));
        final bad = MarriagePrintedTableEngine.badPairs.any(
            (pair) => MarriagePrintedTableEngine.matches(pair,a,b));
        if (bad) adverse = true;
        checks.add('$label: ${MarriagePrintedTableEngine.signs[a]} / '
            '${MarriagePrintedTableEngine.signs[b]} — '
            '${bad ? "అశుభ జంట" : good ? "శుభ జంట" : "పట్టికలో జంట లేదు"}');
      }
      inspect('D1 లగ్నాలు',chart.ascendantSignIndex,other.ascendantSignIndex);
      if (firstMoon != null && otherMoon != null) {
        inspect('చంద్రరాశులు',firstMoon.signIndex,otherMoon.signIndex);
      } else {
        checks.add('చంద్రరాశులు: ఒకటి లేదా రెండు జాతకాల చంద్రస్థితి లేదు');
      }
      const rule = 'పుట 35, సూత్రం 04: శుభ/అశుభ షష్టాష్టక రాశి జంటల '
          'మూల పట్టిక. గమనిక: లగ్నమూ, చంద్రుడూ రెండింటినీ పరిశీలించాలి. '
          'ఒక జంట ఆధారంగా మొత్తం వివాహ ఫలితం ఇవ్వకూడదు.';
      if (adverse) {
        return MarriageBookEvaluation(
          status: MarriageBookEvaluationStatus.ruleNotMatched,
          favourable: false, title: topic.title,
          result: 'మూల పట్టికలో కనీసం ఒక అశుభ షష్టాష్టక జంట గుర్తించబడింది. '
              'ఇతర కూటాలు, దోషభంగం విడిగా పరిశీలించాలి.',
          rule: rule,
          examination: '$evidence\n\n${checks.join("\n")}',
          remedy: _noRemedy, factors: factors,
        );
      }
      return pending(MarriageBookEvaluationStatus.chartObserved,
          'అశుభ పట్టిక జంట గుర్తించబడలేదు; పూర్తి అనుకూల తీర్పు కాదు.',
          '$evidence\n\n${checks.join("\n")}', rule: rule);
    }
    // Explicitly mapped source-backed, two-chart conditions. Do NOT silently
    // promote other 59 subject headings to matched/failed status.
    final printedId = switch (topic.id) {
      'M-53' || 'N-07' => 'MM-P04-S07',
      'N-08' => 'MM-P04-S08',
      'N-06' => 'MM-P03-S06',
      _ => null,
    };
    if (printedId != null) {
      final result = MarriagePrintedTableEngine.evaluate(printedId, chart, partnerChart!);
      final enoughMoon = MarriagePrintedTableEngine.star(chart) != null &&
          MarriagePrintedTableEngine.star(partnerChart) != null;
      if (!enoughMoon) {
        return pending(MarriageBookEvaluationStatus.sourcePredicatePending,
          'చంద్రనక్షత్ర డేటా లేకుండా కూట పరిశీలన పూర్తి కాదు.', evidence,
          rule: result.sourceRule);
      }
      if (result.favourable != null) {
        return MarriageBookEvaluation(
          status: result.favourable!
              ? MarriageBookEvaluationStatus.ruleMatched
              : MarriageBookEvaluationStatus.ruleNotMatched,
          favourable: result.favourable,
          title: topic.title,
          result: result.favourable!
              ? 'ఈ పట్టిక షరతు సరిపోయింది — ఇతర కూటాలు విడిగా చూడాలి.'
              : 'ఈ పట్టికలో హెచ్చరిక షరతు కనిపించింది — దోషభంగం పరిశీలించాలి.',
          rule: result.sourceRule,
          examination: '$evidence\n\nమూల పట్టిక గణన:\n${result.examination}',
          remedy: _noRemedy, factors: factors,
        );
      }
      return pending(MarriageBookEvaluationStatus.chartObserved,
        'మూల పట్టికలో ప్రతికూల జంట కనిపించలేదు; అనుకూల తీర్పు మాత్రం నిర్ధారణ కాలేదు.',
        '$evidence\n\n${result.examination}',rule: result.sourceRule);
    }
    // Exact source page 7, Sutra 04: 10th house must contain a planet.
    // This is a computed source subcondition, not a marriage-promise verdict.
    if (topic.id == 'M-04') {
      const source = 'P07-S04';
      final formula = MarriageVerifiedSutraEngine.sutras
          .firstWhere((s) => s.id == source);
      final match = MarriageVerifiedSutraEngine.evaluate(source,chart);
      if (match.computed) {
        return MarriageBookEvaluation(
          status: match.matched ? MarriageBookEvaluationStatus.ruleMatched
              : MarriageBookEvaluationStatus.ruleNotMatched,
          favourable: match.matched,
          title: topic.title, result: match.result,
          rule: formula.sourceCondition,
          examination: '$evidence\n\n${match.evidence}',
          remedy: _noRemedy, factors: factors,
        );
      }
      return pending(MarriageBookEvaluationStatus.chartObserved,
        match.result, '$evidence\n\n${match.evidence}',
        rule: formula.sourceCondition);
    }
    // Topic labels M-19..M-36 are not sufficient input for a timing verdict:
    // the source uses several dasha + transit methods. A birth chart alone
    // does not authorize a year/month/day, much less clock-time.
    if (topic.id.startsWith('M-')) {
      final number = int.tryParse(topic.id.substring(2));
      if (number != null && number >= 19 && number <= 36) {
        return pending(MarriageBookEvaluationStatus.sourcePredicatePending,
          'వివాహ సమయ నిర్ణయం పెండింగ్ — మూల దశా–గోచార విధానాన్ని కలపాలి.',
          '$evidence\n\nసంఘటన సంవత్సరం/మాసం/రోజు నిర్ణయానికి '
          'జనన తేదీ-సమయం/స్థలం, విమ్శోత్తరి లేదా మూలంలో సూచించిన దశా '
          'పద్ధతి, సంబంధిత తేదీల గోచార గణనలు అవసరం. '
          'వాటిని ఈ పేజీలో అమలు చేయలేదు; తేదీలు ఊహించి ఇవ్వలేదు.',
          rule: ruleReference);
      }
    }
    return pending(MarriageBookEvaluationStatus.sourcePredicatePending,
      'జాతక గ్రహస్థితులు గణించబడ్డాయి • పూర్తి మూల IF–THEN ఇంకా పెండింగ్.',
      '$evidence\n\n$_noVerdict');
  }
}
