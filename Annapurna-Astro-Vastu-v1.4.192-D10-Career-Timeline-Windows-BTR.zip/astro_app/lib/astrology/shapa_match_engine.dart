import 'astro_models.dart';
import 'shapa_rule_service.dart';

/// Explicit, auditable traditional-sign rule matching. House calculations
/// use whole-sign houses; aspects are Parashari sign-to-sign graha drishti.
/// No diagnosis of a supernatural curse is implied.
class ShapaAudit {
  final ShapaRule rule;
  final bool? matched; // null = source/inputs insufficient
  final List<String> evidence;
  final String note;
  const ShapaAudit(this.rule,this.matched,this.evidence,this.note);
}

class ShapaMatchEngine {
  static const rulers = <String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  static const signs = <String>[
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];
  static const tel = <String,String>{
    'Sun':'రవి','Moon':'చంద్రుడు','Mars':'కుజుడు',
    'Mercury':'బుధుడు','Jupiter':'గురువు','Venus':'శుక్రుడు',
    'Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు',
  };

  static List<ShapaAudit> evaluate(AstroChartResult chart) {
    final asc=chart.ascendantSignIndex;
    final planets=<String,PlanetPosition>{for(final p in chart.planets) p.name:p};
    // An incomplete ephemeris is not evidence of a negative rule match.
    final requiredBodies=<String>{'Sun','Moon','Mars','Mercury','Jupiter',
      'Venus','Saturn','Rahu','Ketu'};
    final missingBodies=requiredBodies.difference(planets.keys.toSet());
    if(missingBodies.isNotEmpty) {
      return [for(final rule in ShapaRuleService.rules)
        ShapaAudit(rule,null,[],
          'జాతక గణనలో ${missingBodies.join(', ')} స్థానాలు అందుబాటులో లేవు. పూర్తి జాతకం అవసరం.')];
    }
    int signOfHouse(int house)=>(asc+house-1)%12;
    int houseOfSign(int sign)=>((sign-asc+12)%12)+1;
    String lord(int house)=>rulers[signOfHouse(house)];
    String display(String name) {
      final p=planets[name];
      if(p==null)return '$name (స్థానం లేదు)';
      return '${tel[name]??name}: ${signs[p.signIndex]} ${p.degreesInSign.toStringAsFixed(2)}° / ${houseOfSign(p.signIndex)}వ భావం';
    }
    // Traditional movable/fixed/dual badhaka convention: 11/9/7.
    final movable=<int>{0,3,6,9};
    final fixed=<int>{1,4,7,10};
    final badhakaHouse=movable.contains(asc)?11:fixed.contains(asc)?9:7;
    final badhakaSign=signOfHouse(badhakaHouse);
    final badhakaLord=lord(badhakaHouse);
    final audit=<ShapaAudit>[];
    // Only conjunctions and Parashari planetary aspects. Rahu/Ketu aspects
    // vary by tradition; their conjunction is supported, aspects withheld.
    bool aspects(String from,int targetSign) {
      final p=planets[from];
      if(p==null)return false;
      final distance=(targetSign-p.signIndex+12)%12+1;
      if(distance==7)return !{'Rahu','Ketu'}.contains(from);
      if(from=='Mars')return distance==4||distance==8;
      if(from=='Jupiter')return distance==5||distance==9;
      if(from=='Saturn')return distance==3||distance==10;
      return false;
    }
    String? contactDetail(String from,int targetSign,String targetLabel) {
      final p=planets[from];
      if(p==null)return null;
      if(p.signIndex==targetSign) {
        return '${display(from)} — $targetLabel (${signs[targetSign]})తో ఒకే రాశి యుతి';
      }
      if(aspects(from,targetSign)) {
        return '${display(from)} — $targetLabel (${signs[targetSign]})పై గ్రహదృష్టి';
      }
      return null;
    }
    void record(int index, List<String> evidence,{String note=''}) {
      final unique=evidence.toSet().toList();
      audit.add(ShapaAudit(ShapaRuleService.rules[index],unique.isNotEmpty,unique,note));
    }
    List<String> compareTargets(List<String> sources,Map<String,int> targets) {
      final evidence=<String>[];
      for(final source in sources) {
        for(final target in targets.entries) {
          final d=contactDetail(source,target.value,target.key);
          if(d!=null)evidence.add(d);
        }
      }
      return evidence;
    }
    // SH-01: Cancer, Moon, 4H, 4L with Ketu.
    record(0,compareTargets(['Ketu'],{
      'కర్కాటక రాశి':3,
      if(planets['Moon']!=null)'చంద్రుడు':planets['Moon']!.signIndex,
      '4వ భావం':signOfHouse(4),
      if(planets[lord(4)]!=null)'4వ భావాధిపతి ${tel[lord(4)]??lord(4)}':planets[lord(4)]!.signIndex,
    }),note:'కేతు దృష్టి సంప్రదాయ భేదం వల్ల యుతి మాత్రమే పరీక్షించబడుతుంది.');
    // SH-02: named targets and Venus/Mercury/Rahu associations.
    final fatherTargets=<String,int>{'ధనుస్సు రాశి':8};
    if(planets['Jupiter']!=null) fatherTargets['గురువు']=planets['Jupiter']!.signIndex;
    for(final h in [2,5,9,12])fatherTargets['$hవ భావం']=signOfHouse(h);
    record(1,compareTargets(['Venus','Mercury','Rahu'],fatherTargets),
      note:'మూలంలో ప్రత్యామ్నాయ షరతులుగా ఉన్న సంబంధాలను ఒక్కొక్కటిగా చూపిస్తున్నాం; ఇవి శాప నిర్ధారణ కాదు.');
    final femaleTargets=<String,int>{'సింహ రాశి':4,'5వ భావం':signOfHouse(5)};
    if(planets['Sun']!=null)femaleTargets['రవి']=planets['Sun']!.signIndex;
    record(2,compareTargets(['Venus','Saturn','Rahu','Ketu'],femaleTargets));
    // SH-04: badhaka house or lord related to 4H or 4L.
    Map<String,int> houseTargets(int h) => {
      '$hవ భావం':signOfHouse(h),
      if(planets[lord(h)]!=null)'$hవ అధిపతి ${tel[lord(h)]??lord(h)}':planets[lord(h)]!.signIndex,
    };
    List<String> badhakaContacts(Map<String,int> targets) {
      final evidence=compareTargets([badhakaLord],targets);
      for(final t in targets.entries) {
        if(t.value==badhakaSign) {
          evidence.add('${t.key} బాధక భావం (${signs[badhakaSign]}, $badhakaHouseవ భావం)లో ఉంది');
        }
      }
      return evidence.toSet().toList();
    }
    final badhakaNote='లగ్నం ${signs[asc]}; బాధక భావం $badhakaHouse; బాధకాధిపతి ${tel[badhakaLord]??badhakaLord}. సంప్రదాయ Whole-sign / పరాశరి గ్రహదృష్టి విధానం.';
    record(3,badhakaContacts(houseTargets(4)),note:badhakaNote);
    for(final entry in <int,String>{4:'Rahu',5:'Jupiter',7:'Venus',8:'Mars'}.entries) {
      final p=planets[entry.value];
      if(p==null) {
        audit.add(ShapaAudit(ShapaRuleService.rules[entry.key],null,[],
          '${entry.value} స్థానం అందుబాటులో లేదు.'));
      } else {
        record(entry.key,badhakaContacts({
          '${tel[entry.value]??entry.value}':p.signIndex,
        }),note:badhakaNote);
      }
    }
    // SH-07: the source says Sagittarius or Pisces is the badhaka
    // location. Check that literal sign condition; do not add fabricated
    // planetary aspects. This is a broad screening indication only.
    record(6, (badhakaSign==8 || badhakaSign==11)
      ? ['బాధక భావం $badhakaHouse (${signs[badhakaSign]}) — మూలంలోని ధనుస్సు/మీనం షరతుకు సరిపోలింది']
      : [], note:'బాధక భావం రాశి మాత్రమే పరిశీలించబడింది; శాప నిర్ధారణ కాదు. $badhakaNote');
    record(9,badhakaContacts(houseTargets(1)),note:badhakaNote);
    // SH-11: Sun and Mars both in 6H, and 6H/6L badhaka relation.
    final sun=planets['Sun'];final mars=planets['Mars'];
    if(sun==null||mars==null) {
      audit.add(ShapaAudit(ShapaRuleService.rules[10],null,[],
        'రవి/కుజ స్థానం అందుబాటులో లేదు.'));
    } else {
      final both=sun.signIndex==signOfHouse(6)&&mars.signIndex==signOfHouse(6);
      final related=badhakaContacts(houseTargets(6));
      record(10,both&&related.isNotEmpty?[
        '${display('Sun')}; ${display('Mars')} — ఇద్దరూ 6వ భావంలో',...related,
      ]:[],note:'6వ భావంలో రవి+కుజుడు మరియు బాధక సంబంధం రెండూ అవసరం. $badhakaNote');
    }
    audit.add(ShapaAudit(ShapaRuleService.rules[11],null,[],
      'గుళిక గణనకు జన్మస్థల సూర్యోదయం, వారదినం, దిన/రాత్రి కాల విభజన, '
      'సంప్రదాయ గుళిక పద్ధతి అవసరం. ప్రస్తుత AstroChartResultలో ఆ వివరాలు లేవు. '
      'కాబట్టి ఫలితం ఇవ్వము.'));
    return audit;
  }
}
