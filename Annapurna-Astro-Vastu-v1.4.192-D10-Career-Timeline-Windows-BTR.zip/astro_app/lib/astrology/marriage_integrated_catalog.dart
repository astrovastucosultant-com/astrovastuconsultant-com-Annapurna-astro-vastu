import 'marriage_rules_ok_registry.dart';
import 'marriage_verified_sutra_engine.dart';

/// Navigational integration of the supplied *partial* standalone Flutter menu.
/// A section is NOT an independently verified binary marriage prediction.
/// Links point to the existing source-audited evaluators; missing predicates
/// must remain unresolved until their complete source IF/THEN is available.
class MarriageIntegratedSection {
  final String id;
  final String title;
  final String description;
  final List<String> topicIds;
  final List<String> sutraIds;
  final List<String> d9VargaRuleIds;
  final String auditNote;

  const MarriageIntegratedSection({
    required this.id,
    required this.title,
    required this.description,
    this.topicIds = const [],
    this.sutraIds = const [],
    this.d9VargaRuleIds = const [],
    this.auditNote = '',
  });
}

class MarriageIntegratedCatalog {
  static const sections = <MarriageIntegratedSection>[
    MarriageIntegratedSection(id: 'IM-01', title: 'వివాహ వాగ్దానం (D9)',
      description: '7వ భావం, 7వ అధిపతి, దారాకారక పరిశీలన',
      topicIds: ['M-03','M-43'], d9VargaRuleIds: ['S7-D9-01','S7-D9-02'],
      auditNote: 'దారాకారక నిర్ధారణతో కూడిన పూర్తి సంయుక్త నిర్ణయానికి ప్రత్యేక మూల IF–THEN అవసరం.'),
    MarriageIntegratedSection(id: 'IM-02', title: 'వివాహ యోగం — రాశి/నవాంశం',
      description: 'D1, D9 మూల వివాహ యోగాలు; D9 ఉపచయ ఉపషరతు',
      topicIds: ['M-05','M-06'], sutraIds: ['P07-S04'],
      auditNote: 'పుట 7 ఉపచయ షరతు సరిపోవడం ఒక్కటే వివాహయోగ తుది నిర్ధారణ కాదు.'),
    MarriageIntegratedSection(id: 'IM-03', title: 'ప్రేమ వ్యవహారం / ప్రేమ వివాహం',
      description: 'D1/D9 సప్తమ–పంచమ/ఏకాదశ సంబంధాలు',
      topicIds: ['M-07','M-08'],
      auditNote: 'పుటలు 9,10లో పరీక్షించిన సంబంధాలు మాత్రమే; అరేంజ్డ్ వివాహ నిర్ణయం కాదు.'),
    MarriageIntegratedSection(id: 'IM-04', title: 'కులాంతర వివాహం',
      description: 'దారాకారకుడు మరియు శని/రాహు/కేతు — కొత్తగా ఇచ్చిన మెను శీర్షిక',
      auditNote: 'ఈ కోడ్‌లో పూర్తి గ్రహసంబంధాలు/దోషభంగం IF–THEN ఇవ్వలేదు; ఆటో YES/NO నిలిపివేశాం.'),
    MarriageIntegratedSection(id: 'IM-05', title: 'బహు వివాహం',
      description: 'మొదటి/రెండవ వివాహం — గ్రంథ సూచిక',
      topicIds: ['M-44'],
      auditNote: 'నవాంశ ప్రత్యేక యోగం పూర్తి షరతులు లేక సంఖ్య లేదా ఫలితం తేల్చరాదు.'),
    MarriageIntegratedSection(id: 'IM-06', title: 'విడాకుల సంబంధిత సూచనలు',
      description: 'D1/D7 సంబంధిత కారకాలు — సున్నితమైన మూల పరిశీలన',
      topicIds: ['M-40','M-41'],
      auditNote: 'ఒక కేతు స్థానం వల్ల విడాకులు తప్పనిసరి అని ప్రకటించము.'),
    MarriageIntegratedSection(id: 'IM-07', title: 'అవివాహ సూచనలు',
      description: 'లగ్నం, సప్తమ భావం, జైమిని ఆధారాల పరిశీలన',
      topicIds: ['M-45','M-46','M-47'],
      auditNote: 'పూర్తి మూల షరతులు లేక వివాహం జరగదని తీర్పు ఇవ్వము.'),
    MarriageIntegratedSection(id: 'IM-08', title: 'ఆలస్య వివాహం',
      description: 'D1/D7 గురు, శని, కుజ సంబంధ ఉపషరతులు',
      topicIds: ['M-14','M-15','M-16','M-17'],
      sutraIds: ['P14-S13-R01','P15-S14-R01','P16-S15-R01',
        'P16-S15-R02','P16-S15-R03'],
      auditNote: 'ఈ ఉపషరతులు వయసు లేదా వివాహ తేదీని స్వతంత్రంగా నిర్ధారించవు.'),
    MarriageIntegratedSection(id: 'IM-09', title: 'భాగస్వామి ఆరోగ్య అంశాలు',
      description: '7వ భావాధిపతి, పాపగ్రహ సంబంధం — జాగ్రత్త పరిశీలన',
      topicIds: ['M-42'],
      auditNote: 'భాగస్వామి మరణం/ఆయుష్షుపై నిర్ధారిత తీర్పు లేదా తేదీ చూపించము.'),
    MarriageIntegratedSection(id: 'IM-10', title: 'వివాహ నాణ్యత (D9 + D30)',
      description: 'దాంపత్య సూచనలు, నవాంశ/త్రింశాంశ మూలాలు',
      topicIds: ['M-37','M-38','M-48'],
      auditNote: 'D30 కష్టసూచనను దాంపత్య నాణ్యతకు స్వతంత్ర ఫలితంగా మార్చము.'),
    MarriageIntegratedSection(id: 'IM-11', title: 'వివాహ సాధ్యత — నవాంశ లగ్నం',
      description: 'Navamsha Lagna, Lagna Lord, 7వ భావం',
      topicIds: ['M-01','M-03'],
      d9VargaRuleIds: ['S7-D9-01','S7-D9-02'],
      auditNote: 'లగ్న బలం, దారాకారక సంబంధంపై పూర్తి మూల షరతులు ఇంకా అవసరం.'),
    MarriageIntegratedSection(id: 'IM-12', title: 'త్రింశాంశ (D30) నియమాలు',
      description: 'ఉదయ రాశి + సంబంధిత D30 పరిశీలన',
      topicIds: ['M-48'],
      auditNote: 'D30ను అదనపు జాతక ఆధారంగా మాత్రమే ఉపయోగిస్తాం; పూర్తి వివాహ ఫలితం కాదు.'),
    MarriageIntegratedSection(id: 'IM-13', title: 'జన్మ మహాదశ ఆధారంగా',
      description: 'జనన సమయంలో మహాదశాధిపతి నవాంశ సంబంధం',
      topicIds: ['M-19'],
      auditNote: 'జన్మదశా balance/నవాంశ సంబంధాల పూర్తి IF–THEN ఇవ్వలేదు; తేదీ గణించము.'),
    MarriageIntegratedSection(id: 'IM-14', title: 'వివాహ నాణ్యత — మహాదశ',
      description: 'మీరు పంపిన కోడ్ ఈ శీర్షిక వద్దే ఆగిపోయింది',
      auditNote: 'ఈ స్క్రీన్‌కు సంబంధించిన Flutter క్లాస్, అసలు షరతులు సందేశంలో లేవు.'),
  ];

  static bool get allReferencesValid {
    final topics = MarriageRulesOkRegistry.topics.map((e) => e.id).toSet();
    final sutras = MarriageVerifiedSutraEngine.sutras.map((e) => e.id).toSet();
    return sections.every((e) => e.topicIds.every(topics.contains) &&
        e.sutraIds.every(sutras.contains));
  }
}
