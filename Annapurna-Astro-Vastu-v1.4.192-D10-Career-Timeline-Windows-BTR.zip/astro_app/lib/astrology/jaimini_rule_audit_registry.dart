/// Source-first audit registry for Jaimini rules.
/// A rule is never marked verified merely because its ID or description exists.
enum JaiminiVerificationStatus {
  verified,
  partiallyVerified,
  pendingSourceCheck,
  notApplicable,
  calculationError,
}

class JaiminiRuleAuditRecord {
  final String ruleId;
  final String category;
  final String sourceBook;
  final String chapter;
  final String sutra;
  final String sourcePage;
  final String originalText;
  final String teluguExplanation;
  final List<String> mandatoryConditions;
  final List<String> exceptionConditions;
  final List<String> chartEvidence;
  final JaiminiVerificationStatus status;
  final bool matched;
  final String? mismatchReason;
  final String? remedySource;

  const JaiminiRuleAuditRecord({
    required this.ruleId,
    required this.category,
    required this.sourceBook,
    required this.chapter,
    required this.sutra,
    required this.sourcePage,
    required this.originalText,
    required this.teluguExplanation,
    required this.mandatoryConditions,
    required this.exceptionConditions,
    required this.chartEvidence,
    required this.status,
    required this.matched,
    this.mismatchReason,
    this.remedySource,
  });

  bool get hasTraceableSource => sourceBook.trim().isNotEmpty &&
      sutra.trim().isNotEmpty && originalText.trim().isNotEmpty;

  bool get eligibleForVerifiedResult =>
      status == JaiminiVerificationStatus.verified &&
      hasTraceableSource &&
      mandatoryConditions.isNotEmpty &&
      matched && chartEvidence.isNotEmpty &&
      (mismatchReason == null || mismatchReason!.isEmpty);

  List<String> get auditWarnings => [
    if (!hasTraceableSource) 'Missing primary-source reference/text',
    if (mandatoryConditions.isEmpty) 'Mandatory conditions not recorded',
    if (matched && chartEvidence.isEmpty) 'Match has no chart evidence',
    if (!matched && (mismatchReason == null || mismatchReason!.trim().isEmpty))
      'Non-match reason not recorded',
  ];
}

class JaiminiRuleAuditRegistry {
  const JaiminiRuleAuditRegistry();

  /// Only source-verified matches with actual chart evidence may be published.
  List<JaiminiRuleAuditRecord> publishable(Iterable<JaiminiRuleAuditRecord> records) =>
      records.where((r) => r.eligibleForVerifiedResult).toList(growable: false);

  Map<JaiminiVerificationStatus, int> coverage(Iterable<JaiminiRuleAuditRecord> records) {
    final counts = {for (final s in JaiminiVerificationStatus.values) s: 0};
    for (final record in records) {
      counts[record.status] = counts[record.status]! + 1;
    }
    return counts;
  }
}
