import 'western_ephemeris_service.dart';
import 'western_timing_engine.dart';

class WesternIndicatorContact {
  final String group, moving, natal;
  final int aspect;
  final double orb;
  const WesternIndicatorContact(this.group,this.moving,this.natal,this.aspect,this.orb);
}
class WesternIndicatorReport {
  final int natalSunSign, progressedSunSign;
  final bool sunSignChangeInWindow;
  final double progressedMoon;
  final List<WesternIndicatorContact> contacts;
  const WesternIndicatorReport(this.natalSunSign,this.progressedSunSign,
      this.sunSignChangeInWindow,this.progressedMoon,this.contacts);
}
class WesternFourSignificators {
  static const aspects=[0,60,90,120,180];
  static WesternIndicatorReport assess(WesternSky natal,WesternSky secondary,
      WesternSky solarArc,{double orb=1.0,double? previousSun,double? nextSun}) {
    if(!orb.isFinite || orb<=0) throw ArgumentError('Invalid orb');
    final sun=secondary.planets['Sun'];
    final moon=secondary.planets['Moon'];
    final natalSun=natal.planets['Sun'];
    if(sun==null || moon==null || natalSun==null) {
      throw StateError('Missing progressed Sun/Moon');
    }
    final results=<WesternIndicatorContact>[];
    void add(String group,String moving,double longitude,Map<String,double> targets) {
      for(final t in targets.entries) {
        for(final a in aspects) {
          final o=WesternTimingEngine.aspectOrb(longitude,t.value,a.toDouble());
          if(o!=null && o<=orb) results.add(WesternIndicatorContact(
            group,moving,t.key,a,o));
        }
      }
    }
    add('Progressed Moon','Moon',moon,natal.points);
    final natalAngles=<String,double>{'Asc':natal.asc,'MC':natal.mc,
      'Desc':WesternTimingEngine.normalize(natal.asc+180),
      'IC':WesternTimingEngine.normalize(natal.mc+180)};
    final directedAngles=<String,double>{'Asc':solarArc.asc,'MC':solarArc.mc,
      'Desc':WesternTimingEngine.normalize(solarArc.asc+180),
      'IC':WesternTimingEngine.normalize(solarArc.mc+180)};
    for(final angle in directedAngles.entries) {
      add('Solar Arc Directed Angles',angle.key,angle.value,natal.planets);
    }
    for(final name in ['Sun','Moon','Venus','Mars']) {
      final longitude=solarArc.planets[name];
      if(longitude!=null) add('Solar Arc Personal Planets',name,longitude,natalAngles);
    }
    int sign(double longitude)=>(WesternTimingEngine.normalize(longitude)/30).floor();
    results.sort((a,b)=>a.orb.compareTo(b.orb));
    return WesternIndicatorReport(sign(natalSun),sign(sun),
      (previousSun!=null && sign(previousSun)!=sign(sun)) ||
      (nextSun!=null && sign(nextSun)!=sign(sun)),moon,results);
  }
}
