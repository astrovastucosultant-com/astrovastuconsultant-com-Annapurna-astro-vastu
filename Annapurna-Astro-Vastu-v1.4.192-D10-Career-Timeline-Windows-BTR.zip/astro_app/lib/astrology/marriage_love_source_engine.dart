import 'astro_models.dart';
import 'marriage_chart_evidence_service.dart';
import 'varga_service.dart';

/// Source: `Marrage rules ok.pdf`, physical pages 9 and 10, sutras 07,
/// 07.1, 08 and 08.1. Only explicitly testable associations are scored:
/// same-sign conjunction, classical planetary aspect, house occupation/
/// aspect and exchange of lords. The source says "any relationship"; the
/// absence of these associations is therefore NOT a negative verdict.
class MarriageLoveSourceResult {
  final bool evaluated;
  final bool matched;
  final String summary;
  final String sourceRule;
  final String evidence;

  const MarriageLoveSourceResult({
    required this.evaluated,
    required this.matched,
    required this.summary,
    required this.sourceRule,
    required this.evidence,
  });
}

class MarriageLoveSourceEngine {
  static const _lords = MarriageChartEvidenceService.lords;
  static const _signs = MarriageChartEvidenceService.signs;
  static const _names = MarriageChartEvidenceService.planetNames;

  static VargaPlacement? _planet(VargaChartData v, String name) {
    for (final item in v.planets) {
      if (item.name == name) return item;
    }
    return null;
  }

  static String _lord(VargaChartData v, int house) =>
      _lords[(v.ascendantSignIndex + house - 1) % 12];

  static int _sign(VargaChartData v, int house) =>
      (v.ascendantSignIndex + house - 1) % 12;

  static String _name(String p) => _names[p] ?? p;

  static String _detail(VargaChartData v, String planet) {
    final p = _planet(v, planet);
    if (p == null) return '${_name(planet)}: డేటా లేదు';
    final house = ((p.signIndex - v.ascendantSignIndex + 12) % 12) + 1;
    return '${_name(planet)} ${_signs[p.signIndex]} ($house వ భావం)';
  }

  static bool _aspect(String fromPlanet, int from, int to) {
    final diff = (to - from + 12) % 12;
    if (diff == 6 && fromPlanet != 'Rahu' && fromPlanet != 'Ketu') return true;
    return switch (fromPlanet) {
      'Mars' => diff == 3 || diff == 7,
      'Jupiter' => diff == 4 || diff == 8,
      'Saturn' => diff == 2 || diff == 9,
      _ => false,
    };
  }

  static List<String> _planetLinks(VargaChartData v, String a, String b) {
    final p = _planet(v, a), q = _planet(v, b);
    if (p == null || q == null) return const [];
    if (a == b) return ['${_name(a)} రెండు భావాలకు ఒకే అధిపతి'];
    final links = <String>[];
    if (p.signIndex == q.signIndex) {
      links.add('${_name(a)}–${_name(b)} యుతి (${_signs[p.signIndex]})');
    }
    if (_aspect(a, p.signIndex, q.signIndex)) {
      links.add('${_name(a)} నుంచి ${_name(b)}కు గ్రహదృష్టి');
    }
    if (_aspect(b, q.signIndex, p.signIndex)) {
      links.add('${_name(b)} నుంచి ${_name(a)}కు గ్రహదృష్టి');
    }
    if (_lords[p.signIndex] == b && _lords[q.signIndex] == a) {
      links.add('${_name(a)}–${_name(b)} రాశి పరివర్తన');
    }
    return links;
  }

  static List<String> _planetToHouse(VargaChartData v, String name, int house) {
    final p = _planet(v, name);
    if (p == null) return const [];
    final target = _sign(v, house);
    final hits = <String>[];
    if (p.signIndex == target) hits.add('${_name(name)} $house వ భావంలో ఉంది');
    if (_aspect(name, p.signIndex, target)) {
      hits.add('${_name(name)} $house వ భావాన్ని చూస్తున్నది');
    }
    return hits;
  }

  static List<String> _within(VargaChartData v, String label) {
    final seven = _lord(v, 7);
    final evidence = <String>[];
    for (final house in const [5, 11]) {
      final lord = _lord(v, house);
      final links = <String>[
        ..._planetLinks(v, seven, lord),
        ..._planetToHouse(v, seven, house),
        ..._planetToHouse(v, lord, 7),
      ];
      for (final item in links) {
        evidence.add('$label: 7వ–$house వ సంబంధం: $item');
      }
    }
    return evidence;
  }

  /// Rule 08: natal 7L to natal 5L / 11L when their signs are inspected in D9.
  /// Rule 08.1: natal 7L to D9 5L/11L, or natal 5L/11L to D9 7L/7H.
  static List<String> _crossChart(VargaChartData d1, VargaChartData d9) {
    final sevenD1 = _lord(d1, 7);
    final links = <String>[];
    for (final house in const [5, 11]) {
      final lordD1 = _lord(d1, house);
      for (final link in _planetLinks(d9, sevenD1, lordD1)) {
        links.add('08, D1 7L–${house}Lను D9లో: $link');
      }
      final lordD9 = _lord(d9, house);
      for (final link in _planetLinks(d9, sevenD1, lordD9)) {
        links.add('08.1, D1 7L–D9 ${house}L: $link');
      }
      final sevenD9 = _lord(d9, 7);
      for (final link in _planetLinks(d9, lordD1, sevenD9)) {
        links.add('08.1, D1 ${house}L–D9 7L: $link');
      }
      for (final link in _planetToHouse(d9, lordD1, 7)) {
        links.add('08.1, D1 ${house}L–D9 7H: $link');
      }
    }
    return links;
  }

  static MarriageLoveSourceResult evaluate(String topicId, AstroChartResult? chart) {
    if (chart == null) {
      return const MarriageLoveSourceResult(
        evaluated: false, matched: false,
        summary: 'జాతకం ఇవ్వలేదు; సూత్ర పరీక్ష పెండింగ్.',
        sourceRule: 'అసలు మూలం: Marrage rules ok.pdf, పుటలు 9–10.',
        evidence: 'Saved Chart ఎంచుకోండి.',
      );
    }
    if (topicId != 'M-07' && topicId != 'M-08') {
      return const MarriageLoveSourceResult(
        evaluated: false, matched: false,
        summary: 'ఈ సూత్రానికి పుట–సూత్ర అనుసంధానం లేదు.',
        sourceRule: 'M-07 లేదా M-08 మాత్రమే.', evidence: '',
      );
    }
    final d1 = VargaService.calculate(chart, 1);
    final d9 = VargaService.calculate(chart, 9);
    final critical = <String>{_lord(d1, 7), _lord(d1, 5), _lord(d1, 11),
      _lord(d9, 7), _lord(d9, 5), _lord(d9, 11)};
    final missing = critical.where((p) =>
      _planet(d1, p) == null || _planet(d9, p) == null).toList();
    final rule = topicId == 'M-07'
      ? 'పుట 9, సూత్రాలు 07/07.1 — రాశి లేదా నవాంశ చక్రంలో '
        '7వ అధిపతి/భావానికి 5వ లేదా 11వ అధిపతి/భావంతో సంబంధం '
        'ఉంటే ప్రేమ వ్యవహార సూచన. ఇది అరేంజ్డ్ వివాహ నియమం కాదు.'
      : 'పుట 10, సూత్రాలు 08/08.1 — D1 సప్తమాధిపతి మరియు '
        'D1 పంచమ/ఏకాదశ అధిపతుల D9 సంబంధం; లేదా D1 7L–D9 5L/11L, '
        'D1 5L/11L–D9 7L/7H సంబంధం. ప్రేమ వివాహానికి మూల సూచన మాత్రమే.';
    if (missing.isNotEmpty) {
      return MarriageLoveSourceResult(
        evaluated: false, matched: false,
        summary: 'అవసరమైన భావాధిపతుల గ్రహస్థితులు అందలేదు.',
        sourceRule: rule,
        evidence: 'డేటా లేని గ్రహాలు: ${missing.map(_name).join(", ")}',
      );
    }
    final links = topicId == 'M-07' ? <String>[
      ..._within(d1, '07 D1'), ..._within(d9, '07.1 D9'),
    ] : _crossChart(d1, d9);
    final b = StringBuffer();
    b.writeln('D1: 7L=${_name(_lord(d1, 7))}, 5L=${_name(_lord(d1, 5))}, '
      '11L=${_name(_lord(d1, 11))}');
    b.writeln('D9: 7L=${_name(_lord(d9, 7))}, 5L=${_name(_lord(d9, 5))}, '
      '11L=${_name(_lord(d9, 11))}');
    for (final lord in critical) {
      b.writeln('D1 ${_detail(d1,lord)}; D9 ${_detail(d9,lord)}');
    }
    b.writeln('\nయుతి / పారాశరీ గ్రహదృష్టి / భావస్థానం / పరివర్తన పరీక్ష:');
    b.writeln(links.isEmpty ? 'పరీక్షించిన సంబంధాలు గుర్తించబడలేదు.'
      : links.map((s) => '• $s').join('\n'));
    b.writeln('\nమూలంలోని “ఏ విధమైన సంబంధం” కోసం ఇతర సంబంధ నిర్వచనాలు '
      'మరియు దోషభంగాలు ఇంకా ప్రత్యేక పరిశీలనకు లోబడి ఉంటాయి.');
    return MarriageLoveSourceResult(
      evaluated: true, matched: links.isNotEmpty, sourceRule: rule,
      summary: links.isNotEmpty
        ? 'మూలంలోని ${topicId == "M-07" ? "ప్రేమ వ్యవహార" : "ప్రేమ వివాహ"} '
          'సంబంధ ఉపషరతు గుర్తించబడింది (${links.length} మార్గాలు). '
          'సంఘటనకు తుది నిర్ధారణ కాదు.'
        : 'పరీక్షించిన గ్రహసంబంధాలు గుర్తించబడలేదు; '
          'పూర్తి మూల సూత్రం వర్తించదని నిర్ధారణ కాదు.',
      evidence: b.toString().trimRight(),
    );
  }
}
