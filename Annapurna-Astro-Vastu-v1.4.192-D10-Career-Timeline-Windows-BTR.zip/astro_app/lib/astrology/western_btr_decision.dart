/// Conservative decision layer for exploratory Western BTR evidence.
/// A contact-score is NOT a calibrated probability or proof of birth time.
class WesternBtrDecision {
  final bool sufficient;
  final String status;
  final int matchedEvents;
  final int totalEvents;
  final double meanContactScore;
  const WesternBtrDecision(this.sufficient,this.status,this.matchedEvents,
      this.totalEvents,this.meanContactScore);
}

class WesternBtrDecisionEngine {
  /// Solar Arc, Naibod and symbolic 1° are highly correlated and count as
  /// ONE direction family. Secondary and converse secondary share a family.
  static String familyOf(String method) {
    switch(method) {
      case 'Solar Arc':
      case 'Naibod':
      case '1° Symbolic': return 'symbolic-directions';
      case 'Secondary':
      case 'Converse Secondary': return 'secondary-progressions';
      case 'Tertiary-I': return 'tertiary-progressions';
      case 'Minor': return 'minor-progressions';
      default: return 'unknown';
    }
  }

  static WesternBtrDecision assess(List<Map<String,double>> eventMethods,
      {int minimumEvents=3, int minimumFamiliesPerEvent=2,
      double minimumMethodScore=0.75}) {
    if(eventMethods.length<minimumEvents) {
      return WesternBtrDecision(false,'INSUFFICIENT_EVENTS',0,
          eventMethods.length,0);
    }
    var matched=0;
    var sum=0.0;
    for(final methods in eventMethods) {
      final families=<String>{};
      for(final entry in methods.entries) {
        if(entry.value.isFinite && entry.value>=minimumMethodScore && entry.value<=1.0 &&
            familyOf(entry.key)!='unknown') families.add(familyOf(entry.key));
      }
      if(families.length>=minimumFamiliesPerEvent) matched++;
      if(methods.isNotEmpty) {
        final valid=methods.values.where((v)=>v.isFinite && v>=0 && v<=1).toList();
        if(valid.isNotEmpty) {
          sum+=valid.reduce((a,b)=>a+b)/valid.length;
        }
      }
    }
    final sufficient=matched==eventMethods.length;
    return WesternBtrDecision(sufficient,
        sufficient?'PRELIMINARY_CONTACT_MATCH':'INSUFFICIENT_RULE_EVIDENCE',
        matched,eventMethods.length,sum/eventMethods.length);
  }
}
