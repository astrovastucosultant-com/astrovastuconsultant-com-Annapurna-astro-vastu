import 'dart:math' as math;

/// Equatorial geometry used by astronomical Primary Directions.
/// This is a *coordinate/audit layer*, not a full mundane primary direction
/// engine. A complete engine additionally needs horizon intersections,
/// semi-arcs, house cusps, latitude of every body and a selected direction key.
class WesternEquatorialPoint {
  final double rightAscension;
  final double declination;
  final double? obliqueAscension;
  const WesternEquatorialPoint(this.rightAscension, this.declination,
      this.obliqueAscension);
}

class WesternPrimaryDirections {
  static double _rad(double v) => v * math.pi / 180.0;
  static double _deg(double v) => v * 180.0 / math.pi;
  static double _norm(double v) => (v % 360 + 360) % 360;

  /// Transform geocentric ecliptic longitude/latitude into equatorial RA/Dec.
  /// epsilon is the obliquity at the epoch (mean/true selection belongs to the
  /// ephemeris configuration). Never approximate lunar latitude as zero.
  static WesternEquatorialPoint fromEcliptic({required double longitude,
      required double latitude, required double obliquity,
      required double geographicLatitude}) {
    if (![longitude,latitude,obliquity,geographicLatitude]
        .every((e) => e.isFinite)) {
      throw ArgumentError('Non-finite astronomical coordinate');
    }
    if (geographicLatitude.abs() >= 90) {
      throw ArgumentError('Polar geographic latitude requires separate treatment');
    }
    final lon=_rad(longitude),lat=_rad(latitude),eps=_rad(obliquity);
    final x=math.cos(lat)*math.cos(lon);
    final y=math.cos(lat)*math.sin(lon)*math.cos(eps)-math.sin(lat)*math.sin(eps);
    final z=math.cos(lat)*math.sin(lon)*math.sin(eps)+math.sin(lat)*math.cos(eps);
    final ra=_norm(_deg(math.atan2(y,x)));
    final dec=_deg(math.asin(z.clamp(-1.0,1.0)));
    final p=math.tan(_rad(geographicLatitude))*math.tan(_rad(dec));
    // OA is defined for rising/setting points; circumpolar points have
    // no real horizon crossing and MUST NOT receive a fabricated OA.
    final oa=p.abs()>1.0 ? null : _norm(ra-_deg(math.asin(p)));
    return WesternEquatorialPoint(ra,dec,oa);
  }

  /// Meridian RA contact arc, not a full Placidus/Regiomontanus direction.
  static double meridianArc(double significatorRa,double promissorRa) =>
      _norm(promissorRa-significatorRa);

  static double obliqueAscensionArc(WesternEquatorialPoint significator,
      WesternEquatorialPoint promissor) {
    final a=significator.obliqueAscension,b=promissor.obliqueAscension;
    if(a==null||b==null) throw StateError('Circumpolar point: no horizon arc');
    return _norm(b-a);
  }
}


/// Geometry for Placidus semi-arc directions. All coordinates must share
/// one reference epoch/frame; RAMC is local right ascension of the meridian.
/// Returns null for circumpolar or degenerate geometry rather than inventing
/// an arc. This is a coordinate engine, not a verified full direction suite.
class WesternSemiArcDirection {
  final double directArc;
  final double converseArc;
  final double pole;
  final double directNaibodYears;
  final double converseNaibodYears;
  final double directPtolemyYears;
  final double conversePtolemyYears;
  const WesternSemiArcDirection(this.directArc, this.converseArc, this.pole,
      this.directNaibodYears, this.converseNaibodYears,
      this.directPtolemyYears, this.conversePtolemyYears);
}

class WesternPlacidusSemiArc {
  static double _rad(double d) => d * math.pi / 180;
  static double _deg(double r) => r * 180 / math.pi;
  static double _norm(double d) => (d % 360 + 360) % 360;
  static double _signed(double d) => _norm(d + 180) - 180;
  static double? ascensionalDifference(double latitude, double declination) {
    final x = math.tan(_rad(latitude)) * math.tan(_rad(declination));
    if (!x.isFinite || x.abs() > 1) return null;
    return _deg(math.asin(x));
  }

  /// Ascensional difference and semi-arc are signed by hemisphere.
  /// Pole is derived from the significator's proportional distance from
  /// its upper/lower meridian; avoid applying a flat geographic pole.
  static WesternSemiArcDirection? compute({
    required WesternEquatorialPoint promissor,
    required WesternEquatorialPoint significator,
    required double geographicLatitude,
    required double ramc,
  }) {
    if (![geographicLatitude, ramc, promissor.rightAscension,
          promissor.declination, significator.rightAscension,
          significator.declination].every((x) => x.isFinite) ||
        geographicLatitude.abs() >= 89.99) return null;
    final ad = ascensionalDifference(geographicLatitude,
        significator.declination);
    if (ad == null) return null;
    final md = _signed(significator.rightAscension - ramc);
    // Determine upper vs lower semi-arc by comparing distance to the
    // horizon's true ascensional difference, not by a fixed 90-degree cut.
    final east = md < 0;
    final horizonMd = east ? -(90 + ad) : (90 + ad);
    final above = east ? md >= horizonMd : md <= horizonMd;
    final distance = above ? md.abs() : 180 - md.abs();
    final semiarc = above ? 90 + ad : 90 - ad;
    if (semiarc <= 0 || semiarc >= 180 || distance > semiarc + 1e-7) {
      return null;
    }
    final w = (distance / semiarc).clamp(0.0, 1.0) * math.pi / 2;
    final pole = _deg(math.atan(math.sin(w) *
        math.tan(_rad(geographicLatitude))));
    final adProm = ascensionalDifference(pole, promissor.declination);
    final adSig = ascensionalDifference(pole, significator.declination);
    if (adProm == null || adSig == null) return null;
    final oaProm = _norm(promissor.rightAscension - adProm);
    final oaSig = _norm(significator.rightAscension - adSig);
    final direct = _norm(oaProm - oaSig);
    final converse = _norm(oaSig - oaProm);
    return WesternSemiArcDirection(direct, converse, pole,
        direct / 0.98564736, converse / 0.98564736, direct, converse);
  }
}
