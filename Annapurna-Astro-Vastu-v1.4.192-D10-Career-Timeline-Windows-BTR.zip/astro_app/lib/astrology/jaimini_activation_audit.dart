import 'astro_models.dart';
import 'jaimini_service.dart';

/// Transparent chart observations for an activated Chara Dasha sign.
/// This is a rule-evidence audit, not a prediction or a probability.
class JaiminiActivationAudit {
  static const topics = <String>[
    'P1 ఆరూఢ లగ్నం: ప్రజా గుర్తింపు, ప్రతిష్ఠ',
    'P2 ధనపదం: ధన స్థితి, ఆర్థిక ప్రతిష్ఠ',
    'P3 విక్రమపదం: ప్రయత్నం, సహోదరులు',
    'P4 మాతృపదం: గృహం, ఆస్తి, తల్లి',
    'P5 మంత్రపదం: విద్య, మేధస్సు, మంత్రం',
    'P6 రోగపదం: రుణం, శత్రువు, పోటీ',
    'P7 దారపదం: భాగస్వామ్యం, సంబంధాలు',
    'P8 రంధ్రపదం: మార్పులు, సంక్షోభం',
    'P9 భాగ్యపదం: ధర్మం, గురువు, భాగ్యం',
    'P10 రాజ్యపదం: ఉద్యోగం, వృత్తి, పదవి',
    'P11 లాభపదం: లాభం, నెట్‌వర్క్',
    'P12 ఉపపదం: వివాహ వ్యవస్థ, కుటుంబ సంబంధాలు',
  ];

  static int relativeHouse(int from, int to) => (to - from + 12) % 12 + 1;
  static String _sign(int s) => '${s + 1}';
  static List<String> _occupants(AstroChartResult chart, int sign) => chart.planets
      .where((p) => p.signIndex == sign).map((p) => p.name).toList();
  static String _names(List<String> names) => names.isEmpty ? 'లేవు' : names.join(', ');

  static List<String> forPada(AstroChartResult chart, JaiminiResult j, int number) {
    final p = j.arudhaPadas.firstWhere((p) => p.padaNumber == number);
    final occupied = _occupants(chart, p.padaSignIndex);
    final aspecting = <String>[];
    for (var i = 0; i < 12; i++) {
      if (j.rashiDrishti[i]?.contains(p.padaSignIndex) ?? false) {
        final planets = _occupants(chart, i);
        if (planets.isNotEmpty) aspecting.add('${_sign(i)}: ${planets.join(', ')}');
      }
    }
    return [
      'JA-P${number.toString().padLeft(2, '0')} • ${topics[number - 1]}',
      'మూల రాశి ${_sign(p.sourceSignIndex)} → అధిపతి ${p.lord} (${_sign(p.lordSignIndex)}) → పద రాశి ${_sign(p.padaSignIndex)}',
      'పద రాశిలో గ్రహాలు: ${_names(occupied)}',
      'పదాన్ని దృష్టిచేసే రాశులలో గ్రహాలు: ${aspecting.isEmpty ? 'లేవు' : aspecting.join(' | ')}',
      'పద రాశి జన్మ లగ్నం నుండి ${relativeHouse(chart.ascendantSignIndex, p.padaSignIndex)}వ భావంలో ఉంది.',
      'ఈ పదం సంబంధిత జీవిత అంశాన్ని సూచిస్తుంది; ఒక్క పదంతో సంఘటన తేదీ నిర్ధారణ కాదు.',
    ];
  }

  static List<String> forSign(AstroChartResult chart, JaiminiResult j, int sign,
      {int? mdSign, int? adSign}) {
    final occupants = _occupants(chart, sign);
    final drishti = j.rashiDrishti[sign] ?? const <int>[];
    final lines = <String>[
      'JA-ACT-${_sign(sign).padLeft(2, '0')} • యాక్టివ్ రాశి ${_sign(sign)} తాత్కాలిక లగ్నం',
      'ఈ రాశిలో గ్రహాలు: ${_names(occupants)}',
      'జన్మ లగ్నం నుండి స్థానం: ${relativeHouse(chart.ascendantSignIndex, sign)}వ భావం',
      'రాశి దృష్టి: ${drishti.map(_sign).join(', ')}',
    ];
    for (final target in drishti) {
      final padas = j.arudhaPadas.where((p) => p.padaSignIndex == target)
          .map((p) => 'P${p.padaNumber} (${p.lord})').toList();
      lines.add('దృష్టి ${_sign(target)}: గ్రహాలు ${_names(_occupants(chart, target))}; పదాలు ${_names(padas)}');
    }
    for (final pada in j.arudhaPadas.where((p) => p.padaSignIndex == sign)) {
      lines.add('యాక్టివ్ రాశిలో P${pada.padaNumber}: ${topics[pada.padaNumber - 1]}; అధిపతి ${pada.lord}');
    }
    // Classical argala positions 2, 4, 11 (and optional 5); opposition 12, 10, 3, 9.
    for (final pair in const [(2, 12), (4, 10), (11, 3), (5, 9)]) {
      final a = (sign + pair.$1 - 1) % 12;
      final v = (sign + pair.$2 - 1) % 12;
      final aPlanets = _occupants(chart, a);
      final vPlanets = _occupants(chart, v);
      lines.add('అర్గళ ${pair.$1} (${_sign(a)}): ${_names(aPlanets)}; విరోధ ${pair.$2} (${_sign(v)}): ${_names(vPlanets)}');
      lines.add('  అర్గళ గ్రహాలు ${aPlanets.length}; విరోధ గ్రహాలు ${vPlanets.length} — గ్రహబలం/సంప్రదాయ నియమం తుది నిర్ణయానికి అవసరం.');
    }
    final gk = j.charaKarakas.where((k) => k.code == 'GK');
    if (gk.isNotEmpty) {
      final gkPlanet = gk.first.planet;
      final gkPositions = chart.planets.where((p) => p.name == gkPlanet);
      if (gkPositions.isNotEmpty) {
        lines.add('GK (జ్ఞాతికారక) ${gkPlanet}: యాక్టివ్ రాశి నుండి ${relativeHouse(sign, gkPositions.first.signIndex)}వ భావం');
      }
    }
    for (final house in const [6, 8, 12]) {
      final target = (sign + house - 1) % 12;
      lines.add('${house}వ భావం (${_sign(target)}): ${_names(_occupants(chart, target))}');
    }
    if (mdSign != null && adSign != null) {
      final mdToAd = relativeHouse(mdSign, adSign);
      final adToMd = relativeHouse(adSign, mdSign);
      lines.add('MD ${_sign(mdSign)} → AD ${_sign(adSign)}: ${mdToAd}వ భావ సంబంధం; AD → MD: ${adToMd}వ భావ సంబంధం');
      lines.add('MD–AD పరస్పర రాశి దృష్టి: ${(j.rashiDrishti[mdSign]?.contains(adSign) ?? false) || (j.rashiDrishti[adSign]?.contains(mdSign) ?? false) ? 'ఉంది' : 'లేదు'}');
      lines.add('MD–AD 6/8/12 సంబంధం: ${const [6, 8, 12].contains(mdToAd) || const [6, 8, 12].contains(adToMd) ? 'పరిశీలన అవసరం' : 'ప్రత్యక్ష 6/8/12 సంబంధం లేదు'}');
    }
    lines.add('ఇవి జాతక ఆధారాల పరిశీలనలు మాత్రమే; శుభ/పాప అర్గళ తుది నిర్ణయానికి గ్రహస్వభావం, విరోధబలం, మూలగ్రంథ నియమం అవసరం.');
    return lines;
  }
}
