import 'astro_models.dart';
import 'marriage_chart_evidence_service.dart';
import 'marriage_love_source_engine.dart';
import 'varga_service.dart';

/// 43 IF–THEN clauses copied from user-provided 6-page rulebook.
/// Each status represents a check of the written condition, never a certain life event.
enum MarriageChromeStatus { needsChart, needsDefinition, matched, notMatched }

class MarriageChromeRule {
  final String id;
  final int section;
  final int page;
  final String ifText;
  final String thenText;
  const MarriageChromeRule(this.id,this.section,this.page,this.ifText,this.thenText);
}

class MarriageChromeEvaluation {
  final MarriageChromeStatus status;
  final String examination;
  const MarriageChromeEvaluation(this.status,this.examination);
  bool get isComputed => status == MarriageChromeStatus.matched || status == MarriageChromeStatus.notMatched;
  bool get matches => status == MarriageChromeStatus.matched;
  String get result => switch (status) {
    MarriageChromeStatus.needsChart => 'జాతకం ఎంచుకోవాలి',
    MarriageChromeStatus.needsDefinition => 'ఉపషరతు పరిశీలన / నిర్వచన ధృవీకరణ అవసరం',
    MarriageChromeStatus.matched => 'ఈ IF–THEN షరతు వర్తించింది',
    MarriageChromeStatus.notMatched => 'ఈ IF–THEN షరతు ఈ జాతకంలో సరిపోలలేదు',
  };
}

class MarriageChromeIfThenEngine {
  static const source = 'Annapurna_Marriage_Rules_Chrome.pdf';
  static const sectionTitles = <String>[
    'వివాహ వాగ్దానం (D9)',
    'వివాహ యోగం',
    'ప్రేమ వ్యవహారం / ప్రేమ వివాహం',
    'కులాంతర వివాహం',
    'బహు వివాహం / సంబంధాలు',
    'విడాకుల సూచనలు',
    'అవివాహ సూచనలు',
    'ఆలస్య వివాహం',
    'భాగస్వామి ఆరోగ్య సూచనలు',
    'వివాహ నాణ్యత D9 + D30',
    'నవాంశ లగ్నం & లగ్నాధిపతి',
    'త్రింశాంశ D30 నియమాలు',
    'జన్మ మహాదశ ఆధారంగా',
    'మహాదశాధిపతి – వివాహ నాణ్యత',
    'వివాహానికి ముందు అడ్డంకులు',
    'వివాహం తర్వాత',
    'వివాహం తర్వాత సంబంధ సూచనలు',
    'ఇతర ముఖ్య నియమాలు / మినహాయింపు',
  ];
  static const rules = <MarriageChromeRule>[
    MarriageChromeRule('C01-01', 1, 1, '7వ భావం బలం AND 7వ అధిపతి బలం AND దారాకారకుడు బలం AND జ్ఞాతికారకుడు పీడ లేదు AND రాహు/కేతు పీడ లేదు', 'వివాహ వాగ్దానం ఉంది → YES'),
    MarriageChromeRule('C01-02', 1, 1, 'జ్ఞాతికారకుడు లేదా రాహుకేతువులు 7వ భావం / దారాకారకుడిపై పీడ', 'వివాహ ఆటంకం లేదా అసంతృప్తి → YES'),
    MarriageChromeRule('C01-03', 1, 1, 'దారాకారకుడు ఉచ్చం లేదా స్వక్షేత్రంలో ఉంటే', 'వివాహం శుభకరం → YES'),
    MarriageChromeRule('C01-04', 1, 1, '7వ భావంలో రాజయోగం ఉంటే', 'బలమైన వివాహ వాగ్దానం → YES'),
    MarriageChromeRule('C02-01', 2, 1, 'నవాంశం (D9) లో 7వ భావం లేదా 7వ అధిపతికి వివాహ తార అధిపతి సంబంధం', 'వివాహ యోగం → YES'),
    MarriageChromeRule('C02-02', 2, 1, 'సప్తాంశం (D7) లో 7వ భావం / 7వ అధిపతి / లగ్నాధిపతికి వివాహ కారకుడు (పురుష=శుక్ర, స్త్రీ=కుజ) సంబంధం', 'వివాహ యోగం → YES'),
    MarriageChromeRule('C03-01', 3, 2, 'రాశి చార్టు లేదా నవాంశంలో 7వ అధిపతి / 7వ భావానికి 5వ అధిపతి/భావం లేదా 11వ అధిపతి/భావం సంబంధం', 'ప్రేమ వ్యవహారం → YES'),
    MarriageChromeRule('C03-02', 3, 2, 'రాశి చార్టులోని 7వ అధిపతికి నవాంశంలో 5వ అధిపతి లేదా 11వ అధిపతి సంబంధం', 'ప్రేమ వివాహం → YES'),
    MarriageChromeRule('C04-01', 4, 2, 'నవాంశంలో దారాకారకుడు (DK) కి శని / రాహు / కేతు సంబంధం', 'కులాంతర వివాహం సాధ్యం → YES'),
    MarriageChromeRule('C05-01', 5, 2, 'నవాంశంలో లగ్నాధిపతికి ప్రత్యేక బలం (ఉచ్చ/నీచ/వర్గోత్తమం) AND ధనయోగం AND ఉపచయ (3/6/10/11) లో గ్రహాలు (10వలో కనీసం ఒకటి)', 'బహు వివాహాలు / సంబంధాలు → YES'),
    MarriageChromeRule('C05-02', 5, 2, 'నవాంశంలో 7వ భావం శుభం + 7వ అధిపతి అశుభం', 'బహు వివాహం / సంబంధాలు → YES'),
    MarriageChromeRule('C06-01', 6, 2, 'సప్తాంశం (D7) లో 6వ భావం / 6వ అధిపతి / లగ్నం / లగ్నాధిపతికి కేతువు సంబంధం', 'విడాకుల సూచన → YES'),
    MarriageChromeRule('C07-01', 7, 2, 'రాశి చార్టులో లగ్నాధిపతి + 7వ అధిపతి 4/10 లేదా 6/8 లేదా 2/12 స్థితిలో ఉండి AND 7వ అధిపతికి కేతువు 1/5/9 లేదా 2వ స్థానం AND జీవ గురువు + వివాహ కారకుడు కూడా బలహీనంగా ఉంటే', 'అవివాహ యోగం → YES'),
    MarriageChromeRule('C08-01', 8, 3, 'సప్తాంశంలో గురువు / శని / కుజుడు 7వ భావం లేదా 2వ భావం / అధిపతి / కారకుడితో సంబంధం', 'ఆలస్య వివాహం → YES'),
    MarriageChromeRule('C09-01', 9, 3, 'రాశి చార్టులోని 7వ అధిపతి నవాంశంలో రాహు / కేతు / శని / కుజుడు / సూర్యుడు లేదా పాపగ్రహాలతో సంబంధం', 'భాగస్వామి మరణం / ఆరోగ్య సమస్య సూచన → YES'),
    MarriageChromeRule('C10-01', 10, 3, 'నవాంశం (D9) + త్రిశాంశం (D30) రెండూ శుభం AND కారకాంశ లగ్నం నుంచి సపోర్ట్', 'వివాహ నాణ్యత మంచిది → YES'),
    MarriageChromeRule('C11-01', 11, 3, 'Navamsha Lagnaలో ఏ గ్రహం లేకపోతే + ఎవరూ aspect చేయకపోతే', 'వివాహం పట్ల నిర్లిప్తత (Neutral). పెళ్లి అయినా, కాకపోయినా సమానం.'),
    MarriageChromeRule('C11-02', 11, 3, 'Navamsha Lagnaపై కేవలం శుభ గ్రహాల ప్రభావం ఉంటే', 'వివాహం పట్ల కోరిక ఉంటుంది → YES'),
    MarriageChromeRule('C11-03', 11, 3, 'Navamsha Lagnaపై కేవలం అశుభ గ్రహాల ప్రభావం ఉంటే', 'వివాహం పట్ల కోరిక లేదు. అధిక అశుభం అయితే వివాహం లేకపోవడం లేదా చాలా ఆలస్యం → YES'),
    MarriageChromeRule('C11-04', 11, 3, 'Lagnaపై శుభ + అశుభ రెండూ ఉంటే', 'కోరిక ఉంటుంది కానీ జాగ్రత్తగా ఉంటాడు.'),
    MarriageChromeRule('C11-05', 11, 3, 'Lagna Lordకి శుభ ప్రభావం మాత్రమే ఉంటే', 'వివాహం సమయానికి జరుగుతుంది (Lagna శుభమైతే). Lagna అశుభమైతే దాదాపు నిరాకరణ.'),
    MarriageChromeRule('C11-06', 11, 4, 'Lagna Lordకి కేవలం అశుభ ప్రభావం ఉంటే', 'Lagna శుభమైతే కొంత ఆలస్యం; Lagna అశుభమైతే దాదాపు నిరాకరణ లేదా చాలా ఆలస్యం.'),
    MarriageChromeRule('C12-01', 12, 4, 'Trimshamshaలో ఉదయించే రాశి సూర్యుడు/మంగళుడు/శని రాశి అయి + అదే గ్రహం జన్మ లగ్నాన్ని ప్రభావితం చేస్తే', 'చెడు (వివాహం లేదా ఆలస్యం). అదే గ్రహం Trimshamsha లగ్నాన్ని కూడా ప్రభావితం చేస్తే అత్యంత చెడు → YES'),
    MarriageChromeRule('C12-02', 12, 4, 'Trimshamshaలో శుభ రాశి ఉదయిస్తే + అదే శుభ గ్రహం జన్మ లగ్నం + Trimshamsha లగ్నం రెండింటినీ ప్రభావితం చేస్తే', 'త్వరిత/తొందర వివాహం → YES'),
    MarriageChromeRule('C12-03', 12, 4, 'Trimshamshaలో 7వ & 8వ భావాలపై అశుభ ప్రభావం ఉంటే', 'వివాహం నిరాకరణ → YES'),
    MarriageChromeRule('C13-01', 13, 4, 'జన్మ సమయంలో విమ్శోత్తరి మహాదశాధిపతి Navamshaలో చెడుగా ఉండి (అశుభ సంబంధం/ప్లేస్‌మెంట్) ఉంటే', 'వివాహం నిరాకరించవచ్చు → YES'),
    MarriageChromeRule('C13-02', 13, 4, 'మహాదశాధిపతిపై ఏ అశుభ ప్రభావం లేకపోతే', 'వివాహం వాగ్దానం → YES'),
    MarriageChromeRule('C13-03', 13, 4, 'ఒక అశుభ ప్రభావం మాత్రమే ఉంటే', 'ఆలస్యం → YES'),
    MarriageChromeRule('C14-01', 14, 4, 'జన్మ మహాదశాధిపతి Navamshaలో బాగా ఉండి శుభ సంబంధం ఉంటే', 'వివాహ నాణ్యత మంచిది → YES'),
    MarriageChromeRule('C14-02', 14, 4, 'మహాదశాధిపతి నష్టపోతే / అశుభ సంబంధం ఉంటే', 'వివాహ నాణ్యత సరిగా ఉండదు → YES'),
    MarriageChromeRule('C15-01', 15, 5, 'శని 3వ భావంలో ఉండి లేదా 3వ భావాన్ని aspect చేస్తే', 'వివాహ వేడుకలో అడ్డంకులు (ఆలస్యం, రద్దు, ప్రమాదం) → YES'),
    MarriageChromeRule('C15-02', 15, 5, 'శనితో అధిక అశుభ సంబంధం ఉంటే లేదా శని 3వ అధిపతి అయినా అశుభ సంబంధం ఉంటే', 'వివాహం పూర్తిగా రద్దు అయ్యే అవకాశం కూడా ఉంటుంది → YES'),
    MarriageChromeRule('C16-01', 16, 5, 'Navamsha 2వ భావం అశుభ ప్రభావం కలిగి ఉంటే', 'వివాహం యొక్క మొదటి అనుభవం సరిగా ఉండదు → YES'),
    MarriageChromeRule('C16-02', 16, 5, '2వ అధిపతి అశుభ ప్రభావం కలిగి ఉంటే', 'తదుపరి సంఘటనలు సరిగా ఉండవు → YES'),
    MarriageChromeRule('C17-01', 17, 5, 'Navamshaలో 5వ భావం/5వ అధిపతి విపరీత అధిపతుల (6, 8, 12) చేత ప్రభావితమైతే', 'ఆలోచనలలో వక్రత → అఫైర్స్ సాధ్యత → YES'),
    MarriageChromeRule('C17-02', 17, 5, '5వ & 7వ అధిపతులు పరస్పర సంబంధం కలిగి ఉంటే (Navamshaలో)', 'ప్రేమ/అఫైర్ సాధ్యత → YES'),
    MarriageChromeRule('C17-03', 17, 5, 'మంగళుడు + శుక్రుడు పరస్పర సంబంధం (శని ప్రభావం లేకుండా)', 'అధిక లైంగిక కోరిక → YES'),
    MarriageChromeRule('C17-04', 17, 5, 'శుక్రుడిపై 6వ అధిపతి ప్రభావం / 6వ అధిపతి 7వ భావం లేదా 7వ అధిపతిని ప్రభావితం చేస్తే', 'అధిక లైంగిక కోరిక/అఫైర్స్ → YES'),
    MarriageChromeRule('C17-05', 17, 5, 'శుక్రుడు కేతుతో కలిసి ఉంటే Navamshaలో', 'అధిక లైంగిక కోరిక → YES'),
    MarriageChromeRule('C17-06', 17, 5, '8వ అధిపతి 4వ భావం/4వ అధిపతిని ప్రభావితం చేస్తే', 'అఫైర్ రహస్యంగా ఉంటుంది → YES'),
    MarriageChromeRule('C18-01', 18, 6, 'నవాంశ లగ్నాధిపతి లేదా 7వ అధిపతి ఎగ్జాల్టేషన్ / స్వక్షేత్రం / డెబిలిటేషన్‌లో ఉంటే', 'బహుళ వివాహాలు లేదా అనేక సంబంధాలు → YES'),
    MarriageChromeRule('C18-02', 18, 6, 'శుక్రుడు + 6వ అధిపతి సంయోగం/పరస్పర aspect', 'వ్యభిచారం/ప్రోస్టిట్యూషన్ ధోరణి సాధ్యత → YES'),
    MarriageChromeRule('C18-03', 18, 6, 'త్రికోణ అధిపతులు (1, 5, 9) కనీసం ఇద్దరు పరస్పర సంబంధం కలిగి ఉంటే Navamshaలో', 'పై అశుభ ఫలితాలు రావు (Big Exception) → YES'),
  ];

  static MarriageChromeEvaluation evaluate(MarriageChromeRule rule, AstroChartResult? chart,
      {String? gender}) {
    if (chart == null) {
      return const MarriageChromeEvaluation(MarriageChromeStatus.needsChart, 'Saved Chart లేదా ప్రస్తుతం తెరిచిన జాతకం ఇవ్వాలి.');
    }
    final context = _RuleChartContext(chart, gender: gender);
    return context.evaluate(rule);
  }
}
class _RuleChartContext {
  final AstroChartResult chart;
  final String? gender;
  late final VargaChartData d1 = VargaService.calculate(chart, 1);
  late final VargaChartData d7 = VargaService.calculate(chart, 7);
  late final VargaChartData d9 = VargaService.calculate(chart, 9);
  late final VargaChartData d30 = VargaService.calculate(chart, 30);
  static const _names = MarriageChartEvidenceService.planetNames;
  static const _signs = MarriageChartEvidenceService.signs;
  static const _lords = MarriageChartEvidenceService.lords;
  static const _malefics = {'Sun','Mars','Saturn','Rahu','Ketu'};
  static const _benefics = {'Jupiter','Venus'};
  static const _seven = {'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'};
  static const _nine = {'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'};
  static const _exalted = <String,int>{
    'Sun':0,'Moon':1,'Mars':9,'Mercury':5,'Jupiter':3,'Venus':11,'Saturn':6,
  };
  _RuleChartContext(this.chart, {this.gender});

  VargaPlacement? _planet(VargaChartData v, String name) {
    for(final p in v.planets){if(p.name==name)return p;}
    return null;
  }
  String _lord(VargaChartData v, int house) => _lords[(v.ascendantSignIndex + house - 1)%12];
  int _houseSign(VargaChartData v,int house)=>(v.ascendantSignIndex+house-1)%12;
  int? _h(VargaChartData v,String name){
    final p=_planet(v,name);if(p==null)return null;
    return (p.signIndex-v.ascendantSignIndex+12)%12+1;
  }
  String _n(String name)=>_names[name]??name;
  String _description(VargaChartData v,String name){
    final p=_planet(v,name);if(p==null)return '${_n(name)}: డేటా లేదు';
    return '${_n(name)}: ${_signs[p.signIndex]}, ${_h(v,name)}వ భావం';
  }
  bool _hasAll(VargaChartData v,Set<String> names) =>
      v.planets.map((p)=>p.name).toSet().containsAll(names);
  // Parashari planetary aspects; nodes are evaluated by conjunction only because
  // their aspect convention differs among traditions.
  bool _aspect(String from,int sign,int target){
    final diff=(target-sign+12)%12;
    if(from=='Rahu'||from=='Ketu')return false;
    if(diff==6)return true;
    if(from=='Mars')return diff==3||diff==7;
    if(from=='Jupiter')return diff==4||diff==8;
    if(from=='Saturn')return diff==2||diff==9;
    return false;
  }
  bool _influences(VargaChartData v,String name,int target){
    final p=_planet(v,name);if(p==null)return false;
    return p.signIndex==target || _aspect(name,p.signIndex,target);
  }
  bool _link(VargaChartData v,String a,String b){
    final p=_planet(v,a),q=_planet(v,b);
    if(p==null||q==null)return false;
    if(a==b)return false; // Same planet cannot aspect/conjoin itself.
    return p.signIndex==q.signIndex ||
      _aspect(a,p.signIndex,q.signIndex)||_aspect(b,q.signIndex,p.signIndex)||
      (_lords[p.signIndex]==b && _lords[q.signIndex]==a);
  }
  bool _conjunctionOrMutualAspect(VargaChartData v,String a,String b){
    final p=_planet(v,a),q=_planet(v,b);
    if(p==null||q==null||a==b)return false;
    return p.signIndex==q.signIndex ||
      (_aspect(a,p.signIndex,q.signIndex)&&_aspect(b,q.signIndex,p.signIndex));
  }
  bool _toHouse(VargaChartData v,String name,int h)=>_influences(v,name,_houseSign(v,h));
  bool _linkOrHouse(VargaChartData v,String a,int house) =>
      _link(v,a,_lord(v,house))||_toHouse(v,a,house);
  List<String> _onHouse(VargaChartData v,int house){
    final t=_houseSign(v,house);
    return v.planets.where((p)=>p.signIndex==t||_aspect(p.name,p.signIndex,t))
       .map((p)=>p.name).toList();
  }
  List<String> _onPlanet(VargaChartData v,String name){
    final p=_planet(v,name);if(p==null)return [];
    return v.planets.where((q)=>q.name!=name &&
        (q.signIndex==p.signIndex||_aspect(q.name,q.signIndex,p.signIndex)))
      .map((e)=>e.name).toList();
  }
  String _affection(VargaChartData v,int house) =>
      'D${v.definition.factor} ${house}వ భావాన్ని ప్రభావితం చేసినవి: '
      '${_onHouse(v,house).map(_n).join(', ')}';
  String? get _dk {
    if(!_hasAll(d1,_seven))return null;
    final p=chart.planets.where((e)=>_seven.contains(e.name)).toList()
      ..sort((a,b)=>b.degreesInSign.compareTo(a.degreesInSign));
    for(var i=1;i<p.length;i++){
      if((p[i-1].degreesInSign-p[i].degreesInSign).abs()<1e-8)return null;
    }
    return p.last.name;
  }
  String? get _gk {
    if(!_hasAll(d1,_seven))return null;
    final p=chart.planets.where((e)=>_seven.contains(e.name)).toList()
      ..sort((a,b)=>b.degreesInSign.compareTo(a.degreesInSign));
    for(var i=1;i<p.length;i++){
      if((p[i-1].degreesInSign-p[i].degreesInSign).abs()<1e-8)return null;
    }
    return p[p.length-2].name;
  }
  bool _ownOrExalted(VargaChartData v,String name){
    final p=_planet(v,name);if(p==null)return false;
    return _lords[p.signIndex]==name || _exalted[name]==p.signIndex;
  }
  bool _debilitated(VargaChartData v,String name){
    final p=_planet(v,name);if(p==null)return false;
    final sign=_exalted[name];return sign!=null && p.signIndex==(sign+6)%12;
  }
  String get _baseline {
    final dk=_dk,gk=_gk;
    final r=StringBuffer();
    for(final v in [d1,d7,d9,d30]){
      r.writeln('D${v.definition.factor} లగ్నం: ${_signs[v.ascendantSignIndex]}');
    }
    r.writeln('7-కారక జైమిని DK: ${dk==null?'గణన/డిగ్రీ ధృవీకరణ అవసరం':_n(dk)}; '
        'GK: ${gk==null?'ధృవీకరణ అవసరం':_n(gk)}');
    if(_hasAll(d1,_seven)) {
      final ranked=chart.planets.where((p)=>_seven.contains(p.name)).toList()
        ..sort((a,b)=>b.degreesInSign.compareTo(a.degreesInSign));
      if(ranked.length==7){
        final ak=ranked.first.name;
        final karakaSign=_planet(d9,ak)?.signIndex;
        if(karakaSign!=null){
          r.writeln('జైమిని ఆత్మకారకుడు ${_n(ak)}; కారకాంశ లగ్నం: '
            '${_signs[karakaSign]}; కారకాంశం నుంచి 7వ రాశి: '
            '${_signs[(karakaSign+6)%12]}');
        }
      }
    }
    r.writeln('D9 7L: ${_description(d9,_lord(d9,7))}');
    r.writeln('పరాశరీ యుతి/గ్రహదృష్టి పరిశీలన; రాహు–కేతు దృష్టి సంప్రదాయ భేదం వల్ల యుతి మాత్రమే.');
    return r.toString();
  }
  MarriageChromeEvaluation _met(bool yes,String detail)=>
      MarriageChromeEvaluation(yes ? MarriageChromeStatus.matched:
          MarriageChromeStatus.notMatched,'$detail\n\n$_baseline');
  MarriageChromeEvaluation _pending(String detail)=>
      MarriageChromeEvaluation(MarriageChromeStatus.needsDefinition,'$detail\n\n$_baseline');
  MarriageChromeEvaluation _yesOnly(bool found,String detail)=> found
      ? _met(true,detail) : _pending('$detail\nపరీక్షించిన సంబంధం దొరకలేదు; '
          'మూలంలోని మరొక దృష్టి/దోషభంగ నిర్వచనం ఉండవచ్చు.');

  MarriageChromeEvaluation evaluate(MarriageChromeRule r){
    final key=r.id;
    final dk=_dk;
    switch(key){
      case 'C01-02':
        final gk=_gk;
        if(dk==null||gk==null)return _pending('DK/GK డిగ్రీలు పూర్తిగా లేవు.');
        final affected=[gk,'Rahu','Ketu'].where((p)=>
            _link(d9,p,dk)||_toHouse(d9,p,7)).toList();
        return _yesOnly(affected.isNotEmpty,
          'D9 DK=${_n(dk)}, GK=${_n(gk)}; 7వ భావం/DKకి సంబంధం: '
          '${affected.map(_n).join(', ')}');
      case 'C01-03':
        if(dk==null)return _pending('DK ఖచ్చితంగా నిర్ణయించడానికి 7 కారక గ్రహ డిగ్రీలు అవసరం.');
        return _met(_ownOrExalted(d9,dk),
           'దారాకారకుడు ${_n(dk)}; D9 ${_description(d9,dk)}; స్వ/ఉచ్చ స్థానం పరిశీలన.');
      case 'C02-02':
        if(gender!='male' && gender!='female')return _pending('ఈ సూత్రం పురుషునికి శుక్రుడు, స్త్రీకి కుజుడు అని నిర్దేశించింది. Saved Chartలో లింగం నమోదు కావాలి.');
        final karaka=gender=='male'?'Venus':'Mars';
        return _yesOnly(_linkOrHouse(d7,karaka,7) ||
           _link(d7,karaka,_lord(d7,1)),
           'D7 ${_n(karaka)}: ${_description(d7,karaka)}; '
           '7వ భావం/7L/లగ్నాధిపతి సంబంధం పరిశీలించాం.');
      case 'C03-01':
      case 'C03-02':
        final result=MarriageLoveSourceEngine.evaluate(key=='C03-01'?'M-07':'M-08',chart);
        if(!result.evaluated)return _pending(result.evidence);
        return _yesOnly(result.matched,result.evidence);
      case 'C04-01':
        if(dk==null)return _pending('DK ఖచ్చిత డిగ్రీలు అవసరం.');
        final hits=['Saturn','Rahu','Ketu'].where((name)=>_link(d9,dk,name)).toList();
        return _yesOnly(hits.isNotEmpty,
          'D9 DK ${_n(dk)}; శని/రాహు/కేతు గ్రహసంబంధాలు: ${hits.map(_n).join(', ')}. '
          'ఇది వ్యక్తి కులం/సామాజిక నేపథ్యాన్ని నిర్ధారించదు.');
      case 'C05-01':
        final lord=_lord(d9,1);
        final dignity=_ownOrExalted(d9,lord)||_debilitated(d9,lord)||
          (_planet(d1,lord)?.signIndex==_planet(d9,lord)?.signIndex);
        final in10=d9.planets.where((p)=>_h(d9,p.name)==10).toList();
        return _pending('D9 1L ${_n(lord)} ప్రత్యేక స్థితి: $dignity; '
           '10వ భావంలో ${in10.map((p)=>_n(p.name)).join(', ')}. '
           'ధనయోగం అనే సంయుక్త షరతుకు ఈ PDFలో ప్రత్యేక లెక్కింపు నిర్వచనం లేదు. '
           'ఆ షరతు ధృవీకరణకు ముందు తుది YES/NO కాదు.');
      case 'C06-01':
        final result=_linkOrHouse(d7,'Ketu',6)||
            _toHouse(d7,'Ketu',1)|| _link(d7,'Ketu',_lord(d7,1));
        return _yesOnly(result,'D7 ${_description(d7,'Ketu')}; '
            '6వ భావం/6L/లగ్నం/లగ్నాధిపతి సంబంధం. ఇది విడాకులు తప్పనిసరి అనడానికి ఆధారం కాదు.');
      case 'C07-01':
        final l1=_lord(d1,1), l7=_lord(d1,7);
        final r1=_planet(d1,l1),r7=_planet(d1,l7),ketu=_planet(d1,'Ketu');
        if(r1==null||r7==null||ketu==null)return _pending('D1 అధిపతి/కేతు డేటా అవసరం');
        final diff=(r7.signIndex-r1.signIndex+12)%12+1;
        final opp=(r1.signIndex-r7.signIndex+12)%12+1;
        final k=(ketu.signIndex-r7.signIndex+12)%12+1;
        return _pending('D1 లగ్నాధిపతి–7L పరస్పర స్థానాలు: $diff/$opp; '
            '7L నుంచి కేతువు: ${k}వ భావం. గురు, వివాహ కారకుడు బలం అనే '
            'సంయుక్త షరతుకు ఒక నిర్ధారిత బల ప్రమాణం ఇంకా అవసరం.');
      case 'C08-01':
        final list=['Jupiter','Saturn','Mars'];
        final found=list.where((p)=>[2,7].any((h)=>_linkOrHouse(d7,p,h))).toList();
        return _yesOnly(found.isNotEmpty,
            'D7 గురువు/శని/కుజుడు → 2/7 భావం/అధిపతుల సంబంధం: '
            '${found.map(_n).join(', ')}; ఇతర కారక సంబంధాలు విడిగా పరిశీలించాలి.');
      case 'C09-01':
        final lord=_lord(d1,7);
        final hits=['Rahu','Ketu','Saturn','Mars','Sun'].where((p)=>_link(d9,lord,p)).toList();
        return _yesOnly(hits.isNotEmpty,
           'D1 7L=${_n(lord)}; D9 ${_description(d9,lord)}; '
           'పాపగ్రహ సంబంధాలు: ${hits.map(_n).join(', ')}. '
           'ఇది భాగస్వామి మరణం/రోగ నిర్ధారణకు సరిపడే ఆధారం కాదు.');
      case 'C11-01':
        if(!_hasAll(d9,_nine))return _pending('D9 తొమ్మిది గ్రహాల డేటా లేదు.');
        return _met(_onHouse(d9,1).isEmpty,
           '${_affection(d9,1)}; లగ్నం ఖాళీగా ఉండటం + ఎవరూ చూడకపోవడం.');
      case 'C11-02':
      case 'C11-03':
      case 'C11-04':
        if(!_hasAll(d9,_nine))return _pending('D9 తొమ్మిది గ్రహాల డేటా అవసరం.');
        final affects=_onHouse(d9,1);
        final b=affects.where(_benefics.contains).toList();
        final m=affects.where(_malefics.contains).toList();
        final neutral=affects.where((n)=>!_benefics.contains(n)&&!_malefics.contains(n)).toList();
        if(neutral.isNotEmpty)return _pending('${_affection(d9,1)}; '
          'చంద్రుడు/బుధుడు శుభ–అశుభ వర్గీకరణకు క్షయ/వృద్ధి, యుతి పరిశీలన కావాలి.');
        final ok=key=='C11-02' ? b.isNotEmpty&&m.isEmpty :
            key=='C11-03'?m.isNotEmpty&&b.isEmpty : b.isNotEmpty&&m.isNotEmpty;
        return _met(ok, '${_affection(d9,1)}; శుభ: ${b.map(_n).join(', ')}; '
            'అశుభ: ${m.map(_n).join(', ')}; శుభ–అశుభ కలయిక పరీక్ష.');
      case 'C11-05':
      case 'C11-06':
        final lord=_lord(d9,1);
        final affects=_onPlanet(d9,lord);
        final b=affects.where(_benefics.contains).toList();
        final m=affects.where(_malefics.contains).toList();
        final neutral=affects.where((n)=>!_benefics.contains(n)&&!_malefics.contains(n)).toList();
        if(neutral.isNotEmpty)return _pending('D9 1L ${_n(lord)} ప్రభావాలు: ${affects.map(_n).join(', ')}; చంద్ర/బుధ నిర్ణయం అవసరం.');
        final yes=key=='C11-05'?b.isNotEmpty&&m.isEmpty:m.isNotEmpty&&b.isEmpty;
        return _met(yes,'D9 లగ్నాధిపతి ${_description(d9,lord)}. '
            'ప్రభావాలు: ${affects.map(_n).join(', ')}. '
            'లగ్నంపైనా శుభ/అశుభ పరిశీలన అవసరం; ఇది ఉపషరతు ఫలితం.');
      case 'C12-03':
        final seven=_onHouse(d30,7).any(_malefics.contains);
        final eight=_onHouse(d30,8).any(_malefics.contains);
        return _met(seven&&eight,'${_affection(d30,7)}; ${_affection(d30,8)}. '
          '7,8 భావాలు రెండింటిలో పాపగ్రహ సంబంధం పరీక్ష.');
      case 'C15-01':
        return _met(_toHouse(d1,'Saturn',3),
            'D1 ${_description(d1,'Saturn')}; ${_affection(d1,3)}. '
            'శని 3వ స్థానంలో ఉండటం లేదా దృష్టి చూడటం.');
      case 'C16-01':
        return _met(_onHouse(d9,2).any(_malefics.contains),
           '${_affection(d9,2)}; అశుభగ్రహ ప్రభావ పరీక్ష.');
      case 'C16-02':
        final lord=_lord(d9,2);
        return _met(_onPlanet(d9,lord).any(_malefics.contains),
           'D9 2L ${_description(d9,lord)}; సంబంధాలు: '
           '${_onPlanet(d9,lord).map(_n).join(', ')}');
      case 'C17-01':
        final maleficLords=[6,8,12].map((h)=>_lord(d9,h)).toSet();
        final matches=maleficLords.where((p)=>_linkOrHouse(d9,p,5)).toList();
        return _yesOnly(matches.isNotEmpty,'D9 6/8/12 అధిపతులు 5వ భావం/5L సంబంధం: ${matches.map(_n).join(', ')}. '
           'సంబంధం అంటే నిజ జీవితంలో ప్రవర్తన నిర్ధారణ కాదు.');
      case 'C17-02':
        return _yesOnly(_link(d9,_lord(d9,5),_lord(d9,7)),
           'D9 5L ${_n(_lord(d9,5))}; 7L ${_n(_lord(d9,7))}. '
           'యుతి/దృష్టి/పరివర్తన సంబంధ పరీక్ష.');
      case 'C17-03':
        final mv=_link(d9,'Mars','Venus');
        final sat=_link(d9,'Saturn','Mars')||_link(d9,'Saturn','Venus');
        return _met(mv&&!sat, 'D9 కుజ–శుక్ర సంబంధం: $mv; శని ప్రభావం: $sat; '
            'ఇది వ్యక్తిగత ప్రవర్తన నిర్ధారణ కాదు.');
      case 'C17-04':
        final l6=_lord(d9,6);
        final hits=_link(d9,'Venus',l6)||_linkOrHouse(d9,l6,7);
        return _yesOnly(hits,'D9 6L ${_n(l6)}; శుక్రుడు, 7వ భావం/7L సంబంధాలు పరిశీలించాం.');
      case 'C17-05':
        final v=_planet(d9,'Venus'),k=_planet(d9,'Ketu');
        if(v==null||k==null)return _pending('శుక్రుడు/కేతువు స్థానాలు లేవు.');
        return _met(v.signIndex==k.signIndex,
          'D9 ${_description(d9,'Venus')}; ${_description(d9,'Ketu')}; యుతి (ఒకే రాశి) పరిశీలన.');
      case 'C17-06':
        final l8=_lord(d9,8);
        return _yesOnly(_linkOrHouse(d9,l8,4),'D9 8L ${_n(l8)}; '
           '4వ భావం/4L గ్రహసంబంధ పరీక్ష.');
      case 'C18-01':
        final l1=_lord(d9,1),l7=_lord(d9,7);
        final a=[l1,l7].toSet().where((p)=>_ownOrExalted(d9,p)||_debilitated(d9,p)).toList();
        return _met(a.isNotEmpty,
           'D9 1L ${_description(d9,l1)}; 7L ${_description(d9,l7)}; '
           'ఉచ్చ/స్వ/నీచ స్థితుల్లో ${a.map(_n).join(', ')}. '
           'ఇది వివాహాల సంఖ్యను నిర్ధారించదు.');
      case 'C18-02':
        if(_lord(d9,6)=='Venus')return _pending(
          'D9 6L శుక్రుడే. అదే గ్రహాన్ని రెండు వ్యక్తుల యుతి/పరస్పర దృష్టిగా లెక్కించలేం.');
        return _yesOnly(_conjunctionOrMutualAspect(d9,'Venus',_lord(d9,6)),
           'D9 శుక్రుడు: ${_description(d9,'Venus')}; 6L '
           '${_n(_lord(d9,6))}; యుతి/పరస్పర గ్రహదృష్టి పరీక్ష. '
           'వ్యక్తి వృత్తి/ప్రవర్తనపై తీర్పు కాదు.');
      case 'C18-03':
        final tri=[1,5,9].map((h)=>_lord(d9,h)).toSet().toList();
        var linked=false;
        for(var i=0;i<tri.length;i++){
          for(var j=i+1;j<tri.length;j++){
            if(_link(d9,tri[i],tri[j]))linked=true;
          }
        }
        return _met(linked,'D9 త్రికోణాధిపతులు: ${tri.map(_n).join(', ')}. '
          'కనీసం ఇద్దరు వేర్వేరు గ్రహాధిపతుల పరస్పర సంబంధం: $linked. '
          'ఇది మినహాయింపు; ఇతర ప్రతికూల ఫలితాలను ఆటోమేటిక్‌గా ఖాయం చేయరాదు.');
      default:
        return _pending('IF: ${r.ifText}\n'
          'ఈ సూత్రంలోని బలం/అశుభం/రాజయోగం/తారాధిపతి వంటి సమ్మిళిత ప్రమాణాల '
          'గణనకు ప్రత్యేక ధృవీకరణ కావాలి. అందుబాటులోని గ్రహస్థితులు క్రింద ఉన్నాయి.');
    }
  }
}
