import 'astro_models.dart';

/// Modern/tradition-dependent Kalasarpa classification; not a verified Jaimini sutra.
/// Uses sidereal ecliptic longitudes, never the birth Panchanga Karana.
class KalasarpaResult {
  final String status;
  final String? name;
  final String? ruleId;
  final int? rahuHouse;
  final List<String> evidence;
  const KalasarpaResult(this.status, this.name, this.ruleId, this.rahuHouse, this.evidence);
}

class KalasarpaService {
  static const names = [
    'అనంత', 'కులిక', 'వాసుకి', 'శంఖపాల', 'పద్మ', 'మహాపద్మ',
    'తక్షక', 'కర్కోటక', 'శంఖచూడ', 'ఘాతక', 'విషధార', 'శేషనాగ'
  ];
  static const requiredPlanets = ['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'];
  static double norm(double x) => (x % 360 + 360) % 360;

  static KalasarpaResult evaluate(AstroChartResult chart, {double boundaryTolerance = 0.00001}) {
    PlanetPosition? find(String name) {
      for (final p in chart.planets) {
        if (p.name.toLowerCase() == name.toLowerCase()) return p;
      }
      return null;
    }
    final rahu = find('Rahu');
    final ketu = find('Ketu');
    final missing = requiredPlanets.where((name) => find(name) == null).toList();
    if (rahu == null || ketu == null || missing.isNotEmpty) {
      return KalasarpaResult('పరిశీలన పెండింగ్', null, null, null,
        ['అందుబాటులో లేని గ్రహాలు: ${[if(rahu==null) 'Rahu', if(ketu==null) 'Ketu', ...missing].join(', ')}']);
    }
    final axis = norm(ketu.longitude - rahu.longitude);
    if ((axis - 180).abs() > 1.0) {
      return KalasarpaResult('పరిశీలన పెండింగ్', null, null, null,
        ['రాహు–కేతు అక్షం 180°కు అనుగుణంగా లేదు: ${axis.toStringAsFixed(4)}°']);
    }
    final offsets = requiredPlanets.map((name) => norm(find(name)!.longitude - rahu.longitude)).toList();
    final onBoundary = offsets.any((v) => v <= boundaryTolerance || (v-180).abs() <= boundaryTolerance || (v-360).abs() <= boundaryTolerance);
    final forward = offsets.every((v) => v <= 180 + boundaryTolerance);
    final reverse = offsets.every((v) => v >= 180 - boundaryTolerance);
    final house = ((rahu.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
    final id = 'KS-${house.toString().padLeft(2, '0')}';
    final evidence = [
      'రాహువు: ${norm(rahu.longitude).toStringAsFixed(3)}° • కేతువు: ${norm(ketu.longitude).toStringAsFixed(3)}°',
      'లగ్నం నుంచి రాహువు ${house}వ భావం • కేతువు ${((house+5)%12)+1}వ భావం',
      for (var i=0; i<requiredPlanets.length; i++)
        '${requiredPlanets[i]}: ${norm(find(requiredPlanets[i])!.longitude).toStringAsFixed(3)}° • రాహువు నుంచి ${offsets[i].toStringAsFixed(3)}°',
    ];
    if (onBoundary) return KalasarpaResult('సంధి పరిశీలన అవసరం', names[house-1], id, house, evidence);
    if (forward || reverse) return KalasarpaResult('పూర్ణ కాలసర్ప స్థితి (సంప్రదాయ నిర్వచనం)', names[house-1], id, house,
      [...evidence, 'సప్త గ్రహాలూ ఒకే 180° అర్ధచక్రంలో ఉన్నాయి.']);
    return KalasarpaResult('పూర్ణ కాలసర్ప స్థితి లేదు', null, null, house,
      [...evidence, 'సప్త గ్రహాలు రాహు–కేతు అక్షానికి ఇరువైపులా ఉన్నాయి.']);
  }
}
