import '../models/birth_data.dart';
import 'western_ephemeris_service.dart';
import 'western_event_rules.dart';
import 'western_timing_engine.dart';

/// Traditional Western timing contacts, NOT calibrated event probabilities.
/// All methods are calculated at the SAME requested UTC instant.
class WesternV2Hit {
  final String family, moving, target;
  final int aspect;
  final double orb;
  const WesternV2Hit(this.family,this.moving,this.target,this.aspect,this.orb);
  String get ruleId => 'W2-${family == 'Solar Arc' ? 'SA' : family == 'Progressed Moon' ? 'PM' : 'TR'}-${aspect.toString().padLeft(3,'0')}';
}

class WesternV2Report {
  final String eventId;
  final String natalStatus;
  final Map<int,String> houseLords;
  final List<WesternV2Hit> solarArc, progressedMoon, transits;
  final double arc, progressedMoonLongitude;
  final DateTime eventUtc;
  const WesternV2Report({required this.eventId,required this.natalStatus,
    required this.houseLords,required this.solarArc,
    required this.progressedMoon,required this.transits,
    required this.arc,required this.progressedMoonLongitude,
    required this.eventUtc});
  int get independentFamilies => [solarArc,progressedMoon,transits].where((x)=>x.isNotEmpty).length;
  bool get multipleHits => independentFamilies >= 2;
  bool get threeWaySupport => solarArc.isNotEmpty && progressedMoon.isNotEmpty && transits.isNotEmpty;
  String get status => natalStatus != 'REVIEW_REQUIRED'
      ? natalStatus
      : threeWaySupport ? 'THREE_TECHNIQUE_CONTACTS'
      : multipleHits ? 'TWO_TECHNIQUE_CONTACTS' : 'INSUFFICIENT_CONTACTS';
}

class WesternTimingV2 {
  static const hardAspects=<int>[0,90,180];
  static const moonAspects=<int>[0,60,90,120,180];

  static List<WesternV2Hit> contacts(String family,
      Map<String,double> moving,Map<String,double> targets,
      List<int> aspects,double orbLimit) {
    final hits=<WesternV2Hit>[];
    for(final m in moving.entries) {
      for(final t in targets.entries) {
        for(final aspect in aspects) {
          final orb=WesternTimingEngine.aspectOrb(m.value,t.value,aspect.toDouble());
          if(orb!=null && orb<=orbLimit) hits.add(WesternV2Hit(family,m.key,t.key,aspect,orb));
        }
      }
    }
    hits.sort((a,b)=>a.orb.compareTo(b.orb));
    return hits;
  }

  static Future<WesternV2Report> calculate(BirthData birth,DateTime eventUtc,
      String eventType,{double solarArcOrb=1,double moonOrb=1,
      double transitOrb=1}) async {
    if(eventUtc.isBefore(birth.utcDateTime)) throw ArgumentError('Event precedes birth');
    if([solarArcOrb,moonOrb,transitOrb].any((o)=>!o.isFinite || o<=0 || o>3)) {
      throw ArgumentError('Invalid orb');
    }
    final profile=WesternEventRuleBook.find(eventType);
    if(profile==null || profile.id=='end_of_life') {
      throw ArgumentError('Unsupported or sensitive event type');
    }
    final natal=await WesternEphemerisService.sky(birth.utcDateTime,birth);
    final secondary=await WesternEphemerisService.sky(
      WesternTimingEngine.secondaryDate(birth.utcDateTime,eventUtc),birth);
    final transit=await WesternEphemerisService.sky(eventUtc,birth);
    final cusps=await WesternEphemerisService.natalCuspSigns(birth);
    final lords=<int,String>{};
    for(final h in profile.houses) {
      final sign=cusps[h];
      if(sign!=null) lords[h]=WesternNatalHouseLords.rulerOfSign(sign);
    }
    // A natal configuration cannot establish whether an event will occur.
    // Natal Promise is always a review, never an automatic YES.
    final eventPlanets=<String>{...profile.planets,...lords.values};
    final natalTargets=<String,double>{
      for(final p in eventPlanets)
        if(natal.planets.containsKey(p)) p:natal.planets[p]!,
      'Asc':natal.asc,'MC':natal.mc,
      'Desc':WesternTimingEngine.normalize(natal.asc+180),
      'IC':WesternTimingEngine.normalize(natal.mc+180),
    };
    final arc=WesternTimingEngine.signedShortestArc(
      secondary.planets['Sun']!,natal.planets['Sun']!);
    final directed=WesternEphemerisService.rotate(natal,arc);
    final natalAngles=<String,double>{
      'Asc':natal.asc,'MC':natal.mc,
      'Desc':WesternTimingEngine.normalize(natal.asc+180),
      'IC':WesternTimingEngine.normalize(natal.mc+180),
    };
    final directedAngles=<String,double>{
      'Asc':directed.asc,'MC':directed.mc,
      'Desc':WesternTimingEngine.normalize(directed.asc+180),
      'IC':WesternTimingEngine.normalize(directed.mc+180),
    };
    final solar=<WesternV2Hit>[
      ...contacts('Solar Arc',{
        for(final p in eventPlanets)
          if(directed.planets.containsKey(p)) p:directed.planets[p]!,
      },natalAngles,hardAspects,solarArcOrb),
      ...contacts('Solar Arc',directedAngles,{
        for(final p in eventPlanets)
          if(natal.planets.containsKey(p)) p:natal.planets[p]!,
      },hardAspects,solarArcOrb),
    ]..sort((a,b)=>a.orb.compareTo(b.orb));
    final moonPosition=secondary.planets['Moon'];
    if(moonPosition==null) throw StateError('Progressed Moon missing');
    final moon=contacts('Progressed Moon',{'Moon':moonPosition},
      natalTargets,moonAspects,moonOrb);
    final triggers=WesternProgressionPrinciples.forEvent(eventType)?.transitTriggers ?? const <String>[];
    // Transit contact must involve a rule-specific transit planet, not
    // arbitrary transit-to-angle proximity.
    final moving=<String,double>{
      for(final p in triggers)
        if(transit.planets.containsKey(p)) p:transit.planets[p]!,
    };
    final transits=contacts('Transit',moving,natalTargets,
      hardAspects,transitOrb);
    return WesternV2Report(eventId:profile.id,
      natalStatus:'REVIEW_REQUIRED',houseLords:lords,
      solarArc:solar,progressedMoon:moon,transits:transits,
      arc:arc,progressedMoonLongitude:moonPosition,eventUtc:eventUtc);
  }
}
