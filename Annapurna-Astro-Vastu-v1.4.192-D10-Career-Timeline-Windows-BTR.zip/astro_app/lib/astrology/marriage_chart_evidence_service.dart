import 'astro_models.dart';
import 'varga_service.dart';

/// Displays computed D1/D7/D9/D30 positions as evidence, without treating
/// availability of a chart as a successful source-rule predicate.
class MarriageChartEvidenceService {
  static const signs = [
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];
  static const lords = [
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];
  static const planetNames = {
    'Sun': 'సూర్యుడు', 'Moon': 'చంద్రుడు', 'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు', 'Jupiter': 'గురువు', 'Venus': 'శుక్రుడు',
    'Saturn': 'శని', 'Rahu': 'రాహు', 'Ketu': 'కేతు',
  };

  static String chartSummary(AstroChartResult chart, int factor) {
    final v = VargaService.calculate(chart, factor);
    final lagna = v.ascendantSignIndex;
    final seventh = (lagna + 6) % 12;
    final seventhLordName = lords[seventh];
    VargaPlacement? findPlanet(String name) {
      for (final p in v.planets) {
        if (p.name.toLowerCase() == name.toLowerCase()) return p;
      }
      return null;
    }
    int houseFor(VargaPlacement p) => (p.signIndex - lagna + 12) % 12 + 1;
    final lord = findPlanet(seventhLordName);
    final occupants = v.planets.where((p) => p.signIndex == seventh).map(
      (p) => planetNames[p.name] ?? p.name,
    ).join(', ');
    final venus = findPlanet('Venus');
    final jupiter = findPlanet('Jupiter');
    final moon = findPlanet('Moon');
    final lordHouse = lord == null ? 'డేటా లేదు' : '${houseFor(lord)}వ భావం';
    final venusHouse = venus == null ? 'డేటా లేదు' : '${houseFor(venus)}వ భావం';
    final jupiterHouse = jupiter == null ? 'డేటా లేదు' : '${houseFor(jupiter)}వ భావం';
    final moonHouse = moon == null ? 'డేటా లేదు' : '${houseFor(moon)}వ భావం';
    return 'D$factor లగ్నం: ${signs[lagna]} • '
        '7వ రాశి: ${signs[seventh]} • 7వ అధిపతి: '
        '${planetNames[seventhLordName]} • '
        'అధిపతి స్థానం: $lordHouse\n'
        '7వ భావంలోని గ్రహాలు: ${occupants.isEmpty ? 'లేవు' : occupants}\n'
        'శుక్రుడు: $venusHouse • గురువు: $jupiterHouse • చంద్రుడు: $moonHouse';
  }

  static String forFactors(AstroChartResult? chart, Iterable<int> factors) {
    if (chart == null) {
      return 'ముందుగా జాతకం Generate / Saved Chart నుంచి తెరవండి. '
          'మూల నియమం వర్తించిందో ఇంకా నిర్ధారించలేదు.';
    }
    final wanted = factors.toSet().toList()..sort();
    return '${wanted.map((f) => chartSummary(chart, f)).join('\n\n')}\n\n'
        'పైవి నిజంగా గణించిన గ్రహ/భావ స్థానాలు మాత్రమే. '
        'మూల IF–THEN సూత్రం ధృవీకరించకుండా అనుకూలం/ప్రతికూలం నిర్ణయించలేదు.';
  }
}
