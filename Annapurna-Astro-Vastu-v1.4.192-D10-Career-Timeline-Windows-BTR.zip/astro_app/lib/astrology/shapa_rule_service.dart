import 'astro_models.dart';

/// Traditional rules transcribed from శాపాలు.pdf (pages 1–4).
/// Screening indications only, not claims that a person is cursed.
class ShapaRule {
  final String id, title, condition, remedy, source;
  final int page;
  final List<String> planets;
  final List<int> houses;
  final List<String> afflicters;
  const ShapaRule(this.id,this.title,this.condition,this.remedy,
      this.page,this.planets,this.houses,this.afflicters)
      :source='శాపాలు.pdf';
}
class ShapaMatch {
  final ShapaRule rule;
  final String observation;
  const ShapaMatch(this.rule,this.observation);
}
class ShapaRuleService {
  static const rules=<ShapaRule>[
    ShapaRule('SH-01','మాతృ శాప సూచన',
      'కర్కాటక రాశి / చంద్రుడు / నాలుగవ భావం / భావాధిపతి కేతువు చేత దృష్టి లేదా యుతి పొందినప్పుడు (మూలగ్రంథంలో ప్రత్యామ్నాయ షరతులు ఉన్నాయి).',
      'రామేశ్వరంలో సముద్ర స్నానం; లక్ష గాయత్రీ జపం మరియు ఉదకదానం; అర్ధనారీశ్వర యక్ష ప్రదక్షిణ; యథాశక్తి బ్రాహ్మణ భోజనం.',1,
      ['Moon','Ketu'],[4],['Ketu']),
    ShapaRule('SH-02','పితృ శాప సూచన',
      'ధనుస్సు రాశి / గురువు / 2, 5, 9, 12 భావాలలో శుక్ర, బుధ, రాహు, వీరి కలయిక చేత దృష్టి లేదా యుతి.',
      'గయా శ్రాద్ధం; కన్యాదానం, గోదానం, సువర్ణదానం; ప్రదోషకాల శివారాధన; వేదమంత్ర బ్రాహ్మణులకు భోజనం.',1,
      ['Jupiter'],[2,5,9,12],['Venus','Mercury','Rahu']),
    ShapaRule('SH-03','స్త్రీ శాప సూచన',
      'సింహ రాశి / రవి / ఐదవ భావం మీద శుక్ర, శని, రాహు, కేతువుల కలయిక, దృష్టి లేదా యుతి.',
      'నారాయణ నాగబలి; మృత్యుంజయ జపం; శివారాధన.',1,
      ['Sun'],[5],['Venus','Saturn','Rahu','Ketu']),
    ShapaRule('SH-04','కులదేవత శాప సూచన',
      'నాలుగవ భావం / దాని అధిపతి మీద దృష్టి లేదా యుతి.',
      'కులదేవత ఆరాధన; శివ మరియు విష్ణు ఆరాధన; అనాథలకు అన్నదానం.',2,
      [],[4],[]),
    ShapaRule('SH-05','సర్ప / నాగ శాప సూచన',
      'రాహువుకు సంబంధిత భావం / భావాధిపతితో దృష్టి లేదా యుతి.',
      'నాగ ప్రతిష్ఠ, సర్పబలి; గో, భూ, తిల, సువర్ణ దానములు; సర్ప సంస్కారం.',2,
      ['Rahu'],[],[]),
    ShapaRule('SH-06','గురువు శాప సూచన',
      'గురువుకు సంబంధిత భావం / భావాధిపతితో దృష్టి లేదా యుతి.',
      'బ్రాహ్మణులకు అన్నదానం; చాంద్రాయణ వ్రతం; ప్రజాపత్య వ్రతం; రామేశ్వర స్నానం, చెల్లం దానం; గో, భూ, స్వర్ణ, పంచ రత్న దానములు.',2,
      ['Jupiter'],[],[]),
    ShapaRule('SH-07','బ్రాహ్మణ శాప సూచన',
      'ధనుస్సు / మీనము భావస్థానము ఆధారంగా బ్రాహ్మణ శాప సూచన.',
      'గురు శాపమునకు గల పరిహారములు.',2,
      ['Jupiter'],[],[]),
    ShapaRule('SH-08','కన్యా శాప సూచన',
      'శుక్రునకు భావం / భావాధిపతితో దృష్టి లేదా యుతి.',
      'కన్యాదానం; లక్ష నారాయణ మంత్ర జపం; గోదానం; బ్రాహ్మణులకు శయ్యా, వస్త్ర దానం.',3,
      ['Venus'],[],[]),
    ShapaRule('SH-09','భ్రాతృ శాప సూచన',
      'కుజునకు భావం / భావాధిపతితో దృష్టి లేదా యుతి.',
      'విష్ణు సహస్రనామ పారాయణ; చాంద్రాయణ వ్రతం; ప్రజాపత్య వ్రతం; అన్నదాన స్థాపన; గో, భూ దానములు.',3,
      ['Mars'],[],[]),
    ShapaRule('SH-10','దృష్టి దోష సూచన',
      'లగ్న / మొదటి భావం లేదా భావాధిపతికి దృష్టి లేదా యుతి.',
      'శివాభిషేకం; మృత్యుంజయ జపం; బ్రాహ్మణులకు వస్త్ర దానం.',3,
      [],[1],[]),
    ShapaRule('SH-11','అభిచార సూచన',
      'రవి మరియు కుజుడు ఆరవ భావంలో ఉండి భావం / భావాధిపతితో దృష్టి లేదా యుతి.',
      'మృత్యుంజయ జపం; కాలభైరవ పూజ; కాలభైరవ హోమం.',3,
      ['Sun','Mars'],[6],[]),
    ShapaRule('SH-12','ప్రేత శాప సూచన',
      'గుళిక సంబంధిత భావం / భావాధిపతితో దృష్టి లేదా యుతి.',
      'గయా శ్రాద్ధం; రుద్రాభిషేకం; సుదర్శన హోమం; యథాశక్తి బ్రాహ్మణ భోజనం.',4,
      [],[],[]),
  ];
  /// Conservative, explicitly incomplete automatic matching. Unverified
  /// alternative clauses are not converted into a positive result.
  static List<ShapaMatch> screen(AstroChartResult chart) {
    final asc=chart.ascendantSignIndex;
    final map={for(final p in chart.planets) p.name:p};
    int? house(String name) {
      final p=map[name];
      if(p==null)return null;
      return ((p.signIndex-asc+12)%12)+1;
    }
    final matches=<ShapaMatch>[];
    // SH-01: Moon in the 4th, conjoined Ketu.
    if(house('Moon')==4 && house('Ketu')==4) {
      matches.add(ShapaMatch(rules[0],
        'చంద్రుడు, కేతువు ఇద్దరూ 4వ భావంలో ఉన్నారు (యుతి — ఒకే రాశి).'));
    }
    // SH-02: Jupiter in one of the named houses with named afflicter.
    if([2,5,9,12].contains(house('Jupiter'))) {
      for(final a in ['Venus','Mercury','Rahu']) {
        if(house(a)==house('Jupiter')) {
          matches.add(ShapaMatch(rules[1],
            'గురువు ${house('Jupiter')}వ భావంలో, $a అదే రాశిలో ఉన్నారు.'));
          break;
        }
      }
    }
    // SH-03: Sun in 5th with an afflicter.
    if(house('Sun')==5) {
      for(final a in ['Venus','Saturn','Rahu','Ketu']) {
        if(house(a)==5) {
          matches.add(ShapaMatch(rules[2],
            'రవి 5వ భావంలో, $a అదే రాశిలో ఉన్నారు.'));
          break;
        }
      }
    }
    // SH-11: both Sun and Mars in 6th, explicit natal condition.
    if(house('Sun')==6 && house('Mars')==6) {
      matches.add(ShapaMatch(rules[10],
        'రవి మరియు కుజుడు ఇద్దరూ 6వ భావంలో ఉన్నారు.'));
    }
    return matches;
  }
}
