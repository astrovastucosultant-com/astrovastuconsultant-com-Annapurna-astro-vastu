/// Source-coverage audit for the developer's Jaimini inventory.
/// These counts are NOT a census of original Sanskrit sutras.
/// No entry here is automatically eligible for predictions, timing, or BTR.
class JaiminiChapterCoverage {
  final String chapter;
  final int? developerEntries;
  final bool originalSourceVerified;
  final String sourceStatus;

  const JaiminiChapterCoverage(this.chapter, this.developerEntries,
      {this.originalSourceVerified = false,
      this.sourceStatus = 'SOURCE_PENDING'});

  bool get eligibleForClassicalCoverage => originalSourceVerified;
  bool get missingInventory => developerEntries == null;
}

class JaiminiSourceCoverage {
  const JaiminiSourceCoverage();

  static const chapters = <JaiminiChapterCoverage>[
    JaiminiChapterCoverage('J1Q1', 63),
    JaiminiChapterCoverage('J1Q2', 124),
    JaiminiChapterCoverage('J1Q3', 36),
    JaiminiChapterCoverage('J1Q4', 48),
    JaiminiChapterCoverage('J2Q1', 8),
    JaiminiChapterCoverage('J2Q2', null),
    JaiminiChapterCoverage('J2Q3', 5),
    JaiminiChapterCoverage('J2Q4', null, sourceStatus: 'PARTIAL_SOURCE_REPORTED'),
    JaiminiChapterCoverage('J3Q1', null),
    JaiminiChapterCoverage('J3Q2', null),
    JaiminiChapterCoverage('J3Q3', null),
    JaiminiChapterCoverage('J3Q4', 9),
  ];

  int get knownDeveloperEntries => chapters.fold<int>(
      0, (total, c) => total + (c.developerEntries ?? 0));
  int get chaptersWithoutInventory =>
      chapters.where((c) => c.missingInventory).length;
  int get inventoriedChapters =>
      chapters.where((c) => !c.missingInventory).length;

  /// A source-edition sutra census is required before a classical percentage
  /// is meaningful. null deliberately means 'unknown', not zero percent.
  double? classicalSutraCoveragePercent({
    required int? verifiedMappedSutras,
    required int? totalSutrasInLockedEdition,
  }) {
    if (verifiedMappedSutras == null || totalSutrasInLockedEdition == null ||
        totalSutrasInLockedEdition <= 0 || verifiedMappedSutras < 0 ||
        verifiedMappedSutras > totalSutrasInLockedEdition) {
      return null;
    }
    return verifiedMappedSutras * 100 / totalSutrasInLockedEdition;
  }
}
