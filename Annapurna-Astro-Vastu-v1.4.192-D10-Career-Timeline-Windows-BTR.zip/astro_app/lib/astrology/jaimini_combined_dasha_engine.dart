import 'jaimini_multilevel_prediction.dart';
import 'jaimini_period_result_gate.dart';
import 'jaimini_rule_audit_registry.dart';

/// Cumulative, auditable MD -> AD -> PD -> Prana result assembly.
/// It combines *independently calculated* period evidence; it does not infer
/// Pratyantara/Prana dates, planetary longitudes or rule matches.
class JaiminiCombinedDashaResult {
  final JaiminiPeriodLevel selectedLevel;
  final DateTime start;
  final DateTime end;
  final List<JaiminiPeriodResult> results;
  final Map<String, List<JaiminiPeriodLevel>> supportedAtLevels;
  final Set<String> transitConfirmedRuleIds;
  final List<String> warnings;

  const JaiminiCombinedDashaResult({required this.selectedLevel,
    required this.start, required this.end, required this.results,
    required this.supportedAtLevels, required this.transitConfirmedRuleIds,
    required this.warnings});
}

class JaiminiCombinedDashaEngine {
  static const hierarchy = <JaiminiPeriodLevel>[
    JaiminiPeriodLevel.maha, JaiminiPeriodLevel.antara,
    JaiminiPeriodLevel.pratyantara, JaiminiPeriodLevel.prana,
  ];

  static JaiminiCombinedDashaResult combine({
    required JaiminiPeriodLevel selectedLevel,
    required Map<JaiminiPeriodLevel, JaiminiPeriodEvidence> periods,
    required Iterable<JaiminiRuleAuditRecord> verifiedRuleCandidates,
    required Map<String, String> topics,
    required Map<String, String> teluguResults,
    Set<String> calculatedTransitRuleIds = const {},
    DateTime? birthDate,
    bool requireTransitConfirmation = false,
  }) {
    final index = hierarchy.indexOf(selectedLevel);
    if (index < 0) {
      throw ArgumentError('Select maha, antara, pratyantara or prana');
    }
    final levels = hierarchy.take(index + 1).toList();
    final missing = levels.where((level) => !periods.containsKey(level)).toList();
    if (missing.isNotEmpty) {
      throw StateError('Missing calculated dasha evidence: $missing');
    }
    final chosen = levels.map((level) => periods[level]!).toList();
    var start = chosen.first.start;
    var end = chosen.first.end;
    for (var i = 0; i < chosen.length; i++) {
      final p = chosen[i];
      if (p.level != levels[i] || !p.start.isBefore(p.end)) {
        throw StateError('Invalid or mismatched period evidence');
      }
      if (p.start.isAfter(start)) start = p.start;
      if (p.end.isBefore(end)) end = p.end;
    }
    if (!start.isBefore(end)) {
      throw StateError('Dasha intervals do not overlap');
    }
    final warnings = <String>[];
    if (calculatedTransitRuleIds.isEmpty) {
      warnings.add('గోచార గణన ఆధారాలు అందలేదు; గోచార నిర్ధారణ చూపలేదు.');
    }
    final evidenceByRule = <String, List<String>>{};
    final supported = <String, List<JaiminiPeriodLevel>>{};
    for (final p in chosen) {
      for (final id in p.activatedRuleIds) {
        final evidence = p.evidenceByRuleId[id] ?? const <String>[];
        if (!evidence.any((item) => item.trim().isNotEmpty)) continue;
        supported.putIfAbsent(id, () => []).add(p.level);
        evidenceByRule.putIfAbsent(id, () => []).addAll(evidence);
      }
    }
    final eligibleIds = supported.keys.where((id) =>
      !requireTransitConfirmation || calculatedTransitRuleIds.contains(id)).toSet();
    final composite = JaiminiPeriodEvidence(level: selectedLevel,
      start: start, end: end,
      activeSigns: chosen.last.activeSigns,
      activatedRuleIds: eligibleIds,
      evidenceByRuleId: evidenceByRule,
      transitSupportedRuleIds: calculatedTransitRuleIds);
    var results = JaiminiMultilevelPrediction.evaluate(
      verifiedRuleCandidates: verifiedRuleCandidates,
      topics: topics, teluguResults: teluguResults, period: composite);
    if (birthDate != null) {
      // The period may span a birthday; use the beginning of the selected
      // intersection as the conservative age relevance reference.
      final age = start.year - birthDate.year -
          ((start.month < birthDate.month ||
              (start.month == birthDate.month && start.day < birthDate.day)) ? 1 : 0);
      results = results.where((r) {
        if (age < 0) return false;
        if (age < 16 && (r.topic == 'marriage' || r.topic == 'career' ||
            r.topic == 'business')) return false;
        return true;
      }).toList();
    }
    return JaiminiCombinedDashaResult(selectedLevel: selectedLevel,
      start: start, end: end, results: results,
      supportedAtLevels: supported,
      transitConfirmedRuleIds: eligibleIds.intersection(calculatedTransitRuleIds),
      warnings: warnings);
  }
}
