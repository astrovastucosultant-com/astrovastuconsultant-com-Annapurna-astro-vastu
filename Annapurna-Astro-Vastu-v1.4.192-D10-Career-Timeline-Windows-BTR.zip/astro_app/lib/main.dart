import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'screens/birth_details_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AnnapurnaAstroVastuApp());
}

class _DesktopTabletScrollBehavior extends MaterialScrollBehavior {
  const _DesktopTabletScrollBehavior();

  @override
  Set<PointerDeviceKind> get dragDevices => const {
        PointerDeviceKind.touch,
        PointerDeviceKind.mouse,
        PointerDeviceKind.stylus,
        PointerDeviceKind.invertedStylus,
        PointerDeviceKind.trackpad,
      };
}

class AnnapurnaAstroVastuApp extends StatelessWidget {
  const AnnapurnaAstroVastuApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF7B1E2B);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'అన్నపూర్ణ ఆస్ట్రో వాస్తు',
      scrollBehavior: const _DesktopTabletScrollBehavior(),
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFFFFAF7),
        cardColor: Colors.white,
        canvasColor: Colors.white,
        dividerColor: const Color(0xFFE4D7D9),
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          labelStyle: TextStyle(color: Color(0xFF6F3A43)),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF7B1E2B),
          foregroundColor: Colors.white,
        ),
      ),
      builder: (context, child) => _TraditionNotice(child: child ?? const SizedBox.shrink()),
      home: const BirthDetailsScreen(),
    );
  }
}

/// App-wide attribution and a single, dismissible interpretation notice.
/// Rule provenance and actual evidence remain the responsibility of each engine.
class _TraditionNotice extends StatefulWidget {
  const _TraditionNotice({required this.child});
  final Widget child;
  @override
  State<_TraditionNotice> createState() => _TraditionNoticeState();
}

class _TraditionNoticeState extends State<_TraditionNotice> {
  bool visible = true;
  @override
  Widget build(BuildContext context) => Column(children: [
    if (visible)
      Material(
        color: const Color(0xFFFFF1D6),
        child: SafeArea(
          bottom: false,
          child: Row(children: [
            const Expanded(child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              child: Text(
                'సిద్ధాంతి మల్లికార్జున — జ్యోతిష్య నియమాల విశ్లేషణ. '
                'ఇవి సంప్రదాయ వ్యాఖ్యానాలు; శాస్త్రీయంగా నిరూపితమైన సంఘటన అంచనాలు కావు.',
                style: TextStyle(fontSize: 11, color: Color(0xFF60440D)),
              ),
            )),
            IconButton(
              tooltip: 'సూచన మూసివేయండి',
              icon: const Icon(Icons.close, size: 18),
              onPressed: () => setState(() => visible = false),
            ),
          ]),
        ),
      ),
    Expanded(child: widget.child),
  ]);
}
