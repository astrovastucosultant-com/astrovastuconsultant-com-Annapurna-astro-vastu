# Jaimini source update — verified scope

This update expands topic filtering (marriage, education, children, family, business), adds a period-activation regression test, and clarifies the UI that no event predictions are available without verified source-linked rule matches.

## Not complete
- No primary-source-verified comprehensive Jaimini rule catalog is connected to the UI.
- Pratyantardasha, pranadasha and daily prediction screens are not implemented end-to-end.
- No Flutter SDK is available in this environment; `flutter analyze`, `flutter test`, and APK build were NOT run.
- No chart-based prediction, percentage, or specific timing claim has been validated.

This package is NOT a complete Jaimini prediction engine or a tested APK.
