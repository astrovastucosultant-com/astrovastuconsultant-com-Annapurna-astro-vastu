# Jaimini age-relevance update (2026-10-19)

Implemented in `lib/screens/chart_screen.dart`:
- AD sheet calculates completed age on evaluation date (today if AD is active, otherwise midpoint with explicit label).
- Age-contextual Telugu event interpretation: 0–5, 6–12, 13–17, 18+; career/children/property/wealth and education categories change according to age.
- Non-age-relevant topics display a neutral grey score badge and 'వయస్సుకు వర్తించదు' rather than a misleading red/green judgment. Underlying rule evidence and audit remain accessible.
- Event detail displays age-aware interpretation when opened from AD cards.

Limitations: No verified daily planetary transit calculation was added. Active AD is evaluated for the current date, but within one AD daily scores may remain unchanged until the underlying timing engine is extended. The age bands are app presentation conventions, not classical sutra rules. Flutter analyze and APK build NOT RUN in this environment.
