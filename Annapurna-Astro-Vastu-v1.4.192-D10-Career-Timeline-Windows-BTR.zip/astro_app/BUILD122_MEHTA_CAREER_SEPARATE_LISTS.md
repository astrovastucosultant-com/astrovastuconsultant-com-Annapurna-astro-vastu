# Build122 — S.K. Mehta business/service occupation lists

Changes in S.K. Mehta section only:

- Tappable Business → chart-related example business list.
- Tappable Service → chart-related job/service occupation list.
- One tap on occupation → horoscope inspection (house-lord and house-occupant reasons); next tap → Mehta portfolio source, rule trace.
- List access present on Mehta home screen and within "ధనం / వ్యాపారం" / "ఉద్యోగం / వృత్తి" expansion sections.
- Modern occupational examples are *editorial extensions of Mehta's planetary portfolios*; NOT claimed to be explicit numbered Mehta horoscope combinations or certain predictions.
- Career choices are selected from 7/10/2/11 (business) and 10/6/11/2 (service) house significators. No D10, Ashtakavarga, BPHS or other authors' methods are imported into Mehta panel.
- No fake per-occupation percentages or promised outcomes. Practical qualifications, skills and market/financial evaluation matter.
- All older source files except chart_screen.dart and pubspec.yaml untouched; added one service, one screen, one test, this note.

Validate via GitHub Android APK workflow. Static/source integrity does **not** establish runtime UI or predictive correctness.
