# Jaimini cumulative MD/AD/PD/Prana and transit adapter

Added `lib/astrology/jaimini_combined_dasha_engine.dart`.

- Selecting MD considers MD evidence; AD considers MD+AD; PD considers MD+AD+PD; Prana considers all four.
- Results are de-duplicated by audited rule ID through the existing period result gate, not by averaging scores or inventing predictions.
- The effective result date range is the intersection of calculated dasha intervals.
- Transit rule IDs must be independently calculated. Optional strict transit confirmation can filter results; without it, results remain dasha-based and transit is not claimed.
- An age filter excludes career/business/marriage results before age 16 as a display policy, not a claim of astrological validity.
- Existing Flutter UI is unchanged; the new adapter is **not yet wired into the Jaimini screen**. The existing chart, other modules, and build workflow remain untouched.
- No Flutter SDK was available here; compilation and APK testing are **NOT RUN**.
- PD and Prana calculation methods, source verification, transit ephemeris integration, and UI tap handlers require further work.
