import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_event_rules.dart';

void main() {
  test('Traditional house rulers are indexed Aries through Pisces', () {
    expect(WesternNatalHouseLords.rulerOfSign(0), 'Mars');
    expect(WesternNatalHouseLords.rulerOfSign(7), 'Mars');
    expect(WesternNatalHouseLords.rulerOfSign(11), 'Jupiter');
    expect(() => WesternNatalHouseLords.rulerOfSign(12), throwsRangeError);
  });
  test('House lord evidence is explicitly non-final', () {
    final result = WesternNatalHouseLords.auditEventHouse(
      eventType:'Marriage', cuspSignIndex:6, contactingPlanet:'Venus');
    expect(result['houseLordContact'], true);
    expect(result['status'], 'RULE_CHECK_ONLY');
  });
}
