import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/jaimini_source_coverage.dart';

void main() {
  const audit = JaiminiSourceCoverage();
  test('Developer inventory reconciles to 293 across 7 chapters', () {
    expect(audit.knownDeveloperEntries, 293);
    expect(audit.inventoriedChapters, 7);
    expect(audit.chaptersWithoutInventory, 5);
  });
  test('Unknown original sutra census never becomes a false percentage', () {
    expect(audit.classicalSutraCoveragePercent(
      verifiedMappedSutras: null, totalSutrasInLockedEdition: null), isNull);
    expect(audit.classicalSutraCoveragePercent(
      verifiedMappedSutras: 1, totalSutrasInLockedEdition: 0), isNull);
    expect(audit.classicalSutraCoveragePercent(
      verifiedMappedSutras: 12, totalSutrasInLockedEdition: 10), isNull);
  });
  test('No inventory record claims classical source verification', () {
    expect(JaiminiSourceCoverage.chapters.every(
      (c) => !c.eligibleForClassicalCoverage), isTrue);
  });
  test('Partial source is not the same as verified sutras', () {
    final chapter = JaiminiSourceCoverage.chapters
        .firstWhere((c) => c.chapter == 'J2Q4');
    expect(chapter.sourceStatus, 'PARTIAL_SOURCE_REPORTED');
    expect(chapter.originalSourceVerified, isFalse);
  });
}
