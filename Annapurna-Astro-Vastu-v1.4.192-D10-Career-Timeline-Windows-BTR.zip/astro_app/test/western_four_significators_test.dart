import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_ephemeris_service.dart';
import 'package:astro_app/astrology/western_progression_significators.dart';
void main() {
  test('four indicators', () {
    const natal=WesternSky({'Sun':15,'Moon':110,'Venus':90,'Mars':220},0,90);
    const secondary=WesternSky({'Sun':32,'Moon':90},0,90);
    const solar=WesternSky({'Sun':20,'Moon':115,'Venus':95,'Mars':225},5,95);
    final r=WesternFourSignificators.assess(natal,secondary,solar,
      previousSun:29.9,nextSun:32.5);
    expect(r.sunSignChangeInWindow,true);
    expect(r.contacts.any((c)=>c.group=='Progressed Moon'&&c.natal=='Venus'),true);
    expect(r.contacts.any((c)=>c.group=='Solar Arc Directed Angles'),true);
    expect(r.contacts.any((c)=>c.group=='Solar Arc Personal Planets'),true);
  });
}
