import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/western_event_btr.dart';
import '../lib/astrology/western_event_rules.dart';

void main() {
  test('traditional house ruler mapping', () {
    expect(WesternNatalHouseLords.rulerOfSign(0), 'Mars');
    expect(WesternNatalHouseLords.rulerOfSign(6), 'Venus');
    expect(WesternNatalHouseLords.rulerOfSign(11), 'Jupiter');
  });
  test('child aliases use 5th-house profile', () {
    expect(WesternEventRuleBook.find('First child')?.id, 'children');
    expect(WesternEventRuleBook.find('Second child')?.id, 'children');
  });
  test('verified cusp map is opt-in and does not imply exact BTR', () {
    expect(WesternEventRuleBook.find('Marriage')?.houses.contains(7), true);
  });
}
