import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_btr_decision.dart';

void main() {
  test('correlated solar arc, naibod, symbolic count as one family', () {
    final evidence = List.generate(3, (_) => <String,double>{
      'Solar Arc':0.99,'Naibod':0.99,'1° Symbolic':0.99});
    final result=WesternBtrDecisionEngine.assess(evidence);
    expect(result.sufficient,isFalse);
    expect(result.status,'INSUFFICIENT_RULE_EVIDENCE');
  });
  test('independent families across all three events give provisional result', () {
    final evidence=List.generate(3, (_) => <String,double>{
      'Solar Arc':0.9,'Secondary':0.85,'Tertiary-I':0.8});
    final result=WesternBtrDecisionEngine.assess(evidence);
    expect(result.sufficient,isTrue);
    expect(result.status,'PRELIMINARY_CONTACT_MATCH');
  });
  test('fewer than three events abstains', () {
    expect(WesternBtrDecisionEngine.assess([{'Secondary':1.0}]).status,
      'INSUFFICIENT_EVENTS');
  });
}
