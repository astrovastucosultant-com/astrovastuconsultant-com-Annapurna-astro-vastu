import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jaimini_rule_audit_registry.dart';

void main() {
  test('unverified or evidence-free rules cannot be published', () {
    const rule = JaiminiRuleAuditRecord(
      ruleId: 'JA-TEST', category: 'career', sourceBook: '', chapter: '',
      sutra: '', sourcePage: '', originalText: '', teluguExplanation: '',
      mandatoryConditions: [], exceptionConditions: [], chartEvidence: [],
      status: JaiminiVerificationStatus.pendingSourceCheck, matched: true,
    );
    expect(rule.eligibleForVerifiedResult, isFalse);
    expect(const JaiminiRuleAuditRegistry().publishable([rule]), isEmpty);
  });
}
