import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_event_rules.dart';

void main() {
  test('missing natal house cusps must fail closed', () {
    expect(WesternHouseGateAudit.status(eventType:'Marriage'),
      'INSUFFICIENT_CUSP_EVIDENCE');
    expect(WesternHouseGateAudit.status(eventType:'First child',cuspSigns:{7:3}),
      'INSUFFICIENT_CUSP_EVIDENCE');
    expect(WesternHouseGateAudit.status(eventType:'Marriage',cuspSigns:{7:12}),
      'INSUFFICIENT_CUSP_EVIDENCE');
    expect(WesternHouseGateAudit.status(eventType:'Marriage',cuspSigns:{7:6}),
      'CUSP_AVAILABLE_RULE_MATCH_PENDING');
  });
}
