import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/screens/d10_percent_visual.dart';

void main() {
  test('any confirmed calculated percentage displays without threshold', () {
    expect(D10PercentVisual.percentLabel(true, 5), '5%');
    expect(D10PercentVisual.percentLabel(true, 34), '34%');
    expect(D10PercentVisual.percentLabel(true, 62), '62%');
    expect(D10PercentVisual.percentLabel(true, 100), '100%');
    expect(D10PercentVisual.foreground(true), D10PercentVisual.green);
  });

  test('no D1 to D10 confirm never emits fabricated zero percentage', () {
    expect(D10PercentVisual.percentLabel(false, 0), 'నిర్ధారణ లేదు');
    expect(D10PercentVisual.percentLabel(false, 87), 'నిర్ధారణ లేదు');
    expect(D10PercentVisual.foreground(false), D10PercentVisual.grey);
  });
}
