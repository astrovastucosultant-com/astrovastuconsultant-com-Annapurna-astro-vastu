import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/kalasarpa_service.dart';

AstroChartResult chart(List<double> degrees) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 0, engineVersion: 'test',
  planets: [
    for (var i=0; i<9; i++) PlanetPosition(
      name: [...KalasarpaService.requiredPlanets, 'Rahu', 'Ketu'][i],
      shortName: '', longitude: degrees[i], latitude: 0, speed: 0),
  ],
);
void main() {
  test('seven planets on same semicircle', () {
    final r = KalasarpaService.evaluate(chart([20,40,60,80,100,120,140,0,180]));
    expect(r.ruleId, 'KS-01');
    expect(r.status, contains('పూర్ణ'));
  });
  test('planet on other semicircle rejects full classification', () {
    final r = KalasarpaService.evaluate(chart([20,40,60,80,100,120,220,0,180]));
    expect(r.ruleId, isNull);
  });
  test('node boundary is not classified as unambiguous', () {
    final r = KalasarpaService.evaluate(chart([0,40,60,80,100,120,140,0,180]));
    expect(r.status, 'సంధి పరిశీలన అవసరం');
  });
}
