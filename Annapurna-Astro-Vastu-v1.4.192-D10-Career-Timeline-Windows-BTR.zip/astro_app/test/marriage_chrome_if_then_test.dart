import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/marriage_chrome_if_then_engine.dart';
import 'package:astro_app/astrology/varga_service.dart';

void main() {
  test('all 43 source clauses are indexed in 18 original sections', () {
    const rules=MarriageChromeIfThenEngine.rules;
    expect(rules.length,43);
    expect(MarriageChromeIfThenEngine.sectionTitles.length,18);
    expect(rules.map((e)=>e.id).toSet().length,43);
    for(final rule in rules){
      expect(rule.page,inInclusiveRange(1,6));
      expect(rule.section,inInclusiveRange(1,18));
      expect(rule.ifText.trim(),isNotEmpty);
      expect(rule.thenText.trim(),isNotEmpty);
    }
    expect(rules.where((e)=>e.section==11).length,6);
    expect(rules.where((e)=>e.section==17).length,6);
  });

  test('absence of chart is not a positive result', () {
    for(final rule in MarriageChromeIfThenEngine.rules){
      final result=MarriageChromeIfThenEngine.evaluate(rule,null);
      expect(result.status,MarriageChromeStatus.needsChart);
      expect(result.isComputed,isFalse);
    }
  });

  test('direct D9 Venus and Ketu conjunction has traceable IF–THEN result', () {
    final chart=AstroChartResult(julianDay:2451545.0,
      ayanamsaDegrees:23.0,ascendantLongitude:35.0,engineVersion:'test',
      planets:const [
        PlanetPosition(name:'Sun',shortName:'Su',longitude:2,latitude:0,speed:1),
        PlanetPosition(name:'Moon',shortName:'Mo',longitude:13,latitude:0,speed:1),
        PlanetPosition(name:'Mars',shortName:'Ma',longitude:24,latitude:0,speed:1),
        PlanetPosition(name:'Mercury',shortName:'Me',longitude:34,latitude:0,speed:1),
        PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:49,latitude:0,speed:1),
        PlanetPosition(name:'Venus',shortName:'Ve',longitude:10,latitude:0,speed:1),
        PlanetPosition(name:'Saturn',shortName:'Sa',longitude:87,latitude:0,speed:1),
        PlanetPosition(name:'Rahu',shortName:'Ra',longitude:110,latitude:0,speed:-1),
        PlanetPosition(name:'Ketu',shortName:'Ke',longitude:10,latitude:0,speed:-1),
      ]);
    final rule=MarriageChromeIfThenEngine.rules.firstWhere((e)=>e.id=='C17-05');
    final v=VargaService.calculate(chart,9);
    expect(v.planets.firstWhere((e)=>e.name=='Venus').signIndex,
       v.planets.firstWhere((e)=>e.name=='Ketu').signIndex);
    final result=MarriageChromeIfThenEngine.evaluate(rule,chart);
    expect(result.status,MarriageChromeStatus.matched);
    expect(result.examination,contains('D9'));
  });

  test('combined unconfigured yoga stays pending rather than fabricated YES', () {
    final rule=MarriageChromeIfThenEngine.rules.firstWhere((e)=>e.id=='C05-01');
    expect(rule.ifText,contains('ధనయోగం'));
  });
}
