import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_career_options_service.dart';

const _positions = <PlanetPosition>[
  PlanetPosition(name:'Sun',shortName:'Su',longitude:10,latitude:0,speed:1),
  PlanetPosition(name:'Moon',shortName:'Mo',longitude:44,latitude:0,speed:1),
  PlanetPosition(name:'Mars',shortName:'Ma',longitude:94,latitude:0,speed:1),
  PlanetPosition(name:'Mercury',shortName:'Me',longitude:167,latitude:0,speed:1),
  PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:241,latitude:0,speed:1),
  PlanetPosition(name:'Venus',shortName:'Ve',longitude:197,latitude:0,speed:1),
  PlanetPosition(name:'Saturn',shortName:'Sa',longitude:319,latitude:0,speed:1),
];
AstroChartResult _chart(int ascSign) => AstroChartResult(
  julianDay:2460000,ayanamsaDegrees:24,ascendantLongitude:ascSign*30.0+10,
  planets:_positions,engineVersion:'test',
);
void main() {
  test('Aries chart seventh lord Venus contributes to business list', () {
    final options=MehtaCareerOptionsService.evaluate(_chart(0),MehtaCareerMode.business);
    expect(options, isNotEmpty);
    expect(options.any((o)=>o.planet=='Venus' && o.houseReasons.contains('7 వ భావాధిపతి')),isTrue);
    expect(options.any((o)=>o.name.contains('బుటిక్')),isTrue);
  });
  test('Aries chart tenth lord Saturn contributes to service list', () {
    final options=MehtaCareerOptionsService.evaluate(_chart(0),MehtaCareerMode.service);
    expect(options, isNotEmpty);
    expect(options.any((o)=>o.planet=='Saturn' && o.houseReasons.contains('10 వ భావాధిపతి')),isTrue);
    expect(options.any((o)=>o.name.contains('పారిశ్రామిక')),isTrue);
  });
  test('separate modes expose different occupations and keep sources', () {
    final business=MehtaCareerOptionsService.evaluate(_chart(3),MehtaCareerMode.business);
    final service=MehtaCareerOptionsService.evaluate(_chart(3),MehtaCareerMode.service);
    expect(business.map((o)=>o.name).toSet(),isNot(equals(service.map((o)=>o.name).toSet())));
    for(final o in [...business,...service]) {
      expect(o.source,contains('S.K. Mehta'));
      expect(o.houseReasons,isNotEmpty);
    }
  });
}
