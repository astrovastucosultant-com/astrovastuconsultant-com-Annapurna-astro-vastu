import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d12_book_rule_engine.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('D12 Book108: 59 source rules, 20 examples, 97 notes, 107 fixture assertions', () async {
    final raw = await rootBundle.loadString('assets/d12/D12_Rules_Examples.json');
    final engine = D12BookRuleEngine.fromJsonString(raw);
    final book = engine.rulebook;
    final rules = (book['rules'] as List).cast<Map<String, dynamic>>();
    final cases = (book['examples'] as List).cast<Map<String, dynamic>>();
    expect(rules.length, 59);
    expect(cases.length, 20);
    expect(rules.map((r) => r['id']).toSet().length, 59);
    expect(cases.map((e) => e['id']).toSet().length, 20);
    expect(cases.fold<int>(0, (sum, e) => sum + (e['observations_te'] as List).length), 97);
    final checks = engine.auditExamples();
    expect(checks.length, 20);
    expect(checks.fold<int>(0, (sum, row) => sum + (row['assertions'] as int)), 107);
    expect(checks.fold<int>(0, (sum, row) => sum + (row['passed'] as int)), 107);
    expect(checks.every((row) => (row['missing_rules'] as List).isEmpty), isTrue);
  });

  test('No example fixture facts are silently imported into a current chart', () async {
    final raw = await rootBundle.loadString('assets/d12/D12_Rules_Examples.json');
    final engine = D12BookRuleEngine.fromJsonString(raw);
    expect(engine.evaluate(<String>{'unverified_current_chart'}), isEmpty);
  });
}
