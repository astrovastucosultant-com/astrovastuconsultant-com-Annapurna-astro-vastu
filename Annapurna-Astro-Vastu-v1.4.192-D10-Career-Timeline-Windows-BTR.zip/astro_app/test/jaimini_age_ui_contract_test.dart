import 'package:flutter_test/flutter_test.dart';
import 'dart:io';

void main() {
  test('Jaimini clean UI keeps age/date selectors and removes best-AD cards', () {
    final source = File('lib/screens/chart_screen.dart').readAsStringSync();
    expect(source.contains('రోజువారీ జైమిని పరిశీలన'), isTrue);
    expect(source.contains('వయస్సుకు వర్తించదు'), isTrue);
    expect(source.contains('showDatePicker('), isTrue);
    expect(source.contains('Supportive ADs:'), isFalse);
    expect(source.contains('class _JaiminiCardState'), isTrue);
  });
}
