import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_event_rules.dart';

void main() {
  test('all reference events have distinct rules', () {
    expect(WesternProgressionPrinciples.events.length, 12);
    expect(WesternProgressionPrinciples.events.map((e)=>e.eventId).toSet().length,12);
  });
  test('marriage and child aliases resolve to house lord principles', () {
    expect(WesternProgressionPrinciples.forEvent('Marriage')!.natalHouseLords,[7]);
    expect(WesternProgressionPrinciples.forEvent('First child')!.natalHouseLords,[5]);
    expect(WesternProgressionPrinciples.forEvent('Second child')!.natalHouseLords,[5]);
  });
  test('unknown event never resolves to a generic rule', () {
    expect(WesternProgressionPrinciples.forEvent('unknown'),isNull);
  });
  test('orb must be finite, nonnegative and at most one degree', () {
    expect(WesternProgressionPrinciples.solarArcOrbWithinReference(1),isTrue);
    expect(WesternProgressionPrinciples.solarArcOrbWithinReference(1.1),isFalse);
    expect(WesternProgressionPrinciples.solarArcOrbWithinReference(-0.1),isFalse);
    expect(WesternProgressionPrinciples.solarArcOrbWithinReference(double.nan),isFalse);
  });
}
