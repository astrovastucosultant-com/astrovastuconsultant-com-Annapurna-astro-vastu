import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/marriage_verified_sutra_engine.dart';
import 'package:astro_app/astrology/marriage_book_rule_engine.dart';
import 'package:astro_app/astrology/marriage_rules_ok_registry.dart';

const planets = <String>[
  'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu',
];
AstroChartResult chart(Map<String,double> positions,{double asc=0}) {
  return AstroChartResult(
    julianDay: 2461000,
    ayanamsaDegrees: 24,
    ascendantLongitude: asc,
    engineVersion: 'source-test',
    planets: positions.entries.map((e) => PlanetPosition(
      name: e.key, shortName: e.key.substring(0,2), longitude: e.value,
      latitude: 0,speed: 1,
    )).toList(),
  );
}

// Construct *calculated*, not invented, D9 sign positions with real
// VargaService so the test does not assume a wrong D9 mapping.
double forFactor(int sign, int factor) {
  for (var index=0; index<1440; index++) {
    final degrees=index / 4.0;
    if (VargaService.signForLongitude(degrees,factor) == sign) return degrees;
  }
  throw StateError('No D$factor longitude for sign $sign');
}

void main() {
  test('every verified rule has unique ID and correct PDF page range', () {
    final sutras=MarriageVerifiedSutraEngine.sutras;
    expect(sutras.length,10);
    final ids=<String>{};
    for (final s in sutras) {
      expect(ids.add(s.id),isTrue,reason:s.id);
      expect(s.page,inInclusiveRange(1,39));
      expect(s.sourceCondition,isNotEmpty);
      expect(s.interpretation,isNotEmpty);
      final missing=MarriageVerifiedSutraEngine.evaluate(s.id,null);
      expect(missing.state,MarriageSutraState.needsChart);
      expect(missing.computed,isFalse);
    }
  });

  test('D9 page7: complete 9 planets no 10H vs one in 10H', () {
    final first={for(final p in planets)p:forFactor(0,9)};
    final empty=MarriageVerifiedSutraEngine.evaluate('P07-S04',chart(first));
    expect(empty.state,MarriageSutraState.conditionNotMet);
    expect(empty.matched,isFalse);
    final filled={...first,'Venus':forFactor(9,9)};
    final match=MarriageVerifiedSutraEngine.evaluate('P07-S04',chart(filled));
    expect(match.state,MarriageSutraState.conditionMet);
    expect(match.evidence,contains('10వ భావం'));
    final incomplete=MarriageVerifiedSutraEngine.evaluate('P07-S04',
        chart({'Sun':forFactor(0,9)}));
    expect(incomplete.state,MarriageSutraState.needsPlanetData);
    final topic=MarriageRulesOkRegistry.topics.firstWhere((t)=>t.id=='M-04');
    final r=MarriageBookRuleEngine.evaluate(topic,chart:chart(filled));
    expect(r.decisive,isTrue);
    expect(r.rule,contains('పుట 7'));
    expect(r.result,contains('ఉపషరతు'));
  });

  test('D1 Moon and Ketu 2nd/7th source checks are exact placements', () {
    final birth=chart({'Moon':35, 'Ketu':180}); // Aries asc: 2 and 7
    expect(MarriageVerifiedSutraEngine.evaluate('P12-S10-R01',birth).matched,isTrue);
    expect(MarriageVerifiedSutraEngine.evaluate('P13-S11-R01',birth).matched,isTrue);
    final miss=chart({'Moon':125,'Ketu':125});
    expect(MarriageVerifiedSutraEngine.evaluate('P12-S10-R01',miss).matched,isFalse);
    expect(MarriageVerifiedSutraEngine.evaluate('P13-S11-R01',miss).computed,isTrue);
  });

  test('D1 11L in 7H or 7L in 11H and D1 2L in 11H', () {
    // Aries: 11th ruler Saturn, 7th+2nd ruler Venus.
    final a=chart({'Saturn':180, 'Venus':300});
    expect(MarriageVerifiedSutraEngine.evaluate('P13-S12-R01',a).matched,isTrue);
    expect(MarriageVerifiedSutraEngine.evaluate('P13-S12-R02',a).matched,isTrue);
    final b=chart({'Saturn':70,'Venus':100});
    expect(MarriageVerifiedSutraEngine.evaluate('P13-S12-R01',b).matched,isFalse);
  });

  test('D7 Jupiter and Saturn satisfy source 2H / 7H or condition', () {
    // D7 Aries asc maps to sign 0 from the chosen longitude.
    final lagna=VargaService.signForLongitude(0,7);
    final seventh=(lagna+6)%12;
    final second=(lagna+1)%12;
    final birth=chart({
      'Jupiter':forFactor(seventh,7),
      'Saturn':forFactor(second,7),
    });
    expect(MarriageVerifiedSutraEngine.evaluate('P14-S13-R01',birth).matched,isTrue);
    expect(MarriageVerifiedSutraEngine.evaluate('P15-S14-R01',birth).matched,isTrue);
    final empty=chart({
      'Jupiter':forFactor((lagna+3)%12,7),
      'Saturn':forFactor((lagna+3)%12,7),
    });
    expect(MarriageVerifiedSutraEngine.evaluate('P14-S13-R01',empty).matched,isFalse);
  });

  test('D7 Mars three reference conditions and missing inputs', () {
    final birth=chart({'Mars':35,'Moon':10,'Venus':35});
    for (final s in MarriageVerifiedSutraEngine.sutras
        .where((r)=>r.id.startsWith('P16-'))) {
      final r=MarriageVerifiedSutraEngine.evaluate(s.id,birth);
      expect(r.computed,isTrue);
      expect(r.evidence,contains('D7'));
      expect(r.result,contains('వివాహ'));
    }
    final incomplete=MarriageVerifiedSutraEngine.evaluate('P16-S15-R02',
        chart({'Mars':30}));
    expect(incomplete.state,MarriageSutraState.needsPlanetData);
  });
}
