import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_legacy_rule_link_service.dart';
import 'package:astro_app/astrology/d10_profession_registry.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';

void main() {
  D10VruttiMatch dummy(D10VruttiRule r) =>
      D10VruttiMatch(r, false, false, 0, const [], const [], const []);
  final matches = d10VruttiRulebook.map(dummy).toList();

  test('old gas agency points to its already supplied PDF IF-THEN rule', () {
    final legacy = d10ProfessionRules.firstWhere((r) => r.id == 'D10-PRO-089');
    final linked = D10LegacyRuleLinkService.matchingRules(legacy, matches);
    expect(linked.map((r) => r.rule.id), contains('VR-069'));
    expect(linked.first.rule.condition, contains('రాహువు'));
  });

  test('only exact title aliases + primary planet + deity may match', () {
    const legacy = D10ProfessionRule(id: 'x', category: 'x',
        name: 'గ్యాస్ ఏజెన్సీ', planet: 'Sun', devata: 'Indra',
        extra: '', sourcePage: 1);
    expect(D10LegacyRuleLinkService.matchingRules(legacy, matches), isEmpty);
  });

  test('most old catalog records reuse verified IF-THEN source aliases', () {
    final count = d10ProfessionRules.where((r) =>
      D10LegacyRuleLinkService.matchingRules(r, matches).isNotEmpty).length;
    expect(count, greaterThanOrEqualTo(130));
  });

  test('all 181 old entries stay visible even without a linked predicate', () {
    expect(d10ProfessionRules.length, 181);
    expect(d10VruttiRulebook.length, 336);
    expect(d10ProfessionRules.map((r) => r.id).toSet().length, 181);
  });
}
