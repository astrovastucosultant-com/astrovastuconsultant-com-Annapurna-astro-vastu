import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/screens/marriage_reviewed_sources_screen.dart';

void main(){
  test('only current Chrome PDF six pages are embedded',(){
    expect(ReviewedMarriageSources.pageCounts,
      {ReviewedMarriageSources.chrome:6});
    for(var i=1;i<=6;i++){
      expect(File(ReviewedMarriageSources.assetPath(
        ReviewedMarriageSources.chrome,i)).existsSync(),true);
    }
    expect(Directory('assets/marriage_sources').existsSync(),false);
  });
  test('retired pages cannot be misidentified as current sources',(){
    expect(()=>ReviewedMarriageSources.assetPath(
      ReviewedMarriageSources.handwritten,17),throwsArgumentError);
    expect(()=>ReviewedMarriageSources.assetPath(
      ReviewedMarriageSources.chrome,7),throwsRangeError);
    expect(()=>ReviewedMarriageSources.assetPath('unknown',1),throwsArgumentError);
  });
}
