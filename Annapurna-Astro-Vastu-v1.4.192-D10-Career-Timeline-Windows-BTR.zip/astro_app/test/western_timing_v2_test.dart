import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_timing_v2.dart';
void main(){
 test('hard aspect 1 degree gate and no unrelated contact',(){
  final hits=WesternTimingV2.contacts('Solar Arc',
    {'Venus':90.5},{'Desc':0},WesternTimingV2.hardAspects,1);
  expect(hits.length,1);
  expect(hits.first.aspect,90);
  expect(hits.first.orb,closeTo(0.5,0.00001));
  expect(WesternTimingV2.contacts('Solar Arc',
    {'Venus':92},{'Desc':0},WesternTimingV2.hardAspects,1),isEmpty);
 });
 test('Moon supports soft aspects, Solar Arc does not',(){
  expect(WesternTimingV2.contacts('Progressed Moon',
    {'Moon':60},{'Venus':0},WesternTimingV2.moonAspects,1),isNotEmpty);
  expect(WesternTimingV2.contacts('Solar Arc',
    {'Venus':60},{'Asc':0},WesternTimingV2.hardAspects,1),isEmpty);
 });
}
