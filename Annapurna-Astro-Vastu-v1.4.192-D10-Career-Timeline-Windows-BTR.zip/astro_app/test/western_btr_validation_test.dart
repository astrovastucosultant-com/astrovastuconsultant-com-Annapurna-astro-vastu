import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/western_btr_validation.dart';

void main() {
  test('date-only marriage record covers the full civil day', () {
    final range = WesternBtrValidation.eventDayInterval(DateTime(2008, 4, 16, 15));
    expect(range.$1, DateTime(2008, 4, 16));
    expect(range.$2, DateTime(2008, 4, 17));
  });
  test('three fit events are not independent validation', () {
    expect(WesternBtrValidation.hasIndependentHoldout(
        fittingEventCount: 3, totalKnownEventCount: 3), isFalse);
    expect(WesternBtrValidation.hasIndependentHoldout(
        fittingEventCount: 3, totalKnownEventCount: 4), isTrue);
  });
});
