import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_event_rules.dart';

void main() {
  test('Solar Arc marriage uses Venus/7th lord to DSC or ASC', () {
    expect(WesternProgressionPrinciples.matchesCalculatedContact(
      eventType:'Marriage',method:'Solar Arc',moving:'Venus',natal:'Desc'), isTrue);
    expect(WesternProgressionPrinciples.matchesCalculatedContact(
      eventType:'Marriage',method:'Solar Arc',moving:'Mars',natal:'Desc',
      verifiedHouseLord:'Mars'), isTrue);
    expect(WesternProgressionPrinciples.matchesCalculatedContact(
      eventType:'Marriage',method:'Solar Arc',moving:'Jupiter',natal:'Desc'), isFalse);
  });
  test('Secondary progressed Moon Venus is supportive, not arbitrary contact', () {
    expect(WesternProgressionPrinciples.matchesCalculatedContact(
      eventType:'Marriage',method:'Secondary',moving:'Moon',natal:'Venus'), isTrue);
    expect(WesternProgressionPrinciples.matchesCalculatedContact(
      eventType:'Marriage',method:'Secondary',moving:'Saturn',natal:'Venus'), isFalse);
  });
  test('Unknown event does not score', () {
    expect(WesternProgressionPrinciples.matchesCalculatedContact(
      eventType:'Unknown',method:'Solar Arc',moving:'Venus',natal:'Desc'), isFalse);
  });
}
