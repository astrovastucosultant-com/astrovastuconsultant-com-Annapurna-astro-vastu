import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/marriage_book_rule_engine.dart';
import 'package:astro_app/astrology/marriage_love_source_engine.dart';
import 'package:astro_app/astrology/marriage_rules_ok_registry.dart';

AstroChartResult _chart({bool complete = true}) => AstroChartResult(
  julianDay: 2461000, ayanamsaDegrees: 24, ascendantLongitude: 0.5,
  engineVersion: 'fixture',
  planets: [
    const PlanetPosition(name:'Sun',shortName:'Su',longitude:1.0,latitude:0,speed:1),
    const PlanetPosition(name:'Venus',shortName:'Ve',longitude:2.0,latitude:0,speed:1),
    if (complete) const PlanetPosition(name:'Saturn',shortName:'Sa',longitude:310,latitude:0,speed:1),
    if (complete) ...[
      const PlanetPosition(name:'Moon',shortName:'Mo',longitude:66,latitude:0,speed:1),
      const PlanetPosition(name:'Mars',shortName:'Ma',longitude:270,latitude:0,speed:1),
      const PlanetPosition(name:'Mercury',shortName:'Me',longitude:101,latitude:0,speed:1),
      const PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:200,latitude:0,speed:1),
      const PlanetPosition(name:'Rahu',shortName:'Ra',longitude:132,latitude:0,speed:1),
      const PlanetPosition(name:'Ketu',shortName:'Ke',longitude:312,latitude:0,speed:1),
    ],
  ],
);

MarriageBookTopic _topic(String id) =>
  MarriageRulesOkRegistry.topics.firstWhere((r) => r.id == id);

void main() {
  test('scanned page 9/10 headings are love affairs and love marriage, not arranged', () {
    expect(_topic('M-07').title, contains('ప్రేమ వ్యవహార'));
    expect(_topic('M-07').page, 9);
    expect(_topic('M-08').title, contains('ప్రేమ వివాహ'));
    expect(_topic('M-08').page, 10);
    expect(_topic('M-05').title, contains('వివాహ యోగము'));
    expect(_topic('M-09').title, contains('పెండింగ్'));
  });

  test('M-07 p9 checks D1 7L/5L links and navamsa 07.1', () {
    final result = MarriageLoveSourceEngine.evaluate('M-07',_chart());
    expect(result.evaluated,true);
    expect(result.matched,true); // D1 Venus and Sun in Aries
    expect(result.sourceRule,contains('07/07.1'));
    expect(result.evidence,contains('07 D1'));
    expect(result.evidence,contains('07.1 D9'));
    final topic = MarriageBookRuleEngine.evaluate(_topic('M-07'),chart:_chart());
    expect(topic.decisive,true);
    expect(topic.favourable,true);
    expect(topic.result,contains('తుది నిర్ధారణ కాదు'));
    expect(topic.factors, [1,9]);
  });

  test('M-08 p10 checks natal 7L and natal 5L inside D9', () {
    final result = MarriageLoveSourceEngine.evaluate('M-08',_chart());
    expect(result.evaluated,true);
    expect(result.matched,true);
    expect(result.sourceRule,contains('08/08.1'));
    expect(result.evidence,contains('08, D1 7L'));
    final topic = MarriageBookRuleEngine.evaluate(_topic('M-08'),chart:_chart());
    expect(topic.decisive,true);
    expect(topic.factors,[1,9]);
  });

  test('absence of required lord data never produces a favourable match', () {
    final missing = _chart(complete:false);
    // D9 seventh/fifth/eleventh can require lords besides Venus/Sun/Saturn.
    final result = MarriageLoveSourceEngine.evaluate('M-08',missing);
    expect(result.evaluated,isFalse);
    expect(result.matched,isFalse);
    final topic = MarriageBookRuleEngine.evaluate(_topic('M-08'),chart:missing);
    expect(topic.decisive,false);
  });

  test('no chart keeps rule uncomputed', () {
    for(final id in ['M-07','M-08']) {
      final result = MarriageLoveSourceEngine.evaluate(id,null);
      expect(result.evaluated,false);
      expect(MarriageBookRuleEngine.evaluate(_topic(id)).decisive,false);
    }
  });
}
