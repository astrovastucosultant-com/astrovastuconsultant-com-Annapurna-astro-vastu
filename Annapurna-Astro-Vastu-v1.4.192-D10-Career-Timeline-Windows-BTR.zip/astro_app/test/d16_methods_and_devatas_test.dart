import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/varga_service.dart';

void main() {
  test('D16 Parashara modality starts unchanged', () {
    expect(VargaService.signForLongitude(0, 16), 0); // Aries -> Aries
    expect(VargaService.signForLongitude(30, 16), 4); // Taurus -> Leo
    expect(VargaService.signForLongitude(60, 16), 8); // Gemini -> Sagittarius
  });
  test('D16 Phaladeepika option starts at natal sign', () {
    expect(VargaService.signForLongitude(30, 16, d16Method: D16CalculationMethod.phaladeepika), 1);
    expect(VargaService.signForLongitude(60, 16, d16Method: D16CalculationMethod.phaladeepika), 2);
    expect(VargaService.signForLongitude(30 + 30/16, 16, d16Method: D16CalculationMethod.phaladeepika), 2);
  });
  test('odd/even devata order and final partition', () {
    expect(VargaService.d16DevataForLongitude(0).devata, 'బ్రహ్మ');
    expect(VargaService.d16DevataForLongitude(30).devata, 'సూర్యుడు');
    expect(VargaService.d16DevataForLongitude(30 + 30/16).devata, 'మహేశ్వరుడు');
    expect(VargaService.d16DevataForLongitude(29.99).part, 16);
    expect(VargaService.d16DevataForLongitude(29.99).devata, 'సూర్యుడు');
    expect(VargaService.d16DevataForLongitude(59.99).devata, 'బ్రహ్మ');
  });
}
