import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';
import 'package:astro_app/astrology/d10_career_service.dart';
import 'package:astro_app/astrology/d10_profession_registry.dart';
import 'package:astro_app/astrology/astro_models.dart';

void main() {
  test('both D10 source profession lists are preserved with unique IDs', () {
    expect(d10VruttiRulebook.length, 336);
    expect(d10VruttiRulebook.map((x) => x.category).toSet().length, greaterThanOrEqualTo(12));
    expect(d10VruttiRulebook.map((x) => x.id).toSet().length, 336);
  });

  test('all 181 earlier D10 entries persist alongside 336 IF-THEN entries', () {
    expect(d10ProfessionRules.length, 181);
    expect(d10ProfessionRules.map((x) => x.id).toSet().length, 181);
    expect(d10ProfessionRules.length + d10VruttiRulebook.length, 517);
    expect(d10ProfessionRules.any((r) => r.name == 'ఐఎఫ్‌ఎస్'), isTrue);
  });

  test('new rulebook preserves 10th, 11th and 12th house numbers', () {
    expect(d10VruttiRulebook.firstWhere((r) => r.id == 'VR-215').houses, [10,11]);
    expect(d10VruttiRulebook.firstWhere((r) => r.id == 'VR-225').houses, [3,7,11]);
    expect(d10VruttiRulebook.firstWhere((r) => r.id == 'VR-230').houses, [4,12]);
    expect(d10VruttiRulebook.firstWhere((r) => r.id == 'VR-301').houses, isEmpty);
  });

  test('Sun deity and Venus deity are planets, not fake D10 devatas', () {
    final sun = d10VruttiRulebook.firstWhere((r) => r.condition.contains('సూర్య దేవత'));
    final venus = d10VruttiRulebook.firstWhere((r) => r.condition.contains('శుక్ర దేవత'));
    expect(sun.planets.where((p) => p == 'Sun').length, 1);
    expect(venus.planets.where((p) => p == 'Venus').length, 1);
    expect(sun.deity, isNull);
    expect(venus.deity, isNull);
  });

  test('D10 deities follow odd forward / even reverse sequence', () {
    expect(D10CareerService.devataForLongitude(1).deity, 'Indra');
    expect(D10CareerService.devataForLongitude(31).deity, 'Ananta');
    expect(D10CareerService.devataForLongitude(27.5).deity, 'Ananta');
    expect(D10CareerService.devataForLongitude(57.5).deity, 'Indra');
  });

  test('no D1 tenth house planet means no profession may be confirmed', () {
    // Aries ascendant, all planets strictly in the 1st house, no 10th planet.
    const planets = [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 1, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 2, latitude: 0, speed: 1),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 3, latitude: 0, speed: 1),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 4, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 5, latitude: 0, speed: 1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 6, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 7, latitude: 0, speed: 1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 8, latitude: 0, speed: 1),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 9, latitude: 0, speed: 1),
    ];
    const chart = AstroChartResult(julianDay: 2451545,
        ayanamsaDegrees: 23, ascendantLongitude: 0,
        planets: planets, engineVersion: 'test');
    final evaluated = D10VruttiMatchEngine.evaluate(chart);
    expect(evaluated.length, 336);
    expect(evaluated.any((x) => x.complete), false);
    expect(evaluated.every((x) => x.percent == 0), true);
  });
}
