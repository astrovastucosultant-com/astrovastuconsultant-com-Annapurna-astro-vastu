import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jaimini_condition_matcher.dart';
import 'package:astro_app/astrology/jaimini_rule_audit_registry.dart';

void main() {
  const source = JaiminiRuleAuditRecord(
    ruleId: 'TEST-ONLY', category: 'test', sourceBook: 'test fixture',
    chapter: 'test', sutra: 'test', sourcePage: '', originalText: 'fixture',
    teluguExplanation: '', mandatoryConditions: ['a', 'b'],
    exceptionConditions: ['exception'], chartEvidence: [],
    status: JaiminiVerificationStatus.verified, matched: false);
  const rule = JaiminiEvaluatedRule(source: source,
    conditions: [JaiminiChartCondition('a', JaiminiConditionOperator.isTrue, true),
      JaiminiChartCondition('b', JaiminiConditionOperator.equals, 6)],
    exceptions: [JaiminiChartCondition('exception', JaiminiConditionOperator.isTrue, true)]);
  test('all mandatory conditions required', () {
    final result = const JaiminiConditionMatcher().evaluate(rule, {'a': true, 'b': 5});
    expect(result.matched, false);
  });
  test('active exception vetoes otherwise matched rule', () {
    final result = const JaiminiConditionMatcher().evaluate(rule, {'a': true, 'b': 6, 'exception': true});
    expect(result.matched, false);
  });
  test('fully matched source and conditions produce audit evidence', () {
    final result = const JaiminiConditionMatcher().evaluate(rule, {'a': true, 'b': 6, 'exception': false});
    expect(result.matched, true);
    expect(result.matchedEvidence.length, 2);
  });
}
