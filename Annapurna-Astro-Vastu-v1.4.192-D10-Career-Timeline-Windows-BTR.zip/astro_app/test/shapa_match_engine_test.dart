import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/shapa_match_engine.dart';

PlanetPosition planet(String name, double longitude) => PlanetPosition(
  name:name,shortName:name,longitude:longitude,latitude:0,speed:1);
AstroChartResult chart(double asc,List<PlanetPosition> positions) => AstroChartResult(
  julianDay:2451545,ayanamsaDegrees:24,ascendantLongitude:asc,
  planets:positions,engineVersion:'test');
void main() {
  test('Missing ephemeris never produces negative or positive verdict', () {
    final results=ShapaMatchEngine.evaluate(chart(0,[planet('Sun',10)]));
    expect(results.length,12);
    expect(results.every((r)=>r.matched==null),true);
  });
  test('All rule IDs are reported once and in source order', () {
    final positions=<PlanetPosition>[
      planet('Sun',0),planet('Moon',30),planet('Mars',60),
      planet('Mercury',90),planet('Jupiter',120),planet('Venus',150),
      planet('Saturn',180),planet('Rahu',210),planet('Ketu',30),
    ];
    final results=ShapaMatchEngine.evaluate(chart(0,positions));
    expect(results.length,12);
    expect(results.map((r)=>r.rule.id).toSet().length,12);
    expect(results[0].matched,true); // Ketu and Moon conjoined
    expect(results[11].matched,isNull); // Gulika not calculated
    expect(results[0].evidence,isNotEmpty);
  });
}
