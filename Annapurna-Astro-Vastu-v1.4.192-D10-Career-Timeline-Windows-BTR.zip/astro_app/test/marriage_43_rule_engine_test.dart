import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/marriage_43_rule_engine.dart';
import 'package:astro_app/astrology/marriage_material_registry.dart';
import 'package:astro_app/astrology/marriage_printed_table_engine.dart';

AstroChartResult chart({required int moonSign, required int star}) {
  // Place Moon inside the requested 13°20' nakshatra and sign.
  // Fixtures below use indices whose nakshatra wholly occupies that sign.
  final longitude = (star + 0.1) * (360 / 27);
  assert((longitude / 30).floor() == moonSign);
  return AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 0,
    ascendantLongitude: 0,
    planets: [PlanetPosition(
      name: 'Moon', shortName: 'Mo', longitude: longitude,
      latitude: 0, speed: 0,
    )],
    engineVersion: 'fixture',
  );
}

void main() {
  test('43 indices exist; unknown conditions are never evaluated/pass', () {
    final r = Marriage43RuleEngine.evaluate(
      groom: chart(moonSign: 0, star: 0),
      bride: chart(moonSign: 0, star: 1),
    );
    expect(r.length, 43);
    expect(r.map((x) => x.number).toSet().length, 43);
    expect(r[0].evaluated, isFalse);
    expect(r[2].evaluated, isFalse); // no fake Kuja result
    expect(r[8].evaluated, isFalse); // Bhuta/Ghata not conflated
    expect(r[42].favourable, isNull);
  });

  test('6/8 Moon relation is an adverse Shashtashtaka warning', () {
    // Aries Ashwini -> Virgo Uttara-Phalguni 6/8 relationship.
    final r = Marriage43RuleEngine.evaluate(
      groom: chart(moonSign: 0, star: 0),
      bride: chart(moonSign: 5, star: 12),
    );
    expect(r[3].evaluated, isTrue);
    expect(r[3].favourable, isFalse);
  });

  test('2/12 Moon relation is an adverse Dwir-Dwadasha warning', () {
    // Aries Ashwini -> Taurus Krittika (star index 2, Taurus portion).
    // Star #3 straddles signs; choose index 3 Rohini for Taurus.
    final r = Marriage43RuleEngine.evaluate(
      groom: chart(moonSign: 0, star: 0),
      bride: chart(moonSign: 1, star: 3),
    );
    expect(r[4].evaluated, isTrue);
    expect(r[4].favourable, isFalse);
  });

  test('Nadi and Rajju use complete mutually exclusive printed mappings', () {
    expect(MarriagePrintedTableEngine.nadi.length, 27);
    expect(MarriagePrintedTableEngine.nadi.every((i) => i >= 0 && i <= 2), isTrue);
    // Magha #10 is Antya; Pubba #11 is Madhya (not reversed).
    expect(MarriagePrintedTableEngine.nadi[9], 2);
    expect(MarriagePrintedTableEngine.nadi[10], 1);
    // Ashwini + Magha share Pada Rajju in documented printed mapping;
    // Ashwini + Pubba do not share it.
    final matched = MarriagePrintedTableEngine.evaluate(
      'MM-P04-S08',
      chart(moonSign: 0, star: 0),
      chart(moonSign: 4, star: 9),
    );
    expect(matched.favourable, isFalse);
    final unmatched = MarriagePrintedTableEngine.evaluate(
      'MM-P04-S08',
      chart(moonSign: 0, star: 0),
      chart(moonSign: 4, star: 10),
    );
    expect(unmatched.favourable, isTrue);
  });

  test('D9 has only one-person rules; matching has only two-person rules', () {
    final d9 = MarriageMaterialRegistry.individualForFactor(9);
    final pairs = MarriageMaterialRegistry.matchingRules();
    expect(d9, isNotEmpty);
    expect(pairs, isNotEmpty);
    expect(d9.every((rule) => !rule.requiresTwoCharts), isTrue);
    expect(pairs.every((rule) => rule.requiresTwoCharts), isTrue);
    expect(d9.any((r) => r.id == 'MM-P04-S07'), isFalse);
    expect(pairs.any((r) => r.id == 'MM-P04-S07'), isTrue);
  });
}
