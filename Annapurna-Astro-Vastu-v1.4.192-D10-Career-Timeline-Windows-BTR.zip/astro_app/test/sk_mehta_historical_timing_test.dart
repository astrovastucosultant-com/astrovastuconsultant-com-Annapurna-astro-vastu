import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/dasha_service.dart';
import 'package:astro_app/astrology/sk_mehta_service.dart';

void main() {
  const chart = AstroChartResult(
    julianDay: 0,
    ayanamsaDegrees: 24,
    ascendantLongitude: 10,
    engineVersion: 'unit-test',
    planets: [
      PlanetPosition(
        name: 'Moon', shortName: 'Mo', longitude: 26,
        latitude: 0, speed: 13,
      ),
    ],
  );
  final birth = DateTime(1985, 5, 1, 8);
  final marriage = SkMehtaService.events.firstWhere((e) => e.id == 'M01');

  test('2008 historical scan is bound to 2008, not 2018 or current MD', () {
    for (final kind in [DashaSystemKind.vimshottari, DashaSystemKind.tribhagi]) {
      final audit = SkMehtaService.auditKnownEventYear(
        rule: marriage, kind: kind, chart: chart,
        birthDateTime: birth, year: 2008,
      );
      expect(audit.year, 2008);
      expect(audit.scannedDays, 366); // leap year
      expect(audit.topWindows, isNotEmpty);
      for (final window in audit.topWindows) {
        expect(window.start.year, 2008);
        expect(window.end.year, 2008);
        expect(window.matchedCount, inInclusiveRange(0, 3));
      }
      // No claim that the marriage happened: evidence match is distinct.
      expect(audit.maximumMatchCount, inInclusiveRange(0, 3));
    }
  });

  test('known-event scan must not inspect years before birth', () {
    final audit = SkMehtaService.auditKnownEventYear(
      rule: marriage, kind: DashaSystemKind.tribhagi,
      chart: chart, birthDateTime: birth, year: 1984,
    );
    expect(audit.scannedDays, 0);
    expect(audit.topWindows, isEmpty);
  });

  test('retrospective audit never changes natal dasha or birth balance', () {
    final before = DashaService.system(
      kind: DashaSystemKind.tribhagi,
      chart: chart, birthDateTime: birth,
    );
    SkMehtaService.auditKnownEventYear(
      rule: marriage, kind: DashaSystemKind.tribhagi,
      chart: chart, birthDateTime: birth, year: 2008,
    );
    final after = DashaService.system(
      kind: DashaSystemKind.tribhagi,
      chart: chart, birthDateTime: birth,
    );
    expect(after.birthBalanceYears, before.birthBalanceYears);
    expect(after.startingLord, before.startingLord);
    expect(after.mahadashas.first.start, before.mahadashas.first.start);
  });
}
