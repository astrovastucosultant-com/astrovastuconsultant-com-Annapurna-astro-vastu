import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

AstroChartResult _chart(double shift) => AstroChartResult(
  julianDay: 2460000.5,
  ayanamsaDegrees: 24.0,
  ascendantLongitude: 13.0 + shift,
  engineVersion: 'fixture',
  planets: <PlanetPosition>[
    for (final p in <(String, String, double)>[
      ('Sun', 'Su', 12), ('Moon', 'Mo', 48), ('Mars', 'Ma', 90),
      ('Mercury', 'Me', 144), ('Jupiter', 'Ju', 190),
      ('Venus', 'Ve', 240), ('Saturn', 'Sa', 295),
      ('Rahu', 'Ra', 320), ('Ketu', 'Ke', 140),
    ])
      PlanetPosition(
        name: p.$1, shortName: p.$2,
        longitude: (p.$3 + shift) % 360,
        latitude: 0, speed: 1,
      ),
  ],
);

void main() {
  test('all four original Sarala VII D3 source categories remain indexed', () {
    for (final shift in <double>[0, 37, 91]) {
      final rules = VargaRuleService.allFor(chart: _chart(shift), factor: 3);
      final ids = rules.map((r) => r.ruleId).toList(growable: false);
      expect(ids.toSet().length, ids.length);
      for (final ruleId in <String>[
        'SJ7-D3-01', 'SJ7-D3-02', 'SJ7-D3-03', 'SJ7-D3-04',
        'SJ7-D3-02-CAUTION', 'SJ7-D3-04-NIGADA',
        'D3-SUMMARY-EVIDENCE',
        'D3-REQUEST-YOUNGER', 'D3-REQUEST-ELDER',
        'D3-REQUEST-COUNT', 'D3-REQUEST-LONGEVITY',
        'D3-REQUEST-SIBLING-RELATIONS',
      ]) {
        expect(ids, contains(ruleId));
      }
      expect(rules.every((r) => r.factor == 3), isTrue);
      for (final row in rules.where((r) => r.ruleId.startsWith('D3-REQUEST-'))) {
        expect(row.autoEvaluated, false);
        expect(row.applicable, false);
        expect(row.result.contains('ఖచ్చిత ఫలితం'), true);
      }
      final summary = rules.firstWhere((r) => r.ruleId == 'D3-SUMMARY-EVIDENCE');
      expect(summary.autoEvaluated, true);
      expect(summary.topic.contains('Evidence'), true);
    }
  });
}
