import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/marriage_book_rule_engine.dart';
import 'package:astro_app/astrology/marriage_rules_ok_registry.dart';
import 'package:astro_app/astrology/marriage_printed_table_engine.dart';

AstroChartResult _chart(double moonLongitude, {double ascendant = 22}) => AstroChartResult(
      julianDay: 2461000,
      ayanamsaDegrees: 24,
      ascendantLongitude: ascendant,
      engineVersion: 'test',
      planets: [
        PlanetPosition(name: 'Moon', shortName: 'Mo',
          longitude: moonLongitude, latitude: 0, speed: 1),
        const PlanetPosition(name: 'Venus', shortName: 'Ve',
          longitude: 108, latitude: 0, speed: 1),
        const PlanetPosition(name: 'Jupiter', shortName: 'Ju',
          longitude: 216, latitude: 0, speed: 1),
        const PlanetPosition(name: 'Mars', shortName: 'Ma',
          longitude: 260, latitude: 0, speed: 1),
      ],
    );

MarriageBookTopic _topic(String id) =>
    MarriageRulesOkRegistry.topics.firstWhere((t) => t.id == id);

void main() {
  test('all 62 book topics have individual or matching status (never invented green)', () {
    final first = _chart(5);
    final other = _chart(20);
    expect(MarriageRulesOkRegistry.topics.length, 62);
    for (final topic in MarriageRulesOkRegistry.topics) {
      final result = MarriageBookRuleEngine.evaluate(topic,
        chart: first, partnerChart: topic.requiresTwoCharts ? other : null);
      expect(result.title, isNotEmpty);
      expect(result.factors, isNotEmpty);
      expect(result.examination, isNotEmpty);
      expect(result.rule, isNotEmpty);
      expect(result.remedy, isNotEmpty);
      if (!const {'M-53', 'N-07', 'N-08', 'N-06', 'N-03', 'N-04', 'M-07', 'M-08'}.contains(topic.id)) {
        expect(result.decisive, isFalse,
          reason: '${topic.id} still needs a fully verified source predicate');
        expect(result.favourable, isNull);
      }
    }
  });

  test('separate missing partner/first chart states', () {
    final nadi = _topic('N-07');
    final none = MarriageBookRuleEngine.evaluate(nadi);
    expect(none.status, MarriageBookEvaluationStatus.missingChart);
    final single = MarriageBookRuleEngine.evaluate(nadi, chart: _chart(5));
    expect(single.status, MarriageBookEvaluationStatus.missingPartner);
    expect(single.decisive, isFalse);
  });

  test('source-backed Nadi classification uses real Moon longitudes', () {
    final nadi = _topic('N-07');
    final different = MarriageBookRuleEngine.evaluate(nadi,
        chart: _chart(5), partnerChart: _chart(20));
    expect(different.status, MarriageBookEvaluationStatus.ruleMatched);
    expect(different.favourable, isTrue);
    expect(different.examination, contains('నాడి'));
    final same = MarriageBookRuleEngine.evaluate(nadi,
        chart: _chart(5), partnerChart: _chart(5));
    expect(same.status, MarriageBookEvaluationStatus.ruleNotMatched);
    expect(same.favourable, isFalse);
    expect(_topic('M-53').page, 37);
  });

  test('source-backed Rajju classification is not Rashi Koota', () {
    final rajju = _topic('N-08');
    expect(rajju.title, contains('రజ్జు'));
    final different = MarriageBookRuleEngine.evaluate(rajju,
        chart: _chart(5), partnerChart: _chart(20));
    expect(different.favourable, isTrue);
    final same = MarriageBookRuleEngine.evaluate(rajju,
        chart: _chart(5), partnerChart: _chart(5));
    expect(same.favourable, isFalse);
  });

  test('D9 source page 7 upachaya remains observation, not verdict', () {
    final topic = _topic('M-04');
    final result = MarriageBookRuleEngine.evaluate(topic, chart: _chart(5));
    expect(result.status, MarriageBookEvaluationStatus.chartObserved);
    expect(result.favourable, isNull);
    expect(result.examination, contains('ఉపచయ'));
    expect(result.examination, contains('D9'));
  });

  test('printed source p2/p35 inauspicious pairs match documented table', () {
    final expected = [
      [0,5], [1,8], [3,10], [4,9], [6,11], [2,7],
    ];
    expect(MarriagePrintedTableEngine.badPairs, expected);
    final n04 = MarriageBookRuleEngine.evaluate(_topic('N-04'),
        chart: _chart(5), partnerChart: _chart(170, ascendant: 155));
    expect(n04.status, MarriageBookEvaluationStatus.ruleNotMatched);
    expect(n04.favourable, isFalse);
    expect(n04.examination, contains('అశుభ జంట'));
  });

  test('D7 Mars table can be inspected without calling every absence favourable', () {
    final result = MarriageBookRuleEngine.evaluate(_topic('N-03'),
        chart: _chart(5), partnerChart: _chart(20));
    expect(result.examination, contains('MM-P02-R01'));
    expect(result.result, isNotEmpty);
    expect(result.favourable == true, isFalse);
  });

  test('Varga selector never asks for unsupported factor', () {
    for (final topic in MarriageRulesOkRegistry.topics) {
      for (final factor in MarriageBookRuleEngine.factorsFor(topic)) {
        expect(const {1, 7, 9, 30}.contains(factor), isTrue);
      }
    }
  });
}
