import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/screens/mehta_btr_screen.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('BTR form includes dated events, add/save/search and year 2008',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    final natal = BirthData(
      name: 'Example', localDateTime: DateTime(1985, 5, 8, 7),
      place: 'Guntur', latitude: 16.30, longitude: 80.44,
      timezoneOffsetHours: 5.5, ayanamsa: AyanamsaType.lahiri,
    );
    await tester.pumpWidget(MaterialApp(home: MehtaBtrScreen(birthData: natal)));
    await tester.pump();
    expect(find.textContaining('BTR'), findsWidgets);
    expect(find.textContaining('తేదీ *'), findsWidgets);
    expect(find.textContaining('సంఘటన 1'), findsOneWidget);
  });
}
