import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_event_btr.dart';

void main() {
  test('date-only marriage samples do not inherit an invented clock', () {
    final event=WesternPastEvent('Marriage',DateTime(2008,4,16,0,0),dateOnly:true);
    expect(event.evaluationTimes.length,24);
    expect(event.evaluationTimes.first,DateTime(2008,4,16));
    expect(event.evaluationTimes.last,DateTime(2008,4,16,23));
    expect(event.evaluationTimesAt(stepMinutes:30).length,48);
    expect(event.evaluationTimes.every((e)=>e.day==16 && e.month==4),isTrue);
  });
  test('invalid date-only sampling resolution is rejected', () {
    final event=WesternPastEvent('Marriage',DateTime(2008,4,16),dateOnly:true);
    expect(()=>event.evaluationTimesAt(stepMinutes:7),throwsArgumentError);
  });
  test('timestamped child birth retains its actual event time', () {
    final event=WesternPastEvent('First child',DateTime(2010,5,28,10,10));
    expect(event.evaluationTimes,[DateTime(2010,5,28,10,10)]);
  });
}
