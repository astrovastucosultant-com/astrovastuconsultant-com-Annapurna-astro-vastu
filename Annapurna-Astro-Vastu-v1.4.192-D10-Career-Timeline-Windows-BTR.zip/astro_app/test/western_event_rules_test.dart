import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_event_rules.dart';

void main() {
  test('marriage requires Venus-to-angle in same contact', () {
    expect(WesternEventRuleBook.matchesAngularContact(
      eventType:'Marriage', moving:'Venus', natal:'Asc'), isTrue);
    expect(WesternEventRuleBook.matchesAngularContact(
      eventType:'Marriage', moving:'Venus', natal:'Mars'), isFalse);
    expect(WesternEventRuleBook.matchesAngularContact(
      eventType:'Marriage', moving:'Saturn', natal:'Asc'), isFalse);
  });
  test('first and second child resolve to child event profile', () {
    for(final label in ['First child','Second child','Children']) {
      expect(WesternEventRuleBook.matchesAngularContact(
        eventType:label, moving:'Jupiter', natal:'Asc'), isTrue);
      expect(WesternEventRuleBook.matchesAngularContact(
        eventType:label, moving:'Jupiter', natal:'MC'), isFalse);
    }
  });
  test('unknown events do not pass event gate', () {
    expect(WesternEventRuleBook.matchesAngularContact(
      eventType:'Other', moving:'Venus', natal:'Asc'), isFalse);
  });
}
