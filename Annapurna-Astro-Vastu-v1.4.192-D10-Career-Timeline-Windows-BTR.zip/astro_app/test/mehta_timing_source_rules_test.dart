import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/mehta_timing_source_rules.dart';

void main() {
  test('Mehta timing catalogue has four event-result cards', () {
    final entries = MehtaTimingSourceRules.entries;
    expect(entries.length, 4);
    expect(entries.map((e) => e.id).toSet().length, entries.length);
    expect(entries.map((e) => e.eventId), containsAll(['M01', 'M03', 'M06']));
    for (final entry in entries) {
      expect(entry.checks, isNotEmpty);
      expect(entry.sourceRules, isNotEmpty);
      expect(entry.source, contains('S.K. Mehta'));
      expect(entry.caveat, isNotEmpty);
    }
  });

  test('first and second childbirth both reuse source child-birth rule', () {
    expect(MehtaTimingSourceRules.byId('SK-T-C01').eventId, 'M06');
    expect(MehtaTimingSourceRules.byId('SK-T-C02').eventId, 'M06');
    expect(MehtaTimingSourceRules.byId('SK-T-C02').caveat,
        contains('ప్రత్యేక'));
  });
}
