import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/ashtakoota_36_service.dart';
import 'package:astro_app/astrology/astro_models.dart';
void main(){
 AstroChartResult chart(double moon)=>AstroChartResult(julianDay:2450000,ayanamsaDegrees:24,ascendantLongitude:0,engineVersion:'test',planets:[PlanetPosition(name:'Moon',shortName:'Mo',longitude:moon,latitude:0,speed:13)]);
 test('Identical moon gives the full 36 traditional points',(){final r=Ashtakoota36Service.evaluate(chart(10),chart(10))!;expect(r.points.length,8);expect(r.points.fold<double>(0,(x,p)=>x+p.maxPoints),36);expect(r.total,28); // same nadi is zero: 36-8
 });
 test('All 27 star indices are supported',(){for(int a=0;a<27;a++){for(int b=0;b<27;b++){final r=Ashtakoota36Service.evaluate(chart(a*360/27+0.01),chart(b*360/27+0.01))!;expect(r.points.length,8);for(final p in r.points){expect(p.points>=0,true);expect(p.points<=p.maxPoints,true);}}}});
 test('Missing Moon returns null',(){final noMoon=AstroChartResult(julianDay:0,ayanamsaDegrees:0,ascendantLongitude:0,engineVersion:'test',planets:[]);expect(Ashtakoota36Service.evaluate(noMoon,chart(10)),isNull);});
}
