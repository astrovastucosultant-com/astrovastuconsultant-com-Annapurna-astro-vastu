import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_business_catalog.dart';
import 'package:astro_app/astrology/d10_final_profession_engine.dart';

void main() {
  test('business suggestions follow actual D10 selected profession families', () {
    const families = [
      D10ProfessionCandidate(
        profession: 'Fashion / Beauty / Creative Design',
        evidenceMatchPercent: 75,
        matchedEvidence: ['10L Venus', '10L రాశి వృషభం'],
        availableEvidenceBlocks: 3,
        natureCompatibility: 'Non-Technical Match',
        devataSupport: false,
      ),
      D10ProfessionCandidate(
        profession: 'Banking / Finance',
        evidenceMatchPercent: 67,
        matchedEvidence: ['10L Venus'],
        availableEvidenceBlocks: 3,
        natureCompatibility: 'Non-Technical Match',
        devataSupport: false,
      ),
      D10ProfessionCandidate(
        profession: 'Commercial / Business / Entrepreneurship',
        evidenceMatchPercent: 33,
        matchedEvidence: ['10L Venus'],
        availableEvidenceBlocks: 3,
        natureCompatibility: 'Non-Technical Match',
        devataSupport: false,
      ),
    ];
    final results = D10BusinessCatalog.suggest(families);
    expect(results.length, greaterThanOrEqualTo(10));
    expect(results.any((x) => x.nameTe.contains('బుటిక్')), isTrue);
    expect(results.any((x) => x.nameTe.contains('ఆర్థిక')), isTrue);
    expect(results.any((x) => x.nameTe.contains('ఈ-కామర్స్')), isTrue);
    expect(results.every((x) => x.evidenceMatchPercent >= 0), isTrue);
    expect(results.first.matchedEvidence, contains('10L Venus'));
    expect(results.first.evidenceMatchPercent, 75);
    expect(results.any((x) => x.professionFamily == 'Medicine / Healthcare'), isFalse);
  });

  test('no candidate means no invented business', () {
    expect(D10BusinessCatalog.suggest(const []), isEmpty);
  });

  test('every existing D10 profession family has specific business examples', () {
    for (final family in D10FinalProfessionEngine.professionFamilies) {
      expect(D10BusinessCatalog.optionsByFamily[family.name], isNotEmpty,
          reason: family.name);
    }
  });
}
