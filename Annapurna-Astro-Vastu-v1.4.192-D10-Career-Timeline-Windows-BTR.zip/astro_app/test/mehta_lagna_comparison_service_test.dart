import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_lagna_comparison_service.dart';

PlanetPosition p(String name, int sign) => PlanetPosition(
  name: name,
  shortName: name.substring(0, 2),
  longitude: sign * 30.0 + 12,
  latitude: 0,
  speed: 1,
);

AstroChartResult sample(int lagna, List<PlanetPosition> planets) => AstroChartResult(
  julianDay: 2451545.0,
  ayanamsaDegrees: 24,
  ascendantLongitude: lagna * 30.0 + 2,
  planets: planets,
  engineVersion: 'test',
);

void main() {
  final planets = [
    p('Sun', 0), p('Moon', 3), p('Mars', 7), p('Mercury', 2),
    p('Jupiter', 11), p('Venus', 1), p('Saturn', 9),
  ];

  test('both references review all 12 independent houses', () {
    final result = MehtaLagnaComparisonService.evaluate(sample(0, planets));
    expect(result.natalSign, 'మేషం');
    expect(result.moonSign, 'కర్కాటకం');
    expect(result.houses.length, 12);
    expect(result.houses.map((r) => r.house).toList(),
        List<int>.generate(12, (i) => i + 1));
    expect(result.natalEvidenceHouses, inInclusiveRange(0, 12));
    expect(result.lunarEvidenceHouses, inInclusiveRange(0, 12));
    expect(result.comparativeNote.isNotEmpty, isTrue);
    if (result.natalPercent != null) {
      expect(result.natalPercent!, inInclusiveRange(1, 99));
    }
    if (result.lunarPercent != null) {
      expect(result.lunarPercent!, inInclusiveRange(1, 99));
    }
  });

  test('same sign Lagna/Moon must give exactly equal house evidence', () {
    final result = MehtaLagnaComparisonService.evaluate(sample(3, planets));
    expect(result.natalSign, result.moonSign);
    expect(result.natalPercent, result.lunarPercent);
    for (final row in result.houses) {
      expect(row.natalPercent, row.lunarPercent);
      expect(row.natalSupporting, row.lunarSupporting);
      expect(row.natalCautionary, row.lunarCautionary);
    }
    expect(result.comparativeNote.contains('ఒకే రాశి'), isTrue);
  });

  test('missing Moon has no fabricated 0 or 50 lunar percent', () {
    final result = MehtaLagnaComparisonService.evaluate(sample(0, [p('Sun', 0)]));
    expect(result.moonSign, isNull);
    expect(result.lunarPercent, isNull);
    expect(result.lunarEvidenceHouses, 0);
    expect(result.houses.every((h) => h.lunarPercent == null), isTrue);
  });

  test('no planets means both strengths unknown, not default 50 percent', () {
    final result = MehtaLagnaComparisonService.evaluate(sample(0, []));
    expect(result.natalPercent, isNull);
    expect(result.lunarPercent, isNull);
    expect(result.natalEvidenceHouses, 0);
  });

  test('no double counting: total match counts equal sum over 12 distinct houses', () {
    final result = MehtaLagnaComparisonService.evaluate(sample(0, planets));
    expect(result.natalSupporting,
        result.houses.fold<int>(0, (sum, h) => sum + h.natalSupporting));
    expect(result.natalCautionary,
        result.houses.fold<int>(0, (sum, h) => sum + h.natalCautionary));
    expect(result.lunarSupporting,
        result.houses.fold<int>(0, (sum, h) => sum + h.lunarSupporting));
    expect(result.lunarCautionary,
        result.houses.fold<int>(0, (sum, h) => sum + h.lunarCautionary));
  });
}
