import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/marriage_integrated_catalog.dart';
import 'package:astro_app/astrology/marriage_book_rule_engine.dart';
import 'package:astro_app/astrology/marriage_rules_ok_registry.dart';

void main() {
  test('user supplied partial menu is represented without an extra main', () {
    final sections = MarriageIntegratedCatalog.sections;
    expect(sections.length, 14);
    expect(sections.map((s) => s.id).toSet().length, 14);
    expect(MarriageIntegratedCatalog.allReferencesValid, isTrue);
    expect(sections.first.title, contains('D9'));
    expect(sections.last.auditNote, contains('లేవు'));
  });

  test('each source topic stays pending without chart rather than auto YES', () {
    final topic = MarriageRulesOkRegistry.topics
        .firstWhere((topic) => topic.id == 'M-07');
    final result = MarriageBookRuleEngine.evaluate(topic);
    expect(result.status, MarriageBookEvaluationStatus.missingChart);
    expect(result.decisive, isFalse);
    expect(result.favourable, isNull);
  });

  test('missing source IF THEN does not pretend to have a predicate', () {
    final caste = MarriageIntegratedCatalog.sections
        .firstWhere((s) => s.id == 'IM-04');
    expect(caste.topicIds, isEmpty);
    expect(caste.sutraIds, isEmpty);
    expect(caste.auditNote, contains('IF–THEN'));
  });
}
