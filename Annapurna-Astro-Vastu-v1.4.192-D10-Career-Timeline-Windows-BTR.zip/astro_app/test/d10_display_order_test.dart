import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_display_order.dart';
import 'package:astro_app/astrology/d10_profession_registry.dart';
import 'package:astro_app/astrology/d10_vrutti_match_engine.dart';
import 'package:astro_app/astrology/d10_vrutti_rule_registry.dart';

void main() {
  final source = d10VruttiRulebook.first;
  D10VruttiMatch evidence(bool confirmed, int percent,
      {bool partial = false}) => D10VruttiMatch(
        source, confirmed, confirmed && !partial, percent,
        partial ? const <String>['ఒక గ్రహ సంబంధం ఉంది'] : const <String>[],
        const <String>[], const <String>[]);

  test('Green from any confirmed percentage comes before pink and grey', () {
    final pink = evidence(false, 0, partial: true);
    final grey = evidence(false, 0);
    final green25 = evidence(true, 25, partial: true);
    final green90 = evidence(true, 90);
    expect(D10DisplayOrder.tier(green25), D10EvidenceTier.green);
    final list = D10DisplayOrder.sort([
      D10DisplayEntry.rule(grey),
      D10DisplayEntry.rule(green25),
      D10DisplayEntry.rule(pink),
      D10DisplayEntry.rule(green90),
    ]);
    expect(list.map((x) => x.tier).toList(), [
      D10EvidenceTier.green, D10EvidenceTier.green,
      D10EvidenceTier.pink, D10EvidenceTier.grey,
    ]);
    expect(list[0].evidence!.percent, 90);
    expect(list[1].evidence!.percent, 25);
  });

  test('Older rule with missing IF-THEN is visible in pink but not green', () {
    final item = D10DisplayEntry.old(d10ProfessionRules.first, const []);
    expect(item.tier, D10EvidenceTier.pink);
    expect(item.evidence, isNull);
    expect(item.missingRule, isTrue);
  });

  test('Old catalog best evidence picks larger confirmed score', () {
    final strongest = D10DisplayOrder.strongest([
      evidence(false, 0, partial: true), evidence(true, 39),
      evidence(true, 79),
    ]);
    expect(strongest!.percent, 79);
    expect(D10DisplayOrder.tier(strongest), D10EvidenceTier.green);
  });

  test('No records are deleted by combined sort', () {
    expect(d10VruttiRulebook.length, 336);
    expect(d10ProfessionRules.length, 181);
    final all = D10DisplayOrder.sort([
      for (final r in d10VruttiRulebook)
        D10DisplayEntry.rule(D10VruttiMatch(
          r, false, false, 0, const [], const [], const [])),
      for (final r in d10ProfessionRules)
        D10DisplayEntry.old(r, const []),
    ]);
    expect(all.length, 517);
    expect(all.map((r) => r.id).toSet().length, 517);
  });
}
