# BUILD112 — S.K. Mehta Comprehensive Combination Merge

Base: Build111 v1.4.111 (ZIP SHA256 recorded separately); new version **1.4.112+112**.

- Preserved 81 existing combination registry entries in original order, including their legacy Key–match switch.
- Imported all **85** source-scanned numbered rule summaries via `lib/astrology/mehta_book_catalog.dart` and `assets/mehta/SK_Mehta_85_Rules_Telugu.json`.
- Found **46** scan Rule IDs already represented among the 81 entries and added **39** distinct missing numbered rules, with separate `book:N` keys so old numeric evaluation cases do not shift.
- Combined all **15** Event/Timing rules into S.K. Mehta Combination browsing, while retaining the dedicated timing/synchronization evaluator.
- Total displayed combination entries: **81 + 39 + 15 = 135** (some old registry IDs are multi-context variants).
- Added an ordered C1–C85 index (85/85) plus all 135 registry/timing entries.
- Added displayed scan condition, verification method, historical source result, exceptions, exact printed page citation (when tapped).
- Automated 25 mechanically checkable new conditions only; other new rules are flagged manual/source-review. Sensitive claims are not presented as medical findings or certainty.
- Source-audit flags for C6/C21/C42/C51; existing C21 and C42 legacy automatic matching disabled due to contradiction with supplied scan summary.
- All D12/D7/D10 features and navigation remain in original source (no edits to those module files).
- Flutter toolchain is not available in this environment: structural/static checks were run, but APK compile not certified. Upload the package through GitHub Actions and verify its compile there.

**Important:** The 85-book entries are transcribed Telugu summaries, not page-for-page complete quotations. Their auto-triggers are partial implementation until individually audited against the chart examples.
