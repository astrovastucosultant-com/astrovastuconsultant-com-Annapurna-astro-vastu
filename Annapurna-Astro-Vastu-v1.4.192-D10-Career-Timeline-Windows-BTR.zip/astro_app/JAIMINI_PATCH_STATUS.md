# Jaimini safety patch — 2026-10-19

- Antardasha UI no longer evaluates heuristic event scores merely to discard them.
- Period detail explicitly says W-/M-/C- IDs are not source-verified predictions.
- Antardasha list no longer promises all event results when no verified rule activation is wired.
- Existing MD/AD chart relationship audit remains accessible.

## Not implemented / not verified
- Real source-to-rule mapping and full chart matching.
- Pratyantardasha, Prana dasha, daily predictive UI integration.
- Flutter analyze, tests, and APK build (Flutter SDK unavailable in this environment).

Do not label this archive a complete Jaimini prediction engine.
