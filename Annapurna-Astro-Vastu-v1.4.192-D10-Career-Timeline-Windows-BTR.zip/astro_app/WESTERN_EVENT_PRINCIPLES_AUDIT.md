# Western Progression Event Significators — source addition

Reference: user-supplied `Annapurna_All_Event_Principles.pdf` (3 pages).

Added 12 event categories to `WesternProgressionPrinciples` with natal houses,
natural significators, natal house lords, solar-arc target labels,
progressed-Moon house focus and transit trigger labels. Added category aliases,
profiles, and unit tests. Existing angular-event gate retained.

**Scope limitation:** This is a typed rulebook and look-up API. It is NOT yet
wired to astronomical aspect calculations, transit evaluation, or BTR ranking.
`House5`, `House9` etc. are symbolic target identifiers, not computed cusps.
Rahu/Ketu are source-specific additions and require explicit node ephemeris.
Reference orbs (SA <=1 degree) are heuristics, not probabilities. The user's
marriage/childbirth dates are for historical comparison, not independent proof.

Do not claim timing or BTR is corrected until ephemeris integration, event
contact calculations, backtests, and actual Flutter/device testing pass.
