House lord integration (optional verified natal cusps)
- WesternEventBtr.search(..., verifiedCuspSigns: {5: 4, 7: 6}) 
- WesternEventBtr.refineSeconds(..., verifiedCuspSigns: {5: 4, 7: 6})
- House keys 1..12; sign values Aries=0 through Pisces=11.
- Example sign values above are illustrative ONLY; NOT the user's calculated natal cusps.
- When provided for marriage/children, an angular contact must contain the relevant traditional natal house lord, rather than a generic significator. Missing or invalid required cusp sign fails closed.
- When not supplied, existing legacy significator/angle scoring is preserved, with no claim that house-lord gating occurred.
- House cusp computation, verified ephemeris integration, UI passing cusp signs, full primary directions, and Flutter compile are NOT complete.
