# D10 Career timing clarification — v1.4.189

This build keeps the original 336 IF–THEN career rules, 181 legacy professions,
Green→Pink→Grey ordering, D1→D10 confirmation, and percentage scoring unchanged.

## Changes
- For a fully matching/confirmed profession, show two independent timing sections:
  - historical astrological timing support from 16 years of age to the present
  - prospective timing support in the next 20 years
- Both search monthly Vimshottari MD + AD and Jupiter + Saturn sidereal transits.
- A profession's source-rule score, even 100%, does not prove a dated activation.
- Historical timing support is not confirmation of a real event; events belong
  in the separately saved Career Timeline/BTR evidence log.
- Consecutive qualifying months in one MD/AD are combined to a single window.
- Unconfirmed careers do not receive invented ages or percentages.

## Verification status
- Modified source and tests checked for required file references.
- ZIP CRC/entry integrity checked.
- Actual Dart compile and Flutter release build require GitHub Actions.
