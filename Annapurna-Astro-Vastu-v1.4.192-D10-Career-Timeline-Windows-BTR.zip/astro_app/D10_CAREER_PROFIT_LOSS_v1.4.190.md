# Annapurna Astro Vastu v1.4.190 — D10 Career Profit/Loss/Growth

## New capability
- Tap an IF–THEN profession card → choose **లాభం / నష్టం / మధ్యస్థం · సంవత్సరాలవారీగా**.
- Read profession-specific D1/D10 (2,11 gains; 8,12 uncertainty/expenses) links, separate D2/Indu Lagna wealth **chart-wide** evidence, gains and risks counted separately.
- For confirmed, fully matched profession rules only, scan last 12 and next 36 months at monthly midpoints. Requires Vimshottari MD + AD and *both* Jupiter and Saturn relevant sign/aspect contact. Adjacent evidence-matching months with unchanged MD/AD form one contiguous period.
- Classify gain support, expense/loss risk, mixed, or insufficient; no invented zero/neutral result where no evidence.
- Timeline and Reverse Career Search allow the observed financial events: gain, loss, middle, growth, decline, recovery. BTR compares event types with the dated financial supporting indication, counting the compound financial check at most once; middle/recovery need additional verified event methodology.

## Guardrails and provenance
- Existing 517 D10 profession entries, D9, Green → Pink → Grey sorting, chart suitability % and Reverse Search remain unchanged.
- The provided career IF–THEN PDFs do **not** define a standalone canonical financial profitability model. Extra D1/D10 income/expense links are an app-supplied audit aid, **not** rules quoted from those PDFs.
- D2 evidence comes from the existing `D2DhanaAsthiRegistry` / `D2WealthEvaluationService`; it supports the **whole chart**, not a particular career, so its matches cannot prove business-specific returns.
- 6/8/12 links do not automatically mean loss; they may represent employment, change, overseas or research meanings.
- No scientifically validated probabilities, financial advice, guarantees, or exact appointment dates.
- This package received static source/ZIP integrity checks only. Actual Flutter analyzer/tests/release compilation must occur in GitHub Actions.
