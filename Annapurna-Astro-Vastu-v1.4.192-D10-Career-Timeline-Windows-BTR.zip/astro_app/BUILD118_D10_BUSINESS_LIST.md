# Build118 — D10 Business → specific business list

## User request
In D10's Final Career Interpretation, the generic "Commercial / Business / Entrepreneurship" label should be actionable: tapping the business result should reveal **what specific businesses** are suggested for the actual chart-supported profession families.

## Changes
- The **Final Career Interpretation paragraph itself is tappable**, and a labeled **Business → ఏ వ్యాపారం? జాబితా** button also opens the list.
- New `D10BusinessCatalog` maps all 27 existing D10 profession families to practical, concrete business examples in Telugu. It does **not** introduce new planetary or book rules, assign invented business probabilities, or select business fields unrelated to the chart's returned families.
- The list ranks families using **existing** D10 shortlisted candidates (10L, Nakshatra, sign, conjunction). Per-idea percentage is clearly the family evidence coverage, **not business success chance**.
- Tap an option to see **జాతక పరిశీలన** (10th lord, sign, nakshatra, matched evidence), then use **రూల్ / మూలాధారం** for the existing source rule (when available).
- If D10 is not Gocharastha, the sheet explicitly warns that business is not the confirmed primary work mode.
- Existing Gocharastha/ Agocharastha, D7, D12 and Mehta-only modules are untouched.

## Verification
- Test added: `test/d10_business_catalog_test.dart` for match-based examples, absence of unrelated options, no-candidate behavior, and all 27 profession families having specific options.
- ZIP/structure validation is separate from Flutter compilation. **Flutter tests and APK compilation must be verified in GitHub Actions.**
