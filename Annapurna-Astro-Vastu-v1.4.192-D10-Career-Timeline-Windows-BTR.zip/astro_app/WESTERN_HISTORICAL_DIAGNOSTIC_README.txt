Western historical event diagnostic update (source patch)
- Date-only actual event diagnostics use 12 samples at two-hour intervals
  throughout the IST calendar day, not a fabricated UTC noon event time.
- Each sample is evaluated independently; different sample times are NOT
  combined to manufacture method-family agreement.
- Shows best sample clock (IST), methods observed and rule-gate reason.
- Date-range search's daily reference changed from UTC noon to IST noon.
- Limitations: 2-hour grid can miss contacts; house lord/Primary Directions
  remain incomplete for this diagnostic. Not a validated prediction or BTR.
- No Flutter SDK in this environment. Compile and on-device behavior untested.
