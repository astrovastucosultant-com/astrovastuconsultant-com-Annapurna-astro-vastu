# Western Timing / BTR validation status

This is an **interim audited source patch**, not a complete verified engine.

## Fixed in this patch
- Date-only events no longer combine different methods' best contacts from different sampled hours into an artificial agreement. The single best sampled instant is chosen by independent family count, then exploratory aggregate.

## Not yet verified or complete
- Full mundane Primary Directions end-to-end integration and validation.
- Transits and house-target timing across every event type.
- Independent historical holdout tests and false-positive statistics.
- End-to-end 3pm-4pm BTR and reliable seconds accuracy.
- Flutter compile, unit tests, APK build, device tests (Flutter SDK unavailable here).

No predictive accuracy or exact birth time is asserted.
