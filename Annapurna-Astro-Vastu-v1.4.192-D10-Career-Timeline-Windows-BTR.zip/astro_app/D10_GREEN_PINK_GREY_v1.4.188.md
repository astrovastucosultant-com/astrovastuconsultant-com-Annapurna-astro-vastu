# Annapurna Astro Vastu — D10 v1.4.188

## UI order

Default **All** (336 IF–THEN + 181 legacy = 517 entries), **IF–THEN**, **Old professions**, and search results use one ordered stream:

1. **Green**: D1->D10 confirm is true. Sort high compatibility index (%) first. Even a partially satisfied predicate is green if this underlying confirm is true; its partial-conditions caption remains visible.
2. **Pink**: partial evidence for a rule but no D1->D10 confirm, or an original profession missing a linked IF–THEN rule. No % is shown.
3. **Grey**: no confirm and no matching occupational evidence. No % is shown.

The green percentage is an astrological evidence-matching index, not a validated statistical probability or guarantee. Within pink, list entries with more positive evidence first, and use stable source IDs to break ties. Within grey, source IDs provide stable order. Search relevance is applied only after color priority and evidence ranking; the same rule applies to the reverse-search screen.

Source IF–THEN rules and legacy names are unchanged. D10 profession ranking, activation timing, saved events and BTR continue to use their existing calculations; this is a presentation-order change.

## Changed files
- `lib/astrology/d10_display_order.dart` (new shared, testable ordering)
- `lib/astrology/d10_career_reverse_service.dart` (search tier ordering, legacy best evidence)
- `lib/screens/d10_vrutti_rules_screen.dart` (single sorted stream and tier headers)
- `lib/screens/d10_legacy_profession_tile.dart` (shared status and stronger linked rule)
- `lib/screens/d10_career_reverse_screen.dart` (search card color)
- `lib/screens/d10_percent_visual.dart` (pink/green/grey tier colors)
- `test/d10_display_order_test.dart` (new ordering and 517-record invariants)
- `pubspec.yaml` (version 1.4.188+188)

## Verification limitation
Archive integrity and static cross-reference checks performed. Flutter/Dart SDK is not installed here, so GitHub Actions must run Flutter tests and an APK build.
