Candidate UI now displays per-candidate Placidus cusp-based 5th and 7th rulers. Flutter compile not verified. This is not complete Primary Directions or historical validation.
