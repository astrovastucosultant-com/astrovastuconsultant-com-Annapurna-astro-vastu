import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_bhava_topics.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_topic_index.dart';

BnnMasterRule sample(String result, {String topic = 'శుక్రుడు / వివాహం / ధనం'}) => BnnMasterRule(
  id: 'example', source: 'BNN N', sourcePage: 34,
  topic: topic, condition: 'శని—శుక్రుడు', result: result,
  inspection: '', remedy: '', status: 'FACTS_REQUIRED',
);

void main() {
  test('Every available navigation title has explicit outcome terms', () {
    for (final topic in BnnBhavaTopicService.byHouse.expand((x) => x)) {
      expect(BnnTopicIndex.resultTerms[topic.name], isNotEmpty);
    }
  });

  test('Finance synonyms index source THEN, not a fabricated result', () {
    const savings = BnnBhavaTopic(2, 'ధన నిల్వ', 'Venus');
    final matched = sample('జాతకుడు సంపద నిల్వ చేస్తాడు.');
    expect(BnnTopicIndex.belongs(savings, matched), isTrue);
  });

  test('An agricultural family birth is not family values', () {
    const values = BnnBhavaTopic(2, 'కుటుంబ విలువలు', 'Sun');
    final birth = sample('వ్యవసాయ కుటుంబ జన్మ');
    expect(BnnTopicIndex.belongs(values, birth), isFalse);
  });

  test('Relatives by marriage is not support from relatives', () {
    const support = BnnBhavaTopic(2, 'బంధువుల సహకారం', 'Moon');
    final marriage = sample('భార్య బంధువుల/తెలిసిన కుటుంబం నుంచి');
    expect(BnnTopicIndex.belongs(support, marriage), isFalse);
    final directHelp = sample('బంధువుల సహాయంతో ఆర్థిక లాభం.');
    expect(BnnTopicIndex.belongs(support, directHelp), isTrue);
  });

  test('Acquiring wealth is not evidence of retained savings', () {
    const savings = BnnBhavaTopic(2, 'ధన నిల్వ', 'Venus');
    expect(BnnTopicIndex.belongs(savings,
        sample('జాతకుడు ధనవంతుడు అవుతాడు.')), isFalse);
    expect(BnnTopicIndex.belongs(savings,
        sample('పొదుపు చేయగలడు.')), isTrue);
  });

  test('BNN methodological principles are not personal outcomes', () {
    const topic = BnnBhavaTopic(2, 'ఆదాయ మార్గాలు', 'Saturn');
    final lesson = BnnMasterRule(
      id: 'BNN-BOOK-R-A08', source: 'source', sourcePage: 1,
      topic: 'BNN మూల పద్ధతి', condition: 'గురు ఏ గ్రహాన్ని తాకితే',
      result: 'ఆ కారక ఫలితం వస్తుంది (శుక్ర = ధనం)',
      inspection: '', remedy: '', status: 'OCR_REVIEW');
    expect(BnnTopicIndex.belongs(topic, lesson), isFalse);
  });

  test('First bhava reading searches native traits across source houses', () {
    const devotion = BnnBhavaTopic(1, 'దైవచింతన', 'Ketu');
    final native = sample('జాతకుడు దైవభక్తుడు.');
    final spouse = sample('భార్య భక్తిపరురాలు.');
    final list = BnnTopicIndex.readingRulesFor(devotion, [native, spouse]);
    expect(list, contains(native));
    expect(list, isNot(contains(spouse)));
  });

  test('Only the source topic text is not sufficient', () {
    const savings = BnnBhavaTopic(2, 'ధన నిల్వ', 'Venus');
    final other = sample('వివాహం ఆలస్యమవుతుంది.', topic: 'ధన నిల్వ');
    expect(BnnTopicIndex.belongs(savings, other), isFalse);
  });

  test('Father THEN indexes ninth bhava without guesswork about IF', () {
    const father = BnnBhavaTopic(9, 'తండ్రి', 'Sun');
    final result = sample('తండ్రికి గౌరవం ఉంటుంది.', topic: 'సూర్యుడు / తండ్రి / గౌరవం');
    expect(BnnTopicIndex.belongs(father, result), isTrue);
  });

  test('Unrelated relatives outcomes never look like sibling earnings', () {
    const siblings = BnnBhavaTopic(3, 'సోదరులు', 'Mars');
    final other = sample('వ్యక్తి కుటుంబం నుండి దూరంగా ఉంటాడు.');
    expect(BnnTopicIndex.belongs(siblings, other), isFalse);
  });
}
