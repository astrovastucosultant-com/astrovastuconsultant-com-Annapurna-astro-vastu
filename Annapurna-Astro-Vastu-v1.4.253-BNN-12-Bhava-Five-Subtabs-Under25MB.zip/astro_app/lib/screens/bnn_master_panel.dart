import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_master_service.dart';
import '../models/birth_data.dart';

class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnMasterRule>> _catalog = BnnMasterCatalog.load();
  int _selectedHouse = 1;
  int _selectedSubTab = 0; // 0 results, 1 yogas, 2 past, 3 present, 4 future
  String _search = '';
  bool _showRuleLibrary = false;
  int _resultsLimit = 8;
  int _rulesLimit = 12;
  int _yogaLimit = 10;
  bool _showYogaLibrary = false;
  bool _showPeriodSource = false;

  static const _burgundy = Color(0xFF7B1E2B);
  static const _muted = Color(0xFF62666D);
  static const _panelBg = Color(0xFFF7F8FA);
  static const _cardBg = Colors.white;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BnnMasterRule>>(
      future: _catalog,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _panel(
            child: Text('BNN నియమాలను లోడ్ చేయలేకపోయాం: ${snapshot.error}'),
          );
        }
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          );
        }

        final rules = snapshot.data!;
        final age = BnnMasterAnalysis.completedAge(
          widget.birthData.localDateTime,
          DateTime.now(),
        );
        final houseRules = rules.where(_matchesSearch).where(
          (r) => BnnMasterAnalysis.housesForRule(r).contains(_selectedHouse),
        ).toList(growable: false);
        final matchedResults = _matchedRulesForHouse(houseRules);
        final yogaRules = houseRules
            .where(BnnMasterAnalysis.looksLikeYogaRule)
            .toList(growable: false);
        final yogaMatches = matchedResults
            .where((hit) => BnnMasterAnalysis.looksLikeYogaRule(hit.rule))
            .toList(growable: false);
        final periodRules = houseRules
            .where(BnnMasterAnalysis.looksLikeTimingRule)
            .toList(growable: false);

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'BNN — భావాలవారీ నియమాలు',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'గురు రాశి మొదటి భావం • ప్రతి భావంలో 5 ప్రత్యేక ట్యాబ్‌లు • మూల నియమాల పరిశీలన',
                    style: TextStyle(fontSize: 12.5, color: _muted),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _countPill('462 మూల నియమాలు'),
                      _countPill('${matchedResults.length} ప్రాథమిక matches'),
                      _countPill('${yogaRules.length} యోగ మూల నియమాలు'),
                      _countPill('${houseRules.length} భావ సంబంధిత నియమాలు'),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: 'పలితం / గ్రహం / నియమం / ID వెతకండి',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: (value) => setState(() => _search = value.trim()),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    '12 భావాలు',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  GridView.builder(
                    itemCount: 12,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      childAspectRatio: 1.55,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemBuilder: (context, index) {
                      final house = index + 1;
                      final selected = house == _selectedHouse;
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() {
                          _selectedHouse = house;
                          _resultsLimit = 8;
                          _rulesLimit = 12;
                          _yogaLimit = 10;
                          _showRuleLibrary = false;
                          _showYogaLibrary = false;
                          _showPeriodSource = false;
                          _selectedSubTab = 0;
                        }),
                        child: Ink(
                          decoration: BoxDecoration(
                            color: selected ? _burgundy : const Color(0xFFFFF9F0),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected ? _burgundy : const Color(0xFFE7C98F),
                            ),
                          ),
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                '${house} భావం',
                                style: TextStyle(
                                  fontWeight: FontWeight.w800,
                                  fontSize: 16,
                                  color: selected ? Colors.white : const Color(0xFF14346A),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                BnnMasterAnalysis.houseTheme(house),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 11.5,
                                  height: 1.25,
                                  color: selected ? Colors.white70 : _muted,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    BnnMasterAnalysis.houseLabel(_selectedHouse),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    BnnMasterAnalysis.houseTheme(_selectedHouse),
                    style: const TextStyle(fontSize: 12.5, color: _muted),
                  ),
                  const SizedBox(height: 10),
                  _infoBox(
                    title: 'జన్మ చక్రంలోని గ్రహాలు',
                    body: BnnMasterAnalysis.houseOccupancyText(widget.chart, _selectedHouse),
                  ),
                  const SizedBox(height: 10),
                  const Text('BNN భావ క్రమం: గురు ఉన్న రాశి 1వ భావం; అక్కడి నుండి రాశుల వారీగా 2–12.',
                    style: TextStyle(fontSize: 12, color: _muted, height: 1.45)),
                  const SizedBox(height: 14),
                  _subTabPicker(),
                  const SizedBox(height: 14),
                  if (_selectedSubTab == 0) ...[
                    _sectionTitle('జాతకంలో ప్రాథమికంగా సరిపోయిన ఫలితాలు'),
                    const SizedBox(height: 6),
                    const Text('జన్మగ్రహాల ఒకే రాశి అనేది మొదటి స్థాయి పరిశీలన. పూర్తి BNN గ్రహ క్రమం, దృష్టి, కాలచక్రం ధృవీకరణ తరువాతే ఫలిత నిర్ణయం.',
                      style: TextStyle(color: _muted, fontSize: 12, height: 1.45)),
                    const SizedBox(height: 10),
                    if (matchedResults.isEmpty)
                      _emptyMessage('ఈ భావంలో ప్రస్తుత జాతకానికి ప్రాథమికంగా సరిపోయిన IF–THEN నియమాలు లేవు. క్రింద మూల నియమాలను పరిశీలించవచ్చు.')
                    else ...[
                      for (final hit in matchedResults.take(_resultsLimit))
                        _resultCard(hit.rule, subtitle: 'ప్రాథమిక మ్యాచ్ • ${hit.evidence}', highlight: true),
                      if (matchedResults.length > _resultsLimit)
                        TextButton(
                          onPressed: () => setState(() => _resultsLimit += 8),
                          child: Text('ఇంకా ${matchedResults.length - _resultsLimit} ఫలితాలు చూపించు'),
                        ),
                    ],
                  ] else if (_selectedSubTab == 1) ...[
                    _sectionTitle('ఈ భావానికి సంబంధించిన యోగాలు'),
                    const SizedBox(height: 6),
                    const Text('ప్రాథమికంగా సరిపోయిన యోగాలను ముందుగా చూపిస్తున్నాం. గ్రంథంలోని మిగతా యోగాలు ప్రత్యేకంగా చూడవచ్చు.',
                      style: TextStyle(color: _muted, fontSize: 12, height: 1.45)),
                    const SizedBox(height: 10),
                    if (yogaMatches.isEmpty)
                      _emptyMessage('ఈ జాతకంలో ఈ భావానికి ప్రాథమికంగా సరిపోయిన గ్రహ యోగాలు లేవు.')
                    else
                      for (final hit in yogaMatches.take(_yogaLimit))
                        _resultCard(hit.rule,
                          subtitle: 'ప్రాథమిక గ్రహ సంయోగం • ${hit.evidence}', highlight: true),
                    if (yogaMatches.length > _yogaLimit)
                      TextButton(
                        onPressed: () => setState(() => _yogaLimit += 10),
                        child: Text('ఇంకా ${yogaMatches.length - _yogaLimit} యోగాలు చూపించు'),
                      ),
                    const SizedBox(height: 10),
                    _toggleLine('గ్రంథంలోని ఇతర యోగాలు (${yogaRules.length})',
                      _showYogaLibrary, () => setState(() => _showYogaLibrary = !_showYogaLibrary)),
                    if (_showYogaLibrary) ...[
                      const Text('ఇవి జాతకంలో వర్తించాయని నిర్ధారించలేదు; మూల పరిశీలన కోసం మాత్రమే.',
                        style: TextStyle(color: _muted, fontSize: 12)),
                      const SizedBox(height: 8),
                      if (yogaRules.isEmpty)
                        _emptyMessage('ఈ భావానికి ఇతర యోగ మూల నియమాలు లేవు.')
                      else
                        for (final rule in yogaRules.take(_yogaLimit))
                          _resultCard(rule, subtitle: 'గ్రంథ సూచన మాత్రమే • ${_statusLabel(rule.status)}'),
                      if (yogaRules.length > _yogaLimit)
                        TextButton(
                          onPressed: () => setState(() => _yogaLimit += 10),
                          child: Text('ఇంకా ${yogaRules.length - _yogaLimit} మూల యోగాలు'),
                        ),
                    ],
                  ] else ...[
                    _sectionTitle(_periodTitle),
                    const SizedBox(height: 8),
                    _infoBox(title: _periodHeading(age), body: _periodDescription(age)),
                    const SizedBox(height: 12),
                    _sectionTitle('వయస్సు / గురు–శని చక్ర పరిశీలన'),
                    const SizedBox(height: 8),
                    ..._periodBandWidgets(age),
                    const SizedBox(height: 10),
                    _emptyMessage('ఈ భావానికి ${_periodTitle}లో ఖచ్చితంగా జరిగిన లేదా జరగబోయే సంఘటనను నిర్ణయించే పూర్తి BNN కాలగణన ఇంకా ధృవీకరించలేదు. కిందివి కాల సూచనల మూల నియమాలు మాత్రమే.'),
                    const SizedBox(height: 10),
                    _toggleLine('కాల సూచన మూల నియమాలు (${periodRules.length})',
                      _showPeriodSource, () => setState(() => _showPeriodSource = !_showPeriodSource)),
                    if (_showPeriodSource) ...[
                      const SizedBox(height: 6),
                      if (periodRules.isEmpty)
                        _emptyMessage('ఈ భావానికి కాలానికి సంబంధించిన గ్రంథ నియమాలు లేవు.')
                      else
                        for (final rule in periodRules.take(_rulesLimit))
                          _resultCard(rule, subtitle: 'నిర్ధారణ కాని కాల సూచన • ${rule.id}'),
                      if (periodRules.length > _rulesLimit)
                        TextButton(
                          onPressed: () => setState(() => _rulesLimit += 12),
                          child: Text('ఇంకా ${periodRules.length - _rulesLimit} నియమాలు'),
                        ),
                    ],
                  ],
                  const SizedBox(height: 15),
                  _toggleLine('ఈ భావానికి సంబంధించిన మొత్తం మూల నియమాలు (${houseRules.length})',
                    _showRuleLibrary, () => setState(() => _showRuleLibrary = !_showRuleLibrary)),
                  if (_showRuleLibrary) ...[
                    const SizedBox(height: 7),
                    const Text('462 నియమాల్లో ఈ భావానికి అంశపరంగా అనుసంధానమైనవి. భావ అనుసంధానం = నియమం జాతకంలో వర్తించిందని కాదు.',
                      style: TextStyle(fontSize: 12, color: _muted, height: 1.45)),
                    const SizedBox(height: 8),
                    if (houseRules.isEmpty)
                      _emptyMessage('ఈ భావానికి మూల నియమాలు కనబడలేదు.')
                    else
                      for (final rule in houseRules.take(_rulesLimit))
                        _resultCard(rule, subtitle: '${rule.id} • ${_statusLabel(rule.status)}'),
                    if (houseRules.length > _rulesLimit)
                      TextButton(
                        onPressed: () => setState(() => _rulesLimit += 12),
                        child: Text('ఇంకా ${houseRules.length - _rulesLimit} నియమాలు చూపించు'),
                      ),
                  ],
                ],
              ),
            ),
          ],
        );
      },
    );
  }

  static const _subTabNames = <String>[
    'ఫలితాలు', 'యోగాలు', 'భూతం', 'వర్తమానం', 'భవిష్యత్తు',
  ];

  String get _periodTitle => _subTabNames[_selectedSubTab];

  Widget _subTabPicker() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('భావ విశ్లేషణ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Wrap(
        spacing: 7,
        runSpacing: 7,
        children: [
          for (var i = 0; i < _subTabNames.length; i++)
            ChoiceChip(
              label: Text(_subTabNames[i]),
              selected: _selectedSubTab == i,
              selectedColor: const Color(0xFFF1DDE1),
              labelStyle: TextStyle(
                color: _selectedSubTab == i ? _burgundy : Colors.black87,
                fontWeight: _selectedSubTab == i ? FontWeight.w800 : FontWeight.w600,
              ),
              onSelected: (_) => setState(() {
                _selectedSubTab = i;
                _showPeriodSource = false;
              }),
            ),
        ],
      ),
    ],
  );

  bool _matchesSearch(BnnMasterRule rule) {
    if (_search.isEmpty) return true;
    final hay = '${rule.id} ${rule.topic} ${rule.condition} ${rule.result} ${rule.source}'.toLowerCase();
    return hay.contains(_search.toLowerCase());
  }

  List<_HouseRuleHit> _matchedRulesForHouse(List<BnnMasterRule> houseRules) {
    final hits = <_HouseRuleHit>[];
    for (final rule in houseRules) {
      final evidence = BnnMasterAnalysis.tentativeHouseMatch(
        rule,
        widget.chart,
        _selectedHouse,
      );
      if (evidence != null) {
        hits.add(_HouseRuleHit(rule, evidence));
      }
    }
    return hits;
  }

  List<Widget> _periodBandWidgets(int age) {
    final range = _periodRange(age);
    final bands = BnnMasterAnalysis.jupiterStudyBands(range.$1, range.$2);
    if (bands.isEmpty) {
      return [_emptyMessage('ఈ కాల పరిధికి గురు చక్ర అధ్యయన భాగాలు లేవు.')];
    }
    return [
      Text(
        BnnMasterAnalysis.roundInfo(_referenceAge(age)),
        style: const TextStyle(fontSize: 12.5, color: _muted),
      ),
      const SizedBox(height: 8),
      for (final band in bands)
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Text(
            'గురు ${band.round}వ చక్రం • ${band.fromAge}–${band.toAge} వయస్సు • ${band.sourceTheme}',
            style: const TextStyle(fontSize: 12.5, height: 1.45),
          ),
        ),
      const Text(
        'గమనిక: ఇవి BNN-BOOK-R-A03 ఆధారంగా అధ్యయన విభాగాలు మాత్రమే; ఖచ్చిత సంఘటన నిర్ధారణ కాదు.',
        style: TextStyle(fontSize: 12, color: _muted),
      ),
    ];
  }

  (int, int) _periodRange(int age) {
    switch (_selectedSubTab) {
      case 2:
        return (0, age < 1 ? 0 : age - 1);
      case 3:
        return (age < 0 ? 0 : age, age < 0 ? 0 : age);
      case 4:
        final start = age < 0 ? 0 : age + 1;
        return (start, start + 12);
      default:
        return (age < 0 ? 0 : age, age < 0 ? 0 : age + 5);
    }
  }

  int _referenceAge(int age) {
    switch (_selectedSubTab) {
      case 2:
        return age < 1 ? 0 : age - 1;
      case 3:
        return age < 0 ? 0 : age;
      case 4:
        return age < 0 ? 0 : age + 1;
      default:
        return age < 0 ? 0 : age;
    }
  }

  String _periodHeading(int age) {
    final range = _periodRange(age);
    return '$_periodTitle — వయస్సు ${range.$1} నుండి ${range.$2}';
  }

  String _periodDescription(int age) {
    switch (_selectedSubTab) {
      case 2:
        return 'జననం నుండి ${age < 1 ? 0 : age - 1} వయస్సు వరకు ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన గత అధ్యయన కాలచక్ర అంశాలు మాత్రమే.';
      case 3:
        return 'ప్రస్తుత వయస్సు $age వద్ద ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన వర్తమాన అధ్యయన కాలచక్రం.';
      case 4:
        return 'ప్రస్తుత వయస్సు తరువాత ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన భవిష్యత్ అధ్యయన కాలచక్రం. ఇది సంఘటన తేదీ కాదు.';
      default:
        return '${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన కాల పరిశీలన.';
    }
  }

  Widget _sectionTitle(String text) => Text(
        text,
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
      );

  Widget _countPill(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0xFFEDF0F5),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(text, style: const TextStyle(fontSize: 12.5)),
      );

  Widget _panel({required Widget child}) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _panelBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFE4E7EC)),
        ),
        child: child,
      );

  Widget _infoBox({required String title, required String body}) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFFDF5E6),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE8D8B2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(body, style: const TextStyle(fontSize: 12.5, height: 1.45)),
          ],
        ),
      );

  Widget _emptyMessage(String message) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF3F4F6),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(message, style: const TextStyle(fontSize: 12.5, color: _muted, height: 1.45)),
      );

  Widget _toggleLine(String text, bool opened, VoidCallback onTap) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(
            children: [
              Expanded(
                child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              Icon(opened ? Icons.expand_less : Icons.expand_more, color: _burgundy),
            ],
          ),
        ),
      );

  Widget _resultCard(
    BnnMasterRule rule, {
    required String subtitle,
    bool highlight = false,
  }) => Card(
        color: _cardBg,
        elevation: 0,
        margin: const EdgeInsets.only(bottom: 10),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: highlight ? const Color(0xFFE4C48B) : const Color(0xFFE7EAF0),
          ),
        ),
        child: ListTile(
          contentPadding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
          title: Text(
            rule.result,
            style: const TextStyle(fontWeight: FontWeight.w800, height: 1.35),
          ),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              subtitle,
              style: const TextStyle(fontSize: 12.2, color: _muted, height: 1.45),
            ),
          ),
          trailing: const Icon(Icons.chevron_right, color: _burgundy),
          onTap: () => _showRuleSheet(rule, subtitle),
        ),
      );

  void _showRuleSheet(BnnMasterRule rule, String note) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF7ECEC),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.78,
          maxChildSize: 0.92,
          minChildSize: 0.55,
          builder: (context, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(22, 14, 22, 30),
            children: [
              Center(
                child: Container(
                  width: 52,
                  height: 6,
                  decoration: BoxDecoration(
                    color: Colors.black45,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'BNN — జాతక పరిశీలన రూల్',
                style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 18),
              _sheetBlock('ఫలితం', rule.result),
              _sheetBlock('IF — నియమం', rule.condition),
              _sheetBlock('జాతకానికి సంబంధించిన గమనిక', note),
              _sheetBlock(
                'జన్మ గ్రహస్థితులు',
                BnnMasterAnalysis.natalPositionsForCondition(rule.condition, widget.chart),
              ),
              _sheetBlock('జాతక పరిశీలన', rule.inspection),
              _sheetBlock('ధృవీకరణ స్థితి', _statusLong(rule.status)),
              _sheetBlock('మూల గ్రంథం', '${rule.source} • PDF పేజీ ${rule.sourcePage} • ${rule.id}'),
              _sheetBlock('పరిహారం', rule.remedy),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sheetBlock(String title, String body) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                  color: _burgundy,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                )),
            const SizedBox(height: 6),
            Text(body, style: const TextStyle(fontSize: 15, height: 1.55)),
          ],
        ),
      );

  String _statusLabel(String status) => switch (status) {
        'FACTS_REQUIRED' => 'జాతక match అవసరం',
        'OCR_REVIEW' => 'OCR పరిశీలన',
        'REVIEW' => 'Review',
        _ => status,
      };

  String _statusLong(String status) => switch (status) {
        'FACTS_REQUIRED' => 'ఈ నియమం జాతకంలోని గ్రహస్థితులతో సరిపోతే మాత్రమే పరిశీలించాలి.',
        'OCR_REVIEW' => 'ఈ నియమం OCR నుండి వచ్చినది; మూల గ్రంథంతో మళ్లీ ధృవీకరించాలి.',
        'REVIEW' => 'ఈ నియమం చేతితో మరింత సమీక్ష అవసరం.',
        _ => status,
      };
}

class _HouseRuleHit {
  final BnnMasterRule rule;
  final String evidence;
  const _HouseRuleHit(this.rule, this.evidence);
}
