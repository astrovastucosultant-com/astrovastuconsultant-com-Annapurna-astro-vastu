# BNN v1.4.274 — 144 Topic Chart Reading, Results First

Source: v1.4.273 full ZIP. Changed BNN feature only.

- All 12 bhavas × 12 topics shown as interactive **natal chart inspections**.
- Each topic reveals observed natal karaka sign, BNN house, DMS, retrograde flag, and available Nadi sign links.
- Only **complete parseable** OCR book IF predicates that match the natal chart appear in the topic's source THEN indication panel.
- A source THEN is always **OCR pending**, never a confirmed outcome; non-matching and uncomputable rules are collapsed separately.
- The same person-specific result may be routed to the first-bhava trait from other source house indexes, but third-party/spouse/relative results are not attributed to the native.
- New exact predicate for BNN-BOOK-C39: both Rahu and Mars must be 2nd from natal Jupiter. A single matching planet cannot trigger bravery.
- Adds regression test for screenshot placements (Jupiter Taurus, Rahu Gemini, Mars Cancer) showing C39 does NOT match; Jupiter Taurus also does NOT match C42 exaltation.
- Original 462 source entries, 106 engine rules and 48 timing rules are retained byte-for-byte.
- Full Flutter compile / APK build not run (Flutter/Dart SDK not available in runtime). OCR originals not verified.
