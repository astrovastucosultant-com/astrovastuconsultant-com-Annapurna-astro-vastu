# v1.4.259 — BNN house coverage and natal candidate matching

Base: v1.4.258 Full Source ZIP. This is a FULL SOURCE UPDATE, not an APK.

## Problem reported
An earlier build showed two generic-looking outcomes for a natal chart. The BNN N engine checked only same-sign planet combinations, despite additional sign-to-sign relationships described in modern BNN teaching.

## Changes
- 12 Jupiter-relative house selectors kept, along with 5 existing coloured sub-tabs.
- BNN N candidate evaluation recognizes SAME SIGN, TRINE (5th/9th), SECOND, TWELFTH and SEVENTH sign links. Triples require every pair to meet an accepted sign linkage. For triples, the source's specific ordered sequence and directional subtleties remain **not validated**.
- All 82 FACTS_REQUIRED BNN N records have simple 2/3 planet-dash conditions and are eligible for the expanded provisional relationship check. This is not verification of their full source prediction.
- 343 OCR_REVIEW and 37 REVIEW records remain catalog-only, not automatically promoted to matches.
- Added exactly 144 **unique topical review entries**, 12 per house. They use actual selected-chart planet longitude and Jupiter-relative house, and explicitly say they are NOT an event prediction or a source rule. Do not call these '144 matched predictions'.
- Actual BNN-N rule result cards still lead, tap opens the IF, birth positions, source, and caveats. Review topics are a separately titled lower section.
- Other application source stays intact.

## Research provenance and limits
- Looked up BNN instruction on Jupiter as reference sign, same-rashi/trinal/2nd-12th/7th links, karakatwas, and separately-timed activation.
- The user-provided 462-rule catalog is the source for every automatically surfaced literal IF/THEN result. New topic titles are UI analysis dimensions, not a claim to have found 144 more rules in the book.
- Timing of event / past / future classification is not newly implemented. Jupiter/Saturn age-band study remains unchanged; it must not be promoted to an event forecast.
- Any 100–200 *source-backed matched predictions* would require an expanded, reviewed source-rule catalog and additional fully implementable predicates. The output count must depend on each chart.

## Static QA
- JSON source rules: 462 (343 OCR_REVIEW, 82 FACTS_REQUIRED, 37 REVIEW).
- BNN topics: 12 houses x 12 = 144.
- Runtime in this workspace lacks Flutter/Dart SDK; flutter analyze, test and release build NOT RUN.
