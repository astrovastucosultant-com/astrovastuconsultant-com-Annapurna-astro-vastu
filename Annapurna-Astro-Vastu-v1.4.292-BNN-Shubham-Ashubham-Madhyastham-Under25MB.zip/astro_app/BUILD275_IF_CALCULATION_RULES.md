# v1.4.275 — BNN natal IF engine expansion

## User specification
No rule should be parked in a generic “calculation pending” state. Add complete computation for each well-defined source IF. Do not convert a missing, unclear, or OCR-corrupted IF into TRUE/FALSE or assert a life event.

## Implemented in this increment
- Explicit natal reference to any planet, not only Jupiter: e.g. `శని గురుకి 3`, `సూర్యుడు శనికి 11`, `కేతు కుజకి 3`.
- Explicit relative house and target planet: e.g. `శనికి 2లో రాహు`, `శుక్రకి 7లో శని`, including Telugu house numerals.
- Multiple conjunct target planets in the specified reference house: e.g. `శనికి 2లో చంద్ర+రాహు`. All targets mandatory.
- Conjunct group plus an exact zodiac sign: e.g. `బుధ+శుక్ర తుల`. Every planet must occupy the specified sign.
- Recognize `సూర్య` as Sun in the source terminology.
- If chart lacks a required planet, UNKNOWN not FALSE.
- Main result topics no longer label uncomputed source IF as generic “pending”. Specific definitions/source checks in detail view.

## What is NOT complete
- No full IF evaluator for all 462 source rules: OCR_REVIEW 343, FACTS_REQUIRED 82, REVIEW 37 remain source statuses.
- Explicit conjunctions lacking relation semantics, aspect variants, timing/progression combinations, malformatted source tokens (e.g. `HFtenGd`, `లో శని`), non-natal transits and lineage disagreements are not auto-matched.
- No claim of original PDF/source verification.
- No claim of successful Flutter compilation: Flutter/Dart SDK not present locally. Added Flutter tests but not run.

## Principles
Never promote a partial clause match to a final result. Distinguish an actual false IF from an indeterminate IF. A source IF match is traditional evidence and not a medically/scientifically validated prediction. Original 462/106/48 catalog files remain byte-for-byte unchanged.
