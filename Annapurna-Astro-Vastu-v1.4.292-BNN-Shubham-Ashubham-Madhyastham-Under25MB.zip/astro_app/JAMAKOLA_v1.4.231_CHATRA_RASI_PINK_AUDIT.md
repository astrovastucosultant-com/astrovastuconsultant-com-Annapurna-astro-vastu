# Jamakola v1.4.231 — Chatra Rasi Source, Calculation and Pink Highlight

## Scope
- A separate Chatra **Rasi** calculation has been added to the Jamakola special service.
- Solar Veedhi anchors (Sun in sidereal rasi):
  * Sun Taurus/Gemini/Cancer/Leo → Aries (0).
  * Sun Virgo/Libra/Pisces/Aries → Taurus (1).
  * Sun Scorpio/Sagittarius/Capricorn/Aquarius → Gemini (2).
- `chatraSign = (udhayamSign + veedhiSign - arudamSign) mod 12`.
- South Indian Rasi chart: Chatra cell gets pastel pink background, strong pink outline and bright CHA label.
- Manual Chatra degree overrides the computed rasi when user explicitly supplies it.
- When only Chatra rasi is known, its precise longitude, nakshatra, pada, and Placidus Bhava are **not invented**.
- Chatra and GK Kavippu remain separate, labelled calculations. This change does not claim their exact algorithms are identical.
- Mandi and Yamaghan remain unverified and are not silently calculated.
- The star/degree table for computed Chatra shows its sign label and pending degree; other rows are unchanged.

## Source references
- Traditional Veedhi/Chatra counting explanation: https://jatakavedhan.wordpress.com/2016/09/
- Prasna Marga 9.34 translated example and Veedhi mapping: https://www.scribd.com/document/722066608/Ashtamangala-Rogaprashna-Shubham-Alock
- Jamakkol/GK describes Udhayam, Arudam and Kavippu: https://books.google.com/books?id=e_gvEAAAQBAJ
- The published comparison tool lists Chatra under Ashtamangala and Kavippu under Jamakkol: https://yogatara.app/features/prashna

## Source fixture (user supplied, not proof of complete GK software equivalence)
24 Oct 2026 17:50, Guntur, Sun Libra, Udhayam Libra (06s), Arudam Aquarius (10s).
Sun in Libra → Taurus Veedhi, therefore `6+1-10=-3 mod 12 = 9` → Capricorn (09s) Chatra.
Divya Chakshu displays Chatra 09s 29°59'58"; sign agrees, precise 299°59'58" was **not** independently derived and is **not** shown as a computed longitude.

## Testing and limits
- Added Flutter unit tests for each Sun sign's Veedhi group, the user screenshot fixture, a published Prasna Marga fixture and invalid data.
- ZIP CRC and immutable historical rule assets are checked; Flutter SDK is unavailable in the editing environment, hence `flutter build apk --release` was not run.
- Source-derived calculations are traditional astrology procedures, not empirically established event prediction.
