# Build v1.4.279 — Source IF Boolean AND/OR and E10 THEN-branch scoping

## What changed
- Dedicated BNN-BOOK-E10 evaluation of (Saturn Gemini OR Saturn Virgo), separate from the supplemental (Saturn Gemini AND Moon Cancer).
- Saturn Virgo matches only the primary "వ్యాపారవేత్త" source sentence. The alcohol-related secondary source sentence is never attached to a Virgo chart.
- Restricted parser for fully explicit AND / OR / Telugu మరియు / లేదా / parentheses and spaced + between complete conditions. AND binds more strongly than OR. Unknown atoms never silently evaluate to TRUE. Short-circuit three-valued logic respects F AND unknown = F and T OR unknown = T.
- Explicit sign alternatives and combinations with named relative-house conditions (e.g. C47) can now be tested as one complete IF.
- Chart-match UI shows a branch-specific THEN separately from the original full THEN, which remains untouched.
- Unit regression fixtures for E10 Virgo, Gemini+Cancer, Gemini without Cancer, AND/OR precedence, parentheses, C47, and unknown conditions.

## Boundaries
This does NOT mean all 462 source IFs are implemented or their OCR transcriptions verified. Branch-specific THEN is implemented explicitly for E10; other multi-outcome source rules need their own source-grounded branch definitions. No precise timing or BTR claim. Flutter/Dart SDK not available in container so flutter test/build not run. GitHub build not yet started for this ZIP.
