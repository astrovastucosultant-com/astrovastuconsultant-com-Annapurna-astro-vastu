# Build 248 — Hasta Samudrika tab only

- Keep the `హస్త సాముద్రికం` navigation tab, its icon and original index.
- Render an entirely empty content area when the tab is selected.
- Remove the feature-specific photo picker, rule data, analysis and report UI, and its Dart service.
- Drop the now-unused `image_picker` dependency and its iOS photo-access permission.
- Preserve all other screens, modules, source material and astrology calculations exactly as in v1.4.247.
- Flutter APK compilation not verified in this environment.
