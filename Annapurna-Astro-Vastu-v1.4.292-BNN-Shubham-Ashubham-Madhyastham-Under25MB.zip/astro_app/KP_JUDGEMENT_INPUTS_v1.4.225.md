# v1.4.225 — KP Judgement Date / Time / Place / Horary / Time Chart

Horary tab now includes visible separate controls:
1. Event selection (414 supplied KP event records)
2. Date of Judgement (calendar picker)
3. Time of Judgement (time picker; 'Now' intentionally sets current time at chosen UTC offset)
4. Place name, latitude, longitude, timezone UTC offset
5. Horary number 1–249 and OK button
6. Time Chart action using the same selected judgement moment and place

Time Chart tab reuses the judgement date/time/place controls; calculates an independent chart and judgement-time ruling planets.

Important fix: the Horary OK calculation now passes the **selected** local date/time converted into UTC with the selected offset, instead of always taking DateTime.now() at OK time. This fixes judgement history and reproducibility.

Changing question inputs invalidates stale prior calculated results. Name-only edits do not geocode or change latitude/longitude; verify these manually. The existing default is the opened natal chart's place and coordinates, until edited.

No changes to KP original rule JSON, 555 Jaimini or 255 Varga data. Event prediction still preliminary pending full 6-book Significators, Promise/Denial, DBA/RP/transit validation. Static ZIP integrity tested; Flutter compile not verified in this environment.
