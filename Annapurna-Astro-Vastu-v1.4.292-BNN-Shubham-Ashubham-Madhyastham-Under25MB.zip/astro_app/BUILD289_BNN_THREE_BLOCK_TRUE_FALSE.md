# BNN v1.4.289 — Three-block rule-scoped outcomes

- Original 462 source rule JSON unchanged.
- Every computable natal source IF now has a concise, **rule-specific** positive / negative outcome.
- BNN-BOOK-G05: Saturn-to-Sun sign distance 11 => `ప్రభుత్వ ఉద్యోగం`; otherwise `ప్రభుత్వ ఉద్యోగం లేదు` (only this rule, not a global career diagnosis).
- New `BnnRuleVerdict` centralizes source IF status and compact computed evidence.
- Source library cards and topic evidence cards show chart-conditional results, not unconditional source THEN.
- Default BNN Results tab includes both matching and non-matching computable rules.
- All source-rule detail bottom sheets render only: **రూల్ → పరిశీలన → ఫలితం**; no remedy/OCR/timing narration.
- D1 336 Siddhanti rules also use only three detail sections.
- Unparseable source IFs remain in the 462 catalogue without fabricated TRUE/FALSE outcomes.
- Added G05 true/false/unit tests. Flutter SDK not available here; compile/APK unverified.
