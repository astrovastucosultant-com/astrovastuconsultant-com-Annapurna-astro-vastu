# Annapurna Astro Vastu v1.4.260 — BNN result clarity update

- Starting source: v1.4.259 complete ZIP.
- 12 colored bhavas / 5 subtabs / 144 topic reference items preserved.
- Prominent source outcome cards now require a full single-sign natal planet chain.
- Other preliminary 2nd/7th/12th/trine links are shown in a separate collapsed *review* section without displaying event/outcome assertions on the face of the card.
- 144 study-topic reference list now starts collapsed, to keep focus on actual source-linked candidates.
- 462 JSON source rules unchanged; 343 OCR_REVIEW and 37 REVIEW are not autoconfirmed.
- Source library still separately accessible on demand; rule evidence shown after tapping a card.
- WARNING: Even a same-sign chart placement does not validate a life event, source Nadi order, or specific timing.
- Added Dart regression test for the stricter screen promotion gate; test not run here.
- No Flutter or Dart SDK available; runtime compile, APK and device checks not claimed.
