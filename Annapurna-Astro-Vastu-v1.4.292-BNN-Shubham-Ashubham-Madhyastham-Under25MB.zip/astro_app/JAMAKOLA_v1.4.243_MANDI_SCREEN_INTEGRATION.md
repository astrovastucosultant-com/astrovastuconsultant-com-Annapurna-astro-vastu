# v1.4.243 — Mandi link into Jamakola consultation

The independent `MandiCalculationService` delivered in 1.4.242 was not called
from `JamakolaRulePanel`. As a result, Jamakola still showed `Mandi — Pending`,
although the calculation service existed for the Shapa module.

Changes:
- Added `_mandiFuture` evaluated for the **selected question date/time/place**, not the nativity.
- Recomputed when the user taps "చక్రం గణించండి"; used the selected timezone offset.
- Added calculated Mandi longitude and Vedic nakshatra/pada to the ordinary
  planet table, and placed `Md` with sign-local longitude in the INNER chart
  in both Sign and Bhava modes. A specifically-entered manual Mandi longitude takes priority.
- Shows Gulika Saturn-segment start/end longitudes as separate reference data.
- Exposes calculation failures without blocking the ordinary Jamakola chart.
- Updated the override help text to distinguish automatic Mandi vs manual
  Yamaghan, which is still *not* calculated.
- Serializes calculations that share the Swiss Ephemeris global sidereal mode.

This does not implement an independently validated Yamaghan formula, complete
Jamakola Kavippu degrees, KP Promise/Denial, Tajik 16 yogas, or an exact
horary event-time engine. No timing result is inferred from the Mandi value.

## Validation

ZIP structure/CRC + static integration checks run in the packaging environment.
Flutter SDK is unavailable locally; Android APK build remains unverified.
