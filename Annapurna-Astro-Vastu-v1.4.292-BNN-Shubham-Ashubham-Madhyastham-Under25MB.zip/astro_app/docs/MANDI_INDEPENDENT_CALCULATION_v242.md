# స్వతంత్ర మండీ (Mandi) గణన — 1.4.242

## మూలాలు — ఒకే పద్ధతి అనుకోవద్దు

1. **Prasna Marga, Ch. V**: పగలు సూర్యోదయం నుంచి మండీ ఘడియల స్థానం; వారం ఆదివారం→శని: `26,22,18,14,10,6,2` ఘడియలు. రాత్రి సూర్యాస్తమయం నుంచి `10,6,2,26,22,18,14` ఘడియలు. వాస్తవ పగలు/రాత్రి పొడవు 30 ఘడియలు కాకపోతే అదే నిష్పత్తిలో సవరించాలి.
   - https://studyres.com/doc/4856777/prasna-marga
   - https://vedicpupil.in/library/brihat-parashara-hora-shastra-book-by-parashara/graha-gunas-planetary-qualities-ch3/69
2. **BPHS 3.66–70**: పగలు/రాత్రి ఎనిమిది సమాన కాలాలుగా విభజించి, శనికి వచ్చిన కాలభాగం ప్రారంభంలో ఉదయించే లగ్నం గుళిక. రాత్రి మొదటి భాగం ఆ వారానికి ఐదవ వారాధిపతి నుంచి ప్రారంభం. మరికొన్ని పాఠాంతరాలలో భాగం ముగింపును గుళికగా తీసుకుంటారు. అందుకే ప్రారంభ, ముగింపు డిగ్రీలను వేర్వేరుగా చూపించాం.
   - https://divyachadhava.com/en/sanatan-sahitya/bphs-chapter-3-grah-characters-and-description
   - https://vedicpupil.in/library/books/brihat-parashara-hora-shastra/chapter-3?page=2
3. ఈ అమలు **మండీ**ని వేరు గణించి, శాప నియమాల్లో `MANDI_H` కోసం మండీ స్థానం మాత్రమే వినియోగిస్తుంది. గుళికను మండీకి స్వయంగా సమానం చేయదు.

## గణన వాకిలి

- `BirthData`: తేదీ, స్థానిక గడియార సమయం, స్థల latitude / longitude, UTC offset, Lahiri / Raman / KP ayanamsa.
- `Swiss Ephemeris`: స్థానిక సూర్యోదయం, సూర్యాస్తమయం, తర్వాతి సూర్యోదయం; ఆ తరువాత నిర్ణయించిన మండీ సమయంలో ఖచ్చితమైన sidereal ascendant.
- సూర్యోదయానికి **ముందు** జననం అయితే గత సౌరదినం (మునుపటి వారాధిపతి) రాత్రి భాగం తీసుకుంటాం.
- సూర్యాస్తమయం **తరువాత** అయితే అదే సౌరదినం రాత్రి భాగం తీసుకుంటాం.
- ఫోన్ Timezone‌ను ఉపయోగించకుండా, BirthDataలో ఇచ్చిన UTC Offsetను ఒకేసారి వర్తింపజేస్తాం.
- ఫలితం: మండీ Total Longitude, రాశి, Whole-sign భావం; BPHS గుళిక ప్రారంభం, ముగింపు డిగ్రీలు, స్థానిక సమయాలు.
- ఖచ్చితమైన latitude/longitude, sunrise లేదా astronomical ascendant లేకపోతే ఊహించకుండా లోపం చూపిస్తుంది.

## స్వతంత్ర Swiss Ephemeris పరీక్షా ప్రమాణం (pyswisseph 2.10.03)

**Guntur** (16.3067° N, 80.4365° E), **25-10-2026**, **13:55 IST**, Lahiri.

- Sunrise ≈ **06:02:56 IST**; sunset ≈ **17:41:34 IST**.
- Sunday daytime Mandi fraction = 26/30; Mandi ≈ **340.605409°** → Pisces **10°36′19″**.
- BPHS Gulika START fraction = 6/8; Gulika ≈ **315.292554°** → Aquarius **15°17′33″**.
- Gulika END (alternative) = 7/8; ≈ **342.423139°** → Pisces **12°25′23″**.

The independent Python reference used `swe.rise_trans` + `swe.houses_ex` with Lahiri sidereal mode. This is an engineering numerical fixture, not a claim that Mandi and Gulika have one universally agreed longitude. Observer elevation and refraction assumptions affect seconds.

## పరీక్షా పరిమితి

Pure Dart ghati/weekday regression tests were authored in `test/mandi_calculation_service_test.dart`.
The Swiss-Ephemeris Android compile/run still requires the GitHub Actions APK build; ZIP integrity is not a substitute for Flutter compile.
