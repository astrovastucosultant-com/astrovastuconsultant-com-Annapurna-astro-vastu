# KP Responsive Dashboard — v1.4.222

## UI changes
- Desktop/tablet: South Indian chart and KP Planet/Cusp/Dasha tabular details side by side.
- Mobile: chart first; details below with horizontally scrollable tabs.
- First row: KP Horary 1–249, OK and clear; chart visual rotate and reset.
- Toggle between natal planet chart and natal cusp locations, with separate labels.
- Detail tabs: Planets; 12 Placidus Cusps; KP-Moon-derived Vimshottari period timeline; source event house groups; computation audit.
- South Indian chart is the implemented chart style. North/East styles are not claimed.

## Correctness & scope
- Horary number only sets FIRST cusp (sign/star/sub interval). Horary query epoch/location would be required for planets and the other cusps. Do not present natal data as horary calculations.
- KP Vimshottari uses independent KP sidereal Moon longitude at birth; current period hierarchy: MD/AD/PD/Sukshma/Prana.
- Significators, Ruling Planets, Cuspal Promise/Denial, Event Timing remain pending (no incorrect green checks).
- Rotation changes chart layout only; planetary/cusp longitudes are immutable.

## Verification
- Source ZIP integrity; all originally packaged files retained except the 3 replacements above.
- 555 Jaimini rule data and 255 Varga rule data retained byte-identically.
- Flutter SDK is not present in the packaging environment. APK release build is NOT verified for this version.
