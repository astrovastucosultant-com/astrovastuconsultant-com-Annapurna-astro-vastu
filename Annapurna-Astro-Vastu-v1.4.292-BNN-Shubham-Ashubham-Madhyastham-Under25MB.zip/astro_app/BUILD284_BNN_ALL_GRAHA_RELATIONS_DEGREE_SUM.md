# v1.4.284: Per-graha directed links and within-sign degree sums

Preserved complete v283 source, all original 462 IF/THEN source rules, 106 Master calculation rules, 48 timing rules and the two previously added combination engines.

- Relationships for every anchor planet: 1–5–9, 3–7–11, 2–12 measured 1-based forward from that planet. Source-specific node BNN_159_12 restriction applies to *node-origin* anchors: 1–5–9 and 12 only. Results are directed; A->B need not equal B->A.
- A third method enumerates all directed 2..9 member subsets anchored on each graha, restricted to the three relation families; identical member groups from different anchors are separate viewpoints, not additional life events.
- Each displayed combination shows arithmetic sum of within-sign DMS (rounded to arcseconds) for its exact 2..9 planet subset, e.g. 25°+29°+4°+19°=77°, equivalently 2 full 30-degree blocks plus 17° leftover. This is NOT a real sidereal longitude, event age, event date, or automatic IF/THEN.
- This addition has not been verified as a standard classical BNN event-timing technique in consulted sources, and is explicitly labeled mathematical exploration. DMS sum is not used to generate new natal/source-rule predictions.
- UI: BNN -> గ్రహసంబంధాలు -> డిగ్రీ క్రమం -> ప్రతి గ్రహం... / రెండు కాంబినేషన్ పద్ధతులు. Expand a combination to inspect sum.
- Tests: test/bnn_combination_engine_test.dart. Flutter SDK was not installed, so no Flutter compile claim.
