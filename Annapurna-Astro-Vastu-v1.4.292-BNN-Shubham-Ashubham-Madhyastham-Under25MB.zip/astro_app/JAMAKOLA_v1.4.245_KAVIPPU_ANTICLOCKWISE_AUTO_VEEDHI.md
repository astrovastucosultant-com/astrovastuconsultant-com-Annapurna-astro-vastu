# Jamakola v1.4.245 — Kavippu counter-motion sign and degree comparison

- Auto Veedhi based on sidereal Sun sign, using the three-way sign mapping already in v1.4.244. User may override this anchor if their source differs.
- One explicit implementation of the anticlockwise sign formula: D=(ArudamSign-VeedhiSign+12)%12, K=(UdhayamSign-D+12)%12.
- Pink KAV sign and the rule engine continue to share the existing sign computation; checked it now calls this helper.
- Degree values are **comparison conventions**, not validated precision for traditional verdicts: (a) reflected degree 30 - within-Arudam sign; (b) candidate full sphuta U+V-A modulo 360. No change to KAV manual exact-degree override or to its judgment gate.
- Added regression tests: 06-08-2018 U=Dhanu/A=Simha/V=Mesha => K=Simha, moving Arudam forward shifts Kavippu back, and exhaustively all 12x12x3 sign combinations.
- Existing Jama ring, Tamil solar Udayam, Mandi, KP and Tajik numerical algorithms unchanged.
- ZIP static consistency checked. No local Flutter/Dart toolchain; APK build must be verified with GitHub Actions.
