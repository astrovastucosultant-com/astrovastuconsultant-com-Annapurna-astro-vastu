# BNN v1.4.261 — 144 topic-specific interpretation cards

Starting source: v1.4.260 complete project.

- Retained all 462 original JSON BNN rules unchanged.
- Retained 12 colourful bhava tabs and five sub-tabs.
- Replaced generic Jupiter/karaka placement-only 144-topic descriptions with 144
  distinct topic-specific editorial interpretation hints.
- Evidence uses Jupiter as BNN house 1, natal planet sign/degrees, occupied
  planets in the selected bhava, and any Jupiter-karaka sign relation.
- Default Results screen now shows first 4 topic interpretation cards (expand
  to 8 and 12). Each card opens a scrollable sheet with its topic-specific
  interpretation, app heuristic IF-check, natal evidence and provenance.
- Source-backed matched results remain separate and retain tap-to-open IF-THEN.
- Editorial topical hints are explicitly labelled as unverified traditional
  interpretation, not as source-verified events or predictions.
- Previous Jamakola / Hasta features and other non-BNN source unchanged.
- Dart tests were added but cannot be executed in this environment (Flutter SDK absent).
