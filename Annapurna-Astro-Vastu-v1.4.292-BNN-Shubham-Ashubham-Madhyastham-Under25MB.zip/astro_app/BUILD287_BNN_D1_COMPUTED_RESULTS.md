# v1.4.287 — BNN D1 336: Compute rather than display pending references

Screenshot defect: topic cards previously displayed "ఇంకా IF నిర్ణారణ లేదు" and 48 modifiers displayed "CONDITION NOT EVALUATED". The first D1 bhava card displayed raw source instructions, not a natal computation. That was an actual missing evaluation layer, not just a text/localization issue.

## Implementation

- D1 house ruler/sign/lord's house, house occupants, classic Parashara aspects, lord's 27-star nakshatra ruler, own/exalt/debilitation signs and contact grahas evaluated against the supplied `AstroChartResult`.
- Evaluate 144 topic candidates against the topical karakas and connected house lord relationships. Only those with a directly computable positional relationship are shown; the other items remain in the 336-rule source catalogue rather than being marked 'pending' in the result screen. Each visible result carries the actual natal evidence.
- Evaluate 48 modifiers via actual benefic / malefic contacts, lord nakshatra, or a same-trine 0°..30° local-degree ordering with a <=5° later benefic. Only qualifying modifiers display. These are *traditional indicators*; not real-world event confirmation.
- The 144 lord placement alternatives are evaluated; the unique matching one is shown per house. The 11 nonmatching generic drafts are no longer rendered.
- First Bhava P4/P5 notes having executable predicates are matched separately and cite the classroom timestamp. General lessons remain in a closed reference section and are not falsely shown as matched predictions.
- UI result order: match first, matched class notes, applied topic interpretations, computed modifiers, optional original class notes. Expanded cards contain result, computed evidence, applied IF/THEN and provenance.
- Existing D1 natal reference and BNN Jupiter-relative readings remain separate. No 462 source rule or timing progression data was overwritten.

## Honesty of source attribution

The existing `bnn_d1_12_bhava_336_v1.json` was largely an analyst-derived *draft*: 144 topics without unique source IFs, and 48 general modifiers. These do **not** become source-proven book rules merely because they can be evaluated. The new UI marks their output as *traditional chart-based interpretation*. The teacher's specific P4/P5 classroom examples are displayed separately with real source timestamps, only when their natal IF is met. **No book title or page number has been fabricated.**

## Limits

- These chart-based, traditional interpretations do not prove a personal event. No unsupported medical diagnosis, death or divorce determination is produced.
- The numeric indicator weights sort favorable/mixed/challenging traditional contacts; they are not percentages or empirically validated probabilities.
- Annual or monthly event timing is not inferred from natal-only predicates: the pre-existing separate timing engine is unchanged.
- Flutter SDK is not available in this execution environment; automated Flutter compilation and test runs still require GitHub Actions. A static source and ZIP audit has been performed.
