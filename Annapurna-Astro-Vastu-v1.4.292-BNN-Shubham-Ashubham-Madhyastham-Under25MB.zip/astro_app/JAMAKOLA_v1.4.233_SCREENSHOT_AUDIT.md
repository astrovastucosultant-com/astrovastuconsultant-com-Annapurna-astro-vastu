# Jamakola v1.4.233 — Screenshot issues and targeted fixes

## What was actually visible in the four user screenshots

1. The full five-column planet table had been scrolled horizontally, hiding the first column with planet names.
2. The Prashna Confirmation panel displayed the pink `KAV` rasi-distance and a unique future moon-Jama/Udayam geometric contact.
3. The selected career/business IF–THEN panel said `0 matched / 0 unmatched / 11 pending`, with most missing `kavipu_house_from_udhayam`.
4. The current source shows two separately modeled solar-Veedhi reference paths. GK-compatible identity and exact degrees are not fully verified.

## Changes

- Full table on phones: freeze the **Planets** column, allow horizontal scroll only for Longitude, Degrees, Star, Pada. A compact card view remains the default.
- Make the displayed pink KAV rasi the same input used for `kavipu_house_from_udhayam` in the rule engine (fixed missing fact). User-entered KAV longitude or rasi overrides the preliminary automatically derived point.
- A unique upcoming *mathematical* Jama/Udayam crossing may populate `approaching_udhayam` for **provisional filtering** only. It is never silently passed as verified traditional evidence. Multiple contacts / no contacts do not infer a unique approaching planet.
- Rule UI separates verified/manual-input-supported matches, **provisional matches**, provisional mismatches, true mismatches, and cases requiring unavailable facts. Every provisional match identifies the source limitation, the IF condition, the rule's file/page and the lack of an authenticated remedy.
- Do not change ephemeris, angular formula, 74 Jamakola rules, KP, Tajik, Jaimini or Varga contents.

## Verification limitations

- Static checks and ZIP integrity only; Flutter SDK / APK build not available in the local environment.
- A manually selected point is **user-entered**, not independently verified by the app.
- The automatically computed pink KAV rasi is **not** demonstrated equal to GK Kavippu; formula identification must still be verified with source tables and repeatable GK Astro examples.
- No quantified certainty or guaranteed Yes/No result can responsibly be inferred from one partial traditional rule.
