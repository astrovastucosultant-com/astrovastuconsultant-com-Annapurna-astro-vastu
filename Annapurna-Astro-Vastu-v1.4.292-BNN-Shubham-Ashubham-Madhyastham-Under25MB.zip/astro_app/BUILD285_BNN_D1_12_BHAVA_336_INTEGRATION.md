# v1.4.285 — BNN D1 12 Bhava Reference 336 Integration

Base: full v1.4.284 source zip. Adds **separate** BNN navigation item `D1 12 భావఫలాలు (336)` without changing the existing Jupiter-relative BNN bhava navigation or 462 source rule matching.

## Added
- `assets/bnn/bnn_d1_12_bhava_336_v1.json`: exact original 336-rule draft source (144 topic checks, 144 lord placements, 48 modifiers), plus 17 source notes. This is **not** 336 independently verified life predictions.
- `lib/astrology/bnn_d1_bhava_rules.dart`: parsed & checked source; true D1 lagna indexing from ascendant longitude (Aries=0, 12 signs); traditional seven planet sign rulership; verifies `lord_of -> lord_occupies_house` in the natal chart.
- `lib/screens/bnn_d1_bhava_panel.dart`: user-facing 12-house selector, highlights **exactly one** true positional IF per selected lord, displays actual natal placement evidence, lists nonmatching 11 IFs only if expanded and marked FALSE, 12 topic checks marked not evaluated, 4 modifiers marked not evaluated, class source notes and expandable `ఫలితం → జాతక పరిశీలన → మూల IF–THEN → పరిహారం → సంఘటన సమయం`.
- `test/bnn_d1_bhava_rules_test.dart`: 12*12 natal geometry, Pisces wrap, 336 asset integrity, no conflation of coordinate systems.

## Safeguards
- Existing BNN six tabs retain their order and behavior; seventh is a separate D1 ruleset.
- All 462 historical BNN source rules, 106 engine specs, 48 timing rules, relative Jupiter progression, plus v284 degree-combination engines remain unchanged.
- No fabricated remedies, event dates, or claims of verified future events; true birth-chart IF means **placement**, not empirical outcome.
- No source substitutions: the original 336 draft rules are copied byte-for-byte to assets/bnn.

## Validation state
- JSON structure/integrity and code integration references checked with Python.
- Flutter SDK/Dart tools not available in this runtime, so `flutter analyze`, `flutter test` and APK compilation have **not** been executed. Run GitHub workflow/Flutter CI before claiming a successful build.
