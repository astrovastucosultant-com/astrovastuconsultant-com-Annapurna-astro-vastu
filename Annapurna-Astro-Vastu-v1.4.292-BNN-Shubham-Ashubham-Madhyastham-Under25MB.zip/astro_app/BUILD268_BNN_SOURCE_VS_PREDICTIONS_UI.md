# Build v1.4.268 — BNN source indexing separate from predictions

- Build #302 GitHub Actions actually used v1.4.267 and compiled an APK successfully.
- Previous topic index showed full source THEN sentences inline; users could mistake these for chart-verified results.
- Moved all 12 bhava-topic source indexes into a separately opened bottom sheet; the main Results screen retains natal single-sign candidate results and separates unverified cross-sign checks.
- Strict exact outcome phrase keywords for family values, relatives assistance, savings and sibling titles; generic `కుటుంబ`/`బంధువుల` or `ధనవంత` no longer misclassify those topics.
- Do not show the first unverified THEN sentence in a navigation card. Every library card explicitly says conditions are not verified.
- No invented THEN statements. User's 462 IF/THEN rules and source JSON unchanged. No live timing or fully verified 462-rule matching claimed.
- Added regression tests for screenshot examples: `వ్యవసాయ కుటుంబ జన్మ` vs `కుటుంబ విలువలు`, `భార్య బంధువుల నుంచి` vs `బంధువుల సహకారం`, acquisition vs retention of wealth.
- Set version 1.4.268+268. Local runtime has no Flutter SDK; compile still requires GitHub.
