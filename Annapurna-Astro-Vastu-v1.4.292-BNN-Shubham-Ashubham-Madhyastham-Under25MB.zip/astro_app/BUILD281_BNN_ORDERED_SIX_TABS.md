# BNN 1.4.281 — Six ordered tabs

Top navigation now groups BNN into six areas: (1) chart IF matched results, (2) twelve BNN bhavas retaining the existing five subtabs, (3) natal degrees and relation chains, (4) age-based progression and transit timing, (5) relationships, (6) complete searchable 462-rule source catalogue with TRUE/FALSE/unparsed filters.

Changes are UI navigation and separation only. The source JSON for 462 + 106 + 48 is unchanged. No claim of verified events. The 106 engine specs remain accessible inside Graha Relations; 48 timing specs remain accessible in Timing. Expanded technical charts and pre-verified sources are collapsed on the bhava results tab. Flutter compilation is not available in this environment.
