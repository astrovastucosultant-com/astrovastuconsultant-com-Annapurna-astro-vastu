# v1.4.272 BNN topic source vs actual natal IF

- Topic library shows source-bearing THEN topics first. No-source topics are preserved, collapsed under a separate ExpansionTile. All 144 labels remain available across the 12 houses.
- Every source rule has its own BnnExactIfEngine.check status: matching natal placement with OCR unverified; nonmatching; unsupported parser. No source rule is marked VERIFIED.
- Topic and bhava views label house occupancy accurately and offer a full natal 9-planet position list in Jupiter-relative house coordinates.
- All 462 original IF-THEN source rules, 106 engine rules, 48 timing rules, and unrelated modules preserved verbatim.
- Flutter SDK unavailable locally; this source patch was inspected but not Flutter-compiled or APK-tested.
