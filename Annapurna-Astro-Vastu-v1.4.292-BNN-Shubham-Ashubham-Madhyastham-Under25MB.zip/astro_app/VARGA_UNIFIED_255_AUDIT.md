# Annapurna Astro Vastu v1.4.218 – వర్గ సమగ్ర ఫలితాలు

## Scope
- Added a **new top-level `వర్గ` tab** adjacent to existing `వర్గాలు`.
- Uses original 255-entry `Mallikarjuna_Varga_IF_THEN_Degree_Shadvarga_255_Rules.json` catalog unchanged as bundled source data (247 source PDF rules + 8 separately documented degree/shadvarga rules).
- Groups all 255 IF–THEN source records by source topic and has quick search, group selection and applicability filters.
- Strict rule: only verified matched rule **THEN text** has a green background / green lettering. No entire card, title, IF text, evidence, or pending/source-only text gets green treatment.
- Matched groups and matched rules are sorted ahead of other groups/rules.
- Each item reveals IF text, chart inspection/evidence, original THEN and PDF source pages. For unmatched/pending items original THEN appears only as a source quotation, NOT a personalized prediction.
- A collapsed degree / shadvarga panel shows the user's custom within-sign degree ranking and current app's D1+D2+D3+D9+D12+D30 Vimsopaka score separately; these are NOT occurrence probabilities. This is distinct from conventional Shadbala.

## Automated predicate scope
Direct fully checked IDs (true/false when all inputs exist):
VARGA-D2-001..006, VARGA-D3-003, VARGA-D7-004,
VARGA-D9-001, VARGA-D10-006, VARGA-D12-005,
VARGA-D16-005, VARGA-D27-002.

Limited sufficient-match branches (TRUE if explicit placement/aspect condition observed, otherwise PENDING instead of FALSE, because other possible source alternatives remain):
VARGA-D7-005, VARGA-D7-007, VARGA-D9-002, VARGA-D9-004,
VARGA-D10-001, VARGA-D10-002, VARGA-D12-006, VARGA-D12-007,
VARGA-D12-008, VARGA-D12-012, VARGA-D20-003, VARGA-D24-002,
VARGA-D30-003, VARGA-D45-002.

Other rules stay pending or are classified as source/workflow steps; NO guessed outcomes are displayed. D5, D6, D8, D11 source rules are intentionally retained but cannot be auto-evaluated because these factors are not implemented in the current VargaService. This patch does not promise all 255 are automatically matched.

This package also retains the independent 555-rule Jaimini section; the 255 new Varga catalog MUST NOT be conflated with it.

## Validation
- Original 255 entries: JSON intact and unique IDs confirmed.
- Top-level chart TabBar and TabBarView: 12 tabs each.
- Source screen references in chart_screen.dart and asset registered in pubspec.yaml.
- ZIP CRC integrity check completed.
- Flutter/Dart compilation needs verification through existing GitHub Actions after upload.
