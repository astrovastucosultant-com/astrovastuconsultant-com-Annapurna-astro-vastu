# Jamakola v1.4.234 — IF–THEN topic, alternate-house and pending-evidence UI correction

## Screenshots used

Three screenshots received on 25 October 2026 show a `question_subject` panel with green `JA-ARU-H01`, eleven pink crosses for other houses, eight repeated `approaching_udhayam` missing facts, and a `childbirth` panel with no matching verdict. These are diagnostic UI/semantics issues; screenshots do not establish a new astronomical formula.

## Implemented

1. The 20 `question_subject` rules are **bhava / approaching-graha subject indicators**, not yes/no event predictions. Separate them from event-specific matched/mismatched IF–THEN results. Selecting a topic shows only associated source rule IDs (a curated, auditable lookup), not unrelated indicators.
2. Other Arudam houses and nonmatching IF alternatives are collapsed under "currently non-applicable alternatives" with neutral icons. A nonmatching rule **never** means denial or failure.
3. Missing `approaching_udhayam` is one unavailable observation underlying up to eight alternative rules, not eight independently proven failures. Explain this and provide an optional manual verified selector in the pending group. Do not auto-invent a source-verified approaching planet.
4. When topic is childbirth, explicitly disclose there is currently **one** direct childbirth rule in the 74-rule JSON, not a complete childbirth decision engine. Even a missed match does not mean infertility or a negative final decision.
5. Keep preliminary KAV calculation labelled provisional; charts and calculations unchanged. KP and Tajik integration of a single verdict remains future work.
6. New isolated rule-engine helper `matchingIndicators` and focused `flutter_test` cases for selected Arudam house, topic typing, and missing approaching fact.

## Preserved

- 74 Jamakola JSON rules, 555 Jaimini, 255 Varga, and all KP assets byte-for-byte from v1.4.233.
- Swiss Ephemeris, eight Jama graha longitudes, and U/ARU/KAV graphic/degree calculations.

## Validation

- Source and JSON consistency, ZIP CRC and path audit completed.
- Flutter SDK unavailable in artifact execution runtime: Dart analysis, widget tests and APK build NOT executed. No claim of confirmed compile success.
