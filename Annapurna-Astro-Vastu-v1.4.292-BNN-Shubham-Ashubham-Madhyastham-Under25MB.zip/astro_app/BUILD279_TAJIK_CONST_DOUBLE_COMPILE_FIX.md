Annapurna Astro Vastu — v1.4.236 Tajik compile fix

Cause of GitHub Actions build #278 failure:
lib/astrology/tajik_prashna_service.dart:32
Dart rejects integer keys inside a const <double,String> map.

Fix: change the five aspect keys to double literals:
0.0, 60.0, 90.0, 120.0, 180.0.
App version advanced to 1.4.236+236.

No changes to Jamakola, KP, Tajik calculation logic, IF–THEN JSON, fonts,
UI layout, or Android Gradle/Kotlin configuration.

Verification: ZIP testzip and byte-for-byte unchanged inspection.
Flutter SDK is not available in the authoring environment; APK build and
flutter test must be validated by the user's GitHub Actions run.

NOTE: shared_preferences_android built-in Kotlin Gradle migration warning
in build #278 is not the fatal error shown in that run.
