# Annapurna Astro Vastu 1.4.254 — Jamakola NOW → Nimitta source integration

## Basis and placement

- Base project: v1.4.253 BNN 12 Bhava Five Sub-tabs full Flutter source.
- Source supplied: `జామకోల్ ప్రశ్న & నిమిత్త శాస్త్ర 300 సూత్రాల సమగ్ర సర్వస్వం.pdf`, 12 pages, 300 numbered rows (25/page).
- All 300 rows preserved as data (five distinct source conditions/results; minor repeated-combining-mark cleanup for Telugu PDF text extraction).
- Existing upper Jama chart and lower ordinary question-time planetary chart retained.
- NOW reuses existing location / UTC-offset adjusted current time, recalculates chart, special Udayam, Arudam, Jama ring, Mandī as before.
- New expandable Nimitta interpretation panel immediately below the lower planetary chart. It shows the query timestamp, current Udayam/Arudam/Kavippu rasis, prioritized candidate topics, source conditions, and astrologer-observed nimitta checkbox.

## Evidence and non-claims

- Automatic checking supports explicit zodiac modality/element of Udayam, relative-sign Arudam house, and some Kavippu house / named-planet sign conditions. Ambiguous or undefined source terms are marked pending, never auto confirmed.
- Kavippu sign is a preliminary calculation in the existing app, and exact degrees remain manually verified. Source angular minute comparisons are only computed when exact Kavippu longitude is supplied.
- The source's equation `minutes = Δθ(degrees) * 4` gives 24 minutes for 6°, while its first example labels it 25 minutes. The app calculates mathematical elapsed minutes separately rather than silently reconciling conflicting values.
- PDF does not fully disambiguate inner astronomical vs separate Jama ring for named graha factors. Both are displayed; traditional inference remains pending.
- Observed nimitta requires a deliberate user checkbox, and is cleared on recalculation / NOW.
- A traditional event inference is NOT proof of an actual illness, theft, crime, deception, or prior event. The app must not assert such claims as facts.

## Validation limits

- JSON / 300 distinct rule IDs, source continuity, YAML asset declarations, and relative Dart import paths can be statically inspected.
- Flutter/Dart SDK is unavailable in this environment; actual `flutter analyze`, `flutter test` and APK compilation have not run.
