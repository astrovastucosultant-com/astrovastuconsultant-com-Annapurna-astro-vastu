import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jamakola_rule_engine.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('Only the active Arudam house is an indicator, others are not denials', () {
    final twelve = <JamakolaRule>[
      for (var i=1; i<=12; i++)
        JamakolaRule('JA-ARU-H${i.toString().padLeft(2, '0')}',
          'question_subject', 'భావ సూచన $i', 'book', '1',
          {'arudam_house_from_udhayam': i}),
    ];
    final active=JamakolaRuleEngine.matchingIndicators(
      twelve, {'arudam_house_from_udhayam': 1});
    expect(active.length, 1);
    expect(active.single.id, 'JA-ARU-H01');
    expect(JamakolaRuleEngine.isSubjectIndicator(active.single), isTrue);
  });

  test('Question indicators never count as direct event-decision rules', () {
    const generic = JamakolaRule('JA-ARU-H05', 'question_subject',
      'సంతానం, విద్య, ప్రేమ', 'book', '1',
      {'arudam_house_from_udhayam': 5});
    const direct = JamakolaRule('JA-CHILD-01', 'childbirth',
      'సంతాన అంశం', 'book', '2',
      {'kavipu_house_from_udhayam': 5});
    expect(JamakolaRuleEngine.isSubjectIndicator(generic), isTrue);
    expect(JamakolaRuleEngine.isSubjectIndicator(direct), isFalse);
    expect(JamakolaRuleEngine.matchingIndicators(
      [generic, direct], {'arudam_house_from_udhayam': 5},
      allowedIds: {'JA-ARU-H05'}).map((r)=>r.id),
      contains('JA-ARU-H05'));
    expect(JamakolaRuleEngine.matches(direct,
      {'kavipu_house_from_udhayam': 7}), isFalse);
  });

  test('Missing approaching planet remains missing, not eight denials', () {
    final rules=<JamakolaRule>[
      for (final p in ['Sun','Moon','Mars','Mercury','Venus','Jupiter','Saturn','Rahu'])
        JamakolaRule('JA-APP-$p', 'question_subject', p, 'book','1',
          {'approaching_udhayam': p}),
    ];
    expect(JamakolaRuleEngine.matchingIndicators(rules, {}), isEmpty);
    expect(JamakolaRuleEngine.matchingIndicators(rules,
      {'approaching_udhayam':'Moon'}).single.id, 'JA-APP-Moon');
  });
}
