import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/mandi_calculation_service.dart';

void main() {
  test('Prasna Marga scaled-ghati fraction: all seven weekdays', () {
    const day = <int>[26, 22, 18, 14, 10, 6, 2];
    const night = <int>[10, 6, 2, 26, 22, 18, 14];
    for (var weekday = 0; weekday < 7; weekday++) {
      expect(MandiTiming.mandiFraction(weekday, night: false),
        closeTo(day[weekday] / 30.0, 1e-12));
      expect(MandiTiming.mandiFraction(weekday, night: true),
        closeTo(night[weekday] / 30.0, 1e-12));
    }
  });
  test('BPHS Saturn eighth-parts rotate for day and night', () {
    expect([for (var i = 0; i < 7; i++)
      MandiTiming.saturnSegment(i, night: false)],
      [6, 5, 4, 3, 2, 1, 0]);
    expect([for (var i = 0; i < 7; i++)
      MandiTiming.saturnSegment(i, night: true)],
      [2, 1, 0, 6, 5, 4, 3]);
  });
  test('Mandi vs Gulika are not falsely conflated', () {
    // Sunday day: Mandi at 26/30 ≠ Gulika BEGINNING at 6/8.
    final mandi = MandiTiming.mandiFraction(0, night: false);
    final gulikaStart = MandiTiming.saturnSegment(0, night: false) / 8.0;
    expect(mandi, closeTo(0.8666666667, 1e-9));
    expect(gulikaStart, 0.75);
    expect(mandi, isNot(gulikaStart));
  });
  test('Reject invalid weekday instead of silently wrapping', () {
    expect(() => MandiTiming.mandiFraction(-1, night: true), throwsArgumentError);
    expect(() => MandiTiming.saturnSegment(7, night: false), throwsArgumentError);
  });
}
