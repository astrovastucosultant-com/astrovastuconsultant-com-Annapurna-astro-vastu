import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/unified_prashna_service.dart';

void main(){
  test('topic mapping never pretends every KP question is a Jama rule',(){
    expect(UnifiedPrashnaService.jamaModule('సంతానం'),'childbirth');
    expect(UnifiedPrashnaService.jamaModule('వివాహం, సంబంధాలు'),'marriage');
    expect(UnifiedPrashnaService.jamaModule('విదేశం, ప్రయాణం'),'foreign');
    expect(UnifiedPrashnaService.jamaModule('ఇతర అంశాలు'),isNull);
  });
}
