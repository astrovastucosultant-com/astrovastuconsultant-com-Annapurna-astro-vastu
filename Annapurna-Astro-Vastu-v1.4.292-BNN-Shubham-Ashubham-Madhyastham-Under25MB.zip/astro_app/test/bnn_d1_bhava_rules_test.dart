import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_d1_bhava_rules.dart';

PlanetPosition planet(String name, int sign) => PlanetPosition(
  name: name, shortName: name.substring(0, 2),
  longitude: sign * 30 + 12.0, latitude: 0.0, speed: 1.0,
);

AstroChartResult fakeChart(int lagna) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 0,
  ascendantLongitude: lagna * 30 + 2.0,
  planets: [
    planet('Sun', 4), planet('Moon', 3), planet('Mars', 6),
    planet('Mercury', 2), planet('Jupiter', 8),
    planet('Venus', 1), planet('Saturn', 10),
    planet('Rahu', 9), planet('Ketu', 3),
  ],
  engineVersion: 'fixture',
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('D1 houses count from ASC, not Jupiter', () {
    final chart = fakeChart(0); // Aries rising, Jupiter in Sagittarius
    expect(BnnD1BhavaGeometry.signForHouse(chart, 1), 0);
    expect(BnnD1BhavaGeometry.signForHouse(chart, 10), 9);
    expect(BnnD1BhavaGeometry.houseForSign(chart, 8), 9);
    expect(BnnD1BhavaGeometry.placement(chart, 1)!.lordPlanet, 'Mars');
    expect(BnnD1BhavaGeometry.placement(chart, 1)!.lordHouse, 7);
    expect(BnnD1BhavaGeometry.placement(chart, 9)!.lordHouse, 9);
  });

  test('Wrap from Pisces Lagna to Aries and use traditional lords', () {
    final chart = fakeChart(11);
    expect(BnnD1BhavaGeometry.signForHouse(chart, 2), 0);
    expect(BnnD1BhavaGeometry.placement(chart, 1)!.lordPlanet, 'Jupiter');
    expect(BnnD1BhavaGeometry.placement(chart, 1)!.lordHouse, 10);
    expect(BnnD1BhavaGeometry.houseForSign(chart, 0), 2);
    expect(BnnD1BhavaGeometry.placement(chart, 2)!.lordHouse, 8);
  });

  test('Each lord is in exactly one D1 bhava', () {
    for (var asc = 0; asc < 12; asc++) {
      final chart = fakeChart(asc);
      for (var h = 1; h <= 12; h++) {
        final p = BnnD1BhavaGeometry.placement(chart, h);
        expect(p, isNotNull);
        expect(p!.lordHouse, inInclusiveRange(1, 12));
        expect(BnnD1BhavaGeometry.houseForSign(chart, p.lordSign), p.lordHouse);
      }
    }
  });

  test('All 336 draft rules load and positional IF is separate from THEN', () async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_d1_12_bhava_336_v1.json');
    final catalogue = BnnD1BhavaCatalogue.parse(raw);
    expect(catalogue.rules.length, 336);
    expect(catalogue.rules.every((r) => r.ruleLabel == 'సిద్ధాంతి రూల్'), isTrue);
    expect(catalogue.houses.length, 12);
    expect(catalogue.notes, isNotEmpty);
    for (var house = 1; house <= 12; house++) {
      final topics = catalogue.forHouse(house, 'BHAVA_TOPIC_CHECK');
      final lords = catalogue.forHouse(house, 'BHAVA_LORD_PLACEMENT');
      final mods = catalogue.forHouse(house, 'CONDITIONAL_MODIFIER');
      expect(topics.length, 12);
      expect(lords.length, 12);
      expect(mods.length, 4);
      expect(topics.any((r) => r.eligible), isFalse);
      expect(mods.any((r) => r.eligible), isFalse);
      final chart = fakeChart(0);
      expect(lords.where((r) => BnnD1BhavaGeometry.matchesLordPlacement(chart, r)).length, 1);
    }
    final doc = jsonDecode(raw) as Map<String, dynamic>;
    expect(doc['house_basis_modes']['NEVER_MIX_AS_IF_IDENTICAL'], isTrue);
    expect(doc['rule_series_label'], 'సిద్ధాంతి రూల్');
    expect(catalogue.rules.where((r) => r.provenance ==
      'USER_TRANSCRIPT_FIRST_BHAVA_P5_3RD_LORD').length, 1);
    expect(catalogue.notes.length, 17);
  });
}
