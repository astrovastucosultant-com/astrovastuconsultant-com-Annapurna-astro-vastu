import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_all_rules_match_service.dart';
import 'package:astro_app/astrology/bnn_exact_if_engine.dart';
import 'package:astro_app/astrology/bnn_rule_verdict.dart';

BnnMasterRule g05() => const BnnMasterRule(
  id: 'BNN-BOOK-G05', source: 'Brighu_Naadi_Purnna_Rulebook.pdf',
  sourcePage: 11, topic: 'ఉద్యోగం', condition: 'సూర్యుడు శనికి 11',
  result: 'ప్రభుత్వ ఉద్యోగం', inspection: '', remedy: '',
  status: 'OCR_REVIEW',
);

AstroChartResult chart(double sun, double saturn) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 0,
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: sun,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: saturn,
        latitude: 0, speed: .1),
  ], engineVersion: 'test',
);

void main() {
  test('G05: Virgo Saturn to Scorpio Sun is 3rd, not 11th', () {
    final c = chart(210 + 29.74, 150 + 26.78);
    final check = BnnAllRulesMatchService.check(g05(), c);
    expect(check.evaluable, isTrue);
    expect(check.matched, isFalse);
    expect(BnnRuleVerdict.result(g05(), check), 'ప్రభుత్వ ఉద్యోగం లేదు');
    final detail = BnnRuleVerdict.inspection(g05(), c, check);
    expect(detail.contains('3 వ స్థానం'), isTrue);
    expect(detail.contains('11వ స్థానం'), isTrue);
  });

  test('G05: Virgo Saturn to Cancer Sun is 11th', () {
    final c = chart(90 + 12.0, 150 + 26.78);
    final check = BnnAllRulesMatchService.check(g05(), c);
    expect(check.evaluable, isTrue);
    expect(check.matched, isTrue);
    expect(BnnRuleVerdict.result(g05(), check), 'ప్రభుత్వ ఉద్యోగం');
  });

  test('Unknown IF cannot be inverted to a confident negative', () {
    expect(BnnRuleVerdict.result(g05(), BnnExactIfResult.unsupported),
        'ఈ రూల్‌కు జాతక ఫలితం నిర్ణయించబడలేదు');
  });
  test('C04: Jupiter Aquarius, Saturn Aries, Rahu Cancer do not meet both seventh-house IFs', () {
    const source = BnnMasterRule(
      id: 'BNN-BOOK-C04', source: 'Brighu_Naadi_Purnna_Rulebook.pdf',
      sourcePage: 3, topic: 'గురు యోగాలు',
      condition: 'గురుకి 7లో శని+రాహు',
      result: 'తక్కువ జీతం సేవకుడు', inspection: '', remedy: '',
      status: 'OCR_REVIEW',
    );
    final c = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 0,
      engineVersion: 'test', planets: [
        PlanetPosition(name: 'Jupiter', shortName: 'Ju',
            longitude: 300 + 26.92, latitude: 0, speed: 1),
        PlanetPosition(name: 'Saturn', shortName: 'Sa',
            longitude: 2.96, latitude: 0, speed: 0.1),
        PlanetPosition(name: 'Rahu', shortName: 'Ra',
            longitude: 90 + 29.41, latitude: 0, speed: -0.1),
      ],
    );
    final check = BnnAllRulesMatchService.check(source, c);
    expect(check.evaluable, isTrue);
    expect(check.matched, isFalse);
    expect(BnnRuleVerdict.result(source, check),
        'తక్కువ జీతం సేవకుడు సూచన లేదు');
  });

}
