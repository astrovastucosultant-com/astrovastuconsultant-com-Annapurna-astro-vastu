import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_timing_progression_service.dart';

PlanetPosition p(String name, double longitude) => PlanetPosition(
  name: name, shortName: name.substring(0, 2),
  longitude: longitude, latitude: 0, speed: 0.01,
);
AstroChartResult natal(List<PlanetPosition> planets) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 89,
  planets: planets, engineVersion: 'test',
);

void main() {
  test('User master profile speeds are distinct and signed', () {
    expect(BnnTimingProgressionService.speed('Jupiter', BnnProgressionProfile.raoApprox), 30);
    expect(BnnTimingProgressionService.speed('Saturn', BnnProgressionProfile.raoApprox), 12);
    expect(BnnTimingProgressionService.speed('Rahu', BnnProgressionProfile.raoApprox), closeTo(-360/18.6, 1e-9));
    expect(BnnTimingProgressionService.speed('Jupiter', BnnProgressionProfile.slowDegrees), 2.5);
    expect(BnnTimingProgressionService.speed('Saturn', BnnProgressionProfile.slowDegrees), 1.0);
    expect(BnnTimingProgressionService.speed('Ketu', BnnProgressionProfile.slowDegrees), closeTo(-5/3, 1e-9));
  });

  test('Rao progression is symbolic, natal longitude is unchanged', () {
    final j = p('Jupiter', 350);
    final progressed = BnnTimingProgressionService.progress(j, 2, BnnProgressionProfile.raoApprox);
    expect(progressed.longitude, 50);
    expect(j.longitude, 350);
    final slow = BnnTimingProgressionService.progress(j, 2, BnnProgressionProfile.slowDegrees);
    expect(slow.longitude, 355);
    expect(progressed.longitude, isNot(slow.longitude));
  });

  test('Contacts enumerate multiple Jupiter revolutions without blending profiles', () {
    final chart = natal([p('Jupiter', 10), p('Venus', 100)]);
    final results = BnnTimingProgressionService.contacts(chart: chart,
        profile: BnnProgressionProfile.raoApprox, fromAge: 0, toAge: 30)
        .where((c) => c.mover == 'Jupiter').toList();
    expect(results.map((c) => c.ageYears).toList(), [3, 15, 27]);
    expect(results.map((c) => c.jupiterRound).toList(), [1, 2, 3]);
    final slow = BnnTimingProgressionService.contacts(chart: chart,
        profile: BnnProgressionProfile.slowDegrees, fromAge: 0, toAge: 30);
    expect(slow.where((c) => c.mover == 'Jupiter'), isEmpty);
  });

  test('Negative nodal speed resolves contact by backward motion', () {
    final chart = natal([p('Rahu', 100), p('Moon', 80)]);
    final results = BnnTimingProgressionService.contacts(chart: chart,
        profile: BnnProgressionProfile.raoApprox, fromAge: 0, toAge: 5);
    final node = results.singleWhere((c) => c.mover == 'Rahu');
    expect(node.ageYears, closeTo(20/(360/18.6), 1e-9));
  });

  test('Transit sign relationships stay separate, no invented exact date', () {
    expect(BnnTimingProgressionService.transitRelation(124, 4), 'TRINE_159');
    expect(BnnTimingProgressionService.transitRelation(184, 4), 'OPPOSITION_7');
    expect(BnnTimingProgressionService.transitRelation(20, 4), 'SAME_SIGN');
    expect(BnnTimingProgressionService.transitRelation(64, 4), isNull);
  });

  test('No verified source means never a final event', () {
    expect(BnnTimingProgressionService.finalEligible(
      verifiedNatalEventSource: false,
      matchingProgression: true, overlappingRealTransit: true), isFalse);
    expect(BnnTimingProgressionService.finalEligible(
      verifiedNatalEventSource: true,
      matchingProgression: true, overlappingRealTransit: true), isTrue);
  });

  test('Future 7th-round meanings cannot be inferred from round number', () {
    expect(BnnTimingProgressionService.jupiterRound(0), 1);
    expect(BnnTimingProgressionService.jupiterRound(12), 2);
    expect(BnnTimingProgressionService.jupiterRound(72), 7);
  });
}
