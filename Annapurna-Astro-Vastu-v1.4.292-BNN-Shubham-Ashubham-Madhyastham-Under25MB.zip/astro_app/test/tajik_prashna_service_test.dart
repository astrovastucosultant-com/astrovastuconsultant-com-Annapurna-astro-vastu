import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/tajik_prashna_service.dart';

AstroChartResult chart({required double mars, required double venus}) =>
  AstroChartResult(julianDay:2460000,ayanamsaDegrees:24,
    ascendantLongitude:5,engineVersion:'unit-test',planets:[
    PlanetPosition(name:'Mars',shortName:'Ma',longitude:mars,latitude:0,speed:0.5),
    PlanetPosition(name:'Venus',shortName:'Ve',longitude:venus,latitude:0,speed:1.2),
  ]);

void main(){
  test('same-sign Tajika aspect approaching with Venus catching Mars',(){
    final r=TajikPrashnaService.evaluate(chart:chart(mars:12,venus:10),
      questionHouse:2);
    expect(r.status,'applying');
    expect(r.lagnaLord,'Mars');
    expect(r.questionLord,'Venus');
    expect(r.distanceDegrees,closeTo(2,0.001));
  });
  test('same-sign Tajika aspect separating',(){
    final r=TajikPrashnaService.evaluate(chart:chart(mars:10,venus:12),
      questionHouse:2);
    expect(r.status,'separating');
  });
  test('faraway is outside orb, not negative event decision',(){
    final r=TajikPrashnaService.evaluate(chart:chart(mars:1,venus:29),
      questionHouse:2);
    expect(r.status,'outside_orb');
  });
  test('same lord is not an imaginary inter-planet aspect',(){
    final r=TajikPrashnaService.evaluate(chart:chart(mars:12,venus:10),
      questionHouse:1);
    expect(r.status,'same_lord');
  });
}
