import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_bhava_topics.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_topic_reading_service.dart';

// Regression fixture derived from the natal placements shown in the user's
// screenshot. These are test inputs, not a validated native's birth record.
AstroChartResult exampleChart() => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 0,
  planets: [
    PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 59.74,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 115.14,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 96.12,
        latitude: 0, speed: .1),
    PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 242.41,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 39.81,
        latitude: 0, speed: .1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 280.45,
        latitude: 0, speed: 1),
    PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 116.78,
        latitude: 0, speed: .1),
    PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 89.13,
        latitude: 0, speed: -.1),
    PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 269.13,
        latitude: 0, speed: -.1),
  ], engineVersion: 'test',
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('All 144 bhava topics receive chart-karaka inspection', () async {
    final catalog = await BnnMasterCatalog.load();
    var inspected = 0;
    for (final topic in BnnBhavaTopicService.byHouse.expand((x) => x)) {
      final reading = BnnTopicReadingService.inspect(
          topic, catalog, exampleChart());
      expect(reading.karakaInspection, isNotEmpty);
      expect(reading.sourceCount,
          reading.natalMatches.length + reading.natalNonMatches.length +
              reading.notComputable.length);
      inspected++;
    }
    expect(inspected, 144);
  });

  test('Screenshot chart does NOT satisfy C39 courage or C42 exaltation', () async {
    final catalog = await BnnMasterCatalog.load();
    final courage = BnnTopicReadingService.inspect(
      const BnnBhavaTopic(1, 'ధైర్యం', 'Mars'),
      catalog, exampleChart());
    expect(courage.natalMatches.any((hit) =>
        hit.$1.id == 'BNN-BOOK-C39'), isFalse);
    expect(courage.natalNonMatches.any((hit) =>
        hit.$1.id == 'BNN-BOOK-C39'), isTrue);
    final body = BnnTopicReadingService.inspect(
      const BnnBhavaTopic(1, 'శరీర స్వభావం', 'Sun'),
      catalog, exampleChart());
    expect(body.natalMatches.any((hit) =>
        hit.$1.id == 'BNN-BOOK-C42'), isFalse);
  });

  test('Devotional outcomes include cross-house self traits, not spouses', () async {
    final catalog = await BnnMasterCatalog.load();
    final devotion = BnnTopicReadingService.inspect(
      const BnnBhavaTopic(1, 'దైవచింతన', 'Ketu'),
      catalog, exampleChart());
    expect(devotion.sourceCount, greaterThan(0));
    expect(devotion.natalMatches.any((hit) =>
        hit.$1.id == 'BNN-BOOK-C53'), isFalse);
  });
}
