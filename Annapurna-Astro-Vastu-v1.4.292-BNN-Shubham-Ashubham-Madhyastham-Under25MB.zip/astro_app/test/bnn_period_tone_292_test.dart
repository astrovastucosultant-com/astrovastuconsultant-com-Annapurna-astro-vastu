import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_relative_timing_service.dart';

PlanetPosition _p(String name, double longitude) => PlanetPosition(
    name: name, shortName: name.substring(0, 2), longitude: longitude,
    latitude: 0, speed: 0.1);

AstroChartResult _chart(List<PlanetPosition> planets) => AstroChartResult(
    julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 18,
    planets: planets, engineVersion: 'test');

BnnPeriodReading _read(AstroChartResult chart,
    {List<BnnMasterRule> sources = const []}) {
  final jupiter = chart.planets.firstWhere((p) => p.name == 'Jupiter');
  final mars = chart.planets.firstWhere((p) => p.name == 'Mars');
  final house = BnnRelativeTimingService.relativeHouse(
      jupiter.signIndex, mars.signIndex);
  final w = BnnRelativeTimingService.annualJupiterWindows(
      house: house, birthYear: 1981).first;
  return BnnRelativeTimingService.inspectPeriod(
      chart: chart, jupiter: jupiter, target: mars,
      window: w, passingSource: sources);
}

BnnMasterRule _source(String result) => BnnMasterRule(
    id: 'BNN-TEST', source: 'test', sourcePage: 1,
    topic: 'test', condition: 'test', result: result,
    inspection: '', remedy: '', status: 'test');

void main() {
  test('No angular or source verdict is mixed, not invented auspicious', () {
    final result = _read(_chart([_p('Jupiter', 12), _p('Mars', 105)]));
    expect(result.tone, BnnPeriodTone.mixed);
    expect(result.toneBasis, contains('5° లోపు'));
  });

  test('Jupiter exact trine supports favourable tag', () {
    final r = _read(_chart([_p('Jupiter', 12), _p('Mars', 132)]));
    expect(r.tone, BnnPeriodTone.favourable);
    expect(r.inspection, contains('గురు'));
  });

  test('Saturn near trine indicates unfavourable tag', () {
    final r = _read(_chart([_p('Jupiter', 12), _p('Mars', 108),
      _p('Saturn', 228)]));
    expect(r.tone, BnnPeriodTone.unfavourable);
    expect(r.result, contains('శని'));
  });

  test('Both near supportive and adverse evidence is mixed', () {
    final r = _read(_chart([_p('Jupiter', 12), _p('Mars', 132),
      _p('Saturn', 252)]));
    expect(r.tone, BnnPeriodTone.mixed);
    expect(r.inspection, contains('శుభ సంబంధాలు'));
    expect(r.inspection, contains('పాప సంబంధాలు'));
  });

  test('Distant trinal planets do not produce a spurious tag', () {
    final r = _read(_chart([_p('Jupiter', 12), _p('Mars', 139)]));
    expect(r.tone, BnnPeriodTone.mixed);
  });

  test('Only explicitly supplied matched source THEN changes verdict', () {
    final natal = _chart([_p('Jupiter', 12), _p('Mars', 108)]);
    expect(_read(natal).tone, BnnPeriodTone.mixed);
    expect(_read(natal, sources: [_source('ఉద్యోగంలో లాభం')]).tone,
        BnnPeriodTone.favourable);
    expect(_read(natal, sources: [_source('ఉద్యోగంలో నష్టం')]).tone,
        BnnPeriodTone.unfavourable);
    expect(_read(natal, sources: [
      _source('ఉద్యోగంలో లాభం, కొన్నిసార్లు నష్టం')]).tone,
      BnnPeriodTone.mixed);
  });

  test('Symbolic age rounds keep natal tone, while annual topics vary', () {
    final natal = _chart([_p('Jupiter', 12), _p('Mars', 132)]);
    final j = natal.planets[0];
    final m = natal.planets[1];
    final windows = BnnRelativeTimingService.annualJupiterWindows(
        house: 5, birthYear: 1981);
    final results = windows.map((w) =>
      BnnRelativeTimingService.inspectPeriod(chart: natal,
          jupiter: j, target: m, window: w)).toList();
    expect(results.map((x) => x.tone).toSet().length, 1);
    expect(results.map((x) => x.headline).toSet().length, 7);
    expect(results.last.rule, contains('7వ చక్రానికి'));
  });
}
