import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_relative_timing_service.dart';

void main() {
  const jupiter = PlanetPosition(name: 'Jupiter', shortName: 'Ju',
      longitude: 193.04, latitude: 0, speed: 0.1);
  const mars = PlanetPosition(name: 'Mars', shortName: 'Ma',
      longitude: 78.63, latitude: 0, speed: 0.6);
  final natal = AstroChartResult(julianDay: 0, ayanamsaDegrees: 24,
      ascendantLongitude: 45,
      planets: [jupiter, mars], engineVersion: 'test');

  test('Guru ninth-house Mars: all seven 12-year activations', () {
    expect(BnnRelativeTimingService.relativeHouse(
        jupiter.signIndex, mars.signIndex), 9);
    final windows = BnnRelativeTimingService.annualJupiterWindows(
        house: 9, birthYear: 1994);
    expect(windows.map((w) => w.ordinalLifeYear).toList(),
        [9, 21, 33, 45, 57, 69, 81]);
    expect(windows.map((w) => w.calendarStartYear).toList(),
        [2002, 2014, 2026, 2038, 2050, 2062, 2074]);
    expect(BnnRelativeTimingService.birthdayRange(
        DateTime(1994, 2, 14), windows[2]),
        '14-02-2026 → 14-02-2027');
  });

  test('Every period shows a different subject-specific result, not only age', () {
    final windows = BnnRelativeTimingService.annualJupiterWindows(
        house: 9, birthYear: 1994);
    final readings = windows.map((w) =>
        BnnRelativeTimingService.inspectPeriod(
            chart: natal, jupiter: jupiter, target: mars, window: w)).toList();
    expect(readings.map((r) => r.headline).toSet().length, 7);
    expect(readings[0].result, contains('విద్య'));
    expect(readings[1].result, contains('వృత్తి'));
    expect(readings[2].result, contains('ప్రయాణాలు'));
    expect(readings[3].result, contains('ఇల్లు'));
    expect(readings[4].result, contains('సంతాన'));
    expect(readings[5].result, contains('ఆస్తి'));
    expect(readings[6].rule, contains('7వ చక్రానికి'));
    expect(readings[2].inspection, contains('గురు నుంచి 9 వ భావం'));
  });

  test('Only explicitly passed natal-IF sources appear as source results', () {
    final window = BnnRelativeTimingService.annualJupiterWindows(
        house: 9, birthYear: 1994).first;
    const rule = BnnMasterRule(id: 'T-001', source: 'test',
        sourcePage: 1, topic: 'test', condition: 'test',
        result: 'పరీక్ష కోసం మూల ఫలితం', inspection: '',
        remedy: '', status: 'test');
    final without = BnnRelativeTimingService.inspectPeriod(
        chart: natal, jupiter: jupiter, target: mars, window: window);
    final withSource = BnnRelativeTimingService.inspectPeriod(
        chart: natal, jupiter: jupiter, target: mars,
        window: window, passingSource: [rule]);
    expect(without.result, isNot(contains('పరీక్ష కోసం మూల ఫలితం')));
    expect(withSource.result, contains('పరీక్ష కోసం మూల ఫలితం (T-001)'));
  });

  test('Birthday calendar ranges clamp Feb 29 to Feb 28 when necessary', () {
    final w = BnnRelativeTimingService.annualJupiterWindows(
        house: 1, birthYear: 2000).first;
    expect(BnnRelativeTimingService.birthdayRange(
        DateTime(2000, 2, 29), w),
        '29-02-2000 → 28-02-2001');
  });
}
