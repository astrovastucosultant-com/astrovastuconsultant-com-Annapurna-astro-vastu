import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/kp_service.dart';

void main() {
  group('KP Horary 1–249 numbering', () {
    test('covers all 249 contiguous sub/sign segments without gaps', () {
      final entries = KpService.horaryTable;
      expect(entries, hasLength(249));
      expect(entries.first.startLongitude, 0.0);
      expect(entries.last.endLongitude, 360.0);
      for (var i = 0; i < entries.length; i++) {
        final current = entries[i];
        expect(current.number, i + 1);
        expect(current.startLongitude, lessThan(current.endLongitude));
        expect(current.signIndex, inInclusiveRange(0, 11));
        expect(current.signIndex, (current.startLongitude / 30).floor());
        if (i > 0) {
          expect(current.startLongitude,
              closeTo(entries[i - 1].endLongitude, 0.00000001));
        }
      }
    });

    test('first, second, boundary-split and last numbers', () {
      final first = KpService.horaryNumber(1);
      expect(first.signLord, 'Mars');
      expect(first.starLord, 'Ketu');
      expect(first.subLord, 'Ketu');
      expect(first.endLongitude, closeTo(2800 / 3600.0, 0.00000001));

      final second = KpService.horaryNumber(2);
      expect(second.subLord, 'Venus');
      expect(second.startLongitude, closeTo(2800 / 3600.0, 0.00000001));

      final taurusStart = KpService.horaryNumber(23);
      expect(taurusStart.startLongitude, 30.0);
      expect(taurusStart.signLord, 'Venus');
      expect(taurusStart.starLord, 'Sun');
      expect(taurusStart.subLord, 'Rahu');

      final cancerStart = KpService.horaryNumber(63);
      expect(cancerStart.startLongitude, 90.0);
      expect(cancerStart.subLord, 'Moon');

      final last = KpService.horaryNumber(249);
      expect(last.startLongitude,
          closeTo(357 + (53 * 60 + 20) / 3600.0, 0.00000001));
      expect(last.signIndex, 11);
      expect(last.starLord, 'Mercury');
      expect(last.subLord, 'Saturn');
    });

    test('invalid numbers throw instead of silently rounding', () {
      expect(() => KpService.horaryNumber(0), throwsRangeError);
      expect(() => KpService.horaryNumber(250), throwsRangeError);
    });
  });
}
