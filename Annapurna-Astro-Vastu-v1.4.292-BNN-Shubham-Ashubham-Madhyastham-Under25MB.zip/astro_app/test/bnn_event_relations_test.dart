import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_event_relations.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';

AstroChartResult _sampleChart({required double marsLongitude}) =>
    AstroChartResult(
      julianDay: 0,
      ayanamsaDegrees: 0,
      ascendantLongitude: 0,
      planets: [
        const PlanetPosition(name: 'Jupiter', shortName: 'Ju',
            longitude: 30, latitude: 0, speed: 0),
        PlanetPosition(name: 'Mars', shortName: 'Ma',
            longitude: marsLongitude, latitude: 0, speed: 0),
        const PlanetPosition(name: 'Moon', shortName: 'Mo',
            longitude: 180, latitude: 0, speed: 0),
      ],
      engineVersion: 'test',
    );

BnnMasterRule _rule(String status, String result) => BnnMasterRule(
  id: 'r1', source: 'BNN N', sourcePage: 1, topic: 'తల్లి',
  condition: 'గురుడు—కుజుడు', result: result,
  inspection: 'test', remedy: '', status: status,
);

void main() {
  test('All relations have a unique name and supported house reference', () {
    expect(BnnEventRelations.relations.length, greaterThanOrEqualTo(12));
    expect(BnnEventRelations.relations.map((r) => r.name).toSet().length,
        BnnEventRelations.relations.length);
    for (final group in BnnEventRelations.relations) {
      expect(group.relatedHouse, inInclusiveRange(1, 12));
    }
  });

  test('No timing event is called a verified prediction', () {
    expect(BnnEventRelations.studyWindows.length, greaterThanOrEqualTo(5));
    for (final item in BnnEventRelations.studyWindows) {
      expect(item.toAge, greaterThanOrEqualTo(item.fromAge));
      expect(item.sourceId, startsWith('BNN-BOOK-'));
      expect(item.sourceStatus, contains('సంఘటన నిర్ధారణ కాదు'));
    }
  });

  test('Specific property event requires Mars 4th from Jupiter', () {
    final item = BnnEventRelations.studyWindows
        .firstWhere((event) => event.sourceId == 'BNN-BOOK-C19');
    expect(BnnEventRelations.placementCondition(item,
        _sampleChart(marsLongitude: 120)), isTrue); // Taurus to Leo = 4
    expect(BnnEventRelations.placementCondition(item,
        _sampleChart(marsLongitude: 150)), isFalse);
  });

  test('Relatives must be named in THEN; native family outcomes excluded', () {
    const group = BnnEventRelations.relations;
    final kin = group.firstWhere((g) => g.name == 'బంధువులు / దాయాదులు');
    final mother = group.firstWhere((g) => g.name == 'తల్లి');
    final husband = group.firstWhere((g) => g.name == 'భర్త / జీవిత భాగస్వామి');
    final nativeFamily = _rule('FACTS_REQUIRED',
        'వ్యక్తి కుటుంబం నుండి దూరంగా ఉంటాడు.');
    expect(BnnEventRelations.sourceRulesFor(kin, [nativeFamily]), isEmpty);
    expect(BnnEventRelations.sourceRulesFor(mother, [nativeFamily]), isEmpty);
    final relativeMarriage = _rule('OCR_REVIEW', 'బంధువు వివాహం');
    expect(BnnEventRelations.sourceRulesFor(kin, [relativeMarriage]),
        hasLength(1));
    final mothersHusband = _rule('OCR_REVIEW',
        'తల్లి భర్తకు నమ్మకస్తురాలు');
    expect(BnnEventRelations.sourceRulesFor(husband, [mothersHusband]),
        isEmpty);
    expect(BnnEventRelations.sourceRulesFor(mother, [mothersHusband]),
        hasLength(1));
  });

  test('Relation candidates require source THEN and observed same sign', () {
    final group = BnnEventRelations.relations.firstWhere(
        (g) => g.name == 'తల్లి');
    final same = _sampleChart(marsLongitude: 30);
    final different = _sampleChart(marsLongitude: 60);
    final motherResult = _rule('FACTS_REQUIRED',
        'జాతకుడు, అతని తల్లి బాగుంటారు.');
    expect(BnnEventRelations.tentativeRelationsFor(
        group, [motherResult], same), hasLength(1));
    expect(BnnEventRelations.tentativeRelationsFor(
        group, [motherResult], different), isEmpty);
    expect(BnnEventRelations.tentativeRelationsFor(
        group, [_rule('FACTS_REQUIRED', 'కుటుంబం నుంచి దూరం')], same), isEmpty);
  });

  test('Unverified source rules never get a green or pink decision', () {
    final chart = _sampleChart(marsLongitude: 30);
    expect(BnnEventRelations.polarity(
        _rule('OCR_REVIEW', 'కష్టాలు'), chart), 0);
    expect(BnnEventRelations.polarity(
        _rule('REVIEW', 'లాభాలు'), chart), 0);
  });
}
