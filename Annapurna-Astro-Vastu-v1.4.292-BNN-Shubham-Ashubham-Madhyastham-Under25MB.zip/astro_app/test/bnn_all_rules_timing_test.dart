import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_all_rules_match_service.dart';
import 'package:astro_app/astrology/bnn_relative_timing_service.dart';

BnnMasterRule source(String id, String condition, String result) =>
    BnnMasterRule(id: id, source: 'BNN N', sourcePage: 52,
      topic: 'Test', condition: condition, result: result,
      inspection: '', remedy: '', status: 'FACTS_REQUIRED');

AstroChartResult natal({double jupiter = 34, double venus = 130,
    double ketu = 252, double lagna = 5}) => AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: lagna,
      planets: [
        PlanetPosition(name: 'Jupiter', shortName: 'Ju',
            longitude: jupiter, latitude: 0, speed: .1),
        PlanetPosition(name: 'Venus', shortName: 'Ve',
            longitude: venus, latitude: 0, speed: 1),
        PlanetPosition(name: 'Ketu', shortName: 'Ke',
            longitude: ketu, latitude: 0, speed: -.1),
      ], engineVersion: 'test');

void main() {
  test('Jupiter fourth Venus gives ages 3-4, 15-16, 27-28', () {
    expect(BnnRelativeTimingService.relativeHouse(1, 4), 4);
    final windows = BnnRelativeTimingService.annualJupiterWindows(
        house: 4, birthYear: 2000, maximumAge: 41);
    expect(windows.map((e) => e.ageStart).toList(), [3, 15, 27, 39]);
    expect(windows.map((e) => e.ageEnd).toList(), [4, 16, 28, 40]);
    expect(windows.first.calendarStartYear, 2003);
    expect(windows.first.calendarEndYear, 2004);
  });

  test('C64: Jupiter 4th Venus is not enough without D1 7th lord', () {
    final rule = source('BNN-BOOK-C64',
        'గురుకి 4లో శుక్ర 7వ అధిపతి', 'మూల THEN');
    expect(BnnAllRulesMatchService.check(rule,
        natal(jupiter: 34, venus: 130, lagna: 5)).matched, isTrue);
    // D1 Taurus asc -> 7th Scorpio, Mars is lord: extra IF is FALSE.
    expect(BnnAllRulesMatchService.check(rule,
        natal(jupiter: 34, venus: 130, lagna: 35)).matched, isFalse);
    // Venus in fifth from Jupiter: both conditions cannot be true.
    expect(BnnAllRulesMatchService.check(rule,
        natal(jupiter: 34, venus: 160, lagna: 5)).matched, isFalse);
  });

  test('BNN N dash chain tests trinal LOCAL degrees in source order', () {
    final chain = source('BNNN-P051-R001',
        'గురుడు—శుక్రుడు', 'మూల THEN');
    // Taurus 4°, Virgo 10° belong to the Earth trine and ascend.
    expect(BnnAllRulesMatchService.check(chain,
        natal(jupiter: 34, venus: 160)).matched, isTrue);
    // Same Earth trine but degree order is reversed.
    expect(BnnAllRulesMatchService.check(chain,
        natal(jupiter: 54, venus: 160)).matched, isFalse);
    // Not the same BNN trine.
    expect(BnnAllRulesMatchService.check(chain,
        natal(jupiter: 34, venus: 130)).matched, isFalse);
  });

  test('Source text is retained and no fabricated THEN', () {
    final rule = source('BNNN-P051-R001',
        'గురుడు—శుక్రుడు', 'అసలు ఫలిత వాక్యం');
    final result = BnnAllRulesMatchService.check(rule, natal());
    expect(rule.condition, 'గురుడు—శుక్రుడు');
    expect(rule.result, 'అసలు ఫలిత వాక్యం');
    expect(result.matchedThen, isNull);
  });

  test('The special Venus 4th rule requires full condition; match sources by pair', () {
    final r = source('BNN-BOOK-C64',
        'గురుకి 4లో శుక్ర 7వ అధిపతి', 'భార్య వివాహానికి ముందే తల్లికి తెలిసినది');
    final list = BnnRelativeTimingService.sourceCandidates(
        [r], 4, 'శుక్రుడు');
    expect(list.length, 1);
    expect(BnnRelativeTimingService.sourceCandidates(
        [r], 5, 'శుక్రుడు').length, 0);
  });

  test('F04 two alternate houses correctly use OR', () {
    final f04 = source('BNN-BOOK-F04',
        'బుధకి 12 లేదా 2లో కుజ', 'విద్య అంతరాయం');
    AstroChartResult placement(double mars) => AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 12,
      planets: [
        const PlanetPosition(name: 'Mercury', shortName: 'Me',
            longitude: 45, latitude: 0, speed: 1),
        PlanetPosition(name: 'Mars', shortName: 'Ma',
            longitude: mars, latitude: 0, speed: .1),
      ], engineVersion: 'test');
    expect(BnnAllRulesMatchService.check(f04, placement(18)).matched, isTrue);
    expect(BnnAllRulesMatchService.check(f04, placement(78)).matched, isTrue);
    expect(BnnAllRulesMatchService.check(f04, placement(98)).matched, isFalse);
  });

  test('J26 two distinct placements both mandatory', () {
    final j26 = source('BNN-BOOK-J26',
        'చంద్ర గురుకి 2 + కుజ గురుకి 4', 'తల్లి నుంచి స్థిరాస్తి');
    AstroChartResult placement(double mars) => AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 12,
      planets: [
        const PlanetPosition(name: 'Jupiter', shortName: 'Ju',
            longitude: 31, latitude: 0, speed: .1),
        const PlanetPosition(name: 'Moon', shortName: 'Mo',
            longitude: 65, latitude: 0, speed: 12),
        PlanetPosition(name: 'Mars', shortName: 'Ma',
            longitude: mars, latitude: 0, speed: .1),
      ], engineVersion: 'test');
    expect(BnnAllRulesMatchService.check(j26, placement(125)).matched, isTrue);
    expect(BnnAllRulesMatchService.check(j26, placement(95)).matched, isFalse);
  });

}
