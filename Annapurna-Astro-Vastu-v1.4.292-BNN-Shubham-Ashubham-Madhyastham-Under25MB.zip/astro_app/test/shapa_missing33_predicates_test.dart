import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/shapa_match_engine.dart';
import 'package:astro_app/astrology/shapa_rule_service.dart';

PlanetPosition p(String name,double longitude)=>PlanetPosition(
  name:name,shortName:name,longitude:longitude,latitude:0,speed:1);
AstroChartResult chart(double asc,List<PlanetPosition> positions)=>AstroChartResult(
  julianDay:2451545,ayanamsaDegrees:24,ascendantLongitude:asc,
  planets:positions,engineVersion:'BPHS83-predicate-test');
void main() {
  final full=<PlanetPosition>[
    p('Sun',185),p('Moon',10),p('Mars',95),p('Mercury',35),
    p('Jupiter',275),p('Venus',65),p('Saturn',155),
    p('Rahu',125),p('Ketu',305),
  ];
  test('All 73 PDF yogas have an explicit AND/OR predicate tree', () {
    final set=ShapaMatchEngine.autoClauses.keys.toSet();
    final pdf=ShapaRuleService.rules.where((e)=>!e.legacy)
      .map((e)=>e.id).toSet();
    expect(set, pdf);
    expect(set.length,73);
    expect(ShapaMatchEngine.autoClauses.values.every((x)=>
      x.isNotEmpty&&x.every((branch)=>branch.isNotEmpty)),true);
  });
  test('Verse 83.102: debilitated planet aspects 5th with other clauses', () {
    // Sagittarius rising: Mars (Lord 5) in Cancer (debilitation),
    // Jupiter in Capricorn (debilitation), Sun in Libra (debilitation).
    // Sun sees Aries (the 5th) by 7th aspect.
    final result=ShapaMatchEngine.evaluate(chart(240,full));
    final v=result.singleWhere((a)=>a.rule.id=='BPHS83-ప్రేత-06');
    expect(v.matched,true);
    expect(v.evidence.length,3);
    expect(v.evidence.last.contains('5వ భావంపై నీచగ్రహ దృష్టి'),true);
  });
  test('Weak planet and Mandi do not receive invented values', () {
    final result=ShapaMatchEngine.evaluate(chart(0,full));
    final list=result.where((e)=>!e.rule.legacy).toList();
    expect(list.length,73);
    expect(result.length,77);
  });
  test('Optional confirmed Shadbala virupas and Mandi can be supplied', () {
    final result=ShapaMatchEngine.evaluate(chart(0,full),
      shadbalaVirupas:{'Sun':400.0,'Moon':250.0,'Mars':100.0},
      mandiLongitude:40.0);
    expect(result.length,77);
  });
}
