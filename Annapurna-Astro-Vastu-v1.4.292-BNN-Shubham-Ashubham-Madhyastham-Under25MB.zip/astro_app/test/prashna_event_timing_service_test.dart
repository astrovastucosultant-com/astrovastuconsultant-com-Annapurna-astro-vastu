import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/dasha_service.dart';
import 'package:astro_app/astrology/kp_event_judgement_service.dart';
import 'package:astro_app/astrology/kp_service.dart';
import 'package:astro_app/astrology/jamakola_special_service.dart';
import 'package:astro_app/astrology/prashna_event_timing_service.dart';
import 'package:astro_app/astrology/tajik_prashna_service.dart';
import 'package:astro_app/astrology/astro_models.dart';

void main() {
  final question=DateTime.utc(2026,10,25,13,1);
  final event=KpEventRule(id:'TEST-PROPERTY',name:'Construct house',
    category:'ఆస్తులు, వాహనాలు',mainHouse:4,mainHouseSource:'4',
    supporting:[11],supportingSource:'11',page:1,printedPage:1,
    highStakes:false,requiresReview:false);

  KpStellarPosition body(String name,double longitude)=>KpStellarPosition(
    body:name,signIndex:(longitude~/30)%12,signLord:'Jupiter',
    nakshatraIndex:(longitude/(360/27)).floor(),starLord:'Jupiter',
    subLord:'Jupiter',longitude:longitude);

  final bodies=<KpStellarPosition>[
    for(var i=0;i<DashaService.lordOrder.length;i++)
      body(DashaService.lordOrder[i],(i*37.0)%360),
  ];
  final cusps=<KpStellarPosition>[
    for(var i=0;i<12;i++)body('Cusp ${i+1}',i*30.0),
  ];
  final kpChart=KpChartDetails(planets:bodies,cusps:cusps,
    ayanamsaDegrees:24.0);
  final kp=KpHoraryEventResult(event:event,number:0,
    questionUtc:question,latitude:16.59,longitude:79.73,
    chart:kpChart,relevantSubLord:'Jupiter',evidences:const {},
    cslHouses:const [4,11],matchedHouses:const [4,11],
    mainConnected:true,supportConnected:true,decision:'preliminary',
    explanation:'test',provisionalPositive:true,sourceReview:false);

  test('KP candidate DBAs are real ordered nonempty intervals', () {
    final periods=PrashnaEventTimingService.kpDashaWindows(
      observation:kp,horizonStartUtc:question,horizonDays:120,limit:5);
    expect(periods,isNotEmpty);
    expect(periods.length,lessThanOrEqualTo(5));
    for(final c in periods){
      expect(c.startUtc.isBefore(c.endUtc),isTrue);
      expect(c.startUtc.isBefore(question),isFalse);
      expect(c.endUtc.isAfter(question.add(const Duration(days:120))),isFalse);
      expect(c.limitation,contains('సంఘటన తేదీగా'));
    }
    expect(PrashnaEventTimingService.kpCurrentDasha(kp),contains('/'));
  });

  test('empty unsupported house rule produces no KP candidate', () {
    final missing=KpEventRule(id:'EMPTY',name:'Unmapped',category:'other',
      mainHouse:null,mainHouseSource:'',supporting:[],supportingSource:'',
      page:1,printedPage:1,highStakes:false,requiresReview:true);
    final observation=KpHoraryEventResult(event:missing,number:0,
      questionUtc:question,latitude:16.59,longitude:79.73,
      chart:kpChart,relevantSubLord:'',evidences:const {},cslHouses:const [],
      matchedHouses:const [],mainConnected:false,supportConnected:false,
      decision:'unknown',explanation:'test',provisionalPositive:false,
      sourceReview:true);
    expect(PrashnaEventTimingService.kpDashaWindows(
      observation:observation,horizonStartUtc:question),isEmpty);
  });

  test('Jamakola next contact converts minutes to UTC without timezone shift', () {
    final jama=JamakolaSpecialResult(udhayam:30,arudam:120,
      jamaGrahas:const [JamaRingPosition('Moon',40)],jamam:4,isNight:false,
      sunriseLocal:DateTime.utc(2026,10,25,6),
      sunsetLocal:DateTime.utc(2026,10,25,18),
      sunriseSunLongitude:190,
      jamaContacts:const [JamaUdayaContact('Moon',2.5),
        JamaUdayaContact('Mars',-5)]);
    final results=PrashnaEventTimingService.jamaContactWindows(
      jama:jama,questionUtc:question);
    expect(results.length,1);
    expect(results.single.startUtc,question.add(const Duration(seconds:150)));
    expect(results.single.endUtc,results.single.startUtc);
    expect(results.single.limitation,contains('సంఘటన'));
  });

  test('separating Tajik aspect does not invent event time', () {
    final ob=TajikPrashnaObservation(lagnaLord:'Moon',questionLord:'Jupiter',
      questionHouse:4,aspectName:'త్రికోణ 120°',distanceDegrees:3,
      orbDegrees:9,status:'separating',explanation:'separating');
    final chart=AstroChartResult(julianDay:2450000.5,
      ayanamsaDegrees:24,ascendantLongitude:0,engineVersion:'test',
      planets:const [PlanetPosition(name:'Moon',shortName:'Mo',
        longitude:30,latitude:0,speed:13),
        PlanetPosition(name:'Jupiter',shortName:'Ju',
        longitude:147,latitude:0,speed:0.1)]);
    expect(PrashnaEventTimingService.tajikAspectWindows(
      observation:ob,questionChart:chart,questionUtc:question),isEmpty);
  });
}
