import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_exact_if_engine.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_outcome_router.dart';

BnnMasterRule _rule(String id, String condition, String result) =>
    BnnMasterRule(
      id: id, source: 'BNN', sourcePage: 3, topic: 'ఇతర గ్రంథ విభాగం',
      condition: condition, result: result, inspection: '', remedy: '',
      status: 'OCR_REVIEW',
    );

BnnMatchedOutcome _true(String id, String condition, String result,
        {String? branch}) =>
    (_rule(id, condition, result),
      BnnExactIfResult(true, true, 'గ్రహ IF TRUE', matchedThen: branch));

void main() {
  test('A matched brother outcome routes to bhava 3 even if source category differs', () {
    final hits = [_true('C09', 'గురుకి 12లో కుజుడు', 'ఒక అన్న')];
    expect(BnnOutcomeRouter.forHouse(3, hits).single.$1.id, 'C09');
    expect(BnnOutcomeRouter.forHouse(12, hits), isEmpty);
  });

  test('E10 Virgo branch routes to career, not all source THEN branches', () {
    final hits = [_true('E10', 'శని మిథున/కన్య',
        'వ్యాపారవేత్త; మిథునం + చంద్ర కర్కాటకం - మద్యం',
        branch: 'వ్యాపారవేత్త')];
    expect(BnnOutcomeRouter.forHouse(10, hits).length, 1);
    expect(BnnOutcomeRouter.forHouse(6, hits), isEmpty);
  });

  test('Spouse personal trait must not become native first-house trait', () {
    final hits = [_true('A', 'శుక్ర+శని', 'భార్య ధైర్యవంతురాలు')];
    expect(BnnOutcomeRouter.forHouse(1, hits), isEmpty);
    expect(BnnOutcomeRouter.forHouse(7, hits).length, 1);
  });

  test('Unmatched source sentences never appear as personal outcomes', () {
    final hit = (_rule('A', 'గురుకి 12లో కుజుడు', 'ఒక అన్న'),
        const BnnExactIfResult(true, false, 'జన్మ IF FALSE'));
    expect(BnnOutcomeRouter.forHouse(3, [hit]), isEmpty);
  });

  test('Outcomes without supported 144-topic mapping remain globally visible', () {
    final hits = [_true('X', 'కుజ+శని', 'అనిర్దిష్ట విషయం 123')];
    expect(BnnOutcomeRouter.withoutHouse(hits).length, 1);
  });
}
