import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_navigation_spec.dart';

void main() {
  test('BNN six main tabs are ordered results first, source rules last', () {
    expect(BnnNavigationSpec.labels, hasLength(6));
    expect(BnnNavigationSpec.labels.first, '1. ఫలితాలు');
    expect(BnnNavigationSpec.labels[1], '2. 12 భావాలు');
    expect(BnnNavigationSpec.labels[2], '3. గ్రహసంబంధాలు');
    expect(BnnNavigationSpec.labels[3], '4. సంఘటనల సమయం');
    expect(BnnNavigationSpec.labels[4], '5. బంధుత్వాలు');
    expect(BnnNavigationSpec.labels.last, '6. మూల నియమాలు');
    expect(BnnNavigationSpec.labels.toSet(), hasLength(6));
  });
}
