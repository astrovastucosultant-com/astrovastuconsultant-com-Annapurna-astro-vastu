import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_bhava_topics.dart';

void main() {
  test('All 12 BNN bhavas contain 12 distinct navigation labels', () {
    expect(BnnBhavaTopicService.byHouse.length, 12);
    for (var house = 1; house <= 12; house++) {
      final topics = BnnBhavaTopicService.forHouse(house);
      expect(topics.length, 12);
      expect(topics.map((x) => x.name).toSet().length, 12);
      expect(topics.every((x) => x.house == house), isTrue);
    }
  });

  test('Invalid houses have no topic labels', () {
    expect(BnnBhavaTopicService.forHouse(0), isEmpty);
    expect(BnnBhavaTopicService.forHouse(13), isEmpty);
  });
}
