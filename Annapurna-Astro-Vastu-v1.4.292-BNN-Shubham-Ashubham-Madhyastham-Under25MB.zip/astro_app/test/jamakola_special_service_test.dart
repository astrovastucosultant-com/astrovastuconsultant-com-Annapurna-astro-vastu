import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jamakola_special_service.dart';

void main() {
  test('2018 Kavippu counter-motion: Sagittarius U, Leo A, Aries V => Leo K', () {
    final k=JamakolaSpecialService.kavippuAnticlockwiseSign(
      udhayamSign:8,arudamSign:4,veedhiSign:0);
    expect(k,4);
    expect(JamakolaSpecialService.chatraSign(
      sunLongitude:100,udhayam:264+30/60,arudam:120),4);
  });

  test('Arudam one sign forwards => Kavippu one sign backwards', () {
    final k0=JamakolaSpecialService.kavippuAnticlockwiseSign(
      udhayamSign:8,arudamSign:4,veedhiSign:0);
    final k1=JamakolaSpecialService.kavippuAnticlockwiseSign(
      udhayamSign:8,arudamSign:5,veedhiSign:0);
    expect(k0,4); // Simha
    expect(k1,3); // Karkataka
    expect((k0-k1+12)%12,1);
  });

  test('Counter-motion rasi wraps around all signs, rejects out-of-range', () {
    for(var u=0;u<12;u++) {
      for(var a=0;a<12;a++) {
        for(var v=0;v<3;v++) {
          final result=JamakolaSpecialService.kavippuAnticlockwiseSign(
            udhayamSign:u,arudamSign:a,veedhiSign:v);
          expect(result,(u+v-a+24)%12);
        }
      }
    }
    expect(()=>JamakolaSpecialService.kavippuAnticlockwiseSign(
      udhayamSign:12,arudamSign:4,veedhiSign:0),throwsArgumentError);
  });

  test('2018 Aadi 21 source example: real Tamil month 31 days, sunrise 05:49, sunset 18:37', () {
    final dayMinutes = (18 * 60 + 37) - (5 * 60 + 49);
    expect(dayMinutes, 768);
    final ud=JamakolaSpecialService.tamilSolarMonthDayUdhayam(
      minutesSinceSunrise:(11 * 60 + 20) - (5 * 60 + 49),
      daylightMinutes:dayMinutes.toDouble(),solarSunSignIndex:3,
      tamilMonthDay:21,tamilMonthDays:31);
    expect(ud,closeTo(264.51108870967744,1e-8)); // Dhanu 24°30′40″ approx.
    final ar=JamakolaSpecialService.arudamFromClock(
      DateTime.utc(2018,8,6,11,20));
    expect(ar,120);
    final kav=JamakolaSpecialService.kavippuAbsoluteSphutaCandidate(
      sunLongitude:110,udhayam:ud,arudam:ar); // Sun: Cancer -> Aries Veedhi.
    expect(kav,closeTo(144.51108870967744,1e-8)); // Leo 24°30′40″.
  });

  test('user Kavippu Sphuta formula sample gives Virgo 12°20′', () {
    final kav=JamakolaSpecialService.kavippuAbsoluteSphutaCandidate(
      sunLongitude:195,udhayam:142+40/60,arudam:10+20/60);
    expect(kav,closeTo(162+20/60,1e-8));
  });

  test('Kavippu absolute method is distinct from mirrored-degree convention', () {
    final absolute=JamakolaSpecialService.kavippuAbsoluteSphutaCandidate(
      sunLongitude:195,udhayam:142+40/60,arudam:10+20/60);
    final mirrored=JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:142+40/60,arudam:10+20/60,anchorSignIndex:1);
    expect(absolute,closeTo(162+20/60,1e-8));
    expect(mirrored,closeTo(169+40/60,1e-8));
  });

  test('Tamil solar day ordinal subtracts one and rejects invalid inputs', () {
    final first=JamakolaSpecialService.tamilSolarMonthDayUdhayam(
      minutesSinceSunrise:0,daylightMinutes:768,
      solarSunSignIndex:3,tamilMonthDay:1,tamilMonthDays:31);
    expect(first,90);
    expect(()=>JamakolaSpecialService.tamilSolarMonthDayUdhayam(
      minutesSinceSunrise:800,daylightMinutes:768,
      solarSunSignIndex:3,tamilMonthDay:21,tamilMonthDays:31),throwsArgumentError);
  });

  test('clock Arudam matches printed reference 08:28:10 => 169 degrees', () {
    final a=JamakolaSpecialService.arudamFromClock(DateTime(2026,10,23,8,28,10));
    expect(a,closeTo(169.0,0.000001));
  });

  test('Jama 23 October 2026 08:28:10 Friday: Friday Venus at zero 06:00', () {
    final r=JamakolaSpecialService.jamaFromLocalClock(DateTime(2026,10,23,8,28,10));
    expect(r.length,8);
    expect(r.first.name,'Sun');
    expect(r.first.longitude,closeTo(105+55/60,0.00001));
    expect(r[4].name,'Venus');
    expect(r[4].longitude,closeTo(285+55/60,0.00001));
    for(var i=1;i<8;i++) {
      expect(JamakolaSpecialService.norm(r[i-1].longitude-r[i].longitude),
          closeTo(45.0,0.0000001));
    }
  });

  test('Before 06:00 previous weekday lord governs Jamakkol ring', () {
    final r=JamakolaSpecialService.jamaFromLocalClock(DateTime(2026,9,15,5,58,24));
    expect(r[6].name,'Moon');
    expect(r[6].longitude,closeTo(0.8,0.00001));
    expect(r[0].longitude,closeTo(270.8,0.00001));
  });


  test('Divya Chakshu screenshot 24 Oct 2026 17:50: eight Jama grahas', () {
    final r=JamakolaSpecialService.jamaFromLocalClock(DateTime(2026,10,24,17,50));
    const expected=<String,double>{
      'Sun':230,'Mars':185,'Jupiter':140,'Mercury':95,
      'Venus':50,'Saturn':5,'Moon':320,'Snake':275,
    };
    for (final position in r) {
      expect(position.longitude,closeTo(expected[position.name]!,0.000001));
    }
    expect(JamakolaSpecialService.arudamFromClock(DateTime(2026,10,24,17,50)),
      closeTo(300.0,0.000001));
  });

  test('Veedhi anchor Mesha: public fixture Meena Arudam, Simha Udhayam => Kanni Kavippu', () {
    final k=JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:147+17/60, arudam:350+24/60, anchorSignIndex:0);
    expect(k,closeTo(159+36/60,0.00001));
  });

  test('Veedhi anchor Mesha: public fixture Makara Arudam, Thula Udhayam => Makara Kavippu', () {
    final k=JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:195+12/60, arudam:273+54/60, anchorSignIndex:0);
    expect(k,closeTo(296+6/60,0.00001));
  });

  test('Veedhi anchor Mesha: public fixture Rishaba Arudam, Mithuna Udhayam => Rishaba Kavippu', () {
    final k=JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:84+12/60, arudam:40+54/60, anchorSignIndex:0);
    expect(k,closeTo(49+6/60,0.00001));
  });

  test('bad Veedhi anchor cannot silently return a Kavippu result', () {
    expect(() => JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:200,arudam:100,anchorSignIndex:12),throwsArgumentError);
  });

  test('Wednesday 10:30 2026-09-16 source fixture at 0 Sun', () {
    final r=JamakolaSpecialService.jamaFromLocalClock(DateTime(2026,9,16,10,30));
    expect(r[0].longitude,closeTo(0.0,0.0000001));
    expect(r[3].longitude,closeTo(225.0,0.0000001));
  });


  test('2026-10-25 13:55 Guntur civil clock matches 8 Jama rasi and degrees', () {
    final ring=JamakolaSpecialService.jamaFromLocalClock(
      DateTime.utc(2026,10,25,13,55));
    const expected=[122.5,77.5,32.5,347.5,302.5,257.5,212.5,167.5];
    for(var i=0;i<8;i++) {
      expect(ring[i].longitude,closeTo(expected[i],1e-9));
      expect(ring[i].signIndex,(expected[i]/30).floor());
    }
    expect(JamakolaSpecialService.arudamFromClock(
      DateTime.utc(2026,10,25,13,55)),330);
  });

  test('civil question time is independent of DateTime timezone tag', () {
    final utc=JamakolaSpecialService.jamaFromLocalClock(
      DateTime.utc(2026,10,25,13,55));
    final device=JamakolaSpecialService.jamaFromLocalClock(
      DateTime(2026,10,25,13,55));
    for(var i=0;i<8;i++) {
      expect(utc[i].longitude,device[i].longitude);
    }
  });

  test('boundary near 06:00 keeps previous day and changes at 06:00', () {
    final previous=JamakolaSpecialService.jamaFromLocalClock(
      DateTime.utc(2026,10,25,5,59,59));
    final today=JamakolaSpecialService.jamaFromLocalClock(
      DateTime.utc(2026,10,25,6));
    expect(previous[0].longitude,closeTo(225.0-719.9916666667+720.0,1e-6));
    expect(today[0].longitude,0);
  });

  test('Jama-Udayam relative motion: verified contact direction and minutes', () {
    final contacts=JamakolaSpecialService.contactsWithinSegment(
      udhayam:100,
      jamaGrahas:const [
        JamaRingPosition('Sun',99),   // past one minute
        JamaRingPosition('Mars',110), // future ten minutes
        JamaRingPosition('Jupiter',150), // too far for 30 minute horizon
      ],
      segmentMinutes:720,
      elapsedMinutes:360,
    );
    expect(contacts.length,2);
    expect(contacts[0].planet,'Sun');
    expect(contacts[0].minutesFromJudgement,closeTo(-1,0.00001));
    expect(contacts[1].planet,'Mars');
    expect(contacts[1].minutesFromJudgement,closeTo(10,0.00001));
  });

  test('Contacts never assume movement across sunrise/sunset seam', () {
    final contacts=JamakolaSpecialService.contactsWithinSegment(
      udhayam:100,
      jamaGrahas:const [JamaRingPosition('Sun',99),
                        JamaRingPosition('Mars',110)],
      segmentMinutes:720,
      elapsedMinutes:0.25,
    );
    expect(contacts.length,1);
    expect(contacts.single.planet,'Mars');
    expect(contacts.single.minutesFromJudgement,closeTo(10,0.00001));
  });

  test('Exact coincidence yields one contact at judgement time', () {
    final contacts=JamakolaSpecialService.contactsWithinSegment(
      udhayam:200, jamaGrahas:const [JamaRingPosition('Saturn',200)],
      segmentMinutes:600,elapsedMinutes:100,
    );
    expect(contacts.length,1);
    expect(contacts.single.minutesFromJudgement,0);
  });


  test('Chatra Sun Veedhi: all 12 sidereal signs map to traditional three paths', () {
    const expected=[1,0,0,0,0,1,1,2,2,2,2,1];
    for(var i=0;i<12;i++) {
      expect(JamakolaSpecialService.chatraVeedhiSign(i*30.0+15),expected[i]);
    }
  });

  test('Divya Chakshu 24 Oct 2026 17:50: Libra Udhayam, Aquarius Arudam -> Capricorn Chatra', () {
    final sign=JamakolaSpecialService.chatraSign(
      sunLongitude:186+52/60, // sidereal Sun in Libra, Taurus Veedhi
      udhayam:189+51/60,       // 06s (Libra)
      arudam:300,              // 10s (Aquarius)
    );
    expect(sign,9);           // 09s: Capricorn, matches screenshot
  });

  test('Chatra published example: Cancer Udhayam/Arudam, Pisces Sun -> Taurus Veedhi', () {
    final sign=JamakolaSpecialService.chatraSign(
      sunLongitude:350,udhayam:102,arudam:106);
    expect(sign,1);           // source transfer sign is Taurus
  });

  test('Chatra rejects missing computational evidence', () {
    expect(()=>JamakolaSpecialService.chatraSign(
      sunLongitude:double.nan,udhayam:100,arudam:200),throwsArgumentError);
  });
}
