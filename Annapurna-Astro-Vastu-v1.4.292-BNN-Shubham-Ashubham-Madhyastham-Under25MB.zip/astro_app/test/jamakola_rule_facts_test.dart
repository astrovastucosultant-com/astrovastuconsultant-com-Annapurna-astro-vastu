import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jamakola_rule_engine.dart';

void main() {
  group('Jamakola rule inputs', () {
    test('Pink KAV house is counted inclusively from Jamakola Udayam', () {
      expect(JamakolaRuleEngine.houseFromSigns(7, 1), 7);
      expect(JamakolaRuleEngine.houseFromSigns(0, 0), 1);
      expect(JamakolaRuleEngine.houseFromSigns(11, 0), 2);
    });

    test('KAV fact matches only equal traditional condition values', () {
      const rule = JamakolaRule(
        'JA-TEST-KAV-7', 'career_business', 'Test', 'source', '1',
        {'kavipu_house_from_udhayam': 7},
      );
      expect(JamakolaRuleEngine.matches(rule, {'kavipu_house_from_udhayam': 7}), isTrue);
      expect(JamakolaRuleEngine.matches(rule, {'kavipu_house_from_udhayam': 8}), isFalse);
      expect(JamakolaRuleEngine.matches(rule, {}), isFalse);
    });

    test('Traditional approaching input is distinct from geometric contact', () {
      const rule = JamakolaRule(
        'JA-TEST-MOON', 'question_subject', 'Test', 'source', '1',
        {'approaching_udhayam': 'Moon'},
      );
      expect(JamakolaRuleEngine.matches(rule, {'approaching_udhayam': 'Moon'}), isTrue);
      expect(JamakolaRuleEngine.matches(rule, {'approaching_udhayam': 'Mars'}), isFalse);
    });
  });
}
