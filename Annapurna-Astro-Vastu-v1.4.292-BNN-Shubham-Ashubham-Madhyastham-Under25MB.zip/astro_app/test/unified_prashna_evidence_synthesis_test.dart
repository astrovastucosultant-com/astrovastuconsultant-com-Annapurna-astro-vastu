import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/unified_prashna_service.dart';

void main() {
  test('missing KP support does not conflict with applying Tajik', () {
    final evidence=<PrashnaEvidenceLevel>[
      PrashnaEvidenceLevel.incomplete,
      PrashnaEvidenceLevel.preliminarySupport,
      PrashnaEvidenceLevel.incomplete,
    ];
    expect(PrashnaEvidenceSynthesis.hasVerifiedConflict(evidence), false);
    expect(PrashnaEvidenceSynthesis.summary(evidence),
      contains('ప్రాథమిక అనుకూల సూచనలు'));
    expect(PrashnaEvidenceSynthesis.summary(evidence),
      contains('పెండింగ్'));
  });
  test('zero evidence is not a denial', () {
    expect(PrashnaEvidenceSynthesis.summary([
      PrashnaEvidenceLevel.incomplete,
      PrashnaEvidenceLevel.incomplete,
    ]), contains('ఆధారాలు అసంపూర్ణం'));
  });
  test('only independently verified opposite findings are a conflict', () {
    expect(PrashnaEvidenceSynthesis.hasVerifiedConflict([
      PrashnaEvidenceLevel.verifiedSupport,
      PrashnaEvidenceLevel.verifiedDenial,
    ]), true);
  });
  test('preliminary positive is not a verified conflict with denial', () {
    expect(PrashnaEvidenceSynthesis.hasVerifiedConflict([
      PrashnaEvidenceLevel.preliminarySupport,
      PrashnaEvidenceLevel.verifiedDenial,
    ]), false);
  });
}
