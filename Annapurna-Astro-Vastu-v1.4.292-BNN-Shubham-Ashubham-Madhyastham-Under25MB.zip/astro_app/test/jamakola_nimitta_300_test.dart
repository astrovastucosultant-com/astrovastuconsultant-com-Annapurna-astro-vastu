import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jamakola_special_service.dart';
import 'package:astro_app/astrology/jamakola_nimitta_300_service.dart';

JamaNimittaRule _rule({
  String udayam='ఉదయం 1వ భావం',
  String arudam='ఆరూఢం 4వ భావం',
  String kavippu='కవిప్పు 7లో రాహువుతో',
}) => JamaNimittaRule(number:1,page:1,udayam:udayam,
    arudam:arudam,kavippu:kavippu,nimitta:'చెప్పులు',result:'వాహనం');

AstroChartResult _chart() => AstroChartResult(
    julianDay:0,ayanamsaDegrees:24,ascendantLongitude:3,
    planets:[const PlanetPosition(name:'Sun',shortName:'Su',
        longitude:25,latitude:0,speed:1),
      const PlanetPosition(name:'Rahu',shortName:'Ra',
        longitude:195,latitude:0,speed:-0.01)],engineVersion:'test');

JamakolaSpecialResult _special() => JamakolaSpecialResult(
    udhayam:3,arudam:93,jamaGrahas:const [],jamam:1,isNight:false,
    sunriseLocal:DateTime(2026,10,26,6),
    sunsetLocal:DateTime(2026,10,26,18),
    sunriseSunLongitude:25,jamaContacts:const []);

void main(){
  test('Kavippu sign-only plus named planet is not verified',(){
    final found=JamaNimitta300Analysis.analyse(
      rules:[_rule()],chart:_chart(),special:_special(),
      kavippuSign:6,kavippuVerified:false);
    expect(found.length,1);
    expect(found.first.passCount,2);
    expect(found.first.pendingCount,1);
    expect(found.first.allComputedMatch,false);
  });
  test('Arudam wrong house does not predict',(){
    final found=JamaNimitta300Analysis.analyse(
      rules:[_rule(arudam:'ఆరూఢం 7వ భావం')],chart:_chart(),
      special:_special(),kavippuSign:6,kavippuVerified:false);
    expect(found,isEmpty);
  });
  test('Sign-based Udayam restrictions reject wrong signs',(){
    final found=JamaNimitta300Analysis.analyse(
      rules:[_rule(udayam:'ఉదయం జల రాశిలో')],chart:_chart(),
      special:_special(),kavippuSign:6,kavippuVerified:true);
    expect(found,isEmpty);
  });
  test('Exact past-minute condition remains pending without degrees',(){
    final found=JamaNimitta300Analysis.analyse(
      rules:[_rule(kavippu:'ఉదయానికి వెనుక 6° (25 నిమి.)')],
      chart:_chart(),special:_special(),kavippuSign:6,
      kavippuVerified:false);
    expect(found.single.kavippu,JamaCheck.pending);
  });
}
