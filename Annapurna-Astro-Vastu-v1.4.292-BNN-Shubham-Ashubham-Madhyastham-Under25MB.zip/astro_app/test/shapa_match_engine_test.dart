import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/shapa_match_engine.dart';
import 'package:astro_app/astrology/shapa_rule_service.dart';

PlanetPosition planet(String name,double longitude)=>PlanetPosition(
  name:name,shortName:name,longitude:longitude,latitude:0,speed:1);
AstroChartResult chart(double asc,List<PlanetPosition> positions)=>AstroChartResult(
  julianDay:2451545,ayanamsaDegrees:24,ascendantLongitude:asc,
  planets:positions,engineVersion:'test');
void main() {
  test('User PDF yields 73 BPHS yogas plus four preserved Rahu/Ketu rules', () {
    final rules=ShapaRuleService.rules;
    expect(rules.length,77);
    expect(rules.where((r)=>r.legacy).length,4);
    expect(rules.where((r)=>!r.legacy).length,73);
    expect(rules.map((r)=>r.id).toSet().length,77);
    final groupCounts=<String,int>{};
    for(final r in rules.where((r)=>!r.legacy)) {
      groupCounts[r.group]=(groupCounts[r.group]??0)+1;
      expect(r.verse.startsWith('83.'),true);
      expect(r.condition,isNotEmpty);
      expect(r.result,isNotEmpty);
    }
    expect(groupCounts,{'సర్ప':8,'పితృ':11,'మాతృ':13,'భ్రాతృ':10,
      'మాతుల':4,'బ్రహ్మ':7,'పత్నీ':11,'ప్రేత':9});
  });
  test('Incomplete natal chart reports pending, never a curse', () {
    final r=ShapaMatchEngine.evaluate(chart(0,[planet('Sun',10)]));
    expect(r.length,77);
    expect(r.every((a)=>a.matched==null),true);
  });
  test('Fully checkable preta 83.100 reports full chart evidence', () {
    final r=ShapaMatchEngine.evaluate(chart(0,[
      planet('Sun',60),planet('Moon',330),planet('Mars',90),
      planet('Mercury',150),planet('Jupiter',210),planet('Venus',30),
      planet('Saturn',120),planet('Rahu',0),planet('Ketu',180),
    ]));
    final match=r.singleWhere((a)=>a.rule.id=='BPHS83-ప్రేత-04');
    expect(match.matched,true);
    expect(match.evidence.length,3);
    // Preserved legacy alternate wording is not silently claimed as true.
    expect(r.where((a)=>a.rule.legacy).every((a)=>a.matched==null),true);
  });
}
