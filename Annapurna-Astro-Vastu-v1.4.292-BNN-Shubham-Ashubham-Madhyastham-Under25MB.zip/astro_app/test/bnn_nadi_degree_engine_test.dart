import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_nadi_degree_engine.dart';

PlanetPosition pos(String name, double longitude, {double speed = 0.01}) =>
    PlanetPosition(name: name, shortName: name.substring(0, 2),
      longitude: longitude, latitude: 0, speed: speed);

AstroChartResult chart(List<PlanetPosition> planets) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 24,
  ascendantLongitude: 80, planets: planets, engineVersion: 'test',
);

void main() {
  test('The user master: LOCAL degrees, not zodiac absolute longitudes', () {
    final c = chart([
      pos('Jupiter', 24), // Aries 24 deg
      pos('Venus', 124), // Leo 04 deg
      pos('Saturn', 256), // Sagittarius 16 deg
    ]);
    final fire = BnnNadiDegreeEngine.sequences(c).single;
    expect(fire.trineGroup, 0);
    expect(fire.planets.map((p) => p.name).toList(),
      ['Venus', 'Saturn', 'Jupiter']);
    expect(BnnNadiDegreeEngine.dms(fire.planets.first), '4°00′00″');
    expect(BnnNadiDegreeEngine.degreeOrder(fire.planets[0], fire.planets[1]),
        contains('శని'));
  });

  test('Same-sign order and retrograde motion must be separate', () {
    final venus = pos('Venus', 33);
    final saturn = pos('Saturn', 45, speed: -0.01);
    final c = chart([venus, saturn]);
    expect(BnnNadiDegreeEngine.sequences(c).single.planets.first.name, 'Venus');
    expect(saturn.retrograde, isTrue);
    expect(BnnNadiDegreeEngine.contacts(c).single.kind, 'NATAL_SAME_SIGN');
  });

  test('Equal DMS remains unresolved, not arbitrarily ordered', () {
    final a = pos('Venus', 124.00000);
    final b = pos('Saturn', 256.00008);
    expect(BnnNadiDegreeEngine.degreeOrder(a, b), contains('నిర్ణయించలేని'));
  });

  test('Node seventh aspect unsupported in chosen BNN node profile', () {
    final c = chart([pos('Rahu', 10), pos('Sun', 190)]);
    expect(BnnNadiDegreeEngine.contacts(c), isEmpty);
    expect(BnnNadiDegreeEngine.contacts(c, nodeProfile: 'OTHER').single.kind,
      'BNN_OPPOSITION_7');
  });

  test('Distinct 1-5-9, next and previous signs are labeled', () {
    final c = chart([
      pos('Venus', 5), pos('Mars', 125), pos('Mercury', 35),
    ]);
    final kinds = BnnNadiDegreeEngine.contacts(c).map((c) => c.kind).toSet();
    expect(kinds, contains('NATAL_TRINE_159'));
    expect(kinds, contains('NEXT_SIGN'));
  });

  test('Jupiter quick 12y windows stay distinct from slow symbolic method', () {
    final c = chart([pos('Jupiter', 24), pos('Venus', 124)]);
    final quick = BnnNadiDegreeEngine.jupiterQuickWindows(c, maxAge: 30);
    expect(quick.map((w) => w.fromAge).toList(), [4, 16, 28]);
    expect(quick.every((w) => w.methodId ==
      BnnNadiDegreeEngine.jupiterQuickId), isTrue);
    expect(BnnNadiDegreeEngine.slowJupiterSymbolicLongitude(c, 12), 54);
    expect(BnnNadiDegreeEngine.jupiterQuickId,
      isNot(BnnNadiDegreeEngine.jupiterSlowId));
  });

  test('Saturn 2.5 years per sign is symbolic, not a real transit', () {
    final c = chart([pos('Saturn', 9), pos('Jupiter', 69)]);
    final slow = BnnNadiDegreeEngine.saturnSymbolicWindows(c, maxAge: 35);
    expect(slow.first.fromAge, 5);
    expect(slow.first.toAge, 7.5);
    expect(slow.first.methodId, BnnNadiDegreeEngine.saturnSymbolicId);
  });

  test('Sign wrapping and Jupiter-based house, Lagna remains untouched', () {
    expect(BnnNadiDegreeEngine.zodiacSign(-10), 11);
    expect(BnnNadiDegreeEngine.bnnHouse(3, 11), 5);
    expect(chart([pos('Jupiter', 24)]).ascendantSignIndex, 2);
  });
}
