# Build v1.4.288 — Siddhanti Rule display label

- Renamed the displayed D1 12-bhava 336-rule set to **సిద్ధాంతి రూల్**.
- Added `rule_label` to all 336 catalogue entries and `rule_series_label` to the JSON root.
- UI shows the name on rule cards and their expanded details.
- Original provenance, IF match behavior, calculations, result contents, 17 direct classroom source notes, BNN original 462 rules, and timing logic are unchanged.
- 335 records retain analyst-derived provenance; one entry retains its original First Bhava P5 transcript provenance. Naming is NOT an assertion that all 336 are direct book or teacher quotations.
- Changed pubspec version to 1.4.288+288. Flutter compilation not executed in this environment.
