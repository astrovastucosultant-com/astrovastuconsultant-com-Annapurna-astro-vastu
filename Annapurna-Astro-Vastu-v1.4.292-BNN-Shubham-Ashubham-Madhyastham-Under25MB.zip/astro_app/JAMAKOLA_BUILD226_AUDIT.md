# Jamakola UI v1.4.226 — Audit and limitations

Reference: User-supplied 24-Oct-2026 Divya Chakshu screenshots (four views).

## Added
- Dedicated Jamakola view in system drawer using the existing ChartScreen system page.
- Place name, Place Search with lat/lon update, Date, Time, NOW, UTC offset and Calculate.
- Day of week, sunrise/sunset-based ordinary planetary Hora. Hora is not Jama cycle.
- South Indian fixed sign chart; Placidus Bhava chart using Swiss Ephemeris cusps.
- Pink transit ribbons containing actual computed planetary longitudes (not Jama planets).
- Planet table: Udayam, Arudam, Chatra, Sun–Ketu, Mandi, Yamaghan, Longitude, Degrees, Star, Pada.
- Collapsible Prashna Confirmation (15 labelled checks from screenshot); only the two Udaya-to-Arudam/Chatra relative-house values can be derived from verified manual longitudes. All other checks explicitly pending.
- Manual Arudam, Chatra, Mandi, Yamaghan longitude inputs and supplemental rule conditions for Kavipu, approaching planet and Gowri period.
- Prior Jamakola source-rule JSON retained, with matched/failed/unknown conditions differentiated (missing evidence must not be misclassified as failed).
- Removed former fixed 750px Jamakola list panel height; screen scrolls naturally with the parent.

## Explicitly incomplete
- Automatic Jamakkol Arudam, Chatra, Jama-planet cycles, Mandi and Yamaghan are NOT implemented because their verified source formulae are not included in the prior rule starter. Do not show example screen figures as computed results.
- No guarantee of reproducing the separate Divya Chakshu app's proprietary formula or placements.
- Ordinary planetary Hora is not the Jamakkol-specific Jama time wheel.
- Swiss Sidereal planetary positions use the existing saved chart ayanamsa. They can differ from an external reference using a different ayanamsa.
- Horoscope/prashna outcome remains traditional interpretive data; not a factual guarantee.

## Verification
- Source archive ZIP entries integrity checked before modification.
- New Dart file lexical delimiter balance tested.
- 3 project files modified: `lib/screens/jamakola_rule_panel.dart`, `lib/screens/chart_screen.dart`, `pubspec.yaml`.
- Existing Jamakola rule JSON, Jaimini JSON and Varga JSON preserved byte-identically.
- Flutter SDK not installed in build environment: this ZIP has NOT been compiled by Flutter. GitHub Actions build is needed for definitive validation.
