# v1.4.265 — Relationship result-target indexing correction

Issue demonstrated by user screenshots: BNN relatives/kinsmen tab showed "గురు+రాహు — వ్యక్తి కుటుంబం నుంచి దూరంగా ఉంటాడు" because keyword `కుటుంబ` in the THEN sentence triggered relatives categorization. This rule describes the native, not those relatives.

## Changes
- Source relation indexing now matches specific relationship targets in THEN text, not IF text or generic topical keywords.
- Removed `కుటుంబ` and `వంశ` generic matching from the relatives tab. A named native's personal outcome never becomes a relative's result merely through the word family.
- Exclude 'తల్లి భర్త' from the chart-native husband's tab.
- Preliminary conjunction candidates require both a relation-targeted outcome and one observed same-sign chain; no claim of verified IF execution.
- When no candidate, explicitly show the count of actual source IF–THEN rules available for that relative, rather than implying no source data exists.
- Natal karaka placements hidden beneath an expansion; first screen shows the relation and available outcome status. Source rules open through one button.
- Green and pink withheld for incomplete IF matches. All 462 original source IF/THEN unchanged.
- Regression tests for the exact false-positive case and related relative targeting.

## Limitations
Many IF predicates in the 462 catalog remain non-executable, including OCR_REVIEW/REVIEW, transit and compound conditions. No full event forecast, medical/family verdict or definitive green/pink classification is claimed. Flutter toolchain is not available here; perform CI Flutter analyze/test/build.
