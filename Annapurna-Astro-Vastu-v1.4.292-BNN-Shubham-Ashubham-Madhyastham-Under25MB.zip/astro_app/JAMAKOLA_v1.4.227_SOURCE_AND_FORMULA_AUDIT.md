# Jamakola v1.4.227 — computation implementation and limits

## Confirmed implementations

- Inner grahas: existing Swiss Ephemeris, configured sidereal ayanamsa.
- Jamakkol Udayam: sunrise Sun sidereal longitude + one 360° turn over the daylight interval, then one 360° turn over the following night. Sunrise/sunset are computed for the entered latitude, longitude and UTC offset, rather than applying an arbitrary fixed 06:00 to solar days.
- Arudam automatic clock convention: `(minute + second/60)*6` degrees, reduced modulo 360. Practitioner override remains available to support querent-selected Arudam.
- Jama outer ring: **eight** named markers `Sun, Mars, Jupiter, Mercury, Venus, Saturn, Moon, Snake`; at 06:00 local civil time the appropriate day lord is at 0°, neighbours are separated by –45°, all move –0.5° per minute. Before 06:00 local, the previous weekday governs; positions wrap every 12h. This is a documented *convention*, not an astronomical longitude or universal interpretation.
- Separate solar Jamam index (1–8 for day and 1–8 for night), normal planetary Hora, Jama ring, Udayam, and ordinary Ascendant. Do **not** conflate these.
- Chart + detailed position table and available basic Prashna Confirmation calculations now use the separate levels. Standard sign dignity and mutually exchanged lords are simple checks, not final horary judgement.

## Verification fixtures for the selected ring convention

- Friday 2026-10-23 08:28:10: Jama Sun 105°55′, Jama Venus 285°55′ (public reference fixture).
- Tuesday 2026-09-15 05:58:24: previous-day Moon governs; Jama Moon 0°48′, Jama Sun 270°48′ (public reference fixture).
- Wednesday 2026-09-16 10:30: Jama Sun 0°, Jama Mercury 225° (public reference fixture).
- Friday 2026-10-23 08:28:10: Arudam 169° = Virgo 19°.
- **Direct user screenshot — Guntur 2026-10-24 17:50:** Jama Sun 230°, Mars 185°, Jupiter 140°, Mercury 95°, Venus 50°, Saturn 5°, Moon 320°, Snake 275° — **all eight match**. Clock Arudam 300° = Capricorn 0° also matches. This is strong local fixture evidence for the selected outer-ring model, not a validation of the separate Chatra method.

## Not yet derivable from the supplied 22-page and 200-page source excerpts

The provided book extracts discuss **Kavippu**, whereas the screenshot calls a different point **Chatra**. They cannot be equated without a source-specific definition. The exact Divya Chakshu Chatra algorithm and its `Chatra catching` test have therefore **not** been invented. Manual verification remains available.

**Mandi** and **Yamaghan** also require a verified source-specific weekday/day-night table and method. The current interface retains honest Manual/Pending status for them.

**Kavippu** is retained as a distinct manual reference-sign field in the older source-derived IF–THEN rule UI. Its Surya-Veedhi anchor table is not defined by the two supplied PDFs. Do not substitute `Chatra` for it.

### Source attribution / distinct conventions

User sources: `jamakola టెస్ట్` scanned chapter 15 (printed pages 194 onward), `jamakoka 2.pdf` scanned 200 pages of later chapters; test uses source-derived interpretation of approaching/crossed Udhayam, Arudam/Kavippu houses.

Independent check sources (retrieved October 2026):
- https://rajvidya.com/wiki/article/jama-grahas-jama-time-jamakol-ring/
- https://occultapi.com/docs/astro/prashna/jamakkol
- https://hindupanchangam.in/en/tools/jamakol-prasannam/

## Build status

Static integration checks and ZIP CRC were performed. Flutter SDK not installed in this runtime; no claim of APK compilation or runtime success. Run GitHub Actions release APK workflow and the included `jamakola_special_service_test.dart` before distribution.
