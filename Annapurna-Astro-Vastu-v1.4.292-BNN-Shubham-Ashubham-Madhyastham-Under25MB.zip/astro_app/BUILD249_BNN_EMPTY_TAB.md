# Build 249 — BNN empty tab

- The BNN navigation tab is retained; it opens without results or source material.
- Removed 193 BNN reference scans (19 legacy + 174 newer scans), including both asset directories.
- Removed BNN services, result UI, original rule viewers, tests, rule registry entries, and associated source-only logic from shared D1 catalog and HTML source reference.
- Removed BNN-specific documentation and stale BNN active-engine card.
- Hasta Samudrika continues as a blank tab.
- Other systems (including BSP and BCP) were not intentionally changed.
- New source version: 1.4.249+249.
- Static source/ZIP verification only; Flutter compilation and APK build have not been run.
