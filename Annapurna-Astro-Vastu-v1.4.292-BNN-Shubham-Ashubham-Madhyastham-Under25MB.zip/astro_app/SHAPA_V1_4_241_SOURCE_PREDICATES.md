# v1.4.241 — BPHS Chapter 83, 33 previously pending rule checks

**Input:** user-provided 13-page Telugu PDF: Brihat Parashara Hora Shastra (Chapter 83), 73 yogas. The four retained legacy Rahu/Ketu rules are not rewritten.

**Engine:** `lib/astrology/shapa_match_engine.dart` now has a 73/73 explicit AND/OR predicate tree; 40 were present in v1.4.240, the remaining 33 are covered in this version. It uses Whole Sign D1 houses, Parashari aspects, planetary longitudes, D9 navamsa (reusing VargaService), Papakartari, combustion orbs, Moon phase, conjunction, simple dignity and selected natural enemy sign checks. Each predicate records supporting values for the results-on-tap inspection.

**Verse 83.102:** The original Telugu source gives an ambiguous abbreviated target to the debilitation aspect. The Sanskrit text clarifies it as the 5th house. Check debility of 5th lord, Jupiter and an actually debilitated Graha aspecting the 5th by Parashari aspect. Reference: https://vedicpupil.in/library/books/brihat-parashara-hora-shastra/chapter-83/verse-102

**Shadbala:** Full six-part Shadbala values are not derivable from the app's AstroChartResult (which contains only longitudes, speeds and ascendant). Never equate Navamsa/Vimsopaka/dignity to full Shadbala. Seven verified virupa totals may be supplied through the collapsed input panel; otherwise predicates needing them remain unknown. BPHS table: https://vedic-astro.s3.amazonaws.com/books/bhrihat_parasara_hora_shastra.pdf. Traditional minimum virupas: Sun 390, Moon 360, Mars 300, Mercury 420, Jupiter 390, Venus 330, Saturn 300.

**Mandi:** If a verified longitude exists in the AstroChartResult as Mandi or Gulika, the evaluator reads it. Otherwise the user can supply a verified total longitude via the collapsed panel. It is never invented from sunrise or from the current question time.

**Node aspects:** Conjunction from signs is checkable, but debated Rahu/Ketu aspect rules yield an *unknown* instead of forced true. Real Shadbala or Mandi gaps are printed against the exact unmet predicate, not represented as a blanket implementation blocker for 33 rules.

**No false promises:** A source IF can evaluate TRUE/FALSE/UNKNOWN. TRUE is a traditional rule match, not a factual curse/fertility diagnosis. FALSE is a non-matching *alternative*, not an adverse result. UNKNOWN is explicit incomplete chart evidence.

**Validation**: static unique ID and predicate coverage = 73; supported token vocabulary; static delimiters balanced; source-preserving ZIP CRC. Dart / Flutter SDK is not installed in the authoring environment, so APK compilation requires the next GitHub Build.
