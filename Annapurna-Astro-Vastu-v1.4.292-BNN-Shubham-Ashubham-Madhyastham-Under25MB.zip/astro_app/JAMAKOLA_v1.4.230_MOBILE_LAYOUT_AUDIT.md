# Annapurna Astro Vastu v1.4.230 — Jamakola mobile layout audit

Based on user screenshot (2026-10-24): Rashi Chart centre was crowded by a verbose English legend, the planetary DataTable required horizontal scrolling, and high-density sign cells risked visual overflow on narrow Android screens.

## Implemented
- Moved full U / ARU / KAV / CHA / J: legend outside the square chart. Centre now shows just chart name and compact abbreviations.
- On phone widths (<620 logical px), show a per-planet compact card containing Longitude, Star, Pada, and total Degrees; all essential values visible without horizontal scrolling.
- The user can toggle **పూర్తి పట్టిక** to see the original 5-column table on mobile; larger screens retain the full table.
- Crowded zodiac cells now allow vertical scrolling and use responsive text sizes.
- No changes to Jamakola astronomical arithmetic; no source-specific Kavippu/Chatra/Mandi/Yamaghan algorithms were invented.

## Existing limitations retained
- Kavippu requires independently verified Veedhi anchor; Chatra is distinct and manual. Mandi/Yamaghan also remain manual pending a verified method.
- No Flutter SDK available in the execution container, so compile/release APK is **not verified**; ZIP structure and unmodified-source preservation were checked.
