# Annapurna Astro Vastu v1.4.271 — BNN Timing Progression Master 48

Input: `Annapurna_BNN_Timing_Progression_Master_48_IF_THEN(1).json`.

- Imported **all 48** original BNN-TOE-P001..P048 IF/THEN engine design rules verbatim as a dedicated asset, with original metadata, implementations/stages/statuses, and source references unchanged.
- Existing **106 engine specifications** and **462 original source IF/THEN entries** retained intact. No entry was promoted to VERIFIED.
- New standalone Dart `BnnTimingProgressionService` uses switchable **RAO_APPROX** symbolic rates J +30°/year, S +12°/year, nodes −360/18.6°/year; and **SLOW_DEGREES** symbolic rates J +2.5°/year, S +1°/year, nodes −5/3°/year. No mixing profiles or equating symbolic positions to astronomical transits.
- Computes normalized symbolic positions and approximate fractional-age exact longitude contacts over multiple revolutions. Separate ordinary 12-year Jupiter age-round labels remain non-event metadata. Natal chart unchanged.
- Uses already-existing Swiss Ephemeris `AstroCalculationService.calculatePlanetAtUtc` to calculate actual sidereal Jupiter/Saturn on **six UTC sample dates 30 days apart** (only upon tap), matching SAME_SIGN, TRINE_159, OPPOSITION_7 against chart planets. Actual samples ≠ exact ingress/station/orb/event dates; individual retrograde sample points retained.
- Adds BNN event tab profile dropdown, symbolic contact records, explicit real-transit sampling button, and 48-item IF/THEN drill-down source library. Results marked as exploratory evidence only; no source auto-firing or user-specific guaranteed outcome.
- Tests cover symbolic rates, wrap, contact cycles, inverse node motion, relation types, final-event safety gate, and Jupiter round metadata.

## Pending / NOT implemented

Exact ingress/root refinement with station/retrograde loops, overlapping verified natal event promises and source-page validation, unified time-window merger, cross-method corroboration, BTR decision layer. The source JSON is a *candidate* master; its `status` map describes historical assertions and should not be interpreted as verified runtime functionality. The original 462 source statuses are OCR_REVIEW 343 / FACTS_REQUIRED 82 / REVIEW 37 / VERIFIED 0.

Flutter/Dart SDK not available in current execution environment: **Flutter compile and APK build not run.** ZIP-integrity and asset/rule-count/static structure checks are performed separately.
