# v1.4.263 — BNN Natal D1, Events Study, Relations

## Navigation / chart display
- Main Jataka: standalone D1 Rasi chart with natal Lagna and DMS degrees; the previously embedded auto-expanded Jaimini Chara Dasha was removed from this page.
- Open Systems → BNN: D1 chart with natal Lagna degree and every planet's DMS within its actual sign. Tapping a planet opens the existing planet detail sheet.
- BNN analysis underneath the D1 chart retains Jupiter's sign as the BNN-relative first bhava for interpretation; it does **not** change the D1 birth ascendant.
- Open Systems → Jaimini: the original Jaimini module is retained and has no BNN panel. Other system menu choices remain separate.

## BNN subnavigation
- 12 colorful Bhava selector, 5 sub-tabs.
- Timing study tab: born-year-relative approximate age/calendar ranges from source-attributed Jupiter/Saturn cycles, not asserted actual past/future event dates. No current transit/nakshatra computation was added.
- Relations tab: 16 choices including mother, father, wife, husband, siblings, children, grandparents, relatives and friends. Shows actual karaka planet/sign/degree, Jupiter-relative house, and traced source rules. A source text match is NOT a confirmed personal event.
- Green/Pink cues are not assigned to OCR_REVIEW/REVIEW source rules without evidence.

## Audit and limitations
- 462 original BNN rules preserved unchanged.
- ZIP integrity, source imports and expected source files checked locally.
- Flutter/Dart SDK unavailable in this runtime: flutter analyze, tests and APK compile could not be executed here. No claim of a signed or installable APK.
