# BNN v1.4.276 — Source-to-topic classification and results-first UI

- Fix: BNN-BOOK-I18 "జగడాలాడే స్వభావం" is a social-behavior observation, not a physical-body observation. The overly generic "స్వభావ" word has been removed from body-constitution matching; social behavior includes quarrelling/disputes.
- The 12 items per bhava are still chart-inspected, but topics without a fully matched natal IF are collapsed by default. Matching source clues appear first.
- Technical Nadi contact list is collapsed separately; 106 Engine rules remain a methodology library rather than life results.
- No new predictions, no OCR source verification claimed. All 462+106+48 source/master records remain unchanged.
- Dart regression test was added, but Flutter/Dart SDK was unavailable in container, so compile/build was not run.
