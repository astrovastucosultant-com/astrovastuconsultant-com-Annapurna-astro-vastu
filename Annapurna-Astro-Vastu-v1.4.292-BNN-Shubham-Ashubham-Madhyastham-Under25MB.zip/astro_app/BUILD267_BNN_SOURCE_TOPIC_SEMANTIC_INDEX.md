# Build 267 — BNN topic/source outcome indexing repair

- The 462 user-provided source IF/THEN rules are untouched (catalog identical bytes).
- Topic labels remain exactly 12 bhavas × 12 topics; **no fabricated topic THEN**.
- Topic matching now indexes specific synonyms in the **THEN** statement and
  filters by relevant bhava; generic source topic and planetary IF words
  do not independently make a topic hit.
- Bhava results/conjunctions appear before the separate, collapsed topic index.
- The index displays source THEN text, while complete IF check remains unverified.
- Labels with no indexed THEN are collapsed, avoiding 12 repetitive blank cards.
- Green/Pink is deliberately disabled for BNN preliminary contacts until
  a verifiable full-IF execution engine is implemented.
- 16 relation groups and study-only timing tabs remain unchanged.
- Version 1.4.267+267 avoids the duplicate-latest-ZIP selection failure.
- No Flutter/Dart SDK available in runtime: only static/ZIP checks performed.
