# Unified Prashna Event Timing — v1.4.246

## Goal
One question/moment/place, with separate traceable KP Time Chart (and optional 1–249 Number Chart), Jamakola, and Tajik temporal evidence. No method is incorrectly substituted for another; no single future event date is invented when rule-verification is missing.

## New calculations
1. **KP:** Horary Moon's sidereal KP longitude seeds Vimshottari balance. Use the existing `DashaService` proportional Maha–Antar–Pratyantar periods, and primary/supporting houses from the selected KP event. Filter DBA intervals up to one year using occupant/lord/starlord associations, and optionally use actual Sun/Moon Swiss Ephemeris sidereal KP longitudes sampled at local noon to shortlist transit days (240-day horizon). This is a **candidate** list. Requires complete CSL Promise/Denial, Rahu/Ketu agency, contrary houses and stronger RP/Transit corroboration for a traditional KP conclusion. Ruling planets by local sunrise are not inferred from the Moon transit sample.
2. **Jamakola:** From already-computed solar day/night segment, Udhayam and eight moving Jama planets, report the mathematically verified **upcoming Udhayam-Jama crossing within the next 30 minutes**. This is *not* a date of an external event; exact traditional event-timing transformation to days/months is not claimed. KAV and Arudam remain context for the full horary judgment.
3. **Tajik:** For a preliminary applying aspect, search the actual two-planet ephemeris over 14 days at 6-hour intervals, refine a zero crossing with 22 binary-search iterations. The resulting instant is **aspect perfection**, not an event date. The 16 yogas, Radda, Nakta and Kamboola still need verification.

## UI
- Expanded `3. KP` lists DBA intervals and transit day samples.
- Expanded `4. Jamakola` lists approaching contacts with minute values.
- Expanded `5. Tajik` lists mathematically computed aspect perfection UTC transformed into the query location's fixed UTC offset.
- Expanded `6. మూడింటి సమయ ఆధారాల సమన్వయం` warns that independent signals cannot be averaged into one guaranteed date.
- Copy Report includes all three systems' calculations and explicit provenance limitations.

## Technical guardrails
- Question time (not birth time) anchors the calculations.
- KP uses Krishnamurti sidereal; Tajik aspect separation uses tropical *differences*, invariant under common ayanamsa; Jama ring uses local civil time.
- A nonmatched conditional is not a definitive denial.
- A candidate time is not a real-world probability or a confirmed event date.
- No promise of exact timing until complete source-derived rules match.

## References consulted
- KP Horary Template for Dasha/Transit, Rajendra Nimje (2015): https://astrouser.com/wp-content/uploads/2023/03/KP-Template-for-Horary-chart-Analysis-1.pdf
- KP Horary timing staged outline: https://prashna.diastrologer.com/blog/how-kp-horary-timing-works-dasha-transit
- Tajik: aspect contacts in this update are astronomical, not a complete 16-yoga analysis.
- Jamakol timing and approaching graha: https://rajvidya.com/wiki/article/jamakol-question-types-timing-when-to-act/

## Build verification
ZIP integrity and source structure checks are possible locally. This environment does **not** include Dart/Flutter SDK, and therefore no APK build is claimed successful here. Run GitHub Actions release APK and inspect `flutter analyze`, `flutter test test/prashna_event_timing_service_test.dart` and `flutter build apk --release` before distributing the APK.
