import 'dart:convert';

import 'package:flutter/services.dart';

import 'astro_models.dart';

/// Separate D1-Lagna bhava reference rules. These must NOT be interpreted as
/// the Jupiter-anchored BNN bhavas used elsewhere in the application.
/// Only BHAVA_LORD_PLACEMENT has a fully computable positional predicate;
/// a true predicate is evidence of placement, NOT proof of a life outcome.
class BnnD1BhavaRule {
  final String id;
  final String type;
  final int house;
  final String topic;
  final int? lordOf;
  final int? lordOccupiesHouse;
  final String result;
  final String examination;
  final String sourceIfThen;
  final String remedy;
  final String timing;
  final String provenance;
  final String ruleLabel;
  final bool eligible;

  const BnnD1BhavaRule({
    required this.id,
    required this.type,
    required this.house,
    required this.topic,
    required this.lordOf,
    required this.lordOccupiesHouse,
    required this.result,
    required this.examination,
    required this.sourceIfThen,
    required this.remedy,
    required this.timing,
    required this.provenance,
    required this.ruleLabel,
    required this.eligible,
  });

  factory BnnD1BhavaRule.fromJson(Map<String, dynamic> raw) {
    final result = raw['result'] as Map<String, dynamic>;
    return BnnD1BhavaRule(
      id: raw['id'] as String,
      type: raw['type'] as String,
      house: raw['house'] as int,
      topic: raw['topic'] as String? ?? '',
      lordOf: raw['lord_of'] as int?,
      lordOccupiesHouse: raw['lord_occupies_house'] as int?,
      result: result['ఫలితం'] as String? ?? '',
      examination: result['జాతక పరిశీలన'] as String? ?? '',
      sourceIfThen: result['మూల IF–THEN'] as String? ?? '',
      remedy: result['ఉపశమనం/పరిహారం'] as String? ?? '',
      timing: result['సంఘటన సమయం'] as String? ?? '',
      provenance: raw['provenance'] as String? ?? '',
      ruleLabel: raw['rule_label'] as String? ?? 'సిద్ధాంతి రూల్',
      eligible: raw['auto_match_eligible'] == true,
    );
  }
}

class BnnD1BhavaHouse {
  final int number;
  final String name;
  final String domain;
  const BnnD1BhavaHouse(this.number, this.name, this.domain);
}

class BnnD1BhavaSourceNote {
  final String id;
  final int house;
  final String topic;
  final String source;
  final String ifText;
  final String thenText;
  const BnnD1BhavaSourceNote({
    required this.id, required this.house, required this.topic, required this.source,
    required this.ifText, required this.thenText,
  });
}

class BnnD1BhavaCatalogue {
  final List<BnnD1BhavaRule> rules;
  final List<BnnD1BhavaHouse> houses;
  final List<BnnD1BhavaSourceNote> notes;
  const BnnD1BhavaCatalogue(this.rules, this.houses, this.notes);

  static Future<BnnD1BhavaCatalogue> load() async {
    final source = await rootBundle.loadString(
      'assets/bnn/bnn_d1_12_bhava_336_v1.json',
    );
    return parse(source);
  }

  static BnnD1BhavaCatalogue parse(String source) {
    final root = jsonDecode(source) as Map<String, dynamic>;
    final rules = (root['rules'] as List<dynamic>)
        .map((r) => BnnD1BhavaRule.fromJson(r as Map<String, dynamic>))
        .toList(growable: false);
    final houses = (root['houses'] as List<dynamic>)
        .map((v) {
          final h = v as Map<String, dynamic>;
          return BnnD1BhavaHouse(
            h['number'] as int, h['name'] as String, h['domain'] as String);
        })
        .toList(growable: false);
    final notes = (root['source_notes'] as List<dynamic>)
        .map((v) {
          final r = v as Map<String, dynamic>;
          return BnnD1BhavaSourceNote(
            id: r['id'] as String? ?? '',
            house: r['house'] as int,
            topic: r['topic'] as String? ?? '',
            source: '${r['id'] ?? ''} • ${r['time_reference'] ?? ''}',
            ifText: r['if_text'] as String? ?? '',
            thenText: r['then_telugu'] as String? ?? '',
          );
        }).toList(growable: false);
    if (houses.length != 12 || rules.length != 336 ||
        rules.map((r) => r.id).toSet().length != 336 ||
        rules.where((r) => r.type == 'BHAVA_TOPIC_CHECK').length != 144 ||
        rules.where((r) => r.type == 'BHAVA_LORD_PLACEMENT').length != 144 ||
        rules.where((r) => r.type == 'CONDITIONAL_MODIFIER').length != 48) {
      throw const FormatException('BNN D1 12 Bhava 336 source set incomplete');
    }
    return BnnD1BhavaCatalogue(rules, houses, notes);
  }

  List<BnnD1BhavaRule> forHouse(int house, String type) => rules
      .where((r) => r.house == house && r.type == type)
      .toList(growable: false);
}

class BnnD1BhavaPlacement {
  final int house;
  final int houseSign;
  final String lordPlanet;
  final int lordSign;
  final int lordHouse;
  const BnnD1BhavaPlacement({required this.house, required this.houseSign,
    required this.lordPlanet, required this.lordSign, required this.lordHouse});
}

class BnnD1BhavaGeometry {
  static const signs = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];
  // Classical seven-planet sign ownership. Rahu/Ketu are not assigned
  // co-ownership; no accidental substitution for a natal lord.
  static const signLords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];
  static const planetTelugu = <String, String>{
    'Sun': 'సూర్యుడు', 'Moon': 'చంద్రుడు', 'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు', 'Jupiter': 'గురువు', 'Venus': 'శుక్రుడు',
    'Saturn': 'శని', 'Rahu': 'రాహువు', 'Ketu': 'కేతువు',
  };

  static int signForHouse(AstroChartResult chart, int house) =>
      (chart.ascendantSignIndex + house - 1) % 12;

  static int houseForSign(AstroChartResult chart, int sign) =>
      ((sign - chart.ascendantSignIndex + 12) % 12) + 1;

  static List<PlanetPosition> planetsInHouse(AstroChartResult chart, int house) =>
      chart.planets.where((p) => houseForSign(chart, p.signIndex) == house)
          .toList(growable: false);

  static BnnD1BhavaPlacement? placement(AstroChartResult chart, int house) {
    if (house < 1 || house > 12) return null;
    final sign = signForHouse(chart, house);
    final lord = signLords[sign];
    PlanetPosition? pos;
    for (final planet in chart.planets) {
      if (planet.name == lord) { pos = planet; break; }
    }
    if (pos == null) return null;
    return BnnD1BhavaPlacement(house: house, houseSign: sign,
        lordPlanet: lord, lordSign: pos.signIndex,
        lordHouse: houseForSign(chart, pos.signIndex));
  }

  static bool matchesLordPlacement(AstroChartResult chart, BnnD1BhavaRule rule) {
    if (rule.type != 'BHAVA_LORD_PLACEMENT' || !rule.eligible ||
        rule.lordOf != rule.house || rule.lordOccupiesHouse == null) {
      return false;
    }
    final p = placement(chart, rule.house);
    return p != null && p.lordHouse == rule.lordOccupiesHouse;
  }
}
