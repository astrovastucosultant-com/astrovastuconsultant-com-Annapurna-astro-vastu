import 'package:sweph/sweph.dart';

import 'astro_models.dart';
import 'dasha_service.dart';
import 'jamakola_special_service.dart';
import 'kp_event_judgement_service.dart';
import 'kp_service.dart';
import 'tajik_prashna_service.dart';

/// Astronomical/time windows to CHECK, not verified dates on which an
/// individual's event must occur. A single aspect or contact is not a
/// horary promise, and an unverified KP cusp is never treated as a YES.
class PrashnaTimingCandidate {
  const PrashnaTimingCandidate({required this.system, required this.startUtc,
    required this.endUtc, required this.title, required this.evidence,
    required this.limitation});
  final String system;
  final DateTime startUtc;
  final DateTime endUtc;
  final String title;
  final String evidence;
  final String limitation;
}

class PrashnaEventTimingReport {
  const PrashnaEventTimingReport({required this.kp,
    required this.jamakola, required this.tajik, required this.kpTransit, required this.kpSignificators,
    required this.kpDashaAtQuestion, required this.summary,
    required this.crossChecks});
  final List<PrashnaTimingCandidate> kp, jamakola, tajik, kpTransit;
  final List<String> kpSignificators;
  final String kpDashaAtQuestion;
  final String summary;
  final List<String> crossChecks;

  /// Do NOT turn independent indicators into an arbitrary average date.
  bool get hasThreeWayValidatedEventDate => false;
}

class PrashnaEventTimingService {
  static double _norm(double x) => (x % 360 + 360) % 360;
  static double _signed(double x) => (_norm(x + 180) - 180);

  static int? _houseOf(KpStellarPosition p, List<KpStellarPosition> cusps) {
    final v = _norm(p.longitude);
    for (var i=0; i<12; i++) {
      final start=_norm(cusps[i].longitude);
      final arc=_norm(cusps[(i+1)%12].longitude-start);
      if (arc>0 && _norm(v-start)<arc) return i+1;
    }
    return null;
  }

  /// House significations for each period lord: occupant, lord and the
  /// corresponding star-lord's occupation/lordship. Rahu/Ketu proxy agency
  /// remains preliminary until a full KP agent rule checks conjunctions.
  static Map<String,Set<int>> kpHouseSignifications(KpChartDetails chart) {
    final occupants=<String,int>{};
    for (final p in chart.planets) {
      final house=_houseOf(p,chart.cusps);
      if (house!=null) occupants[p.body]=house;
    }
    final result=<String,Set<int>>{};
    for(final p in chart.planets) {
      final signified=<int>{};
      final lords=<String>{p.body,p.starLord};
      for(final lord in lords) {
        final position=occupants[lord];
        if(position!=null)signified.add(position);
        for(var h=1;h<=12;h++) {
          if(chart.cusps[h-1].signLord==lord)signified.add(h);
        }
      }
      result[p.body]=signified;
    }
    return result;
  }

  /// Candidate DBA windows begin at the question's Moon, not at a fictional
  /// natal epoch. A period must have a main-house link and an additional
  /// supporting house link across its Maha/Antar/Pratyantar lords.
  static List<PrashnaTimingCandidate> kpDashaWindows({
    required KpHoraryEventResult observation,
    required DateTime horizonStartUtc,
    int horizonDays=365,
    int limit=8,
  }) {
    final event=observation.event;
    if(event.mainHouse==null)return const [];
    final moon=observation.chart.planets.where((p)=>p.body=='Moon').firstOrNull;
    if(moon==null)return const [];
    final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'KP horary Moon',
      planets:<PlanetPosition>[PlanetPosition(name:'Moon',shortName:'Mo',
        longitude:moon.longitude,latitude:0,speed:0)]);
    final periods=DashaService.system(kind:DashaSystemKind.vimshottari,
      chart:chart,birthDateTime:observation.questionUtc.toUtc());
    final significations=kpHouseSignifications(observation.chart);
    final result=<PrashnaTimingCandidate>[];
    final start=horizonStartUtc.toUtc();
    final end=start.add(Duration(days:horizonDays));
    for(final maha in periods.mahadashas) {
      if(!maha.end.isAfter(start)||!maha.start.isBefore(end))continue;
      for(final antar in DashaService.subPeriodsFor(periods,maha)) {
        if(!antar.end.isAfter(start)||!antar.start.isBefore(end))continue;
        for(final pratyantar in DashaService.subPeriodsFor(periods,antar)) {
          if(!pratyantar.end.isAfter(start)||!pratyantar.start.isBefore(end))continue;
          final names=<String>[maha.lord,antar.lord,pratyantar.lord];
          final linked=<int>{};
          var lordHits=0;
          for(final name in names) {
            final v=significations[name]??const <int>{};
            if(v.contains(event.mainHouse) ||
              event.supporting.any(v.contains))lordHits++;
            linked.addAll(v);
          }
          final secondary=event.supporting.isEmpty ||
            event.supporting.any(linked.contains);
          if(!linked.contains(event.mainHouse)||!secondary||lordHits<2)continue;
          final windowStart=pratyantar.start.isAfter(start)?pratyantar.start:start;
          final windowEnd=pratyantar.end.isBefore(end)?pratyantar.end:end;
          final matching=<int>{event.mainHouse!,...event.supporting}
            .intersection(linked).toList()..sort();
          result.add(PrashnaTimingCandidate(system:'KP',
            startUtc:windowStart,endUtc:windowEnd,
            title:'${maha.lord} / ${antar.lord} / ${pratyantar.lord}',
            evidence:'వింశోత్తరి DBA; సంబంధిత భావాలు: ${matching.join(', ')}. '
              'ప్రశ్న చంద్రుని నక్షత్ర శేషం నుంచి గణించబడింది.',
            limitation:'ఇది అభ్యర్థి దశా కాలం మాత్రమే. CSL పూర్తి Promise, '
              'Rahu/Ketu agency, విరుద్ధ భావాలు, సూర్య/చంద్ర గోచారాల '
              'ధృవీకరణ లేకుండా సంఘటన తేదీగా పరిగణించరాదు.'));
          if(result.length>=limit)return List.unmodifiable(result);
        }
      }
    }
    return List.unmodifiable(result);
  }

  /// Day-level KP transit corroboration within the candidate DBA windows.
  /// The Moon and Sun are sampled at LOCAL noon on each civil date. This
  /// checks candidate days, NOT an exact instant or a guaranteed event date.
  static List<PrashnaTimingCandidate> kpTransitDays({
    required KpHoraryEventResult observation,
    required List<PrashnaTimingCandidate> periodWindows,
    required DateTime questionUtc,
    required double timezoneOffsetHours,
    int horizonDays=240,
    int limit=6,
  }) {
    if(periodWindows.isEmpty)return const [];
    final all=kpHouseSignifications(observation.chart);
    final targets=<int>{if(observation.event.mainHouse!=null)
      observation.event.mainHouse!,...observation.event.supporting};
    final eligible=<String>{
      for(final e in all.entries)
        if(e.value.intersection(targets).isNotEmpty)e.key,
    };
    if(eligible.isEmpty)return const [];
    final offset=Duration(minutes:(timezoneOffsetHours*60).round());
    final local=questionUtc.toUtc().add(offset);
    final localBase=DateTime.utc(local.year,local.month,local.day);
    final matches=<PrashnaTimingCandidate>[];
    Sweph.swe_set_sid_mode(SiderealMode.SE_SIDM_KRISHNAMURTI,
      SiderealModeFlag.SE_SIDBIT_NONE,0.0,0.0);
    final flags=SwephFlag.SEFLG_MOSEPH|SwephFlag.SEFLG_SIDEREAL;
    for(var day=0;day<horizonDays;day++) {
      final localStart=localBase.add(Duration(days:day));
      final utcStart=localStart.subtract(offset);
      final utcEnd=utcStart.add(const Duration(days:1));
      if(!periodWindows.any((w)=>w.endUtc.isAfter(utcStart) &&
        w.startUtc.isBefore(utcEnd))) continue;
      final noonUtc=utcStart.add(const Duration(hours:12));
      final jd=Sweph.swe_julday(noonUtc.year,noonUtc.month,noonUtc.day,
        noonUtc.hour+noonUtc.minute/60.0,CalendarType.SE_GREG_CAL);
      final moon=Sweph.swe_calc_ut(jd,HeavenlyBody.SE_MOON,flags).longitude;
      final sun=Sweph.swe_calc_ut(jd,HeavenlyBody.SE_SUN,flags).longitude;
      if(!moon.isFinite||!sun.isFinite)continue;
      final mp=KpService.forLongitude('Transit Moon',moon);
      final sp=KpService.forLongitude('Transit Sun',sun);
      final moonStar=eligible.contains(mp.starLord);
      final moonSub=eligible.contains(mp.subLord);
      final sunStar=eligible.contains(sp.starLord);
      if(!moonStar || !(moonSub||sunStar))continue;
      matches.add(PrashnaTimingCandidate(system:'KP Transit',
        startUtc:utcStart,endUtc:utcEnd,
        title:'చంద్ర నక్షత్రం ${mp.starLord} / Sub ${mp.subLord}',
        evidence:'స్థానిక మధ్యాహ్నం గ్రహస్ఫుటం: చంద్ర Star=${mp.starLord}, '
          'Sub=${mp.subLord}; సూర్య Star=${sp.starLord}. '
          'సంబంధిత KP significatorsతో గోచార పోలిక.',
        limitation:'స్థానిక మధ్యాహ్నం ఒక నమూనా మాత్రమే; '
          'నక్షత్ర/సబ్ మార్పు సమయాలు, DBA పూర్తి వాగ్దానం, '
          'Ruling Planets పరిశీలించకుండానే ఈ రోజును సంఘటన తేదీగా ప్రకటించకూడదు.'));
      if(matches.length>=limit)break;
    }
    return List.unmodifiable(matches);
  }

  static String kpCurrentDasha(KpHoraryEventResult observation) {
    final moon=observation.chart.planets.where((p)=>p.body=='Moon').firstOrNull;
    if(moon==null)return 'KP ప్రశ్న చంద్రుడి స్ఫుటం లేదు';
    final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'KP horary Moon',
      planets:[PlanetPosition(name:'Moon',shortName:'Mo',
        longitude:moon.longitude,latitude:0,speed:0)]);
    final periods=DashaService.system(kind:DashaSystemKind.vimshottari,
      chart:chart,birthDateTime:observation.questionUtc.toUtc());
    final current=DashaService.pathAt(periods,observation.questionUtc.toUtc());
    if(current==null)return 'ప్రశ్న సమయ DBA లభించలేదు';
    return '${current.mahadasha.lord} / ${current.antardasha.lord} / '
      '${current.pratyantardasha.lord}';
  }

  static List<PrashnaTimingCandidate> jamaContactWindows({
    required JamakolaSpecialResult jama, required DateTime questionUtc}) {
    return List.unmodifiable([
      for(final contact in jama.jamaContacts)
        if(contact.minutesFromJudgement >= 0)
          PrashnaTimingCandidate(system:'Jamakola',
            startUtc:questionUtc.toUtc().add(Duration(seconds:
              (contact.minutesFromJudgement*60).round())),
            endUtc:questionUtc.toUtc().add(Duration(seconds:
              (contact.minutesFromJudgement*60).round())),
            title:'Jama ${contact.planet} – ఉదయం కోణ-సంపర్కం',
            evidence:'ప్రశ్న సమయం నుంచి '
              '${contact.minutesFromJudgement.toStringAsFixed(2)} నిమిషాలు; '
              'జామ ${jama.jamam} (${jama.isNight?'రాత్రి':'పగలు'}).',
            limitation:'ఇది కేవలం జామ వలయం–ఉదయం గణిత సంపర్కం. '
              'కవిప్పు, ఆరూఢం, అంశ నియమాలు ధృవీకరించకపోతే '
              'ఇది సంఘటన జరుగుతుందని తెలిపే సమయం కాదు.'),
    ]);
  }

  static HeavenlyBody? _body(String name) => switch(name){
    'Sun'=>HeavenlyBody.SE_SUN,
    'Moon'=>HeavenlyBody.SE_MOON,
    'Mars'=>HeavenlyBody.SE_MARS,
    'Mercury'=>HeavenlyBody.SE_MERCURY,
    'Jupiter'=>HeavenlyBody.SE_JUPITER,
    'Venus'=>HeavenlyBody.SE_VENUS,
    'Saturn'=>HeavenlyBody.SE_SATURN,
    _=>null,
  };

  /// Actual two-body ephemeris crossing (not angle / daily speed converted
  /// directly into an event date). Search is bounded to fourteen days.
  /// The first exact mathematical aspect can be a Tajika *candidate contact*,
  /// but Radda / Nakta / Kamboola and reception are not inferred here.
  static List<PrashnaTimingCandidate> tajikAspectWindows({
    required TajikPrashnaObservation observation,
    required AstroChartResult questionChart,
    required DateTime questionUtc,
  }) {
    if(observation.status!='applying')return const [];
    final first=_body(observation.lagnaLord);
    final second=_body(observation.questionLord);
    if(first==null||second==null)return const [];
    final p=questionChart.planets.where(
      (e)=>e.name==observation.lagnaLord).firstOrNull;
    final q=questionChart.planets.where(
      (e)=>e.name==observation.questionLord).firstOrNull;
    if(p==null||q==null)return const [];
    final degree=observation.aspectName.contains('180')?180.0:
      observation.aspectName.contains('120')?120.0:
      observation.aspectName.contains('90')?90.0:
      observation.aspectName.contains('60')?60.0:0.0;
    final rawDiff=_norm(p.longitude-q.longitude);
    final candidates=degree==0||degree==180?
      <double>[degree]:<double>[degree,360.0-degree];
    final target=candidates.reduce((a,b)=>
      _signed(rawDiff-a).abs()<=_signed(rawDiff-b).abs()?a:b);
    double residual(double days){
      final jd=questionChart.julianDay+days;
      final flags=SwephFlag.SEFLG_MOSEPH;
      // Aspect difference is independent of the common ayanamsa;
      // using tropical positions here avoids mutating the sidereal mode.
      final x=Sweph.swe_calc_ut(jd,first,flags).longitude;
      final y=Sweph.swe_calc_ut(jd,second,flags).longitude;
      return _signed(x-y-target);
    }
    var previous=residual(0);
    const increment=0.25; // six-hour sampling
    for(var i=1;i<=56;i++){
      final nextDay=i*increment;
      final next=residual(nextDay);
      if(previous.isFinite && next.isFinite &&
          previous.abs()<35 && next.abs()<35 &&
          (previous==0 || previous.isNegative!=next.isNegative)) {
        var left=nextDay-increment, right=nextDay;
        final initialSign=previous.isNegative;
        for(var step=0;step<22;step++){
          final mid=(left+right)/2;
          if(residual(mid).isNegative==initialSign)left=mid;
          else right=mid;
        }
        final at=questionUtc.toUtc().add(Duration(seconds:
          (((left+right)/2)*86400).round()));
        return [PrashnaTimingCandidate(system:'Tajik',startUtc:at,
          endUtc:at,title:'${observation.lagnaLord}–'
            '${observation.questionLord}: ${observation.aspectName}',
          evidence:'నిజమైన గ్రహ స్ఫుటాలతో తదుపరి ఖచ్చిత కోణ-సంపర్కం '
            '(14 రోజుల శోధన; సుమారు నిమిషం ఖచ్చితత్వం).',
          limitation:'ఇది గ్రహాల Aspect perfection సమయం మాత్రమే; '
            'Radda, Nakta, Kamboola, ఇతర 16 తాజిక యోగాలు, '
            'ప్రశ్న ఫలిత షరతులు లేకుండా సంఘటన తేదీ కాదు.')];
      }
      previous=next;
    }
    return const [];
  }

  static PrashnaEventTimingReport calculate({
    required KpHoraryEventResult kpTime,
    required KpHoraryEventResult? kpNumber,
    required JamakolaSpecialResult jama,
    required TajikPrashnaObservation tajik,
    required AstroChartResult questionChart,
    required DateTime questionUtc,
    required double timezoneOffsetHours,
  }) {
    final chart=kpNumber??kpTime;
    final significations=kpHouseSignifications(chart.chart);
    final targets=<int>{if(chart.event.mainHouse!=null) chart.event.mainHouse!,
      ...chart.event.supporting};
    final lordNames=<String>[
      for(final entry in significations.entries)
        if(entry.value.intersection(targets).isNotEmpty)entry.key,
    ];
    final kpWindows=kpDashaWindows(observation:chart,
      horizonStartUtc:questionUtc,horizonDays:365);
    final kpTransit=kpTransitDays(observation:chart,
      periodWindows:kpWindows,questionUtc:questionUtc,
      timezoneOffsetHours:timezoneOffsetHours);
    final jamaWindows=jamaContactWindows(jama:jama,questionUtc:questionUtc);
    final tajikWindows=tajikAspectWindows(observation:tajik,
      questionChart:questionChart,questionUtc:questionUtc);
    final comparisons=<String>[];
    for(final t in tajikWindows){
      final kpCoincidence=kpWindows.any((k)=>
        !t.startUtc.isBefore(k.startUtc) && t.startUtc.isBefore(k.endUtc));
      if(kpCoincidence){
        comparisons.add('KP అభ్యర్థి DBA కాలంలో Tajik దృష్టి సంపర్కం '
          'ఉంది (${t.startUtc.toIso8601String()} UTC). ఇది రెండు సమయ '
          'గణనల పోలిక మాత్రమే, సంఘటన హామీ కాదు.');
      }
    }
    if(comparisons.isEmpty){
      comparisons.add('ఈ పరిధిలో KP DBA మరియు Tajik ఖచ్చిత దృష్టి '
        'సంపర్కానికి సమయ ఏకీభావం నిర్ధారణ కాలేదు. ఇది సంఘటన '
        'జరగదనే తీర్పు కాదు.');
    }
    comparisons.add('Jamakola జామ సంపర్కం ప్రశ్నకు సమీపంలోని '
      'నిమిషాలను మాత్రమే సూచిస్తుంది; దీర్ఘకాల KP DBA/Tajik '
      'సంపర్కాలకు నేరుగా సమానం కాదు.');
    return PrashnaEventTimingReport(
      kp:kpWindows,kpTransit:kpTransit,
      jamakola:jamaWindows,tajik:tajikWindows,
      kpSignificators:lordNames,
      crossChecks:List.unmodifiable(comparisons),
      kpDashaAtQuestion:kpCurrentDasha(chart),
      summary:'మూడు పద్ధతుల్లో Event Timing గణిత సంపర్కాలు మరియు KP '
        'అభ్యర్థి DBA కాలాలను లెక్కించాం. కానీ ప్రశ్న ఫలితానికి '
        'పూర్తి KP Promise/Denial, పూర్తి తాజిక యోగాలు, మూల జామకోళ '
        'సమయ నియమాలు ఇంకా ధృవీకరణ కావాలి. వీటిని ఒక తేదీగా '
        'సగటు చేయడం లేదా సంఘటన హామీగా ప్రకటించడం సరైంది కాదు.');
  }
}
