import 'astro_models.dart';
import 'bnn_d1_bhava_rules.dart';

/// Computed natal evidence for the 336 D1 reference entries. This is a
/// traditional interpretive layer, not a substitute for a sourced event IF.
/// Source-verified natal events remain handled by the separate BNN 462 engine.
class BnnBhavaReading {
  final String result;
  final String evidence;
  final String ifThen;
  final String basis;
  final String level;
  final bool applied;
  const BnnBhavaReading({required this.result, required this.evidence,
    required this.ifThen, required this.basis, required this.level,
    this.applied = true});
}

class BnnD1BhavaInterpreter {
  static const _benefics = {'Jupiter', 'Venus', 'Mercury'};
  static const _malefics = {'Saturn', 'Mars', 'Rahu', 'Ketu'};
  static const _starLords = [
    'Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury',
  ];
  static const _exaltSigns = <String,int>{
    'Sun':0,'Moon':1,'Mars':9,'Mercury':5,'Jupiter':3,
    'Venus':11,'Saturn':6,
  };
  static const _debilSigns = <String,int>{
    'Sun':6,'Moon':7,'Mars':3,'Mercury':11,'Jupiter':9,
    'Venus':5,'Saturn':0,
  };

  static PlanetPosition? _planet(AstroChartResult chart, String name) {
    for (final p in chart.planets) {
      if (p.name == name) return p;
    }
    return null;
  }

  static String nakshatraLord(PlanetPosition p) {
    final longitude = (p.longitude % 360 + 360) % 360;
    final index = (longitude / (40.0 / 3)).floor() % 27;
    return _starLords[index % 9];
  }

  static String _name(String english) =>
      BnnD1BhavaGeometry.planetTelugu[english] ?? english;

  static String _where(PlanetPosition p) =>
      '${_name(p.name)} (${BnnD1BhavaGeometry.signs[p.signIndex]} '
      '${p.degreesInSign.toStringAsFixed(1)}°)';

  /// Classical Parasara graha aspects, not BNN sign links. Rahu/Ketu here
  /// count only by occupancy; node-specific BNN links remain elsewhere.
  static bool aspectsSign(PlanetPosition source, int targetSign) {
    if (source.name == 'Rahu' || source.name == 'Ketu') return false;
    final position = ((targetSign - source.signIndex + 12) % 12) + 1;
    if (position == 7) return true;
    if (source.name == 'Mars' && (position == 4 || position == 8)) return true;
    if (source.name == 'Jupiter' && (position == 5 || position == 9)) return true;
    if (source.name == 'Saturn' && (position == 3 || position == 10)) return true;
    return false;
  }

  static List<PlanetPosition> linkedToSign(AstroChartResult chart, int sign,
      {String? exclude}) => chart.planets.where((p) =>
        p.name != exclude &&
        (p.signIndex == sign || aspectsSign(p, sign))).toList(growable: false);

  static List<PlanetPosition> _unique(Iterable<PlanetPosition> positions) {
    final found = <String,PlanetPosition>{};
    for (final p in positions) { found[p.name] = p; }
    return found.values.toList(growable: false);
  }

  static bool _strong(PlanetPosition lord) =>
      BnnD1BhavaGeometry.signLords[lord.signIndex] == lord.name ||
      _exaltSigns[lord.name] == lord.signIndex;

  static bool _weak(PlanetPosition lord) =>
      _debilSigns[lord.name] == lord.signIndex;

  /// Evidence includes classical contacts to the bhava and lord; conjunction
  /// is not the same as an aspect. Names and local degrees are always shown.
  static _HouseContext _context(AstroChartResult chart, int house) {
    final placement = BnnD1BhavaGeometry.placement(chart, house);
    if (placement == null) return _HouseContext.empty(house);
    final lord = _planet(chart, placement.lordPlanet)!;
    final houseSign = placement.houseSign;
    final inHouse = BnnD1BhavaGeometry.planetsInHouse(chart, house);
    final houseContacts = linkedToSign(chart, houseSign);
    final lordContacts = linkedToSign(chart, placement.lordSign,
        exclude: placement.lordPlanet);
    final allContacts = _unique([...houseContacts,...lordContacts]);
    final beneficContacts = allContacts.where((p) => _benefics.contains(p.name))
        .toList(growable: false);
    final maleficContacts = allContacts.where((p) => _malefics.contains(p.name))
        .toList(growable: false);
    final starName = nakshatraLord(lord);
    final star = _planet(chart, starName);
    int score = beneficContacts.length - maleficContacts.length;
    if (_strong(lord)) score += 2;
    if (_weak(lord)) score -= 2;
    if (star != null && _benefics.contains(star.name)) score++;
    if (star != null && _malefics.contains(star.name)) score--;
    // This score orders traditional *indicators*. It is not a probability.
    final level = score >= 2 ? 'సహాయక' : score <= -2 ? 'ఆటంక' : 'మిశ్ర';
    return _HouseContext(house, placement, lord, inHouse, houseContacts,
      lordContacts, beneficContacts, maleficContacts, star, level);
  }

  static BnnBhavaReading lordReading(AstroChartResult chart, int house) {
    final c = _context(chart, house);
    if (c.lord == null || c.placement == null) {
      return const BnnBhavaReading(result:'గ్రహస్థాన డేటా అందుబాటులో లేదు.',
        evidence:'', ifThen:'', basis:'D1 జన్మచక్రం', level:'none');
    }
    final p = c.placement!;
    final lord = c.lord!;
    final domain = _domains[house - 1];
    final other = _domains[p.lordHouse - 1];
    final relation = p.lordHouse == house ?
        '$houseవ భావాధిపతి తన భావంలోనే ఉండటం వల్ల $domain అంశాలకు స్వస్థాన సంబంధం ఉంది.' :
        '$houseవ భావంలోని $domain అంశాలు ${p.lordHouse}వ భావంలోని $other అంశాలతో అనుసంధానమయ్యాయి.';
    final result = '$relation ${_tone(c.level)}';
    return BnnBhavaReading(result:result, evidence:_evidence(c),
      ifThen:'IF: $houseవ భావాధిపతి ${_name(lord.name)} '
        '${p.lordHouse}వ భావంలో ఉన్నారు; అక్కడి శుభ/పాప సంబంధాలను '
        'గణించాం. THEN: $relation',
      basis:'సంప్రదాయ D1 భావాధిపతి–స్థాన ఫలిత విస్తరణ; నిర్దిష్ట గ్రంథపుట ధృవీకరణ లేదు.',
      level:c.level);
  }

  static BnnBhavaReading topicReading(AstroChartResult chart,
      BnnD1BhavaRule rule) {
    final c = _context(chart, rule.house);
    if (c.lord == null || c.placement == null) {
      return const BnnBhavaReading(result:'గ్రహస్థాన డేటా అందుబాటులో లేదు.',
        evidence:'', ifThen:'', basis:'D1 జన్మచక్రం', level:'none');
    }
    final linked = _specificKaraka(rule.topic,rule.house);
    final extra = linked.map((n) => _planet(chart,n)).whereType<PlanetPosition>()
        .where((p) => p.signIndex == c.placement!.houseSign ||
            p.signIndex == c.placement!.lordSign ||
            aspectsSign(p, c.placement!.houseSign) ||
            aspectsSign(p, c.placement!.lordSign)).toList(growable:false);
    final found = _unique(extra);
    final related = _relatedHouses(rule.topic,rule.house);
    final linkedHouses = <String>[];
    for (final otherHouse in related) {
      final other = BnnD1BhavaGeometry.placement(chart,otherHouse);
      if (other == null) continue;
      final otherLord = _planet(chart,other.lordPlanet);
      if (otherLord == null) continue;
      if (otherLord.name == c.lord!.name ||
          otherLord.signIndex == c.lord!.signIndex ||
          aspectsSign(otherLord,c.lord!.signIndex) ||
          aspectsSign(c.lord!,otherLord.signIndex)) {
        linkedHouses.add('$otherHouseవ అధిపతి ${_where(otherLord)}');
      }
    }
    // Do not call a neutral/empty contact picture a "mixed" planetary yoga.
    // Keep the source-derived topic name but attach *only* observed relations.
    final applied = found.isNotEmpty || linkedHouses.isNotEmpty;
    final tone = applied ? c.level : 'ప్రత్యేక సంబంధం లేదు';
    final karakaPart = found.isEmpty ?
      'ఈ అంశపు కారకగ్రహానికి భావం/అధిపతితో ప్రత్యక్ష స్థితి లేదా దృష్టి సంబంధం లేదు.' :
      'సరిపోయిన కారకగ్రహం: ${found.map(_where).join(', ')}.';
    final relatedDetail = linkedHouses.isEmpty ?
      'అదనపు భావాధిపతి సంబంధం లేదు.' :
      'సరిపోయిన అనుబంధ భావాధిపతులు: ${linkedHouses.join(', ')}.';
    final evidence = '${_evidence(c)}\n$karakaPart\n$relatedDetail';
    final primary = found.isNotEmpty
        ? 'కారకగ్రహం ${found.map(_where).join(', ')} సంబంధించింది'
        : linkedHouses.isNotEmpty
            ? '${linkedHouses.join(', ')} సంబంధం ఉంది'
            : 'ప్రత్యేక కారక/భావాధిపతి సంబంధం లేదు';
    final verdict = switch (c.level) {
      'సహాయక' => 'అనుకూల సంబంధ సూచన ఉంది',
      'ఆటంక' => 'ఆటంక సంబంధ సూచన ఉంది',
      _ => 'శుభ/పాప గ్రహాల స్పష్టమైన ఆధిక్యం లేదు',
    };
    // The 144 Siddhanti topic headings are conceptual extensions, not 144
    // independent authenticated source IFs. Never generate a definite
    // marriage, disease, wealth, or family event from this contact alone.
    final result = applied
        ? '${rule.topic}: $primary; $verdict.'
        : '${rule.topic}: ఈ అంశానికి ప్రత్యేక గ్రహసంబంధం లేదు.';
    final matchingIf = found.isNotEmpty
        ? 'కారకగ్రహం భావం/అధిపతితో కలయిక లేదా దృష్టిలో ఉంది'
        : linkedHouses.isNotEmpty
            ? 'అనుబంధ భావాధిపతితో స్థితి/దృష్టి సంబంధం ఉంది'
            : 'ప్రత్యేక కారక/అనుబంధ భావాధిపతి సంబంధం లేదు';
    return BnnBhavaReading(result:result,evidence:evidence,
      ifThen:'IF: $matchingIf; ${rule.house}వ భావాధిపతి '
        '${_name(c.lord!.name)} ${c.placement!.lordHouse}వ D1 భావంలో. '
        'THEN: $verdict.',
      basis:'భావకారకత్వం ఆధారంగా రూపొందించిన విశ్లేషణ; '
        'గురువుగారి మాటలను యథాతథంగా ఉటంకించిన ప్రత్యేక నియమం కాదు.',
      level:tone, applied:applied);
  }

  static BnnBhavaReading? modifierReading(AstroChartResult chart,
      BnnD1BhavaRule rule) {
    final c = _context(chart, rule.house);
    if (c.lord == null || c.placement == null) return null;
    final key = rule.id.split('-').last;
    switch(key) {
      case 'SUPPORT':
        if (c.beneficContacts.isEmpty && !_strong(c.lord!)) return null;
        return BnnBhavaReading(
          result:'${rule.house}వ భావానికి శుభసంబంధం కనిపిస్తోంది. '
            'ఆ భావ అంశాలకు సంప్రదాయ సహాయక సూచన.',
          evidence:_evidence(c),
          ifThen:'IF: భావానికి/భావాధిపతికి శుభగ్రహ స్థితి లేదా '
            'పరాశర దృష్టి, లేదా భావాధిపతి స్వ/ఉచ్చస్థితి ఉంది. '
            'THEN: సహాయక సంబంధం.',
          basis:'భావవ్యాప్తి శుభసంబంధ విశ్లేషణ (మూల గ్రంథపుట నిర్ధారణ లేదు).',
          level:'సహాయక');
      case 'CHALLENGE':
        if (c.maleficContacts.isEmpty && !_weak(c.lord!)) return null;
        return BnnBhavaReading(
          result:'${rule.house}వ భావానికి పాపసంబంధం కనిపిస్తోంది. '
            'దీన్ని ఆలస్యం/ఆటంకానికి సంబంధించిన సంప్రదాయ సూచనగా తీసుకోవాలి; '
            'ఒక సంఘటన జరిగినట్లు కాదు.',
          evidence:_evidence(c),
          ifThen:'IF: భావానికి/భావాధిపతికి పాపగ్రహ స్థితి/దృష్టి '
            'లేదా అధిపతి నీచస్థితి ఉంది. THEN: ఆటంక సంబంధం.',
          basis:'భావవ్యాప్తి పాపసంబంధ విశ్లేషణ (మూల గ్రంథపుట నిర్ధారణ లేదు).',
          level:'ఆటంక');
      case 'NAKSHATRA':
        if (c.star == null) return null;
        return BnnBhavaReading(
          result:'${_name(c.lord!.name)} ${_name(c.star!.name)} '
            'నక్షత్రంలో ఉండటం వల్ల ${rule.house}వ భావ అంశాల్లో '
            '${_name(c.star!.name)} కారకత్వాన్ని అదనంగా అనుసంధానించవచ్చు.',
          evidence:_evidence(c),
          ifThen:'IF: భావాధిపతి యొక్క సైడీరియల్ నక్షత్రాధిపతి '
            '${_name(c.star!.name)}. THEN: ఆ గ్రహ కారకత్వ సంబంధం చేర్చబడింది.',
          basis:'తంగపాండియన్ క్లాస్‌లో చెప్పిన గ్రహం→నక్షత్రాధిపతి '
            'పరిశీలన పద్ధతికి గణిత విస్తరణ; వ్యక్తిగత సంఘటన నిర్ధారణ కాదు.',
          level:c.level);
      case 'RESCUE':
        if (c.maleficContacts.isEmpty || c.beneficContacts.isEmpty) return null;
        // Do not claim a sequential rescue just because two planets happen to
        // aspect the same sign. Require an actual directed local-degree chain.
        final rescue = _degreeRescue(c);
        if (rescue == null) return null;
        return BnnBhavaReading(
          result:'పాపసంబంధం తరువాత శుభగ్రహ సంబంధం ఉన్న క్రమం '
            'గణించబడింది. ఆటంక ఫలితం పూర్తిగా నిర్ణయించకుండా '
            'ఉపశమన సూచనను కూడా కలపాలి.',
          evidence:'${_evidence(c)}\n$rescue',
          ifThen:'IF: అదే రాశి/త్రికోణ గ్రహాల్లో సమీప డిగ్రీల '
            'పాపగ్రహం తరువాత శుభగ్రహం ఉంది. THEN: ఫలిత మార్పు సూచన.',
          basis:'BNN క్లాస్ డిగ్రీ క్రమం + శుభగ్రహ ఉపశమన సూచన; '
            'దీంతో తప్పనిసరి సంఘటన/పరిహారం నిర్ధారించబడదు.',
          level:'మిశ్ర');
    }
    return null;
  }

  /// Direct classroom notes with a specific computable IF. Broad teaching
  /// notes without a testable IF are deliberately not advertised as outcomes.
  static BnnBhavaReading? sourceReading(AstroChartResult chart,
      BnnD1BhavaSourceNote note) {
    final first = BnnD1BhavaGeometry.signForHouse(chart, 1);
    final third = BnnD1BhavaGeometry.placement(chart, 3);
    final sixth = BnnD1BhavaGeometry.placement(chart, 6);
    final ninth = BnnD1BhavaGeometry.placement(chart, 9);
    final twelfth = BnnD1BhavaGeometry.placement(chart, 12);
    final venus = _planet(chart, 'Venus');
    final mars = _planet(chart, 'Mars');
    final jupiter = _planet(chart, 'Jupiter');
    final mercury = _planet(chart, 'Mercury');
    final lagnaContacts = linkedToSign(chart, first);
    final venusMars = venus != null && mars != null &&
        aspectsSign(venus, first) && aspectsSign(mars, first);
    bool applicable;
    String predicate;
    switch (note.id) {
      case 'BNN-FIRST-BHAVA-P5-009':
      case 'BNN-FIRST-BHAVA-P5-012':
        applicable = third?.lordHouse == 1;
        predicate = 'మూడవ భావాధిపతి లగ్నంలో ఉన్నారు';
        break;
      case 'BNN-FIRST-BHAVA-P5-006':
        applicable = jupiter != null && mars != null && mercury != null &&
            lagnaContacts.any((p) => p.name == 'Jupiter') &&
            lagnaContacts.any((p) => p.name == 'Mars') &&
            lagnaContacts.any((p) => p.name == 'Mercury');
        predicate = 'లగ్నంతో గురు, కుజ, బుధ మూడింటికీ గ్రహసంబంధం ఉంది';
        break;
      case 'BNN-FIRST-BHAVA-P5-007':
        applicable = lagnaContacts.any((p) => _benefics.contains(p.name)) &&
            lagnaContacts.any((p) => _malefics.contains(p.name));
        predicate = 'లగ్నానికి శుభ–పాప గ్రహాలు రెండూ సంబంధించాయి';
        break;
      case 'BNN-FIRST-BHAVA-P4-001':
      case 'BNN-FIRST-BHAVA-P4-003':
        applicable = venusMars;
        predicate = 'శుక్రుడు, కుజుడు ఇద్దరి పరాశర దృష్టి లగ్నానికి ఉంది';
        break;
      case 'BNN-FIRST-BHAVA-P4-002':
        final twelfthPlanet = twelfth == null ? null : _planet(chart, twelfth.lordPlanet);
        applicable = sixth?.lordHouse == 12 &&
            twelfthPlanet != null && aspectsSign(twelfthPlanet, first);
        predicate = '6వ అధిపతి 12వ భావంలో, 12వ అధిపతి లగ్నాన్ని చూస్తున్నారు';
        break;
      case 'BNN-FIRST-BHAVA-P4-004':
        final thirdPlanet = third == null ? null : _planet(chart, third.lordPlanet);
        final ninthPlanet = ninth == null ? null : _planet(chart, ninth.lordPlanet);
        applicable = thirdPlanet != null && ninthPlanet != null &&
            (thirdPlanet.signIndex == ninthPlanet.signIndex ||
            aspectsSign(thirdPlanet, ninthPlanet.signIndex) ||
            aspectsSign(ninthPlanet, thirdPlanet.signIndex));
        predicate = '3వ/9వ భావాధిపతులకు స్థితి లేదా దృష్టి సంబంధం ఉంది';
        break;
      case 'BNN-FIRST-BHAVA-P4-005':
        final ninthPlanet = ninth == null ? null : _planet(chart, ninth.lordPlanet);
        applicable = ninthPlanet != null &&
            (ninthPlanet.signIndex == first || aspectsSign(ninthPlanet, first));
        predicate = '9వ భావాధిపతి లగ్నంలో లేదా లగ్నానికి దృష్టిలో ఉన్నారు';
        break;
      default:
        return null;
    }
    if (!applicable) return null;
    return BnnBhavaReading(
      result:'${note.thenText} ఇది క్లాస్‌లో వివరించిన సంప్రదాయ సూచన; '
        'జరిగిన సంఘటనగా నిర్ధారణ కాదు.',
      evidence:'జాతకంలో సరిపోయిన షరతు: $predicate. '
        'లగ్నం ${BnnD1BhavaGeometry.signs[first]}. '
        '3L: ${third?.lordPlanet ?? '-'} ${third?.lordHouse ?? '-'}వ భావం; '
        '6L: ${sixth?.lordPlanet ?? '-'} ${sixth?.lordHouse ?? '-'}వ భావం.',
      ifThen:'IF: $predicate. THEN: ${note.thenText}',
      basis:'Thangapandian • ${note.source} • మూల ట్రాన్స్‌క్రిప్ట్. '
        'ఈ వీడియో ఉదాహరణ ఆధారంగా IF అనువర్తనం గణించబడింది; '
        'ఇది క్లాస్ వ్యాఖ్యను విస్తరించి వర్తింపజేసిన పరిశీలన. '
        'జరిగిన సంఘటనగా చెప్పరాదు.',
      level:'మూల క్లాస్ IF సరిపోయింది',
    );
  }

  static String? _degreeRescue(_HouseContext c) {
    for (final bad in c.maleficContacts) {
      for (final good in c.beneficContacts) {
        final sameTrine = bad.signIndex % 4 == good.signIndex % 4;
        final separation = (bad.degreesInSign - good.degreesInSign).abs();
        if (sameTrine && good.degreesInSign > bad.degreesInSign && separation <= 5) {
          return 'BNN స్థానిక డిగ్రీ క్రమం: ${_where(bad)} → '
            '${_where(good)}; త్రికోణ సంబంధం, తేడా '
            '${separation.toStringAsFixed(1)}°. ఇది జన్మస్థితి క్రమం మాత్రమే.';
        }
      }
    }
    return null;
  }

  static String _evidence(_HouseContext c) {
    if (c.lord == null || c.placement == null) return '';
    final place = c.placement!;
    final star = c.star == null ? 'లభించలేదు' : _where(c.star!);
    final occupants = c.inHouse.isEmpty ? 'గ్రహాలు లేవు' :
        c.inHouse.map(_where).join(', ');
    final positive = c.beneficContacts.isEmpty ? 'లేవు' :
        c.beneficContacts.map(_where).join(', ');
    final negative = c.maleficContacts.isEmpty ? 'లేవు' :
        c.maleficContacts.map(_where).join(', ');
    final dignity = _strong(c.lord!) ? 'స్వ/ఉచ్చ రాశి' :
        _weak(c.lord!) ? 'నీచ రాశి' : 'సాధారణ రాశి స్థితి';
    return '${c.house}వ భావం: ${BnnD1BhavaGeometry.signs[place.houseSign]}; '
      'అధిపతి: ${_where(c.lord!)} (${place.lordHouse}వ భావం; $dignity).\n'
      'ఈ భావంలోని గ్రహాలు: $occupants.\n'
      'శుభ గ్రహసంబంధాలు: $positive.\n'
      'పాప గ్రహసంబంధాలు: $negative.\n'
      'అధిపతి నక్షత్రాధిపతి: ${_name(nakshatraLord(c.lord!))} ($star).';
  }

  static const _domains = [
    'లగ్నం/వ్యక్తిత్వం','కుటుంబం/ధనం','తోబుట్టువులు/ప్రయత్నం',
    'తల్లి/ఇల్లు/ఆస్తి','సంతానం/విద్య/ప్రేమ','సేవ/రుణం/పోటీ',
    'వివాహం/భాగస్వామ్యం','ఆకస్మిక మార్పు/వారసత్వం',
    'భాగ్యం/గురువు/తండ్రి','వృత్తి/పదవి/వ్యాపారం',
    'లాభాలు/పెద్ద సోదరులు','వ్యయం/విదేశం/విశ్రాంతి',
  ];

  static String _tone(String level) => switch(level) {
    'సహాయక' => 'శుభసంబంధాలు ఎక్కువగా ఉండటం వల్ల అనుకూలతకు బలం ఉంది.',
    'ఆటంక' => 'పాపసంబంధాలు ఎక్కువగా ఉండటం వల్ల ఆటంకం లేదా ఆలస్యానికి సూచన ఉంది.',
    _ => 'శుభ/పాప గ్రహాల ఆధిక్యం స్పష్టంగా లేదు.',
  };

  // Source catalogue supplies 144 topic names but *no specific topic IFs*.
  // Interpret each topic with computed contacts; never attribute these
  // sentences to a book page or claim a definite medical/life event.
  static String _topicPassage(String topic, int house, String level) {
    final phrase = _topicPhrases['$house:$topic'] ?? _topicPhrases[topic] ??
      '$topic అంశంపై ${_domains[house-1]} భావ సంబంధాలు ప్రభావం చూపుతున్నాయి.';
    return '$phrase ${level == 'సహాయక' ? 'ఈ జాతకంలో అనుకూల గ్రహ సంబంధం ఆధిక్యంలో ఉంది.' :
      level == 'ఆటంక' ? 'ఈ జాతకంలో నిరోధక గ్రహ సంబంధం ఆధిక్యంలో ఉంది.' :
      'ఈ జాతకంలో శుభ/పాప ఆధిక్యం స్పష్టంగా లేదు.'}';
  }

  static const _topicPhrases = <String,String>{
    'శరీర నిర్మాణం':'శారీరక దారుఢ్యం, శరీర స్వరూపంపై లగ్న ప్రభావం ఉంది.',
    'ఆరోగ్య స్వభావం':'శారీరక చురుకుదనం, అలసట వంటి సాధారణ ధోరణులు లగ్న సంబంధంతో ముడిపడ్డాయి.',
    'వ్యక్తిత్వం':'వ్యక్తిత్వం, ఆత్మవిశ్వాసం, స్పందించే తీరుపై లగ్నాధిపతి ప్రభావం ఉంది.',
    'ప్రవర్తనలో మార్పు':'ప్రవర్తనలో స్థిరత్వం లేదా హెచ్చుతగ్గుల సూచనలకు గ్రహసంబంధాలు ఆధారం.',
    'సామాజిక స్థాయి':'సామాజిక గుర్తింపు, వ్యక్తిగత ప్రతిష్ఠకు లగ్న సంబంధం ఉంది.',
    'యోగ ఫల అనుభవ సామర్థ్యం':'లగ్నబలం ఇతర యోగాలను అనుభవించే అంశానికి సహాయక ఆధారం.',
    'స్వీయప్రయత్నం':'స్వయంకృషి, పనిలో ముందడుగు వేయడం వ్యక్తిగతంగా ప్రాధాన్యం పొందుతుంది.',
    'జీవిత దిశ':'వ్యక్తి దృష్టి కేంద్రీకరించే జీవన విషయాలు భావాధిపతి స్థానంతో అనుసంధానమయ్యాయి.',
    'వృత్తి స్థాయి':'వ్యక్తిత్వం మరియు వృత్తి అభివృద్ధి మధ్య సంబంధం ఏర్పడుతోంది.',
    'విదేశీ స్థిరత్వం':'విదేశీ నివాసం లేదా దూర ప్రాంత జీవితం అంశానికి లగ్న సంబంధం కనిపిస్తోంది.',
    'ప్రతిభ':'నైపుణ్యాలను వ్యక్తీకరించే విధానానికి లగ్నాధిపతి సంబంధం ఉంది.',
    'శరీర భాష':'వ్యక్తీకరణ, శరీర భాషకు గ్రహస్వభావాల మిశ్రమం ప్రభావం చూపుతుంది.',
    'కుటుంబ నేపథ్యం':'కుటుంబ మూలాలు, కుటుంబ బాధ్యతలపై ధనభావ సంబంధం కనిపిస్తోంది.',
    'ధనసంచయం':'సంపాదించిన ధనాన్ని నిల్వ చేయగల సామర్థ్యంపై 2వ భావ సంబంధం ఉంది.',
    'ఆదాయ మూలాలు':'సంపాదనలో ఒకటి లేదా ఎక్కువ మార్గాలతో సంబంధం చూపే ధనభావ సూచనలు ఉన్నాయి.',
    'మాటతీరు':'మాట్లాడే ధోరణి, వాక్చాతుర్యం కుటుంబ/ధనభావ గ్రహాలతో ముడిపడ్డాయి.',
    'ఆర్థిక నిర్వహణ':'లెక్కలు, బడ్జెట్, పొదుపు నిర్వహణకు ధనభావ సంబంధం ఉంది.',
    'బ్యాంక్ వ్యవహారాలు':'బ్యాంకింగ్, పత్రాలు, లావాదేవీల నిర్వహణలో గ్రహ సంబంధాలు కనిపిస్తున్నాయి.',
    'ఆహార అలవాట్లు':'ఆహారపు ఇష్టాలు, నియమాలపై రెండవ భావ ప్రభావం ఉంది.',
    'ప్రారంభ విద్య':'బాల్యపు విద్యా నేపథ్యంపై భావాధిపతి సంబంధం ఉంది.',
    'కుటుంబ బాధ్యత':'కుటుంబ పోషణ, బాధ్యతల స్వీకరణకు భావసంబంధం ఉంది.',
    'వివాహానంతర కుటుంబం':'వివాహానంతరం కుటుంబ సంబంధాలపై రెండవ భావ ప్రభావం ఉంది.',
    'భాషా నైపుణ్యం':'భాషల వినియోగం, అభ్యాసానికి వాక్భావ సంబంధం ఉంది.',
    'ఆస్తి నుండి ఆదాయం':'స్థిరాస్తి/కుటుంబ ఆస్తి ఆదాయ మూలంతో సంబంధం కనిపిస్తోంది.',
    'చిన్న తోబుట్టువులు':'చిన్న సోదరులు/సోదరీమణుల అంశంపై మూడవ భావ సంబంధం ఉంది.',
    'ధైర్యం':'సాహసం, ముందడుగు వేయడం, ప్రయత్నంలో ధైర్యం ప్రధాన అంశం.',
    '3:స్వప్రయత్నం':'స్వంత కృషి ద్వారా పనులు పూర్తి చేయడంపై మూడవ భావ సంబంధం ఉంది.',
    'సంగీత ప్రతిభ':'సంగీత అభ్యాసం, వ్యక్తీకరణకు మూడవ భావ/కారక సంబంధం ఉంది.',
    'చేతి నైపుణ్యం':'హస్తకళలు, చేతి పనులు, ప్రాక్టికల్ నైపుణ్యాల అంశం కనిపిస్తోంది.',
    'కమ్యూనికేషన్':'రచన, సమాచార ప్రసారం, సంభాషణలపై మూడవ భావ ప్రభావం ఉంది.',
    'చిన్న ప్రయాణాలు':'తరచూ చేసే చిన్న ప్రయాణాలకు సంబంధిత భావ సూచనలు ఉన్నాయి.',
    'ప్రచారం':'ప్రచారం, ప్రకటన, బహిరంగ సమాచారానికి అనుసంధానం ఉంది.',
    'వ్యాపార ప్రారంభం':'స్వంత ప్రయత్నంతో ప్రారంభించే కార్యకలాపాలకు మూడవ భావ సూచన ఉంది.',
    'సాహిత్యం':'రచన, పుస్తకాలు, సాహిత్య నైపుణ్యాలకు భావ సంబంధం ఉంది.',
    'అభ్యాసం':'పునరావృత సాధన, నిరంతర అభ్యాసం ప్రధాన అంశంగా కనిపిస్తోంది.',
    'తోబుట్టువులతో సహకారం':'సోదరులతో కలిసి పని చేయడం లేదా సహకారం గురించి భావ సూచనలు ఉన్నాయి.',
    'తల్లి స్వభావం':'తల్లి స్వభావానికి నాల్గవ భావం, చంద్ర కారకత్వం సంబంధం ఉంది.',
    'తల్లి స్థితి':'తల్లి జీవన పరిస్థితుల అంశం నాల్గవ భావంతో అనుసంధానమైంది.',
    'స్వగృహం':'సొంత గృహం, నివాస స్థిరత్వం నాల్గవ భావానికి చెందిన అంశం.',
    'స్థిరాస్తి':'భూమి, ఇంటి ఆస్తి నిర్ణయాలకు నాల్గవ భావ సంబంధం ఉంది.',
    'వాహనాలు':'వాహన సౌకర్యం, వినియోగానికి నాల్గవ భావ సంబంధం ఉంది.',
    'గృహసుఖం':'ఇంటి వాతావరణం, గృహసౌఖ్యం నాల్గవ భావ అంశం.',
    'స్థాన మార్పు':'ఇంటి మార్పు లేదా నివాస మార్పుకు నాల్గవ భావ సంబంధం ఉంది.',
    'ప్రాథమిక విద్య':'పాఠశాల స్థాయి విద్యకు నాల్గవ భావ సూచనలు ఉన్నాయి.',
    'ఇంటి వ్యాపారం':'ఇంటినే ఆధారంగా చేసుకుని పని లేదా వ్యాపారం చేసే అంశం ఉంది.',
    'ఇంటి నిర్మాణం':'నివాస నిర్మాణం, మరమ్మతులు, నిర్మాణ నిర్ణయాలు భావానికి చెందుతాయి.',
    'ఆస్తి పత్రాలు':'స్థిరాస్తి రిజిస్ట్రేషన్, యాజమాన్య పత్రాల అంశం ఉంది.',
    'కుటుంబ మూలాలు':'పూర్వీకుల నివాసం, కుటుంబ మూలాల అంశం ఉంది.',
    'సంతాన అంశం':'సంతాన సంబంధిత జీవన అంశాలు పంచమభావంతో ముడిపడ్డాయి.',
    'సంతాన విద్య':'పిల్లల చదువు, అభ్యాస అంశం పంచమభావ పరిధిలో ఉంది.',
    'బుద్ధిశక్తి':'ఆలోచనశక్తి, గ్రహణ సామర్థ్యం పంచమభావంతో ముడిపడ్డాయి.',
    'ఉన్నత విద్యా ఆసక్తి':'విద్యను మరింత ముందుకు తీసుకెళ్లే ఆసక్తికి పంచమ సంబంధం ఉంది.',
    'సృజనాత్మకత':'కొత్త ఆలోచనలు, సృజనాత్మక పనులకు పంచమభావ సంబంధం ఉంది.',
    'ప్రేమ సంబంధం':'ప్రేమ, వ్యక్తిగత అనుబంధాలకు పంచమభావ సూచన ఉంది.',
    'బోధన':'బోధన, జ్ఞానాన్ని పంచే ప్రక్రియ పంచమభావంతో అనుసంధానమైంది.',
    'మంత్ర/ఆధ్యాత్మిక సాధన':'మంత్రాభ్యాసం, ఆధ్యాత్మిక సాధన పంచమ భావంలో పరిగణించబడతాయి.',
    'నిర్ణయ స్వభావం':'నిర్ణయాల్లో మేధో విచారణ, ఆలోచనకు పంచమభావ సంబంధం ఉంది.',
    'స్పెక్యులేషన్':'ఊహాధారిత పెట్టుబడి నిర్ణయాల అంశం పంచమభావంతో అనుసంధానమైంది.',
    'పోటీ పరీక్షలు':'పరీక్షా సిద్ధత, మేధో పోటీ అంశాలకు పంచమభావ సంబంధం ఉంది.',
    'గుర్తింపు':'జ్ఞానం లేదా ప్రతిభ వల్ల గుర్తింపు పొందే అంశం ఉంది.',
    'ఉద్యోగ సేవ':'ఇతరుల సంస్థలో పనిచేయడం, సేవా బాధ్యతలు ఆరవ భావ అంశం.',
    'పోటీ':'వృత్తి/పరీక్ష పోటీలకు ఎదురొడ్డి నిలబడడం ఆరవ భావ అంశం.',
    'రుణాలు':'రుణాలు, అప్పులు, తిరిగి చెల్లింపుల నిర్వహణకు ఆరవ భావ సంబంధం ఉంది.',
    'వివాదాలు':'వివాదాలు, ప్రతిస్పందన, సమస్యల పరిష్కారం ఆరవ భావ పరిధిలో ఉంది.',
    'ప్రత్యర్థులు':'పోటీదారులు, ప్రతిస్పర్థ ఎదుర్కోవడం ఆరవ భావ అంశం.',
    'అనారోగ్య సూచనలు':'శారీరక అసౌకర్యాల సంప్రదాయ కారకత్వం ఆరవ భావానికి చెందుతుంది.',
    'ఉద్యోగ ఆటంకం':'ఉద్యోగంలో ఒత్తిడి, ఆటంకాల అంశం ఆరవ భావంతో అనుసంధానమైంది.',
    'ఉద్యోగులు':'సహాయక సిబ్బంది, పని విభజన ఆరవ భావ అంశం.',
    'సేవా వృత్తులు':'సేవ, పనిలో నైపుణ్యాన్ని ఉపయోగించే వృత్తుల అంశం ఉంది.',
    'వ్యాపారం నుంచి ఉద్యోగం':'వ్యాపారం–ఉద్యోగం మార్పు ఆరవ/దశమ భావ పరస్పర సంబంధ అంశం.',
    'కేసు పరిష్కారం':'న్యాయవివాదం పరిష్కారం ఆరవ భావ పరిధిలో పరిశీలించబడుతుంది.',
    'పరీక్ష విజయం':'పోటీ పరీక్షలలో ప్రయత్నం, విజయం అంశానికి ఆరవ భావ సంబంధం ఉంది.',
    'వివాహ ఏర్పాట్లు':'వివాహ ప్రతిపాదన, వివాహ నిర్వహణకు ఏడవ భావం ప్రధాన కేంద్రం.',
    'వివాహానంతర అనుభవం':'వివాహానంతర సహజీవనం, భాగస్వామి అనుభవం ఏడవ భావ అంశం.',
    'భార్య/భర్త స్వభావం':'భాగస్వామి స్వభావానికి ఏడవ భావ సంబంధం ఉంది.',
    'భాగస్వామ్య వ్యాపారం':'వ్యాపార భాగస్వామ్యాలు, ఉమ్మడి కార్యకలాపాలు ఏడవ భావ అంశం.',
    'వ్యాపార ఒప్పందం':'కాంట్రాక్టులు, వ్యాపార ఒప్పందాలు ఏడవ భావ అంశం.',
    'ప్రేమ వివాహం':'ప్రేమ–వివాహ పరస్పర సంబంధం ఐదవ, ఏడవ భావాలతో ముడిపడుతుంది.',
    'వివాహ ఆలస్యం':'వివాహంలో ఆలస్యం సూచనలకు ఏడవ భావ/కారక సంబంధాలు చూడబడతాయి.',
    'వివాహ విభేదాలు':'దాంపత్య ఘర్షణలకు ఏడవ భావంపై పాపసంబంధం సంప్రదాయ సూచన.',
    'విదేశీ వ్యాపారం':'విదేశీ వ్యాపార సంబంధాలు ఏడవ–పన్నెండవ భావాలతో అనుసంధానమవుతాయి.',
    'పబ్లిక్ సంబంధాలు':'ప్రజలతో లావాదేవీలు, సంబంధాల నిర్వహణకు ఏడవ భావ సంబంధం ఉంది.',
    'కుటుంబ విస్తరణ':'వివాహం తరువాత కుటుంబ విస్తరణకు ఏడవ భావ సంబంధం ఉంది.',
    'సమతుల్యత':'పరస్పర అవగాహన, ఇచ్చిపుచ్చుకోవడం ఏడవ భావ అంశం.',
    'ఆకస్మిక పరిణామం':'అనుకోని మార్పులు, పరిస్థితుల మలుపులు అష్టమ భావానికి చెందుతాయి.',
    'వారసత్వ ఆస్తి':'వారసత్వం, పితృఆస్తి హక్కులకు అష్టమభావ సంబంధం ఉంది.',
    'భీమా':'బీమా, పరిహార ఒప్పందాలకు అష్టమ భావ సంబంధం ఉంది.',
    'ఉమ్మడి ధనం':'ఉమ్మడి ఆర్థిక బాధ్యతలు అష్టమభావ అంశం.',
    'పరిశోధన':'లోతైన పరిశోధన, విచారణ అష్టమభావ అంశం.',
    'రహస్య శాస్త్రాలు':'మర్మశాస్త్రాల అధ్యయనం అష్టమ భావానికి సంప్రదాయ సంబంధం.',
    'వ్యాజ్యం':'న్యాయ సంబంధిత దీర్ఘ ప్రక్రియలు అష్టమ భావ అంశం.',
    'పునర్నిర్మాణం':'విచ్ఛిన్నమైన విషయాలను పునర్నిర్మించే అంశం అష్టమ భావానికి చెందినది.',
    'అప్రమత్తత':'అనుకోని పరిస్థితుల్లో అప్రమత్తత అంశం ఉంది.',
    'శస్త్ర చికిత్స':'శస్త్రచికిత్సకు సంబంధించిన సంప్రదాయ కారకత్వాన్ని మాత్రమే నమోదు చేస్తుంది.',
    'సహచర ధనం':'భాగస్వామి ఆర్థిక వ్యవహారాలకు అష్టమభావ సంబంధం ఉంది.',
    'ఆయుష్షు':'ఆయుర్దాయ అంశం అష్టమభావ కారకత్వం; ఇది మరణకాల గణన కాదు.',
    'భాగ్య ప్రగతి':'అవకాశాలు, భాగ్య సహకారం నవమభావ అంశం.',
    'తండ్రి':'తండ్రి స్థితి, తండ్రితో సంబంధం నవమభావ అంశం.',
    'గురువు':'గురువులు, మార్గదర్శకుల సహకారం నవమభావ అంశం.',
    'ఉన్నత విద్య':'ఉన్నత విద్యా ప్రయాణం నవమభావంతో ముడిపడుతుంది.',
    'దూర ప్రయాణం':'దూర ప్రాంత ప్రయాణాలు నవమభావ కారకత్వం.',
    'ధర్మాచరణ':'ధార్మిక ఆచరణలు, సంప్రదాయాలపై ఆసక్తి నవమభావ అంశం.',
    'దానధర్మం':'దాతృత్వం, సేవా కార్యక్రమాలు నవమభావ అంశం.',
    'చట్టశాస్త్రం':'న్యాయ విద్య, చట్ట విజ్ఞానం నవమ భావంతో అనుసంధానమైంది.',
    'ప్రచురణ':'పుస్తక ప్రచురణ, జ్ఞాన వ్యాప్తి నవమ భావ అంశం.',
    'విదేశీ విద్య':'విదేశీ విశ్వవిద్యాలయాలు, చదువు ప్రయాణాలు నవమ–ద్వాదశ భావ అంశం.',
    'జన్మస్థలం బయట పురోగతి':'జన్మస్థలం బయట అవకాశాలు, దూర ప్రాంత అభివృద్ధి నవమభావ అంశం.',
    'పుణ్యక్షేత్రం':'పుణ్యక్షేత్ర దర్శనం, ధర్మ యాత్రలు నవమభావ అంశం.',
    'ఉద్యోగం':'వృత్తి, సంస్థల్లో పని దశమ భావానికి చెందుతుంది.',
    'స్వవ్యాపారం':'స్వయం ఉపాధి, సొంత వ్యాపారం దశమ భావ అంశం.',
    'పదోన్నతి':'వృత్తిలో పదవి పెరుగుదల దశమ భావ సూచన.',
    'వృత్తి మార్పు':'పని/సంస్థ మార్పు దశమ భావ అంశం.',
    'ప్రభుత్వ సంబంధం':'ప్రభుత్వ సేవ, ప్రభుత్వ సంప్రదింపులకు దశమ భావ సంబంధం ఉంది.',
    'వృత్తి విభాగం':'వృత్తి రకం, రంగం ఎంపికకు దశమాధిపతి కారకత్వం ఉంది.',
    'ఉద్యోగ స్థిరత్వం':'ఉద్యోగంలో కొనసాగింపు, స్థిరత్వం దశమ భావ అంశం.',
    'వ్యాపార విస్తరణ':'వ్యాపారాన్ని పెంచడం, కొత్త విభాగాలు ప్రారంభించడం దశమ భావ అంశం.',
    'అధికార గౌరవం':'పదవి, అధికార హోదా ద్వారా గౌరవం దశమ భావ అంశం.',
    'సిబ్బంది సంబంధం':'పని సిబ్బంది, కార్మికులతో సంబంధాలు దశమ భావానికి చెందుతాయి.',
    'వృత్తి నష్టం':'వృత్తి ఆటంకం లేదా నష్టం అంశానికి దశమ/అష్టమ/వ్యయ భావాల సంబంధం ఉంది.',
    'విదేశీ కెరీర్':'విదేశీ ఉద్యోగం లేదా దూర ప్రాంత వృత్తి దశమ–ద్వాదశ సంబంధం.',
    'లాభం':'ఆర్థిక లాభం, అభివృద్ధి ఏకాదశ భావ అంశం.',
    'జీత పెరుగుదల':'జీతవృద్ధి లేదా వృత్తి ఆదాయ పెరుగుదల ఏకాదశ భావ అంశం.',
    'కోరికల సాధన':'లక్ష్యాలు సాధించడం ఏకాదశ భావంతో అనుసంధానమైంది.',
    'పెద్ద తోబుట్టువులు':'పెద్ద సోదరులు/సోదరీమణులతో సంబంధం ఏకాదశ భావ అంశం.',
    'స్నేహ వలయం':'స్నేహితులు, సంఘ సంబంధాలు ఏకాదశ భావ అంశం.',
    'గ్రూపులు':'సమూహాల ద్వారా సహకారం ఏకాదశ భావ అంశం.',
    'పెట్టుబడి ఫలితం':'పెట్టుబడి ద్వారా లాభ–నష్టం అంశం ఏకాదశ భావ సంబంధం.',
    'కమిషన్ ఆదాయం':'కమీషన్, మధ్యవర్తిత్వ ఆదాయం ఏకాదశ భావ అంశం.',
    'వ్యాపార క్లయింట్లు':'వ్యాపార సంబంధాల ద్వారా లాభాలు ఏకాదశ భావ అంశం.',
    'పదవి ద్వారా ఆదాయం':'హోదా పెరుగుదల వల్ల ఆర్థిక లాభాలు ఏకాదశ భావ అంశం.',
    'ఆస్తి ఆదాయం':'భూమి, భవనాల ద్వారా ఆదాయం ఏకాదశ భావ అంశం.',
    'మిత్రుల ద్వారా సహాయం':'స్నేహితులు, సహకార సంబంధాల నుంచి సహాయం ఏకాదశ భావ అంశం.',
    'ఖర్చులు':'రోజువారీ/ప్రత్యేక వ్యయాల నిర్వహణ ద్వాదశ భావ అంశం.',
    'విదేశీ నివాసం':'దేశాంతర నివాసం ద్వాదశ భావంతో ముడిపడుతుంది.',
    'విదేశీ ఉద్యోగం':'విదేశీ వృత్తి, దూర ప్రాంత పనికి ద్వాదశ భావ సంబంధం ఉంది.',
    '12:విదేశీ విద్య':'విదేశాల్లో చదువుకు ద్వాదశ భావ సంబంధం ఉంది.',
    'ఆసుపత్రి ఖర్చు':'వైద్య ఖర్చుల సంప్రదాయ కారకత్వం ద్వాదశ భావానికి చెందుతుంది.',
    'విశ్రాంతి/నిద్ర':'విశ్రాంతి, నిద్ర అలవాట్లు ద్వాదశ భావ అంశం.',
    'ధ్యానం':'ధ్యానం, అంతర్ముఖ సాధన ద్వాదశ భావ అంశం.',
    '12:దానధర్మం':'దాతృత్వం ద్వారా ఖర్చులు ద్వాదశ భావ అంశం.',
    'నష్టం నియంత్రణ':'ఖర్చుల నియంత్రణ, వ్యయ నిర్వహణ ద్వాదశ భావ అంశం.',
    'పని వదలడం':'పని నుంచి తప్పుకోవడం లేదా విరామం తీసుకోవడం ద్వాదశ భావ అంశం.',
    'దూర నివాసం':'జన్మస్థలం నుంచి దూరంగా నివసించడం ద్వాదశ భావ అంశం.',
    'రహస్య ఖర్చు':'తెలియని లేదా వ్యక్తిగత వ్యయాల అంశం ద్వాదశ భావానికి చెందుతుంది.',
  };

  /// Topic-specific linkage houses are only an interpretive extension.
  /// There is no claim that a teacher dictated all 144 IF combinations.
  static List<int> _relatedHouses(String topic, int house) {
    final linked = <int>{};
    if (topic.contains('విదేశీ') || topic.contains('దూర') ||
        topic.contains('స్థాన మార్పు')) linked.addAll([3,9,12]);
    if (topic.contains('వివాహ') || topic.contains('భార్య') ||
        topic.contains('భర్త') || topic.contains('ప్రేమ')) linked.addAll([5,7]);
    if (topic.contains('సంతాన') || topic.contains('పిల్లల')) linked.addAll([5,9]);
    if (topic.contains('ఉద్యోగ') || topic.contains('వృత్తి') ||
        topic.contains('వ్యాపార') || topic.contains('సిబ్బంది') ||
        topic.contains('పదవి')) linked.addAll([6,7,10,11]);
    if (topic.contains('ఆదాయ') || topic.contains('ధన') ||
        topic.contains('లాభ') || topic.contains('బ్యాంక్') ||
        topic.contains('జీత') || topic.contains('పెట్టుబడి')) linked.addAll([2,11]);
    if (topic.contains('ఆస్తి') || topic.contains('ఇంటి') ||
        topic.contains('గృహ') || topic.contains('వాహన') ||
        topic.contains('నివాస') || topic.contains('భూమి')) linked.addAll([4,11]);
    if (topic.contains('విద్య') || topic.contains('పరీక్ష') ||
        topic.contains('బోధన') || topic.contains('అభ్యాసం')) linked.addAll([4,5,9]);
    if (topic.contains('సోదర') || topic.contains('తోబుట్టువులు')) linked.addAll([3,11]);
    if (topic.contains('అనారోగ్య') || topic.contains('ఆరోగ్య') ||
        topic.contains('శస్త్ర')) linked.addAll([1,6,8]);
    if (topic.contains('రుణం') || topic.contains('వివాద') ||
        topic.contains('కేసు') || topic.contains('వ్యాజ్యం')) linked.addAll([6,8]);
    if (topic.contains('ధర్మ') || topic.contains('గురువు') ||
        topic.contains('ఆధ్యాత్మిక') || topic.contains('ధ్యానం')) linked.addAll([9,12]);
    linked.remove(house);
    return linked.toList(growable:false)..sort();
  }

  static List<String> _specificKaraka(String topic, int house) {
    final names = <String>{};
    final t=topic;
    if (t.contains('తల్లి') || t.contains('గృహ') || t.contains('ఇంటి') ||
        t.contains('నివాస') || t.contains('ఆహార') || t.contains('ప్రయాణ')) names.add('Moon');
    if (t.contains('తండ్రి') || t.contains('ప్రభుత్వ') || t.contains('అధికార') ||
        t.contains('గౌరవం') || t.contains('స్థాయి')) names.add('Sun');
    if (t.contains('సంతాన') || t.contains('గురువు') || t.contains('భాగ్య') ||
        t.contains('ధర్మ') || t.contains('బోధన') || t.contains('విద్య')) names.add('Jupiter');
    if (t.contains('బుధ') || t.contains('భాష') || t.contains('మాట') ||
        t.contains('కమ్యూనికేషన్') || t.contains('పత్ర') || t.contains('లెక్క') ||
        t.contains('బ్యాంక్') || t.contains('వ్యాపార') || t.contains('రచన')) names.add('Mercury');
    if (t.contains('వివాహ') || t.contains('భార్య') || t.contains('భర్త') ||
        t.contains('ప్రేమ') || t.contains('వాహన') || t.contains('సుఖం') ||
        t.contains('కళ') || t.contains('సంగీత')) names.add('Venus');
    if (t.contains('ఆస్తి') || t.contains('భూమి') || t.contains('సోదర') ||
        t.contains('ధైర్య') || t.contains('శస్త్ర') || t.contains('నిర్మాణం')) names.add('Mars');
    if (t.contains('ఉద్యోగ') || t.contains('సిబ్బంది') || t.contains('సేవ') ||
        t.contains('పోటీ') || t.contains('అలస్యం') || t.contains('పని')) names.add('Saturn');
    if (t.contains('ధన') || t.contains('ఆదాయ') || t.contains('లాభ') ||
        t.contains('పొదుపు') || t.contains('ఆర్థిక') || t.contains('పెట్టుబడి')) {
      names.add('Jupiter');names.add('Venus');
    }
    if (names.isEmpty) names.addAll(switch(house) {
      1 => ['Sun'],2 => ['Jupiter'],3 => ['Mars'],4 => ['Moon'],
      5 => ['Jupiter'],6 => ['Saturn'],7 => ['Venus'],8 => ['Saturn'],
      9 => ['Jupiter'],10 => ['Saturn'],11 => ['Jupiter'],_ => ['Saturn'],
    });
    return names.toList(growable:false);
  }
}

class _HouseContext {
  final int house;
  final BnnD1BhavaPlacement? placement;
  final PlanetPosition? lord;
  final List<PlanetPosition> inHouse;
  final List<PlanetPosition> houseContacts;
  final List<PlanetPosition> lordContacts;
  final List<PlanetPosition> beneficContacts;
  final List<PlanetPosition> maleficContacts;
  final PlanetPosition? star;
  final String level;
  const _HouseContext(this.house,this.placement,this.lord,this.inHouse,
      this.houseContacts,this.lordContacts,this.beneficContacts,
      this.maleficContacts,this.star,this.level);
  factory _HouseContext.empty(int house) => _HouseContext(house,null,null,
    const [], const [], const [],const [],const [],null,'none');
}
