import 'package:sweph/sweph.dart';

import '../models/birth_data.dart';
import 'astro_calculation_service.dart';

/// Computed astronomical *points*, not physical planets.
///
/// Mandi: Prasna Marga ch. 5 / Uttara Kalamrita scaled ghati method.
/// Day 26,22,18,14,10,6,2 /30 of actual sunrise-to-sunset duration;
/// night 10,6,2,26,22,18,14 /30 of actual sunset-to-next-sunrise.
///
/// Gulika: BPHS 3.66–70 — lagna at the START of Saturn's allotted eighth
/// day/night interval. The alternative END-of-Saturn-interval longitude is
/// retained as a reference. THESE CONVENTIONS NEED NOT GIVE THE SAME DEGREE.
/// All timestamps are calculated as UTC instants; the user's supplied offset
/// is used only when converting selected local civil time to UTC.
class MandiCalculationResult {
  final double mandiLongitude;
  final double gulikaLongitude;
  final double gulikaEndLongitude;
  final DateTime mandiTimeUtc;
  final DateTime gulikaStartTimeUtc;
  final DateTime gulikaEndTimeUtc;
  final DateTime solarStartUtc;
  final DateTime solarEndUtc;
  final bool isNight;
  final int solarWeekday; // Sunday=0, ... Saturday=6
  const MandiCalculationResult({
    required this.mandiLongitude,
    required this.gulikaLongitude,
    required this.gulikaEndLongitude,
    required this.mandiTimeUtc,
    required this.gulikaStartTimeUtc,
    required this.gulikaEndTimeUtc,
    required this.solarStartUtc,
    required this.solarEndUtc,
    required this.isNight,
    required this.solarWeekday,
  });

  int get mandiSignIndex => (mandiLongitude / 30).floor() % 12;
  int get mandiHouseSignIndex => mandiSignIndex;
}

/// Pure timings kept separate from the ephemeris to make weekday/day-night
/// convention regression-testable without Swiss native assets.
class MandiTiming {
  static const dayGhatis = <int>[26, 22, 18, 14, 10, 6, 2];
  static const nightGhatis = <int>[10, 6, 2, 26, 22, 18, 14];

  static double mandiFraction(int sundayZeroWeekday, {required bool night}) {
    if (sundayZeroWeekday < 0 || sundayZeroWeekday > 6) {
      throw ArgumentError.value(sundayZeroWeekday, 'sundayZeroWeekday');
    }
    return (night ? nightGhatis : dayGhatis)[sundayZeroWeekday] / 30.0;
  }

  static int saturnSegment(int sundayZeroWeekday, {required bool night}) {
    if (sundayZeroWeekday < 0 || sundayZeroWeekday > 6) {
      throw ArgumentError.value(sundayZeroWeekday, 'sundayZeroWeekday');
    }
    // Night sequence starts with the fifth weekday counting inclusively.
    final first = (sundayZeroWeekday + (night ? 4 : 0)) % 7;
    return (6 - first + 7) % 7;
  }
}

class MandiCalculationService {
  static double _julday(DateTime d) {
    final u = d.toUtc();
    return Sweph.swe_julday(u.year, u.month, u.day,
      u.hour + u.minute / 60.0 + u.second / 3600.0 +
      u.millisecond / 3600000.0 + u.microsecond / 3600000000.0,
      CalendarType.SE_GREG_CAL);
  }

  static DateTime _utcFromJd(double jd) => DateTime.utc(1970, 1, 1).add(
    Duration(microseconds: ((jd - 2440587.5) * 86400000000).round()));

  static double _riseSet(double from, double lon, double lat, bool sunrise) {
    final result = Sweph.swe_rise_trans(
      from, HeavenlyBody.SE_SUN, SwephFlag.SEFLG_MOSEPH,
      sunrise ? RiseSetTransitFlag.SE_CALC_RISE : RiseSetTransitFlag.SE_CALC_SET,
      GeoPosition(lon, lat), 0, 0,
    );
    if (result == null || !result.isFinite) {
      throw StateError('స్థానిక సూర్యోదయం/సూర్యాస్తమయం గణన లభించలేదు.');
    }
    return result;
  }

  static double _ascendant(double jd, BirthData data) {
    final houses = Sweph.swe_houses_ex(jd, SwephFlag.SEFLG_SIDEREAL,
      data.latitude, data.longitude, Hsys.P);
    final value = houses.ascmc[AscmcIndex.SE_ASC.index];
    if (!value.isFinite) throw StateError('మండీ లగ్నం గణించలేకపోయాం.');
    return (value % 360 + 360) % 360;
  }

  static Future<MandiCalculationResult> calculate(BirthData data) async {
    if (!data.latitude.isFinite || !data.longitude.isFinite ||
        !data.timezoneOffsetHours.isFinite ||
        data.latitude.abs() > 66 || data.longitude.abs() > 180 ||
        data.timezoneOffsetHours < -12 || data.timezoneOffsetHours > 14) {
      throw ArgumentError('మండీకి సరైన అక్షాంశం, రేఖాంశం, UTC Offset అవసరం.');
    }
    await AstroCalculationService.initialize();
    if (!AstroCalculationService.isInitialized) {
      throw StateError('Swiss Ephemeris అందుబాటులో లేదు: '
        '${AstroCalculationService.initError ?? 'unknown'}');
    }

    final offset = Duration(minutes: (data.timezoneOffsetHours * 60).round());
    final local = data.localDateTime;
    final midnightUtc = DateTime.utc(local.year, local.month, local.day)
        .subtract(offset);
    final instant = _julday(data.utcDateTime);
    final midnightJd = _julday(midnightUtc);
    final todayRise = _riseSet(midnightJd, data.longitude, data.latitude, true);
    final todaySet = _riseSet(todayRise + 0.005, data.longitude, data.latitude, false);
    late final double startJd, endJd;
    late final bool night;
    late final DateTime solarCivilDay;

    if (instant < todayRise) {
      final yesterdayRise = _riseSet(midnightJd - 1.0,
        data.longitude, data.latitude, true);
      startJd = _riseSet(yesterdayRise + 0.005,
        data.longitude, data.latitude, false);
      endJd = todayRise;
      night = true;
      solarCivilDay = DateTime.utc(local.year, local.month, local.day)
          .subtract(const Duration(days: 1));
    } else if (instant >= todaySet) {
      startJd = todaySet;
      endJd = _riseSet(todaySet + 0.005,
        data.longitude, data.latitude, true);
      night = true;
      solarCivilDay = DateTime.utc(local.year, local.month, local.day);
    } else {
      startJd = todayRise;
      endJd = todaySet;
      night = false;
      solarCivilDay = DateTime.utc(local.year, local.month, local.day);
    }
    final span = endJd - startJd;
    if (!(span > 0.0 && span < 1.0)) {
      throw StateError('సూర్యోదయ–సూర్యాస్తమయ మధ్య కాలం చెల్లదు.');
    }
    final weekday = solarCivilDay.weekday % 7;
    final mandiJd = startJd + span *
      MandiTiming.mandiFraction(weekday, night: night);
    final saturnIndex = MandiTiming.saturnSegment(weekday, night: night);
    final gulikaStart = startJd + span * saturnIndex / 8.0;
    final gulikaEnd = startJd + span * (saturnIndex + 1) / 8.0;

    // The sidereal ayanamsa must agree with the user's natal chart setting.
    Sweph.swe_set_sid_mode(switch (data.ayanamsa) {
      AyanamsaType.lahiri => SiderealMode.SE_SIDM_LAHIRI,
      AyanamsaType.raman => SiderealMode.SE_SIDM_RAMAN,
      AyanamsaType.krishnamurti => SiderealMode.SE_SIDM_KRISHNAMURTI,
    }, SiderealModeFlag.SE_SIDBIT_NONE, 0.0, 0.0);

    return MandiCalculationResult(
      mandiLongitude: _ascendant(mandiJd, data),
      gulikaLongitude: _ascendant(gulikaStart, data),
      gulikaEndLongitude: _ascendant(gulikaEnd, data),
      mandiTimeUtc: _utcFromJd(mandiJd),
      gulikaStartTimeUtc: _utcFromJd(gulikaStart),
      gulikaEndTimeUtc: _utcFromJd(gulikaEnd),
      solarStartUtc: _utcFromJd(startJd),
      solarEndUtc: _utcFromJd(endJd),
      isNight: night,
      solarWeekday: weekday,
    );
  }
}
