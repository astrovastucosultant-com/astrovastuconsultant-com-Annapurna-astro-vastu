import 'astro_models.dart';
import 'bnn_master_service.dart';
import 'bnn_exact_if_engine.dart';

/// Compact, rule-scoped reading.  FALSE means only that this particular
/// source IF is absent; it cannot negate every route to the life event.
class BnnRuleVerdict {
  static String result(BnnMasterRule rule, BnnExactIfResult check) {
    if (!check.evaluable) return 'ఈ రూల్‌కు జాతక ఫలితం నిర్ణయించబడలేదు';
    if (check.matched) return check.matchedThen ?? rule.result;
    if (rule.id == 'BNN-BOOK-G05') return 'ప్రభుత్వ ఉద్యోగం లేదు';
    // Do not turn a negative condition into a global assertion such as
    // "no disease", "no children", "no marriage" or "no death".
    final phrase = rule.result.split(RegExp(r'[;\n।]')).first.trim();
    if (phrase.isNotEmpty && phrase.length <= 60 &&
        !RegExp(r'\b(?:మరణం|ఆయుష్యం)\b').hasMatch(phrase)) {
      return '$phrase సూచన లేదు';
    }
    return 'ఈ రూల్ ప్రకారం ఫలిత సూచన లేదు';
  }

  static String inspection(BnnMasterRule rule, AstroChartResult chart,
      BnnExactIfResult check) {
    if (rule.id == 'BNN-BOOK-G05') {
      PlanetPosition? sun;
      PlanetPosition? saturn;
      for (final p in chart.planets) {
        if (p.name == 'Sun') sun = p;
        if (p.name == 'Saturn') saturn = p;
      }
      if (sun == null || saturn == null) return 'రవి లేదా శని స్థానం అందుబాటులో లేదు';
      final actual = (sun.signIndex - saturn.signIndex + 12) % 12 + 1;
      return 'శని ${BnnMasterAnalysis.signNames[saturn.signIndex]} '
          '${saturn.degreesInSign.toStringAsFixed(2)}°, '
          'రవి ${BnnMasterAnalysis.signNames[sun.signIndex]} '
          '${sun.degreesInSign.toStringAsFixed(2)}°. '
          'శని నుంచి రవి $actual వ స్థానం; కావలసింది 11వ స్థానం.';
    }
    if (!check.evaluable) return 'ఈ IFకు గణితపరమైన నిర్ణయం అందుబాటులో లేదు';
    // The parser's computed natal details are retained, unlike hand-authored
    // metadata / OCR provenance that was previously shown in the sheet.
    return check.reason.replaceAll('పూర్తి షరతు TRUE', 'స్థానం సరిపోయింది')
        .replaceAll('పూర్తి షరతు FALSE', 'స్థానం సరిపోలలేదు');
  }
}
