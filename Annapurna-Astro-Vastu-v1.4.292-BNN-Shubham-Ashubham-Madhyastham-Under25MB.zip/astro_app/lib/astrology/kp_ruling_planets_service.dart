import 'kp_service.dart';
import 'package:sweph/sweph.dart';

/// KP Ruling Planets at the INSTANT of judgement.
/// Sources: Astro Secrets & KP Parts III, IV, V, VI (RP rule summaries).
/// Five primary factors are reported individually; sub-lords are additional
/// diagnostic factors and must not silently increase primary RP votes.
class KpRulingFactor {
  final String label;
  final String lord;
  final bool primary;
  const KpRulingFactor(this.label, this.lord, {this.primary = true});
}

class KpRulingPlanetsResult {
  final DateTime localMoment;
  final List<KpRulingFactor> factors;
  final List<String> primaryLords;
  final Map<String, int> occurrenceCounts;
  final List<String> repeatedLords;
  final List<String> nodeRepresentations;
  final String weekdayPolicy;

  const KpRulingPlanetsResult({
    required this.localMoment,
    required this.factors,
    required this.primaryLords,
    required this.occurrenceCounts,
    required this.repeatedLords,
    required this.nodeRepresentations,
    required this.weekdayPolicy,
  });
}

class KpRulingPlanetsService {
  static const _weekdayLord = <String>[
    'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn', 'Sun',
  ];

  static KpRulingPlanetsResult calculate({
    required KpChartDetails chart,
    required DateTime localMoment,
    required double latitude,
    required double longitude,
    required double timezoneOffsetHours,
  }) {
    final asc = chart.cusps.first;
    final moon = chart.planets.firstWhere((p) => p.body == 'Moon');
    // KP weekday changes at the question-location sunrise, not at midnight.
    // Swiss Ephemeris reports the next local sunrise from local midnight UTC.
    final localMidnightUtc = DateTime.utc(
      localMoment.year, localMoment.month, localMoment.day).subtract(
        Duration(minutes: (timezoneOffsetHours * 60).round()));
    final jdStart = Sweph.swe_julday(localMidnightUtc.year,
      localMidnightUtc.month,localMidnightUtc.day,
      localMidnightUtc.hour + localMidnightUtc.minute / 60 +
      localMidnightUtc.second / 3600, CalendarType.SE_GREG_CAL);
    double? sunriseJd;
    String dayPolicy;
    int? weekday;
    try {
      sunriseJd = Sweph.swe_rise_trans(
        jdStart, HeavenlyBody.SE_SUN, SwephFlag.SEFLG_MOSEPH,
        RiseSetTransitFlag.SE_CALC_RISE,
        GeoPosition(longitude, latitude), 0, 0);
      if (sunriseJd != null && sunriseJd.isFinite) {
        final instantUtc = DateTime.utc(localMoment.year,localMoment.month,
          localMoment.day,localMoment.hour,localMoment.minute,localMoment.second)
          .subtract(Duration(minutes:(timezoneOffsetHours*60).round()));
        final instantJd = Sweph.swe_julday(instantUtc.year,
          instantUtc.month,instantUtc.day,instantUtc.hour +
          instantUtc.minute/60 + instantUtc.second/3600,
          CalendarType.SE_GREG_CAL);
        final beforeSunrise = instantJd < sunriseJd;
        weekday = beforeSunrise
          ? (localMoment.weekday == DateTime.monday ? DateTime.sunday : localMoment.weekday - 1)
          : localMoment.weekday;
        dayPolicy = beforeSunrise
          ? 'స్థానిక సూర్యోదయానికి ముందు — మునుపటి వారం అధిపతిని తీసుకున్నాం.'
          : 'స్థానిక సూర్యోదయం తర్వాత — ఈ రోజు వారం అధిపతిని తీసుకున్నాం.';
      } else {
        dayPolicy = 'స్థానిక సూర్యోదయం లభించలేదు; Day Lord నిర్ధారణ పెండింగ్.';
      }
    } catch (_) {
      dayPolicy = 'సూర్యోదయం గణన విఫలమైంది; Day Lord నిర్ధారణ పెండింగ్.';
    }
    // Classical five in priority order: Lagna star, Lagna sign,
    // Moon star, Moon sign and day lord. Sub-lords are supplementary.
    final factors = <KpRulingFactor>[
      KpRulingFactor('లగ్న నక్షత్రాధిపతి', asc.starLord),
      KpRulingFactor('లగ్న రాశ్యధిపతి', asc.signLord),
      KpRulingFactor('చంద్ర నక్షత్రాధిపతి', moon.starLord),
      KpRulingFactor('చంద్ర రాశ్యధిపతి', moon.signLord),
      if (weekday != null) KpRulingFactor('వారం అధిపతి (Day Lord)', _weekdayLord[weekday - 1]),
      KpRulingFactor('లగ్న Sub-Lord (అదనపు)', asc.subLord, primary: false),
      KpRulingFactor('చంద్ర Sub-Lord (అదనపు)', moon.subLord, primary: false),
    ];
    final counts = <String,int>{};
    for (final factor in factors.where((f) => f.primary)) {
      counts.update(factor.lord, (v) => v + 1, ifAbsent: () => 1);
    }
    final priority = factors.where((f)=>f.primary).map((f)=>f.lord).toList();
    final ranked = counts.keys.toList()
      ..sort((a,b) { final n=counts[b]!.compareTo(counts[a]!);
        return n != 0 ? n : priority.indexOf(a).compareTo(priority.indexOf(b)); });
    // Nodes are NOT added merely because they occupy a sign or star of an RP.
    // Actual agency/representation is a separate source-specific check.
    final nodes = <String>[];
    for (final node in chart.planets.where((p) => p.body == 'Rahu' || p.body == 'Ketu')) {
      final represented = <String>{node.signLord, node.starLord};
      final common = ranked.where(represented.contains).toList();
      if (common.isNotEmpty) {
        nodes.add('${node.body}: రాశి ${node.signLord}, నక్షత్రం ${node.starLord}; '
          'RP సంబంధం ${common.join(', ')} — ప్రతినిధిత్వ ధృవీకరణ అవసరం');
      }
    }
    return KpRulingPlanetsResult(
      localMoment: localMoment,
      factors: List.unmodifiable(factors),
      primaryLords: List.unmodifiable(ranked),
      occurrenceCounts: Map.unmodifiable(counts),
      repeatedLords: List.unmodifiable(ranked.where((p)=>counts[p]!>1)),
      nodeRepresentations: List.unmodifiable(nodes),
      weekdayPolicy: dayPolicy,
    );
  }
}
