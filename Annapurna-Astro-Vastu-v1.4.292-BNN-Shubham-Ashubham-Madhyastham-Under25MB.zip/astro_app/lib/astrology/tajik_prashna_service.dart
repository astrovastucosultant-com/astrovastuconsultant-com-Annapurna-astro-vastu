import 'astro_models.dart';
import 'kp_service.dart';

/// First, auditable stage of Tajika Prashna: applying/separating aspect of
/// the querent's lord and the relevant house lord. NOT the sixteen-yoga
/// Tajika verdict, Saham, Radda, combustion or event timing system.
///
/// References: Hayanaratna (Tajika orbs/Deeptamsa) and Tajika Prashna.
/// Current daily speeds, including retrograde motion, are used to establish
/// whether the angular distance to perfection is closing or opening.
class TajikPrashnaObservation {
  const TajikPrashnaObservation({required this.lagnaLord,
    required this.questionLord,required this.questionHouse,
    required this.aspectName,required this.distanceDegrees,
    required this.orbDegrees,required this.status,
    required this.explanation});

  final String lagnaLord, questionLord;
  final int questionHouse;
  final String aspectName;
  final double? distanceDegrees, orbDegrees;
  /// applying / separating / outside_orb / no_sign_aspect / same_lord / missing
  final String status;
  final String explanation;
}

class TajikPrashnaService {
  static const _orbs = <String,double>{
    'Sun':15, 'Moon':12, 'Mars':8, 'Mercury':7,
    'Jupiter':9, 'Venus':7, 'Saturn':9,
  };
  // Dart const maps require keys with primitive constant equality.
  // In particular, double keys (including 0.0) fail const-map validation.
  // Aspect angles are whole degrees, so store the names under int keys.
  static const _aspects = <int,String>{
    0:'యుతి',60:'షష్టి 60° దృష్టి',
    90:'కేంద్ర 90°',120:'త్రికోణ 120°',180:'సప్తమ 180°',
  };

  static double _norm(double value) => (value % 360 + 360) % 360;
  static double _separation(double a,double b) {
    final v=_norm(a-b);
    return v>180?360-v:v;
  }
  static double _gap(double a,double b,double target) =>
    (_separation(a,b)-target).abs();

  static TajikPrashnaObservation evaluate({
    required AstroChartResult chart,
    required int questionHouse,
  }) {
    if(questionHouse<1||questionHouse>12) {
      throw RangeError.range(questionHouse,1,12,'questionHouse');
    }
    final lagnaSign=chart.ascendantSignIndex;
    final questionSign=(lagnaSign+questionHouse-1)%12;
    final first=KpService.signLords[lagnaSign];
    final second=KpService.signLords[questionSign];
    TajikPrashnaObservation result(String status,String message,
      {String aspect='—',double? gap,double? orb}) =>
      TajikPrashnaObservation(lagnaLord:first,questionLord:second,
        questionHouse:questionHouse,aspectName:aspect,
        distanceDegrees:gap,orbDegrees:orb,status:status,explanation:message);
    if(first==second) return result('same_lord',
      'లగ్నాధిపతి, ప్రశ్న భావాధిపతి ఒకే గ్రహం ($first). '
      'ఈ రెండు గ్రహాల మధ్య ఇత్తశాల/ఈసరాఫా పరీక్ష వర్తించదు; ఇతర యోగాలు అవసరం.');
    final p=chart.planets.where((e)=>e.name==first).firstOrNull;
    final q=chart.planets.where((e)=>e.name==second).firstOrNull;
    if(p==null||q==null||!p.longitude.isFinite||!q.longitude.isFinite||
       !p.speed.isFinite||!q.speed.isFinite) {
      return result('missing','సంబంధిత గ్రహ డిగ్రీలు లేదా గమనవేగం లభించలేదు.');
    }
    // Source permits same sign, 3/11, 4/10, 5/9 and opposite signs.
    final signDistance=(p.signIndex-q.signIndex+12)%12;
    if(!const <int>{0,2,3,4,6,8,9,10}.contains(signDistance)) {
      return result('no_sign_aspect',
        'రెండు గ్రహాలకు ప్రాథమిక తాజిక రాశి దృష్టి లేదు. '
        'ఇది ప్రశ్నకు ప్రతికూల తీర్పు కాదు.');
    }
    final allowed= signDistance==0 ? <double>[0] :
      signDistance==2||signDistance==10 ? <double>[60] :
      signDistance==3||signDistance==9 ? <double>[90] :
      signDistance==4||signDistance==8 ? <double>[120] : <double>[180];
    final aspect=allowed.reduce((a,b)=>
      _gap(p.longitude,q.longitude,a)<=_gap(p.longitude,q.longitude,b)?a:b);
    final gap=_gap(p.longitude,q.longitude,aspect);
    final orb=(_orbs[first]!+_orbs[second]!)/2;
    // Every allowed aspect is one of the five integral angles above.
    final name=_aspects[aspect.toInt()]!;
    if(gap>orb) return result('outside_orb',
      '$first – $second $name సంబంధం ఉంది; '
      'అయితే దీప్తాంశ పరిధి (${orb.toStringAsFixed(2)}°) వెలుపల ఉంది.',
      aspect:name,gap:gap,orb:orb);
    // Project present longitudes forward one hour by their *observed* speed.
    // This handles retrograde direction but does not predict perfection dates.
    final next=_gap(p.longitude+p.speed/24,
      q.longitude+q.speed/24,aspect);
    final delta=next-gap;
    if(gap<0.0001||delta.abs()<0.00000001) {
      return result('exact_or_stationary',
        '$first – $second $name సంబంధం ఖచ్చిత స్థితికి సమీపంలో ఉంది; '
        'కదలిక ఆధారంగా నిర్దిష్ట దిశ చెప్పలేము.',aspect:name,gap:gap,orb:orb);
    }
    if(delta<0) return result('applying',
      '$first – $second మధ్య $name సంబంధం దగ్గరవుతోంది (ఇత్తశాల ప్రాథమిక సూచన). '
      'Radda/Nakta/Kamboola తదితర యోగాల పరిశీలన ఇంకా అవసరం.',
      aspect:name,gap:gap,orb:orb);
    return result('separating',
      '$first – $second మధ్య $name సంబంధం విడిపోతోంది (ఈసరాఫా ప్రాథమిక సూచన). '
      'దీన్ని ఒక్కటినే తుది నిరాకరణగా పరిగణించరాదు.',
      aspect:name,gap:gap,orb:orb);
  }
}
