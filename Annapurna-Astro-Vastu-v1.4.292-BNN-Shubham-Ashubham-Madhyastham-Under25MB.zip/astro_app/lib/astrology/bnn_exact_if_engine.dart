import 'astro_models.dart';
import 'bnn_master_service.dart';

/// Tests complete, unambiguous natal IF clauses in the 462-source catalogue.
/// Text provenance (OCR_REVIEW / FACTS_REQUIRED / REVIEW) is NEVER a
/// condition for calculating the natal predicate; preserve that status in
/// the catalogue and UI. A natal match is not verified source text, a factual
/// life event, or a final prediction. Unclear OCR is NEVER guessed.
/// No transit/timing, implied aspect or partial-clause matching here.
class BnnExactIfResult {
  final bool evaluable;
  final bool matched;
  final String reason;
  /// Branch-specific THEN; null means use the original undivided source THEN.
  /// Never replace the original source text stored in BnnMasterRule.
  final String? matchedThen;
  const BnnExactIfResult(this.evaluable, this.matched, this.reason,
      {this.matchedThen});
  static const unsupported = BnnExactIfResult(false, false,
      'ఈ మూల IFకు పూర్తి నిర్దిష్ట గణన నిర్వచనం అందుబాటులో లేదు. '
      'దీనిని TRUE లేదా FALSEగా ఊహించలేదు; జాతక ఫలితంగా చూపలేదు.');
}

class BnnExactIfEngine {
  static const _p = r'(?:సూర్యుడు|సూర్య|రవి|చంద్రుడు|చంద్ర|కుజుడు|కుజ|బుధుడు|బుధ|గురుడు|గురు|శుక్రుడు|శుక్ర|శని|రాహువు|రాహు|కేతువు|కేతు)';
  static const _s = r'(?:మేషం|వృషభం|మిథునం|మిథున|కర్కాటకం|సింహం|కన్య|తుల|వృశ్చికం|ధనుస్సు|మకరం|కుంభం|మీనం)';

  static PlanetPosition? _planet(String name, AstroChartResult chart) {
    final english = BnnMasterAnalysis.teluguPlanetNames[name];
    if (english == null) return null;
    for (final planet in chart.planets) {
      if (planet.name == english) return planet;
    }
    return null;
  }

  static int? _sign(String name) {
    if (name == 'మిథున') return 2;
    final i = BnnMasterAnalysis.signNames.indexOf(name);
    return i < 0 ? null : i;
  }

  static int _fromReference(PlanetPosition target, PlanetPosition reference) =>
      1 + ((target.signIndex - reference.signIndex + 12) % 12);

  static int? _houseNumber(String number) {
    const telugu = '౦౧౨౩౪౫౬౭౮౯';
    final normalized = number.split('').map((c) {
      final i = telugu.indexOf(c);
      return i < 0 ? c : '$i';
    }).join();
    final h = int.tryParse(normalized);
    return h != null && h >= 1 && h <= 12 ? h : null;
  }

  static BnnExactIfResult _checkPlanets(
      AstroChartResult chart, List<String> names,
      bool Function(List<PlanetPosition>) predicate, String explanation) {
    final found = <PlanetPosition>[];
    for (final name in names) {
      final p = _planet(name, chart);
      if (p == null) return BnnExactIfResult(false, false,
          'అవసరమైన $name గ్రహస్థానం జన్మజాతక డేటాలో లేదు; '
          'అందుకే ఈ IFను FALSEగా నిర్ణయించలేదు.');
      found.add(p);
    }
    final ok = predicate(found);
    final positions = found.map((p) =>
        '${p.name}: ${BnnMasterAnalysis.signNames[p.signIndex]} '
        '${p.degreesInSign.toStringAsFixed(2)}°').join(' • ');
    return BnnExactIfResult(true, ok,
      '$explanation • $positions • ${ok ? 'జన్మస్థితి సరిపోయింది' : 'జన్మస్థితి సరిపోలలేదు'}');
  }

  static BnnExactIfResult check(BnnMasterRule rule, AstroChartResult chart) {
    // OCR / REVIEW is a SOURCE PROVENANCE flag, not an astronomical gate.
    // For BNN N's ambiguous dash-chains there is no inferred conjunction:
    // only a full, explicitly parseable source IF can match below.
    final text = rule.condition.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (text.isEmpty) return BnnExactIfResult.unsupported;
    RegExpMatch? m;

    // E10 has TWO distinct THEN branches, not one combined assertion:
    //  (Saturn Gemini OR Saturn Virgo) => entrepreneur (source theme)
    //  (Saturn Gemini AND Moon Cancer) => extra alcohol-related theme.
    // A Virgo Saturn NEVER satisfies the extra Gemini/Moon clause.
    if (rule.id == 'BNN-BOOK-E10' &&
        text == 'శని మిథున/కన్య' &&
        rule.result == 'వ్యాపారవేత్త; మిథునం + చంద్ర కర్కాటకం - మద్యం') {
      return _checkE10(chart);
    }

    // Exact planet in one named sign, optionally one of two named signs.
    m = RegExp('^($_p) ($_s)(?:\\/($_s))?\$').firstMatch(text);
    if (m != null) {
      final one = _sign(m.group(2)!);
      final two = m.group(3) == null ? null : _sign(m.group(3)!);
      if (one == null) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!],
        (ps) => ps[0].signIndex == one ||
            (two != null && ps[0].signIndex == two), 'నిర్దిష్ట రాశి IF');
    }

    // Two explicit planets in the sign immediately after natal Jupiter.
    // Both placements are mandatory (BNN-BOOK-C39 courage is an example).
    m = RegExp('^గురుకి తర్వాతి ఇంట్లో ($_p)\\+($_p)\$').firstMatch(text);
    if (m != null) {
      return _checkPlanets(chart, [m.group(1)!, m.group(2)!],
          (ps) => ps.every((p) =>
              BnnMasterAnalysis.houseOfPlanet(p, chart) == 2),
          'జన్మగురు నుంచి తరువాతి రాశిలో రెండు గ్రహాలు తప్పనిసరి');
    }

    // Two different houses relative to ANY named reference planet:
    // e.g. "శనికి 2లో చంద్ర + 3లో కేతు".
    // Both clauses must be true; the reference is NEVER assumed to be Lagna.
    m = RegExp('^($_p)కి\\s*([0-9౦-౯]{1,2})లో\\s*($_p)\\s*\\+\\s*'
        '([0-9౦-౯]{1,2})లో\\s*($_p)\$').firstMatch(text);
    if (m != null) {
      final h1 = _houseNumber(m.group(2)!);
      final h2 = _houseNumber(m.group(4)!);
      if (h1 == null || h2 == null) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!, m.group(3)!, m.group(5)!],
        (ps) => _fromReference(ps[1], ps[0]) == h1 &&
                _fromReference(ps[2], ps[0]) == h2,
        'పేర్కొన్న గ్రహం నుంచి రెండూ వేర్వేరు భావ షరతులను పరీక్షించాం');
    }

    // Explicit sign, followed by another named sign: all named clauses
    // must hold. No implied conjunction, retrograde, or aspect is added.
    m = RegExp('^($_p)\\s+($_s)\\s*\\+\\s*($_p)\\s+($_s)\$')
        .firstMatch(text);
    if (m != null) {
      final s1 = _sign(m.group(2)!);
      final s2 = _sign(m.group(4)!);
      if (s1 == null || s2 == null) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!, m.group(3)!],
        (ps) => ps[0].signIndex == s1 && ps[1].signIndex == s2,
        'రెండు నిర్దిష్ట రాశులను స్వతంత్రంగా ధృవీకరించాం');
    }

    // Fully specified single natal placement relative to Jupiter.
    m = RegExp('^గురుకి (\\d{1,2})లో ($_p)\$').firstMatch(text);
    if (m != null) {
      final house = int.tryParse(m.group(1)!);
      if (house == null || house < 1 || house > 12) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, [m.group(2)!],
          (ps) => BnnMasterAnalysis.houseOfPlanet(ps[0], chart) == house,
          'గురు రాశి నుంచి $house వ భావస్థానం');
    }
    // House number may be after planet in the source notation.
    m = RegExp('^($_p) గురుకి (\\d{1,2})(?:లో)?\$').firstMatch(text);
    if (m != null) {
      final house = int.tryParse(m.group(2)!);
      if (house == null || house < 1 || house > 12) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, [m.group(1)!],
          (ps) => BnnMasterAnalysis.houseOfPlanet(ps[0], chart) == house,
          'గురు రాశి నుంచి $house వ భావస్థానం');
    }
    // Two planets at separately specified Jupiter-relative places. Both
    // positions are mandatory; checking only the first is never sufficient.
    m = RegExp('^గురుకి (\\d{1,2})లో ($_p) \\+ (\\d{1,2})లో ($_p)\$')
        .firstMatch(text);
    if (m != null) {
      final h1 = int.tryParse(m.group(1)!);
      final h2 = int.tryParse(m.group(3)!);
      if (h1 == null || h2 == null || h1 < 1 || h1 > 12 ||
          h2 < 1 || h2 > 12) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(2)!, m.group(4)!],
        (ps) => BnnMasterAnalysis.houseOfPlanet(ps[0], chart) == h1 &&
                BnnMasterAnalysis.houseOfPlanet(ps[1], chart) == h2,
        'రెండు గురు-ఆధార భావస్థానాలూ పరిశీలించబడ్డాయి');
    }
    // Exact named-sign pair. Any explicit seventh-from-Jupiter qualifier
    // is also checked, not discarded.
    m = RegExp('^($_p) ($_s) \\+ ($_p) ($_s)(?: \\(గురుకి (\\d{1,2})\\))?\$')
        .firstMatch(text);
    if (m != null) {
      final s1 = _sign(m.group(2)!);
      final s2 = _sign(m.group(4)!);
      final h = m.group(5) == null ? null : int.tryParse(m.group(5)!);
      if (s1 == null || s2 == null || (h != null && (h < 1 || h > 12))) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, [m.group(1)!, m.group(3)!],
        (ps) => ps[0].signIndex == s1 && ps[1].signIndex == s2 &&
          (h == null || BnnMasterAnalysis.houseOfPlanet(ps[1], chart) == h),
        'రెండు నిర్దిష్ట రాశులు; అదనపు భావ షరతు ఉంటే దానినీ పరిశీలించాం');
    }

    // Plain, fully stated relative house: "శని గురుకి 3" or
    // "కేతు కుజకి 3". The reference is the named natal planet, never
    // silently replaced by Jupiter/Lagna.
    m = RegExp('^($_p)\\s+($_p)కి\\s*([0-9౦-౯]{1,2})(?:లో)?\$')
        .firstMatch(text);
    if (m != null) {
      final h = _houseNumber(m.group(3)!);
      if (h == null) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!, m.group(2)!],
          (ps) => _fromReference(ps[0], ps[1]) == h,
          'పేర్కొన్న గ్రహం నుంచి $h వ భావాన్ని లెక్కించాం');
    }

    // Other reference planets, not just natal Jupiter:
    // "శనికి 2లో రాహు", "శుక్రకి 7లో శని".
    m = RegExp('^($_p)కి\\s*([0-9౦-౯]{1,2})లో\\s*($_p)\$')
        .firstMatch(text);
    if (m != null) {
      final h = _houseNumber(m.group(2)!);
      if (h == null) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!, m.group(3)!],
          (ps) => _fromReference(ps[1], ps[0]) == h,
          'మూలగ్రంథంలో పేర్కొన్న మొదటి గ్రహం నుంచి $h వ భావం');
    }

    // All explicitly joined planets in one specified relative house.
    // Never check just the first one (e.g. శనికి 2లో చంద్ర+రాహు).
    m = RegExp('^($_p)కి\\s*([0-9౦-౯]{1,2})లో\\s*'
        '($_p(?:\\+$_p){1,3})\$').firstMatch(text);
    if (m != null) {
      final h = _houseNumber(m.group(2)!);
      if (h == null) return BnnExactIfResult.unsupported;
      final named = m.group(3)!.split('+');
      if (named.toSet().length != named.length ||
          named.contains(m.group(1)!)) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!, ...named],
          (ps) => ps.skip(1).every((p) => _fromReference(p, ps[0]) == h),
          'మూల IFలోని అన్ని గ్రహాలకూ $h వ భావ షరతు తప్పనిసరి');
    }

    // Explicit joined planet group + named sign: "బుధ+శుక్ర తుల".
    // A location cannot be granted solely to the first planet.
    m = RegExp('^($_p(?:\\+$_p){1,3})\\s+($_s)\$').firstMatch(text);
    if (m != null) {
      final h = _sign(m.group(2)!);
      final names = m.group(1)!.split('+');
      if (h == null || names.toSet().length != names.length) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, names,
          (ps) => ps.every((p) => p.signIndex == h),
          'కలిసిన గ్రహాలన్నీ పేర్కొన్న రాశిలో ఉన్నాయా పరిశీలించాం');
    }

    // Explicit conjunction shorthand with no other unchecked IF component.
    m = RegExp('^($_p)(?:\\+($_p)){1,3}(?: ఒకే ఇల్లు)?\$')
        .firstMatch(text);
    if (m != null) {
      final names = text.replaceAll(' ఒకే ఇల్లు', '').split('+');
      if (names.toSet().length != names.length) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, names,
        (ps) => ps.every((p) => p.signIndex == ps.first.signIndex),
        'మూల IFలోని + చిహ్నాన్ని ఒకే రాశి సహస్థితిగా మాత్రమే పరిశీలించాం');
    }

    // Single retrograde or classical exaltation/debilitation sign.
    m = RegExp('^($_p) (వక్రం|ఉచ్చం|నీచం)\$').firstMatch(text);
    if (m != null) {
      const exalt = <String, int>{'Sun': 0, 'Moon': 1, 'Mars': 9,
        'Mercury': 5, 'Jupiter': 3, 'Venus': 11, 'Saturn': 6};
      const debil = <String, int>{'Sun': 6, 'Moon': 7, 'Mars': 3,
        'Mercury': 11, 'Jupiter': 9, 'Venus': 5, 'Saturn': 0};
      final quality = m.group(2)!;
      final name = BnnMasterAnalysis.teluguPlanetNames[m.group(1)!];
      if (name == null || (quality != 'వక్రం' && !exalt.containsKey(name))) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, [m.group(1)!], (ps) {
        if (quality == 'వక్రం') return ps[0].speed < 0;
        return ps[0].signIndex ==
            (quality == 'ఉచ్చం' ? exalt[name] : debil[name]);
      }, quality == 'వక్రం' ? 'జన్మ వేగం (వక్ర స్థితి)' : 'సాంప్రదాయ $quality రాశి');
    }
    // General fully explicit boolean IFs: parenthesized groups, AND > OR,
    // 'మరియు'/'లేదా', and a spaced '+' only between COMPLETE clauses.
    // Every atom is recognized in full. Never treat partial OCR as TRUE.
    return _booleanExpression(text, chart) ?? BnnExactIfResult.unsupported;
  }

  static BnnExactIfResult _checkE10(AstroChartResult chart) {
    final saturn = _planet('శని', chart);
    if (saturn == null) {
      return const BnnExactIfResult(false, false,
          'E10: శని జన్మస్థితి లేదు; OR షరతు గణించలేం.');
    }
    final gemini = saturn.signIndex == 2;
    final virgo = saturn.signIndex == 5;
    final saturnPosition = 'శని ${BnnMasterAnalysis.signNames[saturn.signIndex]} '
        '${saturn.degreesInSign.toStringAsFixed(2)}°';
    if (!gemini && !virgo) {
      return BnnExactIfResult(true, false,
          'E10 ప్రధాన OR: శని మిథునం లేదా కన్యలో ఉండాలి. '
          '$saturnPosition; రెండూ సరిపోలలేదు. అదనపు మిథునం–చంద్ర శాఖ వర్తించదు.');
    }
    final moon = _planet('చంద్ర', chart);
    final extraMatch = gemini && moon != null && moon.signIndex == 3;
    final extraReason = virgo
        ? 'మిథునం AND చంద్ర కర్కాటకం అదనపు శాఖ FALSE (శని కన్యలో ఉన్నాడు).'
        : moon == null
            ? 'అదనపు శాఖకు చంద్రుని స్థానం అందుబాటులో లేదు; దానిని TRUE అనలేదు.'
            : 'అదనపు AND: శని మిథునం AND చంద్ర కర్కాటకం '
              '${extraMatch ? 'TRUE' : 'FALSE'} '
              '(చంద్ర ${BnnMasterAnalysis.signNames[moon.signIndex]}).';
    return BnnExactIfResult(true, true,
        '$saturnPosition • ప్రధాన OR: ${gemini ? 'మిథునం' : 'కన్య'} TRUE. '
        '$extraReason • మూల పుస్తకం OCR ధృవీకరణ వేరుగా అవసరం.',
        matchedThen: extraMatch
            ? 'వ్యాపారవేత్త; మిథునం + చంద్ర కర్కాటకం - మద్యం'
            : 'వ్యాపారవేత్త');
  }

  // Only whitespace-delimited operators are expression separators.
  // A bare planet-pair such as 'గురు+శుక్ర' is an atomic conjunction,
  // while 'గురు మేషం + కేతు వృషభం' is an AND of two full predicates.
  static BnnExactIfResult? _booleanExpression(
      String expression, AstroChartResult chart) {
    final pieces = <String>[];
    final separators = RegExp(
        r'\(|\)|\s+\+\s+|\s+\/\s+|\s+(?:AND|OR|మరియు|లేదా)\s+',
        caseSensitive: false);
    var cursor = 0;
    for (final match in separators.allMatches(expression)) {
      final text = expression.substring(cursor, match.start).trim();
      if (text.isNotEmpty) pieces.add(text);
      final delimiter = match.group(0)!.trim();
      pieces.add(delimiter == '+' || delimiter == 'మరియు' ||
              delimiter.toUpperCase() == 'AND' ? 'AND'
          : delimiter == '/' || delimiter == 'లేదా' ||
              delimiter.toUpperCase() == 'OR' ? 'OR' : delimiter);
      cursor = match.end;
    }
    final tail = expression.substring(cursor).trim();
    if (tail.isNotEmpty) pieces.add(tail);
    if (!pieces.any((piece) => piece == 'AND' || piece == 'OR')) {
      return null; // Avoid silently redefining ordinary single IF syntax.
    }
    var index = 0;
    BnnExactIfResult combine(
        BnnExactIfResult a, BnnExactIfResult b, bool and) {
      final yesA = a.evaluable && a.matched;
      final yesB = b.evaluable && b.matched;
      final noA = a.evaluable && !a.matched;
      final noB = b.evaluable && !b.matched;
      // Three-valued logic: F AND unknown = F; T OR unknown = T.
      final yes = and ? yesA && yesB : yesA || yesB;
      final no = and ? noA || noB : noA && noB;
      final evaluable = yes || no;
      return BnnExactIfResult(evaluable, yes,
          '${and ? 'AND' : 'OR'} '
          '[${a.reason}] | [${b.reason}] • '
          '${evaluable ? (yes ? 'TRUE' : 'FALSE') : 'షరతు అసంపూర్ణం'}');
    }
    BnnExactIfResult? parseOr() {
      BnnExactIfResult? parseAnd() {
        BnnExactIfResult? parseAtom() {
          if (index >= pieces.length) return null;
          if (pieces[index] == '(') {
            index++;
            final inside = parseOr();
            if (inside == null || index >= pieces.length ||
                pieces[index] != ')') return null;
            index++;
            return inside;
          }
          if (pieces[index] == 'AND' || pieces[index] == 'OR' ||
              pieces[index] == ')') return null;
          return _atomicPredicate(pieces[index++], chart);
        }
        var left = parseAtom();
        if (left == null) return null;
        while (index < pieces.length && pieces[index] == 'AND') {
          index++;
          final right = parseAtom();
          if (right == null) return null;
          left = combine(left!, right, true);
        }
        return left;
      }
      var left = parseAnd();
      if (left == null) return null;
      while (index < pieces.length && pieces[index] == 'OR') {
        index++;
        final right = parseAnd();
        if (right == null) return null;
        left = combine(left!, right, false);
      }
      return left;
    }
    final value = parseOr();
    return value != null && index == pieces.length ? value : null;
  }

  static BnnExactIfResult _atomicPredicate(String text,
      AstroChartResult chart) {
    RegExpMatch? m;
    // Full named sign disjunction: Saturn Gemini/Virgo.
    m = RegExp('^($_p(?:\\+$_p){0,3})\\s+($_s(?:\\/$_s)*)\$')
        .firstMatch(text);
    if (m != null) {
      final signs = m.group(2)!.split('/').map(_sign).toList();
      if (signs.contains(null)) return BnnExactIfResult.unsupported;
      final planets = m.group(1)!.split('+');
      if (planets.toSet().length != planets.length) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, planets,
          (ps) => ps.every((p) => signs.contains(p.signIndex)),
          'రాశుల OR ${m.group(2)} (జాబితాలోని ఒక్కొక్క గ్రహానికి వర్తింపు)');
    }
    m = RegExp('^($_p)కి\\s*([0-9౦-౯]{1,2})లో\\s*($_p)\$')
        .firstMatch(text);
    if (m != null) {
      final h = _houseNumber(m.group(2)!);
      if (h == null) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!, m.group(3)!],
          (ps) => _fromReference(ps[1], ps[0]) == h,
          'పేర్కొన్న గ్రహానికి $h వ భావం');
    }
    m = RegExp('^($_p)\\s+($_p)కి\\s*([0-9౦-౯]{1,2})(?:లో)?\$')
        .firstMatch(text);
    if (m != null) {
      final h = _houseNumber(m.group(3)!);
      if (h == null) return BnnExactIfResult.unsupported;
      return _checkPlanets(chart, [m.group(1)!, m.group(2)!],
          (ps) => _fromReference(ps[0], ps[1]) == h,
          'పేర్కొన్న గ్రహం నుంచి $h వ భావం');
    }
    // A bare conjunct planet group is valid; a single bare planet is not.
    m = RegExp('^$_p(?:\\+$_p){1,3}\$').firstMatch(text);
    if (m != null) {
      final names = text.split('+');
      if (names.toSet().length != names.length) {
        return BnnExactIfResult.unsupported;
      }
      return _checkPlanets(chart, names,
          (ps) => ps.every((p) => p.signIndex == ps.first.signIndex),
          'అన్ని గ్రహాలు ఒకే రాశిలో');
    }
    return BnnExactIfResult.unsupported;
  }
}
