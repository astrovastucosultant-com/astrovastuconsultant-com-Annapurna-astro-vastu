import 'astro_models.dart';
import 'bnn_nadi_degree_engine.dart';

/// Two independent BNN *natal relationship enumeration* methods.
/// These are not automatic prediction rules. A matched original source IF
/// remains necessary before any THEN is displayed as a chart-specific result.
/// All subsets are generated exactly once per method, without artificial
/// pair-to-trio inference, and the methods are never merged as a single vote.
class BnnCombination {
  final String methodId;
  final List<PlanetPosition> orderedPlanets;
  final bool unresolvedDegreeOrder;
  final int? trineGroup;

  const BnnCombination({
    required this.methodId,
    required this.orderedPlanets,
    this.unresolvedDegreeOrder = false,
    this.trineGroup,
  });

  /// Add *within-sign* 0°..30° DMS for every member of this exact
  /// combination. This is numerical evidence only, NOT an event year.
  /// Integer arcseconds prevent floating-point carry and preserve seconds.
  int get localDegreeSumArcseconds => orderedPlanets.fold<int>(
      0, (total, p) => total + BnnNadiDegreeEngine.roundedArcseconds(p));

  static String _formatArcseconds(int seconds) {
    final d = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    final sec = seconds % 60;
    return '$d°${m.toString().padLeft(2, '0')}′${sec.toString().padLeft(2, '0')}″';
  }

  String get degreeAdditionEquation =>
      '${orderedPlanets.map((p) => _formatArcseconds(
        BnnNadiDegreeEngine.roundedArcseconds(p))).join(' + ')}'
      ' = ${_formatArcseconds(localDegreeSumArcseconds)}';

  int get completedThirtyDegreeBlocks =>
      localDegreeSumArcseconds ~/ (30 * 3600);
  String get residueWithinThirtyDegrees =>
      _formatArcseconds(localDegreeSumArcseconds % (30 * 3600));

  int get size => orderedPlanets.length;
  String get memberKey =>
      (orderedPlanets.map((p) => p.name).toList()..sort()).join('|');
  String get positionalChain => orderedPlanets.map((p) =>
      '${BnnNadiDegreeEngine.teluguName(p)} '
      '${BnnNadiDegreeEngine.dms(p)}${p.retrograde ? ' (వక్ర)' : ''}')
      .join(' → ');

  /// These are sign links for inspecting the chain, not inferred yogas or THENs.
  List<String> get pairEvidence {
    final evidence = <String>[];
    for (var i = 0; i < orderedPlanets.length; i++) {
      final a = orderedPlanets[i];
      for (var j = i + 1; j < orderedPlanets.length; j++) {
        final b = orderedPlanets[j];
        final sa = BnnNadiDegreeEngine.zodiacSign(a.longitude);
        final sb = BnnNadiDegreeEngine.zodiacSign(b.longitude);
        final distance = BnnNadiDegreeEngine.offset(sa, sb);
        final house = distance + 1;
        String kind;
        if (distance == 0) {
          kind = 'ఒకే రాశి';
        } else if (distance == 4 || distance == 8) {
          kind = '1–5–9 త్రికోణం';
        } else if (distance == 1) {
          kind = 'తదుపరి రాశి';
        } else if (distance == 11) {
          kind = 'ముందు రాశి';
        } else if (distance == 2 || distance == 6 || distance == 10) {
          kind = '3–7–11 సంబంధం ($houseవ స్థానం)';
        } else {
          kind = 'రాశి దూరం మాత్రమే';
        }
        // BNN_159_12 node profile is directional: when the *source*
        // graha is Rahu/Ketu, allow 1-5-9 and 12th, not 2nd/3-7-11.
        if ((a.name == 'Rahu' || a.name == 'Ketu') &&
            !(distance == 0 || distance == 4 || distance == 8 ||
              distance == 11)) {
          kind = 'రాహు/కేతు మూలగ్రహం: BNN_159_12లో ఈ సంబంధం వర్తించదు';
        }
        evidence.add('${BnnNadiDegreeEngine.teluguName(a)} → '
            '${BnnNadiDegreeEngine.teluguName(b)}: '
            '$houseవ రాశి • $kind');
      }
    }
    return evidence;
  }
}

/// One *directed* relationship, measured from the anchor graha.
/// A -> B is not interchangeable with B -> A for 2/12, 3/11, 5/9.
class BnnDirectedRelation {
  final PlanetPosition anchor;
  final PlanetPosition target;
  final int house;
  final String family;

  const BnnDirectedRelation({
    required this.anchor,
    required this.target,
    required this.house,
    required this.family,
  });

  String get evidence =>
      '${BnnNadiDegreeEngine.teluguName(target)} '
      '${BnnNadiDegreeEngine.dms(target)} • $houseవ స్థానం';
}

class BnnCombinationEngine {
  static const localDegreeTrine = 'LOCAL_DEGREE_TRINE_ASC';
  static const jupiterFirst = 'JUPITER_FIRST_RELATIVE_HOUSES';

  /// Every graha as its own reference (not just Jupiter). The selected
  /// BNN_159_12 node profile permits node-origin 1-5-9 and 12 only.
  /// The output is geometrical evidence, not 462-source IF verification.
  static List<BnnDirectedRelation> relationsFromEveryPlanet(
      AstroChartResult chart) {
    final all = chart.planets.toList(growable: false);
    final result = <BnnDirectedRelation>[];
    for (final anchor in all) {
      final aSign = BnnNadiDegreeEngine.zodiacSign(anchor.longitude);
      final fromNode = anchor.name == 'Rahu' || anchor.name == 'Ketu';
      for (final target in all) {
        if (anchor.name == target.name) continue;
        final house = BnnNadiDegreeEngine.offset(
          aSign, BnnNadiDegreeEngine.zodiacSign(target.longitude)) + 1;
        String? family;
        if (house == 1 || house == 5 || house == 9) {
          family = '1–5–9';
        } else if (!fromNode &&
            (house == 3 || house == 7 || house == 11)) {
          family = '3–7–11';
        } else if (house == 12 || (!fromNode && house == 2)) {
          family = '2–12';
        }
        if (family != null) {
          result.add(BnnDirectedRelation(anchor: anchor,
              target: target, house: house, family: family));
        }
      }
    }
    result.sort((a, b) {
      final nameOrder = a.anchor.name.compareTo(b.anchor.name);
      if (nameOrder != 0) return nameOrder;
      final houseOrder = a.house.compareTo(b.house);
      return houseOrder != 0
          ? houseOrder : a.target.name.compareTo(b.target.name);
    });
    return List.unmodifiable(result);
  }


  static const allGrahaDirected = 'ALL_GRAHA_DIRECTIONAL_159_3711_212';

  /// Every graha as anchor. Form all non-empty subsets of grahas linked from
  /// that anchor under the explicitly chosen BNN relation profile. Distinct
  /// anchors produce distinct *inspection paths*, NOT distinct final events.
  static List<BnnCombination> everyPlanetAnchored(AstroChartResult chart) {
    final directed = relationsFromEveryPlanet(chart);
    final result = <BnnCombination>[];
    for (final anchor in chart.planets) {
      final connected = directed.where((r) => r.anchor.name == anchor.name)
          .map((r) => r.target).toList(growable: false);
      final aSign = BnnNadiDegreeEngine.zodiacSign(anchor.longitude);
      _combinations(connected, minSize: 1, onSubset: (subset) {
        final ordered = [...subset]..sort((a, b) {
          final da = BnnNadiDegreeEngine.offset(
              aSign, BnnNadiDegreeEngine.zodiacSign(a.longitude));
          final db = BnnNadiDegreeEngine.offset(
              aSign, BnnNadiDegreeEngine.zodiacSign(b.longitude));
          return da == db ? _compareLocalDegrees(a, b) : da.compareTo(db);
        });
        result.add(BnnCombination(
          methodId: allGrahaDirected,
          orderedPlanets: List.unmodifiable([anchor, ...ordered]),
          unresolvedDegreeOrder: _hasTiedDegree(ordered,
              onlyWithinSameSign: true),
        ));
      });
    }
    result.sort((a, b) {
      final count = a.size.compareTo(b.size);
      if (count != 0) return count;
      final anchor = a.orderedPlanets.first.name
          .compareTo(b.orderedPlanets.first.name);
      return anchor == 0 ? a.memberKey.compareTo(b.memberKey) : anchor;
    });
    return List.unmodifiable(result);
  }

  /// Exhaustive combinations of 2..N within each distinct 1–5–9 group.
  /// Ordered by the local sign-degree 0..30, never by 0..360 longitude.
  static List<BnnCombination> degreeTrine(AstroChartResult chart) {
    final result = <BnnCombination>[];
    for (final group in BnnNadiDegreeEngine.sequences(chart)) {
      _combinations(group.planets, minSize: 2, onSubset: (subset) {
        final planets = [...subset]..sort(_compareLocalDegrees);
        result.add(BnnCombination(
          methodId: localDegreeTrine,
          orderedPlanets: List.unmodifiable(planets),
          trineGroup: group.trineGroup,
          unresolvedDegreeOrder: _hasTiedDegree(planets),
        ));
      });
    }
    result.sort(_compareCombination);
    return List.unmodifiable(result);
  }

  /// Exhaustive Jupiter-centred subsets: natal Jupiter plus any non-empty
  /// subset of other natal planets. Jupiter is the anchor, not necessarily
  /// the lowest-degree planet. Remaining planets follow forward sign count
  /// from natal Jupiter, with local degree used only for same-sign ordering.
  static List<BnnCombination> jupiterCentred(AstroChartResult chart) {
    final jupiter = BnnNadiDegreeEngine.planet(chart, 'Jupiter');
    if (jupiter == null) return const [];
    final others = chart.planets.where((p) => p.name != 'Jupiter').toList();
    final js = BnnNadiDegreeEngine.zodiacSign(jupiter.longitude);
    final result = <BnnCombination>[];
    _combinations(others, minSize: 1, onSubset: (subset) {
      final ordered = [...subset]..sort((a, b) {
        final da = BnnNadiDegreeEngine.offset(
            js, BnnNadiDegreeEngine.zodiacSign(a.longitude));
        final db = BnnNadiDegreeEngine.offset(
            js, BnnNadiDegreeEngine.zodiacSign(b.longitude));
        return da == db ? _compareLocalDegrees(a, b) : da.compareTo(db);
      });
      result.add(BnnCombination(
        methodId: jupiterFirst,
        orderedPlanets: List.unmodifiable([jupiter, ...ordered]),
        unresolvedDegreeOrder: _hasTiedDegree(ordered,
            onlyWithinSameSign: true),
      ));
    });
    result.sort(_compareCombination);
    return List.unmodifiable(result);
  }

  static int _compareCombination(BnnCombination a, BnnCombination b) {
    final c = a.size.compareTo(b.size);
    return c == 0 ? a.memberKey.compareTo(b.memberKey) : c;
  }

  static int _compareLocalDegrees(PlanetPosition a, PlanetPosition b) {
    final c = BnnNadiDegreeEngine.roundedArcseconds(a)
        .compareTo(BnnNadiDegreeEngine.roundedArcseconds(b));
    // Stable deterministic *display* order for ties, but never assert an
    // astronomical first/last when rounded DMS values are equal.
    return c == 0 ? a.name.compareTo(b.name) : c;
  }

  static bool _hasTiedDegree(List<PlanetPosition> p,
      {bool onlyWithinSameSign = false}) {
    for (var i = 0; i < p.length; i++) {
      for (var j = i + 1; j < p.length; j++) {
        if (onlyWithinSameSign &&
            BnnNadiDegreeEngine.zodiacSign(p[i].longitude) !=
                BnnNadiDegreeEngine.zodiacSign(p[j].longitude)) continue;
        if (BnnNadiDegreeEngine.roundedArcseconds(p[i]) ==
            BnnNadiDegreeEngine.roundedArcseconds(p[j])) return true;
      }
    }
    return false;
  }

  /// 9 classical grahas -> <= 2^9 subsets per method. No arbitrary
  /// fixed maximum such as three or four planets; 2..9 are supported.
  static void _combinations(List<PlanetPosition> planets, {
    required int minSize,
    required void Function(List<PlanetPosition>) onSubset,
  }) {
    final n = planets.length;
    if (n < minSize) return;
    // Avoid bit overflow / pathological data (chart is expected to contain 9).
    if (n > 12) throw ArgumentError('BNN expects at most 12 chart positions');
    for (var mask = 1; mask < (1 << n); mask++) {
      final subset = <PlanetPosition>[];
      for (var bit = 0; bit < n; bit++) {
        if ((mask & (1 << bit)) != 0) subset.add(planets[bit]);
      }
      if (subset.length >= minSize) onSubset(subset);
    }
  }
}
