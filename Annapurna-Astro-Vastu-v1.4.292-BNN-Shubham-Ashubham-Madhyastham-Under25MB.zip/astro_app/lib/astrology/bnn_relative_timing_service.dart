import 'astro_models.dart';
import 'bnn_master_service.dart';

/// User-specified BNN progression: one natal-Jupiter sign per symbolic year.
/// Each ordinal house produces a nominal [ageStart, ageEnd) window in every
/// 12-year round. It is NOT a real Jupiter transit or an event assertion.
class BnnRelativeTimingWindow {
  final int house;
  final int round;
  final int ageStart;
  final int ageEnd;
  final int calendarStartYear;
  final int calendarEndYear;
  const BnnRelativeTimingWindow({required this.house,
    required this.round, required this.ageStart, required this.ageEnd,
    required this.calendarStartYear, required this.calendarEndYear});

  int get ordinalLifeYear => ageEnd;
  String get summary => 'జీవిత $ordinalLifeYear వ సంవత్సరం • '
      'పూర్తయిన వయస్సు $ageStart–$ageEnd • '
      'సుమారు $calendarStartYear–$calendarEndYear';
}

/// A chart-specific annual *symbolic* reading.  The result always names
/// the graha-karakatwa and the natal-Jupiter house; a matched source THEN is
/// shown separately and never promoted to an observed event or transit date.
/// Interpretation of natal evidence for a SYMBOLIC age window. It does not
/// mean that a specific event, outcome or transit has been established.
enum BnnPeriodTone { favourable, unfavourable, mixed }

extension BnnPeriodToneLabel on BnnPeriodTone {
  String get teluguLabel {
    switch (this) {
      case BnnPeriodTone.favourable: return 'శుభం';
      case BnnPeriodTone.unfavourable: return 'అశుభం';
      case BnnPeriodTone.mixed: return 'మధ్యస్థం';
    }
  }
}

class BnnPeriodReading {
  final BnnPeriodTone tone;
  final String toneBasis;
  final String rule;
  final String inspection;
  final String result;
  final String headline;
  const BnnPeriodReading({required this.tone, required this.toneBasis,
      required this.rule, required this.inspection,
      required this.result, required this.headline});
}

class BnnRelativeTimingService {
  static int relativeHouse(int referenceSign, int targetSign) =>
      1 + (targetSign - referenceSign + 12) % 12;

  static const _planetNames = <String, String>{
    'Sun': 'రవి', 'Moon': 'చంద్రుడు', 'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు', 'Venus': 'శుక్రుడు',
    'Saturn': 'శని', 'Rahu': 'రాహువు', 'Ketu': 'కేతువు',
  };

  /// Each line is a topic-specific, round-sensitive *suggested result*, not
  /// an assertion that an event must occur.  R-A03 has only SIX rounds.
  /// The 7th round is consequently not assigned an invented source dictum.
  static const _roundEffects = <String, List<String>>{
    'Sun': [
      'తండ్రి సహకారం, చదువులో నాయకత్వ లక్షణాలు ప్రధానమవుతాయి',
      'ఉద్యోగ ప్రవేశం, అధికారులతో పరిచయాలు, కుటుంబ గౌరవం ముఖ్యమవుతాయి',
      'ఉద్యోగ స్థల మార్పు, పదవి లేదా గుర్తింపు కోసం ప్రయత్నాలు ఉంటాయి',
      'గృహ నిర్ణయాల్లో తండ్రి లేదా ఉన్నతాధికారుల సహకారం అవసరమవుతుంది',
      'సంతానం విద్య/ఉద్యోగం, కుటుంబ ప్రతిష్ఠపై శ్రద్ధ పెరుగుతుంది',
      'అధికార, కుటుంబ పత్రాల నిర్వహణలో జాగ్రత్త అవసరమవుతుంది',
      'కుటుంబ గౌరవం, తండ్రి వారసత్వ వ్యవహారాల నిర్వహణ ప్రధానమవుతుంది',
    ],
    'Moon': [
      'తల్లి, చదువు, నివాస వాతావరణంలో మార్పులకు ప్రాధాన్యం వస్తుంది',
      'కుటుంబ స్థిరత్వం, ఆదాయ వినియోగం, నివాస నిర్ణయాలు ముఖ్యమవుతాయి',
      'ప్రయాణాలు, నివాస/ఉద్యోగ స్థల మార్పు అవకాశాలు ప్రధానమవుతాయి',
      'ఇల్లు, తల్లి, వాహనం, గృహసౌఖ్య కార్యక్రమాలు ముఖ్యమవుతాయి',
      'సంతాన సంరక్షణ, కుటుంబ ప్రయాణాలపై శ్రద్ధ అవసరమవుతుంది',
      'ప్రయాణ అలసట, గృహ ఖర్చుల విషయంలో ముందుజాగ్రత్త అవసరమవుతుంది',
      'కుటుంబంతో సమయం, నివాస సౌకర్యాల నిర్వహణ ప్రధానమవుతుంది',
    ],
    'Mars': [
      'విద్య, ధైర్యం, సోదర సంబంధాలు, చురుకైన ప్రయత్నాలు ప్రధానమవుతాయి',
      'వృత్తి ప్రారంభ ప్రయత్నాలు, భూమి/ఆస్తి నిర్ణయాలు, కుటుంబ ఆర్థిక బాధ్యతలు ముందుకు వస్తాయి',
      'సోదర సహకారం, ప్రయాణాలు, స్థిరాస్తి కొనుగోలు లేదా వ్యాపార ప్రయత్నాలు ప్రధానమవుతాయి',
      'ఇల్లు కొనుగోలు/నిర్మాణం, భూమి పత్రాలు, కుటుంబ ఆస్తి నిర్వహణ ముఖ్యమవుతాయి',
      'సంతాన బాధ్యతలు, కుటుంబ ఆస్తి పంచకం లేదా స్థిరాస్తి ప్రణాళికలు ముందుకు వస్తాయి',
      'ఆస్తి లావాదేవీలు, వాహన ప్రయాణాలు, వివాదాల నివారణలో జాగ్రత్త అవసరమవుతుంది',
      'కుటుంబ స్థిరాస్తి నిర్వహణ, సోదరుల సహకారంపై శ్రద్ధ పెరుగుతుంది',
    ],
    'Mercury': [
      'విద్య, పరీక్షలు, వ్రాత నైపుణ్యం, స్నేహ సంబంధాలు ప్రధానమవుతాయి',
      'ఉద్యోగ నైపుణ్యాలు, లెక్కలు, ఒప్పందాలు, చిన్న వ్యాపార ప్రయత్నాలు ముందుకు వస్తాయి',
      'వ్యాపార ప్రయాణాలు, కమ్యూనికేషన్, కొత్త పరిచయాలు లాభదాయకంగా మారే అవకాశం ఉంది',
      'ఇల్లు/ఆస్తి పత్రాలు, రుణాల లెక్కలు, ఒప్పందాల నిర్వహణ ప్రధానమవుతుంది',
      'సంతానం చదువు, సలహాలు, విద్యా ప్రణాళికలపై శ్రద్ధ పెరుగుతుంది',
      'పత్రాలు, లెక్కలు, రుణాలు లేదా ఒప్పందాల్లో జాగ్రత్త అవసరమవుతుంది',
      'పత్రాల నిర్వహణ, బోధన, కుటుంబ సంప్రదింపులు ప్రధానమవుతాయి',
    ],
    'Venus': [
      'కళలు, స్నేహం, కుటుంబ సౌకర్యాలు, సృజనాత్మక విద్య ప్రధానమవుతాయి',
      'ధన ఆదాయం, సంబంధాలు, వివాహ ప్రయత్నాలు లేదా భాగస్వామ్య నిర్ణయాలు ముఖ్యమవుతాయి',
      'ఆదాయ మార్గాలు, వ్యాపార భాగస్వామ్యం, ప్రయాణాలపై దృష్టి పెరుగుతుంది',
      'ఇల్లు, వాహనం, విలాస వస్తువులు లేదా గృహ సౌకర్యాల కోసం ఖర్చులు ఉంటాయి',
      'సంతానం, కుటుంబ సంతోషం, కళా అభిరుచులకు ప్రాధాన్యం వస్తుంది',
      'ధన వినియోగం, సంబంధాల్లో విభేదాలు, వాహన ఖర్చులపై జాగ్రత్త అవసరమవుతుంది',
      'కుటుంబ సౌఖ్యం, ధన నిర్వహణ, కళా ఆసక్తులు ప్రధానమవుతాయి',
    ],
    'Saturn': [
      'క్రమశిక్షణ, శ్రమ, చదువులో ఆలస్యాలు లేదా బాధ్యతలు ప్రధానమవుతాయి',
      'ఉద్యోగం, సేవ, వృత్తి సాధన, కుటుంబ సంపాదన బాధ్యతలు పెరుగుతాయి',
      'పని కారణంగా ప్రయాణం/బదిలీ, సోదర సంబంధ బాధ్యతలు ముందుకు వస్తాయి',
      'ఇల్లు, ఆస్తి పనుల్లో దీర్ఘకాల శ్రమ, ఆలస్యాల నివారణ అవసరమవుతుంది',
      'సంతాన బాధ్యతలు, దీర్ఘకాల పెట్టుబడులు, కుటుంబ ఖర్చుల నిర్వహణ ప్రధానమవుతుంది',
      'వృత్తి ఒత్తిడి, రుణాలు, పాత బాధ్యతల పరిష్కారంపై జాగ్రత్త అవసరమవుతుంది',
      'పెన్షన్, సేవింగ్స్, కుటుంబ బాధ్యతల సర్దుబాటు ప్రధానమవుతుంది',
    ],
    'Rahu': [
      'కొత్త నైపుణ్యాలు, విదేశీ భాషలపై ఆసక్తి, అసాధారణ అవకాశాలు కనిపించవచ్చు',
      'విదేశీ సంబంధాలు, ఉద్యోగ/వ్యాపార మార్పుల ప్రయత్నాల్లో అధిక ఆశలకు జాగ్రత్త అవసరం',
      'సుదూర ప్రయాణాలు, కొత్త రంగాల పరిచయాలు, స్నేహ వర్గ మార్పులు ముఖ్యమవుతాయి',
      'నివాస మార్పు, భూమి/పత్రాల తనిఖీ, కొత్త పెట్టుబడుల్లో జాగ్రత్త అవసరం',
      'సంతానం విద్య, విదేశీ అవకాశాలు, ఊహాపోహల ఆధార నిర్ణయాలకు జాగ్రత్త అవసరం',
      'పెట్టుబడులు, రుణాలు, ప్రయాణాల్లో జాగ్రత్తగా వ్యవహరించాలి',
      'విదేశీ కుటుంబ సంబంధాలు, పాత పెట్టుబడుల సమీక్ష ప్రధానమవుతాయి',
    ],
    'Ketu': [
      'ఏకాగ్రత, ఆధ్యాత్మిక ఆసక్తి, చదువులో దిశ నిర్ణయానికి ప్రాధాన్యం వస్తుంది',
      'వృత్తి మార్పు ఆలోచనలు, కుటుంబ బాధ్యతలు, ఏకాంతంగా పనిచేసే రంగాలు ప్రధానమవుతాయి',
      'ఆధ్యాత్మిక ప్రయాణాలు, సోదర సంబంధ దూరాలు లేదా జీవన దిశ మార్పుల ఆలోచనలు ఉంటాయి',
      'నివాసంలో మార్పులు, పాత భూమి/ఇంటి సమస్యల పరిష్కార ప్రయత్నాలు ప్రధానమవుతాయి',
      'సంతానం, ఆధ్యాత్మిక విద్య, కుటుంబ ప్రాధాన్యతల పునఃపరిశీలన ప్రధానమవుతుంది',
      'ఆరోగ్యం, ఆస్తి పత్రాలు, అనవసర విభేదాల్లో ముందుజాగ్రత్త అవసరం',
      'ఆధ్యాత్మిక సాధన, కుటుంబ వ్యవహారాల సరళీకరణ ప్రధానమవుతాయి',
    ],
  };

  // Read BNN source THEN wording conservatively. This is an evidence tag,
  // not a claim that a life event is known or an astrological rule is proven.
  static const _favourableWords = <String>[
    'లాభం', 'లాభాలు', 'అభివృద్ధి', 'వృద్ధి', 'శుభం', 'విజయం',
    'ఉన్నతి', 'ప్రమోషన్', 'ఉద్యోగం లభి', 'ఉద్యోగం పొందు',
    'సంపాదన', 'ఆదాయం పెరుగు', 'సంతోషం', 'సౌఖ్యం', 'గౌరవం',
  ];
  static const _unfavourableWords = <String>[
    'నష్టం', 'నష్టాలు', 'వివాదం', 'వివాదాలు', 'కలహం', 'గొడవ',
    'ఆలస్యం', 'జాప్యం', 'విడాకులు', 'విడిపో', 'అనారోగ్యం',
    'రోగం', 'వ్యాధి', 'ప్రమాదం', 'అవమానం', 'పతనం',
    'అప్పులు', 'ఋణం', 'కోర్టు కేసు', 'కష్టాలు', 'లేదు',
  ];

  /// Only exact natal source IF hits are accepted by the caller.
  /// Near (<=3 degrees, allowed up to 5) conjunction or 1-5-9 sign links
  /// identify possible supportive/challenging associations. Trines beyond
  /// 5 degrees do not invent a decisive contact. No timed transits here.
  static ({BnnPeriodTone tone, String basis}) _classifyNatalEvidence({
    required AstroChartResult chart,
    required PlanetPosition target,
    required List<BnnMasterRule> passingSource,
  }) {
    final favourable = <String>[];
    final unfavourable = <String>[];
    for (final other in chart.planets) {
      if (other.name == target.name) continue;
      final house = relativeHouse(target.signIndex, other.signIndex);
      if (house != 1 && house != 5 && house != 9) continue;
      final difference = (target.degreesInSign - other.degreesInSign).abs();
      if (difference > 5) continue;
      final name = _planetNames[other.name] ?? (other.name == 'Jupiter'
          ? 'గురు' : other.name);
      final note = '$name ($house వ రాశి, డిగ్రీ తేడా '
          '${difference.toStringAsFixed(2)}°)';
      if (other.name == 'Jupiter' || other.name == 'Venus') {
        favourable.add(note);
      } else if (const {'Saturn', 'Mars', 'Rahu', 'Ketu'}
          .contains(other.name)) {
        unfavourable.add(note);
      }
      // Moon, Sun and unafflicted Mercury alone do not establish polarity.
    }
    for (final rule in passingSource) {
      final positive = _favourableWords.any(rule.result.contains);
      final negative = _unfavourableWords.any(rule.result.contains);
      if (positive) favourable.add('మూల IF ${rule.id}');
      if (negative) unfavourable.add('మూల IF ${rule.id}');
    }
    final tone = favourable.isNotEmpty && unfavourable.isEmpty
        ? BnnPeriodTone.favourable
        : unfavourable.isNotEmpty && favourable.isEmpty
            ? BnnPeriodTone.unfavourable
            : BnnPeriodTone.mixed;
    final basis = <String>[
      if (favourable.isNotEmpty) 'శుభ సంబంధాలు: ${favourable.join(', ')}',
      if (unfavourable.isNotEmpty) 'పాప సంబంధాలు: ${unfavourable.join(', ')}',
      if (favourable.isEmpty && unfavourable.isEmpty)
        'ఈ గ్రహానికి 5° లోపు నిర్ణయాత్మక శుభ/పాప సంబంధం లేదా స్పష్టమైన మూల IF ఫలితం లేదు',
    ].join('; ');
    return (tone: tone, basis: basis);
  }

  /// Calendar endpoints are birthday anniversaries for the symbolic age
  /// bracket, not verified event dates. Clamps Feb 29 on non-leap years.
  static DateTime _birthday(DateTime birth, int age) {
    final year = birth.year + age;
    final lastDay = DateTime(year, birth.month + 1, 0).day;
    final day = birth.day > lastDay ? lastDay : birth.day;
    return DateTime(year, birth.month, day);
  }

  static String birthdayRange(DateTime birth, BnnRelativeTimingWindow w) {
    String fmt(DateTime d) =>
        '${d.day.toString().padLeft(2, '0')}-'
        '${d.month.toString().padLeft(2, '0')}-${d.year}';
    return '${fmt(_birthday(birth, w.ageStart))} → '
        '${fmt(_birthday(birth, w.ageEnd))}';
  }

  static BnnPeriodReading inspectPeriod({
    required AstroChartResult chart,
    required PlanetPosition jupiter,
    required PlanetPosition target,
    required BnnRelativeTimingWindow window,
    List<BnnMasterRule> passingSource = const [],
  }) {
    final house = relativeHouse(jupiter.signIndex, target.signIndex);
    if (house != window.house) {
      throw ArgumentError('Jupiter house and annual window do not agree');
    }
    final name = _planetNames[target.name] ?? target.name;
    final list = _roundEffects[target.name];
    final effect = list == null
        ? 'ఈ గ్రహానికి సంబంధించిన కారక అంశాలను పరిశీలించాలి'
        : list[(window.round - 1).clamp(0, list.length - 1).toInt()];
    final nativeHouse = 1 +
        (target.signIndex - chart.ascendantSignIndex + 12) % 12;
    final verdict = _classifyNatalEvidence(
      chart: chart, target: target, passingSource: passingSource);
    final confirmedText = passingSource.isEmpty
        ? ''
        : ' పూర్తి జన్మ IF సరిపోయిన మూల ఫలితాలు: '
            '${passingSource.take(3).map((r) => '${r.result} (${r.id})').join('; ')}.';
    final roundRule = window.round <= 6
        ? 'BNN-BOOK-R-A03 (${window.round}వ గురు చక్రం)'
        : '7వ చక్రానికి R-A03లో ప్రత్యేక ఫలిత నియమం లేదు';
    final rule = 'BNN-BOOK-R-A08 (గురు–గ్రహ కారక సూత్రం) • '
        '$roundRule • సిద్ధాంతి అన్వయ రూల్ (భావం + కారకత్వం)';
    final inspection = 'జన్మగురు '
        '${BnnMasterAnalysis.signNames[jupiter.signIndex]} '
        '${jupiter.degreesInSign.toStringAsFixed(2)}°; '
        '$name ${BnnMasterAnalysis.signNames[target.signIndex]} '
        '${target.degreesInSign.toStringAsFixed(2)}°; '
        'గురు నుంచి $house వ భావం; D1 లగ్నం నుంచి $nativeHouse వ భావం. '
        '${verdict.basis}.';
    final bhavaTheme = BnnMasterAnalysis.houseTheme(house);
    final outcome = '${verdict.tone.teluguLabel} — $name కారకత్వంతో $effect. '
        '$house వ భావానికి సంబంధించిన అంశాలు: $bhavaTheme.$confirmedText';
    // Round 1-6 are the only round-level dictums in the supplied catalog.
    // An event date or a definite positive/negative outcome additionally
    // needs a fully defined natal event IF, transit and overlapping timing.
    return BnnPeriodReading(
        tone: verdict.tone, toneBasis: verdict.basis,
        rule: rule, inspection: inspection,
        result: outcome, headline: effect);
  }

  /// BNN-M-046. `birthYear` alone supports a *year-range*, not an exact date.
  static List<BnnRelativeTimingWindow> annualJupiterWindows({
    required int house,
    required int birthYear,
    int maximumAge = 84,
  }) {
    if (house < 1 || house > 12 || maximumAge < 0) {
      throw ArgumentError('Invalid symbolic window');
    }
    final result = <BnnRelativeTimingWindow>[];
    for (var round = 0; round * 12 + house - 1 < maximumAge; round++) {
      final start = round * 12 + house - 1;
      final end = start + 1;
      result.add(BnnRelativeTimingWindow(
          house: house, round: round + 1,
          ageStart: start, ageEnd: end,
          calendarStartYear: birthYear + start,
          calendarEndYear: birthYear + end));
    }
    return result;
  }

  /// Optional age-only summary for a source IF with an explicitly stated
  /// Jupiter-relative planet location; never changes the THEN itself.
  static String? ageWindowsForRule(BnnMasterRule rule,
      AstroChartResult chart, int birthYear) {
    final matcher = RegExp(
        r'గురుకి\s*([0-9]{1,2})లో\s*'
        r'(సూర్యుడు|సూర్య|రవి|చంద్రుడు|చంద్ర|కుజుడు|కుజ|'
        r'బుధుడు|బుధ|శుక్రుడు|శుక్ర|శుకుడు|శని|రాహువు|రాహు|'
        r'కేతువు|కేతు)');
    final match = matcher.firstMatch(rule.condition);
    if (match == null) return null;
    final h = int.tryParse(match.group(1)!);
    if (h == null || h < 1 || h > 12) return null;
    final english = <String, String>{
      'శుకుడు': 'Venus',
    }[match.group(2)!] ??
        BnnMasterAnalysis.teluguPlanetNames[match.group(2)!];
    final jupiter = natalPlanet(chart, 'Jupiter');
    final target = english == null ? null : natalPlanet(chart, english);
    if (jupiter == null || target == null) return null;
    final actualHouse = relativeHouse(jupiter.signIndex, target.signIndex);
    if (actualHouse != h) return null;
    final windows = annualJupiterWindows(house: h, birthYear: birthYear);
    return 'మూల IFలోని గ్రహస్థానం సరిపోయింది: గురువుకు $h వ భావం. '
        'JUPITER_1SIGN_PER_YEAR_APPROX కాల సూచికలు: '
        '${windows.take(7).map((w) => w.summary).join('; ')}. '
        'ఇవి ప్రోగ్రెషన్ సూచికలు మాత్రమే; మూల IFలో ఇతర షరతులు '
        'ఉంటే అవి కూడా గణించాలి. నిజ గోచార తేదీలు వేరు.';
  }

  static PlanetPosition? natalPlanet(AstroChartResult chart, String name) {
    for (final p in chart.planets) {
      if (p.name == name) return p;
    }
    return null;
  }

  /// Only explicit Jupiter-relative source placements are listed.  Rules
  /// with added conditions (e.g., C64 7th lord) remain *conditional* and
  /// must pass the exact IF evaluator before their THEN is treated as matched.
  static List<BnnMasterRule> sourceCandidates(
      List<BnnMasterRule> rules, int house, String planetTelugu) {
    final variants = <String>{planetTelugu};
    const aliases = <String, List<String>>{
      'సూర్యుడు': ['సూర్య', 'రవి'],
      'చంద్రుడు': ['చంద్ర'],
      'కుజుడు': ['కుజ'],
      'బుధుడు': ['బుధ'],
      'శుక్రుడు': ['శుక్ర', 'శుకుడు'],
      'శని': ['శని'],
      'రాహువు': ['రాహు'],
      'కేతువు': ['కేతు'],
    };
    variants.addAll(aliases[planetTelugu] ?? const []);
    final prefix = 'గురుకి $houseలో ';
    return rules.where((r) =>
        variants.any((name) => r.condition.contains('$prefix$name')))
        .toList(growable: false);
  }
}
