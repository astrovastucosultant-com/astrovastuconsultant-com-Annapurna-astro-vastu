import 'astro_models.dart';
import 'bnn_exact_if_engine.dart';
import 'bnn_master_service.dart';

/// Performs natal geometry checks against every catalogue row.  Original
/// source sentences and OCR provenance are not edited.  Dash-separated
/// BNN-N chains are evaluated under the *named* degree-trine profile; they
/// are never presented as an observed conjunction or a factual life event.
class BnnAllRulesMatchService {
  static const _localNames = <String, String>{
    'సూర్యుడు': 'Sun', 'చంద్రుడు': 'Moon', 'కుజుడు': 'Mars',
    'బుధుడు': 'Mercury', 'గురుడు': 'Jupiter', 'శుక్రుడు': 'Venus',
    'శని': 'Saturn', 'రాహువు': 'Rahu', 'కేతువు': 'Ketu',
  };

  static PlanetPosition? _planet(AstroChartResult chart, String name) {
    final english = _localNames[name] ??
        BnnMasterAnalysis.teluguPlanetNames[name];
    if (english == null) return null;
    for (final p in chart.planets) {
      if (p.name == english) return p;
    }
    return null;
  }

  static const _p = r'(?:సూర్యుడు|సూర్య|రవి|చంద్రుడు|చంద్ర|కుజుడు|కుజ|బుధుడు|బుధ|గురుడు|గురు|శుక్రుడు|శుక్ర|శని|రాహువు|రాహు|కేతువు|కేతు)';

  static BnnExactIfResult _checkNamed(AstroChartResult chart,
      List<String> names, bool Function(List<PlanetPosition>) predicate,
      String description) {
    final found = <PlanetPosition>[];
    for (final name in names) {
      final p = _planet(chart, name);
      if (p == null) return BnnExactIfResult(false, false,
          'IFకు అవసరమైన $name గ్రహస్థానం లేదు.');
      found.add(p);
    }
    final ok = predicate(found);
    final positions = <String>[];
    for (final p in found) {
      positions.add('${p.name}: '
          '${BnnMasterAnalysis.signNames[p.signIndex]} '
          '${p.degreesInSign.toStringAsFixed(2)}°');
    }
    return BnnExactIfResult(true, ok,
        '$description • ${positions.join(' • ')} • '
        'పూర్తి షరతు ${ok ? 'TRUE' : 'FALSE'}');
  }

  static int _relative(PlanetPosition reference, PlanetPosition target) =>
      1 + (target.signIndex - reference.signIndex + 12) % 12;

  static BnnExactIfResult check(BnnMasterRule rule, AstroChartResult chart) {
    final condition = rule.condition.trim().replaceAll(RegExp(r'\s+'), ' ');
    // Never silently count a Jupiter-relative house from Lagna if Jupiter
    // is absent from the chart; the BNN natal reference must be natal Guru.
    if (condition.contains('గురుకి') &&
        _planet(chart, 'గురుడు') == null) {
      return const BnnExactIfResult(false, false,
          'గురు జన్మస్థానం అందుబాటులో లేదు; BNN భావాన్ని లగ్నం నుంచి ఊహించలేదు.');
    }
    final direct = BnnExactIfEngine.check(rule, chart);
    if (direct.evaluable) return direct;

    RegExpMatch? m;
    // Alternatives are OR, not an implied conjunction: F04, etc.
    m = RegExp('^($_p)కి\\s*([0-9]{1,2})\\s+లేదా\\s+'
        '([0-9]{1,2})లో\\s*($_p)\$').firstMatch(condition);
    if (m != null) {
      final h1 = int.tryParse(m.group(2)!);
      final h2 = int.tryParse(m.group(3)!);
      if (h1 != null && h2 != null && h1 > 0 && h1 <= 12 &&
          h2 > 0 && h2 <= 12) {
        return _checkNamed(chart, [m.group(1)!, m.group(4)!],
            (ps) => _relative(ps[0], ps[1]) == h1 ||
                    _relative(ps[0], ps[1]) == h2,
            'మొదటి గ్రహం నుంచి $h1 లేదా $h2 భావంలో రెండవ గ్రహం');
      }
    }

    // Two explicit independent planet-relative conditions: F20, J26.
    m = RegExp('^($_p)\\s+($_p)కి\\s*([0-9]{1,2})\\s*'
        '\\+\\s*($_p)\\s+($_p)కి\\s*([0-9]{1,2})\$')
        .firstMatch(condition);
    if (m != null) {
      final h1 = int.tryParse(m.group(3)!);
      final h2 = int.tryParse(m.group(6)!);
      if (h1 != null && h2 != null && h1 > 0 && h1 <= 12 &&
          h2 > 0 && h2 <= 12) {
        return _checkNamed(chart, [m.group(1)!, m.group(2)!,
            m.group(4)!, m.group(5)!],
            (ps) => _relative(ps[1], ps[0]) == h1 &&
                    _relative(ps[3], ps[2]) == h2,
            'రెండు గ్రహ-ఆధార భావాల షరతులూ (AND)');
      }
    }

    // A named reference without the -కి suffix, e.g. "శని 10లో సూర్యుడు".
    m = RegExp('^($_p)\\s+([0-9]{1,2})లో\\s*($_p)\$')
        .firstMatch(condition);
    if (m != null) {
      final h = int.tryParse(m.group(2)!);
      if (h != null && h > 0 && h <= 12) {
        return _checkNamed(chart, [m.group(1)!, m.group(3)!],
            (ps) => _relative(ps[0], ps[1]) == h,
            'మొదటి గ్రహం నుంచి $h భావంలో రెండవ గ్రహం');
      }
    }

    // A planet group placed at the same house relative to one named ruler.
    m = RegExp('^($_p(?:\\+$_p){1,3})\\s+($_p)కి\\s*'
        '([0-9]{1,2})\$').firstMatch(condition);
    if (m != null) {
      final h = int.tryParse(m.group(3)!);
      final names = m.group(1)!.split('+');
      if (h != null && h > 0 && h <= 12 &&
          names.toSet().length == names.length) {
        return _checkNamed(chart, [...names, m.group(2)!],
            (ps) => ps.take(names.length)
                .every((p) => _relative(ps.last, p) == h),
            'మూల IFలోని గ్రహాలన్నీ పేర్కొన్న గ్రహం నుంచి $h భావంలో');
      }
    }

    // Explicit retrograde reference plus other planets in one relative house.
    m = RegExp('^($_p)\\s+వక్రం\\s+([0-9]{1,2})లో\\s*'
        '($_p(?:\\+$_p){1,2})\$').firstMatch(condition);
    if (m != null) {
      final h = int.tryParse(m.group(2)!);
      final names = m.group(3)!.split('+');
      if (h != null && h > 0 && h <= 12) {
        return _checkNamed(chart, [m.group(1)!, ...names],
            (ps) => ps.first.retrograde &&
                ps.skip(1).every((p) => _relative(ps.first, p) == h),
            'మొదటి గ్రహం వక్రం AND ఇతరులంతా $h భావంలో');
      }
    }

    // C59 has 3 independent conditions and a fixed Jupiter sign.
    if (rule.id == 'BNN-BOOK-C59' &&
        condition == 'గురు కర్కాటకం + శుక్ర+కుజ 7 + చంద్ర 4') {
      return _checkNamed(chart,
          ['గురు', 'శుక్ర', 'కుజ', 'చంద్ర'],
          (ps) => ps[0].signIndex == 3 &&
              _relative(ps[0], ps[1]) == 7 &&
              _relative(ps[0], ps[2]) == 7 &&
              _relative(ps[0], ps[3]) == 4,
          'C59: గురు కర్కాటకం, శుక్ర+కుజ 7వ, చంద్ర 4వ — అన్నీ AND');
    }

    // The source leaves "7వ అధిపతి" without an explicit starting frame.
    // Calculate a clearly labelled D1 Lagna-lord interpretation instead of
    // treating Jupiter-relative house 4 alone as the entire source IF.
    if (rule.id == 'BNN-BOOK-C64' &&
        condition == 'గురుకి 4లో శుక్ర 7వ అధిపతి') {
      final j = _planet(chart, 'గురుడు');
      final v = _planet(chart, 'శుక్రుడు');
      if (j == null || v == null) {
        return const BnnExactIfResult(false, false,
            'C64కు జన్మ గురు, శుక్రుల స్థానాలు అవసరం.');
      }
      final house = 1 + (v.signIndex - j.signIndex + 12) % 12;
      final seventhSign = (chart.ascendantSignIndex + 6) % 12;
      // Zodiac sign 1 Taurus and sign 6 Libra are ruled by Venus.
      final d1VenusLord = seventhSign == 1 || seventhSign == 6;
      final matched = house == 4 && d1VenusLord;
      return BnnExactIfResult(true, matched,
          'C64 పూర్తి IF: శుక్రుడు జన్మగురువుకు $house వ భావం; '
          'D1 జన్మలగ్నం నుంచి 7వ రాశి '
          '${BnnMasterAnalysis.signNames[seventhSign]}; '
          'D1 7వ అధిపతి శుక్రుడా: ${d1VenusLord ? 'అవును' : 'కాదు'}; '
          'రెండు షరతులూ ${matched ? 'TRUE' : 'FALSE'}. '
          'అధిపతి గణనకు D1 పద్ధతి ఉపయోగించాం.');
    }

    // The source explicitly says a planet lies in Jupiter's 12th (behind).
    if (rule.id == 'BNN-BOOK-C26' &&
        condition == 'గురుకి 12లో కేతు (గురు వెనుక)') {
      final j = _planet(chart, 'గురుడు');
      final k = _planet(chart, 'కేతువు');
      if (j == null || k == null) {
        return const BnnExactIfResult(false, false,
            'C26కు గురు, కేతు స్థానాలు అవసరం.');
      }
      final house = 1 + (k.signIndex - j.signIndex + 12) % 12;
      return BnnExactIfResult(true, house == 12,
          'C26: గురువుకు కేతు $house వ రాశిలో ఉన్నాడు; '
          '12వ రాశి వెనుక స్థానంగా పరిశీలించబడింది.');
    }

    // Deliberately isolated optical typo normalization: the original file
    // remains unmodified and the normalization is visible to the astrologer.
    if (rule.id == 'BNN-BOOK-C33' &&
        condition == 'గురుకి 2లో శుకుడు') {
      final j = _planet(chart, 'గురుడు');
      final v = _planet(chart, 'శుక్రుడు');
      if (j == null || v == null) {
        return const BnnExactIfResult(false, false,
            'C33కు గురు, శుక్రుల స్థానాలు అవసరం.');
      }
      final house = 1 + (v.signIndex - j.signIndex + 12) % 12;
      return BnnExactIfResult(true, house == 2,
          'C33: గురు నుంచి శుక్రుడు $house వ భావం. మూలంలో "శుకుడు" '
          'అన్న OCR రూపాన్ని పరీక్ష కోసం "శుక్రుడు"గా పరిగణించాం; '
          'మూల IFని మార్చలేదు.');
    }

    // "A—B—C" in BNN N is *not* automatically same-sign.  The selected
    // traditional Nadi profile tests same 1-5-9 group AND local sign-degree
    // ascending sequence, with no invented relationship or source THEN.
    if (rule.id.startsWith('BNNN-') && condition.contains('—')) {
      final names = condition.split('—').map((n) => n.trim()).toList();
      if (names.length < 2 || names.length > 4 ||
          names.any((n) => !_localNames.containsKey(n)) ||
          names.toSet().length != names.length) {
        return BnnExactIfResult.unsupported;
      }
      final planets = <PlanetPosition>[];
      for (final name in names) {
        final p = _planet(chart, name);
        if (p == null) {
          return BnnExactIfResult(false, false,
              'నాడీ చైన్‌కు అవసరమైన $name జన్మస్థానం లేదు.');
        }
        planets.add(p);
      }
      final trine = planets.every((p) =>
          p.signIndex % 4 == planets.first.signIndex % 4);
      final order = <String>[];
      var strictlyAscending = true;
      for (var i = 0; i < planets.length; i++) {
        final p = planets[i];
        order.add('${names[i]} '
            '${BnnMasterAnalysis.signNames[p.signIndex]} '
            '${p.degreesInSign.toStringAsFixed(3)}°');
        if (i > 0 && planets[i - 1].degreesInSign >= p.degreesInSign) {
          strictlyAscending = false;
        }
      }
      final ok = trine && strictlyAscending;
      return BnnExactIfResult(true, ok,
          'BNN N DEGREE_TRINE_ASC_PROFILE • మూల గ్రహక్రమం: '
          '${order.join(' → ')} • 1–5–9 సమూహం: '
          '${trine ? 'TRUE' : 'FALSE'} • స్థానిక డిగ్రీల ఆరోహణ: '
          '${strictlyAscending ? 'TRUE' : 'FALSE'} • '
          '${ok ? 'సరిపోయింది' : 'సరిపోలలేదు'}. '
          'ఇది ఎంచుకున్న నాడీ క్రమ పద్ధతి; అసలు IFలో '
          'సంయోగమా/దృష్టా అనే అదనపు పద్ధతి వేరుగా సమీక్షించాలి.');
    }

    return direct;
  }
}
