import 'astro_models.dart';
import 'bnn_bhava_topics.dart';
import 'bnn_exact_if_engine.dart';
import 'bnn_all_rules_match_service.dart';
import 'bnn_master_service.dart';
import 'bnn_nadi_degree_engine.dart';
import 'bnn_topic_index.dart';

/// Every bhava topic is inspected against the native's actual chart.
/// Source THEN sentences are *never* created by this service.
/// Matched means chart IF matched, NOT historical OCR source verification.
class BnnTopicReading {
  final BnnBhavaTopic topic;
  final String karakaInspection;
  final List<(BnnMasterRule, BnnExactIfResult)> natalMatches;
  final List<(BnnMasterRule, BnnExactIfResult)> natalNonMatches;
  final List<(BnnMasterRule, BnnExactIfResult)> notComputable;

  const BnnTopicReading({
    required this.topic,
    required this.karakaInspection,
    required this.natalMatches,
    required this.natalNonMatches,
    required this.notComputable,
  });

  int get sourceCount => natalMatches.length + natalNonMatches.length + notComputable.length;
}

class BnnTopicReadingService {
  static BnnTopicReading inspect(BnnBhavaTopic topic,
      List<BnnMasterRule> catalog, AstroChartResult chart) {
    final matched = <(BnnMasterRule, BnnExactIfResult)>[];
    final noMatch = <(BnnMasterRule, BnnExactIfResult)>[];
    final missingDefinitions = <(BnnMasterRule, BnnExactIfResult)>[];
    for (final rule in BnnTopicIndex.readingRulesFor(topic, catalog)) {
      final evaluated = BnnAllRulesMatchService.check(rule, chart);
      if (!evaluated.evaluable) {
        missingDefinitions.add((rule, evaluated));
      } else if (evaluated.matched) {
        matched.add((rule, evaluated));
      } else {
        noMatch.add((rule, evaluated));
      }
    }
    return BnnTopicReading(
      topic: topic,
      karakaInspection: _karakaInspection(topic.karaka, chart),
      natalMatches: matched,
      natalNonMatches: noMatch,
      notComputable: missingDefinitions,
    );
  }

  static String _karakaInspection(String name, AstroChartResult chart) {
    final p = BnnNadiDegreeEngine.planet(chart, name);
    if (p == null) return 'ఈ అంశం పరిశీలించేందుకు $name గ్రహస్థానం అందుబాటులో లేదు.';
    final sign = BnnMasterAnalysis.signNames[p.signIndex];
    final house = BnnMasterAnalysis.houseOfPlanet(p, chart);
    final motion = p.speed < 0 ? ' • వక్రస్థితి' : '';
    final details = <String>[
      '${BnnNadiDegreeEngine.teluguName(p)} — $sign '
          '${BnnNadiDegreeEngine.dms(p)} • BNN $house భావం$motion',
    ];
    // These are observable sign links only, not predictive source rules.
    for (final contact in BnnNadiDegreeEngine.contacts(chart)) {
      if (contact.first.name != name && contact.second.name != name) continue;
      final other = contact.first.name == name ? contact.second : contact.first;
      details.add('${BnnNadiDegreeEngine.teluguName(other)}: '
          '${contact.kind} • ${contact.degreeOrder}');
      if (details.length >= 5) break;
    }
    if (details.length == 1) details.add('ఈ కారకగ్రహానికి పరిశీలించిన నాడీ సంబంధాలు గుర్తించలేదు.');
    return details.join('\n');
  }
}
