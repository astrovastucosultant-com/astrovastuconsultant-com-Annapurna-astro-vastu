import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'bnn_master_service.dart';

/// User's BNN-M-001..106 are ENGINE SPECS, not extra 106 natal predictions.
/// The 462 SOURCE entries are separate and must not auto-fire just because
/// an observable positional relationship is present.
class BnnEngineSpec {
  final String id;
  final String condition;
  final String consequence;
  const BnnEngineSpec(this.id, this.condition, this.consequence);
}

class BnnEngineSpecCatalog {
  static Future<List<BnnEngineSpec>> load() async {
    final jsonText = await rootBundle.loadString('assets/bnn/bnn_engine_106_v1_1.json');
    final parsed = jsonDecode(jsonText) as Map<String, dynamic>;
    final rules = (parsed['rules'] as List<dynamic>).map((raw) {
      final r = raw as Map<String, dynamic>;
      return BnnEngineSpec(r['id'] as String, r['if'] as String, r['then'] as String);
    }).toList(growable: false);
    if (rules.length != 106 || rules.map((r) => r.id).toSet().length != 106) {
      throw const FormatException('BNN Engine v1.1 106 rules incomplete');
    }
    return rules;
  }
}

class BnnNadiSequence {
  final int trineGroup;
  final List<PlanetPosition> planets;
  const BnnNadiSequence(this.trineGroup, this.planets);
}

class BnnNadiContact {
  final PlanetPosition first;
  final PlanetPosition second;
  final String kind;
  final int signOffset;
  final String degreeOrder;
  const BnnNadiContact(this.first, this.second, this.kind,
      this.signOffset, this.degreeOrder);
}

class BnnSymbolicWindow {
  final String methodId;
  final String targetPlanet;
  final double fromAge;
  final double toAge;
  final int round;
  const BnnSymbolicWindow(this.methodId, this.targetPlanet,
      this.fromAge, this.toAge, this.round);
}

class BnnNadiDegreeEngine {
  static const jupiterQuickId = 'JUPITER_1SIGN_PER_YEAR_APPROX';
  static const jupiterSlowId = 'JUPITER_12Y_PER_SIGN_SLOW';
  static const saturnSymbolicId = 'SATURN_2P5Y_PER_SIGN_APPROX';

  static double normalize(double longitude) =>
      (longitude % 360 + 360) % 360;
  static int zodiacSign(double longitude) => (normalize(longitude) / 30).floor();
  static double withinSignDegree(double longitude) => normalize(longitude) % 30;
  static int trineGroup(int sign) => sign % 4;
  static int offset(int signA, int signB) => (signB - signA + 12) % 12;
  static int bnnHouse(int sign, int natalJupiterSign) =>
      1 + offset(natalJupiterSign, sign);

  static PlanetPosition? planet(AstroChartResult chart, String name) {
    for (final p in chart.planets) {
      if (p.name == name) return p;
    }
    return null;
  }

  /// Local degree, minute, second ordering. Ephemeris exposes floating-point
  /// longitude but no independent uncertainty; these are rounded display DMS
  /// values, never an astronomical exact-contact guarantee.
  static int roundedArcseconds(PlanetPosition p) =>
      (withinSignDegree(p.longitude) * 3600).round();
  static String dms(PlanetPosition p) {
    final seconds = roundedArcseconds(p);
    final d = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    final s = seconds % 60;
    return '$d°${m.toString().padLeft(2, '0')}′${s.toString().padLeft(2, '0')}″';
  }

  static String teluguName(PlanetPosition p) {
    const labels = <String, String>{
      'Sun': 'సూర్య', 'Moon': 'చంద్ర', 'Mars': 'కుజ',
      'Mercury': 'బుధ', 'Jupiter': 'గురు', 'Venus': 'శుక్ర',
      'Saturn': 'శని', 'Rahu': 'రాహు', 'Ketu': 'కేతు',
    };
    return labels[p.name] ?? p.name;
  }

  static String groupName(int group) => switch (group) {
    0 => 'అగ్ని: మేషం–సింహం–ధనుస్సు',
    1 => 'భూమి: వృషభం–కన్య–మకరం',
    2 => 'వాయు: మిథునం–తుల–కుంభం',
    _ => 'జలం: కర్కాటకం–వృశ్చికం–మీనం',
  };

  static List<BnnNadiSequence> sequences(AstroChartResult chart) {
    final groups = <BnnNadiSequence>[];
    for (var group = 0; group < 4; group++) {
      final positions = chart.planets.where((p) =>
          trineGroup(zodiacSign(p.longitude)) == group).toList();
      positions.sort((a, b) => roundedArcseconds(a).compareTo(roundedArcseconds(b)));
      if (positions.length >= 2) groups.add(BnnNadiSequence(group, positions));
    }
    return groups;
  }

  static String degreeOrder(PlanetPosition a, PlanetPosition b) {
    final first = roundedArcseconds(a);
    final second = roundedArcseconds(b);
    if (first == second) return 'సమాన / నిర్ణయించలేని డిగ్రీ క్రమం';
    final low = first < second ? a : b;
    final high = first < second ? b : a;
    return '${teluguName(low)} ముందుగా వరుసలో (తక్కువ డిగ్రీ); '
        '${teluguName(high)} ఎక్కువ డిగ్రీతో స్థానపరంగా ముందుంది';
  }

  static List<BnnNadiContact> contacts(AstroChartResult chart,
      {String nodeProfile = 'BNN_159_12'}) {
    final found = <BnnNadiContact>[];
    for (var i = 0; i < chart.planets.length; i++) {
      final a = chart.planets[i];
      final sa = zodiacSign(a.longitude);
      for (var j = i + 1; j < chart.planets.length; j++) {
        final b = chart.planets[j];
        final sb = zodiacSign(b.longitude);
        final diff = offset(sa, sb);
        final node = const {'Rahu', 'Ketu'}.contains(a.name) ||
            const {'Rahu', 'Ketu'}.contains(b.name);
        String? relation;
        if (diff == 0) {
          relation = 'NATAL_SAME_SIGN';
        } else if (diff == 4 || diff == 8) {
          relation = node && nodeProfile == 'BNN_159_12'
              ? 'NODE_NADI_TRINE' : 'NATAL_TRINE_159';
        } else if (diff == 1 || diff == 11) {
          relation = node && nodeProfile == 'BNN_159_12'
              ? 'NODE_NADI_ADJACENT' : diff == 1 ? 'NEXT_SIGN' : 'PREVIOUS_SIGN';
        } else if (diff == 6) {
          // Do not treat nodes' opposition as a BNN_159_12 aspect.
          if (node && nodeProfile == 'BNN_159_12') continue;
          relation = 'BNN_OPPOSITION_7';
        }
        if (relation == null) continue;
        found.add(BnnNadiContact(a, b, relation, diff,
            diff == 0 || diff == 4 || diff == 8
                ? degreeOrder(a, b)
                : 'రాశి సంబంధం మాత్రమే; త్రికోణ డిగ్రీ వరుస కాదు'));
      }
    }
    return found;
  }

  static List<BnnSymbolicWindow> jupiterQuickWindows(
      AstroChartResult chart, {int minAge = 0, int maxAge = 84}) {
    final j = planet(chart, 'Jupiter');
    if (j == null) return const [];
    final windows = <BnnSymbolicWindow>[];
    for (final target in chart.planets) {
      if (target.name == 'Jupiter') continue;
      final h = bnnHouse(zodiacSign(target.longitude), zodiacSign(j.longitude));
      for (var round = 0; round * 12 + h - 1 <= maxAge; round++) {
        final age = (round * 12 + h - 1).toDouble();
        if (age + 1 <= minAge) continue;
        windows.add(BnnSymbolicWindow(jupiterQuickId, target.name,
            math.max(age, minAge.toDouble()), math.min(age + 1, maxAge + 1.0),
            round + 1));
      }
    }
    windows.sort((a, b) => a.fromAge.compareTo(b.fromAge));
    return windows;
  }

  static List<BnnSymbolicWindow> saturnSymbolicWindows(
      AstroChartResult chart, {int minAge = 0, int maxAge = 84}) {
    final saturn = planet(chart, 'Saturn');
    if (saturn == null) return const [];
    final windows = <BnnSymbolicWindow>[];
    for (final target in chart.planets) {
      if (target.name == 'Saturn') continue;
      final distance = offset(zodiacSign(saturn.longitude), zodiacSign(target.longitude));
      for (var round = 0; 30 * round + 2.5 * distance <= maxAge; round++) {
        final start = 30 * round + 2.5 * distance;
        final end = start + 2.5;
        if (end <= minAge) continue;
        windows.add(BnnSymbolicWindow(saturnSymbolicId, target.name,
            math.max(start, minAge.toDouble()), math.min(end, maxAge + 1.0),
            round + 1));
      }
    }
    windows.sort((a, b) => a.fromAge.compareTo(b.fromAge));
    return windows;
  }

  static double? slowJupiterSymbolicLongitude(AstroChartResult chart, double age) {
    final j = planet(chart, 'Jupiter');
    if (j == null || age < 0) return null;
    return normalize(j.longitude + 2.5 * age);
  }
}
