import 'astro_models.dart';
import 'shapa_rule_service.dart';
import 'varga_service.dart';
import 'dart:math' as math;

/// Traditional rule audit, not a real-world diagnosis or evidence of a curse.
/// Every automatic TRUE requires evaluation of the full supported IF expression.
/// Unimplemented/ambiguous clauses are PENDING, never TRUE or FALSE.
class ShapaAudit {
  final ShapaRule rule;
  final bool? matched;
  final List<String> evidence;
  final String note;
  const ShapaAudit(this.rule, this.matched, this.evidence, this.note);
}

class ShapaMatchEngine {
  static const rulers = <String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  static const signs = <String>[
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];
  static const tel = <String,String>{
    'Sun':'రవి','Moon':'చంద్రుడు','Mars':'కుజుడు',
    'Mercury':'బుధుడు','Jupiter':'గురువు','Venus':'శుక్రుడు',
    'Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు',
  };

  // Simple clauses transcribed against the exact PDF IF wording.
  // Each inner list is AND; outer list is OR. Missing entries stay pending.
  // DO NOT infer conjunction or an aspect from mere occupancy in other houses.
  static const autoClauses = <String,List<List<String>>>{
    'BPHS83-సర్ప-01': [['H:Rahu:5','ASPECT: Mars:Rahu'],['IN:Rahu:0:7']],
    'BPHS83-సర్ప-04': [['SAME:Jupiter:Mars','H:Rahu:1','DUST:Lord5']],
    'BPHS83-సర్ప-06': [['LORD_NAME:5:Mars','SAME:Lord5:Rahu']],
    'BPHS83-సర్ప-08': [['SAME:Lord1:Rahu','SAME:Lord5:Mars'],['SAME:Jupiter:Rahu']],
    'BPHS83-పితృ-03': [['S:Jupiter:4','SAME:Lord5:Sun','MAL:5','MAL:1']],
    'BPHS83-పితృ-05': [['H:Lord9:5','MAL:5','MAL:1'],['H:Lord5:10','MAL:5','MAL:1']],
    'BPHS83-పితృ-09': [['H:Sun:8','H:Saturn:5','SAME:Lord5:Rahu','MAL:1']],
    'BPHS83-పితృ-10': [['H:Lord12:1','H:Lord8:5','H:Lord9:8']],
    'BPHS83-పితృ-11': [['H:Lord6:5','H:Lord9:6','SAME:Jupiter:Rahu']],
    'BPHS83-మాతృ-02': [['H:Saturn:11','MAL:4','H:Moon:5','DEB:Moon']],
    'BPHS83-మాతృ-07': [['H:Lord1:6','H:Lord5:6','H:Lord4:8','H:Lord9:1','H:Lord8:1']],
    'BPHS83-మాతృ-10': [['H:Lord8:5','H:Lord5:8','DUST:Moon','DUST:Lord4']],
    'BPHS83-మాతృ-11': [['ASC:3','H:Mars:1','H:Rahu:1','H:Moon:5','H:Saturn:5']],
    'BPHS83-మాతృ-12': [['H:Mars:1','H:Rahu:5','H:Sun:8','H:Saturn:12','DUST:Lord4','DUST:Lord1']],
    'BPHS83-మాతృ-13': [['H:Jupiter:8','SAME:Jupiter:Mars','SAME:Jupiter:Rahu','H:Saturn:5','H:Moon:5']],
    'BPHS83-భ్రాతృ-02': [['H:Mars:1','H:Saturn:5','H:Lord3:9','H:Jupiter:8']],
    'BPHS83-భ్రాతృ-03': [['H:Jupiter:3','DEB:Jupiter','H:Saturn:5','H:Moon:8','H:Mars:8']],
    'BPHS83-భ్రాతృ-07': [['LORD_NAME:5:Mercury','H:Saturn:5','H:Rahu:5','H:Mercury:12','H:Mars:12']],
    'BPHS83-భ్రాతృ-08': [['H:Lord1:3','H:Lord3:5','MAL:1','MAL:3','MAL:5']],
    'BPHS83-భ్రాతృ-10': [['H:Lord8:5','SAME:Lord8:Lord3','H:Mars:8','H:Saturn:8']],
    'BPHS83-మాతుల-01': [['H:Mercury:5','H:Jupiter:5','H:Mars:5','H:Rahu:5','H:Saturn:1']],
    'BPHS83-మాతుల-02': [['H:Lord1:5','H:Lord5:5','H:Mercury:5','H:Mars:5','H:Saturn:5']],
    'BPHS83-మాతుల-04': [['H:Lord6:1','H:Lord12:1','H:Moon:5','H:Mercury:5','H:Mars:5']],
    'BPHS83-బ్రహ్మ-01': [['IN:Rahu:8:11','H:Jupiter:5','H:Mars:5','H:Saturn:5','H:Lord9:8']],
    'BPHS83-బ్రహ్మ-02': [['H:Lord9:5','H:Lord5:8','H:Jupiter:8','H:Mars:8','H:Rahu:8']],
    'BPHS83-బ్రహ్మ-04': [['DEB:Jupiter','H:Rahu:1','DUST:Lord5'],['DEB:Jupiter','H:Rahu:5','DUST:Lord5']],
    'BPHS83-బ్రహ్మ-07': [['H:Saturn:1','H:Jupiter:1'],['H:Saturn:9','H:Rahu:9'],['H:Saturn:12','H:Jupiter:12']],
    'BPHS83-పత్నీ-02': [['H:Lord7:8','H:Lord5:8','CONJ_MAL:Jupiter']],
    'BPHS83-పత్నీ-03': [['H:Venus:5','H:Lord7:8','CONJ_MAL:Jupiter']],
    'BPHS83-పత్నీ-04': [['MAL:2','H:Lord7:8','MAL:5']],
    'BPHS83-పత్నీ-05': [['H:Venus:9','H:Lord7:8','MAL:1','MAL:5']],
    'BPHS83-పత్నీ-07': [['LORD_NAME:5:Venus','H:Rahu:5','H:Moon:5','MAL:12','MAL:1','MAL:2']],
    'BPHS83-పత్నీ-08': [['H:Saturn:7','H:Venus:7','H:Lord8:5','H:Sun:5','H:Rahu:1']],
    'BPHS83-పత్నీ-10': [['H:Lord2:8','H:Lord7:8','H:Mars:5','H:Saturn:1','CONJ_MAL:Jupiter']],
    'BPHS83-పత్నీ-11': [['H:Rahu:1','H:Saturn:5','H:Mars:9','H:Lord5:8','H:Lord7:8']],
    'BPHS83-ప్రేత-02': [['LORD_NAME:5:Saturn','H:Lord5:8','H:Mars:1','H:Jupiter:8']],
    'BPHS83-ప్రేత-03': [['MAL:1','H:Sun:12','H:Mars:5','H:Saturn:5','H:Mercury:5','H:Lord5:8']],
    'BPHS83-ప్రేత-04': [['H:Rahu:1','H:Saturn:5','H:Jupiter:8']],
    'BPHS83-ప్రేత-07': [['H:Saturn:1','H:Rahu:5','H:Sun:8','H:Mars:12']],
    'BPHS83-ప్రేత-09': [['H:Lord8:5','H:Saturn:5','H:Venus:5','H:Jupiter:8']],
    // BPHS 83 previously pending: complete IF trees; uncertain classical
    // inputs remain tri-state until actual chart measurements are supplied.
    'BPHS83-సర్ప-02': [['SAME:Lord5:Rahu','H:Saturn:5','SAME:Saturn:Moon'],['SAME:Lord5:Rahu','H:Saturn:5','ASPECT:Moon:Saturn']],
    'BPHS83-సర్ప-03': [['SAME:Jupiter:Rahu','WEAK:Lord5','SAME:Lord1:Mars']],
    'BPHS83-సర్ప-05': [['LORD_NAME:5:Mercury','NAV_LORD:Mercury:Mars','NAV_SAME:Mercury:Mars','H:Rahu:1','MANDI_H:1']],
    'BPHS83-సర్ప-07': [['H:Sun:5','H:Saturn:5','H:Mars:5','H:Rahu:5','H:Mercury:5','H:Jupiter:5','WEAK:Lord5','WEAK:Lord1']],
    'BPHS83-పితృ-01': [['H:Sun:5','DEB:Sun','NAV_LORD:Sun:Saturn','PAPAKARTARI:Sun']],
    'BPHS83-పితృ-02': [['LORD_NAME:5:Sun','TRINE:Lord5','CONJ_MAL:Lord5','PAPAKARTARI:Lord5','MAL_ASPECT:Lord5']],
    'BPHS83-పితృ-04': [['WEAK:Lord1','H:Lord1:5','SAME:Lord5:Sun','MAL:5','MAL:1']],
    'BPHS83-పితృ-06': [['LORD_NAME:9:Mars','SAME:Lord9:Lord5','MAL:1','MAL:5','MAL:9']],
    'BPHS83-పితృ-07': [['DUST:Lord9','PAPA_SIGN:Jupiter','CONJ_MAL:Lord5','CONJ_MAL:Lord1']],
    'BPHS83-పితృ-08': [['H:Sun:1','H:Mars:1','H:Saturn:5','H:Rahu:8','H:Jupiter:12'],['H:Sun:5','H:Mars:1','H:Saturn:5','H:Rahu:12','H:Jupiter:8'],['GROUP_H:Sun,Mars,Saturn:1,5','H:Rahu:8','H:Jupiter:12'],['GROUP_H:Sun,Mars,Saturn:1,5','H:Rahu:12','H:Jupiter:8']],
    'BPHS83-మాతృ-01': [['LORD_NAME:5:Moon','DEB:Moon','MAL:4','MAL:5'],['LORD_NAME:5:Moon','PAPAKARTARI:Moon','MAL:4','MAL:5']],
    'BPHS83-మాతృ-03': [['DUST:Lord5','DEB:Lord1','CONJ_MAL:Moon']],
    'BPHS83-మాతృ-04': [['DUST:Lord5','NAV_MAL:Moon','MAL:1','MAL:5']],
    'BPHS83-మాతృ-05': [['LORD_NAME:5:Moon','SAME:Moon:Saturn','SAME:Moon:Rahu','SAME:Moon:Mars','H:Moon:9'],['LORD_NAME:5:Moon','SAME:Moon:Saturn','SAME:Moon:Rahu','SAME:Moon:Mars','H:Moon:5']],
    'BPHS83-మాతృ-06': [['LORD_NAME:4:Mars','SAME:Mars:Saturn','SAME:Mars:Rahu','SAME:Mars:Sun','SAME:Mars:Moon','H:Mars:5'],['LORD_NAME:4:Mars','SAME:Mars:Saturn','SAME:Mars:Rahu','SAME:Mars:Sun','SAME:Mars:Moon','H:Mars:1']],
    'BPHS83-మాతృ-08': [['H:Lord6:1','H:Lord8:1','H:Lord4:12','H:Moon:5','H:Jupiter:5','CONJ_MAL:Moon','CONJ_MAL:Jupiter']],
    'BPHS83-మాతృ-09': [['PAPAKARTARI:ASC','WANING:Moon','H:Moon:7','H:Rahu:4','H:Saturn:5'],['PAPAKARTARI:ASC','WANING:Moon','H:Moon:7','H:Rahu:5','H:Saturn:4']],
    'BPHS83-భ్రాతృ-01': [['H:Lord3:5','SAME:Lord3:Mars','SAME:Lord3:Rahu','H:Lord5:8','H:Lord1:8']],
    'BPHS83-భ్రాతృ-04': [['H:Lord1:12','H:Mars:5','H:Lord5:8','CONJ_MAL:Lord5']],
    'BPHS83-భ్రాతృ-05': [['PAPAKARTARI:ASC','PAPAKARTARI:HOUSE5','DUST:Lord1','DUST:Lord5']],
    'BPHS83-భ్రాతృ-06': [['H:Lord10:3','CONJ_MAL:Lord10','H:Mars:5','BEN_CONJ:Mars']],
    'BPHS83-భ్రాతృ-09': [['H:Lord3:8','H:Jupiter:5','CONTACT:Jupiter:Rahu','CONTACT:Jupiter:Saturn']],
    'BPHS83-మాతుల-03': [['COMBUST:Lord5','H:Lord5:1','H:Saturn:7','SAME:Lord1:Mercury']],
    'BPHS83-బ్రహ్మ-03': [['DEB:Lord9','H:Lord12:5','CONTACT:Lord12:Rahu']],
    'BPHS83-బ్రహ్మ-05': [['LORD_NAME:5:Jupiter','H:Lord5:8','CONJ_MAL:Lord5'],['SAME:Lord5:Sun','SAME:Lord5:Moon']],
    'BPHS83-బ్రహ్మ-06': [['NAV_LORD:Jupiter:Saturn','SAME:Jupiter:Saturn','SAME:Jupiter:Mars','H:Lord5:12']],
    'BPHS83-పత్నీ-01': [['H:Lord7:5','NAV_LORD:Lord7:Saturn','H:Lord5:8']],
    'BPHS83-పత్నీ-06': [['LORD_NAME:9:Venus','ENEMY_SIGN:Lord5','DUST:Jupiter','DUST:Lord1','DUST:Lord7']],
    'BPHS83-పత్నీ-09': [['H:Mars:2','H:Jupiter:12','H:Venus:5','CONTACT:Venus:Saturn','CONTACT:Venus:Rahu']],
    'BPHS83-ప్రేత-01': [['H:Saturn:5','H:Sun:5','WANING:Moon','H:Moon:7','H:Rahu:1','H:Jupiter:12']],
    'BPHS83-ప్రేత-05': [['H:Rahu:1','SAME:Moon:Venus','SAME:Moon:Jupiter','SAME:Moon:Saturn','H:Lord1:8']],
    'BPHS83-ప్రేత-06': [['DEB:Lord5','DEB:Jupiter','DEB_ASPECT:5']],
    'BPHS83-ప్రేత-08': [['DUST:Lord7','H:Moon:5','H:Saturn:1','MANDI_H:1']],

  };

  static List<ShapaAudit> evaluate(AstroChartResult chart, {
    Map<String,double>? shadbalaVirupas, double? mandiLongitude,
  }) {
    final positions = <String,PlanetPosition>{for(final p in chart.planets) p.name:p};
    final required = <String>{'Sun','Moon','Mars','Mercury','Jupiter',
      'Venus','Saturn','Rahu','Ketu'};
    final missing = required.difference(positions.keys.toSet());
    if (missing.isNotEmpty) {
      return [for (final rule in ShapaRuleService.rules)
        ShapaAudit(rule,null,[],
          'గ్రహస్థితులు అందుబాటులో లేవు: ${missing.join(', ')}')];
    }
    final asc = chart.ascendantSignIndex;
    final verifiedMandi = mandiLongitude ?? positions['Mandi']?.longitude ?? positions['Gulika']?.longitude;
    int houseSign(int n) => (asc+n-1)%12;
    String houseLord(int n) => rulers[houseSign(n)];
    String? person(String name) {
      if (name.startsWith('Lord')) {
        final house=int.tryParse(name.substring(4));
        if(house==null||house<1||house>12)return null;
        return houseLord(house);
      }
      return positions.containsKey(name)?name:null;
    }
    int? sign(String name) {
      final id=person(name);
      return id==null?null:positions[id]?.signIndex;
    }
    int? house(String name) {
      final i=sign(name);
      return i==null?null:((i-asc+12)%12)+1;
    }
    String observed(String name) {
      final id=person(name);
      if(id==null)return '$name — సమాచారం లేదు';
      final p=positions[id]!;
      return '${tel[id]??id} ${signs[p.signIndex]} ${p.degreesInSign.toStringAsFixed(2)}°, ${house(id)}వ భావం';
    }
    int? navSign(String name) {
      final id=person(name);
      final p=id==null?null:positions[id];
      return p==null?null:VargaService.signForLongitude(p.longitude,9);
    }
    bool isMal(int rasi) => positions.entries.any((e)=>
      const {'Sun','Mars','Saturn','Rahu','Ketu'}.contains(e.key) &&
      e.value.signIndex==rasi);
    // PAPA-KARTARI means signs immediately before and after the target
    // must each contain a traditional malefic. Target itself is not enough.
    bool? papaKartari(String name) {
      final target=name=='ASC'?asc:name=='HOUSE5'?houseSign(5):sign(name);
      if(target==null)return null;
      return isMal((target+11)%12)&&isMal((target+1)%12);
    }
    double angle(double a,double b) {
      final raw=(a-b).abs()%360;
      return math.min(raw,360-raw);
    }
    bool? combust(String name) {
      final id=person(name);
      final pl=id==null?null:positions[id];
      final sun=positions['Sun'];
      if(pl==null||sun==null)return null;
      if(id=='Sun'||id=='Rahu'||id=='Ketu')return false;
      const limit=<String,double>{'Moon':12,'Mars':17,'Mercury':14,
        'Jupiter':11,'Venus':10,'Saturn':15};
      var orb=limit[id];
      if(orb==null)return null;
      if(pl.retrograde && id=='Mercury')orb=12;
      if(pl.retrograde && id=='Venus')orb=8;
      return angle(pl.longitude,sun.longitude)<=orb;
    }
    bool? weakByShadbala(String name) {
      final id=person(name);
      if(id==null)return null;
      const minimum=<String,double>{'Sun':390,'Moon':360,'Mars':300,
        'Mercury':420,'Jupiter':390,'Venus':330,'Saturn':300};
      final actual=shadbalaVirupas?[id];
      final target=minimum[id];
      if(actual==null||target==null||!actual.isFinite||actual<0)return null;
      return actual<target;
    }
    bool? waningMoon() {
      final sun=positions['Sun'],moon=positions['Moon'];
      if(sun==null||moon==null)return null;
      final sep=((moon.longitude-sun.longitude)%360+360)%360;
      return sep>=180;
    }
    // Conventional Parashari aspects. Nodal special aspects are not assumed.
    bool? grahaAspect(String from,String target) {
      final a=person(from),b=person(target);
      if(a==null||b==null)return null;
      if(a=='Rahu'||a=='Ketu')return null;
      final dist=((positions[b]!.signIndex-positions[a]!.signIndex+12)%12)+1;
      return dist==7 || (a=='Mars' && (dist==4||dist==8)) ||
        (a=='Jupiter' && (dist==5||dist==9)) ||
        (a=='Saturn' && (dist==3||dist==10));
    }
    // When nodal aspects are involved, same-sign contacts are certain;
    // nodal sight outside conjunction is tradition-dependent (unknown).
    bool? contact(String nameA,String nameB) {
      final a=person(nameA),b=person(nameB);
      final sa=sign(nameA),sb=sign(nameB);
      if(a==null||b==null||sa==null||sb==null)return null;
      if(sa==sb)return true;
      if(a=='Rahu'||a=='Ketu'||b=='Rahu'||b=='Ketu') {
        if(a!='Rahu'&&a!='Ketu')return grahaAspect(a,b)==true?true:null;
        if(b!='Rahu'&&b!='Ketu')return grahaAspect(b,a)==true?true:null;
        return null;
      }
      return grahaAspect(a,b)==true||grahaAspect(b,a)==true;
    }

    // One predicate produces an evidence line even on false; avoid hidden heuristics.
    (bool?,String) check(String token) {
      final parts=token.split(':');
      final op=parts.first;
      String n(String key) => tel[person(key)]??key;
      if(op=='ASC') {
        final v=int.tryParse(parts[1]);
        return (v==null?null:asc==v,'లగ్న రాశి ${signs[asc]}');
      }
      if(op=='H' && parts.length==3) {
        final h=house(parts[1]),want=int.tryParse(parts[2]);
        return (h==null||want==null?null:h==want, '${observed(parts[1])} (అవసరం $wantవ భావం)');
      }
      if(op=='S' && parts.length==3) {
        final s=sign(parts[1]),want=int.tryParse(parts[2]);
        return (s==null||want==null?null:s==want, '${observed(parts[1])} (అవసర రాశి ${want!=null&&want>=0&&want<12?signs[want]:want})');
      }
      if(op=='IN' && parts.length>2) {
        final s=sign(parts[1]);
        return (s==null?null:parts.skip(2).any((x)=>int.tryParse(x)==s),
          '${observed(parts[1])} — సూచించిన రాశులు ${parts.skip(2).join(', ')}');
      }
      if(op=='LORD_NAME' && parts.length==3) {
        final h=int.tryParse(parts[1]);
        if(h==null||h<1||h>12)return (null,'భావాధిపతి లెక్కలేదు');
        return (houseLord(h)==parts[2], '$hవ భావాధిపతి ${n('Lord$h')}');
      }
      if(op=='SAME' && parts.length==3) {
        final a=sign(parts[1]),b=sign(parts[2]);
        return (a==null||b==null?null:a==b,'యుతి: ${observed(parts[1])}; ${observed(parts[2])}');
      }
      if(op=='ASPECT' && parts.length==3) {
        return (grahaAspect(parts[1].trim(),parts[2].trim()),
          'పరాశరి గ్రహదృష్టి ${observed(parts[1].trim())} → ${observed(parts[2].trim())}');
      }
      if(op=='DEB' && parts.length==2) {
        const deb=<String,int>{'Sun':6,'Moon':7,'Mars':3,'Mercury':11,
          'Jupiter':9,'Venus':5,'Saturn':0};
        final key=person(parts[1]),s=sign(parts[1]);
        return (key==null||s==null||!deb.containsKey(key)?null:deb[key]==s,
          '${observed(parts[1])} — నీచ రాశి పరిశీలన');
      }
      if(op=='DUST' && parts.length==2) {
        final h=house(parts[1]);
        return (h==null?null:<int>{6,8,12}.contains(h),
          '${observed(parts[1])} — దుఃస్థానం 6/8/12');
      }
      if(op=='MAL' && parts.length==2) {
        final h=int.tryParse(parts[1]);
        if(h==null||h<1||h>12)return(null,'భావం తెలియదు');
        final found=positions.entries.where((e)=>
          <String>{'Sun','Mars','Saturn','Rahu','Ketu'}.contains(e.key) &&
          e.value.signIndex==houseSign(h)).map((e)=>n(e.key)).toList();
        return (found.isNotEmpty,'$hవ భావంలో సంప్రదాయ పాపగ్రహాలు: ${found.isEmpty?'లేవు':found.join(', ')}');
      }
      if(op=='CONJ_MAL' && parts.length==2) {
        final s=sign(parts[1]);
        if(s==null)return(null,'యుతి వివరాలు లేవు');
        final body=person(parts[1]);
        final found=positions.entries.where((e)=>
          <String>{'Sun','Mars','Saturn','Rahu','Ketu'}.contains(e.key) &&
          e.key!=body && e.value.signIndex==s).map((e)=>n(e.key)).toList();
        return (found.isNotEmpty,
          '${observed(parts[1])}తో పాపగ్రహ యుతి: ${found.isEmpty?'లేదు':found.join(', ')}');
      }
      if(op=='NAV_LORD' && parts.length==3) {
        final r=navSign(parts[1]);
        return (r==null?null:rulers[r]==parts[2],
          '${n(parts[1])} నవాంశం: ${r==null?'తెలియదు':'${signs[r]} / ${tel[rulers[r]]??rulers[r]}'}; అవసరం ${parts[2]}');
      }
      if(op=='NAV_SAME' && parts.length==3) {
        final a=navSign(parts[1]),b=navSign(parts[2]);
        return (a==null||b==null?null:a==b,
          '${n(parts[1])} / ${n(parts[2])} నవాంశ యుతి: '
          '${a==null?'?':signs[a]}, ${b==null?'?':signs[b]}');
      }
      if(op=='NAV_MAL' && parts.length==2) {
        final r=navSign(parts[1]);
        return (r==null?null:const {'Sun','Mars','Saturn'}.contains(rulers[r]),
          '${n(parts[1])} నవాంశ రాశి ${r==null?'?':signs[r]} (పాపాధిపతి)');
      }
      if(op=='PAPAKARTARI' && parts.length==2) {
        final ok=papaKartari(parts[1]);
        return (ok,'${parts[1]}కు ఇరువైపుల రాశుల్లో పాపగ్రహాలు (పాపకర్తరి): ${ok==null?'?':ok?'ఉన్నాయి':'లేవు'}');
      }
      if(op=='TRINE' && parts.length==2) {
        final h=house(parts[1]);
        return (h==null?null:const {1,5,9}.contains(h),
          '${observed(parts[1])} — త్రికోణ భావం 1/5/9');
      }
      if(op=='MAL_ASPECT' && parts.length==2) {
        final id=person(parts[1]);
        if(id==null)return(null,'గ్రహం లేదు');
        final found=<String>[];
        for(final x in ['Sun','Mars','Saturn']) {
          if(x!=id&&grahaAspect(x,id)==true)found.add(tel[x]??x);
        }
        return (found.isNotEmpty,'${n(parts[1])}పై పాపగ్రహ దృష్టి: ${found.join(', ')}');
      }
      if(op=='WEAK' && parts.length==2) {
        final id=person(parts[1]),actual=id==null?null:shadbalaVirupas?[id];
        return (weakByShadbala(parts[1]),
          '${n(parts[1])} షడ్బలం: ${actual==null?'గణన/ఇన్‌పుట్ లేదు':'${actual.toStringAsFixed(1)} విరూపాలు'}');
      }
      if(op=='COMBUST' && parts.length==2) {
        final v=combust(parts[1]);
        return (v,'${n(parts[1])} రవి నుంచి అస్తంగత దూరం: '
          '${person(parts[1])==null?'?':angle(positions[person(parts[1])]!.longitude,positions['Sun']!.longitude).toStringAsFixed(2)}°');
      }
      if(op=='MANDI_H' && parts.length==2) {
        final want=int.tryParse(parts[1]);
        final h=verifiedMandi==null?null:((((verifiedMandi%360+360)%360)/30).floor()-asc+12)%12+1;
        return (h==null||want==null?null:h==want,
          'మాంది భావం: ${h??'మూల సమయ గణన/ఇన్‌పుట్ లేదు'}; అవసరం $want');
      }
      if(op=='WANING' && parts.length==2) {
        final v=waningMoon();
        return (v,'సూర్య–చంద్ర దూరం ప్రకారం కృష్ణపక్ష చంద్రుడు: ${v==null?'?':v?'అవును':'కాదు'}');
      }
      if(op=='PAPA_SIGN' && parts.length==2) {
        final r=sign(parts[1]);
        return (r==null?null:const {'Sun','Mars','Saturn'}.contains(rulers[r]),
          '${n(parts[1])} పాపాధిపతి రాశి: ${r==null?'?':signs[r]}');
      }
      if(op=='GROUP_H' && parts.length==3) {
        final names=parts[1].split(','),wanted=parts[2].split(',').map(int.parse).toSet();
        final h=names.map(house).toList();
        return (h.contains(null)?null:h.every((x)=>wanted.contains(x)),
          '${names.join(', ')} భావాలు ${h.join(', ')} — అవసరం ${parts[2]}');
      }
      if(op=='BEN_CONJ' && parts.length==2) {
        final r=sign(parts[1]);
        if(r==null)return(null,'శుభగ్రహ యుతి తెలియదు');
        final seen=positions.entries.where((e)=>e.value.signIndex==r &&
          const {'Jupiter','Venus','Mercury','Moon'}.contains(e.key) &&
          e.key!=person(parts[1])&&(e.key!='Moon'||waningMoon()==false))
          .map((e)=>n(e.key)).toList();
        return (seen.isNotEmpty,'${n(parts[1])}తో శుభగ్రహ యుతి: ${seen.join(', ')}');
      }
      if(op=='CONTACT' && parts.length==3) {
        final v=contact(parts[1],parts[2]);
        return(v,'${n(parts[1])}–${n(parts[2])} యుతి/దృష్టి: '
          '${v==null?'రాహు/కేతు దృష్టి సంప్రదాయం నిర్ధారించాలి':v?'ఉంది':'లేదు'}');
      }
      if(op=='ENEMY_SIGN' && parts.length==2) {
        const enemies=<String,Set<String>>{
          'Sun':{'Venus','Saturn'},'Moon':{},'Mars':{'Mercury'},
          'Mercury':{'Moon'},'Jupiter':{'Mercury','Venus'},
          'Venus':{'Sun','Moon'},'Saturn':{'Sun','Moon','Mars'}};
        final id=person(parts[1]),r=sign(parts[1]);
        return(id==null||r==null||!enemies.containsKey(id)?null:
          enemies[id]!.contains(rulers[r]),
          '${n(parts[1])} ${r==null?'?':signs[r]} రాశి అధిపతి '
          '${r==null?'?':rulers[r]} — నైసర్గిక శత్రుత్వం');
      }
      if(op=='DEB_ASPECT' && parts.length==2) {
        // BPHS 83.102, Sanskrit: nīcasthagrahadṛṣṭe ca. Source's
        // translation applies the debilitated planet's sight to the 5th.
        final dest=int.tryParse(parts[1]);
        if(dest==null||dest<1||dest>12)return(null,'దృష్టి భావం లేదు');
        const deb=<String,int>{'Sun':6,'Moon':7,'Mars':3,
          'Mercury':11,'Jupiter':9,'Venus':5,'Saturn':0};
        final afflicted=<String>[];
        for(final e in deb.entries) {
          final start=sign(e.key);
          if(start==null||start!=e.value)continue;
          final distance=((houseSign(dest)-start+12)%12)+1;
          final yes=distance==7 ||
             (e.key=='Mars' && (distance==4||distance==8)) ||
             (e.key=='Jupiter' && (distance==5||distance==9)) ||
             (e.key=='Saturn' && (distance==3||distance==10));
          if(yes)afflicted.add(n(e.key));
        }
        return(afflicted.isNotEmpty,
          '$destవ భావంపై నీచగ్రహ దృష్టి: ${afflicted.isEmpty?'లేదు':afflicted.join(', ')}');
      }
      return (null,'గణన అమలుకాని షరతు: $token');
    }
    List<String> legacyEvidence(String id) {
      String? contact(String from,int targetSign,String label) {
        final s=sign(from);
        if(s==null)return null;
        if(s==targetSign)return '${observed(from)} — $labelతో ఒకే రాశి';
        // Only non-nodal classical aspects are defined in this layer.
        if(from=='Rahu'||from=='Ketu')return null;
        final distance=((targetSign-s+12)%12)+1;
        final yes=distance==7 || (from=='Mars'&&(distance==4||distance==8)) ||
          (from=='Jupiter'&&(distance==5||distance==9)) ||
          (from=='Saturn'&&(distance==3||distance==10));
        return yes?'${observed(from)} — $labelపై పరాశరి దృష్టి':null;
      }
      final found=<String>[];
      void checkContact(String from,int targetSign,String label) {
        final x=contact(from,targetSign,label);
        if(x!=null)found.add(x);
      }
      if(id=='SH-01') {
        checkContact('Ketu',3,'కర్కాటక రాశి');
        checkContact('Ketu',sign('Moon')??3,'చంద్రుడు');
        checkContact('Ketu',houseSign(4),'4వ భావం');
        checkContact('Ketu',sign('Lord4')??houseSign(4),'చతుర్థేశుడు');
      } else if(id=='SH-02') {
        for(final planet in ['Venus','Mercury','Rahu']) {
          checkContact(planet,8,'ధనుస్సు రాశి');
          checkContact(planet,sign('Jupiter')??8,'గురువు');
          for(final h in [2,5,9,12])checkContact(planet,houseSign(h),'$hవ భావం');
        }
      } else if(id=='SH-03') {
        for(final planet in ['Venus','Saturn','Rahu','Ketu']) {
          checkContact(planet,4,'సింహరాశి');
          checkContact(planet,sign('Sun')??4,'రవి');
          checkContact(planet,houseSign(5),'5వ భావం');
        }
      } else if(id=='SH-05') {
        final badhakaHouse=<int>{0,3,6,9}.contains(asc)?11:
          <int>{1,4,7,10}.contains(asc)?9:7;
        final badhakaSign=houseSign(badhakaHouse);
        final badhakaLord=houseLord(badhakaHouse);
        checkContact(badhakaLord,sign('Rahu')??badhakaSign,'రాహువు');
        if(sign('Rahu')==badhakaSign) {
          found.add('${observed('Rahu')} — బాధక భావం $badhakaHouse');
        }
      }
      return found.toSet().toList();
    }
    final audits=<ShapaAudit>[];
    for(final rule in ShapaRuleService.rules) {
      final alternatives=autoClauses[rule.id];
      if(alternatives==null) {
        final evidence=rule.legacy?legacyEvidence(rule.id):<String>[];
        audits.add(ShapaAudit(rule,null,evidence,rule.legacy
          ? 'పాత రాహు–కేతు నియమంలో ${evidence.length} ప్రాథమిక గ్రహ సంబంధాలు కనిపించాయి. '
            'అవి పూర్తి IF ప్రమాణం కావు; శాప నిర్ధారణ పెండింగ్.'
          : 'ఈ PDF నియమానికి అవసరమైన బలం/నవాంశం/దృష్టి/సంపూర్ణ IF గణన ఇంకా అమలుకాలేదు.'));
        continue;
      }
      bool anyTrue=false,anyUnknown=false;
      List<String> positiveEvidence=[];
      List<String> pendingEvidence=[];
      for(final conjunction in alternatives) {
        bool hasFalse=false,hasUnknown=false;
        final evidence=<String>[];
        for(final token in conjunction) {
          final (matched, detail)=check(token);
          evidence.add('${matched==true?'✓':matched==false?'×':'?'} $detail');
          if(matched==false)hasFalse=true;
          if(matched==null)hasUnknown=true;
        }
        if(!hasFalse&&!hasUnknown) {
          anyTrue=true;
          positiveEvidence=evidence;
          break;
        }
        if(!hasFalse&&hasUnknown){anyUnknown=true;pendingEvidence=evidence;}
      }
      audits.add(ShapaAudit(rule, anyTrue?true:anyUnknown?null:false,
        anyTrue?positiveEvidence:anyUnknown?pendingEvidence:[],
        'Whole-sign భావాలు, D9 నవాంశం, పాపకర్తరి, అస్తంగతం, కృష్ణపక్షం. బలం/మాంది సమాచారం లేనప్పుడు ? చూపుతుంది. గ్రహదృష్టి పరాశరి పద్ధతి. పాపగ్రహాలు: రవి, కుజ, శని, రాహు, కేతు. '
        'రూల్‌లోని అమలు చేసిన షరతులన్నీ సరిపోతేనే సూచన. శాప నిర్ధారణ కాదు.'));
    }
    return audits;
  }
}
