import 'dart:convert';
import 'package:flutter/services.dart';

class JamakolaRule {
  final String id, module, result, sourceFile, sourcePage;
  final Map<String, dynamic> conditions;
  const JamakolaRule(this.id, this.module, this.result, this.sourceFile, this.sourcePage, this.conditions);
  factory JamakolaRule.fromJson(Map<String, dynamic> x) {
    final source = (x['source'] as Map<String, dynamic>? ?? {});
    return JamakolaRule(x['id'].toString(), x['module'].toString(), x['result_te'].toString(), source['file'].toString(), source['printed_page'].toString(), Map<String, dynamic>.from(x['conditions'] as Map));
  }
}

class JamakolaRuleEngine {
  static Future<List<JamakolaRule>> load() async {
    final raw = await rootBundle.loadString('assets/jamakola/rules.json');
    final doc = jsonDecode(raw) as Map<String, dynamic>;
    return (doc['rules'] as List).map((e) => JamakolaRule.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }
  /// House/graha subject indicators describe the possible question topic.
  /// They are not acceptance/denial rules. In particular, 11 non-selected
  /// house indicators must not be rendered as 11 negative predictions.
  static bool isSubjectIndicator(JamakolaRule rule) =>
      rule.module == 'question_subject';
  static List<JamakolaRule> matchingIndicators(
    List<JamakolaRule> rules, Map<String,dynamic> facts,
    {Set<String>? allowedIds}
  ) => rules.where((r) => isSubjectIndicator(r) &&
    (allowedIds == null || allowedIds.contains(r.id)) &&
    r.conditions.keys.every(facts.containsKey) && matches(r,facts)).toList();

  static bool matches(JamakolaRule rule, Map<String, dynamic> facts) =>
      rule.conditions.entries.every((e) => facts.containsKey(e.key) && facts[e.key] == e.value);
  static int? houseFromSigns(int? udhayam, int? other) =>
      udhayam == null || other == null ? null : ((other - udhayam + 12) % 12) + 1;
  static List<JamakolaRule> matching(List<JamakolaRule> rules, Map<String, dynamic> facts, {String? module}) =>
      rules.where((r) => (module == null || r.module == module) && matches(r, facts)).toList();
}
