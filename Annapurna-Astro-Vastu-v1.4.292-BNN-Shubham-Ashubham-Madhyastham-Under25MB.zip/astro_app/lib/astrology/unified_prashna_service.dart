import 'astro_calculation_service.dart';
import 'astro_models.dart';
import 'kp_event_judgement_service.dart';
import 'jamakola_special_service.dart';
import 'jamakola_rule_engine.dart';
import 'tajik_prashna_service.dart';
import 'prashna_event_timing_service.dart';
import '../models/birth_data.dart';

/// One question, one location, one UTC instant; three *independent* systems.
/// The evidence layer may be incomplete; a numerical score is intentionally
/// NOT presented as a probability of a real-world outcome.
class UnifiedPrashnaReport {
  const UnifiedPrashnaReport({required this.question,
    required this.event,required this.input,
    required this.kpTime,required this.kpNumber,
    required this.jamakola,required this.jamakolaRules,
    required this.jamakolaIndications,required this.tajik,
    required this.verdict,required this.conflicts,
    required this.supportingEvidence,required this.pendingEvidence,
    required this.timingStatus,required this.timing});
  final String question;
  final KpEventRule event;
  final BirthData input;
  final KpHoraryEventResult kpTime;
  final KpHoraryEventResult? kpNumber;
  final JamakolaSpecialResult jamakola;
  final List<JamakolaRule> jamakolaRules;
  final List<String> jamakolaIndications;
  final TajikPrashnaObservation tajik;
  final String verdict;
  final List<String> conflicts;
  final List<String> supportingEvidence;
  final List<String> pendingEvidence;
  final String timingStatus;
  final PrashnaEventTimingReport timing;
}


/// A missing/pending condition is NOT a verified negative prediction.
/// Preliminary planetary indications are NOT verified promises of an event.
enum PrashnaEvidenceLevel {
  preliminarySupport,
  incomplete,
  verifiedSupport,
  verifiedDenial,
}

class PrashnaEvidenceSynthesis {
  static bool hasVerifiedConflict(Iterable<PrashnaEvidenceLevel> evidence) =>
    evidence.contains(PrashnaEvidenceLevel.verifiedSupport) &&
    evidence.contains(PrashnaEvidenceLevel.verifiedDenial);

  static String summary(Iterable<PrashnaEvidenceLevel> evidence) {
    if (hasVerifiedConflict(evidence)) {
      return 'ధృవీకరించిన ఆధారాల్లో విభేదం — తుది నిర్ణయం పెండింగ్';
    }
    if (evidence.contains(PrashnaEvidenceLevel.preliminarySupport) ||
        evidence.contains(PrashnaEvidenceLevel.verifiedSupport)) {
      return 'ప్రాథమిక అనుకూల సూచనలు ఉన్నాయి — తుది నిర్ణయం పెండింగ్';
    }
    return 'ఆధారాలు అసంపూర్ణం — తుది నిర్ణయం పెండింగ్';
  }
}

class UnifiedPrashnaService {
  static String? jamaModule(String category) => switch(category) {
    'వివాహం, సంబంధాలు' => 'marriage',
    'ఉద్యోగం, వృత్తి' => 'career_business',
    'సంతానం' => 'childbirth',
    'విద్య' => 'education',
    'ధనం, ఆర్థికం' => 'wealth',
    'ఆస్తులు, వాహనాలు' => 'property',
    'విదేశం, ప్రయాణం' => 'foreign',
    'ఆరోగ్యం, ఆయుర్దాయం' => 'health',
    _ => null,
  };

  static Future<UnifiedPrashnaReport> analyze({
    required BirthData input,
    required KpEventRule event,
    required String question,
    int? horaryNumber,
  }) async {
    if(question.trim().isEmpty)throw ArgumentError('ఒక స్పష్టమైన ప్రశ్న ఇవ్వండి');
    if(input.latitude.abs()>66||input.longitude.abs()>180||
        input.timezoneOffsetHours < -12||input.timezoneOffsetHours >14) {
      throw ArgumentError('Placidus/Jamakola గణనకు సరైన స్థలం, అక్షాంశం అవసరం');
    }
    if(horaryNumber!=null&&(horaryNumber<1||horaryNumber>249)) {
      throw RangeError.range(horaryNumber,1,249,'KP Horary');
    }
    // Serialize calculation because Swiss Ephemeris sidereal mode is global.
    final jamaChart=await AstroCalculationService.calculate(input);
    final jama=await JamakolaSpecialService.calculate(
      local:input.localDateTime,latitude:input.latitude,
      longitude:input.longitude,offsetHours:input.timezoneOffsetHours,
      ayanamsa:input.ayanamsa,chart:jamaChart);
    final allRules=await JamakolaRuleEngine.load();
    final facts=<String,dynamic>{
      'arudam_house_from_udhayam':
        JamakolaRuleEngine.houseFromSigns(
          (jama.udhayam/30).floor(),(jama.arudam/30).floor()),
    };
    final saturn=jamaChart.planets.where((p)=>p.name=='Saturn').firstOrNull;
    if(saturn?.signIndex==6)facts['saturn_dignity']='exalted';
    if(saturn?.signIndex==0)facts['saturn_dignity']='debilitated';
    // Do NOT silently map Prasna Marga Chatra to GK's Kavippu: that would
    // turn unverified rasi positions into invented binary outcomes.
    final module=jamaModule(event.category);
    final selected=<JamakolaRule>[
      for(final r in allRules)
        if(r.module==module&&!JamakolaRuleEngine.isSubjectIndicator(r)&&
          r.conditions.keys.every(facts.containsKey)&&
          JamakolaRuleEngine.matches(r,facts)) r,
    ];
    final indications=<String>[
      'జామం: ${jama.jamam} (${jama.isNight?'రాత్రి':'పగలు'})',
      'ఉదయం రాశి: ${(jama.udhayam/30).floor()+1}',
      'ఆరూఢం రాశి: ${(jama.arudam/30).floor()+1}',
      'ఈ ప్రశ్నకు ${module??'ప్రత్యేకంగా మ్యాప్ కాని'} విభాగం: '
        '${selected.length} ఆధార-షరతులు సరిపోయాయి.',
      'కవిప్పు పూర్తిగా ధృవీకరించలేదు; దాని ఆధారిత తీర్పు చేర్చలేదు.',
    ];
    // Tajika uses actual daily planetary speeds and the SAME question moment.
    final house=event.mainHouse;
    final tajik=house==null
      ? TajikPrashnaObservation(lagnaLord:'—',questionLord:'—',
        questionHouse:0,aspectName:'—',distanceDegrees:null,
        orbDegrees:null,status:'missing',
        explanation:'ఈ KP మూల సంఘటనకు ప్రధాన భావ సంఖ్య స్పష్టం కాలేదు; '
          'ప్రశ్న భావాధిపతితో తాజిక యోగం గణించలేదు.')
      : TajikPrashnaService.evaluate(chart:jamaChart,questionHouse:house);
    final time=await KpHoraryEventService.judgeTimeChart(
      event:event,questionUtc:input.utcDateTime,
      latitude:input.latitude,longitude:input.longitude);
    final number=horaryNumber==null?null:await KpHoraryEventService.judge(
      event:event,number:horaryNumber,questionUtc:input.utcDateTime,
      latitude:input.latitude,longitude:input.longitude);
    // IMPORTANT: KP's provisionalPositive=false does NOT mean KP denies
    // the event. In particular, missing 2/11 house support or a source
    // clause awaiting review is NOT a contradiction of a Tajik trine.
    final supporting=<String>[];
    final pending=<String>[];
    final grades=<PrashnaEvidenceLevel>[];

    void addKpEvidence(String label,KpHoraryEventResult observation) {
      if(observation.mainConnected) {
        supporting.add('$label: ${event.mainHouse??"?"}వ ప్రధాన భావంతో '
          'Cuspal Sub-Lord సంబంధం కనిపించింది (ప్రాథమికం).');
      }
      if(observation.supportConnected) {
        supporting.add('$label: సహాయక భావాలలో కొంత సంబంధం కనిపించింది '
          '(ప్రాథమికం).');
      } else if(event.supporting.isNotEmpty) {
        pending.add('$label: ${event.supporting.join(", ")} సహాయక భావాల '
          'పూర్తి మద్దతు ఇంకా నిర్ధారణ కాలేదు. ఇది నిరాకరణ కాదు.');
      }
      if(observation.sourceReview) {
        pending.add('$label: మూల పుస్తకంలో ఉన్న అదనపు గ్రహ/రాశి '
          'షరతులను ఇంకా పరీక్షించాలి.');
      }
      grades.add(observation.mainConnected||observation.supportConnected
        ?PrashnaEvidenceLevel.preliminarySupport
        :PrashnaEvidenceLevel.incomplete);
    }
    addKpEvidence('KP Time Chart',time);
    if(number!=null) {
      addKpEvidence('KP Number Chart',number);
      if(number.provisionalPositive!=time.provisionalPositive) {
        pending.add('KP Time Chart, Number Chart ప్రాథమిక భావ మద్దతులో '
          'తేడా ఉంది. ఏదీ తుది నిరాకరణ/హామీ కాదు.');
      }
    } else {
      pending.add('KP 1–249 సంఖ్య ఇవ్వలేదు; Number Chartతో '
        'పరస్పర పరిశీలన జరగలేదు (ఇది ఐచ్ఛికం).');
    }
    if(tajik.status=='applying') {
      grades.add(PrashnaEvidenceLevel.preliminarySupport);
      supporting.add('Tajik: ${tajik.lagnaLord}–${tajik.questionLord} '
        'సమీపించే ${tajik.aspectName} సంబంధం (ప్రాథమికం).');
    } else {
      grades.add(PrashnaEvidenceLevel.incomplete);
      pending.add('Tajik: ${tajik.explanation} '
        'ఇది ఒక్కటే సంఘటన నిరాకరణ కాదు.');
    }
    if(selected.isNotEmpty) {
      grades.add(PrashnaEvidenceLevel.preliminarySupport);
      supporting.add('Jamakola: ${selected.length} మూల IF–THEN '
        'షరతులు సరిపోయాయి; సంప్రదాయ తుది నిర్ణయం ఇంకా కాదు.');
    } else {
      grades.add(PrashnaEvidenceLevel.incomplete);
      pending.add('Jamakola: ఎంపిక చేసిన అంశానికి ధృవీకరించిన '
        'నిర్ణాయక నియమం సరిపోలలేదు. ఇది నిరాకరణ కాదు.');
    }
    pending.add('KP: Star/Sub పూర్తి Promise–Denial, వ్యతిరేక భావాలు, '
      'రాహు–కేతు ప్రతినిధిత్వం, దశా–భుక్తి–అంతర, '
      'Ruling Planets, Transit తనిఖీ ఇంకా అవసరం.');
    pending.add('Tajik: 16 యోగాలు, Radda/Nakta/Kamboola, ఇతర నిరోధాల '
      'పూర్తి పరిశీలన లేదు; GK Jamakola Kavippu మూల ధృవీకరణ కూడా పెండింగ్.');
    // All three timing clocks are computed from this SAME question instant.
    // The results are screening windows, never a real-world event promise.
    final timingReport=PrashnaEventTimingService.calculate(
      kpTime:time,kpNumber:number,jama:jama,tajik:tajik,
      questionChart:jamaChart,questionUtc:input.utcDateTime,
      timezoneOffsetHours:input.timezoneOffsetHours);
    final timing='KP అభ్యర్థి DBA కాలాలు: ${timingReport.kp.length}; '
      'KP గోచార తేదీ నమూనాలు: ${timingReport.kpTransit.length}; '
      'Jamakola సమీప సంపర్కాలు: ${timingReport.jamakola.length}; '
      'Tajik ఖచ్చిత దృష్టి సంపర్కాలు: ${timingReport.tajik.length}. '
      'ఇవి పరిశీలన సమయాలు మాత్రమే — సంఘటన జరుగుతుందనే హామీ కాదు. '
      'పూర్తి Promise/Denial మరియు సంప్రదాయ నిర్ణయ నియమాలు ఇంకా అవసరం.';
    final conflicts=<String>[];
    // There is no confirmed denial or promise from ANY of these preliminary
    // engines today. Only *verified* opposite decisions may be a conflict.
    final verdict=PrashnaEvidenceSynthesis.summary(grades);
    return UnifiedPrashnaReport(question:question,event:event,input:input,
      kpTime:time,kpNumber:number,jamakola:jama,
      jamakolaRules:List.unmodifiable(selected),
      jamakolaIndications:List.unmodifiable(indications),tajik:tajik,
      verdict:verdict,conflicts:List.unmodifiable(conflicts),
      supportingEvidence:List.unmodifiable(supporting),
      pendingEvidence:List.unmodifiable(pending),timingStatus:timing,
      timing:timingReport);
  }
}
