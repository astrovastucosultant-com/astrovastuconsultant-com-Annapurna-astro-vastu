import 'bnn_bhava_topics.dart';
import 'bnn_exact_if_engine.dart';
import 'bnn_master_service.dart';
import 'bnn_topic_index.dart';

/// One source of truth for routing *already chart-matched* original THEN
/// sentences to the twelve bhava screens.  A rule's catalogue heading or
/// a planet's location in the IF does NOT make that outcome a house result.
/// No generated source predictions; original rule ids and IFs are retained.
typedef BnnMatchedOutcome = (BnnMasterRule, BnnExactIfResult);

class BnnOutcomeRouter {
  static const _otherPerson = <String>[
    'తండ్రి', 'తల్లికి', 'తల్లి ', 'భార్య', 'భర్త', 'సోదరుడు',
    'సోదరి', 'కుమారుడు', 'కుమార్తె', 'పిల్లలు',
  ];

  /// A single original THEN can legitimately relate to more than one area
  /// (e.g. business income). A single bhava never duplicates a source ID.
  static List<BnnMatchedOutcome> forHouse(
      int house, List<BnnMatchedOutcome> chartMatches) {
    if (house < 1 || house > 12) return const [];
    final topics = BnnBhavaTopicService.forHouse(house);
    final seen = <String>{};
    final selected = <BnnMatchedOutcome>[];
    for (final hit in chartMatches) {
      if (!hit.$2.evaluable || !hit.$2.matched) continue;
      final outcome = hit.$2.matchedThen ?? hit.$1.result;
      if (outcome.trim().isEmpty) continue;
      // Rules defining a general calculation are not outcomes.
      if (const <String>{
        'BNN-BOOK-R-A01', 'BNN-BOOK-R-A02', 'BNN-BOOK-R-A03',
        'BNN-BOOK-R-A04', 'BNN-BOOK-R-A08',
      }.contains(hit.$1.id)) continue;
      // A father/spouse/sibling's personal trait is not the native's trait.
      if (house == 1 && _otherPerson.any(outcome.contains)) continue;
      final relevant = topics.any((topic) {
        final keywords = BnnTopicIndex.resultTerms[topic.name];
        return keywords != null && keywords.any(outcome.contains);
      });
      if (relevant && seen.add(hit.$1.id)) selected.add(hit);
    }
    return selected;
  }

  static List<BnnMatchedOutcome> withoutHouse(
      List<BnnMatchedOutcome> chartMatches) {
    final assigned = <String>{};
    for (var h = 1; h <= 12; h++) {
      assigned.addAll(forHouse(h, chartMatches).map((e) => e.$1.id));
    }
    return chartMatches.where((hit) => !assigned.contains(hit.$1.id))
        .toList(growable: false);
  }
}
