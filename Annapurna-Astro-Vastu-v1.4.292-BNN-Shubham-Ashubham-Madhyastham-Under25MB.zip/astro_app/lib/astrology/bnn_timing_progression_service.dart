import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'astro_calculation_service.dart';
import 'bnn_nadi_degree_engine.dart';
import '../models/birth_data.dart';

/// User-supplied timing/progression master v1.2.249 candidate (48 rules).
/// Calculation specifications are not verified natal event promises.
class BnnTimingRule {
  final String id;
  final String stage;
  final String condition;
  final String consequence;
  final String implementation;
  final String sourceType;
  const BnnTimingRule({required this.id, required this.stage,
    required this.condition, required this.consequence,
    required this.implementation, required this.sourceType});
}

class BnnTimingCatalog {
  static Future<List<BnnTimingRule>> load() async {
    final text = await rootBundle.loadString(
      'assets/bnn/bnn_timing_progression_48_v1_2_249.json');
    final data = jsonDecode(text) as Map<String, dynamic>;
    final rules = (data['rules'] as List<dynamic>).map((element) {
      final rule = element as Map<String, dynamic>;
      return BnnTimingRule(
        id: rule['id'] as String,
        stage: rule['stage'] as String,
        condition: rule['IF'] as String,
        consequence: rule['THEN'] as String,
        implementation: rule['implementation'] as String,
        sourceType: rule['source_type'] as String,
      );
    }).toList(growable: false);
    if (rules.length != 48 ||
        rules.map((r) => r.id).toSet().length != 48 ||
        rules.first.id != 'BNN-TOE-P001' ||
        rules.last.id != 'BNN-TOE-P048') {
      throw const FormatException('BNN timing master 48 rules incomplete');
    }
    return rules;
  }
}

enum BnnProgressionProfile { raoApprox, slowDegrees }

extension BnnProfileLabel on BnnProgressionProfile {
  String get methodId => this == BnnProgressionProfile.raoApprox
      ? 'RAO_APPROX' : 'SLOW_DEGREES';
  String get teluguLabel => this == BnnProgressionProfile.raoApprox
      ? 'RAO_APPROX — గురు 30°/సంవత్సరం' : 'SLOW_DEGREES — గురు 2.5°/సంవత్సరం';
}

class BnnProgressedPosition {
  final String planet;
  final double longitude;
  final double degreesPerYear;
  final BnnProgressionProfile profile;
  const BnnProgressedPosition(this.planet, this.longitude,
      this.degreesPerYear, this.profile);
}

class BnnProgressionContact {
  final String mover;
  final String target;
  final double ageYears;
  final int jupiterRound;
  final BnnProgressionProfile profile;
  const BnnProgressionContact(this.mover, this.target,
      this.ageYears, this.jupiterRound, this.profile);
}

class BnnTransitSample {
  final DateTime atUtc;
  final String mover;
  final double longitude;
  final String target;
  final String relation;
  const BnnTransitSample(this.atUtc, this.mover,
      this.longitude, this.target, this.relation);
}

class BnnTimingProgressionService {
  static double normalize(double value) =>
      BnnNadiDegreeEngine.normalize(value);

  static double speed(String name, BnnProgressionProfile profile) {
    if (profile == BnnProgressionProfile.raoApprox) {
      return switch (name) {
        'Jupiter' => 30.0,
        'Saturn' => 12.0,
        'Rahu' || 'Ketu' => -360.0 / 18.6,
        _ => throw ArgumentError.value(name, 'name', 'Unsupported mover'),
      };
    }
    return switch (name) {
      'Jupiter' => 2.5,
      'Saturn' => 1.0,
      'Rahu' || 'Ketu' => -5.0 / 3.0,
      _ => throw ArgumentError.value(name, 'name', 'Unsupported mover'),
    };
  }

  static int jupiterRound(double age) {
    if (!age.isFinite || age < 0) throw ArgumentError.value(age, 'age');
    return (age / 12).floor() + 1;
  }

  static BnnProgressedPosition progress(PlanetPosition natal,
      double age, BnnProgressionProfile profile) {
    if (!age.isFinite || age < 0) throw ArgumentError.value(age, 'age');
    final rate = speed(natal.name, profile);
    return BnnProgressedPosition(natal.name,
        normalize(natal.longitude + age * rate), rate, profile);
  }

  /// Solve L_mover + rate*age = L_target (mod 360), including each revolution.
  /// Fractional ages describe symbolic contacts; not calendar event dates.
  static List<BnnProgressionContact> contacts({
    required AstroChartResult chart,
    required BnnProgressionProfile profile,
    required double fromAge,
    required double toAge,
  }) {
    if (!fromAge.isFinite || !toAge.isFinite || fromAge < 0 ||
        toAge < fromAge || toAge > 150) {
      throw ArgumentError('Invalid age window');
    }
    final found = <BnnProgressionContact>[];
    for (final moverName in const ['Jupiter', 'Saturn', 'Rahu', 'Ketu']) {
      final mover = BnnNadiDegreeEngine.planet(chart, moverName);
      if (mover == null) continue;
      final rate = speed(moverName, profile);
      final start = mover.longitude + rate * fromAge;
      final end = mover.longitude + rate * toAge;
      final low = math.min(start, end);
      final high = math.max(start, end);
      for (final target in chart.planets) {
        if (target.name == moverName) continue;
        final firstK = ((low - target.longitude) / 360).ceil();
        final lastK = ((high - target.longitude) / 360).floor();
        for (var k = firstK; k <= lastK; k++) {
          final a = (target.longitude + 360 * k - mover.longitude) / rate;
          if (a < fromAge - 1e-9 || a > toAge + 1e-9) continue;
          final bounded = a.clamp(fromAge, toAge).toDouble();
          found.add(BnnProgressionContact(moverName, target.name,
              bounded, jupiterRound(bounded), profile));
        }
      }
    }
    found.sort((a, b) => a.ageYears.compareTo(b.ageYears));
    return found;
  }

  static String? transitRelation(double movingLongitude, double natalLongitude) {
    final m = BnnNadiDegreeEngine.zodiacSign(movingLongitude);
    final n = BnnNadiDegreeEngine.zodiacSign(natalLongitude);
    final offset = BnnNadiDegreeEngine.offset(n, m);
    return switch (offset) {
      0 => 'SAME_SIGN',
      4 || 8 => 'TRINE_159',
      6 => 'OPPOSITION_7',
      _ => null,
    };
  }

  /// Samples actual sidereal Swiss Ephemeris positions 30 days apart.
  /// NEVER report a sample as the exact ingress/contact date.
  static Future<List<BnnTransitSample>> sampleRealTransits({
    required AstroChartResult natal,
    required BirthData birth,
    required DateTime startUtc,
    int steps = 6,
    int intervalDays = 30,
  }) async {
    if (steps < 1 || steps > 24 || intervalDays < 1 || intervalDays > 90) {
      throw ArgumentError('Invalid sampling range');
    }
    final result = <BnnTransitSample>[];
    for (var i = 0; i < steps; i++) {
      final day = startUtc.toUtc().add(Duration(days: i * intervalDays));
      for (final name in const ['Jupiter', 'Saturn']) {
        final actual = await AstroCalculationService.calculatePlanetAtUtc(
          utc: day, planetName: name, ayanamsa: birth.ayanamsa);
        for (final target in natal.planets) {
          if (target.name == name) continue;
          final relation = transitRelation(actual.longitude, target.longitude);
          if (relation != null) {
            result.add(BnnTransitSample(day, name, actual.longitude,
                target.name, relation));
          }
        }
      }
    }
    return result;
  }

  /// Historical catalogue has 0 verified source IF/THEN entries. A numeric
  /// progression age or sampled transit NEVER unlocks final predictions.
  static bool finalEligible({required bool verifiedNatalEventSource,
      required bool matchingProgression, required bool overlappingRealTransit}) =>
      verifiedNatalEventSource && matchingProgression && overlappingRealTransit;
}
