/// Six ordered BNN areas. Engine rules and source rules remain distinct.
class BnnNavigationSpec {
  const BnnNavigationSpec._();

  static const labels = <String>[
    '1. ఫలితాలు',
    '2. 12 భావాలు',
    '3. గ్రహసంబంధాలు',
    '4. సంఘటనల సమయం',
    '5. బంధుత్వాలు',
    '6. మూల నియమాలు',
  ];
}
