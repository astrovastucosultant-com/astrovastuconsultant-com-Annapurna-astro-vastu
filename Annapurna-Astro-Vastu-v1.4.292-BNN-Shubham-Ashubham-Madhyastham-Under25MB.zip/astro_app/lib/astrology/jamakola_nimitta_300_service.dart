import 'dart:convert';
import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'jamakola_special_service.dart';
import 'jamakola_rule_engine.dart';

/// 300 source statements are hypotheses until directly observed by the
/// consulting astrologer. Missing, ambiguous or unverifiable factors never
/// count as a satisfied condition.
class JamaNimittaRule {
  const JamaNimittaRule({required this.number, required this.page,
    required this.udayam, required this.arudam, required this.kavippu,
    required this.nimitta, required this.result});
  final int number, page;
  final String udayam, arudam, kavippu, nimitta, result;
  String get id => 'JNM-${number.toString().padLeft(3, '0')}';

  factory JamaNimittaRule.fromJson(Map<String,dynamic> data) =>
      JamaNimittaRule(
        number:data['number'] as int, page:data['source_page'] as int,
        udayam:data['udayam'] as String, arudam:data['arudam'] as String,
        kavippu:data['kavippu'] as String, nimitta:data['nimitta'] as String,
        result:data['result'] as String,
      );
}

class JamaNimittaCatalog {
  static Future<List<JamaNimittaRule>> load() async {
    final raw=await rootBundle.loadString('assets/jamakola/nimitta_300.json');
    final obj=jsonDecode(raw) as Map<String,dynamic>;
    final rules=(obj['rules'] as List)
      .map((e)=>JamaNimittaRule.fromJson(Map<String,dynamic>.from(e as Map)))
      .toList(growable:false);
    if(rules.length!=300 || rules.map((r)=>r.number).toSet().length!=300) {
      throw const FormatException('జామకోల్ నిమిత్తం 300 నియమాల డేటా అసంపూర్ణం');
    }
    return rules;
  }
}

enum JamaCheck {yes, no, pending}

class JamaNimittaCandidate {
  const JamaNimittaCandidate(this.rule, this.udayam, this.arudam,
    this.kavippu, this.explanation);
  final JamaNimittaRule rule;
  final JamaCheck udayam,arudam,kavippu;
  final String explanation;
  int get passCount => [udayam,arudam,kavippu]
      .where((x)=>x==JamaCheck.yes).length;
  int get pendingCount => [udayam,arudam,kavippu]
      .where((x)=>x==JamaCheck.pending).length;
  bool get hasFailure => [udayam,arudam,kavippu]
      .contains(JamaCheck.no);
  bool get allComputedMatch => passCount==3 && !hasFailure;
}

class JamaNimitta300Analysis {
  static double _norm(double deg)=>(deg%360+360)%360;
  static int _sign(double deg)=>(_norm(deg)/30).floor();
  static int _house(int u,int other)=>
      JamakolaRuleEngine.houseFromSigns(u,other)!;
  static final RegExp _housePattern=RegExp(r'(\d{1,2})\s*(?:వ)?\s*(?:భావ|ఇంట|లో)');
  static final RegExp _degrees=RegExp(r'(\d+(?:\.\d+)?)\s*°');
  static const planetNames=<String,String>{
    'రవి':'Sun', 'సూర్య':'Sun', 'చంద్ర':'Moon', 'కుజ':'Mars',
    'బుధ':'Mercury','గురు':'Jupiter','శుక్ర':'Venus',
    'శని':'Saturn','రాహు':'Rahu','కేతు':'Ketu',
  };

  static List<JamaNimittaCandidate> analyse({
    required List<JamaNimittaRule> rules,
    required AstroChartResult chart,
    required JamakolaSpecialResult special,
    required int kavippuSign,
    required bool kavippuVerified,
    double? exactKavippu,
    double? overrideArudam,
  }) {
    final uSign=_sign(special.udhayam);
    final aSign=_sign(overrideArudam??special.arudam);
    final aHouse=_house(uSign,aSign);
    final kHouse=_house(uSign,kavippuSign);
    final results=<JamaNimittaCandidate>[];
    for(final rule in rules){
      final ud=_udayam(rule.udayam,uSign);
      final ar=_arudam(rule.arudam,aHouse);
      final ka=_kavippu(rule.kavippu,kHouse,
        special.udhayam,kavippuSign,chart,special,exactKavippu);
      // The derived Kavippu sign is preliminary; any positive match using it
      // is demoted until an independent placement is entered by the expert.
      final adjustedKa=(!kavippuVerified && ka==JamaCheck.yes)
          ?JamaCheck.pending:ka;
      final candidate=JamaNimittaCandidate(rule,ud,ar,adjustedKa,
        'ఉదయం రాశి ${uSign+1} • ఆరూఢం $aHouseవ భావం • '
        'కవిప్పు $kHouseవ రాశి-దూరం '
        '(${kavippuVerified?'జ్యోతిష్కుడు ఇచ్చిన స్థానం':'ప్రాథమిక గణన'}) • '
        'జామ గ్రహ సంబంధం అవసరమైతే విడిగా పరిశీలించాలి');
      if(!candidate.hasFailure && (candidate.passCount>=2 ||
          (candidate.passCount==1 && ar==JamaCheck.yes))) {
        results.add(candidate);
      }
    }
    results.sort((a,b){
      final s=b.passCount.compareTo(a.passCount);
      if(s!=0)return s;
      final pending=a.pendingCount.compareTo(b.pendingCount);
      if(pending!=0)return pending;
      return a.rule.number.compareTo(b.rule.number);
    });
    return results;
  }

  static JamaCheck _udayam(String expression,int sign) {
    final text=expression.replaceAll('ుు','ు').replaceAll('ంం','ం');
    if(text.contains('చర రాశి')){
      return [0,3,6,9].contains(sign)?JamaCheck.yes:JamaCheck.no;
    }
    if(text.contains('స్థిర రాశి')){
      return [1,4,7,10].contains(sign)?JamaCheck.yes:JamaCheck.no;
    }
    if(text.contains('ద్విస్వభావ')){
      return [2,5,8,11].contains(sign)?JamaCheck.yes:JamaCheck.no;
    }
    if(text.contains('అగ్ని రాశి')){
      return [0,4,8].contains(sign)?JamaCheck.yes:JamaCheck.no;
    }
    if(text.contains('జల రాశి')){
      return [3,7,11].contains(sign)?JamaCheck.yes:JamaCheck.no;
    }
    if(text.contains('వాయు రాశి')){
      return [2,6,10].contains(sign)?JamaCheck.yes:JamaCheck.no;
    }
    // Udayam counted as its own first house is a positional identity only.
    if(text.contains('1వ భావం') && !text.contains('దృష్టి')){
      return JamaCheck.yes;
    }
    return JamaCheck.pending;
  }

  static JamaCheck _arudam(String expression,int arudamHouse) {
    final text=expression.replaceAll('ంం','ం');
    if(text.contains(' & ') || text.contains('మరియు')){
      return JamaCheck.pending;
    }
    final found=_housePattern.allMatches(text).map((m)=>int.parse(m[1]!))
      .where((x)=>x>=1&&x<=12).toSet();
    if(found.isEmpty) return JamaCheck.pending;
    return found.contains(arudamHouse)?JamaCheck.yes:JamaCheck.no;
  }

  static JamaCheck _kavippu(String expression,int house,
      double udhayam,int kSign,AstroChartResult chart,
      JamakolaSpecialResult special,double? exactKavippu){
    final text=expression.replaceAll('ుు','ు').replaceAll('ంం','ం');
    // Angular distance is meaningful only when a verified exact degree
    // has been supplied; never derive it from a sign-only Kavippu.
    if(text.contains('వెనుక') && text.contains('°')) {
      if(exactKavippu==null)return JamaCheck.pending;
      final match=_degrees.firstMatch(text);
      if(match==null)return JamaCheck.pending;
      final expected=double.parse(match[1]!);
      final separation=_norm(udhayam-exactKavippu);
      return (separation-expected).abs()<=0.35
          ?JamaCheck.yes:JamaCheck.no;
    }
    final match=_housePattern.firstMatch(text);
    if(match!=null){
      final target=int.parse(match[1]!);
      if(target!=house)return JamaCheck.no;
      if(text.contains('దృష్టి'))return JamaCheck.pending;
      final namedPlanets=<String>{};
      for(final entry in planetNames.entries){
        if(text.contains(entry.key))namedPlanets.add(entry.value);
      }
      if(namedPlanets.isNotEmpty){
        // Both Jama and ordinary question planets are tested. Which ring
        // the source refers to is ambiguous; even positive geometry remains
        // pending for the traditional consultant's interpretation.
        for(final planetName in namedPlanets){
          final inJama=special.jamaGrahas.any((p)=>
            p.name==planetName && p.signIndex==kSign);
          final inInner=chart.planets.any((p)=>
            p.name==planetName && p.signIndex==kSign);
          if(!inJama && !inInner)return JamaCheck.no;
        }
        return JamaCheck.pending;
      }
      return JamaCheck.yes;
    }
    return JamaCheck.pending;
  }
}
