import 'package:flutter/material.dart';
import 'package:sweph/sweph.dart';

import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/jamakola_rule_engine.dart';
import '../astrology/jamakola_nimitta_300_service.dart';
import '../astrology/jamakola_special_service.dart';
import '../astrology/mandi_calculation_service.dart';
import '../astrology/vedic_calculation_service.dart';
import '../models/birth_data.dart';
import '../services/place_search_service.dart';

/// Reference-inspired Jamakola consultation interface.
/// Swiss Ephemeris provides ordinary sidereal planets and Udayam (ascendant).
/// Arudam and the separate Jama ring use their documented computational modes.
/// The pink KAV sign uses the counter-motion Sun Veedhi/Arudam/Udhayam rule.
/// Two alternative exact-degree conventions remain comparisons, not verdicts.
/// Some source-dependent values remain manually verifiable.
class JamakolaRulePanel extends StatefulWidget {
  const JamakolaRulePanel({super.key, required this.birthData});
  final BirthData birthData;

  @override
  State<JamakolaRulePanel> createState() => _JamakolaRulePanelState();
}

class _JamakolaRulePanelState extends State<JamakolaRulePanel> {
  static const _maroon = Color(0xFFB30000);
  static const _cream = Color(0xFFFFFBD3);
  static const _pink = Color(0xFFFF0752);
  static const _teSigns = <String>[
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];
  static const _signShort = <String>[
    'మేష','వృష','మిథు','కర్కా','సింహ','కన్య',
    'తుల','వృశ్చి','ధను','మకర','కుంభ','మీనం',
  ];
  static const _planetTe = <String,String>{
    'Sun':'రవి','Moon':'చంద్ర','Mars':'కుజ','Mercury':'బుధ',
    'Jupiter':'గురు','Venus':'శుక్ర','Saturn':'శని',
    'Rahu':'రాహు','Ketu':'కేతు',
  };
  static const _short = <String,String>{
    'Sun':'Su','Moon':'Mo','Mars':'Ma','Mercury':'Me',
    'Jupiter':'Ju','Venus':'Ve','Saturn':'Sa','Rahu':'Ra','Ketu':'Ke',
  };
  static const _weekdays = <String>[
    'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday',
  ];
  static const _confirmationFields = <String>[
    'Jama Planet Crossed Udaya',
    'Jama Planet approaching Udaya',
    'Inner Planets in Udaya',
    'Udaya to Aruda bhava connection',
    'Udaya to Kavippu bhava connection',
    'Exalted Inner Planets',
    'Exalted Jama Planets',
    'Debilitated Inner Planets',
    'Debilitated Jama Planets',
    'Same Inner and Jama Planet',
    '10th Lord bhava connections',
    'Inner Planets Parivarthana',
    'Jama Planets Parivarthana',
    'Inner-Jama Planets Parivarthana',
    'Kavippu catching',
  ];

  late DateTime _localMoment;
  late final TextEditingController _place;
  late final TextEditingController _latitude;
  late final TextEditingController _longitude;
  late final TextEditingController _utcOffset;
  final _arudam = TextEditingController();
  final _chatra = TextEditingController();
  final _mandi = TextEditingController();
  final _yamaghan = TextEditingController();
  late Future<AstroChartResult> _chartFuture;
  late Future<JamakolaSpecialResult> _specialFuture;
  late Future<MandiCalculationResult> _mandiFuture;
  late final Future<List<JamakolaRule>> _ruleFuture;
  late final Future<List<JamaNimittaRule>> _nimittaFuture;
  final Set<int> _witnessedNimitta = <int>{};
  bool _moreNimitta = false;
  final GlobalKey _nimittaPanelKey = GlobalKey();
  bool _stale = false;
  bool _coordinatesVerified = true;
  bool _latUpdated = true;
  bool _lonUpdated = true;
  bool _bhava = false;
  bool _showWideTableOnMobile = false;
  bool _searchingPlace = false;
  String _selectedJamaModule = 'all';
  String? _approaching;
  String? _gowri;
  int? _kavipuSign;
  int? _veedhiAnchorSign;

  @override
  void initState() {
    super.initState();
    final offset = widget.birthData.timezoneOffsetHours;
    _localMoment = DateTime.now().toUtc().add(
      Duration(minutes:(offset*60).round()));
    _place = TextEditingController(text:widget.birthData.place);
    _latitude = TextEditingController(text:widget.birthData.latitude.toStringAsFixed(5));
    _longitude = TextEditingController(text:widget.birthData.longitude.toStringAsFixed(5));
    _utcOffset = TextEditingController(text:offset.toString());
    _chartFuture = _calculateChart();
    _specialFuture = _calculateSpecial();
    _mandiFuture = _calculateMandi();
    _ruleFuture = JamakolaRuleEngine.load();
    _nimittaFuture = JamaNimittaCatalog.load();
  }

  @override
  void dispose() {
    for (final c in [_place,_latitude,_longitude,_utcOffset,
      _arudam,_chatra,_mandi,_yamaghan]) { c.dispose(); }
    super.dispose();
  }

  double? get _lat => double.tryParse(_latitude.text.trim());
  double? get _lon => double.tryParse(_longitude.text.trim());
  double? get _offset => double.tryParse(_utcOffset.text.trim());

  Future<AstroChartResult> _calculateChart() {
    final lat = _lat, lon = _lon, tz = _offset;
    if (lat==null || lon==null || tz==null || !_coordinatesVerified ||
        lat < -90 || lat > 90 || lon < -180 || lon > 180 ||
        tz < -12 || tz > 14) {
      return Future.error(StateError('Place, Latitude, Longitude, UTC Offset సరిచూడండి.'));
    }
    return AstroCalculationService.calculate(BirthData(
      name:'Jamakola ప్రశ్న',localDateTime:_localMoment,
      place:_place.text.trim(),latitude:lat,longitude:lon,
      timezoneOffsetHours:tz,ayanamsa:widget.birthData.ayanamsa,
    ));
  }

  Future<JamakolaSpecialResult> _calculateSpecial() async {
    final chart=await _chartFuture;
    return JamakolaSpecialService.calculate(
      local:_localMoment,
      latitude:_lat!,longitude:_lon!,offsetHours:_offset!,
      ayanamsa:widget.birthData.ayanamsa,
      chart:chart,
    );
  }

  /// Mandi is evaluated for the selected *question's local civil time*,
  /// with the chosen coordinates and UTC offset. Never use the device time zone.
  Future<MandiCalculationResult> _calculateMandi() async {
    // Swiss Ephemeris is process-global. Finish the ordinary/Jama calculations
    // before changing its sidereal mode to evaluate Mandi's special ascendant.
    await _specialFuture;
    final lat=_lat, lon=_lon, tz=_offset;
    if(lat==null || lon==null || tz==null || !_coordinatesVerified ||
        lat.abs()>66 || lon.abs()>180 || tz < -12 || tz > 14) {
      throw StateError('మండీ గణనకు సరైన స్థలం, అక్షాంశం, రేఖాంశం, UTC Offset అవసరం.');
    }
    return MandiCalculationService.calculate(BirthData(
      name:'Jamakola ప్రశ్న',localDateTime:_localMoment,
      place:_place.text.trim(),latitude:lat,longitude:lon,
      timezoneOffsetHours:tz,ayanamsa:widget.birthData.ayanamsa,
    ));
  }

  void _recalculate() {
    setState(() {
      _chartFuture=_calculateChart();
      _specialFuture=_calculateSpecial();
      _mandiFuture=_calculateMandi();
      _stale=false;
      _witnessedNimitta.clear();
      _moreNimitta=false;
    });
  }

  void _markStale() => setState(() => _stale=true);

  void _now() {
    final tz = _offset ?? widget.birthData.timezoneOffsetHours;
    _localMoment=DateTime.now().toUtc().add(
      Duration(minutes:(tz*60).round()));
    _recalculate();
  }

  Future<void> _selectDate() async {
    final selected = await showDatePicker(
      context:context,firstDate:DateTime(1800),lastDate:DateTime(2200),
      initialDate:_localMoment);
    if (selected==null || !mounted) return;
    setState(() {
      _localMoment=DateTime(selected.year,selected.month,selected.day,
        _localMoment.hour,_localMoment.minute);_stale=true;
    });
  }
  Future<void> _selectTime() async {
    final selected = await showTimePicker(context:context,
      initialTime:TimeOfDay(hour:_localMoment.hour,minute:_localMoment.minute));
    if (selected==null || !mounted) return;
    setState(() {
      _localMoment=DateTime(_localMoment.year,_localMoment.month,_localMoment.day,
        selected.hour,selected.minute);_stale=true;
    });
  }

  Future<void> _searchPlace() async {
    if (_searchingPlace) return;
    setState(() => _searchingPlace=true);
    try {
      final results=await PlaceSearchService.search(_place.text);
      if (!mounted) return;
      if (results.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content:Text('స్థలం కనపడలేదు. మరో పేరు ప్రయత్నించండి.')));
        return;
      }
      await showModalBottomSheet<void>(context:context,isScrollControlled:true,
        builder:(sheet)=>SafeArea(child:ConstrainedBox(
          constraints:BoxConstraints(maxHeight:MediaQuery.sizeOf(sheet).height*0.7),
          child:ListView(children:[
            const ListTile(title:Text('స్థలం ఎంచుకోండి')),
            for(final item in results)
              ListTile(title:Text(item.displayName),
                subtitle:Text('${item.latitude}, ${item.longitude}'),
                onTap:(){
                  _place.text=item.displayName;
                  _latitude.text=item.latitude.toStringAsFixed(6);
                  _longitude.text=item.longitude.toStringAsFixed(6);
                  setState(() { _coordinatesVerified=true;_stale=true; });
                  Navigator.pop(sheet);
                }),
          ]))));
    } catch(e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text('స్థలం వెతకలేకపోయాం: $e')));
    } finally {
      if (mounted) setState(() => _searchingPlace=false);
    }
  }

  static String _two(int v)=>v.toString().padLeft(2,'0');
  static double _norm(double v)=>(v%360+360)%360;
  static String _dms(double value) {
    final seconds=(_norm(value)*3600).round()%(360*3600);
    final d=seconds~/3600, m=(seconds%3600)~/60,s=seconds%60;
    return '${d}° ${_two(m)}′ ${_two(s)}″';
  }
  static String _inSign(double value) => _dms(_norm(value)%30);
  static String _longitudeString(double value)=>
    '${_two((_norm(value)/30).floor())}s ${_inSign(value)}';
  static String _date(DateTime d)=>'${_two(d.day)}-${_two(d.month)}-${d.year}';
  static String _time(DateTime d)=>'${_two(d.hour)}:${_two(d.minute)}';

  double? _optionalLongitude(TextEditingController c) {
    if(c.text.trim().isEmpty)return null;
    final n=double.tryParse(c.text.trim());
    return n==null || n<0 || n>=360 ? null : n;
  }
  int? _manualSign(TextEditingController c) =>
    _optionalLongitude(c)==null?null:(_optionalLongitude(c)!/30).floor();


  /// Pink KAV sign comes from the counter-motion solar Veedhi transfer.
  /// The historical method name chatraSign is kept for backward compatibility;
  /// an entered total longitude overrides it for display only.
  int _chatraSign(AstroChartResult chart, JamakolaSpecialResult special) {
    final entered=_optionalLongitude(_chatra);
    if (entered!=null) return (entered/30).floor();
    // One source of truth: a user-verified manual rasi takes precedence over
    // the preliminary computed pink KAV rasi on both chart and rule panel.
    if (_kavipuSign!=null) return _kavipuSign!;
    final sun=chart.planets.where((p)=>p.name=='Sun').firstOrNull;
    if (sun==null) throw StateError('ఛత్రం గణనకు సూర్యుడి స్థానము అవసరం');
    return JamakolaSpecialService.chatraSign(
      sunLongitude:sun.longitude,
      udhayam:special.udhayam,
      arudam:_optionalLongitude(_arudam)??special.arudam,
    );
  }

  /// Degree comparison only: auto Veedhi from the sidereal Sun unless the
  /// user explicitly overrides the anchor. The mirrored degree method is not
  /// used for rules or for asserting a confirmed exact KAV bhava.
  double? _sourceKavippu(AstroChartResult chart,JamakolaSpecialResult special) {
    final sun=chart.planets.where((p)=>p.name=='Sun').firstOrNull;
    if (sun==null && _veedhiAnchorSign==null) return null;
    final anchor=_veedhiAnchorSign ??
      JamakolaSpecialService.chatraVeedhiSign(sun!.longitude);
    return JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:special.udhayam,
      arudam:_optionalLongitude(_arudam)??special.arudam,
      anchorSignIndex:anchor,
    );
  }

  Widget _input(TextEditingController ctrl,String label,
      {ValueChanged<String>? onChanged, bool numeric=false}) =>
    TextField(controller:ctrl,
      keyboardType:numeric?const TextInputType.numberWithOptions(decimal:true,
        signed:true):TextInputType.text,
      onChanged:onChanged,
      decoration:InputDecoration(labelText:label,isDense:true,
        border:const OutlineInputBorder()));

  Widget _top() {
    return Container(color:_cream,padding:const EdgeInsets.all(12),
      child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Container(color:_maroon,padding:const EdgeInsets.symmetric(
          vertical:10,horizontal:14),child:const Text('Jamakola / జామకోళ ప్రశ్న చక్రం',
          style:TextStyle(color:Colors.white,fontSize:19,
            fontWeight:FontWeight.bold))),
        const SizedBox(height:12),
        Row(children:[
          Expanded(child:_input(_place,'Place / స్థలం',onChanged:(_){
            setState(() {_coordinatesVerified=false;_latUpdated=false;_lonUpdated=false;_stale=true;});
          })),
          const SizedBox(width:6),
          IconButton(onPressed:_searchingPlace?null:_searchPlace,
            tooltip:'Village / Place Search',icon:_searchingPlace
              ?const SizedBox(height:18,width:18,child:CircularProgressIndicator(strokeWidth:2))
              :const Icon(Icons.search)),
        ]),
        const SizedBox(height:8),
        Row(children:[
          Expanded(child:_headerButton(_date(_localMoment),_selectDate,Colors.black)),
          const SizedBox(width:4),
          Expanded(child:_headerButton(_time(_localMoment),_selectTime,Colors.black)),
          const SizedBox(width:4),
          Expanded(child:_headerButton('NOW',_now,const Color(0xFFFF9400),
            textColor:Colors.black)),
        ]),
        const SizedBox(height:8),
        Row(children:[
          Expanded(child:_input(_latitude,'Latitude',numeric:true,onChanged:(_){
            setState(() { _latUpdated=true;_coordinatesVerified=_latUpdated&&_lonUpdated;_stale=true;});
          })),
          const SizedBox(width:5),
          Expanded(child:_input(_longitude,'Longitude',numeric:true,onChanged:(_){
            setState(() { _lonUpdated=true;_coordinatesVerified=_latUpdated&&_lonUpdated;_stale=true;});
          })),
          const SizedBox(width:5),
          SizedBox(width:82,child:_input(_utcOffset,'UTC ±',numeric:true,
            onChanged:(_)=>_markStale())),
        ]),
        if(!_coordinatesVerified) const Padding(
          padding:EdgeInsets.only(top:5),
          child:Text('స్థలం పేరు మారింది. Searchతో స్థలం ఎంచుకోండి లేదా సరైన Coordinates ఇవ్వండి.',
            style:TextStyle(color:Color(0xFFAA3300),fontSize:12))),
        const SizedBox(height:8),
        FilledButton.icon(onPressed:_recalculate,
          icon:const Icon(Icons.calculate_outlined),
          label:const Text('చక్రం గణించండి'),
          style:FilledButton.styleFrom(backgroundColor:_maroon)),
        const Divider(height:20,thickness:2,color:Colors.black),
      ]));
  }

  Widget _headerButton(String label,VoidCallback action,Color bg,
    {Color textColor=Colors.white})=>SizedBox(height:46,
      child:Material(color:bg,child:InkWell(onTap:action,
        child:Center(child:Text(label,maxLines:1,
          style:TextStyle(color:textColor,fontSize:16,fontWeight:FontWeight.bold))))));

  /// Finds locally observable planetary hora using actual sunrise and sunset.
  /// It is *not* the unverified Jamakola Jama-planet calculation.
  String _hora() {
    final lat=_lat,lon=_lon,tz=_offset;
    if(lat==null||lon==null||tz==null)return '—';
    final utc=DateTime.utc(_localMoment.year,_localMoment.month,_localMoment.day,
      _localMoment.hour,_localMoment.minute)
      .subtract(Duration(minutes:(tz*60).round()));
    double jd(DateTime d)=>Sweph.swe_julday(d.year,d.month,d.day,
      d.hour+d.minute/60+d.second/3600,CalendarType.SE_GREG_CAL);
    double? rise(double from, bool sunrise){
      final t=Sweph.swe_rise_trans(from,HeavenlyBody.SE_SUN,
        SwephFlag.SEFLG_MOSEPH,
        sunrise?RiseSetTransitFlag.SE_CALC_RISE:RiseSetTransitFlag.SE_CALC_SET,
        GeoPosition(lon,lat),0,0);
      if(t==null || !t.isFinite)return null;
      return t;
    }
    try {
      final dayStart=DateTime.utc(_localMoment.year,_localMoment.month,
        _localMoment.day).subtract(Duration(minutes:(tz*60).round()));
      final sunriseToday=rise(jd(dayStart),true);
      if(sunriseToday==null)return '—';
      final todayJd=jd(utc);
      final before=todayJd<sunriseToday;
      final start=before?rise(jd(dayStart)-1,true):sunriseToday;
      if(start==null)return '—';
      final sunset=rise(start+0.01,false);
      if(sunset==null)return '—';
      final nextRise=rise(sunset+0.01,true);
      if(nextRise==null)return '—';
      final sunlight=todayJd<sunset;
      final segment=sunlight?(sunset-start)/12:(nextRise-sunset)/12;
      if(segment<=0)return '—';
      final elapsed=sunlight?(todayJd-start):(todayJd-sunset);
      final index=(elapsed/segment).floor().clamp(0,11).toInt()+(sunlight?0:12);
      const cycle=['Sun','Venus','Mercury','Moon','Saturn','Jupiter','Mars'];
      final todayWeekday=before
        ?(_localMoment.weekday==1?7:_localMoment.weekday-1)
        :_localMoment.weekday;
      const dayLord=['Moon','Mars','Mercury','Jupiter','Venus','Saturn','Sun'];
      final first=cycle.indexOf(dayLord[todayWeekday-1]);
      return '${cycle[(first+index)%7]} (${index+1}వ హోరా)';
    } catch (_) {return '—';}
  }


  static const _houseTopics = <String>[
    'శరీరం / స్వభావం / స్వీయ ప్రశ్న',
    'ధనం / కుటుంబం / బకాయిలు',
    'ప్రయాణాలు / సోదరులు / సమాచారము',
    'ఇల్లు / భూమి / వాహనం',
    'విద్య / సంతానం / ప్రేమ',
    'అడ్డంకులు / ఋణం / విభేదాలు',
    'వివాహం / భాగస్వామ్యం',
    'అనిశ్చితి / క్లిష్ట పరిస్థితులు',
    'ధర్మం / ప్రయాణం / అదృష్టం',
    'ఉద్యోగం / వ్యాపారం / అధికారులు',
    'ఆదాయం / లాభం / మిత్రులు',
    'వ్యయాలు / విదేశం / నిద్ర',
  ];

  /// Visible immediately BELOW the upper Jama Grahas chart. This is an
  /// Arudam/Kavippu topic lead, not an asserted event or diagnosis. The
  /// longer 300-rule inspection stays after the ordinary question chart.
  Widget _nowQuestionSummary(AstroChartResult chart,
      JamakolaSpecialResult special,int kavippuSign,double? manualKav,
      double arudam) {
    final u=(special.udhayam/30).floor()%12;
    final a=(arudam/30).floor()%12;
    final arudamHouse=(a-u+12)%12+1;
    final kavHouse=(kavippuSign-u+12)%12+1;
    final isManual=manualKav!=null || _kavipuSign!=null;
    final sun=chart.planets.where((p)=>p.name=='Sun').firstOrNull;
    final sphuta=sun==null?null:
      JamakolaSpecialService.kavippuAbsoluteSphutaCandidate(
        sunLongitude:sun.longitude,
        udhayam:special.udhayam,arudam:arudam);

    return Container(
      margin:const EdgeInsets.fromLTRB(8,10,8,8),
      padding:const EdgeInsets.all(13),
      decoration:BoxDecoration(
        color:const Color(0xFFF1F7FF),
        borderRadius:BorderRadius.circular(16),
        border:Border.all(color:const Color(0xFF3261A4),width:1.4),
      ),
      child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Text('NOW TIME — ప్రశ్నకర్త వచ్చిన సమస్య సూచన',
          style:TextStyle(fontSize:17,fontWeight:FontWeight.w900,
            color:Color(0xFF17345F))),
        const SizedBox(height:5),
        Text('ప్రశ్న సమయం: ${_date(_localMoment)} ${_time(_localMoment)}'
          '  •  ${_place.text.trim()}',
          style:const TextStyle(fontSize:12.5,color:Color(0xFF17345F))),
        const SizedBox(height:9),
        Wrap(spacing:6,runSpacing:6,children:[
          Chip(label:Text('ఉదయం: ${_teSigns[u]}'),
            backgroundColor:const Color(0xFFEBE4FF)),
          Chip(label:Text('ఆరూఢం: ${_teSigns[a]}'),
            backgroundColor:const Color(0xFFD8F1DC)),
          Chip(label:Text('కవిప్పు: ${_teSigns[kavippuSign]}'),
            backgroundColor:const Color(0xFFFFDAE8)),
        ]),
        const SizedBox(height:5),
        Text('ఆరూఢం $arudamHouse వ రాశి స్థానంలో — '
          '${_houseTopics[arudamHouse-1]}',
          style:const TextStyle(fontSize:14.5,fontWeight:FontWeight.w800,
            height:1.45)),
        const SizedBox(height:5),
        Text('కవిప్పు $kavHouse వ రాశి స్థానంలో — '
          '${_houseTopics[kavHouse-1]} '
          '${isManual?'(Manual స్థాన పరిశీలన)':'(ప్రాథమిక గణన)'}',
          style:const TextStyle(fontSize:13,height:1.45)),
        if(sphuta!=null && (sphuta/30).floor()%12!=kavippuSign)
          Padding(padding:const EdgeInsets.only(top:6),child:Text(
            'గమనిక: ప్రతిపాదిత కవిప్పు స్ఫుటం ${_teSigns[(sphuta/30).floor()%12]}; '
            'పింక్ KAV ${_teSigns[kavippuSign]} వేరే పద్ధతి. '
            'స్ఫుటం పోలిక మాత్రమే; నియమానికి పింక్ KAV రాశే ఆధారం.',
            style:const TextStyle(color:Color(0xFF9C5312),fontSize:11.5,
              height:1.45))),
        const SizedBox(height:7),
        FutureBuilder<List<JamaNimittaRule>>(
          future:_nimittaFuture,
          builder:(context,snapshot){
            if(snapshot.hasError) return const Text(
              '300 నిమిత్త సూత్రాల లోడింగ్ సమస్య.',
              style:TextStyle(fontSize:12,color:Colors.deepOrange));
            if(!snapshot.hasData) return const LinearProgressIndicator();
            final candidates=JamaNimitta300Analysis.analyse(
              rules:snapshot.data!,chart:chart,special:special,
              kavippuSign:kavippuSign,
              kavippuVerified:isManual,
              exactKavippu:manualKav,overrideArudam:arudam,
            );
            return Text('300 సూత్రాలలో ${candidates.length} ప్రాథమిక సూచనలు. '
              'నిజమైన సంఘటన/కారణం నిమిత్తం మరియు మిగిలిన '
              'గ్రహసంబంధ షరతులు ధృవీకరించిన తరువాతే నిర్ణయించాలి.',
              style:const TextStyle(fontSize:12.5,height:1.45));
          }),
        const SizedBox(height:5),
        Align(alignment:Alignment.centerLeft,child:OutlinedButton.icon(
          onPressed:(){
            final ctx=_nimittaPanelKey.currentContext;
            if(ctx!=null){
              Scrollable.ensureVisible(ctx,
                duration:const Duration(milliseconds:450),
                curve:Curves.easeInOut);
            }
          },
          icon:const Icon(Icons.fact_check_outlined),
          label:const Text('300 నిమిత్తాల పూర్తి జాతక పరిశీలన చూడండి'),
        )),
        const Text('ఇవి జ్యోతిష్య పరిశీలనకు ప్రశ్న అంశ సూచనలు మాత్రమే; '
          'జరిగిన ప్రమాదం, అనారోగ్యం, మోసం మొదలైనవి నిర్ధారించబడలేదు.',
          style:TextStyle(fontSize:11.5,color:Color(0xFF6A6472),height:1.4)),
      ]),
    );
  }

  Widget _nimittaPanel(AstroChartResult chart,JamakolaSpecialResult special,
      int kavippuSign,double? verifiedKavippu,double arudam) {
    return FutureBuilder<List<JamaNimittaRule>>(
      future:_nimittaFuture,
      builder:(context,snapshot) {
        if(snapshot.hasError) return Padding(
          padding:const EdgeInsets.all(10),
          child:Text('300 నిమిత్త నియమాలు లోడ్ కాలేదు: ${snapshot.error}',
            style:const TextStyle(color:Colors.red)),
        );
        if(!snapshot.hasData)return const Padding(
          padding:EdgeInsets.all(12),child:LinearProgressIndicator());
        final candidates=JamaNimitta300Analysis.analyse(
          rules:snapshot.data!,chart:chart,special:special,
          kavippuSign:kavippuSign,
          kavippuVerified:verifiedKavippu!=null || _kavipuSign!=null,
          exactKavippu:verifiedKavippu,overrideArudam:arudam,
        );
        final visible=_moreNimitta?candidates.take(60):candidates.take(6);
        final evidenceNeeded=candidates.where((x)=>x.pendingCount>0).length;
        return Container(
          key:_nimittaPanelKey,
          margin:const EdgeInsets.fromLTRB(8,12,8,12),
          padding:const EdgeInsets.all(13),
          decoration:BoxDecoration(
            color:const Color(0xFFFFFBF0),
            borderRadius:BorderRadius.circular(15),
            border:Border.all(color:const Color(0xFFD8B66A),width:1.4),
          ),
          child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
            const Text('ఇప్పుడు వచ్చిన ప్రశ్న — జామకోల్ నిమిత్త పరిశీలన',
              style:TextStyle(fontSize:17,fontWeight:FontWeight.w900,
                color:Color(0xFF17345F))),
            const SizedBox(height:5),
            Text('ప్రశ్న సమయం: ${_date(_localMoment)} ${_time(_localMoment)}  •  '
              '${_place.text.trim()} • జామం ${special.jamam}',
              style:const TextStyle(fontSize:12.5,fontWeight:FontWeight.w600)),
            const SizedBox(height:5),
            Text('ఉదయం ${_teSigns[(special.udhayam/30).floor()%12]}  •  '
              'ఆరూఢం ${_teSigns[(arudam/30).floor()%12]}  •  '
              'కవిప్పు ${_teSigns[kavippuSign]}',
              style:const TextStyle(fontSize:12.5)),
            if(verifiedKavippu!=null) Padding(
              padding:const EdgeInsets.only(top:6),
              child:Text(() {
                final degrees=_norm(special.udhayam-verifiedKavippu);
                if(degrees>15) {
                  return 'ఉదయం–కవిప్పు దూరం ${degrees.toStringAsFixed(2)}°. '
                    '15° పరిధి దాటింది; గతించిన నిమిషాలను ఈ సూత్రంతో నిర్ధారించలేదు.';
                }
                return 'Manual KAV డిగ్రీ ఆధారంగా ఉదయం వెనుక సుమారు '
                  '${(degrees*4).toStringAsFixed(1)} నిమిషాలు (Δθ × 4). '
                  'ఇది గణిత అంచనా; సంఘటన సమయానికి స్వతంత్ర ధృవీకరణ కాదు.';
              }(),style:const TextStyle(fontSize:12.5,
                fontWeight:FontWeight.w700)),
            ),
            const SizedBox(height:7),
            const Text('సూత్రాల ఆధారంగా ప్రశ్నకర్త ఏ సమస్యతో వచ్చి ఉండవచ్చో '
              'పరిశీలించండి. ప్రత్యక్ష నిమిత్తం జ్యోతిష్కుడు మాత్రమే ధృవీకరించాలి.',
              style:TextStyle(fontSize:12.5,height:1.4)),
            const SizedBox(height:8),
            Text('300 సూత్రాలలో ${candidates.length} ప్రాథమిక సూచనలు  •  '
              '$evidenceNeeded కు అదనపు ధృవీకరణ అవసరం',
              style:const TextStyle(fontSize:12.5,fontWeight:FontWeight.w800,
                color:Color(0xFF8A4D1B))),
            const SizedBox(height:9),
            if(candidates.isEmpty)const Padding(
              padding:EdgeInsets.all(8),child:Text(
                'ఉదయం–ఆరూఢం–కవిప్పు ప్రస్తుత గణనతో సరిపోయే సూచనలు లేవు. '
                'అది ప్రశ్న లేకపోవడానికి ఆధారం కాదు.')),
            for(final candidate in visible)
              Card(
                margin:const EdgeInsets.only(bottom:8),
                color:Colors.white,elevation:0,
                shape:RoundedRectangleBorder(
                  borderRadius:BorderRadius.circular(12),
                  side:const BorderSide(color:Color(0xFFE3DDCF))),
                child:ExpansionTile(
                  key:ValueKey('${candidate.rule.id}-${_localMoment.toIso8601String()}'),
                  title:Text(candidate.rule.result,
                    style:const TextStyle(fontSize:14,fontWeight:FontWeight.w800,
                      height:1.4)),
                  subtitle:Text('${candidate.rule.id} • '
                    '${candidate.passCount}/3 చక్ర షరతులు • '
                    '${candidate.pendingCount} పరిశీలించాల్సినవి',
                    style:const TextStyle(fontSize:11.5,color:Colors.deepOrange)),
                  children:[
                    _nimittaDetail('ఉదయం షరతు',candidate.rule.udayam,candidate.udayam),
                    _nimittaDetail('ఆరూఢం షరతు',candidate.rule.arudam,candidate.arudam),
                    _nimittaDetail('కవిప్పు షరతు',candidate.rule.kavippu,candidate.kavippu),
                    ListTile(dense:true,
                      title:const Text('జామ గ్రహాలు / ఇన్నర్ గ్రహాల పోలిక'),
                      subtitle:Text(_nimittaPlanetFacts(candidate.rule,chart,special))),
                    CheckboxListTile(
                      value:_witnessedNimitta.contains(candidate.rule.number),
                      controlAffinity:ListTileControlAffinity.leading,
                      title:const Text('ఈ ప్రత్యక్ష నిమిత్తాన్ని నేను గమనించాను'),
                      subtitle:Text(candidate.rule.nimitta),
                      onChanged:(v)=>setState(() {
                        if(v==true) _witnessedNimitta.add(candidate.rule.number);
                        else _witnessedNimitta.remove(candidate.rule.number);
                      }),
                    ),
                    ListTile(dense:true,
                      title:const Text('జ్యోతిష్కుని నిర్ణయ స్థితి'),
                      subtitle:Text(
                        _witnessedNimitta.contains(candidate.rule.number)
                          ?(candidate.allComputedMatch
                              ?'ప్రత్యక్ష నిమిత్తం నమోదైంది; మూడు చక్ర షరతులు సరిపోయాయి. '
                                'ఇది సంప్రదాయ సూచన, జరిగిన సంఘటనకు రుజువు కాదు.'
                              :'నిమిత్తం నమోదైంది; మిగిలిన చక్ర/గ్రహ షరతులు ఇంకా పెండింగ్.')
                          :'ప్రత్యక్ష నిమిత్తం నమోదు కాలేదు — తుది నిర్ణయం పెండింగ్.')),
                    ListTile(dense:true,
                      title:const Text('మూలం / పరిశీలన'),
                      subtitle:Text('జామకోల్ ప్రశ్న & నిమిత్త శాస్త్రం 300 సూత్రాలు, '
                        'PDF పేజీ ${candidate.rule.page}, సూత్రం ${candidate.rule.number}. '
                        '${candidate.explanation}')),
                  ],
                ),
              ),
            if(candidates.length>6)
              TextButton.icon(
                onPressed:()=>setState(()=>_moreNimitta=!_moreNimitta),
                icon:Icon(_moreNimitta?Icons.expand_less:Icons.expand_more),
                label:Text(_moreNimitta?'తక్కువ చూపించు':
                  'మిగతా ${candidates.length-6} సూచనలు చూపించు'),
              ),
            const Text('గమనిక: సూత్రాల్లో పేర్కొన్న అనారోగ్యం, నేరం, మోసం '
              'వంటి నిర్దిష్ట సంఘటనలు స్వతంత్రంగా ధృవీకరించబడవు. '
              'Now Time చక్రం ఆధారంగా వాటిని ఖచ్చిత గత సంఘటనగా ప్రకటించరాదు. '
              'కవిప్పు స్ఫుటం లేకపోతే డిగ్రీల ఆధారిత గత నిమిషాలు గణించరు.',
              style:TextStyle(fontSize:11.5,color:Color(0xFF82420D),height:1.4)),
          ]),
        );
      },
    );
  }

  Widget _nimittaDetail(String label,String condition,JamaCheck check) =>
    ListTile(dense:true,
      leading:Icon(switch(check) {
          JamaCheck.yes=>Icons.check_circle_outline,
          JamaCheck.no=>Icons.cancel_outlined,
          JamaCheck.pending=>Icons.help_outline,
        },color:check==JamaCheck.yes?Colors.green:Colors.deepOrange),
      title:Text(label,style:const TextStyle(fontWeight:FontWeight.w700)),
      subtitle:Text('$condition  •  ${_nimittaCheckLabel(check)}'),
    );

  String _nimittaCheckLabel(JamaCheck check) => switch(check) {
    JamaCheck.yes=>'స్థాన షరతు సరిపోయింది',
    JamaCheck.no=>'సరిపోలేదు',
    JamaCheck.pending=>'ధృవీకరణ అవసరం',
  };

  String _nimittaPlanetFacts(JamaNimittaRule rule,
      AstroChartResult chart,JamakolaSpecialResult special) {
    final text=rule.kavippu;
    final facts=<String>[];
    for(final entry in JamaNimitta300Analysis.planetNames.entries){
      if(!text.contains(entry.key))continue;
      final inner=chart.planets.where((p)=>p.name==entry.value).firstOrNull;
      final jama=special.jamaGrahas.where((p)=>p.name==entry.value).firstOrNull;
      facts.add('${entry.key}: జామ ${jama==null?'—':_teSigns[jama.signIndex]}; '
        'ఇన్నర్ ${inner==null?'—':_teSigns[inner.signIndex]}');
    }
    return facts.isEmpty?'ఈ నియమంలో నిర్దిష్ట గ్రహం లేదు.':
      '${facts.join(' • ')}. జామ/ఇన్నర్ ఏది వర్తిస్తుందో మూల సంప్రదాయంతో ధృవీకరించాలి.';
  }

  Widget _selectedChart(AstroChartResult chart,JamakolaSpecialResult special,
      MandiCalculationResult? calculatedMandi, {String? mandiError}){
    final ar=_optionalLongitude(_arudam)??special.arudam;
    final ud=special.udhayam;
    final ch=_optionalLongitude(_chatra);
    final chatraSign=_chatraSign(chart,special);
    final kav=_sourceKavippu(chart,special);
    final sun=chart.planets.where((p)=>p.name=='Sun').firstOrNull;
    final sphutaKav=sun==null?null:
      JamakolaSpecialService.kavippuAbsoluteSphutaCandidate(
        sunLongitude:sun.longitude,udhayam:ud,arudam:ar);
    final rows=<({String key,double? longitude, String label})>[
      (key:'Udayam',longitude:ud,label:'Udayam (జామకోళ)'),
      (key:'Lagna',longitude:chart.ascendantLongitude,label:'సాధారణ లగ్నం'),
      (key:'Arudam',longitude:ar,label:'Arudam'),
      (key:'Chatra',longitude:ch,label:ch==null?'Kavippu (కవిప్పు — ${_teSigns[chatraSign]} రాశి; డిగ్రీ పెండింగ్)':'Kavippu (Manual degree)'),
      (key:'Kavippu',longitude:kav,label:'KAV ప్రతిబింబ డిగ్రీ — పోలిక మాత్రమే'),
      (key:'KavippuSphuta',longitude:sphutaKav,label:'కవిప్పు స్ఫుట నమూనా (U + V − A; పోలిక మాత్రమే)'),
      for(final p in chart.planets)
        (key:p.name,longitude:p.longitude,label:p.name),
      (key:'Mandi',longitude:_optionalLongitude(_mandi)??calculatedMandi?.mandiLongitude,
        label:_optionalLongitude(_mandi)!=null?'Mandi (Manual Override)':'Mandi (Auto · ప్రశ్నమార్గం)'),
      (key:'Yamaghan',longitude:_optionalLongitude(_yamaghan),label:'Yamaghan'),
      for(final j in special.jamaGrahas)
        (key:'Jama ${j.name}',longitude:j.longitude,label:'Jama ${j.name}'),
    ];
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Padding(padding:const EdgeInsets.all(8),child:Wrap(
        alignment:WrapAlignment.spaceBetween,spacing:12,runSpacing:3,
        children:[Text('Day of Week: ${_weekdays[_localMoment.weekday-1]}',
            style:const TextStyle(fontWeight:FontWeight.w600)),
          Text('Hora: ${_hora()}',style:const TextStyle(fontWeight:FontWeight.w600)),
          Text('జామం: ${special.jamam} (${special.isNight?'రాత్రి':'పగలు'})',
            style:const TextStyle(fontWeight:FontWeight.w600))])),
      const Divider(color:Colors.black,thickness:2),
      Row(mainAxisAlignment:MainAxisAlignment.center,children:[
        const Text('House System  ',style:TextStyle(fontWeight:FontWeight.bold)),
        Radio<bool>(value:false,groupValue:_bhava,onChanged:(v)=>setState(()=>_bhava=false)),
        const Text('Sign'),
        Radio<bool>(value:true,groupValue:_bhava,onChanged:(v)=>setState(()=>_bhava=true)),
        const Text('Bhava'),
      ]),
      Container(color:_pink,padding:const EdgeInsets.symmetric(vertical:7,horizontal:8),
        child:Wrap(alignment:WrapAlignment.center,spacing:10,runSpacing:4,
          children:[for(final j in special.jamaGrahas.take(4))
            Text('J:${_short[j.name]??j.name} ${_dms(j.longitude)}',
              style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w700,fontSize:11))])),
      // The same south-Indian 12-rasi layout is shown twice, not merged:
      // TOP is the calculated Jama ring; BOTTOM is ordinary astronomical
      // planets at the question time (not the person's birth-time nativity).
      const Padding(
        padding:EdgeInsets.fromLTRB(8,8,8,5),
        child:Text('పై చక్రం — జామ గ్రహాలు / Jama Grahas',
          style:TextStyle(fontSize:17,fontWeight:FontWeight.w900)),
      ),
      _JamakkolSouthChart(chart:chart,bhava:_bhava,jamaOnly:true,
        lagna:chart.ascendantLongitude,
        udhayam:ud,jamaGrahas:special.jamaGrahas,
        arudam:ar,chatra:ch,chatraSign:chatraSign,
        kavippu:kav,cream:_cream,pink:_pink,
        mandi:_optionalLongitude(_mandi)??calculatedMandi?.mandiLongitude,
        lat:_lat!,lon:_lon!),
      _nowQuestionSummary(chart,special,chatraSign,ch,ar),
      const Padding(
        padding:EdgeInsets.fromLTRB(8,12,8,5),
        child:Text('కింది చక్రం — ఇన్నర్ / ప్రశ్న సమయ గ్రహాలు',
          style:TextStyle(fontSize:17,fontWeight:FontWeight.w900)),
      ),
      _JamakkolSouthChart(chart:chart,bhava:_bhava,jamaOnly:false,
        lagna:chart.ascendantLongitude,
        udhayam:ud,jamaGrahas:special.jamaGrahas,
        arudam:ar,chatra:ch,chatraSign:chatraSign,
        kavippu:kav,cream:_cream,pink:_pink,
        mandi:_optionalLongitude(_mandi)??calculatedMandi?.mandiLongitude,
        lat:_lat!,lon:_lon!),
      const Padding(padding:EdgeInsets.symmetric(horizontal:8,vertical:4),
        child:Text('కింది చక్రంలోని గ్రహాలు ప్రశ్న సమయానికి చెందినవి; జన్మ జాతక గ్రహాలు కావు.',
          style:TextStyle(fontSize:11,color:Colors.black54))),
      _nimittaPanel(chart,special,chatraSign,ch,ar),
      Padding(padding:const EdgeInsets.symmetric(vertical:7,horizontal:5),
        child:Wrap(spacing:10,runSpacing:5,children:[
          const Text('U = ఉదయం  〃',style:TextStyle(fontSize:13,fontWeight:FontWeight.w900,color:Colors.deepPurple)),
          const Text('ARU = ఆరూఢం',style:TextStyle(fontSize:13,fontWeight:FontWeight.w900,color:Colors.deepPurple)),
          const Text('వీథి + ఆరూఢం ఆధారంగా KAV అపసవ్య రాశి',style:TextStyle(fontSize:11)),
          Text('KAV = కవిప్పు: ${_teSigns[chatraSign]}${ch!=null?' (Manual డిగ్రీ)':_kavipuSign!=null?' (Manual రాశి)':' (ప్రాథమిక రాశి గణన)'}',
            style:const TextStyle(color:Color(0xFFBD004D),fontSize:12,fontWeight:FontWeight.bold)),
          const Text('J: = పై చక్రంలోని జామ గ్రహాలు',style:TextStyle(fontSize:12)),
        ])),
      if(_bhava && ch==null) const Padding(
        padding:EdgeInsets.symmetric(vertical:3,horizontal:5),
        child:Text('కవిప్పు రాశి గణించబడింది. ఖచ్చితమైన డిగ్రీ లేనందున Placidus భావంలో KAV స్థానాన్ని ఊహించి చూపించలేదు.',
          style:TextStyle(color:Color(0xFF99384F),fontSize:12))),
      Container(color:_pink,padding:const EdgeInsets.symmetric(vertical:7,horizontal:8),
        child:Wrap(alignment:WrapAlignment.center,spacing:10,runSpacing:4,
          children:[for(final j in special.jamaGrahas.skip(4))
            Text('J:${_short[j.name]??j.name} ${_dms(j.longitude)}',
              style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w700,fontSize:11))])),
      ExpansionTile(
        title:const Text('ఎనిమిది జామ గ్రహాలు — డిగ్రీల పట్టిక',
          style:TextStyle(fontWeight:FontWeight.w800)),
        subtitle:const Text('జామ గ్రహం • పూర్తి longitude • రాశిలో డిగ్రీలు'),
        children:[for(final j in special.jamaGrahas)
          ListTile(
            dense:true,
            title:Text('${_planetTe[j.name]??(j.name=='Snake'?'పాము':j.name)} '
              '— ${_teSigns[j.signIndex]}',
              style:const TextStyle(fontWeight:FontWeight.w700)),
            subtitle:Text('మొత్తం: ${_dms(j.longitude)}  |  '
              'రాశిలో: ${_inSign(j.longitude)}'),
          )],
      ),
      const Padding(padding:EdgeInsets.only(top:4),
        child:Text('పింక్ పట్టీలు = జామ గ్రహాల మొత్తం Longitude. పై చక్రం జామ గ్రహాలు; కింది చక్రం ప్రశ్న సమయ సాధారణ గ్రహాలు.',
          style:TextStyle(fontSize:11,color:Colors.black54))),
      const SizedBox(height:8),
      Text('జామకోళ ఉదయం: ${_longitudeString(ud)}  ·  ' 
        'ఆరూఢం: ${_longitudeString(ar)}  ·  సూర్యోదయం: ${_time(special.sunriseLocal)}  ·  ' 
        'సూర్యాస్తమయం: ${_time(special.sunsetLocal)}',
        style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600)),
      const SizedBox(height:4),
      if(sphutaKav!=null) Padding(
        padding:const EdgeInsets.symmetric(vertical:5,horizontal:4),
        child:Text('ప్రతిపాదిత కవిప్పు స్ఫుటం (U + V − A): '
          '${_longitudeString(sphutaKav)} · మొత్తం ${_dms(sphutaKav)}. '
          'ఇది గణిత పోలిక; పింక్ KAV నియమాలకు స్వయంగా ఆధారం కాదు.',
          style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600,
            color:Colors.deepPurple))),
      if(sun!=null) Text(() {
        final anchor=_veedhiAnchorSign ??
            JamakolaSpecialService.chatraVeedhiSign(sun.longitude);
        final aSign=(ar/30).floor(), uSign=(ud/30).floor();
        final d=(aSign-anchor+12)%12;
        return 'కవిప్పు అపసవ్య రాశి లెక్క: ఆరూఢం ${_teSigns[aSign]} '
            '→ వీథి ${_teSigns[anchor]}: $d రాశుల వెనుకకు; '
            'ఉదయం ${_teSigns[uSign]} నుంచి $d వెనుకకు = '
            '${_teSigns[chatraSign]}. '
            '${_veedhiAnchorSign==null?'సూర్యరాశి వీథి ఆటో':'Manual వీథి యాంకర్'}. '
            'రాశి నిర్ణయం; డిగ్రీ పోలికలు క్రింద ఉన్నాయి.';
      }(),style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600,
          color:Colors.deepPurple)),
      Text(kav==null
          ?'కవిప్పు ప్రతిబింబ డిగ్రీ పోలికకు సూర్యస్థానం అవసరం.'
          :'ప్రతిబింబ డిగ్రీ నమూనా (30° − ఆరూఢం అంశం): '
           '${_longitudeString(kav)} · ఖచ్చిత KAV డిగ్రీగా నిర్ధారించలేదు.',
        style:const TextStyle(fontSize:12,fontWeight:FontWeight.w600,color:Colors.deepOrange)),
      const SizedBox(height:4),
      Text(_bhava?'Bhava: Placidus భావాలు; జామకోళ ఉదయం వేరుగా గుర్తించబడింది.':
        'Sign: లోపలి సాధారణ గ్రహాలు + బయటి జామగ్రహాలు; కవిప్పు (KAV) రాశి పింక్‌లో ఉంటుంది.',
        style:const TextStyle(fontSize:12,color:Colors.black87)),
      const SizedBox(height:8),
      _planetPositionView(rows),
      const SizedBox(height:6),
      if(calculatedMandi!=null) Padding(
        padding:const EdgeInsets.symmetric(vertical:6,horizontal:8),
        child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text('మండీ (Auto): ${_teSigns[calculatedMandi.mandiSignIndex]} · '
            '${_longitudeString(calculatedMandi.mandiLongitude)} · '
            'మొత్తం ${_dms(calculatedMandi.mandiLongitude)}',
            style:const TextStyle(fontWeight:FontWeight.w700)),
          Text('గుళిక (శని భాగం ప్రారంభం): '
            '${_longitudeString(calculatedMandi.gulikaLongitude)} · '
            'భాగం ముగింపు: ${_longitudeString(calculatedMandi.gulikaEndLongitude)}',
            style:const TextStyle(fontSize:12)),
          const Text('మండీ, గుళిక వేర్వేరు సంప్రదాయ గణన ప్రమాణాలు. '
            'Manual Override ఉంటే పట్టికలో దానికే ప్రాధాన్యం.',
            style:TextStyle(fontSize:11,color:Colors.black54)),
        ])),
      if(mandiError!=null) Padding(
        padding:const EdgeInsets.symmetric(vertical:5,horizontal:8),
        child:Text('మండీ ఆటో గణన సాధ్యం కాలేదు: $mandiError',
          style:const TextStyle(color:Colors.deepOrange,fontSize:12))),
      const SizedBox(height:14),
      _confirmation(chart,special),
      const SizedBox(height:10),
      _rulesPanel(chart,special),
    ]);
  }

  // On phones the planetary data is not hidden behind a wide table.
  // The full original five-column table is still available on demand.
  Widget _planetPositionView(
      List<({String key, double? longitude, String label})> rows) {
    return LayoutBuilder(builder:(context, constraints) {
      final compact = constraints.maxWidth < 620;
      final fullTable = !compact || _showWideTableOnMobile;
      return Column(crossAxisAlignment:CrossAxisAlignment.stretch, children:[
        Row(children:[
          const Expanded(child:Text('గ్రహస్థితులు',
            style:TextStyle(fontSize:17,fontWeight:FontWeight.bold))),
          if(compact) TextButton.icon(
            onPressed:()=>setState(
              ()=>_showWideTableOnMobile=!_showWideTableOnMobile),
            icon:Icon(fullTable?Icons.view_agenda_outlined:Icons.table_chart_outlined,
              size:18),
            label:Text(fullTable?'మొబైల్ వీక్షణ':'పూర్తి పట్టిక'),
          ),
        ]),
        const SizedBox(height:5),
        if(compact && !fullTable)
          ...rows.map((r) {
            final longitude=r.longitude;
            final nakshatra=longitude==null?null:
              VedicCalculationService.nakshatra(longitude);
            final star=nakshatra==null?'—':
              VedicCalculationService.nakshatraNamesTe[nakshatra.index];
            final pada=nakshatra==null?'—':'${nakshatra.pada}';
            return Container(
              margin:const EdgeInsets.only(bottom:5),
              padding:const EdgeInsets.symmetric(horizontal:10,vertical:8),
              decoration:BoxDecoration(
                color:_cream,
                border:Border.all(color:Colors.black26),
                borderRadius:BorderRadius.circular(6)),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text(r.label,style:const TextStyle(
                  fontWeight:FontWeight.bold,fontSize:14)),
                const SizedBox(height:3),
                Wrap(spacing:12,runSpacing:3,children:[
                  Text('స్థానం: ${longitude==null?'పెండింగ్':_longitudeString(longitude)}',
                    style:const TextStyle(fontSize:12)),
                  Text('నక్షత్రం: $star · పాదం: $pada',
                    style:const TextStyle(fontSize:12)),
                  Text('మొత్తం డిగ్రీలు: ${longitude==null?'—':_dms(longitude)}',
                    style:const TextStyle(fontSize:12)),
                ]),
              ]),
            );
          }),
        if(fullTable) ...[
          if(compact)const Padding(
            padding:EdgeInsets.only(bottom:5),
            child:Text('గ్రహం పేరు ఎడమవైపు స్థిరంగా ఉంటుంది; మిగతా వివరాలకు కుడి/ఎడమ జరపండి ↔',
              style:TextStyle(fontSize:12,color:Colors.black54))),
          if(compact) _mobileFrozenPlanetTable(rows,constraints.maxWidth)
          else SingleChildScrollView(
            scrollDirection:Axis.horizontal,
            child:DataTable(
              headingRowColor:WidgetStateProperty.all(const Color(0xFFFFA000)),
              border:TableBorder.all(color:Colors.black87,width:1),
              columnSpacing:14,horizontalMargin:10,
              dataRowMinHeight:44,dataRowMaxHeight:55,
              columns:const [
                DataColumn(label:Text('Planets')),
                DataColumn(label:Text('Longitude')),
                DataColumn(label:Text('Degrees')),
                DataColumn(label:Text('Star')),
                DataColumn(label:Text('Pada')),
              ],
              rows:[for(final r in rows)
                DataRow(cells:[
                  DataCell(Text(r.label,
                    style:const TextStyle(fontWeight:FontWeight.w600))),
                  DataCell(Text(r.longitude==null?'పెండింగ్':
                    _longitudeString(r.longitude!))),
                  DataCell(Text(r.longitude==null?'—':_dms(r.longitude!))),
                  DataCell(Text(r.longitude==null?'—':
                    VedicCalculationService.nakshatraNamesTe[
                      VedicCalculationService.nakshatra(r.longitude!).index])),
                  DataCell(Text(r.longitude==null?'—':
                    '${VedicCalculationService.nakshatra(r.longitude!).pada}')),
                ]),
              ],
            ),
          ),
        ],
      ]);
    });
  }

  // Full table on a phone keeps the planet name visible at all times.
  // Only longitude/degrees/star/pada scroll horizontally; row heights match.
  Widget _mobileFrozenPlanetTable(
    List<({String key, double? longitude, String label})> rows,
    double availableWidth,
  ) {
    const rowHeight=62.0;
    const headerHeight=54.0;
    final frozenWidth=(availableWidth*0.31).clamp(104.0,150.0).toDouble();
    const orange=Color(0xFFFFA000);
    Widget cell(String value,double width,{bool header=false,bool fixed=false}) =>
      Container(width:width,height:header?headerHeight:rowHeight,
        padding:const EdgeInsets.symmetric(horizontal:8,vertical:5),
        alignment:Alignment.centerLeft,
        decoration:BoxDecoration(
          color:header?orange:(fixed?_cream:null),
          border:Border.all(color:Colors.black87,width:0.65)),
        child:Text(value,maxLines:3,overflow:TextOverflow.ellipsis,
          style:TextStyle(fontSize:header?13:12,
            fontWeight:header||fixed?FontWeight.w700:FontWeight.w400)));
    String shortLabel(({String key,double? longitude,String label}) r){
      if(r.key=='Chatra')return 'కవిప్పు (KAV)';
      if(r.key=='Kavippu')return 'GK Veedhi (వేరు)';
      if(r.key=='Lagna')return 'సాధారణ లగ్నం';
      if(r.key.startsWith('Jama ')) {
        final planet=r.key.substring(5);
        return 'జామ ${_planetTe[planet]??(planet=='Snake'?'పాము':planet)}';
      }
      return r.label;
    }
    return Container(decoration:BoxDecoration(border:Border.all(
      color:Colors.black87,width:0.65)),child:Row(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        // The planet-name column does not participate in horizontal scrolling.
        Column(children:[
          cell('Planets',frozenWidth,header:true),
          for(final r in rows) cell(shortLabel(r),frozenWidth,fixed:true),
        ]),
        Expanded(child:SingleChildScrollView(scrollDirection:Axis.horizontal,
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Row(children:[
              cell('Longitude',150,header:true),
              cell('Degrees',137,header:true),
              cell('Star',114,header:true),
              cell('Pada',57,header:true),
            ]),
            for(final r in rows) Row(children:[
              cell(r.longitude==null?'పెండింగ్':_longitudeString(r.longitude!),150),
              cell(r.longitude==null?'—':_dms(r.longitude!),137),
              cell(r.longitude==null?'—':
                VedicCalculationService.nakshatraNamesTe[
                  VedicCalculationService.nakshatra(r.longitude!).index],114),
              cell(r.longitude==null?'—':
                '${VedicCalculationService.nakshatra(r.longitude!).pada}',57),
            ]),
          ]))),
      ],
    ));
  }

  static const _signLords=<String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  static const _exaltation=<String,int>{
    'Sun':0,'Moon':1,'Mars':9,'Mercury':5,
    'Jupiter':3,'Venus':11,'Saturn':6,
  };
  static String _showNames(Iterable<String> keys) {
    final items=keys.map((x)=>_planetTe[x]??(x=='Snake'?'పాము':x)).toList();
    return items.isEmpty?'లేవు':items.join(', ');
  }
  static String _exchanges(Map<String,int> p) {
    final pairs=<String>[];
    final names=p.keys.where((e)=>_exaltation.containsKey(e)).toList();
    for(var i=0;i<names.length;i++) {
      for(var j=i+1;j<names.length;j++) {
        final a=names[i],b=names[j];
        if(_signLords[p[a]!] == b && _signLords[p[b]!] == a) {
          pairs.add('${_planetTe[a]}–${_planetTe[b]}');
        }
      }
    }
    return pairs.isEmpty?'లేవు':pairs.join(', ');
  }

  Widget _confirmation(AstroChartResult chart,JamakolaSpecialResult special) {
    final u=(special.udhayam/30).floor();
    final a=(_optionalLongitude(_arudam)??special.arudam);
    final c=_optionalLongitude(_chatra);
    final cSign=_chatraSign(chart,special);
    final kav=_sourceKavippu(chart,special);
    final inMap=<String,int>{for(final p in chart.planets)p.name:p.signIndex};
    final jamaMap=<String,int>{for(final p in special.jamaGrahas)p.name:p.signIndex};
    final exIn=inMap.entries.where((e)=>_exaltation[e.key]==e.value).map((e)=>e.key);
    final debIn=inMap.entries.where((e)=>_exaltation[e.key]!=null &&
      (_exaltation[e.key]!+6)%12==e.value).map((e)=>e.key);
    final exJama=jamaMap.entries.where((e)=>_exaltation[e.key]==e.value).map((e)=>e.key);
    final debJama=jamaMap.entries.where((e)=>_exaltation[e.key]!=null &&
      (_exaltation[e.key]!+6)%12==e.value).map((e)=>e.key);
    final pastContacts=special.jamaContacts
      .where((c)=>c.minutesFromJudgement<=0).toList();
    final futureContacts=special.jamaContacts
      .where((c)=>c.minutesFromJudgement>0).toList();
    String displayContacts(List<JamaUdayaContact> contacts) => contacts.isEmpty
      ?'ప్రస్తుత సౌర జామ సరిహద్దులో (గరిష్టంగా 30 ని) కోణ-సంపర్కం లేదు'
      :contacts.map((c)=>
          '${_showNames([c.planet])} (${c.minutesFromJudgement.abs().toStringAsFixed(1)} నిమి)').join(', ');
    final coincident=inMap.entries.where((entry)=>jamaMap[entry.key]==entry.value).map((e)=>e.key);
    final tenthLord=_signLords[(u+9)%12];
    final tenthPosition=inMap[tenthLord];
    final values=<String,String>{
      'Jama Planet Crossed Udaya':displayContacts(pastContacts),
      'Jama Planet approaching Udaya':displayContacts(futureContacts),
      'Inner Planets in Udaya':_showNames(inMap.entries.where((x)=>x.value==u).map((e)=>e.key)),
      'Udaya to Aruda bhava connection':'${((a/30).floor()-u+12)%12+1}వ భావం (ఆటో/Manual)',
      'Udaya to Kavippu bhava connection':'${(cSign-u+12)%12+1}వ రాశి-దూరం (${_teSigns[cSign]}; ${c!=null?'Manual degree':_kavipuSign!=null?'Manual రాశి':'ప్రాథమిక Auto రాశి'}; ఖచ్చితమైన భావం వేరు)',
      'Exalted Inner Planets':_showNames(exIn),
      'Exalted Jama Planets':_showNames(exJama),
      'Debilitated Inner Planets':_showNames(debIn),
      'Debilitated Jama Planets':_showNames(debJama),
      'Same Inner and Jama Planet':_showNames(coincident),
      '10th Lord bhava connections':tenthPosition==null?'గ్రహం లేదు':
        '${_showNames([tenthLord])}: ${(tenthPosition-u+12)%12+1}వ భావం',
      'Inner Planets Parivarthana':_exchanges(inMap),
      'Jama Planets Parivarthana':_exchanges(jamaMap),
    };
    return ExpansionTile(initiallyExpanded:true,
      title:const Text('Prashna Confirmation Section',
        style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),
      subtitle:const Text('ఉదయం–జామ గ్రహాల గత/తదుపరి 30 నిమిషాల కోణ-సంపర్కాలు మాత్రమే; సంప్రదాయ ఫలిత నిర్ధారణ కాదు. పింక్ KAV పేరు మీ అమరిక ప్రకారం.'),
      children:[
        ListTile(
          title:const Text('KAV ప్రతిబింబ డిగ్రీ — తులనాత్మక పద్ధతి'),
          subtitle:Text(kav==null
            ? 'సూర్య వీథి రాశి అందుబాటులో లేదు'
            : '${_longitudeString(kav)} · ఉదయం నుంచి ${((kav/30).floor()-u+12)%12+1}వ రాశి-దూరం · ఇది ధృవీకరించిన ఖచ్చిత స్ఫుటం కాదు'),
        ),
        for(final label in _confirmationFields)
          Padding(padding:const EdgeInsets.symmetric(vertical:5,horizontal:8),
            child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Expanded(flex:5,child:Text(label)),
              Expanded(flex:3,child:Text(values[label]??'మూల గణన ధృవీకరణ అవసరం',
                style:TextStyle(color:values.containsKey(label)
                  ?Colors.teal.shade700:Colors.grey.shade700))),
            ])),
      ]);
  }

  Widget _manualInputs(){
    return ExpansionTile(title:const Text('Arudam · Kavippu · Mandi Override · Yamaghan — Verification',
      style:TextStyle(fontSize:14,fontWeight:FontWeight.w700)),
      subtitle:const Text('మండీ ఆటో గణన ఉంది; అవసరమైతే Manual Override. యమఘంటం ఇంకా Manual.'),
      children:[
        const Padding(padding:EdgeInsets.symmetric(vertical:5),child:Text(
          '0–360° Longitude Override అవసరమైతే మాత్రమే నమోదు చేయండి. ఆరూఢం గడియార సమయంతో, మండీ ప్రశ్న స్థానపు సూర్యోదయం–సూర్యాస్తమయం నుంచి ఆటోమేటిక్‌గా గణిస్తాయి. కవిప్పు ఖచ్చిత డిగ్రీ ధృవీకరించినప్పుడు మాత్రమే Override ఇవ్వండి. యమఘంటం ఇంకా Manual.',
          style:TextStyle(fontSize:12))),
        _input(_arudam,'Arudam Override (optional)',numeric:true,onChanged:(_)=>setState((){})),
        const SizedBox(height:8),
        DropdownButtonFormField<int>(
          value:_veedhiAnchorSign,isExpanded:true,
          decoration:const InputDecoration(
            labelText:'సూర్యవీధి Anchor (ఐచ్ఛిక Override)',
            border:OutlineInputBorder()),
          hint:const Text('ఆటో సూర్యవీధి (మార్చనవసరం లేదు)'),
          items:[for(var i=0;i<12;i++)
            DropdownMenuItem(value:i,child:Text(_teSigns[i]))],
          onChanged:(v)=>setState(()=>_veedhiAnchorSign=v),
        ),
        const Padding(padding:EdgeInsets.all(6),child:Text(
          'సూర్యుడి రాశి నుంచి వీథి ఆటోమేటిక్‌గా వస్తుంది. ప్రధాన పింక్ KAV రాశిని అపసవ్య దూరంతో నిర్ణయిస్తాం. ప్రతిబింబ డిగ్రీ, సంపూర్ణ స్ఫుటం రెండు పోలిక పద్ధతులు; ఖచ్చిత ఫలితాలుగా వాడం.',
          style:TextStyle(fontSize:12,color:Colors.deepOrange))),
        const SizedBox(height:8),
        _input(_chatra,'Kavippu exact longitude (optional manual override)',numeric:true,onChanged:(_)=>setState((){})),
        const SizedBox(height:8),
        _input(_mandi,'Mandi Override (optional · 0–360°)',numeric:true,onChanged:(_)=>setState((){})),
        const SizedBox(height:8),
        _input(_yamaghan,'Yamaghan total degrees',numeric:true,onChanged:(_)=>setState((){})),
        const SizedBox(height:8),
        DropdownButtonFormField<int>(value:_kavipuSign,isExpanded:true,
          decoration:const InputDecoration(labelText:'కవిప్పు రాశి (Manual)',
            border:OutlineInputBorder()),
          items:[for(var i=0;i<12;i++)DropdownMenuItem(value:i,child:Text(_teSigns[i]))],
          onChanged:(v)=>setState(()=>_kavipuSign=v)),
        const SizedBox(height:8),
        DropdownButtonFormField<String>(value:_approaching,isExpanded:true,
          decoration:const InputDecoration(labelText:'ఉదయాన్ని సమీపించే గ్రహం (Manual)',
            border:OutlineInputBorder()),
          items:[for(final e in _planetTe.entries)
            DropdownMenuItem(value:e.key,child:Text(e.value))],
          onChanged:(v)=>setState(()=>_approaching=v)),
        const SizedBox(height:8),
        DropdownButtonFormField<String>(value:_gowri,isExpanded:true,
          decoration:const InputDecoration(labelText:'గౌరీ కాలం (Manual)',
            border:OutlineInputBorder()),
          items:const [
            DropdownMenuItem(value:'Uthiyogam',child:Text('ఉద్యోగం')),
            DropdownMenuItem(value:'Amirtham',child:Text('అమృతం')),
            DropdownMenuItem(value:'Rogam',child:Text('రోగం')),
            DropdownMenuItem(value:'Laabam',child:Text('లాభం')),
            DropdownMenuItem(value:'Dhanam',child:Text('ధనం')),
            DropdownMenuItem(value:'Shubam',child:Text('శుభం')),
            DropdownMenuItem(value:'Choram',child:Text('చోరం')),
            DropdownMenuItem(value:'Visham',child:Text('విషం')),
          ],onChanged:(v)=>setState(()=>_gowri=v)),
        const SizedBox(height:12),
      ]);
  }

  static const _jamaTopics=<String,String>{
    'all':'అన్ని అంశాలు',
    'marriage':'వివాహం / దాంపత్యం',
    'career_business':'ఉద్యోగం / వ్యాపారం',
    'education':'విద్య',
    'childbirth':'సంతానం',
    'obstruction':'ఆటంకాలు / అడ్డంకులు',
    'gowri':'గౌరీ / కాల పరిశీలన',
    'question_subject':'ప్రశ్న అంశం / కారకత్వం',
    'wealth':'ధనం (పూర్తి మూల నియమాలు పెండింగ్)',
    'property':'ఆస్తి (పూర్తి మూల నియమాలు పెండింగ్)',
    'foreign':'విదేశం (పూర్తి మూల నియమాలు పెండింగ్)',
    'health':'ఆరోగ్యం (పూర్తి మూల నియమాలు పెండింగ్)',
  };

  // These are *question-identification* indicators from the source rulebook,
  // not standalone success/failure predictions. Match them by rule ID rather
  // than keyword-guessing from the Telugu result text.
  static const _topicEvidenceIds=<String,List<String>>{
    'marriage':['JA-ARU-H07','JA-APP-VENUS'],
    'career_business':['JA-ARU-H10','JA-ARU-H11','JA-APP-SATURN','JA-APP-MERCURY'],
    'education':['JA-ARU-H05','JA-APP-MERCURY','JA-APP-JUPITER'],
    'childbirth':['JA-ARU-H05','JA-APP-JUPITER'],
    'obstruction':['JA-ARU-H06','JA-ARU-H08'],
    'wealth':['JA-ARU-H02','JA-ARU-H11'],
    'property':['JA-ARU-H04','JA-APP-MARS'],
    'foreign':['JA-ARU-H09','JA-ARU-H12','JA-APP-RAHU'],
    'health':['JA-ARU-H01','JA-ARU-H06'],
  };

  static const _jamaFactLabels=<String,String>{
    'kavipu_house_from_udhayam':'కవిప్పు స్థానం (ఉదయం నుంచి రాశి-దూరం)',
    'arudam_house_from_udhayam':'ఆరూఢం స్థానం (ఉదయం నుంచి రాశి-దూరం)',
    'approaching_udhayam':'ఉదయాన్ని సమీపించే జామ గ్రహం',
    'saturn_dignity':'శని ఉచ్చ / నీచ స్థితి',
    'gowri_period':'గౌరీ కాలం',
  };

  Widget _rulesPanel(AstroChartResult chart,JamakolaSpecialResult special) {
    final facts=<String,dynamic>{};
    // Do not equate instantaneous angle proximity with actual approach/crossing.
    // A unique upcoming *geometric* contact can aid filtering, but it is not
    // equivalent to a source-verified traditional 'approaching' judgement.
    final futureContactPlanets=special.jamaContacts
      .where((c)=>c.minutesFromJudgement>0)
      .map((c)=>c.planet).toSet();
    final autoApproaching=_approaching==null && futureContactPlanets.length==1;
    if(_approaching!=null) {
      facts['approaching_udhayam']=_approaching;
    } else if(autoApproaching) {
      facts['approaching_udhayam']=futureContactPlanets.single;
    }
    if(_gowri!=null)facts['gowri_period']=_gowri;
    final a=(_optionalLongitude(_arudam)??special.arudam)/30;
    final u=(special.udhayam/30).floor();
    facts['arudam_house_from_udhayam']=(a.floor()-u+12)%12+1;
    // The displayed pink KAV and the rule engine MUST read the same sign.
    // This primary automatic Chatra-rasi transfer has NOT been validated as
    // GK's exact Kavippu; its rule outcomes remain provisional.
    final kavSign=_chatraSign(chart,special);
    final manualKavipu=_optionalLongitude(_chatra)!=null ||
      _kavipuSign!=null;
    facts['kavipu_house_from_udhayam']=
      JamakolaRuleEngine.houseFromSigns(u,kavSign)!;
    final saturn=chart.planets.where((p)=>p.name=='Saturn').firstOrNull;
    if(saturn?.signIndex==6)facts['saturn_dignity']='exalted';
    if(saturn?.signIndex==0)facts['saturn_dignity']='debilitated';
    return FutureBuilder<List<JamakolaRule>>(future:_ruleFuture,
      builder:(context,snapshot) {
        if(snapshot.hasError)return Text('నియమాల డేటా లభించలేదు: ${snapshot.error}');
        if(!snapshot.hasData)return const LinearProgressIndicator();
        final filtered=snapshot.data!.where((r)=>_selectedJamaModule=='all' ||
          r.module==_selectedJamaModule).toList();
        // Question-subject indicators identify a relevant bhava/graha only;
        // they must not count as an affirmative prashna verdict, nor should
        // the other eleven houses be shown as adverse predictions.
        final indicatorIds=_topicEvidenceIds[_selectedJamaModule];
        final indicators=JamakolaRuleEngine.matchingIndicators(
          snapshot.data!, facts,
          allowedIds:(_selectedJamaModule=='all' ||
            _selectedJamaModule=='question_subject')
              ?null:(indicatorIds?.toSet()??<String>{}));
        final complete=<JamakolaRule>[],failed=<JamakolaRule>[],
          provisional=<JamakolaRule>[], provisionalFailed=<JamakolaRule>[],
          pending=<JamakolaRule>[];
        for(final r in filtered){
          if(JamakolaRuleEngine.isSubjectIndicator(r)) continue;
          if(r.conditions.keys.any((k)=>!facts.containsKey(k))) {
            pending.add(r);
            continue;
          }
          // The user-requested pink point is only a preliminary transfer
          // until manually verified against a complete primary source.
          final unverifiedKav=r.conditions.containsKey(
            'kavipu_house_from_udhayam') && !manualKavipu;
          final unverifiedContact=r.conditions.containsKey(
            'approaching_udhayam') && autoApproaching;
          final matched=JamakolaRuleEngine.matches(r,facts);
          if(unverifiedKav || unverifiedContact) {
            (matched?provisional:provisionalFailed).add(r);
          } else {
            (matched?complete:failed).add(r);
          }
        }
        return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          const SizedBox(height:6),
          const Text('జామకోళ — అంశాలవారీ ప్రశ్న పరిశీలన',
            style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)),
          const SizedBox(height:7),
          SingleChildScrollView(scrollDirection:Axis.horizontal,
            child:Row(children:[for(final topic in _jamaTopics.entries.take(8))
              Padding(padding:const EdgeInsets.only(right:5),
                child:ChoiceChip(label:Text(topic.value),
                  selected:_selectedJamaModule==topic.key,
                  onSelected:(_)=>setState(()=>_selectedJamaModule=topic.key))),
            ])),
          const SizedBox(height:7),
          DropdownButtonFormField<String>(
            value:_selectedJamaModule,
            isExpanded:true,
            decoration:const InputDecoration(
              labelText:'ప్రశ్న అంశం ఎంచుకోండి',border:OutlineInputBorder()),
            items:[for(final e in _jamaTopics.entries)
              DropdownMenuItem<String>(value:e.key,child:Text(e.value,
                overflow:TextOverflow.ellipsis))],
            onChanged:(v){if(v!=null)setState(()=>_selectedJamaModule=v);},
          ),
          if(filtered.isEmpty)const Padding(
            padding:EdgeInsets.symmetric(vertical:10),
            child:Text('ఈ అంశానికి ప్రత్యేక IF–THEN నిర్ణయ నియమాలు ఇంకా లేవు. '
              'కింద కనిపించే భావ/గ్రహ సూచనలు కారకత్వ ఆధారాలు మాత్రమే; '
              'వాటితో శుభం/అశుభం లేదా సంఘటన సమయాన్ని నిర్ణయించలేం.',
              style:TextStyle(color:Colors.deepOrange)),
          ),
          if(_selectedJamaModule=='childbirth') const Padding(
            padding:EdgeInsets.symmetric(vertical:7),
            child:Text('సంతానం విభాగంలో ప్రస్తుతం ఒక ప్రత్యేక మూల నియమమే ఉంది. '
              'ఆ ఒక్క నియమం వర్తించకపోవడం సంతానం లేదనే తీర్పు కాదు. '
              'KP / Tajik ఆధారాల పూర్తి పరిశీలన ఇంకా అవసరం.',
              style:TextStyle(color:Colors.deepOrange,fontSize:12.5)),
          ),
          if(indicators.isNotEmpty) ExpansionTile(
            initiallyExpanded:true,
            title:Text('ప్రశ్నకు సంబంధించిన భావ/గ్రహ సూచనలు (${indicators.length})',
              style:const TextStyle(fontWeight:FontWeight.bold)),
            subtitle:const Text('ఇవి ప్రశ్న కారకత్వాన్ని గుర్తించే సూచనలు మాత్రమే; '
              'Yes/No తీర్పు లేదా శుభ/అశుభ నిర్ధారణ కాదు.'),
            children:[for(final r in indicators)
              ListTile(
                leading:const Icon(Icons.info_outline,color:Colors.indigo),
                title:Text(r.result),
                subtitle:Text('${r.id} · ${r.sourceFile} · పేజీ ${r.sourcePage} '
                  '· ${r.conditions.keys.any((k)=>k=='approaching_udhayam') && autoApproaching?'ప్రాథమిక కోణ-సంపర్కం':'భావ/గ్రహ కారకత్వం'}'),
              ),
            ],
          ),
          if(_selectedJamaModule=='question_subject' && indicators.isEmpty)
            const Text('ప్రస్తుతం సంబంధిత భావ/గ్రహ సూచికలు గుర్తించబడలేదు. '
              'ఇది ప్రశ్నకు ప్రతికూల ఫలితం కాదు.',
              style:TextStyle(fontSize:12.5,color:Colors.black54)),
          if(_selectedJamaModule=='question_subject' &&
              !facts.containsKey('approaching_udhayam'))
            const Padding(padding:EdgeInsets.symmetric(vertical:5),
              child:Text('సమీపించే జామ గ్రహం ధృవీకరించబడలేదు. '
                'ఆ గ్రహానికి సంబంధించిన ఎనిమిది ప్రత్యామ్నాయ కారకత్వ నియమాలను '
                'తుది ఫలితంగా పరిగణించడం లేదు.',
                style:TextStyle(fontSize:12,color:Colors.deepOrange))),
          Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Text(
            'పింక్ KAV: ${_teSigns[kavSign]} · ఉదయం నుంచి ${facts['kavipu_house_from_udhayam']}వ రాశి-దూరం '
            '(${manualKavipu?'మాన్యువల్ స్థానం':'ప్రాథమిక ఆటో రాశి — GK మూల సూత్ర ధృవీకరణ అవసరం'})',
            style:TextStyle(fontSize:12.5,fontWeight:FontWeight.w600,
              color:manualKavipu?Colors.teal.shade800:Colors.deepOrange))),
          if(autoApproaching) Padding(
            padding:const EdgeInsets.only(bottom:7),child:Text(
              'ఉదయాన్ని సమీపించే జామ గ్రహం: '
              '${_planetTe[futureContactPlanets.single]??futureContactPlanets.single} '
              '(గణిత సంపర్కం ఆధారంగా ప్రాథమిక పరిశీలన మాత్రమే)',
              style:const TextStyle(color:Colors.deepOrange,fontSize:12.5))),
          ExpansionTile(title:Text(
          'అంశానికి వర్తించిన IF–THEN నియమాలు: ${complete.length} · '
          'ప్రాథమికం ${provisional.length} · ఆధారం అవసరం ${pending.length}'),
          subtitle:Text('వర్తించని ప్రత్యామ్నాయ నియమాలు '
            '${failed.length+provisionalFailed.length} · '
            'వర్తించకపోవడం ప్రతికూల ఫలితం కాదు; మూడు పద్ధతుల ఉమ్మడి తీర్పు ఇంకా అందుబాటులో లేదు.'),
          children:[
            if(complete.isEmpty && provisional.isEmpty)
              const Padding(padding:EdgeInsets.all(10),child:Text(
                'ఈ అంశానికి నిర్ధారించిన IF–THEN ఫలితం ఇంకా లేదు. '
                'వర్తించని నియమాన్ని నిరాకరణ/అపజయంగా భావించరాదు.',
                style:TextStyle(color:Colors.deepOrange))),
            for(final r in complete)
              ExpansionTile(
                leading:const Icon(Icons.check_circle_outline,color:Colors.green),
                title:Text(r.result,style:const TextStyle(color:Color(0xFF176B3A),
                  fontWeight:FontWeight.w800)),
                children:[
                  ListTile(title:const Text('పరిశీలన'),
                    subtitle:Text('మూల షరతులు గణనలో సరిపోయాయి: '
                      '${r.conditions.entries.map((e)=>'${e.key}=${e.value}').join('; ')}')),
                  ListTile(title:const Text('మూల నియమం'),
                    subtitle:Text('${r.id} · ${r.sourceFile} · పేజీ ${r.sourcePage}')),
                  const ListTile(title:Text('పరిహారం'),
                    subtitle:Text('ఈ నియమానికి మూలాధార పరిహారం అందుబాటులో లేదు.')),
                  const Padding(padding:EdgeInsets.all(8),child:Text(
                    'ఇది జామకోళ సంప్రదాయ సూచన మాత్రమే; ఖచ్చిత సంఘటన హామీ కాదు.',
                    style:TextStyle(fontSize:11.5))),
                ]),
            if(provisional.isNotEmpty) ExpansionTile(
              title:Text('ప్రాథమికంగా సరిపోయిన నియమాలు (${provisional.length})',
                style:const TextStyle(color:Colors.deepOrange,
                  fontWeight:FontWeight.bold)),
              subtitle:const Text('ప్రాథమిక KAV రాశి / గణిత జామ-ఉదయ సంపర్కం ఆధారం మాత్రమే; సంప్రదాయ నిర్ణయం కాదు.'),
              children:[for(final r in provisional)
                ExpansionTile(
                  leading:const Icon(Icons.info_outline,color:Colors.deepOrange),
                  title:Text(r.result,style:const TextStyle(
                    color:Colors.deepOrange,fontWeight:FontWeight.w700)),
                  children:[
                    ListTile(title:const Text('పరిశీలన'),
                      subtitle:Text('ప్రాథమిక గణన ఆధారంగా '
                        '${r.conditions.entries.map((e)=>'${e.key}=${e.value}').join('; ')} '
                        'సరిపోతుంది. GK/సంప్రదాయ ధృవీకరణకు లోబడి ఉంటుంది.')),
                    ListTile(title:const Text('మూల నియమం'),
                      subtitle:Text('${r.id} · ${r.sourceFile} · పేజీ ${r.sourcePage}')),
                    const ListTile(title:Text('పరిహారం'),
                      subtitle:Text('ఈ మూల నియమానికి నిర్ధారించిన పరిహారం లేదు; ఊహించి చూపించలేదు.')),
                  ]),
              ]),
            if(provisionalFailed.isNotEmpty || failed.isNotEmpty)
              ExpansionTile(
                title:Text('ప్రస్తుతం వర్తించని ప్రత్యామ్నాయ నియమాలు '
                  '(${provisionalFailed.length+failed.length})'),
                subtitle:const Text('ఇవి వేరే రాశి/గ్రహ షరతులకు చెందినవి. '
                  '❌ లేదా ప్రతికూల సంఘటనగా చూపడం లేదు.'),
                children:[
                  for(final r in [...provisionalFailed,...failed])
                    ListTile(
                      leading:const Icon(Icons.remove_circle_outline,
                        color:Colors.blueGrey),
                      title:Text(r.result),
                      subtitle:Text('${r.id} · అవసరమైన షరతు ఈ చక్రంలో లేదు; '
                        'ఇది ప్రతికూల ఫలితం కాదు.'),
                    ),
                ],
              ),
            if (pending.isNotEmpty) ExpansionTile(
              title:Text('ధృవీకరణకు కావలసిన ఆధారాలు (${pending.length} నియమాలు)'),
              subtitle:Text('పరిశీలనలో లేని షరతులు: '
                '${pending.expand((r)=>r.conditions.keys.where((k)=>!facts.containsKey(k))).toSet().map((k)=>_jamaFactLabels[k]??k).join(', ')}. '
                'ఒకే సమాచారం అవసరమైన ఎనిమిది నియమాలు ఎనిమిది వేర్వేరు లోపాలు కావు.'),
              children:[
                if(pending.any((r)=>r.conditions.containsKey('approaching_udhayam')) &&
                   !facts.containsKey('approaching_udhayam'))
                  Padding(padding:const EdgeInsets.all(8),
                    child:DropdownButtonFormField<String>(
                      value:_approaching,
                      hint:const Text('తెలియదు — ఆధారం పెండింగ్'),
                      decoration:const InputDecoration(
                        labelText:'సంప్రదాయంగా నిర్ధారించిన సమీపించే జామ గ్రహం',
                        helperText:'తెలియకపోతే పెండింగ్‌లో ఉంచండి; కోణ-సంపర్కమే ప్రమాణం కాదు.',
                        border:OutlineInputBorder()),
                      items:[
                        const DropdownMenuItem<String>(value:'',
                          child:Text('తెలియదు — పెండింగ్‌లో ఉంచండి')),
                        for(final e in _planetTe.entries)
                          DropdownMenuItem<String>(value:e.key,child:Text(e.value)),
                      ],
                      onChanged:(v)=>setState(()=>_approaching=(v==null||v.isEmpty)?null:v),
                    ),
                  ),
                for(final r in pending)
                  ListTile(title:Text(r.id),
                    subtitle:Text('అవసరమైనవి: '
                      '${r.conditions.keys.where((k)=>!facts.containsKey(k)).map((k)=>_jamaFactLabels[k]??k).join(', ')}')),
              ],
            ),
            const Padding(padding:EdgeInsets.all(8),child:Text(
              'నియమం మ్యాచ్ అయ్యిందంటే సాంప్రదాయ సూచన మాత్రమే. సంఘటన ధృవీకరణ లేదా శాస్త్రీయ సంభావ్యత శాతం కాదు.',
              style:TextStyle(fontSize:12))),
          ]),
        ]);
      });
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      _top(),
      if(_stale) const Card(child:Padding(padding:EdgeInsets.all(12),
        child:Text('ఇన్‌పుట్ మార్చారు. కొత్త చక్రం కోసం “చక్రం గణించండి” నొక్కండి.',
          style:TextStyle(color:Colors.deepOrange)))),
      if(!_stale) FutureBuilder<AstroChartResult>(future:_chartFuture,
        builder:(context,snapshot) {
          if(snapshot.hasError) return Padding(padding:const EdgeInsets.all(12),
            child:Text('గణన అందుబాటులో లేదు: ${snapshot.error}',
              style:const TextStyle(color:Colors.red)));
          if(!snapshot.hasData)return const Padding(
            padding:EdgeInsets.all(14),child:LinearProgressIndicator());
          return FutureBuilder<JamakolaSpecialResult>(future:_specialFuture,
            builder:(context,special){
              if(special.hasError)return Padding(padding:const EdgeInsets.all(12),
                child:Text('జామకోళ ప్రత్యేక గణన సమస్య: ${special.error}',
                  style:const TextStyle(color:Colors.red)));
              if(!special.hasData)return const LinearProgressIndicator();
              return FutureBuilder<MandiCalculationResult>(future:_mandiFuture,
                builder:(context,mandi) {
                  if(!mandi.hasData && !mandi.hasError) {
                    return const Padding(padding:EdgeInsets.all(10),
                      child:LinearProgressIndicator());
                  }
                  return _selectedChart(snapshot.data!,special.data!,
                    mandi.data,mandiError:mandi.hasError?'${mandi.error}':null);
                });
            });
        }),
      const SizedBox(height:8),
      _manualInputs(),
      const SizedBox(height:8),
      const ExpansionTile(title:Text('చక్రం ఉపయోగించే సూచనలు'),children:[
        Padding(padding:EdgeInsets.all(10),child:Text(
          '1. రాశి చక్రంలో U = ఉదయ లగ్నం. రంగు కేవలం ప్రదర్శనకు మాత్రమే.\n'
          '2. గ్రహ స్థితులు Swiss Ephemeris ఆధారంగా, ఎంచుకున్న అయనాంశంతో గణిస్తాయి.\n'
          '3. సాధారణ లగ్నం, ప్రత్యేక Jamakkol Udayam వేర్వేరు — రెండింటినీ పట్టికలో చూడండి.\n'
          '4. Arudam గడియార నిమిషాల నుంచి గణిస్తుంది. Manual Override అందుబాటులో ఉంది.\n'
          '5. ఎనిమిది బయటి జామ గ్రహాలు 06:00 వారం-ఆధారిత 45° రింగ్ పద్ధతిలో ఉంటాయి. ఇది మూలాంతరాలు ఉండగల పద్ధతి.\n'
          '6. పింక్ KAV రాశి: అపసవ్య దూరం D=(ఆరూఢ రాశి−వీథి రాశి+12)%12, K=(ఉదయం రాశి−D+12)%12. సూర్యవీథి ఆటో పట్టిక నుంచి వస్తుంది. ఖచ్చిత డిగ్రీకి రెండు వేర్వేరు పోలికలు ఉన్నాయి; వాటిని నిర్ణయాత్మకంగా వాడం. మండీ Auto, యమఘంటం Manual.\n'
          '7. Crossed/Approaching అనేవి ప్రస్తుత సౌర జామ వ్యవధిలోని ±30 నిమిషాల గణిత సంపర్కాలు మాత్రమే; సంప్రదాయ నిర్ణయం కాదు.\n'
          '8. Hora సాధారణ Planetary Hora; జామ రింగ్‌కు ప్రత్యామ్నాయం కాదు.')),
      ]),
    ]);
  }
}

class _JamakkolSouthChart extends StatelessWidget {
  const _JamakkolSouthChart({required this.chart,required this.bhava,
    required this.jamaOnly,required this.lagna,
    required this.udhayam,required this.jamaGrahas,
    required this.arudam,required this.chatra,required this.chatraSign,
    required this.kavippu,required this.mandi,required this.cream,
    required this.pink,required this.lat,required this.lon});
  final AstroChartResult chart;
  final bool bhava, jamaOnly;
  final double lagna;
  final double udhayam;
  final List<JamaRingPosition> jamaGrahas;
  final double? arudam, chatra, kavippu, mandi;
  final int chatraSign;
  final Color cream,pink;
  final double lat,lon;

  static const _cells=<int>[
    11,0,1,2,
    10,-1,-1,3,
    9,-1,-1,4,
    8,7,6,5,
  ];
  static String _sign(int v)=>_JamakolaRulePanelState._signShort[v];
  static String _short(String v)=>_JamakolaRulePanelState._short[v]??v;
  static double _norm(double v)=>(v%360+360)%360;

  List<List<String>> _contents(){
    final c=List.generate(12,(_)=><String>[]);
    if(!bhava){
      if(jamaOnly) {
        c[(udhayam/30).floor()%12].add('U');
        if(arudam!=null)c[(arudam!/30).floor()%12].add('ARU');
        c[chatraSign].add('KAV');
        for(final j in jamaGrahas) {
          c[j.signIndex].add('J:${j.name=='Snake'?'Sn':_short(j.name)} '
            '${_JamakolaRulePanelState._inSign(j.longitude)}');
        }
      } else {
        c[(lagna/30).floor()%12].add('L');
        if(mandi!=null)c[(mandi!/30).floor()%12].add(
          'Md ${_JamakolaRulePanelState._inSign(mandi!)}');
        for(final p in chart.planets) {
          c[p.signIndex].add('${_short(p.name)} '
            '${_JamakolaRulePanelState._inSign(p.longitude)}');
        }
      }
    }else{
      try {
        final v=Sweph.swe_houses_ex(chart.julianDay,
          SwephFlag.SEFLG_SIDEREAL,lat,lon,Hsys.P).cusps;
        if(v.length!=12&&v.length!=13) return c;
        final cusps=v.length==12?v:v.skip(1).take(12).toList();
        int h(double longitude){
          for(var i=0;i<12;i++) {
            final start=_norm(cusps[i]),end=_norm(cusps[(i+1)%12]);
            final span=_norm(end-start),delta=_norm(longitude-start);
            if(span>0&&delta<span)return i;
          }
          return 0;
        }
        if(jamaOnly) {
          c[h(udhayam)].add('U');
          if(arudam!=null)c[h(arudam!)].add('ARU');
          // Chatra/KAV degree is not proven from its rasi alone. Never
          // manufacture a bhava placement when no degree was provided.
          if(chatra!=null)c[h(chatra!)].add('KAV');
          for(final j in jamaGrahas) {
            c[h(j.longitude)].add('J:${j.name=='Snake'?'Sn':_short(j.name)} '
              '${_JamakolaRulePanelState._inSign(j.longitude)}');
          }
        } else {
          c[h(lagna)].add('L');
          if(mandi!=null)c[h(mandi!)].add(
            'Md ${_JamakolaRulePanelState._inSign(mandi!)}');
          for(final p in chart.planets) {
            c[h(p.longitude)].add('${_short(p.name)} '
              '${_JamakolaRulePanelState._inSign(p.longitude)}');
          }
        }
      } catch (_) {return c;}
    }
    return c;
  }

  @override
  Widget build(BuildContext context){
    final positions=_contents();
    return LayoutBuilder(builder:(context,constraints){
      final w=constraints.maxWidth.clamp(200.0,510.0).toDouble();
      final cell=w/4;
      return Center(child:SizedBox(width:w,height:w,
        child:Stack(children:[
          for(var i=0;i<16;i++)if(_cells[i]>=0)
            Positioned(left:(i%4)*cell,top:(i~/4)*cell,
              width:cell,height:cell,
              child:Container(decoration:BoxDecoration(
                color:jamaOnly && positions[_cells[i]].contains('KAV')
                  ?const Color(0xFFFFD9E6):cream,
                border:Border.all(
                  color:jamaOnly && positions[_cells[i]].contains('KAV')
                    ?const Color(0xFFB6004D):Colors.black,
                  width:jamaOnly && positions[_cells[i]].contains('KAV')?2.5:1.5)),
                padding:const EdgeInsets.all(4),
                child:Stack(children:[
                  Column(crossAxisAlignment:CrossAxisAlignment.start,
                  children:[
                    Text(bhava?'భావ ${_cells[i]+1}':_sign(_cells[i]),
                      style:const TextStyle(fontSize:11,fontWeight:FontWeight.bold)),
                    Expanded(child:SingleChildScrollView(
                      primary:false,
                      child:Wrap(spacing:3,runSpacing:1,
                        children:[for(final p in positions[_cells[i]])
                          if(p=='KAV') Container(
                            padding:const EdgeInsets.symmetric(horizontal:5,vertical:2),
                            decoration:BoxDecoration(color:pink,
                              borderRadius:BorderRadius.circular(4)),
                            child:Text('KAV',style:TextStyle(
                              fontSize:w<370?10:12,color:Colors.white,
                              fontWeight:FontWeight.bold)))
                          else Text(p,style:TextStyle(
                            color:p=='U'||p=='ARU'||p=='L'
                              ?Colors.deepPurple:Colors.black,
                            fontSize:p=='U'||p=='ARU'||p=='L'?(w<370?13:15)
                              :(p.startsWith('J:')?(w<370?9:10):(w<370?9:10)),
                            fontWeight:p=='U'||p=='ARU'||p=='L'
                              ?FontWeight.w900:FontWeight.w700))]))),
                  ]),
                  if(jamaOnly && positions[_cells[i]].contains('U'))
                    Positioned(top:1,right:1,child:CustomPaint(
                      size:const Size(23,20),painter:_UdayamDoubleLinePainter())),
                ]))),
          Positioned(left:cell,top:cell,width:2*cell,height:2*cell,
            child:Container(decoration:BoxDecoration(color:cream,
              border:Border.all(color:Colors.black,width:2)),
              child:Center(child:Padding(
                padding:const EdgeInsets.all(5),
                child:Column(mainAxisSize:MainAxisSize.min,children:[
                  FittedBox(fit:BoxFit.scaleDown,
                    child:Text(jamaOnly?'Jama Grahas':'Inner Grahas',
                      style:TextStyle(fontSize:w<350?17:19,
                        fontWeight:FontWeight.bold))),
                  const SizedBox(height:4),
                  Text(bhava?'Bhava Chart':'Rashi Chart',
                    textAlign:TextAlign.center,
                    style:TextStyle(fontSize:w<350?11:12)),
                  const SizedBox(height:4),
                  Text(jamaOnly?'U · ARU · KAV · J:':'L · Md · సాధారణ గ్రహాలు',
                    textAlign:TextAlign.center,
                    style:TextStyle(fontSize:w<350?10:11,
                      color:Colors.deepPurple,fontWeight:FontWeight.w700)),
                ]))))),
        ])));
    });
  }
}

/// Two parallel slashes identify the Udayam cell without changing rasi data.
class _UdayamDoubleLinePainter extends CustomPainter {
  const _UdayamDoubleLinePainter();
  @override
  void paint(Canvas canvas,Size size) {
    final paint=Paint()..color=const Color(0xFFBA1248)
      ..strokeWidth=2.8..strokeCap=StrokeCap.round;
    canvas.drawLine(const Offset(3,18),const Offset(13,3),paint);
    canvas.drawLine(const Offset(11,18),const Offset(21,3),paint);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate)=>false;
}
