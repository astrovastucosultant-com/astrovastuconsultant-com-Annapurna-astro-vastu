# Build 292 — BNN 12-year symbolic period readings

Source: v1.4.291 complete Flutter ZIP; application version `1.4.292+292`.

**New:** Every existing natal-Jupiter-relative annual window now displays a calculated `శుభం` (pale green), `అశుభం` (pale pink), or `మధ్యస్థం` (grey) evidence label. The label is based on close (<=5°) 1/5/9 natal-sign links to Jupiter/Venus vs Saturn/Mars/Rahu/Ketu and exact natal IF source THEN wording already matched by `BnnAllRulesMatchService`. Both polarities or insufficient evidence are mixed. Classifier never changes the source rule itself.

Each annual card retains birthday-anniversary date range, period-specific topic result, and **రూల్ → పరిశీలన → ఫలితం** only. The 12-year symbolic windows remain unchanged; a category based on natal evidence can recur for that planet across different rounds. It is not a verified transit, event date, or factual guarantee. In particular, no classification based purely on sign/rashi placement can establish that a medical event, marriage, or career event occurred.

New test: `test/bnn_period_tone_292_test.dart` exercises 3 grades, insufficient evidence, degree tolerance, matched natal source sentiment, and age-window preservation. Prior `test/bnn_relative_period_result_test.dart` is kept.

Release verification: source ZIP inventory and archive integrity checked. Flutter SDK is not available in this build environment, so **Dart analyzer, Flutter test, and APK build have NOT been run**.
