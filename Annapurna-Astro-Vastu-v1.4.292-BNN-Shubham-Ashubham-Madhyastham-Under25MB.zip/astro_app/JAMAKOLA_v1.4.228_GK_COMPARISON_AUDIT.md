# Jamakola v1.4.228 — GK / Veedhi Comparison Audit

## Scope / limitations

This is an incremental correction of v1.4.227, NOT proof that this project reproduces the proprietary GK Astro application. GK's underlying executable and its complete source formula tables are not accessible from the public evidence inspected; comparisons here use published Jamakkol Prasannam references, source excerpts supplied by the user, and the user's separate Divya Chakshu screenshot.

## Changes

1. Added `JamakolaSpecialService.kavippuFromVeedhiAnchor(udhayam, arudam, anchorSignIndex)`. The transfer-of-distance (rasi-count) rule is separately auditable and the in-sign longitude moves opposite Arudam. The Veedhi anchor must be confirmed; the app does NOT guess the solar-Veedhi mapping for all 12 Sun signs. Missing anchor = Pending, not a made-up Kavippu.
2. `KAV` is displayed inside the chart and in the position table **only** after an anchor is provided. Existing `CHA` remains the Divya Chakshu Chatra and is not equated with Kavippu.
3. The reference-conditioned Kavippu rasi is passed through to the IF–THEN engine instead of relying exclusively on manual Kavippu sign selection.
4. The `Jama Planet Crossed Udaya` field is no longer reported on the basis of mere angular proximity. The `approaching` entry is explicitly labelled as an angular estimate and no longer auto-matches event rules. A crossing check needs motion of Udhayam and Jama marker over a time interval.
5. 8 Jama ring positions, sunrise/sunset calculations and clock Arudam are retained from v1.4.227 because their published/reference fixtures were internally consistent. No unsupported new Mandi, Yamaghan, Divya Chakshu Chatra or GK-specific alternate Udhayam claims are made.

## Independent published comparison cases (Veedhi anchor Mesha=0)

- 2026-09-15 05:58:24, Udhayam Simha 27°17', Arudam Meena 20°24' → Kavippu Kanni 9°36' (159°36').
- 2026-09-10 07:45:39, Udhayam Thula 15°12', Arudam Makara 3°54' → Kavippu Makara 26°06' (296°06').
- 2026-09-11 04:06:49, Udhayam Mithuna 24°12', Arudam Rishaba 10°54' → Kavippu Rishaba 19°06' (49°06').

Source-reference pages:
- https://rajvidya.com/wiki/article/udhayam-aarudam-kavippu-three-pillars-of-jamakol/
- https://hindupanchangam.in/en/tools/jamakol-prasannam/
- https://occultapi.com/docs/astro/prashna/jamakkol

User's Divya Chakshu screenshot (Guntur, 2026-10-24 17:50) confirms its own Jama ring: Sun230°, Mars185°, Jupiter140°, Mercury95°, Venus50°, Saturn5°, Moon320°, Snake275°. It does **not** certify the GK Udhayam, Veedhi anchor, Kavippu, Mandi or Chatra conventions.

## Remaining external reference requirements

- GK solar-Veedhi-to-anchor table for the 12 sidereal Sun signs.
- GK/Udhayam Tamil-month initial-slot and sunrise duration convention: the existing implementation is **one documented model**, not proven identical to GK.
- GK Maandi and Yamagandam weekday day/night tables and precise degree formula.
- Divya Chakshu Chatra degree calculation and 'catching' condition. No evidence establishes Chatra = Kavippu.
- Time-series crossing calculation for Jama and Udhayam (not a snapshot proximity test).
- Any GK application-specific prediction rules and differences.

## Validation

- Updated unit tests in `test/jamakola_special_service_test.dart` cover three public Kavippu fixtures, invalid anchor rejection, Oct 24 Jama ring, earlier clock Arudam fixture.
- Archive integrity and source-data hashes checked locally. Flutter SDK is not installed in this environment; no `flutter test` or release APK build is claimed.
