# Annapurna Astro Vastu v1.4.251 — BNN result presentation cleanup

Basis: v1.4.250 full Flutter source ZIP and user-provided BNN_MASTER_IF_THEN_462_TELUGU.txt.

## Changes
- The 462-rule SOURCE CATALOG is left byte-for-byte unchanged (343 OCR_REVIEW, 82 FACTS_REQUIRED, 37 REVIEW).
- Original category selector, source search, rule ID, full source text, result tap -> IF condition, natal positions/degrees, original inspection note and PDF page are retained.
- Topic-wise natal sign-placement hints are now visibly separated from temporal conclusions. Source text is labeled **unverified**; a rulebook statement is not a diagnosis, verified past event or future forecast.
- Past, present and future period controls no longer repeat the *same natal-placement cards* under each period. All three explicitly state that no date-confirmed events exist without a validated transit/timing algorithm.
- A collapsed study panel retains original age/round information and separate time-source snippets. The 462 source entries are in a separate collapsed searchable library, with paging.
- BNN medical-source rows carry an explicit non-diagnostic disclaimer in the rule detail. The user-supplied kidney-stone remedy infographic has not been added to BNN (outside this rule source and unverified medical advice).
- Previous empty Hasta Samudrika tab untouched; all other source files preserved without changes.

## Validation and limitations
- ZIP CRC, 462 IDs, status split, asset declaration, and local Dart import references are statically checked.
- Flutter SDK unavailable in runtime: no flutter analyze, flutter test or APK compile. No timing engine was invented. No medical prediction or remedy is asserted.
