# Annapurna Astro Vastu v1.4.255 — BNN Colorful Tabs

- Base: v1.4.254 (includes Jamakola Now/Nimitta 300); no change to Jamakola.
- 12 Jupiter-relative BNN bhava selectors use coordinated, accessible colored accents with animated selected state.
- Five sub-tabs (results, yoga, past, present, future) each use their own selected/background colors and icons.
- Unverified book rules are kept behind closed-by-default source-library expanders, with compact, clearly labeled reference tiles.
- Source rule sheets distinguish OCR REVIEW from chart-inspection.
- Source library content and chart-matching logic remain unchanged; no new timing or prediction claims.
- 462 BNN rules retained.
- Static ZIP and import tests are required; Flutter compile was not run in this environment.
