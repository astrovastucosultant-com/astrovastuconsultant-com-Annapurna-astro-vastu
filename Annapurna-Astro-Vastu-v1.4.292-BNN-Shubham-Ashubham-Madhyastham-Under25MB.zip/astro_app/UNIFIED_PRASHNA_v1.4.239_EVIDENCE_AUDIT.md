# Unified Prashna v1.4.239 — evidence vs contradiction audit

- Reproduced the visible logic defect from childbirth question on 25 October 2026.
- Previously, `!time.provisionalPositive` was interpreted as KP/Tajik disagreement, even when KP `mainConnected=true` and `supportConnected=false` or the source rule demanded manual verification.
- Missing evidence is **incomplete**, not a verified denial.
- A Tajik applying aspect is preliminary support; it is not confirmed childbirth or a timing prediction.
- Shows (a) available preliminary evidence, (b) what still requires evaluation, (c) event timing not calculated.
- KP 414 events, Jamakola 74 rules and existing calculation services unchanged.
- Future verified promise/denial contradictions may be represented using `PrashnaEvidenceLevel.verifiedSupport` and `.verifiedDenial`. No current provisional engine populates these.
- User-visible question prompt generalized beyond job questions.

## Test scope
- Added `test/unified_prashna_evidence_synthesis_test.dart` with four cases.
- Flutter CLI unavailable in present execution environment; release build and automated Flutter tests require CI.
- This update does NOT add KP dasha timing, complete Tajik 16 yoga methods, or source-verified full Jamakola judgement.
