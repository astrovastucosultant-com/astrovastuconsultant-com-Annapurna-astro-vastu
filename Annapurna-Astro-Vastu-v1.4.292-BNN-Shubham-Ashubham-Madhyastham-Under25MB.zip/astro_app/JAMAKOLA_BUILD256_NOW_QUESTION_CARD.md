# Annapurna Astro Vastu v1.4.256 — Jamakola NOW question summary

Source: v1.4.255 full Flutter ZIP (17.97 MB). Changed existing Jama panel plus pubspec version; all other existing files unchanged. Added quick topic summary directly under Udayam/Arudam/Kavippu TOP Jama Grahas chart, retained BOTTOM ordinary time chart and full 300-source-rules Nimitta panel after it. Jump-to-details button scrolls to that panel. No auto claim that a guessed event has occurred. Uses the existing astrological Arudam house and provisional pink Kavippu sign and discloses alternate candidate sphuta when different. On NOW, the existing calculation pipeline recomputes in the selected location/offset, and the summary reads that timestamp.

No change to source 300 rows or BNN 462 rules.

Verification: static ZIP integrity, retained files/asset checks and Dart source consistency. Flutter SDK / Dart SDK unavailable: no `flutter analyze`, `flutter test`, Android APK build, or on-device test was run.
