# Annapurna Astro Vastu v1.4.238 — Jamakola dual charts + local civil clock fix

- **Above**: 12-sign South-Indian chart showing ONLY eight Jama clock-ring planets, Jamakola Udayam (U), Arudam (ARU), and pink Kavippu (KAV, rasi-only where exact degrees unverified). Each Jama position is placed by `floor(longitude/30)` and displays degrees/minutes/seconds **within that sign**. Udayam double-line marker retained.
- **Below**: independent South-Indian chart showing ordinary sidereal Inner planets for the QUESTION TIME and astronomical ascendant marked L. This is NOT the birth nativity. Each Inner planet displays degree within sign.
- Full eight-Jama DMS longitude table preserved. Existing Sign / Bhava toggle works for both charts. In Bhava mode KAV stays absent unless user has supplied exact degree.
- Fixed an offset-handling issue in `jamaFromLocalClock`: mixing a UTC-tagged representation of civil time with `DateTime(y,m,d)` in host timezone produced incorrect +05:30 shift on Indian phones. New computation uses civil wall-clock fields and `DateTime.utc` for day arithmetic. Astronomical UTC conversion continues to use explicit place offset in `AstroCalculationService`.
- Regression fixtures: 2026-10-25 13:55 local gives Sun=122°30′, Mars=77°30′, Jupiter=32°30′, Mercury=347°30′, Venus=302°30′, Saturn=257°30′, Moon=212°30′, Snake=167°30′; and Arudam=330°. These match rounded reference positions; seconds in external Divya Chakshu output are not independently confirmed.
- This is a chart layout / timezone correctness update; NOT completion of full traditional prognostic rule verification or full Tajik/KP decision logic.
- No Flutter SDK is present in this execution environment; APK compilation is **not** claimed.
