# BNN v1.4.273 — screenshot-driven topic UI fix

- An empty-source topic is only a navigation label, not a horoscope result. Hide the 10 empty topic cards in normal scroll. On-demand dialog lists their titles without result cards.
- Source topic index counts are explicit source references, not chart-confirmed result counts.
- In the tapped source topic sheet, display actual checkable natal IF matches first; all other source IFs stay in a closed panel.
- Keep OCR_REVIEW on every match; no rule promoted to VERIFIED. No unverified IF produces a final event.
- Entire 462 source catalogue, 106 master rules, 48 timing rules remain intact.
- This ZIP is not proof of successful Flutter compile; run GitHub Action for APK.
