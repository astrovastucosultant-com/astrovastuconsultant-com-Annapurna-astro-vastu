import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/varga_ashtakavarga_service.dart';
import '../astrology/d10_topic_rule_bridge.dart';
import '../astrology/d10_vrutti_match_engine.dart';
import '../astrology/varga_service.dart';
import '../astrology/varga_topic_catalog.dart';
import '../astrology/varga_topic_rule_linker.dart';
import '../astrology/varga_rule_service.dart';
import '../astrology/varga_rule_match_policy.dart';
import '../astrology/varga_unified_rule_service.dart';
import '../astrology/varga_source_stub_live_support.dart';
import 'unified_rule_result_tile.dart';
import 'varga_ashtakavarga_panel.dart';

/// All chart-specific subject titles in one compact list. A source table of
/// contents is NOT an IF–THEN match. Verified hits alone highlight conclusions.
class VargaTopicsPanel extends StatefulWidget {
  const VargaTopicsPanel({
    super.key,
    required this.natal,
    required this.factor,
    required this.d16Method,
  });
  final AstroChartResult natal;
  final int factor;
  final D16CalculationMethod d16Method;

  // The title index is not the source evidence. Verified rule hits are still
  // produced only by the original calculation engines.
  static bool matchesTopic(String text, VargaTopic topic) {
    final folded = text.toLowerCase();
    return topic.matchWords.any((w) => folded.contains(w.toLowerCase()));
  }

  static RuleVerdict verdict(VargaRuleHit rule) => switch (rule.tone) {
    VargaRuleTone.favorable => RuleVerdict.favourable,
    VargaRuleTone.caution => RuleVerdict.adverse,
    VargaRuleTone.neutral => RuleVerdict.mixed,
    VargaRuleTone.info => RuleVerdict.unverified,
  };

  @override
  State<VargaTopicsPanel> createState() => _VargaTopicsPanelState();
}

class _VargaTopicsPanelState extends State<VargaTopicsPanel> {
  late Future<List<UnifiedVargaRule>> _sourceRulesFuture;
  int get factor => widget.factor;
  AstroChartResult get natal => widget.natal;
  D16CalculationMethod get d16Method => widget.d16Method;

  @override
  void initState() {
    super.initState();
    _sourceRulesFuture = VargaUnifiedRuleService.evaluate(widget.natal);
  }

  @override
  void didUpdateWidget(covariant VargaTopicsPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.natal, widget.natal)) {
      _sourceRulesFuture = VargaUnifiedRuleService.evaluate(widget.natal);
    }
  }

  bool matchesTopic(String text, VargaTopic topic) =>
      VargaTopicsPanel.matchesTopic(text, topic);
  RuleVerdict verdict(VargaRuleHit rule) =>
      VargaTopicsPanel.verdict(rule);

  /// The unified catalog is evaluated once per horoscope, then routed into
  /// topic cards. Source catalog matches and computed engine hits share the
  /// SAME item rather than being parked in a separate bottom audit.
  /// Only a brief mathematical AV reference travels with a rule. Full BAV and
  /// Prastara contributor lists belong in the single expandable house audit;
  /// repeating the 7 x 8 table after each rule overwhelmed the mobile UI.
  String _avTrace(VargaAshtakavargaReport? av, int? house) {
    if (av == null || house == null || !av.auditPassed) return '';
    final h = av.forHouse(house);
    final d1Sav = av.natal.arithmetic.savHouse(house);
    return '\nAV సహాయక పరిశీలన: D${av.factor} ${house}వ భావం '
        'SAV ${h.sav}/56 • D1 అదే భావం SAV $d1Sav/56. '
        'BAV/PAV బిందువుల పూర్తి వివరాలు దిగువ అష్టకవర్గ పట్టికలో ఉన్నాయి. '
        'ఈ గణిత గణన వల్ల మూల IF–THEN ఫలితం మారదు.';
  }

  RuleResultData _sourceRow(UnifiedVargaRule r,
      {VargaAshtakavargaReport? av, int? house}) {
    // Supplemental D16 evidence is calculated with the SELECTED D16 method.
    // Source rows from the Parashara-only 255 catalog remain gated when the
    // alternate method is selected; do not discard correctly remapped support.
    final alternateD16 = factor == 16 &&
        d16Method != D16CalculationMethod.parashara &&
        !r.id.startsWith('VARGA-GENERAL-004/D16') &&
        !r.id.startsWith('USER-STUB-') &&
        !r.id.startsWith('VARGA-PROTOCOL-');
    final crossAuditOnly = VargaRuleMatchPolicy.isCrossVargaEvidence(r.id);
    final matched = VargaRuleMatchPolicy.sourceMatch(
        r, factor: factor, d16Method: d16Method);
    return RuleResultData(
      topic: r.topic,
      ruleId: r.id,
      verdict: switch (r.tone) {
        UnifiedVargaRuleTone.favorable => RuleVerdict.favourable,
        UnifiedVargaRuleTone.adverse => RuleVerdict.adverse,
        UnifiedVargaRuleTone.neutral => RuleVerdict.mixed,
      },
      ruleMatched: matched,
      rule: r.condition,
      examination: crossAuditOnly
          ? 'CROSS / SAV / వర్గోత్తమ పరిశీలన మాత్రమే; ఇది స్వతంత్రంగా తుది ఫలితాన్ని నిర్ణయించదు. ${r.evidence}${_avTrace(av, house)}'
          : alternateD16
          ? 'ప్రామాణిక D16 పద్ధతితో పరీక్షించిన మూల నియమం ఇది. '
              'మీరు ఎంచుకున్న ప్రత్యామ్నాయ D16 పద్ధతికి ఫలితం '
              'మళ్లీ ధృవీకరించాలి. ${r.evidence}${_avTrace(av, house)}'
          : '${r.evidence}${_avTrace(av, house)}',
      result: r.outcome,
      source: r.source,
      remedy: null,
    );
  }

  RuleResultData _evaluatedRow(VargaRuleHit hit,
      {VargaAshtakavargaReport? av, int? house}) {
    // Bibliographic/source-authorship verification is independent from the
    // actual IF–THEN chart-condition calculation. A computed rule is NOT
    // discarded because its original printed source page is still pending.
    // Source-only or informational rows remain unverified predictions.
    final bool? matched = VargaRuleMatchPolicy.calculatedMatch(hit);
    return RuleResultData(
      topic: hit.topic,
      ruleId: hit.ruleId,
      verdict: verdict(hit),
      ruleMatched: matched,
      rule: hit.rule,
      examination: '${hit.inspection}${_avTrace(av, house)}',
      result: hit.result,
      source: hit.source,
      // Exact source-to-remedy matching must be demonstrated separately.
      remedy: null,
    );
  }

  RuleResultData _vruttiRow(D10VruttiMatch match) {
    final source = match.rule;
    return RuleResultData(
      topic: source.profession,
      ruleId: source.id,
      verdict: match.fullRuleMatched
          ? RuleVerdict.mixed : RuleVerdict.unverified,
      ruleMatched: match.fullRuleMatched,
      rule: source.condition,
      examination: <String>[
        if (match.passed.isNotEmpty) 'సరిపోయిన షరతులు:\n${match.passed.join('\n')}',
        if (match.failed.isNotEmpty) 'సరిపోని షరతులు:\n${match.failed.join('\n')}',
        if (match.pending.isNotEmpty) 'పెండింగ్ / సహాయక ఆధారాలు:\n${match.pending.join('\n')}',
      ].join('\n'),
      result: match.fullRuleMatched
          ? 'ఈ జాతకంలో ${source.profession} రంగానికి సంబంధించిన '
              'మూల IF–THEN షరతులు సరిపోయాయి. ఇది వృత్తి సూచన మాత్రమే; '
              'నియామకం, లాభం, కాలం నిర్ధారణ కాదు.'
          : 'ఈ జాతకంలో ${source.profession} వృత్తికి పూర్తి మూల '
              'IF–THEN మ్యాచ్ లేదు. ఇది పరిశీలన మాత్రమే; వృత్తి ఫలితం కాదు.',
      source: '${source.source} • ముద్రిత పుట ${source.page}',
      evidencePercent: match.fullRuleMatched ? match.percent.toDouble() : null,
    );
  }

  Widget _item({
    required String title,
    required List<VargaRuleHit> calculated,
    required List<UnifiedVargaRule> sources,
    VargaAshtakavargaReport? av,
    int? topicHouse,
    List<D10VruttiMatch> vruttiMatched = const [],
    List<D10VruttiMatch> vruttiAudit = const [],
  }) {
    // The same three-state IF–THEN policy applies to every one of the
    // supported vargas. Do not show failed/pending rules in D2–D60 as
    // matched predictions while
    // treating them as horoscope results.
    final validCalculated = calculated.where((h) =>
        VargaRuleMatchPolicy.calculatedMatch(h) == true).toList();
    final validSource = sources.where((r) =>
        VargaRuleMatchPolicy.sourceMatch(
            r, factor: factor, d16Method: d16Method) == true).toList();
    final count = validCalculated.length + validSource.length + vruttiMatched.length;
    final total = calculated.length + sources.length +
        vruttiMatched.length + vruttiAudit.length;
    final auditTotal = total - count;
    final sourceOrder = [...sources]..sort((a, b) =>
        VargaRuleMatchPolicy.priority(VargaRuleMatchPolicy.sourceMatch(
            a, factor: factor, d16Method: d16Method)).compareTo(
        VargaRuleMatchPolicy.priority(VargaRuleMatchPolicy.sourceMatch(
            b, factor: factor, d16Method: d16Method))));
    final calcOrder = [...calculated]..sort((a, b) =>
        VargaRuleMatchPolicy.priority(
            VargaRuleMatchPolicy.calculatedMatch(a)).compareTo(
        VargaRuleMatchPolicy.priority(
            VargaRuleMatchPolicy.calculatedMatch(b))));
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      color: const Color(0xFFFFF7E8),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        key: ValueKey('varga-topic-$factor-$title'),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(total == 0
            ? 'అనుసంధానిత IF–THEN నియమాలు లేవు — ఫలితం నిర్ధారణ కాదు'
            : 'వర్తించిన నియమాలు: $count • అనుసంధానిత ఆధారాలు: $total'
              '${count == 0 ? ' • మ్యాచ్ కాలేదు / పరిశీలన పెండింగ్' : ''}',
            style: const TextStyle(fontSize: 12)),
        childrenPadding: const EdgeInsets.only(bottom: 8),
        children: [
          if (count == 0 && total > 0)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 14, vertical: 7),
              child: Text('ఈ అంశంలో పరీక్షించిన షరతులు పూర్తిగా సరిపోలలేదు '
                  'లేదా గణన పెండింగ్. మూల ఫలితాన్ని జాతక ఫలితంగా చూపలేదు.',
                  style: TextStyle(fontSize: 12, color: Color(0xFF6A6470))),
            ),
          // Applied source-backed rules first. Category placeholders are
          // never displayed as if they were evaluated IF–THEN predictions.
          for (final m in vruttiMatched)
            UnifiedRuleResultTile(
              key: ValueKey('topic-d10-vrutti-$factor-${m.rule.id}'),
              data: _vruttiRow(m),
              showRemedyStatus: true,
            ),
          for (final h in calcOrder.where((h) =>
              VargaRuleMatchPolicy.calculatedMatch(h) == true))
            UnifiedRuleResultTile(
              key: ValueKey('topic-engine-$factor-${h.ruleId}'),
              data: _evaluatedRow(h, av: av, house: topicHouse),
              showRemedyStatus: true,
            ),
          for (final r in sourceOrder.where((r) =>
              VargaRuleMatchPolicy.sourceMatch(
                  r, factor: factor, d16Method: d16Method) == true))
            UnifiedRuleResultTile(
              key: ValueKey('topic-source-rule-$factor-${r.id}'),
              data: _sourceRow(r, av: av, house: topicHouse),
              showRemedyStatus: true,
            ),
          if (total == 0)
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 8, 16, 15),
              child: Text('ఈ అంశానికి పరీక్షించగల మూల IF–THEN నియమం '
                  'ఇంకా అనుసంధానం కాలేదు. 0 అంటే ఈ యోగం లేదని కాదు. '
                  'వర్గ గ్రహస్థితుల ఆధారంగా ఫలితం ఊహించలేదు.',
                  style: TextStyle(color: Color(0xFF656C76), fontSize: 12)),
            ),
          if (av != null && topicHouse != null)
            VargaAvHouseEvidenceTile(report: av, house: topicHouse),
          if (auditTotal > 0)
            ExpansionTile(
              key: ValueKey('varga-audit-$factor-$title'),
              initiallyExpanded: false,
              title: Text('సరిపోని / పరీక్ష పెండింగ్ / CROSS పరిశీలన ($auditTotal)',
                  style: const TextStyle(fontSize: 12,
                      color: Color(0xFF657080))),
              children: [
                for (final m in vruttiAudit)
                  UnifiedRuleResultTile(
                    key: ValueKey('topic-d10-vrutti-audit-$factor-${m.rule.id}'),
                    data: _vruttiRow(m),
                    showRemedyStatus: true,
                  ),
                for (final h in calcOrder.where((h) =>
                    VargaRuleMatchPolicy.calculatedMatch(h) != true))
                  UnifiedRuleResultTile(
                    key: ValueKey('topic-engine-audit-$factor-${h.ruleId}'),
                    data: _evaluatedRow(h, av: av, house: topicHouse),
                    showRemedyStatus: true,
                  ),
                for (final r in sourceOrder.where((r) =>
                    VargaRuleMatchPolicy.sourceMatch(
                        r, factor: factor, d16Method: d16Method) != true))
                  UnifiedRuleResultTile(
                    key: ValueKey('topic-source-audit-$factor-${r.id}'),
                    data: _sourceRow(r, av: av, house: topicHouse),
                    showRemedyStatus: true,
                  ),
              ],
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final topics = VargaTopicCatalog.forFactor(factor);
    if (topics.isEmpty) return const SizedBox.shrink();
    final data = VargaService.calculate(natal, factor, d16Method: d16Method);
    final sav = VargaSourceStubLiveSupport.natalSavIfAvailable(natal);
    VargaAshtakavargaReport? avReport;
    String? avIssue;
    try {
      avReport = VargaAshtakavargaService.calculate(
          natal, factor, d16Method: d16Method);
      if (!avReport.auditPassed) {
        avIssue = 'PAV / BAV / SAV audit failed; values not used as evidence.';
        avReport = null;
      }
    } catch (error) {
      avIssue = 'అష్టకవర్గ గణనకు కావలసిన పూర్తి గ్రహస్థితులు లేవు: $error';
    }
    final allCalculated = VargaRuleService.allFor(
        chart: natal, factor: factor, d16Method: d16Method);
    // Reuse the existing 174+ source profession predicates. Only full
    // condition matches may appear as results in corresponding D10 topics.
    final d10AllSourceChecks = factor == 10
        ? D10VruttiMatchEngine.evaluate(natal)
        : <D10VruttiMatch>[];
    final d10SourceMatches = d10AllSourceChecks.where(
        (m) => m.fullRuleMatched).toList(growable: false);
    // Stable ID -> one *primary* topic. A rule is not counted repeatedly
    // merely because several Telugu title words overlap.
    final calcGroups = List.generate(topics.length, (_) => <VargaRuleHit>[]);
    final calcOther = <VargaRuleHit>[];
    final seenCalculated = <String>{};
    for (final h in allCalculated) {
      if (!seenCalculated.add(h.ruleId)) continue;
      final destination = VargaTopicRuleLinker.computedIndex(
          factor, h.ruleId, h.topic, topics);
      if (destination == null) {
        calcOther.add(h);
      } else {
        calcGroups[destination].add(h);
      }
    }
    return FutureBuilder<List<UnifiedVargaRule>>(
      future: _sourceRulesFuture,
      builder: (context, snapshot) {
        final sourceGroups = List.generate(
            topics.length, (_) => <UnifiedVargaRule>[]);
        final sourceOther = <UnifiedVargaRule>[];
        // Source-page SAV, Vargottama and unlocated supplementary
        // predicates remain audit evidence, not final event predictions.
        for (var i = 0; i < topics.length; i++) {
          sourceGroups[i].addAll(VargaSourceStubLiveSupport.natalSavForTopic(
              natal, topics[i], sav, factor: factor));
        }
        final vargottama = VargaSourceStubLiveSupport.vargottama(natal, data);
        if (vargottama != null) sourceOther.add(vargottama);
        sourceOther.addAll(VargaSourceStubLiveSupport.supplementaryObservations(
            natal, data));
        if (snapshot.hasData) {
          for (final r in snapshot.data!) {
            // Explicit D-factor sources + cross-chart rules with a verified
            // navigation binding. Unrelated 255-rule groups are not silently
            // presented as chart-specific event predictions.
            final isDirect = r.group == 'D$factor';
            final crossIdx = VargaTopicRuleLinker.crossIndex(
                factor, r.id, topics.length);
            if (!isDirect && crossIdx == null) continue;
            final destination = isDirect
                ? VargaTopicRuleLinker.sourceIndex(
                    factor, r.id, topics.length)
                : crossIdx;
            if (destination == null) {
              sourceOther.add(r);
            } else {
              sourceGroups[destination].add(r);
            }
          }
        }
        final allSourceForFactor = <UnifiedVargaRule>[
          for (final group in sourceGroups) ...group,
          ...sourceOther,
        ];
        final sourceStatuses = allSourceForFactor.map((r) =>
            VargaRuleMatchPolicy.sourceMatch(
                r, factor: factor, d16Method: d16Method)).toList();
        final computedStatuses = allCalculated.map(
            VargaRuleMatchPolicy.calculatedMatch).toList();
        final sourceMatched = VargaRuleMatchPolicy.countMatched(sourceStatuses);
        final computedMatched = VargaRuleMatchPolicy.countMatched(computedStatuses);
        final unMatched = VargaRuleMatchPolicy.countRejected(sourceStatuses) +
            VargaRuleMatchPolicy.countRejected(computedStatuses);
        final pending = VargaRuleMatchPolicy.countPending(sourceStatuses) +
            VargaRuleMatchPolicy.countPending(computedStatuses);
        return Card(
          color: const Color(0xFFF1F5FB),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(10, 12, 10, 12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('D$factor — మొత్తం ${topics.length} అంశాలు • IF–THEN పరిశీలన',
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900,
                    color: Color(0xFF12315E))),
              const SizedBox(height: 5),
              const Text('అంశం తెరిస్తే 1. మూల రూల్ → 2. గ్రహ/భావ పరిశీలన → '
                  '3. ధృవీకరించిన ఫలితం హైలైట్ → 4. మూల పరిహారం (ఉంటే). '
                  'సరిపోని/పెండింగ్ రూల్స్ ఫలితాలు కావు.',
                  style: TextStyle(fontSize: 12, height: 1.45)),
              const SizedBox(height: 5),
              if (factor == 10)
                Text('D10 వృత్తి మూలనియమాలు పరీక్షించినవి: '
                    '${d10AllSourceChecks.length}. పూర్తి మ్యాచ్‌లు: '
                    '${d10SourceMatches.length}. సరిపోని/పాక్షిక ఆధారాలు '
                    'అంశాల్లో ప్రత్యేక పరిశీలనగా ఉంటాయి.',
                  style: const TextStyle(fontSize: 12,
                      color: Color(0xFF415269))),
              Text('ఈ జాతకానికి పరీక్షించి సరిపోయినవి: '
                  '${computedMatched + sourceMatched + (factor == 10 ? d10SourceMatches.length : 0)} • '
                  'ఇంజన్ ఆధారాలు $computedMatched • '
                  'మూలపట్టిక + అనుబంధ గణన $sourceMatched. '
                  '${factor == 10 ? 'పూర్తి D10 వృత్తి మూల మ్యాచ్‌లు ${d10SourceMatches.length}. ' : ''}'
                  'సరిపోని: $unMatched • పెండింగ్/పరిశీలన: $pending. '
                  'ఇవి Rule Match సంఖ్యలు; సంఘటనల హామీ కాదు.',
                  style: const TextStyle(fontSize: 12, color: Color(0xFF415269))),
              if (!snapshot.hasData)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: snapshot.hasError
                      ? const Text('మూల 255 నియమాల జాబితా తెరవడంలో సమస్య. '
                          'ఇంజన్ ఆధారాలు మాత్రమే చూపుతున్నాం.',
                          style: TextStyle(color: Color(0xFFAA3355)))
                      : const LinearProgressIndicator(),
                ),
              const SizedBox(height: 7),
              if (avIssue != null)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  child: Text(avIssue, style: const TextStyle(
                      fontSize: 12, color: Color(0xFFAF334F))),
                ),
              for (var i = 0; i < topics.length; i++)
                _item(title: topics[i].title, calculated: calcGroups[i],
                    sources: sourceGroups[i],
                    av: avReport, topicHouse: topics[i].house,
                    vruttiMatched: factor == 10
                        ? D10TopicRuleBridge.forTopic(
                            topics[i].title, d10SourceMatches)
                        : const <D10VruttiMatch>[],
                    vruttiAudit: factor == 10
                        ? D10TopicRuleBridge.auditForTopic(
                            topics[i].title, d10AllSourceChecks)
                        : const <D10VruttiMatch>[]),
              if (calcOther.isNotEmpty || sourceOther.isNotEmpty)
                _item(title: 'ఇతర మూల నియమాలు • ప్రత్యేక అంశాలు',
                    calculated: calcOther, sources: sourceOther),
              // Keep original computed/source IF–THEN items ahead of AV overview.
              // Per-topic AV evidence remains inside each topic, after matches.
              if (avReport != null) VargaAshtakavargaPanel(report: avReport),
              if (const {5, 6, 8}.contains(factor))
                const Padding(
                  padding: EdgeInsets.all(8),
                  child: Text('D5/D6/D8లో మూల IF పూర్తిగా గణించగలిగిన '
                    'నియమాలనే మ్యాచ్ చేస్తాం. Goel గారి ప్రత్యామ్నాయ '
                    'వర్గ పద్ధతులు పూర్తిగా ధృవీకరించేవరకు వాటి ఫలితాలు '
                    'ఈ లెక్కలో చేర్చం.',
                    style: TextStyle(color: Color(0xFF8C5A1F), fontSize: 12))),
            ]),
          ),
        );
      },
    );
  }
}
