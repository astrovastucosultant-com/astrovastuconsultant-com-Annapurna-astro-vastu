import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/marriage_book_rule_engine.dart';
import '../astrology/marriage_rules_ok_registry.dart';
import '../astrology/marriage_verified_sutra_engine.dart';
import 'marriage_reviewed_sources_screen.dart';
import 'marriage_rule_drill_down.dart';

enum MarriageBookTopicScope { all, individual, matching }

/// An audited source register with chart observations and source-verified
/// predicates; headings are not treated as 62 automatically passed rules.
class MarriageBookTopicsScreen extends StatefulWidget {
  final MarriageBookTopicScope scope;
  final AstroChartResult? chart;
  final AstroChartResult? partnerChart;

  const MarriageBookTopicsScreen({
    super.key,
    this.scope = MarriageBookTopicScope.all,
    this.chart,
    this.partnerChart,
  });

  @override
  State<MarriageBookTopicsScreen> createState() =>
      _MarriageBookTopicsScreenState();
}

class _MarriageBookTopicsScreenState extends State<MarriageBookTopicsScreen> {
  String query = '';
  bool showOnlyDecisive = false;

  @override
  Widget build(BuildContext context) {
    final topics = switch (widget.scope) {
      MarriageBookTopicScope.all => MarriageRulesOkRegistry.topics,
      MarriageBookTopicScope.individual => MarriageRulesOkRegistry.forIndividual(),
      MarriageBookTopicScope.matching => MarriageRulesOkRegistry.forMatching(),
    };
    final evaluations = {
      for (final topic in topics) topic.id: MarriageBookRuleEngine.evaluate(
        topic, chart: widget.chart, partnerChart: widget.partnerChart),
    };
    final checked = evaluations.values.where((r) => r.decisive).length;
    final observed = evaluations.values.where((r) => r.hasChartObservation && !r.decisive).length;
    final missing = evaluations.values.where((r) =>
        r.status == MarriageBookEvaluationStatus.missingChart ||
        r.status == MarriageBookEvaluationStatus.missingPartner).length;
    final q = query.toLowerCase().trim();
    final visible = topics.where((r) =>
        (q.isEmpty || r.id.toLowerCase().contains(q) ||
          r.title.toLowerCase().contains(q) ||
          r.focus.toLowerCase().contains(q) || '${r.page}'.contains(q)) &&
        (!showOnlyDecisive || evaluations[r.id]!.decisive),
      ).toList(growable: false);

    return Scaffold(
      appBar: AppBar(title: const Text('వివాహ గ్రంథం — నియమాల పరిశీలన')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(ReviewedMarriageSources.reviewer,
                style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('Marrage rules ok.pdf — 39 మూల పేజీలు. '
                'పూర్తి గ్రంథ సూచికలోని 62 అంశాలను విడిగా చూపిస్తున్నాం.'),
            const SizedBox(height: 8),
            Text('మొత్తం: ${topics.length} • పూర్తి మూల-షరతు గణన: $checked • '
                'జాతక స్థితులు మాత్రమే: $observed • జాతకం అవసరం: $missing • '
                'పూర్తి సూత్రం పెండింగ్: ${topics.length-checked-observed-missing}',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Text(widget.chart == null
              ? 'ఈ గ్రంథ సూచికకు జాతకం ఇవ్వలేదు. D9 నుంచి వచ్చి జాతకంతో పరీక్షించండి.'
              : widget.scope == MarriageBookTopicScope.matching && widget.partnerChart == null
                ? 'పొంతనలో రెండో జాతకం ఇంకా లేదు. Saved Chartsలో ఎంపిక చేసి జాతకంతో ఈ పేజీ తెరవండి.'
                : 'జాతక ఆధారాలు అందుబాటులో ఉన్నాయి. మూల సూత్రం ధృవీకరించిన వాటికే రంగుతో ఫలితం వస్తుంది.',
              style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 7),
            const Text('గమనిక: 62 అంశాలు = 62 ధృవీకరించిన IF–THEN రూల్స్ కావు. '
                'గ్రహస్థితి కనిపించడం వివాహ సంఘటనకు హామీ కాదు. '
                'మూలంలోని అస్పష్ట భాగాలు పెండింగ్‌గా ఉంటాయి.',
                style: TextStyle(fontSize: 12.5)),
          ],
        ))),
        if (widget.scope != MarriageBookTopicScope.matching)
          _VerifiedSourceSubrules(chart: widget.chart),
        TextField(
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            labelText: 'నియమం, అంశం లేదా పేజీ వెతకండి',
            border: OutlineInputBorder(),
          ),
          onChanged: (v) => setState(() => query = v),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('పూర్తిగా గణించిన నియమాలు మాత్రమే'),
          subtitle: const Text('పెండింగ్ అంశాలను దాచుతుంది; తొలగించదు'),
          value: showOnlyDecisive,
          onChanged: (v) => setState(() => showOnlyDecisive = v),
        ),
        Text('చూపిస్తున్నవి ${visible.length} / ${topics.length}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        for (final r in visible)
          Builder(builder: (context) {
            final eval = evaluations[r.id]!;
            final color = eval.decisive
                ? eval.favourable == true ? Colors.green.shade700 : Colors.deepOrange.shade700
                : Colors.blueGrey;
            final state = eval.decisive
                ? eval.favourable == true ? 'ఈ మూల ఉపషరతు సరిపోయింది' : 'మూల ఉపషరతు సరిపోలలేదు / హెచ్చరిక ఉంది'
                : eval.status == MarriageBookEvaluationStatus.missingPartner
                    ? 'రెండవ జాతకం అవసరం'
                    : eval.status == MarriageBookEvaluationStatus.missingChart
                        ? 'జాతకం అవసరం'
                        : eval.status == MarriageBookEvaluationStatus.chartObserved
                            ? 'పాక్షిక గణన • తుది తీర్పు కాదు'
                            : 'IF–THEN మూల ధృవీకరణ పెండింగ్';
            return Card(child: ExpansionTile(
              key: ValueKey(r.id),
              title: Text('${r.id} — ${r.title}'),
              subtitle: Text('పుట ${r.page} • $state',
                style: TextStyle(color: color)),
              childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
              children: [
                if (r.page >= 12 && r.page <= 16)
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    child: Text('ఈ పేజీలకు పాత అంశాల సూచికలో పేర్ల భేదం గుర్తించబడింది. '
                      'నిర్ధారణకు అసలు పేజీ–సూత్ర సంఖ్యను చూడండి; '
                      'సూచిక శీర్షిక ఆధారంగా ఫలితం గణించలేదు.',
                      style: TextStyle(color: Colors.deepOrange)),
                  ),
                MarriageRuleDrillDown(
                  resultText: eval.result,
                  resultIsComputed: eval.decisive,
                  favourable: eval.favourable,
                  ruleText: eval.rule,
                  sourceText: '${MarriageRulesOkRegistry.sourceName} • పుట ${r.page}',
                  onOpenSource: () => ReviewedMarriageSources.openPage(
                    context, ReviewedMarriageSources.marriageRules, r.page),
                  examinationText: eval.examination,
                  remedyText: eval.remedy,
                ),
                InkWell(
                  onTap: () => ReviewedMarriageSources.openPage(
                      context, ReviewedMarriageSources.marriageRules, r.page),
                  child: Image.asset(
                    ReviewedMarriageSources.assetPath(
                        ReviewedMarriageSources.marriageRules, r.page),
                    height: 200,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) =>
                        const Text('అసలు మూల పేజీ అందుబాటులో లేదు'),
                  ),
                ),
              ],
            ));
          }),
      ]),
    );
  }
}

/// Direct PDF page/sutra subrules. Deliberately separate from the older
/// 62 subject headings, some of which have inaccurate historical names.
class _VerifiedSourceSubrules extends StatelessWidget {
  final AstroChartResult? chart;
  const _VerifiedSourceSubrules({this.chart});

  @override
  Widget build(BuildContext context) {
    final rules = MarriageVerifiedSutraEngine.sutras;
    final results = {
      for (final r in rules)
        r.id: MarriageVerifiedSutraEngine.evaluate(r.id, chart),
    };
    final computed = results.values.where((r) => r.computed).length;
    return Card(
      child: ExpansionTile(
        title: const Text('అసలు పుట–సూత్రం ఆధారంగా ధృవీకరించిన ఉపనియమాలు',
          style: TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${rules.length} ప్రత్యేక IF–THEN స్థాన పరీక్షలు • '
          '$computed గణించబడ్డాయి. ఇవి 62 గ్రంథ అంశాలకు అదనం; '
          'వివాహానికి పూర్తి తీర్పు కాదు.'),
        childrenPadding: const EdgeInsets.all(6),
        children: [
          for (final r in rules)
            Builder(builder: (context) {
              final result = results[r.id]!;
              final color = !result.computed
                  ? Colors.blueGrey
                  : result.matched ? Colors.green.shade700 : Colors.deepOrange;
              return ExpansionTile(
                key: ValueKey('sutra_${r.id}'),
                title: Text('${r.id} — ${r.title}'),
                subtitle: Text('PDF పుట ${r.page} • '
                    '${result.computed ? result.matched ? "ఉపషరతు సరిపోయింది" : "ఉపషరతు సరిపోలేదు" : "డేటా / పరీక్ష పెండింగ్"}',
                  style: TextStyle(color: color)),
                children: [
                  MarriageRuleDrillDown(
                    resultText: result.result,
                    resultIsComputed: result.computed,
                    favourable: result.computed ? result.matched : null,
                    ruleText: '${r.sourceCondition}\n\n${r.interpretation}',
                    sourceText: '${MarriageVerifiedSutraEngine.sourceName} • PDF పుట ${r.page}',
                    onOpenSource: () => ReviewedMarriageSources.openPage(
                      context, ReviewedMarriageSources.marriageRules, r.page),
                    examinationText: result.evidence,
                    remedyText: 'ఈ సూత్రంతో ధృవీకరించిన పరిహారం మూలంలో లేదు. '
                      'ఊహించిన పరిహారాన్ని జోడించలేదు.',
                  ),
                ],
              );
            }),
        ],
      ),
    );
  }
}
