ANNAPURNA ASTRO VASTU — V49 + V50 APP PACKAGE

ఈ ZIPలో:
1. index.html = V50 Latest Combined Main File
2. versions/Annapurna_Astro_Vastu_V49_Varga_Result_Rule_Remedy.html = V49 backup/reference
3. versions/Annapurna_Astro_Vastu_V50_Source_Rulebooks.html = V50 original file

V50, V49 ఆధారంగా తయారైన తాజా version. అందువల్ల app main entryగా index.html (V50) ఉంచబడింది.
V49 fileను backup/reference కోసం packageలో అలాగే ఉంచాం.

Main flow:
Varga / Topic -> Applied Result -> Rule -> Remedy / Guidance

GitHub/App projectలో integrate చేయేటప్పుడు existing index/main entryకి ఈ index.htmlని use చేయవచ్చు. Existing Android wrapper/Capacitor/other project structure ఉంటే, దాని web rootలో index.htmlగా merge చేయాలి.
