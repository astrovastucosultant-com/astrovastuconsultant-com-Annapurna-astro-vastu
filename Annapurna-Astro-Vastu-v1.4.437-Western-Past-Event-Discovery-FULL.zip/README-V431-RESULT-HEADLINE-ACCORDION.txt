Annapurna Astro Vastu v1.4.431 — Result-First, Collapsible Cross-Varga Review

SOURCE
  Based on v1.4.430 FULL ZIP supplied in the project library.
  This package includes the complete astro_app/ Flutter tree.

CHANGES
  1. TopicResultCard391 (shared cross-varga review for registered vargas):
     - Top-level verified evidence headline first.
     - D1/D9/D10 and other required vargas are collapsed, selectable headlines.
     - Open one heading to inspect its rule ID, rule, natal examination,
       matched-only result, and source; remedies remain source-gated.
     - Identical rule prose shared across multiple stages is printed only
       once under a separate 'common source rules' expansion.
     - Career: D10 is primary; D1/D9 supporting. Pending or unmatched D10
       cannot be transformed into a definite profession prediction.
     - Matched/Not Matched/Pending remain distinct; event probability is
       never equated to chart coverage percent.
     - Source charts and marriage-specialized inspection remain available.
  2. TopicResultCard398 (other multi-chart topic result details):
     - Existing conclusions remain immediately visible.
     - Long per-varga audit and each source rule open on tap only.
     - Additional client guidance and method notes collapsed by default.
  3. New read-only TopicInspectionHeadline431 model, with regression tests.

NOT CHANGED
  - D1, D9, D10 planetary longitudes and chart calculation.
  - Rule matching and IF–THEN sources, remedial text source gates,
    special topic engine assessments, Jamakola/Tajik/KP isolation.
  - Saved-chart migrations and chart export calculations.

TEST LIMITATION
  Static source/package checks completed in the generating environment.
  Flutter SDK is not present there. GitHub Actions YAML runs Flutter tests
  and creates APK only when tests succeed. Never treat a packaged ZIP as
  a successful Android build until Actions reports success.
