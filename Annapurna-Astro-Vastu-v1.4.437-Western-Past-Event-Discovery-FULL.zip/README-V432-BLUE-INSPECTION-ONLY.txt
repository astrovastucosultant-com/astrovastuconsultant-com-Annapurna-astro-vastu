Annapurna Astro Vastu — v1.4.432 Blue Scope Correction

VISUAL ONLY — underlying rule matching, source references and calculations are unchanged.
- Blue (heading and pale-blue panel) is exclusively for the "జాతక పరిశీలన" presentation.
- Rule headings, IF/THEN source text, rule IDs and chart headings use neutral ink, not blue.
- Matched favourable results retain green; matched adverse results retain pink.
- Pending, not-matched and status labels retain their original semantic colours.
- Accordion opens on touch. The source rule remains separate from inspection.

Files changed:
- lib/screens/rule_inspection_highlight_v432.dart
- lib/screens/topic_varga_review_panel.dart
- lib/screens/topic_result_card_v391.dart
- lib/screens/topic_result_card_v398.dart
- test/rule_inspection_blue_only_v432_test.dart (new)

This is a SOURCE update, not an APK. Run `flutter test test/rule_inspection_blue_only_v432_test.dart`,
then relevant existing tests and a release build on a Flutter-enabled system.
Pubspec version is preserved from the supplied v1.4.432 source, as requested for a UI-only patch.
