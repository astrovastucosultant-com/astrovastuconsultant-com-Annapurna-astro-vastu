Annapurna Astro Vastu v1.4.429 — Jamakola UI order + topic customization
1. Jamakola view: Jama chart -> Udayam -> Arudam -> Kavippu -> geometric touch status -> rules verdict.
2. Full calculations, inner chart, 300 nimittas and evidence review stay collapsed.
3. Standalone Jamakola rule results use only source JA-* rules from assets/jamakola/rules.json, filtered by one or multiple chosen categories. KP/Tajik evidence is excluded from this page.
4. Combined Prashna tab is separate: Jamakola + KP + Tajik evidence for one supported KP event; user can filter topic categories and enter a free-text topic label.
5. Free-text custom topic does NOT generate new IF/THEN rules or guarantee a verdict. Source-based unknowns remain pending.
6. All other varga, marriage, chart and KP modules preserved unchanged.
7. Flutter tests and Android build must be run in GitHub Actions. Mobile behavior not yet verified.
