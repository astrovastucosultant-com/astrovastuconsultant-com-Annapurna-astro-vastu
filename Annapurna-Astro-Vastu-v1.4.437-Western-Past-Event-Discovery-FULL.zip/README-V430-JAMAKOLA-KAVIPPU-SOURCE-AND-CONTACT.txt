Annapurna Astro Vastu v1.4.430 -- Jamakola Kavippu geometry audit and automatic contact

Method: selected public Jamakkol/Vaidyanathan mirrored-Arudam degree.
The sign from Udhayam, Arudam and Sun Veedhi; degree in sign = (30 - Arudam-in-sign) mod 30.
Public sample: 13 Nov 2026, U Pisces 3d58m, Arudam Gemini 20d24m, Veedhi Taurus => Kavippu Aquarius 9d36m.
Exact angular display: within 1 arc-minute = software proximity, NOT traditional prescribed orb.
Next retrograde direction: find smallest positive arc moving backwards from Kavippu to jama marker; not an event time prediction.
A manually entered total Kavippu longitude takes precedence; manual sign alone suppresses auto precise contact.
Jamakola JA rule engine stays unchanged; KP and Tajik only in separate combined module.
Sources: https://www.hindupanchangam.in/en/tools/jamakol-prasannam/
https://rajvidya.com/wiki/article/udhayam-aarudam-kavippu-three-pillars-of-jamakol/

No astronomical validation of alternative U+V-A method, and no traditional touch interpretation is claimed.
Tests need Flutter CI; no local Flutter SDK available.
