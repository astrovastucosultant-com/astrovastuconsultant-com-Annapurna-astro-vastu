Annapurna Astro Vastu v1.4.433 — Western Timing / BTR settings

Implemented:
- Western Progression tab includes Transit ON/OFF (default ON).
- Select Secondary Progression, Solar Arc, Progressed Moon independently.
- Transit configuration retains planet/aspect selections and 0.5, 1 or 2 degree orb.
- Configuration is persisted locally via shared_preferences and Reset restores defaults.
- The same settings apply to the Timing of Event and BTR views.
- A typed evidence filter excludes all Transit evidence when OFF and rejects unverifiable transit contacts.
- Existing v432 inspection color fixes and test fixtures were integrated into source.

Not implemented:
- Calculation of progressed positions, Solar Arc directions, transits, exact event dates, BTR matching.
- Existing Western tab was only a placeholder, without an underlying timing engine.
- No event prediction, probability or verified timing result is displayed.

Test: test/western_timing_settings_v433_test.dart
