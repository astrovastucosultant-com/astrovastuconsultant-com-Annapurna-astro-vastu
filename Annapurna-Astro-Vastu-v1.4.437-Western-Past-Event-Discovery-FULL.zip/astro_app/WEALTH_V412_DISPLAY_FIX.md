# v412: wealth result and source-label corrections

Screenshots from the installed v411 app showed a retention-risk rule presented as a definitive overall wealth level, and general devotional references labelled as personally applicable.

The summary now separates positive wealth levels from ST-004 retention caution. Without a positive level match it says the wealth amount level is undetermined. Original source wording and rule conditions remain unchanged in full details. Counts explicitly refer to the six evaluated named yoga tests; zero is not a statement that income or wealth is absent.

All four general-reference sections (Bansal perception, Bansal Mahavidya transcript, tantric wealth practices, MahaVastu) use source-only status and evidence labels. Pending Ketu NE-upper reference remains pending. General guidance is shown after chart-analysis sections. Repeated implementation provenance is removed from each detail sheet and retained once in the existing definitions expansion.

Pure-Dart regressions include source-versus-chart labels and retention-summary checks. Flutter widget checks updated for source labels; local Flutter runtime unavailable, CI remains required for UI/APK validation.
