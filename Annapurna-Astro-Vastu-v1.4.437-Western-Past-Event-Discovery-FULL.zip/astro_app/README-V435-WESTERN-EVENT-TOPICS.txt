Annapurna Astro Vastu v1.4.435 — Western-only Timing of Event topics

Scope: Western only. No Lahiri/Sidereal interpretation, Parashara, KP,
Jaimini, Nakshatra, Varga, Dasha, BNN, BSP, BCP or other Indian astrology
rules are evaluated in this Western Timing module.

The Western event catalog presents 12 thematic areas (relationship, career,
business/partnership, promotion, finance, property/home, children/creativity,
education, travel, relocation, wellbeing/routine, retirement/career change).

Matching uses independently calculated Swiss Ephemeris Tropical natal planetary
positions, Tropical Placidus house cusps and traditional Western domicile
rulers, alongside the previously implemented secondary progressions, solar arc
directions, progressed Moon and optional transits. Existing daily sampled
contacts (not exact event instants) are filtered by each event's 4th/5th/7th/
10th etc Western house areas, house-ruler contact, and selected natural planet
symbolism. The rule IDs WEST-EVENT-...-435 identify thematic app filters;
they are not claimed as verbatim historical textual quotations.

Verified Western source trace IDs (source descriptions are paraphrases, not
verbatim, universally deterministic rules):
- WEST-SRC-HOUSES — Astrodienst, House domains (all topic domains except REL):
  https://www.astro.com/astrowiki/en/Houses
- WEST-SRC-REL-2019 — Michele Adler, Predicting for Relationships,
  on Astrodienst (REL topic specifically):
  https://www.astro.com/astrology/iam_article190812_e.htm
- WEST-SRC-RULER — Western traditional cusp sign rulers:
  https://www.astro.com/astrowiki/en/Sign_Ruler
- WEST-SRC-SECONDARY — Day-for-a-year secondary progression:
  https://www.astro.com/astrowiki/en/Secondary_Directions
- WEST-SRC-SOLAR — Solar Arc chart method:
  https://www.astro.com/faq/fq_fh_owtype_s.htm?lang=e&nhor=12
- WEST-SRC-TRANSIT — Natal chart contacts and major aspects:
  https://www.astro.com/astrowiki/en/Transit
- Interpretation cross-check, Cafe Astrology houses:
  https://cafeastrology.com/articles/housesofthehoroscope.html

The app's WEST-EVENT IF/THEN is a derived *topic-selection filter* based on
those Western house and timing descriptions, NOT an exact quotation or
independently verified rule for each personal event.


Accuracy limits:
- The month overview labels trine/sextile facilitative, square/opposition
  challenging and conjunction contextual. This describes the traditional
  Western *aspect tone*, not whether a real event will happen or be good/bad.
  No percentages of future outcome are fabricated.
- Existing daily scanning is one sample each civil noon (at a fixed UTC
  offset), not the exact moment of an aspect.
- If Placidus cusps cannot be calculated (e.g. polar region), report this and
  use planet symbolism only, rather than making up houses.
- BTR and complete Western multi-method event forecasting remain separate
  future implementation work; this release adds typed EVENT filtering.
- Transits OFF excludes transits while preserving progression evidence.
- Blue is used only for the inspection details, never for rule IDs.

Current source version: 1.4.435+435. Compilation/installation are to be
validated in the GitHub Actions build and on a device.
