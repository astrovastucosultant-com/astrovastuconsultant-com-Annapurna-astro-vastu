# v1.4.416 — Varga review display

Based on v1.4.415 full source. Retains automatic bala implementation.

Changes:
- Topic cards use available width and actual text scaling to choose 1–3 columns.
- South Indian chart cells fit all planet labels, grouped in pairs; no ellipsis.
- Inspection summaries are fully visible.
- Topic name appears above its charts.
- Longevity source workflow IDs and source outcomes remain visible even while incomplete. D2/D3 explicitly disclose that full mathematical procedures are absent from the source catalog.
- No pending rule was promoted to a match; no longevity totals or new astrological rules were invented.

Validation: reviewed changed source and ZIP integrity; verified original source catalog IDs 045–047 and their workflow-only status. Flutter/Dart unavailable in this workspace; compilation, widget tests, APK and device visual verification remain outstanding. This ZIP is source, not an APK. Previous generated workflow embeds v415 and does not automatically include this source update.

Web research integration: BPHS chapter 43, verses 61, 64 and 69 are independent D1 checks with exact AND/OR conditions, Parashari Jupiter aspects, whole-sign conjunctions and sign-level exaltation. Each output cites the source URL and verse. They do not produce a completed lifespan calculation. D2/D3 mathematical methods were located in BPHS 43.4–32, but full deductions, strength comparisons and integration are outstanding. D8 source workflow remains pending. Added tool/verify_longevity_v416.dart with 10 targeted checks; not run because Dart SDK is unavailable.

Source URL: https://sanskritdocuments.org/doc_z_misc_sociology_astrology/horaashaastraEng34-45.html
