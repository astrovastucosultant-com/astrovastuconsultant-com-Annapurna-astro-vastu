Annapurna Astro Vastu 1.4.434 — Western Tropical Aspect Timing (Stage 1)

Built from v1.4.433 FULL source. New geometry module:
 lib/astrology/western_timing_engine_v434.dart
 UI: lib/screens/western_timing_tab.dart; chart_screen.dart passes BirthData.
 Tests: test/western_timing_engine_v434_test.dart

METHOD
- Tropical geocentric ecliptic longitude, Swiss Ephemeris (Moshier), SEFLG_SIDEREAL NOT set.
- Natal UT derived from saved BirthData UTC offset. For each selected local civil day
  in a month, sample at 12:00 using the recorded fixed birth UTC offset.
- Secondary progression: progressed ephemeris date = birth UTC +
  (elapsed real UTC days / 365.2425) ephemeris days.
- Solar Arc: longitude = natal longitude + (secondary progressed Sun - natal Sun).
- Progressed Moon: secondary Moon separately; never double counted in secondary.
- Transits: only selected planets/aspects when Transits ON. When OFF they are not
  computed or included in the report. Orb setting applies to all calculated contacts.
- Aspect angles: 0, 60, 90, 120, 180 degrees, minimum wrapped angular separation.
- Matched daily contacts merged into consecutive-day intervals. Report lists 35 best
  windows by minimum sampled orb, not event-specific forecasts.
- Longitudes are TROPICAL, separate from the Lahiri/KP sidereal chart view.

STATUS & LIMITATIONS
- Event-specific rule matching, exact aspect instants, timing verdict, probability,
  birth-time rectification and precise BTR candidate scoring NOT implemented.
- Daily-noon sampling can miss brief contacts (especially Moon or fast transits).
- Birth timezone is a fixed UTC offset, not historic DST. Event date window is
  a local civil calendar sampled at noon with the stored birth UTC offset.
- The geometry/source ID WEST-*-434 is an application calculation tag, not a
  purported classical or publisher quotation.
- An aspect being present is NOT evidence an event must occur.
- Always report no evidence rather than inventing an event or remedy.

CALCULATION REFERENCES
 https://www.astro.com/swisseph/swephprg.htm
 https://www.astro.com/faq/fq_fh_owtype_e.htm
