# v414: strength summary at Gem Remedy

Gem Remedy now opens with three vertical bar groups and expandable numeric tables, matching the supplied layout: Shadvarga Vimsopaka for nine grahas, Shadbala for seven classical planets, and Bhava Bala for twelve houses. Bars keep stable planet/house order, units, percentages and Roman competition ranks. Horizontal scrolling preserves readable widths on phones.

Vimsopaka uses the existing PlanetDetailService Shadvarga calculation automatically, displayed as /20 and genuine percent of 20. App color cutoff is explicitly 10/20. Shadbala colors and rank use total rupas / required rupas, consistent with the existing app convention Sun 6.5, Moon 6, Mars 5, Mercury 7, Jupiter 6.5, Venus 5.5, Saturn 5. For example Moon 9.48/6 is 158%, not 1.58%. Rahu and Ketu are excluded from classical Shadbala. Bhava rank uses rupas; no universal red/green cutoff is invented.

IMPORTANT LIMITATION: the existing app does not implement the full six-part classical Shadbala engine or the complete classical Bhava Bala engine. This release does not pretend otherwise or substitute Vimsopaka/SAV for those calculations. Verified report totals can be entered in rupas, with a source label. Missing is unknown, not zero or weak. Sixty virupas equal one rupa. No screenshot totals are prefilled into a client's chart.

Verified inputs are saved using the existing AnnapurnaPrefs backend, keyed by exact chart JD, coordinates, ayanamsa, ascendant and planet longitudes. Chart changes clear stale inputs. Async loads/saves are generation guarded and storage failures are visible. Existing GemRemedyService selection/restriction rules are retained; these charts do not automatically recommend a stone for every weak planet.

Validation: 33 focused pure-Dart checks cover sample ratio ranks, correct percent units, boundaries, missing/zero distinction, nodes, source-required storage, malformed/wrong-unit rejection, ties and chart isolation. Flutter tests cover domains, saved loading, source-backed input saving, remount persistence and 320px/large Telugu text. Flutter/APK execution remains pending GitHub Actions.

Reference for separating strength systems: P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach, chapter 15.3 (printed p189), https://www.vedicastrologer.org/articles/vedic_astro_textbook.pdf. It explicitly distinguishes Shadbala and Ashtakavarga and refers detailed Shadbala arithmetic to BPHS / B.V. Raman, not an interchangeable proxy.
