ANNAPURNA ASTRO VASTU v1.4.437 — WESTERN PAST EVENT DISCOVERY

Scope: Three candidate EVENT-YEAR shortlists, using ONLY Western tropical
Placidus natal houses, traditional domicile lords, secondary progression,
progressed Moon, solar arc directions, plus optional user-selected transits.
Indian dashas, KP, BNN, vargas, and nakshatras are never involved.

User flow:
  Western Progression > Past Event Discovery > set start age >
  search historical candidate years > choose event/year >
  review selected 12 calendar months with the existing DAILY scanner.

HOW IT COMPUTES
- Historical screening samples ONE DAY PER MONTH (15th at local 12:00),
  not all days; this is a shortlist, NOT an exhaustive day-level event search.
- One (method, moving body, natal target, aspect) is counted only once per year,
  retaining the sampled month with smallest orb.
- Direct core evidence requires a topical house ruler, occupant, or angle.
  Natural planets without topical house support cannot generate a candidate.
- Candidate years are ranked by matched core evidence, independent methods,
  independent targets, and orb proximity. The score is ONLY ordering points;
  there is no probability, no event certainty, no automatic historical labels.
- Underage marriage candidates are excluded by existing age-presentation
  rule for India, separate from astrology; gender unknown at 18-20 is not guessed.
- The software CANNOT establish actual marriage, first child's birth,
  or first job merely from an aspect. Birth records or client validation
  are required for backtesting; none are fed to the blind scanner.

WESTERN SOURCE REFERENCES
Marriage/relationships: Michele Adler, Predicting for Relationships (2019)
https://www.astro.com/astrology/iam_article190812_e.htm
Children/family: The Astrology of Pregnancy (2015)
https://www.astro.com/astrology/tma_article150203_e.htm
Career/job: Vocational Astrology in a Pandemic Era (2020)
https://www.astro.com/astrology/opa_article200814_e.htm
These are source references for symbolism; NOT claims that the app's
multi-criteria IF-THEN ranking is taken verbatim from those sources.

RULE STORE (used live, not just audit backup):
assets/western/western_past_event_rules_v437.json

RULE ENGINE:
lib/astrology/western_past_event_discovery_v437.dart

UI:
lib/screens/western_timing_tab.dart

Tests:
test/western_past_event_discovery_v437_test.dart

Change to existing scanner:
lib/astrology/western_timing_engine_v434.dart adds *optional* screeningDay
and includeNatalAngles. Both are OFF by default, preserving v434-v436
exhaustive daily scan behavior. No BTR algorithm was added or modified.

Build not compiled within the ChatGPT container (Flutter SDK unavailable).
GitHub workflow must run Flutter tests and a release APK build.
