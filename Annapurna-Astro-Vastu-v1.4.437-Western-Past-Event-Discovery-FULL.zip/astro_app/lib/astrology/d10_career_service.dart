import 'astro_models.dart';
import 'dasha_service.dart';
import 'varga_service.dart';

enum D10CareerTone { favorable, caution, neutral }

class D10CareerWindow {
  final String eventKey;
  final String title;
  final DateTime start;
  final DateTime end;
  final String mahadasha;
  final String antardasha;
  final int score;
  final D10CareerTone tone;
  final String reason;
  final List<String> ruleIds;

  const D10CareerWindow({
    required this.eventKey,
    required this.title,
    required this.start,
    required this.end,
    required this.mahadasha,
    required this.antardasha,
    required this.score,
    required this.tone,
    required this.reason,
    required this.ruleIds,
  });
}

class D10SaturnStream {
  final String birthState;
  final String navamsaState;
  final String dashamsaState;
  final String result;
  final String reason;
  final bool governmentAdministrativeSupport;

  const D10SaturnStream({
    required this.birthState,
    required this.navamsaState,
    required this.dashamsaState,
    required this.result,
    required this.reason,
    required this.governmentAdministrativeSupport,
  });
}

class D10DevataProfile {
  final String deity;
  final String direction;
  final String sourceMeaning;
  final String workflowModifier;
  final List<String> professionGroups;

  const D10DevataProfile({
    required this.deity,
    required this.direction,
    required this.sourceMeaning,
    required this.workflowModifier,
    required this.professionGroups,
  });
}

/// Each foreign-job source condition is separately auditable. A single
/// indicator in each chart is NOT sufficient to assert the printed rule.
class D10ForeignRuleCheck {
  final String label;
  final bool passed;
  const D10ForeignRuleCheck(this.label, this.passed);
}

class D10ForeignPromiseEvidence {
  final List<D10ForeignRuleCheck> checks;
  const D10ForeignPromiseEvidence(this.checks);

  /// Conservative AND gate: all explicit birth + D10 prerequisites must hold.
  /// This is a rule match, not a promise that foreign employment will occur.
  bool get fullRuleMatched => checks.length == 7 &&
      checks.every((check) => check.passed);
  int get passedCount => checks.where((check) => check.passed).length;
  String get audit => [
    for (final check in checks)
      '${check.passed ? 'YES' : 'NO'} • ${check.label}',
    'పూర్తి IF–THEN షరతులు: $passedCount/${checks.length}. '
        '${fullRuleMatched ? 'మూల షరతుల మ్యాచ్ ఉంది; దశా సమయం విడిగా పరీక్షించాలి.' : 'పాక్షిక ఆధారాలు మాత్రమే; విదేశీ ఉద్యోగం నిర్ధారణ కాలేదు.'}',
  ].join('\n');
}

/// Source-bound D10 career timing layer from the supplied "D10 special.pdf".
///
/// The service intentionally separates (a) static promise from (b) dasha timing.
/// It uses source-defined houses/lords and only standard conjunction / classical
/// graha drishti as relationship checks. It does not invent missing nakshatra
/// profession tables or Progress-Yogini arithmetic.
class D10CareerService {
  static const _lords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];

  static int signLordIndex(int sign) => sign % 12;
  static String signLord(int sign) => _lords[sign % 12];

  static int d1House(AstroChartResult chart, String planet) {
    final p = chart.planets.firstWhere((x) => x.name == planet);
    return ((p.signIndex - chart.ascendantSignIndex + 12) % 12) + 1;
  }

  static int vargaHouse(VargaChartData v, String planet) {
    final p = v.planets.firstWhere((x) => x.name == planet);
    return ((p.signIndex - v.ascendantSignIndex + 12) % 12) + 1;
  }

  static int houseSignD1(AstroChartResult chart, int house) =>
      (chart.ascendantSignIndex + house - 1) % 12;

  static int houseSignVarga(VargaChartData v, int house) =>
      (v.ascendantSignIndex + house - 1) % 12;

  static bool _aspects(String planet, int fromSign, int toSign) {
    final diff = (toSign - fromSign + 12) % 12;
    if (diff == 6) return true; // universal 7th aspect
    return switch (planet) {
      'Mars' => diff == 3 || diff == 7,
      'Jupiter' => diff == 4 || diff == 8,
      'Saturn' => diff == 2 || diff == 9,
      _ => false,
    };
  }

  static bool relatedD1(AstroChartResult chart, String a, String b) {
    final pa = chart.planets.firstWhere((x) => x.name == a);
    final pb = chart.planets.firstWhere((x) => x.name == b);
    return pa.signIndex == pb.signIndex ||
        _aspects(a, pa.signIndex, pb.signIndex) ||
        _aspects(b, pb.signIndex, pa.signIndex);
  }

  static bool relatedVarga(VargaChartData v, String a, String b) {
    final pa = v.planets.firstWhere((x) => x.name == a);
    final pb = v.planets.firstWhere((x) => x.name == b);
    return pa.signIndex == pb.signIndex ||
        _aspects(a, pa.signIndex, pb.signIndex) ||
        _aspects(b, pb.signIndex, pa.signIndex);
  }

  static bool _inTrika(int house) => house == 6 || house == 8 || house == 12;

  static String _saturnStateFor({
    required int sign,
    required int house,
    required bool withNode,
  }) {
    final strongDignity = sign == 6 || sign == 9 || sign == 10; // Libra exalted; Capricorn/Aquarius own
    final debilitated = sign == 0; // Aries
    // User-supplied Saturn source: any 6/8/12 relation or node/debilitation
    // shifts the D10 profession mode toward Agocharastha. Saturn itself does
    // not create an "administrative" state; authority is judged separately
    // from Sun/Indra support.
    if (debilitated || withNode || _inTrika(house)) return 'AGOCHARASHTHA';
    if (strongDignity) return 'GOCHARASHTHA';
    return 'MIXED';
  }

  static D10SaturnStream saturnStream(AstroChartResult chart) {
    final d9 = VargaService.calculate(chart, 9);
    final d10 = VargaService.calculate(chart, 10);
    final s1 = chart.planets.firstWhere((p) => p.name == 'Saturn');
    final s9 = d9.planets.firstWhere((p) => p.name == 'Saturn');
    final s10 = d10.planets.firstWhere((p) => p.name == 'Saturn');

    bool d1Node() => chart.planets.any((p) =>
        (p.name == 'Rahu' || p.name == 'Ketu') && p.signIndex == s1.signIndex);
    bool vNode(VargaChartData v, int sign) => v.planets.any((p) =>
        (p.name == 'Rahu' || p.name == 'Ketu') && p.signIndex == sign);

    final b = _saturnStateFor(
      sign: s1.signIndex,
      house: d1House(chart, 'Saturn'),
      withNode: d1Node(),
    );
    final n = _saturnStateFor(
      sign: s9.signIndex,
      house: vargaHouse(d9, 'Saturn'),
      withNode: vNode(d9, s9.signIndex),
    );
    final d = _saturnStateFor(
      sign: s10.signIndex,
      house: vargaHouse(d10, 'Saturn'),
      withNode: vNode(d10, s10.signIndex),
    );

    const admin = false;
    String result;
    String reason;
    // User-locked sequence rule (Build 76): D1 shows the initial work mode and
    // D10 shows the later/professional expression. D9 is retained for audit
    // only; it must not override the D1 -> D10 sequence.
    if (b == 'AGOCHARASHTHA' && d == 'GOCHARASHTHA') {
      result = 'ముందు Service / Job → తరువాత Self-employment / Business';
      reason = 'D1 Saturn Agocharastha; D10 Saturn Gocharastha. మొదట ఉద్యోగ/సర్వీస్ విధానం, తరువాత వ్యాపారం/స్వయం ఉపాధి వైపు మార్పు.';
    } else if (b == 'GOCHARASHTHA' && d == 'AGOCHARASHTHA') {
      result = 'ముందు Self-employment / Business → తరువాత Service / Job';
      reason = 'D1 Saturn Gocharastha; D10 Saturn Agocharastha. మొదట వ్యాపారం/స్వయం ఉపాధి, తరువాత ఉద్యోగ/సర్వీస్ వైపు మార్పు.';
    } else if (b == 'GOCHARASHTHA' && d == 'GOCHARASHTHA') {
      result = 'Self-employment / independent stream కొనసాగేందుకు బలమైన support';
      reason = 'D1 మరియు D10 రెండింటిలో Saturn Gocharastha — business/self-employment stream కొనసాగింపు.';
    } else if (b == 'AGOCHARASHTHA' && d == 'AGOCHARASHTHA') {
      result = 'Service / employment stream కొనసాగేందుకు బలమైన support';
      reason = 'D1 మరియు D10 రెండింటిలో Saturn Agocharastha — job/service stream కొనసాగింపు.';
    } else if (d == 'GOCHARASHTHA') {
      result = 'D10లో Self-employment / Business ప్రధాన విధానం';
      reason = 'D1 state mixed/unclear; D10 Saturn Gocharastha కాబట్టి final professional expression business/self-employment వైపు ఉంది.';
    } else if (d == 'AGOCHARASHTHA') {
      result = 'D10లో Service / Job ప్రధాన విధానం';
      reason = 'D1 state mixed/unclear; D10 Saturn Agocharastha కాబట్టి final professional expression job/service వైపు ఉంది.';
    } else {
      result = 'Mixed career stream — Job/Business రెండింటి evidenceను కలిపి చూడాలి';
      reason = 'D1/D10 Saturn state రెండింటిలో final mode స్పష్టంగా నిర్ణయించబడలేదు.';
    }
    reason = '$reason D9 Saturn: $n (audit/support only).';
    if (admin) {
      result = '$result • Government/administrative-level service indication కూడా ఉంది';
    }

    return D10SaturnStream(
      birthState: b,
      navamsaState: n,
      dashamsaState: d,
      result: result,
      reason: reason,
      governmentAdministrativeSupport: admin,
    );
  }

  static D10DevataProfile devataForLongitude(double longitude) {
    final normalized = ((longitude % 360) + 360) % 360;
    final sign = (normalized / 30).floor();
    final degree = normalized % 30;
    final oddRasi = sign.isEven; // 1-based odd sign
    var segment = (degree / 3).floor().clamp(0, 9).toInt();
    if (!oddRasi) segment = 9 - segment;
    return _devataProfiles[segment];
  }

  static const _devataProfiles = <D10DevataProfile>[
    D10DevataProfile(
      deity: 'Indra', direction: 'East',
      sourceMeaning: 'King/ruler/government, authority and public command.',
      workflowModifier: 'Authority, command, public responsibility మరియు decision-led work flow.',
      professionGroups: ['Government / Administration', 'Management / High Position'],
    ),
    D10DevataProfile(
      deity: 'Agni', direction: 'South-East',
      sourceMeaning: 'Energy/aggression; police/army and fire/cooking type work.',
      workflowModifier: 'Energy, initiative, fast action, active execution మరియు operations-oriented work flow.',
      professionGroups: ['Defence / Security', 'Engineering / Technical', 'Hospitality / Restaurants', 'Medicine / Surgery'],
    ),
    D10DevataProfile(
      deity: 'Yama', direction: 'South',
      sourceMeaning: 'Law, judges, bureaucrats, administrators, lawyers; disciplined authority.',
      workflowModifier: 'Discipline, rules, accountability, structured authority మరియు controlled execution.',
      professionGroups: ['Law / Judiciary', 'Government / Administration', 'Defence / Security'],
    ),
    D10DevataProfile(
      deity: 'Rakshash', direction: 'South-West',
      sourceMeaning: 'Rule-breaking/mysterious or instinctive work; secrecy can be prominent.',
      workflowModifier: 'Confidential, unconventional, investigative మరియు risk-handling work flow.',
      professionGroups: ['Research / Specialized Studies', 'Defence / Security'],
    ),
    D10DevataProfile(
      deity: 'Varuna', direction: 'West',
      sourceMeaning: 'Foreign travel/lands and water-linked work; shipping, fishery, medicines.',
      workflowModifier: 'Mobility, external networks, foreign/water-linked context మరియు adaptive movement.',
      professionGroups: ['Travel / Tourism', 'Import / Export', 'Diplomacy / Foreign Relations', 'Medicine / Surgery'],
    ),
    D10DevataProfile(
      deity: 'Vayu', direction: 'North-West',
      sourceMeaning: 'Intellectual/mobile professions; writers, teachers and thinkers.',
      workflowModifier: 'Communication, movement, learning, idea-sharing మరియు adaptable intellectual work flow.',
      professionGroups: ['Teaching / Education', 'Journalism / Writing', 'Communication / Languages', 'Books / Publishing'],
    ),
    D10DevataProfile(
      deity: 'Kubera', direction: 'North',
      sourceMeaning: 'Money/intelligence in finance; tax consultants and chartered accountants.',
      workflowModifier: 'Resources, money-management, calculation, commercial judgement మరియు optimization-oriented flow.',
      professionGroups: ['Banking / Finance', 'Accounting', 'Commercial / Business'],
    ),
    D10DevataProfile(
      deity: 'Ishana', direction: 'North-East',
      sourceMeaning: 'Religious/self-realized direction; priests, consultants, teachers, bankers.',
      workflowModifier: 'Guidance, knowledge, counsel, ethics మరియు advisory/service-oriented work flow.',
      // Build 52: keep the Devata layer exactly at the level supported by the
      // Dashamsha source. Ishana by itself does NOT mean "Astrologer". The
      // exact astrology title is allowed only through the separate
      // vrutti-graha-devata row (Ketu + Ishana + Jupiter + 8/9/12).
      professionGroups: [
        'Consultant / Advisor',
        'Priest / Spiritual Consultant',
        'Teaching / Education',
        'Banking / Finance',
      ],
    ),
    D10DevataProfile(
      deity: 'Brahma', direction: 'Downward',
      sourceMeaning: 'Creation/rooted work arising from inner contentment; source gives no narrow occupation list.',
      workflowModifier: 'Creation, planning, foundation-building మరియు patient development-oriented work flow.',
      professionGroups: [],
    ),
    D10DevataProfile(
      deity: 'Ananta', direction: 'Upward',
      sourceMeaning: 'Wide-spreading/global reach; source does not give a narrow occupation list.',
      workflowModifier: 'Expansion, scale, wide reach, continuity మరియు network-spreading work flow.',
      professionGroups: [],
    ),
  ];

  static int _relationScoreD1(AstroChartResult chart, String lord, List<int> houses) {
    final p = chart.planets.firstWhere((x) => x.name == lord);
    var score = 0;
    final ph = d1House(chart, lord);
    if (houses.contains(ph)) score += 2;
    for (final h in houses) {
      final hl = signLord(houseSignD1(chart, h));
      if (lord == hl) score += 2;
      if (lord != hl && relatedD1(chart, lord, hl)) score += 1;
      final hs = houseSignD1(chart, h);
      if (_aspects(lord, p.signIndex, hs)) score += 1;
    }
    return score;
  }

  static int _relationScoreVarga(VargaChartData v, String lord, List<int> houses) {
    final p = v.planets.firstWhere((x) => x.name == lord);
    var score = 0;
    final ph = vargaHouse(v, lord);
    if (houses.contains(ph)) score += 2;
    for (final h in houses) {
      final hl = signLord(houseSignVarga(v, h));
      if (lord == hl) score += 2;
      if (lord != hl && relatedVarga(v, lord, hl)) score += 1;
      final hs = houseSignVarga(v, h);
      if (_aspects(lord, p.signIndex, hs)) score += 1;
    }
    return score;
  }

  static bool _lordInfluencesD1House(AstroChartResult chart, String lord, int house) =>
      _relationScoreD1(chart, lord, [house]) >= 2;

  static bool _lordInfluencesVargaHouse(VargaChartData v, String lord, int house) =>
      _relationScoreVarga(v, lord, [house]) >= 2;

  /// Conservative, explicit interpretation of the source conditions.
  /// D1 prerequisites, D10 repetition and D10 8L/10L relationship must each
  /// be evidenced. This intentionally rejects the earlier OR-shortcut.
  static D10ForeignPromiseEvidence foreignEvidence(AstroChartResult chart) {
    final d10 = VargaService.calculate(chart, 10);
    final eighthLord = signLord(houseSignD1(chart, 8));
    final tenthLord = signLord(houseSignD1(chart, 10));
    final thirdLord = signLord(houseSignD1(chart, 3));
    final d10EighthLord = signLord(houseSignVarga(d10, 8));
    final d10TenthLord = signLord(houseSignVarga(d10, 10));
    final d10ThirdLord = signLord(houseSignVarga(d10, 3));
    return D10ForeignPromiseEvidence(<D10ForeignRuleCheck>[
      D10ForeignRuleCheck('D1 8L $eighthLord → లగ్నం / 10వ భావం',
          _lordInfluencesD1House(chart, eighthLord, 1) ||
          _lordInfluencesD1House(chart, eighthLord, 10)),
      D10ForeignRuleCheck('D1 10L $tenthLord → 9/12 సంబంధం',
          _relationScoreD1(chart, tenthLord, const [9, 12]) >= 2),
      D10ForeignRuleCheck('D1 3L $thirdLord → 10వ భావం (మార్పు)',
          _relationScoreD1(chart, thirdLord, const [10]) >= 2),
      D10ForeignRuleCheck('D10 8L $d10EighthLord → లగ్నం / 10వ భావం',
          _lordInfluencesVargaHouse(d10, d10EighthLord, 1) ||
          _lordInfluencesVargaHouse(d10, d10EighthLord, 10)),
      D10ForeignRuleCheck('D10 10L $d10TenthLord → 9/12 సంబంధం',
          _relationScoreVarga(d10, d10TenthLord, const [9, 12]) >= 2),
      D10ForeignRuleCheck('D10 3L $d10ThirdLord → 10వ భావం (మార్పు)',
          _relationScoreVarga(d10, d10ThirdLord, const [10]) >= 2),
      D10ForeignRuleCheck('D10 8L $d10EighthLord ↔ 10L $d10TenthLord / 10వ భావం',
          relatedVarga(d10, d10EighthLord, d10TenthLord) ||
          _lordInfluencesVargaHouse(d10, d10EighthLord, 10)),
    ]);
  }

  static bool foreignPromise(AstroChartResult chart) =>
      foreignEvidence(chart).fullRuleMatched;

  static bool lossPromise(AstroChartResult chart) {
    final d10 = VargaService.calculate(chart, 10);
    final d1TenthLord = signLord(houseSignD1(chart, 10));
    final d10TenthLord = signLord(houseSignVarga(d10, 10));
    final lossLordsD1 = [3, 9, 12].map((h) => signLord(houseSignD1(chart, h))).toSet();
    final lossLordsD10 = [3, 9, 12].map((h) => signLord(houseSignVarga(d10, h))).toSet();
    final d1 = lossLordsD1.any((l) => relatedD1(chart, l, d1TenthLord) || _lordInfluencesD1House(chart, l, 10));
    final d10p = lossLordsD10.any((l) => relatedVarga(d10, l, d10TenthLord) || _lordInfluencesVargaHouse(d10, l, 10));
    return d1 || d10p;
  }

  static List<D10CareerWindow> timingWindows({
    required AstroChartResult chart,
    required DateTime birthDateTime,
  }) {
    final d9 = VargaService.calculate(chart, 9);
    final d10 = VargaService.calculate(chart, 10);
    final d16 = VargaService.calculate(chart, 16);
    final vim = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: birthDateTime,
    );
    final foreignOk = foreignPromise(chart);
    final lossOk = lossPromise(chart);
    final out = <D10CareerWindow>[];

    int ageOn(DateTime dt) {
      var age = dt.year - birthDateTime.year;
      if (dt.month < birthDateTime.month ||
          (dt.month == birthDateTime.month && dt.day < birthDateTime.day)) age--;
      return age;
    }

    for (final md in vim.mahadashas) {
      if (md.end.isBefore(birthDateTime)) continue;
      for (final ad in DashaService.subPeriodsFor(vim, md)) {
        final age = ageOn(ad.start);
        if (age < 14 || age > 80) continue;
        final mdLord = md.lord;
        final adLord = ad.lord;

        int d1Score(List<int> houses) =>
            _relationScoreD1(chart, mdLord, houses) + _relationScoreD1(chart, adLord, houses);
        int d10Score(List<int> houses) =>
            _relationScoreVarga(d10, mdLord, houses) + _relationScoreVarga(d10, adLord, houses);

        // First earning / career start: 2-10-11 in birth and Lagna/2/10/11 in D10.
        final startScore = d1Score(const [2, 10, 11]) + d10Score(const [1, 2, 10, 11]);
        if (age <= 40 && startScore >= 9) {
          out.add(D10CareerWindow(
            eventKey: 'career_start', title: 'Career Start / First Earning',
            start: ad.start, end: ad.end, mahadasha: mdLord, antardasha: adLord,
            score: startScore, tone: D10CareerTone.favorable,
            reason: 'D1లో 2/10/11 మరియు D10లో Lagna/2/10/11 period activation కలిసి వచ్చింది.',
            ruleIds: const ['D10-CS01', 'D10-CS02'],
          ));
        }

        // Rise: source asks D1 Kendra, D9, D16 Kendra and D10 Kendra/11 confirmation.
        final riseScore =
            _relationScoreD1(chart, mdLord, const [1, 4, 7, 10]) +
            _relationScoreVarga(d9, mdLord, const [1, 4, 7, 10, 11]) +
            _relationScoreVarga(d16, mdLord, const [1, 4, 7, 10]) +
            _relationScoreVarga(d10, mdLord, const [1, 4, 7, 10, 11]) +
            _relationScoreD1(chart, adLord, const [1, 4, 7, 10]) +
            _relationScoreVarga(d10, adLord, const [1, 4, 7, 10, 11]);
        if (riseScore >= 8) {
          out.add(D10CareerWindow(
            eventKey: 'rise', title: 'Career Rise / Fame',
            start: ad.start, end: ad.end, mahadasha: mdLord, antardasha: adLord,
            score: riseScore, tone: D10CareerTone.favorable,
            reason: 'Vimshottari MD/ADకు D1 Kendra + D9/D16 + D10 Kendra/11 confirmation వచ్చింది.',
            ruleIds: const ['D10-R01', 'D10-R02', 'D10-R03'],
          ));
        }

        final promotionScore = d1Score(const [2, 10, 11]) + d10Score(const [1, 2, 10, 11]);
        if (promotionScore >= 11) {
          out.add(D10CareerWindow(
            eventKey: 'promotion', title: 'Promotion / Higher Position',
            start: ad.start, end: ad.end, mahadasha: mdLord, antardasha: adLord,
            score: promotionScore, tone: D10CareerTone.favorable,
            reason: '10/11 position housesతో పాటు 2వ income house మరియు D10 Lagna period activation బలంగా ఉంది.',
            ruleIds: const ['D10-PR01', 'D10-PR02'],
          ));
        }

        if (foreignOk) {
          final foreignScore = d1Score(const [9, 10, 12]) + d10Score(const [9, 10, 12]);
          if (foreignScore >= 8) {
            out.add(D10CareerWindow(
              eventKey: 'foreign', title: 'Foreign Job / Assignment',
              start: ad.start, end: ad.end, mahadasha: mdLord, antardasha: adLord,
              score: foreignScore, tone: D10CareerTone.favorable,
              reason: 'Birth+D10 foreign promiseతో 9/10/12 period activation match అయింది.',
              ruleIds: const ['D10-FJ01', 'D10-FJ02'],
            ));
          }
        }

        // Career change / profession switch: app decision-support layer built
        // only from source-described change/business/profession houses. 3H =
        // change/effort, 7H = business/partnership, 10H = profession, 11H =
        // gains, 12H = loss/change of profession. It is not labeled as a
        // standalone classical yoga.
        final careerChangeScore =
            d1Score(const [3, 7, 10, 11, 12]) +
            d10Score(const [3, 7, 10, 11, 12]);
        if (careerChangeScore >= 10) {
          out.add(D10CareerWindow(
            eventKey: 'career_change', title: 'Career Change / Business Switch',
            start: ad.start, end: ad.end, mahadasha: mdLord, antardasha: adLord,
            score: careerChangeScore, tone: D10CareerTone.neutral,
            reason: '3/7/10/11/12 change-business-profession houses period activation కలిసి వచ్చింది. ఇది source-house convergence ఆధారమైన app decision-support window.',
            ruleIds: const ['D10-CHG01'],
          ));
        }

        final transferScore = d1Score(const [3, 9]) + d10Score(const [3, 9]) +
            ((d1Score(const [2, 10, 11]) + d10Score(const [2, 10, 11])) ~/ 2);
        if (transferScore >= 8) {
          out.add(D10CareerWindow(
            eventKey: 'transfer', title: 'Transfer / Job Location Change',
            start: ad.start, end: ad.end, mahadasha: mdLord, antardasha: adLord,
            score: transferScore, tone: D10CareerTone.neutral,
            reason: '3/9 change houses activate అవుతూ 2/10/11 career housesతో link వచ్చింది.',
            ruleIds: const ['D10-TR01', 'D10-TR02'],
          ));
        }

        if (lossOk) {
          final lossScore = d1Score(const [3, 9, 12]) + d10Score(const [3, 9, 12]);
          final support = d1Score(const [2, 10, 11]) + d10Score(const [2, 10, 11]);
          if (lossScore >= 9 && lossScore > support) {
            out.add(D10CareerWindow(
              eventKey: 'job_loss', title: 'Downfall / Job Loss Caution',
              start: ad.start, end: ad.end, mahadasha: mdLord, antardasha: adLord,
              score: lossScore - support, tone: D10CareerTone.caution,
              reason: '3/9/12 loss/change activation 2/10/11 supportకంటే బలంగా ఉంది. ఇది source-based caution window, certainty కాదు.',
              ruleIds: const ['D10-JL01', 'D10-JL02'],
            ));
          }
        }

        if (age >= 48) {
          final retireScore = d1Score(const [3, 9, 12]) + d10Score(const [3, 9, 12]);
          if (retireScore >= 9) {
            final fifthLordD1 = signLord(houseSignD1(chart, 5));
            final fifthLordD10 = signLord(houseSignVarga(d10, 5));
            final forced = mdLord == fifthLordD1 || adLord == fifthLordD1 || mdLord == fifthLordD10 || adLord == fifthLordD10;
            out.add(D10CareerWindow(
              eventKey: 'retirement',
              title: forced ? 'Forced / Early Retirement Caution' : 'Retirement / Career Exit Window',
              start: ad.start, end: ad.end, mahadasha: mdLord, antardasha: adLord,
              score: retireScore, tone: forced ? D10CareerTone.caution : D10CareerTone.neutral,
              reason: forced
                  ? '3/9/12 retirement activationతో 5th-lord involvement కూడా ఉంది; sourceలో 5th lord forced retirementకు ప్రత్యేక సూచన.'
                  : '3/9/12 retirement/end-of-career activation ఉంది. 48+ age filter app display safeguard మాత్రమే; classical age formula కాదు.',
              ruleIds: const ['D10-RT01', 'D10-RT02'],
            ));
          }
        }
      }
    }

    out.sort((a, b) => a.start.compareTo(b.start));
    return out;
  }

  static String formatDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

  static String durationText(DateTime start, DateTime end) {
    final days = end.difference(start).inDays.abs();
    final years = days ~/ 365;
    final months = (days % 365) ~/ 30;
    final rem = (days % 365) % 30;
    final parts = <String>[];
    if (years > 0) parts.add('$yearsసం');
    if (months > 0) parts.add('$monthsనె');
    if (rem > 0 || parts.isEmpty) parts.add('$remరోజు');
    return parts.join(' ');
  }

  static String summarizeWindows(List<D10CareerWindow> windows, String key, {int max = 5}) {
    final items = windows.where((w) => w.eventKey == key).take(max).toList();
    if (items.isEmpty) return 'ఈ source conditionsకు సరిపోయే Vimshottari MD/AD window ఈ calculated rangeలో కనిపించలేదు.';
    return items.map((w) =>
        '${formatDate(w.start)} → ${formatDate(w.end)} (${durationText(w.start, w.end)}) • ${w.mahadasha}/${w.antardasha}').join('\n');
  }

  static List<D10CareerWindow> graphWindows(List<D10CareerWindow> windows, {int max = 14}) {
    final priority = <String, int>{
      'career_start': 0,
      'promotion': 1,
      'rise': 2,
      'foreign': 3,
      'transfer': 4,
      'career_change': 5,
      'job_loss': 6,
      'retirement': 7,
    };
    final copy = [...windows];
    copy.sort((a, b) {
      final c = a.start.compareTo(b.start);
      if (c != 0) return c;
      return (priority[a.eventKey] ?? 9).compareTo(priority[b.eventKey] ?? 9);
    });
    final out = <D10CareerWindow>[];
    for (final w in copy) {
      if (out.any((x) => x.start == w.start && x.end == w.end && x.eventKey == w.eventKey)) continue;
      out.add(w);
      if (out.length >= max) break;
    }
    return out;
  }
}
