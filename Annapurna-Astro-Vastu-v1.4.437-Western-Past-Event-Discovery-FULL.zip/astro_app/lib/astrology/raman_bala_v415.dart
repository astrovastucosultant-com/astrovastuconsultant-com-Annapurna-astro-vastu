import 'dart:math' as math;
import 'varga_service.dart';

/// Independently implemented arithmetic from B.V. Raman, Graha and Bhava Balas,
/// articles 18–133. Not a speed/dignity/SAV proxy and not copied from PyJHora.
class RamanBalaContext415 {
  final double jd, ayanamsa, sunrise, sunset, nextSunrise, solarHourAngle;
  final List<double> longitudes, madhyas;
  final int year, ahargana, weekday;
  final double? ramanAyanamsa;
  const RamanBalaContext415({
    required this.jd,
    required this.ayanamsa,
    required this.sunrise,
    required this.sunset,
    required this.nextSunrise,
    required this.solarHourAngle,
    required this.longitudes,
    required this.madhyas,
    required this.year,
    required this.ahargana,
    required this.weekday,
    this.ramanAyanamsa,
  });
}

class PlanetBala415 {
  final String name;
  final Map<String, double> parts, details;
  const PlanetBala415(this.name, this.parts, this.details);
  double get virupas => parts.values.fold(0.0, (a, b) => a + b);
  double get rupas => virupas / 60;
}

class HouseBala415 {
  final int house;
  final String lord;
  final double madhya, lordBala, dig, drik;
  const HouseBala415(
    this.house,
    this.lord,
    this.madhya,
    this.lordBala,
    this.dig,
    this.drik,
  );
  double get rupas => (lordBala + dig + drik) / 60;
}

class RamanBalaResult415 {
  final List<PlanetBala415> planets;
  final List<HouseBala415> houses;
  const RamanBalaResult415(this.planets, this.houses);
  Map<String, double> get shadbala => {
    for (final p in planets) p.name: p.rupas,
  };
  Map<int, double> get bhava => {for (final h in houses) h.house: h.rupas};
}

class RamanBala415 {
  static const names = [
    'Sun',
    'Moon',
    'Mars',
    'Mercury',
    'Jupiter',
    'Venus',
    'Saturn',
  ];
  static const minimum = <String, double>{
    'Sun': 5,
    'Moon': 6,
    'Mars': 5,
    'Mercury': 7,
    'Jupiter': 6.5,
    'Venus': 5.5,
    'Saturn': 5,
  };
  static const source =
      'B.V. Raman • Graha and Bhava Balas • శ్రీపతి పద్ధతి • ఆర్టికల్స్ 18–133 • https://astrojyotish.info/pdf/graha-bhava-balas.pdf';
  static const convention =
      'శ్రీపతి–రామన్ పద్ధతి: 1900 mean-motion పట్టికలు; సమయ బలానికి స్థానిక సూర్యోదయం; భావమధ్యాలు క్వాడ్రంట్ త్రిభాగాలు. సూర్య కనీసం ఈ మూలంలో 5 రూపాలు. ఇతర సాఫ్ట్‌వేర్ పద్ధతులతో సంఖ్యలు భిన్నంగా ఉండవచ్చు.';
  static const _lords = [2, 5, 3, 1, 0, 3, 5, 2, 4, 6, 6, 4];
  static const _debil = [190.0, 213.0, 118.0, 345.0, 275.0, 177.0, 20.0];
  static const _moola = [4, 1, 0, 5, 8, 6, 10];
  static const _friends = [
    {1, 2, 4},
    {0, 3},
    {0, 1, 4},
    {0, 5},
    {0, 1, 2},
    {3, 6},
    {3, 5},
  ];
  static const _enemies = [
    {5, 6},
    <int>{},
    {3},
    {1},
    {3, 5},
    {0, 1},
    {0, 1, 2},
  ];
  static const _week = [0, 1, 2, 3, 4, 5, 6]; // Sunday to Saturday.
  static const _chaldean = [6, 4, 2, 0, 5, 3, 1];
  static const _disc = [0.0, 0.0, 9.4, 6.6, 190.4, 16.6, 158.0];
  static double norm(double v) => (v % 360 + 360) % 360;
  static double signed(double v) => (norm(v + 180) - 180);
  static double arc(double a, double b) => signed(a - b).abs();
  static double uchcha(int p, double longitude) =>
      arc(longitude, _debil[p]) / 3;
  static double aspect(double angle, int p) {
    final a = norm(angle);
    double base = 0;
    if (a >= 30 && a < 60) {
      base = (a - 30) / 2;
    } else if (a < 90 && a >= 60) {
      base = a - 45;
    } else if (a < 120 && a >= 90) {
      base = (120 - a) / 2 + 30;
    } else if (a < 150 && a >= 120) {
      base = 150 - a;
    } else if (a < 180 && a >= 150) {
      base = (a - 150) * 2;
    } else if (a >= 180 && a <= 300) {
      base = (300 - a) / 2;
    }
    if (p == 2 && ((a >= 90 && a < 120) || (a >= 210 && a < 240))) base += 15;
    if (p == 4 && ((a >= 120 && a < 150) || (a >= 240 && a < 270))) base += 30;
    if (p == 6 && ((a >= 60 && a < 90) || (a >= 270 && a < 300))) base += 45;
    return base;
  }

  static double kranti(double tropical) {
    final l = norm(tropical);
    final folded = math.min(l % 180, 180 - l % 180);
    const increments = [362.0, 341.0, 299.0, 236.0, 150.0, 52.0];
    double minutes = 0;
    for (var n = 0; n < 6; n++)
      minutes += increments[n] * ((folded - n * 15) / 15).clamp(0.0, 1.0);
    return minutes / 60 * (l >= 180 ? -1 : 1);
  }

  static double ayana(int p, double tropical) {
    final k = kranti(tropical);
    final additive = p == 3 ? k.abs() : ({1, 6}.contains(p) ? -k : k);
    return (24 + additive) * 1.25 * (p == 0 ? 2 : 1);
  }

  static List<double> sripati(double asc, double mc) {
    final anchors = [norm(asc), norm(mc + 180), norm(asc + 180), norm(mc)];
    return [
      for (var q = 0; q < 4; q++)
        for (var n = 0; n < 3; n++)
          norm(anchors[q] + norm(anchors[(q + 1) % 4] - anchors[q]) * n / 3),
    ];
  }

  static double bhavaDig(int house, double cusp) {
    final sign = (norm(cusp) / 30).floor(), d = norm(cusp) % 30;
    final dead = sign == 7
        ? 1
        : ({0, 1, 4}.contains(sign) ||
              (sign == 8 && d >= 15) ||
              (sign == 9 && d < 15))
        ? 4
        : ({2, 5, 6, 10}.contains(sign) || (sign == 8 && d < 15))
        ? 7
        : 10;
    final diff = (house - dead).abs();
    return math.min(diff, 12 - diff) * 10.0;
  }

  static double relationValue(int p, int owner, List<int> rasi) {
    if (p == owner) return 30;
    final h = (rasi[owner] - rasi[p] + 12) % 12 + 1;
    final temporary = {2, 3, 4, 10, 11, 12}.contains(h);
    if (_friends[p].contains(owner)) return temporary ? 22.5 : 7.5;
    if (_enemies[p].contains(owner)) return temporary ? 7.5 : 1.875;
    return temporary ? 15 : 3.75;
  }

  static double sapta(int p, double longitude, List<int> rasi) {
    double total = 0;
    for (final factor in [1, 2, 3, 7, 9, 12, 30]) {
      final sign = VargaService.signForLongitude(longitude, factor);
      total += factor == 1 && sign == _moola[p]
          ? 45
          : relationValue(p, _lords[sign], rasi);
    }
    return total;
  }

  static Map<String, double> meanMotions(double jd, int year) {
    // Epoch: 1900-01-01 00:00 at Ujjain 76E (2415020.5 - 76/360 UT).
    final days = jd - (2415020.5 - 76 / 360), t = year - 1900;
    return {
      'Sun': norm(257.4568 + 0.9856026546 * days),
      'Mars': norm(270.22 + 0.524019 * days),
      'Jupiter': norm(220.04 + 0.083096 * days - 3.33 - 0.0067 * t),
      'Saturn': norm(236.74 + 0.033439 * days + 5 + 0.001 * t),
      'MercuryApogee': norm(164 + 4.092318 * days + 6.67 - 0.00133 * t),
      'VenusApogee': norm(328.51 + 1.602146 * days - 5 - 0.001 * t),
    };
  }

  static double cheshta(int p, double longitude, Map<String, double> means) {
    if (p < 2)
      return 0; // Raman art.79 and table56: already doubled Ayana/Paksha.
    final mean = (p == 3 || p == 5) ? means['Sun']! : means[names[p]]!;
    final apogee = p == 3
        ? means['MercuryApogee']!
        : p == 5
        ? means['VenusApogee']!
        : means['Sun']!;
    final midpoint = norm(mean + signed(longitude - mean) / 2);
    return arc(apogee, midpoint) / 3;
  }

  static RamanBalaResult415 calculate(RamanBalaContext415 c) {
    if (c.longitudes.length != 7 ||
        c.madhyas.length != 12 ||
        [
          ...c.longitudes,
          ...c.madhyas,
          c.jd,
          c.ayanamsa,
          c.sunrise,
          c.sunset,
          c.nextSunrise,
          c.solarHourAngle,
          if (c.ramanAyanamsa != null) c.ramanAyanamsa!,
        ].any((x) => !x.isFinite) ||
        !(c.sunrise <= c.jd &&
            c.sunset > c.sunrise &&
            c.nextSunrise > c.sunset &&
            c.jd < c.nextSunrise) ||
        c.weekday < 0 ||
        c.weekday > 6) {
      throw ArgumentError(
        'పూర్తి గ్రహస్థితులు, భావమధ్యాలు, స్థానిక సూర్యోదయ సమాచారం అవసరం',
      );
    }
    final l = c.longitudes.map(norm).toList(),
        rasi = l.map((v) => (v / 30).floor()).toList();
    final ascSign = (norm(c.madhyas[0]) / 30).floor();
    final phase = norm(l[1] - l[0]), moonBenefic = phase >= 84 && phase < 276;
    final bad = <int>{0, 2, 6, if (!moonBenefic) 1};
    final mercuryBad = bad.any((p) => rasi[p] == rasi[3]);
    bool benefic(int p, {bool house = false}) =>
        p == 4 ||
        p == 5 ||
        (p == 1 && moonBenefic) ||
        (p == 3 && (house || !mercuryBad));
    final sthana = <double>[],
        digs = <double>[],
        kalaBase = <double>[],
        ayanaValues = <double>[];
    final details = <Map<String, double>>[];
    final elapsed = (c.jd - c.sunrise) * 24, day = c.jd < c.sunset;
    final third =
        (((c.jd - (day ? c.sunrise : c.sunset)) /
                    ((day ? c.sunset : c.nextSunrise) -
                        (day ? c.sunrise : c.sunset))) *
                3)
            .floor()
            .clamp(0, 2);
    final triLord = (day ? [3, 0, 6] : [1, 5, 2])[third];
    final yearLord = _week[(3 + 3 * (c.ahargana / 360).floor()) % 7];
    final monthLord = _week[(3 + 2 * (c.ahargana / 30).floor()) % 7];
    final dayLord = _week[c.weekday];
    final horaLord =
        _chaldean[(_chaldean.indexOf(dayLord) + elapsed.floor().clamp(0, 23)) %
            7];
    final illumination = arc(l[1], l[0]) / 3;
    for (var p = 0; p < 7; p++) {
      final u = uchcha(p, l[p]), sv = sapta(p, l[p], rasi);
      final nav = VargaService.signForLongitude(l[p], 9);
      final wantEven = p == 1 || p == 5;
      final oja =
          ((rasi[p].isOdd == wantEven) ? 15.0 : 0.0) +
          ((nav.isOdd == wantEven) ? 15.0 : 0.0);
      final house = (rasi[p] - ascSign + 12) % 12 + 1;
      final kendra = ({1, 4, 7, 10}.contains(house)
          ? 60.0
          : {2, 5, 8, 11}.contains(house)
          ? 30.0
          : 15.0);
      final drekkana = (l[p] % 30 / 10).floor();
      final expected = {0, 2, 4}.contains(p)
          ? 0
          : {3, 6}.contains(p)
          ? 1
          : 2;
      final drekkanaBala = drekkana == expected ? 15.0 : 0.0;
      sthana.add(u + sv + oja + kendra + drekkanaBala);
      final powerless = [3, 9, 3, 6, 6, 9, 0][p];
      digs.add(arc(l[p], c.madhyas[powerless]) / 3);
      final night = signed(c.solarHourAngle).abs() / 3;
      final natha = p == 3
          ? 60.0
          : {1, 2, 6}.contains(p)
          ? night
          : 60 - night;
      // Moon's own phase strength follows folded elongation (art.55c/summary),
      // even when its aspect nature is malefic; do not give new Moon 120.
      final paksha = p == 1
          ? 2 * illumination
          : (benefic(p) ? illumination : 60 - illumination);
      final tribhaga = (p == 4 || p == triLord) ? 60.0 : 0.0;
      final abda = p == yearLord ? 15.0 : 0.0,
          masa = p == monthLord ? 30.0 : 0.0;
      final vara = p == dayLord ? 45.0 : 0.0, hora = p == horaLord ? 60.0 : 0.0;
      kalaBase.add(natha + paksha + tribhaga + abda + masa + vara + hora);
      ayanaValues.add(ayana(p, l[p] + c.ayanamsa));
      details.add({
        'ఉచ్చ': u,
        'సప్తవర్గజ': sv,
        'ఓజయుగ్మ': oja,
        'కేంద్ర': kendra,
        'ద్రేక్కాణ': drekkanaBala,
        'నతోన్నత': natha,
        'పక్ష': paksha,
        'త్రిభాగ': tribhaga,
        'అబ్ద': abda,
        'మాస': masa,
        'వార': vara,
        'హోరా': hora,
        'అయన': ayanaValues.last,
      });
    }
    final war = List<double>.filled(7, 0);
    for (var p = 2; p < 7; p++)
      for (var q = p + 1; q < 7; q++)
        if (arc(l[p], l[q]) < 1) {
          if (arc(l[p], l[q]) < 1e-10)
            throw StateError(
              'సమాన డిగ్రీల గ్రహయుద్ధ నిర్ణయం ప్రత్యేకంగా పరిశీలించాలి',
            );
          final a = sthana[p] + digs[p] + kalaBase[p],
              b = sthana[q] + digs[q] + kalaBase[q];
          final amount = (a - b).abs() / (_disc[p] - _disc[q]).abs();
          final winner = l[p] < l[q] ? p : q, loser = winner == p ? q : p;
          war[winner] += amount;
          war[loser] -= amount;
        }
    // Epoch tables are Raman nirayana. Bring means and apogees into the same
    // frame as the selected chart, rather than mixing Raman and Lahiri degrees.
    final frameShift = (c.ramanAyanamsa ?? c.ayanamsa) - c.ayanamsa;
    final means = {
      for (final e in meanMotions(c.jd, c.year).entries)
        e.key: norm(e.value + frameShift),
    };
    final planets = <PlanetBala415>[];
    const natural = [60.0, 360 / 7, 120 / 7, 180 / 7, 240 / 7, 300 / 7, 60 / 7];
    for (var p = 0; p < 7; p++) {
      double net = 0;
      for (var other = 0; other < 7; other++)
        if (other != p)
          net += aspect(l[p] - l[other], other) * (benefic(other) ? 1 : -1) / 4;
      final motion = cheshta(p, l[p], means);
      details[p]['యుద్ధ'] = war[p];
      if (p >= 2) details[p]['చేష్టాకేంద్రం'] = motion * 3;
      planets.add(
        PlanetBala415(names[p], {
          'స్థాన': sthana[p],
          'దిగ్': digs[p],
          'కాల': kalaBase[p] + ayanaValues[p] + war[p],
          'చేష్టా': motion,
          'నైసర్గిక': natural[p],
          'దృక్': net,
        }, details[p]),
      );
    }
    final houses = <HouseBala415>[];
    for (var h = 0; h < 12; h++) {
      final cusp = norm(c.madhyas[h]), owner = _lords[(cusp / 30).floor()];
      double net = 0;
      for (var p = 0; p < 7; p++)
        net +=
            aspect(cusp - l[p], p) *
            (benefic(p, house: true) ? 1 : -1) *
            ({3, 4}.contains(p) ? 1 : 0.25);
      houses.add(
        HouseBala415(
          h + 1,
          names[owner],
          cusp,
          planets[owner].virupas,
          bhavaDig(h + 1, cusp),
          net,
        ),
      );
    }
    return RamanBalaResult415(planets, houses);
  }
}
