import 'dart:convert';
import 'astro_models.dart';
import '../models/birth_data.dart';

class BalaMetric414 {
  final String id, label, shortLabel;
  final double? value, minimum;
  const BalaMetric414(
    this.id,
    this.label,
    this.shortLabel,
    this.value, {
    this.minimum,
  });
  double? get percent =>
      value == null || minimum == null ? null : value! / minimum! * 100;
  bool? get sufficient => percent == null ? null : percent! >= 100;
}

class BalaSummary414 {
  static const planets = [
    'Sun',
    'Moon',
    'Mars',
    'Mercury',
    'Jupiter',
    'Venus',
    'Saturn',
    'Rahu',
    'Ketu',
  ];
  static const shortNames = [
    'Su',
    'Mo',
    'Ma',
    'Me',
    'Ju',
    'Ve',
    'Sa',
    'Ra',
    'Ke',
  ];
  static const telugu = [
    'రవి',
    'చంద్రుడు',
    'కుజుడు',
    'బుధుడు',
    'గురువు',
    'శుక్రుడు',
    'శని',
    'రాహువు',
    'కేతువు',
  ];
  // Same convention already used in ShapaOverview: 60 virupas = 1 rupa.
  static const requiredRupas = <String, double>{
    'Sun': 6.5,
    'Moon': 6,
    'Mars': 5,
    'Mercury': 7,
    'Jupiter': 6.5,
    'Venus': 5.5,
    'Saturn': 5,
  };
  final List<BalaMetric414> vimsopaka, shadbala, bhava;
  final String source;
  const BalaSummary414(this.vimsopaka, this.shadbala, this.bhava, this.source);

  static String chartKey(AstroChartResult chart, BirthData birth) =>
      'gem-bala-414:${chart.julianDay.toStringAsPrecision(17)}:${birth.latitude.toStringAsPrecision(17)}:${birth.longitude.toStringAsPrecision(17)}:${chart.ayanamsaDegrees.toStringAsPrecision(17)}:${chart.ascendantLongitude.toStringAsPrecision(17)}:${chart.planets.map((p) => '${p.name}:${p.longitude.toStringAsPrecision(17)}').join('|')}';

  factory BalaSummary414.calculate(
    AstroChartResult chart, {
    Map<String, double> vimsopakaValues = const {},
    Map<String, double> shadbalaMinimums = requiredRupas,
    Map<String, double> shadbalaRupas = const {},
    Map<int, double> bhavaRupas = const {},
    String source = '',
  }) {
    return BalaSummary414(
      [
        for (var n = 0; n < planets.length; n++)
          BalaMetric414(
            planets[n],
            telugu[n],
            shortNames[n],
            _vimsopaka(chart, planets[n], vimsopakaValues),
            minimum: 20,
          ),
      ],
      [
        for (var n = 0; n < 7; n++)
          BalaMetric414(
            planets[n],
            telugu[n],
            shortNames[n],
            valid(shadbalaRupas[planets[n]]),
            minimum: shadbalaMinimums[planets[n]],
          ),
      ],
      [
        for (var h = 1; h <= 12; h++)
          BalaMetric414('$h', '$hవ భావం', '$h', valid(bhavaRupas[h])),
      ],
      source,
    );
  }
  static double? _vimsopaka(
    AstroChartResult chart,
    String name,
    Map<String, double> values,
  ) {
    final candidates = chart.planets.where((p) => p.name == name);
    if (candidates.length != 1 || !candidates.single.longitude.isFinite)
      return null;
    final result = values[name];
    return result != null && result.isFinite && result >= 0 && result <= 20
        ? result
        : null;
  }

  static double? valid(double? value) =>
      value != null && value.isFinite && value >= 0 && value <= 1000
      ? value
      : null;
  // Competition ranking; shadbala uses ratio to the planet-specific minimum.
  static int? rank(
    BalaMetric414 row,
    List<BalaMetric414> rows, {
    bool ratio = false,
  }) {
    final value = ratio ? row.percent : row.value;
    if (value == null) return null;
    return 1 +
        rows.where((other) {
          final score = ratio ? other.percent : other.value;
          return score != null && score > value + 1e-9;
        }).length;
  }

  static String roman(int? value) => value == null
      ? '—'
      : const [
          '',
          'I',
          'II',
          'III',
          'IV',
          'V',
          'VI',
          'VII',
          'VIII',
          'IX',
          'X',
          'XI',
          'XII',
        ][value];
}

class BalaInput414 {
  final Map<String, double> shadbala;
  final Map<int, double> bhava;
  final String source;
  const BalaInput414({
    this.shadbala = const {},
    this.bhava = const {},
    this.source = '',
  });
  String encode() => jsonEncode({
    'schema': 1,
    'units': 'rupas',
    'source': source,
    'shadbala': shadbala,
    'bhava': {for (final e in bhava.entries) '${e.key}': e.value},
  });
  static BalaInput414 decode(String? text) {
    if (text == null || text.isEmpty) return const BalaInput414();
    try {
      final v = jsonDecode(text);
      if (v is! Map || v['schema'] != 1 || v['units'] != 'rupas')
        return const BalaInput414();
      final shad = <String, double>{}, houses = <int, double>{};
      if (v['shadbala'] is Map)
        for (final e in (v['shadbala'] as Map).entries) {
          if (!BalaSummary414.requiredRupas.containsKey(e.key) ||
              e.value is! num)
            continue;
          final n = BalaSummary414.valid((e.value as num).toDouble());
          if (n != null) shad[e.key as String] = n;
        }
      if (v['bhava'] is Map)
        for (final e in (v['bhava'] as Map).entries) {
          final h = int.tryParse('${e.key}');
          if (h == null || h < 1 || h > 12 || e.value is! num) continue;
          final n = BalaSummary414.valid((e.value as num).toDouble());
          if (n != null) houses[h] = n;
        }
      final source = v['source'] is String
          ? (v['source'] as String).trim()
          : '';
      if ((shad.isNotEmpty || houses.isNotEmpty) && source.isEmpty)
        return const BalaInput414();
      return BalaInput414(shadbala: shad, bhava: houses, source: source);
    } catch (_) {
      return const BalaInput414();
    }
  }
}
