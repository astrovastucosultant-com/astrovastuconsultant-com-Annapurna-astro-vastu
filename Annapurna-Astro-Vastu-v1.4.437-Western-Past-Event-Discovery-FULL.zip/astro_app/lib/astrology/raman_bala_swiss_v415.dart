import 'dart:math' as math;
import 'package:sweph/sweph.dart';
import '../models/birth_data.dart';
import 'astro_models.dart';
import 'astro_calculation_service.dart';
import 'raman_bala_v415.dart';

class RamanBalaSwiss415 {
  static Future<RamanBalaResult415> calculate(
    AstroChartResult chart,
    BirthData birth,
  ) async {
    if (!birth.latitude.isFinite ||
        !birth.longitude.isFinite ||
        birth.latitude.abs() > 90 ||
        birth.longitude.abs() > 180)
      throw ArgumentError('సరైన జన్మస్థల అక్షాంశం, రేఖాంశం అవసరం');
    await AstroCalculationService.initialize();
    if (!AstroCalculationService.isInitialized)
      throw StateError('Swiss Ephemeris గణన అందుబాటులో లేదు');
    final jd = chart.julianDay;
    double riseSet(double start, bool rise) {
      final value = Sweph.swe_rise_trans(
        start,
        HeavenlyBody.SE_SUN,
        SwephFlag.SEFLG_MOSEPH,
        rise ? RiseSetTransitFlag.SE_CALC_RISE : RiseSetTransitFlag.SE_CALC_SET,
        GeoPosition(birth.longitude, birth.latitude),
        0,
        0,
      );
      if (value == null || !value.isFinite)
        throw StateError('ఈ ప్రదేశం/తేదీకి సూర్యోదయ–అస్తమయ గణన లభించలేదు');
      return value;
    }

    var rise = riseSet(jd - 2.0, true);
    for (var n = 0; n < 4; n++) {
      final next = riseSet(rise + 0.01, true);
      if (next > jd) break;
      rise = next;
    }
    final sunset = riseSet(rise + 0.001, false),
        nextRise = riseSet(rise + 0.01, true);
    if (rise > jd || nextRise <= jd)
      throw StateError(
        'జన్మ సమయాన్ని కలిగిన స్థానిక సూర్యోదయ దినం నిర్ణయించలేకపోయాం',
      );
    // Tropical MC minus the chart's selected ayanamsa; no reliance on global sidereal mode.
    final houses = Sweph.swe_houses_ex(
      jd,
      SwephFlag.SEFLG_MOSEPH,
      birth.latitude,
      birth.longitude,
      Hsys.P,
    );
    final mc = RamanBala415.norm(houses.ascmc[1] - chart.ayanamsaDegrees);
    final madhyas = RamanBala415.sripati(chart.ascendantLongitude, mc);
    final longs = <double>[];
    for (final name in RamanBala415.names) {
      final rows = chart.planets.where((p) => p.name == name);
      if (rows.length != 1)
        throw ArgumentError('పూర్తి ఏడు గ్రహస్థితులు అవసరం');
      longs.add(rows.single.longitude);
    }
    final localRise = DateTime.utc(1970, 1, 1)
        .add(Duration(microseconds: ((rise - 2440587.5) * 86400000000).round()))
        .add(
          Duration(
            microseconds: (birth.timezoneOffsetHours * 3600000000).round(),
          ),
        );
    final date = DateTime.utc(localRise.year, localRise.month, localRise.day);
    final ahargana = date.difference(DateTime.utc(1827, 5, 2)).inDays + 1;
    final t = (jd - 2451545) / 36525, rad = math.pi / 180;
    final epsilon =
        (23.439291111 -
            0.013004167 * t -
            0.000000164 * t * t +
            0.000000504 * t * t * t) *
        rad;
    final sun = chart.planets.singleWhere((p) => p.name == 'Sun');
    final lambda = (sun.longitude + chart.ayanamsaDegrees) * rad,
        beta = sun.latitude * rad;
    final ra =
        math.atan2(
          math.sin(lambda) * math.cos(epsilon) -
              math.tan(beta) * math.sin(epsilon),
          math.cos(lambda),
        ) /
        rad;
    final gmst =
        280.46061837 +
        360.98564736629 * (jd - 2451545) +
        0.000387933 * t * t -
        t * t * t / 38710000;
    final hourAngle = RamanBala415.signed(gmst + birth.longitude - ra);
    double ramanAyanamsa;
    try {
      Sweph.swe_set_sid_mode(
        SiderealMode.SE_SIDM_RAMAN,
        SiderealModeFlag.SE_SIDBIT_NONE,
        0,
        0,
      );
      ramanAyanamsa = Sweph.swe_get_ayanamsa_ut(jd);
    } finally {
      final selected = switch (birth.ayanamsa) {
        AyanamsaType.lahiri => SiderealMode.SE_SIDM_LAHIRI,
        AyanamsaType.raman => SiderealMode.SE_SIDM_RAMAN,
        AyanamsaType.krishnamurti => SiderealMode.SE_SIDM_KRISHNAMURTI,
      };
      Sweph.swe_set_sid_mode(selected, SiderealModeFlag.SE_SIDBIT_NONE, 0, 0);
    }
    return RamanBala415.calculate(
      RamanBalaContext415(
        jd: jd,
        ayanamsa: chart.ayanamsaDegrees,
        sunrise: rise,
        sunset: sunset,
        nextSunrise: nextRise,
        solarHourAngle: hourAngle,
        longitudes: longs,
        madhyas: madhyas,
        year: birth.localDateTime.year,
        ahargana: ahargana,
        weekday: date.weekday % 7,
        ramanAyanamsa: ramanAyanamsa,
      ),
    );
  }
}
