import '../models/birth_data.dart';
import 'western_event_topics_v435.dart';
import 'western_timing_engine_v434.dart';
import 'western_timing_settings_v433.dart';

/// Inclusive civil-calendar MONTH range. Every included month is calculated
/// using the unchanged v434 daily-sampling tropical Western geometry.
class WesternTimingPeriodV436 {
  WesternTimingPeriodV436({required DateTime start, required DateTime end})
      : start = DateTime.utc(start.year, start.month),
        end = DateTime.utc(end.year, end.month) {
    if (monthCount < 1 || monthCount > maxMonths) {
      throw ArgumentError('Select a period of 1–$maxMonths months');
    }
  }

  static const int maxMonths = 24;
  final DateTime start;
  final DateTime end;

  int get monthCount =>
      (end.year - start.year) * 12 + end.month - start.month + 1;

  Iterable<DateTime> get months sync* {
    for (var i = 0; i < monthCount; i++) {
      yield DateTime.utc(start.year, start.month + i);
    }
  }

  DateTime get lastDay => DateTime.utc(end.year, end.month + 1, 0);
}

enum WesternLifeStageV436 { eligible, notEligible, unknown }

/// This is a legal/contextual presentation safeguard, NOT an astrological
/// rule, and must never be described as a Western timing technique.
/// India-specific rule: 18 completed years for female, 21 for male.
/// With unspecified gender ages 18–20, return unknown, never guess.
class WesternEventEligibilityV436 {
  WesternEventEligibilityV436._();

  static int completedAge(DateTime born, DateTime onDate) {
    final at = DateTime.utc(onDate.year, onDate.month, onDate.day);
    final birth = DateTime.utc(born.year, born.month, born.day);
    var years = at.year - birth.year;
    if (at.month < birth.month ||
        (at.month == birth.month && at.day < birth.day)) years--;
    return years;
  }

  static WesternLifeStageV436 marriageStage({
    required BirthData birth,
    required DateTime onDate,
  }) {
    final years = completedAge(birth.localDateTime, onDate);
    switch (birth.gender) {
      case BirthGender.female:
        return years >= 18
            ? WesternLifeStageV436.eligible
            : WesternLifeStageV436.notEligible;
      case BirthGender.male:
        return years >= 21
            ? WesternLifeStageV436.eligible
            : WesternLifeStageV436.notEligible;
      case BirthGender.unspecified:
        if (years < 18) return WesternLifeStageV436.notEligible;
        if (years >= 21) return WesternLifeStageV436.eligible;
        return WesternLifeStageV436.unknown;
    }
  }
}

class WesternPeriodEvidenceV436 {
  const WesternPeriodEvidenceV436({
    required this.match,
    required this.stage,
  });

  final WesternEventEvidenceV435 match;
  final WesternLifeStageV436 stage;
}

/// Aggregates actual per-month topical aspect matches. Period counts are
/// evidence counts, NOT event probabilities; duplicates across adjacent month
/// boundaries may be reported separately and are deliberately not invented
/// into a single exact time of event.
class WesternEventPeriodSummaryV436 {
  const WesternEventPeriodSummaryV436({
    required this.period,
    required this.topic,
    required this.scannedMonths,
    required this.samples,
    required this.evidence,
  });

  final WesternTimingPeriodV436 period;
  final WesternEventTopicV435 topic;
  final int scannedMonths;
  final int samples;
  final List<WesternPeriodEvidenceV436> evidence;

  List<WesternPeriodEvidenceV436> get eligibleEvidence => evidence
      .where((e) => e.stage == WesternLifeStageV436.eligible).toList();
  int get blockedCount => evidence
      .where((e) => e.stage == WesternLifeStageV436.notEligible).length;
  int get uncertainCount => evidence
      .where((e) => e.stage == WesternLifeStageV436.unknown).length;
  int get eligibleCount => eligibleEvidence.length;

  static WesternEventPeriodSummaryV436 analyze({
    required WesternTimingPeriodV436 period,
    required WesternEventTopicV435 topic,
    required BirthData birth,
    required WesternTimingSettingsV433 settings,
    required List<WesternTimingReportV434> reports,
  }) {
    final evidence = <WesternPeriodEvidenceV436>[];
    var sampled = 0;
    for (final report in reports) {
      sampled += report.sampledDays;
      final summary = WesternEventMatcherV435.match(
          report: report, topic: topic, settings: settings);
      for (final match in summary.matches) {
        final stage = topic.id == 'MAR'
            ? WesternEventEligibilityV436.marriageStage(
                birth: birth, onDate: match.window.best.localDate)
            : WesternLifeStageV436.eligible;
        evidence.add(WesternPeriodEvidenceV436(
            match: match, stage: stage));
      }
    }
    evidence.sort((a, b) {
      final byDate = a.match.window.best.localDate
          .compareTo(b.match.window.best.localDate);
      if (byDate != 0) return byDate;
      return a.match.window.best.deviationDegrees
          .compareTo(b.match.window.best.deviationDegrees);
    });
    return WesternEventPeriodSummaryV436(
      period: period,
      topic: topic,
      scannedMonths: reports.length,
      samples: sampled,
      evidence: List.unmodifiable(evidence),
    );
  }
}
