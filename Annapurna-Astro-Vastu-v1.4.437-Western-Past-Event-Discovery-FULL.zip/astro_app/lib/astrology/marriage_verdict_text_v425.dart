/// Traditional marriage matching source-rule verdict display.
/// These labels describe only the rules that actually returned true/false.
/// Unmatched, unverified or unavailable conditions never count as evidence.
class MarriageVerdictText425 {
  static String rule(bool? favourable) {
    if (favourable == true) {
      return 'కలిసింది బాగుంది — ఈ నియమం ప్రకారం అనుకూల సంయోగం ఉంది.';
    }
    if (favourable == false) {
      return 'చెడు సంయోగం ఉన్నది కనుక ఈ నియమం ప్రకారం అనుకూలము కాదు.';
    }
    return 'ఈ నియమం నుంచి నిర్ణయించలేం — మూల షరతు లేదా సమాచారం సరిపోలలేదు.';
  }

  static String summary({
    required int favourable,
    required int adverse,
  }) {
    if (favourable > 0 && adverse == 0) {
      return 'కలిసింది బాగుంది — పరిశీలించిన నిర్ధారిత నియమాల్లో అనుకూల సంయోగాలే ఉన్నాయి.';
    }
    if (adverse > 0 && favourable == 0) {
      return 'చెడు సంయోగాలు ఉన్నవి కనుక పరిశీలించిన నిర్ధారిత నియమాల మేరకు అనుకూలము కాదు.';
    }
    if (favourable > 0 && adverse > 0) {
      return 'మిశ్రమ ఫలితం — మంచి, చెడు సంయోగాలు రెండూ ఉన్నాయి. మరింత జాతక పరిశీలన అవసరం.';
    }
    return 'అనుకూలతపై నిర్ణయం ఇవ్వడానికి ధృవీకరించిన నియమాల ఆధారాలు సరిపోలేదు.';
  }
}
