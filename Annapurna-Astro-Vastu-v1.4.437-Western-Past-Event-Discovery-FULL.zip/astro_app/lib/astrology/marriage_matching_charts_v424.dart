import 'astro_models.dart';
import 'varga_service.dart';

/// Display-only charts for comparing two people. No new compatibility verdict
/// is inferred from these placements; the existing matching rules remain the
/// sole source of rule examinations and scoring.
class MarriageMatchingChartPair424 {
  final String title;
  final String code;
  final String firstName;
  final String secondName;
  final VargaChartData first;
  final VargaChartData second;
  final String centreLabel;
  final String methodNote;

  const MarriageMatchingChartPair424({
    required this.title,
    required this.code,
    required this.firstName,
    required this.secondName,
    required this.first,
    required this.second,
    required this.centreLabel,
    required this.methodNote,
  });
}

class MarriageMatchingCharts424 {
  static const List<int> factors = [1, 7, 9];

  /// Moon-lagna is NOT a D-chart: keep all natal (D1) planet signs unchanged
  /// and use the Moon's natal rashi as the chart ascendant. Missing Moon
  /// does not default to Aries or silently reuse the birth ascendant.
  static VargaChartData? moonLagna(AstroChartResult natal) {
    final moon = natal.planets.where((p) => p.name == 'Moon');
    if (moon.isEmpty) return null;
    final rasi = VargaService.calculate(natal, 1);
    return VargaChartData(
      definition: rasi.definition,
      ascendantSignIndex: moon.first.signIndex,
      planets: rasi.planets,
    );
  }

  static List<MarriageMatchingChartPair424> compare({
    required String firstName,
    required AstroChartResult first,
    required String secondName,
    required AstroChartResult second,
  }) {
    final rows = <MarriageMatchingChartPair424>[
      for (final factor in factors)
        MarriageMatchingChartPair424(
          title: switch (factor) {
            1 => 'D1 — రాశి చక్రం',
            7 => 'D7 — సప్తాంశం',
            _ => 'D9 — నవాంశం',
          },
          code: 'D$factor',
          firstName: firstName,
          secondName: secondName,
          first: VargaService.calculate(first, factor),
          second: VargaService.calculate(second, factor),
          centreLabel: 'D$factor',
          methodNote: factor == 7
              ? 'D7 అంశానికి సంబంధిత మూల నియమం ఉన్నప్పుడే ఫలితం పరిశీలించాలి.'
              : factor == 9
                  ? 'D9 వివాహ సంబంధిత నియమాలకు సహాయక పరిశీలన.'
                  : 'D1 మూల రాశి స్థితులు; ఇతర చక్రాల ఫలితాలను ఇక్కడి నుంచి ఊహించరాదు.',
        ),
    ];
    final firstMoon = moonLagna(first);
    final secondMoon = moonLagna(second);
    if (firstMoon != null && secondMoon != null) {
      rows.add(MarriageMatchingChartPair424(
        title: 'చంద్రలగ్న చక్రం',
        code: 'CHANDRA',
        firstName: firstName,
        secondName: secondName,
        first: firstMoon,
        second: secondMoon,
        centreLabel: 'చంద్రలగ్నం',
        methodNote: 'D1లో గ్రహాల రాశులు మారవు; చంద్రుడు ఉన్న రాశిని లగ్నంగా గుర్తించాం.',
      ));
    }
    return rows;
  }

  static String signDetails(VargaChartData data) {
    const signs = <String>[
      'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
      'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
    ];
    return List.generate(12, (sign) {
      final items = <String>[
        if (sign == data.ascendantSignIndex) 'Lg',
        ...data.planets.where((p) => p.signIndex == sign).map(
          (p) => '${p.shortName}${p.retrograde ? 'R' : ''}',
        ),
      ];
      return '${sign + 1}. ${signs[sign]}: ${items.isEmpty ? '—' : items.join(', ')}';
    }).join('\n');
  }
}
