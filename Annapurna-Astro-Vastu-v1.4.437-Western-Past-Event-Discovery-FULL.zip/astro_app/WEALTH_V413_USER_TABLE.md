# v413: supplied Mahavidya table integrated

The user had supplied the four-page Telugu MahaVastu/Tantra/Mahavidya report. Its pages 2–3 contain nine numbered planet/deity/zone rows covering the ten Mahavidyas through alternatives. The previous app incorrectly continued requesting that supplied table.

All nine rows are now included as a visible Telugu table in the MahaVastu detail sheet and as individual source records. Number 1 Matangi/Bhuvaneshwari, number 2 Bhuvaneshwari/Kamalatmika and NW/NE, and number 9 Baglamukhi/Bhairavi alternatives are preserved without inventing selection conditions. Number 7 Dhumavati/Ketu uses the user's later correction NE upper part; original PDF NE/SE stays in source history. Urdhva remains distinct. No installation height is invented.

The blanket missing-table message is replaced with confirmation that the user's table is recorded. Video-only absence is distinguished from the separately supplied PDF. User attribution is retained without pretending independent official MahaVastu verification. General reference entries remain separate from natal wealth yoga counts. The v412 result/status fixes and all earlier cumulative overlays remain included.

Pure-Dart checks cover row completeness, preserved alternatives, Ketu override/history and source attribution. Flutter widget/APK checks require GitHub Actions.
