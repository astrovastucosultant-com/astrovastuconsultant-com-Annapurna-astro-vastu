ANNAPURNA ASTRO VASTU v1.4.436 — WESTERN EVENT PERIOD / LIFE STAGE

Scope: Western Timing of Event ONLY. Does not add KP, Jaimini, BNN,
Indian dashas, sidereal astrology, or invented outcomes. It preserves
v1.4.435's Western thematic matching and v1.4.434's tropical geometry.

New:
- Inclusive START month and END month; preset periods of 1, 3, 6, 12 or
  24 months; Custom END month allows inclusive 1–24 month selection.
- Every included month is scanned through existing daily-sampled
  Secondary Progression, Solar Arc, Progressed Moon and optional Transit
  settings; results are chronological and report day samples.
- Marriage (MAR) is separate from Love / Relationships (REL).
- An Indian legal minimum-marriage-age filter is applied to MAR contact
  presentation only: female 18 completed years, male 21; unknown gender
  under 18 = ineligible, ages 18–20 = unknown, >=21 = eligible.
- Before the minimum age, Western aspect contacts are NOT shown as
  marriage-eligible contacts. Relationships are a separate theme.
- User-visible counts distinguish supported vs ineligible vs unknown
  marriage-theme contacts. These are counts of aspect evidence, NOT
  probability or a marriage forecast.
- The legal/contextual life-stage safeguard is NOT a Western astrological
  rule. It is India-specific and not valid as a worldwide marriage rule.
- All earlier Western-only reference IDs remain; MAR has its own app
  rule ID WEST-EVENT-MAR-435, sharing the REL topical source document.

Primary Western astrology methodology references:
  https://www.astro.com/astrowiki/en/Secondary_Directions
  https://www.astro.com/astrology/iam_article190812_e.htm
  https://cafeastrology.com/secondaryprogressions.html

Legal presentation reference (India, NOT astrology):
  https://www.indiacode.nic.in/bitstream/123456789/2055/4/a2007-06.pdf

Limitations:
- Daily Swiss Ephemeris sampling is one sample at local civil noon using
  the stored fixed timezone offset; no exact contact time is claimed.
- The scan can take longer over long date ranges; runs sequentially by
  month and yields between them, with a completion counter.
- If a window crosses the eligibility birthday, its best sampled date
  determines the gate; for greater precision inspect a shorter period.
- No event occurrence, causal certainty, predictive percentage, or BTR
  birth-time change is inferred from these contact windows.
- The old BTR placeholder remains unchanged.
- APK build and unit tests need Flutter CI or a local Flutter SDK.

Changed/added sources:
  pubspec.yaml
  lib/astrology/western_event_topics_v435.dart
  lib/astrology/western_event_period_v436.dart
  lib/screens/western_timing_tab.dart
  test/western_event_period_v436_test.dart
