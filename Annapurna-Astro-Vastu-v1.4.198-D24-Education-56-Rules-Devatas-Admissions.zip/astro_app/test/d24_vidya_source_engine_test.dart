import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d24_vidya_source_engine.dart';
import 'package:astro_app/astrology/d24_vidya_source_registry.dart';
import 'package:astro_app/astrology/d24_education_registry.dart';

const _chart = AstroChartResult(
  julianDay: 2451545, ayanamsaDegrees: 23,
  ascendantLongitude: 0.5, engineVersion: 'd24-upload-test',
  planets: [
    PlanetPosition(name:'Sun',shortName:'Su',longitude:27.5,latitude:0,speed:1),
    PlanetPosition(name:'Moon',shortName:'Mo',longitude:30.1,latitude:0,speed:1),
    PlanetPosition(name:'Mars',shortName:'Ma',longitude:2.5,latitude:0,speed:1),
    PlanetPosition(name:'Mercury',shortName:'Me',longitude:6.2,latitude:0,speed:1),
    PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:9.9,latitude:0,speed:1),
    PlanetPosition(name:'Venus',shortName:'Ve',longitude:31.3,latitude:0,speed:1),
    PlanetPosition(name:'Saturn',shortName:'Sa',longitude:38.9,latitude:0,speed:1),
    PlanetPosition(name:'Rahu',shortName:'Ra',longitude:65.1,latitude:0,speed:-1),
    PlanetPosition(name:'Ketu',shortName:'Ke',longitude:245.1,latitude:0,speed:-1),
  ],
);

void main(){
  test('24 subdivisions use 1 degree 15 minutes and 12 devatas repeat',(){
    expect(D24VidyaSourceEngine.devataForLongitude(0).name,'స్కంద');
    expect(D24VidyaSourceEngine.devataForLongitude(1.25).name,'పరశుధర');
    expect(D24VidyaSourceEngine.devataForLongitude(15).name,'స్కంద');
    expect(D24VidyaSourceEngine.devataForLongitude(29.999).name,'భీమ');
    expect(D24VidyaSourceEngine.devataForLongitude(30).name,'భీమ');
    expect(D24VidyaSourceEngine.devataForLongitude(31.25).name,'మదన');
    expect(D24VidyaSourceEngine.devataForLongitude(45).name,'భీమ');
    expect(D24VidyaSourceEngine.devataForLongitude(59.999).name,'స్కంద');
    expect(D24VidyaSourceEngine.devataForLongitude(0).part,1);
    expect(D24VidyaSourceEngine.devataForLongitude(29.99).part,24);
  });
  test('all source content and 26 education / 14 admission rules retained',(){
    expect(D24VidyaSourceRegistry.rules.length,56);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='CORE').length,6);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='FIELD').length,26);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='EXAM').length,6);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='ADMISSION').length,14);
    expect(D24VidyaSourceRegistry.rules.where((r)=>r.category=='TIMING').length,4);
    expect(D24VidyaSourceRegistry.catalogs.length,64);
    expect(D24VidyaSourceRegistry.rules.map((r)=>r.id).toSet().length,56);
  });
  test('chart-specific audit does not assert exact admissions or overwrite old sign natures',(){
    final items=D24VidyaSourceEngine.evaluate(_chart);
    expect(items.length,56);
    expect(items.every((e)=>e.label.contains('తుది నిర్ధారణ కాదు') || e.label.contains('పెండింగ్')),isTrue);
    expect(items.first.source.category,'CORE');
    expect(D24VidyaSourceEngine.allDevatas(_chart).length,10);
    expect(D24EducationRegistry.natureForSign(0),'Technical');
    expect(D24EducationRegistry.natureForSign(3),'Non-technical');
  });
}
