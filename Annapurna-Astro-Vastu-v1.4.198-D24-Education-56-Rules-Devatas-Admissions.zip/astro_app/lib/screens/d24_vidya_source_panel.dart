import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/d24_vidya_source_engine.dart';
import '../astrology/d24_vidya_source_registry.dart';

/// Distinct source-backed expansion of D24; existing Education.pdf evaluator
/// and its user-approved 4/9/2/7 continuity ladder remain unchanged.
class D24VidyaSourcePanel extends StatelessWidget {
  final AstroChartResult chart;
  const D24VidyaSourcePanel({super.key, required this.chart});

  static const _groups = <String,String>{
    'CORE':'సాధారణ విద్యా నియమాలు (6)',
    'FIELD':'ఏ విద్య చదువుతారు? 26 విద్యారంగ నియమాలు',
    'EXAM':'పోటీ పరీక్షల నియమాలు (6)',
    'ADMISSION':'IIT / AIIMS / IIM తదితర ప్రవేశ యోగాలు (14)',
    'TIMING':'చదువు / ప్రవేశ కాలనిర్ణయం (4)',
  };

  void _showRule(BuildContext context,D24VidyaRuleAudit audit) {
    final src=audit.source;
    showModalBottomSheet<void>(
      context:context, isScrollControlled:true, showDragHandle:true,
      backgroundColor:const Color(0xFFFFFAF8),
      builder:(ctx)=>SafeArea(top:false,child:SizedBox(
        height:MediaQuery.of(ctx).size.height*.78,
        child:DefaultTabController(length:3,child:Column(children:[
          Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:4),
            child:Text('${src.id} · ${src.topic}',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800))),
          const TabBar(tabs:[Tab(text:'ఫలితం'),Tab(text:'IF–THEN రూల్'),Tab(text:'జాతక పరిశీలన')]),
          Expanded(child:TabBarView(children:[
            _sheetText('ఫలితం (మూల పత్రం)', '${src.result}\n\n${audit.label}\n\nఈ నియమం వ్యక్తికి నిర్ధారణ అయిందని కాదు. ప్రవేశం/ర్యాంకు/కోర్సు ఖాయం అని చెప్పడం లేదు.'),
            _sheetText('IF (నియమం)', '${src.condition}\n\nTHEN: ${src.result}\n\nమూలం: ${D24VidyaSourceRegistry.sourceName}\nపేజీ: ${src.sourcePage}\nRule ID: ${src.id}'),
            _sheetText('D1 → D24 పరిశీలన', '${audit.explanation}\n\nపరిహారం: ఇచ్చిన విద్యా మూలపత్రంలో ఈ నిర్దిష్ట నియమానికి పరిహారం పేర్కొనలేదు.'),
          ])),
        ])),
      )),
    );
  }

  Widget _sheetText(String heading,String content) => SingleChildScrollView(
    padding:const EdgeInsets.all(18),
    child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(heading,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:16)),
      const SizedBox(height:12),SelectableText(content,style:const TextStyle(fontSize:15,height:1.55)),
    ]));

  @override
  Widget build(BuildContext context) {
    final audit=D24VidyaSourceEngine.evaluate(chart);
    final devatas=D24VidyaSourceEngine.allDevatas(chart);
    final supported=audit.where((x)=>x.hasSupportingEvidence).length;
    final lagna=devatas['లగ్నం'];
    final bySection = <String,List<D24VidyaCatalogRow>>{};
    for (final row in D24VidyaSourceRegistry.catalogs) {
      bySection.putIfAbsent(row.section,()=>[]).add(row);
    }
    return Card(
      color:const Color(0xFFF4F7FF),surfaceTintColor:Colors.transparent,
      margin:const EdgeInsets.symmetric(vertical:10),
      child:ExpansionTile(
        initiallyExpanded:true,
        leading:const Icon(Icons.school_rounded,color:Color(0xFF294875)),
        title:const Text('D24 — కొత్త విద్యా నియమాలు · ప్రవేశ పరీక్షలు',style:TextStyle(fontWeight:FontWeight.w900)),
        subtitle:Text('56 IF–THEN మూల నియమాలు · 26 విద్యా రంగాలు · 14 సంస్థలు · $supported సహాయక ఆధారాల పరిశీలనలు'),
        childrenPadding:const EdgeInsets.fromLTRB(10,0,10,16),
        children:[
          const Text('మూలం: విద్యా జ్యోతిష నియమాలు – D24.docx (9 పేజీలు). కొత్త నియమాలు పాత D24 గణనలు, శాతాలు, విద్యా స్థాయి నియమాలను మార్చవు.',style:TextStyle(fontSize:12.5,height:1.5)),
          const SizedBox(height:8),
          Card(color:Colors.white,child:Padding(padding:const EdgeInsets.all(10),child:
            Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text('లగ్న బిందువు D24 అంశదేవత: ${lagna?.name ?? 'లభించలేదు'} (భాగం ${lagna?.part ?? '-'} /24)',style:const TextStyle(fontWeight:FontWeight.w800)),
              const SizedBox(height:6),
              const Text('ప్రతి భాగం 1°15′. బేసి రాశి: స్కంద → భీమ; సరి రాశి: భీమ → స్కంద; 12 దేవతలు రెండుసార్లు వస్తారు.',style:TextStyle(fontSize:12.5)),
              ExpansionTile(tilePadding:EdgeInsets.zero,title:const Text('గ్రహాల అంశదేవతలు · పూర్తి గణన'),children:[
                ...devatas.entries.map((e)=>ListTile(dense:true,title:Text(e.key=='లగ్నం'?'లగ్నం':D24VidyaSourceEngine.teluguPlanet(e.key)),
                  trailing:Text('${e.value.name} · ${e.value.part}/24'),subtitle:Text(e.value.oddSign?'బేసి రాశి':'సరి రాశి'))),
              ]),
            ]))),
          const Text('సహాయక ఆధారం ఉందంటే పూర్తి IF షరతు సరిపోయిందని కాదు. గ్రహబలం, దృష్టులు, దశలు, వాస్తవ పరీక్ష సమాచారం ఇంకా cross-check చేయాలి.',style:TextStyle(fontSize:12,color:Color(0xFF6C4F40))),
          ..._groups.entries.map((g){
            final items=audit.where((x)=>x.source.category==g.key).toList();
            final evidence=items.where((x)=>x.hasSupportingEvidence).length;
            return Card(color:Colors.white,child:ExpansionTile(
              initiallyExpanded:g.key=='FIELD',
              title:Text(g.value,style:const TextStyle(fontWeight:FontWeight.w800)),
              subtitle:Text('${items.length} రూల్స్ · $evidence ప్రాథమిక ఆధారాలు'),
              children:items.map((item)=>ListTile(
                leading:Icon(item.hasSupportingEvidence?Icons.fact_check_outlined:Icons.menu_book_outlined,
                  color:item.hasSupportingEvidence?const Color(0xFF2A745D):Colors.blueGrey),
                title:Text('${item.source.id} · ${item.source.topic}'),
                subtitle:Text('${item.label}\n${item.source.result}',maxLines:3,overflow:TextOverflow.ellipsis),
                isThreeLine:true,
                trailing:const Icon(Icons.chevron_right),
                onTap:()=>_showRule(context,item),
              )).toList(),
            ));
          }),
          Card(color:Colors.white,child:ExpansionTile(
            title:const Text('పూర్తి కోర్సులు / పరీక్షలు / విద్యాసంస్థల జాబితా (64)',style:TextStyle(fontWeight:FontWeight.w800)),
            subtitle:const Text('ఆధునిక · విదేశీ · సంప్రదాయ · గూఢ విద్య · ప్రవేశ పరీక్షలు · సంస్థలు'),
            children:bySection.entries.map((section)=>ExpansionTile(
              title:Text('${section.key} (${section.value.length})',style:const TextStyle(fontWeight:FontWeight.w700)),
              children:section.value.map((row)=>ListTile(dense:true,
                title:Text(row.title),subtitle:Text('${row.details}\nమూల పేజీ ${row.sourcePage}'))).toList(),
            )).toList(),
          )),
          const SizedBox(height:7),
          const Text('ప్రవేశ పరీక్ష ఫలితాలు లేదా విద్యాసంస్థల సీట్లు జ్యోతిష నియమంతో ఖచ్చితంగా నిర్ధారించలేం. D24 అంశదేవతలకు ఆధునిక విద్యారంగ అన్వయం ఈ పత్రంలోని వ్యాఖ్యానం; ప్రామాణిక శ్లోక మూలం అని సూచించడం లేదు.',style:TextStyle(fontSize:11.5,height:1.45,color:Colors.black54)),
        ],
      ),
    );
  }
}
