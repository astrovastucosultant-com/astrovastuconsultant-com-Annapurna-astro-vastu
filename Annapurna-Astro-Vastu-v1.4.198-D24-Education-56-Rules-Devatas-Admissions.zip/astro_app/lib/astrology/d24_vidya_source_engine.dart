import 'astro_models.dart';
import 'varga_service.dart';
import 'd24_vidya_source_registry.dart';

/// A natal (D1 sidereal) longitude determines a D24 1°15' subdivision.
/// Do not divide D24 remapped longitudes a second time.
class D24VidyaDevata {
  final int part;
  final String name;
  final bool oddSign;
  final double natalDegreesInSign;
  const D24VidyaDevata(this.part, this.name, this.oddSign, this.natalDegreesInSign);
}

class D24VidyaRuleAudit {
  final D24VidyaSourceRule source;
  final bool devataSupport;
  final bool relevantHouseSupport;
  final bool planetRelationSupport;
  final String explanation;
  const D24VidyaRuleAudit({required this.source, required this.devataSupport,
      required this.relevantHouseSupport, required this.planetRelationSupport,
      required this.explanation});

  /// Positive partial evidence is not a verified full IF-THEN condition.
  bool get hasSupportingEvidence => devataSupport || relevantHouseSupport || planetRelationSupport;
  String get label => hasSupportingEvidence ? 'సహాయక ఆధారాలు — తుది నిర్ధారణ కాదు' : 'పూర్తి పరిశీలన పెండింగ్';
}

class D24VidyaSourceEngine {
  static const _signLords = <String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];
  static const _teluguNames = <String,String>{
    'Sun':'సూర్యుడు','Moon':'చంద్రుడు','Mars':'కుజుడు',
    'Mercury':'బుధుడు','Jupiter':'గురువు','Venus':'శుక్రుడు',
    'Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు',
  };

  static D24VidyaDevata devataForLongitude(double longitude) {
    final normalized = (longitude % 360.0 + 360.0) % 360.0;
    final sign = (normalized / 30.0).floor();
    final degree = normalized % 30.0;
    final part = (degree / 1.25).floor().clamp(0,23).toInt();
    final isOddSign = sign.isEven; // Aries=0, Taurus=1
    final deityIndex = isOddSign ? (part % 12) : (11 - (part % 12));
    return D24VidyaDevata(part+1, D24VidyaSourceRegistry.oddDevatas[deityIndex], isOddSign, degree);
  }

  static String signLord(int sign) => _signLords[((sign%12)+12)%12];
  static String teluguPlanet(String name) => _teluguNames[name] ?? name;

  static Map<String,D24VidyaDevata> allDevatas(AstroChartResult chart) => {
    'లగ్నం': devataForLongitude(chart.ascendantLongitude),
    for (final planet in chart.planets)
      planet.name: devataForLongitude(planet.longitude),
  };

  static List<D24VidyaRuleAudit> evaluate(AstroChartResult chart) {
    final d24 = VargaService.calculate(chart,24);
    final perPlanet = {
      for (final p in d24.planets) p.name: p,
    };
    final devatas = allDevatas(chart);
    int? houseOf(String planet) {
      final p = perPlanet[planet];
      if (p == null) return null;
      return ((p.signIndex-d24.ascendantSignIndex+12)%12)+1;
    }
    final audits = <D24VidyaRuleAudit>[];
    for (final rule in D24VidyaSourceRegistry.rules) {
      final present = rule.planets.where((x)=>perPlanet.containsKey(x)).toList();
      final deityEvidence = rule.devatas.isNotEmpty &&
          present.any((p)=>rule.devatas.contains(devatas[p]?.name));
      // House evidence: named significator occupies an indicated D24 house,
      // or is the lord of that house. This is one reproducible direct link;
      // it does NOT establish all aspects, strengths or cuspal relations.
      final houseEvidence = rule.houses.isNotEmpty && present.any((name) =>
        rule.houses.any((house) => houseOf(name)==house ||
            signLord((d24.ascendantSignIndex+house-1)%12)==name));
      // Explicit conjunction only. '+' in source may mean several other
      // sambandhas; these remain pending rather than being guessed.
      final conjunctionEvidence = present.length >= 2 &&
          present.length == rule.planets.length &&
          present.any((a) => present.any((b) => a != b &&
              perPlanet[a]!.signIndex == perPlanet[b]!.signIndex));
      final notes = <String>['D24 లగ్న రాశి index: ${d24.ascendantSignIndex+1}.'];
      if (rule.planets.isNotEmpty) {
        for (final p in rule.planets) {
          final h = houseOf(p);
          final devata = devatas[p];
          notes.add('${teluguPlanet(p)}: D24 భావం ${h ?? 'లభించలేదు'}; అంశదేవత ${devata?.name ?? 'లభించలేదు'}${devata == null ? '' : ' (భాగం ${devata.part}/24)'}.');
        }
      }
      if (rule.devatas.isNotEmpty) {
        notes.add('మూల నియమ దేవతలు: ${rule.devatas.join(' / ')}. పేర్కొన్న గ్రహాల్లో అంశదేవత మద్దతు: ${deityEvidence ? 'ఉంది' : 'లేదు / పెండింగ్'}.');
      }
      if (rule.houses.isNotEmpty) {
        notes.add('మూలంలో పరిశీలించాల్సిన భావాలు: ${rule.houses.join(', ')}. ప్రత్యక్ష గ్రహ–భావ లేదా భావాధిపతి లింక్: ${houseEvidence ? 'ఉంది' : 'ఇంకా ధృవీకరించలేదు'}.');
      }
      if (rule.planets.length >= 2) {
        notes.add('సూచించిన గ్రహాల్లో D24 ఒకే రాశి కలయిక: ${conjunctionEvidence ? 'ఉంది' : 'లేదు'}. ఇతర దృష్టులు/సంబంధాలు ఇంకా ఆటోగా ధృవీకరించలేదు.');
      }
      notes.add('ఇది chart-supported partial audit మాత్రమే. పూర్తి గ్రహబలం, దృష్టి, పోటీ పరీక్ష షరతులు, దశ/అంతర్దశ లేదా ప్రవేశ ఫలితాన్ని నిర్ధారించడం లేదు.');
      audits.add(D24VidyaRuleAudit(source:rule, devataSupport:deityEvidence,
          relevantHouseSupport:houseEvidence, planetRelationSupport:conjunctionEvidence,
          explanation:notes.join('\n')));
    }
    return audits;
  }
}
