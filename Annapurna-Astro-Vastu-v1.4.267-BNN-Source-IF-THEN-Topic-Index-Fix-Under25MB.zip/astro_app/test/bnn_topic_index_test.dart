import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_bhava_topics.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';
import 'package:astro_app/astrology/bnn_topic_index.dart';

BnnMasterRule sample(String result, {String topic = 'శుక్రుడు / వివాహం / ధనం'}) => BnnMasterRule(
  id: 'example', source: 'BNN N', sourcePage: 34,
  topic: topic, condition: 'శని—శుక్రుడు', result: result,
  inspection: '', remedy: '', status: 'FACTS_REQUIRED',
);

void main() {
  test('Every available navigation title has explicit outcome terms', () {
    for (final topic in BnnBhavaTopicService.byHouse.expand((x) => x)) {
      expect(BnnTopicIndex.resultTerms[topic.name], isNotEmpty);
    }
  });

  test('Finance synonyms index source THEN, not a fabricated result', () {
    const savings = BnnBhavaTopic(2, 'ధన నిల్వ', 'Venus');
    final matched = sample('జాతకుడు సంపదను పొందుతాడు.');
    expect(BnnTopicIndex.belongs(savings, matched), isTrue);
  });

  test('BNN methodological principles are not personal outcomes', () {
    const topic = BnnBhavaTopic(2, 'ఆదాయ మార్గాలు', 'Saturn');
    final lesson = BnnMasterRule(
      id: 'BNN-BOOK-R-A08', source: 'source', sourcePage: 1,
      topic: 'BNN మూల పద్ధతి', condition: 'గురు ఏ గ్రహాన్ని తాకితే',
      result: 'ఆ కారక ఫలితం వస్తుంది (శుక్ర = ధనం)',
      inspection: '', remedy: '', status: 'OCR_REVIEW');
    expect(BnnTopicIndex.belongs(topic, lesson), isFalse);
  });

  test('Only the source topic text is not sufficient', () {
    const savings = BnnBhavaTopic(2, 'ధన నిల్వ', 'Venus');
    final other = sample('వివాహం ఆలస్యమవుతుంది.', topic: 'ధన నిల్వ');
    expect(BnnTopicIndex.belongs(savings, other), isFalse);
  });

  test('Father THEN indexes ninth bhava without guesswork about IF', () {
    const father = BnnBhavaTopic(9, 'తండ్రి', 'Sun');
    final result = sample('తండ్రికి గౌరవం ఉంటుంది.', topic: 'సూర్యుడు / తండ్రి / గౌరవం');
    expect(BnnTopicIndex.belongs(father, result), isTrue);
  });

  test('Unrelated relatives outcomes never look like sibling earnings', () {
    const siblings = BnnBhavaTopic(3, 'సోదరులు', 'Mars');
    final other = sample('వ్యక్తి కుటుంబం నుండి దూరంగా ఉంటాడు.');
    expect(BnnTopicIndex.belongs(siblings, other), isFalse);
  });
}
