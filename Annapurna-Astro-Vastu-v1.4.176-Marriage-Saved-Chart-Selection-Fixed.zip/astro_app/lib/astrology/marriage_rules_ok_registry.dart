/// Indexed topics from the user's earlier Annapurna V51 Marriage source
/// list. This is a NAVIGATIONAL INDEX to the 39-page scanned source,
/// not an assertion that each rule has a validated IF-THEN implementation.
/// Physical page numbers are preserved from the historical V51 source list.
class MarriageBookTopic {
  final String id;
  final String title;
  final String focus;
  final int page;
  final bool requiresTwoCharts;

  const MarriageBookTopic({
    required this.id,
    required this.title,
    required this.focus,
    required this.page,
    required this.requiresTwoCharts,
  });
}

class MarriageRulesOkRegistry {
  static const String sourceName = 'Marrage rules ok.pdf';
  static const List<MarriageBookTopic> topics = [
    MarriageBookTopic(id: 'M-01', title: 'జాతకుని ధర్మ/వివాహ ప్రాథమిక పరిశీలన', focus: 'D1: 7వ భావం, 7వ అధిపతి, సంబంధిత కారక గ్రహాలు', page: 6, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-02', title: 'ధర్మము / బృహస్పతి పాత్ర', focus: 'Jupiter + 7th-house marriage indicators', page: 6, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-03', title: 'నవాంశ చక్ర పరిశీలన', focus: 'D9 Lagna, D9 7th house and D9 7th lord', page: 7, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-04', title: 'నవాంశ ఉపచయ భావాల పరిశీలన', focus: 'D9 Upachaya 3/6/10/11 occupancy, source rule 04', page: 7, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-05', title: 'ప్రేమ వ్యవహార యోగము — రాశి చక్రం', focus: 'D1 5th/7th factors and their links', page: 8, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-06', title: 'ప్రేమ వ్యవహార యోగము — నవాంశం', focus: 'D9 marriage/love indicators', page: 8, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-07', title: 'అరేంజ్డ్ వివాహ యోగము — రాశి', focus: 'D1 7th-house based arranged-marriage indicators', page: 9, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-08', title: 'అరేంజ్డ్ వివాహ యోగము — నవాంశం', focus: 'D9 7th-house based confirmation', page: 10, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-09', title: 'కులాంతర వివాహ యోగము', focus: 'D1/D9 source conditions for inter-caste marriage', page: 10, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-10', title: 'శీఘ్ర వివాహ యోగము', focus: 'Source rapid-marriage combinations; D1/D9 cross-check', page: 10, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-11', title: 'శీఘ్ర వివాహం — చంద్రుని పాత్ర', focus: 'Moon-related source condition', page: 11, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-12', title: 'శీఘ్ర వివాహం — కేతువు పాత్ర', focus: 'Ketu-related source condition', page: 11, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-13', title: 'శీఘ్ర వివాహం — 11వ భావాధిపతి', focus: '11th-lord relationship used by source', page: 11, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-14', title: 'ఆలస్య వివాహ యోగము', focus: 'Source delayed-marriage conditions', page: 11, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-15', title: 'సప్తమాంశంలో గురువు పాత్ర', focus: 'D7 Jupiter and marriage-related support', page: 12, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-16', title: 'సప్తమాంశంలో శని పాత్ర', focus: 'D7 Saturn and delay/modification layer', page: 12, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-17', title: 'సప్తమాంశంలో కుజ దోషము', focus: 'D7 Mars-related condition from source', page: 12, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-18', title: 'సప్తమాంశ 7వ భావంలోని గ్రహాలు', focus: 'D7 7th-house occupants', page: 12, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-19', title: 'వివాహ సంవత్సరము — దశా పద్ధతులు', focus: 'Marriage-year timing through source dasa methods', page: 12, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-20', title: 'వివాహ సంవత్సరము — చర దశ', focus: 'Chara Dasha timing layer', page: 14, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-21', title: 'వివాహ సంవత్సరము — K.N. Rao పద్ధతి', focus: 'K.N. Rao timing layer as presented in source', page: 14, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-22', title: 'వివాహ సంవత్సరము — ఇతర దశా పద్ధతి', focus: 'Additional source dasa method', page: 15, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-23', title: 'వివాహ సంవత్సరము — త్రిభాగి దశ', focus: 'Tribhangi/three-part dasa timing layer', page: 15, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-24', title: 'వివాహ సంవత్సర గోచార నిర్ణయము', focus: 'Transit confirmation for marriage year', page: 15, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-25', title: 'నవాంశం ద్వారా సంవత్సర గోచారం', focus: 'D9 transit-year method', page: 16, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-26', title: 'సప్తమాంశం ద్వారా సంవత్సర గోచారం', focus: 'D7 transit-year method', page: 16, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-27', title: 'సర్వాష్టకవర్గం ద్వారా సంవత్సర నిర్ణయము', focus: 'SAV transit support for marriage year', page: 16, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-28', title: 'వివాహ మాస నిర్ణయము', focus: 'Month-level marriage timing framework', page: 17, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-29', title: 'రాశి చక్రం ద్వారా రవి గోచారం — మాసం', focus: 'D1 Sun transit month trigger', page: 18, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-30', title: 'సప్తమాంశం ద్వారా రవి గోచారం — మాసం', focus: 'D7 Sun transit month trigger', page: 18, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-31', title: 'Rule of Three — మాసం', focus: 'Source Rule-of-Three month calculation', page: 19, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-32', title: 'వివాహ దిన గోచార నిర్ణయము', focus: 'Day-level transit framework', page: 20, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-33', title: 'రాశి చక్రం ద్వారా చంద్ర గోచారం — రోజు', focus: 'D1 Moon transit day trigger', page: 20, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-34', title: 'సప్తమాంశం ద్వారా చంద్ర గోచారం — రోజు', focus: 'D7 Moon transit day trigger', page: 20, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-35', title: 'Rule of Three — రోజు', focus: 'Source Rule-of-Three day calculation', page: 20, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-36', title: 'సప్తమాంశం ద్వారా వివాహ లగ్న గోచారం', focus: 'D7-based marriage ascendant timing', page: 21, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-37', title: 'వైవాహిక జీవితం — రాశి చక్ర నియమాలు', focus: 'D1 post-marriage relationship/stability indicators', page: 22, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-38', title: 'వైవాహిక జీవితం — నవాంశ నియమాలు', focus: 'D9 post-marriage relationship/stability indicators', page: 22, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-39', title: 'వివాహ జీవితం — సంబంధాలపై source conditions', focus: 'Marriage relationship indicators from source', page: 23, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-40', title: 'విడాకుల సూచనలు', focus: 'Source divorce-related chart conditions; non-deterministic review only', page: 23, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-41', title: 'సప్తమాంశ చక్ర నియమాలు', focus: 'D7 relationship/marriage rules', page: 23, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-42', title: 'వివాహ భాగస్వామి/విధి సంబంధిత నియమాలు', focus: 'Source spouse-related indicators; death/longevity claims are excluded from app output', page: 24, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-43', title: 'వివాహ కారకులు మరియు నవాంశ నియమాలు', focus: 'Marriage significators + D9 conditions', page: 24, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-44', title: 'మొదటి / రెండవ వివాహ నియమాలు', focus: 'Source first/second-marriage combinations; relationship analysis only', page: 25, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-45', title: 'అవివాహ యోగ నిర్ణయము', focus: 'Source non-marriage combinations; shown as rule-review only', page: 27, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-46', title: 'అవివాహం — రాశి చక్ర నియమాలు', focus: 'D1 conditions', page: 27, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-47', title: 'అవివాహం — జైమిని పద్ధతి', focus: 'Jaimini conditions', page: 27, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-48', title: 'నవాంశ + త్రింశాంశ నియమాలు', focus: 'D9 + D30 cross-check', page: 28, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-49', title: 'వివాహ జాతక సమన్వయ నిర్ణయము', focus: 'D1/D9/D7 cross-chart synthesis', page: 29, requiresTwoCharts: false),
    MarriageBookTopic(id: 'M-50', title: 'జన్మ దశా-భుక్తి నాధుల నియమము', focus: 'Birth Dasha/Bhukti lords', page: 29, requiresTwoCharts: true),
    MarriageBookTopic(id: 'M-51', title: 'ప్రస్తుత దశా-భుక్తి నాధుల నియమము', focus: 'Current Dasha/Bhukti timing layer', page: 29, requiresTwoCharts: true),
    MarriageBookTopic(id: 'M-52', title: 'కుజ దోషము', focus: 'Source Manglik/Mars-dosha rule set', page: 30, requiresTwoCharts: true),
    MarriageBookTopic(id: 'M-53', title: 'నాడీ కూటము', focus: 'Nadi-koota matching framework, source nadi table', page: 37, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-01', title: 'జన్మ దశా–భుక్తి నాధులు — నియమం 01', focus: 'Birth dasha/bhukti lords and two-chart source contacts', page: 34, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-02', title: 'జన్మ దశా–భుక్తి నాధులు — నియమం 02', focus: 'Birth dasha/bhukti lords and chart relationship source check', page: 34, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-03', title: 'కుజ దోషము — D7 గ్రహసంబంధ పట్టిక (నియమం 03)', focus: 'D7 Mars in 2/4/7/8/12 and other planetary contacts', page: 35, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-04', title: 'కుజ దోషము — శుభ/అశుభ జంటలు (నియమం 04)', focus: 'Source auspicious and inauspicious sign combinations', page: 35, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-05', title: 'వేధ దోషము — శుభ/అశుభ వర్గాలు (నియమం 05)', focus: 'Source Vedha good/bad nakshatra classification', page: 36, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-06', title: 'వేధ నక్షత్రాలు — గ్రంథ చిత్రం (నియమం 06)', focus: 'Source Vedha nakshatra diagram', page: 36, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-07', title: 'నాడీ కూటము — ఆది/మధ్య/అంత్య', focus: 'Nadi categories and compatibility table', page: 37, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-08', title: 'రజ్జు కూటము', focus: 'Source Rajju nakshatra classification table', page: 37, requiresTwoCharts: true),
    MarriageBookTopic(id: 'N-09', title: 'భూత కూటము', focus: 'Source Bhuta-koota compatibility table', page: 38, requiresTwoCharts: true),
  ];

  static List<MarriageBookTopic> forIndividual() =>
      topics.where((e) => !e.requiresTwoCharts).toList(growable: false);

  static List<MarriageBookTopic> forMatching() =>
      topics.where((e) => e.requiresTwoCharts).toList(growable: false);
}
