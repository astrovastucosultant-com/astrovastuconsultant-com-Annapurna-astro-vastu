import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/screens/marriage_reviewed_sources_screen.dart';

void main() {
  test('all three reviewed source volumes retain each scanned page', () {
    expect(ReviewedMarriageSources.pageCounts.length, 3);
    final pageCount = ReviewedMarriageSources.pageCounts.values
        .fold<int>(0, (sum, value) => sum + value);
    expect(pageCount, 88);

    for (final id in ReviewedMarriageSources.names.keys) {
      for (var page = 1;
          page <= ReviewedMarriageSources.pageCounts[id]!;
          page++) {
        final asset = ReviewedMarriageSources.assetPath(id, page);
        expect(File(asset).existsSync(), true, reason: asset);
      }
    }
  });

  test('a source page path is bounded by the actual volume', () {
    expect(ReviewedMarriageSources.assetPath('handwritten', 17),
        'assets/marriage_sources/handwritten/page_17.webp');
    expect(() => ReviewedMarriageSources.assetPath('handwritten', 21),
        throwsRangeError);
    expect(() => ReviewedMarriageSources.assetPath('unknown', 1),
        throwsArgumentError);
  });
}
