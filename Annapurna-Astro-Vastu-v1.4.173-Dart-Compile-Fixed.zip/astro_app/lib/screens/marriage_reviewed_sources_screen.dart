import 'package:flutter/material.dart';
import 'marriage_book_topics_screen.dart';

/// These are images of the actual pages supplied by the user, NOT machine
/// transcriptions or additional automatically-evaluated predicates.
/// Reviewed-by credit is provided by the user. Original book authorship is
/// not reassigned.
class ReviewedMarriageSources {
  static const reviewer = 'సిద్ధాంతి మల్లికార్జున పరిశీలించిన నియమాలు';
  static const handwritten = 'handwritten';
  static const marriageRules = 'marriage_rules';
  static const marriage2 = 'marriage_2';

  static const Map<String, String> names = {
    handwritten: 'marriage my meterial.pdf',
    marriageRules: 'Marrage rules ok.pdf',
    marriage2: 'Marrage -2.pdf',
  };
  static const Map<String, int> pageCounts = {
    handwritten: 20,
    marriageRules: 39,
    marriage2: 29,
  };

  static String assetPath(String sourceId, int page) {
    if (!pageCounts.containsKey(sourceId)) {
      throw ArgumentError.value(sourceId, 'sourceId', 'Unknown source');
    }
    final count = pageCounts[sourceId]!;
    if (page < 1 || page > count) {
      throw RangeError.range(page, 1, count, 'page');
    }
    return 'assets/marriage_sources/$sourceId/page_${page.toString().padLeft(2, '0')}.webp';
  }

  static void openPage(BuildContext context, String sourceId, int page) {
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => MarriageReviewedSourcePageScreen(
        sourceId: sourceId,
        initialPage: page,
      ),
    ));
  }
}

/// Browsable index for all 88 original scanned pages.
class MarriageReviewedSourcesScreen extends StatelessWidget {
  const MarriageReviewedSourcesScreen({super.key});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('వివాహ మూల గ్రంథాలు')),
    body: ListView(padding: const EdgeInsets.all(12), children: [
      const Card(child: Padding(
        padding: EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(ReviewedMarriageSources.reviewer,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('మూలం యథాతథంగా: 20 + 39 + 29 = 88 స్కాన్ పేజీలు. '
              'పేజీలపై జూమ్ చేసి అసలు జ్యోతిష సూత్రాలు చూడవచ్చు.'),
          SizedBox(height: 6),
          Text('మూల గ్రంథ రచయిత పేర్లను మార్చలేదు. మూల పేజీ ఉండటం '
              'ఆటోమేటిక్ IF–THEN గణన పూర్తయిందని అర్థం కాదు.'),
        ]),
      )),
      Card(child: ListTile(
        leading: const Icon(Icons.format_list_numbered),
        title: const Text('వివాహ నియమాల PDF — 62 విషయసూచిక అంశాలు'),
        subtitle: const Text('మూల నియమం, పేజీ వారీగా వెతికి చూడండి'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => const MarriageBookTopicsScreen(),
        )),
      )),
      for (final id in ReviewedMarriageSources.names.keys)
        Card(child: ListTile(
          leading: const Icon(Icons.auto_stories_outlined),
          title: Text(ReviewedMarriageSources.names[id]!),
          subtitle: Text('${ReviewedMarriageSources.pageCounts[id]} అసలు పేజీలు'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => ReviewedMarriageSources.openPage(context, id, 1),
        )),
    ]),
  );
}

/// The page is rendered as a picture of the user's actual source, with a
/// bounded pinch-to-zoom surface. No OCR-derived text is substituted for it.
class MarriageReviewedSourcePageScreen extends StatefulWidget {
  final String sourceId;
  final int initialPage;

  const MarriageReviewedSourcePageScreen({
    super.key,
    required this.sourceId,
    this.initialPage = 1,
  });

  @override
  State<MarriageReviewedSourcePageScreen> createState() =>
      _MarriageReviewedSourcePageScreenState();
}

class _MarriageReviewedSourcePageScreenState
    extends State<MarriageReviewedSourcePageScreen> {
  late final PageController controller;
  late int currentPage;

  @override
  void initState() {
    super.initState();
    final count = ReviewedMarriageSources.pageCounts[widget.sourceId] ?? 1;
    currentPage = widget.initialPage.clamp(1, count).toInt();
    controller = PageController(initialPage: currentPage - 1);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void goTo(int page) {
    final count = ReviewedMarriageSources.pageCounts[widget.sourceId] ?? 1;
    if (page < 1 || page > count) return;
    controller.jumpToPage(page - 1);
    setState(() => currentPage = page);
  }

  @override
  Widget build(BuildContext context) {
    final count = ReviewedMarriageSources.pageCounts[widget.sourceId] ?? 1;
    final title = ReviewedMarriageSources.names[widget.sourceId] ?? '';
    return Scaffold(
      appBar: AppBar(title: Text(title, overflow: TextOverflow.ellipsis)),
      body: SafeArea(child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          child: Text(ReviewedMarriageSources.reviewer,
              style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          IconButton(
            tooltip: 'మునుపటి పేజీ',
            icon: const Icon(Icons.chevron_left),
            onPressed: currentPage == 1 ? null : () => goTo(currentPage - 1),
          ),
          Tooltip(
            message: 'పేజీ సంఖ్య ఎంచుకోండి',
            child: DropdownButton<int>(
              value: currentPage,
              items: List.generate(count, (index) => DropdownMenuItem<int>(
                value: index + 1, child: Text('పేజీ ${index + 1} / $count'),
              )),
              onChanged: (p) { if (p != null) goTo(p); },
            ),
          ),
          IconButton(
            tooltip: 'తరువాతి పేజీ',
            icon: const Icon(Icons.chevron_right),
            onPressed: currentPage == count ? null : () => goTo(currentPage + 1),
          ),
        ]),
        const Text('చదవడానికి రెండు వేళ్లతో జూమ్ చేయండి',
            style: TextStyle(fontSize: 12, color: Colors.black54)),
        Expanded(child: PageView.builder(
          controller: controller,
          itemCount: count,
          onPageChanged: (index) => setState(() => currentPage = index + 1),
          itemBuilder: (context, index) => InteractiveViewer(
            key: ValueKey('${widget.sourceId}-${index + 1}'),
            minScale: 0.8,
            maxScale: 6,
            child: Center(child: Image.asset(
              ReviewedMarriageSources.assetPath(widget.sourceId, index + 1),
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) =>
                  const Text('మూల పేజీ చిత్రం అందుబాటులో లేదు'),
            )),
          ),
        )),
      ])),
    );
  }
}
