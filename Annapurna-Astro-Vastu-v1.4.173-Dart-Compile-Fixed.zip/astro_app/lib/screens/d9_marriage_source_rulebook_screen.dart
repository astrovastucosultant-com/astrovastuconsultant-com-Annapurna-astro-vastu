import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/marriage_chart_evidence_service.dart';
import '../astrology/marriage_material_registry.dart';
import 'marriage_book_topics_screen.dart';
import 'marriage_reviewed_sources_screen.dart';
import 'marriage_rule_drill_down.dart';

/// Personal D9 marriage material, with genuine chart positions and original
/// scanned pages. Missing IF-THEN logic remains explicitly pending.
class D9MarriageSourceRulebookScreen extends StatefulWidget {
  final AstroChartResult? chart;
  const D9MarriageSourceRulebookScreen({super.key, this.chart});

  @override
  State<D9MarriageSourceRulebookScreen> createState() =>
      _D9MarriageSourceRulebookScreenState();
}

class _D9MarriageSourceRulebookScreenState
    extends State<D9MarriageSourceRulebookScreen> {
  String search = '';

  String displayTopic(MarriageMaterialRuleEntry r) {
    if (r.topic.contains('rule ') ||
        r.topic.startsWith('D7 rule') ||
        r.topic.startsWith('నవాంశ rule')) {
      return 'మూల వివాహ సూత్రం ${r.id.replaceFirst('MM-', '')}';
    }
    return r.topic;
  }

  @override
  Widget build(BuildContext context) {
    final allRules = MarriageMaterialRegistry.individualForFactor(9);
    final q = search.trim().toLowerCase();
    final rules = allRules.where((r) => q.isEmpty ||
        r.id.toLowerCase().contains(q) ||
        r.topic.toLowerCase().contains(q) ||
        '${r.page}'.contains(q)).toList(growable: false);
    return Scaffold(
      appBar: AppBar(title: const Text('D9 — వ్యక్తిగత వివాహ నియమాలు')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text(ReviewedMarriageSources.reviewer,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('D9, D1, D7 ఆధారాలు • ${allRules.length} వ్యక్తిగత మూల రికార్డులు. '
                'నియమం టచ్ చేస్తే అసలు పేజీ, జాతక గణన స్థానాలు చూడవచ్చు.'),
            const SizedBox(height: 8),
            Text(widget.chart == null
                ? 'జాతకాన్ని తెరిస్తే గ్రహ/భావ స్థానాలను కూడా చూడవచ్చు.'
                : 'ప్రస్తుత జాతకంలోని గ్రహ/భావ స్థానాలు అందుబాటులో ఉన్నాయి. '
                    'సూత్రం నిర్ధారణ పెండింగ్ అయితే ఫలితం ఇవ్వము.'),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => const MarriageReviewedSourcesScreen(),
              )),
              icon: const Icon(Icons.auto_stories_outlined),
              label: const Text('మూడు మూల గ్రంథాలు — మొత్తం 88 పేజీలు'),
            ),
            OutlinedButton.icon(
              onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                builder: (_) => MarriageBookTopicsScreen(
                  scope: MarriageBookTopicScope.individual,
                  chart: widget.chart,
                ),
              )),
              icon: const Icon(Icons.menu_book_outlined),
              label: const Text('వివాహ PDF — అంశాల వారీ నియమాల సూచిక'),
            ),
          ]),
        )),
        TextField(
          decoration: const InputDecoration(
            labelText: 'MM నియమం / పేజీ వెతకండి',
            prefixIcon: Icon(Icons.search), border: OutlineInputBorder(),
          ),
          onChanged: (value) => setState(() => search = value),
        ),
        const SizedBox(height: 8),
        Text('చూపిస్తున్నవి: ${rules.length} / ${allRules.length}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        for (final r in rules)
          Builder(builder: (context) {
            final sourceId = r.id == 'MM-D7-DIV-35'
                ? ReviewedMarriageSources.marriageRules
                : ReviewedMarriageSources.handwritten;
            final validPage = r.page >= 1 &&
                r.page <= ReviewedMarriageSources.pageCounts[sourceId]!;
            return Card(child: ExpansionTile(
              key: ValueKey(r.id),
              title: Text('${r.id} — ${displayTopic(r)}'),
              subtitle: Text('మూల పేజీ ${r.page} • పూర్తి సూత్ర గణన పెండింగ్'),
              childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 10),
              children: [
                MarriageRuleDrillDown(
                  resultText: 'మూల రికార్డు నమోదైంది • ఆటో గణన ధృవీకరణ పెండింగ్',
                  ruleText: '${displayTopic(r)}\n'
                      '${r.note.startsWith('Handwritten') ? 'చేతిరాత మూల నియమం — పూర్తి సూత్రం అసలు పేజీలో చూడాలి.' : r.note}\n'
                      'పూర్తి IF–THEN నియమం ఈ మూల పేజీలో పరిశీలించాలి.',
                  sourceText: '${ReviewedMarriageSources.names[sourceId]} • పుట ${r.page}',
                  onOpenSource: validPage ? () => ReviewedMarriageSources.openPage(
                      context, sourceId, r.page) : null,
                  examinationText: MarriageChartEvidenceService.forFactors(
                      widget.chart, r.factors),
                ),
                if (validPage) ...[
                  const SizedBox(height: 8),
                  InkWell(
                    onTap: () => ReviewedMarriageSources.openPage(context, sourceId, r.page),
                    child: Image.asset(
                      ReviewedMarriageSources.assetPath(sourceId, r.page),
                      height: 210, fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) =>
                          const Text('మూల పేజీ అందుబాటులో లేదు'),
                    ),
                  ),
                ],
              ],
            ));
          }),
      ]),
    );
  }
}
