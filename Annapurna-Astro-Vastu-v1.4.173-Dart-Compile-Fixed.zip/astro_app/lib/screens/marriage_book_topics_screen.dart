import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/marriage_chart_evidence_service.dart';
import '../astrology/marriage_rules_ok_registry.dart';
import 'marriage_reviewed_sources_screen.dart';
import 'marriage_rule_drill_down.dart';

enum MarriageBookTopicScope { all, individual, matching }

/// Actual Flutter rule/topic explorer for the original 39-page source.
/// Its titles and page numbers come from the earlier user project catalogue.
/// These are *indexed topics*, not 62 newly implemented predicates.
class MarriageBookTopicsScreen extends StatefulWidget {
  final MarriageBookTopicScope scope;
  final AstroChartResult? chart;

  const MarriageBookTopicsScreen({
    super.key,
    this.scope = MarriageBookTopicScope.all,
    this.chart,
  });

  @override
  State<MarriageBookTopicsScreen> createState() =>
      _MarriageBookTopicsScreenState();
}

class _MarriageBookTopicsScreenState extends State<MarriageBookTopicsScreen> {
  String query = '';

  @override
  Widget build(BuildContext context) {
    final topics = switch (widget.scope) {
      MarriageBookTopicScope.all => MarriageRulesOkRegistry.topics,
      MarriageBookTopicScope.individual => MarriageRulesOkRegistry.forIndividual(),
      MarriageBookTopicScope.matching => MarriageRulesOkRegistry.forMatching(),
    };
    final q = query.toLowerCase().trim();
    final visible = topics.where((r) => q.isEmpty ||
        r.id.toLowerCase().contains(q) ||
        r.title.toLowerCase().contains(q) ||
        r.focus.toLowerCase().contains(q) ||
        '${r.page}'.contains(q)).toList(growable: false);
    return Scaffold(
      appBar: AppBar(title: const Text('వివాహ గ్రంథం — నియమాల సూచిక')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        const Card(child: Padding(padding: EdgeInsets.all(12), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(ReviewedMarriageSources.reviewer,
                style: TextStyle(fontWeight: FontWeight.w800)),
            SizedBox(height: 6),
            Text('Marrage rules ok.pdf — అసలు 39 పేజీలు. '
                'పాత యాప్‌లో నమోదైన అంశాల పేర్లు, పేజీ సూచికలతో అనుసంధానం.'),
            SizedBox(height: 6),
            Text('గణన ధృవీకరణ లేని నియమాలను అనుకూలం/ప్రతికూలం అని ప్రకటించము.',
                style: TextStyle(fontSize: 12)),
          ],
        ))),
        TextField(
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            labelText: 'నియమం, అంశం లేదా పేజీ వెతకండి',
            border: OutlineInputBorder(),
          ),
          onChanged: (v) => setState(() => query = v),
        ),
        const SizedBox(height: 8),
        Text('మొత్తం ${topics.length} అంశాలు • చూపిస్తున్నవి ${visible.length}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        for (final r in visible)
          Card(child: ExpansionTile(
            key: ValueKey(r.id),
            title: Text('${r.id} — ${r.title}'),
            subtitle: Text('మూల పేజీ ${r.page} • '
                '${r.requiresTwoCharts ? 'వివాహ పొంతన' : 'వ్యక్తిగత వివాహ విశ్లేషణ'}'),
            childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
            children: [
              MarriageRuleDrillDown(
                resultText: 'మూల సూచిక ఉంది • పూర్తి Rule Matching పెండింగ్',
                ruleText: 'మూల అంశం: ${r.title}\n'
                    'ఇప్పటికే నమోదైన అధ్యయన పరిధి: ${r.focus}\n'
                    'పూర్తి IF–THEN సూత్రం కోసం అసలు పేజీని పరిశీలించాలి.',
                sourceText: '${MarriageRulesOkRegistry.sourceName} • పుట ${r.page}',
                onOpenSource: () => ReviewedMarriageSources.openPage(
                    context, ReviewedMarriageSources.marriageRules, r.page),
                examinationText: r.requiresTwoCharts
                    ? 'ఇది రెండు జాతకాలు అవసరమైన అంశం. '
                        'వరుడు–వధువు జాతకాలను వివాహ పొంతన ట్యాబ్‌లో ఎంచుకోండి. '
                        'ఈ గ్రంథ సూచిక మాత్రమే ఆటోగణన చేయదు.'
                    : MarriageChartEvidenceService.forFactors(widget.chart, const [1, 9]),
              ),
              InkWell(
                onTap: () => ReviewedMarriageSources.openPage(
                    context, ReviewedMarriageSources.marriageRules, r.page),
                child: Image.asset(
                  ReviewedMarriageSources.assetPath(
                      ReviewedMarriageSources.marriageRules, r.page),
                  height: 200,
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) =>
                      const Text('అసలు మూల పేజీ అందుబాటులో లేదు'),
                ),
              ),
            ],
          )),
      ]),
    );
  }
}
