import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/planet_detail_service.dart';
import '../astrology/varga_unified_rule_service.dart';
import '../astrology/multi_chart_topic_service.dart';
import 'unified_rule_result_tile.dart';
import 'topic_varga_review_panel.dart';

/// One compact, topic-wise home for all 255 Mallikarjuna IF–THEN definitions.
/// GREEN is confined to the THEN result for chart-verified matches ONLY.
class UnifiedVargaResultsTab extends StatefulWidget {
  final AstroChartResult chart;

  const UnifiedVargaResultsTab({super.key, required this.chart});

  @override
  State<UnifiedVargaResultsTab> createState() => _UnifiedVargaResultsTabState();
}

class _UnifiedVargaResultsTabState extends State<UnifiedVargaResultsTab> {
  late Future<List<UnifiedVargaRule>> _rules;
  final TextEditingController _search = TextEditingController();
  String _group = 'ALL';
  String _status = 'ALL';

  @override
  void initState() {
    super.initState();
    _rules = VargaUnifiedRuleService.evaluate(widget.chart);
    _search.addListener(_refresh);
  }

  @override
  void didUpdateWidget(covariant UnifiedVargaResultsTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(widget.chart, oldWidget.chart)) {
      _rules = VargaUnifiedRuleService.evaluate(widget.chart);
      _group = 'ALL';
      _status = 'ALL';
    }
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _search.removeListener(_refresh);
    _search.dispose();
    super.dispose();
  }

  bool _matchesStatus(UnifiedVargaRule r) => switch (_status) {
    'MATCH' => r.status == UnifiedVargaRuleStatus.matched,
    'NO' => r.status == UnifiedVargaRuleStatus.notMatched,
    'PENDING' => r.status == UnifiedVargaRuleStatus.pending ||
        r.status == UnifiedVargaRuleStatus.method,
    _ => true,
  };

  int _rank(UnifiedVargaRule r) => switch (r.status) {
    UnifiedVargaRuleStatus.matched => 0,
    UnifiedVargaRuleStatus.notMatched => 1,
    UnifiedVargaRuleStatus.pending => 2,
    UnifiedVargaRuleStatus.method => 3,
  };

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<UnifiedVargaRule>>(
      future: _rules,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text('వర్గ IF–THEN నియమాలు తెరవలేకపోయాం: ${snapshot.error}'),
          ));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final all = snapshot.data!;
        final groups = <String, String>{};
        for (final r in all) {
          groups.putIfAbsent(r.group, () => r.groupTitle);
        }
        final q = _search.text.trim().toLowerCase();
        final filtered = all.where((r) {
          if (_group != 'ALL' && r.group != _group) return false;
          if (!_matchesStatus(r)) return false;
          if (q.isEmpty) return true;
          return '${r.id} ${r.groupTitle} ${r.topic} ${r.condition} ${r.outcome}'
              .toLowerCase().contains(q);
        }).toList(growable: false);
        final byGroup = <String, List<UnifiedVargaRule>>{};
        for (final r in filtered) {
          byGroup.putIfAbsent(r.group, () => <UnifiedVargaRule>[]).add(r);
        }
        final keys = byGroup.keys.toList();
        // Topic groups with real, verified matches lead. Inside each topic,
        // matched results precede not-matched and unverified source rules.
        int matches(String group) => byGroup[group]!
            .where((r) => r.status == UnifiedVargaRuleStatus.matched).length;
        keys.sort((a, b) {
          final first = matches(b).compareTo(matches(a));
          if (first != 0) return first;
          return groups.keys.toList().indexOf(a).compareTo(groups.keys.toList().indexOf(b));
        });
        final rows = <Object>[];
        if (_group == 'ALL' && _status == 'ALL') {
          final topicSummaries = MultiChartTopicService.summarize(
            chart: widget.chart, evaluatedRules: all,
          ).where((t) => q.isEmpty || t.name.toLowerCase().contains(q) ||
              t.chartOrderSourceId.toLowerCase().contains(q)).toList();
          if (topicSummaries.isNotEmpty) {
            rows.add('అంశాలవారీ చార్ట్ ధృవీకరణ (సంఘటన సంభావ్యత కాదు)');
            rows.addAll(topicSummaries);
          }
        }
        for (final group in keys) {
          final items = byGroup[group]!..sort((a, b) => _rank(a).compareTo(_rank(b)));
          rows.add(group);
          rows.addAll(items);
        }
        final hitCount = all.where((r) => r.status == UnifiedVargaRuleStatus.matched).length;
        final noCount = all.where((r) => r.status == UnifiedVargaRuleStatus.notMatched).length;
        final pendingCount = all.length - hitCount - noCount;
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
              child: Text('వర్గ ఫలితాలు ·  ${all.length} నియమాలు · '
                  'మ్యాచ్ $hitCount · సరిపోనివి $noCount · పరిశీలన $pendingCount',
                  style: Theme.of(context).textTheme.bodySmall,
                  maxLines: 2),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: TextField(
                controller: _search,
                decoration: const InputDecoration(
                  isDense: true,
                  prefixIcon: Icon(Icons.search),
                  hintText: 'అంశం / వర్గం / రూల్ వెతకండి',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            SizedBox(
              height: 44,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                children: [
                  _chip('అన్నీ', 'ALL'),
                  _chip('వర్తించినవి', 'MATCH'),
                  _chip('వర్తించనివి', 'NO'),
                  _chip('పరిశీలన పెండింగ్', 'PENDING'),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 3),
              child: Row(children: [
                const Text('అంశం: ', style: TextStyle(fontSize: 13)),
                Expanded(
                  child: DropdownButton<String>(
                    isDense: true,
                    isExpanded: true,
                    value: groups.containsKey(_group) ? _group : 'ALL',
                    items: [
                      const DropdownMenuItem(value: 'ALL', child: Text('అన్ని అంశాలు')),
                      ...groups.entries.map((g) => DropdownMenuItem(
                        value: g.key,
                        child: Text(g.value, overflow: TextOverflow.ellipsis),
                      )),
                    ],
                    onChanged: (v) => setState(() => _group = v ?? 'ALL'),
                  ),
                ),
              ]),
            ),
            ExpansionTile(
              initiallyExpanded: false,
              tilePadding: const EdgeInsets.symmetric(horizontal: 12),
              title: const Text('గ్రహ డిగ్రీ బలం + షడ్వర్గ ఆధారాలు',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              children: [
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 14, vertical: 3),
                  child: Text('డిగ్రీ సూచిక మీ నిర్వచనం; షడ్వర్గ వింశోపక బలం వేరు. ఇవి ఫలిత సంభావ్యత శాతాలు కావు.',
                      style: TextStyle(fontSize: 11)),
                ),
                ...widget.chart.planets.map((p) {
                  final rank = (30.0 - p.degreesInSign) / 30.0 * 100.0;
                  final shad = PlanetDetailService.forPlanet(widget.chart, p)
                      .vargaStrength.shadVimsopaka;
                  return Padding(
                    padding: const EdgeInsets.fromLTRB(14, 2, 14, 3),
                    child: Text('${p.name}: ${p.degreesInSign.toStringAsFixed(2)}° · '
                        'డిగ్రీ సూచిక ${rank.toStringAsFixed(1)}% · '
                        'షడ్వర్గ ${shad.toStringAsFixed(2)}/20',
                        style: const TextStyle(fontSize: 12)),
                  );
                }),
              ],
            ),
            Expanded(
              child: rows.isEmpty
                  ? const Center(child: Text('ఈ ఫిల్టర్‌లో నియమాలు లేవు.'))
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(8, 2, 8, 18),
                      itemCount: rows.length,
                      itemBuilder: (context, i) {
                        final entry = rows[i];
                        if (entry is MultiChartTopicEvidence) {
                          return _topicTile(entry);
                        }
                        if (entry is String) {
                          return Padding(
                            padding: const EdgeInsets.fromLTRB(8, 14, 8, 5),
                            child: Text(groups[entry] ?? entry,
                                style: Theme.of(context).textTheme.titleSmall),
                          );
                        }
                        return _ruleTile(entry as UnifiedVargaRule);
                      },
                    ),
            ),
          ],
        );
      },
    );
  }

  Widget _chip(String label, String key) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 4),
    child: ChoiceChip(
      label: Text(label, style: const TextStyle(fontSize: 12)),
      selected: _status == key,
      onSelected: (_) => setState(() => _status = key),
      visualDensity: VisualDensity.compact,
    ),
  );

  Widget _topicTile(MultiChartTopicEvidence summary) {
    final fullyEvaluated = summary.evaluatedStages == summary.totalStages;
    final coverage = summary.confirmationPercent;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 3),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.fromLTRB(12, 3, 8, 3),
        childrenPadding: const EdgeInsets.fromLTRB(12, 2, 12, 12),
        title: Text(summary.name,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
        subtitle: Text(fullyEvaluated
          ? '${summary.chartOrderSourceId.startsWith('USER-') ? 'వృత్తి విధాన మద్దతు' : 'చార్ట్ మ్యాచ్ ఆధారం'} ${summary.displayCoverage}'
          : 'ధృవీకరణ: ${summary.displayCoverage}',
          style: const TextStyle(fontSize: 12)),
        trailing: coverage == null
          ? const Icon(Icons.manage_search, color: Colors.grey)
          : Text('$coverage%', style: TextStyle(
              fontWeight: FontWeight.bold,
              color: summary.matchedStages == 0
                  ? Colors.grey.shade700 : const Color(0xFF176B36))),
        children: [
          if (coverage != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: LinearProgressIndicator(
                value: coverage / 100,
                minHeight: 7,
                backgroundColor: Colors.grey.shade200,
                valueColor: AlwaysStoppedAnimation<Color>(
                  summary.matchedStages == 0
                    ? Colors.grey : const Color(0xFF168047)),
              ),
            ),
          Text(summary.note, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 5),
          TopicVargaReviewPanel(chart: widget.chart, summary: summary),
          const SizedBox(height: 7),
          _detail(summary.chartOrderSourceId.startsWith('USER-')
              ? 'ఎంపిక చేసిన ప్రధాన చార్ట్ క్రమం' : 'మూల చార్ట్ క్రమం',
            summary.chartOrderSourceId.startsWith('USER-')
                ? '${summary.chartOrderSourceId} · వినియోగదారు నిర్ణయం D1–D9–D10'
                : '${summary.chartOrderSourceId} · Mallikarjuna 255 Rules PDF'),
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('మూడు-చక్రాల శాతం = వర్తించిన నియమం/విధానానికి చక్రాల మద్దతు మాత్రమే. '
              'ఇది సంఘటన అవకాశం శాతం కాదు; ఒక రూల్ సరిపోలకపోవడం '
              'మొత్తం అంశానికి ప్రతికూల తీర్పు కాదు.', 
              style: TextStyle(fontSize: 11, color: Colors.grey)),
          ),
        ],
      ),
    );
  }

  // Same visible order for all D1–D60 source rules as the per-chart panel.
  // Unmatched/pending source THEN text must NEVER become a highlighted result.
  Widget _ruleTile(UnifiedVargaRule r) {
    final matched = r.status == UnifiedVargaRuleStatus.matched;
    final verdict = !matched
        ? RuleVerdict.unverified
        : switch (r.tone) {
            UnifiedVargaRuleTone.favorable => RuleVerdict.favourable,
            UnifiedVargaRuleTone.adverse => RuleVerdict.adverse,
            UnifiedVargaRuleTone.neutral => RuleVerdict.mixed,
          };
    return UnifiedRuleResultTile(
      key: ValueKey('unified-varga-${r.id}'),
      data: RuleResultData(
        topic: r.topic,
        ruleId: r.id,
        rule: r.condition,
        examination: r.evidence,
        source: r.source,
        result: matched ? r.outcome :
            r.status == UnifiedVargaRuleStatus.notMatched
                ? 'ఈ జాతకంలో మూల షరతు సరిపోలలేదు.'
                : 'పూర్తి షరతులు ఇంకా పరిశీలించలేదు.',
        verdict: verdict,
        ruleMatched: r.status == UnifiedVargaRuleStatus.notMatched
            ? false : matched ? true : null,
      ),
    );
  }

  Widget _detail(String label, String value) => Padding(
    padding: const EdgeInsets.only(top: 9),
    child: Align(
      alignment: Alignment.centerLeft,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        const SizedBox(height: 3),
        Text(value, style: const TextStyle(fontSize: 13)),
      ]),
    ),
  );
}
