import 'package:flutter/material.dart';

/// Presentation only. All conclusions MUST come from the calling rule engine.
/// Never infer a favourable result from missing evidence.
enum RuleVerdict { favourable, adverse, mixed, unverified }

class RuleResultData {
  const RuleResultData({
    required this.topic,
    required this.result,
    required this.verdict,
    required this.examination,
    required this.rule,
    this.ruleId,
    this.source,
    this.remedy,
    this.evidencePercent,
    this.ruleMatched,
  });

  final String topic;
  final String result;
  final RuleVerdict verdict;
  final String examination;
  final String rule;
  final String? ruleId;
  final String? source;
  final String? remedy;
  /// Evidence index only; NEVER label as event probability.
  final double? evidencePercent;
  /// Chart condition matched; independent of favourable/adverse interpretation.
  final bool? ruleMatched;
}

/// Shared order for all varga result drill-downs:
/// 1. source rule, 2. natal examination, 3. highlighted chart-matched result,
/// 4. optional source-backed remedy. No adverse or favourable highlight for
/// incomplete/missing evaluation.
class UnifiedRuleResultTile extends StatefulWidget {
  const UnifiedRuleResultTile({
    super.key,
    required this.data,
    this.initiallyExpanded = false,
    this.showRemedyStatus = false,
  });
  final RuleResultData data;
  final bool initiallyExpanded;
  /// Show the explicit non-invention status as section four for topic pages.
  final bool showRemedyStatus;

  @override
  State<UnifiedRuleResultTile> createState() => _UnifiedRuleResultTileState();
}

class _UnifiedRuleResultTileState extends State<UnifiedRuleResultTile> {
  late bool _expanded;

  @override
  void initState() {
    super.initState();
    _expanded = widget.initiallyExpanded;
  }

  @override
  void didUpdateWidget(covariant UnifiedRuleResultTile oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Do not reuse the old rule's expansion when filtering to another row.
    if (oldWidget.data.ruleId != widget.data.ruleId ||
        oldWidget.data.topic != widget.data.topic) {
      _expanded = widget.initiallyExpanded;
    }
  }

  Color get accent => switch (widget.data.verdict) {
    RuleVerdict.favourable => const Color(0xFF176B36),
    RuleVerdict.adverse => const Color(0xFFA33667),
    RuleVerdict.mixed => const Color(0xFF90630D),
    RuleVerdict.unverified => const Color(0xFF5E6875),
  };

  Color get highlightedBackground => switch (widget.data.verdict) {
    RuleVerdict.favourable => const Color(0xFFE6F5EA),
    RuleVerdict.adverse => const Color(0xFFFBE6ED),
    RuleVerdict.mixed => const Color(0xFFFFF3D8),
    RuleVerdict.unverified => const Color(0xFFF2F3F5),
  };

  // A source rule is never claimed as a client result when its conditions
  // are not verified. Absence of a match is not an adverse prediction.
  bool get hasVerifiedResult => widget.data.ruleMatched == true;

  String get verdictLabel {
    if (widget.data.ruleMatched == false) return 'నియమం వర్తించలేదు';
    if (!hasVerifiedResult) return 'పూర్తి రూల్ మ్యాచ్ ధృవీకరణ లేదు';
    return switch (widget.data.verdict) {
      RuleVerdict.favourable => 'నియమం వర్తించింది • అనుకూల ఆధారం',
      RuleVerdict.adverse => 'నియమం వర్తించింది • ప్రతికూల ఆధారం',
      RuleVerdict.mixed => 'నియమం వర్తించింది • మిశ్రమ ఆధారాలు',
      RuleVerdict.unverified => 'మ్యాచ్ అయ్యింది • ఫలిత స్వభావం ధృవీకరించాలి',
    };
  }

  IconData get verdictIcon {
    if (!hasVerifiedResult) return Icons.fact_check_outlined;
    return switch (widget.data.verdict) {
      RuleVerdict.favourable => Icons.check_circle_outline,
      RuleVerdict.adverse => Icons.cancel_outlined,
      RuleVerdict.mixed => Icons.info_outline,
      RuleVerdict.unverified => Icons.help_outline,
    };
  }

  String get _sourceLabel {
    final source = widget.data.source?.trim();
    return source == null || source.isEmpty
        ? 'మూలగ్రంథం / పేజీ ధృవీకరణ పెండింగ్' : source;
  }

  bool get _hasSourcedRemedy {
    final d = widget.data;
    final remedy = d.remedy?.trim() ?? '';
    final source = d.source?.trim() ?? '';
    return hasVerifiedResult && remedy.isNotEmpty && source.isNotEmpty &&
        !source.toUpperCase().contains('SOURCE_PENDING') &&
        !source.contains('పెండింగ్');
  }

  Widget _sectionHeading(String number, String label) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Row(children: [
      Container(
        alignment: Alignment.center,
        width: 24, height: 24,
        decoration: BoxDecoration(
          color: const Color(0xFF12315E),
          borderRadius: BorderRadius.circular(7),
        ),
        child: Text(number, style: const TextStyle(
          color: Colors.white, fontSize: 12, fontWeight: FontWeight.w800)),
      ),
      const SizedBox(width: 8),
      Text(label, style: const TextStyle(fontSize: 14,
          fontWeight: FontWeight.w800)),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    final d = widget.data;
    final percent = d.evidencePercent;
    return Card(
      key: ValueKey('rule-card-${d.ruleId ?? d.topic}'),
      color: Theme.of(context).cardColor,
      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: Color(0xFFE1D5BF))),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            child: Row(children: [
              Icon(verdictIcon, color: hasVerifiedResult ? accent : const Color(0xFF657080)),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(d.topic, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
                if (d.ruleId != null && d.ruleId!.trim().isNotEmpty)
                  Text('Rule ID: ${d.ruleId}', style: const TextStyle(fontSize: 11,
                      color: Color(0xFF68717D))),
                Text(verdictLabel, style: TextStyle(
                    color: hasVerifiedResult ? accent : const Color(0xFF657080),
                    fontWeight: FontWeight.w700, fontSize: 12)),
                if (hasVerifiedResult)
                  Text('ఫలిత స్వభావం: ${d.verdict == RuleVerdict.adverse ? "ప్రతికూలం" : d.verdict == RuleVerdict.favourable ? "అనుకూలం" : d.verdict == RuleVerdict.mixed ? "మిశ్రమం" : "ధృవీకరణ అవసరం"}',
                    style: TextStyle(color: accent, fontSize: 11)),
              ])),
              Icon(_expanded ? Icons.expand_less : Icons.expand_more),
            ]),
          ),
          if (_expanded) ...[
            const Divider(height: 20),
            _sectionHeading('1', 'రూల్ / మూల నియమం'),
            Text(d.rule.trim().isNotEmpty ? d.rule : 'పూర్తి మూల నియమం అందుబాటులో లేదు.',
                style: const TextStyle(fontSize: 13, height: 1.4)),
            const SizedBox(height: 5),
            Text('మూలం: $_sourceLabel',
                style: const TextStyle(fontSize: 11, color: Color(0xFF656C76))),
            const SizedBox(height: 14),
            _sectionHeading('2', 'జాతక పరిశీలన'),
            Text(d.examination.trim().isNotEmpty ? d.examination :
                'ఈ నియమానికి గ్రహ–భావ ఆధారాలు అందుబాటులో లేవు.',
                style: const TextStyle(fontSize: 13, height: 1.4)),
            const SizedBox(height: 14),
            _sectionHeading('3', 'ఫలితం'),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: hasVerifiedResult ? highlightedBackground : const Color(0xFFF2F3F5),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: hasVerifiedResult ? accent.withOpacity(0.5) :
                    const Color(0xFFCDD3DC)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(hasVerifiedResult ? d.result :
                    d.ruleMatched == false
                        ? 'ఈ జాతకంలో నియమం వర్తించలేదు — ఫలితం ప్రకటించలేదు.'
                        : 'పూర్తి షరతులు పరీక్షించలేదు — ఫలితం నిర్ధారించలేదు.',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16,
                      height: 1.45, color: hasVerifiedResult ? accent : const Color(0xFF5E6875))),
                if (hasVerifiedResult && percent != null && percent.isFinite &&
                    percent >= 0 && percent <= 100) ...[
                  const SizedBox(height: 5),
                  Text('ఆధార సూచిక ${percent.toStringAsFixed(0)}% • సంఘటన సంభావ్యత కాదు',
                      style: const TextStyle(fontSize: 11)),
                ],
              ]),
            ),
            if (_hasSourcedRemedy || widget.showRemedyStatus) ...[
              const SizedBox(height: 14),
              _sectionHeading('4', 'మూలాధారిత పరిహారం'),
              Text(_hasSourcedRemedy ? d.remedy!.trim()
                  : 'ఈ అంశానికి ఖచ్చితమైన మూల నియమం–పరిహారం అనుసంధానం '
                    'ధృవీకరించలేదు. పరిహారం కల్పించలేదు.',
                style: const TextStyle(fontSize: 13, height: 1.4)),
            ],
          ],
        ]),
      ),
    );
  }
}
