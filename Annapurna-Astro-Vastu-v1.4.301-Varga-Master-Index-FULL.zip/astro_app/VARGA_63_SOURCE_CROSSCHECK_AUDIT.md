# Annapurna Astro Vastu — 63 HTML Varga Rules Crosscheck

**Source:** `Annapurna_All_Vargas_Rules.html` received 2026-11-07 (63 records across 19 chart codes).  
**App baseline:** locally available 1.4.301 full Flutter source *with the prior OCR / result-display patch*. This is **NOT** the newer v1.4.326 codebase.  
**Scope:** correct rule provenance and on-device result selection, not a new horoscope prediction standard.

## 1. Actual findings

| Classification | Count | How presented |
|--|--:|--|
| Page-supported **executable sufficient conditions** | 4 | Chart verified -> THEN result (green). Other cases FALSE/UNKNOWN remain rulebook/non-prediction |
| Source paragraph / page checked, full condition not computable | 13 | Rulebook only |
| Source/page only named generically in HTML | 37 | Rulebook only; no auto result |
| Explicit contradiction to project-fixed method | 3 | Flagged; not executed |
| Overstrong or insufficiently supported YES/NO claim | 6 | Flagged; not executed |
| **Total** | **63** | All original IF/YES/NO preserved for review |

The 63 HTML rows had no machine-readable `rule_id`, no `if` expressions, no real Natal D1-D60 calculations, no page-accurate source pointers, and unconditional alternative `NO` outcomes. A text-based table **cannot** establish true horoscope matching.

## 2. Four audited executable subsets

- `HTML-D3-02`: D3 Mars in Capricorn (exaltation) **AND** tenth house; Sarala VII, PDF page 2, book page 1. Only a supportive Mars-strength observation; not a guaranteed life event.
- `HTML-D10-02`: D10 Saturn Aries (debilitated), conjunct Rahu/Ketu in sign or occupies 6/8/12 as one supported part of Agocharastha 8.2; `sani-gochara-agochara.pdf`, PDF page 1. Other uncalculated weaknesses keep it UNKNOWN if the visible subset does not match. **This is not transit.**
- `HTML-D12-04`: D12 second-house malefic occupancy as one directly calculated instance of affliction; D12.pdf PDF page 9, book page 300.
- `HTML-D12-05`: D12 fourth-house malefic occupancy; D12.pdf PDF page 9, book page 300.

Other kinds of affliction (planetary aspects, lord conditions, combustion, graha-yuddha, condition-specific exceptions) are **not** assumed false when unavailable. The engine only emits the result on a true, source-supported **sufficient** subset; it otherwise stays Unknown.

## 3. Corrected D12 source pagination

| Book page | Actual PDF page | Topic |
|--:|--:|--|
| 293 | 2 | Raj/Dhana yoga, ancestral blessings (KL) |
| 300 | 9 | Child's early life, second/fourth house afflictions |
| 307 | 18 | Parent/child relation, Ravi/Chandra and Jaimini karakas |
| 314 | 25 | Whether child takes care of parents |
| 323 | 34 | Inheritance **or** legacy, not guaranteed material inheritance |
| 332 | 43 | Longevity reference from KL and respective parental houses |

These are independently checked scanned-book pages, not a uniform page offset.

## 4. Contradictions and false-negative prevention

- D10 original HTML uses D9/D10 at `HTML-D10-03`, but the fixed application principle compares D1 and D10; therefore withheld pending exact doctrinal confirmation.
- D24 `HTML-D24-03/04` contradict the project's established 4th up to Intermediate, 9th up to Degree/B.Tech, 2nd for PG and 7th for post-PG.
- D7 `HTML-D7-03`: papakartari cannot by itself justify an absolute "no own child" output.
- D10 `HTML-D10-13`: do not claim employees will harm the native from a vaguely "malefic sixth" alone.
- `HTML-D30-02` and `HTML-D60-03`: avoid unconditional life misfortune/past-karma claims without complete source rules.
- For **all 63** records, original `NO` is an unsafe logical converse: `IF false` does **not** prove the opposite result.

## 5. Flutter implementation

The patch adds one immutable JSON asset and one Flutter service (`VargaSource63Service`), integrates the rows into the existing `VargaUnifiedRuleService.evaluate` and displays evidence + sources in `UnifiedVargaResultsTab`. No OCR happens at chart time. `D5/D6/D8/D11` in the HTML are **not** implemented by current `VargaService`; `D4` is implemented in the app but absent from this HTML. Do not claim all D1-D60 rule calculations have been added.

New HTML rows remain traceable with `HTML-Dx-yy` IDs and do not replace or rewrite any of the original 255 rules or the existing 462 BNN source records. Overlap with the 255 rules is **not semantic deduplicated**; total rows displayed are not a count of unique doctrines.

User-required view flow is supported through rule tile -> IF -> chart evidence -> THEN -> source. There is **no invented remedy**.

## 6. Executed checks, and limitations

**Executed:** JSON syntax, all 63 IDs unique, exact preservation of 63 original IF/YES/NO strings, expected source-page mapping, YAML parsing, the four calculator whitelist entries, original NO not consumed by Flutter calculation, source-code and asset wiring, archive CRC and no duplicate paths. JavaScript preview syntax also parsed successfully.

**Not executed:** `flutter analyze`, `flutter test`, APK build and Android device tests: no Flutter SDK exists in this environment. Test source `test/varga_source_63_service_test.dart` was written but **not run**. This is a crosschecked **source update**, not a certified Android APK or complete transcription of all supplied PDFs.

**IMPORTANT:** If your installed app/source is 1.4.326 or later, merge the patch into that latest baseline; **do not overwrite** the newer complete source with the included 1.4.301 full ZIP.
