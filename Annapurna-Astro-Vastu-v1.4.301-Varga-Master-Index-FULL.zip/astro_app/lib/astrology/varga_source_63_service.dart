import 'dart:convert';

import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'varga_service.dart';
import 'varga_unified_rule_service.dart';

/// Crosschecked 63-entry HTML annex.
/// `source verification` and `chart matching` are independent.
/// All 63 are retained in the rulebook; ONLY four sufficient, book-supported
/// predicates have an evaluator. Unknown is never interpreted as NO.
/// No OCR is performed during chart rendering.
class VargaSource63Service {
  static const asset = 'assets/varga/annapurna_all_vargas_63_audited.json';
  static const _signs = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];
  static const _malefics = <String>{'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};

  static Future<List<UnifiedVargaRule>> evaluate(AstroChartResult natal) async {
    final parsed = jsonDecode(await rootBundle.loadString(asset)) as Map<String, dynamic>;
    final raw = parsed['rules'] as List<dynamic>? ?? const [];
    final charts = <int, VargaChartData>{};
    for (final factor in const <int>[3, 10, 12]) {
      charts[factor] = VargaService.calculate(natal, factor);
    }
    final results = <UnifiedVargaRule>[];
    for (final entry in raw) {
      final r = entry as Map<String, dynamic>;
      final src = r['source'] as Map<String, dynamic>;
      final audit = r['audit'] as Map<String, dynamic>;
      final calculator = r['calculator'] as String?;
      final (bool?, String) evaluation = _match(calculator, charts);
      final status = calculator == null
          ? UnifiedVargaRuleStatus.pending
          : evaluation.$1 == true
              ? UnifiedVargaRuleStatus.matched
              : evaluation.$1 == false
                  ? UnifiedVargaRuleStatus.notMatched
                  : UnifiedVargaRuleStatus.pending;
      final pPdf = src['pdf_page']?.toString() ?? '—';
      final pPrinted = src['printed_page']?.toString() ?? '—';
      final file = src['file'] as String? ?? 'మూల పేజీ గుర్తించలేదు';
      final note = audit['notes_te'] as String? ?? '';
      final kind = audit['category'] as String? ?? 'source_reference_missing';
      final provenance = 'మూలం: $file · PDF పేజీ $pPdf · పుస్తక పేజీ $pPrinted';
      final summary = calculator == null
          ? '$note\nఅంశం: $kind. ఈ రికార్డుకు ఆటోమేటిక్ ఫలితాన్ని ప్రకటించలేదు.'
          : '${evaluation.$2}\n$note';
      results.add(UnifiedVargaRule(
        id: r['id'] as String,
        group: 'HTML-${r['chart']}',
        groupTitle: '${r['chart']} · HTML 63 క్రాస్‌చెక్',
        topic: r['topic'] as String,
        condition: r['original_if'] as String,
        outcome: r['audited_result_te'] as String,
        source: provenance,
        evidence: summary,
        status: status,
      ));
    }
    return results;
  }

  /// Positive matches are only sufficient conditions, not proof of an event.
  /// The other branches remain unknown where factors/aspects were not checked.
  static (bool?, String) _match(String? calculator, Map<int, VargaChartData> charts) {
    if (calculator == null) return (null, 'మూల/షరతు పరిశీలన అవసరం.');
    int? signOf(VargaChartData chart, String name) {
      for (final p in chart.planets) {
        if (p.name == name) return p.signIndex;
      }
      return null;
    }
    int? houseOf(VargaChartData chart, String name) {
      final s = signOf(chart, name);
      return s == null ? null : (s - chart.ascendantSignIndex + 12) % 12 + 1;
    }
    String place(VargaChartData chart, String name) {
      final s = signOf(chart, name);
      if (s == null) return '$name గ్రహస్థానం లేదు';
      return '$name ${_signs[s]} · ${houseOf(chart, name)}వ భావం';
    }
    switch (calculator) {
      case 'D3_MARS_EXALT_TENTH':
        final d3 = charts[3];
        if (d3 == null || signOf(d3, 'Mars') == null) {
          return (null, 'D3లో కుజుడి రాశి/లగ్నం అందుబాటులో లేదు.');
        }
        return (signOf(d3, 'Mars') == 9 && houseOf(d3, 'Mars') == 10,
            'D3 ${place(d3, 'Mars')}; ఉచ్చ మకరం + 10వ భావం రెండూ అవసరం.');
      case 'D10_SAT_AGOCHARA_WEAKNESS':
        final d10 = charts[10];
        if (d10 == null || signOf(d10, 'Saturn') == null) {
          return (null, 'D10లో శని రాశి/లగ్నం అందుబాటులో లేదు.');
        }
        final satSign = signOf(d10, 'Saturn')!;
        final satHouse = houseOf(d10, 'Saturn')!;
        final rahu = signOf(d10, 'Rahu');
        final ketu = signOf(d10, 'Ketu');
        final markers = <String>[];
        if (satSign == 0) markers.add('మేష నీచం');
        if (rahu != null && satSign == rahu) markers.add('రాహు యుతి');
        if (ketu != null && satSign == ketu) markers.add('కేతు యుతి');
        if (const <int>{6, 8, 12}.contains(satHouse)) markers.add('${satHouse}వ దుఃస్థాన సంబంధం');
        if (markers.isNotEmpty) {
          return (true, 'D10 ${place(d10, 'Saturn')}; ${markers.join(', ')}. '
              'ఇవి నియమం 8.2లోని తగిన ఉపషరతులు.');
        }
        return (null, 'D10 ${place(d10, 'Saturn')}; నీచం/యుతి/దుఃస్థాన స్థితి కనిపించలేదు. '
            'కంబస్టు, గ్రహయుద్ధం, 6/8/12 అధిపతి సంబంధం ఇంకా పరీక్షించలేదు; '
            'కాబట్టి 8.2 FALSE లేదా 8.1 TRUE అని తీర్పు ఇవ్వడం లేదు.');
      case 'D12_SECOND_HOUSE_MALEFIC_OCCUPANCY':
      case 'D12_FOURTH_HOUSE_MALEFIC_OCCUPANCY':
        final d12 = charts[12];
        if (d12 == null) return (null, 'D12 గణన లేదు.');
        final house = calculator == 'D12_SECOND_HOUSE_MALEFIC_OCCUPANCY' ? 2 : 4;
        final hits = d12.planets.where((p) => _malefics.contains(p.name) &&
            (p.signIndex - d12.ascendantSignIndex + 12) % 12 + 1 == house)
            .map((p) => p.name).toList(growable: false);
        if (hits.isEmpty) {
          return (null, 'D12 ${house}వ భావంలో ప్రత్యక్ష పాపగ్రహ స్థానం లేదు. '
              'దృష్టి, భావాధిపతి-బాధ మరి ఇతర షరతులు ఇంకా పూర్తికాలేదు.');
        }
        return (true, 'D12 ${house}వ భావంలోని పాపగ్రహాలు: ${hits.join(', ')}. '
            'మూలంలోని పాపబాధ షరతుకు ఇది ఒక ప్రత్యక్ష ఉపసమితి.');
      default:
        return (null, 'తెలియని గణన కోడ్; ఫలితం ప్రకటించలేదు.');
    }
  }
}
