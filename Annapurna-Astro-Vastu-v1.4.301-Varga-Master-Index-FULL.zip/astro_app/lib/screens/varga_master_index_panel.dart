import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../astrology/varga_unified_rule_service.dart';
import '../astrology/astro_models.dart';

/// The navigation index refers to original, distinct rule registries; it does
/// not re-run them or turn source/OCR review flags into prediction verdicts.
/// A reference-only record can NEVER create a green result.
class VargaMasterIndexPanel extends StatefulWidget {
  final List<UnifiedVargaRule> evaluated;
  final String initialChart;

  const VargaMasterIndexPanel({
    super.key, required this.evaluated, this.initialChart = 'ALL',
  });

  @override
  State<VargaMasterIndexPanel> createState() => _VargaMasterIndexPanelState();
}

class _VargaMasterIndexPanelState extends State<VargaMasterIndexPanel> {
  static const _asset = 'assets/varga/annapurna_varga_master_index.json';
  late final Future<Map<String, dynamic>> _index;
  final TextEditingController _search = TextEditingController();
  String _chart = 'ALL';

  @override
  void initState() {
    super.initState();
    _chart = widget.initialChart;
    _index = rootBundle.loadString(_asset)
        .then((s) => jsonDecode(s) as Map<String, dynamic>);
    _search.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _search.removeListener(_refresh);
    _search.dispose();
    super.dispose();
  }

  String _pageText(Object? raw) {
    if (raw == null) return '';
    if (raw is List) return raw.map((e) => e.toString()).join(', ');
    return raw.toString();
  }

  String _source(Map<String, dynamic> r) {
    final pages = (r['pages'] as Map<String, dynamic>?) ?? const {};
    final parts = <String>['${r['source'] ?? 'మూలం తెలియదు'}'];
    for (final item in <(String, String)>[
      ('pdf_page', 'PDF పేజీ'),
      ('printed_page', 'పుస్తక పేజీ'),
      ('catalog_pages', 'కేటలాగ్ పేజీలు'),
      ('source_pages', 'సోర్స్ పేజీలు'),
      ('registry_page', 'రిజిస్ట్రీ పేజీ'),
      ('registry_pages', 'రిజిస్ట్రీ పేజీలు'),
    ]) {
      final value = _pageText(pages[item.$1]);
      if (value.isNotEmpty && value != '[]') {
        parts.add('${item.$2}: $value');
      }
    }
    parts.add('రూల్ రిజిస్ట్రీ: ${r['registry'] ?? '—'}');
    return parts.join('\n');
  }

  Widget _detail(String label, String content) => Padding(
    padding: const EdgeInsets.only(top: 10),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
      const SizedBox(height: 3),
      SelectableText(content.isEmpty ? 'ఈ రికార్డులో లేదు' : content,
          style: const TextStyle(fontSize: 13)),
    ]),
  );

  void _openRule(Map<String, dynamic> item, UnifiedVargaRule? evaluated) {
    final matched = evaluated?.status == UnifiedVargaRuleStatus.matched;
    final notMatched = evaluated?.status == UnifiedVargaRuleStatus.notMatched;
    final proposal = '${item['then'] ?? ''}';
    final topicSection = item['kind'] == 'topic_section';
    final ifText = '${item['if'] ?? ''}';
    final notes = '${item['notes'] ?? ''}';
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('${item['id']} · ${item['topic']}',
            style: const TextStyle(fontSize: 16)),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (topicSection)
                _detail('అంశాల జాబితా — ప్రత్యేక IF నియమం కాదు',
                    'ఈ విభాగంలో ఇప్పటికే ఉన్న మూల నియమాలను చూడాలి.'),
              if (!topicSection) _detail('1. మూల నియమం / IF', ifText),
              _detail('2. జాతక పరిశీలన', evaluated?.evidence ??
                  'మూల రిజిస్ట్రీకి లింక్ ఉంది. ఈ ఇండెక్స్ ద్వారా ఆటోమేటిక్ జాతక గణన చేయడం లేదు.'),
              if (matched) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(6)),
                  child: Text('3. ఫలితం: ${evaluated!.outcome}',
                      style: const TextStyle(color: Color(0xFF176B36),
                          fontWeight: FontWeight.w600)),
                ),
              ] else ...[
                _detail('3. ప్రస్తుతం నిర్ధారిత ఫలితం', notMatched
                    ? 'ఈ నియమం యొక్క షరతు ఈ జాతకంలో సరిపోలలేదు; వ్యతిరేక ఫలితం అని కాదు.'
                    : 'పూర్తి IF గణన ధృవీకరించబడలేదు; ఫలితాన్ని ప్రకటించడం లేదు.'),
                if (!topicSection && proposal.isNotEmpty)
                  _detail('మూల THEN — ఈ జాతక ఫలితం కాదు', proposal),
              ],
              _detail('4. పరిహారం', 'ధృవీకరించిన మూల పరిహారం ఈ ఇండెక్స్‌లో లేకపోవడంతో చేర్చలేదు.'),
              _detail('మూలం / పేజీలు', _source(item)),
              if (notes.isNotEmpty) _detail('పరిశీలన గమనిక', notes),
              if ((item['linked_sources'] as List?)?.isNotEmpty ?? false)
                _detail('అనుబంధ మూల సూచనలు',
                    (item['linked_sources'] as List).map((e) => '${e['id']}').join(', ')),
            ]),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context),
            child: const Text('మూసివేయి'))],
      ),
    );
  }

  Widget _record(Map<String, dynamic> row, Map<String, UnifiedVargaRule> evals) {
    final matchedRecord = evals[row['id']];
    final matched = matchedRecord?.status == UnifiedVargaRuleStatus.matched;
    final title = '${row['if'] ?? ''}';
    return ListTile(
      dense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 12),
      title: Text('${row['id']} · ${title.isEmpty ? row['topic'] : title}',
          maxLines: 2, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
      subtitle: Text(matched ? 'జాతక IF సరిపోయింది — ఫలితం చూడండి' :
          (row['kind'] == 'topic_section'
              ? 'ఇప్పటికే ఉన్న విభాగం · సూత్రాల సూచిక'
              : 'మూల రూల్ / IF ధృవీకరణ స్థితి చూడండి'),
          style: TextStyle(fontSize: 11,
              color: matched ? const Color(0xFF176B36) : Colors.grey.shade700)),
      trailing: Icon(matched ? Icons.check_circle_outline : Icons.chevron_right,
          color: matched ? const Color(0xFF176B36) : null, size: 18),
      onTap: () => _openRule(row, matchedRecord),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: _index,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('మాస్టర్ ఇండెక్స్ తెరవలేకపోయాం: ${snapshot.error}'));
        }
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final data = snapshot.data!;
        final names = (data['chart_names'] as Map).cast<String, dynamic>();
        final items = (data['records'] as List)
            .cast<Map<String, dynamic>>();
        final evals = <String, UnifiedVargaRule>{
          for (final r in widget.evaluated) r.id: r,
        };
        final q = _search.text.trim().toLowerCase();
        final visible = items.where((r) {
          if (_chart != 'ALL' && !(r['charts'] as List).contains(_chart)) return false;
          if (q.isEmpty) return true;
          final source = '${r['topic']} ${r['id']} ${r['if']} ${r['then']} ${r['source']}';
          return source.toLowerCase().contains(q);
        }).toList(growable: false);
        // ALL uses the sole primary chart, never duplicates a cross-linked rule.
        final groupMap = <String, Map<String, List<Map<String, dynamic>>>>{};
        for (final r in visible) {
          final ch = _chart == 'ALL' ? r['primary_chart'] as String : _chart;
          final topic = '${r['topic']}';
          groupMap.putIfAbsent(ch, () => {});
          groupMap[ch]!.putIfAbsent(topic, () => []).add(r);
        }
        final chartKeys = names.keys.toList()
          ..sort((a,b) {
            if (a == 'COMMON') return 1;
            if (b == 'COMMON') return -1;
            int number(String x) => int.tryParse(x.substring(1)) ?? 999;
            return number(a).compareTo(number(b));
          });
        final widgets = <Widget>[];
        for (final ch in chartKeys) {
          final topics = groupMap[ch];
          if (topics == null || topics.isEmpty) continue;
          final matchCount = topics.values.expand((e) => e)
              .where((r) => evals[r['id']]?.status == UnifiedVargaRuleStatus.matched).length;
          widgets.add(Padding(
            padding: const EdgeInsets.fromLTRB(13, 15, 9, 5),
            child: Text('$ch — ${names[ch]} · ${topics.values.fold<int>(0,(n,e) => n+e.length)} సూచనలు · మ్యాచ్ $matchCount',
                style: Theme.of(context).textTheme.titleSmall),
          ));
          final sortedTopics = topics.keys.toList()..sort();
          for (final topic in sortedTopics) {
            final topicItems = topics[topic]!;
            final count = topicItems.where((r) =>
                evals[r['id']]?.status == UnifiedVargaRuleStatus.matched).length;
            widgets.add(Card(
              margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              child: ExpansionTile(
                key: PageStorageKey<String>('master_$ch' + '_$topic'),
                tilePadding: const EdgeInsets.symmetric(horizontal: 12),
                title: Text(topic, style: const TextStyle(fontSize: 13,
                    fontWeight: FontWeight.w600)),
                subtitle: Text('${topicItems.length} నియమాలు/అంశాలు${count > 0 ? ' · వర్తించినవి $count' : ''}',
                    style: TextStyle(fontSize: 11,
                        color: count > 0 ? const Color(0xFF176B36) : null)),
                children: [for (final r in topicItems) _record(r, evals)],
              ),
            ));
          }
        }
        return Column(children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 8, 12, 2),
            child: Text('ఒకే మాస్టర్ జాబితా: పాత నియమాలు మళ్లీ కాపీ చేయలేదు. '
                'ప్రస్తుత జాతకానికి గణనలో సరిపడినవి మాత్రమే ఫలితాలు. '
                'OCR/PDF పరిశీలన స్థితి వేరుగా ఉంటుంది.',
                style: TextStyle(fontSize: 12)),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
            child: TextField(controller: _search,
                decoration: const InputDecoration(
                    border: OutlineInputBorder(), isDense: true,
                    prefixIcon: Icon(Icons.search), hintText: 'వర్గం / అంశం / రూల్ ID / గ్రహం')),
          ),
          SizedBox(height: 43, child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            children: [
              _choice('అన్నీ', 'ALL'),
              for (final ch in chartKeys) _choice(ch, ch),
            ],
          )),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 1, 12, 4),
            child: Align(alignment: Alignment.centerLeft,
                child: Text('${visible.length} ప్రత్యేక రికార్డులు · ${groupMap.values.fold<int>(0,(n,e) => n+e.length)} అంశాల గ్రూపులు',
                    style: const TextStyle(fontSize: 11))),
          ),
          Expanded(child: widgets.isEmpty
              ? const Center(child: Text('ఈ వర్గం / వెతుకులాటకు నియమం కనిపించలేదు.'))
              : ListView(children: widgets)),
        ]);
      },
    );
  }

  Widget _choice(String title, String value) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 3),
    child: ChoiceChip(label: Text(title, style: const TextStyle(fontSize: 12)),
        selected: _chart == value,
        onSelected: (_) => setState(() => _chart = value)),
  );
}


/// A shortcut from each visible Dn chart to the same central master list,
/// pre-filtered to the selected divisional chart. There is no second copy of
/// the rules in a chart-specific asset.
class VargaMasterChartScreen extends StatefulWidget {
  final AstroChartResult chart;
  final String chartCode;

  const VargaMasterChartScreen({
    super.key, required this.chart, required this.chartCode,
  });

  @override
  State<VargaMasterChartScreen> createState() => _VargaMasterChartScreenState();
}

class _VargaMasterChartScreenState extends State<VargaMasterChartScreen> {
  late final Future<List<UnifiedVargaRule>> _evaluated;

  @override
  void initState() {
    super.initState();
    _evaluated = VargaUnifiedRuleService.evaluate(widget.chart);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${widget.chartCode} — అన్ని అంశాలు / రూల్స్')),
      body: FutureBuilder<List<UnifiedVargaRule>>(
        future: _evaluated,
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(
            child: Text('వర్గ నియమాలు తెరవలేకపోయాం: ${snapshot.error}'),
          );
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          return VargaMasterIndexPanel(
            initialChart: widget.chartCode, evaluated: snapshot.data!,
          );
        },
      ),
    );
  }
}
