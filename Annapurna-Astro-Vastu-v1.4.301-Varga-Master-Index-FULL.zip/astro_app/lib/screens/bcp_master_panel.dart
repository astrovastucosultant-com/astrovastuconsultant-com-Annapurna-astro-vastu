import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bcp_app_adapter.dart';
import '../astrology/bcp_master_engine.dart';
import '../astrology/bcp_natal_rule_bridge.dart';
import '../astrology/bcp_year_result_explainer.dart';
import '../astrology/bnn_master_service.dart';
import '../astrology/dasha_service.dart';
import '../models/birth_data.dart';
import '../utils/astro_format.dart';

/// UI for the uploaded BCP v1.0 engine. Only this panel is the BCP route;
/// it does not change BNN/BSP, other timing engines or Western's clean slate.
class BcpMasterPanel extends StatefulWidget {
  final BirthData birthData;
  final AstroChartResult chart;
  /// Only genuinely verified external source-rule matches may populate this.
  /// An empty map deliberately keeps BCP events as topic links, not predictions.
  final Map<BcpEventKind, BcpEventEvidence> verifiedEventEvidence;

  const BcpMasterPanel({
    super.key,
    required this.birthData,
    required this.chart,
    this.verifiedEventEvidence = const {},
  });

  @override
  State<BcpMasterPanel> createState() => _BcpMasterPanelState();
}

class _BcpMasterPanelState extends State<BcpMasterPanel> {
  static const _accent = Color(0xFF6633A6);
  static const _signNames = AstroFormat.signNamesTe;
  static const _planetNames = <String, String>{
    'sun': 'రవి',
    'moon': 'చంద్రుడు',
    'mars': 'కుజుడు',
    'mercury': 'బుధుడు',
    'jupiter': 'గురువు',
    'venus': 'శుక్రుడు',
    'saturn': 'శని',
    'rahu': 'రాహువు',
    'ketu': 'కేతువు',
  };

  late NatalChart _natal;
  DashaSystemResult? _vimshottari;
  String? _dashaIssue;
  late DateTime _targetDate;
  BcpReference _reference = BcpReference.lagna;
  late Map<BcpEventKind, BcpNatalAssessment> _natalAssessments;
  String? _natalCatalogIssue;

  void _refreshDashaSafely() {
    try {
      _vimshottari = DashaService.system(
        kind: DashaSystemKind.vimshottari,
        chart: widget.chart,
        birthDateTime: widget.birthData.localDateTime,
      );
      _dashaIssue = null;
    } catch (error) {
      _vimshottari = null;
      _dashaIssue = 'ఈ జాతకానికి మహాదశ గణన అందుబాటులో లేదు; '
          'లగ్నం/చంద్రుడు ఆధారంగా BCP ఫలితాలు మాత్రం చూడవచ్చు. '
          'సాంకేతిక వివరాలు: $error';
    }
  }

  Map<BcpEventKind, BcpNatalAssessment> _assessSafely(
      {List<BnnMasterRule> bnnCatalog = const []}) {
    try {
      return BcpNatalRuleBridge.assess(widget.chart, bnnCatalog: bnnCatalog);
    } catch (error) {
      // BCP house-cycle and event links must remain visible even when a
      // separate D2/D9/D10/D24/BNN rule evaluator fails for one chart.
      _natalCatalogIssue = 'కొన్ని జన్మ రూల్స్ గణనలో లోపం వచ్చింది. '
          'BCP భావచక్రం మాత్రం కనిపిస్తుంది; పూర్తి IF మార్కులు ఇవ్వలేదు. '
          'సాంకేతిక వివరాలు: $error';
      return {
        for (final kind in BcpEventKind.values)
          kind: const BcpNatalAssessment(),
      };
    }
  }

  Future<void> _loadNatalSources() async {
    try {
      final catalog = await BnnMasterCatalog.load();
      if (!mounted) return;
      setState(() {
        _natalCatalogIssue = null;
        _natalAssessments = _assessSafely(bnnCatalog: catalog);
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _natalCatalogIssue =
          'BNN మూల కేటలాగ్ అందుబాటులో లేదు; D1/D2/D4/D9/D10/D24 ఆధారాలు మాత్రమే చూపుతున్నాం.');
    }
  }

  @override
  void initState() {
    super.initState();
    _natal = BcpAppAdapter.fromAstroChart(widget.chart);
    _natalAssessments = _assessSafely();
    _loadNatalSources();
    _refreshDashaSafely();
    final now = DateTime.now();
    final birth = widget.birthData.localDateTime;
    _targetDate = now.isBefore(birth) ? birth : now;
  }

  @override
  void didUpdateWidget(covariant BcpMasterPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.chart, widget.chart) ||
        oldWidget.birthData.localDateTime != widget.birthData.localDateTime) {
      _natal = BcpAppAdapter.fromAstroChart(widget.chart);
      _refreshDashaSafely();
      _natalAssessments = _assessSafely();
      final birth = widget.birthData.localDateTime;
      _targetDate = _targetDate.isBefore(birth) ? birth : _targetDate;
      _loadNatalSources();
    }
  }

  String _date(DateTime dt) =>
      '${dt.day.toString().padLeft(2, '0')}-${dt.month.toString().padLeft(2, '0')}-${dt.year}';

  String _planet(String name) => _planetNames[name.toLowerCase()] ?? name;

  String _sign(int sign) => _signNames[sign - 1];

  String _referenceLabel(BcpReference reference) => switch (reference) {
        BcpReference.lagna => 'లగ్నం',
        BcpReference.moon => 'చంద్రుడు',
        BcpReference.mahadashaLord => 'మహాదశాధిపతి',
        BcpReference.cycleRuler => 'చక్రాధిపతి',
      };

  String _conditionText(BcpActivation activation, String link) =>
      BcpYearResultExplainer.describeLink(_natal, activation, link);

  DateTime _anniversaryForRunningYear(int year) {
    final date = widget.birthData.localDateTime;
    return DateTime(date.year + year - 1, date.month, date.day);
  }

  void _chooseYear(int year) {
    if (year < 1 || year > 120) return;
    setState(() => _targetDate = _anniversaryForRunningYear(year));
  }

  Future<void> _chooseDate() async {
    final birth = widget.birthData.localDateTime;
    final first = DateTime(birth.year, birth.month, birth.day);
    final last = DateTime(birth.year + 119, 12, 31);
    final today = _targetDate.isBefore(first)
        ? first
        : (_targetDate.isAfter(last) ? last : _targetDate);
    final picked = await showDatePicker(
      context: context,
      initialDate: today,
      firstDate: first,
      lastDate: last,
      helpText: 'BCP పరిశీలన తేదీ',
    );
    if (picked != null && mounted) setState(() => _targetDate = picked);
  }

  Widget _line(String label, String value, {Color? color}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(fontWeight: FontWeight.w800, color: color ?? _accent)),
            const SizedBox(height: 2),
            Text(value),
          ],
        ),
      );

  Widget _natalSign(int sign, BcpActivation active) {
    final ascSign = _natal.ascendantSign;
    final isActive = active.activatedSign == sign;
    final isAsc = ascSign == sign;
    final planets = _natal.planetsInSign(sign);
    final label = planets
        .map((planet) => '${_planet(planet)} ${_natal.intraSignDegree(planet)!.toStringAsFixed(1)}°')
        .join('\n');
    return Container(
      height: 75,
      margin: const EdgeInsets.all(1.5),
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: isActive ? const Color(0xFFEBE1FF) : (isAsc ? const Color(0xFFE1F2E9) : const Color(0xFFF8F7F9)),
        border: Border.all(color: isActive ? _accent : const Color(0xFFCEC9D3), width: isActive ? 1.8 : .75),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('${_sign(sign)}${isAsc ? ' (ల)' : ''}',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10)),
          if (label.isNotEmpty)
            Expanded(
              child: FittedBox(
                alignment: Alignment.topLeft,
                fit: BoxFit.scaleDown,
                child: Text(label,
                    style: const TextStyle(fontSize: 10, height: 1.2)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _natalChart(BcpActivation active) {
    const layout = <List<int>>[
      [12, 1, 2, 3],
      [11, 0, 0, 4],
      [10, 0, 0, 5],
      [9, 8, 7, 6],
    ];
    return Card(
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('జన్మ D1 చక్రం • గ్రహ డిగ్రీలు', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            for (var r = 0; r < 4; r++)
              Row(
                children: [
                  for (var c = 0; c < 4; c++)
                    Expanded(
                      child: layout[r][c] == 0
                          ? SizedBox(
                              height: 78,
                              child: (r == 1 && c == 1)
                                  ? const Center(child: Text('BCP', style: TextStyle(fontWeight: FontWeight.w900, color: _accent)))
                                  : null,
                            )
                          : _natalSign(layout[r][c], active),
                    ),
                ],
              ),
            const SizedBox(height: 5),
            const Text('ఊదా: BCP క్రియాశీల రాశి • ఆకుపచ్చ: జన్మలగ్నం',
                style: TextStyle(fontSize: 11, color: Color(0xFF625A67))),
          ],
        ),
      ),
    );
  }

  Color _evidenceColor(BcpEvidenceScore score) {
    if (score.hasVerifiedNatalRule && score.percent >= 70) {
      return const Color(0xFF16824C); // verified: green
    }
    if (score.percent < 25 || score.contradicted) {
      return const Color(0xFFC64E85); // weak/blocked: pink
    }
    return const Color(0xFF66626D); // links/uncertain: neutral
  }

  Widget _eventTile(
    BcpActivation activation,
    BcpEventDefinition event,
    List<String> links,
    BcpEvidenceScore score,
    BcpNatalAssessment? natalAssessment,
  ) {
    final color = _evidenceColor(score);
    final verified = widget.verifiedEventEvidence[event.kind] ??
        natalAssessment?.evidence;
    final dateWindow = score.timingWindow ?? activation.yearWindow;
    final dateLabel = score.hasTimingConfirmation
        ? 'దశ–గోచార సమ్మిళిత కాలం (అభ్యర్థి)'
        : 'BCP క్రియాశీల జీవిత సంవత్సర కాలం (సంఘటన తేదీ కాదు)';
    final calculatedPreview = BcpYearResultExplainer.yearPreview(
        _natal, activation, event, links);
    final result = score.hasTimingConfirmation
        ? '“${event.titleTelugu}” అంశానికి జన్మ రూల్, దశ, గోచార కాలం కలిసి వచ్చాయి. '
          'ఇది పరిశీలనకు అర్హమైన సంఘటన కాలం మాత్రమే.'
        : score.hasVerifiedNatalRule
            ? '${natalAssessment?.verified.isNotEmpty == true ? natalAssessment!.verified.first.result : 'జన్మ రూల్ సరిపోయింది.'} '
              '$calculatedPreview దశ–గోచార సమ్మిళితం ధృవీకరించలేదు.'
            : '$calculatedPreview స్వతంత్ర జన్మ IF–THEN రూల్ ధృవీకరణ లేకుండా సంఘటన జరుగుతుందని చెప్పరాదు.';
    return Card(
      key: ValueKey('bcp-${_reference.name}-${activation.runningYear}-${event.ruleId}'),
      margin: const EdgeInsets.only(bottom: 8),
      color: score.hasVerifiedNatalRule && score.percent >= 70
          ? const Color(0xFFE7F5EB)
          : score.percent < 25 || score.contradicted
              ? const Color(0xFFFFF1F5)
              : const Color(0xFFF6F4F7),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        key: PageStorageKey('bcp-expanded-${_reference.name}-${activation.runningYear}-${event.ruleId}'),
        title: Row(
          children: [
            Expanded(child: Text(event.titleTelugu,
                style: const TextStyle(fontWeight: FontWeight.w800))),
            Text('ఆధార బలం ${score.percent}%',
                style: TextStyle(fontWeight: FontWeight.w900, color: color)),
          ],
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(calculatedPreview,
                  style: const TextStyle(fontSize: 12,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(score.statusTelugu,
                  style: TextStyle(fontSize: 12, color: color,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: LinearProgressIndicator(
                  minHeight: 7,
                  value: score.percent / 100.0,
                  color: color,
                  backgroundColor: const Color(0xFFE3DEE5),
                ),
              ),
              const SizedBox(height: 5),
              const Text('ఇది రూల్ ఆధార బలం మాత్రమే; సంఘటన జరిగే శాతం కాదు. Pink = ఆధారం తక్కువ, అశుభ ఫలితం కాదు.',
                  style: TextStyle(fontSize: 10, color: Color(0xFF625B65))),
            ],
          ),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(14, 2, 14, 14),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _line('ఫలితం', result, color: color),
          const Divider(height: 12),
          _line('రూల్', [
            '${activation.methodRuleId} • ${event.ruleId} (యాప్ అంశ మ్యాపింగ్)',
            'IF: BCP క్రియాశీల భావానికి సంబంధిత భావాధిపతి/కారకగ్రహ సంబంధం ఉంటే',
            'THEN: ఆ అంశాన్ని పరిశీలనలో చేర్చాలి — సంఘటన నిర్ధారణ కాదు.',
            'నిజ సంఘటన కాలం కోసం స్వతంత్ర మూల జన్మ IF–THEN, దశ, గోచారం ధృవీకరణ అవసరం.',
            if (score.hasVerifiedNatalRule && verified != null)
              'ధృవీకరించిన జన్మ రూల్: ${verified!.natalRuleId}'
              '${verified.natalSourceName == null ? '' : ' • ${verified.natalSourceName}'}'
              '${verified.natalSourcePage == null ? '' : ' • పేజీ ${verified.natalSourcePage}'}'
            else
              'మూల జన్మ IF–THEN రూల్: ఈ జాతకానికి ఇంకా ధృవీకరించలేదు.',
          ].join('\n')),
          if (natalAssessment != null &&
              (natalAssessment.verified.isNotEmpty ||
                  natalAssessment.supportingOnly.isNotEmpty)) ...[
            const Divider(height: 12),
            _line('స్వతంత్ర జన్మ రూల్ ఆధారాలు',
                'పూర్తి IF మ్యాచ్: ${natalAssessment.verified.length} • '
                'పాక్షిక / మూల ధృవీకరణ పెండింగ్: ${natalAssessment.supportingOnly.length}. '
                'పాక్షిక ఆధారాలకు జన్మ రూల్ 30 మార్కులు ఇవ్వలేదు.'),
            for (final hit in natalAssessment.verified.take(3))
              _line('✓ ${hit.id} • పూర్తి IF సరిపోయింది', [
                '${hit.source} • పేజీ ${hit.page}',
                'రూల్: IF ${hit.condition}',
                'పరిశీలన: ${hit.inspection}',
                'ఫలితం: ${hit.result}',
                'పరిధి: ${hit.scope}',
              ].join('\n'), color: const Color(0xFF16824C)),
            if (natalAssessment.supportingOnly.isNotEmpty)
              ExpansionTile(
                title: Text('పెండింగ్ / ఉపనియమాల మూల వివరాలు '
                    '(${natalAssessment.supportingOnly.length})'),
                subtitle: const Text('సంఘటన ధృవీకరణ కాదు • జన్మ మార్కులు 0/30',
                    style: TextStyle(fontSize: 11)),
                childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                children: [
                  for (final hit in natalAssessment.supportingOnly.take(4))
                    _line('◌ ${hit.id} • మూల పరిశీలన', [
                      '${hit.source} • పేజీ ${hit.page}',
                      'రూల్: IF ${hit.condition}',
                      'గణన వివరాలు (మూల టెక్స్ట్): ${hit.inspection}',
                      'సూచన: ${hit.result}',
                      'పరిమితి: ${hit.scope}',
                    ].join('\n'), color: const Color(0xFF796273)),
                ],
              ),
          ] else
            _line('జన్మ రూల్స్',
                'ఈ అంశానికి స్వతంత్ర పూర్తి IF–THEN మ్యాచ్ లేదు. '
                'BCP భావ–గ్రహ సూచన మాత్రమే; జన్మ రూల్ 30 మార్కులు ఇవ్వలేదు.'),
          const Divider(height: 12),
          _line('జాతక పరిశీలన', [
            '${activation.runningYear}వ సంవత్సరం • ${_sign(activation.activatedSign)} • '
                'జన్మ ${activation.activatedNatalHouse}వ భావం',
            ...links.map((link) => _conditionText(activation, link)),
            'ఆధార స్కోరు: BCP ${score.bcpPoints}/40 + '
                'జన్మ రూల్ ${score.natalPoints}/30 + '
                'దశ ${score.dashaPoints}/15 + '
                'గోచారం ${score.transitPoints}/15 = ${score.percent}/100',
          ].join('\n')),
          const Divider(height: 12),
          _line(dateLabel,
              '${_date(dateWindow.start)} నుంచి '
              '${_date(dateWindow.end.subtract(const Duration(days: 1)))} వరకు'),
        ],
      ),
    );
  }

  // Keep method/source audits available without treating pending conditions
  // as a predicted life event or flooding the primary BCP result list.
  Widget _natalEvidenceOverview() {
    final supported = <({BcpEventKind kind, BcpEventDefinition event,
        BcpNatalAssessment assessment})>[];
    for (final event in eventDefinitions) {
      final assessment = _natalAssessments[event.kind];
      if (assessment != null &&
          (assessment.verified.isNotEmpty || assessment.supportingOnly.isNotEmpty)) {
        supported.add((kind: event.kind, event: event, assessment: assessment));
      }
    }
    supported.sort((a, b) {
      final order = b.assessment.verified.length.compareTo(a.assessment.verified.length);
      return order != 0 ? order :
          b.assessment.supportingOnly.length.compareTo(a.assessment.supportingOnly.length);
    });
    final fullCount = supported.fold<int>(0,
        (sum, item) => sum + item.assessment.verified.length);
    final partialCount = supported.fold<int>(0,
        (sum, item) => sum + item.assessment.supportingOnly.length);
    return Card(
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        key: const PageStorageKey('bcp-natal-source-audit'),
        initiallyExpanded: false,
        title: const Text('జన్మ రూల్స్ — మూల పరిశీలన',
            style: TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('పూర్తి IF $fullCount • మూల ధృవీకరణ / ఉపనియమాలు $partialCount. '
            'ఇవి అన్ని ఈ సంవత్సరంలో జరిగే సంఘటనలు కావు.',
            style: const TextStyle(fontSize: 11)),
        childrenPadding: const EdgeInsets.fromLTRB(10, 0, 10, 12),
        children: [
          if (supported.isEmpty)
            const Padding(
              padding: EdgeInsets.all(8),
              child: Text('ఈ జాతకానికి అనుసంధానమైన మూల IF ప్రస్తుతం లేదు. '
                  'ఇది సంఘటన జరగదనే అర్థం కాదు.'),
            ),
          for (final item in supported)
            ExpansionTile(
              key: PageStorageKey('bcp-natal-topic-${item.kind.name}'),
              title: Text(item.event.titleTelugu,
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('పూర్తి IF ${item.assessment.verified.length} • '
                  'అదనపు పరిశీలన ${item.assessment.supportingOnly.length}',
                  style: const TextStyle(fontSize: 11)),
              childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
              children: [
                for (final hit in item.assessment.verified.take(4))
                  _line('✓ ${hit.id} • పూర్తి జన్మ IF',
                      '${hit.result}\nమూలం: ${hit.source} • పేజీ ${hit.page}\n'
                      'పరిశీలన: ${hit.inspection}\n'
                      'ఈ IF సంఘటన జరిగే తేదీని ధృవీకరించదు.',
                      color: const Color(0xFF16824C)),
                if (item.assessment.supportingOnly.isNotEmpty)
                  ExpansionTile(
                    key: PageStorageKey('bcp-partial-${item.kind.name}'),
                    title: Text('పెండింగ్ / ఉపనియమాలు '
                        '(${item.assessment.supportingOnly.length})',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: const Text('మూల పరిశీలన కోసం మాత్రమే; '
                        '30 జన్మ మార్కులు రావు.',
                        style: TextStyle(fontSize: 11)),
                    childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                    children: [
                      for (final hit in item.assessment.supportingOnly.take(4))
                        _line('◌ ${hit.id} • ధృవీకరణ పెండింగ్',
                            'మూలం: ${hit.source} • పేజీ ${hit.page}\n'
                            'రూల్: ${hit.condition}\n'
                            'గణన వివరాలు (మూల టెక్స్ట్): ${hit.inspection}\n'
                            'సూచన: ${hit.result}\n'
                            'పరిమితి: ${hit.scope}',
                            color: const Color(0xFF795B6D)),
                    ],
                  ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _unmatchedTopics(BcpActivation activation,
      List<BcpEventDefinition> unmatched) {
    return Card(
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        title: Text('ఈ సంవత్సరంలో BCP సంబంధం లేని అంశాలు (${unmatched.length})',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: const Text('దాచకుండా, ఏ సంబంధం సరిపోలలేదో ఇక్కడ చూడవచ్చు',
            style: TextStyle(fontSize: 11)),
        childrenPadding: const EdgeInsets.fromLTRB(12, 2, 12, 12),
        children: [
          for (final event in unmatched)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${event.titleTelugu} • ${event.ruleId}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text('ఈ కాలంలో ${_sign(activation.activatedSign)} '
                      '(${activation.activatedNatalHouse}వ జన్మ భావం) నుంచి '
                      'ఈ అంశపు భావాలు/కారకులకు ప్రత్యక్ష BCP లింక్ లేదు. '
                      'ఇది సంఘటన జరగదనే తీర్పు కాదు.',
                      style: const TextStyle(fontSize: 12)),
                  const Divider(height: 10),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _degreePoints(BcpActivation activation) {
    final triggers = BcpEngine.degreeTriggers(chart: _natal, activation: activation);
    return Card(
      child: ExpansionTile(
        title: const Text('డిగ్రీ ఆధారిత కాలబిందువులు',
            style: TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${triggers.length} అంచనా బిందువులు • BCP-EXT-002'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 2, 12, 14),
        children: [
          for (final t in triggers)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${_planet(t.label)} • ${t.intraSignDegrees.toStringAsFixed(2)}°'),
              trailing: Text(_date(t.tentativeDate),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(t.reasons.join(', '), style: const TextStyle(fontSize: 11)),
            ),
          const Text('ఇవి జన్మదినం నుంచి డిగ్రీ నిష్పత్తిలో లెక్కించిన సూచన తేదీలు మాత్రమే.',
              style: TextStyle(fontSize: 12, color: Color(0xFF715C7C))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final year = BcpEngine.runningYear(widget.birthData.localDateTime, _targetDate);
    final cycleStart = ((year - 1) ~/ 12) * 12 + 1;
    final md = _vimshottari == null
        ? null
        : DashaService.periodAt(_vimshottari!.mahadashas, _targetDate);
    final selected = _reference == BcpReference.mahadashaLord && md == null
        ? <BcpActivation>[]
        : BcpEngine.activations(
            chart: _natal,
            birthDate: widget.birthData.localDateTime,
            onDate: _targetDate,
            references: {_reference},
            activeMahadashaLord: md?.lord,
          );
    final activation = selected.isEmpty ? null : selected.single;
    final connected = <({BcpEventDefinition event, List<String> links, BcpEvidenceScore score})>[];
    final unmatched = <BcpEventDefinition>[];
    if (activation != null) {
      for (final event in eventDefinitions) {
        final links = BcpEngine.eventLinks(_natal, activation, event);
        if (links.isEmpty) {
          unmatched.add(event);
          continue;
        }
        final assessment = _natalAssessments[event.kind];
        final score = BcpEngine.scoreEvent(
          activation: activation,
          matchedLinks: links,
          evidence: widget.verifiedEventEvidence[event.kind] ??
              assessment?.evidence ?? const BcpEventEvidence(),
        );
        connected.add((event: event, links: links, score: score));
      }
      connected.sort((a, b) {
        final verifiedOrder = (b.score.hasVerifiedNatalRule ? 1 : 0)
            .compareTo(a.score.hasVerifiedNatalRule ? 1 : 0);
        if (verifiedOrder != 0) return verifiedOrder;
        final scoreOrder = b.score.percent.compareTo(a.score.percent);
        return scoreOrder != 0 ? scoreOrder : a.event.ruleId.compareTo(b.event.ruleId);
      });
    }
    final primary = connected.where((item) =>
        BcpYearResultExplainer.hasIndependentNatalSupport(item.score)).toList();
    final linkOnly = connected.where((item) =>
        !BcpYearResultExplainer.hasIndependentNatalSupport(item.score)).toList();
    final dateWindow = activation?.yearWindow;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Card(
          color: const Color(0xFFF1EBFC),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('BCP — భృగు చక్ర పద్ధతి',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: _accent)),
                const SizedBox(height: 6),
                const Text('12 సంవత్సరాల భావ చక్రం • Running Year ఆధారంగా గణన',
                    style: TextStyle(fontSize: 12)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.remove_circle_outline),
                      onPressed: year > 1 ? () => _chooseYear(year - 1) : null,
                      tooltip: 'మునుపటి సంవత్సరం',
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Text('$year వ జీవిత సంవత్సరం', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                          Text('పూర్తయిన వయస్సు: ${year - 1}', style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add_circle_outline),
                      onPressed: year < 120 ? () => _chooseYear(year + 1) : null,
                      tooltip: 'తదుపరి సంవత్సరం',
                    ),
                  ],
                ),
                Align(
                  alignment: Alignment.center,
                  child: TextButton.icon(
                    onPressed: _chooseDate,
                    icon: const Icon(Icons.calendar_month),
                    label: Text('పరిశీలన తేదీ: ${_date(_targetDate)}'),
                  ),
                ),
                const Divider(),
                Text('12 ఏళ్ల చక్రం • ${cycleStart}–${cycleStart + 11}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    for (int i = cycleStart; i < cycleStart + 12 && i <= 120; i++)
                      ChoiceChip(
                        label: Text('$i'),
                        selected: i == year,
                        onSelected: (_) => _chooseYear(i),
                        selectedColor: const Color(0xFFD9C5FC),
                        labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                        visualDensity: VisualDensity.compact,
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text('BCP గణన ఆధారం', style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final reference in BcpReference.values)
              ChoiceChip(
                label: Text(_referenceLabel(reference), style: const TextStyle(fontSize: 12)),
                selected: _reference == reference,
                selectedColor: const Color(0xFFDCCAF9),
                onSelected: (_) => setState(() => _reference = reference),
              ),
          ],
        ),
        if (activation == null) ...[
          const SizedBox(height: 10),
          const Card(child: Padding(
            padding: EdgeInsets.all(12),
            child: Text('ఎంపిక చేసిన తేదీకి ఈ ఆధారం అందుబాటులో లేదు. చక్రాధిపతి పద్ధతి 108వ సంవత్సరం వరకు; మహాదశాధిపతి కోసం దశా గణన అవసరం.'),
          )),
        ] else ...[
          const SizedBox(height: 10),
          Card(
            color: const Color(0xFFE8F5EF),
            surfaceTintColor: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${activation.activatedHouseFromReference}వ చక్ర భావం → ${_sign(activation.activatedSign)}',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF177548))),
                  const SizedBox(height: 4),
                  Text('జన్మ లగ్నం నుంచి ${activation.activatedNatalHouse}వ భావం • ${activation.methodRuleId}'),
                  if (_reference == BcpReference.mahadashaLord && md != null)
                    Text('ఈ తేదీకి మహాదశ: ${_planet(md.lord)}'),
                  if (_reference == BcpReference.cycleRuler && activation.referencePlanet != null)
                    Text('ఈ చక్రాధిపతి: ${_planet(activation.referencePlanet!)}'),
                  if (dateWindow != null)
                    Text('కాలం: ${_date(dateWindow.start)} నుంచి ${_date(dateWindow.end.subtract(const Duration(days: 1)))} వరకు',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
          _natalChart(activation),
          const SizedBox(height: 10),
          Text('ఈ కాలంలో జన్మ IF మద్దతు ఉన్న అంశాలు (${primary.length})',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          const Text('BCP సంబంధం + స్వతంత్ర పూర్తి జన్మ IF సరిపోయిన అంశాలు మాత్రమే '
              'ప్రధానంగా కనిపిస్తాయి. ఇది సంఘటన జరిగే హామీ కాదు.',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          if (primary.isEmpty)
            const Card(
              color: Color(0xFFF6F4F7),
              child: Padding(
                padding: EdgeInsets.all(12),
                child: Text('ఈ సంవత్సరానికి BCP సంబంధంతో పాటు ధృవీకరించిన '
                    'పూర్తి జన్మ IF ప్రస్తుతం గుర్తించలేదు. '
                    'సంబంధ సూచనలు, మూల పరిశీలనలను క్రింద చూడవచ్చు. '
                    'సంఘటన జరగదని దీని అర్థం కాదు.'),
              ),
            ),
          for (final item in primary)
            _eventTile(activation, item.event, item.links, item.score,
                _natalAssessments[item.event.kind]),
          const SizedBox(height: 6),
          Card(
            color: const Color(0xFFF6F4F7),
            surfaceTintColor: Colors.transparent,
            child: ExpansionTile(
              key: PageStorageKey('bcp-links-${_reference.name}-${activation.runningYear}'),
              initiallyExpanded: false,
              title: Text('BCP సంబంధ సూచనలు మాత్రమే (${linkOnly.length})',
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('జన్మ IF / కాల ధృవీకరణ లేదు — '
                  'టచ్ చేస్తే సంబంధించిన గ్రహం, భావం, Rule Evidence % చూడవచ్చు. '
                  'పింక్ రంగు అశుభ సంఘటన అని అర్థం కాదు.',
                  style: TextStyle(fontSize: 11)),
              childrenPadding: const EdgeInsets.fromLTRB(8, 0, 8, 10),
              children: [
                for (final item in linkOnly)
                  _eventTile(activation, item.event, item.links, item.score,
                      _natalAssessments[item.event.kind]),
              ],
            ),
          ),
          const SizedBox(height: 6),
          _natalEvidenceOverview(),
          _unmatchedTopics(activation, unmatched),
          const SizedBox(height: 10),
          _degreePoints(activation),
        ],
      ],
    );
  }
}
