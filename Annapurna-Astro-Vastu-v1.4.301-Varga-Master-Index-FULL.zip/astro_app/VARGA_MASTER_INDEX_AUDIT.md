# Annapurna Astro Vastu — all-varga topic and source-rule master index

**Source baseline:** `Annapurna-Astro-Vastu-v1.4.301-Vargas-63-Crosscheck-FULL-Source.zip` (version `1.4.301+301`). This update is additive. The November 5 `v1.4.326` D10 *patch* was prepared for version 325 and has **not** been blindly overlaid on this earlier baseline.

## Scope

- 693 **registry/index entries**, each with its own source ID, primary varga, linked vargas, topic, source and known source pages. This is **not** 693 executable IF–THEN rules or 693 independent predictions.
- 20 chart labels (D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D11, D12, D16, D20, D24, D27, D30, D40, D45, D60) + a `COMMON` section for general, cross-chart, dasha and timing source instructions.
- New navigation into the **same** master source from the existing Unified Varga tab and the Dn selection in the chart tab. A cross-chart source appears once in the full list; the chart filter can link to it without copying its rule into another source catalog.

## Source inventories (do not sum as actual applied matches)

| Existing source | Records | Application state |
|---|---:|---|
| `mallikarjuna_255_rules.json` | 255 | Existing varga engine; only its supported predicates can be MATCHED |
| `annapurna_all_vargas_63_audited.json` | 63 | Existing 4-source-condition subset; remaining source review |
| `D12_Rules_Examples.json` | 59 | Already in the separate D12 module |
| `D10_VRUTTI_IF_THEN_REGISTRY.json` | 213 | Already indexed by separate D10 module |
| `d24_education_master_rules.json` | 34 | Existing D24 education source definitions |
| `d7_saptamsha_master_rules.json` | 14 | Topic/section index **not 14 distinct executable IFs** |
| `marriage_integrated_catalog.dart` | 14 | Topic/section index **not 14 distinct executable IFs** |
| `d3_sarala7_complete_source_index.json` | 4 | Existing D3 book-source summary, not guaranteed full predicates |
| `varga_ocr_json_37_rules.json` | 37 | Older standalone JSON source; *not* linked to live Flutter evaluator |
| **Unique source IDs** | **693** | One master navigation index |

### Duplicate policy

The 693 source IDs are unique and none has an *exact same normalized IF + THEN in the same primary chart*. Similar teaching points across different books or partial-condition expansions are retained as distinct source references, **not** silently declared independent corroborating outcomes. This is an exact-duplicate structural check, not a claim of full doctrinal/semantic deduplication.

### Eligibility and no-pending false outputs

- Any evaluated result uses the already existing `VargaUnifiedRuleService` and `VargaSource63Service`. The new index is navigation only.
- Entries from D10/D12/D24/D7/marriage existing modules or the older OCR JSON get **no automatic green result from the index**.
- An `OCR_REVIEW`, source-null or missing calculator does **not** become an affirmative prediction or an inverse negative (`IF=false` never means `NOT event`). It is visible as a source link only.
- The displayed sequence is rule -> chart examination -> validated result (if matched) -> remedy (only if sourced) -> provenance and page.
- The index does not produce remedy text. It does not hide unsourced material; missing source pages are explicitly null.
- D5/D6/D8/D11 **are indexed only**; current `VargaService.definitions` supports classical 16 factors, not those additional four charts. Their separate calculated charts should not be claimed as implemented.
- A rule may refer to more than one chart; one primary index entry and chart references avoid storing it repeatedly.

### User-fixed D24 source configuration

The existing D24 file and app classification are preserved: Technical Aries/Scorpio/Capricorn/Aquarius, semi-technical Gemini/Leo/Virgo, non-technical Taurus/**Cancer**/Libra/Sagittarius/Pisces. The user education levels are 4H up to Intermediate; 9H Degree/B.Tech; 2H PG; 7H Post-PG. These definitions are not overridden by the HTML-derived contradictions.

## Modified or added Flutter items

- `assets/varga/annapurna_varga_master_index.json` — master references, not second rule engine.
- `assets/varga/varga_ocr_json_37_rules.json` — standalone source preserved for navigation.
- `lib/screens/varga_master_index_panel.dart` — chart tabs, topic lists, source pages, read-only source details; evaluated results only where the existing engine says MATCH.
- `lib/screens/unified_varga_results_tab.dart` — two-mode view: All Charts / Topics (default); Existing Applied Results.
- `lib/screens/chart_screen.dart` — chart-local button opens the same master index filtered to selected Dn.
- `pubspec.yaml` — two additional asset declarations (app version unchanged).
- `test/varga_master_index_test.dart` — declared index tests (not executable in this environment without Flutter SDK).
- `VARGA_MASTER_INDEX_AUDIT.md` — this document.

## Validation limits

JSON formatting, 693 unique IDs, complete 255/63 ID preservation, all IDs linked to valid charts, catalog source preservation, ZIP CRC, unchanged pre-existing source catalogs, HTML JS syntax and page link structure can be checked statically. Flutter compile/tests, real app runtime, timing predictions and APK are **not** certified here because Flutter SDK is absent. Do **not** replace an installed/newer 1.4.325/326 project with this 1.4.301-based full source; merge these changed files into the most recent complete source instead.
