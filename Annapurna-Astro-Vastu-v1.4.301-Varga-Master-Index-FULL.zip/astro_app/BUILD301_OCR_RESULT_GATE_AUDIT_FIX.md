# Annapurna — OCR status / IF result separation (v1.4.301 source baseline)

## Verified from available Flutter source
- BNN source 462: 343 OCR_REVIEW; 82 FACTS_REQUIRED; 37 REVIEW.
- `BnnAllRulesMatchService.check` already calculates supported IF across source statuses.
- 343 app-authored `inspection` notes falsely claimed OCR always stops auto match. Corrected ONLY these notes.
- Unified Varga catalogue 255: its 247 source records have catalogue-only implementation status; a limited hard-coded matcher exists. Not all 255 have executable calculations.

## Patch changes
1. Default Varga tab shows MATCH (real computed IF results) instead of ALL pending rows. The full review list is accessible under All / Calculation/Source Review.
2. BNN computed natal IF matches stay visible without an OCR provenance gate. The source text remains unverified. One explanatory note distinguishes computed IF from confirmed source accuracy.
3. BNN false condition no longer says there is no government job, or automatically negates any other outcome. Non-matches are grouped into a collapsed audit section.
4. BNN rule detail shows PDF page and remedies only if present; no invented remedy.
5. Source catalogue entries, IDs, IF/THEN texts, PDF page numbers and provenance statuses are unchanged.

## Limitations
- This patch does not transcribe or verify scanned original books. No OCR source truth has been upgraded.
- It cannot make 255 qualitative catalogue entries or 462 BNN records fully executable. No false event predictions were added.
- Based ONLY on Library full source v1.4.301, NOT an unverified later v1.4.325/326 full release. Do not use this full ZIP to overwrite a newer app without merging intervening changes.
- Flutter/Dart SDK not installed here: static audit only; no compilation, device runtime or APK validation.
