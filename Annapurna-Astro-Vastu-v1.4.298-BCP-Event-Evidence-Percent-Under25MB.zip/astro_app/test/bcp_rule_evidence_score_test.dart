import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bcp_master_engine.dart';

void main() {
  final chart = NatalChart(ascendantSign: 1, longitudes: {
    'sun': 2, 'moon': 93, 'mars': 41, 'mercury': 350,
    'jupiter': 250, 'venus': 185, 'saturn': 282,
    'rahu': 315, 'ketu': 135,
  });
  final year = BcpEngine.activations(
    chart: chart,
    birthDate: DateTime(1990, 5, 10),
    onDate: DateTime(2020, 10, 11),
  ).single;

  test('unverified BCP house/graha links never score more than 40/100', () {
    for (final event in eventDefinitions) {
      final links = BcpEngine.eventLinks(chart, year, event);
      final score = BcpEngine.scoreEvent(
        activation: year, matchedLinks: links,
      );
      expect(score.percent, inInclusiveRange(0, 40));
      expect(score.status, BcpStatus.insufficientEvidence);
      expect(score.hasTimingConfirmation, isFalse);
    }
  });

  test('unknown natal rule is not silently treated as verified', () {
    final score = BcpEngine.scoreEvent(
      activation: year, matchedLinks: ['DIRECT_HOUSE: natal house 7'],
      evidence: BcpEventEvidence(
        natalPromise: true, natalRuleVerified: true,
        // Missing source rule id means not independently verified.
      ),
    );
    expect(score.percent, 14);
    expect(score.natalPoints, 0);
    expect(score.status, BcpStatus.insufficientEvidence);
  });

  test('natal rule and mutually overlapping timing windows give a candidate', () {
    final score = BcpEngine.scoreEvent(
      activation: year, matchedLinks: ['DIRECT_HOUSE: natal house 7'],
      evidence: BcpEventEvidence(
        natalPromise: true, natalRuleVerified: true,
        natalRuleId: 'SOURCE-VERIFIED-1',
        dashaSupported: true, transitSupported: true,
        dashaWindow: DateWindow(DateTime(2020, 6), DateTime(2021, 4)),
        transitWindow: DateWindow(DateTime(2020, 8), DateTime(2021, 1)),
      ),
    );
    expect(score.percent, 74); // 14+30+15+15
    expect(score.status, BcpStatus.timingCandidate);
    expect(score.timingWindow!.start, DateTime(2020, 8));
    expect(score.timingWindow!.end, DateTime(2021, 1));
  });

  test('nonoverlapping windows do not produce a date confirmation', () {
    final score = BcpEngine.scoreEvent(
      activation: year, matchedLinks: ['DIRECT_HOUSE: natal house 7'],
      evidence: BcpEventEvidence(
        natalPromise: true, natalRuleVerified: true, natalRuleId: 'RULE-1',
        dashaSupported: true, transitSupported: true,
        dashaWindow: DateWindow(DateTime(2020, 6), DateTime(2020, 7)),
        transitWindow: DateWindow(DateTime(2020, 8), DateTime(2021, 1)),
      ),
    );
    expect(score.timingWindow, isNull);
    expect(score.hasTimingConfirmation, isFalse);
    expect(score.status, BcpStatus.yearCandidate);
  });

  test('explicitly disproved natal promise blocks an event claim', () {
    final score = BcpEngine.scoreEvent(
      activation: year, matchedLinks: ['DIRECT_HOUSE: natal house 7'],
      evidence: BcpEventEvidence(
        natalPromise: false, natalRuleVerified: true, natalRuleId: 'RULE-1',
      ),
    );
    expect(score.percent, 0);
    expect(score.status, BcpStatus.insufficientEvidence);
  });

  test('score capped at 100 regardless of duplicate supporting links', () {
    final score = BcpEngine.scoreEvent(
      activation: year,
      matchedLinks: [
        'DIRECT_HOUSE: natal house 7',
        'HOUSE_LORD_OCCUPIES_ACTIVE_SIGN: house 2 -> venus',
        'HOUSE_LORD_ASPECT: house 7 -> venus',
        'KARAKA_OCCUPIES_ACTIVE_SIGN: venus',
        'KARAKA_ASPECTS_ACTIVE_SIGN: venus',
      ],
    );
    expect(score.bcpPoints, 40);
    expect(score.percent, 40);
  });
}
