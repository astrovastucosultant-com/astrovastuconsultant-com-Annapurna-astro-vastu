import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bcp_app_adapter.dart';
import 'package:astro_app/astrology/bcp_master_engine.dart';

void main() {
  test('Swiss sidereal degrees and 0-based lagna convert exactly once', () {
    const result = AstroChartResult(
      julianDay: 2451545.0,
      ayanamsaDegrees: 23.8,
      ascendantLongitude: 89.99,
      planets: [
        PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 330.5, latitude: 0, speed: 1),
        PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 90.25, latitude: 0, speed: 13),
        PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 30, latitude: 0, speed: -0.05),
        PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 210, latitude: 0, speed: -0.05),
      ],
      engineVersion: 'test',
    );
    final natal = BcpAppAdapter.fromAstroChart(result);
    expect(natal.ascendantSign, 3); // Gemini
    expect(natal.signOf('sun'), 12);
    expect(natal.signOf('moon'), 4);
    expect(natal.intraSignDegree('moon'), closeTo(0.25, 1e-10));
    expect(natal.signOf('ketu'), 8);
    final activation = BcpEngine.activations(
      chart: natal,
      birthDate: DateTime(2000, 1, 1),
      onDate: DateTime(2000, 1, 1),
    ).single;
    expect(activation.activatedSign, 3);
    expect(activation.activatedNatalHouse, 1);
  });
}
