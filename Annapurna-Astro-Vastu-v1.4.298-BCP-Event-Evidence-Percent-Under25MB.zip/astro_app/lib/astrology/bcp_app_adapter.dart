import 'astro_models.dart';
import 'bcp_master_engine.dart';

/// Glue between Annapurna's Swiss Ephemeris D1 positions and BCP's
/// side-effect-free natal calculations. No pseudo or demo longitudes.
class BcpAppAdapter {
  static NatalChart fromAstroChart(AstroChartResult result) {
    return NatalChart(
      ascendantSign: result.ascendantSignIndex + 1,
      longitudes: {
        for (final planet in result.planets)
          planet.name.toLowerCase(): planet.longitude,
      },
    );
  }
}
