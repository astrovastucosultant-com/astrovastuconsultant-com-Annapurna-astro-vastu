import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bcp_app_adapter.dart';
import '../astrology/bcp_master_engine.dart';
import '../astrology/dasha_service.dart';
import '../models/birth_data.dart';
import '../utils/astro_format.dart';

/// UI for the uploaded BCP v1.0 engine. Only this panel is the BCP route;
/// it does not change BNN/BSP, other timing engines or Western's clean slate.
class BcpMasterPanel extends StatefulWidget {
  final BirthData birthData;
  final AstroChartResult chart;
  /// Only genuinely verified external source-rule matches may populate this.
  /// An empty map deliberately keeps BCP events as topic links, not predictions.
  final Map<BcpEventKind, BcpEventEvidence> verifiedEventEvidence;

  const BcpMasterPanel({
    super.key,
    required this.birthData,
    required this.chart,
    this.verifiedEventEvidence = const {},
  });

  @override
  State<BcpMasterPanel> createState() => _BcpMasterPanelState();
}

class _BcpMasterPanelState extends State<BcpMasterPanel> {
  static const _accent = Color(0xFF6633A6);
  static const _signNames = AstroFormat.signNamesTe;
  static const _planetNames = <String, String>{
    'sun': 'రవి',
    'moon': 'చంద్రుడు',
    'mars': 'కుజుడు',
    'mercury': 'బుధుడు',
    'jupiter': 'గురువు',
    'venus': 'శుక్రుడు',
    'saturn': 'శని',
    'rahu': 'రాహువు',
    'ketu': 'కేతువు',
  };

  late final NatalChart _natal;
  late final DashaSystemResult _vimshottari;
  late DateTime _targetDate;
  BcpReference _reference = BcpReference.lagna;

  @override
  void initState() {
    super.initState();
    _natal = BcpAppAdapter.fromAstroChart(widget.chart);
    _vimshottari = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: widget.chart,
      birthDateTime: widget.birthData.localDateTime,
    );
    final now = DateTime.now();
    final birth = widget.birthData.localDateTime;
    _targetDate = now.isBefore(birth) ? birth : now;
  }

  String _date(DateTime dt) =>
      '${dt.day.toString().padLeft(2, '0')}-${dt.month.toString().padLeft(2, '0')}-${dt.year}';

  String _planet(String name) => _planetNames[name.toLowerCase()] ?? name;

  String _sign(int sign) => _signNames[sign - 1];

  String _referenceLabel(BcpReference reference) => switch (reference) {
        BcpReference.lagna => 'లగ్నం',
        BcpReference.moon => 'చంద్రుడు',
        BcpReference.mahadashaLord => 'మహాదశాధిపతి',
        BcpReference.cycleRuler => 'చక్రాధిపతి',
      };

  String _conditionText(String link) {
    final parts = link.split(':');
    if (parts.length < 2) return link;
    final value = parts.skip(1).join(':').trim();
    switch (parts.first) {
      case 'DIRECT_HOUSE':
        return 'క్రియాశీల జన్మ భావం: ${value.replaceFirst('natal house ', '')}';
      case 'HOUSE_LORD_OCCUPIES_ACTIVE_SIGN':
        return 'సంబంధిత భావాధిపతి క్రియాశీల రాశిలో ఉన్నాడు: $value';
      case 'HOUSE_LORD_ASPECT':
        return 'సంబంధిత భావాధిపతి క్రియాశీల రాశిని చూస్తున్నాడు: $value';
      case 'KARAKA_OCCUPIES_ACTIVE_SIGN':
        return 'కారకగ్రహం క్రియాశీల రాశిలో ఉంది: ${_planet(value)}';
      case 'KARAKA_ASPECTS_ACTIVE_SIGN':
        return 'కారకగ్రహం క్రియాశీల రాశిని చూస్తోంది: ${_planet(value)}';
      default:
        return link;
    }
  }

  DateTime _anniversaryForRunningYear(int year) {
    final date = widget.birthData.localDateTime;
    return DateTime(date.year + year - 1, date.month, date.day);
  }

  void _chooseYear(int year) {
    if (year < 1 || year > 120) return;
    setState(() => _targetDate = _anniversaryForRunningYear(year));
  }

  Future<void> _chooseDate() async {
    final birth = widget.birthData.localDateTime;
    final first = DateTime(birth.year, birth.month, birth.day);
    final last = DateTime(birth.year + 119, 12, 31);
    final today = _targetDate.isBefore(first)
        ? first
        : (_targetDate.isAfter(last) ? last : _targetDate);
    final picked = await showDatePicker(
      context: context,
      initialDate: today,
      firstDate: first,
      lastDate: last,
      helpText: 'BCP పరిశీలన తేదీ',
    );
    if (picked != null && mounted) setState(() => _targetDate = picked);
  }

  Widget _line(String label, String value, {Color? color}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(fontWeight: FontWeight.w800, color: color ?? _accent)),
            const SizedBox(height: 2),
            Text(value),
          ],
        ),
      );

  Widget _natalSign(int sign, BcpActivation active) {
    final ascSign = _natal.ascendantSign;
    final isActive = active.activatedSign == sign;
    final isAsc = ascSign == sign;
    final planets = _natal.planetsInSign(sign);
    final label = planets
        .map((planet) => '${_planet(planet)} ${_natal.intraSignDegree(planet)!.toStringAsFixed(1)}°')
        .join('\n');
    return Container(
      height: 75,
      margin: const EdgeInsets.all(1.5),
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: isActive ? const Color(0xFFEBE1FF) : (isAsc ? const Color(0xFFE1F2E9) : const Color(0xFFF8F7F9)),
        border: Border.all(color: isActive ? _accent : const Color(0xFFCEC9D3), width: isActive ? 1.8 : .75),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('${_sign(sign)}${isAsc ? ' (ల)' : ''}',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10)),
          if (label.isNotEmpty)
            Expanded(
              child: FittedBox(
                alignment: Alignment.topLeft,
                fit: BoxFit.scaleDown,
                child: Text(label,
                    style: const TextStyle(fontSize: 10, height: 1.2)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _natalChart(BcpActivation active) {
    const layout = <List<int>>[
      [12, 1, 2, 3],
      [11, 0, 0, 4],
      [10, 0, 0, 5],
      [9, 8, 7, 6],
    ];
    return Card(
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('జన్మ D1 చక్రం • గ్రహ డిగ్రీలు', style: TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            for (var r = 0; r < 4; r++)
              Row(
                children: [
                  for (var c = 0; c < 4; c++)
                    Expanded(
                      child: layout[r][c] == 0
                          ? SizedBox(
                              height: 78,
                              child: (r == 1 && c == 1)
                                  ? const Center(child: Text('BCP', style: TextStyle(fontWeight: FontWeight.w900, color: _accent)))
                                  : null,
                            )
                          : _natalSign(layout[r][c], active),
                    ),
                ],
              ),
            const SizedBox(height: 5),
            const Text('ఊదా: BCP క్రియాశీల రాశి • ఆకుపచ్చ: జన్మలగ్నం',
                style: TextStyle(fontSize: 11, color: Color(0xFF625A67))),
          ],
        ),
      ),
    );
  }

  Color _evidenceColor(BcpEvidenceScore score) {
    if (score.hasVerifiedNatalRule && score.percent >= 70) {
      return const Color(0xFF16824C); // verified: green
    }
    if (score.percent < 25 || score.contradicted) {
      return const Color(0xFFC64E85); // weak/blocked: pink
    }
    return const Color(0xFF66626D); // links/uncertain: neutral
  }

  Widget _eventTile(
    BcpActivation activation,
    BcpEventDefinition event,
    List<String> links,
    BcpEvidenceScore score,
  ) {
    final color = _evidenceColor(score);
    final verified = widget.verifiedEventEvidence[event.kind];
    final dateWindow = score.timingWindow ?? activation.yearWindow;
    final dateLabel = score.hasTimingConfirmation
        ? 'దశ–గోచార సమ్మిళిత కాలం (అభ్యర్థి)'
        : 'BCP క్రియాశీల జీవిత సంవత్సర కాలం (సంఘటన తేదీ కాదు)';
    final result = score.hasTimingConfirmation
        ? '“${event.titleTelugu}” అంశానికి జన్మ రూల్, దశ, గోచార కాలం కలిసి వచ్చాయి. '
          'ఇది పరిశీలనకు అర్హమైన సంఘటన కాలం మాత్రమే.'
        : score.hasVerifiedNatalRule
            ? '“${event.titleTelugu}” అంశానికి స్వతంత్ర జన్మ రూల్ ఆధారం ఉంది. '
              'కానీ దశ–గోచార సమ్మిళితం ధృవీకరించలేదు.'
            : '“${event.titleTelugu}” అంశానికి BCP భావ–గ్రహ సంబంధ సూచన మాత్రమే. '
              'స్వతంత్ర జన్మ IF–THEN రూల్ ధృవీకరణ లేకుండా సంఘటన జరుగుతుందని చెప్పరాదు.';
    return Card(
      key: ValueKey('bcp-${_reference.name}-${activation.runningYear}-${event.ruleId}'),
      margin: const EdgeInsets.only(bottom: 8),
      color: score.hasVerifiedNatalRule
          ? const Color(0xFFE7F5EB)
          : const Color(0xFFFFF1F5),
      surfaceTintColor: Colors.transparent,
      child: ExpansionTile(
        key: PageStorageKey('bcp-expanded-${_reference.name}-${activation.runningYear}-${event.ruleId}'),
        title: Row(
          children: [
            Expanded(child: Text(event.titleTelugu,
                style: const TextStyle(fontWeight: FontWeight.w800))),
            Text('${score.percent}%',
                style: TextStyle(fontWeight: FontWeight.w900, color: color)),
          ],
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(score.statusTelugu,
                  style: TextStyle(fontSize: 12, color: color,
                      fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              ClipRRect(
                borderRadius: BorderRadius.circular(5),
                child: LinearProgressIndicator(
                  minHeight: 7,
                  value: score.percent / 100.0,
                  color: color,
                  backgroundColor: const Color(0xFFE3DEE5),
                ),
              ),
              const SizedBox(height: 5),
              const Text('ఆధార బలం % మాత్రమే; సంఘటన జరిగే గణాంక సంభావ్యత కాదు.',
                  style: TextStyle(fontSize: 10, color: Color(0xFF625B65))),
            ],
          ),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(14, 2, 14, 14),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _line('ఫలితం', result, color: color),
          const Divider(height: 12),
          _line('రూల్', [
            '${activation.methodRuleId} • ${event.ruleId} (యాప్ అంశ మ్యాపింగ్)',
            'IF: BCP క్రియాశీల భావానికి సంబంధిత భావాధిపతి/కారకగ్రహ సంబంధం ఉంటే',
            'THEN: ఆ అంశాన్ని పరిశీలనలో చేర్చాలి — సంఘటన నిర్ధారణ కాదు.',
            'నిజ సంఘటన కాలం కోసం స్వతంత్ర మూల జన్మ IF–THEN, దశ, గోచారం ధృవీకరణ అవసరం.',
            if (score.hasVerifiedNatalRule && verified != null)
              'ధృవీకరించిన జన్మ రూల్: ${verified!.natalRuleId}'
              '${verified.natalSourceName == null ? '' : ' • ${verified.natalSourceName}'}'
              '${verified.natalSourcePage == null ? '' : ' • పేజీ ${verified.natalSourcePage}'}'
            else
              'మూల జన్మ IF–THEN రూల్: ఈ జాతకానికి ఇంకా ధృవీకరించలేదు.',
          ].join('\n')),
          const Divider(height: 12),
          _line('జాతక పరిశీలన', [
            '${activation.runningYear}వ సంవత్సరం • ${_sign(activation.activatedSign)} • '
                'జన్మ ${activation.activatedNatalHouse}వ భావం',
            ...links.map(_conditionText),
            'ఆధార స్కోరు: BCP ${score.bcpPoints}/40 + '
                'జన్మ రూల్ ${score.natalPoints}/30 + '
                'దశ ${score.dashaPoints}/15 + '
                'గోచారం ${score.transitPoints}/15 = ${score.percent}/100',
          ].join('\n')),
          const Divider(height: 12),
          _line(dateLabel,
              '${_date(dateWindow.start)} నుంచి '
              '${_date(dateWindow.end.subtract(const Duration(days: 1)))} వరకు'),
        ],
      ),
    );
  }

  Widget _degreePoints(BcpActivation activation) {
    final triggers = BcpEngine.degreeTriggers(chart: _natal, activation: activation);
    return Card(
      child: ExpansionTile(
        title: const Text('డిగ్రీ ఆధారిత కాలబిందువులు',
            style: TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${triggers.length} అంచనా బిందువులు • BCP-EXT-002'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 2, 12, 14),
        children: [
          for (final t in triggers)
            ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${_planet(t.label)} • ${t.intraSignDegrees.toStringAsFixed(2)}°'),
              trailing: Text(_date(t.tentativeDate),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(t.reasons.join(', '), style: const TextStyle(fontSize: 11)),
            ),
          const Text('ఇవి జన్మదినం నుంచి డిగ్రీ నిష్పత్తిలో లెక్కించిన సూచన తేదీలు మాత్రమే.',
              style: TextStyle(fontSize: 12, color: Color(0xFF715C7C))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final year = BcpEngine.runningYear(widget.birthData.localDateTime, _targetDate);
    final cycleStart = ((year - 1) ~/ 12) * 12 + 1;
    final md = DashaService.periodAt(_vimshottari.mahadashas, _targetDate);
    final selected = _reference == BcpReference.mahadashaLord && md == null
        ? <BcpActivation>[]
        : BcpEngine.activations(
            chart: _natal,
            birthDate: widget.birthData.localDateTime,
            onDate: _targetDate,
            references: {_reference},
            activeMahadashaLord: md?.lord,
          );
    final activation = selected.isEmpty ? null : selected.single;
    final connected = <({BcpEventDefinition event, List<String> links, BcpEvidenceScore score})>[];
    if (activation != null) {
      for (final event in eventDefinitions) {
        final links = BcpEngine.eventLinks(_natal, activation, event);
        if (links.isEmpty) continue;
        final score = BcpEngine.scoreEvent(
          activation: activation,
          matchedLinks: links,
          evidence: widget.verifiedEventEvidence[event.kind] ?? const BcpEventEvidence(),
        );
        connected.add((event: event, links: links, score: score));
      }
      connected.sort((a, b) {
        final verifiedOrder = (b.score.hasVerifiedNatalRule ? 1 : 0)
            .compareTo(a.score.hasVerifiedNatalRule ? 1 : 0);
        if (verifiedOrder != 0) return verifiedOrder;
        final scoreOrder = b.score.percent.compareTo(a.score.percent);
        return scoreOrder != 0 ? scoreOrder : a.event.ruleId.compareTo(b.event.ruleId);
      });
    }
    final dateWindow = activation?.yearWindow;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Card(
          color: const Color(0xFFF1EBFC),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('BCP — భృగు చక్ర పద్ధతి',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: _accent)),
                const SizedBox(height: 6),
                const Text('12 సంవత్సరాల భావ చక్రం • Running Year ఆధారంగా గణన',
                    style: TextStyle(fontSize: 12)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.remove_circle_outline),
                      onPressed: year > 1 ? () => _chooseYear(year - 1) : null,
                      tooltip: 'మునుపటి సంవత్సరం',
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Text('$year వ జీవిత సంవత్సరం', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                          Text('పూర్తయిన వయస్సు: ${year - 1}', style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add_circle_outline),
                      onPressed: year < 120 ? () => _chooseYear(year + 1) : null,
                      tooltip: 'తదుపరి సంవత్సరం',
                    ),
                  ],
                ),
                Align(
                  alignment: Alignment.center,
                  child: TextButton.icon(
                    onPressed: _chooseDate,
                    icon: const Icon(Icons.calendar_month),
                    label: Text('పరిశీలన తేదీ: ${_date(_targetDate)}'),
                  ),
                ),
                const Divider(),
                Text('12 ఏళ్ల చక్రం • ${cycleStart}–${cycleStart + 11}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    for (int i = cycleStart; i < cycleStart + 12 && i <= 120; i++)
                      ChoiceChip(
                        label: Text('$i'),
                        selected: i == year,
                        onSelected: (_) => _chooseYear(i),
                        selectedColor: const Color(0xFFD9C5FC),
                        labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                        visualDensity: VisualDensity.compact,
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text('BCP గణన ఆధారం', style: TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 6),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final reference in BcpReference.values)
              ChoiceChip(
                label: Text(_referenceLabel(reference), style: const TextStyle(fontSize: 12)),
                selected: _reference == reference,
                selectedColor: const Color(0xFFDCCAF9),
                onSelected: (_) => setState(() => _reference = reference),
              ),
          ],
        ),
        if (activation == null) ...[
          const SizedBox(height: 10),
          const Card(child: Padding(
            padding: EdgeInsets.all(12),
            child: Text('ఎంపిక చేసిన తేదీకి ఈ ఆధారం అందుబాటులో లేదు. చక్రాధిపతి పద్ధతి 108వ సంవత్సరం వరకు; మహాదశాధిపతి కోసం దశా గణన అవసరం.'),
          )),
        ] else ...[
          const SizedBox(height: 10),
          Card(
            color: const Color(0xFFE8F5EF),
            surfaceTintColor: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${activation.activatedHouseFromReference}వ చక్ర భావం → ${_sign(activation.activatedSign)}',
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: Color(0xFF177548))),
                  const SizedBox(height: 4),
                  Text('జన్మ లగ్నం నుంచి ${activation.activatedNatalHouse}వ భావం • ${activation.methodRuleId}'),
                  if (_reference == BcpReference.mahadashaLord && md != null)
                    Text('ఈ తేదీకి మహాదశ: ${_planet(md.lord)}'),
                  if (_reference == BcpReference.cycleRuler && activation.referencePlanet != null)
                    Text('ఈ చక్రాధిపతి: ${_planet(activation.referencePlanet!)}'),
                  if (dateWindow != null)
                    Text('కాలం: ${_date(dateWindow.start)} నుంచి ${_date(dateWindow.end.subtract(const Duration(days: 1)))} వరకు',
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
          _natalChart(activation),
          const SizedBox(height: 10),
          Text('ఈ కాలంలోని భావ–గ్రహ సంబంధాలు (${connected.length})',
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 5),
            child: Text('Rule Evidence % = జాతక ఆధారాల బలం. ఇది సంఘటన జరిగే అసలు సంభావ్యత కాదు. '
                'స్వతంత్ర జన్మ రూల్ ధృవీకరణ లేకపోతే ఫలితం “సంబంధ సూచన మాత్రమే”.',
                style: TextStyle(fontSize: 11, color: Color(0xFF625B65))),
          ),
          const SizedBox(height: 6),
          for (final item in connected)
            _eventTile(activation, item.event, item.links, item.score),
          if (connected.isEmpty)
            const Text('ఈ విధానానికి సంబంధిత అంశ మ్యాచింగ్ లేదు.'),
          const SizedBox(height: 10),
          _degreePoints(activation),
        ],
      ],
    );
  }
}
