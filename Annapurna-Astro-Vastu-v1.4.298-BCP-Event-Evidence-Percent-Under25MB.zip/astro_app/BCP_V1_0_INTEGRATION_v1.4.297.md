# BCP v1.0 Integration into Annapurna Astro Vastu v1.4.297

## Imported files
- lib/astrology/bcp_master_engine.dart (unaltered uploaded core)
- lib/astrology/bcp_app_adapter.dart (Swiss D1 chart adapter)
- lib/screens/bcp_master_panel.dart (live BCP UI)
- assets/bcp/bcp_rule_catalog.json (47 source/app-rule ledger items)
- test/bcp_master_engine_test.dart (uploaded test adapted for flutter_test)
- test/bcp_app_adapter_test.dart (Swiss-lagna and longitude map checks)

## Connected
- Existing ChartScreen menu BCP route -> BcpMasterPanel(chart, birthData).
- BirthData local birthday and actual Swiss D1 natal longitudes used.
- On-date Maha Dasha lord supplied from existing Vimshottari service.
- Pick year, local day, reference mode; 12-year cycle activated sign/house.
- All 26 editorial event-domain links evaluated with real natal grahas.
- Details: Rule -> Inspection -> Result; tentative degree dates in accordion.
- South-Indian-style compact D1 sign grid shows lagna and degrees.
- Earlier main-panel BCP placeholder replaced with active module overview.

## Important bounds
- This BCP v1.0 library DOES NOT itself compute independently verified natal promises,
  natal source/page IF matches, or transits. Without this source evidence it does not
  assert event occurrence or exact dates; UI shows only verified calculated house/graha
  LINKS for the 26 app-defined topic mappings.
- Dasha lord reference is at the selected inspection date; if it changes mid-year,
  select a different date to inspect the other MD reference.
- Feb-29 birthday follows supplied core's March-1 rule in nonleap years.
- Tested with static inspection and zip integrity. Dart/Flutter SDK availability
  determines whether runtime/compilation tests can be executed.
- Western fresh-clean module, BNN, BSP, D10, KP untouched.
