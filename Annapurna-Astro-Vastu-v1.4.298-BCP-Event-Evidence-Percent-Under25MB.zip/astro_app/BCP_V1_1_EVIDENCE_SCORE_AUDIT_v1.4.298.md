# BCP v1.1 — Event-specific Rule Evidence % audit

- Starting source: Annapurna Astro Vastu v1.4.297 BCP integration.
- UI order: Result → applied IF–THEN → natal inspection → active BCP year window.
- **Score is NOT event probability.** It is a transparent 0–100 evidence index; weights are application-defined, and there is no empirical calibration.
- BCP links contribute **at most 40/100** (direct natal house 14, lord in active sign 10, lord aspect 6, karaka in active sign 12, karaka aspect 6; unique categories, capped at 40).
- Natal source rule contributes 30 only with *both* natal promise and verified rule and a nonempty rule id. Missing verification = 0.
- Event-specific dasha-window overlap contributes up to 15 and event-specific transit-window overlap up to 15. Neither is inferred merely from the current MD lord or generic transit.
- **Timing candidate** requires natal verification and an actual intersection of the activated BCP year, event-specific dasha window, and event-specific transit window. Otherwise output is year candidate / link-only, not a prediction.
- `BcpMasterPanel.verifiedEventEvidence` defaults to empty. This deliberately marks events as **సంబంధ సూచన మాత్రమే** until source-verified natal rules are wired in by a verified producer.
- Green for verified 70+; pink for low score / blocked; grey for unverified moderate link strengths. Visible score and explanatory caveat on every tile.
- No changes to Western Progression, BNN, BSP, KP, Jaimini.
- Unit regression tests in `test/bcp_rule_evidence_score_test.dart` cover missing verification, capped links, verified timing overlap, nonoverlap, explicitly contradicted rules, and 40-point cap.
- Flutter APK compilation not performed unless SDK is available.
