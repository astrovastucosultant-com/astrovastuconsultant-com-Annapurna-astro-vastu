import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';

BnnMasterRule _rule(String condition, {String status = 'FACTS_REQUIRED',
    String source = 'BNN N'}) => BnnMasterRule(
  id: 'BNNN-P034-R002',
  source: source,
  sourcePage: 34,
  topic: 'వివాహం / సంబంధాలు',
  condition: condition,
  result: 'చిన్నవయస్సులోనే వివాహము.',
  inspection: 'మూలం జాతకంతో ధృవీకరించాలి',
  remedy: 'మూలంలో నిర్ధారించబడలేదు',
  status: status,
);

AstroChartResult _chart(double jupiter, double venus) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 24,
  ascendantLongitude: 17,
  planets: [
    PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: jupiter,
        latitude: 0, speed: 0.1),
    PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: venus,
        latitude: 0, speed: 0.1),
  ],
  engineVersion: 'test',
);

void main() {
  test('Same-sign facts lead to a tentative natal placement only', () {
    final evidence = BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 47));
    expect(evidence, isNotNull);
    expect(evidence!.placement, contains('ప్రారంభ పరిశీలన మాత్రమే'));
  });

  test('Different signs do not produce a placement hit', () {
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు'), _chart(42, 75)), isNull);
  });

  test('Unverified OCR rules can never be auto-matched', () {
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు', status: 'OCR_REVIEW',
            source: 'Brighu_Naadi_Purnna_Rulebook.pdf'),
        _chart(42, 47)), isNull);
  });

  test('Ambiguous multi-part and REVIEW rules cannot auto-match', () {
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('గురు దృష్టి ఉంటే'), _chart(42, 47)), isNull);
    expect(BnnMasterAnalysis.tentativeNatalPlacement(
        _rule('శుక్రుడు—గురుడు', status: 'REVIEW'),
        _chart(42, 47)), isNull);
  });

  test('Period topics are age-band study markers, not events', () {
    final history = BnnMasterAnalysis.jupiterStudyBands(0, 25);
    expect(history.map((x) => x.round).toList(), [1, 2, 3]);
    final future = BnnMasterAnalysis.jupiterStudyBands(35, 43);
    expect(future.map((x) => x.round).toList(), [3, 4]);
    expect(BnnMasterAnalysis.jupiterStudyBands(0, -1), isEmpty);
  });

  test('Age bands honor birth month and day', () {
    expect(BnnMasterAnalysis.completedAge(
        DateTime(2000, 11, 7), DateTime(2026, 10, 26)), 25);
    expect(BnnMasterAnalysis.completedAge(
        DateTime(2000, 11, 7), DateTime(2026, 11, 7)), 26);
  });

  test('BNN first bhava is Jupiter sign, not ascendant sign', () {
    final chart = _chart(42, 47); // ascendant Aries; Jupiter Taurus
    expect(BnnMasterAnalysis.bnnReferenceSignIndex(chart), 1);
    expect(BnnMasterAnalysis.houseOfPlanet(chart.planets[0], chart), 1);
    expect(BnnMasterAnalysis.houseOfPlanet(chart.planets[1], chart), 1);
  });

  test('Marriage topics index to seventh bhava', () {
    final house = BnnMasterAnalysis.housesForRule(_rule('శుక్రుడు—గురుడు'));
    expect(house.contains(7), isTrue);
  });

  test('Only source-eligible natal-chain matches become candidate results', () {
    final rule = _rule('శుక్రుడు—గురుడు');
    expect(BnnMasterAnalysis.tentativeHouseMatch(rule, _chart(42, 47), 7),
        isNotNull);
    expect(BnnMasterAnalysis.tentativeHouseMatch(rule, _chart(42, 75), 7),
        isNull);
    expect(BnnMasterAnalysis.tentativeHouseMatch(
      _rule('శుక్రుడు—గురుడు', status: 'OCR_REVIEW'), _chart(42, 47), 7),
        isNull);
    expect(BnnMasterAnalysis.tentativeHouseMatch(
      _rule('శుక్రుడు—గురుడు', status: 'REVIEW'), _chart(42, 47), 7),
        isNull);
  });

  test('The source index accepts all twelve bhavas', () {
    for (var i = 1; i <= 12; i++) {
      expect(BnnMasterAnalysis.houseLabel(i), contains('$i'));
      expect(BnnMasterAnalysis.houseTheme(i).isNotEmpty, isTrue);
    }
  });

}
