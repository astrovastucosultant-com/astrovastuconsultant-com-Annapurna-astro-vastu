# Jamakkol calculation comparison v1.4.244

## Independent calculations added
- `tamilSolarMonthDayUdhayam`: daylit solar-half, with Tamil ordinal day N and exact solar month length M. Fraction of opening sign already traversed = (N - 1)/M, and daytime progression = elapsed / (daylight/12). This is **not** the same as the astronomical sunrise-longitude Udhayam; production chart continues using the existing model until validated.
- `kavippuAbsoluteSphutaCandidate`: longitude (U+V-A) mod 360 with three-Sun-Veedhi mapping, as supplied by the user. Shows the candidate in the detailed planetary list and comparison text. **Does not silently substitute into pink KAV or rule verdicts**.
- Source comparison `kavippuFromVeedhiAnchor`: sign transfer plus 30°−Arudam-within-sign degree; its exact longitude can differ from U+V−A.

## Test 06 Aug 2018 / Aadi 21
- Sunrise 05:49, sunset 18:37 => day length 768 min. One sign 64 min, Jamam 96 min.
- Actual Aadi 2018 had 31 days; calendar ordinal is 21, so elapsed days = 20, not 21. Opening Cancer sign progress = 20/31.
- Question 11:20 => 331 min since sunrise. Udayam = 264.5110887° = Sagittarius 24°30′40″ (Tamil solar-day comparison method); Arudam = Leo 0° for clock minute 20; Sun Cancer => Veedhi Aries 0°; candidate Kavippu = 144.5110887° = Leo 24°30′40″.
- Earlier 64/30 *21 calculation yields Sagittarius 26°09′22.5″, a different *approximation* despite the same sign.

## Validation and limitations
- Aadi 21 on 06 Aug 2018: Tamil calendar source (https://calendar.goldenchennai.com/tamil-months/aadi-masam-2018/).
- For the (Tamil day − 1)/total days approach, see https://hindupanchangam.in/en/tools/jamakol-prasannam/.
- Clock Arudam 5-minute mapping see https://medium.com/@balaji.natarajan.7/jamakkol-prasannam-03-arudam-%C4%81r%C5%AB%E1%B9%ADam-simple-mathematical-method-with-powerful-predictive-2c84cdf13372
- Full Flutter build NOT run here; local Dart SDK not present. Tests included but NOT executed in Dart runtime.
