import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/d24_education_break_engine.dart';

const chart=AstroChartResult(
  julianDay:2451545,ayanamsaDegrees:23,
  ascendantLongitude:0.5,engineVersion:'D24-education-break-regression',
  planets:[
    PlanetPosition(name:'Sun',shortName:'Su',longitude:27.5,latitude:0,speed:1),
    PlanetPosition(name:'Moon',shortName:'Mo',longitude:30.1,latitude:0,speed:1),
    PlanetPosition(name:'Mars',shortName:'Ma',longitude:2.5,latitude:0,speed:1),
    PlanetPosition(name:'Mercury',shortName:'Me',longitude:6.2,latitude:0,speed:1),
    PlanetPosition(name:'Jupiter',shortName:'Ju',longitude:9.9,latitude:0,speed:1),
    PlanetPosition(name:'Venus',shortName:'Ve',longitude:31.3,latitude:0,speed:1),
    PlanetPosition(name:'Saturn',shortName:'Sa',longitude:38.9,latitude:0,speed:1),
    PlanetPosition(name:'Rahu',shortName:'Ra',longitude:65.1,latitude:0,speed:-1),
    PlanetPosition(name:'Ketu',shortName:'Ke',longitude:245.1,latitude:0,speed:-1),
  ],
);

void main(){
  final birth=DateTime(2000,1,1,12);
  test('specific D24 education-interruption rule is separately audited',(){
    final result=D24EducationBreakEngine.evaluate(chart,birthDateTime:birth,at:DateTime(2017,6,15));
    expect(result.primary.any((e)=>e.id=='SOURCE-D24-CORE-05'),true);
    final direct=result.primary.firstWhere((e)=>e.id=='SOURCE-D24-CORE-05');
    expect(direct.source,contains('D24-VIDYA-CORE-05'));
    expect(result.primary.where((e)=>e.id.startsWith('D1-EDU-')).length,3);
    expect(result.primary.where((e)=>e.id.startsWith('D24-EDU-')).length,3);
  });
  test('eight distinct possible causes require evidence in D1 and D24',(){
    final result=D24EducationBreakEngine.evaluate(chart,birthDateTime:birth,at:DateTime(2020,2,2));
    expect(result.causes.length,8);
    expect(result.causes.map((e)=>e.id).toSet().length,8);
    expect(result.causes.map((e)=>e.id),containsAll(['FATHER','MOTHER','LOVE','FINANCE','STUDY','HEALTH','MOVE','WORK']));
    for(final cause in result.causes){
      if(cause.supported){
        expect(cause.multiLayer,true);
        expect(cause.hits,greaterThanOrEqualTo(2));
      }
      expect(cause.caveat,isNotEmpty);
      for(final evidence in cause.evidence){
        expect(evidence.source,contains('వ్యాఖ్యాన'));
      }
    }
  });
  test('break verdict never calls school dropout or family culprit certain',(){
    final r=D24EducationBreakEngine.evaluate(chart,birthDateTime:birth,at:DateTime(2024,1,1));
    expect(r.mainVerdict.contains('ఖాయం'),false);
    expect(r.mainVerdict.contains('తప్పకుండా'),false);
    expect(r.recoveryVerdict.contains('ఖాయం'),false);
    expect(r.timingNotes.isNotEmpty,true);
    expect(r.recovery.length,5);
  });
  test('different event dates recalculate Vimshottari timing without changing natal evidence',(){
    final a=D24EducationBreakEngine.evaluate(chart,birthDateTime:birth,at:DateTime(2012,6,15));
    final b=D24EducationBreakEngine.evaluate(chart,birthDateTime:birth,at:DateTime(2026,6,15));
    expect(a.at.year,2012);
    expect(b.at.year,2026);
    expect(a.primary.map((e)=>e.matched).toList(),b.primary.map((e)=>e.matched).toList());
  });
}
