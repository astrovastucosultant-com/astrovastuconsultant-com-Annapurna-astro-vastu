import 'astro_models.dart';
import 'dasha_service.dart';
import 'varga_service.dart';

/// D24 education interruption / return-to-study evidence (interpretive rules).
/// A chart pattern is NOT proof of a historical interruption or of its social
/// cause. The supplied D24 document page 4 directly supports only the narrower
/// 'D1 4th/5th lords in D24 6/8/12 with malefics' interruption condition.
/// Other cause patterns are transparently tagged as derived interpretations.
class D24BreakEvidence {
  final String id;
  final String title;
  final String explanation;
  final bool? matched;
  final String source;
  /// Prevent two house roles sharing one lord from being double-counted.
  final String groupKey;
  const D24BreakEvidence(this.id,this.title,this.explanation,this.matched,this.source,{this.groupKey=''});

  String get status => matched == null ? 'పరీక్ష మిగిలింది' :
    matched! ? 'ఆధారం ఉంది' : 'ఆధారం కనిపించలేదు';
}

class D24BreakCause {
  final String id;
  final String name;
  final String caveat;
  final List<D24BreakEvidence> evidence;
  const D24BreakCause(this.id,this.name,this.caveat,this.evidence);
  int get hits => evidence.where((e)=>e.matched==true).length;
  bool get multiLayer => evidence.any((e)=>e.id.startsWith('D1-') && e.matched==true) &&
      evidence.any((e)=>e.id.startsWith('D24-') && e.matched==true);
  bool get supported => multiLayer && hits>=2;
  String get verdict => supported ? 'రెండు చక్రాల్లో కారణసంబంధ సూచనలు' :
      hits > 0 ? 'కొన్ని సూచనలు · కారణం నిర్ధారణ కాలేదు' : 'ప్రత్యక్ష కారణసంబంధ మద్దతు లేదు';
}


/// A dasha-only window, NOT a verified dropout/passing date. Transits and
/// actual educational history must be reviewed before labeling an event.
class D24EducationDashaWindow {
  final DateTime start;
  final DateTime end;
  final String maha;
  final String antar;
  final String type;
  const D24EducationDashaWindow(this.start,this.end,this.maha,this.antar,this.type);
}

class D24EducationBreakReport {
  final List<D24BreakEvidence> primary;
  final List<D24BreakEvidence> recovery;
  final List<D24BreakCause> causes;
  final String mahaLord;
  final String antarLord;
  final DateTime at;
  final bool timingStress;
  final bool timingRecovery;
  final List<String> timingNotes;
  final bool uncertainTime;
  final List<D24EducationDashaWindow> candidateWindows;
  const D24EducationBreakReport({
    required this.primary, required this.recovery, required this.causes,
    required this.mahaLord, required this.antarLord, required this.at,
    required this.timingStress, required this.timingRecovery,
    required this.timingNotes, required this.uncertainTime,
    required this.candidateWindows,
  });
  int get d1Count => primary.where((e)=>e.id.startsWith('D1-') && e.matched==true)
      .map((e)=>e.groupKey.isEmpty?e.id:e.groupKey).toSet().length;
  int get d24Count => primary.where((e)=>e.id.startsWith('D24-') && e.matched==true)
      .map((e)=>e.groupKey.isEmpty?e.id:e.groupKey).toSet().length;
  bool get crossConfirmed => d1Count>0 && d24Count>0;
  bool get strongSourceRule => primary.any((e)=>e.id=='SOURCE-D24-CORE-05' && e.matched==true);
  bool get breakPattern => crossConfirmed && (strongSourceRule || d24Count>=2) && (d1Count+d24Count+(strongSourceRule?1:0)>=3);
  String get mainVerdict {
    if (breakPattern && timingStress) return 'విద్యలో తీవ్రమైన ఆటంకం/విరామానికి బలమైన జ్యోతిష సూచనలు';
    if (breakPattern) return 'విద్యా విరామానికి బహుళ చక్రాల మద్దతు · కాలనిర్ధారణ మిగిలింది';
    if (crossConfirmed) return 'విద్యలో ఆటంక సూచనలు · పూర్తి విరామ యోగం నిర్ధారణ కాదు';
    return 'విద్య మధ్యలో ఆగిపోతుందని చెప్పడానికి తగిన ఆధారాలు లేవు';
  }
  String get recoveryVerdict {
    final hits=recovery.where((e)=>e.matched==true).length;
    if (hits>=2 && timingRecovery) return 'చదువు తిరిగి కొనసాగడానికి పునరుద్ధరణ ఆధారాలు, దశమద్దతు ఉన్నాయి';
    if (hits>=2) return 'చదువు తిరిగి కొనసాగే అవకాశానికి జాతక ఆధారాలు ఉన్నాయి';
    return 'పునఃప్రారంభం నిర్ధారణకు మరిన్ని ఆధారాలు అవసరం';
  }
}

class D24EducationBreakEngine {
  static const String docSource='విద్యా జ్యోతిష నియమాలు – D24.docx, పేజీ 4, 2.2, ఆటంకం (D24-VIDYA-CORE-05)';
  static const String interpretive='D1/D24 భావకారకత్వాల ఆధారంగా ఈ యాప్ కోసం రూపొందించిన వ్యాఖ్యాన నియమం; ప్రత్యేక శ్లోక ఆధారం నిర్ధారించలేదు';
  static const String timingSource='వింశోత్తరి మహాదశ–అంతర్దశ కాలసరిపోలిక; సంఘటనకు స్వతంత్ర సాక్ష్యం కాదు';
  static const _rulers=<String>['Mars','Venus','Mercury','Moon','Sun','Mercury','Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'];
  static const _exaltation=<String,int>{'Sun':0,'Moon':1,'Mars':9,'Mercury':5,'Jupiter':3,'Venus':11,'Saturn':6};
  static const _hard=<String>['Mars','Saturn','Rahu','Ketu'];

  static D24EducationBreakReport evaluate(AstroChartResult chart,{
    required DateTime birthDateTime,required DateTime at,
  }) {
    final d1=_ChartHouses(chart.ascendantSignIndex, {
      for(final p in chart.planets) p.name:p.signIndex,
    });
    final varga=VargaService.calculate(chart,24);
    final d24=_ChartHouses(varga.ascendantSignIndex, {
      for(final p in varga.planets) p.name:p.signIndex,
    });
    final primary=<D24BreakEvidence>[];
    for (final h in [4,5,9]) {
      final lord=d1.lord(h);
      primary.add(D24BreakEvidence('D1-EDU-$h',
        'D1 $hవ విద్యాభావాధిపతి బలహీన సంబంధం',
        '${_tel(lord)}: D1 ${d1.house(lord)??'-'}వ భావం; 6/8/12 స్థానం లేదా పాపగ్రహ కలయిక పరిశీలన.',
        d1.stressed(lord), interpretive,groupKey:'D1:$lord'));
    }
    for (final h in [4,5,9]) {
      final lord=d24.lord(h);
      primary.add(D24BreakEvidence('D24-EDU-$h',
        'D24 $hవ విద్యాభావాధిపతి బలహీన సంబంధం',
        '${_tel(lord)}: D24 ${d24.house(lord)??'-'}వ భావం; 6/8/12 స్థానం లేదా పాపగ్రహ కలయిక పరిశీలన.',
        d24.stressed(lord), interpretive,groupKey:'D24:$lord'));
    }
    final sourceHits=<String>[];
    for (final h in [4,5]) {
      final lord=d1.lord(h);
      if (d24.isDusthana(lord) && d24.withMalefic(lord)) sourceHits.add('$hవ D1 అధిపతి ${_tel(lord)} D24 ${d24.house(lord)}వ భావంలో పాపగ్రహంతో');
    }
    primary.add(D24BreakEvidence('SOURCE-D24-CORE-05',
      'మూల D24-VIDYA-CORE-05: D1 విద్యాధిపతి D24లో 6/8/12 + పాపయుతి',
      sourceHits.isEmpty?'4వ/5వ D1 అధిపతులకు ఈ పూర్తి యుక్త షరతు కనిపించలేదు.':sourceHits.join('; '),
      sourceHits.isNotEmpty,docSource));
    primary.add(D24BreakEvidence('D1-MERCURY',
      'D1 బుధుడి విద్యా అవరోధ సంబంధం',
      'బుధుడు D1 ${d1.house('Mercury')??'-'}వ భావం; అభ్యాస కారకత్వానికి పాప సంబంధం.',
      d1.stressed('Mercury'),interpretive,groupKey:'D1:Mercury'));
    primary.add(D24BreakEvidence('D24-MERCURY',
      'D24 బుధుడి విద్యా అవరోధ సంబంధం',
      'బుధుడు D24 ${d24.house('Mercury')??'-'}వ భావం; పూర్తిస్థాయి బుద్ధిబలం పరీక్ష కాదు.',
      d24.stressed('Mercury'),interpretive,groupKey:'D24:Mercury'));

    D24BreakEvidence causeCheck(String id,String title,String desc,bool match) =>
      D24BreakEvidence(id,title,desc,match,interpretive);
    D24BreakCause cause(String id,String title,String caveat,List<D24BreakEvidence> checks) =>
      D24BreakCause(id,title,caveat,checks);
    final causes=<D24BreakCause>[
      cause('FATHER','తండ్రి సంబంధిత కుటుంబ పరిస్థితులు',
        '9వ భావం/సూర్య సంబంధం వల్ల తండ్రి కారణమని నిర్ధారించరాదు; వాస్తవ కుటుంబ పరిస్థితులతోనే పరిశీలించాలి.',[
        causeCheck('D1-FATHER','D1 9వ భావాధిపతి–విద్యాభావ సంబంధం',
          '9వ అధిపతి విద్యా 4/5 అధిపతితో సంబంధించి ఆటంక సూచన.',d1.stressed(d1.lord(9)) && d1.linkToEdu(d1.lord(9))),
        causeCheck('D24-FATHER','D24 9వ భావాధిపతి–విద్యాభావ సంబంధం',
          '9వ అధిపతి 4/5 అధిపతితో సంబంధం, 6/8/12 లేదా పాప సంబంధం.',d24.stressed(d24.lord(9)) && d24.linkToEdu(d24.lord(9))),
        causeCheck('CHECK-FATHER-SUN','సూర్యుడి కుటుంబ కారకత్వం',
          'సూర్యుడు విద్యా అధిపతితో సంబంధం; ఇది స్వతంత్ర కారణ నిర్ధారణ కాదు.',d1.stressed('Sun') && d1.linkToEdu('Sun')),
      ]),
      cause('MOTHER','తల్లి/గృహ పరిస్థితుల వల్ల అంతరాయం',
        '4వ భావం విద్యకూ గృహానికీ కారకం; ఒక్క 4వ భావ దోషం వల్ల తల్లిని కారణంగా చూపరాదు.',[
        causeCheck('D1-MOTHER','D1 చంద్రుడు–విద్యాభావ సంబంధం',
          'చంద్రుడు విద్యా అధిపతితో అనుసంధానమై ఒత్తిడి సూచన ఉండాలి.',d1.stressed('Moon') && d1.linkToEdu('Moon')),
        causeCheck('D24-MOTHER','D24 చంద్రుడు–విద్యాభావ సంబంధం',
          'చంద్రుడు D24లో విద్యా అధిపతితో సంబంధం, ఆటంక స్థితి.',d24.stressed('Moon') && d24.linkToEdu('Moon')),
      ]),
      cause('LOVE','ప్రేమ / సంబంధాల వల్ల చదువుకు విరామం',
        '5వ/7వ భావం లేదా శుక్రుడు మాత్రమే ప్రేమ కారణాన్ని నిర్ధారించవు. సంఘటన రికార్డుతో పోలిక అవసరం.',[
        causeCheck('D1-LOVE','D1 శుక్రుడు–5/7 భావ సంబంధం',
          'శుక్రుడు 5/7 అధిపతి లేదా ఆ అధిపతితో సంబంధం, విద్యా ఆటంకానికి అనుసంధానం.',d1.loveStress()),
        causeCheck('D24-LOVE','D24 శుక్రుడు–5/7 భావ సంబంధం',
          'D24లో 5/7 అధిపతి–శుక్ర సంబంధం విద్యా అవరోధంతో కలిసి ఉండాలి.',d24.loveStress()),
      ]),
      cause('FINANCE','ఆర్థిక ఇబ్బందులు / ఫీజు సమస్యలు',
        'ధనభావ సూచనలు ఆర్థిక పరిస్థితులకు ప్రత్యక్ష రుజువు కావు.',[
        causeCheck('D1-FINANCE','D1 2/11వ ధనాధిపతుల ఒత్తిడి',
          '2/11 అధిపతులు 6/8/12 లేదా పాపగ్రహ సంబంధం; విద్యాభావ సంబంధం.',d1.moneyStress()),
        causeCheck('D24-FINANCE','D24 2/11వ భావాల విద్యా సంబంధం',
          'D24లో 2/11 అధిపతుల ఒత్తిడి, విద్యా 4/5 అధిపతితో సంబంధం.',d24.moneyStress()),
      ]),
      cause('STUDY','అభ్యాసం / పరీక్షలలో పునరావృత ఇబ్బంది',
        'ఇది విద్యార్థి సామర్థ్యంపై తీర్పు కాదు. అధ్యయన పద్ధతి, సహాయం, వాస్తవ మార్కులతో పోల్చాలి.',[
        causeCheck('D1-STUDY','D1 బుధుడు–5వ విద్యాభావ ఒత్తిడి',
          'బుధుడు లేదా 5వ అధిపతికి ఆటంక స్థితి, పరస్పర సంబంధం.',d1.stressed('Mercury') && d1.linkToEdu('Mercury')),
        causeCheck('D24-STUDY','D24 బుధుడు–గురు విద్యా ఒత్తిడి',
          'బుధుడు/గురు మరియు 4/5 అధిపతికి సంబంధిత అవరోధాలు.',d24.stressed('Mercury') && (d24.linkToEdu('Mercury')||d24.stressed('Jupiter'))),
      ]),
      cause('HEALTH','ఆరోగ్యం / మానసిక ఒత్తిడి కారణంగా అంతరాయం',
        '6/8/12 జ్యోతిష సంబంధం ఆరోగ్య నిర్ధారణ కాదు. వ్యక్తి వివరాలు, వైద్య సమాచారం వేరుగా అవసరం.',[
        causeCheck('D1-HEALTH','D1 6/8వ భావం–విద్య సంబంధం',
          '6/8 అధిపతుల్లో ఎవరికైనా విద్యా అధిపతితో ప్రత్యక్ష సంబంధం.',d1.healthEduLink()),
        causeCheck('D24-HEALTH','D24 6/8వ భావం–విద్య సంబంధం',
          'D24లో 6/8 మరియు 4/5 విద్యాధిపతుల సంబంధం.',d24.healthEduLink()),
      ]),
      cause('MOVE','ఇల్లు మారడం / దూరప్రయాణం / పాఠశాల మార్పు',
        '3/12 భావ సంబంధం నిజంగా చోటు మారిందనే ధృవీకరణ కాదు.',[
        causeCheck('D1-MOVE','D1 3/12వ అధిపతి విద్యతో సంబంధం',
          '3/12 అధిపతి విద్యా 4/5 అధిపతితో సంబంధించి ఒత్తిడి.',d1.travelEduLink()),
        causeCheck('D24-MOVE','D24 3/12వ అధిపతి విద్యతో సంబంధం',
          'D24లో 3/12 అధిపతి విద్యాభావ సంబంధం మరియు ఒత్తిడి.',d24.travelEduLink()),
      ]),
      cause('WORK','ఉద్యోగం / కుటుంబ బాధ్యతల ఒత్తిడి',
        '10వ భావం ఆధారంతో చదువు ఆగిందని నిర్ధారించరాదు.',[
        causeCheck('D1-WORK','D1 10వ భావాధిపతి–విద్య సంబంధం',
          '10వ అధిపతి 4/5 విద్యాధిపతితో సంబంధించి ఒత్తిడి.',d1.stressed(d1.lord(10)) && d1.linkToEdu(d1.lord(10))),
        causeCheck('D24-WORK','D24 10వ భావాధిపతి–విద్య సంబంధం',
          'D24లో 10వ అధిపతి విద్యాభావ సంబంధం, ఒత్తిడి.',d24.stressed(d24.lord(10)) && d24.linkToEdu(d24.lord(10))),
      ]),
    ];

    final recovery=<D24BreakEvidence>[];
    for (final h in [4,5,9]) {
      final lord=d24.lord(h);
      recovery.add(D24BreakEvidence('D24-RECOVERY-$h',
        'D24 $hవ విద్యాధిపతి పునరుద్ధరణ మద్దతు',
        '${_tel(lord)} D24 ${d24.house(lord)??'-'}వ భావం; స్వ/ఉచ్చ లేదా కేంద్ర/త్రికోణంలో శుభ సంబంధ సూచన.',
        d24.supportive(lord),interpretive));
    }
    recovery.add(D24BreakEvidence('D1-RECOVERY-5',
      'D1 విద్యా 5వ అధిపతి మద్దతు',
      'D1 5వ అధిపతి స్వ/ఉచ్చ లేదా అనుకూల స్థానం.',
      d1.supportive(d1.lord(5)),interpretive));
    recovery.add(D24BreakEvidence('D24-JUPITER','D24 గురువు విద్యా సహకారం',
      'గురువు అనుకూల D24 స్థానం/బలం; పూర్తి షడ్బల సూచన కాదు.',
      d24.supportive('Jupiter'),interpretive));

    final times=<String>[];
    final windows=<D24EducationDashaWindow>[];
    String mdName='తెలియదు', adName='తెలియదు';
    bool stress=false,recover=false;
    try {
      final vim=DashaService.vimshottari(chart:chart,birthDateTime:birthDateTime);
      final md=DashaService.periodAt(vim.mahadashas,at);
      final ad=md==null ? null : DashaService.periodAt(DashaService.subPeriods(md),at);
      if (md!=null) mdName=md.lord;
      if (ad!=null) adName=ad.lord;
      final stressLords=<String>{d1.lord(4),d1.lord(5),d24.lord(4),d24.lord(5)};
      final favorable=<String>{d1.lord(4),d1.lord(5),d1.lord(9),d24.lord(4),d24.lord(5),d24.lord(9),'Mercury','Jupiter'};
      bool adverseLord(String lord) => (stressLords.contains(lord) && (d1.stressed(lord)||d24.stressed(lord)));
      bool favorableLord(String lord) => favorable.contains(lord) &&
          (d1.supportive(lord)||d24.supportive(lord));
      stress=(md!=null && adverseLord(md.lord)) || (ad!=null && adverseLord(ad.lord));
      recover=(md!=null && favorableLord(md.lord)) || (ad!=null && favorableLord(ad.lord));
      times.add('తేదీ ${at.day}-${at.month}-${at.year}: ${_tel(mdName)} మహాదశ · ${_tel(adName)} అంతర్దశ.');
      times.add(stress?'విద్యా అవరోధ భావాధిపతితో దశా సంబంధం కనిపించింది.':'ఈ తేదీ దశలో ప్రత్యేక విద్యా అవరోధ అధిపతి మద్దతు కనిపించలేదు.');
      times.add(recover?'విద్యా పునరుద్ధరణ కారక దశమద్దతు కూడా కనిపించింది.':'ఈ తేదీకి అదనపు పునరుద్ధరణ దశమద్దతు గుర్తించలేదు.');
      if (md==null||ad==null) times.add('ఈ తేదీకి పూర్తిస్థాయి మహాదశ–అంతర్దశ పరిధి లభించలేదు.');
      // Candidate windows at conventional school / higher education ages.
      // These are explicitly limited to Vimshottari timing evidence; not a
      // claim that an interruption occurred or that education must stop.
      final from=DateTime(birthDateTime.year+6,birthDateTime.month,birthDateTime.day);
      final until=DateTime(birthDateTime.year+36,birthDateTime.month,birthDateTime.day);
      for (final maha in vim.mahadashas) {
        if (!maha.end.isAfter(from) || !maha.start.isBefore(until)) continue;
        for (final antar in DashaService.subPeriods(maha)) {
          if (!antar.end.isAfter(from) || !antar.start.isBefore(until)) continue;
          final stressed=adverseLord(maha.lord)||adverseLord(antar.lord);
          final supported=favorableLord(maha.lord)||favorableLord(antar.lord);
          if (!stressed && !supported) continue;
          final a=antar.start.isBefore(from)?from:antar.start;
          final b=antar.end.isAfter(until)?until:antar.end;
          windows.add(D24EducationDashaWindow(a,b,maha.lord,antar.lord,
            stressed&&supported?'మిశ్రమ దశ':stressed?'విద్యా అవరోధ దశమద్దతు':'చదువు పునఃప్రారంభ దశమద్దతు'));
        }
      }
    } catch (_) {times.add('దశ గణనకు చంద్రస్థానం లేదా జనన తేదీ సమాచారం సరిపోలేదు.');}
    times.add('గోచార గురు/శని పూర్తి ధృవీకరణ, వాస్తవ సంఘటన తేదీ పోలిక వేరుగా అవసరం.');
    return D24EducationBreakReport(
      primary:List.unmodifiable(primary),recovery:List.unmodifiable(recovery),
      causes:List.unmodifiable(causes),mahaLord:mdName,antarLord:adName,
      at:at,timingStress:stress,timingRecovery:recover,
      timingNotes:List.unmodifiable(times),uncertainTime:false,
      candidateWindows:List.unmodifiable(windows),
    );
  }
  static String _tel(String lord) => const <String,String>{
    'Sun':'సూర్యుడు','Moon':'చంద్రుడు','Mars':'కుజుడు','Mercury':'బుధుడు',
    'Jupiter':'గురువు','Venus':'శుక్రుడు','Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు',
  }[lord]??lord;
}

class _ChartHouses {
  final int asc;
  final Map<String,int> signs;
  const _ChartHouses(this.asc,this.signs);
  String lord(int house)=>D24EducationBreakEngine._rulers[(asc+house-1)%12];
  int? house(String planet) {final sign=signs[planet];return sign==null?null:((sign-asc+12)%12)+1;}
  bool isDusthana(String planet)=>const [6,8,12].contains(house(planet));
  bool joined(String a,String b)=>signs[a]!=null&&signs[a]==signs[b];
  bool aspects(String a,String b){
    final x=signs[a],y=signs[b]; if(x==null||y==null||!const <String>['Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn'].contains(a))return false;
    final dist=(y-x+12)%12+1;
    return dist==7 || (a=='Mars'&&(dist==4||dist==8)) || (a=='Jupiter'&&(dist==5||dist==9)) || (a=='Saturn'&&(dist==3||dist==10));
  }
  bool related(String a,String b)=>a==b||joined(a,b)||aspects(a,b)||aspects(b,a);
  bool withMalefic(String p)=>D24EducationBreakEngine._hard.any((m)=>m!=p&&joined(p,m));
  bool stressed(String p)=>signs[p]!=null&&(isDusthana(p)||withMalefic(p)||const <String,int>{'Sun':6,'Moon':7,'Mars':3,'Mercury':11,'Jupiter':9,'Venus':5,'Saturn':0}[p]==signs[p]);
  bool strong(String p)=>signs[p]!=null&&(D24EducationBreakEngine._rulers[signs[p]!]==p||D24EducationBreakEngine._exaltation[p]==signs[p]);
  bool supportive(String p)=>signs[p]!=null && !stressed(p) &&
      (strong(p)||const [1,4,5,7,9,10].contains(house(p))) &&
      (aspects('Jupiter',p)||joined('Jupiter',p)||strong(p));
  bool linkToEdu(String p)=>related(p,lord(4))||related(p,lord(5));
  bool loveStress()=>signs['Venus']!=null&&stressed('Venus') &&
      (related('Venus',lord(5))||related('Venus',lord(7))) &&
      (stressed(lord(4))||stressed(lord(5)));
  bool moneyStress()=>[2,11].any((h)=>stressed(lord(h))&&linkToEdu(lord(h)));
  bool healthEduLink()=>[6,8].any((h)=>stressed(lord(h))&&linkToEdu(lord(h)));
  bool travelEduLink()=>[3,12].any((h)=>stressed(lord(h))&&linkToEdu(lord(h)));
}
