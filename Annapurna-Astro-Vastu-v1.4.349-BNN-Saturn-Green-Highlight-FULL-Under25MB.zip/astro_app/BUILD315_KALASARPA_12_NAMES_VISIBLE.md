# Build 315 — Rahu house-axis type and full Kalasarpa yoga separated

- Rahu house 1–12 always maps to the corresponding modern Kalasarpa name when axis/planet data are valid.
- A Rahu house label alone is never reported as full Kalasarpa yoga.
- Full / absent / boundary / insufficient evidence are independently calculated from seven ecliptic longitudes.
- Boundary rule fixed: a boundary planet does not make a split seven-planet distribution ambiguous.
- The report shows Rahu and Ketu houses, the type name, optional 12-name glossary, observed planetary longitudes, and KS-TYPE vs KS full-match rule status.
- Kalasarpa is displayed before BPHS chapter 83; neither source ID nor remedy is falsely assigned to BPHS.
- Added regression tests for every Rahu house and for absent/boundary cases.
- APK compile not performed; this environment has no Flutter/Dart SDK.
