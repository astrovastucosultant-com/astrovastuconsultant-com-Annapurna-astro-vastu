# Annapurna Astro Vastu v1.4.301 — BCP result priority and source-IF audit

## Screenshots reviewed, 2026-11-01

- 10% BCP-only link scores appeared as large, prominent event cards (e.g. education, exams). A 10% rule-evidence index is not a 10% event chance, nor a predicted event.
- D2-PR-001/002/003 sometimes had D4 confirmation absent and D2 partial match scores 75/80, but the BCP natal bridge still elevated the records as complete IFs worth 30/30.
- BNN OCR_REVIEW/FACTS_REQUIRED source matches and D24 subconditions displayed long raw TRUE/FALSE technical inspections despite not being source-verified natal promises.
- 26 domain names are topic mappings; existence of a mapping alone must never produce an event prediction.

## Changes

1. BCP output grouped into **natal-IF-supported BCP links** (primary event review cards) and **BCP associations only** (collapsed by default). All linked topics remain accessible; unmatched topics remain in their own collapsed section.
2. Independent natal source audit collapsed by default; nested topic and partial-source groups make original traceable source conditions accessible without flooding the result screen.
3. Partial source review entries inside event cards are collapsed as well. Raw technical inspections, if any, are explicitly labeled as source data; not shown as verified predictions.
4. D2 matching bridge promotes only uncautioned evaluator matches with match.percent == 100 to verifiedFull; 75/80/90 partial matches stay in supportingOnly and receive 0/30 natal points.
5. The BCP 40 + natal 30 + dasha 15 + transit 15 evidence scoring formula is unchanged. In particular BCP-only links never masquerade as full source IFs. Green indicates corroborated source evidence, pink indicates low evidence (NOT a negative life event).
6. Added regression tests for grouping based on source IF and the D2 partial-to-full promotion gate.

## Unchanged

- BNN, BSP, Jaimini, Western clean tab and other calculation engines.
- Source rulebook strings, source page references and provenance are untouched.
- No source-unverified 462 BNN rules are counted as full natal support.

## Validation

- Zip structure/CRC and source-diff checks were performed.
- Dart/Flutter SDK was not available in this environment, so Flutter build, unit test execution and APK installation are not verified.
- Future work: cross-module event-specific dasha, gochara, and independently validated source IFs for remaining BCP topics.
