# v1.4.310 — D10 Career UI / Ashtakavarga / Exact Transit Source Release

Release scope: complete source project; no APK included. This is an uncompiled source release. Flutter SDK is not installed in the local environment; run GitHub Actions to build and perform on-device QA.

D10 report order:
1. Gocharishta / business strength (favorable and obstacle *rule-evidence* shares).
2. Agocharishta / job strength, same metrics.
3. Stronger career mode and first-versus-later profession, with D1 supporting the first stage and D10 main stage.
4. Separate D1 and D10 natal SAV evidence (337-point audits), job/business profession lists.
5. Government service and high-rank source-rule outcomes.
6. Rising / fall / change timeline, 0-33/33-66/66-99 SAV display buckets, natal PAV, and exact sidereal transit calculations for a user-selected date/time.
7. Supporting yogas and source audit details.

Exact transit mode: Swiss Ephemeris/Moshier and the recorded ayanamsa/timezone, with 7 classical transit planets, 3°45′ kakshya, giver bindu and BAV/SAV evidence. Rahu and Ketu have no separate traditional 7-planet PAV recipient row.

Limitations: UI resembles the proposed order and green/pink emphasis but is not a pixel-perfect implementation of an in-chat mockup. Evidence percentages are neither financial profit/loss nor empirically validated prediction probability. Full source IF audit for every D10 profession rule, all physical UI tests, the Flutter analyzer, tests, and an APK build are **not** verified in this environment.
