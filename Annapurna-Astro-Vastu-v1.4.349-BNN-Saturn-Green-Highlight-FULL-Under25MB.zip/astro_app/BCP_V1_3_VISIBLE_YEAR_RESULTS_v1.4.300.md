# Annapurna Astro Vastu v1.4.300 — BCP visible year results / no-empty-state

## User issue found in v1.4.299

- The BCP panel showed only the event definitions with at least one `BcpEngine.eventLinks` match. All unmatched topics were discarded by `if (links.isEmpty) continue;`, with no explanatory section. Consequently users could see few or no event cards.
- The independent natal-rule gate was intentionally strict: positive complete IFs currently apply chiefly to wealth, property, and vehicle from `Dhana_Aasthi_Rules.pdf`. Many other modules carry only partial source predicates. Hence their `natalPoints=0`, not a prediction, even when the BCP link itself is present.
- The 15-point event-specific dasha and 15-point transit sources are *not connected*. Therefore a 70–100% evidence score and exact event timing must NOT be invented.
- Source-only ZIP v1.4.299 was not present on the GitHub repo's `main` branch at the time of this patch; installation of its changes in an APK cannot be assumed.

## Fixes

1. **Visible result text in collapsed BCP cards**: each matched event shows an event-specific review topic and actual matched house, house-lord or karaka, including graha sign and degree where relevant.
2. **Always-accounted-for 26 topics**: matched cards appear first; unmatched topics are listed under a separate expandable section and explain that no DIRECT BCP link was found for that running year, not that the event is impossible.
3. **Natal rule overview**: all independently computed complete and partial natal-rule matches are available even when the selected BCP year has no link to that event. Verified full source IFs are distinguished from partial/unverified supporting matches.
4. **Failure isolation**: exceptions in source natal-rule evaluation or Vimshottari computation do not hide the primary BCP yearly chart and links; a visible diagnostic indicates which source is unavailable.
5. **Score honesty preserved**: independent natal IF 30 only for qualifying source matches; dasha/transit 15+15 remain zero when absent; the percentage is a rule-evidence index, not a statistical event likelihood.
6. **Regression test added**: `test/bcp_year_result_explainer_test.dart` describes all 26 domains, exact matched-link presentation, unmatched visibility, and the no-false-timing gate.
7. Western Progression remains cleared; other module files unchanged.

## Visible UI

BCP -> choose life year -> choose reference -> D1 chart -> **BCP event results** (each card shows actual computed link) -> tap result to see Source Rule / Inspection / Result -> **Natal rule overview** -> **Unmatched 26-domain checklist** -> degree timing points (tentative only).

## Validation and limits

- Source ZIP structure/integrity can be checked without the Flutter SDK.
- Flutter / Dart test execution and APK compile must be performed with Flutter SDK, e.g. `flutter test test/bcp_year_result_explainer_test.dart` and `flutter build apk --release`.
- This patch is a *visibility and audit fix*, not a fabricated complete 26-event predictive engine. Full predictions require independently verified source IFs plus event-specific dasha and transit windows.
