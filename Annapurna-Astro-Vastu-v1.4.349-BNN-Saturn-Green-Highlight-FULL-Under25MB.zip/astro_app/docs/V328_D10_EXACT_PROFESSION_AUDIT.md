# v1.4.328 — D10 exact-profession match truthfulness

Based on v1.4.327 full Flutter source. Keeps all previous files and all 19 vargas.

## Corrected
- `D10-EXACT-PROF-SUMMARY`: no chart-matched result without fully confirmed exact profession source conditions.
- `D10-EXACT-PROF-LIST`: remains available in the audit drawer when unsupported/partial.
- `D10-PROF-ASTROLOGER` and `D10-PROF-CONSULTANT`: exact IF–THEN must be confirmed for a positive result.
- Individual exact profession rows: half/manual-only support remains audit, not a verified green result.
- Devata/broad career scoring kept as supplemental evidence, not a client-facing final result.
- Saturn mode gets a positive rule match only when Gocharastha/Agocharastha is actually determined.

The existing UI drilldown, source listings, remedial matching and 19 varga charts are preserved.

## Verification
`flutter pub get && flutter analyze && flutter test test/d10_v328_exact_profession_match_test.dart && flutter build apk --release`

This environment does not have Flutter/Dart SDK. Flutter analyze, test and APK must run in GitHub Actions.

## Android size
The prior full release APK is 93.5 MB. The under-25MB requirement currently applies to the source ZIP only; 25 MB APK has not been achieved.
