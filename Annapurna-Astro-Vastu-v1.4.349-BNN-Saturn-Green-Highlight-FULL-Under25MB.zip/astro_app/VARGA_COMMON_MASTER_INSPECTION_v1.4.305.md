# v1.4.305 — Universal Varga House/Lord Basic Inspection

## Scope shipped
- Adds `VargaMasterInspectionPanel` beneath each of the sixteen supported D1..D60 charts. Respects the user's D16 Parashara/Phaladeepika selection.
- Reuses existing VargaService placements and D1-derived PanchadhaMaitriService; no copy of the astrology math and no new synthetic source pages.
- Shows **Varga Lagna**, house and house lord, actual house occupancy, Parashari graha aspects, association/aspects to the house lord, five/nine vs six/eight/twelve functional ownership, and Panchadha relation to sign lord.
- For house 2 tests the user-defined favored positions 2/4/5/9/10/11 and, in D1 and D2, displays 2H/11H/12H separately (earning, gain and retention/expense are not identical).
- Labels Mercury/context-dependent classifications separately; phase-dependent Moon; Rahu/Ketu drishti is not automatically invented. Does not make desire disappear simply because a malefic or dussthana lord is in Lagna.
- Color encodes supportive/challenging/contextual **evidence only**; every shown observation has a `USER-VARGA-*` auditable ID and matching computed placement. No generic fixed prediction.
- Optional *experimental* index: 100 baseline only when a favorable house-lord position exists; distinct planet-support and challenge ±20 from user example, deduplicated per planet/polarity. This is explicitly **not percent, calibrated probability or source-backed strength**; it cannot override a source IF–THEN rule.
- Leaves existing BNN/BCP/KP/D1..D60 source rules, results, and remedy flow untouched.

## Source provenance and limitations
These generic inspection rules come from the user's November 2 instructions, *not a verified book passage*. Never cite a fictitious source page for `USER-VARGA-*`. The previously supplied Dhana_Aasthi_Rules PDF has independent wealth/retention/loss rules and still requires **per-rule** validation: generic observations alone cannot establish income, inheritance, property, or outcomes. Existing VargaUnifiedRuleService retains its own verified/pending statuses, and this layer must not convert them to matched.

The natural benefic/malefic split is a provisional indication, not functional benefic lordship or planetary strength. Extra factors such as combustion, avasthas, exaltation, yogakaraka, cancellations, Bhava Chalit, multiple D2/other varga methods and dasha/transit timing remain for separately sourced modules. Do not claim complete classical strength or a guaranteed prediction.

## Tests/build
Test file `test/varga_master_inspection_service_test.dart` covers all 16 vargas, D2/D24, aspects, ID provenance, method selection, and deduplicated index. Flutter/Dart SDK is not installed in this environment; run `flutter test test/varga_master_inspection_service_test.dart` and `flutter analyze`, then a GitHub Actions Android build before APK release.
