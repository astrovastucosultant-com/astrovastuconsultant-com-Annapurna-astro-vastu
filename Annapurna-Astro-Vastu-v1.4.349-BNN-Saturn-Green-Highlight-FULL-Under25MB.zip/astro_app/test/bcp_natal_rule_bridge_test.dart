import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bcp_master_engine.dart';
import 'package:astro_app/astrology/bcp_natal_rule_bridge.dart';
import 'package:astro_app/astrology/d2_wealth_evaluation_service.dart';

void main() {
  // D1: Aries rising; 2L Venus and 11L Saturn in Taurus, thus matching
  // the user-provided D2-DY-001 D1 धनयोग source IF. Moon in Taurus is
  // only one P12-S10-R01 marriage subcondition.
  const chart = AstroChartResult(
    julianDay: 2451545.0,
    ayanamsaDegrees: 23.8,
    ascendantLongitude: 12,
    engineVersion: 'BCP-natal-bridge-fixture',
    planets: [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 130, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 40, latitude: 0, speed: 13),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 290, latitude: 0, speed: 0.5),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 280, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 260, latitude: 0, speed: 0.2),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 35, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 50, latitude: 0, speed: 0.1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 310, latitude: 0, speed: -0.1),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 130, latitude: 0, speed: -0.1),
    ],
  );

  test('matching complete source D1/D2 dhanayoga is traceable, and worth one 30-point block', () {
    final assessments = BcpNatalRuleBridge.assess(chart);
    final wealth = assessments[BcpEventKind.wealth]!;
    expect(wealth.verified.any((h) => h.id == 'D2-DY-001'), isTrue);
    expect(wealth.evidence.hasVerifiedNatalRule, isTrue);
    expect(wealth.evidence.natalSourceName, 'Dhana_Aasthi_Rules.pdf');
    final activation = BcpEngine.activations(
      chart: NatalChart(ascendantSign: 1, longitudes: {
        for (final p in chart.planets) p.name.toLowerCase(): p.longitude,
      }),
      birthDate: DateTime(2000, 1, 1),
      onDate: DateTime(2000, 1, 1),
    ).single;
    final score = BcpEngine.scoreEvent(
      activation: activation,
      matchedLinks: ['DIRECT_HOUSE: natal house 2'],
      evidence: wealth.evidence,
    );
    expect(score.natalPoints, 30);
    expect(score.percent, 44);
    expect(score.dashaPoints, 0);
    expect(score.transitPoints, 0);
    expect(score.hasTimingConfirmation, isFalse);
  });

  test('a matched PDF marriage subcondition does not become a whole marriage promise', () {
    final marriage = BcpNatalRuleBridge.assess(chart)[BcpEventKind.marriage]!;
    expect(marriage.supportingOnly.any((h) => h.id == 'P12-S10-R01'), isTrue);
    expect(marriage.verified, isEmpty);
    expect(marriage.evidence.hasVerifiedNatalRule, isFalse);
  });

  test('clean reset has no BNN source in BCP natal evidence', () {
    final assessments = BcpNatalRuleBridge.assess(chart);
    for (final assessment in assessments.values) {
      expect(assessment.verified.any((h) => h.id.startsWith('BNN')), isFalse);
      expect(assessment.supportingOnly.any((h) => h.id.startsWith('BNN')), isFalse);
    }
  });

  test('unrelated event without full natal match stays unverified', () {
    final result = BcpNatalRuleBridge.assess(chart);
    expect(result[BcpEventKind.retirement]!.verified, isEmpty);
    expect(result[BcpEventKind.retirement]!.evidence.hasVerifiedNatalRule, isFalse);
  });

  test('partial D2 predicates cannot count as complete natal IF', () {
    final matches = {
      for (final m in D2WealthEvaluationService.evaluate(chart)) m.ruleId: m,
    };
    final assessments = BcpNatalRuleBridge.assess(chart);
    for (final assessment in assessments.values) {
      for (final hit in assessment.verified) {
        final d2 = matches[hit.id];
        if (d2 == null) continue;
        expect(d2.percent, 100,
            reason: 'Partial ${hit.id} must not receive 30 natal points');
        expect(d2.caution, isFalse);
      }
    }
    // Review-only D2 matches are preserved for disclosure.
    for (final match in matches.values.where((m) => m.percent < 100)) {
      expect(assessments.values.any((assessment) =>
          assessment.verified.any((hit) => hit.id == match.ruleId)),
          isFalse,
          reason: '${match.ruleId} partial match was presented as complete IF');
    }
  });
}
