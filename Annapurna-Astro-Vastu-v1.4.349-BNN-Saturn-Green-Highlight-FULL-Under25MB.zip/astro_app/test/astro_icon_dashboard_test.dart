import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import '../lib/screens/astro_icon_dashboard.dart';

void main() {
  testWidgets('color icon dashboard shows functional 3-column entries',
      (tester) async {
    var tapped = 0;
    await tester.pumpWidget(MaterialApp(
      home: Scaffold(
        body: SingleChildScrollView(
          child: SizedBox(
            width: 360,
            child: AstroIconDashboard(title: 'విభాగాలు', items: [
              AstroDashboardItem(
                title: 'పంచాంగం', icon: Icons.calendar_month,
                color: Colors.blue, onTap: () => tapped += 1),
              AstroDashboardItem(
                title: 'D10 వృత్తి', icon: Icons.work_outline,
                color: Colors.green, onTap: () => tapped += 10),
              AstroDashboardItem(
                title: 'అష్టకవర్గం', icon: Icons.grid_view,
                color: Colors.orange, onTap: () => tapped += 100),
            ]),
          ),
        ),
      ),
    ));
    expect(find.text('పంచాంగం'), findsOneWidget);
    expect(find.text('D10 వృత్తి'), findsOneWidget);
    expect(find.text('అష్టకవర్గం'), findsOneWidget);
    await tester.tap(find.text('D10 వృత్తి'));
    expect(tapped, 10);
    expect(tester.takeException(), isNull);
  });
}
