import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/ashtakavarga_service.dart';
import 'package:astro_app/astrology/ashtakavarga_pav_career_service.dart';

void main() {
  const natal = AstroChartResult(
    julianDay: 2460000.5, ayanamsaDegrees: 24,
    ascendantLongitude: 18, engineVersion: 'test',
    planets: [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 10, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 42, latitude: 0, speed: 12),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 75, latitude: 0, speed: 0.5),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 108, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 141, latitude: 0, speed: 0.1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 174, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 207, latitude: 0, speed: -0.1),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 240, latitude: 0, speed: -0.05),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 60, latitude: 0, speed: -0.05),
    ],
  );
  test('PAV donor count equals the same sign BAV and passes 337 audit', () {
    final av=AshtakavargaService.calculate(natal);
    expect(AshtakavargaPavCareerService.audit(av), isTrue);
    for (final p in AshtakavargaService.planetOrder) {
      for (var sign=0;sign<12;sign++) {
        expect(AshtakavargaPavCareerService.giversAt(av,p,sign).length,
            av.bhinna[p]![sign]);
      }
    }
  });
  test('PAV MD/AD output uses D1 tenth and eleventh with no invented timing', () {
    final av=AshtakavargaService.calculate(natal);
    final p=AshtakavargaPavCareerService.periodEvidence(
      chart:natal,av:av,mahadasha:'Saturn',antardasha:'Mercury');
    expect(p.valid,isTrue);
    expect(p.lords.map((e)=>e.planet).toList(),['Saturn','Mercury']);
    for (final e in p.lords) {
      expect(e.careerBindus,av.bhinna[e.planet]![9]);
      expect(e.gainBindus,av.bhinna[e.planet]![10]);
      expect(e.careerGivers.length,e.careerBindus);
    }
    final nodes=AshtakavargaPavCareerService.periodEvidence(
      chart:natal,av:av,mahadasha:'Rahu',antardasha:'Ketu');
    expect(nodes.lords,isEmpty);
    expect(nodes.notCovered,['Rahu','Ketu']);
  });
  test('transit kakshya switches giver exactly at 3.75 degrees', () {
    final av=AshtakavargaService.calculate(natal);
    final one=AshtakavargaPavCareerService.atTransit(
      av:av,recipient:'Saturn',siderealTransitLongitude:3.749);
    final two=AshtakavargaPavCareerService.atTransit(
      av:av,recipient:'Saturn',siderealTransitLongitude:3.75);
    expect(one!.giver,'Saturn');
    expect(two!.giver,'Jupiter');
    expect(one.kakshyaIndex,1);
    expect(two.kakshyaIndex,2);
    expect(one.hasBindu,av.prastara['Saturn']!['Saturn']![0]==1);
    expect(AshtakavargaPavCareerService.atTransit(
        av:av,recipient:'Rahu',siderealTransitLongitude:4),isNull);
  });
}
