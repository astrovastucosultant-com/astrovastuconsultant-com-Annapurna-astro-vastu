import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_career_comparison_service.dart';

D10CareerModeEvidence make(String key, int? score) => D10CareerModeEvidence(
  key: key, title: key, earlyStage: false, mainStage: false,
  favorableSharePercent: score, obstacleSharePercent: 25,
  professionFamilyEvidencePercent: null, favorableSignals: 4,
  obstacleSignals: 2, checkedSignals: 11,
  favorableRuleIds: const [], obstacleRuleIds: const [], audit: '',
);

D10CareerComparison compare(int? b, int? j, String stronger) =>
    D10CareerComparison(
      business: make('GOCHARASHTHA', b),
      job: make('AGOCHARASHTHA', j),
      strongerMode: stronger, firstProfession: 'Job', laterProfession: 'Business',
      conclusion: 'test', audit: '',
    );

void main() {
  test('41/42 is near equal, not proof job is the main career', () {
    final note = D10CareerComparisonService.explainStrengthContrast(
      compare(41, 42, 'GOCHARASHTHA'));
    expect(note, contains('తేడా 1 శాతం'));
    expect(note, contains('స్పష్టమైన ఆధిక్యం లేదు'));
    expect(note, contains('D10 శని'));
    expect(note, contains('వ్యాపారం / స్వయం ఉపాధి'));
  });

  test('large score difference remains separate from D10 work mode', () {
    final note = D10CareerComparisonService.explainStrengthContrast(
      compare(65, 40, 'AGOCHARASHTHA'));
    expect(note, contains('వ్యాపారం వైపు 25'));
    expect(note, contains('ప్రధాన D10 శని విధానం: ఉద్యోగం'));
  });

  test('missing numerator does not imply a zero strength', () {
    final note = D10CareerComparisonService.explainStrengthContrast(
      compare(null, 40, 'MIXED'));
    expect(note, contains('అసంపూర్ణ'));
  });
}
