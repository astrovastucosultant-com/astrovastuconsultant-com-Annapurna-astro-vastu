import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bcp_master_engine.dart';
import 'package:astro_app/astrology/bcp_year_result_explainer.dart';

void main() {
  final chart = NatalChart(ascendantSign: 1, longitudes: {
    'sun': 120, 'moon': 42.4, 'mars': 191.5,
    'mercury': 111, 'jupiter': 280, 'venus': 225,
    'saturn': 160, 'rahu': 345, 'ketu': 165,
  });
  final active = BcpEngine.activations(
    chart: chart, birthDate: DateTime(2000, 1, 1),
    onDate: DateTime(2017, 1, 1),
  ).single;

  test('every one of the 26 BCP domains can be inspected', () {
    expect(eventDefinitions.length, 26);
    for (final event in eventDefinitions) {
      final links = BcpEngine.eventLinks(chart, active, event);
      final summary = BcpYearResultExplainer.yearPreview(
          chart, active, event, links);
      expect(summary.isNotEmpty, isTrue);
      if (links.isEmpty) {
        expect(summary, contains('ప్రత్యక్ష సంబంధం లేదు'));
      } else {
        expect(summary, contains(BcpYearResultExplainer.focus(event.kind)));
        expect(summary, contains('నిర్ధారణ కాదు'));
      }
    }
  });

  test('specific natal house and lord links disclose computed graha', () {
    final direct = BcpYearResultExplainer.describeLink(
        chart, active, 'DIRECT_HOUSE: natal house 6');
    expect(direct, contains('6వ భావం'));
    final lord = BcpYearResultExplainer.describeLink(
        chart, active, 'HOUSE_LORD_ASPECT: house 10 -> saturn');
    expect(lord, contains('10వ భావాధిపతి శని'));
    expect(lord, contains('°'));
  });

  test('unmatched domain says no direct BCP link, not impossible event', () {
    final event = eventDefinitions.first;
    final preview = BcpYearResultExplainer.yearPreview(
        chart, active, event, const []);
    expect(preview, contains('ప్రత్యక్ష సంబంధం లేదు'));
    expect(preview, contains('నిరాకరించలేం'));
  });

  test('no inventing timing confirmation from a simple link', () {
    final event = eventDefinitions.first;
    final score = BcpEngine.scoreEvent(
      activation: active,
      matchedLinks: BcpEngine.eventLinks(chart, active, event),
    );
    expect(score.natalPoints, 0);
    expect(score.dashaPoints, 0);
    expect(score.transitPoints, 0);
    expect(score.hasTimingConfirmation, isFalse);
  });

  test('10-percent BCP-only relation is review, never a main result', () {
    const weak = BcpEvidenceScore(
      bcpPoints: 10, natalPoints: 0, dashaPoints: 0,
      transitPoints: 0, contradicted: false,
    );
    expect(weak.percent, 10);
    expect(BcpYearResultExplainer.hasIndependentNatalSupport(weak), isFalse);
    const full = BcpEvidenceScore(
      bcpPoints: 14, natalPoints: 30, dashaPoints: 0,
      transitPoints: 0, contradicted: false,
    );
    expect(BcpYearResultExplainer.hasIndependentNatalSupport(full), isTrue);
    const blocked = BcpEvidenceScore(
      bcpPoints: 14, natalPoints: 30, dashaPoints: 0,
      transitPoints: 0, contradicted: true,
    );
    expect(BcpYearResultExplainer.hasIndependentNatalSupport(blocked), isFalse);
  });
}
