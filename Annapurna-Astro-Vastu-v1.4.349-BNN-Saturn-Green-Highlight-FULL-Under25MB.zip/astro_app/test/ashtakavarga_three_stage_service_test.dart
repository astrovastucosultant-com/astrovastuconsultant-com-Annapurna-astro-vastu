import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/ashtakavarga_three_stage_service.dart';

void main() {
  test('source Pisces-start 4-sign thirds cover each sign exactly once', () {
    // 140 + 112 + 85 = 337; Pisces-start grouping means sign 11 first.
    final sign = <int>[35, 35, 35, 28, 28, 28, 28, 21, 21, 21, 22, 35];
    final result = AshtakavargaThreeStageService.evaluate(
        sarvaBySign: sign, lagnaSignIndex: 11);
    expect(result.valid, isTrue);
    expect(result.stages.map((s) => s.fixedBindus).toList(),
      [140, 112, 85]);
    expect(result.stages.map((s) => s.lagnaBindus).toList(),
      [140, 112, 85]);
    expect(result.leadingFixedStage, 0);
    expect(result.methodsAgree, isTrue);
    expect(result.atAge(0)?.index, 0);
    expect(result.atAge(32)?.index, 0);
    expect(result.atAge(33)?.index, 1);
    expect(result.atAge(65)?.index, 1);
    expect(result.atAge(66)?.index, 2);
    expect(result.atAge(98)?.index, 2);
    expect(result.atAge(99), isNull);
  });

  test('lagna-based variant is independent and Bandhu/Sevaka uses houses', () {
    final sign = <int>[35, 35, 35, 28, 28, 28, 28, 21, 21, 21, 22, 35];
    final result = AshtakavargaThreeStageService.evaluate(
        sarvaBySign: sign, lagnaSignIndex: 0);
    expect(result.valid, isTrue);
    expect(result.stages[0].fixedBindus, 140);
    expect(result.stages[0].lagnaBindus, 133);
    // House indices from Aries are 1, 5, 9 vs 2, 6, 10.
    expect(result.bandhu, 35 + 28 + 21);
    expect(result.sevaka, 35 + 28 + 21);
    expect(result.modeSupport, contains('సమానం'));
  });

  test('bad SAV totals produce no source conclusions', () {
    final result = AshtakavargaThreeStageService.evaluate(
        sarvaBySign: List<int>.filled(12, 28), lagnaSignIndex: 0);
    expect(result.valid, isFalse);
    expect(result.stages, isEmpty);
  });
}
