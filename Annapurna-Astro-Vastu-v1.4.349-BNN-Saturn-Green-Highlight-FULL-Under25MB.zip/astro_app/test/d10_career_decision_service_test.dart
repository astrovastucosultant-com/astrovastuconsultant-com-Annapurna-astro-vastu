import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/d10_career_decision_service.dart';
import 'package:astro_app/astrology/d10_career_service.dart';
import 'package:astro_app/astrology/varga_rule_service.dart';

D10SaturnStream saturn(String d1, String d10) => D10SaturnStream(
  birthState: d1, navamsaState: 'MIXED', dashamsaState: d10,
  result: 'Test', reason: 'D1/D10 Saturn rule', governmentAdministrativeSupport: false,
);

VargaRuleHit hit(String id, VargaRuleTone tone, {bool auto = true}) =>
    VargaRuleHit(factor: 10, ruleId: id, topic: id, result: 'source result',
      rule: 'source rule', inspection: 'computed positions', remedy: '',
      source: 'supplied source p.1', tone: tone, applicable: true,
      autoEvaluated: auto);

void main() {
  test('D10 service mode is clearly job, not equally business', () {
    final d = D10CareerDecisionService.summarize(
      saturn: saturn('GOCHARASHTHA', 'AGOCHARASHTHA'), rules: [
        hit('D10-AGOCHARISTA', VargaRuleTone.neutral),
        hit('D10-SEQUENCE', VargaRuleTone.favorable),
      ]);
    expect(d[0].tone, D10DecisionTone.favorable);
    expect(d[0].matchedRuleIds, contains('D10-AGOCHARISTA'));
    expect(d[1].tone, D10DecisionTone.mixed);
    expect(d[1].result, contains('D1లో వ్యాపార దశ'));
  });

  test('government D9 promise without D10 authority is not a direct job', () {
    final d = D10CareerDecisionService.summarize(
      saturn: saturn('MIXED', 'AGOCHARASHTHA'), rules: [
        hit('D10-GOV-01', VargaRuleTone.favorable),
        hit('D10-GOV-02', VargaRuleTone.neutral),
        hit('D10-GOV-03', VargaRuleTone.neutral),
      ]);
    expect(d[2].tone, D10DecisionTone.mixed);
    expect(d[2].matchedRuleIds, contains('D10-GOV-01'));
    expect(d[2].matchedRuleIds, isNot(contains('D10-GOV-03')));
  });

  test('government authority with business mode does not imply civil service', () {
    final d = D10CareerDecisionService.summarize(
      saturn: saturn('MIXED', 'GOCHARASHTHA'), rules: [
        hit('D10-GOV-01', VargaRuleTone.favorable),
        hit('D10-GOV-03', VargaRuleTone.favorable),
      ]);
    expect(d[2].tone, D10DecisionTone.mixed);
    expect(d[2].result, contains('కాంట్రాక్ట్'));
  });

  test('high position requires management with yoga or strong government', () {
    final d = D10CareerDecisionService.summarize(
      saturn: saturn('AGOCHARASHTHA', 'AGOCHARASHTHA'), rules: [
        hit('D10-HIGH-POSITION', VargaRuleTone.favorable),
        hit('D10-RAJAYOGA', VargaRuleTone.favorable),
        hit('D10-GOV-04', VargaRuleTone.neutral),
      ]);
    expect(d[3].tone, D10DecisionTone.favorable);
    expect(d[3].matchedRuleIds, containsAll(['D10-HIGH-POSITION', 'D10-RAJAYOGA']));
  });

  test('low high-position rule is a caution, not a denied career', () {
    final d = D10CareerDecisionService.summarize(
      saturn: saturn('MIXED', 'MIXED'), rules: [
        hit('D10-HIGH-POSITION', VargaRuleTone.caution),
      ]);
    expect(d[3].tone, D10DecisionTone.caution);
    expect(d[3].result, contains('జాగ్రత్త'));
  });

  test('missing rule is not a fabricated adverse outcome', () {
    final d = D10CareerDecisionService.summarize(
      saturn: saturn('MIXED', 'MIXED'), rules: const []);
    expect(d[2].tone, D10DecisionTone.unconfirmed);
    expect(d[2].result, isNot(contains('ఉద్యోగం లేదు')));
    expect(d[3].matchedRuleIds, isEmpty);
  });

  test('source-only rows do not silently count as matched', () {
    final d = D10CareerDecisionService.summarize(
      saturn: saturn('MIXED', 'MIXED'), rules: [
        hit('D10-HIGH-POSITION', VargaRuleTone.favorable, auto: false),
      ]);
    expect(d[3].tone, D10DecisionTone.unconfirmed);
    expect(d[3].checkedRuleIds, isEmpty);
  });
}
