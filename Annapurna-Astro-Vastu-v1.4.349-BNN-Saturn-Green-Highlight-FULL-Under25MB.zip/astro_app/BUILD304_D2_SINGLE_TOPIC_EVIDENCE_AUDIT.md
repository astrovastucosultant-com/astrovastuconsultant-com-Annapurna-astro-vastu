# Build 304 — D2 single-topic evidence audit / misleading 100% results fix

Base: v1.4.303. Scope: D2 client-facing result presentation for property/vehicles and one D4 weakness classifier.

1. The four visible property results (PR-001, PR-002, PR-003, PR-007) could show four independent 100% labels when the same D4 4L confirmation passed. These were legacy evidence scores, not four independent predictions or independent full chart confirmations. Percentages are removed from all D2 matched source card titles/results.
2. D2 property and vehicle hits now appear under one topic-level result with separate favorable/adverse counts and explicit chart categories. User can expand to inspect every original matched Rule ID, exact placement evidence, source and source page. No source rules were deleted or converted from unmatched into matched.
3. When both favorable/adverse source rules match the same topic, the topic-level result says MIXED / no final decision; no categorical outcome chosen merely based on larger score.
4. `D2-PR-006` previously considered any not-strong D4 4L to be weak. Now it uses the narrower debility/dusthana `_weakVarga` predicate; other non-kendra placements alone do not trigger a categorical delay.
5. Shared result tile labels distinguish favorable, adverse and mixed even where the source rule itself matched.

Limitations: This is a targeted UI/source-classification fix. It does not validate empirical event probabilities, add new astrology source rules, or implement cross-chart scoring for every topic in the app. The original source rule and inspect/remedy drill-down remain available. Flutter compile and on-device tests are not verified in this environment.
