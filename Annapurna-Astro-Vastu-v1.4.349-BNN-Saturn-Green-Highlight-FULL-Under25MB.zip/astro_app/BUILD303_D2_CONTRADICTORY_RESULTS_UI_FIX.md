# Build 303 — D2 Rule Contradiction UI / Adverse Status Fix

Source base: 1.4.302. Existing D2 registry (58 rules), original source conditions, and other modules remain unchanged.

## Screenshot issue corrected

* Both `D2-VH-003` (more vehicles) and `D2-VH-006` (no vehicle) can be true in the same D1 chart. This is not logically impossible: the source rules use separate conditions. A source-match percentage does not determine which outcome will happen.
* A source-backed contradiction detector recognises overlapping matched outcome rules for vehicles and property. It shows one **MIXED / unresolved** top-level result; the original two matched rules are kept under an expandable evidence panel, with their original IDs, chart inspections and source page. Neither source rule is deleted or silently marked false.
* Matched negative results now use a negative icon/color instead of a green check: match status and favorable/adverse tone are independent.
* `Source Rules / Audit` now counts unmatched vs pending separately. Rules with implemented evaluators but no match are `autoEvaluated=true, applicable=false`; pending stays pending (including missing Moon preventing computation).
* D2 results clarify % is an **evidence index**, not probability or event certainty. No arbitrary priority for conflicting rule outcomes is introduced.

## Verification

* Dart unit tests added for conflict detection, and an actual synthetic D1 chart meeting both `D2-VH-003` and `D2-VH-006`.
* Flutter widget regression test added for negative match styling.
* Tests require Flutter/Dart SDK and must still be run by GitHub Actions or a machine with Flutter installed; zip archive integrity can be checked here.

## Known limits

* Contradiction checking initially targets explicit opposed D2 vehicle/property claims. It does not complete every source-only rule across all vargas.
* Ranking the strength of conflicting outcomes must be specified using verified book rules, not invented from source-match percentages.
