# Annapurna Astro Vastu v1.4.329 — D10 విదేశీ ఉద్యోగం IF–THEN audit

## Screenshot issue
D10 foreign job card used `applicable: true` regardless of source conditions and
`foreignPromise` shortcut used `(D1 any hit) AND (D10 any hit)`; this could present
partial signals as a green complete foreign-job match.

## Corrected boundary
1. Check separate D1 8L link, D1 10L to 9/12, D1 3L career-change link.
2. Check repeated D10 8L link, D10 10L to 9/12, D10 3L and 8L to 10H/10L.
3. Seven explicit conditions are shown YES/NO; only complete checklist
   enables a favorable / auto-applied source result. Conditional dasha timing
   is shown only after promise.
4. Conservative source interpretation: the supplied *D10 special.pdf*
   bibliography is carried over, but its printed-rule wording was not
   re-audited here. Treat the strict AND gate as conservative implementation,
   not a proof of correctness of astrology or the manuscript source.
5. `0 linked` means no machine-evaluable rule connected, not 'this profession
   is impossible'. Empty topics remain present for source-backfill.
6. All legacy sources, 19 varga topics/charts, and other rule engines are
   retained unchanged. VARGA-CROSS continues to be audit-only.

## QA
New Flutter tests: test/d10_foreign_promise_strict_gate_v329_test.dart.
No Flutter/Dart SDK in this container; Flutter analyze/tests/APK build NOT verified.

## Varga topic audit fix
Unmatched source-backed professions for banking/engineering/medical-education are now kept under a collapsed audit with passed, failed, and pending predicates; a zero applied count no longer falsely implies zero linked rules. Legacy full-match routing is unchanged.
