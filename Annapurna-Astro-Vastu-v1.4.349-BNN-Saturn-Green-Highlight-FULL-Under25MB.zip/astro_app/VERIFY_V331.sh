#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tool/verify_v331.py
flutter pub get
flutter analyze
flutter test test/varga_ashtakavarga_all_19_v331_test.dart
flutter test test/varga_ashtakavarga_widget_v331_test.dart
flutter test
flutter build apk --release
