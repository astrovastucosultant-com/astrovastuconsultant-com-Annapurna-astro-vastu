# Annapurna Astro Vastu v1.4.332 — D2/D7/D20 screenshot QA

## Observed behavior
- D7 combined `D7-SANTANA-001` displayed `Evidence 0%` while its inherited flag was `applicable: true`. An aggregate support index is not a complete independent event rule.
- D3 and D4 also promoted multi-criterion evidence indices into result count and color.
- The PAV contributor enumeration appeared below almost every expanded source row, and again immediately after the AV table for the same house. This made mobile panels long and obscured the IF–THEN rule/evidence distinction.
- D20 source guidance (`D20-MAHAVIDYA-GUIDE`) is still an incomplete source condition: no result has been inferred from the AV totals.
- Raw D7/D20 SAV and BAV figures in the screenshots are arithmetically consistent. This audit does **not** establish doctrinal validity of applying conventional D1-style Ashtakavarga to all vargas.

## Changes
1. Evidence summaries D3/D4/D7 and D16 ratio rows are **audit-only** in the shared rule match policy. No auto green/pink result from a composite ratio.
2. D7 summary is explicitly named `ఆధారాల పరిశీలన x/5` with `auto:false` and `applicable:false`; cannot be displayed as a confirmed birth outcome.
3. Source rule examinations now append only D1 SAV vs selected varga SAV and a link-instruction to the one per-topic AV house panel.
4. AV house panel contains the seven BAV values and complete PAV contributor table once, with explicit arithmetic check; the former duplicate full 7×8 textual enumeration was removed.
5. The varga AV panel explicitly labels D2–D60 derived application **exploratory**; arithmetic consistency is not interpretation or a classical endorsement.
6. Existing source rules, 19 varga definitions, linked texts and old tests preserved.

## Tests
- `flutter test test/varga_v332_evidence_summary_truth_test.dart test/varga_v332_av_mobile_readability_test.dart`
- `flutter analyze`
- `flutter test`
- `flutter build apk --release`

These Flutter/Dart commands require an SDK; they are **not verified** in this environment. ZIP integrity and source preservation are verified separately.
