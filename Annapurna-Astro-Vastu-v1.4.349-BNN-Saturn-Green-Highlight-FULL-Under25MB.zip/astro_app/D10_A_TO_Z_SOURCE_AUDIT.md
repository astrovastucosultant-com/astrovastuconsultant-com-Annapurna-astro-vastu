# D10 A to Z – Source audit / working specification (not a production release)

Date: 2026-11-03. This is a source-side internal planning/audit note; no APK, ZIP, or verified Flutter test run has been released for these changes.

## Verified against present working source
- D10 Parashari 3-degree parity mapping in `VargaService`.
- D1/D9/D10 Saturn classification and first/later occupation via `D10CareerService`, **user-defined rule**, not a universal BPHS prescription.
- `D10CareerDecisionService` four major mode/government/rank summary cards.
- `D10CareerComparisonService` relative favorable/obstacle evidence, not money or event probability.
- `D10FinalProfessionEngine` 10L sign, 27-star tags, benefic supportive profession families.
- Source book registry `d10_vrutti_rule_registry.dart`: 336 VR rows, with source title/page and conditional qualifiers. Registry count does not certify full match for every row.
- `D10VruttiMatchEngine` separates confirmed primary planet vs fully matched rule; unresolved source conditions are kept pending.
- Dasha-based timing windows, separate Rise/JobLoss/Change transfer and retirement; PAV transit resolver in `D10PavTransitCareerService`.
- PAV 8 giver row, 3°45′ kakshya, actual requested transit date, sidereal longitude and 337 natal SAV invariant.
- New during audit: `D10VargaAshtakavargaService` calculates **distinct D1 and D10 natal SAV tables**, 337 each; D10 career house inspection displayed in D10 report, with tests authored but unrun.

## Must correct or validate before a complete D10 release
1. Validate 3° D10 parity and lagna boundary inputs against two independent calculators; warn when birth-time uncertainty crosses D10 lagna boundary.
2. Rule engine: verify full `IF` predicates and exact original page for each of the 336 occupation rows. Do not expose partial matches as occupation verdicts. Detect contradictory or ambiguous source fields and differentiate independent vs correlated checks.
3. D10 overall job/business final verdict: combine Saturn-mode **user-specified** rule with occupation source rules, D10 6th service, D10 7th business, and 10th career; do not make a definitive verdict from Saturn sign alone.
4. Treat 10th-from-10th (D10 7th) as an additional evaluation, not duplicate proof for partnership.
5. Add D10 Arudha Lagna / A10, Amatyakaraka and D10 10L linked to D1 10L as separately sourced, auditable optional evidence. No invented cross-chart formulas.
6. Government / high-position: keep employment and contractors separate; use multiple source-backed independent conditions. Career leadership, role rank and government employment are distinct outcomes.
7. Rank business and job sector-specific lists by source-rule coverage + qualification/skill constraints. Family-score % is evidence coverage only, not job probability.
8. Separate financial **earnings / savings / losses / expenses** and do not convert AV into currency % without measured validation.
9. Timing: test MD/AD/PD windows, exact Jupiter/Saturn ephemeris, retrograde re-entry and kakshya boundaries; separate actual static natal SAV from D10 static SAV and natal D1 PAV/kakshya transit. Compare with normal periods, not only known events.
10. 0–33, 33–66, 66–99 are user-requested display buckets, not a proven quoted age boundary from Mehta; mark clearly as app bins.
11. Source-ground all rise, demotion, transfers, foreign work, retirement, partnership and career break. Change/transfer is **not** evidence for stable/neutral years. Label corrected in report.
12. Run `flutter analyze`, all D10 tests, Android release build, and QA with independent births and held-out events before claiming completion. Flutter/Dart not installed in this environment; test files have been authored but **not run**.

## Evidence hierarchy and transparent output
Result first → chart conditions / counterevidence → applied source Rule ID and page → sourced remedy if supplied. Distinguish:
- Fully matched natal IF rule
- Supporting/partial observational context
- Tested-but-not-matched rules
- Pending data/method
- Strong vs weak astrological **indicator** vs statistically measured predictive accuracy

## Web references reviewed
- BPHS, Shodashavarga/D10 construction, 3° parity and digpala sequence: https://www.astroengine.ai/d10
- BPHS chapter 21, tenth-lord interpretations: https://vedicpupil.in/library/books/brihat-parashara-hora-shastra/chapter-21
- P.V.R. Narasimha Rao, *Vedic Astrology: An Integrated Approach*, section 6.2.10 D10 construction, section 12.5 divisional Ashtakavarga / D10 case study: https://storage.yandexcloud.net/j108/library/rptviqw0/P.V.R._Narasimha_Rao_-_Vedic_Astrology_-_An_Integrated_Approach.pdf
- PAV Kakshya and BAV/SAV career use: https://jagannathhora.com/ashtakavarga-10th-house-career/
- Modern layered D1/D10/dasha approach: https://horamsa.com/learn/career-timing

No claim is made that astrology's prediction success has been scientifically established, or that new code was compiled.
