# Build 312 — D10 real screenshot QA / presentation audit

- Source base is v1.4.311 (every prior project asset preserved).
- Compact top 13-system tab strip to use one-line icon+text and retain existing 13 indices. Bottom navigation, charts, save and engines preserved.
- Shortened branded AppBar title to avoid screenshot truncation.
- No repeated D10 legacy decision cards before D10CareerOverview. The overview remains the result-first report; every applied source rule remains available through rule taps and the collapsed detailed source audit. Optional external D10 rule screen and investment timing are now a single collapsed advanced section after the main D10 report.
- Preserve user-defined D1 first stream and D10 main Saturn stream, but explicitly distinguish it from numerical evidence-share indices. The observed 41 vs 42 scores are within 1 percentage point and are not decisive proof of a main career stream.
- Keep favorable/obstacle indices as rule-evidence shares, not promotion or financial loss probabilities. Source rules and calculation engines unchanged.
- Show D10 SAV later, after career timing, matching numbered report order. Keep source evidence fully inspectable.
- Added 3 comparison-explanation regression tests. Flutter/Dart compile not executed in this environment.
