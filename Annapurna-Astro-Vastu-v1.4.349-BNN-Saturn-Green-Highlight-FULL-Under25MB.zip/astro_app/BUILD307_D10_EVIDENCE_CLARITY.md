# v1.4.307 — D10 Evidence vs Result clarity

* Preserves v1.4.306 source rules and results; changes only the shared varga inspection summary and D10 audited houses.
* Separates **overall varga placement evidence** from **lagna-only evidence**. Mixed good/adverse indicators in different houses now produce a mixed overall synopsis instead of a misleading favorable lagna-only headline.
* D10 now inspects houses 10, 6, 7, 2, 11 as individual evidence panels (career/service/partnership/income/gains).
* D10 screen explicitly says that generic planetary placements do **not** prove employment, business, government job or rank. Final outcome needs matched source IF–THEN, exceptions and event timing.
* New tests cover the D10 focus-house list and mixed overall evidence.
* No claim of Flutter compile or APK verification: use GitHub Actions to build and inspect the actual release log.
