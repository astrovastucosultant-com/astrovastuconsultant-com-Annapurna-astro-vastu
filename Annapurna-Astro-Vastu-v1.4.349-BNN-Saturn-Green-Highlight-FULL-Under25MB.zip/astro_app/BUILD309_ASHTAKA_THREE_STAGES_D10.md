# Build v1.4.309 — D10 summary + Ashtakavarga stage evidence

- D10 order: గోచరిష్ట, అగోచరిష్ట, mode comparison, profession/industry shortlist, government/rank, timing, yoga/audit.
- New classical SAV groups, based on M. S. Mehta, *Ashtakvarga: Concept and Application* (printed pp. 48–49):
  - Bandhu = 1+5+9 (additional independent-work support), Sevaka = 2+6+10 (additional service support).
  - Life stages: fixed Pisces–Gemini / Cancer–Libra / Scorpio–Aquarius, plus alternative Lagna-based 1–4 / 5–8 / 9–12.
- Each of 3 groups displays exact bindus; one peak is not guaranteed. Show source and method differences.
- User-requested age bands 0–32, 33–65, 66–98 are display conventions, **not** a formula proven by the cited source.
- A life-stage change is **not** a calculated promotion/downfall event; D10 natal promise and dasha/year rules continue controlling timing.
- Percentages for career are evidence coverage, not real rupee loss/profit or probabilities.
- Do not double count Ashtakavarga evidence with existing D10 source rules.
- Test code provided, but Flutter compile/unit-test execution is not verified in this environment.

## Added PAV period-graha evidence

- Raw prastara is already computed by `AshtakavargaService` (7 BAV recipients x 8 contributors x 12 signs). Reuse it; validate against 337 bindus and recipient BAV signs.
- D10 summary: show 10th/11th house bindu counts for career-relevant planets (D1 natal chart).
- Every existing D10 Vimshottari rise/fall/middle window can be opened to show its MD/AD BAV bindus, donor rows in 10/11 and natal planet sign.
- Rahu/Ketu do **not** have rows in standard 7-graha PAV and are shown as not-covered, not 0 points.
- 8 kakshya x 3°45′ evaluation is implemented as a **pure function requiring real transit longitude**; the report does not synthesize or invent historical/future transit positions.
- PAV donor data supports assessment but is **not a separate source or proof** of promotion/downfall, and is not double-counted with BAV in computed career evidence percentages.
