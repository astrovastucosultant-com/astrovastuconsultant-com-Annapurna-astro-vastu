import 'package:sweph/sweph.dart';
import '../models/birth_data.dart';

/// Classical solar weekday: the day begins at the sunrise at the *birthplace*,
/// not at 00:00 local civil time. Never silently substitute civil weekday
/// when Swiss Ephemeris cannot compute the requested local sunrise.
class SunriseVaraResult {
  final int civilWeekday;
  final int solarWeekday; // Dart weekdays: Monday=1 through Sunday=7
  final bool beforeSunrise;
  final DateTime sunriseUtc;
  const SunriseVaraResult({required this.civilWeekday,
    required this.solarWeekday, required this.beforeSunrise,
    required this.sunriseUtc});
}

class SunriseVaraService {
  static DateTime midnightUtc(BirthData birth) =>
      DateTime.utc(birth.localDateTime.year, birth.localDateTime.month,
        birth.localDateTime.day).subtract(
          Duration(minutes:(birth.timezoneOffsetHours*60).round()));

  static SunriseVaraResult resolve(BirthData birth, DateTime sunriseUtc) {
    final localSunrise = sunriseUtc.toUtc().add(
      Duration(minutes:(birth.timezoneOffsetHours*60).round()));
    final localBirth=birth.localDateTime;
    if (localBirth.year != localSunrise.year ||
        localBirth.month != localSunrise.month ||
        localBirth.day != localSunrise.day) {
      throw ArgumentError('సూర్యోదయం జన్మ స్థానిక తేదీకి చెందాలి.');
    }
    final before=birth.utcDateTime.isBefore(sunriseUtc.toUtc());
    final civil=localBirth.weekday;
    final solar=before?(civil==DateTime.monday?DateTime.sunday:civil-1):civil;
    return SunriseVaraResult(civilWeekday:civil,solarWeekday:solar,
      beforeSunrise:before,sunriseUtc:sunriseUtc.toUtc());
  }

  static DateTime _dateTimeFromJd(double jd) => DateTime.utc(1970,1,1).add(
    Duration(microseconds:((jd-2440587.5)*86400000000).round()));

  /// Must be invoked after Swiss Ephemeris is initialized for the natal chart.
  /// Null is an explicit unverified state, not a civil-weekday fallback.
  static SunriseVaraResult? tryCalculate(BirthData birth) {
    if (!birth.latitude.isFinite || !birth.longitude.isFinite ||
        !birth.timezoneOffsetHours.isFinite ||
        birth.latitude.abs() >= 66 || birth.longitude.abs() > 180 ||
        birth.timezoneOffsetHours < -12 || birth.timezoneOffsetHours > 14) {
      return null;
    }
    try {
      final midnight = midnightUtc(birth);
      final jd=Sweph.swe_julday(midnight.year,midnight.month,midnight.day,
        midnight.hour+midnight.minute/60.0+midnight.second/3600.0+
          midnight.millisecond/3600000.0,
        CalendarType.SE_GREG_CAL);
      final rise=Sweph.swe_rise_trans(jd,HeavenlyBody.SE_SUN,
        SwephFlag.SEFLG_MOSEPH,RiseSetTransitFlag.SE_CALC_RISE,
        GeoPosition(birth.longitude,birth.latitude),0,0);
      if(rise==null || !rise.isFinite) return null;
      return resolve(birth,_dateTimeFromJd(rise));
    } catch (_) { return null; }
  }
}
