import 'ashtakavarga_service.dart';
import 'astro_models.dart';
import 'varga_service.dart';

/// Source: P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach,
/// section 12.5 (Ashtakavarga of divisional charts; D10 SAV case study).
///
/// The *birth chart* SAV and *D10 chart* SAV are distinct tables. Both use the
/// same eight classical contributors and seven recipient planets; D10 receives
/// varga-mapped planetary and ascendant longitudes, not a current transit.
/// These values are astrological evidence scores, not promotion probabilities.
class D10VargaAshtakavargaReport {
  final AshtakavargaResult natal;
  final AshtakavargaResult dashamsa;
  final int dashamsaLagnaSign;

  const D10VargaAshtakavargaReport({
    required this.natal,
    required this.dashamsa,
    required this.dashamsaLagnaSign,
  });

  int natalSav(int house, int natalLagnaSign) =>
      natal.sarva[(natalLagnaSign + house - 1) % 12];

  int dashamsaSav(int house) =>
      dashamsa.sarva[(dashamsaLagnaSign + house - 1) % 12];

  bool get auditPassed => natal.totalsValid && dashamsa.totalsValid &&
      natal.grandTotal == 337 && dashamsa.grandTotal == 337 &&
      natal.arithmetic.auditValid && dashamsa.arithmetic.auditValid;

  String evidenceForHouse(int house) {
    final points = dashamsaSav(house);
    // 28 is the seven-planet SAV mean (337 / 12 = 28.08); 30+ is
    // used in the referenced D10-SAV case study. Interpret relationally.
    if (points >= 30) return 'బలమైన వర్గ అష్టకవర్గ మద్దతు';
    if (points >= 28) return 'సగటు సమీపం / మధ్యస్థ మద్దతు';
    return 'సగటు కంటే తక్కువ బిందువులు';
  }
}

class D10VargaAshtakavargaService {
  static const source =
      'P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach, section 12.5';
  static const ruleId = 'D10-AV-SAV-01';

  static D10VargaAshtakavargaReport calculate(AstroChartResult natal) {
    // The AV engine only reads whole-sign indices. Keeping the converted
    // D10 fractional degrees is nevertheless useful for auditing boundaries.
    final d10 = AstroChartResult(
      julianDay: natal.julianDay,
      ayanamsaDegrees: natal.ayanamsaDegrees,
      ascendantLongitude:
          VargaService.d10LongitudeForLongitude(natal.ascendantLongitude),
      planets: List<PlanetPosition>.unmodifiable(natal.planets.map((p) =>
          PlanetPosition(
            name: p.name,
            shortName: p.shortName,
            longitude: VargaService.d10LongitudeForLongitude(p.longitude),
            latitude: p.latitude,
            speed: p.speed,
          ))),
      engineVersion: '${natal.engineVersion}:D10',
    );
    final result = D10VargaAshtakavargaReport(
      natal: AshtakavargaService.calculate(natal),
      dashamsa: AshtakavargaService.calculate(d10),
      dashamsaLagnaSign: d10.ascendantSignIndex,
    );
    if (!result.auditPassed) {
      throw StateError('D1 / D10 Ashtakavarga internal 337-bindu audit failed');
    }
    return result;
  }
}
