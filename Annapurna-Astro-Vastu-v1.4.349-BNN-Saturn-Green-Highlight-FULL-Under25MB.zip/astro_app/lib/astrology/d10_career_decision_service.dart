import 'd10_career_service.dart';
import 'varga_rule_service.dart';

/// Present a result from the actual source-rule evaluators rather than from
/// counts of generic varga house signals. These are astrological indications,
/// never statistical event probabilities or a guarantee of recruitment.
enum D10DecisionTone { favorable, mixed, caution, unconfirmed }

class D10CareerDecision {
  final String key;
  final String title;
  final String result;
  final D10DecisionTone tone;
  final List<String> matchedRuleIds;
  final List<String> checkedRuleIds;
  final String reasoning;

  const D10CareerDecision({
    required this.key,
    required this.title,
    required this.result,
    required this.tone,
    required this.matchedRuleIds,
    required this.checkedRuleIds,
    required this.reasoning,
  });
}

class D10CareerDecisionService {
  static List<D10CareerDecision> summarize({
    required D10SaturnStream saturn,
    required List<VargaRuleHit> rules,
  }) {
    final byId = <String, VargaRuleHit>{
      for (final r in rules.where((r) => r.factor == 10))
        r.ruleId: r,
    };

    bool positive(String id) {
      final r = byId[id];
      return r != null && r.autoEvaluated && r.applicable && r.tone == VargaRuleTone.favorable;
    }

    D10CareerDecision entry(
      String key,
      String title,
      String result,
      D10DecisionTone tone,
      List<String> candidates,
      String reasoning, {
      List<String>? confirmed,
    }) {
      final checked = candidates.where(byId.containsKey).toList(growable: false);
      final matched = (confirmed ?? checked.where(positive))
          .where(byId.containsKey).toSet().toList(growable: false);
      return D10CareerDecision(
        key: key, title: title, result: result, tone: tone,
        matchedRuleIds: matched, checkedRuleIds: checked, reasoning: reasoning,
      );
    }

    final d10 = saturn.dashamsaState;
    final d1 = saturn.birthState;
    final scoreResult = byId['D10-JOB-BUSINESS']?.result ?? '';
    final scoreSupportsJob = scoreResult.startsWith('ఉద్యోగం / Service సూచనలు బలంగా ఉన్నాయి');
    final scoreSupportsBusiness = scoreResult.startsWith('వ్యాపారం / Self-employment సూచనలు బలంగా ఉన్నాయి');

    // D10 is the selected final work mode under the user's established rule;
    // D1 may describe an earlier stage, not an equal competing final verdict.
    final jobMain = d10 == 'AGOCHARASHTHA';
    final businessMain = d10 == 'GOCHARASHTHA';
    final jobSecondary = !jobMain && d1 == 'AGOCHARASHTHA';
    final businessSecondary = !businessMain && d1 == 'GOCHARASHTHA';
    final jobSupport = jobMain || (d10 == 'MIXED' && scoreSupportsJob);
    final businessSupport = businessMain || (d10 == 'MIXED' && scoreSupportsBusiness);

    final job = entry(
      'job', 'ఉద్యోగం / సర్వీస్',
      jobMain
          ? 'ఉద్యోగం / సర్వీస్ వైపు ప్రధాన వృత్తి సూచన ఉంది.'
          : jobSupport
              ? 'వృత్తి గ్రహ నియమాలు ఉద్యోగం వైపు మద్దతు ఇస్తున్నాయి.'
              : jobSecondary
                  ? 'D1లో ఉద్యోగ దశ సూచన ఉంది; D10లో ప్రస్తుతం ప్రధాన విధానం వేరుగా ఉంది.'
                  : 'ఈ పరీక్షించిన నియమాల్లో ఉద్యోగం ప్రధాన విధానంగా నిర్ధారణ కాలేదు.',
      jobSupport ? D10DecisionTone.favorable :
          jobSecondary ? D10DecisionTone.mixed : D10DecisionTone.unconfirmed,
      const ['D10-AGOCHARISTA', 'D10-SEQUENCE', 'D10-JOB-BUSINESS'],
      'D1: ${saturn.birthState} • D9: ${saturn.navamsaState} • D10: ${saturn.dashamsaState}. '
      'మూల విధానం: ${saturn.reason}',
      confirmed: [if (jobMain || jobSecondary) 'D10-SEQUENCE',
        if (jobMain) 'D10-AGOCHARISTA',
        if (d10 == 'MIXED' && scoreSupportsJob) 'D10-JOB-BUSINESS'],
    );

    final business = entry(
      'business', 'వ్యాపారం / స్వయం ఉపాధి',
      businessMain
          ? 'వ్యాపారం / స్వయం ఉపాధి వైపు ప్రధాన వృత్తి సూచన ఉంది.'
          : businessSupport
              ? 'వృత్తి గ్రహ నియమాలు వ్యాపారం వైపు మద్దతు ఇస్తున్నాయి.'
              : businessSecondary
                  ? 'D1లో వ్యాపార దశ సూచన ఉంది; D10లో ప్రస్తుతం ప్రధాన విధానం వేరుగా ఉంది.'
                  : 'ఈ పరీక్షించిన నియమాల్లో వ్యాపారం ప్రధాన విధానంగా నిర్ధారణ కాలేదు.',
      businessSupport ? D10DecisionTone.favorable :
          businessSecondary ? D10DecisionTone.mixed : D10DecisionTone.unconfirmed,
      const ['D10-GOCHARISTA', 'D10-SEQUENCE', 'D10-JOB-BUSINESS'],
      'D1: ${saturn.birthState} • D9: ${saturn.navamsaState} • D10: ${saturn.dashamsaState}. '
      'మూల విధానం: ${saturn.reason}',
      confirmed: [if (businessMain || businessSecondary) 'D10-SEQUENCE',
        if (businessMain) 'D10-GOCHARISTA',
        if (d10 == 'MIXED' && scoreSupportsBusiness) 'D10-JOB-BUSINESS'],
    );

    final govFifth = positive('D10-GOV-01');
    final govNinth = positive('D10-GOV-02');
    // GOV-03 uses a cross-source operational indicator, not an exact
    // government-service IF–THEN from the source book. It is SUPPORT only.
    final govAuthoritySupport = byId['D10-GOV-03']?.applicable == true;
    final govMain = govAuthoritySupport && d10 == 'AGOCHARASHTHA';
    final govLinkedBusiness = govAuthoritySupport && d10 == 'GOCHARASHTHA';
    final govPromise = govFifth || govNinth;
    final government = entry(
      'government', 'ప్రభుత్వ ఉద్యోగం',
      govMain
          ? 'D9 ప్రభుత్వ సంబంధ సూచనతో D10 సర్వీస్–అధికార మద్దతు ఉంది; ప్రత్యక్ష ప్రభుత్వ ఉద్యోగానికి పూర్తి ప్రత్యేక మూల నియమ నిర్ధారణ లేదు.'
          : govLinkedBusiness
              ? 'ప్రభుత్వ సంబంధిత కన్సల్టెన్సీ / కాంట్రాక్ట్ పనికి సూచన ఉంది; ప్రత్యక్ష ప్రభుత్వ ఉద్యోగంగా ప్రకటించము.'
              : govPromise
                  ? 'D9లో ప్రభుత్వ సేవ/సంబంధ సూచన ఉంది; D10 పూర్తి ప్రభుత్వ ఉద్యోగ ధృవీకరణ ఈ నియమాల్లో లేదు.'
                  : 'ఈ 5వ/9వ అధిపతి మూల నియమాల్లో ప్రభుత్వ ఉద్యోగయోగం గుర్తించబడలేదు; ప్రభుత్వ ఉద్యోగం లేదని దీని అర్థం కాదు.',
      govMain ? D10DecisionTone.mixed :
          (govLinkedBusiness || govPromise) ? D10DecisionTone.mixed : D10DecisionTone.unconfirmed,
      const ['D10-GOV-01', 'D10-GOV-02', 'D10-GOV-03', 'D10-AGOCHARISTA', 'D10-GOCHARISTA'],
      '${byId['D10-GOV-03']?.inspection ?? 'D9–D10 government check unavailable.'} '
      'D10 వృత్తి విధానం: ${saturn.dashamsaState}.',
      confirmed: [if (govFifth) 'D10-GOV-01', if (govNinth) 'D10-GOV-02',
        if (govMain) 'D10-AGOCHARISTA',
        if (govLinkedBusiness) 'D10-GOCHARISTA'],
    );

    final management = positive('D10-HIGH-POSITION');
    final yogaRepeat = positive('D10-RAJAYOGA');
    final seniorGovernment = positive('D10-GOV-04'); // example-only GOV-04 is not a full match
    final highSupported = management && (yogaRepeat || seniorGovernment);
    final highPartial = management || yogaRepeat || seniorGovernment;
    final highCaution = byId['D10-HIGH-POSITION']?.tone == VargaRuleTone.caution;
    final high = entry(
      'high-position', 'ఉన్నత పదవి / అధికారం',
      highSupported
          ? 'ఉన్నత పదవి / అధికార స్థాయికి వృత్తి బలం మరియు అదనపు రాజయోగ/ప్రభుత్వ ఆధారాలు సరిపోయాయి.'
          : highPartial
              ? 'ఉన్నత పదవికి కొంత మూల ఆధారం ఉంది; పూర్తి సంయుక్త బలం కనిపించలేదు.'
              : highCaution
                  ? 'ఉన్నత పదవి బలం ఈ వృత్తి నియమంలో బలహీనంగా ఉంది; పదోన్నతి విషయంలో జాగ్రత్త సూచన.'
                  : 'పరీక్షించిన నిర్వహణ, రాజయోగ, అధికార నియమాల్లో ఉన్నత పదవి బలం నిర్ధారణ కాలేదు.',
      highSupported ? D10DecisionTone.favorable :
          highPartial ? D10DecisionTone.mixed :
          highCaution ? D10DecisionTone.caution : D10DecisionTone.unconfirmed,
      const ['D10-HIGH-POSITION', 'D10-RAJAYOGA', 'D10-GOV-04'],
      'నిర్వహణ/అధికారం: ${byId['D10-HIGH-POSITION']?.inspection ?? 'లెక్క లేదు'}. '
      'రాజయోగం: ${byId['D10-RAJAYOGA']?.inspection ?? 'లెక్క లేదు'}. '
      'ప్రభుత్వ ఆధారం: ${byId['D10-GOV-04']?.inspection ?? 'లెక్క లేదు'}.',
      confirmed: [if (management) 'D10-HIGH-POSITION',
        if (yogaRepeat) 'D10-RAJAYOGA', if (seniorGovernment) 'D10-GOV-04'],
    );

    return List<D10CareerDecision>.unmodifiable([job, business, government, high]);
  }
}
