import 'astro_models.dart';
import 'ashtakavarga_service.dart';
import 'ashtakavarga_pav_career_service.dart';
import 'varga_rule_match_policy.dart';
import 'varga_service.dart';

/// A computed, chart-specific SAV / BAV / Prastara (PAV) evidence layer for
/// each of the 19 supported vargas. These are raw classical 7-recipient,
/// 8-contributor Ashtakavarga *arithmetic* applied to varga sign placements.
/// The D1 (natal) table is always retained for a transparent comparison.
///
/// Important: a divisional Ashtakavarga table is NOT an event prediction, a
/// source-backed timing window, a medical diagnosis or a proof of an IF–THEN
/// natal promise. D1 and the selected varga are not interchangeable.
class VargaAvHouseEvidence {
  final int house; // 1-based house in the selected chart
  final int signIndex; // 0-based sign in the selected chart
  final int sav;
  final Map<String, int> bav;
  final Map<String, List<String>> pavContributors;

  const VargaAvHouseEvidence({
    required this.house,
    required this.signIndex,
    required this.sav,
    required this.bav,
    required this.pavContributors,
  });

  bool get arithmeticValid =>
      bav.values.fold<int>(0, (sum, n) => sum + n) == sav &&
      AshtakavargaService.planetOrder.every(
        (p) => pavContributors[p] != null &&
            pavContributors[p]!.length == bav[p]);

  /// Observable facts; never converts a bindu score into a final prediction.
  String get examination {
    final bavValues = AshtakavargaService.planetOrder
        .map((p) => '$p ${bav[p] ?? '—'}').join(' • ');
    final pavValues = AshtakavargaService.planetOrder
        .map((p) => '$p: ${pavContributors[p]!.isEmpty ? '—' : pavContributors[p]!.join(', ')}')
        .join(' | ');
    return '${house}వ భావం • రాశి ${signIndex + 1}: SAV $sav / 56; '
        'BAV (ప్రతి గ్రహానికి 0–8): $bavValues. '
        'PAV బిందువులు ఇచ్చిన గ్రహాలు/లగ్నం: $pavValues. '
        'ఇది గణన ఆధారం మాత్రమే; సంఘటన ఫలితం కాదు.';
  }
}

class VargaAshtakavargaReport {
  final int factor;
  final int lagnaSignIndex;
  final D16CalculationMethod d16Method;
  final AshtakavargaResult natal;
  final AshtakavargaResult selected;
  final List<VargaAvHouseEvidence> houses;
  final bool auditPassed;

  const VargaAshtakavargaReport({
    required this.factor,
    required this.lagnaSignIndex,
    required this.d16Method,
    required this.natal,
    required this.selected,
    required this.houses,
    required this.auditPassed,
  });

  VargaAvHouseEvidence forHouse(int house) {
    if (house < 1 || house > 12) {
      throw RangeError.range(house, 1, 12, 'house');
    }
    return houses[house - 1];
  }

  /// Explicit source-independent, audit-only rule ID, not a prediction.
  String ruleIdForHouse(int house) => 'AV-D$factor-H$house-SAV-BAV-PAV';

  int natalSavForSign(int signIndex) => natal.sarva[signIndex];
}

class VargaAshtakavargaService {
  static const source =
      'Parashari seven-planet BAV/SAV, eight contributors; '
      'P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach, '
      'divisional-chart Ashtakavarga method. Derived evidence, not prediction.';

  static VargaAshtakavargaReport calculate(
    AstroChartResult natal,
    int factor, {
    D16CalculationMethod d16Method = D16CalculationMethod.parashara,
  }) {
    if (!VargaRuleMatchPolicy.supportedFactors.contains(factor)) {
      throw ArgumentError.value(factor, 'factor', 'Unsupported varga');
    }
    if (!natal.ascendantLongitude.isFinite ||
        AshtakavargaService.planetOrder.any((name) =>
            natal.planets.where((p) => p.name == name && p.longitude.isFinite).length != 1)) {
      throw StateError('Ashtakavarga requires a finite Lagna and exactly '
          'one finite longitude for each of the seven classical planets');
    }

    final natalAv = AshtakavargaService.calculate(natal);
    final mapped = VargaService.calculate(natal, factor, d16Method: d16Method);
    final sourcePlanet = {for (final p in natal.planets) p.name: p};
    // Raw SAV/BAV/PAV depends only on sign placements, not a fractional
    // varga longitude. Sign-centre longitudes explicitly avoid pretending to
    // derive a precise D16/D60 transit longitude from these placements.
    final mappedChart = AstroChartResult(
      julianDay: natal.julianDay,
      ayanamsaDegrees: natal.ayanamsaDegrees,
      ascendantLongitude: mapped.ascendantSignIndex * 30.0 + 15.0,
      planets: List<PlanetPosition>.unmodifiable(mapped.planets.map((p) {
        final original = sourcePlanet[p.name]!;
        return PlanetPosition(
          name: p.name,
          shortName: p.shortName,
          longitude: p.signIndex * 30.0 + 15.0,
          latitude: original.latitude,
          speed: original.speed,
        );
      })),
      engineVersion: '${natal.engineVersion}:D$factor:$d16Method:sign-only-AV',
    );
    final selectedAv = factor == 1
        ? natalAv
        : AshtakavargaService.calculate(mappedChart);
    final lagna = mapped.ascendantSignIndex;
    final houses = List<VargaAvHouseEvidence>.generate(12, (index) {
      final sign = (lagna + index) % 12;
      final bav = <String, int>{};
      final pav = <String, List<String>>{};
      for (final planet in AshtakavargaService.planetOrder) {
        bav[planet] = selectedAv.bhinna[planet]![sign];
        pav[planet] = AshtakavargaPavCareerService.giversAt(
          selectedAv, planet, sign);
      }
      return VargaAvHouseEvidence(
        house: index + 1,
        signIndex: sign,
        sav: selectedAv.sarva[sign],
        bav: Map<String, int>.unmodifiable(bav),
        pavContributors: Map<String, List<String>>.unmodifiable(pav),
      );
    }, growable: false);
    final valid = natalAv.totalsValid && selectedAv.totalsValid &&
        natalAv.grandTotal == 337 && selectedAv.grandTotal == 337 &&
        natalAv.arithmetic.auditValid && selectedAv.arithmetic.auditValid &&
        AshtakavargaPavCareerService.audit(natalAv) &&
        AshtakavargaPavCareerService.audit(selectedAv) &&
        houses.every((h) => h.arithmeticValid);
    return VargaAshtakavargaReport(
      factor: factor,
      lagnaSignIndex: lagna,
      d16Method: d16Method,
      natal: natalAv,
      selected: selectedAv,
      houses: List<VargaAvHouseEvidence>.unmodifiable(houses),
      auditPassed: valid,
    );
  }
}
