// annapurna_all_rules_stubs.dart
// Combined file: All generated stubs + helpers for Annapurna Astro Vastu
// Sources: Original audit + annapurna.html + Sarala Jyotishya VII (V.P. Goel)
//
// Usage: SourceStubLiveSupport connects safe chart-derived inputs to selected
// functions. Other predicates remain PENDING until all inputs and source pages
// are verified. D16 sign mapping is ALREADY in varga_service.dart; DO NOT copy.
//
// Return values used: 'YES' | 'NO' | 'PENDING' | 'MIXED'

// =============================================================================
// 1. D16 CALCULATION (from annapurna.html — classical BPHS)
// =============================================================================

double d16Longitude(double siderealLon) {
  final x = _norm(siderealLon);
  final sign = (x / 30).floor();
  final degInSign = x - sign * 30;

  final trip = sign % 3; // 0=movable, 1=fixed, 2=dual
  final start = trip == 0 ? 0 : (trip == 1 ? 4 : 8); // Aries / Leo / Sagittarius

  return _mapPart(degInSign, 30 / 16, start);
}

double _mapPart(double degInSign, double partSize, int startSign) {
  final part = (degInSign / partSize).floor().clamp(0, (30 / partSize).floor() - 1);
  final rem = degInSign - part * partSize;
  final r = (startSign + part + 120) % 12;
  return r * 30 + rem * (30 / partSize);
}

double _norm(double x) {
  x = x % 360;
  if (x < 0) x += 360;
  return x;
}

// =============================================================================
// 2. STRENGTH HELPER
// =============================================================================

class StrengthHelper {
  /// Common “బలంగా” definition.
  /// Adjust as needed.
  static bool isStrong({
    required bool ownOrExaltedOrMoolatrikona,
    required bool inKendraOrTrikona,
    required bool noStrongMaleficAspectOrConjunction,
    double? shadbalaPercent,
  }) {
    final dignityOk = ownOrExaltedOrMoolatrikona || inKendraOrTrikona;
    final noAffliction = noStrongMaleficAspectOrConjunction;
    // Missing Shadbala is UNKNOWN, never a free pass to a strong verdict.
    final strengthOk = shadbalaPercent != null &&
        shadbalaPercent.isFinite && shadbalaPercent >= 60;
    return dignityOk && noAffliction && strengthOk;
  }

  /// Three-valued form: false means a fully supplied requirement failed,
  /// PENDING means a required quantitative strength input was not supplied.
  static String strengthStatus({
    required bool ownOrExaltedOrMoolatrikona,
    required bool inKendraOrTrikona,
    required bool noStrongMaleficAspectOrConjunction,
    double? shadbalaPercent,
  }) {
    if (!(ownOrExaltedOrMoolatrikona || inKendraOrTrikona) ||
        !noStrongMaleficAspectOrConjunction) return 'NO';
    if (shadbalaPercent == null || !shadbalaPercent.isFinite) return 'PENDING';
    return shadbalaPercent >= 60 ? 'YES' : 'NO';
  }
}

// =============================================================================
// 3. DIRECT RULES (29) — Original audit
// =============================================================================

class DirectRuleStubs {
  String verifyVargaGeneral004({
    required String d1Sign,
    required String targetVargaSign,
  }) =>
      d1Sign == targetVargaSign ? 'YES' : 'NO';

  String verifyVargaCross023({required int d9HouseFromLagna}) {
    const kendraTrikona = {1, 4, 5, 7, 9, 10};
    return kendraTrikona.contains(d9HouseFromLagna) ? 'YES' : 'NO';
  }

  String verifyDashaLordRule({
    required String dashaLord,
    required String expectedLord,
  }) =>
      dashaLord.toLowerCase() == expectedLord.toLowerCase() ? 'YES' : 'NO';

  String verifyDasha014({required bool hasBeneficAspectOrConjunctionOnDashaLord}) =>
      hasBeneficAspectOrConjunctionOnDashaLord ? 'YES' : 'NO';

  String verifyDasha015({required bool hasMaleficAspectOrConjunctionOnDashaLord}) =>
      hasMaleficAspectOrConjunctionOnDashaLord ? 'YES' : 'NO';

  String verifyDasha022({
    required bool ownsKendra,
    required bool ownsTrikona,
  }) =>
      (ownsKendra && ownsTrikona) ? 'YES' : 'NO';

  String verifyDasha026({required int bhuktiLordHouseFromMahadashaLord}) =>
      [6, 8, 12].contains(bhuktiLordHouseFromMahadashaLord) ? 'YES' : 'NO';

  String verifyDasha027({required bool hasExchangeBetween6_8_12Lords}) =>
      hasExchangeBetween6_8_12Lords ? 'YES' : 'NO';

  String verifyDasha028({required bool eighthLordDashaJustBeforeNewDasha}) =>
      eighthLordDashaJustBeforeNewDasha ? 'YES' : 'NO';

  String verifyDasha029({
    required String mahadashaLord,
    required String bhuktiLord,
  }) =>
      mahadashaLord == bhuktiLord ? 'YES' : 'NO';

  String verifyTiming001({required bool dashaOrBhuktiLordRelatedTo7thInD9}) =>
      dashaOrBhuktiLordRelatedTo7thInD9 ? 'YES' : 'NO';

  String verifyTiming002({required bool dashaLordRelatedTo10thInD10}) =>
      dashaLordRelatedTo10thInD10 ? 'YES' : 'NO';

  String verifyTiming003({required bool dashaLordRelatedTo5thInD7}) =>
      dashaLordRelatedTo5thInD7 ? 'YES' : 'NO';

  String verifyTiming004({required bool dashaLordHasMaleficRelationTo6thInD6OrD30}) =>
      dashaLordHasMaleficRelationTo6thInD6OrD30 ? 'YES' : 'NO';

  String verifyTiming008({required bool transitBeneficAspectOnNatalPlanets}) =>
      transitBeneficAspectOnNatalPlanets ? 'YES' : 'NO';

  String verifyProtocol010({required double savValue}) =>
      savValue.isFinite ? (savValue >= 28 ? 'YES' : 'NO') : 'PENDING';

  String verifyProtocol011({required double savValue}) =>
      savValue.isFinite ? (savValue < 25 ? 'YES' : 'NO') : 'PENDING';

  String verifyProtocol014({
    required double karakaShadbalaPercent,
    required double lordShadbalaPercent,
  }) =>
      (!karakaShadbalaPercent.isFinite || !lordShadbalaPercent.isFinite)
          ? 'PENDING'
          : (karakaShadbalaPercent > 60 && lordShadbalaPercent > 60)
              ? 'YES'
              : 'NO';

  String verifyStrength004({required bool allSixShadvargaHaveFullKshetraBala}) =>
      allSixShadvargaHaveFullKshetraBala ? 'YES' : 'NO';

  String verifyStrength006({required double shadbalaPercentFromPdfDefinition}) =>
      !shadbalaPercentFromPdfDefinition.isFinite ||
              shadbalaPercentFromPdfDefinition == 0
          ? 'PENDING'
          : shadbalaPercentFromPdfDefinition >= 60 ? 'YES' : 'NO';

  String verifyStrength007({required bool anyChartOrDignityUnknown}) =>
      anyChartOrDignityUnknown ? 'PENDING' : 'NO';
}

// =============================================================================
// 4. D11 + D16 (Sarala Jyotishya)
// =============================================================================

class SaralaD11D16Stubs {
  String d11LowEffortIncome({
    required bool karakamsa11thStrong,
    required bool hasRahuRelationTo11th,
    required bool hasGuruShukraRelation,
    required bool hasKetuOrGnatikaraka,
    required bool eleventhIsWeak,
  }) {
    if (eleventhIsWeak) return 'NO';
    if (karakamsa11thStrong && hasRahuRelationTo11th) return 'YES';
    if (hasGuruShukraRelation) return 'YES';
    if (hasKetuOrGnatikaraka) return 'YES';
    return 'PENDING';
  }

  String d11Disaster({
    required bool karakamsaLagnaStrong,
    required bool atmakarakaRelatedTo8th,
    required bool hasRajaYogaInD11,
    required bool eighthRelatedToKarakamsa,
  }) {
    if (!karakamsaLagnaStrong) return 'NO';
    if (atmakarakaRelatedTo8th && (hasRajaYogaInD11 || eighthRelatedToKarakamsa)) return 'YES';
    return 'PENDING';
  }

  String d11DeathIndication({
    required bool amatyakarakaInBadPosition,
    required bool tenthHouseOrLordAfflicted,
    required bool marsOrNodesInvolved,
    required bool saturnInvolved,
  }) {
    // Neither a death event nor a time of death follows from two booleans.
    // The remaining parameters are also necessary; do not claim YES/NO.
    return 'PENDING';
  }

  String d16SukhaBhoga({
    required bool karakamsaLagnaStrong,
    required bool hasGnatikarakaOrNodes,
    required bool putrakarakaStrong,
  }) {
    if (!karakamsaLagnaStrong) return 'NO';
    if (hasGnatikarakaOrNodes) return 'MIXED';
    if (putrakarakaStrong) return 'YES';
    return 'PENDING';
  }

  String d16Vehicle({
    required bool karakamsaLagnaStrong,
    required bool karakamsaLagnaLordStrong,
    required bool hasGnatikarakaOrNodes,
  }) {
    if (!karakamsaLagnaStrong || !karakamsaLagnaLordStrong) return 'NO';
    if (hasGnatikarakaOrNodes) return 'MIXED';
    return 'YES';
  }

  String d16AccidentOrTheft({
    required bool fourthRelatedTo6or8,
    required bool matrukarakaInvolvedWith6or8,
    required bool strongAfflictionOn4thOrMatrukaraka,
  }) {
    if ((fourthRelatedTo6or8 || matrukarakaInvolvedWith6or8) &&
        strongAfflictionOn4thOrMatrukaraka) return 'YES';
    return 'NO';
  }

  String d16LagnaShubha({required bool d16LagnaHasBeneficRelation}) =>
      d16LagnaHasBeneficRelation ? 'YES' : 'NO';

  String d16FourthShubha({required bool d16FourthHasBeneficRelation}) =>
      d16FourthHasBeneficRelation ? 'YES' : 'NO';

  String d16RajaYoga({required bool hasRajaYogaInD16}) =>
      hasRajaYogaInD16 ? 'YES' : 'NO';
}

// =============================================================================
// 5. OTHER QUALITATIVE (D7, D8, D9, D10)
// =============================================================================

class OtherQualitativeStubs {
  String d7Santana({
    required bool fifthHouseOrLordStrong,
    required bool putrakarakaStrong,
    required bool hasGnatikarakaOrNodesAffliction,
  }) {
    if (hasGnatikarakaOrNodesAffliction) return 'MIXED';
    if (fifthHouseOrLordStrong && putrakarakaStrong) return 'YES';
    return 'PENDING';
  }

  String d7LotteryOrGame({
    required bool hasRahuRelationTo11th,
    required bool d3CourageStrong,
    required bool d7FifthStrong,
  }) {
    if (hasRahuRelationTo11th) return 'YES';
    if (d3CourageStrong && d7FifthStrong) return 'YES';
    return 'NO';
  }

  String d8SuddenOrChronic({
    required bool eighthRelatedToMarsOrNodes,
    required bool saturnInvolved,
  }) {
    if (eighthRelatedToMarsOrNodes || saturnInvolved) return 'YES';
    return 'NO';
  }

  String d8Samadhi({required bool karakamsaSadhanaStrong}) =>
      karakamsaSadhanaStrong ? 'YES' : 'NO';

  String d9Vivaha({
    required bool seventhOrLordOrDarakarakaStrong,
    required bool hasGnatikarakaOrNodesAffliction,
    required bool hasRajaYogaOn7th,
  }) {
    if (hasGnatikarakaOrNodesAffliction) return 'NO';
    if (seventhOrLordOrDarakarakaStrong || hasRajaYogaOn7th) return 'YES';
    return 'PENDING';
  }

  String d9Dharma({
    required bool ninthHouseOrLordOrGuruStrong,
    required bool hasAfflictionOn9th,
  }) {
    if (hasAfflictionOn9th) return 'NO';
    if (ninthHouseOrLordOrGuruStrong) return 'YES';
    return 'PENDING';
  }

  String d10StatusAndFame({
    required bool karakamsaAnd10thYoga,
    required bool amatyakarakaStrong,
  }) =>
      (karakamsaAnd10thYoga && amatyakarakaStrong) ? 'YES' : 'NO';

  String d10DisgraceOrFall({
    required bool tenthOrAmatyakarakaAfflictedByNodesOrDusthana,
    required bool strongAffliction,
  }) {
    if (tenthOrAmatyakarakaAfflictedByNodesOrDusthana) {
      return strongAffliction ? 'YES' : 'MIXED';
    }
    return 'NO';
  }

  String d10RiseOrFallByDasha({
    required bool dashaPlanetHasShubhaWith10thOrAmatyakaraka,
    required bool dashaRelatedToGnatikarakaOr8th,
  }) {
    if (dashaRelatedToGnatikarakaOr8th) return 'NO';
    if (dashaPlanetHasShubhaWith10thOrAmatyakaraka) return 'YES';
    return 'PENDING';
  }
}

// =============================================================================
// END OF COMBINED FILE
// =============================================================================
