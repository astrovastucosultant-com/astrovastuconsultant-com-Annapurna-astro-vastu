import 'd10_vrutti_match_engine.dart';

/// Routes only FULLY evaluated D10 source IF-THEN rule matches to a specific
/// career topic. A profession label / table-of-contents entry alone does not
/// establish a matched outcome. No source-less profit/loss or timeline claims.
class D10TopicRuleBridge {
  D10TopicRuleBridge._();

  static const _financeWords = <String>[
    'బ్యాంక', 'ఫైనాన్స్', 'ఫైనాన్స', 'లోన్', 'రుణ', 'మనీ లెండ',
    'చిట్ ఫండ్', 'అకౌంట', 'ఆడిట', 'స్టాక్ బ్రోక', 'షేరు',
    'క్రిప్టో', 'ఇన్సూరెన్స్', 'సి.ఎ', 'టాక్స్',
  ];
  static const _technicalWords = <String>[
    'ఇంజినీర', 'ఇంజనీర', 'టెక్నిక', 'ఎలక్ట్ర', 'మెకానిక',
    'సివిల్', 'సాఫ్ట్‌వేర్', 'సాఫ్ట్ వేర్', 'ఐటీ', 'సైబర్',
    'కంప్యూట', 'రోబోట', 'నెట్‌వర్క', 'హార్డ్‌వేర్',
  ];
  static const _medicalEducationWords = <String>[
    'డాక్టర్', 'డెంటిస్ట్', 'నర్సు', 'మెడిక', 'ఫార్మ',
    'థెరపీ', 'ఆయుర్వేద', 'హోమియో', 'ల్యాబ్', 'ఎక్స్‌రే',
    'టీచ', 'అధ్యాప', 'ఉపాధ్యా', 'లెక్చర', 'ప్రొఫెస',
  ];

  static bool _containsAny(String value, List<String> terms) {
    final normalized = value.toLowerCase();
    return terms.any((term) => normalized.contains(term.toLowerCase()));
  }

  /// Display routing only, not profession prediction.
  static bool _belongsToTopic(String title, String profession) {
    switch (title) {
      case 'బ్యాంకింగ్ / ఫైనాన్స్':
        return _containsAny(profession, _financeWords);
      case 'టెక్నికల్ / ఇంజినీరింగ్':
        return _containsAny(profession, _technicalWords);
      case 'వైద్యం / విద్య / సేవారంగాలు':
        return _containsAny(profession, _medicalEducationWords);
      default:
        return false;
    }
  }

  /// Source-backed FULL matches appear as horoscope results.
  static List<D10VruttiMatch> forTopic(
      String title, Iterable<D10VruttiMatch> matches) =>
      List<D10VruttiMatch>.unmodifiable(matches.where((m) =>
          m.fullRuleMatched && _belongsToTopic(title, m.rule.profession)));

  /// Incomplete and failed source rules are audit only, never highlighted as
  /// established occupations. This ensures 0 matches != 0 linked predicates.
  static List<D10VruttiMatch> auditForTopic(
      String title, Iterable<D10VruttiMatch> matches) =>
      List<D10VruttiMatch>.unmodifiable(matches.where((m) =>
          !m.fullRuleMatched && _belongsToTopic(title, m.rule.profession)));
}
