import 'astro_models.dart';
import 'ashtakavarga_service.dart';
import 'd10_career_service.dart';

/// Prastara (PAV) contributor-level career evidence.
/// A contributor bindu is a 0/1 relationship in a BAV recipient table;
/// it does not by itself measure absolute graha strength or promise a job.
/// Year timing is inherited ONLY from a separately computed Dasha window.
class AvPavPlanetCareer {
  final String planet;
  final int natalBindus;
  final int careerBindus;
  final int gainBindus;
  final int sixthBindus;
  final int careerSav;
  final int gainSav;
  final List<String> careerGivers;
  final List<String> gainGivers;

  const AvPavPlanetCareer({
    required this.planet,
    required this.natalBindus,
    required this.careerBindus,
    required this.gainBindus,
    required this.sixthBindus,
    required this.careerSav,
    required this.gainSav,
    required this.careerGivers,
    required this.gainGivers,
  });

  String get careerSignal {
    if (careerBindus >= 5 && careerSav >= 28) return '10వ భావానికి బలమైన అష్టకవర్గ మద్దతు';
    if (careerBindus <= 3 || careerSav < 25) return '10వ భావ మద్దతు బలహీనంగా ఉంది';
    return '10వ భావ మద్దతు మధ్యస్థంగా ఉంది';
  }

  String get gainSignal {
    if (gainBindus >= 5 && gainSav >= 28) return '11వ భావ లాభ సూచనకు మద్దతు';
    if (gainBindus <= 3 || gainSav < 25) return '11వ భావ లాభ మద్దతు పరిమితంగా ఉంది';
    return '11వ భావ మద్దతు మధ్యస్థంగా ఉంది';
  }
}

class AvPavPeriodCareer {
  final bool valid;
  final List<AvPavPlanetCareer> lords;
  final List<String> notCovered;
  final String note;
  const AvPavPeriodCareer({
    required this.valid,
    required this.lords,
    required this.notCovered,
    required this.note,
  });
}

class AvPavTransitKakshya {
  final String planet;
  final int signIndex;
  final int kakshyaIndex;
  final String giver;
  final double startDegree;
  final double endDegree;
  final bool hasBindu;
  const AvPavTransitKakshya({
    required this.planet,
    required this.signIndex,
    required this.kakshyaIndex,
    required this.giver,
    required this.startDegree,
    required this.endDegree,
    required this.hasBindu,
  });
}

class AshtakavargaPavCareerService {
  // Standard seven-target raw PAV and eight kakshya givers. No Rahu/Ketu row.
  static const List<String> kakshyaGivers = [
    'Saturn', 'Jupiter', 'Mars', 'Sun', 'Venus',
    'Mercury', 'Moon', 'Lagna',
  ];
  static const List<String> contributors = [
    'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter',
    'Venus', 'Saturn', 'Lagna',
  ];

  static int houseSign(AstroChartResult chart, int house) =>
      (chart.ascendantSignIndex + house - 1) % 12;

  static bool audit(AshtakavargaResult av) {
    if (!av.totalsValid || av.grandTotal != 337) return false;
    for (final recipient in AshtakavargaService.planetOrder) {
      final rows = av.prastara[recipient];
      final bav = av.bhinna[recipient];
      if (rows == null || bav == null || bav.length != 12 ||
          rows.length != 8 || !contributors.every(rows.containsKey)) return false;
      for (var sign = 0; sign < 12; sign++) {
        var sum = 0;
        for (final giver in contributors) {
          final row = rows[giver];
          if (row == null || row.length != 12) return false;
          final bindu = row[sign];
          if (bindu != 0 && bindu != 1) return false;
          sum += bindu;
        }
        if (sum != bav[sign]) return false;
      }
    }
    return true;
  }

  static List<String> giversAt(AshtakavargaResult av,
      String recipient, int signIndex) {
    final rows = av.prastara[recipient];
    if (rows == null || signIndex < 0 || signIndex > 11) return const [];
    return List<String>.unmodifiable(contributors.where((giver) =>
        rows[giver] != null && rows[giver]![signIndex] == 1));
  }

  static AvPavPlanetCareer? planetEvidence({
    required AstroChartResult chart,
    required AshtakavargaResult av,
    required String planet,
  }) {
    if (!AshtakavargaService.planetOrder.contains(planet) || !audit(av)) {
      return null;
    }
    final positions = chart.planets.where((p) => p.name == planet).toList();
    if (positions.length != 1) return null;
    final s10 = houseSign(chart, 10);
    final s11 = houseSign(chart, 11);
    final s6 = houseSign(chart, 6);
    final values = av.bhinna[planet]!;
    return AvPavPlanetCareer(
      planet: planet,
      natalBindus: values[positions.single.signIndex],
      careerBindus: values[s10], gainBindus: values[s11],
      sixthBindus: values[s6], careerSav: av.sarva[s10],
      gainSav: av.sarva[s11],
      careerGivers: giversAt(av, planet, s10),
      gainGivers: giversAt(av, planet, s11),
    );
  }

  static AvPavPeriodCareer periodEvidence({
    required AstroChartResult chart,
    required AshtakavargaResult av,
    required String mahadasha,
    required String antardasha,
  }) {
    if (!audit(av)) {
      return const AvPavPeriodCareer(valid: false, lords: [],
          notCovered: [], note: 'PAV / BAV సమగ్రత తనిఖీ విజయవంతం కాలేదు.');
    }
    final names = <String>[];
    final missed = <String>[];
    for (final lord in [mahadasha, antardasha]) {
      if (AshtakavargaService.planetOrder.contains(lord)) {
        if (!names.contains(lord)) names.add(lord);
      } else if (!missed.contains(lord)) {
        missed.add(lord);
      }
    }
    final matched = <AvPavPlanetCareer>[];
    for (final lord in names) {
      final evidence = planetEvidence(chart: chart, av: av, planet: lord);
      if (evidence != null) matched.add(evidence);
      else missed.add(lord);
    }
    return AvPavPeriodCareer(
      valid: true,
      lords: List.unmodifiable(matched),
      notCovered: List.unmodifiable(missed),
      note: 'ఈ సంవత్సరం కోసం కాలపరిమితి దశా Engine నుంచి మాత్రమే వచ్చింది. '
          'PAV 10/11 భావాల మద్దతును క్రాస్-చెక్ చేస్తుంది; '
          'ప్రమోషన్/ఉద్యోగనష్టం స్వతంత్రంగా నిర్ధారించదు.',
    );
  }

  static List<AvPavPlanetCareer> natalCareerPlanets({
    required AstroChartResult chart,
    required AshtakavargaResult av,
  }) {
    final tenthLord = D10CareerService.signLord(houseSign(chart, 10));
    final eleventhLord = D10CareerService.signLord(houseSign(chart, 11));
    final planets = <String>{'Sun','Saturn', tenthLord, eleventhLord};
    return List.unmodifiable(planets.map((p) =>
        planetEvidence(chart: chart, av: av, planet: p))
        .whereType<AvPavPlanetCareer>());
  }

  /// Needs a real *sidereal* transit longitude, not a date inferred from natal PAV.
  /// Do not call with natal longitude when claiming a current transit prediction.
  static AvPavTransitKakshya? atTransit({
    required AshtakavargaResult av,
    required String recipient,
    required double siderealTransitLongitude,
  }) {
    if (!audit(av) || !AshtakavargaService.planetOrder.contains(recipient) ||
        !siderealTransitLongitude.isFinite) return null;
    final normalized = ((siderealTransitLongitude % 360.0) + 360.0) % 360.0;
    final sign = (normalized / 30.0).floor() % 12;
    final index = AshtakavargaService.kakshyaIndex(normalized);
    final giver = kakshyaGivers[index - 1];
    final range = AshtakavargaService.kakshyaRange(index);
    return AvPavTransitKakshya(
      planet: recipient, signIndex: sign, kakshyaIndex: index,
      giver: giver, startDegree: range.start, endDegree: range.end,
      hasBindu: av.prastara[recipient]![giver]![sign] == 1,
    );
  }
}
