import 'annapurna_all_rules_stubs.dart';
import 'ashtakavarga_service.dart';
import 'astro_models.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';
import 'varga_topic_catalog.dart';
import 'varga_unified_rule_service.dart';

/// Connects the submitted 39-method stub file to REAL natal/chart inputs.
///
/// Only source-identified, fully checked conditions may enter the green/pink
/// result path. Unlocated Sarala/Goel stub pages are displayed as *auditable
/// observations* and never asserted as source-verified event outcomes.
class VargaSourceStubLiveSupport {
  VargaSourceStubLiveSupport._();

  static const _benefics = <String>{'Jupiter', 'Venus', 'Mercury', 'Moon'};
  static const _malefics = <String>{'Sun', 'Mars', 'Saturn', 'Rahu', 'Ketu'};
  static const _lords = <String>['Mars', 'Venus', 'Mercury', 'Moon',
      'Sun', 'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter'];
  static const _exaltSigns = <String, int>{'Sun': 0, 'Moon': 1, 'Mars': 9,
      'Mercury': 5, 'Jupiter': 3, 'Venus': 11, 'Saturn': 6};
  static const _signNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  static AshtakavargaResult? natalSavIfAvailable(AstroChartResult natal) {
    const seven = <String>{
      'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn',
    };
    final available = natal.planets.map((p) => p.name).toSet();
    if (!available.containsAll(seven)) return null;
    try {
      final data = AshtakavargaService.calculate(natal);
      return data.totalsValid ? data : null;
    } catch (_) {
      return null;
    }
  }

  /// Original PDF page 1, VARGA-GENERAL-004: compare each planet's D1 sign
  /// with the same planet in the selected divisional chart.
  /// D1 alone is NOT a cross-varga comparison, so no duplicate D1 assertion.
  static UnifiedVargaRule? vargottama(AstroChartResult natal,
      VargaChartData varga) {
    final factor = varga.definition.factor;
    if (factor == 1) return null;
    final d1 = {for (final p in natal.planets) p.name: p.signIndex};
    final fn = DirectRuleStubs();
    final matches = <String>[];
    final examined = <String>[];
    for (final p in varga.planets) {
      final natalSign = d1[p.name];
      if (natalSign == null) continue;
      examined.add(p.name);
      if (fn.verifyVargaGeneral004(
          d1Sign: _signNames[natalSign],
          targetVargaSign: _signNames[p.signIndex]) == 'YES') {
        matches.add('${p.name} (${_signNames[p.signIndex]})');
      }
    }
    if (examined.isEmpty) return null;
    return UnifiedVargaRule(
      id: 'VARGA-GENERAL-004/D$factor',
      group: 'GENERAL',
      groupTitle: 'సాధారణ మూల నియమం',
      topic: 'వర్గోత్తమ గ్రహబలం — D1 / D$factor',
      condition: 'ఒకే గ్రహం D1, D$factor రెండింటిలో ఒకే రాశిలో ఉండాలి.',
      outcome: 'సరిపోయిన గ్రహాలకు వర్గోత్తమ బల/స్థిరత్వ మద్దతు. '
          'ఇది ఒక్కటే ఏ సంఘటనకు తుది నిర్ధారణ కాదు.',
      source: 'షోడశ వర్గాలు — మల్లికార్జున అందించిన 42 పేజీల PDF · పేజీ 1 '
          '(VARGA-GENERAL-004)',
      evidence: 'D1 / D$factorలో ${examined.length} గ్రహాలు పోల్చాం. '
          'ఒకే రాశిలో ఉన్నవి: ${matches.isEmpty ? 'లేవు' : matches.join(', ')}.',
      status: matches.isNotEmpty
          ? UnifiedVargaRuleStatus.matched
          : UnifiedVargaRuleStatus.notMatched,
      tone: UnifiedVargaRuleTone.favorable,
    );
  }

  /// Page 38 SAV source rules, using NATAL D1 sign SAV, never D10 SAV.
  /// Expose only at a dedicated relevant topic to prevent hundreds of
  /// repeated generic score cards across all 176 topics.
  static List<UnifiedVargaRule> natalSavForTopic(
      AstroChartResult natal, VargaTopic topic,
      AshtakavargaResult? sav, {required int factor}) {
    final active = factor == 1 || (factor == 10 &&
        topic.title.contains('SAV'));
    if (!active) return const <UnifiedVargaRule>[];
    final sign = (natal.ascendantSignIndex + topic.house - 1) % 12;
    final value = sav?.sarva[sign];
    final direct = DirectRuleStubs();
    final good = value == null ? 'PENDING' :
        direct.verifyProtocol010(savValue: value.toDouble());
    final weak = value == null ? 'PENDING' :
        direct.verifyProtocol011(savValue: value.toDouble());
    UnifiedVargaRule build({required bool favorable, required String verdict}) {
      final id = favorable ? 'VARGA-PROTOCOL-010' : 'VARGA-PROTOCOL-011';
      return UnifiedVargaRule(
        id: '$id/D$factor/H${topic.house}/${topic.title}',
        group: 'PROTOCOL',
        groupTitle: 'జన్మ D1 SAV మద్దతు',
        topic: favorable ? 'D1 SAV అనుకూల బలం' : 'D1 SAV తక్కువ బలం',
        condition: favorable
            ? 'పరిశీలన భావం/రాశి SAV ≥ 28 అయితే.'
            : 'పరిశీలన భావం/రాశి SAV < 25 అయితే.',
        outcome: favorable
            ? 'ఈ D1 రాశిలో SAV బలం అనుకూల సూచన. '
                'ఇది సంబంధిత వర్గ సంఘటనకు తుది నిర్ధారణ కాదు.'
            : 'ఈ D1 రాశిలో SAV మద్దతు తక్కువగా ఉందనే '
                'సంప్రదాయ సూచన; సంఘటన నిశ్చయం కాదు.',
        source: 'షోడశ వర్గాలు — మల్లికార్జున అందించిన 42 పేజీల PDF · పేజీ 38 ($id)',
        evidence: 'అంశం: ${topic.title}. జన్మ D1 ${topic.house}వ భావం '
            '(${_signNames[sign]}) SAV = ${value ?? 'తెలియదు'}. '
            '${sav == null ? 'పూర్తి అష్టకవర్గ గణన అందుబాటులో లేదు.' : 'SAV మొత్తం తనిఖీ PASS.'} '
            'ఈ స్కోర్ D1కి చెందినది; D$factor వర్గ SAV అని పరిగణించరాదు.',
        status: switch (verdict) {
          'YES' => UnifiedVargaRuleStatus.matched,
          'NO' => UnifiedVargaRuleStatus.notMatched,
          _ => UnifiedVargaRuleStatus.pending,
        },
        tone: favorable
            ? UnifiedVargaRuleTone.favorable
            : UnifiedVargaRuleTone.adverse,
      );
    }
    return <UnifiedVargaRule>[
      build(favorable: true, verdict: good),
      build(favorable: false, verdict: weak),
    ];
  }

  static bool _aspects(String planet, int targetSign, Map<String, int> p) {
    final s = p[planet];
    if (s == null || planet == 'Rahu' || planet == 'Ketu') return false;
    final d = ((targetSign - s + 12) % 12) + 1;
    return d == 7 ||
        (planet == 'Mars' && (d == 4 || d == 8)) ||
        (planet == 'Jupiter' && (d == 5 || d == 9)) ||
        (planet == 'Saturn' && (d == 3 || d == 10));
  }

  static bool _relation(String planet, int targetSign, Map<String, int> p) =>
      p[planet] == targetSign || _aspects(planet, targetSign, p);

  /// Unlocated predicates in the user's Dart file: computed where possible,
  /// but evidence is PENDING until the corresponding Goel/Sarala page and ALL
  /// qualitative premises are available. The row stays visible, not green.
  static List<UnifiedVargaRule> supplementaryObservations(
      AstroChartResult natal, VargaChartData varga) {
    final factor = varga.definition.factor;
    final placements = {for (final p in varga.planets) p.name: p.signIndex};
    final asc = varga.ascendantSignIndex;
    final house4 = (asc + 3) % 12;
    final lagnaBenefics = _benefics.where((p) => _relation(p, asc, placements))
        .toList(growable: false);
    final fourthBenefics = _benefics.where((p) => _relation(p, house4, placements))
        .toList(growable: false);
    final stubs = SaralaD11D16Stubs();
    final qualitative = OtherQualitativeStubs();
    final house6 = (asc + 5) % 12;
    final house8 = (asc + 7) % 12;
    final house9 = (asc + 8) % 12;
    final house10 = (asc + 9) % 12;
    bool maleficTouches(int sign, String name) =>
        _malefics.where((p) => p != name && _relation(p, sign, placements)).isNotEmpty;
    final output = <UnifiedVargaRule>[];
    void add(String key, String topic, String condition, String observation) {
      output.add(UnifiedVargaRule(
        id: 'USER-STUB-$key',
        group: 'USER-STUB',
        groupTitle: 'అనుబంధ పరిశీలన',
        topic: topic,
        condition: condition,
        outcome: 'మూల పుస్తక పేజీ, పూర్తి గ్రహబల ప్రమాణం '
            'ధృవీకరించిన తరువాత మాత్రమే తుది ఫలితం.',
        source: 'అందించిన annapurna_all_rules_stubs.dart · '
            'Goel/Sarala మూల పేజీ నిర్ధారణ పెండింగ్',
        evidence: observation,
        status: UnifiedVargaRuleStatus.pending,
        tone: UnifiedVargaRuleTone.neutral,
      ));
    }
    if (factor == 16) {
      final lagna = stubs.d16LagnaShubha(
          d16LagnaHasBeneficRelation: lagnaBenefics.isNotEmpty);
      final fourth = stubs.d16FourthShubha(
          d16FourthHasBeneficRelation: fourthBenefics.isNotEmpty);
      add('D16-LAGNA-SHUBHA', 'షోడశాంశ లగ్న శుభ సంబంధం',
          'D16 లగ్నానికి శుభగ్రహ యుతి లేదా పరాశరి దృష్టి.',
          'D16 లగ్నం ${_signNames[asc]}; శుభ సంబంధం: '
          '${lagnaBenefics.isEmpty ? 'లేదు' : lagnaBenefics.join(', ')}. '
          'సమర్పించిన స్టబ్ గణన: $lagna. మూల ధృవీకరణ అవసరం.');
      add('D16-FOURTH-SHUBHA', 'షోడశాంశ 4వ భావ శుభ సంబంధం',
          'D16 4వ భావానికి శుభగ్రహ యుతి లేదా పరాశరి దృష్టి.',
          '4వ భావం ${_signNames[house4]}; శుభ సంబంధం: '
          '${fourthBenefics.isEmpty ? 'లేదు' : fourthBenefics.join(', ')}. '
          'సమర్పించిన స్టబ్ గణన: $fourth. మూల ధృవీకరణ అవసరం.');
      // Matrukaraka is obtained from the *existing* Jaimini calculations.
      // A complete source strength threshold is unavailable, so this may
      // only be a preliminary conjunction/aspect observation.
      final j = JaiminiService.calculate(natal);
      final mk = j.charaKarakas.where((k) => k.code == 'MK').toList();
      final mkSign = mk.isEmpty ? null : placements[mk.first.planet];
      final l4 = _lords[house4];
      final l6 = _lords[house6];
      final l8 = _lords[house8];
      final fourthRelatedTo6or8 = placements[l4] == house6 ||
          placements[l4] == house8 || placements[l6] == house4 ||
          placements[l8] == house4;
      final mkRelated = mkSign != null && (mkSign == house6 || mkSign == house8);
      final afflicted = maleficTouches(house4, l4) ||
          (mkSign != null && maleficTouches(mkSign, mk.first.planet));
      final accident = stubs.d16AccidentOrTheft(
        fourthRelatedTo6or8: fourthRelatedTo6or8,
        matrukarakaInvolvedWith6or8: mkRelated,
        strongAfflictionOn4thOrMatrukaraka: afflicted,
      );
      add('D16-FOURTH-OBSTACLE', 'వాహన ఆటంకాల అనుబంధ పరిశీలన',
          '4వ భావ–6/8 సంబంధం లేదా మాతృకారక–6/8 సంబంధం, '
          'దానితో పాటు తీవ్రమైన పీడ.',
          'D16 4L $l4–6/8: $fourthRelatedTo6or8; '
          'మాతృకారక ${mk.isEmpty ? 'తెలియదు' : mk.first.planet}–6/8: $mkRelated; '
          'పీడ సూచన: $afflicted; స్టబ్ గణన: $accident. '
          'తీవ్ర పీడ ప్రమాణం ఇంకా మూలగ్రంథంతో ధృవీకరించలేదు.');
    }
    if (factor == 7) {
      final eleventh = (asc + 10) % 12;
      final rahuOccupies11 = placements['Rahu'] == eleventh;
      final speculation = rahuOccupies11
          ? qualitative.d7LotteryOrGame(
              hasRahuRelationTo11th: true,
              d3CourageStrong: false, d7FifthStrong: false)
          : 'PENDING';
      add('D7-SPECULATION', 'స్పెక్యులేషన్ సహాయక పరిశీలన',
          'D7 లాభ భావానికి రాహు సంబంధం, లేదా D3/D7 బల సంయోగం.',
          'D7 లాభ భావం ${_signNames[eleventh]}; '
          'రాహు అక్కడ ఉన్నాడా: $rahuOccupies11. '
          'స్టబ్‌లో పరీక్షించిన ప్రత్యక్ష శాఖ: $speculation. '
          'ఇతర రాహు సంబంధాలు, D3/D7 పూర్తి బల ప్రమాణాలు '
          'ఇంకా ధృవీకరించాలి; లాటరీ విజయం అని ప్రకటించరాదు.');
    }
    if (factor == 8) {
      final marsOrNodes = <String>{'Mars', 'Rahu', 'Ketu'}
          .any((p) => _relation(p, house8, placements));
      final saturn = _relation('Saturn', house8, placements);
      final signal = qualitative.d8SuddenOrChronic(
        eighthRelatedToMarsOrNodes: marsOrNodes,
        saturnInvolved: saturn,
      );
      add('D8-SUDDEN-CHANGE', 'ఆకస్మిక మార్పుల సహాయక పరిశీలన',
          '8వ భావానికి కుజ/రాహు/కేతు సంబంధం లేదా శని సంబంధం.',
          'D8 8వ భావం ${_signNames[house8]}; కుజ/నోడ్స్: $marsOrNodes; '
          'శని: $saturn; స్టబ్ గణన: $signal. '
          'మూల పేజీ లేక సంఘటన నిర్ధారణ కాదు.');
    }
    if (factor == 9) {
      final l9 = _lords[house9];
      final l9Sign = placements[l9];
      final guruSign = placements['Jupiter'];
      final ninthSupport = (l9Sign != null &&
              (l9Sign == house9 || _exaltSigns[l9] == l9Sign)) ||
          (guruSign != null &&
              (guruSign == 8 || _exaltSigns['Jupiter'] == guruSign));
      final ninthAfflicted = _malefics.any((p) => _relation(p, house9, placements));
      final status = qualitative.d9Dharma(
        ninthHouseOrLordOrGuruStrong: ninthSupport,
        hasAfflictionOn9th: ninthAfflicted,
      );
      add('D9-DHARMA', 'ధర్మ భావ అనుబంధ పరిశీలన',
          'D9 9వ భావ/అధిపతి/గురు బలం మరియు పీడ పరిశీలన.',
          'D9 9వ భావం ${_signNames[house9]}, 9L $l9; '
          'స్వ/ఉచ్చ స్థితి మద్దతు: $ninthSupport; '
          '9వ భావానికి పాప సంబంధం: $ninthAfflicted; '
          'స్టబ్ గణన: $status. పూర్తి బల ప్రమాణం ఇంకా పెండింగ్.');
    }
    if (factor == 10) {
      final tenth = house10;
      add('D10-KARAKA-STATUS', 'వృత్తి స్థాయి / అమాత్యకారక పరిశీలన',
          'కారకాంశ–10వ భావ యోగం మరియు అమాత్యకారక బలం రెండూ.',
          'D10 లగ్నం ${_signNames[asc]}, 10వ భావం ${_signNames[tenth]}. '
          'కారకాంశ యోగం, అమాత్యకారక బలం పూర్తి పరీక్ష లేక '
          'ఈ స్టబ్ ఫలితం పెండింగ్.');
      final hasObstruction = _malefics.any((p) => _relation(p, tenth, placements));
      final observed = qualitative.d10DisgraceOrFall(
        tenthOrAmatyakarakaAfflictedByNodesOrDusthana: hasObstruction,
        strongAffliction: hasObstruction &&
            _malefics.where((p) => _relation(p, tenth, placements)).length >= 2,
      );
      add('D10-OBSTACLE', 'వృత్తి ఆటంకాల అనుబంధ పరిశీలన',
          '10వ భావం లేదా అమాత్యకారకుడిపై పీడ; బలమైన పీడ అయితే అదనపు జాగ్రత్త.',
          'D10 10వ భావం ${_signNames[tenth]}; పాప సంబంధం: $hasObstruction; '
          'స్టబ్ గణన: $observed. అమాత్యకారక పూర్తి బలం, మూల పేజీ '
          'అందుబాటులో లేక పతనం అని ప్రకటించలేదు.');
    }
    return output;
  }
}
