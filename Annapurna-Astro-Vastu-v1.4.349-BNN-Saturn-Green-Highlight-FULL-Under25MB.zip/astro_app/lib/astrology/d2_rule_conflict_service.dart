/// A matched source condition is not automatically a final, unique prediction.
/// Some traditional source conditions are simultaneously true and point in
/// opposite directions. Preserve BOTH source hits, but withhold a categorical
/// final answer until a source-backed conflict priority rule is available.
class D2RuleConflict {
  final String id;
  final String topic;
  final String explanation;
  final Set<String> matchedRuleIds;

  const D2RuleConflict({
    required this.id,
    required this.topic,
    required this.explanation,
    required this.matchedRuleIds,
  });
}

class D2RuleConflictService {
  static List<D2RuleConflict> detect(Set<String> matchedRuleIds) {
    final out = <D2RuleConflict>[];

    void check({
      required String id,
      required String topic,
      required Set<String> favorable,
      required Set<String> adverse,
      required String explanation,
    }) {
      final a = matchedRuleIds.intersection(favorable);
      final b = matchedRuleIds.intersection(adverse);
      if (a.isEmpty || b.isEmpty) return;
      out.add(D2RuleConflict(
        id: id,
        topic: topic,
        explanation: explanation,
        matchedRuleIds: {...a, ...b},
      ));
    }

    check(
      id: 'D2-CONFLICT-VEHICLE',
      topic: 'వాహనాలు',
      favorable: const {
        'D2-VH-001', 'D2-VH-003', 'D2-VH-004', 'D2-VH-005',
      },
      adverse: const {'D2-VH-006'},
      explanation: 'వాహనం సమకూరే సూచనలు మరియు వాహనం లేకపోయే సూచన రెండూ మ్యాచ్ అయ్యాయి. '
          'D1లోని 4వ భావం/అధిపతి, శుక్రుడి బలం, D16 షోడశాంశ ధృవీకరణను మూల నియమాలతో '
          'పోల్చకుండా వాహనాల సంఖ్య లేదా లేమి అని తుది నిర్ణయం ఇవ్వకూడదు.',
    );
    check(
      id: 'D2-CONFLICT-PROPERTY',
      topic: 'స్థిరాస్తి / ఇల్లు / భూమి',
      favorable: const {'D2-PR-001', 'D2-PR-002', 'D2-PR-003', 'D2-PR-007'},
      adverse: const {'D2-PR-005'},
      explanation: 'స్థిరాస్తి సమకూరే సూచనలు మరియు స్థిరాస్తి లేకపోయే సూచన రెండూ మ్యాచ్ అయ్యాయి. '
          'D1/D4 ఆధారాలకు మధ్య విరుద్ధత ఉంది; మూలాధారంతో మరింత పరిశీలన అవసరం.',
    );
    return out;
  }
}
