import 'varga_topic_catalog.dart';

/// Links *already-existing* source rule IDs to the on-screen varga topics.
/// Navigation and rule evaluation are deliberately separate. A link NEVER
/// promotes an untested source rule to a verified natal prediction.
class VargaTopicRuleLinker {
  VargaTopicRuleLinker._();

  // Index = source rule numeric suffix - 1; value = corresponding topic index.
  // -1 means there is no honest equivalent among the 176 topic titles. Such
  // rules stay visible under the same chart's 'unassigned source rules' section.
  // This is a navigation map, NOT newly-authored classical IF–THEN rules.
  static const Map<int, List<int>> _sourceTopicByFactor = {
    2: [1, 1, 1, 0, 3, 3, 7],
    3: [1, 1, 1, 2, 2],
    4: [0, 1, 6, 4, 3],
    5: [1, -1, 0, 4],
    6: [3, 4, 4, 4, -1, -1],
    7: [0, -1, -1, 0, 6, 6, 5],
    8: [-1, -1, 0, -1, 5],
    9: [0, 0, 2, 0, -1, -1, 2, 4, 2, 7],
    10: [25, 25, 25, 6, 0, 10, 14, 17],
    12: [0, 1, 0, 0, 0, 1, 0, 3, 2, 6, 3, 3],
    16: [1, 3, 3, 3, 2],
    20: [0, 0, 3],
    24: [6, 7, 6, 4, 4, 4],
    27: [0, -1, 6],
    30: [1, -1, 2, -1],
    40: [0, 3],
    45: [0, 2],
    60: [0, 0, 0],
  };

  /// An explicit source ID is more reliable than guessing from words such as
  /// 'loss', which may refer to a house, property, business or a health rule.
  static int? sourceIndex(int factor, String ruleId, int topicCount) {
    final match = RegExp(r'^VARGA-D(\d+)-(\d{3})$').firstMatch(ruleId);
    if (match == null || int.tryParse(match.group(1)!) != factor) return null;
    final seq = int.parse(match.group(2)!) - 1;
    final indices = _sourceTopicByFactor[factor];
    if (indices == null || seq < 0 || seq >= indices.length) return null;
    final index = indices[seq];
    return index >= 0 && index < topicCount ? index : null;
  }

  /// Explicit references to cross-varga source rules. The values are primary
  /// topic indices in the relevant chart; source workflows remain method-only
  /// until the original evaluator verifies all conditions.
  static const Map<int, Map<int, int>> _crossTopics = {
    1: {1:10, 2:10, 3:10, 4:6, 5:4, 6:4, 7:1, 8:7, 9:3,
      10:6, 11:11, 12:5, 13:8, 14:10, 15:3, 16:10, 17:10,
      18:10, 22:10, 27:10, 31:6, 33:6, 35:4, 38:4,
      42:1, 45:7, 48:3, 51:6, 54:11, 58:5, 61:8, 65:10, 68:3},
    2: {3:1, 9:4, 29:0},
    4: {9:0, 11:4, 15:6, 49:0, 57:4, 69:6},
    6: {7:0, 12:4, 43:0, 59:4},
    7: {5:0, 36:0},
    9: {1:9, 2:9, 3:10, 4:0, 10:2, 19:9, 23:9,
      32:0, 33:0, 52:2, 62:7, 67:8},
    10: {1:6, 2:7, 3:0, 14:8, 20:6, 21:7,
      24:7, 28:0, 56:17, 66:8},
    12: {9:2, 50:2},
    16: {15:1, 70:1},
    20: {13:0, 26:0, 63:0},
    24: {6:0, 40:0},
    30: {7:0, 44:0, 60:1},
  };

  static int? crossIndex(int factor, String ruleId, int topicCount) {
    final match = RegExp(r'^VARGA-CROSS-(\d{3})$').firstMatch(ruleId);
    if (match == null) return null;
    final idx = _crossTopics[factor]?[int.parse(match.group(1)!)];
    return idx != null && idx >= 0 && idx < topicCount ? idx : null;
  }

  static const Map<String, int> _d10ComputedIds = {
    'D10-JOB-BUSINESS': 2,
    'D10-SEQUENCE': 3,
    'D10-FINAL-MASTER-PROF': 4,
    'D10-FINAL-MASTER-NATURE': 25,
    'D10-HIGH-POSITION': 7,
    'D10-RAJAYOGA': 9,
  };

  /// Route *computed* rule hits by stable ID where possible, and otherwise by
  /// strongest topic phrase. Never use a weak one-word match against a generic
  /// source condition: the rule's own declared topic is the only fallback.
  static int? computedIndex(int factor, String ruleId, String ruleTopic,
      List<VargaTopic> topics) {
    if (factor == 10) {
      final explicit = _d10ComputedIds[ruleId];
      if (explicit != null && explicit < topics.length) return explicit;
      if (ruleId.startsWith('D10-GOV')) return 6;
      if (ruleId.startsWith('D10-PROF')) return 4;
    }
    final normalized = ruleTopic.toLowerCase();
    var bestIndex = -1;
    var bestScore = 0;
    for (var i = 0; i < topics.length; i++) {
      var score = 0;
      for (final word in topics[i].matchWords) {
        if (word.trim().isEmpty) continue;
        final lower = word.toLowerCase();
        if (normalized.contains(lower)) score += lower.length;
      }
      // A source explicitly naming the whole topic receives higher priority.
      if (normalized.contains(topics[i].title.toLowerCase())) score += 100;
      if (score > bestScore) {
        bestScore = score;
        bestIndex = i;
      }
    }
    return bestIndex < 0 ? null : bestIndex;
  }

  static Map<int, List<String>> linkedSourceIds(int factor,
      Iterable<String> ids, int topicCount) {
    final groups = <int, List<String>>{};
    for (final id in ids) {
      final index = sourceIndex(factor, id, topicCount) ??
          crossIndex(factor, id, topicCount);
      if (index != null) groups.putIfAbsent(index, () => []).add(id);
    }
    return groups;
  }
}
