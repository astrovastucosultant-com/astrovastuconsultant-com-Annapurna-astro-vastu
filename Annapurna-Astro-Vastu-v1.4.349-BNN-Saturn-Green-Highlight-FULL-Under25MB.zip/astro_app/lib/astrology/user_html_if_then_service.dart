import 'dart:convert';

import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'varga_service.dart';

/// Uploaded HTML is a user-supplied transcription/index, not independently
/// verified OCR from a particular printed book. No arbitrary string `if` is
/// evaluated. Only these explicitly implemented predicates can return true.
/// Source bibliography and astronomical condition matching are kept separate.
class UserHtmlIfThenRow {
  const UserHtmlIfThenRow({
    required this.id,
    required this.varga,
    required this.topic,
    required this.ocr,
    required this.condition,
    required this.whenYes,
    required this.whenNo,
    required this.source,
    required this.engineId,
    required this.evaluationMode,
    required this.predicate,
    required this.printedPageClaim,
  });

  final String id;
  final String varga;
  final String topic;
  final String ocr;
  final String condition;
  final String whenYes;
  final String whenNo;
  final String source;
  final String engineId;
  final String evaluationMode;
  final String? predicate;
  final String? printedPageClaim;

  int get factor => int.parse(varga.substring(1));

  factory UserHtmlIfThenRow.fromJson(Map<String, dynamic> row) =>
      UserHtmlIfThenRow(
        id: row['id'] as String,
        varga: row['varga'] as String,
        topic: row['topic'] as String,
        ocr: row['ocr'] as String,
        condition: row['if'] as String,
        whenYes: row['then_yes'] as String,
        whenNo: row['then_no'] as String,
        source: row['source'] as String,
        engineId: row['engine_id'] as String,
        evaluationMode: row['evaluation_mode'] as String,
        predicate: row['predicate_key'] as String?,
        printedPageClaim: row['source_printed_page_claim'] as String?,
      );
}

class UserHtmlConditionCheck {
  const UserHtmlConditionCheck(this.matched, this.evidence);

  /// true = entire IF is demonstrated, false = entire IF is demonstrated false,
  /// null = cannot determine this IF from available calculations. No alternate
  /// ELSE outcome is implied by false or null.
  final bool? matched;
  final String evidence;
}

class UserHtmlIfThenService {
  static const asset = 'assets/varga/user_html_60_rules.json';
  static const supportedRuleCount = 60;

  static Future<List<UserHtmlIfThenRow>> load() async {
    final obj = jsonDecode(await rootBundle.loadString(asset))
        as Map<String, dynamic>;
    final rows = (obj['rules'] as List<dynamic>)
        .map((r) => UserHtmlIfThenRow.fromJson(r as Map<String, dynamic>))
        .toList(growable: false);
    if (rows.length != supportedRuleCount ||
        rows.map((r) => r.engineId).toSet().length != rows.length) {
      throw StateError('HTML rule catalog incomplete or duplicated');
    }
    return rows;
  }

  static UserHtmlConditionCheck evaluate(
    UserHtmlIfThenRow row,
    AstroChartResult natal, {
    D16CalculationMethod d16Method = D16CalculationMethod.parashara,
  }) {
    const signs = <String>[
      'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
      'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
    ];
    // Unsupported D11 is present in the user's HTML but cannot be evaluated
    // by the app's current 19-factor VargaService.
    if (!VargaService.definitions.any((x) => x.factor == row.factor)) {
      return const UserHtmlConditionCheck(
        null, 'ఈ వర్గానికి ప్రస్తుత యాప్‌లో గణన విధానం లేదు. '
            'మూల నియమం సూచికలో మాత్రమే ఉంది.',
      );
    }
    if (row.predicate == null) {
      return const UserHtmlConditionCheck(null,
          'అప్‌లోడ్ చేసిన HTMLలో IF పేరు మాత్రమే ఉంది. '
          'బలం / దృష్టి / యోగ నిర్వచనాలు పూర్తిగా లేవు. '
          'అందువల్ల ఈ నియమాన్ని జాతక ఫలితంగా గణించలేదు.');
    }
    final varga = VargaService.calculate(natal, row.factor,
        d16Method: d16Method);
    final planets = {for (final p in varga.planets) p.name: p.signIndex};
    final asc = varga.ascendantSignIndex;
    final modeNote = 'D${row.factor} లగ్న రాశి: ${signs[asc]}. ';

    switch (row.predicate) {
      case 'sun_hora':
      case 'moon_hora':
        // Classical D2 hora maps the birth ascendant into Leo/Cancer.
        // A natal planet being in solar hora is NOT used as birth hora.
        final expected = row.predicate == 'sun_hora' ? 4 : 3;
        if (asc != 4 && asc != 3) {
          return UserHtmlConditionCheck(null,
              '$modeNote సూర్య/చంద్ర హోరా గణన ధృవీకరించలేదు.');
        }
        return UserHtmlConditionCheck(asc == expected,
            '$modeNote జన్మ లగ్నం ఆధారంగా D2 '
            '${asc == 4 ? 'సూర్య' : 'చంద్ర'} హోరా. '
            'ఇది HTMLలో పేర్కొన్న షరతు గణన మాత్రమే.');
      case 'mars_exalted_in_10th_d3':
        final mars = planets['Mars'];
        if (mars == null) {
          return const UserHtmlConditionCheck(null,
              'D3లో కుజుడి స్థానం అందుబాటులో లేదు.');
        }
        final house = (mars - asc + 12) % 12 + 1;
        return UserHtmlConditionCheck(mars == 9 && house == 10,
            '$modeNote కుజుడు ${signs[mars]}లో $house వ భావం. '
            'ఉచ్చరాశి మకరం; ఉచ్చం మరియు 10వ భావం రెండూ కావాలి.');
      case 'saturn_debilitated_or_nodes_partial':
        final sat = planets['Saturn'];
        if (sat == null) {
          return const UserHtmlConditionCheck(null,
              'D10లో శనిగ్రహ స్థానం అందుబాటులో లేదు.');
        }
        final satDebilitated = sat == 0;
        final nodeConjoined = planets['Rahu'] == sat || planets['Ketu'] == sat;
        final details = '$modeNote శని ${signs[sat]}లో; '
            'మేషంలో నీచం = $satDebilitated; '
            'రాహు/కేతుతో ఒకే రాశి = $nodeConjoined. '
            '6/8/12తో ఇతర సంబంధాలు, దహనం, గ్రహయుద్ధం '
            'ఇక్కడ ఇంకా గణించలేదు.';
        // These two are individually sufficient OR clauses. If both are false
        // we MUST NOT claim the full OR condition is false.
        return UserHtmlConditionCheck(
            (satDebilitated || nodeConjoined) ? true : null, details);
      case 'planet_in_eighth_partial':
        final occupants = varga.planets
            .where((p) => (p.signIndex - asc + 12) % 12 + 1 == 8)
            .map((p) => p.name)
            .toList(growable: false);
        if (occupants.isNotEmpty) {
          return UserHtmlConditionCheck(true,
              '$modeNote 8వ భావంలో: ${occupants.join(', ')}. '
              'ఇది IFలోని మొదటి OR ఉపషరతు మాత్రమే; '
              'వారసత్వం సంఘటనకు హామీ కాదు.');
        }
        return UserHtmlConditionCheck(null,
            '$modeNote 8వ భావంలో గ్రహం లేదు. '
            '8వ భావంపై దృష్టులను పూర్తిగా పరీక్షించకపోవడంతో '
            'మొత్తం IF అబద్ధమని చెప్పలేం.');
      default:
        return const UserHtmlConditionCheck(null,
            'ఈ IF‌కు ఆమోదించిన గణన పద్ధతి లేదు.');
    }
  }
}
