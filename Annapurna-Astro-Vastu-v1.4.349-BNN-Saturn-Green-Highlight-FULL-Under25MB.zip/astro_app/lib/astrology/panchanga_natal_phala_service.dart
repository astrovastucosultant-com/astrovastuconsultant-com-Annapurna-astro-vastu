import 'astro_models.dart';
import 'vedic_calculation_service.dart';
import 'sunrise_vara_service.dart';
import '../models/birth_data.dart';

/// Source-indexed traditional natal aphorisms: Jātaka Pārijāta 9.34–39,
/// 9.84–90, 9.97–103. This is NOT a scientific diagnostic or a forecast.
/// The readable summaries are conservative paraphrases, not verbatim verses.
class PanchangaNatalReading {
  final String label, result, evidence, ruleId, source;
  const PanchangaNatalReading(this.label, this.result, this.evidence,
      this.ruleId, this.source);
}

class PanchangaNatalPhalaService {
  static const sourceUrl='https://vedicreader.com/s/shl?s=31c305a18f0';
  static const _planets=<String,String>{
    'Sun':'రవి','Moon':'చంద్రుడు','Mars':'కుజుడు',
    'Mercury':'బుధుడు','Jupiter':'గురువు','Venus':'శుక్రుడు',
    'Saturn':'శని','Rahu':'రాహువు','Ketu':'కేతువు'};
  static const _signs=<String>[
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం'];
  static const _starLords=<String>[
    'Ketu','Venus','Sun','Moon','Mars','Rahu','Jupiter','Saturn','Mercury'];
  static const _weekdayNames=<String>[
    'సోమవారం','మంగళవారం','బుధవారం','గురువారం','శుక్రవారం','శనివారం','ఆదివారం'];
  static const _weekdayLords=<String>[
    'Moon','Mars','Mercury','Jupiter','Venus','Saturn','Sun'];

  // Classical birth-tithi meanings, NOT the Nanda/Bhadra/Jaya/Rikta/Purna
  // MUHURTA selection system. First 14 apply to either paksha; 15 is separate.
  static const tithiBirthPhala=<String>[
    'కృషిశీలత, ధార్మిక కార్యాలపై ఆసక్తి',
    'ప్రతిష్ఠ, బలం, సంపదలపై ఆసక్తి',
    'పుణ్యకార్యాల ఆసక్తి, వాక్చాతుర్యం; భయభావం',
    'ఆశయాలు, ప్రయాణనైపుణ్యం, మంత్రణశక్తి',
    'శాస్త్రశ్రవణం, అధ్యయనాసక్తి; చంచలత్వం',
    'తెలివి, నాయకత్వ గుణాలు; త్వరిత కోపం',
    'నిర్వహణశక్తి, బలం; కఠిన వాక్కు',
    'కుటుంబ అనురాగం, సుఖాలపై ఆసక్తి',
    'పేరు, గుర్తింపు; కుటుంబ విషయాల్లో జాగ్రత్త',
    'ధర్మాసక్తి, వాక్చాతుర్యం, కుటుంబ–ధన సంబంధిత శుభ సూచన',
    'దైవారాధన, సేవక సహకారం, సంపద సూచన',
    'ధార్మిక కార్యాలు, దానగుణం, విద్య, సంపద',
    'ధనసంబంధ ఆసక్తి; అధిక లోభం పట్ల జాగ్రత్త',
    'ఆవేశం, ఇతరుల విషయాల్లో అసూయ/లోభం పట్ల జాగ్రత్త',
    'వంశగౌరవం, సద్బుద్ధి (పౌర్ణమి)',
    'పితృదేవతారాధన ఆసక్తి, ఆశయాలు, ధనసంబంధ సూచన (అమావాస్య)',
  ];
  // Monday through Sunday, following the exact weekday used at sunrise.
  static const weekdayBirthPhala=<String>[
    'సౌమ్యత, కరుణ, ఆకర్షణ, కుటుంబ సంబంధాల పట్ల ఆసక్తి',
    'సాహసం, క్రియాశీలత; తొందరపాటు, కఠిన వాక్కుపై జాగ్రత్త',
    'మృదువైన సంభాషణ, దేవగురు పట్ల గౌరవం',
    'సత్కార్యాలు, గౌరవం, విద్య, ఆధ్యాత్మికాభిరుచి',
    'వ్యవసాయ–సంపద సంబంధిత ఆసక్తి, ప్రజాదరణ, సౌఖ్యాభిలాష',
    'వాదవివాదాల్లో జాగ్రత్త, బాధ్యతల్లో శ్రమ, విభేదాల అవకాశం',
    'ఆత్మగౌరవం, అధికారభావం, నాయకత్వ ఆసక్తి',
  ];
  static const starBirthPhala=<String>[
    'తెలివి, వినయం, కీర్తి, సుఖసంపదల సూచన', // 84: Asvini
    'సంపాదనశక్తి; కఠినత్వం, సంబంధ ప్రవర్తనలో జాగ్రత్త',
    'తేజస్సు, విద్య, నాయకత్వ స్వభావం',
    'సూక్ష్మ పరిశీలన, విషయ అవగాహన; సంబంధాలలో జాగ్రత్త',
    'సౌమ్య ప్రవర్తన, అన్వేషణ; మనస్సులో చంచలత్వం', // 85
    'శక్తి, మార్పు; అస్థిర నిర్ణయాలపై జాగ్రత్త',
    'వాక్ప్రతిభ, కవిత్వం, శక్తి, పేరు',
    'బుద్ధి, సహకారం, కుటుంబ–గౌరవ సూచన',
    'సూక్ష్మబుద్ధి; కోపం, మాటల విషయంలో జాగ్రత్త', // 86
    'గౌరవాసక్తి, సంపద, ధార్మిక ఆసక్తి',
    'కళాసక్తి, పట్టుదల; చంచలత్వం',
    'కృతజ్ఞత, వివేకం, గౌరవం',
    'తెలివి, సహాయగుణం, ధర్మాసక్తి, ధన సూచన', // 87
    'రహస్య విషయాలపై ఆసక్తి, ఆత్మగౌరవం',
    'సుఖ–ధనాసక్తి, సామాజిక సంబంధాలు',
    'శత్రువులను ఎదుర్కొనే ధైర్యం; కోపంపై జాగ్రత్త',
    'మధుర వాక్కు, కీర్తి, సామర్థ్యం, సుఖసంపద', // 88
    'బలం, ధార్మికత; ఆవేశంపై జాగ్రత్త',
    'వాక్చాతుర్యం, ఇబ్బందులను అధిగమించే నైపుణ్యం',
    'స్థిరమైన ప్రవర్తన, శాంతి, సుఖాభిలాష',
    'గౌరవం, విద్య, ధనం, శాంత స్వభావం', // 89
    'ధర్మం, గురుభక్తి, గౌరవం, సంపద',
    'ధనం, సుఖం; ఆశలు, కోరికల ప్రభావం',
    'సమయ అవగాహన, ధైర్యం, శాంతి',
    'బలమైన మాట, చతురత; ఆందోళన', // 90
    'మృదుత్వం, త్యాగం, విద్య, ధన సూచన',
    'సలహా నైపుణ్యం, స్నేహ–కుటుంబ సహకారం, స్థిరశ్రీ అభిలాష',
  ];
  static const yogaBirthPhala=<String>[
    'విరోధాలపై గెలుపు, సంపద, వనరుల సూచన', // 97
    'సంబంధ ఆకర్షణ; భావోద్వేగ నిర్ణయాల్లో జాగ్రత్త',
    'దీర్ఘకాల ఆరోగ్య–శక్తి సంబంధిత సంప్రదాయ శుభ సూచన',
    'సౌఖ్యం, సంతోషకర అనుభవాల సూచన',
    'సౌందర్యం, సుఖభోగాలపై ఆసక్తి',
    'ఆవేశం, దూకుడైన ప్రవర్తన పట్ల జాగ్రత్త',
    'ధార్మిక కార్యాలు, సత్ప్రవర్తన',
    'సంపాదనాసక్తి; సంబంధాల్లో వివేకం అవసరం',
    'కోపాన్ని నియంత్రించుకోవాల్సిన స్వభావ సూచన', // 98
    'కలహాల విషయంలో జాగ్రత్త',
    'పాండిత్యం, వాక్చాతుర్యం',
    'ధనసంబంధ శుభ సూచన',
    'ఆవేశం, వివాదాలపై జాగ్రత్త',
    'జ్ఞానం, గౌరవం, కీర్తి',
    'ధనం, ఆకర్షణలపై ఆసక్తి',
    'ప్రజల సహకారం, నాయకత్వ సామర్థ్యం',
    'అధికార ఆసక్తి; మోసం/అతివిశ్వాసంపై జాగ్రత్త',
    'కోరికల విషయంలో సంయమనం అవసరం', // 99
    'ధనాసక్తి; విరోధ భావంపై జాగ్రత్త',
    'శాస్త్రజ్ఞానం, శాంతి, గౌరవం',
    'ధర్మాచరణ, ఆధ్యాత్మిక కార్యాలు',
    'సత్ప్రవర్తన, క్రమశిక్షణ',
    'సౌందర్యం, సంపద; సుఖాసక్తి పట్ల జాగ్రత్త',
    'విద్య, మాట నైపుణ్యం; కోపం–చంచలత్వంపై జాగ్రత్త', // 100
    'ధన–జ్ఞానాసక్తి, వివేకం, దానగుణం',
    'ప్రజాహితం, జ్ఞానం, ధన సూచన',
    'సామర్థ్యం, ధనం, దానగుణం; మాటల్లో జాగ్రత్త',
  ];
  // Ordered to match VedicCalculationService's names, not the 60-half index.
  static const karanaBirthPhala=<String,String>{
    'బవ':'ఉత్సాహం, ప్రతాపం; బాలస్వభావం', // 101
    'బాలవ':'వినయం, గౌరవం, పెద్దల ఆదరణ',
    'కౌలవ':'వాహన–వనరుల ఆసక్తి, మంచి కార్యనైపుణ్యం',
    'తైతిల':'మృదువైన మాట, వాక్చాతుర్యం, సత్ప్రవర్తన',
    'గరజ':'సాహసం, శత్రుబాధలను ఎదుర్కొనే శక్తి', // 102
    'వణిజ':'మాట నైపుణ్యం; సంబంధ విషయాల్లో జాగ్రత్త',
    'విష్టి':'స్వతంత్ర భావం; విభేదాలు, విమర్శల్లో జాగ్రత్త',
    'శకుని':'సమయజ్ఞానం, స్థిర సౌఖ్య సూచన', // 103
    'చతుష్పాద':'జ్ఞానం, పేరు–సంపద సూచన; సమస్యలపైనా పరిశీలన',
    'నాగ':'తేజస్సు, శక్తి, వాక్చాతుర్యం, సంపద',
    'కింస్తుఘ్న':'ఇతరులకు సహాయం, ఉల్లాసం; చంచలత్వం',
  };
  static const _karanaVerse=<String,int>{
    'బవ':101,'బాలవ':101,'కౌలవ':101,'తైతిల':101,
    'గరజ':102,'వణిజ':102,'విష్టి':102,
    'శకుని':103,'చతుష్పాద':103,'నాగ':103,'కింస్తుఘ్న':103};

  static int tithiVerse(int tithiIndex)=> tithiIndex%15 < 4?34:
    tithiIndex%15 < 8?35:tithiIndex%15 < 12?36:37;
  static int nakshatraVerse(int n)=>84+n~/4;
  static int yogaVerse(int n)=>n<8?97:n<17?98:n<23?99:100;
  static int weekdayVerse(int wd)=>wd<=3||wd==7?38:39;
  static int karanaVerse(String name)=>_karanaVerse[name]??0;

  static String _source(int verse)=>
    'జాతక పారిజాతం (Jātaka Pārijāta), అధ్యాయం 9, శ్లోకం $verse. '
    'ముద్రిత పేజీ సంచికనుబట్టి మారుతుంది; ధృవీకరించిన స్థిర సూచన శ్లోక సంఖ్య. $sourceUrl';
  static String _tradition(String phrase)=>
    'జన్మఫల శ్లోకం సూచించే స్వభావ/జీవన ధోరణి: $phrase. '
    'ఇది సంప్రదాయ శాస్త్రవివరణ; ఒక్క ఈ అంగంతో జీవితం, ఆరోగ్యం, '
    'ఆదాయం లేదా సంతానం గురించి తుది నిర్ణయం కాదు.';

  /// [solarWeekday] should be supplied from sunrise_vara_service.dart.
  /// No implicit civil weekday fallback: missing sunrise means unverified.
  static List<PanchangaNatalReading> evaluate(AstroChartResult chart,
      BirthData birth, {SunriseVaraResult? solarWeekday}) {
    final sun=chart.planets.firstWhere((p)=>p.name=='Sun');
    final moon=chart.planets.firstWhere((p)=>p.name=='Moon');
    double norm(double x)=>(x%360+360)%360;
    final separation=norm(moon.longitude-sun.longitude);
    final tithiIndex=(separation/12).floor().clamp(0,29).toInt();
    final tithiSlot=tithiIndex%15;
    final tithiPhalaIndex=tithiSlot==14?(tithiIndex<15?14:15):tithiSlot;
    final n=VedicCalculationService.nakshatra(moon.longitude);
    final yogaIndex=(norm(sun.longitude+moon.longitude)/(360/27))
      .floor().clamp(0,26).toInt();
    final p=VedicCalculationService.panchanga(chart);
    String placement(String lord){
      final found=chart.planets.where((x)=>x.name==lord);
      if(found.isEmpty) return 'గ్రహస్థితి లభించలేదు';
      final g=found.first;
      final h=(g.signIndex-chart.ascendantSignIndex+12)%12+1;
      return '${_planets[lord]??lord}: ${_signs[g.signIndex]} • $h భావం';
    }
    final karana=p.karana.startsWith('విష్టి')?'విష్టి':p.karana;
    final karanaId=(separation/6).floor().clamp(0,59).toInt()+1;
    final starLord=_starLords[n.index%9];
    final weekday=solarWeekday?.solarWeekday;
    final weekdayIndex=weekday==null?null:weekday-1;
    String sunriseEvidence(){
      if(solarWeekday==null){
        return 'జనన తేదీ సివిల్ వారం: ${_weekdayNames[birth.localDateTime.weekday-1]}. '
          'స్థానిక సూర్యోదయం లభించలేదు; జన్మ వారాధిపతి నిర్ధారణ పెండింగ్. '
          'పుట్టిన స్థలం/అక్షాంశం/రేఖాంశం, UTC offset మరియు Swiss Ephemeris పరిశీలించాలి.';
      }
      final shift=Duration(minutes:(birth.timezoneOffsetHours*60).round());
      final sr=solarWeekday.sunriseUtc.add(shift);
      String two(int x)=>x.toString().padLeft(2,'0');
      final h='${two(sr.hour)}:${two(sr.minute)}';
      final policy=solarWeekday.beforeSunrise?
        'జననం సూర్యోదయానికి ముందు — గతరోజు వారం వర్తిస్తుంది':
        'జననం సూర్యోదయం తరువాత/సమయంలో — ఆ రోజు వారం వర్తిస్తుంది';
      return 'జన్మస్థలం ${birth.place} (${birth.latitude.toStringAsFixed(4)}°, '
        '${birth.longitude.toStringAsFixed(4)}°); స్థానిక సూర్యోదయం $h; $policy. '
        'సివిల్ వారం: ${_weekdayNames[solarWeekday.civilWeekday-1]}. '
        '${placement(_weekdayLords[weekdayIndex!])}.';
    }
    final weekdayResult=weekdayIndex==null?
      'స్థానిక సూర్యోదయం లభించలేదు; శాస్త్రోక్త జన్మవార ఫలితం ఇంకా నిర్ధారించలేదు.':
      _tradition('${weekdayBirthPhala[weekdayIndex]}; '
        'వారాధిపతి ${_planets[_weekdayLords[weekdayIndex]]}');
    return <PanchangaNatalReading>[
      PanchangaNatalReading(
        'తిథి — ${p.paksha} ${p.tithi}',
        _tradition(tithiBirthPhala[tithiPhalaIndex]),
        'చంద్ర–సూర్య కోణభేదం ${separation.toStringAsFixed(4)}°; '
        'తిథి ${tithiIndex+1}/30; పక్షంలోని తిథి ${tithiSlot+1}/15. '
        'జన్మక్షణంలోని నిజమైన తిథి; నందాది ముహూర్త వర్గం వేరు.',
        'JP-9-${tithiVerse(tithiIndex)}-T${(tithiIndex+1).toString().padLeft(2,'0')}',
        _source(tithiVerse(tithiIndex))),
      PanchangaNatalReading(
        weekdayIndex==null?'వారం — సూర్యోదయ గణన పెండింగ్':
          'వారం — ${_weekdayNames[weekdayIndex]}',
        weekdayResult, sunriseEvidence(),
        weekdayIndex==null?'JP-9-VARA-UNVERIFIED':
          'JP-9-${weekdayVerse(weekday!)}-V${weekday}',
        weekdayIndex==null?
          'సూర్య సిద్ధాంతం 14.18 — దినారంభం సూర్యోదయం; '
          'స్థానిక సూర్యోదయ గణన అవసరం. https://packolkata.imd.gov.in/panchang/en/explanation':
          _source(weekdayVerse(weekday!))),
      PanchangaNatalReading(
        'నక్షత్రం — ${p.nakshatra} ${n.pada}వ పాదం',
        _tradition(starBirthPhala[n.index]),
        'చంద్రుని నిరయణ డిగ్రీ ${moon.longitude.toStringAsFixed(4)}°; '
        'నక్షత్రం ${n.index+1}/27; పాదం ${n.pada}/4. '
        'వింశోత్తరి నక్షత్రాధిపతి ${_planets[starLord]}; ${placement(starLord)}.',
        'JP-9-${nakshatraVerse(n.index)}-N${(n.index+1).toString().padLeft(2,'0')}',
        _source(nakshatraVerse(n.index))),
      PanchangaNatalReading(
        'నిత్యయోగం — ${p.yoga}',
        _tradition(yogaBirthPhala[yogaIndex]),
        'సూర్య–చంద్రుల నిరయణ భోగాల మొత్తం '
        '${norm(sun.longitude+moon.longitude).toStringAsFixed(4)}°; '
        'యోగం ${yogaIndex+1}/27. ఇది జన్మ నిత్యయోగం; ఇతర రాజయోగం కాదు.',
        'JP-9-${yogaVerse(yogaIndex)}-Y${(yogaIndex+1).toString().padLeft(2,'0')}',
        _source(yogaVerse(yogaIndex))),
      PanchangaNatalReading(
        'కరణం — ${p.karana}',
        _tradition(karanaBirthPhala[karana]??'మూల నియమం నిర్ధారించాలి'),
        'చంద్ర–సూర్య కోణభేదం ${separation.toStringAsFixed(4)}°; '
        'అర్ధతిథి $karanaId/60; కరణం ${p.karana}. '
        'కరణం రకాలు 11 మాత్రమే; జన్మ కరణం ఇక్కడ లెక్కించబడింది.',
        'JP-9-${karanaVerse(karana)}-K${karanaId.toString().padLeft(2,'0')}',
        _source(karanaVerse(karana))),
    ];
  }
}
