import 'astro_models.dart';
import 'd10_career_service.dart';
import 'varga_service.dart';
import 'varga_unified_rule_service.dart';

/// Source-led chart review. Career-mode primary chart selection is a separate
/// user instruction (D1/D9/D10) and DOES NOT rewrite the original 255-rule
/// catalog, where VARGA-CROSS-003 additionally mentions D2/D7.
/// A chart's existence is never proof of a matched natal IF condition.
/// Percentages are rule-mode chart-coverage, never event probabilities.
enum TopicStageStatus { matched, notMatched, insufficientEvidence }

enum TopicPolarity { supportive, adverse, undetermined }

class TopicStageEvidence {
  final int factor;
  final TopicStageStatus status;
  final List<String> ruleIds;
  final String details;
  final TopicPolarity polarity;
  /// Exact verified condition or named user-defined career-mode check.
  final String ruleText;
  /// Only a matched source/mode rule can produce a highlighted supportive result.
  final String result;
  final String source;

  const TopicStageEvidence({
    required this.factor,
    required this.status,
    required this.ruleIds,
    required this.details,
    this.polarity = TopicPolarity.undetermined,
    this.ruleText = '',
    this.result = '',
    this.source = '',
  });
}

class MultiChartTopicEvidence {
  final String name;
  final String chartOrderSourceId;
  final List<TopicStageEvidence> stages;
  final String note;

  const MultiChartTopicEvidence({
    required this.name,
    required this.chartOrderSourceId,
    required this.stages,
    required this.note,
  });

  int get matchedStages => stages.where((s) => s.status == TopicStageStatus.matched).length;
  int get evaluatedStages => stages.where((s) => s.status != TopicStageStatus.insufficientEvidence).length;
  int get totalStages => stages.length;
  /// Numerator is confirmed stages, denominator is source-selected stages.
  /// Never count pending as confirmed. When 0 stages are confirmed and at
  /// least one is pending, omit 0% rather than insinuating no event promise.
  int? get confirmationPercent => matchedStages > 0 || evaluatedStages == totalStages
      ? (100 * matchedStages ~/ totalStages)
      : null;

  String get displayCoverage => confirmationPercent == null
      ? '$matchedStages/$totalStages · ${totalStages - evaluatedStages} పూర్తి పరీక్ష మిగిలింది'
      : '$confirmationPercent% · $matchedStages/$totalStages చక్రాలు'
          '${evaluatedStages < totalStages ? ' · ${totalStages - evaluatedStages} పెండింగ్' : ''}';
}

class _TopicDefinition {
  final String name;
  final String sourceId;
  final List<int> factors;
  final Map<int, List<String>> detailedRuleIds;
  final String? careerMode;
  const _TopicDefinition(this.name, this.sourceId, this.factors,
      this.detailedRuleIds, {this.careerMode});
}

class MultiChartTopicService {
  // Career primary charts are selected by the user. The underlying source
  // registry remains unchanged and independently auditable.
  static const _definitions = <_TopicDefinition>[
    _TopicDefinition('వ్యాపారం', 'USER-CAREER-CORE-BUSINESS', [1, 9, 10], {
      1: ['VARGA-CROSS-027'],
      9: [], // D9 Saturn is audit/support; no invented D9 business IF.
      10: ['VARGA-CROSS-028', 'VARGA-D10-005'],
    }, careerMode: 'GOCHARASHTHA'),
    _TopicDefinition('ఉద్యోగం / సర్వీస్', 'USER-CAREER-CORE-JOB', [1, 9, 10], {
      1: [],
      9: [],
      10: [], // Job mode sourced from D10 special.pdf, not invented 255-rule IDs.
    }, careerMode: 'AGOCHARASHTHA'),
    _TopicDefinition('ప్రభుత్వ ఉద్యోగం', 'VARGA-CROSS-001', [1, 9, 10], {
      1: ['VARGA-CROSS-016', 'VARGA-CROSS-017', 'VARGA-CROSS-018'],
      9: ['VARGA-CROSS-019'], 10: ['VARGA-CROSS-020'],
    }),
    _TopicDefinition('ఉన్నత ప్రభుత్వ పదవి', 'VARGA-CROSS-002', [1, 9, 10, 24, 20], {
      1: ['VARGA-CROSS-022'], 9: ['VARGA-CROSS-023'],
      10: ['VARGA-CROSS-021', 'VARGA-CROSS-024'],
      24: ['VARGA-CROSS-025'], 20: ['VARGA-CROSS-026'],
    }),
    _TopicDefinition('వివాహం', 'VARGA-CROSS-004', [1, 9, 2, 7], {
      1: ['VARGA-CROSS-031', 'VARGA-CROSS-033'],
      9: ['VARGA-CROSS-032', 'VARGA-CROSS-033'],
      2: ['VARGA-CROSS-034'], 7: ['VARGA-CROSS-034'],
    }),
    _TopicDefinition('సంతానం', 'VARGA-CROSS-005', [1, 7, 9], {
      1: ['VARGA-CROSS-035'], 7: ['VARGA-CROSS-036'], 9: ['VARGA-CROSS-037'],
    }),
    _TopicDefinition('విద్య', 'VARGA-CROSS-006', [1, 4, 24, 9], {
      1: ['VARGA-CROSS-038'], 4: ['VARGA-CROSS-039'],
      24: ['VARGA-CROSS-040'], 9: ['VARGA-CROSS-041'],
    }),
    _TopicDefinition('ఆరోగ్యం', 'VARGA-CROSS-007', [1, 6, 30], {
      1: ['VARGA-CROSS-042'], 6: ['VARGA-CROSS-043'],
      30: ['VARGA-CROSS-044'],
    }),
    _TopicDefinition('ఆయుష్షు', 'VARGA-CROSS-008', [1, 2, 3, 8], {
      1: ['VARGA-CROSS-045'], 2: ['VARGA-CROSS-046'],
      3: ['VARGA-CROSS-046'], 8: ['VARGA-CROSS-047'],
    }),
    _TopicDefinition('ఆస్తి / వారసత్వం', 'VARGA-CROSS-009', [1, 4, 12], {
      1: ['VARGA-CROSS-048'], 4: ['VARGA-CROSS-049'],
      12: ['VARGA-CROSS-050'],
    }),
    _TopicDefinition('దాంపత్య విఘాతం', 'VARGA-CROSS-010', [1, 9, 30], {
      1: ['VARGA-CROSS-051'], 9: ['VARGA-CROSS-052'],
      30: ['VARGA-CROSS-053'],
    }),
    _TopicDefinition('విదేశీ ప్రయాణం / నివాసం', 'VARGA-CROSS-011', [1, 9, 10, 4], {
      1: ['VARGA-CROSS-054'], 9: ['VARGA-CROSS-055'],
      10: ['VARGA-CROSS-056'], 4: ['VARGA-CROSS-057'],
    }),
    _TopicDefinition('కోర్టు కేసులు', 'VARGA-CROSS-012', [1, 6, 30], {
      1: ['VARGA-CROSS-058'], 6: ['VARGA-CROSS-059'],
      30: ['VARGA-CROSS-060'],
    }),
    _TopicDefinition('ఆధ్యాత్మికత', 'VARGA-CROSS-013', [1, 9, 20, 24], {
      1: ['VARGA-CROSS-061'], 9: ['VARGA-CROSS-062'],
      20: ['VARGA-CROSS-063'], 24: ['VARGA-CROSS-064'],
    }),
    _TopicDefinition('కీర్తి', 'VARGA-CROSS-014', [1, 10, 9], {
      1: ['VARGA-CROSS-065'], 10: ['VARGA-CROSS-066'],
      9: ['VARGA-CROSS-067'],
    }),
    _TopicDefinition('వాహన సుఖం', 'VARGA-CROSS-015', [1, 4, 16], {
      1: ['VARGA-CROSS-068'], 4: ['VARGA-CROSS-069'],
      16: ['VARGA-CROSS-070'],
    }),
  ];

  static List<MultiChartTopicEvidence> summarize({
    required AstroChartResult chart,
    required List<UnifiedVargaRule> evaluatedRules,
  }) {
    final byId = {for (final rule in evaluatedRules) rule.id: rule};
    return _definitions.map((definition) {
      final stages = <TopicStageEvidence>[];
      for (final factor in definition.factors) {
        final refs = definition.detailedRuleIds[factor] ?? const <String>[];
        final selected = refs.map((id) => byId[id]).whereType<UnifiedVargaRule>().toList();
        final matched = selected.where((r) => r.status == UnifiedVargaRuleStatus.matched).toList();
        final pending = selected.where((r) => r.status == UnifiedVargaRuleStatus.pending ||
            r.status == UnifiedVargaRuleStatus.method).toList();
        final allChecked = selected.isNotEmpty && pending.isEmpty;
        var status = matched.isNotEmpty
            ? TopicStageStatus.matched
            : allChecked ? TopicStageStatus.notMatched : TopicStageStatus.insufficientEvidence;
        var ids = matched.map((r) => r.id).toList();
        var details = matched.isNotEmpty
            ? matched.map((r) => '${r.id}: ${r.evidence}').join('\n')
            : 'మూల నియమం ఉంది; ఈ చక్రానికి పూర్తి IF–THEN ధృవీకరణ ఇంకా లేదు. '
              'దీనిని ప్రతికూల ఫలితంగా భావించకూడదు.';
        if (allChecked && matched.isEmpty) {
          details = selected.map((r) => '${r.id}: ${r.evidence}').join('\n');
          ids = selected.map((r) => r.id).toList();
        }

        // For user-selected career primary charts, classify only the Saturn
        // work-mode rule, not a guaranteed profession or source-catalog result.
        if (definition.careerMode != null) {
          stages.add(_careerModeStage(chart, factor,
              definition.careerMode!, selected));
          continue;
        }

        TopicStageEvidence? govExtra;
        // User-specified 5L/9L six-way OR, evaluated independently in D1/D9/D10.
        // This is clearly labelled a user-defined support check, not one of
        // the classical government's full natal-promise rules.
        if (definition.sourceId == 'VARGA-CROSS-001') {
          final extra = evaluateFiveNine(chart, factor);
          govExtra = extra;
          // For this specific topic the displayed percentage is ONLY the
          // complete six-OR user-defined check across D1/D9/D10. Pending
          // separate source IFs are disclosed, but don't erase a completed
          // negative six-OR test or turn it into a government-job denial.
          status = extra.status;
          ids = {...extra.ruleIds, ...ids}.toList();
          final extraSource = matched.isNotEmpty
              ? '\nఇతర వర్తించిన మూల నియమాలు: ${matched.map((r) => r.id).join(', ')}.'
              : '';
          details = '${extra.details}$extraSource'
              '\nమిగిలిన పూర్తికాని ప్రభుత్వ ఉద్యోగ రూల్స్: '
              '${pending.map((r) => r.id).join(', ')}.';
        }
        stages.add(TopicStageEvidence(
          factor: factor,
          status: status,
          ruleIds: ids,
          details: details,
          polarity: definition.sourceId == 'VARGA-CROSS-010' ||
              definition.sourceId == 'VARGA-CROSS-012'
              ? TopicPolarity.adverse : TopicPolarity.supportive,
          ruleText: [
            if (govExtra != null) govExtra.ruleText,
            ...selected.map((r) => '${r.id}: ${r.condition}'),
          ].where((t) => t.isNotEmpty).join('\n'),
          source: [
            if (govExtra != null) govExtra.source,
            ...selected.map((r) => '${r.id} — ${r.source}'),
          ].where((t) => t.isNotEmpty).join('\n'),
          result: status == TopicStageStatus.matched
              ? [
                  if (govExtra?.status == TopicStageStatus.matched)
                    govExtra!.result,
                  ...matched.map((r) => '${r.id}: ${r.outcome}'),
                ].where((t) => t.isNotEmpty).join('\n')
              : '',
        ));
      }
      return MultiChartTopicEvidence(
        name: definition.name,
        chartOrderSourceId: definition.sourceId,
        stages: stages,
        note: definition.careerMode == 'GOCHARASHTHA'
          ? 'ప్రధాన వృత్తి చక్రాల క్రమం D1 → D9 → D10 అనేది మీ తాజా నిర్ణయం. '
            'ఇక్కడి మ్యాచ్ కేవలం గోచరిష్ట శని విధానానికి మద్దతు; పూర్తి వ్యాపార ఫలితానికి కాదు. '
            'పాత VARGA-CROSS-003 (మూల PDF పేజీ 23)లో D1 → D10 → D2 → D7 ఉంది; '
            'దాని అసలు రూల్ తొలగించలేదు. D2 ధనపరిశీలన, D7 ప్రత్యేక అనుబంధ పరిశీలనకు కింద ఉన్నాయి; '
            'ప్రధాన D1–D9–D10 స్కోరులో కలపలేదు. V.P. Goel D7 గ్రంథ పరిచయంలో speculation, '
            'creativity, spouse prosperity అంశాలు ఉన్నాయి; వ్యాపారానికి ప్రత్యేక IF/పేజీ ఇక్కడ ధృవీకరించలేదు.'
          : definition.careerMode == 'AGOCHARASHTHA'
            ? 'ప్రధాన ఉద్యోగ చక్రాలు D1 → D9 → D10. ఇది అగోచరిష్ట శని విధానం మద్దతు పరీక్ష మాత్రమే; '
              'ఉద్యోగ నియామకం/స్థాయి ఖచ్చితమని కాదు. D9 మద్దతు, D10 ప్రధాన వృత్తి విధానం.'
          : definition.sourceId == 'VARGA-CROSS-001'
            ? 'USER-GOV-5-9 అనేది మీరు చెప్పిన ఆరు ప్రత్యామ్నాయాల్లో ఏదో ఒకటి సరిపోయే సపోర్ట్ చెక్. '
              'ఉద్యోగం లేదా హై ర్యాంక్ ఖచ్చితమని కాదు. ఇతర ప్రభుత్వ ఉద్యోగ నియమాలు, దశ, గోచారం ఇంకా కావాలి.'
            : 'మూలగ్రంథంలోని చార్ట్ క్రమం చూపుతున్నాం. అన్ని IF షరతులు అమలు కాని చక్రాన్ని మ్యాచ్‌గా లెక్కించము.',
      );
    }).toList(growable: false);
  }


  /// D1 = initial work style, D9 = support/audit, D10 = primary profession.
  /// A Saturn mode match is not a conclusive employment/business prediction.
  static TopicStageEvidence _careerModeStage(
      AstroChartResult chart, int factor, String requiredMode,
      List<UnifiedVargaRule> legacyRules) {
    final business = requiredMode == 'GOCHARASHTHA';
    final id = business ? 'D10-GOCHARISTA' : 'D10-AGOCHARISTA';
    const source = 'D10 special.pdf — Chapter 04, pp.50–51; '
        'USER-CAREER-CORE D1–D9–D10 chart selection.';
    if (!chart.ascendantLongitude.isFinite ||
        chart.planets.any((p) => !p.longitude.isFinite) ||
        !chart.planets.any((p) => p.name == 'Saturn')) {
      return TopicStageEvidence(
        factor: factor,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: const [],
        ruleText: 'గోచరిష్ట / అగోచరిష్ట నిర్ణయానికి శని, లగ్న డిగ్రీలు కావాలి.',
        details: 'శని / లగ్నం సమాచారం పూర్తిగా లేక ఈ విధానానికి పరీక్ష జరగలేదు.',
        source: source,
      );
    }
    final stream = D10CareerService.saturnStream(chart);
    final state = switch (factor) {
      1 => stream.birthState,
      9 => stream.navamsaState,
      10 => stream.dashamsaState,
      _ => 'MIXED',
    };
    final legacyMatched = legacyRules
        .where((r) => r.status == UnifiedVargaRuleStatus.matched).toList();
    final legacyPending = legacyRules
        .where((r) => r.status == UnifiedVargaRuleStatus.pending ||
            r.status == UnifiedVargaRuleStatus.method).toList();
    final status = state == requiredMode
        ? TopicStageStatus.matched
        : state == 'MIXED'
            ? TopicStageStatus.insufficientEvidence
            : TopicStageStatus.notMatched;
    final mode = business ? 'గోచరిష్ట (వ్యాపారం)' : 'అగోచరిష్ట (ఉద్యోగం)';
    final result = status != TopicStageStatus.matched ? '' : factor == 1
        ? 'D1లో $mode విధానానికి ప్రారంభ-వృత్తి మద్దతు ఉంది.'
        : factor == 9
            ? 'D9లో $mode విధానానికి అనుబంధ మద్దతు ఉంది; ఇది D10 నిర్ణయాన్ని మార్చదు.'
            : 'D10లో $mode ప్రధాన వృత్తి విధానానికి మద్దతు ఉంది. ఇది తుది సంఘటన నిర్ధారణ కాదు.';
    return TopicStageEvidence(
      factor: factor,
      status: status,
      polarity: TopicPolarity.supportive,
      ruleIds: [id, if (factor == 10) 'D10-SEQUENCE',
        ...legacyMatched.map((r) => r.id)],
      ruleText: '${business ? 'గోచరిష్ట' : 'అగోచరిష్ట'}: శని రాశి బలం, '
          '6/8/12 స్థానం, రాహు/కేతు యుతి ఆధారంగా వృత్తి విధానం పరీక్ష. '
          'D1 ప్రారంభం; D9 మద్దతు; D10 ప్రధాన వృత్తి. '
          'మూల నిబంధనలో combust/planetary war వంటి షరతులు ఈ ఆటో చెక్‌లో పూర్తిగా లేవు.',
      details: 'D$factor శని విధానం: $state; పరిశీలించాల్సింది: $requiredMode. '
          'D1=${stream.birthState}, D9=${stream.navamsaState}, '
          'D10=${stream.dashamsaState}. '
          '${legacyMatched.isEmpty ? '' : 'ఇతర నిర్ధారిత మూల రూల్స్: ${legacyMatched.map((r) => r.id).join(', ')}. '} '
          '${legacyPending.isEmpty ? '' : 'పూర్తికాని మూల IF: ${legacyPending.map((r) => r.id).join(', ')}.'}',
      source: source,
      result: result,
    );
  }

  /// Used only for the six user-supplied alternative conditions. The sign
  /// lord of a house is recalculated from that varga's own ascendant.
  static TopicStageEvidence evaluateFiveNine(AstroChartResult chart, int factor) {
    const rulers = <String>[
      'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
      'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
    ];
    if (!VargaService.definitions.any((d) => d.factor == factor)) {
      return TopicStageEvidence(factor: factor,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: const [], details: 'D$factor గణన అందుబాటులో లేదు.');
    }
    if (!chart.ascendantLongitude.isFinite ||
        chart.planets.any((p) => !p.longitude.isFinite)) {
      return TopicStageEvidence(factor: factor,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: const [], details: 'జన్మలగ్నం లేదా గ్రహ డిగ్రీల సమాచారం పూర్తిగా లేదు.');
    }
    final varga = VargaService.calculate(chart, factor);
    final signs = <String, int>{for (final p in varga.planets) p.name: p.signIndex};
    final l5 = rulers[(varga.ascendantSignIndex + 4) % 12];
    final l9 = rulers[(varga.ascendantSignIndex + 8) % 12];
    final s5 = signs[l5];
    final s9 = signs[l9];
    if (s5 == null || s9 == null) {
      return TopicStageEvidence(factor: factor,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: const [], details: '5వ/9వ అధిపతుల గ్రహస్థితులు లేవు.');
    }
    final house5 = (s5 - varga.ascendantSignIndex + 12) % 12 + 1;
    final house9 = (s9 - varga.ascendantSignIndex + 12) % 12 + 1;
    final own5 = rulers[s5] == l5;
    final own9 = rulers[s9] == l9;
    final found = <String>[];
    if (house5 == 9 && house9 == 5) found.add('5–9 పరివర్తన');
    if (l5 != l9 && s5 == s9) found.add('5L–9L యుతి');
    if (own5) found.add('5L స్వరాశి');
    if (own9) found.add('9L స్వరాశి');
    if (house5 == 9) found.add('5L 9వ భావంలో');
    if (house9 == 5) found.add('9L 5వ భావంలో');
    return TopicStageEvidence(
      factor: factor,
      status: found.isEmpty ? TopicStageStatus.notMatched : TopicStageStatus.matched,
      ruleIds: const ['USER-GOV-5-9'],
      details: 'D$factor: 5L $l5 = $house5 భావం; 9L $l9 = $house9 భావం. '
          '${found.isEmpty ? 'ఈ ఆరు షరతుల్లో ఏదీ సరిపోలలేదు.' : 'మ్యాచ్: ${found.join(', ')}.'}',
      polarity: TopicPolarity.supportive,
      ruleText: 'మీ USER-GOV-5-9 షరతు: 5L/9L యుతి, పరివర్తన, స్వరాశి, '
          'ఒకరి భావంలో మరొకరు ఉండడం — ఆరు OR ప్రత్యామ్నాయాల్లో ఒకటి.',
      source: 'USER-GOV-5-9 — మీరు నిర్దేశించిన పరీక్ష; పూర్తి ప్రభుత్వ ఉద్యోగ మూలయోగం కాదు.',
      result: found.isEmpty ? '' : 'ఈ చక్రంలో 5L–9L ప్రభుత్వ ఉద్యోగ సపోర్ట్ చెక్ మ్యాచ్ అయింది. '
          'ప్రభుత్వ ఉద్యోగం నిర్ధారణ కాదు.',
    );
  }
}
