import 'varga_rule_service.dart';
import 'varga_service.dart';
import 'varga_unified_rule_service.dart';

/// Shared, conservative IF–THEN display policy for all 19 vargas.
///
/// A computed placement is not automatically a predicted event. `null`
/// means that the source condition or outcome has not been fully verified,
/// and never means that an adverse event is predicted.
///
/// IMPORTANT: this is a truth-status/presentation layer. It does not invent
/// classical rules, source pages, event timings or missing remedies.
class VargaRuleMatchPolicy {
  VargaRuleMatchPolicy._();

  static const supportedFactors = <int>{
    1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 16, 20, 24, 27, 30, 40, 45, 60,
  };

  static bool isCrossVargaEvidence(String ruleId) =>
      ruleId.startsWith('VARGA-CROSS-') ||
      ruleId.startsWith('VARGA-GENERAL-004/D') ||
      ruleId.startsWith('VARGA-PROTOCOL-') ||
      ruleId.startsWith('AV-D');

  /// Composite evidence ratios are not independent scripture-backed IF–THEN
  /// event rules. They must remain visible for audit, never as green/pink
  /// conclusions (including the 0/5 D7 screenshot case).
  static bool isEvidenceSummaryRule(String ruleId) => const <String>{
    'D3-SUMMARY-EVIDENCE',
    'D4-PROPERTY-EVIDENCE',
    'D7-SANTANA-001',
    'D16-VEHICLE-EVIDENCE',
    'D16-LUXURY-COMFORT',
    'D16-VEHICLE-DELAY',
    'D16-VEHICLE-CAUTION',
  }.contains(ruleId);

  static bool? calculatedMatch(VargaRuleHit hit) {
    // Bibliographic source-only, informational and incomplete results are
    // audit material, not chart predictions.
    if (!hit.autoEvaluated || hit.tone == VargaRuleTone.info ||
        hit.rule.trim().isEmpty || hit.result.trim().isEmpty ||
        isCrossVargaEvidence(hit.ruleId) ||
        isEvidenceSummaryRule(hit.ruleId)) {
      return null;
    }
    return hit.applicable;
  }

  static bool? sourceMatch(
    UnifiedVargaRule rule, {
    required int factor,
    required D16CalculationMethod d16Method,
  }) {
    // Cross-varga, SAV and Vargottama links are supporting inspection only,
    // including when the catalogue's mathematical condition is true.
    if (isCrossVargaEvidence(rule.id)) return null;

    final alternateD16 = factor == 16 &&
        d16Method != D16CalculationMethod.parashara &&
        !rule.id.startsWith('VARGA-GENERAL-004/D16') &&
        !rule.id.startsWith('USER-STUB-') &&
        !rule.id.startsWith('VARGA-PROTOCOL-');
    if (alternateD16) return null;

    if (rule.status == UnifiedVargaRuleStatus.notMatched) return false;
    if (rule.status != UnifiedVargaRuleStatus.matched) return null;

    // Even a computed true condition is not a *result* if there is no
    // identifiable IF condition and THEN outcome in the source.
    if (rule.condition.trim().isEmpty || rule.outcome.trim().isEmpty) {
      return null;
    }
    return true;
  }

  /// D3 ascendant support and affliction may coexist in the same horoscope.
  /// They are independent IF checks, not exclusive predictions; the D3 UI
  /// combines two TRUE checks into one mixed assessment with both source IDs.
  static bool d3KarmaHasMixedEvidence(Iterable<VargaRuleHit> hits) {
    final matchedIds = <String>{
      for (final hit in hits)
        if (hit.factor == 3 && calculatedMatch(hit) == true) hit.ruleId,
    };
    return matchedIds.contains('SJ7-D3-02') &&
        matchedIds.contains('SJ7-D3-02-CAUTION');
  }

  static int priority(bool? match) => match == true ? 0 :
      match == false ? 1 : 2;

  static int countMatched(Iterable<bool?> matches) =>
      matches.where((m) => m == true).length;

  static int countRejected(Iterable<bool?> matches) =>
      matches.where((m) => m == false).length;

  static int countPending(Iterable<bool?> matches) =>
      matches.where((m) => m == null).length;
}
