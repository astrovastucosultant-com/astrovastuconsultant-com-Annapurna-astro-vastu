import 'bcp_master_engine.dart';

/// Only describes *computed BCP associations*. A BCP association must never
/// be promoted into a natal promise or a guaranteed event by this helper.
class BcpYearResultExplainer {
  static const _planetTe = <String, String>{
    'sun': 'రవి', 'moon': 'చంద్రుడు', 'mars': 'కుజుడు',
    'mercury': 'బుధుడు', 'jupiter': 'గురువు', 'venus': 'శుక్రుడు',
    'saturn': 'శని', 'rahu': 'రాహువు', 'ketu': 'కేతువు',
  };
  static const _signTe = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  /// Editorial areas to REVIEW, not asserted events.
  static const Map<BcpEventKind, String> _focus = {
    BcpEventKind.marriage: 'వివాహ సంబంధాలు, వివాహ చర్చలు',
    BcpEventKind.childbirth: 'సంతాన ప్రయత్నాలు, కుటుంబ విస్తరణ',
    BcpEventKind.service: 'ఉద్యోగ అవకాశం, ఉద్యోగ బాధ్యతలు',
    BcpEventKind.business: 'వ్యాపార ప్రయత్నాలు, వ్యాపార నిర్ణయాలు',
    BcpEventKind.promotion: 'పదోన్నతి ప్రయత్నాలు, పదవి బాధ్యతలు',
    BcpEventKind.careerChange: 'వృత్తి మార్పు, కొత్త పనిలో ప్రవేశం',
    BcpEventKind.wealth: 'ధన ఆదాయం, పొదుపు, లాభం',
    BcpEventKind.property: 'భూమి, ఇల్లు, స్థిరాస్తి వ్యవహారాలు',
    BcpEventKind.education: 'విద్య, పరీక్షలు, కోర్సుల ఎంపిక',
    BcpEventKind.foreignTravel: 'విదేశ సంబంధాలు, దీర్ఘ ప్రయాణాలు',
    BcpEventKind.healthReview: 'శరీర ఆరోగ్యంపై శ్రద్ధ, సాధారణ ఆరోగ్య పరిశీలన',
    BcpEventKind.spirituality: 'తీర్థయాత్రలు, ఆధ్యాత్మిక ఆసక్తి',
    BcpEventKind.partnership: 'వ్యాపార భాగస్వామ్యాలు, ఒప్పందాలు',
    BcpEventKind.relationshipChange: 'కుటుంబ, దాంపత్య సంబంధాల్లో నిర్ణయాలు',
    BcpEventKind.transfer: 'ఉద్యోగ బదిలీ, పని స్థల మార్పు',
    BcpEventKind.resignation: 'ఉద్యోగం విడిచే ఆలోచనలు, పని మార్పు',
    BcpEventKind.competitiveExam: 'పోటీ పరీక్షలు, నియామక ప్రయత్నాలు',
    BcpEventKind.borrowing: 'రుణాలు, అప్పు చెల్లింపులు',
    BcpEventKind.vehicle: 'వాహన కొనుగోలు, నిర్వహణ',
    BcpEventKind.residenceChange: 'ఇల్లు మారడం, నివాస నిర్ణయాలు',
    BcpEventKind.motherMatters: 'తల్లి, కుటుంబ గృహ విషయాలు',
    BcpEventKind.fatherMatters: 'తండ్రి, కుటుంబ బాధ్యతలు',
    BcpEventKind.siblings: 'సోదరులు, సోదరీమణులతో వ్యవహారాలు',
    BcpEventKind.disputes: 'వివాదాలు, ఒప్పందాల పరిశీలన',
    BcpEventKind.recognition: 'గౌరవం, పేరు, వృత్తి గుర్తింపు',
    BcpEventKind.retirement: 'పదవీ విరమణ ప్రణాళిక, బాధ్యతల్లో మార్పు',
  };

  /// BCP links alone do not deserve a prominent event result card. Keep
  /// such links in a collapsed, auditable review section. A complete natal
  /// match can be highlighted, but it still does not guarantee timing.
  static bool hasIndependentNatalSupport(BcpEvidenceScore score) =>
      score.hasVerifiedNatalRule;

  static String focus(BcpEventKind kind) => _focus[kind] ?? 'సంబంధిత అంశాలు';

  static String _planet(String name) => _planetTe[name.toLowerCase()] ?? name;

  static String _sign(int sign) => _signTe[(sign - 1) % 12];

  static String describeLink(NatalChart chart, BcpActivation activation, String link) {
    final separator = link.indexOf(':');
    if (separator < 0) return 'BCP సంబంధం: $link';
    final code = link.substring(0, separator).trim();
    final value = link.substring(separator + 1).trim();
    final houseMatch = RegExp(r'^house\s+(\d+)\s+->\s+([a-z]+)$').firstMatch(value);
    final planet = houseMatch?.group(2) ?? value;
    final house = houseMatch?.group(1);
    final sign = chart.signOf(planet);
    final degree = chart.intraSignDegree(planet);
    final position = sign == null ? '' :
        ' (${_sign(sign)} ${degree!.toStringAsFixed(2)}°)';
    switch (code) {
      case 'DIRECT_HOUSE':
        return 'జన్మ ${activation.activatedNatalHouse}వ భావం క్రియాశీలమైంది • ${_sign(activation.activatedSign)}';
      case 'HOUSE_LORD_OCCUPIES_ACTIVE_SIGN':
        return 'జన్మ ${house ?? '?'}వ భావాధిపతి ${_planet(planet)}$position క్రియాశీల రాశిలో ఉన్నాడు';
      case 'HOUSE_LORD_ASPECT':
        return 'జన్మ ${house ?? '?'}వ భావాధిపతి ${_planet(planet)}$position క్రియాశీల రాశిపై దృష్టి కలిగి ఉన్నాడు';
      case 'KARAKA_OCCUPIES_ACTIVE_SIGN':
        return 'కారకగ్రహం ${_planet(planet)}$position క్రియాశీల రాశిలో ఉంది';
      case 'KARAKA_ASPECTS_ACTIVE_SIGN':
        return 'కారకగ్రహం ${_planet(planet)}$position క్రియాశీల రాశిపై దృష్టి కలిగి ఉంది';
      default:
        return link;
    }
  }

  static String strongestLink(NatalChart chart, BcpActivation activation, List<String> links) {
    if (links.isEmpty) {
      return 'ఈ సంవత్సరంలో ప్రత్యక్ష BCP భావాధిపతి / కారకగ్రహ సంబంధం గుర్తించలేదు';
    }
    const order = <String>[
      'DIRECT_HOUSE', 'HOUSE_LORD_OCCUPIES_ACTIVE_SIGN',
      'KARAKA_OCCUPIES_ACTIVE_SIGN', 'HOUSE_LORD_ASPECT',
      'KARAKA_ASPECTS_ACTIVE_SIGN',
    ];
    final ranked = [...links]..sort((a, b) {
      final ai = order.indexOf(a.split(':').first);
      final bi = order.indexOf(b.split(':').first);
      return (ai < 0 ? 99 : ai).compareTo(bi < 0 ? 99 : bi);
    });
    return describeLink(chart, activation, ranked.first);
  }

  static String yearPreview(NatalChart chart, BcpActivation activation,
      BcpEventDefinition event, List<String> links) {
    if (links.isEmpty) return 'ఈ BCP సంవత్సరంలో ప్రత్యక్ష సంబంధం లేదు; ఇతర పద్ధతుల ద్వారా సంఘటనను నిరాకరించలేం.';
    return '${focus(event.kind)} • ${strongestLink(chart, activation, links)}. '
        'ఇది కాలసంబంధ పరిశీలన; జరిగిన సంఘటన అని నిర్ధారణ కాదు.';
  }
}
