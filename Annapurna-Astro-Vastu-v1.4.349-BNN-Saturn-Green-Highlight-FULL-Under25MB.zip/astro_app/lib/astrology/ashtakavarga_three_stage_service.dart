import 'astro_models.dart';
import 'ashtakavarga_service.dart';

/// Source: M. S. Mehta, Ashtakvarga: Concept and Application, printed pp. 48–49.
///
/// The three four-sign bands and Bandhu/Sevaka sums are source-backed. The
/// approximate 33-year labels are USER-CHOSEN presentation bins, not a
/// calendar-year timing formula supplied by this source. Neither SAV totals
/// nor the difference between bands measures probability or a financial loss.
class AvLifeStage {
  final int index;
  final int startAge;
  final int endAge;
  final int fixedBindus;
  final int lagnaBindus;
  const AvLifeStage({
    required this.index,
    required this.startAge,
    required this.endAge,
    required this.fixedBindus,
    required this.lagnaBindus,
  });
  String get approximateAgeLabel => '$startAge–$endAge సంవత్సరాలు';
}

class AvLifeStageEvidence {
  final bool valid;
  final int savGrandTotal;
  final List<AvLifeStage> stages;
  final int bandhu;
  final int sevaka;
  final int? leadingFixedStage;
  final int? leadingLagnaStage;
  final String modeSupport;
  const AvLifeStageEvidence({
    required this.valid,
    required this.savGrandTotal,
    required this.stages,
    required this.bandhu,
    required this.sevaka,
    required this.leadingFixedStage,
    required this.leadingLagnaStage,
    required this.modeSupport,
  });
  bool get methodsAgree => leadingFixedStage != null &&
      leadingFixedStage == leadingLagnaStage;

  AvLifeStage? atAge(int age) {
    for (final stage in stages) {
      if (age >= stage.startAge && age <= stage.endAge) return stage;
    }
    return null;
  }
}

class AshtakavargaThreeStageService {
  static const source = 'M. S. Mehta, Ashtakvarga: Concept and Application, '
      'printed pp. 48 (Bandhu/Sevaka) & 49 (Periods for Prosperity)';

  static int? _uniqueMaximum(List<int> scores) {
    if (scores.length != 3) return null;
    final maxScore = scores.reduce((a, b) => a > b ? a : b);
    return scores.where((v) => v == maxScore).length == 1
        ? scores.indexOf(maxScore) : null;
  }

  static AvLifeStageEvidence evaluate({
    required List<int> sarvaBySign,
    required int lagnaSignIndex,
  }) {
    final valid = sarvaBySign.length == 12 &&
        sarvaBySign.every((v) => v >= 0 && v <= 56) &&
        sarvaBySign.fold<int>(0, (a, b) => a + b) == 337 &&
        lagnaSignIndex >= 0 && lagnaSignIndex < 12;
    if (!valid) {
      return AvLifeStageEvidence(
        valid: false, savGrandTotal: sarvaBySign.fold<int>(0, (a, b) => a + b),
        stages: const [], bandhu: 0, sevaka: 0,
        leadingFixedStage: null, leadingLagnaStage: null,
        modeSupport: 'SAV గణన ధృవీకరణ కాలేదు',
      );
    }
    int totalFrom(int startSign, int count) => List.generate(count,
      (i) => sarvaBySign[(startSign + i) % 12]
    ).fold<int>(0, (a, b) => a + b);
    int house(int h) => sarvaBySign[(lagnaSignIndex + h - 1) % 12];
    final fixed = <int>[]; // Pisces→Gemini, Cancer→Libra, Scorpio→Aquarius.
    final relative = <int>[]; // Alternate: Lagna 1–4, 5–8, 9–12.
    for (var i = 0; i < 3; i++) {
      fixed.add(totalFrom((11 + i * 4) % 12, 4));
      relative.add(totalFrom((lagnaSignIndex + i * 4) % 12, 4));
    }
    final bandhu = house(1) + house(5) + house(9);
    final sevaka = house(2) + house(6) + house(10);
    final stageList = List<AvLifeStage>.unmodifiable(List.generate(3, (i) =>
      AvLifeStage(index: i, startAge: i * 33, endAge: i * 33 + 32,
          fixedBindus: fixed[i], lagnaBindus: relative[i])));
    return AvLifeStageEvidence(
      valid: true, savGrandTotal: 337, stages: stageList,
      bandhu: bandhu, sevaka: sevaka,
      leadingFixedStage: _uniqueMaximum(fixed),
      leadingLagnaStage: _uniqueMaximum(relative),
      modeSupport: bandhu > sevaka ? 'గోచరిష్ట — స్వతంత్ర వృత్తికి అదనపు ఆధారం' :
          sevaka > bandhu ? 'అగోచరిష్ట — ఉద్యోగానికి అదనపు ఆధారం' :
          'బంధు–సేవక బిందువులు సమానం — అదనపు ఆధిక్యం లేదు',
    );
  }

  static AvLifeStageEvidence fromChart(AstroChartResult chart) {
    final av = AshtakavargaService.calculate(chart);
    return evaluate(sarvaBySign: av.sarva,
        lagnaSignIndex: chart.ascendantSignIndex);
  }

  static int completedAge(DateTime birth, DateTime asOf) {
    var age = asOf.year - birth.year;
    if (asOf.month < birth.month ||
        (asOf.month == birth.month && asOf.day < birth.day)) age--;
    return age;
  }
}
