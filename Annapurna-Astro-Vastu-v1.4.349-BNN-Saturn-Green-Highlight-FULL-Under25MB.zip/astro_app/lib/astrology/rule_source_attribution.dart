/// Distinguishes the contributor of the rule material from the author of the
/// original published work. A filename such as "Mallikarjuna PDF" is NEVER
/// evidence that Siddhanti Mallikarjuna wrote the classical rule.
///
/// A title, an uploaded-PDF page, or an author name typed into a free-form
/// source string does not automatically verify the original printed citation.
/// Source authorship is entered only after an explicit bibliographic audit.
class RuleSourceAttribution {
  static const collector = 'సిద్ధాంతి మల్లికార్జున';
  static const originalPending = 'మూలగ్రంథ రచయిత / ముద్రిత పేజీ ధృవీకరణ పెండింగ్';

  final String? suppliedSource;
  final String? verifiedAuthor;
  final String? verifiedBook;
  final String? verifiedPrintedPage;
  final bool explicitlyUserAuthored;

  const RuleSourceAttribution({
    this.suppliedSource,
    this.verifiedAuthor,
    this.verifiedBook,
    this.verifiedPrintedPage,
    this.explicitlyUserAuthored = false,
  });

  bool get verifiedOriginal =>
      (verifiedAuthor?.trim().isNotEmpty ?? false) &&
      (verifiedBook?.trim().isNotEmpty ?? false) &&
      (verifiedPrintedPage?.trim().isNotEmpty ?? false);

  bool get hasSuppliedSource {
    final s = suppliedSource?.trim() ?? '';
    return s.isNotEmpty && !s.toUpperCase().contains('SOURCE_PENDING');
  }

  /// Supplied page references are preserved as they were received; they are
  /// not promoted to original-book page numbers without verification.
  String get sourceLine => hasSuppliedSource
      ? 'అందించిన మూలపత్రం / సూచన: ${suppliedSource!.trim()}'
      : 'అందించిన మూలపత్రం: పూర్తి వివరాలు లభించలేదు';

  String get originalLine {
    if (explicitlyUserAuthored) {
      return 'స్వయంగా రచించిన నియమం: $collector';
    }
    if (verifiedOriginal) {
      return 'ధృవీకరించిన మూలగ్రంథం: ${verifiedBook!.trim()} • '
          'రచయిత: ${verifiedAuthor!.trim()} • '
          'ముద్రిత పేజీ: ${verifiedPrintedPage!.trim()}';
    }
    return originalPending;
  }

  String get contributorLine => 'నియమాలను సేకరించి అందించినవారు: $collector';
}
