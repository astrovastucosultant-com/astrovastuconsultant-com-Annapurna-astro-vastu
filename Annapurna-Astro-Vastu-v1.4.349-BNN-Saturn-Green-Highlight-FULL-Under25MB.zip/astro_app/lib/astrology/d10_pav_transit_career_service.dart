import '../models/birth_data.dart';
import 'astro_calculation_service.dart';
import 'astro_models.dart';
import 'ashtakavarga_pav_career_service.dart';
import 'ashtakavarga_service.dart';

/// Sidereal, date-specific gochara evidence for the D10 career timing report.
/// BAV/SAV/PAV are calculated from the NATAL D1 chart, not from a transit chart.
/// No transit alone proves promotion, a job loss, or a monetary percentage.
typedef D10TransitPlanetResolver = Future<PlanetPosition> Function({
  required DateTime utc,
  required String planetName,
  required AyanamsaType ayanamsa,
});

class D10PavTransitPlanet {
  final PlanetPosition position;
  final int houseFromNatalLagna;
  final int bav;
  final int sav;
  final AvPavTransitKakshya kakshya;
  final bool isDashaLord;
  const D10PavTransitPlanet({
    required this.position,
    required this.houseFromNatalLagna,
    required this.bav,
    required this.sav,
    required this.kakshya,
    required this.isDashaLord,
  });

  String get signal {
    if (!kakshya.hasBindu) return 'ఈ కక్ష్యలో బిందువు లేదు — సహాయక మద్దతు తక్కువ';
    if (bav >= 5 && sav >= 28) return 'కక్ష్య బిందువు ఉంది; BAV/SAV అనుకూల మద్దతు';
    if (bav <= 3 || sav < 25) return 'కక్ష్య బిందువు ఉంది; BAV/SAV బలం పరిమితం';
    return 'కక్ష్య బిందువు ఉంది; BAV/SAV మిశ్రమ మద్దతు';
  }
}

class D10PavTransitReport {
  final DateTime localDateTime;
  final DateTime utcDateTime;
  final AyanamsaType ayanamsa;
  final double timezoneOffsetHours;
  final List<D10PavTransitPlanet> planets;
  final List<String> omittedDashaLords;
  final String ruleId;
  final String audit;
  const D10PavTransitReport({
    required this.localDateTime,
    required this.utcDateTime,
    required this.ayanamsa,
    required this.timezoneOffsetHours,
    required this.planets,
    required this.omittedDashaLords,
    required this.ruleId,
    required this.audit,
  });
}

class D10PavTransitCareerService {
  static const ruleId = 'AV-PAV-KAKSHYA-GOCHARA';
  static const source = 'P.V.R. Narasimha Rao, Vedic Astrology, section 25.5.2, Table 60 (Kakshya order and degrees)';
  static const planetOrder = <String>[
    'Jupiter', 'Saturn', 'Sun', 'Moon', 'Mars', 'Mercury', 'Venus',
  ];

  /// Convert the native's recorded local clock to UTC by the recorded birth
  /// timezone. Do not use device .toUtc(): the client may be in another zone.
  static DateTime localToUtc(BirthData birthData, DateTime local) {
    final localClockAsUtc = DateTime.utc(local.year, local.month, local.day,
        local.hour, local.minute, local.second, local.millisecond);
    final offsetMinutes = (birthData.timezoneOffsetHours * 60).round();
    return localClockAsUtc.subtract(Duration(minutes: offsetMinutes));
  }

  /// Pure evaluator suitable for comparison tests without Swiss Ephemeris.
  /// Requires precisely one sidereal position per standard BAV recipient.
  static D10PavTransitReport evaluatePositions({
    required BirthData birthData,
    required AstroChartResult natal,
    required AshtakavargaResult av,
    required DateTime localDateTime,
    required List<PlanetPosition> transitPositions,
    String? mahadasha,
    String? antardasha,
  }) {
    if (!AshtakavargaPavCareerService.audit(av)) {
      throw StateError('Natal PAV/BAV audit mismatch; transit result withheld');
    }
    final seen = <String, PlanetPosition>{};
    for (final position in transitPositions) {
      if (!AshtakavargaService.planetOrder.contains(position.name) ||
          !position.longitude.isFinite || position.longitude < 0 ||
          position.longitude >= 360 || !position.speed.isFinite ||
          seen.containsKey(position.name)) {
        throw StateError('Invalid or duplicate transit position ${position.name}');
      }
      seen[position.name] = position;
    }
    if (seen.length != AshtakavargaService.planetOrder.length) {
      throw StateError('All seven classical transit positions are required');
    }
    final lords = <String>{if (mahadasha != null) mahadasha,
      if (antardasha != null) antardasha};
    final results = <D10PavTransitPlanet>[];
    for (final planet in planetOrder) {
      final pos = seen[planet]!;
      final kakshya = AshtakavargaPavCareerService.atTransit(
        av: av, recipient: planet, siderealTransitLongitude: pos.longitude);
      if (kakshya == null) {
        throw StateError('Cannot resolve PAV kakshya for $planet');
      }
      results.add(D10PavTransitPlanet(
        position: pos,
        houseFromNatalLagna:
            ((pos.signIndex - natal.ascendantSignIndex + 12) % 12) + 1,
        bav: av.bhinna[planet]![pos.signIndex],
        sav: av.sarva[pos.signIndex],
        kakshya: kakshya,
        isDashaLord: lords.contains(planet),
      ));
    }
    final omitted = lords
        .where((p) => !AshtakavargaService.planetOrder.contains(p))
        .toList(growable: false);
    return D10PavTransitReport(
      localDateTime: localDateTime,
      utcDateTime: localToUtc(birthData, localDateTime),
      ayanamsa: birthData.ayanamsa,
      timezoneOffsetHours: birthData.timezoneOffsetHours,
      planets: List.unmodifiable(results),
      omittedDashaLords: List.unmodifiable(omitted),
      ruleId: ruleId,
      audit: 'Swiss Ephemeris/Moshier నిరయణ గోచారం • జన్మ D1 అష్టకవర్గం '
          '337 బిందువుల audit • 1 కక్ష్య = 3°45′. '
          'కక్ష్య బిందువు Rising/Downfallకి స్వతంత్ర నిర్ధారణ కాదు. '
          'దశ, జన్మ వృత్తియోగం, D10 నియమాలతో కలిపి మాత్రమే ఉపయోగించాలి.',
    );
  }

  /// Calculate actual longitude and speed at the requested calendar instant.
  /// A chosen date defaults in UI to 12:00 in the natal chart's timezone.
  static Future<D10PavTransitReport> calculate({
    required BirthData birthData,
    required AstroChartResult natal,
    required AshtakavargaResult av,
    required DateTime localDateTime,
    String? mahadasha,
    String? antardasha,
    D10TransitPlanetResolver? resolver,
  }) async {
    if (!AshtakavargaPavCareerService.audit(av)) {
      throw StateError('Natal PAV/BAV audit mismatch; transit not calculated');
    }
    final D10TransitPlanetResolver lookup =
        resolver ?? AstroCalculationService.calculatePlanetAtUtc;
    final utc = localToUtc(birthData, localDateTime);
    final positions = <PlanetPosition>[];
    for (final planet in planetOrder) {
      positions.add(await lookup(utc: utc, planetName: planet,
          ayanamsa: birthData.ayanamsa));
    }
    return evaluatePositions(
      birthData: birthData, natal: natal, av: av,
      localDateTime: localDateTime, transitPositions: positions,
      mahadasha: mahadasha, antardasha: antardasha,
    );
  }
}
