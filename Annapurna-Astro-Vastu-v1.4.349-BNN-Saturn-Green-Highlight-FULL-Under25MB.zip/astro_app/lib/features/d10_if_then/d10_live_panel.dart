import 'package:flutter/material.dart';

import '../../astrology/astro_models.dart';
import '../../astrology/varga_rule_service.dart';
import 'd10_if_then_engine.dart';
import 'd10_live_bridge.dart';
import 'd10_rules_panel.dart';

/// New 1.4.326 lead panel; existing D10 report remains fully in place below.
class D10LiveIfThenPanel extends StatefulWidget {
  final AstroChartResult chart;
  final List<VargaRuleHit> rules;

  const D10LiveIfThenPanel({
    super.key,
    required this.chart,
    required this.rules,
  });

  @override
  State<D10LiveIfThenPanel> createState() => _D10LiveIfThenPanelState();
}

class _D10LiveIfThenPanelState extends State<D10LiveIfThenPanel> {
  late Future<List<VargaCrossObservation>> _cross;

  @override
  void initState() {
    super.initState();
    _cross = D10LiveBridge.crossObservations(widget.chart);
  }

  @override
  void didUpdateWidget(covariant D10LiveIfThenPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (!identical(oldWidget.chart, widget.chart)) {
      _cross = D10LiveBridge.crossObservations(widget.chart);
    }
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<VargaCrossObservation>>(
    future: _cross,
    builder: (context, snapshot) {
      // A failed cross-varga catalog lookup cannot silently become career
      // evidence or prevent D1/D10 source rules from working.
      final cross = snapshot.data ?? const <VargaCrossObservation>[];
      final evidence = D10LiveBridge.context(
        chart: widget.chart,
        rules: widget.rules,
        crossVarga: cross,
      );
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        D10AppliedRulesPanel(
          report: D10IfThenEngine().evaluate(evidence),
        ),
        if (snapshot.hasError)
          const Padding(
            padding: EdgeInsets.only(left: 10, bottom: 10),
            child: Text('VARGA-CROSS మూల పరిశీలన లోడ్ కాలేదు; '
                'ఈ ఆధారాన్ని తుది ఫలితానికి ఉపయోగించలేదు.',
              style: TextStyle(fontSize: 12, color: Colors.grey)),
          ),
      ]);
    },
  );
}
