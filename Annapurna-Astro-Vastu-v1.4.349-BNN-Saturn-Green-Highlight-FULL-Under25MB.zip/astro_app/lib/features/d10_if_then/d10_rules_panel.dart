import 'package:flutter/material.dart';

import 'd10_if_then_engine.dart';

/// Add this widget to the EXISTING D10 screen; do not replace the screen,
/// legacy rule sections, career lists, or any of the 19 Varga charts.
///
/// Display: applied Rule -> tap -> natal inspection -> tap -> highlighted
/// result -> tap -> source-verified remedy (or explicit unavailable).
class D10AppliedRulesPanel extends StatefulWidget {
  const D10AppliedRulesPanel({super.key, required this.report});

  final D10MatchReport report;

  @override
  State<D10AppliedRulesPanel> createState() => _D10AppliedRulesPanelState();
}

class _D10AppliedRulesPanelState extends State<D10AppliedRulesPanel> {
  final Map<String, int> _step = <String, int>{};

  @override
  Widget build(BuildContext context) {
    final matches = widget.report.appliedRules;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Text('D10 · వర్తించిన నియమాలు ముందుగా',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        ),
        if (matches.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('ధ్రువీకరించిన D1/D10 ఆధారాలతో వర్తించిన IF–THEN నియమాలు లేవు.'),
          ),
        for (final match in matches) _ruleTile(match),
        if (widget.report.crossVarga.isNotEmpty)
          Card(
            color: const Color(0xFFF3F5FA),
            margin: const EdgeInsets.fromLTRB(4, 5, 4, 9),
            child: ExpansionTile(
              initiallyExpanded: false,
              title: const Text('VARGA-CROSS — పరిశీలన మాత్రమే',
                  style: TextStyle(fontWeight: FontWeight.w800)),
              subtitle: const Text('ఈ మూల నియమాలు D10 ఫలితాన్ని trigger చేయవు'),
              childrenPadding: const EdgeInsets.all(10),
              children: [
                for (final item in widget.report.crossVarga)
                  ListTile(
                    dense: true,
                    title: Text(item.sourceRuleId ?? item.varga),
                    subtitle: Text(item.inspection),
                  ),
              ],
            ),
          ),
        if (widget.report.insufficientRules.isNotEmpty)
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              'అసంపూర్ణ సమాచారం: ${widget.report.insufficientRules.length} నియమాలు (ఫలితాలుగా చూపలేదు)',
              style: const TextStyle(color: Colors.grey),
            ),
          ),
      ],
    );
  }

  Widget _ruleTile(D10RuleCheck match) {
    final rule = match.rule;
    final stage = _step[rule.id] ?? 0;
    return Card(
      color: rule.isFavourable
          ? const Color(0xFFECF7EF)
          : const Color(0xFFFBEAF0),
      surfaceTintColor: Colors.transparent,
      key: ValueKey('d10-applied-${rule.id}'),
      margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 4),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Text('రూల్ · ${rule.id}',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(rule.title),
            Text(rule.sourceName, style: const TextStyle(fontSize: 12)),
            if (rule.sourcePage != null)
              Text('మూల పుట: ${rule.sourcePage}'),
            if (stage >= 1) ...<Widget>[
              const Divider(),
              const Text('జాతక పరిశీలన',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              for (final fact in match.matchedFacts)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text('• ${fact.chart} / ${fact.key}: ${fact.inspection}'
                      '${fact.sourceRuleId == null ? '' : ' [${fact.sourceRuleId}]'}'
                      '${fact.sourcePage == null ? '' : ' పుట ${fact.sourcePage}'}'),
                ),
            ],
            if (stage >= 2) ...<Widget>[
              const SizedBox(height: 8),
              Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: rule.isFavourable
                      ? const Color(0xFFE0F3E4)
                      : const Color(0xFFFCE4EC),
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.all(10),
                child: Text('హైలైట్ ఫలితం: ${rule.highlightResult}',
                    style: const TextStyle(fontWeight: FontWeight.bold,
                        color: Colors.black87)),
              ),
            ],
            if (stage >= 3) ...<Widget>[
              const SizedBox(height: 8),
              const Text('పరిహారం',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              Text(rule.verifiedRemedy ??
                  'మూలగ్రంథం ఆధారంగా ధ్రువీకరించిన పరిహారం అందుబాటులో లేదు.'),
            ],
            if (stage < 3) ...<Widget>[
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => setState(() => _step[rule.id] = stage + 1),
                child: Text(stage == 0
                    ? 'రూల్ టచ్ → జాతక పరిశీలన'
                    : stage == 1
                        ? 'పరిశీలన టచ్ → హైలైట్ ఫలితం'
                        : 'ఫలితం టచ్ → పరిహారం'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
