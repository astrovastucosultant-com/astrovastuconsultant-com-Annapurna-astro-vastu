/// D10 evidence-gated IF–THEN matching for Annapurna Astro Vastu.
///
/// This is an additive module. It never deletes/replaces legacy rules or Vargas.
/// Source/book pages and remedies must come from verified, existing rule data.
/// IMPORTANT: cross-Varga observations are for inspection only; they do not
/// independently establish a D10 career outcome.

import 'dart:collection';

/// Keys must be populated from *calculated* D1/D10 chart positions/strengths.
/// Null means not calculated, not 'false'. Never use hard-coded birth defaults.
abstract final class D10FactKeys {
  static const d1Gocharishta = 'D1_GOCHARISHTA';
  static const d10Gocharishta = 'D10_GOCHARISHTA';
  static const d1Agocharishta = 'D1_AGOCHARISHTA';
  static const d10Agocharishta = 'D10_AGOCHARISHTA';
  static const d10BusinessYoga = 'D10_BUSINESS_YOGA';
  static const d1IndependentPP = 'D1_INDEPENDENT_PP';
  static const d10SeventhBusinessSupport = 'D10_7H_BUSINESS_SUPPORT';
  static const d1ServicePromise = 'D1_SERVICE_PROMISE';
  static const d10ServiceYoga = 'D10_SERVICE_YOGA';
  static const d1SunAuthorityLink = 'D1_SUN_AUTHORITY_LINK';
  static const d10SunAuthorityLink = 'D10_SUN_AUTHORITY_LINK';
  static const d1GovernmentLink = 'D1_GOVERNMENT_LINK';
  static const d10GovernmentLink = 'D10_GOVERNMENT_LINK';
  static const d1CareerSupport = 'D1_CAREER_SUPPORT';
  static const d10TenthLordStrong = 'D10_10L_STRONG';
}

class D10Fact {
  const D10Fact({
    required this.key,
    required this.chart,
    required this.met,
    required this.inspection,
    this.sourceRuleId,
    this.sourcePage,
  });

  final String key;
  final String chart; // D1 or D10 for a deciding fact
  final bool? met; // null: data unavailable
  final String inspection; // real natal evidence, NOT a generic prediction
  final String? sourceRuleId;
  final int? sourcePage;

  bool get isDecidingChart => chart == 'D1' || chart == 'D10';
}

class VargaCrossObservation {
  const VargaCrossObservation({
    required this.varga,
    required this.inspection,
    this.sourceRuleId,
    this.sourcePage,
  });

  final String varga; // D2/D4/D9 etc., can be any existing Varga
  final String inspection;
  final String? sourceRuleId;
  final int? sourcePage;
}

class D10EvidenceContext {
  D10EvidenceContext({
    required Iterable<D10Fact> facts,
    Iterable<VargaCrossObservation> crossVarga = const [],
  })  : facts = UnmodifiableMapView<String, D10Fact>(_index(facts)),
        crossVarga = List.unmodifiable(crossVarga) {
    _validateExclusivePaths(this.facts);
  }

  final Map<String, D10Fact> facts;
  final List<VargaCrossObservation> crossVarga;

  static Map<String, D10Fact> _index(Iterable<D10Fact> supplied) {
    final map = <String, D10Fact>{};
    for (final fact in supplied) {
      if (map.containsKey(fact.key)) {
        throw ArgumentError('Duplicate evidence key: ${fact.key}');
      }
      map[fact.key] = fact;
    }
    return map;
  }

  static void _validateExclusivePaths(Map<String, D10Fact> facts) {
    for (final pair in <List<String>>[
      [D10FactKeys.d1Gocharishta, D10FactKeys.d1Agocharishta],
      [D10FactKeys.d10Gocharishta, D10FactKeys.d10Agocharishta],
    ]) {
      final first = facts[pair[0]];
      final second = facts[pair[1]];
      if (first != null && second != null &&
          first.isDecidingChart && second.isDecidingChart &&
          first.met == true && second.met == true) {
        throw ArgumentError('Contradictory career classification: ${pair.join(' and ')}');
      }
    }
  }

  /// Fail closed: a fact outside D1/D10 is not final-outcome evidence.
  bool? decidingValue(String key) {
    final fact = facts[key];
    if (fact == null || !fact.isDecidingChart) return null;
    return fact.met;
  }
}

enum D10CareerKind { governmentService, business, service, mixedSequence }

enum D10CheckStatus { applied, contradicted, insufficientEvidence }

/// AND of clauses; each clause is an OR of fact keys.
/// An outcome is applied only when ALL clauses contain at least one true fact.
class D10RuleDefinition {
  const D10RuleDefinition({
    required this.id,
    required this.title,
    required this.careerKind,
    required this.clauses,
    required this.highlightResult,
    this.sourceName = 'యాప్ IF–THEN అమలు నియమం — మూలపుట ధ్రువీకరణ అవసరం',
    this.sourcePage,
    this.verifiedRemedy,
    this.isFavourable = true,
  });

  final String id;
  final String title;
  final D10CareerKind careerKind;
  final List<List<String>> clauses;
  final String highlightResult;
  final String sourceName;
  final int? sourcePage;
  final String? verifiedRemedy;
  final bool isFavourable;
}

class D10RuleCheck {
  const D10RuleCheck({
    required this.rule,
    required this.status,
    required this.matchedFacts,
    required this.missingKeys,
    required this.failedClauses,
  });

  final D10RuleDefinition rule;
  final D10CheckStatus status;
  final List<D10Fact> matchedFacts;
  final List<String> missingKeys;
  final List<List<String>> failedClauses;

  bool get isApplied => status == D10CheckStatus.applied;
}

class D10MatchReport {
  const D10MatchReport({required this.checks, required this.crossVarga});
  final List<D10RuleCheck> checks;
  final List<VargaCrossObservation> crossVarga;

  /// UI renders these first; unverified/unmatched rules are never predictions.
  List<D10RuleCheck> get appliedRules =>
      List.unmodifiable(checks.where((check) => check.isApplied));

  List<D10RuleCheck> get insufficientRules => List.unmodifiable(
      checks.where((check) => check.status == D10CheckStatus.insufficientEvidence));
}

class D10IfThenEngine {
  D10IfThenEngine({List<D10RuleDefinition>? definitions})
      : definitions = List.unmodifiable(definitions ?? defaultRules) {
    final ids = <String>{};
    for (final rule in this.definitions) {
      if (!ids.add(rule.id)) {
        throw ArgumentError('Duplicate rule ID: ${rule.id}');
      }
      if (rule.clauses.isEmpty || rule.clauses.any((clause) => clause.isEmpty)) {
        throw ArgumentError('Rule clauses must not be empty: ${rule.id}');
      }
      if (rule.verifiedRemedy != null &&
          (rule.sourcePage == null ||
              rule.sourceName.contains('ధ్రువీకరణ అవసరం'))) {
        throw ArgumentError('Remedy needs verified source and page: ${rule.id}');
      }
    }
  }

  final List<D10RuleDefinition> definitions;

  D10MatchReport evaluate(D10EvidenceContext context) {
    final checks = <D10RuleCheck>[];
    for (final rule in definitions) {
      final evidence = <String, D10Fact>{};
      final missing = <String>{};
      final failed = <List<String>>[];
      var hasUnresolvedClause = false;
      for (final clause in rule.clauses) {
        var clausePassed = false;
        var clauseUnknown = false;
        for (final key in clause) {
          final value = context.decidingValue(key);
          if (value == true) {
            clausePassed = true;
            final fact = context.facts[key];
            if (fact != null) evidence[key] = fact;
          } else if (value == null) {
            clauseUnknown = true;
            missing.add(key);
          }
        }
        if (!clausePassed) {
          if (clauseUnknown) {
            hasUnresolvedClause = true;
          } else {
            failed.add(List.unmodifiable(clause));
          }
        }
      }
      final status = failed.isNotEmpty
          ? D10CheckStatus.contradicted
          : hasUnresolvedClause
              ? D10CheckStatus.insufficientEvidence
              : D10CheckStatus.applied;
      checks.add(D10RuleCheck(
        rule: rule,
        status: status,
        matchedFacts: List.unmodifiable(evidence.values),
        missingKeys: List.unmodifiable(missing),
        failedClauses: List.unmodifiable(failed),
      ));
    }
    return D10MatchReport(
      checks: List.unmodifiable(checks),
      crossVarga: List.unmodifiable(context.crossVarga),
    );
  }

  // Source-backed conditions are evaluated from the live horoscope by
  // D10LiveBridge. A D10 work MODE is not proof of actual hiring/profit.
  // Mixed D1→D10 stages must not be suppressed by an extra same-mode D1 gate.
  static const List<D10RuleDefinition> defaultRules = [
    D10RuleDefinition(
      id: 'D10-IF-GOV-001',
      title: 'ప్రభుత్వ ఉద్యోగం — మూల సూచన + D10 ఉద్యోగ విధానం + అధికార పరిశీలన',
      careerKind: D10CareerKind.governmentService,
      clauses: [
        [D10FactKeys.d1GovernmentLink],
        [D10FactKeys.d10Agocharishta],
        [D10FactKeys.d10SunAuthorityLink],
      ],
      sourceName: 'gov job.pdf Chapter 26 p.1 (D1 5L/9L→D9 source rules) + '
          'D10 special.pdf Ch.04 pp.50–51 (work mode); '
          'ఈ AND కలయిక సిద్ధాంతి మల్లికార్జున పరిశీలన నియమం, '
          'పుస్తకంలోని స్వతంత్ర ప్రభుత్వ నియామక సూత్రం కాదు.',
      highlightResult: 'ప్రభుత్వ ఉద్యోగానికి సంబంధించిన జన్మసూచన, D10 సర్వీస్ '
          'విధానం, అధికార సంబంధం అన్నీ సరిపోయాయి. ఇది జ్యోతిష్యపరమైన '
          'సమగ్ర సూచన మాత్రమే; నియామకం, పరీక్ష విజయం లేదా తేదీకి హామీ కాదు.',
    ),
    D10RuleDefinition(
      id: 'D10-IF-BUS-001',
      title: 'గోచరిష్ట — D10 ప్రధాన వ్యాపార / స్వయం ఉపాధి విధానం',
      careerKind: D10CareerKind.business,
      clauses: [[D10FactKeys.d10Gocharishta]],
      sourceName: 'D10 special.pdf Chapter 04 Self Employed–Service p.50; '
          'existing D10-GOCHARISTA rule.',
      highlightResult: 'D10లో గోచరిష్ట శని విధానం వర్తించింది. '
          'స్వయం ఉపాధి / వ్యాపార పని విధాన సూచన మాత్రమే; '
          'వ్యాపార విజయం లేదా లాభం ఖాయం కాదు.',
    ),
    D10RuleDefinition(
      id: 'D10-IF-BUS-002',
      title: 'గోచరిష్ట + జన్మ PP గ్రహాలు — స్వతంత్ర వృత్తి మద్దతు',
      careerKind: D10CareerKind.business,
      clauses: [
        [D10FactKeys.d10Gocharishta],
        [D10FactKeys.d1IndependentPP],
      ],
      sourceName: 'D10 special.pdf Chapter 04 pp.50–51; '
          'existing D10-PP condition (Sun/Moon/Mars/Rahu >= 2 links).',
      highlightResult: 'D10 స్వయం ఉపాధి విధానానికి జన్మ PP గ్రహాల '
          'స్వతంత్ర వృత్తి సూచన కూడా సరిపోయింది; ఇది రెండవ మూల ఆధారం.',
    ),
    D10RuleDefinition(
      id: 'D10-IF-SRV-001',
      title: 'అగోచరిష్ట — D10 ప్రధాన ఉద్యోగ / సర్వీస్ విధానం',
      careerKind: D10CareerKind.service,
      clauses: [[D10FactKeys.d10Agocharishta]],
      sourceName: 'D10 special.pdf Chapter 04 Self Employed–Service pp.50–51; '
          'existing D10-AGOCHARISTA rule.',
      highlightResult: 'D10లో అగోచరిష్ట శని విధానం వర్తించింది. '
          'సర్వీస్ / ఉద్యోగ విధాన సూచన మాత్రమే; నియామకం ఖాయం కాదు.',
    ),
    D10RuleDefinition(
      id: 'D10-IF-SRV-002',
      title: 'D1 + D10 అగోచరిష్ట — ఉద్యోగ విధానం కొనసాగింపు',
      careerKind: D10CareerKind.service,
      clauses: [
        [D10FactKeys.d1Agocharishta],
        [D10FactKeys.d10Agocharishta],
      ],
      sourceName: 'D10 special.pdf Chapter 04 pp.50–51; '
          'existing D10-SEQUENCE rule.',
      highlightResult: 'జన్మ మరియు దశాంశంలో ఉద్యోగ విధాన సూచనలు '
          'కలిసి ఉన్నాయి; కాలనిర్ణయం వేరుగా పరీక్షించాలి.',
    ),
    D10RuleDefinition(
      id: 'D10-IF-BUS-003',
      title: 'D1 + D10 గోచరిష్ట — స్వతంత్ర వృత్తి విధానం కొనసాగింపు',
      careerKind: D10CareerKind.business,
      clauses: [
        [D10FactKeys.d1Gocharishta],
        [D10FactKeys.d10Gocharishta],
      ],
      sourceName: 'D10 special.pdf Chapter 04 pp.50–51; '
          'existing D10-SEQUENCE rule.',
      highlightResult: 'జన్మ మరియు దశాంశంలో స్వతంత్ర వృత్తి విధానం '
          'కలిసి ఉంది; సంఘటన/లాభం నిర్ధారణ కాదు.',
    ),
    D10RuleDefinition(
      id: 'D10-IF-MIX-001',
      title: 'D1 గోచరిష్ట + D10 అగోచరిష్ట — వృత్తి క్రమం',
      careerKind: D10CareerKind.mixedSequence,
      clauses: [
        [D10FactKeys.d1Gocharishta],
        [D10FactKeys.d10Agocharishta],
      ],
      sourceName: 'D10 special.pdf Chapter 04 pp.50–51; D10-SEQUENCE.',
      highlightResult: 'మొదట వ్యాపారం / స్వయం ఉపాధి → తరువాత '
          'ఉద్యోగ విధానం; నిజమైన సంవత్సరాలకు దశా పరిశీలన అవసరం.',
    ),
    D10RuleDefinition(
      id: 'D10-IF-MIX-002',
      title: 'D1 అగోచరిష్ట + D10 గోచరిష్ట — వృత్తి క్రమం',
      careerKind: D10CareerKind.mixedSequence,
      clauses: [
        [D10FactKeys.d1Agocharishta],
        [D10FactKeys.d10Gocharishta],
      ],
      sourceName: 'D10 special.pdf Chapter 04 pp.50–51; D10-SEQUENCE.',
      highlightResult: 'మొదట ఉద్యోగం / సర్వీస్ → తరువాత '
          'స్వయం ఉపాధి / వ్యాపార విధానం; ఖచ్చిత సమయం వేరు.',
    ),
  ];
}
