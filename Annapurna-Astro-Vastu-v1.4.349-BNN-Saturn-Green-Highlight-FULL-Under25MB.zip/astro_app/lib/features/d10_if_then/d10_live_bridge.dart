import '../../astrology/astro_models.dart';
import '../../astrology/d10_career_service.dart';
import '../../astrology/varga_rule_service.dart';
import '../../astrology/varga_service.dart';
import '../../astrology/varga_unified_rule_service.dart';
import 'd10_if_then_engine.dart';

/// Converts only calculated D1/D10 facts and explicit gov job.pdf source
/// matches to the v1.4.326 IF–THEN layer. Other vargas have NO decision path.
/// Keeps all existing VargaRuleService results and all 19 vargas untouched.
class D10LiveBridge {
  static const _requiredPlanets = <String>{
    'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus',
    'Saturn', 'Rahu', 'Ketu',
  };

  static D10EvidenceContext context({
    required AstroChartResult chart,
    required List<VargaRuleHit> rules,
    List<VargaCrossObservation> crossVarga = const [],
  }) {
    // A partial or invalid chart is insufficient evidence, NEVER "no job".
    if (!chart.ascendantLongitude.isFinite ||
        !chart.planets.map((p) => p.name).toSet().containsAll(_requiredPlanets) ||
        chart.planets.any((p) => !p.longitude.isFinite)) {
      return D10EvidenceContext(facts: const [], crossVarga: crossVarga);
    }

    final saturn = D10CareerService.saturnStream(chart);
    final d10 = VargaService.calculate(chart, 10);
    final d1Saturn = chart.planets.firstWhere((p) => p.name == 'Saturn');
    final d10Saturn = d10.planets.firstWhere((p) => p.name == 'Saturn');
    final d1SaturnHouse = D10CareerService.d1House(chart, 'Saturn');
    final d10SaturnHouse = D10CareerService.vargaHouse(d10, 'Saturn');

    String saturnAudit({required bool d10Chart}) {
      final placement = d10Chart ? d10Saturn.signIndex : d1Saturn.signIndex;
      final h = d10Chart ? d10SaturnHouse : d1SaturnHouse;
      final positions = d10Chart
          ? d10.planets.map((p) => (p.name, p.signIndex))
          : chart.planets.map((p) => (p.name, p.signIndex));
      final nodes = positions.where((p) =>
          (p.$1 == 'Rahu' || p.$1 == 'Ketu') && p.$2 == placement)
          .map((p) => p.$1).toList();
      final label = d10Chart ? 'D10' : 'D1';
      final state = d10Chart ? saturn.dashamsaState : saturn.birthState;
      return '$label శని రాశి ${placement + 1} • భావం $h • '
          'రాహు/కేతు యుతి: ${nodes.isEmpty ? 'లేదు' : nodes.join(', ')} • '
          'స్థితి $state. శని ఉచ్చ/స్వరాశి, నీచ, 6/8/12 స్థానాలు '
          'ప్రస్తుత D10CareerService గణన ప్రకారమే పరీక్షించబడ్డాయి. '
          'అస్తంగతం/గ్రహయుద్ధం ఈ గణనలో లేవు.';
    }

    D10Fact fact(String key, String sourceChart, bool? met,
        String inspection, String sourceId, {int? page}) =>
        D10Fact(key: key, chart: sourceChart, met: met,
            inspection: inspection, sourceRuleId: sourceId, sourcePage: page);

    final facts = <D10Fact>[
      fact(D10FactKeys.d1Gocharishta, 'D1',
          saturn.birthState == 'GOCHARASHTHA', saturnAudit(d10Chart: false),
          'D10-GOCHARISTA', page: 50),
      fact(D10FactKeys.d1Agocharishta, 'D1',
          saturn.birthState == 'AGOCHARASHTHA', saturnAudit(d10Chart: false),
          'D10-AGOCHARISTA', page: 50),
      fact(D10FactKeys.d10Gocharishta, 'D10',
          saturn.dashamsaState == 'GOCHARASHTHA', saturnAudit(d10Chart: true),
          'D10-GOCHARISTA', page: 50),
      fact(D10FactKeys.d10Agocharishta, 'D10',
          saturn.dashamsaState == 'AGOCHARASHTHA', saturnAudit(d10Chart: true),
          'D10-AGOCHARISTA', page: 50),
    ];

    // D10 special.pdf Ch.04 p.51: >=2 PP planets (Sun/Moon/Mars/Rahu)
    // linked with D1 Lagna/10th or their lords => independent profession.
    // Do NOT substitute D10-PP applicable=true: that catalog row is an audit.
    final firstLord = D10CareerService.signLord(chart.ascendantSignIndex);
    final tenthLordD1 = D10CareerService.signLord(
        (chart.ascendantSignIndex + 9) % 12);
    final pp = <String>[];
    for (final planet in const ['Sun', 'Moon', 'Mars', 'Rahu']) {
      final h = D10CareerService.d1House(chart, planet);
      if (h == 1 || h == 10 ||
          D10CareerService.relatedD1(chart, planet, firstLord) ||
          D10CareerService.relatedD1(chart, planet, tenthLordD1)) {
        pp.add(planet);
      }
    }
    facts.add(fact(D10FactKeys.d1IndependentPP, 'D1', pp.length >= 2,
        'D1 PP-గ్రహాలు: ${pp.isEmpty ? 'ఏవి లేవు' : pp.join(', ')} '
        '(${pp.length}/4); అవసరం కనీసం రెండు. '
        'D1 లగ్నం / 10వ భావం / 1L / 10L సంబంధాలు పరీక్షించబడ్డాయి.',
        'D10-PP', page: 51));

    final d10TenthLord = D10CareerService.signLord(
        (d10.ascendantSignIndex + 9) % 12);
    final sunHouse = D10CareerService.vargaHouse(d10, 'Sun');
    final natalTenthLord = chart.planets.firstWhere(
        (p) => p.name == d10TenthLord);
    final amsha = D10CareerService.devataForLongitude(
        natalTenthLord.longitude);
    final linkWithSun = D10CareerService.relatedVarga(
        d10, 'Sun', d10TenthLord);
    final authority = d10TenthLord == 'Sun' || sunHouse == 10 ||
        amsha.deity == 'Indra' || linkWithSun;
    facts.add(fact(D10FactKeys.d10SunAuthorityLink, 'D10', authority,
        'D10 10L $d10TenthLord • సూర్యుడు భావం $sunHouse • '
        '10L అంశదేవత ${amsha.deity} • సూర్య-10L గ్రహ సంబంధం '
        '${linkWithSun ? 'ఉంది' : 'లేదు'}. '
        'ఇది అధికారం/పరిపాలనకు సహాయక పరిశీలన; '
        'ప్రభుత్వ నియామకానికి స్వతంత్ర హామీ కాదు.',
        'D10-GOV-03'));

    // gov job.pdf Ch.26 p.1 provides exactly two natal-source predicates:
    // D1 fifth/ninth lord must land in the natal fifth/ninth SIGN in D9.
    // These are not generic VARGA-CROSS rules. The latter remain audit-only.
    final govRules = <VargaRuleHit>[
      for (final r in rules)
        if (r.factor == 10 &&
            (r.ruleId == 'D10-GOV-01' || r.ruleId == 'D10-GOV-02') &&
            r.autoEvaluated) r,
    ];
    final govKnown = govRules.map((r) => r.ruleId).toSet()
        .containsAll(const ['D10-GOV-01', 'D10-GOV-02']);
    final govMatches = govRules.where((r) => r.applicable &&
        r.tone == VargaRuleTone.favorable).toList(growable: false);
    facts.add(fact(D10FactKeys.d1GovernmentLink, 'D1',
        !govKnown ? null : govMatches.isNotEmpty,
        govKnown
            ? 'D1 5L/9L → D9లో జన్మ 5/9 రాశి షరతు: '
                '${govMatches.isEmpty ? 'ఏదీ సరిపోలలేదు' : govMatches.map((r) => r.ruleId).join(', ')}. '
                '${govRules.map((r) => '${r.ruleId}: ${r.inspection}').join(' | ')} '
                'ఇవి gov job.pdf మూల నియమాలు; సాధారణ VARGA-CROSS ఫలితం కాదు.'
            : 'gov job.pdf GOV-01/GOV-02 ధ్రువీకరించిన గణనలు అందుబాటులో లేవు.',
        govMatches.isEmpty ? 'D10-GOV-01/02' :
            govMatches.map((r) => r.ruleId).join(' + '),
        page: 1));

    return D10EvidenceContext(facts: facts, crossVarga: crossVarga);
  }

  /// True source-catalog VARGA-CROSS rows from the existing 255-rule engine.
  /// Inspection ONLY, including matched rows: never add them as D10Fact.
  static Future<List<VargaCrossObservation>> crossObservations(
      AstroChartResult chart) async {
    final evaluated = await VargaUnifiedRuleService.evaluate(chart);
    const relevant = <String>{
      'VARGA-CROSS-001', 'VARGA-CROSS-002',
      'VARGA-CROSS-016', 'VARGA-CROSS-017',
      'VARGA-CROSS-019', 'VARGA-CROSS-020',
      'VARGA-CROSS-021', 'VARGA-CROSS-022',
      'VARGA-CROSS-028',
    };
    return List<VargaCrossObservation>.unmodifiable([
      for (final item in evaluated)
        if (relevant.contains(item.id))
          VargaCrossObservation(
            varga: item.group,
            sourceRuleId: item.id,
            inspection: '${item.topic} • ${item.status.name} • '
                '${item.evidence} • ${item.source} • '
                'ఫలితంగా కాదు; పరిశీలనకు మాత్రమే.',
          ),
    ]);
  }
}
