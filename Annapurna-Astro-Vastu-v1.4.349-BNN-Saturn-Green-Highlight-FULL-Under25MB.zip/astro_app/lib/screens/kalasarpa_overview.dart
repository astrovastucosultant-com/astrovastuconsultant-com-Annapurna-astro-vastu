import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/kalasarpa_service.dart';

/// Kalasarpa names are a Rahu/Ketu house-axis classification.  A name is not
/// itself evidence that the complete seven-planet enclosure is present.
/// BPHS chapter 83's serpent curse is analyzed independently.
class KalasarpaOverview extends StatelessWidget {
  final AstroChartResult chart;
  const KalasarpaOverview({super.key, required this.chart});

  @override
  Widget build(BuildContext context) {
    final result = KalasarpaService.evaluate(chart);
    final active = result.status.startsWith('పూర్ణ కాలసర్ప స్థితి (');
    final absent = result.status == 'పూర్ణ కాలసర్ప స్థితి లేదు';
    final house = result.rahuHouse;
    final type = house != null && result.name != null;
    final statusColor = active ? const Color(0xFFAC4166)
        : absent ? const Color(0xFF237B56) : const Color(0xFFA87924);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('రాహు–కేతు కాలసర్పం — 12 రకాల పేర్లు',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: active ? const Color(0xFFFBEAF0) : const Color(0xFFF4F6F9),
              borderRadius: BorderRadius.circular(12)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('1. రాహు–కేతు స్థానపరమైన రకం',
                style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              if (type) ...[
                Text('${result.name} కాలసర్ప రకం',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                Text('రాహువు ${house}వ భావం • కేతువు ${((house + 5) % 12) + 1}వ భావం'),
                Text('పరిశీలించే అంశాలు: ${KalasarpaService.themes[house - 1]}',
                  style: const TextStyle(fontSize: 12.5, color: Colors.black87)),
                const SizedBox(height: 3),
                const Text('పేరు రాహువు భావస్థానం ద్వారా వస్తుంది; పేరు ఒక్కటే దోషం ఉన్నట్లు నిర్ధారణ కాదు.',
                  style: TextStyle(fontSize: 12, color: Colors.black54)),
              ] else
                const Text('రాహు–కేతు గ్రహస్థితులు పూర్తిగా లభించిన తరువాత రకం తెలుస్తుంది.'),
              const SizedBox(height: 10),
              const Text('2. పూర్తి యోగం వర్తించిందా?',
                style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(active ? 'పూర్తి కాలసర్ప యోగం — గ్రహస్థితి నియమం సరిపోయింది'
                  : absent ? 'పూర్తి కాలసర్ప యోగం లేదు — ఏడు గ్రహాలు అక్షానికి రెండు వైపులా ఉన్నాయి'
                  : result.status,
                style: TextStyle(fontWeight: FontWeight.bold, color: statusColor)),
              if (!active && !absent)
                const Padding(padding: EdgeInsets.only(top: 4), child: Text(
                  'సంధి లేదా అసంపూర్ణ సమాచారం ఉన్నప్పుడు యోగం ఉందని/లేదని నిర్ణయించము.',
                  style: TextStyle(fontSize: 12))),
            ]),
          ),
          const SizedBox(height: 5),
          ExpansionTile(
            title: const Text('3. జాతక పరిశీలన — గ్రహ డిగ్రీలు'),
            children: [for (final line in result.evidence)
              ListTile(dense: true, title: Text(line))],
          ),
          ExpansionTile(
            title: const Text('4. వర్తించిన Rule ID & మూలం'),
            children: [Padding(padding: const EdgeInsets.all(12),
              child: Text(
                'స్థానపరమైన రకం: ${house == null ? 'గణన పెండింగ్' : 'KS-TYPE-${house.toString().padLeft(2, '0')}'}'
                ' • ${result.name ?? 'పరిశీలించలేదు'}\n'
                'పూర్తి యోగ నియమం: ${active ? result.ruleId : absent ? 'వర్తించలేదు' : 'సంధి/గణన పరిశీలన అవసరం'}\n'
                'పేర్లు: ఆధునిక కాలసర్ప సంప్రదాయంలోని 12 రకాల వర్గీకరణ. '
                'ఈ జాబితాను BPHS అధ్యాయం 83 సర్పశాప శ్లోకాలుగా పేర్కొనరాదు. '
                'ఈ వర్గీకరణకు నిర్ధారించిన ప్రాచీన గ్రంథ పేజీ అందుబాటులో లేదు.\n'
                'ఆధార సూచన: https://www.astroliya.com/blog/kaal-sarp-dosh',
              )),
            ],
          ),
          ExpansionTile(
            title: const Text('5. పన్నెండు రకాల పూర్తి జాబితా'),
            children: [for (var i = 0; i < KalasarpaService.names.length; i++)
              ListTile(
                dense: true,
                title: Text('${i + 1}వ భావం — ${KalasarpaService.names[i]}'),
                subtitle: Text('కేతువు ${((i + 6) % 12) + 1}వ భావం'),
                selected: i + 1 == house,
              )],
          ),
          const ExpansionTile(
            title: Text('6. సంఘటనల సమయం'),
            children: [Padding(padding: EdgeInsets.all(12), child: Text(
              'ఈ జన్మస్థితి ఒక్కటితో సంఘటన తేదీ నిర్ణయించలేము. వర్తించిన దశ, గోచార మూల నియమాలు వేరుగా పరీక్షించాలి.'))],
          ),
          const ExpansionTile(
            title: Text('7. మూలగ్రంథ పరిహారం'),
            children: [Padding(padding: EdgeInsets.all(12), child: Text(
              'ఈ 12 రకాల పేర్లకు నిర్ధారించిన ప్రాచీన మూలగ్రంథ పరిహారం జోడించలేదు. '
              'BPHS అధ్యాయం 83లోని సర్పశాప నియమం పూర్తిగా సరిపోతే, ఆ గ్రంథంలోని పరిహారం ప్రత్యేకంగా చూపబడుతుంది.'))],
          ),
          const Padding(
            padding: EdgeInsets.all(8),
            child: Text(
              'కాలసర్ప వర్గీకరణ ఆధునిక సంప్రదాయానికి చెందినది. '
              'BPHS సర్పశాపానికి వేరే IF–THEN నియమాలు ఉన్నాయి; రెండు ఒకే దోషం కావు. '
              'భావస్థానాల పేర్లు సంప్రదాయ సూచనలు మాత్రమే; ప్రతికూల సంఘటన నిర్ధారణ కాదు.',
              style: TextStyle(fontSize: 12, color: Colors.black54)),
          ),
        ]),
      ),
    );
  }
}
