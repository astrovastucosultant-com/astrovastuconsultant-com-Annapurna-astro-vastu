import 'package:flutter/material.dart';

/// Large, accessible 3-column navigation tiles inspired by the user's layout
/// reference. The tiles are real navigation controls, not decorative images.
class AstroDashboardItem {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  const AstroDashboardItem({
    required this.title,
    required this.icon,
    required this.color,
    required this.onTap,
  });
}

class AstroIconDashboard extends StatelessWidget {
  final String title;
  final List<AstroDashboardItem> items;
  const AstroIconDashboard({super.key, required this.title, required this.items});

  static const Color navy = Color(0xFF102F60);
  static const Color gold = Color(0xFFD9AD55);
  static const Color cream = Color(0xFFFFF3DB);

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Container(
        padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 10),
        decoration: BoxDecoration(
          color: navy, borderRadius: BorderRadius.circular(18),
        ),
        child: Text(title, textAlign: TextAlign.center,
          style: const TextStyle(color: gold, fontSize: 21,
            fontWeight: FontWeight.w900)),
      ),
      const SizedBox(height: 10),
      LayoutBuilder(builder: (context, constraints) {
        final columns = constraints.maxWidth >= 880 ? 5
            : constraints.maxWidth >= 580 ? 4 : 3;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: items.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            crossAxisSpacing: 9,
            mainAxisSpacing: 10,
            childAspectRatio: columns == 3 ? 0.82 : 1.02,
          ),
          itemBuilder: (context, index) {
            final entry = items[index];
            return Material(
              color: cream,
              elevation: 1,
              borderRadius: BorderRadius.circular(18),
              child: InkWell(
                onTap: entry.onTap,
                borderRadius: BorderRadius.circular(18),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: gold, width: 1.3),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 7),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 26,
                        backgroundColor: entry.color,
                        child: Icon(entry.icon, size: 28, color: Colors.white),
                      ),
                      const SizedBox(height: 9),
                      Flexible(child: Text(entry.title,
                        textAlign: TextAlign.center,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: navy,
                          fontWeight: FontWeight.w900, fontSize: 13, height: 1.25),
                      )),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      }),
    ]);
  }
}
