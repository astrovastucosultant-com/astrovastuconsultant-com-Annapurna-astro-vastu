import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_rashi_rule_service.dart';
import '../models/birth_data.dart';

/// Fresh BNN rashi rules: source IF -> natal test -> source THEN.
/// The old 462 registry and former aliases are not imported.
class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnRashiRule>> _rules = BnnRashiRuleService.load();
  bool _showAll = false;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BnnRashiRule>>(
      future: _rules,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Card(child: Padding(padding: const EdgeInsets.all(18),
            child: Text('BNN రాశి నియమాల డేటా చదవడంలో సమస్య: ${snapshot.error}')));
        }
        if (!snapshot.hasData) {
          return const Card(child: Padding(padding: EdgeInsets.all(18),
            child: Center(child: CircularProgressIndicator())));
        }
        final findings = BnnRashiRuleService.evaluate(
          rules: snapshot.data!, chart: widget.chart,
          gender: widget.birthData.gender,
        );
        final matching = findings.where((f) => f.matched).toList();
        final results = matching.where((f) => f.canDisplayEffect).toList();
        final unclear = matching.where((f) => !f.canDisplayEffect).toList();
        final unmatched = findings.where((f) => !f.matched).toList();
        final missing = unmatched.where((f) => f.position == null).length;
        // Only chart-matched, displayable THEN statements are results.
        // Unverified OCR passages stay accessible in the source catalog,
        // but must never turn into a result/pending card.
        final display = _showAll ? [...results, ...unclear, ...unmatched] : results;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              color: const Color(0xFFF2F7F4),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('BNN — రాశి నియమాల జాతక పరిశీలన',
                      style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text('84 మూల నియమాలు • రాశి IF సరిపోయినవి ${matching.length} • '
                      'ఫలిత పాఠ్యం చూపినవి ${results.length}'),
                    if (unclear.isNotEmpty)
                      Text('మూల సూచికలో మాత్రమే ఉన్నవి: ${unclear.length}',
                        style: const TextStyle(color: Color(0xFF8A4D2E))),
                    if (missing > 0)
                      Text('గణనకు గ్రహస్థితులు లేనివి: $missing',
                        style: const TextStyle(color: Color(0xFF8A4D2E))),
                    const SizedBox(height: 9),
                    const Text('ఇక్కడ TRUE అంటే గ్రహం ఆ రాశిలో ఉన్నట్లు మాత్రమే. '
                      'THEN వాక్యాలు మీరు ఇచ్చిన మూల ప్రతిలిపిలోని సంప్రదాయ సూచనలు; '
                      'జీవిత సంఘటనలు నిర్ధారణ అయినట్లు కాదు. ',
                      style: TextStyle(fontSize: 12.5, height: 1.5)),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: () => setState(() => _showAll = !_showAll),
                      icon: Icon(_showAll ? Icons.visibility_off : Icons.list_alt),
                      label: Text(_showAll ? 'ఫలితాలు మాత్రమే చూడండి' : 'మొత్తం 84 మూల నియమాలు చూడండి'),
                    ),
                  ],
                ),
              ),
            ),
            if (display.isEmpty)
              const Padding(padding: EdgeInsets.all(16),
                child: Text('ఈ జన్మ జాతకానికి ప్రదర్శించదగిన BNN రాశి ఫలితాలు లేవు. మూల నియమాలను ప్రత్యేకంగా చూడవచ్చు.')),
            for (final finding in display)
              _RuleCard(key: ValueKey(finding.rule.id), finding: finding),
          ],
        );
      },
    );
  }
}

/// BNN-only Result First design: a THEN outcome is the collapsed card title.
/// Tapping it reveals the source IF, natal calculation and source page.
/// The rest of the application's varga presentation is untouched.
class _RuleCard extends StatelessWidget {
  final BnnRashiFinding finding;
  const _RuleCard({super.key, required this.finding});

  @override
  Widget build(BuildContext context) {
    final rule = finding.rule;
    final p = finding.position;
    final matched = finding.matched;
    final showsResult = finding.canDisplayEffect;
    final status = p == null
        ? 'గణనకు సమాచారం లేదు'
        : matched
            ? 'IF TRUE — రాశి స్థానం సరిపోయింది'
            : 'వర్తించలేదు';

    // Only this explicitly favorable BNN rule receives a strong green panel.
    // Other BNN cards and all varga cards keep their existing appearance.
    final highlightSaturn = showsResult && rule.id == 'BNN-RASHI-014' && p != null;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      color: showsResult ? const Color(0xFFF2F8F6) : null,
      child: ExpansionTile(
        key: ValueKey('bnn-outcome-${rule.id}'),
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        // Do not truncate a multi-sentence result. The complete THEN that may
        // be displayed is visible here, BEFORE opening any rule details.
        title: highlightSaturn
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'శని వృషభంలో ${BnnRashiRuleService.dms(p!.longitude)} వద్ద ఉన్నందున',
                    style: const TextStyle(
                      color: Color(0xFF245A36),
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 9),
                  Container(
                    key: const ValueKey('bnn-result-highlight-BNN-RASHI-014'),
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
                    decoration: BoxDecoration(
                      color: const Color(0xFFD9F3E0),
                      border: Border.all(color: const Color(0xFF68AA7A), width: 1.25),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      finding.displayEffect!,
                      softWrap: true,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        height: 1.5,
                        color: Color(0xFF176A36),
                      ),
                    ),
                  ),
                ],
              )
            : Text(
                showsResult ? finding.displayEffect! : '${rule.id} • ${rule.title}',
                softWrap: true,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  height: 1.4,
                  color: showsResult ? const Color(0xFF086D51) : null,
                ),
              ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 7),
          child: Text(
            showsResult
                ? 'ఫలితాన్ని టచ్ చేస్తే రూల్ • జాతక పరిశీలన • మూలపేజీ'
                : status,
            style: TextStyle(
              fontSize: 12.5,
              color: showsResult
                  ? const Color(0xFF086D51)
                  : const Color(0xFF666C72),
            ),
          ),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(15, 0, 15, 15),
        children: [
          _section('1. రూల్ — ${rule.id}', rule.originalIf),
          const SizedBox(height: 10),
          _section(
            '2. జాతక పరిశీలన',
            p == null
                ? 'ఈ గ్రహానికి జన్మస్ఫుటం అందలేదు.'
                : '${rule.planet}: ${BnnRashiRuleService.signs[p.signIndex]} '
                    '${BnnRashiRuleService.dms(p.longitude)}'
                    '${p.retrograde ? ' (వక్రం)' : ''} • '
                    '${matched ? 'IF TRUE — గ్రహం చెప్పిన రాశిలో ఉంది' : 'IF FALSE — ఈ రాశిలో లేదు'}.',
          ),
          if (matched && finding.house != null)
            Padding(
              padding: const EdgeInsets.only(top: 3),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'జన్మలగ్నం నుంచి ${finding.house}వ భావం.',
                  style: const TextStyle(
                      color: Color(0xFF086D51), fontSize: 13),
                ),
              ),
            ),
          if (matched) ...[
            const SizedBox(height: 10),
            // The card already shows the readable result; show the original
            // unedited THEN separately, to preserve every source clause.
            _section('3. మూలంలోని పూర్తి THEN వాక్యం', rule.originalThen),
            if (finding.annotation != null && finding.annotation!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    finding.annotation!,
                    style: const TextStyle(
                      fontSize: 12.5,
                      color: Color(0xFF8A4D2E),
                    ),
                  ),
                ),
              ),
          ],
          const SizedBox(height: 10),
          _section(
            '4. మూలాధారం',
            '${rule.transcriptionFile}\n'
            'BNN మూల స్కాన్: PDF పేజీ ${rule.pdfPage}, '
            'ముద్రిత పేజీ ${rule.printedPage}. '
            'పేజీలో రాశి పట్టిక ఉన్న స్థానం పరిశీలించారు; '
            'THEN వాక్యం అక్షరాలవారీ మూల ధృవీకరణ ఇంకా జరగలేదు.',
          ),
        ],
      ),
    );
  }

  Widget _section(String title, String body) => Align(
        alignment: Alignment.centerLeft,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 14, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(body, style: const TextStyle(height: 1.45)),
          ],
        ),
      );
}
