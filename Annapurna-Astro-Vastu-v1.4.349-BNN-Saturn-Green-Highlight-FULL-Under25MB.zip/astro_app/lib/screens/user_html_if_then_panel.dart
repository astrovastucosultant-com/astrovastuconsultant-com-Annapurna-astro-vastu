import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/user_html_if_then_service.dart';
import '../astrology/varga_service.dart';
import 'unified_rule_result_tile.dart';

/// One source index across the 19 vargas listed in the uploaded HTML.
/// Never activates the old BNN catalog or a scanned OCR queue.
class UserHtmlIfThenPanel extends StatefulWidget {
  const UserHtmlIfThenPanel({
    super.key,
    required this.natal,
    required this.factor,
    required this.d16Method,
  });

  final AstroChartResult natal;
  final int factor;
  final D16CalculationMethod d16Method;

  @override
  State<UserHtmlIfThenPanel> createState() => _UserHtmlIfThenPanelState();
}

class _UserHtmlIfThenPanelState extends State<UserHtmlIfThenPanel> {
  late Future<List<UserHtmlIfThenRow>> _future;
  final TextEditingController _search = TextEditingController();
  bool _showAudit = false;

  @override
  void initState() {
    super.initState();
    _future = UserHtmlIfThenService.load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<UserHtmlIfThenRow>>(
      future: _future,
      builder: (context, snapshot) {
        final rows = snapshot.data?.where((r) => r.factor == widget.factor)
                .toList(growable: false) ?? const <UserHtmlIfThenRow>[];
        final checks = <String, UserHtmlConditionCheck>{
          for (final r in rows)
            r.engineId: UserHtmlIfThenService.evaluate(r, widget.natal,
                d16Method: widget.d16Method),
        };
        final matched = rows.where((r) => checks[r.engineId]?.matched == true)
            .toList(growable: false);
        final audit = rows.where((r) => checks[r.engineId]?.matched != true)
            .toList(growable: false);
        return Card(
          key: ValueKey('uploaded-html-ifthen-D${widget.factor}'),
          color: const Color(0xFFF3F5F9),
          surfaceTintColor: Colors.transparent,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text('D${widget.factor} — OCR / JSON / IF–THEN మూల సూచిక',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900,
                      color: Color(0xFF12315E)))),
                TextButton.icon(
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
                    builder: (_) => UserHtmlAllRulebookScreen(natal: widget.natal,
                        d16Method: widget.d16Method),
                  )),
                  icon: const Icon(Icons.menu_book_outlined, size: 18),
                  label: const Text('అన్నీ 60'),
                ),
              ]),
              const Text('అప్‌లోడ్ HTMLలోని నియమాలు. మూలపుస్తక OCR ధృవీకరణ '
                  'ప్రత్యేకం; లెక్కించగలిగిన IF సరిపోతే మాత్రమే క్రింద ఫలితం. '
                  'ELSEను వ్యతిరేక జాతక ఫలితంగా ఉపయోగించం.',
                style: TextStyle(fontSize: 12, color: Color(0xFF5B6471))),
              if (snapshot.hasError)
                Text('మూల నియమాలు తెరవడంలో సమస్య: ${snapshot.error}',
                  style: const TextStyle(color: Colors.red)),
              if (!snapshot.hasData && !snapshot.hasError)
                const LinearProgressIndicator(),
              if (snapshot.hasData) ...[
                const SizedBox(height: 8),
                Text('మూల రికార్డులు ${rows.length} • షరతు మ్యాచ్‌లు '
                    '${matched.length} • మిగిలినవి మూల సూచికలో ${audit.length}',
                    style: const TextStyle(fontSize: 12,
                        fontWeight: FontWeight.w700)),
                for (final r in matched)
                  _ruleTile(r, checks[r.engineId]!, true),
                if (audit.isNotEmpty)
                  ExpansionTile(
                    key: ValueKey('uploaded-html-source-index-${widget.factor}'),
                    initiallyExpanded: _showAudit,
                    onExpansionChanged: (v) => _showAudit = v,
                    title: Text('మూల నియమాల సూచిక (${audit.length})'),
                    subtitle: const Text('జాతక ఫలితాలు కాదు'),
                    children: [
                      for (final r in audit)
                        _ruleTile(r, checks[r.engineId]!, false),
                    ],
                  ),
              ],
            ]),
          ),
        );
      },
    );
  }
}

Widget _ruleTile(
    UserHtmlIfThenRow rule, UserHtmlConditionCheck check, bool hit) {
  return UnifiedRuleResultTile(
    key: ValueKey('html-ifthen-${rule.engineId}'),
    data: RuleResultData(
      topic: '${rule.varga} • ${rule.topic}',
      ruleId: rule.engineId,
      rule: '${rule.ocr}\nIF: ${rule.condition}',
      examination: check.evidence,
      result: hit
          ? 'అప్‌లోడ్ HTML ప్రకారం: ${rule.whenYes}. '
              'ఇది సంప్రదాయ జ్యోతిష్య నియమానికి చెందిన సూచన; '
              'మూల పుస్తక పేజీ స్వతంత్రంగా ధృవీకరించలేదు.'
          : 'ఈ రూల్‌ను వర్తించిన జాతక ఫలితంగా ప్రకటించలేదు. '
              'మూల HTML THEN వాక్యం: ${rule.whenYes}. '
              'ELSE వాక్యం (${rule.whenNo})ను అంచనాగా ఉపయోగించలేదు.',
      verdict: hit ? RuleVerdict.mixed : RuleVerdict.unverified,
      ruleMatched: check.matched,
      source: 'అప్‌లోడ్ HTML — ${rule.source}'
          '${rule.printedPageClaim == null ? '' : ' • పుస్తక పుట ${rule.printedPageClaim} (ధృవీకరించలేదు)'}',
      remedy: null,
    ),
    showRemedyStatus: hit,
  );
}

/// Standalone searchable view, including D11 text-only entries even though
/// VargaService has no D11 calculation.
class UserHtmlAllRulebookScreen extends StatefulWidget {
  const UserHtmlAllRulebookScreen({super.key, required this.natal,
      required this.d16Method});
  final AstroChartResult natal;
  final D16CalculationMethod d16Method;

  @override
  State<UserHtmlAllRulebookScreen> createState() =>
      _UserHtmlAllRulebookScreenState();
}

class _UserHtmlAllRulebookScreenState extends State<UserHtmlAllRulebookScreen> {
  late final Future<List<UserHtmlIfThenRow>> _future =
      UserHtmlIfThenService.load();
  String _query = '';
  String _factor = 'ALL';

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('OCR + JSON + IF–THEN • 60 నియమాలు')),
    body: FutureBuilder<List<UserHtmlIfThenRow>>(
      future: _future,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('Rulebook JSON తెరవడం సాధ్యం కాలేదు: '
              '${snapshot.error}'));
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final all = snapshot.data!;
        final choices = all.map((r) => r.varga).toSet().toList()
          ..sort((a,b) => int.parse(a.substring(1))
              .compareTo(int.parse(b.substring(1))));
        final filtered = all.where((r) =>
            (_factor == 'ALL' || r.varga == _factor) &&
            ('${r.id} ${r.varga} ${r.topic} ${r.ocr} ${r.source}'
                .toLowerCase().contains(_query.toLowerCase())))
            .toList(growable: false);
        return ListView(padding: const EdgeInsets.all(12), children: [
          TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search),
                labelText: 'నియమం / అంశం / మూలం వెతకండి'),
            onChanged: (v) => setState(() => _query = v),
          ),
          SingleChildScrollView(scrollDirection: Axis.horizontal,
            child: Row(children: [
              ChoiceChip(label: const Text('అన్నీ'),
                  selected: _factor == 'ALL',
                  onSelected: (_) => setState(() => _factor = 'ALL')),
              const SizedBox(width: 6),
              for (final f in choices) Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(label: Text(f), selected: _factor == f,
                  onSelected: (_) => setState(() => _factor = f)),
              ),
            ]),
          ),
          Text('${filtered.length} / ${all.length} రికార్డులు • '
              'D11 మూల సూచిక మాత్రమే; గణన లేదు.',
              style: const TextStyle(fontSize: 12)),
          for (final r in filtered)
            _ruleTile(r, UserHtmlIfThenService.evaluate(r, widget.natal,
                d16Method: widget.d16Method),
                UserHtmlIfThenService.evaluate(r, widget.natal,
                    d16Method: widget.d16Method).matched == true),
        ]);
      },
    ),
  );
}
