import 'package:flutter/material.dart';

import '../astrology/d10_career_decision_service.dart';
import '../astrology/d10_career_service.dart';
import '../astrology/varga_rule_service.dart';

/// Results first. The only verdicts displayed are from the source-rule
/// evaluators already present in VargaRuleService. Each item retains its
/// natal evidence and original Rule ID / source via onRuleTap.
class D10CareerDecisionPanel extends StatelessWidget {
  final D10SaturnStream saturn;
  final List<VargaRuleHit> rules;
  final ValueChanged<VargaRuleHit> onRuleTap;

  const D10CareerDecisionPanel({
    super.key,
    required this.saturn,
    required this.rules,
    required this.onRuleTap,
  });

  @override
  Widget build(BuildContext context) {
    final decisions = D10CareerDecisionService.summarize(
      saturn: saturn, rules: rules,
    );
    final byId = {for (final r in rules) r.ruleId: r};
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(4, 6, 4, 10),
        child: Text('D10 — ఉద్యోగం, వ్యాపారం, ప్రభుత్వం, ఉన్నత పదవి',
          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900,
            color: Color(0xFF781F32))),
      ),
      for (final decision in decisions) _decisionCard(decision, byId),
      const Padding(
        padding: EdgeInsets.fromLTRB(6, 2, 6, 12),
        child: Text('ఇవి ఉన్న మూల IF–THEN / దశాంశ నియమాలు సరిపోలిన జ్యోతిష్య సూచనలు. '
          'మ్యాచ్ కాని రూల్‌ను ప్రతికూల సంఘటనగా ప్రకటించము. శాతం = ఉద్యోగం '
          'జరిగే అవకాశం అని చూపించము. దశలు/గోచారం సంఘటన సమయ పరిశీలనకు వేరు.',
          style: TextStyle(fontSize: 11.5, color: Color(0xFF63585D))),
      ),
    ]);
  }

  Widget _decisionCard(D10CareerDecision decision, Map<String, VargaRuleHit> byId) {
    final color = switch (decision.tone) {
      D10DecisionTone.favorable => const Color(0xFF176B39),
      D10DecisionTone.mixed => const Color(0xFF975B25),
      D10DecisionTone.caution => const Color(0xFFA22F61),
      D10DecisionTone.unconfirmed => const Color(0xFF5A6068),
    };
    final background = switch (decision.tone) {
      D10DecisionTone.favorable => const Color(0xFFEDF8F1),
      D10DecisionTone.mixed => const Color(0xFFFFF8E9),
      D10DecisionTone.caution => const Color(0xFFF9F2F5),
      D10DecisionTone.unconfirmed => const Color(0xFFF2F4F6),
    };
    final label = switch (decision.tone) {
      D10DecisionTone.favorable => 'అనుకూలం',
      D10DecisionTone.mixed => 'మిశ్రమ ఆధారం',
      D10DecisionTone.caution => 'ప్రతికూల బల సూచన',
      D10DecisionTone.unconfirmed => 'ఈ నియమాల్లో నిర్ధారణ లేదు',
    };
    return Card(
      color: background, surfaceTintColor: Colors.transparent,
      margin: const EdgeInsets.only(bottom: 9),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        leading: Icon(decision.tone == D10DecisionTone.favorable
            ? Icons.check_circle_outline
            : decision.tone == D10DecisionTone.mixed
                ? Icons.rule_outlined : Icons.info_outline, color: color),
        title: Text(decision.title,
          style: TextStyle(fontWeight: FontWeight.w900, color: color)),
        subtitle: Text('$label\n${decision.result}',
          style: const TextStyle(fontSize: 12.5, height: 1.4)),
        children: [
          const Divider(),
          const Align(alignment: Alignment.centerLeft,
            child: Text('జాతక పరిశీలన',
              style: TextStyle(fontWeight: FontWeight.w800))),
          const SizedBox(height: 4),
          Align(alignment: Alignment.centerLeft,
            child: Text(decision.reasoning,
              style: const TextStyle(fontSize: 12.5, height: 1.4))),
          const SizedBox(height: 8),
          if (decision.matchedRuleIds.isNotEmpty)
            const Align(alignment: Alignment.centerLeft,
              child: Text('సరిపోయిన మూల నియమాలు — టచ్ చేయండి',
                style: TextStyle(fontWeight: FontWeight.w800))),
          for (final id in decision.matchedRuleIds)
            if (byId[id] != null)
              ListTile(
                dense: true, contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.menu_book_outlined, size: 19),
                title: Text(id, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Text(byId[id]!.source,
                    maxLines: 2, overflow: TextOverflow.ellipsis),
                trailing: const Icon(Icons.chevron_right, size: 18),
                onTap: () => onRuleTap(byId[id]!),
              ),
          if (decision.matchedRuleIds.isEmpty)
            const Align(alignment: Alignment.centerLeft,
              child: Text('ఈ అంశానికి పరీక్షించిన మూల నియమాల్లో సరిపోయినవి లేవు.',
                style: TextStyle(fontSize: 12))),
          if (decision.checkedRuleIds.toSet().difference(
                decision.matchedRuleIds.toSet()).isNotEmpty)
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: const Text('ఇతర పరీక్షించిన నియమాలు / సరిపోని షరతులు',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
              children: [
                for (final id in decision.checkedRuleIds)
                  if (!decision.matchedRuleIds.contains(id) && byId[id] != null)
                    ListTile(
                      dense: true, title: Text(id),
                      subtitle: Text(byId[id]!.inspection,
                        maxLines: 3, overflow: TextOverflow.ellipsis),
                      onTap: () => onRuleTap(byId[id]!),
                    ),
              ],
            ),
        ],
      ),
    );
  }
}
