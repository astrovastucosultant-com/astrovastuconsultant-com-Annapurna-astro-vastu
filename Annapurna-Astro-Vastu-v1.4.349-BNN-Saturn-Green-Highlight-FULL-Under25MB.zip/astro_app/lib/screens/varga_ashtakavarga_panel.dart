import 'package:flutter/material.dart';

import '../astrology/ashtakavarga_service.dart';
import '../astrology/varga_ashtakavarga_service.dart';

/// Raw calculations are available on every one of the 19 varga tabs.
/// AV never changes the parent source IF–THEN result; it is evidence only.
class VargaAshtakavargaPanel extends StatelessWidget {
  final VargaAshtakavargaReport report;
  const VargaAshtakavargaPanel({super.key, required this.report});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFEAF2F9),
      child: ExpansionTile(
        key: ValueKey('varga-av-all-${report.factor}'),
        title: Text('D${report.factor} అష్టకవర్గం — SAV / BAV / PAV',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(report.auditPassed
            ? 'D1 SAV 337 • D${report.factor} SAV 337 • PAV→BAV→SAV audit PASS • పరిశీలన మాత్రమే'
            : 'అష్టకవర్గ గణన సమగ్రత తనిఖీ విఫలమైంది; ఫలితంగా ఉపయోగించవద్దు',
            style: const TextStyle(fontSize: 12)),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: [
          const Align(
            alignment: Alignment.centerLeft,
            child: Text('D1 జన్మ అష్టకవర్గం వేరు; ఎంపిక చేసిన వర్గ అష్టకవర్గం '
                'ఆ వర్గ గ్రహ/లగ్న రాశులపై మళ్లీ గణించబడింది. '
                'రెండింటిని కలిపి సంఘటన హామీ లేదా శాతంగా చూపము.',
                style: TextStyle(fontSize: 12)),
          ),
          const SizedBox(height: 6),
          Table(
            border: TableBorder.all(color: const Color(0xFFD3DCE8)),
            columnWidths: const {
              0: FlexColumnWidth(1.05),
              1: FlexColumnWidth(1.2),
              2: FlexColumnWidth(1.25),
            },
            children: [
              const TableRow(children: [
                _AvTableCell('భావం', bold: true),
                _AvTableCell('D1 SAV', bold: true),
                _AvTableCell('వర్గ SAV', bold: true),
              ]),
              for (final h in report.houses)
                TableRow(children: [
                  _AvTableCell('${h.house}'),
                  _AvTableCell('${report.natal.arithmetic.savHouse(h.house)}'),
                  _AvTableCell('${h.sav}'),
                ]),
            ],
          ),
          const SizedBox(height: 8),
          Text('గణన ఆధారం: ${VargaAshtakavargaService.source}',
              style: const TextStyle(fontSize: 11,
                  color: Color(0xFF606E81))),
          const SizedBox(height: 6),
          const Text('D1లోని సంప్రదాయ అష్టకవర్గ గణనకు వర్గచక్రాలపై '
              'అదే పద్ధతిని ప్రయోగాత్మకంగా వర్తింపజేశాం; D2–D60 '
              'విధానాన్ని అన్ని సంప్రదాయాలు ఒకే విధంగా అంగీకరించవు. '
              'Arithmetic PASS అంటే ఈ గణిత మొత్తం సరిపోయిందని మాత్రమే; '
              'జ్యోతిష ఫలితానికి మూల ధ్రువీకరణ కాదు.',
              style: TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}

class _AvTableCell extends StatelessWidget {
  final String text;
  final bool bold;
  const _AvTableCell(this.text, {this.bold = false});

  @override
  Widget build(BuildContext context) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      child: Text(text, textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12,
              fontWeight: bold ? FontWeight.bold : FontWeight.normal)));
}

/// Attached to *each* of the 176 topic cards, using the topic's own house.
/// The value of AV is visible even when no scholarly event rule is matched;
/// no fake matched-rule count is created from the arithmetic.
class VargaAvHouseEvidenceTile extends StatelessWidget {
  final VargaAshtakavargaReport report;
  final int house;
  const VargaAvHouseEvidenceTile({
    super.key,
    required this.report,
    required this.house,
  });

  @override
  Widget build(BuildContext context) {
    final h = report.forHouse(house);
    return ExpansionTile(
      key: ValueKey('varga-av-house-${report.factor}-$house'),
      initiallyExpanded: false,
      title: const Text('అష్టకవర్గ పరిశీలన • SAV / BAV / PAV',
          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
      subtitle: Text('D${report.factor} ${house}వ భావం SAV ${h.sav} • '
          'D1 అదే భావం SAV ${report.natal.arithmetic.savHouse(house)} • '
          'గణన ID ${report.ruleIdForHouse(house)}',
          style: const TextStyle(fontSize: 11)),
      childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      children: [
        if (!report.auditPassed)
          const Text('Audit FAIL — బిందువులు ఫలితంలో ఉపయోగించలేదు.',
              style: TextStyle(color: Color(0xFFB02944)))
        else ...[
          const Align(alignment: Alignment.centerLeft,
            child: Text('గణన తనిఖీ: 7 గ్రహాల BAV బిందువుల మొత్తం = SAV. '
                'PAV contributor జాబితా ఒక్కొక్క BAV మొత్తాన్ని వివరిస్తుంది. '
                'ఇది ఫలిత నియమం కాదు.',
                style: TextStyle(fontSize: 12))),
          const SizedBox(height: 7),
          Table(
            border: TableBorder.all(color: const Color(0xFFD3DCE8)),
            columnWidths: const {
              0: FlexColumnWidth(1.1),
              1: FlexColumnWidth(0.6),
              2: FlexColumnWidth(3),
            },
            children: [
              const TableRow(children: [
                _AvTableCell('గ్రహం', bold: true),
                _AvTableCell('BAV', bold: true),
                _AvTableCell('PAV బిందు దాతలు', bold: true),
              ]),
              for (final planet in AshtakavargaService.planetOrder)
                TableRow(children: [
                  _AvTableCell(planet),
                  _AvTableCell('${h.bav[planet]}'),
                  Padding(
                    padding: const EdgeInsets.all(5),
                    child: Text(
                      h.pavContributors[planet]!.isEmpty
                          ? 'లేరు'
                          : h.pavContributors[planet]!.join(', '),
                      style: const TextStyle(fontSize: 11),
                    ),
                  ),
                ]),
            ],
          ),
          const SizedBox(height: 7),
          Text('మొత్తం తనిఖీ: '
              '${h.bav.values.fold<int>(0, (sum, points) => sum + points)} '
              '= SAV ${h.sav} • '
              '${h.arithmeticValid ? 'PASS' : 'FAIL'}. '
              'బిందువుల వివరాలు పై పట్టికలో ఒక్కసారి మాత్రమే చూపించాం.',
              style: const TextStyle(fontSize: 11)),
          const Text('ఫలితం: సంఖ్యా గణన ధ్రువీకరణ మాత్రమే. '
              'ఈ బిందువుల నుంచి ఉద్యోగం, వివాహం, ఆయుష్షు, నష్టం, '
              'ఆరోగ్య ఫలితం లేదా సంఘటన సమయం స్వతంత్రంగా నిర్ణయించలేదు.',
              style: TextStyle(fontSize: 12)),
          const Text('పరిహారం: ఈ గణనకు ప్రత్యేక మూల పరిహారం లేదు.',
              style: TextStyle(fontSize: 12)),
        ],
      ],
    );
  }
}
