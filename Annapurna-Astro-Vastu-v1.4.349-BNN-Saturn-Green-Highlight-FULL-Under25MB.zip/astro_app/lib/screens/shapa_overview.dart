import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/mandi_calculation_service.dart';
import '../models/birth_data.dart';
import '../astrology/shapa_match_engine.dart';
import '../astrology/shapa_rule_service.dart';
import 'kalasarpa_overview.dart';

/// BPHS Chapter 83 curses-for-progeny rules: result tap -> chart review & rule.
/// Retains separate Rahu/Ketu legacy rules and Kalasarpa screen.
class ShapaOverview extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  const ShapaOverview({super.key,required this.chart,required this.birthData});
  @override
  State<ShapaOverview> createState()=>_ShapaOverviewState();
}
class _ShapaOverviewState extends State<ShapaOverview> {
  String selected='అన్ని విభాగాలు';
  int _mandiGeneration = 0;
  MandiCalculationResult? _calculatedMandi;
  String? _mandiCalculationError;
  bool _mandiCalculating = true;
  // Large manual inputs stay folded until the user needs verified values.
  bool _showManualShadbala = false;

  @override
  void initState() {
    super.initState();
    _calculateMandi();
  }

  @override
  void didUpdateWidget(covariant ShapaOverview oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.chart.julianDay != widget.chart.julianDay ||
        oldWidget.birthData.latitude != widget.birthData.latitude ||
        oldWidget.birthData.longitude != widget.birthData.longitude ||
        oldWidget.birthData.timezoneOffsetHours != widget.birthData.timezoneOffsetHours ||
        oldWidget.birthData.ayanamsa != widget.birthData.ayanamsa) {
      _calculatedMandi = null;
      _mandiCalculationError = null;
      _mandiCalculating = true;
      _calculateMandi();
    }
  }

  Future<void> _calculateMandi() async {
    final generation = ++_mandiGeneration;
    try {
      final result = await MandiCalculationService.calculate(widget.birthData);
      if (mounted && generation == _mandiGeneration) setState(() {
        _calculatedMandi = result;
        _mandiCalculationError = null;
        _mandiCalculating = false;
      });
    } catch (error) {
      if (mounted && generation == _mandiGeneration) setState(() {
        _mandiCalculationError = error.toString();
        _mandiCalculating = false;
      });
    }
  }

  static String _degrees(double value) {
    final seconds = ((value % 360 + 360) % 360 * 3600).round();
    final wrapped = seconds % (360 * 3600);
    final d = wrapped ~/ 3600;
    final m = (wrapped % 3600) ~/ 60;
    final s = wrapped % 60;
    return '$d° ${m.toString().padLeft(2,'0')}′ ${s.toString().padLeft(2,'0')}″';
  }

  String _localTime(DateTime utc) {
    final d = utc.add(Duration(minutes:
      (widget.birthData.timezoneOffsetHours * 60).round()));
    return '${d.day.toString().padLeft(2,'0')}-'
        '${d.month.toString().padLeft(2,'0')}-${d.year} '
        '${d.hour.toString().padLeft(2,'0')}:'
        '${d.minute.toString().padLeft(2,'0')}:'
        '${d.second.toString().padLeft(2,'0')}';
  }

  // Optional verified inputs from a dedicated six-part Shadbala worksheet.
  // NEVER substitute Vimsopaka or a simple dignity judgement for Shadbala.
  final _shadbalaInputs=<String,TextEditingController>{
    for(final name in <String>['Sun','Moon','Mars','Mercury',
      'Jupiter','Venus','Saturn']) name:TextEditingController(),
  };
  final _mandiInput=TextEditingController();
  @override
  void dispose() {
    for(final c in _shadbalaInputs.values)c.dispose();
    _mandiInput.dispose();
    super.dispose();
  }
  // Minimum Shadbala virupas per classical BPHS convention.
  // The user must provide verified six-part Shadbala totals; no calculated
  // Vimsopaka value is substituted for these inputs.
  static const _minimumVirupas = <String, double>{
    'Sun': 390, 'Moon': 360, 'Mars': 300, 'Mercury': 420,
    'Jupiter': 390, 'Venus': 330, 'Saturn': 300,
  };

  Widget _manualShadbalaChart() {
    final provided = _providedShadbala;
    if (provided.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(3, 8, 3, 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('షడ్బలం — విరూపాల బార్ చార్ట్',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        for (final entry in provided.entries) Builder(builder: (context) {
          final minimum = _minimumVirupas[entry.key]!;
          final strong = entry.value >= minimum;
          final color = strong ? const Color(0xFF16864C) : const Color(0xFFC43B75);
          final fill = (entry.value / minimum).clamp(0.0, 1.0).toDouble();
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: strong ? const Color(0xFFE8F8ED) : const Color(0xFFFFEAF2),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Text(ShapaMatchEngine.tel[entry.key] ?? entry.key,
                    style: const TextStyle(fontWeight: FontWeight.w800))),
                Text('${entry.value.toStringAsFixed(1)} / ${minimum.toStringAsFixed(0)}',
                    style: TextStyle(fontWeight: FontWeight.w900, color: color)),
              ]),
              const SizedBox(height: 7),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(value: fill, minHeight: 12,
                    color: color, backgroundColor: const Color(0xFFDCE1DF)),
              ),
              const SizedBox(height: 5),
              Text(strong ? '● బలం బాగుంది' : '● బలం తక్కువ',
                  style: TextStyle(color: color, fontWeight: FontWeight.w800)),
            ]),
          );
        }),
        const Text('మీరు నమోదు చేసిన ధృవీకరించిన విరూపాలపై మాత్రమే రంగులు. '
            'విలువ ఇవ్వని గ్రహానికి ఫలితం చూపించము.',
            style: TextStyle(fontSize: 11.5, color: Colors.black54)),
      ]),
    );
  }

  Map<String,double> get _providedShadbala {
    final result=<String,double>{};
    for(final entry in _shadbalaInputs.entries) {
      final value=double.tryParse(entry.value.text.trim());
      if(value!=null && value.isFinite && value>=0 && value<=10000) {
        result[entry.key]=value;
      }
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final rawMandi=double.tryParse(_mandiInput.text.trim());
    final mandi=rawMandi!=null && rawMandi.isFinite && rawMandi>=0 && rawMandi<360
      ?rawMandi:_calculatedMandi?.mandiLongitude;
    final all=ShapaMatchEngine.evaluate(widget.chart,
      shadbalaVirupas:_providedShadbala,mandiLongitude:mandi);
    final filtered=all.where((r)=>selected=='అన్ని విభాగాలు'||r.rule.group==selected).toList();
    final yes=filtered.where((r)=>r.matched==true).toList();
    final pending=filtered.where((r)=>r.matched==null).toList();
    final no=filtered.where((r)=>r.matched==false).toList();
    Widget inspection(ShapaAudit a) => Padding(
      padding:const EdgeInsets.fromLTRB(14,6,14,12),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('జాతక పరిశీలన',style:TextStyle(fontWeight:FontWeight.bold,fontSize:16)),
        const SizedBox(height:5),
        if(a.evidence.isEmpty)
          const Text('ఈ నియమానికి పూర్తిగా ధృవీకరించిన జాతక సరిపోలిక అందుబాటులో లేదు.'),
        for(final item in a.evidence) Padding(
          padding:const EdgeInsets.only(bottom:5),child:Text(item)),
        if(a.note.isNotEmpty) Padding(
          padding:const EdgeInsets.only(top:4),child:Text(a.note,
            style:const TextStyle(fontSize:12,color:Colors.black54))),
        const Divider(height:22),
        const Text('వర్తించే IF–THEN రూల్',
          style:TextStyle(fontWeight:FontWeight.bold,fontSize:16)),
        const SizedBox(height:5),
        Text('IF: ${a.rule.condition}'),
        const SizedBox(height:5),
        Text('THEN: ${a.rule.result}',style:const TextStyle(fontWeight:FontWeight.w600)),
        const SizedBox(height:8),
        Text('నియమం: ${a.rule.id} • అధ్యాయం/శ్లోకం: ${a.rule.verse} • PDF పేజీ: ${a.rule.page}',
          style:const TextStyle(fontSize:12)),
        Text('మూలం: ${a.rule.source}',style:const TextStyle(fontSize:12)),
        const SizedBox(height:6),
        ExpansionTile(tilePadding:EdgeInsets.zero,
          title:const Text('పరిహారం (మూల గ్రంథంలోని సంప్రదాయ సూచన)',
            style:TextStyle(fontWeight:FontWeight.w600)),
          children:[Padding(padding:const EdgeInsets.only(bottom:10),
            child:Text('${a.rule.remedy}\n\nఆచరణ ఐచ్ఛికం. వైద్య నిర్ధారణ లేదా సంతానం కలగదనే హామీ కాదు.'))]),
      ]));
    Widget resultTile(ShapaAudit a) => Card(
      margin:const EdgeInsets.only(bottom:7),
      child:ExpansionTile(
        key:PageStorageKey('shapa-result-${a.rule.id}'),
        title:Text('${a.rule.group} శాప సూచన — సంతాన సంబంధిత ఆటంకం',
          style:const TextStyle(color: Color(0xFFAD3C70),fontWeight:FontWeight.bold)),
        subtitle:Text('${a.rule.id} • మూలఫలితం: ${a.rule.result}\n'
          'శాస్త్రోక్త IF సరిపోలిక మాత్రమే; నిజమైన శాపం/సంతానహాని నిర్ధారణ కాదు.'),
        children:[inspection(a)],
      ),
    );
    Widget pendingTile(ShapaAudit a) => ExpansionTile(
      key:PageStorageKey('shapa-pending-${a.rule.id}'),
      title:Text('${a.rule.id} • ${a.rule.group}'),
      subtitle:const Text('పూర్తి IF షరతుల ధృవీకరణ పెండింగ్'),
      children:[inspection(a)],
    );
    return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(
      crossAxisAlignment:CrossAxisAlignment.start,children:[
        KalasarpaOverview(chart:widget.chart),
        const SizedBox(height: 12),
        const Text('పూర్వజన్మ శాపములు — BPHS అధ్యాయం 83',
          style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        const SizedBox(height:5),
        const Text('మూల PDF: 8 శాప విభాగాలు • 73 యోగాలు • పాత రాహు–కేతు సూచనలు 4',
          style:TextStyle(fontWeight:FontWeight.w500)),
        const SizedBox(height:5),
        const Text('ఇవి సంప్రదాయ గ్రహస్థితి సూచనలు మాత్రమే; నిజమైన శాపం, సంతానలేమి లేదా వైద్య సమస్య నిర్ధారణలు కావు.',
          style:TextStyle(color:Colors.black54,fontSize:12)),
        const SizedBox(height:8),
        ExpansionTile(
          key:const PageStorageKey('shapa-verified-bala-and-mandi'),
          title:const Text('మండీ స్వయంచాలక గణన • గుళిక పోలిక • షడ్బలం',
            style:TextStyle(fontWeight:FontWeight.w600)),
          subtitle:Text(_mandiCalculating?'స్థానిక సూర్యోదయం, మండీ గణిస్తున్నాం…':
            _calculatedMandi!=null?'మండీ ${_degrees(_calculatedMandi!.mandiLongitude)} — ఆటోమేటిక్':
            'మండీ గణన లభించలేదు; వివరాలు చూడండి'),
          children:[
            if (_mandiCalculating) const Padding(
              padding:EdgeInsets.all(8),
              child:LinearProgressIndicator()),
            if (_calculatedMandi != null) Padding(
              padding:const EdgeInsets.all(8),
              child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
                Text('మండీ (ప్రశ్నమార్గం): ${_degrees(_calculatedMandi!.mandiLongitude)}'
                  ' • ${ShapaMatchEngine.signs[_calculatedMandi!.mandiSignIndex]}'
                  ' • ${((_calculatedMandi!.mandiSignIndex - widget.chart.ascendantSignIndex + 12) % 12) + 1}వ భావం',
                  style:const TextStyle(fontWeight:FontWeight.bold)),
                Text('మండీ గణన కాలం: ${_localTime(_calculatedMandi!.mandiTimeUtc)}'),
                Text('శని-భాగం ప్రారంభ గుళిక (BPHS): ${_degrees(_calculatedMandi!.gulikaLongitude)}'),
                Text('శని-భాగం ముగింపు గుళిక (పోలిక): ${_degrees(_calculatedMandi!.gulikaEndLongitude)}'),
                Text('స్థానిక ${_calculatedMandi!.isNight?'రాత్రి':'పగలు'} కాలం: '
                  '${_localTime(_calculatedMandi!.solarStartUtc)} — '
                  '${_localTime(_calculatedMandi!.solarEndUtc)}'),
                const SizedBox(height:4),
                const Text('మండీ, గుళిక రెండు వేరు గణన ప్రమాణాలు. '
                  'ఇక్కడ శాప నియమాల్లో MANDI_Hకి మండీ స్థానమే వర్తిస్తుంది. '
                  'రెండు స్థానాలను ఒకటిగా ఊహించడం లేదు.',
                  style:TextStyle(fontSize:12)),
              ]),
            ),
            if (_mandiCalculationError != null) Padding(
              padding:const EdgeInsets.all(8),
              child:Text('మండీ స్వయంచాలక గణన జరగలేదు: $_mandiCalculationError',
                style:const TextStyle(color:Colors.deepOrange)),
            ),
            const Padding(padding:EdgeInsets.all(8),child:Text(
              'గ్రహాల పూర్తి ఆరు బలాల (షడ్బలం) మొత్తాన్ని విరూపాలలో నమోదు చేయాలి. 60 విరూపాలు = 1 రూపం. '
              'కేవలం ఉచ్చ/నీచ లేదా నవాంశ బలాన్ని పూర్తి షడ్బలంగా నమోదు చేయవద్దు. '
              'ఈ ఫీల్డ్స్ ఖాళీగా ఉంటే వాటిపై ఆధారపడిన నియమాలు నిర్ధారణ లేకుండా ఉంటాయి.',
              style:TextStyle(fontSize:12))),
            Padding(padding:const EdgeInsets.symmetric(horizontal:8),
              child:ExpansionTile(
                initiallyExpanded:false,
                tilePadding:EdgeInsets.zero,
                title:const Text('షడ్బలం విలువలు నమోదు — ఐచ్ఛికం',
                  style:TextStyle(fontSize:14,fontWeight:FontWeight.w600)),
                subtitle:const Text('ఏడు గ్రహాల ధృవీకరించిన విరూపాల విలువలు ఉంటే మాత్రమే తెరవండి',
                  style:TextStyle(fontSize:11.5)),
                onExpansionChanged:(opened)=>setState(()=>_showManualShadbala=opened),
                children:[if(_showManualShadbala)
                  Padding(padding:const EdgeInsets.only(bottom:10),
                    child:Wrap(spacing:8,runSpacing:9,children:[
                      for(final entry in _shadbalaInputs.entries)
                        SizedBox(width:160,child:TextField(
                          controller:entry.value,
                          maxLines:1,
                          onChanged:(_)=>setState((){}),
                          keyboardType:const TextInputType.numberWithOptions(decimal:true),
                          decoration:InputDecoration(
                            isDense:true,
                            filled:true,
                            fillColor:Colors.white,
                            border:const OutlineInputBorder(),
                            labelText:'${ShapaMatchEngine.tel[entry.key]} (విరూపాలు)'),
                        )),
                    ])),
                  if (_showManualShadbala && _providedShadbala.isNotEmpty)
                    _manualShadbalaChart(),
                ],
              )),
            Padding(padding:const EdgeInsets.all(8),child:TextField(
              controller:_mandiInput,
              onChanged:(_)=>setState((){}),
              keyboardType:const TextInputType.numberWithOptions(decimal:true),
              decoration:const InputDecoration(
                border:OutlineInputBorder(),
                labelText:'మండీ డిగ్రీ — ఐచ్ఛిక Verified Override (0°–360°)',
                helperText:'ఖాళీగా ఉంటే స్వయంచాలక మండీ; ధృవీకరించిన ఇతర పద్ధతి ఉంటేనే మార్చండి'),
            )),
          ],
        ),
        const SizedBox(height:8),
        DropdownButtonFormField<String>(
          value:selected,
          decoration:const InputDecoration(labelText:'శాపం అంశం ఎంచుకోండి',
            border:OutlineInputBorder()),
          isExpanded:true,
          items:['అన్ని విభాగాలు',...ShapaRuleService.groups]
            .map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),
          onChanged:(v){if(v!=null)setState(()=>selected=v);},
        ),
        const SizedBox(height:10),
        Text('పూర్తిగా సరిపోయినవి ${yes.length} • ధృవీకరణ పెండింగ్ ${pending.length} • సరిపోనివి ${no.length}',
          style:const TextStyle(fontWeight:FontWeight.w600)),
        const SizedBox(height:9),
        if (yes.isNotEmpty) ...[
          const Text('వర్తించిన శాప విభాగాలు — సాంప్రదాయ ప్రతికూల ఫల సూచనలు',
            style:TextStyle(fontSize:15.5,fontWeight:FontWeight.w800,
              color:Color(0xFFAD3C70))),
          for (final group in ShapaRuleService.groups)
            if (yes.any((entry) => entry.rule.group == group))
              Padding(
                padding: const EdgeInsets.symmetric(vertical:3),
                child:Text('$group శాపం: '
                  '${yes.where((entry) => entry.rule.group == group).length} '
                  'పూర్తి IF నియమాలు సరిపోయాయి • శాస్త్రోక్త సంతాన ఆటంక సూచన',
                  style:const TextStyle(fontWeight:FontWeight.w600)),
              ),
          const SizedBox(height:7),
        ],
        const Text('ఫలితాలు — నొక్కితే జాతక పరిశీలన & రూల్',
          style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
        const SizedBox(height:5),
        if(yes.isEmpty) const Padding(padding:EdgeInsets.symmetric(vertical:8),
          child:Text('పూర్తి షరతులతో ధృవీకరించిన సూచన ప్రస్తుతం లేదు. ఇది శాపం లేదని లేదా ఉందని చెప్పే తీర్పు కాదు.')),
        for(final item in yes) resultTile(item),
        ExpansionTile(
          key:const PageStorageKey('bphs-planet-remedies'),
          title:const Text('గ్రహాలవారీ పరిహారాలు — BPHS 83.109–111',
            style:TextStyle(fontWeight:FontWeight.w600)),
          subtitle:const Text('రాహు, కేతు సహా ఏడు మూల పరిహార నియమాలు'),
          children:const [
            ListTile(title:Text('బుధుడు / శుక్రుడు — శివపూజ (83.109)')),
            ListTile(title:Text('గురువు / చంద్రుడు — మంత్ర, యంత్ర, ఔషధాల సూచన (83.109)')),
            ListTile(title:Text('రాహువు — కన్యాదానం (83.110)')),
            ListTile(title:Text('రవి — హరి కీర్తన (83.110)')),
            ListTile(title:Text('కేతువు — గోదానం (83.110)')),
            ListTile(title:Text('కుజుడు / శని — రుద్ర జపం (83.110)')),
            ListTile(title:Text('సాధారణం — హరివంశ కథా శ్రవణం (83.111)')),
            Padding(padding:EdgeInsets.all(12),child:Text(
              'ఈ పట్టిక మూలగ్రంథంలోని ఆచార సూచనలు మాత్రమే. వాటిని జాతకంలో నిర్ధారించని దోషానికి ఆటోమేటిక్ పరిహారంగా అన్వయించవద్దు.',
              style:TextStyle(fontSize:12))),
          ],
        ),
        ExpansionTile(
          key:PageStorageKey('pending-group-$selected'),
          title:Text('పూర్తి పరిశీలన పెండింగ్ — ${pending.length} నియమాలు'),
          subtitle:const Text('సూత్రం, అవసరమైన జాతక సమాచారం చూసేందుకు తెరవండి'),
          children:[for(final item in pending)pendingTile(item)],
        ),
        ExpansionTile(
          key:PageStorageKey('not-matched-group-$selected'),
          title:Text('ఈ జాతకానికి సరిపోని ప్రత్యామ్నాయ IFలు — ${no.length}'),
          subtitle:const Text('ఇవి ప్రతికూల ఫలితాలు కావు'),
          children:[for(final item in no)ListTile(
            title:Text('${item.rule.id} • ${item.rule.group}'),
            subtitle:Text('IF: ${item.rule.condition}'),
          )],
        ),
      ])));
  }
}
