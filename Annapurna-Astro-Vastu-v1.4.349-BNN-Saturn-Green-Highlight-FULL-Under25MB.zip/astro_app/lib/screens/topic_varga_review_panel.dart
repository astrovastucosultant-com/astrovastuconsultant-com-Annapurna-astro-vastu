import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/multi_chart_topic_service.dart';
import '../astrology/varga_service.dart';

/// Source-defined required vargas for ONE question shown together, with actual
/// D1/Dx planetary positions. Chart existence is NOT a rule verification.
/// Every colored status comes from TopicStageEvidence, not from the chart image.
class TopicVargaReviewPanel extends StatelessWidget {
  const TopicVargaReviewPanel({
    super.key,
    required this.chart,
    required this.summary,
  });

  final AstroChartResult chart;
  final MultiChartTopicEvidence summary;

  static const _darkBlue = Color(0xFF12315E);
  static const _gold = Color(0xFFE6B958);

  static String statusText(TopicStageStatus status) => switch (status) {
    TopicStageStatus.matched => 'మ్యాచ్ అయింది',
    TopicStageStatus.notMatched => 'ఈ నియమం సరిపోలలేదు',
    TopicStageStatus.insufficientEvidence => 'ధృవీకరణ పెండింగ్',
  };

  static Color statusColor(TopicStageEvidence stage) => switch (stage.status) {
    TopicStageStatus.matched => stage.polarity == TopicPolarity.adverse
        ? const Color(0xFF9D315D) : const Color(0xFF176B36),
    TopicStageStatus.notMatched => const Color(0xFF586577),
    TopicStageStatus.insufficientEvidence => const Color(0xFF836524),
  };

  void _openDetail(BuildContext context, TopicStageEvidence stage, VargaChartData data) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.87,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 28),
            children: [
              Text('D${stage.factor} — ${data.definition.teluguName}',
                style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 4),
              Text('${summary.name} • ${statusText(stage.status)}',
                style: TextStyle(color: statusColor(stage), fontWeight: FontWeight.w700)),
              const SizedBox(height: 14),
              const Text('1. రూల్ / మూల నియమం',
                style: TextStyle(fontWeight: FontWeight.w900,
                  color: _darkBlue, fontSize: 15)),
              const SizedBox(height: 5),
              SelectableText(stage.ruleText.isEmpty
                  ? 'ఈ చక్రానికి పూర్తి మూల IF షరతు అందుబాటులో లేదు.'
                  : stage.ruleText),
              const SizedBox(height: 5),
              Text('Rule IDలు: ${stage.ruleIds.isEmpty ? "మ్యాచ్‌ అయిన రూల్ ID లేదు" : stage.ruleIds.join(", ")}',
                  style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 4),
              Text('మూలం: ${stage.source.isEmpty ? "మూలం ధృవీకరణ పెండింగ్" : stage.source}',
                  style: const TextStyle(fontSize: 11, color: Color(0xFF596373))),
              const SizedBox(height: 16),
              const Text('2. జాతక పరిశీలన',
                  style: TextStyle(fontWeight: FontWeight.w900,
                      color: _darkBlue, fontSize: 15)),
              const SizedBox(height: 8),
              Center(child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 340),
                child: _VargaPreview(data: data),
              )),
              const SizedBox(height: 8),
              SelectableText(stage.details),
              const SizedBox(height: 16),
              const Text('3. ఫలితం',
                  style: TextStyle(fontWeight: FontWeight.w900,
                      color: _darkBlue, fontSize: 15)),
              const SizedBox(height: 6),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: stage.status != TopicStageStatus.matched
                      ? const Color(0xFFF2F3F5)
                      : stage.polarity == TopicPolarity.adverse
                          ? const Color(0xFFFBE6ED)
                          : stage.polarity == TopicPolarity.supportive
                              ? const Color(0xFFE6F5EA)
                              : const Color(0xFFFFF3D8),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: statusColor(stage)),
                ),
                child: Text(stage.status == TopicStageStatus.matched
                    ? stage.result.isNotEmpty ? stage.result
                        : 'మూల షరతు మ్యాచ్ అయిన ఆధారం ఉంది; తుది ఫలిత వ్యాఖ్యానం ధృవీకరించాలి.'
                    : stage.status == TopicStageStatus.notMatched
                        ? 'ఈ నియమం సరిపోలలేదు — అంశం లేదనే తీర్పు కాదు.'
                        : 'పూర్తి రూల్ ధృవీకరణ లేదు — ఫలితం ప్రకటించలేదు.',
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16,
                      color: statusColor(stage), height: 1.45)),
              ),
              const SizedBox(height: 10),
              Text(summary.chartOrderSourceId.startsWith('USER-')
                    ? 'ప్రధాన చార్ట్ క్రమం: ${summary.chartOrderSourceId} (మీ తాజా సూచన)'
                    : 'చార్ట్ క్రమ మూలం: ${summary.chartOrderSourceId} • Mallikarjuna 255 Rules PDF',
                style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 7),
              const Text('ఒక గ్రహస్థితి లేదా శని విధానం మాత్రమే తుది ఉద్యోగం/వ్యాపార ఫలితం కాదు. '
                'పూర్తి IF–THEN, దశ, గోచార ధృవీకరణ వేరు.',
                style: TextStyle(fontSize: 12, color: Color(0xFF586577))),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Career primary chart selection is user-defined D1/D9/D10; other
    // source topics retain their original chart order.
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('పరిశీలించాల్సిన వర్గచక్రాలు — ఒకేచోట',
        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900,
          color: _darkBlue)),
      const SizedBox(height: 5),
      Wrap(spacing: 6, runSpacing: 6, children: [
        for (final stage in summary.stages)
          Chip(
            visualDensity: VisualDensity.compact,
            label: Text('D${stage.factor}${VargaService.definitions.any((d) => d.factor == stage.factor) ? "" : " • గణన లేదు"}', style: const TextStyle(
              fontWeight: FontWeight.w800, fontSize: 12)),
            avatar: Icon(
              !VargaService.definitions.any((d) => d.factor == stage.factor)
                  ? Icons.pending_outlined :
              stage.status == TopicStageStatus.matched ? Icons.check_circle :
              stage.status == TopicStageStatus.notMatched ? Icons.remove_circle_outline :
              Icons.pending_outlined,
              color: VargaService.definitions.any((d) => d.factor == stage.factor)
                  ? statusColor(stage) : const Color(0xFF836524), size: 17),
            backgroundColor: const Color(0xFFFFF7E8),
            side: const BorderSide(color: _gold),
          ),
      ]),
      const Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: Text('క్రింద ఆ అంశానికి అవసరమైన అన్ని చక్రాల గ్రహస్థితులు. '
            'ప్రతి చక్రాన్ని టచ్ చేస్తే పూర్తి చక్రం, గ్రహ పరిశీలన, Rule IDలు తెరుచుకుంటాయి.',
            style: TextStyle(fontSize: 11, color: Color(0xFF596373))),
      ),
      LayoutBuilder(builder: (context, constraints) {
        final gap = 8.0;
        final columns = constraints.maxWidth < 310 ? 1 : constraints.maxWidth < 760 ? 2 : 3;
        final width = (constraints.maxWidth - gap * (columns - 1)) / columns;
        return Wrap(spacing: gap, runSpacing: 8, children: [
          for (final stage in summary.stages)
            SizedBox(width: width, child: _stagePreview(context, stage)),
        ]);
      }),
      if (summary.chartOrderSourceId == 'USER-CAREER-CORE-BUSINESS')
        _businessSupplementaryVargas(context),
    ]);
  }

  /// The original VARGA-CROSS-003 workflow contains D1/D10/D2/D7.
  /// D2/D7 are NOT the user's three primary career factors and must never
  /// increase the main career match percentage or claim an automatic Goel hit.
  Widget _businessSupplementaryVargas(BuildContext context) {
    return Card(
      key: const ValueKey('business-supplementary-vargas'),
      margin: const EdgeInsets.only(top: 12),
      color: const Color(0xFFFFFAEF),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: _gold),
      ),
      child: ExpansionTile(
        initiallyExpanded: false,
        title: const Text('అదనపు మూల చక్రాలు — D2, D7',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14,
            color: _darkBlue)),
        subtitle: const Text('ప్రధాన D1–D9–D10 స్కోరుకు కలపలేదు • VARGA-CROSS-003',
          style: TextStyle(fontSize: 11)),
        childrenPadding: const EdgeInsets.fromLTRB(10, 4, 10, 12),
        children: [
          const Text('మూల వర్గ-క్రమ నియమం: వ్యాపారం పరిశీలనలో D1 → D10 → D2 → D7. '
            'Mallikarjuna 255 Rules, పేజీ 23 (VARGA-CROSS-003). '
            'V.P. Goel రచించిన Predict with Saptamsha గ్రంథ పరిచయంలో D7కు '
            'speculation, creativity, spouse prosperity వంటి అంశాల ప్రస్తావన ఉంది. '
            'కానీ వ్యాపారాన్ని నిర్ధారించే ప్రత్యేక Goel నియమం/ముద్రిత పేజీ '
            'ప్రస్తుతం ధృవీకరించలేదు. వీటిని వర్తించిన ఫలితాలుగా లెక్కించలేదు.',
            style: TextStyle(fontSize: 12, height: 1.45,
              color: Color(0xFF4D5666))),
          const SizedBox(height: 10),
          LayoutBuilder(builder: (context, constraints) {
            final width = constraints.maxWidth < 350
                ? constraints.maxWidth : (constraints.maxWidth - 8) / 2;
            return Wrap(spacing: 8, runSpacing: 8, children: [
              SizedBox(width: width, child: _sourceOnlyVarga(context, 2,
                'ధనార్జన / ధననిల్వ')),
              SizedBox(width: width, child: _sourceOnlyVarga(context, 7,
                'ప్రత్యేక సందర్భాలు / సప్తాంశం')),
            ]);
          }),
        ],
      ),
    );
  }

  Widget _sourceOnlyVarga(BuildContext context, int factor, String title) {
    final supported = VargaService.definitions.any((d) => d.factor == factor);
    final data = supported ? VargaService.calculate(chart, factor) : null;
    if (data == null) {
      return const Text('ఈ చక్ర గణన అందుబాటులో లేదు.');
    }
    final stage = TopicStageEvidence(
      factor: factor,
      status: TopicStageStatus.insufficientEvidence,
      ruleIds: const ['VARGA-CROSS-003'],
      ruleText: 'IF వ్యాపారం పరిశీలిస్తే, THEN D1 → D10 → D2 → D7 '
          'చక్రాలను మూల క్రమంలో పరిశీలించాలి. ఇది పరిశీలన క్రమం మాత్రమే, '
          'నిర్దిష్ట శుభ/అశుభ ఫల నియమం కాదు.',
      source: 'Mallikarjuna 255 Rules, VARGA-CROSS-003, పేజీ 23. '
          'V.P. Goel D7 గ్రంథంలోని నిర్దిష్ట వ్యాపార IF/పేజీ ధృవీకరణ పెండింగ్.',
      details: 'D$factor — $title. చక్రం గణించబడింది. '
          'ఇది వ్యాపారం విజయవంతం/విఫలం అనే రూల్ మ్యాచ్ కాదు; '
          'అదనపు మూల పద్ధతి వర్తింపునకు వివరమైన IF నియమం అవసరం.',
    );
    return InkWell(
      onTap: () => _openDetail(context, stage, data),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: _gold),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('D$factor — $title',
            style: const TextStyle(fontSize: 12,
              fontWeight: FontWeight.w800, color: _darkBlue)),
          const SizedBox(height: 5),
          _VargaPreview(data: data),
          const SizedBox(height: 5),
          const Text('అనుబంధ మూల పరిశీలన • ఫలిత మ్యాచ్ కాదు',
            style: TextStyle(color: Color(0xFF836524), fontSize: 11)),
        ]),
      ),
    );
  }

  Widget _stagePreview(BuildContext context, TopicStageEvidence stage) {
    // The cross-chart registry can mention D6/D8 as source-only stages,
    // whereas the app implements the classical 16 vargas. Do not synthesize
    // an unsupported D6/D8 chart or mark the stage as a verified match.
    final supported = VargaService.definitions.any((d) => d.factor == stage.factor);
    final data = supported ? VargaService.calculate(chart, stage.factor) : null;
    return Card(
      margin: EdgeInsets.zero,
      elevation: 0,
      color: const Color(0xFFFFFBF3),
      shape: RoundedRectangleBorder(
        side: const BorderSide(color: _gold),
        borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: data == null ? null : () => _openDetail(context, stage, data),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('D${stage.factor} — ${data?.definition.teluguName ?? "చక్రం అందుబాటులో లేదు"}',
              maxLines: 2, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800,
                color: _darkBlue)),
            const SizedBox(height: 5),
            if (data != null)
              _VargaPreview(data: data)
            else const SizedBox(
              height: 72,
              child: Center(child: Text('ఈ వర్గ గణన ఇంకా లేదు. '
                'మ్యాచ్‌గా లెక్కించలేదు.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 11)))),
            const SizedBox(height: 6),
            Text(data == null ? 'గణన అందుబాటులో లేదు • పెండింగ్'
                : statusText(stage.status), maxLines: 2,
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700,
                color: data == null ? const Color(0xFF836524) : statusColor(stage))),
          ]),
        ),
      ),
    );
  }
}

/// A fixed-sign 12-cell South Indian chart. The 4 center squares represent
/// a single central panel, not houses. No degrees are invented in vargas:
/// VargaChartData presently carries sign placement, not fractional degrees.
class _VargaPreview extends StatelessWidget {
  const _VargaPreview({required this.data});
  final VargaChartData data;

  static const _signSlots = <int>[
    11, 0, 1, 2,
    10, -1, -1, 3,
    9, -1, -1, 4,
    8, 7, 6, 5,
  ];

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: LayoutBuilder(builder: (context, constraints) {
        final side = math.min(constraints.maxWidth, constraints.maxHeight);
        final cell = side / 4;
        final small = side < 240;
        return Stack(children: [
          for (var i = 0; i < 16; i++)
            if (_signSlots[i] >= 0)
              Positioned(
                left: (i % 4) * cell,
                top: (i ~/ 4) * cell,
                width: cell,
                height: cell,
                child: Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: const Color(0xFF8B3A4C), width: 0.8),
                    color: _signSlots[i] == data.ascendantSignIndex
                        ? const Color(0xFFFFE9EF) : Colors.white,
                  ),
                  padding: EdgeInsets.all(small ? 2 : 4),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (_signSlots[i] == data.ascendantSignIndex)
                        Text('Lg', style: TextStyle(fontWeight: FontWeight.bold,
                          color: const Color(0xFF8B3A4C), fontSize: small ? 9 : 11)),
                      Flexible(child: Text(
                        data.planets.where((p) => p.signIndex == _signSlots[i])
                            .map((p) => '${p.shortName}${p.retrograde ? "ᴿ" : ""}')
                            .join(' '),
                        maxLines: small ? 2 : 4,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: small ? 9 : 11,
                          color: const Color(0xFF132947), height: 1.1),
                      )),
                    ],
                  ),
                ),
              ),
          Positioned(
            left: cell, top: cell, width: cell * 2, height: cell * 2,
            child: Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: const Color(0xFFFFF9EE),
                border: Border.all(color: const Color(0xFF8B3A4C), width: 1)),
              child: Text('D${data.definition.factor}\n${data.definition.teluguName}',
                textAlign: TextAlign.center, maxLines: 3,
                style: TextStyle(fontSize: small ? 11 : 15,
                  color: const Color(0xFF12315E), fontWeight: FontWeight.w800)),
            ),
          ),
        ]);
      }),
    );
  }
}
