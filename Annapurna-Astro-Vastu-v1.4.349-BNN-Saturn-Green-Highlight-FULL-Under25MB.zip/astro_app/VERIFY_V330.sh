#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 tool/verify_varga_v330.py
if ! command -v flutter >/dev/null 2>&1; then
  echo 'Flutter SDK not installed. Static audit only. NOT an APK build pass.' >&2
  exit 2
fi
flutter --version
flutter pub get
flutter analyze
flutter test test/varga_all_19_if_then_policy_v330_test.dart
flutter test test/varga_four_stage_tap_v330_test.dart
flutter test
flutter build apk --release
