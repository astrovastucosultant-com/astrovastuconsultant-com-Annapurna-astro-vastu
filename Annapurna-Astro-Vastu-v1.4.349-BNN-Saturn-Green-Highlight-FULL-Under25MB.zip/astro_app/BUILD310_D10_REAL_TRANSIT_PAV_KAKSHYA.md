# Build 310 (working source, not packaged/released) — D10 exact transit PAV

- Reuses Swiss Ephemeris `AstroCalculationService.calculatePlanetAtUtc` to calculate date-specific sidereal longitudes and speed for the seven standard PAV recipient planets.
- Uses the saved horoscope ayanamsa and recorded fixed timezone offset; never silently converts through the phone timezone.
- Natal D1 PAV, BAV, SAV integrity audit (337) remains compulsory; no new ephemeris or approximate-longitude formulas are invented.
- Uses eight kakshyas of 3°45′: Saturn, Jupiter, Mars, Sun, Venus, Mercury, Moon, Lagna; direct and retrograde identified from actual speed.
- Selected D10 Rising/Stable/Downfall year now opens an instant transit panel at the first corresponding dasha window's midpoint, with selectable local calendar date and clock time. Jupiter/Saturn first, five other classical planets expandable.
- Displays each planet's absolute and sign longitude, zodiac sign, natal-lagna house, kakshya giver, exact 0/1 PAV, same-sign BAV/SAV, speed direction and period-lord marking.
- Rahu/Ketu are absent as PAV recipient rows under this classical method, and never reported as zero-point recipients.
- Distinguishes supporting transit evidence from independently verified promise or event timing; does not convert bindus into money/profit/loss probabilities.
- Corrected missing D10CareerOverview imports in v309 source.
- Added injectable resolver to support timezone, ayanamsa, seven-planet, kakshya boundary, valid-input unit tests.
- Verified independently with installed pyswisseph at 2026-11-03 12:00 IST: longitude-to-sign/kakshya mapping works for Jupiter and Saturn; this is NOT Flutter compile or on-device QA.

Not yet verified: Flutter analyzer, flutter test, Android APK compilation, device UI. User explicitly requested NO downloadable ZIP/APK until they ask.

Source for kākṣya order: P.V.R. Narasimha Rao, Vedic Astrology: An Integrated Approach, section 25.5.2 table 60.
