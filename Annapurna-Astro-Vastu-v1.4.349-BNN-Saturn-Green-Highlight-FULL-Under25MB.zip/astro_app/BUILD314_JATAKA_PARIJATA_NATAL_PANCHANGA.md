# Annapurna Astro Vastu v1.4.314: Natal Panchanga

- Five *birth* results from Jataka Parijata chapter 9: tithi 34–37; vara 38–39; nakshatra 84–90; nitya yoga 97–100; karana 101–103.
- Birth moment for all astronomical angas; weekday from birthplace's Swiss Ephemeris apparent sunrise. On missing sunrise, day lord remains unverified instead of silently using midnight/civil weekday.
- Every computed natal result has rule ID and verified chapter/verse link; printed page varies by edition and is not invented.
- Remainder of existing chart, prior BPHS curses rule-engine, varga, D10 unchanged.
- The traditional character sketches should not be treated as science or deterministic predictions of health, finances, or relationships.
- Validation: Dart/Flutter tests added; **SDK not available in current container; tests and APK build are not run**.
Source: https://vedicreader.com/s/shl?s=31c305a18f0 ; astronomical convention: https://packolkata.imd.gov.in/panchang/en/explanation
