# Build 325 — మూలగ్రంథ రచయిత vs. నియమాల సేకరణ (Provenance)

## Changes

- Shared result cards now display three **separate** bibliographic fields:
  1. supplied source/document and any supplied PDF page reference,
  2. verified original author/book/printed page **only when independently
     explicitly entered**; otherwise `మూలగ్రంథ రచయిత / ముద్రిత పేజీ ధృవీకరణ పెండింగ్`,
  3. `నియమాలను సేకరించి అందించినవారు: సిద్ధాంతి మల్లికార్జున`.
- A filename `Mallikarjuna PDF` is NEVER evidence that Mallikarjuna authored
  the original book or the astrological rule.
- `సిద్ధాంతి మల్లికార్జున నియమం`/self-authorship is only displayed for rules
  **explicitly** declared self-authored, not for missing citations.
- IF–THEN calculation match status is now independent of bibliographic author
  verification in the 176-topic varga list. A `SOURCE_PENDING` citation cannot
  turn a computed `hit.applicable=true` into a missing chart match.
- No original source file is renamed or overwritten and existing page
  information is preserved as a *supplied-document* reference.
- Preserves in-progress safe integration of the submitted 39-function Dart
  audit into supplementary varga evidence. That supplementary evidence is
  labeled pending and is NOT promoted to a classical final result without
  full conditions and printed-source corroboration.

## Attribution policy

| Provenance | App display | IF–THEN calculation |
| --- | --- | --- |
| Book, author, printed page explicitly source-audited | Original author + book + printed page | Evaluate chart conditions |
| Supplied file/page known, author not audited | Supplied document + pending author/printed-page verification | Evaluate chart conditions |
| No source file/page | Source pending | Evaluate if deterministic IF is available |
| Independently declared rule invented by Mallikarjuna | Clearly labeled self-authored | Evaluate chart conditions |

The app does not assert the accuracy of any traditional interpretation merely
because an IF–THEN predicate matched a sample chart.

## Validation limits

- Source and test Dart file syntax reviewed; 6 attribution regression test
  cases added under `test/rule_source_attribution_v325_test.dart`.
- Flutter/Dart SDK **not available** in the sandbox, so Flutter compilation,
  test execution and an APK build are not claimed here.
