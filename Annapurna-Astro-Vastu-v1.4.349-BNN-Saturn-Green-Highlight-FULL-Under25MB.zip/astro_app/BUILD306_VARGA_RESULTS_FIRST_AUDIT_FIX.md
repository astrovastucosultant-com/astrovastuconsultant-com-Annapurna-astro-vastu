# Build 306: varga evidence UI + D2 income route audit fix

- Base: 1.4.305. No original files removed.
- D2-IN-011 is the original Indu-lagna lord-house **observation**, not a proven income route: keep original rule/source and chart evidence under audit; do not label as favourable or predictive.
- D2 source-only unmatched/pending rules no longer display wealth-level THEN statements in their *result* fields; these remain accessible in the source rule drawer, with an explicit not-confirmed qualification.
- D2 audit separately counts inspected-but-unresolved income-route placement, actually nonmatching rules, and unavailable computations.
- The 16-varga master inspection no longer expands all lagna evidence by default. Lead with concise lagna summary; individual planetary placements are in tap details.
- New regression tests check Indu source-only treatment and unverified wealth-level result text.
- A complete source-backed IF–THEN result engine and full Flutter/APK compile are *not* claimed; this release is targeted UI and classification correction.
