# Annapurna Astro Vastu — v1.4.316

Purpose: Fix the Varga lordship and evidence presentation issue shown in the supplied D1 screenshot.

- Show all 12 potential house lordships for planets in the inspected varga instead of only 5/9/6/8/12. Example: Sagittarius ascendant Venus = 6L and 11L, not just 6L.
- Group planet-level supportive and challenging indicators. When the same planet appears on both sides (e.g., naturally benefic Venus as functional 6L), classify as mixed once, not as two independent confirmations.
- Do not mislabel raw indicator counts as proven outcomes or probabilities.
- Put detailed observational USER-VARGA IDs behind a second expansion tile; the first expansion shows the consolidated context and contradictory-planet explanation.
- Retain all prior v1.4.315 sources and UI features.
- Add regression tests for mixed unique-planet counting and Sagittarius/Venus 6L+11L.

Status: ZIP archive integrity and source continuity checked. Flutter SDK not available in this environment; compilation and automated Flutter test run are NOT verified. This is a presentation/ownership audit improvement, NOT a new source-backed predictive rule.
