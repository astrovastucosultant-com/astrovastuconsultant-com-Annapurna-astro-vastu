# v1.4.319 — extra D5 D6 D8 + topic-first navigation

- Kept all previous v1.4.318 source, rules and UI components.
- Added 3 extra varga calculations: D5 (PVR fixed odd/even panchamsa 6°), D6 (odd Aries/even Libra 5°), D8 (modality-start 3°45′).
- The extra three are NOT included in Shodashavarga/Vimshopaka.
- All chart-specific topic navigation is available directly above the selected varga chart. On opening a subject show source rule, actual chart placement inspection, highlighted outcome only for verified IF hits, and only verified remedy.
- V.P. Goel contents pagination: D5 from p.305, D6 from p.317, D8 from p.324; these contents alone are not verifiable predictive IF–THEN, so those results remain source-pending.
- Distinguishes PVR constructions from Goel Cyclical / Hadda / Raman alternate methods pending access to full source text.
- Added mapping and UI data tests, not executed (Flutter SDK unavailable). No APK is claimed.
