# v1.4.313 — Natal Panchanga + BPHS 83 curse results

- Five results calculated from actual natal Sun/Moon longitudes and civil weekday.
- Tithi: 5 traditional Nanda/Bhadra/Jaya/Rikta/Purna groups. Muhurta classification is explicitly NOT a natal curse/promise.
- Weekday: actual civil weekday and its ruler, house placement. Before local sunrise traditional vara can differ; not silently treated as confirmed.
- Nakshatra: 27 themes, 4 padas and correct 9-lord Vimshottari order.
- Yoga: 27 traditional Muhurta categories based on 27 Nitya yogas.
- Karana: 11 traditional activity domains, 60 half-tithi placements.
- Every result expandable as: Result -> Natal evidence -> Rule ID -> source URL.
- User's elemental planetary associations distinguished from the real vara/nakshatra lords and marked as source-pending.
- BPHS chapter 83 73 yogas + 4 older Rahu/Ketu rules preserved. Full matched curse group and source-implied progeny obstruction upfront, pink not green; no medical/factual curse claims.
- No new invented remedies. Existing source remedies kept under expanded source rule.
- Flutter SDK and APK compiler unavailable for execution: tests authored but NOT run.

References:
https://whatsmytithi.com/guides/panchang-five-limbs
https://totallytarot.net/library/term/tithi-groups
https://paramarsh.app/patrika/nakshatras/27-nakshatras-complete-guide
https://sitharsastrology.com/blog/the-27-nithya-yogas-in-panchang
https://totallytarot.net/library/term/karana
https://enjoylearningsanskrit.com/scriptures/parashara/chapter-83/

IMPORTANT: Original BPHS curses are largely progeny-specific; do not extrapolate to career, longevity, wealth or physical illness.
