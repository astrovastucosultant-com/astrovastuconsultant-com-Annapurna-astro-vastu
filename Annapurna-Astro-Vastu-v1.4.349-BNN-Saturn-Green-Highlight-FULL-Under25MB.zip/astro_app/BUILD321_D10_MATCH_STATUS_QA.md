# v1.4.321 — D10 applied-status screenshot QA

- Government 5th-lord / 9th-lord source rules are applicable only when their actual conditions match. Unmatched rules stay in the source/audit section, not green client results.
- The combined D9 promise + D10 authority result is informational: the supplied government-job source does not specify a complete D10 job verification IF–THEN. Do not convert it into a government job or senior-rank prediction.
- Senior-government source examples stay in the audit section; no inferred senior rank.
- Daily-worker category appears as an applied finding only with a confirmed exact worker or skilled-trade row.
- Per-topic rows no longer repeat the same unsupported remedy message. D10 practical guidance is not presented as a source-backed remedy.
- No natal calculation, varga formulas, original books/registries, or other module rules were altered.

QA: Source ZIP integrity and preservation can be checked in this environment. Flutter/dart SDK was not installed; compilation and widget tests must run in GitHub Actions.
