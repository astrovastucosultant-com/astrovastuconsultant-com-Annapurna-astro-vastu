# Annapurna Astro Vastu v1.4.326 — D10 పూర్తి సోర్స్ ఇంటిగ్రేషన్

## సోర్స్ మూలం

యూజర్ అందించిన `Annapurna-Astro-Vastu-v1.4.325-Source-Author-Collector-Separate-Stubs-Linked-Under25MB (1).zip` నుండి నేరుగా పూర్తి Flutter ప్రాజెక్ట్ తీసుకున్నాం. ZIP పేరు 325 అయినా మూల `pubspec.yaml`లో `1.4.324+324` ఉంది; కొత్త వెర్షన్‌ను `1.4.326+326`గా మార్చాం. 19 వర్గచక్రాల definitions, పాత రూల్ ఇంజన్లు, డేటా, ఇతర UI తొలగించలేదు.

## D10 నిజమైన calculation bridge

`D10LiveBridge.context` ద్వారా అసలు natal chart (Swiss-Ephemeris‌తో తయారైన D1) నుండి D10/D9 ను `VargaService.calculate` ద్వారా గణిస్తుంది. పాత `D10CareerService.saturnStream` — శని ఉచ్చ/స్వరాశి, నీచ, 6/8/12, రాహు/కేతు యుతి — అదే ఫలితాన్ని మూల గణనగా తీసుకుంటుంది. D1 ప్రారంభ వృత్తి, D10 ప్రధాన వృత్తి; D9 కేవలం మద్దతు/ఆడిట్. `D10-PP` (D1 Sun/Moon/Mars/Rahu లో కనీసం 2 మంది లగ్నం/10H/ఆ భావాధిపతులతో సంబంధం) గణన స్వతంత్రంగా తిరిగి తనిఖీ చేసి ఉపయోగించబడుతుంది.

ప్రభుత్వ ఉద్యోగం: `gov job.pdf` Ch.26 p.1 `D10-GOV-01` లేదా `D10-GOV-02` (D1 5L/9L → D9 natal 5/9 sign) **మూల నియమాలు వర్తించాలి**, D10 శని అగోచరిష్ట అయి ఉండాలి, D10 సూర్యుడు/10L/ఇంద్రదేవత అధికార సంబంధం కలిగి ఉండాలి. **ఇది మల్లికార్జున సమీకృత IF–THEN పరిశీలన, మూలగ్రంథంలో ఉన్న ఒకే జడ్జ్‌మెంట్ అని చెప్పడం లేదు.** ప్రభుత్వ నియామక ఫలితానికి హామీ కాదు. `D10-GOV-03/04` source-only examples స్వతంత్ర ధ్రువీకరణగా తప్పుగా ఉపయోగించబడవు.

వ్యాపారం: D10 గోచరిష్ట వర్తించినప్పుడే ప్రధాన మోడ్; జన్మ PP అదనపు మద్దతైతే రెండవ రూల్. ఉద్యోగం: D10 అగోచరిష్ట వర్తించినప్పుడే ప్రధాన మోడ్. D1/D10 రెండూ ఒకే దిశలో ఉంటే continuation rule; వ్యతిరేకంగా ఉంటే మూల వృత్తి క్రమం రూల్.

## UX

`lib/screens/d10_career_overview.dart` మొదట `D10LiveIfThenPanel` ప్రదర్శిస్తుంది: వర్తించిన Rule ID → టచ్ చేస్తే జాతక పరిశీలన/మూలపుట → టచ్ చేస్తే హైలైట్ ఫలితం → టచ్ చేస్తే (ఉన్నప్పుడే) పరిశీలించిన పరిహారం. ధ్రువీకరించిన remedy లేనిచోట ఏ పరిహారమూ ఊహించి సృష్టించదు. Existing career dashboard/business/job lists/government/high-position/timing/year/Ashtakavarga/లెగసీ రూల్స్ అన్నీ దిగువ అలాగే ఉన్నాయి.

## VARGA-CROSS

అసలు `assets/varga/mallikarjuna_255_rules.json` నుండి ఇప్పటికే ఉన్న `VargaUnifiedRuleService.evaluate` ద్వారా సంబంధిత VARGA-CROSS 001/002/016/017/019/020/021/022/028 రూల్స్ పరిశీలించి, matched/pending స్థితితో ప్యానెల్ inspectionలో మాత్రమే చూపిస్తాం. **ఒక్క VARGA-CROSS స్థితి కూడా `D10EvidenceContext.facts`లోకి పోదు; ఫలితం trigger చేయదు.**

## పరీక్షలు

- New: `test/d10_if_then_engine_test.dart`, `test/d10_live_bridge_test.dart`, `test/d10_rules_panel_test.dart`.
- Regression: all existing `test/` files preserved; varga definitions remain 19.
- Container లో Flutter/Dart SDK లేదు, network DNS కూడా లేదు. అందుచేత **`flutter analyze`, `flutter test`, `flutter build apk --release` ఇక్కడ విజయవంతం కాలేదు / చేయలేకపోయాం**. Static checks, ZIP CRC, ఫైల్ పోలిక నివేదికలు ప్యాకేజీతో జత.

## GitHub Actions ద్వారా compile/test/build

GitHubలో కొత్త పూర్తి సోర్స్ ZIPను రిపోజిటరీ rootకు అప్‌లోడ్ చేయండి (పాత 325 ZIPను తొలగించవద్దు). రిపోజిటరీ `.github/workflows/build-apk.yml` లో `source_zip` manual inputలో కొత్త ZIP ఫైల్ పూర్తి పేరు ఇవ్వండి. ఆ workflow APK build చేస్తుంది; కానీ ప్రస్తుతం ఆ workflow `flutter analyze` / `flutter test` రెండింటినీ నడపదు. కాబట్టి క్రింది commandలను projectలో లేదా CIలో విడిగా అమలు చేయాలి:

```bash
cd astro_app
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

టెస్టులు fail అయితే Build Success గా ప్రకటించకండి; APK మరియు Flutter run logsతో తిరిగి పరిశీలించాలి.
