# v1.4.311 — Blue & Gold Icon Tile Navigation

- Added accessible 3-column cream/gold icon navigation in the natal chart screen.
- Tiles open the actual Panchangam/natal chart, Varga, D10, Ashtakavarga, Jaimini, BNN, KP and Dasha modules.
- The existing 13 horizontal tabs and system drawer remain intact.
- Added a bottom five-item blue navigation bar (birth chart, vargas, D10, Ashtakavarga, more).
- Added the same icon-grid navigation to D10 with jumps to existing career results, source rules, D10 SAV and year panels.
- No alteration to calculations, ephemeris, source rule matching, save/export, or chart data.
- The result is styled after the reference screenshot but not pixel-identical; the mobile build must be checked on-device.
- Flutter SDK not present in the editing environment; build/test must be performed by GitHub Actions.
