# v1.4.318 — Source-preserving career cross-chart review

- User-defined primary career factors for BOTH business and employment are D1/D9/D10.
- Original `VARGA-CROSS-003` (Mallikarjuna 255 rule catalog, p.23) remains intact as D1/D10/D2/D7 source-only chart order. The rule is workflow/source-only, not an outcome.
- Business secondary D2 (wealth) and D7 (context-specific) previews are shown in a collapsed panel, never counted in the primary chart confirmation score.
- V. P. Goel *Predict with Saptamsha* public synopsis names speculation, creativity, spouse prosperity and fulfillment among D7 subjects. No verified printed page or specific IF-for-business was established; the UI explicitly says so. Do not label Goel-D7 a chart-matched business prediction.
- Source IF -> natal analysis -> highlighted result order preserved in the common varga result widget.
- Full Flutter compile and APK build are not verified by this repository patch alone.
