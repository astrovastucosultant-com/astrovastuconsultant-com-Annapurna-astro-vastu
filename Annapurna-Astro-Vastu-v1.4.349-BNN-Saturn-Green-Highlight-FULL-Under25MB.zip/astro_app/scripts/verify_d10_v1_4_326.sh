#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v flutter >/dev/null || { echo 'Flutter SDK not found; no build was run.' >&2; exit 127; }
flutter --version
flutter pub get
flutter analyze
flutter test
flutter build apk --release
apk=build/app/outputs/flutter-apk/app-release.apk
[[ -s "$apk" ]] || { echo "Missing APK: $apk" >&2; exit 1; }
echo "All gates passed. APK: $apk"
