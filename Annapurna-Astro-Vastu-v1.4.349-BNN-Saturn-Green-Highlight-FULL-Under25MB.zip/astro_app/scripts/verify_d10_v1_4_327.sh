#!/usr/bin/env bash
# Execute in astro_app directory with Flutter SDK configured.
set -euo pipefail
flutter pub get
flutter analyze lib/astrology/d10_topic_rule_bridge.dart \
  lib/screens/varga_topics_panel.dart \
  lib/screens/unified_varga_results_tab.dart \
  lib/features/d10_if_then
flutter test test/d10_topic_rule_bridge_test.dart
flutter test test/d10_if_then_engine_test.dart \
  test/d10_live_bridge_test.dart \
  test/d10_rules_panel_test.dart \
  test/varga_topic_catalog_all_19_test.dart
flutter build apk --release
