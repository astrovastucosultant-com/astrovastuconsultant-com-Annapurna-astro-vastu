ANNAPURNA ASTRO VASTU v1.4.320 — APK compile correction

Source: v1.4.319, all 848 original ZIP entries preserved.

Build #335 from 2026-11-05 diagnostic artifact reported:
  lib/screens/varga_shastra_audit_panel.dart:62:55: Error: Not a constant expression.
  lib/screens/varga_shastra_audit_panel.dart:62:48: Error: Method invocation is not a constant expression.

Fix:
  Replaced `Clipboard.setData(const ClipboardData(text: VargaShastraRegistry.urlFor(factor)))`
  with `Clipboard.setData(ClipboardData(text: VargaShastraRegistry.urlFor(factor)))`.

Reason: `VargaShastraRegistry.urlFor(factor)` is a runtime function call and
cannot be an argument to a const constructor. The surrounding const Icon,
Text, SnackBar widgets remain unaffected.

Other changes: pubspec version from 1.4.319+319 to 1.4.320+320.
No astrological rules, varga calculations, UI structure, other existing
files or source references were intentionally changed.

Validation: ZIP CRC check and source substitution check passed. Flutter/Dart
SDK is absent in this runtime, so no compile or APK build could be run here.
Build v1.4.320 using GitHub Actions. A rerun of v1.4.319 with identical code
will not resolve this deterministic Dart compile error.
