# Annapurna v1.4.335 — User Uploaded OCR/JSON/IF–THEN Flutter Integration Audit

Base: `Annapurna-Astro-Vastu-v1.4.334-BNN-CLEAN-RESET-FULL-Source-Under25MB.zip`; version 1.4.334+334. Updated to 1.4.335+335.

## Source and scope
- Source upload: `Annapurna_OCR_JSON_IfThen.html` (HTML, **not authenticated book OCR**).
- Exact source SHA256: `03785ac2db496b75d53b3f55da5d1b000e905d86ddc0378cc374112a25a734dd`.
- Parsed unique source records: **60**, across **19** D-factors in the uploaded HTML (D11 present as index-only, D4 not present).
- Original source fields `id`, `varga`, `topic`, `ocr`, `if`, `then_yes`, `then_no`, `source` preserved. New unique engine IDs are prefixed `USR-HTML-` to avoid colliding with existing app rule catalogs.
- No printed-source attribution or PDF image-page numbers invented; some D12 user labels claim p.293/300/etc, clearly *unverified*.
- Existing 255-rule catalog and old engine files unchanged. User HTML catalog is a separate reference layer in selected D-factor, and a searchable all-60 rulebook screen.
- NO old BNN data restored. `assets/bnn/bnn_verified_release.json` remains an empty release catalog.

## Predicate coverage
- 3 complete interpretable checks: `D2-01` sun hora, `D2-02` moon hora, `D3-02` D3 exalted Mars in 10th.
- 2 partial-positive OR checks: `D10-02` Saturn debilitated or same sign with nodes (other clauses unimplemented); `D12-10` D12 8th planet (aspect branch unimplemented). Their absence returns UNKNOWN, never false.
- Remaining 55 records: reference/source-only; unknown rather than an invented matching horoscope prediction.
- NO `then_no` fallback prediction is generated. No OCR status gates applied to chart mathematics.
- Source verification and chart predicate verification are independent. The displayed outcomes are *traditional claims from the uploaded HTML*, not empirically validated probabilities.

## Source preservation and compatibility
- Original ZIP files: 828; new files: 5; modified files: 2; removed files: 0.
- Changed source files: astro_app/lib/screens/chart_screen.dart, astro_app/pubspec.yaml.
- New source files: astro_app/BUILD335_UPLOAD_HTML_IFTHEN_INTEGRATION.md, astro_app/assets/varga/user_html_60_rules.json, astro_app/lib/astrology/user_html_if_then_service.dart, astro_app/lib/screens/user_html_if_then_panel.dart, astro_app/test/user_html_if_then_v335_test.dart.
- Baseline D9/D10/D12 and all BNN-related files in v1.4.334: SHA256 unchanged.
- This build is based on the BNN-Clean-Reset 334 branch, **NOT** the separate D9-One-Place-Unified-Marriage 334 ZIP. That independent same-version D9 update has not been merged.

## QA status
- HTML records extracted, original text fields and IDs validated; JSON valid; ZIP CRC validated; source file comparison validated.
- Flutter/Dart analyzer, `flutter test` and actual Android APK build: **NOT run** (Flutter SDK unavailable in local runtime).
- Dart test source added but **NOT executed**.
- For GitHub Actions, upload the full ZIP as a separate filename; workflow chooses highest version 1.4.335 when no equal-version archive exists, or supply exact `source_zip`.

## HTML varga record counts
- D1: 2
- D2: 2
- D3: 2
- D5: 2
- D6: 2
- D7: 4
- D8: 2
- D9: 2
- D10: 10
- D11: 2
- D12: 11
- D16: 2
- D20: 2
- D24: 4
- D27: 2
- D30: 2
- D40: 2
- D45: 2
- D60: 3
