# Build v1.4.324 — Apply existing source rules, don't fabricate missing rules

Base: full v1.4.323 project. No previous source files removed.

## Source-preserving executable IF improvements
- Cross-varga **VARGA-CROSS-022**: D1 verified 5L/9L special relationship plus exalted 10L in kendra; unverified other raja-yoga forms stay pending.
- **VARGA-CROSS-028**: D10 10L's conjunction with a separate Mercury/Venus or its occupation of their governed signs (Taurus/Gemini/Virgo/Libra). This exact source OR is fully tested.
- **VARGA-D10-001/002**: communication/engineering career source relationships tested for genuine conjunction, Parashari graha aspect or exchange; a planet cannot conjunct/aspect itself.
- **VARGA-D9-002**: 7L-Sun/Moon relationship tested under same explicit convention.
- **VARGA-D10-008**: verified concrete 10–12/Rahu links can match; untested node aspects are not inferred.
- **VARGA-D24-002**: 4/9–12/Rahu educational links tested in D24, with alternative undefined node aspects left unverified.
- **VARGA-D45-002**: Jupiter's D45 lagna occupation or classical aspect tested directly.
- **VARGA-D12-006/007**: both the respective house and house lord must receive benefic support; one alone cannot create a full match.
- **VARGA-D12-012**: Rahu conjunction alone no longer pretends to verify a source requiring Rahu graha drishti; unresolved node drishti remains pending.
- Exact preserved 42-page source document name and PDF page displayed. DO NOT attribute source PDF rows to V. P. Goel without bibliographic verification.

## Not changed
- 176 subject headings / 19 vargas; existing Rule ID topic mapper; all other modules including D10, Panchanga, Shapa, KP, BNN, Jaimini; True Rahu.
- Existing 255 rule JSON is unchanged; 102 workflow / 72 direct / 81 qualitative; no transformation of a procedure or subjective strength criterion into a false event guarantee.

## Testing and known limits
- Regression tests added for source binding, D10 self-conjunction, D9/D10/D45 source condition status, D12 combined conditions and Rahu drishti caution.
- `flutter test` and Android APK compilation require Flutter SDK; if unavailable, tests are supplied but not claimed passed.
- This is a targeted expansion, NOT a claim of all 176 topics having complete validated event predictions. Source IF conditions and genuine chart data still govern matched status.
