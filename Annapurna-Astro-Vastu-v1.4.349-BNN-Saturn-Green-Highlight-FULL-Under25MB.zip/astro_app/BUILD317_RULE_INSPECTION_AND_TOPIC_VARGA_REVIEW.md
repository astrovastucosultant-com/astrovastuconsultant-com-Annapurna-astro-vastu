# Build 317 — Source Rule → Natal Examination → Highlighted Result

Based on full v1.4.316 source, retaining older rule engines and modules.

1. `UnifiedRuleResultTile`: one common source-first drill down across all 16 available varga charts: rule/source, natal evidence, status-aware highlighted result, source-backed remedy if supplied.
2. `UnifiedVargaResultsTab`: matches use the same shared presentation, with unverified/unmatched source rules never highlighted as client predictions. Original source identifier and page string are retained.
3. `TopicVargaReviewPanel`: under topic-wise cross-varga review, show the *source-prescribed relevant charts together* as fixed-sign South Indian mini charts, plus status badges. Tapping an individual chart shows its larger placements, chart-specific evidence, and matching Rule IDs. Uses existing `MultiChartTopicService` definitions without inventing new associations.
4. Unsupported source-only D6/D8 are labelled as unavailable/pending rather than drawing fake charts or treating them as matches. D1, D2, D3, D4, D7, D9, D10, D12, D16, D20, D24, D27, D30, D40, D45, D60 remain available.
5. Added widget tests for grouped required charts, unsupported charts, and order of source/evidence/highlight.

## Implementation scope and validation

* This is a UI integration and source-preserving update; not all existing astrologic source IF predicates are fully implemented.
* Scores represent confirmed conditions, **never predicted event probabilities**.
* `VargaChartData` carries placements (signs) but not a derived divisional-planet degree; no fractional divisional degree is fabricated in the new mini chart.
* ZIP integrity and asset retention can be checked without the Flutter SDK. Flutter compile / APK device rendering / widget tests **not executed** in this environment.
