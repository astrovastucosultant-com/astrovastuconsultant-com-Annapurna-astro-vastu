# v1.4.333 — D9 handwritten duplicate cleanup

## Scope
- User requested: remove handwritten marriage rules from D9 UI as duplicates of printed marriage material; they are not validated IF–THEN matches.
- Suppression is restricted to **D9 runtime** registry calls (`individualForFactor(9)` and `forFactor(9)`) for entries whose identifiers start with `MM-R`.
- 42 D9-related handwritten registry entries are no longer shown in D9 varga result cards.
- 69 original registry records stay in the source archive for rollback / traceability, and historical D1/D7/D30 routing is unchanged.
- Existing two-chart **printed table** entries (10) and other marriage engines remain unchanged. The distinct 43-rule marriage checklist is not changed.
- Special D7 Ketu confirmation `MM-D7-DIV-35` remains in the D9 single-chart source registry.
- Outdated D9 marriage timing label no longer refers to unimplemented handwritten rules.
- No new IF–THEN rule, remedy, or favourable outcome has been invented.

## Important printed-rule-count boundary
The available code explicitly distinguishes 10 printed matching tables, a separate 43-rule checklist, and legacy handwritten registry items. A complete, independent set of 44 machine-verified printed predicates cannot be inferred from this repository. No claim of 44 fully implemented printed rules is made.

## Regressions to run with Flutter SDK
`flutter pub get && flutter test test/d9_handwritten_duplicate_suppression_v333_test.dart && flutter analyze && flutter build apk --release`

The environment in which this archive was made does not have Flutter or Dart installed; build and Dart tests must be verified through GitHub Actions.
