# v1.4.323 — 176 అంశాలు × ఉన్న మూల నియమాల అనుసంధానం

## Actual changes

* `VargaTopicsPanel`: the evaluated `VargaRuleService` rules and the source-preserving `VargaUnifiedRuleService` (255 rules) are **displayed inside the corresponding chart topic**, not only in a separate appendix.
* Direct D-factor rules: 97 entries belong to the 19 currently displayed vargas. 84 are explicitly assigned to their most appropriate one of the existing 176 subject topics; 13 have no honest subject equivalent and stay visible as **ఇతర మూల నియమాలు** in the SAME D-factor.
* Selected multi-varga CROSS rules are attached to the topic they audit; a CROSS workflow instruction is **not** itself a matched prediction.
* In each subject: tested/verified source matches first; tested nonmatches next; unimplemented and qualitative conditions remain pending. Do not display their THEN as a client's natal outcome.
* New evaluable original IFs: D5-003, D6-002/003/006 and D8-003/004 (preserving the original IDs, wording and pages). Avoid treating D6 indications as medical diagnoses.
* Existing VargaRuleService families, D10 profession engine, 255 JSON rulebook, 19 varga definitions, calculation settings and source remedies are preserved.
* Original 255 JSON asset remains unchanged (source provenance intact).

## Not yet completed

The original 255 source catalog includes 102 workflow, 81 qualitative and 72 direct entries. There is no claim of 176 fully verified independent predictions. Remaining qualitative strength, dashas, specialised Goel text and timing require exact source-linked IF implementations. This integration puts existing computed findings where the user can actually find and review them while preserving honest status.

## Verification

Automated tests were added for chart counts, topic bindings and D5/D6/D8 IF evaluation. Flutter SDK is not installed in this container, so **the tests/Android APK build were NOT executed**. Upload this source ZIP to GitHub for a compile + mobile verification.
