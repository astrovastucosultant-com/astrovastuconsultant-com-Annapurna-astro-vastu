# Annapurna Astro Vastu v1.4.331 — All 19 Vargas IF–THEN + SAV/BAV/PAV

## Scope and provenance

- Base: **complete 1.4.330 source**; all existing 888 archive members preserved by path.
- All 19 charts and their 176 topic titles remain; no existing source rules, D10 engine, or rule attachments deleted.
- Existing `VargaRuleService` and 255-rule `VargaUnifiedRuleService` remain the authoritative IF–THEN engines. Actual matched rules appear first. Failed/pending source rules appear in separate audit sections. Only conditions wholly verifiable from chart inputs can be marked matched.
- Added one directly evaluable original rule **`VARGA-D8-002`**: D8 eighth-house planet occupancy. The original source IF/THEN and page are retained; there is no invented strength threshold.
- An **independent evidence layer**, not a replacement event engine, computes 7-planet BAV, 8-contributor PAV (Prastara), and SAV for all 19 charts and all 12 houses, using the exact varga signs already computed by `VargaService` (including selected D16 method). A separately computed D1 natal reference accompanies each varga. Do not confuse D1 with the varga table.
- Existing computational and source-backed event rules are **not modified by AV values**. AV is appended to the *horoscope examination* and displayed in a separate inspectable calculation panel. AV records always have IDs `AV-D{factor}-H{house}-SAV-BAV-PAV` and the policy forbids treating them as predicted outcomes.
- **Method caveat:** Applying classical seven-planet raw Ashtakavarga to divisional sign placements is a supplementary divisional AV method (the D10 case has an existing reference in the project). Numeric support from a divisional AV table should not be advertised as a universally established prediction rule for every varga. Source-backed additional interpretation and event timing remain separate.

## In each of the 19 chart tabs

1. Rule-matched original IF–THEN lines first, preserving Rule ID and available source/page.
2. Tap rule → actual chart examination. Includes the selected topic house's computed SAV, all seven BAV bindus and the eight-contributor PAV giver identities (only 1 contributors displayed as bindu givers).
3. Highlighted event result only for the original verified source/chart IF–THEN condition; an AV score cannot create a result by itself.
4. Remedy only if exactly linked to its source. Otherwise explicitly unavailable.
5. Unmatched and pending rules isolated from green prediction cards.
6. Separate per-chart 12-house SAV table against **D1 house SAV** and per-topic detailed BAV/PAV table; missing planet data / failed audit generates a warning rather than false output.

## Raw AV arithmetic invariants

- BAV is seven recipient planets (Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn); Rahu/Ketu do **not** receive independent classical BAV rows.
- Each BAV recipient receives 8 binary PAV contributor rows: the seven planets + Lagna.
- Each recipient's sign-specific BAV is the sum of its eight contributor bits; each sign SAV is the sum of seven BAV recipient values.
- Standard seven BAV totals: Sun 48; Moon 49; Mars 39; Mercury 54; Jupiter 56; Venus 52; Saturn 39. Grand SAV total: 337.
- Source ashtakavarga and mapped varga ashtakavarga must both pass checks before their evidence appears. They are **never** interpreted as event probabilities, promotion/job guarantees, medical claims, specific dates or self-contained full-source matches.

## Existing direct source catalogue, not a count of final predictions

19 varga factors: D1, D2, D3, D4, D5, D6, D7, D8, D9, D10, D12, D16, D20, D24, D27, D30, D40, D45, D60.

176 topic headings and 97 direct varga rows out of 255 source-registry rows remain, **not 176 independently verified prediction rules**. Some original rules require qualitative strength, aspects, karakas, dates or timing calculations not present in the underlying IF engine. They remain pending. AV numbers do not supply missing classical IFs or page evidence. A successful static check does not prove a horoscope prediction correct.

## Changes

Updated existing:

- `pubspec.yaml` → `1.4.331+331`
- `lib/screens/varga_topics_panel.dart` → per chart and per topic AV evidence, appended only to examinations; all original rule decisions remain untouched
- `lib/astrology/varga_rule_match_policy.dart` → `AV-D*` IDs audit-only
- `lib/astrology/varga_unified_rule_service.dart` → exact D8 occupation rule evaluator

New:

- `lib/astrology/varga_ashtakavarga_service.dart` → all 19 vargas / 12 houses / 7 BAV / 8 PAV bindu givers and invariant verification
- `lib/screens/varga_ashtakavarga_panel.dart` → all-house summary and per-topic BAV/PAV drilldown
- `test/varga_ashtakavarga_all_19_v331_test.dart` → factor/house, PAV→BAV→SAV, D10 parity, D16 method, failures and audit-only guards
- `test/varga_ashtakavarga_widget_v331_test.dart` → expanded per-topic UI
- `tool/verify_v331.py` → offline source-and-arithmetic-constant sanity check
- `VERIFY_V331.sh` → full CI commands
- This report.

## Verification honesty

Offline source audit: **18/18 static checks PASS** and all original files preserved by path. ZIP integrity is separately checked after packing.

Flutter SDK is **not** available in this container. `flutter analyze`, Flutter unit/widget tests, and release APK build **have not been executed**. For definitive verification after uploading the full ZIP to GitHub and extracting, run:

```bash
bash VERIFY_V331.sh
```

A 25 MB **source ZIP** constraint is not the same as a 25 MB release **APK** constraint; do not claim the APK meets the size target until an actual build verifies it.
