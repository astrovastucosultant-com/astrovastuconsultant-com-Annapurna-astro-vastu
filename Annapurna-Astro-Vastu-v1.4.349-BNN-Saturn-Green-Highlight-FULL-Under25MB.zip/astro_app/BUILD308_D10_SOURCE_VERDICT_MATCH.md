# v1.4.308 — D10 source-rule verdict presentation

* Reuses **existing evaluated source IDs** (D10-SEQUENCE, D10-GOCHARISTA,
  D10-AGOCHARISTA, D10-JOB-BUSINESS, D10-GOV-01..04,
  D10-HIGH-POSITION and D10-RAJAYOGA).
* Adds source-linked conclusion cards for **Job, Business, Government Service,
  and High Position**. Tap card -> natal inspection and matching IDs -> tap ID
  -> existing Rule/Source inspection screen.
* Distinguishes D1 earlier mode vs D10 current career mode. Direct Government
  employment is not claimed from the D9 promise alone or from a business-oriented
  D10 mode; government-linked consultancy is labelled separately.
* High-position claim requires management support plus repeated Rajayoga or
  strong government-status evidence. Source-only rows cannot be promoted to
  matched outcomes. Nonmatching rules never mean a real-world job is impossible.
* Removes the generic "needs separate source rules" dead-end from D10 summary,
  since the existing source evaluators now drive the four outcome cards.
* No percentage is displayed as event probability. No unverified remedies added.
* Static integration and model tests supplied. Build and device testing
  still require a Flutter toolchain / GitHub Actions.
