import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_master_service.dart';
import '../models/birth_data.dart';

/// BNN presentation separates chart placement observations, time study,
/// and the verbatim source library. It does not assert unverified rules as
/// past events, present diagnoses, or future events.
class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnMasterRule>> _catalog = BnnMasterCatalog.load();
  int _period = 1;
  String? _topic;
  String _search = '';
  int _visibleLimit = 10;
  bool _showLibrary = false;
  bool _showTimeDetails = false;
  bool _showTimeSource = false;

  static const _burgundy = Color(0xFF7B1E2B);
  static const _muted = Color(0xFF62666D);
  static const _bg = Color(0xFFF7F8FA);
  static const _periodNames = <String>['గతం', 'వర్తమానం', 'భవిష్యత్తు'];

  @override
  Widget build(BuildContext context) => FutureBuilder<List<BnnMasterRule>>(
        future: _catalog,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return _panel(child: Text(
              'BNN నియమాలను లోడ్ చేయలేకపోయాం: ${snapshot.error}',
            ));
          }
          if (!snapshot.hasData) {
            return const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            );
          }
          final rules = snapshot.data!;
          final age = BnnMasterAnalysis.completedAge(
            widget.birthData.localDateTime, DateTime.now(),
          );
          final topics = rules.map((r) => r.topic).toSet().toList()..sort();
          final allCandidates = BnnMasterAnalysis.inspect(rules, widget.chart);
          final candidates = allCandidates
              .where((e) => _matches(e.rule))
              .toList(growable: false);
          final selectedRules = rules
              .where(_matches)
              .toList(growable: false);
          final timeRules = rules.where((r) =>
              r.condition.contains('రౌండ్') ||
              r.condition.contains('రవాణా') ||
              r.condition.contains('గోచార') ||
              r.result.contains('వయస్సు') ||
              r.result.contains('కాలం')).toList(growable: false);

          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _panel(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('భృగు నాడీ (BNN)',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  const Text('అంశాలవారీ గ్రహ పరిశీలన • కాల అధ్యయనం • మూల నియమాలు',
                    style: TextStyle(fontSize: 12.5, color: _muted)),
                  const SizedBox(height: 12),
                  Wrap(spacing: 6, runSpacing: 6, children: [
                    _countPill('462 మూల నియమాలు', const Color(0xFFEDF0F5)),
                    _countPill('${topics.length} అంశాలు', const Color(0xFFEDF0F5)),
                    _countPill('${allCandidates.length} ప్రారంభ సూచనలు',
                        const Color(0xFFFFF0D6)),
                  ]),
                  const SizedBox(height: 9),
                  const Text(
                    'గమనిక: జాతకంలో కొన్ని గ్రహాలు ఒకే రాశిలో ఉండటం పూర్తి '
                    'నాడీ నియమం వర్తించిందనడానికి ఆధారం కాదు. మూలం, దృష్టి, '
                    'గ్రహ క్రమం, గోచారం, కాలం ధృవీకరించాలి.',
                    style: TextStyle(fontSize: 12, color: _muted, height: 1.45),
                  ),
                ],
              )),
              const SizedBox(height: 10),
              _panel(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _heading('అంశం ఎంచుకోండి'),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: _topic ?? '__all__',
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'అంశం', isDense: true,
                      border: OutlineInputBorder(),
                    ),
                    items: [
                      const DropdownMenuItem(value: '__all__',
                          child: Text('అన్ని అంశాలు')),
                      ...topics.map((t) => DropdownMenuItem(
                          value: t, child: Text(t,
                          overflow: TextOverflow.ellipsis))),
                    ],
                    onChanged: (value) => setState(() {
                      _topic = value == '__all__' ? null : value;
                      _visibleLimit = 10;
                    }),
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    decoration: const InputDecoration(
                      isDense: true, border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.search),
                      hintText: 'ఫలితం, గ్రహం లేదా Rule ID వెతకండి',
                    ),
                    onChanged: (value) => setState(() {
                      _search = value.trim().toLowerCase();
                      _visibleLimit = 10;
                    }),
                  ),
                ],
              )),
              const SizedBox(height: 10),
              _panel(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _heading('జన్మ జాతకంలో గుర్తించిన గ్రహ సూచనలు'),
                  const SizedBox(height: 5),
                  const Text('ఇవి కాల ఫలితాలు కావు. పరిశీలన కోసం గుర్తించిన '
                      'గ్రహ అమరికలు మాత్రమే. ఫలితం టచ్ చేసి పూర్తి నియమాన్ని చూడండి.',
                    style: TextStyle(fontSize: 12, color: _muted, height: 1.5)),
                  const SizedBox(height: 9),
                  if (candidates.isEmpty)
                    _emptyMessage('ఎంచుకున్న అంశంలో గుర్తించిన ప్రారంభ గ్రహ అమరికలు '
                        'లేవు. మొత్తం నియమాలు క్రింద గ్రంథాలయంలో ఉన్నాయి.'),
                  for (final match in candidates.take(15))
                    _ruleRow(match.rule, candidate: true,
                        placement: match.placement),
                  if (candidates.length > 15)
                    Text('మిగతా ${candidates.length - 15} సూచనలకు '
                        'అంశం / శోధన ఫిల్టర్ ఉపయోగించండి.',
                        style: const TextStyle(fontSize: 12, color: _muted)),
                ],
              )),
              const SizedBox(height: 10),
              _panel(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _heading('గతం • వర్తమానం • భవిష్యత్తు'),
                  const SizedBox(height: 10),
                  SizedBox(width: double.infinity, child: SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 0, label: Text('గతం')),
                      ButtonSegment(value: 1, label: Text('వర్తమానం')),
                      ButtonSegment(value: 2, label: Text('భవిష్యత్తు')),
                    ],
                    selected: {_period},
                    showSelectedIcon: false,
                    onSelectionChanged: (v) => setState(() {
                      _period = v.first;
                      _showTimeDetails = false;
                      _showTimeSource = false;
                    }),
                  )),
                  const SizedBox(height: 11),
                  Text(_periodHeading(age),
                      style: const TextStyle(fontWeight: FontWeight.w700,
                          height: 1.4)),
                  const SizedBox(height: 4),
                  Text(_periodDescription(age),
                      style: const TextStyle(fontSize: 12.5, color: _muted,
                          height: 1.5)),
                  const SizedBox(height: 12),
                  _emptyMessage('${_periodNames[_period]} కాలానికి '
                      'ధృవీకరించిన సంఘటన ఫలితాలు ప్రస్తుతం అందుబాటులో లేవు. '
                      'జన్మ గ్రహస్థితి సూచనలను ఈ కాలానికి అన్వయించలేదు. '
                      'నిజమైన గోచార, వయస్సు నియమాల పరిశీలన అవసరం.'),
                  const SizedBox(height: 8),
                  _toggleLine('వయస్సు / గురు–శని చక్రాల అధ్యయనం',
                      _showTimeDetails, () => setState(
                          () => _showTimeDetails = !_showTimeDetails)),
                  if (_showTimeDetails) ...[
                    const SizedBox(height: 9),
                    Text(BnnMasterAnalysis.roundInfo(_referenceAge(age)),
                        style: const TextStyle(fontSize: 12.5, color: _muted)),
                    const SizedBox(height: 6),
                    for (final band in _studyBands(age))
                      Padding(padding: const EdgeInsets.only(bottom: 5),
                        child: Text('గురు ${band.round}వ చక్రం • '
                            '${band.fromAge}–${band.toAge} వయస్సు • '
                            '${band.sourceTheme}',
                            style: const TextStyle(fontSize: 12.5,
                                height: 1.45))),
                    const Text('మూలం: BNN-BOOK-R-A03, PDF పేజీ 2. '
                        'OCR ధృవీకరణ పెండింగ్. ఇవి సంఘటనల తేదీలు కాదు.',
                        style: TextStyle(fontSize: 12, color: _muted)),
                  ],
                  const SizedBox(height: 7),
                  _toggleLine('కాలానికి సంబంధించిన మూల నియమాలు '
                      '(${timeRules.length})', _showTimeSource,
                      () => setState(() => _showTimeSource = !_showTimeSource)),
                  if (_showTimeSource) ...[
                    const SizedBox(height: 9),
                    const Text('క్రింది నియమాలు ఈ కాలంలో వర్తించాయని '
                        'నిర్ధారించలేదు. ఇవి గ్రంథ పరిశీలన కోసం మాత్రమే.',
                        style: TextStyle(fontSize: 12, color: _muted)),
                    const SizedBox(height: 9),
                    for (final r in timeRules.take(8))
                      _ruleRow(r, candidate: false),
                    if (timeRules.length > 8)
                      const Text('మిగతా కాల నియమాలు క్రింది గ్రంథాలయంలో '
                          'ID / పదం ద్వారా వెతకండి.',
                          style: TextStyle(fontSize: 12, color: _muted)),
                  ],
                ],
              )),
              const SizedBox(height: 10),
              _panel(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _toggleLine('BNN మూల IF–THEN నియమ గ్రంథాలయం '
                      '(${selectedRules.length})', _showLibrary,
                      () => setState(() => _showLibrary = !_showLibrary),
                      strong: true),
                  const SizedBox(height: 6),
                  const Text('343 OCR పరిశీలన • 82 గ్రహ ధృవీకరణ • 37 REVIEW. '
                      'అన్ని 462 నియమాలు ఇక్కడ భద్రంగా ఉన్నాయి. '
                      'ఇవి స్వయంచాలకంగా ఫలితాలు కావు.',
                      style: TextStyle(fontSize: 12, color: _muted,
                          height: 1.45)),
                  if (_showLibrary) ...[
                    const SizedBox(height: 12),
                    for (final rule in selectedRules.take(_visibleLimit))
                      _ruleRow(rule, candidate: false),
                    if (selectedRules.isEmpty)
                      _emptyMessage('శోధనకు సరిపోయిన మూల నియమాలు లేవు.'),
                    if (selectedRules.length > _visibleLimit)
                      Center(child: TextButton.icon(
                        onPressed: () => setState(
                            () => _visibleLimit += 20),
                        icon: const Icon(Icons.add),
                        label: const Text('మరో 20 నియమాలు చూపండి'),
                      )),
                  ],
                ],
              )),
            ],
          );
        },
      );

  bool _matches(BnnMasterRule rule) {
    if (_topic != null && rule.topic != _topic) return false;
    if (_search.isEmpty) return true;
    return '${rule.id} ${rule.topic} ${rule.condition} ${rule.result} '
            '${rule.inspection} ${rule.source}'
        .toLowerCase().contains(_search);
  }

  Widget _panel({required Widget child}) => Card(
        margin: EdgeInsets.zero,
        elevation: 1,
        color: Colors.white,
        surfaceTintColor: Colors.transparent,
        child: Padding(padding: const EdgeInsets.all(14), child: child),
      );

  Widget _heading(String value) => Text(value,
      style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800));

  Widget _countPill(String text, Color color) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: color,
          borderRadius: BorderRadius.circular(18)),
      child: Text(text, style: const TextStyle(
          fontWeight: FontWeight.w600, fontSize: 11.5)));

  Widget _emptyMessage(String text) => Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFFFF8E8),
          borderRadius: BorderRadius.circular(10)),
      child: Text(text, style: const TextStyle(
          fontSize: 12.5, height: 1.5, color: Color(0xFF735115))));

  Widget _toggleLine(String label, bool expanded, VoidCallback onTap,
      {bool strong = false}) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(children: [
            Expanded(child: Text(label,
              style: TextStyle(fontSize: strong ? 16 : 13,
                  fontWeight: FontWeight.w700, height: 1.4))),
            Icon(expanded ? Icons.expand_less : Icons.expand_more,
                color: _burgundy),
          ]),
        ),
      );

  Widget _ruleRow(BnnMasterRule rule, {
    required bool candidate,
    String? placement,
  }) => Padding(
        padding: const EdgeInsets.only(bottom: 7),
        child: Material(
          color: _bg,
          borderRadius: BorderRadius.circular(10),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => _showRule(rule,
                candidate: candidate, placement: placement),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 11),
              child: Row(children: [
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (candidate)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 5),
                        child: Text('మూల గ్రంథంలోని ఫలిత వాక్యం — ధృవీకరించలేదు',
                          style: TextStyle(color: Color(0xFF916212),
                              fontSize: 11.5, fontWeight: FontWeight.w600)),
                      ),
                    Text(candidate ? rule.result : rule.condition,
                        style: const TextStyle(fontSize: 14.5,
                            fontWeight: FontWeight.w700, height: 1.4)),
                    const SizedBox(height: 4),
                    Text(candidate
                        ? '${rule.topic} • గ్రహ అమరిక సూచన మాత్రమే'
                        : '${rule.result} • ${_statusLabel(rule.status)}',
                        maxLines: candidate ? 2 : 3,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11.5,
                            color: _muted, height: 1.45)),
                  ],
                )),
                const SizedBox(width: 5),
                const Icon(Icons.chevron_right, color: _burgundy),
              ]),
            ),
          ),
        ),
      );

  String _statusLabel(String status) => switch (status) {
        'OCR_REVIEW' => 'OCR మూల పరిశీలన అవసరం',
        'FACTS_REQUIRED' => 'జాతక ధృవీకరణ అవసరం',
        'REVIEW' => 'గ్రంథ భావన పరిశీలన అవసరం',
        _ => status,
      };

  void _showRule(BnnMasterRule rule, {
    required bool candidate,
    String? placement,
  }) {
    final natal = BnnMasterAnalysis.natalPositionsForCondition(
        rule.condition, widget.chart);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.83,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 26),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('BNN — జాతక పరిశీలన రూల్',
                    style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                _emptyMessage(candidate
                    ? 'ఇది గ్రహస్థితి ప్రారంభ సూచన. క్రింది గ్రంథ వాక్యం '
                        'జాతకానికి వర్తించిందని లేదా సంఘటన జరిగిందని '
                        'నిర్ధారించలేదు.'
                    : 'ఇది మూల గ్రంథ నమోదు మాత్రమే. జాతకానికి '
                        'వర్తించిందని నిర్ధారించలేదు.'),
                const SizedBox(height: 13),
                _detail('గ్రంథంలోని ఫలిత వాక్యం', rule.result),
                _detail('IF — పరిశీలించాల్సిన నియమం', rule.condition),
                _detail('జన్మగ్రహ స్థితులు (తెలిసినవి మాత్రమే)', natal),
                if (placement != null)
                  _detail('జాతకంలో గుర్తించిన ప్రారంభ అమరిక', placement),
                _detail('పూర్తి జాతక పరిశీలన', rule.inspection),
                _detail('నియమ స్థితి', _statusLabel(rule.status)),
                _detail('మూల గ్రంథం',
                    '${rule.source} • PDF పేజీ ${rule.sourcePage} • ${rule.id}'),
                _detail('మూలంలో పేర్కొన్న పరిహారం', rule.remedy),
                if (rule.topic.contains('వైద్య'))
                  const Text('ఈ జ్యోతిష్య వాక్యం వైద్య నిర్ధారణ కాదు. '
                      'ఆరోగ్య సమస్యలకు వైద్య పరిశీలన అవసరం.',
                      style: TextStyle(fontSize: 12,
                          color: Color(0xFF916212), height: 1.45)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _detail(String title, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 13),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(
          fontWeight: FontWeight.w800, color: _burgundy)),
      const SizedBox(height: 4),
      SelectableText(value, style: const TextStyle(height: 1.48)),
    ]),
  );

  List<BnnRoundStudyBand> _studyBands(int age) {
    if (age < 0) return const [];
    if (_period == 0) return BnnMasterAnalysis.jupiterStudyBands(0, age - 1);
    if (_period == 1) return BnnMasterAnalysis.jupiterStudyBands(age, age);
    return BnnMasterAnalysis.jupiterStudyBands(age + 1, age + 12);
  }

  int _referenceAge(int age) {
    if (_period == 0) return age > 0 ? age - 1 : 0;
    if (_period == 2) return age + 1;
    return age;
  }

  String _periodHeading(int age) {
    if (age < 0) return 'జనన తేదీ భవిష్యత్తులో ఉంది';
    if (_period == 0) return age == 0
        ? 'గతం: జన్మించిన మొదటి సంవత్సరంలో ఉన్నారు'
        : 'గతం: 0–${age - 1} పూర్తి సంవత్సరాల వయస్సు';
    if (_period == 1) return 'వర్తమానం: $age సంవత్సరాల వయస్సు';
    return 'భవిష్యత్తు: ${age + 1}–${age + 12} సంవత్సరాల వయస్సు';
  }

  String _periodDescription(int age) {
    if (age < 0) return 'జనన తేదీని సరిచూడండి.';
    if (_period == 0) return 'గడిచిన వయస్సు పరిధి మాత్రమే; '
        'జరిగిన సంఘటనలు స్వయంగా ధృవీకరించబడవు.';
    if (_period == 1) return 'ప్రస్తుత జన్మ సంవత్సరం: '
        '${BnnMasterAnalysis.ageYear(widget.birthData, age)}. '
        'వాస్తవ గోచారంతో పరిశీలన అవసరం.';
    return 'భవిష్యత్తు అధ్యయన సంవత్సరం పరిధి: '
        '${BnnMasterAnalysis.ageYear(widget.birthData, age + 1)}–'
        '${BnnMasterAnalysis.ageYear(widget.birthData, age + 12)}. '
        'ఇది సంఘటన జరిగే కాలనిర్ధారణ కాదు.';
  }
}
