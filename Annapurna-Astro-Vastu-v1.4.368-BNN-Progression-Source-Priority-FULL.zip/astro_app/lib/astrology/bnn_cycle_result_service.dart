import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';

/// Keeps traditional source rules separate from karakatwa-based topic hints.
/// A cycle/sign contact alone is not an event prediction.
class BnnCycleReading {
  final String id;
  final String label;
  final String result;
  final String ifText;
  final String source;
  final String page;
  final bool isSourceRule;
  final String tone;
  const BnnCycleReading({required this.id, required this.label,
    required this.result, required this.ifText, required this.source,
    required this.page, required this.isSourceRule, required this.tone});
}

class BnnCycleResultCatalog {
  final Map<String,Map<String,dynamic>> contacts;
  final List<Map<String,dynamic>> sourceRules;
  const BnnCycleResultCatalog({required this.contacts,required this.sourceRules});
}

class BnnCycleResultService {
  const BnnCycleResultService._();

  static Future<BnnCycleResultCatalog> load() async {
    final txt=await rootBundle.loadString(
      'assets/bnn/bnn_cycle_contact_interpretations_v357.json');
    final json=jsonDecode(txt) as Map<String,dynamic>;
    if(json['schema']!='ANNAPURNA-BNN-CYCLE-CONTACT-INTERPRETATIONS-1.0') {
      throw const FormatException('Unsupported BNN cycle result schema');
    }
    final items=(json['contacts'] as List).cast<Map<String,dynamic>>();
    final byName={for (final c in items) c['planet'] as String: c};
    if(items.length!=9 || byName.length!=9) {
      throw const FormatException('Cycle karakatwa list must contain 9 planets');
    }
    return BnnCycleResultCatalog(contacts:Map.unmodifiable(byName),
      sourceRules:List.unmodifiable(
        (json['source_rules'] as List).cast<Map<String,dynamic>>()));
  }

  /// A single factual evidence summary per age-year, rather than reprinting
  /// the same generic round-wide topic for every contacted planet. The
  /// progression is approximate and cannot prove a personal event.
  /// An independently sourced Jupiter event rule is used only when its
  /// explicit year/cycle/planet/sign guards are all satisfied.
  static List<BnnCycleReading> forJupiter({required int cycle,
    required int ageStart, required List<PlanetPosition> natalContacts,
    required BnnCycleResultCatalog catalog, String? roundTopic,
    int? relativeSignFromNatalJupiter, int? progressedSignIndex}) {
    final contacts=natalContacts.where((p)=>catalog.contacts.containsKey(p.name))
      .toList()..sort((a,b)=>a.longitude.compareTo(b.longitude));
    if (contacts.isEmpty) return const <BnnCycleReading>[];
    final verified=<BnnCycleReading>[];
    for (final p in contacts) {
      for (final rule in catalog.sourceRules) {
        if (rule['moving_planet']!='Jupiter' ||
            rule['natal_planet']!=p.name || rule['cycle']!=cycle ||
            rule['age_start']!=ageStart) continue;
        if (rule['natal_sign'] is int &&
            rule['natal_sign']!=p.signIndex) continue;
        if (rule['relative_sign'] is int &&
            rule['relative_sign']!=relativeSignFromNatalJupiter) continue;
        if (rule['progressed_sign'] is int &&
            rule['progressed_sign']!=progressedSignIndex) continue;
        verified.add(BnnCycleReading(
          id:rule['id'] as String,
          label:'${catalog.contacts[p.name]!['label_te']} — మూల నియమం',
          result:rule['then_te'] as String,ifText:rule['if_te'] as String,
          source:rule['source'] as String,page:rule['page'] as String,
          isSourceRule:true,tone:rule['tone'] as String));
      }
    }
    if (verified.isNotEmpty) return List.unmodifiable(verified);
    final labels=<String>[
      for (final p in contacts) catalog.contacts[p.name]!['label_te'] as String,
    ];
    final topics=<String>[
      for (final p in contacts) '${catalog.contacts[p.name]!['label_te']}: '
        '${catalog.contacts[p.name]!['topics_te']}',
    ];
    final signContext=progressedSignIndex==null ? ''
      : ' రాశి సూచిక ${progressedSignIndex+1};';
    final relativeContext=relativeSignFromNatalJupiter==null ? ''
      : ' గురువు జన్మరాశి నుంచి ${relativeSignFromNatalJupiter}వ రాశి;';
    return List.unmodifiable([BnnCycleReading(
      id:'BNN-JUP-C${cycle.toString().padLeft(2,'0')}'
        '-AGE${ageStart.toString().padLeft(3,'0')}-CONTACTS',
      label:'${labels.join(' + ')} — ఈ సంవత్సరపు గ్రహస్పర్శ',
      result:'ఈ వయస్సు రాశిలో జన్మ ${labels.join(', ')} '
        '${contacts.length==1 ? 'గ్రహం ఉంది' : 'గ్రహాలు ఉన్నాయి'}. '
        'పరిశీలించాల్సిన ప్రత్యేక కారకత్వాలు: ${topics.join('; ')}. '
        'ఈ రాశి-స్పర్శకు వ్యక్తిగత సంఘటనను నిర్ధారించే '
        'ప్రత్యేక మూల IF–THEN నియమం ప్రస్తుతం లేదు.',
      ifText:'గురు యొక్క సుమారు సంవత్సరానికి ఒక రాశి ప్రోగ్రెషన్‌లో '
        '${cycle}వ రౌండ్ వయస్సు $ageStart–${ageStart+1} వద్ద '
        'జన్మ ${labels.join(', ')} ఉన్న రాశి చేరితే;$signContext$relativeContext',
      source:'BNN 12-ఏళ్ల సరళ రాశి ప్రోగ్రెషన్ — గ్రహస్థాన గణన; '
        'గ్రహకారకత్వ అంశాల సంకలనం మాత్రమే, R. G. Rao ప్రత్యక్ష సంఘటన సూత్రం కాదు',
      page:'ఈ సంవత్సరానికి ధృవీకరించిన ప్రత్యేక సంఘటన-ఫలిత పేజీ లేదు',
      isSourceRule:false,tone:'neutral'),
    ]);
  }

  static List<BnnCycleReading> forSaturn({required int cycle,
    required double ageStart, required List<PlanetPosition> natalContacts,
    required BnnCycleResultCatalog catalog, String? roundTopic}) {
    final results=<BnnCycleReading>[];
    for(final p in natalContacts) {
      final c=catalog.contacts[p.name];
      if(c==null) continue;
      for(final rule in catalog.sourceRules) {
        if(rule['moving_planet']=='Saturn' && rule['natal_planet']==p.name &&
           rule['cycle']==cycle) {
          results.add(BnnCycleReading(id:rule['id'] as String,
            label:'${c['label_te']} — మూల నియమం',
            result:rule['then_te'] as String,
            ifText:rule['if_te'] as String,
            source:rule['source'] as String,page:rule['page'] as String,
            isSourceRule:true,tone:rule['tone'] as String));
        }
      }
      results.add(BnnCycleReading(
        id:'BNN-SAT-C${cycle.toString().padLeft(2,'0')}'
          '-AGE${ageStart.toStringAsFixed(1)}-${p.name.toUpperCase()}',
        label:'${c['label_te']} — కారకత్వ సూచన',
        result:'శని యొక్క వృత్తి/బాధ్యతల సూచనకు '
          '${c['topics_te']} అంశాల అనుసంధానం పరిశీలించవచ్చు.'
          '${roundTopic==null ? '' : ' సైకిల్ అంశం: $roundTopic.'}',
        ifText:'శని సరళ ప్రోగ్రెషన్ జన్మ ${c['label_te']} ఉన్న రాశిని తాకితే',
        source:'R. G. Rao గ్రహకారకత్వాలు + శని రౌండ్ సందర్భం — '
          'వివరణాత్మక అన్వయం, ప్రత్యేక సంఘటన సూత్రం కాదు',
        page:'కారకత్వ ఆధారిత వ్యాఖ్యానం; నిర్దిష్ట మూల పేజీ లేదు',
        isSourceRule:false,tone:'neutral'));
    }
    return List.unmodifiable(results);
  }
}
