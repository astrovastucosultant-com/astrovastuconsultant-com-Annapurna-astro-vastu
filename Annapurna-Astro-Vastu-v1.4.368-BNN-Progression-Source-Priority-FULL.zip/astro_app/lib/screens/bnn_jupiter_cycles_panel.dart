import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_house_relation_service.dart';
import '../astrology/bnn_jupiter_cycle_service.dart';
import '../astrology/bnn_cycle_result_service.dart';
import 'bnn_cycle_result_card.dart';
import '../astrology/bnn_rashi_rule_service.dart';

/// BNN only: separate 12-year rounds; source-backed topics, no invented events.
class BnnJupiterCyclesPanel extends StatefulWidget {
  final AstroChartResult chart;
  const BnnJupiterCyclesPanel({super.key,required this.chart});
  @override
  State<BnnJupiterCyclesPanel> createState()=>_BnnJupiterCyclesPanelState();
}

class _BnnJupiterCyclesPanelState extends State<BnnJupiterCyclesPanel> {
  late final Future<(List<BnnJupiterCycleTheme>,BnnCycleResultCatalog)> _data=_load();
  Future<(List<BnnJupiterCycleTheme>,BnnCycleResultCatalog)> _load() async =>
    (await BnnJupiterCycleService.loadThemes(),await BnnCycleResultService.load());

  @override
  Widget build(BuildContext context) => FutureBuilder<(List<BnnJupiterCycleTheme>,BnnCycleResultCatalog)>(
    future:_data,
    builder:(context,snap) {
      if (snap.hasError) return Card(child:Padding(padding:const EdgeInsets.all(12),
        child:Text('గురు సైకిల్ మూల డేటా చదవడంలో లోపం: ${snap.error}')));
      if (!snap.hasData) return const Center(child:CircularProgressIndicator());
      final cycles=BnnJupiterCycleService.calculate(chart:widget.chart,
        themes:snap.data!.$1);
      return Card(
        key:const ValueKey('bnn-jupiter-cycles-panel'),
        color:const Color(0xFFEDF3FA),
        margin:const EdgeInsets.symmetric(vertical:8),
        child:ExpansionTile(
          initiallyExpanded:false,
          title:const Text('BNN — గురువు 12 ఏళ్ల సైకిల్స్',
            style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),
          subtitle:const Text('1వ నుంచి 12వ సైకిల్ • వయస్సు • గురువు రాశి • గ్రహస్పర్శ'),
          childrenPadding:const EdgeInsets.fromLTRB(10,0,10,12),
          children:[
            const Text('మూల BNNలో గురువు సుమారు ఏడాదికి ఒక రాశి చొప్పున '
              'ముందుకు వెళ్తాడనే సరళ ప్రోగ్రెషన్ ఉంది. 12 ఏళ్ల తరువాత '
              'మళ్లీ అదే రాశికి చేరుతుంది. వాస్తవ గోచారానికి ఈ వయస్సులు '
              'అక్షరాలా సమానం కావు; సంఘటన సమయానికి దశ, గోచారం విడిగా పరిశీలించాలి.',
              style:TextStyle(height:1.5,fontSize:12.5)),
            const SizedBox(height:7),
            const Text('ప్రతి సంవత్సరానికి ఆ రాశిలో ఉన్న జన్మ గ్రహాలు, వాటి డిగ్రీలు చూపిస్తాము; '
              'మూల IF–THEN లేకుండా ఒకే గ్రహస్పర్శకు ఖచ్చిత సంఘటనల '
              'ఫలితాలను కల్పించము.',
              style:TextStyle(height:1.45,fontSize:12.5,fontWeight:FontWeight.w600)),
            const Padding(padding:EdgeInsets.symmetric(vertical:8),
              child:Text('మీరు కోరిన ప్రత్యేక రౌండ్లు: 5, 6, 8, 9. '
                '5, 6కు సంప్రదాయ అంశాల సూచన ఉంది; '
                '8, 9కు కారకత్వ వ్యాఖ్యాన సూచన మాత్రమే; నిర్ధారిత సంఘటన కాదు.',
                style:TextStyle(fontSize:13.5,fontWeight:FontWeight.bold))),
            for (final cycle in cycles.where(
              (c)=>const <int>[5,6,8,9].contains(c.theme.round)))
              _BnnJupiterCycleCard(key:ValueKey('bnn-cycle-${cycle.theme.round}'),
                cycle:cycle,catalog:snap.data!.$2),
            ExpansionTile(
              title:const Text('మిగతా గురు సైకిళ్లు (1–4, 7, 10–12)'),
              children:[
                for (final cycle in cycles.where(
                  (c)=>!const <int>[5,6,8,9].contains(c.theme.round)))
                  _BnnJupiterCycleCard(key:ValueKey('bnn-cycle-${cycle.theme.round}'),
                    cycle:cycle,catalog:snap.data!.$2),
              ],
            ),
          ],
        ),
      );
    },
  );
}

class _BnnJupiterCycleCard extends StatelessWidget {
  final BnnJupiterCycle cycle;
  final BnnCycleResultCatalog catalog;
  const _BnnJupiterCycleCard({super.key,required this.cycle,required this.catalog});

  @override
  Widget build(BuildContext context) {
    final theme=cycle.theme;
    final contacts=cycle.years.where((y)=>y.natalSignContacts.isNotEmpty).length;
    return Card(
      margin:const EdgeInsets.symmetric(vertical:5),
      color:Colors.white,
      child:ExpansionTile(
        key:ValueKey('bnn-cycle-round-${theme.round}'),
        title:Text('${theme.round}వ సైకిల్ • '
          '${theme.ageStart}–${theme.ageEndExclusive} సంవత్సరాలు',
          style:const TextStyle(fontSize:15,fontWeight:FontWeight.bold)),
        subtitle:Text(theme.traditionalFocus == null
          ? '12 రాశుల స్థానగణన • $contacts గ్రహస్పర్శ సంవత్సరాలు'
          : 'పరిశీలన పరిధి: ${theme.traditionalFocus}'),
        childrenPadding:const EdgeInsets.fromLTRB(10,0,10,10),
        children:[
          if (theme.traditionalFocus != null)
            const Padding(padding:EdgeInsets.only(bottom:9),
              child:Text('ఇది ఈ రౌండ్‌కు సంప్రదాయంగా చెప్పిన అంశాల సూచిక మాత్రమే; '
                'వ్యక్తిగత సంఘటన జరిగిందనే తీర్పు కాదు.',
                style:TextStyle(fontSize:12.5,color:Color(0xFF536675)))),
          if (theme.traditionalFocus == null)
            const Padding(padding:EdgeInsets.only(bottom:9),
              child:Text('72 ఏళ్ల తరువాత ప్రతి రౌండ్‌కు ప్రత్యేక ఫలితాల '
                'మూలాధారం నిర్ధారించలేదు. గ్రహస్పర్శ ఆధారంగా కారకత్వ సూచనలు మాత్రమే; సంఘటన తీర్పు కాదు.',
                style:TextStyle(fontSize:12.5,color:Color(0xFF536675)))),
          for (final year in cycle.years)
            _JupiterCycleYearRow(year:year,catalog:catalog),
          if (theme.sourceUrl != null)
            const Padding(padding:EdgeInsets.only(top:6),
              child:Text('మూల సూచన: Progression in Bhrigu Nandi Nadi '
                '(2026, 12-year round themes). R. G. Rao గ్రంథంలోని '
                'చక్ర ఉదాహరణలతో ఇది భిన్నంగా ఉండవచ్చు.',
                style:TextStyle(fontSize:11.5,color:Color(0xFF586677)))),
        ],
      ),
    );
  }
}

class _JupiterCycleYearRow extends StatelessWidget {
  final BnnJupiterCycleYear year;
  final BnnCycleResultCatalog catalog;
  const _JupiterCycleYearRow({required this.year,required this.catalog});

  @override
  Widget build(BuildContext context) {
    final sign=BnnRashiRuleService.signs[year.progressedSignIndex];
    final contactNames=year.natalSignContacts.map((p) =>
      BnnHouseRelationService.planetLabels[p.name]??p.name).toList();
    final readings=BnnCycleResultService.forJupiter(cycle:year.cycle,
      ageStart:year.ageStart,natalContacts:year.natalSignContacts,
      catalog:catalog,progressedSignIndex:year.progressedSignIndex,
      relativeSignFromNatalJupiter:year.relativeSignFromNatalJupiter);
    final hasContacts=contactNames.isNotEmpty;
    final degreeDetails=year.natalSignContacts.map((p) =>
      '${BnnHouseRelationService.planetLabels[p.name]??p.name} '
      '${BnnRashiRuleService.dms(p.degreesInSign)}').join(' • ');
    return Container(
      margin:const EdgeInsets.only(bottom:5),
      padding:const EdgeInsets.symmetric(horizontal:9,vertical:9),
      decoration:BoxDecoration(
        color:hasContacts ? const Color(0xFFF0F3F6) : const Color(0xFFF4F5F6),
        borderRadius:BorderRadius.circular(9)),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text('వయస్సు ${year.ageStart}–${year.ageEndExclusive} • '
          '$sign (${year.relativeSignFromNatalJupiter}వ రాశి)',
          style:const TextStyle(fontWeight:FontWeight.bold,fontSize:12.5)),
        if (hasContacts) Padding(
          padding:const EdgeInsets.only(top:3),
          child:Text('జన్మ గ్రహస్పర్శ: $degreeDetails',
            style:const TextStyle(fontSize:12,color:Color(0xFF286C49)))),
        if (!hasContacts) const Text('ఈ రాశిలో జన్మగ్రహం లేదు — ఈ సంవత్సరానికి గ్రహస్పర్శ వర్తించలేదు',
          style:TextStyle(fontSize:11.5,color:Color(0xFF6E7882))),
        for(final r in readings)
          BnnCycleResultCard(
            reading:r,
            inspection:'గురువు ${year.cycle}వ సైకిల్ • '
              'వయస్సు ${year.ageStart}–${year.ageEndExclusive} • '
              'రాశి $sign (${year.relativeSignFromNatalJupiter}వ రాశి) • '
              'జన్మ గ్రహాల డిగ్రీలు: $degreeDetails • '
              'ఇది రాశి-స్థాయి స్పర్శ మాత్రమే; డిగ్రీలకు ఖచ్చిత '
              'సంఘటన తేదీ/సంభావ్యత కేటాయించలేదు.'),
        if (hasContacts) Padding(padding:const EdgeInsets.only(top:5),
          child:Text('గణన ID: ${year.calculationId} • కాలం సరళ ప్రోగ్రెషన్',
            style:const TextStyle(fontSize:10,color:Color(0xFF536675)))),
      ]),
    );
  }
}
