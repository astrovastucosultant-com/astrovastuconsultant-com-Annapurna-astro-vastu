# Annapurna Astro Vastu — BNN v1.4.368 source/evidence audit

## Changes from v1.4.367

1. Jupiter 12-year progressions: drop the generic round-topic sentence duplicated in every age-year contact card. The round-wide topic is shown once in the round heading, **not** as a personal event prediction.
2. Per age-year, give a single **neutral** natal-contact evidence reading listing all contacted grahas and their distinct source-catalog karakatwa fields. Display their degrees in a deterministic ascending sign-degree order; retain exact cycle, age, sign and relative house in the IF and inspection. Do not infer precise timing, probability or personal outcome from a sign contact.
3. For future independently sourced Jupiter rules, require *moving_planet=Jupiter*, natal planet, specific cycle and specific age; validate any provided natal-sign/relative-sign/progressed-sign conditions. Current contact JSON contains only a Saturn source rule, so **no new sourced Jupiter event predictions were created**.
4. Three/four-planet source case presentation is visually neutral and explicitly distinguished from favorable predictions. Source priority: named 4-planet example before named 3-planet subset example before the pre-existing 35 interpretive two-planet pairs. Matching source pattern is NOT verification of the full historical chart; missing source sign guards explicitly lower evidential completeness.
5. Preserve original Green/Red **pair-karakatwa interpretation** cards; do not fabricate standalone multi-planet unfavorable outcomes or remedies. Preserve source URLs, record IDs, and original example catalog as supplied in v367.
6. Version bumped to 1.4.368+368; original v367 files retained, 0 removed.

## Explicit limitations

- Repeated zodiacal geometry after 12 years is intrinsic to the 1-sign/year model; a different specific event **cannot** be produced for each repetition from geometry alone.
- A historical BNN chart/case is not a general universal IF–THEN rule; source case comparison would require full chart conditions.
- Full BNN user-supplied three/four-planet classical rulebook still needs separately authenticated transcription; the existing mini-catalog of seven examples is not exhaustive.
- Red/Green from 35 pairs are alternatives to examine; not assessed outcome certainty.
- No exact astrology-event predictions or independent medical facts are generated here.
- Flutter SDK is unavailable in local workspace. GitHub Actions `build-bnn-v368.yml` contains the Flutter test/build pipeline; release APK is not claimed before successful GitHub build.

## Tests

Added `test/bnn_progression_source_priority_v368_test.dart` covering:
- Yearly progressed sign and degree-sorted natal contacts.
- Unique per-age evidence reading instead of repeated round-topic prose.
- No fictional Jupiter source rule from Saturn-only catalog.
- Guarded independent Jupiter source event rules.
- Four-planet priority and partial-three-planet-source match labeling.

The workflow also executes the v355, v357, v358, v359, v363, v364 and v367 regression test suites.
