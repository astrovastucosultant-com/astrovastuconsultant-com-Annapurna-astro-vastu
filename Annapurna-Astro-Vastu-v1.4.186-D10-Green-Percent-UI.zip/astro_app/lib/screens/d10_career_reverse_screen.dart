import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/d10_career_reverse_service.dart';
import '../astrology/d10_vrutti_match_engine.dart';
import '../astrology/d10_legacy_rule_link_service.dart';
import '../models/birth_data.dart';
import 'd10_percent_visual.dart';

/// Two-way D10: observed occupation -> source predicates, and observed dated
/// career events -> historical MD/AD/transit and *candidate* BTR evidence.
class D10CareerReverseScreen extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  const D10CareerReverseScreen({super.key, required this.chart,
    required this.birthData});

  @override
  State<D10CareerReverseScreen> createState() => _D10CareerReverseScreenState();
}

class _D10CareerReverseScreenState extends State<D10CareerReverseScreen> {
  final _occupation = TextEditingController();
  final _note = TextEditingController();
  late final List<D10VruttiMatch> _evaluated =
      D10VruttiMatchEngine.evaluate(widget.chart);
  List<D10CareerEvent> _events = <D10CareerEvent>[];
  D10CareerSearchHit? _selected;
  DateTime _eventDate = DateTime.now();
  String _eventType = 'వృత్తి ప్రారంభం';
  bool _saving = false;
  bool _comparing = false;
  int _rangeMinutes = 3;
  List<D10CareerBtrCandidate>? _candidates;
  String? _error;

  static const _eventTypes = <String>[
    'వృత్తి ప్రారంభం', 'ఉద్యోగ మార్పు', 'వ్యాపార ప్రారంభం',
    'పదోన్నతి', 'వృత్తి మార్పు', 'వృత్తి విరమణ', 'ఇతర సంఘటన',
  ];

  @override
  void initState() {
    super.initState();
    _loadEvents();
  }

  @override
  void dispose() {
    _occupation.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _loadEvents() async {
    try {
      final found = await D10CareerEventStore.load(widget.birthData);
      if (mounted) setState(() => _events = found);
    } catch (e) {
      if (mounted) setState(() => _error = 'Career Timeline చదవలేకపోయాము: $e');
    }
  }

  String _dateText(DateTime value) =>
      '${value.day.toString().padLeft(2, '0')}/'
      '${value.month.toString().padLeft(2, '0')}/${value.year}';

  String _timeText(DateTime value) =>
      '${value.hour.toString().padLeft(2, '0')}:'
      '${value.minute.toString().padLeft(2, '0')}:'
      '${value.second.toString().padLeft(2, '0')}';

  Future<void> _pickDate() async {
    final minDate = DateTime(widget.birthData.localDateTime.year,
        widget.birthData.localDateTime.month, widget.birthData.localDateTime.day);
    final initial = _eventDate.isBefore(minDate) ? minDate :
        (_eventDate.isAfter(DateTime.now()) ? DateTime.now() : _eventDate);
    final chosen = await showDatePicker(
      context: context, initialDate: initial, firstDate: minDate,
      lastDate: DateTime.now());
    if (chosen != null && mounted) setState(() => _eventDate = chosen);
  }

  void _openMatchDetail(D10CareerSearchHit hit) {
    final linked = hit.legacy == null ? <D10VruttiMatch>[] :
        D10LegacyRuleLinkService.matchingRules(hit.legacy!, _evaluated);
    final matches = hit.match == null ? linked : <D10VruttiMatch>[
      hit.match!, ...linked.where((m) => m.rule.id != hit.match!.rule.id),
    ];
    showModalBottomSheet<void>(context: context, isScrollControlled: true,
      builder: (ctx) => SafeArea(child: FractionallySizedBox(heightFactor: .86,
        child: ListView(padding: const EdgeInsets.all(18), children: [
          Text(hit.label, style: Theme.of(ctx).textTheme.titleLarge),
          Text(hit.group),
          const SizedBox(height: 12),
          if (matches.isEmpty) const Text('పాత వృత్తి రిజిస్ట్రీలో పేరు ఉంది. '
              'ధృవీకరించిన IF–THEN లేదు; వాస్తవ వృత్తిని నమోదు చేసుకోవచ్చు '
              'కానీ దాని ఆధారంగా BTR స్కోరు ఇవ్వరు.'),
          for (final match in matches) ...[
            const Divider(),
            Text('${match.rule.id} · ${match.rule.source} పేజీ ${match.rule.page}',
              style: const TextStyle(fontWeight: FontWeight.bold)),
            SelectableText('IF ${match.rule.condition}\nTHEN ${match.rule.profession}'),
            Text(match.confirmed
                ? 'జాతక ఆధారాల సరిపోలిక ${D10PercentVisual.percentLabel(match.confirmed, match.percent)}'
                : 'D1→D10 Confirm లేదు • శాతం ఇవ్వలేదు',
                style: TextStyle(fontWeight: FontWeight.w800,
                  color: D10PercentVisual.foreground(match.confirmed))),
            for (final s in match.passed)
              ListTile(dense: true, leading: const Icon(Icons.check_circle_outline,
                  color: Colors.green), title: Text(s)),
            for (final s in match.failed)
              ListTile(dense: true, leading: const Icon(Icons.cancel_outlined,
                  color: Colors.redAccent), title: Text(s)),
            for (final s in match.pending)
              ListTile(dense: true, leading: const Icon(Icons.info_outline,
                  color: Colors.orange), title: Text(s)),
          ],
          const Text('వాస్తవంగా ఈ వృత్తి చేస్తున్నారని నమోదు చేయడం వల్ల '
              'జాతక Rule Match స్వయంగా TRUE కాదు.'),
        ]))));
  }

  Future<void> _saveEvent() async {
    final label = _occupation.text.trim();
    if (_saving || label.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ముందుగా చేస్తున్న వృత్తిని నమోదు చేయండి.')));
      return;
    }
    final birthDay = DateTime(widget.birthData.localDateTime.year,
        widget.birthData.localDateTime.month, widget.birthData.localDateTime.day);
    if (_eventDate.isBefore(birthDay) || _eventDate.isAfter(DateTime.now())) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('వాస్తవ సంఘటన తేదీ సరిచూడండి.')));
      return;
    }
    if (_events.any((e) =>
        D10CareerReverseLookup.normalize(e.occupation) ==
            D10CareerReverseLookup.normalize(label) &&
        e.type == _eventType &&
        e.date.year == _eventDate.year &&
        e.date.month == _eventDate.month &&
        e.date.day == _eventDate.day)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('ఈ వృత్తి, సంఘటన రకం, తేదీ ఇప్పటికే Timelineలో ఉన్నాయి.')));
      return;
    }
    setState(() => _saving = true);
    final event = D10CareerEvent(
      id: '${DateTime.now().microsecondsSinceEpoch}',
      occupation: label,
      ruleId: _selected != null && _selected!.label == label ? _selected!.id : '',
      date: _eventDate, type: _eventType, notes: _note.text.trim());
    final updated = <D10CareerEvent>[..._events, event]
      ..sort((a, b) => a.date.compareTo(b.date));
    try {
      await D10CareerEventStore.save(widget.birthData, updated);
      if (mounted) {
        setState(() {
          _events = updated;
          _candidates = null; // prior BTR comparison is now stale
          _saving = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Career Timelineలో సంఘటన సేవ్ అయింది.')));
      }
    } catch (e) {
      if (mounted) setState(() {
        _saving = false;
        _error = 'సేవ్ కాలేదు: $e';
      });
    }
  }

  Future<void> _deleteEvent(D10CareerEvent event) async {
    final approved = await showDialog<bool>(context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Career Event తొలగించాలా?'),
        content: Text('${event.occupation} · ${_dateText(event.date)}'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
            child: const Text('రద్దు')),
          TextButton(onPressed: () => Navigator.pop(ctx, true),
            child: const Text('తొలగించు')),
        ],
      ));
    if (approved != true || !mounted) return;
    final changed = _events.where((e) => e.id != event.id).toList();
    try {
      await D10CareerEventStore.save(widget.birthData, changed);
      if (mounted) setState(() {
        _events = changed;
        _candidates = null;
      });
    } catch (e) {
      if (mounted) setState(() => _error = 'తొలగింపు సేవ్ కాలేదు: $e');
    }
  }

  Future<void> _inspectEvent(D10CareerEvent event) async {
    final future = D10CareerEvidenceService.evaluateEvent(
      chart: widget.chart, birth: widget.birthData, event: event,
      evaluated: _evaluated);
    showModalBottomSheet<void>(context: context, isScrollControlled: true,
      builder: (ctx) => SafeArea(child: FractionallySizedBox(heightFactor: .82,
        child: FutureBuilder<D10CareerEventEvidence>(future: future,
          builder: (ctx, snapshot) => ListView(
            padding: const EdgeInsets.all(18), children: [
              Text('${event.occupation} · ${_dateText(event.date)}',
                  style: Theme.of(ctx).textTheme.titleLarge),
              Text('${event.type} · వయసు ${D10VruttiActivationService.ageOn(widget.birthData.localDateTime, event.date)}'),
              if (event.notes.isNotEmpty) Text('గమనిక: ${event.notes}'),
              const Divider(),
              if (snapshot.hasError) Text('గణన అందుబాటులో లేదు: ${snapshot.error}'),
              if (!snapshot.hasData && !snapshot.hasError)
                const ListTile(leading: CircularProgressIndicator(),
                  title: Text('MD, AD, గురు–శని గోచార పరిశీలన…')),
              if (snapshot.hasData) ...[
                Text('సంఘటన ఆధారాలు ${snapshot.data!.gatesMatched}/5 · '
                    '${snapshot.data!.hasRule ? 'మూల రూల్ ఉంది' : 'మూల రూల్ లేదు'}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                for (final line in snapshot.data!.reasons)
                  Padding(padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Text('• $line')),
              ],
              const Divider(),
              const Text('ఇది చారిత్రక సంఘటనకు జ్యోతిష ఆధారాల పోలిక మాత్రమే; '
                  'జనన సమయాన్ని స్వయంగా మార్చదు.'),
            ],
          )))));
  }

  Future<void> _compareBtr() async {
    if (_comparing || _events.length < 2) return;
    setState(() {
      _comparing = true;
      _candidates = null;
      _error = null;
    });
    try {
      final result = await D10CareerBtrService.compare(
        birth: widget.birthData, events: _events,
        rangeMinutes: _rangeMinutes);
      if (mounted) setState(() => _candidates = result);
    } catch (e) {
      if (mounted) setState(() => _error = 'BTR పోలిక పూర్తి కాలేదు: $e');
    } finally {
      if (mounted) setState(() => _comparing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final results = D10CareerReverseLookup.search(_occupation.text, _evaluated,
      limit: 35);
    final List<D10CareerBtrCandidate> best = _candidates?.where(
        (c) => c.error == null).toList() ?? <D10CareerBtrCandidate>[];
    final tie = best.length > 1 &&
        best.first.fullyAlignedEvents == best[1].fullyAlignedEvents &&
        best.first.evidenceGates == best[1].evidenceGates;
    return Scaffold(
      appBar: AppBar(title: const Text('D10 — వృత్తి Reverse Search & BTR')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        const Text('చేస్తున్న వృత్తి నుంచి → మూల IF–THEN → D1/D10 కారణాలు → '
            'వాస్తవ వయసు/సంఘటన → మహాదశ, అంతర్దశ, గోచారం → BTR ఆధారాలు',
            style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 12),
        TextField(controller: _occupation,
          decoration: const InputDecoration(labelText: 'ప్రస్తుతం/గతంలో చేసిన వృత్తి',
            hintText: 'ఉదా: గ్యాస్ ఏజెన్సీ / డ్రైవర్ / టీచర్',
            prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
          onChanged: (_) => setState(() => _selected = null)),
        const SizedBox(height: 6),
        Text('517 వృత్తి నమోదుల్లో సంబంధిత ఫలితాలు: ${results.length}'
            '${results.length == 35 ? ' (మొదటి 35 మాత్రమే; మరింత స్పష్టంగా టైప్ చేయండి)' : ''}'),
        if (results.isEmpty && _occupation.text.trim().isNotEmpty)
          const ListTile(title: Text('ఖచ్చితమైన వృత్తి పేరు గుర్తించలేదు.'),
            subtitle: Text('సంఘటనను సేవ్ చేయవచ్చు; IF–THEN ఆధారం లేకుండా BTR స్కోరులో కలపరు.')),
        for (final hit in results) Card(
          color: hit.match == null ? D10PercentVisual.pendingSurface :
              D10PercentVisual.background(hit.match!.confirmed),
          child: Padding(padding: const EdgeInsets.all(8), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('${hit.label} · ${hit.id}',
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              Text('${hit.group} · ${hit.source}',
                  style: const TextStyle(fontSize: 12.5)),
              if (hit.match != null)
                Text(hit.match!.confirmed
                    ? 'జాతక నియమ ఆధారాలు ${D10PercentVisual.percentLabel(hit.match!.confirmed, hit.match!.percent)}'
                    : 'D1 → D10 Confirm లేదు (వృత్తి వాస్తవాన్ని తిరస్కరించదు)',
                    style: TextStyle(fontWeight: FontWeight.w800,
                      color: D10PercentVisual.foreground(hit.match!.confirmed))),
              Wrap(spacing: 8, alignment: WrapAlignment.spaceBetween, children: [
                TextButton.icon(
                  onPressed: () => _openMatchDetail(hit),
                  icon: const Icon(Icons.fact_check_outlined),
                  label: const Text('రూల్ / జాతక పరిశీలన')),
                TextButton(onPressed: () => setState(() {
                  _selected = hit;
                  _occupation.text = hit.label;
                }), child: const Text('ఈ వృత్తి ఎంచుకోండి')),
              ]),
            ])),
        ),
        const Divider(),
        const Text('జరిగిన వృత్తి సంఘటన నమోదు',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(value: _eventType,
          decoration: const InputDecoration(labelText: 'సంఘటన రకం',
            border: OutlineInputBorder()),
          items: _eventTypes.map((x) => DropdownMenuItem(
            value: x, child: Text(x))).toList(),
          onChanged: (v) => setState(() => _eventType = v ?? _eventType)),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: _pickDate,
          icon: const Icon(Icons.event),
          label: Text('జరిగిన తేదీ: ${_dateText(_eventDate)} · వయసు '
              '${D10VruttiActivationService.ageOn(widget.birthData.localDateTime, _eventDate)}')),
        TextField(controller: _note,
          maxLines: 2, decoration: const InputDecoration(
            labelText: 'గమనిక (ఐచ్ఛికం)', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: _saving ? null : _saveEvent,
          icon: const Icon(Icons.save_outlined),
          label: Text(_saving ? 'సేవ్ చేస్తోంది…' : 'Career Event సేవ్ చేయండి')),
        const Divider(),
        Text('Career Timeline — ${_events.length} సంఘటనలు',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        for (final event in _events) Card(child: ListTile(
          title: Text('${event.occupation} · ${event.type}'),
          subtitle: Text('${_dateText(event.date)} · వయసు '
              '${D10VruttiActivationService.ageOn(widget.birthData.localDateTime, event.date)} '
              '· ${event.ruleId.isEmpty ? 'Manual' : event.ruleId}'),
          onTap: () => _inspectEvent(event),
          trailing: IconButton(tooltip: 'ఈ సంఘటన తొలగించండి',
            icon: const Icon(Icons.delete_outline),
            onPressed: () => _deleteEvent(event)),
        )),
        if (_events.isEmpty) const Text('ఉద్యోగ ప్రారంభం, మార్పు, పదోన్నతి వంటి '
            'వాస్తవ తేదీలను పై భాగంలో నమోదు చేయండి.'),
        const Divider(),
        const Text('BTR — Career Evidence Comparison',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const Text('జనన సమయానికి చుట్టుపక్కల అభ్యర్థి సమయాలను మాత్రమే పోలుస్తుంది. '
            'సేవ్ చేసిన వాస్తవ Career Events ఆధారంగా ఐదు రకాల ఆధారాలను లెక్కిస్తుంది.'),
        const SizedBox(height: 7),
        Wrap(spacing: 7, children: [
          for (final min in const [2, 3, 5, 10])
            ChoiceChip(label: Text('±$min నిమి'), selected: _rangeMinutes == min,
              onSelected: (_) => setState(() {
                _rangeMinutes = min;
                _candidates = null;
              })),
        ]),
        FilledButton.icon(
          onPressed: _events.length < 2 || _comparing ? null : _compareBtr,
          icon: _comparing ? const SizedBox(height: 18, width: 18,
              child: CircularProgressIndicator(strokeWidth: 2)) :
              const Icon(Icons.manage_search),
          label: Text(_comparing ? 'జనన సమయాలను పరిశీలిస్తోంది…' :
              'BTR అభ్యర్థులను పోల్చండి (${_events.length} సంఘటనలు)'),
        ),
        if (_events.length < 2)
          const Text('BTR పోలికకు కనీసం 2 నిజమైన వృత్తి సంఘటనలు నమోదు చేయండి.',
              style: TextStyle(color: Colors.deepOrange)),
        if (_error != null) Text(_error!,
          style: const TextStyle(color: Colors.red)),
        if (best.isNotEmpty) ...[
          Text('సమయ అభ్యర్థులు: ${_candidates!.length} · '
              'ఉత్తమ ఆధారాలు ${best.first.fullyAlignedEvents}/${_events.length} '
              'సంఘటనలు · ${best.first.evidenceGates} షరతు ఆధారాలు',
              style: const TextStyle(fontWeight: FontWeight.bold)),
          if (tie) const Text('⚠️ ఒకటి కంటే ఎక్కువ జనన సమయాలకు సమాన ఆధారాలు. '
              'ఈ డేటాతో ఖచ్చిత BTR నిర్ణయం లేదు.'),
          for (final c in _candidates!) ExpansionTile(
            title: Text('${_timeText(c.birthTime)} · '
                '${c.fullyAlignedEvents}/${_events.length} సంఘటనలు'),
            subtitle: Text(c.error ?? 'ఐదు-షరతుల ఆధారాలు: ${c.evidenceGates} · '
                'మూల నియమాలతో పరిశీలించినవి: ${c.evaluatedEvents}'),
            children: [
              for (final e in c.eventEvidence) ListTile(
                title: Text('${e.event.occupation} · ${e.gatesMatched}/5'),
                subtitle: Text('${e.event.type} · ${_dateText(e.event.date)} '
                  '· ${e.matchedRuleId ?? 'మూల లింక్ లేదు'}\n'
                  'MD ${e.mahadasha} / AD ${e.antardasha} · '
                  '${e.allAligned ? 'మొత్తం ఆధారాలు సరిపోయాయి' : 'పాక్షిక/లేని ఆధారాలు'}'),
                isThreeLine: true,
              ),
            ],
          ),
          const Text('ఈ ర్యాంకింగ్ జనన సమయ ఖచ్చితత్వానికి శాస్త్రీయ % కాదు. '
              'BTR ప్రధాన నిర్ణయం కోసం స్వతంత్ర సంఘటనలు, ఇతర పద్ధతుల ఆధారాలు '
              'అవసరం. ఈ స్క్రీన్ జనన సమయాన్ని స్వయంగా మార్చదు.'),
        ],
      ]),
    );
  }
}
