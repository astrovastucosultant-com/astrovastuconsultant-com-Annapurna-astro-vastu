import 'astro_models.dart';
import 'bnn_master_service.dart';

/// 144 navigation topics. These are NOT 144 chart predictions or extra
/// source rules. Each item exposes the person's actual natal placements.
class BnnBhavaTopic {
  final int house;
  final String name;
  final String karaka;
  const BnnBhavaTopic(this.house, this.name, this.karaka);
}

class BnnBhavaTopicService {
  static const List<List<BnnBhavaTopic>> byHouse = <List<BnnBhavaTopic>>[
    <BnnBhavaTopic>[
      BnnBhavaTopic(1, 'జీవన దిశ', 'Jupiter'),
      BnnBhavaTopic(1, 'శరీర స్వభావం', 'Sun'),
      BnnBhavaTopic(1, 'ఆత్మవిశ్వాసం', 'Sun'),
      BnnBhavaTopic(1, 'మనోస్థితి', 'Moon'),
      BnnBhavaTopic(1, 'ధైర్యం', 'Mars'),
      BnnBhavaTopic(1, 'జ్ఞానాసక్తి', 'Mercury'),
      BnnBhavaTopic(1, 'నాయకత్వం', 'Sun'),
      BnnBhavaTopic(1, 'క్రమశిక్షణ', 'Saturn'),
      BnnBhavaTopic(1, 'దైవచింతన', 'Ketu'),
      BnnBhavaTopic(1, 'సామాజిక ప్రవర్తన', 'Venus'),
      BnnBhavaTopic(1, 'స్వయంకృషి', 'Mars'),
      BnnBhavaTopic(1, 'జీవశక్తి', 'Jupiter'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(2, 'ఆదాయ మార్గాలు', 'Saturn'),
      BnnBhavaTopic(2, 'ధన నిల్వ', 'Venus'),
      BnnBhavaTopic(2, 'కుటుంబ బాధ్యత', 'Sun'),
      BnnBhavaTopic(2, 'వాక్చాతుర్యం', 'Mercury'),
      BnnBhavaTopic(2, 'ఆర్థిక ప్రణాళిక', 'Mercury'),
      BnnBhavaTopic(2, 'సంపాదన విధానం', 'Saturn'),
      BnnBhavaTopic(2, 'ధన వినియోగం', 'Venus'),
      BnnBhavaTopic(2, 'భోజన అలవాట్లు', 'Moon'),
      BnnBhavaTopic(2, 'కుటుంబ విలువలు', 'Jupiter'),
      BnnBhavaTopic(2, 'బంధువుల సహకారం', 'Moon'),
      BnnBhavaTopic(2, 'సేవింగ్స్', 'Mercury'),
      BnnBhavaTopic(2, 'వారసత్వ సంపద', 'Sun'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(3, 'సోదరులు', 'Mars'),
      BnnBhavaTopic(3, 'సోదరీమణులు', 'Venus'),
      BnnBhavaTopic(3, 'ధైర్యం', 'Mars'),
      BnnBhavaTopic(3, 'స్వల్ప ప్రయాణాలు', 'Moon'),
      BnnBhavaTopic(3, 'సందేశాలు', 'Mercury'),
      BnnBhavaTopic(3, 'రచనా శక్తి', 'Mercury'),
      BnnBhavaTopic(3, 'నూతన ప్రయత్నాలు', 'Mars'),
      BnnBhavaTopic(3, 'వ్యాపార నైపుణ్యం', 'Mercury'),
      BnnBhavaTopic(3, 'పొరుగు సంబంధాలు', 'Moon'),
      BnnBhavaTopic(3, 'సాంకేతిక నైపుణ్యం', 'Mars'),
      BnnBhavaTopic(3, 'సంకల్ప బలం', 'Sun'),
      BnnBhavaTopic(3, 'సంబంధిత సహకారం', 'Jupiter'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(4, 'గృహసుఖం', 'Moon'),
      BnnBhavaTopic(4, 'తల్లి', 'Moon'),
      BnnBhavaTopic(4, 'స్థిరాస్తి', 'Mars'),
      BnnBhavaTopic(4, 'భూమి', 'Mars'),
      BnnBhavaTopic(4, 'వాహనాలు', 'Venus'),
      BnnBhavaTopic(4, 'నివాస మార్పు', 'Moon'),
      BnnBhavaTopic(4, 'గృహ నిర్మాణం', 'Mars'),
      BnnBhavaTopic(4, 'పారంపర్య ఆస్తి', 'Sun'),
      BnnBhavaTopic(4, 'కుటుంబ ప్రశాంతత', 'Moon'),
      BnnBhavaTopic(4, 'సౌకర్యాలు', 'Venus'),
      BnnBhavaTopic(4, 'వ్యవసాయం', 'Saturn'),
      BnnBhavaTopic(4, 'విద్యా వాతావరణం', 'Mercury'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(5, 'సంతాన అంశాలు', 'Jupiter'),
      BnnBhavaTopic(5, 'విద్యాభ్యాసం', 'Mercury'),
      BnnBhavaTopic(5, 'బుద్ధి', 'Mercury'),
      BnnBhavaTopic(5, 'మంత్రోపాసన', 'Ketu'),
      BnnBhavaTopic(5, 'సృజనాత్మకత', 'Venus'),
      BnnBhavaTopic(5, 'పరీక్షలు', 'Mercury'),
      BnnBhavaTopic(5, 'ప్రేమ సంబంధాలు', 'Venus'),
      BnnBhavaTopic(5, 'సంతాన బాధ్యత', 'Saturn'),
      BnnBhavaTopic(5, 'ఆధ్యాత్మిక విద్య', 'Jupiter'),
      BnnBhavaTopic(5, 'కళలు', 'Venus'),
      BnnBhavaTopic(5, 'అభ్యాస నైపుణ్యం', 'Mercury'),
      BnnBhavaTopic(5, 'పూర్వపుణ్య భావన', 'Jupiter'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(6, 'ఆరోగ్య అంశాలు', 'Sun'),
      BnnBhavaTopic(6, 'ఋణాలు', 'Saturn'),
      BnnBhavaTopic(6, 'పోటీలు', 'Mars'),
      BnnBhavaTopic(6, 'శత్రు సంబంధాలు', 'Mars'),
      BnnBhavaTopic(6, 'ఉద్యోగ సేవ', 'Saturn'),
      BnnBhavaTopic(6, 'క్రమమైన శ్రమ', 'Saturn'),
      BnnBhavaTopic(6, 'న్యాయ వివాదాలు', 'Sun'),
      BnnBhavaTopic(6, 'శారీరక శ్రమ', 'Mars'),
      BnnBhavaTopic(6, 'జీవన అలవాట్లు', 'Moon'),
      BnnBhavaTopic(6, 'చికిత్స అంశాలు', 'Mercury'),
      BnnBhavaTopic(6, 'అడ్డంకులు', 'Rahu'),
      BnnBhavaTopic(6, 'బాధ్యతలు', 'Saturn'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(7, 'వివాహ అంశాలు', 'Venus'),
      BnnBhavaTopic(7, 'జీవిత భాగస్వామి', 'Venus'),
      BnnBhavaTopic(7, 'వైవాహిక ఆలస్యం', 'Saturn'),
      BnnBhavaTopic(7, 'భాగస్వామ్య వ్యాపారం', 'Mercury'),
      BnnBhavaTopic(7, 'ఒప్పందాలు', 'Mercury'),
      BnnBhavaTopic(7, 'పరస్పర సహకారం', 'Jupiter'),
      BnnBhavaTopic(7, 'సంబంధ సంభాషణ', 'Mercury'),
      BnnBhavaTopic(7, 'వివాహ అనుకూలత', 'Venus'),
      BnnBhavaTopic(7, 'దాంపత్య బాధ్యతలు', 'Saturn'),
      BnnBhavaTopic(7, 'సామాజిక సంబంధాలు', 'Moon'),
      BnnBhavaTopic(7, 'వ్యాపార కలయిక', 'Venus'),
      BnnBhavaTopic(7, 'సహజీవనం', 'Moon'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(8, 'పరివర్తనలు', 'Ketu'),
      BnnBhavaTopic(8, 'ఆకస్మిక మార్పులు', 'Rahu'),
      BnnBhavaTopic(8, 'దీర్ఘకాల భద్రత', 'Saturn'),
      BnnBhavaTopic(8, 'బీమా అంశాలు', 'Saturn'),
      BnnBhavaTopic(8, 'వారసత్వ వివాదాలు', 'Mars'),
      BnnBhavaTopic(8, 'రహస్య విషయాలు', 'Ketu'),
      BnnBhavaTopic(8, 'పరిశోధన', 'Mercury'),
      BnnBhavaTopic(8, 'కష్టాలను ఎదుర్కోవడం', 'Mars'),
      BnnBhavaTopic(8, 'విధి మార్పు భావన', 'Jupiter'),
      BnnBhavaTopic(8, 'దాచిన వనరులు', 'Venus'),
      BnnBhavaTopic(8, 'మానసిక భయాలు', 'Moon'),
      BnnBhavaTopic(8, 'జీవన స్థిరత్వం', 'Saturn'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(9, 'భాగ్యం', 'Jupiter'),
      BnnBhavaTopic(9, 'తండ్రి', 'Sun'),
      BnnBhavaTopic(9, 'గురువులు', 'Jupiter'),
      BnnBhavaTopic(9, 'ధర్మం', 'Jupiter'),
      BnnBhavaTopic(9, 'తీర్థయాత్ర', 'Ketu'),
      BnnBhavaTopic(9, 'ఉన్నత విద్య', 'Mercury'),
      BnnBhavaTopic(9, 'ఆధ్యాత్మిక ఆసక్తి', 'Ketu'),
      BnnBhavaTopic(9, 'శాస్త్ర అధ్యయనం', 'Jupiter'),
      BnnBhavaTopic(9, 'దీర్ఘ ప్రయాణాలు', 'Moon'),
      BnnBhavaTopic(9, 'పారంపర్య విలువలు', 'Sun'),
      BnnBhavaTopic(9, 'దాన ధర్మం', 'Jupiter'),
      BnnBhavaTopic(9, 'జీవన సిద్ధాంతం', 'Jupiter'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(10, 'ఉద్యోగం', 'Saturn'),
      BnnBhavaTopic(10, 'వృత్తి మార్గం', 'Saturn'),
      BnnBhavaTopic(10, 'వ్యాపారం', 'Mercury'),
      BnnBhavaTopic(10, 'స్వయం ఉపాధి', 'Mars'),
      BnnBhavaTopic(10, 'అధికార సంబంధాలు', 'Sun'),
      BnnBhavaTopic(10, 'పదోన్నతి అంశాలు', 'Sun'),
      BnnBhavaTopic(10, 'పని క్రమశిక్షణ', 'Saturn'),
      BnnBhavaTopic(10, 'సాంకేతిక వృత్తి', 'Mars'),
      BnnBhavaTopic(10, 'ఆర్థిక వృత్తి', 'Venus'),
      BnnBhavaTopic(10, 'పబ్లిక్ ఇమేజ్', 'Sun'),
      BnnBhavaTopic(10, 'వృత్తి మార్పు', 'Rahu'),
      BnnBhavaTopic(10, 'పని స్థిరత్వం', 'Saturn'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(11, 'లాభం', 'Jupiter'),
      BnnBhavaTopic(11, 'జీత వృద్ధి', 'Saturn'),
      BnnBhavaTopic(11, 'మిత్రులు', 'Mercury'),
      BnnBhavaTopic(11, 'పెద్ద సోదరులు', 'Mars'),
      BnnBhavaTopic(11, 'ఆశయ సాధన', 'Jupiter'),
      BnnBhavaTopic(11, 'వ్యాపార లాభం', 'Mercury'),
      BnnBhavaTopic(11, 'సామాజిక వలయం', 'Venus'),
      BnnBhavaTopic(11, 'ఆర్థిక అవకాశాలు', 'Venus'),
      BnnBhavaTopic(11, 'పరిచయాల సహాయం', 'Moon'),
      BnnBhavaTopic(11, 'పేరుప్రతిష్ఠ', 'Sun'),
      BnnBhavaTopic(11, 'సహకార ప్రయత్నాలు', 'Mercury'),
      BnnBhavaTopic(11, 'దీర్ఘకాల ఆదాయం', 'Saturn'),
    ],
    <BnnBhavaTopic>[
      BnnBhavaTopic(12, 'వ్యయాలు', 'Venus'),
      BnnBhavaTopic(12, 'విదేశ ప్రయాణం', 'Rahu'),
      BnnBhavaTopic(12, 'విదేశ నివాసం', 'Rahu'),
      BnnBhavaTopic(12, 'నిద్ర', 'Moon'),
      BnnBhavaTopic(12, 'ఏకాంతం', 'Ketu'),
      BnnBhavaTopic(12, 'ధ్యాన ఆసక్తి', 'Ketu'),
      BnnBhavaTopic(12, 'దాతృత్వం', 'Jupiter'),
      BnnBhavaTopic(12, 'ఆరోగ్య ఖర్చులు', 'Saturn'),
      BnnBhavaTopic(12, 'దీర్ఘ ప్రయాణ వ్యయాలు', 'Moon'),
      BnnBhavaTopic(12, 'దాచిన ఖర్చులు', 'Mercury'),
      BnnBhavaTopic(12, 'విరక్తి', 'Ketu'),
      BnnBhavaTopic(12, 'విడుదల భావన', 'Ketu'),
    ],
  ];

  static List<BnnBhavaTopic> forHouse(int house) =>
      (house >= 1 && house <= 12) ? byHouse[house - 1] : const [];

  static const _teluguPlanet = <String, String>{
    'Jupiter': 'గురు', 'Sun': 'రవి', 'Moon': 'చంద్రుడు',
    'Mercury': 'బుధుడు', 'Mars': 'కుజుడు', 'Venus': 'శుక్రుడు',
    'Saturn': 'శని', 'Rahu': 'రాహువు', 'Ketu': 'కేతువు',
  };
  /// Short, chart-dependent reading of an individual topic. This is an
  /// interpretive *screening* layer; it does not claim to satisfy a classical
  /// BNN IF–THEN rule or establish that a real-world event occurred.
  static const _positionThemes = <String>[
    'స్వీయ నిర్ణయాలు, వ్యక్తిగత చొరవ',
    'కుటుంబ వనరులు, ధన నిర్వహణ',
    'ప్రయత్నాలు, కమ్యూనికేషన్, ప్రయాణాలు',
    'గృహం, స్థిరాస్తి, నివాస సౌకర్యాలు',
    'విద్య, అభ్యాసం, సంతాన అంశాలు',
    'క్రమశిక్షణ, పోటీ, బాధ్యతలు',
    'సహకారం, ఒప్పందాలు, భాగస్వామ్యం',
    'మార్పులు, దీర్ఘకాల భద్రత, పరిశోధన',
    'మార్గదర్శకత్వం, అధ్యయనం, ధర్మం',
    'వృత్తి, అధికారాలు, ప్రజా సంబంధాలు',
    'లాభావకాశాలు, మిత్రులు, మద్దతు',
    'వ్యయాలు, దూరప్రాంతం, ఏకాంతం',
  ];
  static const _signModes = <String>[
    'చొరవ, కొత్త నిర్ణయాలు', 'కొనసాగింపు, నిలకడ',
    'మార్పులకు అనుకూలత, రెండు మార్గాల పరిశీలన',
  ];

  static String _specificTopicSignal(BnnBhavaTopic topic, int house) {
    // The most frequently reported money screen needs meaningful, visibly
    // different judgement from income, savings, family and expenditure.
    if (topic.house == 2) {
      switch (topic.name) {
        case 'ఆదాయ మార్గాలు':
          if (house == 10 || house == 11) {
            return 'వృత్తి లేదా లాభస్థానంతో అనుసంధానం ఉంది; ఉపాధి ద్వారా వచ్చే ఆదాయ మార్గం పరిశీలనకు ప్రాధాన్యం.';
          }
          if (house == 12) {
            return 'వ్యయాలు, దూరప్రాంత/వెనుకనుండి చేసే పని అంశాలతో ఆదాయ కారకుడి సంబంధం ఉంది; ఆదాయ నిలకడ ఇంకా నిర్ధారణ కాదు.';
          }
          return 'ఆదాయ కారకుడు $house వ భావంలోని ${_positionThemes[house - 1]}తో ముడిపడ్డాడు; వృత్తి–లాభ ఆధారాలు ఇంకా అవసరం.';
        case 'ధన నిల్వ':
          if (house == 4) {
            return 'గృహం, స్థిరాస్తి, సౌకర్యాల వినియోగంతో ధన కారకుడి సంబంధం కనిపిస్తోంది; పొదుపు ఫలితం వేరుగా నిర్ధారించాలి.';
          }
          if (house == 2 || house == 11) {
            return 'కుటుంబ ధన లేదా లాభస్థానంతో నేర సంబంధం ఉంది; ధనం నిలిచే విధానాన్ని అదనపు నియమాలతో పరిశీలించాలి.';
          }
          return 'ధన కారకుడికి $house వ భావంలోని ${_positionThemes[house - 1]}తో సంబంధం ఉంది; పొదుపు నిర్ధారణ కాదు.';
        case 'కుటుంబ బాధ్యత':
          if (house == 2) {
            return 'కుటుంబ ధనస్థానంలో రవి సంబంధం ఉంది; కుటుంబ నిర్ణయాలు, పెద్దల పాత్రకు ప్రాధాన్యం ఉండవచ్చు.';
          }
          return 'కుటుంబ బాధ్యతల్లో $house వ భావంలోని ${_positionThemes[house - 1]} సంబంధం కనిపిస్తోంది; కుటుంబ సంఘటన నిర్ధారణ కాదు.';
        case 'వాక్చాతుర్యం':
          return house == 3
              ? 'మాట, వ్యాపార చర్చలు, సమాచార మార్పిడితో బుధుడి ప్రత్యక్ష సంబంధం ఉంది.'
              : 'మాట, వ్యాపార చర్చల్లో బుధుడి $house వ భావంలోని ${_positionThemes[house - 1]} సంబంధం కనిపిస్తోంది.';
        case 'ఆర్థిక ప్రణాళిక':
          return house == 3
              ? 'ఆర్థిక లెక్కలు, పత్రాలు, సమాచార నిర్వహణలో ప్రయత్నానికి ప్రాధాన్యం ఉండే సూచన.'
              : 'ఆర్థిక లెక్కలు, పత్రాలపై $house వ భావంలోని ${_positionThemes[house - 1]}తో సంబంధం ఉంది.';
        case 'సంపాదన విధానం':
          return house == 12
              ? 'పని/శ్రమ కారకుడు 12వ స్థానంలో ఉన్నాడు; ఆదాయంతో పాటు ఖర్చులు, దూరప్రాంత పనుల సంబంధాన్ని పరిశీలించాలి.'
              : 'సంపాదన పద్ధతి $house వ భావంలోని ${_positionThemes[house - 1]}తో ముడిపడింది; ఉపాధి విధానం నిర్ధారణ కాదు.';
        case 'ధన వినియోగం':
          return house == 4
              ? 'నివాసం, వాహనం, సౌకర్యాలపై వనరులు వినియోగించే సూచనను పరిశీలించవచ్చు.'
              : 'ధన వినియోగంపై $house వ భావంలోని ${_positionThemes[house - 1]} సంబంధం కనిపిస్తోంది.';
        case 'భోజన అలవాట్లు':
          return 'ఆహార దినచర్యను చంద్రుడు ఉన్న భావం, కుటుంబ అలవాట్లతో కలిపి పరిశీలించాలి; ఆరోగ్య నిర్ధారణ కాదు.';
        case 'కుటుంబ విలువలు':
          return house == 1
              ? 'గురు ఆధార రాశిలోనే ఉండడంతో కుటుంబ విలువల్లో వ్యక్తిగత సలహా, మార్గదర్శకత్వానికి ప్రాధాన్యం ఉండవచ్చు.'
              : 'కుటుంబ విలువల్లో గురు కారకత్వ సంబంధాన్ని ప్రత్యేకంగా పరిశీలించాలి.';
        case 'బంధువుల సహకారం':
          return 'బంధువుల సహకారం $house వ భావంలోని ${_positionThemes[house - 1]}తో ముడిపడింది; సహకారం నిర్ధారణ కాదు.';
        case 'సేవింగ్స్':
          return house == 3
              ? 'పొదుపులో చిన్నచిన్న లెక్కలు, నిరంతర ప్రయత్నాల పాత్రను పరిశీలించవచ్చు.'
              : 'పొదుపు అంశంపై $house వ భావంలోని ${_positionThemes[house - 1]} సంబంధం ఉంది; ధనవృద్ధి నిర్ధారణ కాదు.';
        case 'వారసత్వ సంపద':
          return 'వారసత్వ హక్కులు $house వ భావంలోని ${_positionThemes[house - 1]}తో ముడిపడ్డాయి; ఆస్తి లభించినట్లు నిర్ధారణ కాదు.';
      }
    }
    return '';
  }

  static BnnTopicReading read(BnnBhavaTopic topic, AstroChartResult chart) {
    final planetMatches = chart.planets.where((p) => p.name == topic.karaka);
    final jupiters = chart.planets.where((p) => p.name == 'Jupiter');
    if (planetMatches.isEmpty || jupiters.isEmpty) {
      return const BnnTopicReading(
        summary: 'కారకగ్రహం లేదా గురు స్థానం లేదు — ఈ అంశానికి ఫలిత సూచన ఇవ్వలేము.',
        evidence: 'కారక గ్రహం లేదా గురు స్థానం అందుబాటులో లేదు.',
        rule: 'IF: అవసరమైన జన్మగ్రహస్థితులు అందుబాటులో ఉంటేనే అంశాన్ని పరిశీలించాలి.',
        provenance: 'జన్మగ్రహ సమాచారం లేకపోవడంతో గణన నిలిపివేయబడింది.',
      );
    }
    final planet = planetMatches.first;
    final jupiter = jupiters.first;
    final karakaHouse = BnnMasterAnalysis.houseOfPlanet(planet, chart);
    final targetPlanets = BnnMasterAnalysis.planetsInHouse(chart, topic.house);
    final relation = planet.name == 'Jupiter'
        ? 'గురు ఆధార రాశి'
        : BnnMasterAnalysis.planetaryLink(jupiter, planet);
    final karakaInTopic = karakaHouse == topic.house;
    final otherPlanetNames = targetPlanets
        .where((p) => p.name != planet.name)
        .map((p) => _teluguPlanet[p.name] ?? p.name).toList();
    final mode = planet.signIndex % 3;
    final planetName = _teluguPlanet[planet.name] ?? planet.name;
    final signName = BnnMasterAnalysis.signNames[planet.signIndex];
    final ownTopicSignal = _specificTopicSignal(topic, karakaHouse);
    final placementContext = _positionThemes[karakaHouse - 1];
    final support = karakaInTopic
        ? 'కారకగ్రహం ఈ అంశ భావంలోనే ఉంది.'
        : 'కారకగ్రహం ఈ అంశ భావంలో కాక $karakaHouse వ భావంలో ఉంది.';
    // No mere placement is promoted to a verified life event. An editorial
    // outcome is a chart-specific direction for further BNN rule matching.
    final String leading;
    if (ownTopicSignal.isNotEmpty) {
      leading = ownTopicSignal;
    } else if (karakaInTopic) {
      leading = '${topic.name} అంశంలో ప్రత్యక్ష కారకగ్రహ అనుసంధానం కనిపిస్తోంది; '
          'ఈ విషయంలో నిర్ణయాలు లేదా మార్పులు ముఖ్యమయ్యే సూచన.';
    } else if (karakaHouse == 6 || karakaHouse == 8 || karakaHouse == 12) {
      leading = '${topic.name} అంశానికి $placementContext సంబంధం ఉంది; '
          'ఆలస్యం, అడ్డంకి లేదా అదనపు శ్రమ విషయాలను పరిశీలించాలి.';
    } else if (karakaHouse == 5 || karakaHouse == 9 || karakaHouse == 11) {
      leading = '${topic.name} అంశానికి $placementContext అనుసంధానం ఉంది; '
          'అవకాశాలు, సహకారం ఉన్నాయో మూల నియమాలతో పరిశీలించాలి.';
    } else {
      leading = '${topic.name} అంశం $placementContext ప్రభావంతో ముడిపడి ఉంది; '
          'ప్రత్యక్ష BNN ఫలితం ధృవీకరించబడలేదు.';
    }
    final summary = leading;
    final occupantText = targetPlanets.isEmpty
        ? '${topic.house}వ భావంలో గ్రహాలు లేవు'
        : '${topic.house}వ భావంలో ${targetPlanets.map((p) => _teluguPlanet[p.name] ?? p.name).join(', ')} ఉన్నాయి';
    final evidence = 'కారకగ్రహం: $planetName • $signName '
        '${planet.degreesInSign.toStringAsFixed(2)}° • గురు నుంచి $karakaHouse వ భావం. '
        '$support $occupantText. '
        '${otherPlanetNames.isEmpty ? 'ఇతర గ్రహ సహస్థితి లేదు' : 'ఇతర గ్రహాలు: ${otherPlanetNames.join(', ')}'}. '
        'గురు–కారకగ్రహ సంబంధం: ${relation ?? 'గుర్తించబడలేదు'}. '
        'రాశి స్వభావం: ${_signModes[mode]}.';
    final rule = 'IF: అంశం ${topic.name}; కారకుడు $planetName; '
        'గురు ఆధారంగా కారకుడు $karakaHouse వ భావం; '
        '${karakaInTopic ? 'అంశ భావంలో ఉన్నాడు' : 'అంశ భావంలో లేడు'}; '
        'గురు–కారకగ్రహ సంబంధం ${relation ?? 'స్పష్టంగా గుర్తించలేదు'}. '
        'THEN: పై అంశాధారిత వ్యాఖ్యానాన్ని ప్రాథమిక పరిశీలన సూచనగా మాత్రమే చూపాలి. '
        '462 మూలగ్రంథ IF–THEN నియమం ఈ ప్రత్యేక ఫలితాన్ని నిర్ధారించలేదు.';
    return BnnTopicReading(
      summary: summary,
      evidence: evidence,
      rule: rule,
      provenance: 'యాప్ 144 అంశాల వివరణ/స్క్రీనింగ్ విధానం. '
          'ఇది 462 BNN మూలగ్రంథ నియమాలలో ధృవీకరించిన సంఘటన ఫలితం కాదు. '
          'మూల నాడీ గ్రహక్రమం, సంబంధం, గోచారం, కాల నిర్ధారణను విడిగా పరీక్షించాలి.',
    );
  }

  static String describe(BnnBhavaTopic topic, AstroChartResult chart) =>
      read(topic, chart).summary;
}

class BnnTopicReading {
  final String summary;
  final String evidence;
  final String rule;
  final String provenance;
  const BnnTopicReading({
    required this.summary,
    required this.evidence,
    required this.rule,
    required this.provenance,
  });
}
