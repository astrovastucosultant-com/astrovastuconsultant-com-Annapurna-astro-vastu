import 'western_timing_engine_v434.dart';
import 'western_timing_settings_v433.dart';

/// Western *tropical* topical interpretation of the existing aspect contacts.
/// House themes are Western natal Placidus houses, with traditional Western
/// zodiac domicile rulers. This intentionally excludes sidereal vargas,
/// Jaimini, KP, nakshatras, dasha, BNN and all other Indian techniques.
///
/// Topic matching is an evidence filter, not a marriage/job/health prediction.
class WesternEventTopicV435 {
  const WesternEventTopicV435({
    required this.id,
    required this.teluguTitle,
    required this.houses,
    required this.naturalPlanets,
    required this.interpretation,
    required this.sourceId,
    required this.sourceTitle,
    required this.sourceUrl,
  });

  final String id;
  final String teluguTitle;
  final List<int> houses;
  final List<String> naturalPlanets;
  final String interpretation;
  /// Verifiable published Western reference for this topic. The app matcher
  /// itself is a transparent synthesis, not a verbatim quote from the source.
  final String sourceId;
  final String sourceTitle;
  final String sourceUrl;

  String get ruleId => 'WEST-EVENT-$id-435';

  static const String houseSource = 'https://www.astro.com/astrowiki/en/Houses';
  static const String relationshipSource =
      'https://www.astro.com/astrology/iam_article190812_e.htm';
  static const String rulerSource = 'https://www.astro.com/astrowiki/en/Sign_Ruler';
  static const String secondarySource =
      'https://www.astro.com/astrowiki/en/Secondary_Directions';
  static const String solarArcSource =
      'https://www.astro.com/faq/fq_fh_owtype_s.htm?lang=e&nhor=12';
  static const String transitSource =
      'https://www.astro.com/astrowiki/en/Transit';

  static const List<WesternEventTopicV435> all = [
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-REL-2019', sourceTitle: 'Astrodienst — Predicting for Relationships', sourceUrl: relationshipSource,
      id: 'REL', teluguTitle: 'ప్రేమ / సంబంధాలు',
      houses: [7, 5], naturalPlanets: ['Venus', 'Moon'],
      interpretation: 'Western 7వ భావం భాగస్వామ్యం; 5వ భావం ప్రేమ/రోమాన్స్. '
          'Venus, Moon సంపర్కాలు అనుబంధ సంకేతాలుగా మాత్రమే చూడాలి.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-REL-2019',
      sourceTitle: 'Astrodienst — Predicting for Relationships',
      sourceUrl: relationshipSource,
      id: 'MAR', teluguTitle: 'వివాహం (వయస్సు అర్హతతో)',
      houses: [7, 5], naturalPlanets: ['Venus', 'Moon'],
      interpretation: 'Western 7వ భావం భాగస్వామ్య సంబంధాలు; Venus/Moon '
          'సంపర్కాలు వివాహానికి నిర్ధారణ కావు. చట్టపరమైన వయస్సు అర్హత '
          'ప్రత్యేక ప్రదర్శన ఫిల్టర్; Western జ్యోతిష్య నియమం కాదు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'JOB', teluguTitle: 'ఉద్యోగం / కెరీర్',
      houses: [10, 6, 2], naturalPlanets: ['Saturn', 'Sun', 'Mercury'],
      interpretation: 'Western 10వ భావం కెరీర్/స్థానం; 6వ భావం రోజువారీ పని; '
          '2వ భావం సంపాదన.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'BUS', teluguTitle: 'వ్యాపారం / ఒప్పందాలు',
      houses: [7, 10, 2], naturalPlanets: ['Mercury', 'Jupiter'],
      interpretation: 'Western 7వ భావం ఒప్పందాలు/భాగస్వాములు; '
          '10వ భావం వృత్తి; 2వ భావం ఆర్థిక వనరులు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'PRM', teluguTitle: 'పదోన్నతి / వృత్తి మార్పు',
      houses: [10, 11], naturalPlanets: ['Sun', 'Jupiter', 'Saturn'],
      interpretation: 'Western 10వ భావం ప్రతిష్ఠ/కెరీర్, '
          '11వ భావం నెట్‌వర్క్/లక్ష్యాలు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'FIN', teluguTitle: 'ఆదాయం / ఆర్థిక విషయాలు',
      houses: [2, 8], naturalPlanets: ['Venus', 'Jupiter'],
      interpretation: 'Western 2వ భావం వ్యక్తిగత వనరులు; '
          '8వ భావం ఉమ్మడి ఆస్తులు/వనరులు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'HOM', teluguTitle: 'ఇల్లు / స్థిరాస్తి',
      houses: [4, 2], naturalPlanets: ['Moon', 'Saturn'],
      interpretation: 'Western 4వ భావం ఇల్లు/కుటుంబ మూలాలు; '
          '2వ భావం ఆర్థిక వనరులు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'CHD', teluguTitle: 'సంతానం / సృజనాత్మకత',
      houses: [5], naturalPlanets: ['Moon', 'Venus', 'Jupiter'],
      interpretation: 'Western 5వ భావం పిల్లలు/సృజనాత్మకతకు '
          'సంబంధించిన ప్రతీకాత్మక అంశం; గర్భధారణ ఫలితం కాదు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'EDU', teluguTitle: 'విద్య / ఉన్నత చదువులు',
      houses: [3, 9], naturalPlanets: ['Mercury', 'Jupiter'],
      interpretation: 'Western 3వ భావం అధ్యయనం/సమాచారం; '
          '9వ భావం ఉన్నత విద్య/విస్తృత జ్ఞానం.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'TRV', teluguTitle: 'విదేశీ / దూర ప్రయాణం',
      houses: [9, 3], naturalPlanets: ['Jupiter', 'Mercury'],
      interpretation: 'Western 9వ భావం దీర్ఘ ప్రయాణాలు/విదేశాలు; '
          '3వ భావం చిన్న ప్రయాణాలు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'MOV', teluguTitle: 'ఇల్లు మార్పు / నివాస మార్పు',
      houses: [4, 9], naturalPlanets: ['Moon', 'Uranus'],
      interpretation: 'Western 4వ భావం నివాసం; '
          '9వ భావం దూర ప్రాంతాల మార్పు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'WEL', teluguTitle: 'ఆరోగ్యం / దినచర్య (పరిశీలన)',
      houses: [1, 6], naturalPlanets: ['Sun', 'Mars'],
      interpretation: 'Western 1వ భావం వ్యక్తిగత జీవితం, '
          '6వ భావం ఆరోగ్య దినచర్య; వ్యాధి నిర్ధారణ కాదు.'),
    WesternEventTopicV435(
      sourceId: 'WEST-SRC-HOUSES', sourceTitle: 'Astrodienst — Houses', sourceUrl: houseSource,
      id: 'RET', teluguTitle: 'రిటైర్మెంట్ / జీవన మార్పు',
      houses: [10, 4], naturalPlanets: ['Saturn', 'Sun'],
      interpretation: 'Western 10వ భావం వృత్తి పాత్ర; '
          '4వ భావం ఇల్లు/వ్యక్తిగత జీవితం.'),
  ];

  static WesternEventTopicV435 byId(String id) => all.firstWhere(
    (t) => t.id == id,
    orElse: () => all.first,
  );
}

class WesternEventEvidenceV435 {
  const WesternEventEvidenceV435({
    required this.window,
    required this.reasons,
  });
  final WesternTimingWindowV434 window;
  final List<String> reasons;
}

class WesternEventSummaryV435 {
  const WesternEventSummaryV435({
    required this.topic,
    required this.matches,
    required this.houseDataAvailable,
    required this.progressionMethods,
    required this.hasTransit,
  });
  final WesternEventTopicV435 topic;
  final List<WesternEventEvidenceV435> matches;
  final bool houseDataAvailable;
  final Set<String> progressionMethods;
  final bool hasTransit;
  bool get onlyTransit => hasTransit && progressionMethods.isEmpty;

  /// Western aspect *contact quality* only; not event probability.
  /// Major trines and sextiles are traditionally facilitative; squares and
  /// oppositions are challenging; conjunction depends on chart context.
  int get facilitativeContacts => matches.where((m) =>
      const {'Trine', 'Sextile'}.contains(m.window.best.aspect)).length;
  int get challengingContacts => matches.where((m) =>
      const {'Square', 'Opposition'}.contains(m.window.best.aspect)).length;
  int get contextualContacts => matches.where((m) =>
      m.window.best.aspect == 'Conjunction').length;

  String get contactResultTelugu {
    if (matches.isEmpty) return 'ఈ నెల ఎంపిక చేసిన Western నియమాలు వర్తించలేదు';
    if (facilitativeContacts > 0 && challengingContacts > 0) {
      return 'సహాయక, సవాలు కలిగించే Western సంపర్కాలు రెండూ ఉన్నాయి';
    }
    if (facilitativeContacts > 0) {
      return 'సహాయక Western Aspect సంపర్కాలు ఉన్నాయి';
    }
    if (challengingContacts > 0) {
      return 'సవాలు కలిగించే Western Aspect సంపర్కాలు ఉన్నాయి';
    }
    return 'సందర్భాన్ని బట్టి పరిశీలించాల్సిన Western సంయోగాలు ఉన్నాయి';
  }

}

class WesternEventMatcherV435 {
  WesternEventMatcherV435._();

  static const List<String> _traditionalWesternRulers = [
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];

  static String domicileRuler(double tropicalLongitude) {
    final normalized = WesternTimingEngineV434.normalize(tropicalLongitude);
    return _traditionalWesternRulers[normalized ~/ 30];
  }

  static int? natalHouse(double longitude, List<double>? cusps) {
    if (cusps == null || cusps.length != 12 ||
        !longitude.isFinite || cusps.any((v) => !v.isFinite)) return null;
    final p = WesternTimingEngineV434.normalize(longitude);
    for (var i = 0; i < 12; i++) {
      final start = WesternTimingEngineV434.normalize(cusps[i]);
      final end = WesternTimingEngineV434.normalize(cusps[(i + 1) % 12]);
      final width = WesternTimingEngineV434.normalize(end - start);
      if (width <= 0 || width >= 180) return null;
      if (WesternTimingEngineV434.normalize(p - start) < width) return i + 1;
    }
    return null;
  }

  static WesternEventSummaryV435 match({
    required WesternTimingReportV434 report,
    required WesternEventTopicV435 topic,
    required WesternTimingSettingsV433 settings,
  }) {
    final cusps = report.natalTropicalPlacidusCusps;
    final hasCusps = cusps != null && cusps.length == 12 &&
        cusps.every((v) => v.isFinite);
    final topicalRulers = <String>{};
    if (hasCusps) {
      for (final house in topic.houses) {
        topicalRulers.add(domicileRuler(cusps![house - 1]));
      }
    }
    final hits = <WesternEventEvidenceV435>[];
    final methods = <String>{};
    var hasTransit = false;
    for (final window in report.windows) {
      final c = window.best;
      if (c.method == 'transit' && (!settings.transitsEnabled ||
          !settings.transitPlanets.contains(c.movingPlanet) ||
          !settings.transitAspects.contains(c.aspect) ||
          c.deviationDegrees > settings.orbDegrees)) continue;
      if (c.method == 'secondary' && !settings.secondaryEnabled) continue;
      if (c.method == 'solarArc' && !settings.solarArcEnabled) continue;
      if (c.method == 'progressedMoon' && !settings.progressedMoonEnabled) continue;
      final reasons = <String>[];
      final natalHouseNumber = natalHouse(c.natalLongitude, cusps);
      if (natalHouseNumber != null && topic.houses.contains(natalHouseNumber)) {
        reasons.add('Natal ${c.natalPlanet}: Western $natalHouseNumberవ భావంలో ఉంది');
      }
      if (topicalRulers.contains(c.natalPlanet)) {
        final ruled = topic.houses.where((h) =>
            domicileRuler(cusps![h - 1]) == c.natalPlanet).join(', ');
        reasons.add('Natal ${c.natalPlanet}: Western $ruled భావాధిపతి (traditional domicile)');
      }
      if (topic.naturalPlanets.contains(c.natalPlanet)) {
        reasons.add('Natal ${c.natalPlanet}: ఎంపిక చేసిన అంశానికి Western సహజ సూచకం');
      }
      if (reasons.isEmpty) continue;
      hits.add(WesternEventEvidenceV435(
          window: window, reasons: List.unmodifiable(reasons)));
      if (c.method == 'transit') {
        hasTransit = true;
      } else {
        methods.add(c.method);
      }
    }
    return WesternEventSummaryV435(
      topic: topic,
      matches: List.unmodifiable(hits),
      houseDataAvailable: hasCusps,
      progressionMethods: Set.unmodifiable(methods),
      hasTransit: hasTransit,
    );
  }
}
