Annapurna Astro Vastu — BNN 1.4.364 Update Kit

మీరు పంపిన గత ఫైల్: Annapurna-Astro-Vastu-D9-APK (11).zip
దానిలో app-release.apk ఒక్కటే ఉంది. APK వెర్షన్ 1.4.361 (code 361).
ప్యాకేజీ: com.annapurna.astrovastu.build11.
ఇందులో Flutter source లేదు. అందువల్ల ఈ APKను నేరుగా edit చేసి కొత్త APKగా ప్రకటించడం సాధ్యం కాదు.

అసలు 1.4.361 Full Flutter Source ఇప్పటికే మీ GitHub repositoryలో ఉంది:
Annapurna-Astro-Vastu-FRESH-From-Uploaded-Build377-v1.4.361-FULL.zip

Full ZIP + కొత్త APK రూపొందించడానికి:
1. ఈ Kit ZIPను Extract చేయండి.
2. GitHub repositoryలో .github/workflows ఫోల్డర్ ఓపెన్ చేయండి.
3. ఆ ఫోల్డర్‌లో build-bnn-v364.yml ఫైల్ మాత్రమే Upload చేసి Commit చేయండి.
   ముఖ్యంగా repository root లో upload చేయకండి.
4. Actions -> Build BNN v1.4.364 Full Source and APK workflow చూడండి.
5. Workflow Success అయితే ఆ రన్‌లో Artifacts క్రింద 2 Downloads వస్తాయి:
   Annapurna-v1.4.364-FULL-SOURCE
   Annapurna-v1.4.364-APK

ఈ workflow GitHubలోని Original v361 Sourceను చదివి, v364 patchను automaticగా కలుపుతుంది.
Original Source ZIP, గత APKలను GitHubలో overwrite చేయదు.
Wrong version / mismatched source code ఉంటే error ఇచ్చి ఆగుతుంది.

BNN 1.4.364:
- ఒకే గ్రహ కాంబినేషన్‌కు శుభ Green + ప్రతికూల Red రెండూ ఉంచుతుంది.
- Rule -> జాతక పరిశీలన -> ఫలితం -> పరిహారం.
- ఆరోగ్య విషయాల్లో జాగ్రత్త సూచన.
- సంప్రదాయ మృత్యు సంబంధ సూచన ఉంటే మహామృత్యుంజయ హోమం ఆధ్యాత్మిక పరిహార సూచన,
  మరణ తేదీ నిర్ధారణ లేదా వైద్య హామీ కాదు.

ముఖ్యం: ఈ Kit ఇన్‌స్టాల్ చేయగల APK కాదు, Build workflow + Patch మాత్రమే.
పూర్తి కొత్త APK Build ఇంకా చేయలేదు. ఫోన్‌లో పాత యాప్‌ను తొలగించకండి.

ధృవీకరణ: పాత APK ZIP, APK CRC PASS; Android Manifest వర్షన్ 1.4.361;
Patch ZIP Integrity PASS; Workflow YAML Parse, Shell Syntax PASS;
Sample v361 test structure మీద PATCH -> 1.4.364 Full ZIP పరీక్ష PASS.
Actual original Full Source మీద compile/phone install ఇంకా పరీక్షించలేదు.
