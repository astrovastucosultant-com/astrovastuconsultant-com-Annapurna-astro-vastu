Annapurna Astro Vastu v1.4.423 — Home KP Time Chart + Jamakola shortcuts

Source: full v1.4.422 ZIP, existing KP (_KpCard) and JamakolaRulePanel.

Changes:
- Two visible green tabs in the Birth Details home card under/alongside its title.
- KP Time Chart opens ChartScreen directly in KP's Time Chart mode, with judgement date/time/place form and independent KP RP calculations; does not default to natal KP.
- Jamakola opens the already implemented Jamakola question-chart system directly.
- For question quick launch, birth name/gender/date are not required; current moment at entered place UTC offset is used. The birth-date fields are not confused with the question moment.
- Place name, latitude, longitude and UTC offset must be valid; otherwise no fictitious location or chart is substituted. For Placidus/Mandi, latitude is constrained to +/-66 degrees.
- Legacy birth chart generation, 19 vargas, marriage, saved charts and source rules remain unchanged.

Test added: test/home_kp_jamakola_v423_test.dart
Caveat: widget and APK tests require Flutter on a GitHub Actions runner. No direct APK was compiled in this container.
