ANNAPURNA ASTRO VASTU — v1.4.424 Marriage Matching Chart Comparison

Source: v1.4.423 FULL. User references: "marrage matching " (the app's
existing text-only 8-page report), "marrage matching 1" (six-page AstroSage
sample with two persons' South Indian charts displayed side by side).

Changes:
- Marriage Matching tab after selecting partner from Saved Charts:
  Four paired rows D1, D7, D9, Chandra Lagna (total 8 South Indian charts).
- Each side-by-side pair is tappable to enlarge and examine the 12 signs.
- On very narrow phones, pairs scroll horizontally instead of cropping.
- Chandra lagna reuses D1 planets without moving any planet into a new sign;
  only the lagna reference is changed to the natal Moon's sign.
- If a natal Moon is unavailable, that chart is omitted and a warning shown.
- Final Marriage Report / PDF Save / Share includes actual chart images for
  both people on two additional diagram pages, as well as sign audit text.
- Existing 36-point Ashtakoota calculation, source IF-THEN rules, D7 rules,
  and no-forced-marriage-verdict policy remain unchanged.
- This is a visualization / audit update, not new numerical compatibility
  evidence, prognostic claims or remediation.

Build and test status: Source package structurally checked; GitHub Flutter
unit/widget tests and APK build must complete before claiming installability.
