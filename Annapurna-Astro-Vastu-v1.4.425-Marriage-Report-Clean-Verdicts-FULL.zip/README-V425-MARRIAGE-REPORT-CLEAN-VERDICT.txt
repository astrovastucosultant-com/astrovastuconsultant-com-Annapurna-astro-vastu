ANNAPURNA ASTRO VASTU — v1.4.425 marriage report presentation / verdict labels

Base: v1.4.424 eight paired marriage matching charts, Flutter source.

1. Remove repeated D1, D7, D9, Chandra-Lagna 12-rashi textual planet lists
   from the Final Marriage Report. The eight actual South Indian charts still
   appear side-by-side in the Matching screen and the generated PDF pages.
   The chart popup still supports a detailed sign-by-sign examination.
2. Each source-rule result now says (in Telugu):
   favourable => 'కలిసింది బాగుంది — ఈ నియమం ప్రకారం అనుకూల సంయోగం ఉంది.'
   adverse    => 'చెడు సంయోగం ఉన్నది కనుక ఈ నియమం ప్రకారం అనుకూలము కాదు.'
   unknown    => 'ఈ నియమం నుంచి నిర్ణయించలేం ...'
3. The report and on-screen summary show the source Rule IDs and counts for
   favourable/adverse rule matches. Mixed evidence is shown as 'మిశ్రమ ఫలితం';
   absent confirmed evidence is NEVER interpreted as a favorable/adverse match.
4. Ashtakoota 36-mark computations, Moon-lagna method, D7/D9 rules, natal
   charts, chart pair visualization and timing engines are not changed.
5. The previously GitHub-tested PDF rendering asynchronous test is now a
   regular test in the source, so no fragile YAML source-edit step is needed.

Verification: ZIP file hashes and test/source presence are verified locally;
Flutter tests and a signed APK build must run on GitHub before installation.
