import 'astro_models.dart';
import 'jaimini_service.dart';
import 'varga_service.dart';
import '../utils/astro_format.dart';

/// Additional, source-scoped Jaimini predicates. No natural-language parsing:
/// only an explicitly reviewed rule ID can become a chart match.
/// Multiple alternative outcomes are calculations, not a blanket prediction.
class JaiminiExtendedRuleCheck {
  final bool? matched;
  final String evidence;
  final bool calculated;
  const JaiminiExtendedRuleCheck(this.matched, this.evidence,
      {this.calculated = false});
}

class JaiminiExtendedRuleEngine {
  const JaiminiExtendedRuleEngine._();

  static JaiminiExtendedRuleCheck? check(
      String id, AstroChartResult chart, JaiminiResult jm) {
    // Avoid computing D9/planet maps for unsupported catalog records.
    const explicitRules = <String>{
      '1.1', '1.2', '1.3', '1.4', '1.5', '1.6', '1.7', '1.9', '1.10', '1.13', '1.8', '1.22',
      '1.23', '1.24', '1.25', '2.1', '2.2', '2.3', '2.4', '2.7', '2.21', '3.24', '3.26', '3.27',
      '3.28', '3.29', '3.30', '3.31', '3.32', '3.35', '3.38', '3.46', '3.47', '3.49', '3.50', '3.51',
      '3.52', '3.53', '3.54', '3.55', '3.56', '3.57', '3.59', '3.60', '3.61', '3.62', '3.63', '3.64',
      '3.65', '3.66', '3.67', '3.68', '3.69', '3.70', '3.71', '3.72', '3.73', '3.74', '3.76', '5.1',
      '5.2', '5.3', '5.5', '5.6', '5.7', '5.8', '5.9', '5.11', '6.10', '6.11', '5.24', '6.1',
      '6.2', '6.3', '6.4', '6.5', '6.6', '6.7', '6.9', '6.25', '6.27', '6.28', '7.6', '14.16',
      '14.17', '14.18', '14.19', '14.20', '14.21', '1.31', '1.32', '1.33', '3.25', '3.34', '3.48',
      '3.58', '5.4', '5.12', '5.38', '5.39', '5.40', '6.8', '6.13', '6.14', '6.15', '6.18', '6.21',
      '6.22', '6.23', '6.24', '7.23', '7.24', '7.25', '7.26', '7.27', '7.28', '14.15', '14.24', '14.25',
      '14.26',
    };
    if (!explicitRules.contains(id)) return null;
    if (chart.planets.isEmpty) return null;
    final lagna = chart.ascendantSignIndex;
    final d9 = VargaService.calculate(chart, 9);
    final kl = jm.karakamsaSignIndex;
    final ulRows = jm.arudhaPadas.where((p) => p.padaNumber == 12);
    final alRows = jm.arudhaPadas.where((p) => p.padaNumber == 1);
    final a7Rows = jm.arudhaPadas.where((p) => p.padaNumber == 7);
    final ul = ulRows.isEmpty ? null : ulRows.first.padaSignIndex;
    final al = alRows.isEmpty ? null : alRows.first.padaSignIndex;
    final a7 = a7Rows.isEmpty ? null : a7Rows.first.padaSignIndex;
    final signs = AstroFormat.signNamesTe;
    final n = (int sign) => (sign % 12 + 12) % 12;
    final at = (int sign, int house) => n(sign + house - 1);
    final name = (int sign) => signs[n(sign)];
    final d1planets = <String, int>{for (final p in chart.planets) p.name: p.signIndex};
    final d9planets = <String, int>{for (final p in d9.planets) p.name: p.signIndex};
    final benefics = <String>{'Jupiter', 'Venus', 'Mercury', 'Moon'};
    final malefics = <String>{'Saturn', 'Mars', 'Rahu', 'Sun'};
    final signLords = <String>[
      'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
      'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
    ];
    final exalted = <String, int>{
      'Sun': 0, 'Moon': 1, 'Mars': 9, 'Mercury': 5,
      'Jupiter': 3, 'Venus': 11, 'Saturn': 6,
    };
    final debilitated = <String, int>{
      for (final e in exalted.entries) e.key: n(e.value + 6),
    };
    bool inD9(String p, int s) => d9planets[p] == n(s);
    bool inD1(String p, int s) => d1planets[p] == n(s);
    bool d9Together(List<String> ps, int s) => ps.every((p) => inD9(p, s));
    bool d1Together(List<String> ps, int s) => ps.every((p) => inD1(p, s));
    List<String> d9At(int s) => d9planets.keys.where((p) => inD9(p, s)).toList();
    List<String> d1At(int s) => d1planets.keys.where((p) => inD1(p, s)).toList();
    List<int> drishti(int s) => jm.rashiDrishti[n(s)] ?? <int>[];
    bool sees(int from, int to) => drishti(from).contains(n(to));
    bool d9Sees(String p, int s) => d9planets.containsKey(p) && sees(d9planets[p]!, s);
    bool d1Sees(String p, int s) => d1planets.containsKey(p) && sees(d1planets[p]!, s);
    bool d9Affects(String p, int s) => inD9(p, s) || d9Sees(p, s);
    bool d1Affects(String p, int s) => inD1(p, s) || d1Sees(p, s);
    bool d9Any(Iterable<String> ps, int s) => ps.any((p) => inD9(p, s));
    bool d9AnyAffects(Iterable<String> ps, int s) => ps.any((p) => d9Affects(p, s));
    bool d1AnyAffects(Iterable<String> ps, int s) => ps.any((p) => d1Affects(p, s));
    bool exD9(int s) => d9At(s).any((p) => exalted[p] == n(s));
    bool exD1(int s) => d1At(s).any((p) => exalted[p] == n(s));
    bool debD1(int s) => d1At(s).any((p) => debilitated[p] == n(s));
    String list(List<String> ps) => ps.isEmpty ? 'లేవు' : ps.join(', ');
    JaiminiExtendedRuleCheck decision(bool ok, String reason) =>
        JaiminiExtendedRuleCheck(ok, '${ok ? 'షరతు సరిపోయింది' : 'షరతు సరిపోలేదు'}: $reason. '
        'ఇది పేర్కొన్న జైమిని షరతు పరీక్ష మాత్రమే; పూర్తి జీవితఫల నిర్ధారణ కాదు.');
    JaiminiExtendedRuleCheck measured(String reason) =>
        JaiminiExtendedRuleCheck(null, '$reason. మూలంలోని విభిన్న ఫలిత శాఖలు '
        'ఒకే Boolean యోగంగా పరిగణించలేదు.', calculated: true);
    if (jm.hasDegreeTie && (id.startsWith('3.') || id.startsWith('6.25'))) {
      return null; // Karakamsa cannot be safely selected in this case.
    }
    final second = at(kl, 2);
    final third = at(kl, 3);
    final fourth = at(kl, 4);
    final fifth = at(kl, 5);
    final sixth = at(kl, 6);
    final seventh = at(kl, 7);
    final ninth = at(kl, 9);
    final tenth = at(kl, 10);
    final twelfth = at(kl, 12);

    switch (id) {
      // Foundations: the output is a reproducible formula, not an event claim.
      case '1.1': case '1.2': case '1.3': case '1.4': case '1.5':
        return measured('జన్మ లగ్నం ${name(lagna)} రాశిదృష్టులు: '
          '${drishti(lagna).map(name).join(', ')}; ప్రస్తుత చక్రంలో 12 రాశుల '
          'దృష్టి పట్టిక గణించబడింది');
      case '1.6':
        return measured('ఒకే రాశిలో ఉన్న గ్రహాల యుతులు: '
          "${List.generate(12, (s) => '${name(s)}: ${list(d1At(s))}').where((row) => !row.endsWith('లేవు')).join('; ')}. "
          'యుతి, రాశిదృష్టి వేర్వేరు గణనలు');
      case '1.7': case '1.9': case '1.10': case '1.13':
        return measured('లగ్నం ${name(lagna)} నుంచి 2వ ${list(d1At(at(lagna,2)))}, '
          '4వ ${list(d1At(at(lagna,4)))}, 5వ ${list(d1At(at(lagna,5)))}, '
          '11వ ${list(d1At(at(lagna,11)))}; విరోధ స్థానాలు: '
          '12వ ${list(d1At(at(lagna,12)))}, '
          '10వ ${list(d1At(at(lagna,10)))}, '
          '9వ ${list(d1At(at(lagna,9)))}, '
          '3వ ${list(d1At(at(lagna,3)))}. '
          'అర్గళ బలం, విరోధ అర్గళ బలం ప్రత్యేకంగా తూకం వేయాలి');
      case '1.8':
        // 1.1.5 is stated for a reference sign. Checking only the natal
        // ascendant's third cannot disprove the rule for all reference signs.
        // Moon/Mercury/Ketu malefic classifications vary by tradition.
        final thirdSign = at(lagna, 3);
        final counted = d1At(thirdSign).where(malefics.contains).toList();
        final otherReferenceSigns = <String>[];
        for (var s = 0; s < 12; s++) {
          if (d1At(at(s, 3)).where(malefics.contains).length >= 3) {
            otherReferenceSigns.add(name(s));
          }
        }
        return measured('జన్మలగ్నం ${name(lagna)} నుండి 3వ రాశి '
          '${name(thirdSign)}: నిసర్గ పాపగ్రహాలు ${list(counted)} '
          '(సంఖ్య ${counted.length}; లెక్కించినవి రవి/కుజ/శని/రాహు మాత్రమే). '
          'ఈ పరిమిత నిర్వచనంలో 3వ స్థానంలో ముగ్గురు లేదా ఎక్కువ పాపగ్రహాలు '
          'కలిగిన ఇతర సూచనా రాశులు: '
          '${otherReferenceSigns.isEmpty ? 'లేవు' : otherReferenceSigns.join(', ')}. '
          'మూల నియమం ఏ సూచనా రాశి నుంచి పరీక్షించాలో, కేతు/చంద్ర/బుధ '
          'పాపత్వ భేదాలు, ఇతర అర్గళ సూచనలను నిర్ధారించకముందు '
          'అన్ని జాతకాలకు తుది నిజం/అబద్ధం తీర్పు ఇవ్వలేము');
      case '1.22': case '1.23': case '1.24': case '1.25':
        return measured('జన్మ లగ్న రాశి ${name(lagna)}; ఈ నియమం రాశి/దశ '
          'గణన దిశను వివరిస్తుంది. చరదశ పద్ధతి ఎంపికను స్వతంత్రంగా నిల్వ చేయాలి');
      case '2.1': case '2.2': case '2.3': case '2.4': case '2.7':
        return measured('భావ ఆరూఢాలు: '
          '${jm.arudhaPadas.map((p) => 'A${p.padaNumber}=${name(p.padaSignIndex)} '
          '(అధిపతి ${p.lord})').join('; ')}. '
          'ప్రత్యేక ఆరూఢ మినహాయింపులపై మూల వ్యాఖ్యాన భేదాలు ఉన్నాయి');
      case '2.21':
        if (al == null) return null;
        // Upagrahas are computed from the real D1 Sun longitude.
        final sun = chart.planets.where((p) => p.name == 'Sun');
        if (sun.isEmpty) return null;
        final dh = (sun.first.longitude + 133 + 20/60) % 360;
        final vy = (360 - dh) % 360;
        final pa = (vy + 180) % 360;
        final ic = (360 - pa) % 360;
        final uk = (ic + 16 + 40/60) % 360;
        final pairs = <String, int>{
          'ధూమం': (dh / 30).floor(), 'వ్యతీపాతం': (vy / 30).floor(),
          'పరివేషం': (pa / 30).floor(), 'ఇంద్రచాపం': (ic / 30).floor(),
          'ఉపకేతు': (uk / 30).floor(),
        };
        final target = at(al, 9);
        final found = pairs.keys.where((p) => pairs[p] == target).toList();
        return decision(found.isNotEmpty,
          'AL=${name(al)}, AL నుంచి 9వ ${name(target)}, అక్కడ ఉన్న '
          'లెక్కించిన ఉపగ్రహాలు: ${list(found)}');
      // Karakamsa / vocation: explicit geometric predicates.
      case '3.24':
        return decision(d9Affects('Sun', kl) && d9Affects('Venus', kl),
          'కారకాంశం ${name(kl)}పై రవి, శుక్ర యుతి/రాశిదృష్టి: '
          '${d9Affects('Sun',kl)}, ${d9Affects('Venus',kl)}');
      case '3.26':
        return decision(inD9('Moon', kl) && d9Sees('Mercury', kl),
          'KL=${name(kl)}, చంద్రుడు KLలో ${inD9('Moon',kl)}, '
          'బుధుని రాశిదృష్టి ${d9Sees('Mercury',kl)}');
      case '3.27':
        return measured('KL నుంచి 4వ ${name(fourth)}లో గ్రహాలు: '
          '${list(d9At(fourth))}. శని/కేతు/బుధ/రాహు/రవి/కుజ '
          'ఒక్కో శాఖకు PDFలో భిన్న వృత్తి ఫలితం ఉంది');
      case '3.28':
        return decision(d9Affects('Mercury', tenth),
          'KL నుంచి 10వ ${name(tenth)}లో బుధుడు/దృష్టి: '
          '${d9Affects('Mercury',tenth)}');
      case '3.29':
        return measured('KL నుంచి 10వ ${name(tenth)}పై శుభ దృష్టి/యుతి: '
          '${benefics.where((p)=>d9Affects(p,tenth)).join(', ')}; '
          'పాప దృష్టి/యుతి: ${malefics.where((p)=>d9Affects(p,tenth)).join(', ')}');
      case '3.30':
        final onlyJupiter = d9planets.keys.where((p) =>
          p != 'Sun' && d9Sees(p,tenth)).toSet();
        return decision(inD9('Sun', tenth) && onlyJupiter.length == 1 &&
          onlyJupiter.contains('Jupiter'),
          'KL10=${name(tenth)}, రవి ${inD9('Sun',tenth)}; '
          'దృష్టి గ్రహాలు: ${list(onlyJupiter.toList())}');
      case '3.31':
        final m3 = d9At(third).where(malefics.contains).toList();
        final m6 = d9At(sixth).where(malefics.contains).toList();
        return decision(m3.isNotEmpty && m6.isNotEmpty,
          'KL3=${name(third)}లో ${list(m3)}; '
          'KL6=${name(sixth)}లో ${list(m6)}; '
          'గురు KL9లో ${inD9('Jupiter',ninth)}');
      case '3.32':
        return measured('KL3=${name(third)}లో శుభ గ్రహాలు '
          '${list(d9At(third).where(benefics.contains).toList())}; '
          'పాప గ్రహాలు ${list(d9At(third).where(malefics.contains).toList())}');
      case '3.35':
        return decision(d9Together(['Sun','Rahu'],kl) ||
          d9Together(['Sun','Rahu'],second),
          'కారకాంశం ${name(kl)} లేదా 2వ ${name(second)}లో రవి+రాహు '
          'కలసి ఉన్నారా: ${d9Together(['Sun','Rahu'],kl)||d9Together(['Sun','Rahu'],second)}');
      case '3.38':
        final noOthers = [kl,fifth].any((s)=>inD9('Venus',s) &&
          d9At(s).where((p)=>p!='Venus').isEmpty);
        return decision(noOthers,
          'KL/5వలో కేవలం శుక్రుడు (అదే రాశిలో ఇతర గ్రహాలు లేకుండా): $noOthers; '
          'బాహ్య రాశిదృష్టుల బలం ఇక్కడ తుది నిర్ణయంలో చేర్చలేదు');
      case '3.46':
        return measured('KL=${name(kl)} లేదా KL5=${name(fifth)}కు '
          'గురు యుతి/రాశిదృష్టి ${d9Affects('Jupiter',kl)||d9Affects('Jupiter',fifth)}; '
          'వర్గ సంబంధం ఇంకా వేరుగా పరీక్షించాలి');
      case '3.47':
        final obs = malefics.where((p)=>p!='Ketu' && d9Sees(p,second)).toList();
        return decision(inD9('Ketu',second) && obs.isNotEmpty,
          'KL2=${name(second)}లో కేతువు ${inD9('Ketu',second)}; '
          'పాప రాశిదృష్టి: ${list(obs)}');
      case '3.49':
        final both = (inD9('Moon',fourth)||d9Sees('Moon',fourth)) &&
          (inD9('Venus',fourth)||d9Sees('Venus',fourth));
        return decision(both,'KL4=${name(fourth)}పై చంద్ర/శుక్ర యుతి/రాశిదృష్టి $both');
      case '3.50':
        return decision(exD9(fourth),'KL4=${name(fourth)}లో ఉచ్చ గ్రహాలు: '
          '${list(d9At(fourth).where((p)=>exalted[p]==fourth).toList())}');
      case '3.51':
        final branches = <String>[
          if (d9Together(['Saturn','Rahu'],fourth)) 'శని+రాహు: రాతి ఇల్లు',
          if (d9Together(['Mars','Ketu'],fourth)) 'కుజ+కేతు: ఇటుక ఇల్లు',
          if (inD9('Jupiter',fourth)) 'గురు: చెక్క ఇల్లు',
          if (inD9('Sun',fourth)) 'రవి: పూరి ఇల్లు',
        ];
        return measured('KL4=${name(fourth)}లో గ్రహాలు ${list(d9At(fourth))}; '
          'సరిపోయిన ప్రత్యేక శాఖలు: ${list(branches)}');
      case '3.52':
        return decision(d9At(fourth).isEmpty || inD9('Mercury',fourth),
          'KL4=${name(fourth)}లో ${list(d9At(fourth))}; బుధుడు/గ్రహం లేకపోవడం');
      case '3.53':
        return decision(inD9('Moon',fourth),
          'KL4=${name(fourth)}లో చంద్రుడు ${inD9('Moon',fourth)}');
      case '3.54': case '3.55':
        final ps = id=='3.54'?benefics:malefics;
        return decision(d9AnyAffects(ps,ninth),
          'KL9=${name(ninth)}పై ${id=='3.54'?'శుభ':'పాప'} యుతి/దృష్టి: '
          '${list(ps.where((p)=>d9Affects(p,ninth)).toList())}');
      case '3.56':
        return decision(d9Together(['Saturn','Rahu'],ninth),
          'KL9=${name(ninth)}లో శని+రాహువు ఇద్దరూ: '
          '${d9Together(['Saturn','Rahu'],ninth)}');
      case '3.57':
        return decision(d9Together(['Sun','Jupiter'],ninth),
          'KL9=${name(ninth)}లో రవి+గురువు ఇద్దరూ: '
          '${d9Together(['Sun','Jupiter'],ninth)}');
      case '3.59':
        return decision(d9Together(['Mars','Venus'],ninth)||
          (d9Sees('Mars',ninth)&&d9Sees('Venus',ninth)),
          'KL9=${name(ninth)}లో కుజ+శుక్ర యుతి లేదా రెండింటి రాశిదృష్టి');
      case '3.60':
        return decision(d9Affects('Ketu',ninth),
          'KL9=${name(ninth)}కు కేతు యుతి/రాశిదృష్టి: ${d9Affects('Ketu',ninth)}');
      case '3.61':
        return measured('KL9=${name(ninth)}లో గురువు: ${inD9('Jupiter',ninth)}, '
          'రాహు: ${inD9('Rahu',ninth)}. మూలంలో రెండు వేరు ఫలితాలు');
      case '3.62':
        return decision(d9Affects('Jupiter',seventh)&&d9Affects('Moon',seventh),
          'KL7=${name(seventh)}కు గురు, చంద్ర యుతి/దృష్టి: '
          '${d9Affects('Jupiter',seventh)}, ${d9Affects('Moon',seventh)}');
      case '3.63': case '3.64': case '3.65': case '3.66': case '3.67':
        final ps=<String,String>{'3.63':'Rahu','3.64':'Saturn',
          '3.65':'Mars','3.66':'Sun','3.67':'Mercury'};
        final p=ps[id]!;
        return decision(inD9(p,seventh),'KL7=${name(seventh)}లో $p: ${inD9(p,seventh)}');
      case '3.68':
        return decision(d9At(twelfth).any(benefics.contains),
          'KL12=${name(twelfth)}లో శుభగ్రహాలు: '
          '${list(d9At(twelfth).where(benefics.contains).toList())}; '
          'ఉచ్చ బలం స్వతంత్రంగా చూపాలి');
      case '3.69':
        return decision(d9At(kl).any(benefics.contains)||inD9('Ketu',twelfth),
          'KLలో శుభగ్రహాలు ${list(d9At(kl).where(benefics.contains).toList())}; '
          'KL12లో కేతువు ${inD9('Ketu',twelfth)}');
      case '3.70':
        return decision((twelfth==11 || twelfth==3) &&
          d9AnyAffects(benefics,twelfth),
          'KL12=${name(twelfth)}; శుభసంబంధం '
          '${list(benefics.where((p)=>d9Affects(p,twelfth)).toList())}');
      case '3.71':
        return decision(malefics.where((p)=>p!='Ketu'&&d9Affects(p,twelfth)).isNotEmpty,
          'KL12=${name(twelfth)}పై కేతు తప్ప పాపగ్రహాల ప్రభావం: '
          '${list(malefics.where((p)=>p!='Ketu'&&d9Affects(p,twelfth)).toList())}');
      case '3.72': case '3.73': case '3.74':
        return measured('KL12=${name(twelfth)}లో ${list(d9At(twelfth))}; '
          'కేతువుతో కలసిన గ్రహాల ప్రకారం మూలంలో వేర్వేరు ఉపాస్యదేవతలు');
      case '3.76':
        final f=d9At(fifth).where(malefics.contains).length;
        final t=d9At(ninth).where(malefics.contains).length;
        return decision(f>=2||t>=2,
          'KL5=${name(fifth)}లో పాపులు $f; KL9=${name(ninth)}లో పాపులు $t');
      // AL, wealth / income: keep conflicting sign indicators separate.
      case '5.1':
        if(al==null)return null;
        final target=at(al,11);
        return decision(d1At(target).isNotEmpty || d1planets.keys.any((p)=>d1Sees(p,target)),
          'AL=${name(al)}, 11వ=${name(target)}; గ్రహాలు ${list(d1At(target))}; '
          'దృష్టి ${list(d1planets.keys.where((p)=>d1Sees(p,target)).toList())}');
      case '5.2':
        if(al==null)return null;
        final target=at(al,11);
        return measured('AL11=${name(target)}పై శుభ ప్రభావం '
          '${list(benefics.where((p)=>d1Affects(p,target)).toList())}; '
          'పాప ప్రభావం ${list(malefics.where((p)=>d1Affects(p,target)).toList())}');
      case '5.3':
        if(al==null)return null;
        final target=at(al,11);
        return measured('AL11=${name(target)}లో ఉచ్చగ్రహం ${exD1(target)}, శుభ ప్రభావం '
          '${d1AnyAffects(benefics,target)}; మూలత్రికోణ భేదం పూర్తి కాదు');
      case '5.5':
        if(al==null)return null;
        final target=at(al,12);
        return decision(debD1(target)||d1At(target).any(malefics.contains),
          'AL12=${name(target)}, నీచ గ్రహం ${debD1(target)}; '
          'పాపగ్రహాలు ${list(d1At(target).where(malefics.contains).toList())}');
      case '5.6':
        if(al==null)return null;
        final target=at(al,12);
        return measured('AL12=${name(target)}పై రవి ${d1Affects('Sun',target)}, '
          'రాహు ${d1Affects('Rahu',target)}, శుక్ర ${d1Affects('Venus',target)}; '
          'మూడు శాఖల వ్యయకారణాలు వేర్వేరు');
      case '5.7': case '5.8':
        if(al==null)return null;
        final target=at(al,id=='5.7'?12:11);
        return measured('AL నుంచి ${id=='5.7'?12:11}వ ${name(target)}పై '
          'బుధ ${d1Affects('Mercury',target)}, '
          'గురు ${d1Affects('Jupiter',target)}, '
          'కుజ+శని ${d1Affects('Mars',target)&&d1Affects('Saturn',target)}');
      case '5.9':
        if(al==null)return null;
        final target=at(al,2);
        return decision(d1At(target).any(<String>{'Moon','Jupiter','Venus'}.contains)
          ||exD1(target),'AL2=${name(target)}, గ్రహాలు ${list(d1At(target))}, '
          'ఉచ్చగ్రహం ${exD1(target)}; మూలంలోని భిన్న పాక్షిక కలయికలు చూడాలి');
      case '5.11': case '6.10': case '6.11':
        if(al==null||a7==null)return null;
        final distance=(a7-al+12)%12+1;
        final relationship = <int>{1,4,5,7,9,10}.contains(distance) ?
          'కేంద్ర/త్రికోణ' : <int>{6,8,12}.contains(distance) ? '6/8/12' : 'ఇతర';
        if(id=='5.11')return measured('AL=${name(al)}, A7=${name(a7)}, '
          'AL నుంచి A7 $distance వ స్థానం ($relationship). మూలంలో రెండూ వేరు ఫలితాలు');
        if(id=='6.10')return decision(<int>{1,3,4,5,7,9,10,11}.contains(distance),
          'AL=${name(al)}, A7=${name(a7)}, సాపేక్ష స్థానం $distance');
        return decision(<int>{6,8,12}.contains(distance),
          'AL=${name(al)}, A7=${name(a7)}, సాపేక్ష స్థానం $distance');
      case '5.24':
        final akSign=d1planets[jm.atmakaraka];
        if(akSign==null)return null;
        final target=at(akSign,4);
        return decision(d1Together(['Venus','Moon'],target),
          'AK ${jm.atmakaraka} రాశి ${name(akSign)} నుంచి 4వ ${name(target)}లో '
          'శుక్ర+చంద్ర యుతి: ${d1Together(['Venus','Moon'],target)}');
      // Upapada, partner: relative signs must be present.
      case '6.1': case '6.2':
        if(ul==null)return null;
        final target=at(ul,2);
        final ps=id=='6.1'?malefics.difference({'Sun'}):benefics;
        return decision(d1AnyAffects(ps,target),
          'UL=${name(ul)}, UL2=${name(target)}పై '
          '${id=='6.1'?'పాప':'శుభ'} ప్రభావం: '
          '${list(ps.where((p)=>d1Affects(p,target)).toList())}; '
          'ఇది ఒక్క పరిమిత షరతు, దాంపత్య తుది తీర్పు కాదు');
      case '6.3': case '6.4':
        if(ul==null)return null;
        final signsToCheck=[ul,at(ul,2)];
        final found=signsToCheck.where((s)=>id=='6.3'?debD1(s):exD1(s)).toList();
        return decision(found.isNotEmpty,
          'UL=${name(ul)} / UL2=${name(at(ul,2))}; '
          '${id=='6.3'?'నీచ':'ఉచ్చ'} గ్రహం ఉన్న రాశులు '
          '${list(found.map(name).toList())}');
      case '6.5':
        if(ul==null)return null;
        return decision(ul==2 || at(ul,2)==2,
          'UL=${name(ul)}, UL2=${name(at(ul,2))}; మిథునం ఉన్నదా');
      case '6.6':
        if(ul==null)return null;
        final target=at(ul,2);
        final lord=signLords[target];
        final ownPlace=d1planets[lord];
        return decision(inD1(lord,target) || (ownPlace!=null && signLords[ownPlace]==lord),
          'UL2=${name(target)}, అధిపతి $lord స్థానం '
          '${ownPlace==null?'అందుబాటులో లేదు':name(ownPlace)}; '
          'అధిపతి స్వరాశి ${ownPlace!=null&&signLords[ownPlace]==lord}');
      case '6.7':
        if(ul==null)return null;
        final lord1=signLords[ul], lord2=signLords[at(ul,2)];
        return decision(debilitated[lord1]==d1planets[lord1] ||
          debilitated[lord2]==d1planets[lord2],
          'UL అధిపతి $lord1, UL2 అధిపతి $lord2 నీచ స్థితి తనిఖీ');
      case '6.9':
        if(ul==null)return null;
        return measured('UL=${name(ul)} (${list(d1At(ul))}), '
          'UL2=${name(at(ul,2))} (${list(d1At(at(ul,2)))}); '
          'శని-రాహు యుతి, అధిపతులపై దృష్టి శాఖలు వేర్వేరుగా చూడాలి');
      case '6.25':
        return measured('AK=${jm.atmakaraka}, KL=${name(kl)}; '
          'ఈ నియమం 12 కారకాంశ రాశుల ఫలితాల సూచిక, '
          '3.1–3.12లో ఒక్కొక్క రాశికి ప్రత్యక్ష పరీక్ష ఉంది');
      case '6.27':
        return measured('KL=${name(kl)}, గ్రహాలు ${list(d9At(kl))}; '
          'శని+రాహు యుతి ${d9Together(['Saturn','Rahu'],kl)}; '
          'ఇతర పాప/శుభ వర్గాలు స్వతంత్రంగా వర్గీకరించాలి');
      case '6.28':
        return decision(d9At(kl).length>=2,'KL=${name(kl)}లో గ్రహాలు '
          '${list(d9At(kl))}, సంఖ్య ${d9At(kl).length}');
      case '7.6':
        if(ul==null)return null;
        return measured('UL9=${name(at(ul,9))} (${at(ul,9)%2==0?'బేసి':'సరి'}), '
          'KL9=${name(ninth)} (${ninth%2==0?'బేసి':'సరి'}). '
          'జనన లింగం లేదా సంతాన సంఖ్యను దీని ఆధారంగా తేల్చరు');
      case '14.16':
        final nl=d9.ascendantSignIndex;
        return decision([nl,at(nl,5),at(nl,9)].any((s)=>inD9('Mars',s)) ||
          (d9planets['Moon']!=null && [d9planets['Moon']!,at(d9planets['Moon']!,5),
          at(d9planets['Moon']!,9)].any((s)=>inD9('Mars',s))),
          'D9 లగ్నం=${name(nl)}, త్రికోణాలు '
          '${[nl,at(nl,5),at(nl,9)].map(name).join(', ')}, '
          'కుజుడు=${d9planets['Mars']==null?'తెలియదు':name(d9planets['Mars']!)}');
      case '14.17':
        final nl=d9.ascendantSignIndex;
        return decision([nl,at(nl,5),at(nl,9)].any((s)=>inD9('Mercury',s)),
          'D9 లగ్నం ${name(nl)} త్రికోణాల్లో బుధుని స్థానం');
      case '14.18':
        final nl=d9.ascendantSignIndex;
        final mercury=d9planets['Mercury'];
        return decision([nl,at(nl,5),at(nl,9)].any((s)=>inD9('Jupiter',s)) ||
          (mercury!=null && [mercury,at(mercury,5),at(mercury,9)]
          .any((s)=>inD9('Jupiter',s))),
          'D9 త్రికోణాల్లో గురువు / బుధుని త్రికోణంలో గురువు');
      case '14.19': case '14.20': case '14.21':
        final nl=d9.ascendantSignIndex;
        final ps=id=='14.19'?['Venus']:id=='14.20'?['Saturn','Rahu']:['Ketu'];
        final target=<int>{nl,at(nl,5),at(nl,9),if(id=='14.21')at(nl,2)};
        return decision(ps.any((p)=>target.any((s)=>inD9(p,s))),
          'D9 లగ్నం ${name(nl)}, పరిశీలించిన స్థానాలు '
          '${target.map(name).join(', ')}, గ్రహాలు ${ps.join('/')}');
      case '1.31':
        return measured('12 రాశులపై స్వాధిపతి, గురు, బుధ యుతి/రాశిదృష్టి: '
          '${List.generate(12,(s)=> '${name(s)}: ${[signLords[s], 'Jupiter', 'Mercury'].toSet().where((p)=>d1Affects(p,s)).join('/')}').join('; ')}');
      case '1.32':
        final akSign=d1planets[jm.atmakaraka];
        if(akSign==null)return null;
        return measured('AK రాశి=${name(akSign)}; ఇతర రాశ్యధిపతుల '
          'కేంద్ర/పణపర/ఆపోక్లిమ బలం వేర్వేరుగా తూకం వేయాలి');
      case '1.33':
        final found=<String>[];
        for(var s=0;s<12;s+=2){
          if(d1At(s).isNotEmpty&&d1At(at(s,2)).isNotEmpty&&
            d1At(at(s,12)).isNotEmpty)found.add(name(s));
        }
        return decision(found.isNotEmpty,
          'బేసి రాశి, దాని 2వ,12వలో గ్రహాలు ఉన్న రాశులు: ${list(found)}');
      case '3.25':
        return measured('KL=${name(kl)}, చంద్రుడు ${d9planets['Moon']==null?'లేదు':name(d9planets['Moon']!)}, '
          'శుక్రుడు ${d9planets['Venus']==null?'లేదు':name(d9planets['Venus']!)}, '
          'చంద్ర–శుక్ర యుతి ${d9Together(['Moon','Venus'],kl)}, '
          'శుక్ర రాశి/రాశిదృష్టి ప్రత్యామ్నాయాలు మరింత పరిశీలించాలి');
      case '3.34':
        return measured('KL=${name(kl)}, KL2=${name(second)}, '
          'కేతువు ${d9planets['Ketu']==null?'లేదు':name(d9planets['Ketu']!)}, '
          'శని/బుధ/శుక్ర సంబంధాలకు వేర్వేరు మూల ఫలితాలు');
      case '3.48':
        return measured('D9 చంద్రుడు=${d9planets['Moon']==null?'లేదు':name(d9planets['Moon']!)}, '
          'బుధుడు=${d9planets['Mercury']==null?'లేదు':name(d9planets['Mercury']!)}, '
          'శుక్రుడు=${d9planets['Venus']==null?'లేదు':name(d9planets['Venus']!)}. '
          'చంద్ర–బుధ–శుక్ర భాగిక సంబంధాలకు పూర్తి వర్గ ధృవీకరణ ఇంకా అవసరం');
      case '3.58':
        return measured('KL9=${name(ninth)}; కుజుడు '
          '${d9planets['Mars']==null?'లేదు':name(d9planets['Mars']!)}, '
          'శుక్రుడు ${d9planets['Venus']==null?'లేదు':name(d9planets['Venus']!)}; '
          'నిర్దిష్ట వర్గ బలం ఈ జాతకపు D1+D9 ఆధారంతో మాత్రమే తేల్చలేం');
      case '5.4':
        if(al==null)return null;
        final eleventh=at(al,11), twelve=at(al,12);
        final found=d1planets.keys.where((p)=>d1Sees(p,eleventh) &&
          !d1Sees(p,twelve)).toList();
        return decision(found.isNotEmpty,'AL11=${name(eleventh)}కు దృష్టి ఇచ్చి '
          'AL12=${name(twelve)}ను చూడని గ్రహాలు: ${list(found)}');
      case '5.12':
        if(al==null)return null;
        String counts(int origin) => '2వ=${d1At(at(origin,2)).where(malefics.contains).length}, '
          '8వ=${d1At(at(origin,8)).where(malefics.contains).length}';
        bool equals(int origin){
          final p2=d1At(at(origin,2)).where(malefics.contains).length;
          final p8=d1At(at(origin,8)).where(malefics.contains).length;
          return p2>0 && p8>0 && p2==p8;
        }
        return measured('జన్మ లగ్నం ${name(lagna)}: ${counts(lagna)}; '
          'AL=${name(al)}: ${counts(al)}. సమాన పాప సంఖ్య: '
          '${equals(lagna)} / ${equals(al)}; చంద్ర రాశిదృష్టి తీవ్రతను వేరు చేయాలి');
      case '5.38':
        final targets=<int>{lagna,at(lagna,4),at(lagna,5),at(lagna,7),
          at(lagna,9),at(lagna,10)};
        return measured('జన్మ లగ్నం కేంద్ర/త్రికోణాల్లో శుభులు: '
          '${List.generate(12,(s)=>s).where(targets.contains).map((s)=>
             '${name(s)}=${list(d1At(s).where(benefics.contains).toList())}').join('; ')}');
      case '5.39':
        return measured('జన్మ లగ్నం ${name(lagna)}, KL=${name(kl)}; '
          'ఒకే రాశి=${lagna==kl}. లగ్నాధిపతి మరియు AK అధిపతుల '
          'D9 ఉచ్చ బలాన్ని వేరు చేయాలి');
      case '5.40':
        if(al==null)return null;
        final c1=d1At(al).where(benefics.contains).length;
        final c9=d1At(at(al,9)).where(benefics.contains).length;
        return decision(c1>0&&c9>0&&c1==c9,
          'AL=${name(al)}లో శుభులు $c1, AL9=${name(at(al,9))}లో శుభులు $c9');
      case '6.8':
        if(ul==null)return null;
        return decision(d1At(ul).any(benefics.contains)||
          d1At(at(ul,2)).any(benefics.contains),
          'UL=${name(ul)}లో ${list(d1At(ul).where(benefics.contains).toList())}, '
          'UL2లో ${list(d1At(at(ul,2)).where(benefics.contains).toList())}');
      case '6.13': case '6.14': case '6.15': case '6.18':
        if(ul==null)return null;
        return measured('UL=${name(ul)}, UL2=${name(at(ul,2))}; '
          'UL సంబంధిత గ్రహాలు ${list(d1At(ul))} / '
          '${list(d1At(at(ul,2)))}. ప్రతి గ్రహ కలయికకు ప్రత్యేక మూల ఫలితం');
      case '6.21': case '6.22': case '6.23': case '6.24':
        if(ul==null)return null;
        return measured('UL=${name(ul)}లో ${list(d1At(ul))}; '
          'UL2=${name(at(ul,2))}లో ${list(d1At(at(ul,2)))}. '
          'ఇతర 7వ భావ/అధిపతి సంబంధాలను కలిపి చూడాలి');
      case '7.23': case '7.24': case '7.25': case '7.26':
      case '7.27': case '7.28':
        if(ul==null)return null;
        return measured('UL=${name(ul)} నుంచి 3వ ${name(at(ul,3))}: '
          '${list(d1At(at(ul,3)))}, 11వ ${name(at(ul,11))}: '
          '${list(d1At(at(ul,11)))}; జన్మ లగ్నం 3వ '
          '${list(d1At(at(lagna,3)))}, 11వ '
          '${list(d1At(at(lagna,11)))}. సోదరుల ప్రతి శాఖకు '
          'UL, దాని అధిపతి, లగ్న దృష్టుల ప్రత్యేక సమ్మేళనం అవసరం');
      case '14.15':
        final nl=d9.ascendantSignIndex;
        return measured('జన్మ లగ్నం ${name(lagna)}, D9 లగ్నం '
          '${name(nl)}, జన్మ లగ్నం నుంచి D9 లగ్నం '
          '${(nl-lagna+12)%12+1}వది. మూలంలో నాలుగు ప్రత్యేక శాఖలు ఉన్నాయి');
      case '14.24':
        final nl=d9.ascendantSignIndex;
        return measured('జన్మ లగ్న 2వలో కేతు=${inD1('Ketu',at(lagna,2))}, '
          'D9 లగ్నంలో కేతు=${inD9('Ketu',nl)}; '
          'జన్మ తొలి నవాంశ షరతుకు బిందు గణన అవసరం');
      case '14.25': case '14.26':
        return measured('జన్మ లగ్నం ${name(lagna)}పై '
          'రవి దృష్టి ${d1Sees('Sun',lagna)}, '
          'కుజ దృష్టి ${d1Sees('Mars',lagna)}, '
          'ఇతర శుభ ప్రభావం ${list(benefics.where((p)=>d1Affects(p,lagna)).toList())}, '
          'ఇతర పాప ప్రభావం ${list(malefics.where((p)=>d1Affects(p,lagna)).toList())}. '
          'ఇవి స్వభావ అంచనాలకు స్వతంత్ర నిర్ధారణ కావు');
    }
    return null;
  }
}
