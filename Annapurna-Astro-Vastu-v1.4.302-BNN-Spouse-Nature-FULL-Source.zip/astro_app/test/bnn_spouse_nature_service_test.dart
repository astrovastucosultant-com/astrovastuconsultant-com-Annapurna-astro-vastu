import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/services.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_spouse_nature_service.dart';

AstroChartResult natal({int venus = 11, int sun = 0, int jupiter = 10,
    int saturn = 5}) {
  PlanetPosition p(String name, int sign) => PlanetPosition(
    name: name, shortName: name, longitude: sign * 30.0 + 12,
    latitude: 0, speed: 1);
  return AstroChartResult(julianDay: 2450000, ayanamsaDegrees: 24,
    ascendantLongitude: 5,
    planets: [p('Venus',venus),p('Sun',sun),p('Jupiter',jupiter),p('Saturn',saturn)],
    engineVersion:'test');
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('Venus Pisces H03 and H26 share one true predicate', () {
    final result = BnnSpouseNatureService.inspect('venus_in_pisces', natal());
    expect(result.$1, BnnSpouseCheck.matched);
    expect(BnnSpouseNatureService.inspect('venus_in_pisces', natal(venus: 0)).$1,
      BnnSpouseCheck.notMatched);
  });
  test('seventh from Venus is six sign offsets, not seventh offset', () {
    expect(BnnSpouseNatureService.inspect('saturn_seventh_from_venus',
      natal(venus: 11, saturn: 5)).$1, BnnSpouseCheck.matched);
    expect(BnnSpouseNatureService.inspect('saturn_seventh_from_venus',
      natal(venus: 11, saturn: 6)).$1, BnnSpouseCheck.notMatched);
  });
  test('Sun and Jupiter must EACH be adjacent to Venus for H16', () {
    expect(BnnSpouseNatureService.inspect('sun_jupiter_adjacent_to_venus',
      natal(venus:11,sun:0,jupiter:10)).$1, BnnSpouseCheck.matched);
    expect(BnnSpouseNatureService.inspect('sun_jupiter_adjacent_to_venus',
      natal(venus:11,sun:0,jupiter:9)).$1, BnnSpouseCheck.notMatched);
  });
  test('Ambiguous H24 is not a false natal prediction', () {
    expect(BnnSpouseNatureService.inspect(
      'undefined_venus_second_lord_jupiter_aspect', natal()).$1,
      BnnSpouseCheck.needsDefinition);
  });
  test('Missing data remains unavailable instead of FALSE', () {
    const chart = AstroChartResult(julianDay: 0,ayanamsaDegrees: 0,
      ascendantLongitude:0,planets: [],engineVersion:'test');
    expect(BnnSpouseNatureService.inspect('venus_in_pisces',chart).$1,
      BnnSpouseCheck.unavailable);
  });
}
