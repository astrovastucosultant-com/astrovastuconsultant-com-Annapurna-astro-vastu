import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_spouse_nature_service.dart';

/// The same source-based view is shared by BNN relations and D9 marriage UI.
/// All placements come from D1, since the selected BNN rules address natal
/// planetary signs, not the D9 divisional placements.
class BnnSpouseNaturePanel extends StatefulWidget {
  final AstroChartResult natal;
  const BnnSpouseNaturePanel({super.key, required this.natal});

  @override
  State<BnnSpouseNaturePanel> createState() => _BnnSpouseNaturePanelState();
}

class _BnnSpouseNaturePanelState extends State<BnnSpouseNaturePanel> {
  late Future<List<BnnSpouseNatureItem>> _future =
      BnnSpouseNatureService.evaluate(widget.natal);

  @override
  void didUpdateWidget(covariant BnnSpouseNaturePanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.natal != widget.natal) {
      _future = BnnSpouseNatureService.evaluate(widget.natal);
    }
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<BnnSpouseNatureItem>>(
    future: _future,
    builder: (context, snapshot) {
      if (snapshot.hasError) {
        return Text('BNN భార్య స్వభావ నియమాలు లోడ్ కాలేదు: ${snapshot.error}',
            style: const TextStyle(color: Colors.red));
      }
      if (!snapshot.hasData) return const LinearProgressIndicator();
      final all = snapshot.data!;
      final matched = all.where((x) => x.check == BnnSpouseCheck.matched).toList();
      final unresolved = all.where((x) =>
        x.check == BnnSpouseCheck.needsDefinition ||
        x.check == BnnSpouseCheck.unavailable).toList();
      final notMatched = all.where((x) => x.check == BnnSpouseCheck.notMatched).toList();
      return Card(
        color: const Color(0xFFF7F9FB),
        margin: const EdgeInsets.symmetric(vertical: 8),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('BNN — భార్య / జీవిత భాగస్వామి స్వభావ సూచనలు',
                style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            const Text('D1 జన్మ గ్రహస్థానాల ఆధారంగా • మూలగ్రంథ సూచనలు మాత్రమే; '
                'వ్యక్తి నిజ స్వభావం, వృత్తి, విశ్వాసాలకు నిర్ధారణ కాదు. '
                'భార్య గురించి ఉన్న అసలు గ్రంథ వాక్యాలను ఇతర భాగస్వామికి '
                'యథేచ్ఛగా అన్వయించలేదు.',
                style: TextStyle(fontSize: 12.5, color: Color(0xFF5C6470))),
            const SizedBox(height: 9),
            Text('${matched.length} సరిపోయిన IF గుంపులు · '
                '${notMatched.length} సరిపోనివి · '
                '${unresolved.length} పూర్తిగా గణించలేనివి',
                style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            if (matched.isEmpty)
              const Text('ఈ ఆరు మూల నియమాల్లో పూర్తి షరతు సరిపోయిన ఫలితం '
                  'ప్రస్తుతం గుర్తించలేదు. ఇది భాగస్వామి స్వభావం లేదని అర్థం కాదు.'),
            for (final item in matched) _item(item, matched: true),
            if (unresolved.isNotEmpty)
              ExpansionTile(
                initiallyExpanded: false,
                title: Text('పూర్తి IF నిర్వచనం లేనివి (${unresolved.length})'),
                children: unresolved.map((e) => _item(e, matched: false)).toList(),
              ),
            if (notMatched.isNotEmpty)
              ExpansionTile(
                initiallyExpanded: false,
                title: Text('ఈ జాతకానికి సరిపోని నియమాలు (${notMatched.length})'),
                children: notMatched.map((e) => _item(e, matched: false)).toList(),
              ),
          ]),
        ),
      );
    },
  );

  Widget _item(BnnSpouseNatureItem item, {required bool matched}) {
    final color = matched ? const Color(0xFFE4F5EA) : const Color(0xFFF1F2F5);
    final border = matched ? const Color(0xFF82BA98) : const Color(0xFFCED4DC);
    return Card(
      color: color, elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10), side: BorderSide(color: border)),
      child: ExpansionTile(
        key: ValueKey(item.id),
        initiallyExpanded: false,
        title: Text(matched ? item.resultText : item.label,
            style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('Rule ${item.sourceIds} • PDF పేజీ ${item.sourcePages} • ${item.category}',
            style: const TextStyle(fontSize: 12)),
        childrenPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('1 • మూల నియమం', style: TextStyle(fontWeight: FontWeight.w900)),
          for (final rule in item.rules)
            Padding(padding: const EdgeInsets.only(bottom: 4),
              child: Text('${rule.id}: IF ${item.displayedIf(rule)} → THEN ${rule.result} '
                  '(PDF పేజీ ${rule.sourcePage})')),
          const SizedBox(height: 8),
          const Text('2 • జాతక పరిశీలన', style: TextStyle(fontWeight: FontWeight.w900)),
          Text(item.inspection),
          Text(item.methodNote, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 8),
          const Text('3 • ఫలితం', style: TextStyle(fontWeight: FontWeight.w900)),
          Text(matched ? '${item.resultText} (సంప్రదాయ BNN సూచన)' :
              item.check == BnnSpouseCheck.notMatched
                ? 'ఈ నిర్దిష్ట IF సరిపోలలేదు. దీనికి వ్యతిరేక ఫలితాన్ని ప్రకటించలేదు.'
                : 'షరతుకు పూర్తి గణన లేదు; ఫలితం ప్రకటించలేదు.'),
          const SizedBox(height: 8),
          const Text('4 • పరిహారం', style: TextStyle(fontWeight: FontWeight.w900)),
          const Text('ఈ మూల నియమాలకు ధృవీకరించిన పరిహారం లేదు; కల్పించి జోడించలేదు.'),
          const SizedBox(height: 5),
          const Text('మూలపాఠం ఎంపిక చేసిన PDF పేజీతో పోల్చబడింది. '
              '462 నియమాల అసలు డేటా మరియు OCR స్థితులు మార్చలేదు.',
              style: TextStyle(fontSize: 11.5, color: Color(0xFF62666D))),
        ],
      ),
    );
  }
}
