import 'dart:convert';

import 'package:flutter/services.dart';

import 'astro_models.dart';
import 'bnn_master_service.dart';

/// A source-preserving BNN wife/spouse indication module.
/// Important: chart is the *natal D1* chart. Do not feed the D9 varga chart.
/// The predicate never treats a generic planet contact as proof of character.
/// Source text has been visually compared to pages 11, 13 and 14, but the
/// traditional interpretation is not empirically validated.
enum BnnSpouseCheck { matched, notMatched, needsDefinition, unavailable }

class BnnSpouseNatureItem {
  final String id;
  final String category;
  final String label;
  final String methodNote;
  final List<BnnMasterRule> rules;
  final BnnSpouseCheck check;
  final String inspection;
  final Map<String, String> reviewedIf;
  const BnnSpouseNatureItem({
    required this.id, required this.category, required this.label,
    required this.methodNote, required this.rules,
    required this.check, required this.inspection, required this.reviewedIf,
  });
  String displayedIf(BnnMasterRule r) => reviewedIf[r.id] ?? r.condition;
  String get sourceIds => rules.map((r) => r.id).join(' + ');
  String get sourcePages => rules.map((r) => r.sourcePage).toSet().join(', ');
  String get resultText => rules.map((r) => r.result).toSet().join(' • ');
}

class BnnSpouseNatureService {
  static const asset = 'assets/bnn/bnn_spouse_nature_v1.json';

  /// Keyed by source rule rather than duplicated source texts. A single IF
  /// may refer to several source rules; results share a matched predicate.
  static Future<List<BnnSpouseNatureItem>> evaluate(AstroChartResult natal) async {
    final raw = await rootBundle.loadString(asset);
    final root = jsonDecode(raw) as Map<String, dynamic>;
    final candidates = root['entries'] as List<dynamic>;
    final catalog = await BnnMasterCatalog.load();
    final known = {for (final r in catalog) r.id: r};
    final out = <BnnSpouseNatureItem>[];
    for (final any in candidates) {
      final entry = any as Map<String, dynamic>;
      final ids = (entry['source_ids'] as List<dynamic>).cast<String>();
      final pages = (entry['source_pdf_pages'] as List<dynamic>).cast<int>();
      if (ids.isEmpty || ids.length != pages.length) {
        throw FormatException('Invalid source ID/page pairing: ${entry['key']}');
      }
      final rules = <BnnMasterRule>[];
      for (var i = 0; i < ids.length; i++) {
        final rule = known[ids[i]];
        if (rule == null || rule.sourcePage != pages[i] ||
            rule.source != root['source']) {
          throw FormatException('BNN source mismatch ${ids[i]} / PDF page ${pages[i]}');
        }
        rules.add(rule);
      }
      final computed = inspect((entry['operator'] as String), natal);
      out.add(BnnSpouseNatureItem(
        id: entry['key'] as String,
        category: entry['category'] as String,
        label: entry['label'] as String,
        methodNote: entry['method_note'] as String,
        rules: rules,
        check: computed.$1,
        inspection: computed.$2,
        reviewedIf: Map<String, String>.from(
          (root['visually_verified_ocr_corrections'] as Map<String, dynamic>? ?? const {})
              .map((k, v) => MapEntry(k, v.toString()))),
      ));
    }
    if (out.map((r) => r.id).toSet().length != out.length) {
      throw const FormatException('Duplicate BNN spouse evaluator IDs');
    }
    return out;
  }

  static (BnnSpouseCheck, String) inspect(
      String operator, AstroChartResult natal) {
    PlanetPosition? byName(String name) {
      for (final p in natal.planets) {
        if (p.name == name) return p;
      }
      return null;
    }
    final venus = byName('Venus');
    if (venus == null) return (BnnSpouseCheck.unavailable,
        'శుక్రుడి జన్మరాశి అందుబాటులో లేదు. ఫలితం ప్రకటించలేము.');
    String placement(PlanetPosition p) =>
        '${p.name} ${BnnMasterAnalysis.signNames[p.signIndex]} '
        '${p.degreesInSign.toStringAsFixed(2)}°';
    int offset(PlanetPosition a, PlanetPosition b) =>
        (b.signIndex - a.signIndex + 12) % 12;
    bool adjacent(PlanetPosition a, PlanetPosition b) {
      final d = offset(a, b);
      return d == 1 || d == 11;
    }
    switch (operator) {
      case 'venus_in_pisces':
        final matched = venus.signIndex == 11;
        return (matched ? BnnSpouseCheck.matched : BnnSpouseCheck.notMatched,
          '${placement(venus)}. మీనం = 12వ రాశి, ఉచ్చ శుక్ర స్థానము.');
      case 'saturn_seventh_from_venus':
        final saturn = byName('Saturn');
        if (saturn == null) return (BnnSpouseCheck.unavailable, 'శని స్థానం లేదు.');
        final house = offset(venus, saturn) + 1;
        return (house == 7 ? BnnSpouseCheck.matched : BnnSpouseCheck.notMatched,
          '${placement(venus)} • ${placement(saturn)}. '
          'శుక్రుని రాశి నుంచి శని $house వ రాశిలో ఉన్నాడు.');
      case 'adjacent_sign':
        final sun = byName('Sun');
        if (sun == null) return (BnnSpouseCheck.unavailable, 'సూర్య స్థానం లేదు.');
        return (adjacent(venus, sun) ? BnnSpouseCheck.matched : BnnSpouseCheck.notMatched,
          '${placement(venus)} • ${placement(sun)}. '
          'ఇక్కడ పక్కన అంటే ముందరి/తరువాతి పక్కరాశి మాత్రమే.');
      case 'sun_jupiter_adjacent_to_venus':
        final sun = byName('Sun');
        final jupiter = byName('Jupiter');
        if (sun == null || jupiter == null) {
          return (BnnSpouseCheck.unavailable, 'సూర్య లేదా గురు స్థానం లేదు.');
        }
        final sunOk = adjacent(venus, sun);
        final jupOk = adjacent(venus, jupiter);
        return (sunOk && jupOk ? BnnSpouseCheck.matched : BnnSpouseCheck.notMatched,
          '${placement(venus)} • ${placement(sun)} • ${placement(jupiter)}. '
          'సూర్య పక్కరాశి=${sunOk ? 'అవును' : 'కాదు'}, '
          'గురు పక్కరాశి=${jupOk ? 'అవును' : 'కాదు'}.');
      case 'undefined_venus_second_lord_jupiter_aspect':
        return (BnnSpouseCheck.needsDefinition,
          'మూలంలో 2వ భావాధిపతి రిఫరెన్స్ మరియు గురు దృష్టి '
          'పద్ధతి స్పష్టంగా లేదు. సరిపోలిక TRUE/FALSEగా నిర్ణయించలేదు.');
      default:
        return (BnnSpouseCheck.needsDefinition,
          'తెలియని IF operator: $operator. ఫలితం ప్రకటించలేదు.');
    }
  }
}
