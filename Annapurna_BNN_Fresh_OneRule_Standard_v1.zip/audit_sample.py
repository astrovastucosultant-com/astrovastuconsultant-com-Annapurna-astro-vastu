#!/usr/bin/env python3
"""Reference structural audit. It cannot replace page-by-page human verification."""
import json, pathlib, sys
r=json.loads(pathlib.Path(__file__).with_name('assets').joinpath('BNN-NEW-DEMO-001.json').read_text(encoding='utf-8'))
assert r['schema_version']=='ANNAPURNA-BNN-RULE-1.0'
assert r['published'] is False
segs=r['segments']; assert len(segs)==4
ids={s['segment_id'] for s in segs}; assert len(ids)==len(segs)
conditions={'C-01'}
outcomes={x['id'] for x in r['outcomes']}
assert all(s['mapped_to'] and set(s['mapped_to']) <= (conditions if s['kind']=='if' else outcomes) for s in segs)
assert all(x['segment_id'] in ids for x in r['outcomes'])
assert any(x['kind']=='if' for x in segs) and any(x['kind']=='then' for x in segs)
assert all(x.get('source_checked') is False for x in segs)
assert r['source']['pdf_page'] is None
assert not all(r['audit'].values())
print('PASS: all four source segments mapped, source page not invented, NOT published')
