import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import '../lib/bnn_fresh_rule_engine.dart';

void main() {
  final rule = jsonDecode(File('assets/BNN-NEW-DEMO-001.json').readAsStringSync()) as Map<String, dynamic>;
  test('Draft must NOT appear as a released prediction', () {
    final r = BnnFreshRuleEngine.inspect(rule, {'D1': {'Venus': {'sign': 3}}});
    expect(r.status, RuleStatus.reviewRequired);
    expect(r.canShowResult, false);
  });
  test('IF TRUE in a diagnostic test', () {
    final r = BnnFreshRuleEngine.inspect(rule, {'D1': {'Venus': {'sign': 3}}}, publicationMode: false);
    expect(r.status, RuleStatus.matched);
  });
  test('IF FALSE in a diagnostic test', () {
    final r = BnnFreshRuleEngine.inspect(rule, {'D1': {'Venus': {'sign': 2}}}, publicationMode: false);
    expect(r.status, RuleStatus.notMatched);
  });
  test('Missing planet cannot be assumed FALSE', () {
    final r = BnnFreshRuleEngine.inspect(rule, {'D1': {}}, publicationMode: false);
    expect(r.status, RuleStatus.missingInput);
  });
  test('Unimplemented operations cannot return TRUE', () {
    final r = Map<String, dynamic>.from(rule);
    r['conditions'] = {'op': 'nadi_progression', 'chart': 'D1'};
    expect(BnnFreshRuleEngine.inspect(r, {'D1': {}}, publicationMode: false).status, RuleStatus.unsupported);
  });
  test('Exact house distance uses 1-based inclusive count', () {
    final r = Map<String, dynamic>.from(rule);
    r['conditions'] = {'op':'relative_sign_house','chart':'D1','from':'Jupiter','to':'Mars','house':12};
    expect(BnnFreshRuleEngine.inspect(r, {'D1': {'Jupiter':{'sign':3}, 'Mars':{'sign':2}}}, publicationMode: false).status, RuleStatus.matched);
  });
}
