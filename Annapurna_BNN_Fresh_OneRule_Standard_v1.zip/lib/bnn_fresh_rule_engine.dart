// No packages required: paste into lib/bnn/fresh_rule_engine.dart or import
// from a Flutter application. This module is NOT integrated into the app yet.
// Only supported IF operators run. Unknown operators must never be true.

enum RuleStatus { matched, notMatched, missingInput, unsupported, reviewRequired }

class RuleEvaluation {
  const RuleEvaluation(this.status, this.reasons);
  final RuleStatus status;
  final List<String> reasons;
  bool get canShowResult => status == RuleStatus.matched;
}

class BnnFreshRuleEngine {
  // Chart input example: { 'D1': { 'Venus': {'sign': 3, 'degree':11.87} } }
  // Rashi index is 1=Aries,...,12=Pisces; house distance is 1-based.
  static RuleEvaluation inspect(
    Map<String, dynamic> rule,
    Map<String, dynamic> charts, {
    bool publicationMode = true,
  }) {
    if (publicationMode && !isPublishable(rule)) {
      return const RuleEvaluation(RuleStatus.reviewRequired,
          ['మూల ధృవీకరణ / అన్ని భాగాల పరీక్ష / ఆమోదం పూర్తి కాలేదు']);
    }
    final raw = rule['conditions'];
    if (raw is! Map) {
      return const RuleEvaluation(RuleStatus.unsupported, ['IF షరతు లేదు']);
    }
    return _eval(Map<String, dynamic>.from(raw), charts);
  }

  static bool isPublishable(Map<String, dynamic> rule) {
    if (rule['published'] != true) return false;
    final audit = rule['audit'];
    if (audit is! Map) return false;
    const checks = [
      'original_source_verified',
      'all_segments_source_checked',
      'all_conditions_implemented',
      'true_false_missing_tests_pass',
      'chart_recalculation_verified',
      'reviewer_approved',
    ];
    if (!checks.every((k) => audit[k] == true)) return false;
    final source = rule['source'];
    if (source is! Map || source['if_verbatim'] is! String || source['then_verbatim'] is! String) return false;
    if ((source['if_verbatim'] as String).isEmpty || (source['then_verbatim'] as String).isEmpty) return false;
    final segments = rule['segments'];
    if (segments is! List || segments.isEmpty) return false;
    if (!segments.every((s) => s is Map && s['source_checked'] == true && s['mapped_to'] is List && (s['mapped_to'] as List).isNotEmpty)) return false;
    return true;
  }

  static RuleEvaluation _eval(Map<String, dynamic> c, Map<String, dynamic> charts) {
    final op = c['op'];
    if (op == 'all' || op == 'any') {
      final raw = c['children'];
      if (raw is! List || raw.isEmpty || raw.any((x) => x is! Map)) {
        return const RuleEvaluation(RuleStatus.unsupported, ['IF పిల్ల షరతులు లేవు']);
      }
      final parts = raw.map((x) => _eval(Map<String, dynamic>.from(x as Map), charts)).toList();
      if (op == 'all') {
        if (parts.any((r) => r.status == RuleStatus.notMatched)) return const RuleEvaluation(RuleStatus.notMatched, ['AND షరతు FALSE']);
        if (parts.any((r) => r.status == RuleStatus.unsupported)) return const RuleEvaluation(RuleStatus.unsupported, ['ANDలో తెలియని గణన']);
        if (parts.any((r) => r.status == RuleStatus.missingInput)) return const RuleEvaluation(RuleStatus.missingInput, ['ANDకు సమాచారం లేదు']);
        return const RuleEvaluation(RuleStatus.matched, ['AND అన్ని షరతులు TRUE']);
      }
      if (parts.any((r) => r.status == RuleStatus.matched)) return const RuleEvaluation(RuleStatus.matched, ['OR షరతుల్లో కనీసం ఒకటి TRUE']);
      if (parts.any((r) => r.status == RuleStatus.unsupported)) return const RuleEvaluation(RuleStatus.unsupported, ['ORలో తెలియని గణన']);
      if (parts.any((r) => r.status == RuleStatus.missingInput)) return const RuleEvaluation(RuleStatus.missingInput, ['ORకు సమాచారం లేదు']);
      return const RuleEvaluation(RuleStatus.notMatched, ['OR అన్నీ FALSE']);
    }
    if (op == 'not') {
      final child = c['child'];
      if (child is! Map) return const RuleEvaluation(RuleStatus.unsupported, ['NOTకు షరతు లేదు']);
      final r = _eval(Map<String, dynamic>.from(child), charts);
      if (r.status == RuleStatus.matched) return const RuleEvaluation(RuleStatus.notMatched, ['NOT TRUE → FALSE']);
      if (r.status == RuleStatus.notMatched) return const RuleEvaluation(RuleStatus.matched, ['NOT FALSE → TRUE']);
      return r;
    }
    final chartName = c['chart'];
    final map = charts[chartName];
    if (map is! Map) return const RuleEvaluation(RuleStatus.missingInput, ['వర్గ చక్రం అందలేదు']);
    Map<dynamic, dynamic>? position(String planet) {
      final x = map[planet];
      return x is Map ? x : null;
    }
    int? sign(String planet) {
      final v = position(planet)?['sign'];
      if (v is int && v >= 1 && v <= 12) return v;
      return null;
    }
    if (op == 'planet_in_sign') {
      final p = c['planet']; final s = c['sign'];
      if (p is! String || s is! int || s < 1 || s > 12) return const RuleEvaluation(RuleStatus.unsupported, ['తప్పు planet_in_sign షరతు']);
      final actual = sign(p);
      if (actual == null) return RuleEvaluation(RuleStatus.missingInput, ['$p రాశి సమాచారం లేదు']);
      return RuleEvaluation(actual == s ? RuleStatus.matched : RuleStatus.notMatched, ['$p రాశి $actual; కావలసిన రాశి $s']);
    }
    if (op == 'same_sign' || op == 'relative_sign_house') {
      final a = c['from']; final b = c['to'];
      if (a is! String || b is! String) return const RuleEvaluation(RuleStatus.unsupported, ['గ్రహాల పేర్లు లేవు']);
      final sa = sign(a), sb = sign(b);
      if (sa == null || sb == null) return const RuleEvaluation(RuleStatus.missingInput, ['గ్రహ రాశి సమాచారం లేదు']);
      if (op == 'same_sign') return RuleEvaluation(sa == sb ? RuleStatus.matched : RuleStatus.notMatched, ['$a=$sa, $b=$sb']);
      final expected = c['house'];
      if (expected is! int || expected < 1 || expected > 12) return const RuleEvaluation(RuleStatus.unsupported, ['1–12 ఇంటి సంఖ్య అవసరం']);
      final actual = (sb - sa + 12) % 12 + 1;
      return RuleEvaluation(actual == expected ? RuleStatus.matched : RuleStatus.notMatched, ['$a నుంచి $b $actual వ రాశి']);
    }
    if (op == 'degree_between') {
      final p = c['planet']; final low = c['min']; final high = c['max'];
      if (p is! String || low is! num || high is! num || low < 0 || high > 30 || low > high) return const RuleEvaluation(RuleStatus.unsupported, ['డిగ్రీ పరిధి తప్పు']);
      final actual = position(p)?['degree'];
      if (actual is! num) return const RuleEvaluation(RuleStatus.missingInput, ['$p డిగ్రీ సమాచారం లేదు']);
      return RuleEvaluation(actual >= low && actual < high ? RuleStatus.matched : RuleStatus.notMatched, ['$p = $actual°; పరిధి [$low,$high)']);
    }
    return RuleEvaluation(RuleStatus.unsupported, ['ఇంకా అమలు చేయని గణన: $op']);
  }
}
