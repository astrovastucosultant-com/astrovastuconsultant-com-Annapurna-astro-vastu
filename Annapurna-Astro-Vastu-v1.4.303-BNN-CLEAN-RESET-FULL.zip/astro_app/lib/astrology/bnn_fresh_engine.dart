import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';

/// BNN Fresh 1.0 — no OCR/REVIEW records are read by this runtime.
/// Only a complete signed-off source catalogue can become a published asset.
class BnnFreshRule {
  final String id, title, topic, source, thenText, remedy;
  final int pdfPage;
  final int? printedPage;
  final Map<String, dynamic> predicate;
  const BnnFreshRule({required this.id, required this.title, required this.topic,
    required this.source, required this.thenText, required this.remedy,
    required this.pdfPage, required this.printedPage, required this.predicate});
}

class BnnFreshRelease {
  final bool published;
  final List<BnnFreshRule> rules;
  const BnnFreshRelease({required this.published, required this.rules});
  static Future<BnnFreshRelease> load() async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_verified_release.json');
    final doc = jsonDecode(raw) as Map<String, dynamic>;
    if (doc['schema_version'] != 'BNN-FRESH-1.0') {
      throw const FormatException('BNN fresh schema mismatch');
    }
    if (doc['published'] != true) return const BnnFreshRelease(published: false, rules: []);
    final expected = doc['expected_publish_count'] as int;
    final items = (doc['rules'] as List<dynamic>);
    if (expected != 462 || items.length != expected || doc['verified_rule_count'] != expected) {
      throw const FormatException('BNN source coverage not verified');
    }
    final ids = <String>{};
    final list = <BnnFreshRule>[];
    for (final item in items) {
      final r = item as Map<String, dynamic>;
      final id = r['id'] as String;
      final source = r['source'] as String;
      final page = r['pdf_page'] as int;
      final ruleText = r['then'] as String;
      final ifTree = (r['if'] as Map).cast<String, dynamic>();
      if (!ids.add(id) || id.trim().isEmpty || page < 1 || page > 21 ||
        source.trim().isEmpty || ruleText.trim().isEmpty ||
        r['source_text_checked'] != true || r['predicate_checked'] != true ||
        r['chart_test_passed'] != true || !_Predicate.valid(ifTree)) {
        throw FormatException('BNN source validation failed: $id');
      }
      list.add(BnnFreshRule(
        id: id, title: r['title'] as String, topic: r['topic'] as String,
        source: source, pdfPage: page,
        printedPage: r['book_page'] as int?,
        thenText: ruleText, remedy: (r['remedy'] as String?) ?? '',
        predicate: ifTree,
      ));
    }
    return BnnFreshRelease(published: true, rules: List.unmodifiable(list));
  }
}

class BnnFreshHit {
  final BnnFreshRule rule;
  final String evidence;
  const BnnFreshHit(this.rule, this.evidence);
}

class _Predicate {
  static const _names = {'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'};
  static bool _planet(dynamic name) => name is String && _names.contains(name);
  static bool valid(Map<String,dynamic> p) {
    final op=p['op'];
    if (op=='and' || op=='or') {
      final clauses=p['clauses'];
      return clauses is List && clauses.isNotEmpty && clauses.every(
        (c)=> c is Map && valid(c.cast<String,dynamic>()));
    }
    if (op=='same_sign' || op=='adjacent_sign') {
      return _planet(p['a']) && _planet(p['b']);
    }
    if (op=='sign_is') return _planet(p['planet']) && p['sign'] is int && p['sign']>=1 && p['sign']<=12;
    if (op=='relative_house') return _planet(p['from']) && _planet(p['planet']) &&
        p['house'] is int && p['house']>=1 && p['house']<=12;
    return false; // unknown operators are NEVER evaluated as true
  }

  static bool? evaluate(Map<String,dynamic> p, Map<String,int> s) {
    if (!valid(p)) return null;
    final op=p['op'];
    if (op=='and' || op=='or') {
      final list=(p['clauses'] as List).map((v)=>evaluate((v as Map).cast<String,dynamic>(),s)).toList();
      if (op=='and') {
        if (list.contains(false)) return false;
        return list.contains(null)?null:true;
      }
      if (list.contains(true)) return true;
      return list.contains(null)?null:false;
    }
    String a,b;
    if (op=='sign_is') {
      a=p['planet'] as String;
      return s.containsKey(a)? s[a]==p['sign'] : null;
    }
    if (op=='relative_house') {
      a=p['from'] as String; b=p['planet'] as String;
      if (!s.containsKey(a)||!s.containsKey(b)) return null;
      return ((s[b]!-s[a]!+12)%12)+1 == p['house'];
    }
    a=p['a'] as String; b=p['b'] as String;
    if (!s.containsKey(a)||!s.containsKey(b)) return null;
    if (op=='same_sign') return s[a]==s[b];
    final diff=(s[a]!-s[b]!+12)%12;
    return diff==1 || diff==11;
  }
}

class BnnFreshEngine {
  static List<BnnFreshHit> evaluate(BnnFreshRelease release, AstroChartResult chart) {
    if (!release.published) return const [];
    final signs=<String,int>{};
    for (final p in chart.planets) {
      final english=p.name;
      if (_Predicate._names.contains(english)) {
        signs[english]=p.signIndex+1;
      }
    }
    final hits=<BnnFreshHit>[];
    for (final rule in release.rules) {
      final result=_Predicate.evaluate(rule.predicate,signs);
      if (result != true) continue;
      final named=signs.entries.map((p)=>'${p.key}: ${p.value}').join(' • ');
      hits.add(BnnFreshHit(rule,'జన్మ D1 గ్రహరాశులు: $named'));
    }
    return List.unmodifiable(hits);
  }
}
