import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_fresh_engine.dart';
import '../models/birth_data.dart';

/// Replaces the entire legacy BNN UI. The natal chart above is retained.
class BnnMasterPanel extends StatelessWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  const BnnMasterPanel({super.key, required this.chart, required this.birthData});

  @override
  Widget build(BuildContext context) => FutureBuilder<BnnFreshRelease>(
    future: BnnFreshRelease.load(),
    builder: (context,snapshot) {
      if (snapshot.hasError) {
        return const _BnnInfoCard('BNN మూలసంపుటి తనిఖీ విఫలమైంది. ఏ ఫలితాన్నీ ప్రకటించలేదు.');
      }
      if (!snapshot.hasData) {
        return const Padding(padding: EdgeInsets.all(18), child: LinearProgressIndicator());
      }
      final release=snapshot.data!;
      if (!release.published) {
        return const _BnnInfoCard(
          'BNN ట్యాబ్‌ను కొత్తగా ఖాళీ చేశాం. పాత నియమాలు, పాత ఫలితాలు ఇక్కడ లేవు. '
          'కొత్త OCR → మూలపేజీ పరిశీలన → JSON → IF–THEN → జాతక పరీక్షలు పూర్తయిన '
          'నియమసంపుటిని మాత్రమే తరువాత ప్రచురించాలి. జన్మ చక్రం పైన యథాతథంగా ఉంది.');
      }
      final hits=BnnFreshEngine.evaluate(release,chart);
      if (hits.isEmpty) {
        return const _BnnInfoCard('ఈ జాతకానికి విడుదలైన BNN నియమాల్లో పూర్తి IF సరిపోలలేదు. ఇది ప్రతికూల ఫలితం కాదు.');
      }
      return Column(children: [
        Padding(padding: const EdgeInsets.all(8),child: Text('BNN • అన్వయించిన నియమాలు: ${hits.length}',
          style: Theme.of(context).textTheme.titleMedium)),
        for (final hit in hits) Card(
          color:const Color(0xFFE9F6EE),
          child:ExpansionTile(
            title:Text(hit.rule.thenText,style:const TextStyle(fontWeight:FontWeight.bold)),
            subtitle:Text('Rule ID: ${hit.rule.id} • ${hit.rule.topic}'),
            children:[
              ListTile(title:const Text('నియమం / మూలం'), subtitle:Text(
                '${hit.rule.id} • ${hit.rule.source} • PDF పేజీ ${hit.rule.pdfPage}'
                '${hit.rule.printedPage==null?'':' • పుస్తక పేజీ ${hit.rule.printedPage}'}')),
              ListTile(title:const Text('జాతక పరిశీలన'),subtitle:Text(hit.evidence)),
              ListTile(title:const Text('ఫలితం'),subtitle:Text(hit.rule.thenText)),
              if (hit.rule.remedy.trim().isNotEmpty)
                ListTile(title:const Text('మూలాధారిత పరిహారం'),subtitle:Text(hit.rule.remedy)),
            ],
          ),
        ),
      ]);
    },
  );
}

class _BnnInfoCard extends StatelessWidget {
  final String text;
  const _BnnInfoCard(this.text);
  @override
  Widget build(BuildContext context) => Card(
    color:const Color(0xFFF6F1E9),
    child:Padding(padding:const EdgeInsets.all(20),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('BNN — కొత్త మూలాధార రూల్ ఇంజన్',
          style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        const SizedBox(height:12), Text(text,style:const TextStyle(height:1.55)),
      ])),
  );
}
