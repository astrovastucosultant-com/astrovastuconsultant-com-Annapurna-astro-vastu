/// Configurable Western event-significator profiles: traditional
/// interpretive conventions, not validated predictive probabilities.
class WesternEventRuleProfile {
  final String id;
  final String label;
  final List<String> planets;
  final List<String> angles;
  final List<int> houses;
  const WesternEventRuleProfile(this.id,this.label,this.planets,this.angles,this.houses);
}

class WesternEventRuleBook {
  static const profiles = <WesternEventRuleProfile>[
    WesternEventRuleProfile('marriage','Marriage',['Venus','Moon','Jupiter'],['Asc','Desc'],[1,7]),
    WesternEventRuleProfile('career','Career',['Sun','Saturn','Jupiter','Mercury'],['MC'],[2,6,10]),
    WesternEventRuleProfile('children','Children',['Moon','Jupiter','Venus'],['Asc'],[5]),
    WesternEventRuleProfile('property','Property',['Moon','Saturn','Jupiter'],['IC'],[4]),
    WesternEventRuleProfile('education','Education',['Mercury','Jupiter'],['MC'],[3,9]),
    WesternEventRuleProfile('relocation','Relocation',['Moon','Mercury','Jupiter'],['IC','Asc'],[4,9,12]),
    WesternEventRuleProfile('health','Health',['Sun','Moon','Mars','Saturn'],['Asc'],[1,6]),
  ];
  static WesternEventRuleProfile? find(String name) {
    var key=name.toLowerCase().trim();
    if(key=='first child' || key=='second child') key='children';
    for(final p in profiles) {
      if(p.id==key || p.label.toLowerCase()==key) return p;
    }
    return null;
  }
  static bool isRelevant({required String eventType,
    required String moving, required String natal}) {
    final p=find(eventType);
    if(p==null) return false; // Never score unknown event as a generic hit.
    return p.planets.contains(moving) || p.planets.contains(natal) ||
        p.angles.contains(moving) || p.angles.contains(natal);
  }
}


extension WesternEventLookup on WesternEventRuleBook {
  static String? profileForTelugu(String label) {
    if (label.contains('వివాహ') || label.contains('ప్రేమ') || label.contains('నిశ్చితార్థ')) return 'Marriage';
    if (label.contains('సంతాన') || label.contains('గర్భ')) return 'Children';
    if (label.contains('విద్య') || label.contains('పరీక్ష')) return 'Education';
    if (label.contains('ఉద్యోగ') || label.contains('వ్యాపార') || label.contains('ప్రమోషన్') || label.contains('విరమణ') || label.contains('గుర్తింపు')) return 'Career';
    if (label.contains('ఆస్తి') || label.contains('ఇంటి') || label.contains('భూమి') || label.contains('వాహనం')) return 'Property';
    if (label.contains('విదేశ') || label.contains('స్థాన మార్పు')) return 'Relocation';
    if (label.contains('ఆరోగ్య') || label.contains('శస్త్ర') || label.contains('ప్రమాద')) return 'Health';
    return null;
  }
}
