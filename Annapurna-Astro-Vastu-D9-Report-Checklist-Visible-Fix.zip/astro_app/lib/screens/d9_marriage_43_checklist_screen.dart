import 'package:flutter/material.dart';
import '../astrology/marriage_material_registry.dart';

/// Source scope: the 43 IDs supplied by the user. Only rules 04, 07, 08
/// have a usable predicate in the supplied snippet. Never mark other IDs tested.
class D9Marriage43ChecklistScreen extends StatefulWidget {
  const D9Marriage43ChecklistScreen({super.key});
  @override
  State<D9Marriage43ChecklistScreen> createState() => _D9Marriage43ChecklistScreenState();
}

class _D9Marriage43ChecklistScreenState extends State<D9Marriage43ChecklistScreen> {
  static const signs = ['మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య','తులా','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం'];
  static const stars = ['అశ్విని','భరణి','కృత్తిక','రోహిణి','మృగశిర','ఆరుద్ర','పునర్వసు','పుష్యమి','ఆశ్లేష','మఖ','పూర్వాఫల్గుణి','ఉత్తరాఫల్గుణి','హస్త','చిత్త','స్వాతి','విశాఖ','అనురాధ','జ్యేష్ఠ','మూల','పూర్వాషాఢ','ఉత్తరాషాఢ','శ్రవణం','ధనిష్ట','శతభిషం','పూర్వాభాద్ర','ఉత్తరాభాద్ర','రేవతి'];
  static const nadi = <String,List<String>>{
    'ఆది':['అశ్విని','ఆరుద్ర','పునర్వసు','ఉత్తరాఫల్గుణి','హస్త','జ్యేష్ఠ','మూల','శతభిషం','పూర్వాభాద్ర'],
    'మధ్య':['భరణి','మృగశిర','పుష్యమి','మఖ','చిత్త','అనురాధ','పూర్వాషాఢ','ధనిష్ట','ఉత్తరాభాద్ర'],
    'అంత్య':['కృత్తిక','రోహిణి','ఆశ్లేష','పూర్వాఫల్గుణి','స్వాతి','విశాఖ','ఉత్తరాషాఢ','శ్రవణం','రేవతి']
  };
  static const rajju = <String,List<String>>{
    'శిరో':['మృగశిర','చిత్త','ధనిష్ట'],
    'కంఠ':['రోహిణి','ఆరుద్ర','హస్త','స్వాతి','శ్రవణం','శతభిషం'],
    'ఉదర':['కృత్తిక','పునర్వసు','ఉత్తరాఫల్గుణి','విశాఖ','ఉత్తరాషాఢ','పూర్వాభాద్ర'],
    'కటి':['భరణి','పుష్యమి','మఖ','అనురాధ','పూర్వాషాఢ','ఉత్తరాభాద్ర'],
    'పాద':['అశ్విని','ఆశ్లేష','మఖ','జ్యేష్ఠ','మూల','రేవతి']
  };
  static const titles = <String>[
    'జనన దశా–భుక్తి','ప్రస్తుత దశా–భుక్తి','కుజ దోషం','షష్టాష్టకము','చిద్వాదశము',
    'వేధ నక్షత్రాలు','నాడీ కూటము','రజ్జు కూటము','ఘాత కూటము',
    '7వ భావాధిపతి సంబంధం 10','7వ భావాధిపతి సంబంధం 11','7వ భావాధిపతి సంబంధం 12',
    '7వ భావాధిపతి సంబంధం 13','7వ భావాధిపతి సంబంధం 14','7వ భావాధిపతి సంబంధం 15',
    'D7/D9/D30 సంబంధం 16','D7/D9/D30 సంబంధం 17','D7/D9/D30 సంబంధం 18',
    'D7/D9/D30 సంబంధం 19','D7/D9/D30 సంబంధం 20','D7/D9/D30 సంబంధం 21',
    'D7/D9/D30 సంబంధం 22','D7/D9/D30 సంబంధం 23','D7/D9/D30 సంబంధం 24','D7/D9/D30 సంబంధం 25',
    'సబ్‌లార్డ్ / గ్రహ సంబంధం 26','సబ్‌లార్డ్ / గ్రహ సంబంధం 27','సబ్‌లార్డ్ / గ్రహ సంబంధం 28',
    'సబ్‌లార్డ్ / గ్రహ సంబంధం 29','సబ్‌లార్డ్ / గ్రహ సంబంధం 30','సబ్‌లార్డ్ / గ్రహ సంబంధం 31',
    'సబ్‌లార్డ్ / గ్రహ సంబంధం 32','సబ్‌లార్డ్ / గ్రహ సంబంధం 33','సబ్‌లార్డ్ / గ్రహ సంబంధం 34','సబ్‌లార్డ్ / గ్రహ సంబంధం 35',
    'అధునాతన పొంతన నియమం 36','అధునాతన పొంతన నియమం 37','అధునాతన పొంతన నియమం 38',
    'అధునాతన పొంతన నియమం 39','అధునాతన పొంతన నియమం 40','అధునాతన పొంతన నియమం 41',
    'అధునాతన పొంతన నియమం 42','అధునాతన పొంతన నియమం 43',
  ];
  String? groomMoon, brideMoon, groomStar, brideStar;
  bool showChecklist = false;
  String? group(Map<String,List<String>> groups, String star) {
    final found = groups.entries.where((e)=>e.value.contains(star)).map((e)=>e.key).toList();
    return found.length == 1 ? found.single : null;
  }
  Widget pick(String label, String? value, List<String> choices, ValueChanged<String?> change) =>
      Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: DropdownButtonFormField<String>(
        value:value, isExpanded:true, decoration:InputDecoration(labelText:label,border:const OutlineInputBorder()),
        items:choices.map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(),onChanged:(v)=>setState(()=>change(v))));
  @override
  Widget build(BuildContext context) {
    final results = <int,({bool match,String evidence,String outcome})>{};
    if (groomMoon != null && brideMoon != null) {
      final a=signs.indexOf(groomMoon!), b=signs.indexOf(brideMoon!);
      final diff=(b-a+12)%12+1;
      final reverse=(a-b+12)%12+1;
      final match=(diff==6 && reverse==8)||(diff==8 && reverse==6);
      results[4]=(match:match,evidence:'చంద్రరాశులు: $groomMoon / $brideMoon; పరస్పర స్థానాలు $diff / $reverse',outcome:match?'షష్టాష్టక సంబంధం ఉంది':'షష్టాష్టక సంబంధం లేదు');
    }
    if (groomStar != null && brideStar != null) {
      final ng=group(nadi,groomStar!), nb=group(nadi,brideStar!);
      if (ng!=null && nb!=null) results[7]=(match:ng==nb,evidence:'నాడీ: $groomStar — $ng; $brideStar — $nb',outcome:ng==nb?'సమాన నాడీ':'వేర్వేరు నాడీలు');
      final rg=group(rajju,groomStar!), rb=group(rajju,brideStar!);
      if (rg!=null && rb!=null) results[8]=(match:rg==rb,evidence:'రజ్జు: $groomStar — $rg; $brideStar — $rb',outcome:rg==rb?'సమాన రజ్జు':'వేర్వేరు రజ్జులు');
    }
    // Preserve all pre-existing source rules. Merge only two clearly matching
    // source references; do not merge unrelated rules on the basis of ID numbers.
    const sourceAliases = <String,int>{
      'MM-P04-S07':7, 'MM-P04-S08':8,
    };
    final sourceRules = MarriageMaterialRegistry.entries.where(
      (rule) => !sourceAliases.containsKey(rule.id),
    ).toList(growable:false);
    final tested=results.length, matched=results.values.where((x)=>x.match).length;
    final totalRules=43+sourceRules.length;
    return Scaffold(appBar:AppBar(title:const Text('D9 — వివాహ పొంతన: 43 నియమాలు')),
      body:ListView(padding:const EdgeInsets.all(14),children:[
        const Text('వరుడు–వధువు వివరాలు',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
        Text('కొత్త 43 నియమాలు + పాత వివాహ నియమాలు: మొత్తం $totalRules ప్రత్యేక అంశాలు. ఒకే మూల నియమం నిర్ధారితమైనప్పుడు మాత్రమే కలిపి చూపిస్తున్నాం.'),
        pick('వరుడు చంద్రరాశి',groomMoon,signs,(v)=>groomMoon=v),
        pick('వధువు చంద్రరాశి',brideMoon,signs,(v)=>brideMoon=v),
        pick('వరుడు జన్మనక్షత్రం',groomStar,stars,(v)=>groomStar=v),
        pick('వధువు జన్మనక్షత్రం',brideStar,stars,(v)=>brideStar=v),
        const SizedBox(height:8),
        Card(child:ListTile(title:const Text('వివాహ నియమాల పూర్తి చెక్‌లిస్ట్',style:TextStyle(fontWeight:FontWeight.bold)),
          subtitle:Text('మొత్తం: $totalRules • గణించినవి: $tested • వర్తించినవి: $matched • వర్తించనివి: ${tested-matched} • గణన ఇంకా లేనివి: ${totalRules-tested}'),
          trailing:Icon(showChecklist?Icons.expand_less:Icons.expand_more),onTap:()=>setState(()=>showChecklist=!showChecklist))),
        if(showChecklist) const Padding(padding:EdgeInsets.all(8),child:Text('కొత్త 43 నియమాలు',style:TextStyle(fontWeight:FontWeight.bold))),
        if(showChecklist) for(var i=1;i<=43;i++) Builder(builder:(context){
          final r=results[i];final id='Rule-${i.toString().padLeft(2,'0')}';
          return Card(child:ExpansionTile(
            leading:Icon(r==null?Icons.remove_circle_outline:r.match?Icons.check_circle:Icons.radio_button_unchecked,
              color:r==null?Colors.grey:r.match?Colors.green:Colors.blueGrey),
            title:Text('$id — ${titles[i-1]}'),
            subtitle:Text(r==null?'ఈ కోడ్‌లో పూర్తి గణన షరతు లేదు':r.match?'నియమం వర్తించింది':'వర్తించలేదు'),
            children:[Padding(padding:const EdgeInsets.all(12),child:Align(alignment:Alignment.centerLeft,
              child:Text(r==null?'ఈ Rule ID మాత్రమే మూల కోడ్‌లో ఉంది. గణించినట్లు లెక్కించలేదు.':
                'జాతక పరిశీలన: ${r.evidence}\nఫలితం: ${r.outcome}\nస్థితి: ${r.match?'వర్తించింది':'వర్తించలేదు'}')))]));
        }),
        if(showChecklist) const Padding(padding:EdgeInsets.all(8),child:Text('ఇప్పటికే ఉన్న వివాహ నియమాలు (మూలాలు భద్రపరచబడ్డాయి)',style:TextStyle(fontWeight:FontWeight.bold))),
        if(showChecklist) for(final rule in sourceRules) Card(child:ExpansionTile(
          leading:const Icon(Icons.remove_circle_outline,color:Colors.grey),
          title:Text('${rule.id} — ${rule.topic}'),
          subtitle:const Text('నియమం నమోదైంది • ఆటోమేటిక్ జాతక పరిశీలన నిర్ధారించలేదు'),
          children:[Padding(padding:const EdgeInsets.all(12),child:Align(
            alignment:Alignment.centerLeft,
            child:Text('మూలం: ${MarriageMaterialRegistry.sourceName} • పేజీ ${rule.page}\nచక్రాలు: ${rule.factors.map((n)=>'D$n').join(', ')}\nవివరణ: ${rule.note}\nగణన స్థితి: పూర్తి షరతుల ధృవీకరణ అవసరం'),
          ))],
        )),
      ]));
  }
}
