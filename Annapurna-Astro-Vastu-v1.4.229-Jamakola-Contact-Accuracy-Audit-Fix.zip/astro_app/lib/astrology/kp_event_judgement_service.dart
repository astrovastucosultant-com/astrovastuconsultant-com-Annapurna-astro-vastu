import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:sweph/sweph.dart';
import '../models/birth_data.dart';
import 'astro_calculation_service.dart';
import 'dasha_service.dart';
import 'kp_service.dart';

/// Event house references extracted from user's 20-page KP table.
/// Source event rows are not (by themselves) fully verified prediction rules.
class KpEventRule {
  final String id;
  final String name;
  final String category;
  final int? mainHouse;
  final String mainHouseSource;
  final List<int> supporting;
  final String supportingSource;
  final int page;
  final int printedPage;
  final bool highStakes;
  final bool requiresReview;

  const KpEventRule({required this.id, required this.name,
    required this.category, required this.mainHouse,
    required this.mainHouseSource, required this.supporting,
    required this.supportingSource, required this.page,
    required this.printedPage, required this.highStakes,
    required this.requiresReview});

  factory KpEventRule.fromJson(Map<String,dynamic> x) => KpEventRule(
    id: x['id']?.toString() ?? '',
    name: x['event_en']?.toString() ?? '',
    category: x['topic_te']?.toString() ?? 'ఇతర అంశాలు',
    mainHouse: (x['main_house_number'] as num?)?.toInt(),
    mainHouseSource: x['main_house_as_printed']?.toString() ?? '',
    supporting: ((x['supporting_houses_parsed_partial'] as List?) ?? [])
      .whereType<num>().map((v)=>v.toInt()).where((n)=>n>=1&&n<=12).toList(),
    supportingSource: x['supporting_houses_original']?.toString() ?? '',
    page: (x['source_pdf_page'] as num?)?.toInt() ?? 0,
    printedPage: (x['source_printed_page'] as num?)?.toInt() ?? 0,
    highStakes: x['high_stakes_caution'] == true,
    requiresReview: x['review_status'] != 'source_transcribed',
  );

  @override String toString() => name;
}

class KpEventRuleCatalog {
  static Future<List<KpEventRule>> load() async {
    final decoded=jsonDecode(await rootBundle.loadString('assets/kp/kp_events_414.json')) as Map<String,dynamic>;
    return ((decoded['event_rules'] as List).cast<Map<String,dynamic>>())
      .map(KpEventRule.fromJson).toList(growable:false);
  }
}

class KpHoraryEventResult {
  final KpEventRule event;
  final int number;
  final DateTime questionUtc;
  final double latitude, longitude;
  final KpChartDetails chart;
  final String relevantSubLord;
  final Map<int,List<String>> evidences;
  final List<int> cslHouses;
  final List<int> matchedHouses;
  final bool mainConnected;
  final bool supportConnected;
  final String decision;
  final String explanation;
  final bool provisionalPositive;
  final bool sourceReview;

  const KpHoraryEventResult({required this.event,required this.number,
    required this.questionUtc,required this.latitude,required this.longitude,
    required this.chart,required this.relevantSubLord,required this.evidences,
    required this.cslHouses,required this.matchedHouses,
    required this.mainConnected,required this.supportConnected,
    required this.decision, required this.explanation,
    required this.provisionalPositive,required this.sourceReview});
}

/// Preliminary KP horary analysis.
/// The Horary number defines the FIRST cusp; Placidus cusps are obtained by
/// matching an equivalent local sidereal time at the question latitude.
/// Planet positions ALWAYS use the actual question timestamp (not the
/// equivalent Placidus geometry timestamp). Natal cusps are never reused.
/// RP and Dasa–Bhukti–Anthra/transit timing are NOT assumed to be verified.
class KpHoraryEventService {
  static double _norm(double d)=>(d%360+360)%360;
  static double _diff(double a,double b) {
    final v=(_norm(a-b)+180)%360-180;
    return v.abs();
  }
  static double _julday(DateTime u) {
    final dt=u.toUtc();
    final hour=dt.hour+dt.minute/60+dt.second/3600+
      dt.millisecond/3600000;
    return Sweph.swe_julday(dt.year,dt.month,dt.day,hour,CalendarType.SE_GREG_CAL);
  }
  static List<double> _houseValues(double jd,double lat,double lon) {
    final values=Sweph.swe_houses_ex(jd,SwephFlag.SEFLG_SIDEREAL,lat,lon,Hsys.P).cusps;
    if(values.length!=12&&values.length!=13)throw StateError('KP Placidus cusps not available');
    return List<double>.generate(12,(i)=>_norm(values[values.length==13?i+1:i]));
  }

  static Future<KpChartDetails> calculateHoraryChart({required int number,
    required DateTime questionUtc,required double latitude,
    required double longitude}) async {
    if(!latitude.isFinite||latitude.abs()>66.5||!longitude.isFinite||longitude.abs()>180) {
      throw ArgumentError('Placidus: latitude must be within ±66.5°, longitude within ±180°');
    }
    await AstroCalculationService.initialize();
    if(!AstroCalculationService.isInitialized)throw StateError('Swiss Ephemeris unavailable');
    final jd=_julday(questionUtc);
    Sweph.swe_set_sid_mode(SiderealMode.SE_SIDM_KRISHNAMURTI,
      SiderealModeFlag.SE_SIDBIT_NONE,0.0,0.0);
    final targetEntry=KpService.horaryNumber(number);
    final target=(targetEntry.startLongitude+targetEntry.endLongitude)/2;
    // Search a sidereal day for the Placidus chart geometry corresponding
    // to the first cusp fixed by number. This is NOT a birth-time shift.
    const steps=240;
    final siderealDay=0.9972695663;
    double bestOffset=0, bestDiff=1e9;
    for(int i=0;i<=steps;i++){
      final offset=i*siderealDay/steps;
      final asc=_houseValues(jd+offset,latitude,longitude).first;
      final d=_diff(asc,target);
      if(d<bestDiff){bestDiff=d;bestOffset=offset;}
    }
    double span=siderealDay/steps;
    for(var iteration=0;iteration<22;iteration++) {
      final left=bestOffset-span;
      final right=bestOffset+span;
      final l=_diff(_houseValues(jd+left,latitude,longitude).first,target);
      final m=_diff(_houseValues(jd+bestOffset,latitude,longitude).first,target);
      final r=_diff(_houseValues(jd+right,latitude,longitude).first,target);
      if(l<m&&l<=r){bestOffset=left;bestDiff=l;}
      else if(r<m&&r<=l){bestOffset=right;bestDiff=r;}
      else {bestDiff=m;}
      span/=2;
    }
    if(bestDiff>0.025)throw StateError('Horary ascendant alignment not accurate');
    final cuspDegrees=_houseValues(jd+bestOffset,latitude,longitude);
    final cusps=List<KpStellarPosition>.generate(12,
      (i)=>KpService.forLongitude('Cusp ${i+1}',cuspDegrees[i]));
    // Preserve the number-defined cusp exactly (midpoint inside the sub).
    cusps[0]=KpService.forLongitude('Cusp 1',target);
    final bodies=<HeavenlyBody,String>{
      HeavenlyBody.SE_SUN:'Sun',HeavenlyBody.SE_MOON:'Moon',
      HeavenlyBody.SE_MARS:'Mars',HeavenlyBody.SE_MERCURY:'Mercury',
      HeavenlyBody.SE_JUPITER:'Jupiter',HeavenlyBody.SE_VENUS:'Venus',
      HeavenlyBody.SE_SATURN:'Saturn',HeavenlyBody.SE_TRUE_NODE:'Rahu',
    };
    final flags=SwephFlag.SEFLG_MOSEPH|SwephFlag.SEFLG_SIDEREAL|SwephFlag.SEFLG_SPEED;
    final planets=<KpStellarPosition>[];
    double? rahu;
    for (final body in bodies.entries) {
      final pos=Sweph.swe_calc_ut(jd,body.key,flags).longitude;
      if(!pos.isFinite)throw StateError('KP planet longitude not finite');
      planets.add(KpService.forLongitude(body.value,pos));
      if(body.value=='Rahu')rahu=pos;
    }
    if(rahu==null)throw StateError('Rahu longitude absent');
    planets.add(KpService.forLongitude('Ketu',rahu+180));
    return KpChartDetails(planets:List.unmodifiable(planets),
      cusps:List.unmodifiable(cusps),ayanamsaDegrees:Sweph.swe_get_ayanamsa_ut(jd));
  }

  static int? _houseOf(KpStellarPosition p,List<KpStellarPosition> cusps){
    final v=_norm(p.longitude);
    for(var i=0;i<12;i++){
      final start=_norm(cusps[i].longitude);
      final end=_norm(cusps[(i+1)%12].longitude);
      final arc=_norm(end-start);
      final from=_norm(v-start);
      if(arc>0&&from<arc)return i+1;
    }
    return null;
  }

  static Future<KpHoraryEventResult> judge({required KpEventRule event,
    required int number,required DateTime questionUtc,
    required double latitude,required double longitude}) async {
    final chart=await calculateHoraryChart(number:number,questionUtc:questionUtc,
      latitude:latitude,longitude:longitude);
    final occupants=<int,List<String>>{
      for(var i=1;i<=12;i++)i:<String>[]
    };
    for(final p in chart.planets){
      final h=_houseOf(p,chart.cusps);
      if(h!=null)occupants[h]!.add(p.body);
    }
    final main=event.mainHouse;
    final csl=main==null?'':chart.cusps[main-1].subLord;
    final planet=chart.planets.where((p)=>p.body==csl).firstOrNull;
    final evidence=<int,List<String>>{};
    final cslHouses=<int>[];
    if(planet!=null){
      for(var i=1;i<=12;i++){
        final e=<String>[];
        final houseOccupants=occupants[i]!;
        if(houseOccupants.contains(planet.starLord))e.add('నక్షత్రాధిపతి ${planet.starLord} ${i}వ భావంలో');
        if(houseOccupants.contains(planet.body))e.add('$csl ${i}వ భావంలో');
        if(chart.cusps[i-1].signLord==planet.starLord)e.add('నక్షత్రాధిపతి ${planet.starLord} ${i}వ భావాధిపతి');
        if(chart.cusps[i-1].signLord==csl)e.add('$csl ${i}వ భావాధిపతి');
        if(e.isNotEmpty){evidence[i]=e;cslHouses.add(i);}
      }
    }
    final targets={if(main!=null)main,...event.supporting};
    final matches=cslHouses.where(targets.contains).toList()..sort();
    final mainMatch=main!=null&&cslHouses.contains(main);
    final supportMatch=event.supporting.any(cslHouses.contains);
    final hasExtraCondition=RegExp(r'[A-Za-z]').hasMatch(event.supportingSource);
    final incomplete=main==null||event.requiresReview||hasExtraCondition;
    final provisional=mainMatch&&supportMatch&&!incomplete;
    final status=main==null?'మూలంలో ప్రధాన భావం సంఖ్య స్పష్టం కాదు — మాన్యువల్ పరిశీలన':
      incomplete?'అదనపు గ్రహ/రాశి షరతులు — ధృవీకరణ పెండింగ్':
      provisional?'ప్రాథమిక KP భావ మద్దతు ఉంది — తుది Promise ఇంకా కాదు':
      'Cusp Sub-Lordతో నిర్దేశిత భావ మద్దతు పూర్తిగా కనిపించలేదు';
    final explain='Cusp ${main??"?"} Sub-Lord: ${csl.isEmpty?"తెలియదు":csl}. '
      'సూచించే భావాలు: ${cslHouses.isEmpty?"కనిపించలేదు":cslHouses.join(", ")}. '
      'మూల ప్రధాన భావం: ${event.mainHouseSource}. సహాయక భావాలు: ${event.supportingSource}. '
      'మూల పుస్తక 6 భాగాల నిర్ణయక్రమంలో పూర్తి గ్రహ/రాహు-కేతు, వ్యతిరేక భావాలు, '
      'దశా–భుక్తి–అంతర, Ruling Planets, Transit cross-check ఇంకా అవసరం.';
    return KpHoraryEventResult(event:event,number:number,
      questionUtc:questionUtc,latitude:latitude,longitude:longitude,
      chart:chart,relevantSubLord:csl,evidences:evidence,
      cslHouses:cslHouses,matchedHouses:matches,
      mainConnected:mainMatch,supportConnected:supportMatch,
      decision:status,explanation:explain,provisionalPositive:provisional,
      sourceReview:incomplete);
  }
}
