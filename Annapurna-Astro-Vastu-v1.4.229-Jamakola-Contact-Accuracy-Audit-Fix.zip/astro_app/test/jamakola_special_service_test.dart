import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/jamakola_special_service.dart';

void main() {
  test('clock Arudam matches printed reference 08:28:10 => 169 degrees', () {
    final a=JamakolaSpecialService.arudamFromClock(DateTime(2026,10,23,8,28,10));
    expect(a,closeTo(169.0,0.000001));
  });

  test('Jama 23 October 2026 08:28:10 Friday: Friday Venus at zero 06:00', () {
    final r=JamakolaSpecialService.jamaFromLocalClock(DateTime(2026,10,23,8,28,10));
    expect(r.length,8);
    expect(r.first.name,'Sun');
    expect(r.first.longitude,closeTo(105+55/60,0.00001));
    expect(r[4].name,'Venus');
    expect(r[4].longitude,closeTo(285+55/60,0.00001));
    for(var i=1;i<8;i++) {
      expect(JamakolaSpecialService.norm(r[i-1].longitude-r[i].longitude),
          closeTo(45.0,0.0000001));
    }
  });

  test('Before 06:00 previous weekday lord governs Jamakkol ring', () {
    final r=JamakolaSpecialService.jamaFromLocalClock(DateTime(2026,9,15,5,58,24));
    expect(r[6].name,'Moon');
    expect(r[6].longitude,closeTo(0.8,0.00001));
    expect(r[0].longitude,closeTo(270.8,0.00001));
  });


  test('Divya Chakshu screenshot 24 Oct 2026 17:50: eight Jama grahas', () {
    final r=JamakolaSpecialService.jamaFromLocalClock(DateTime(2026,10,24,17,50));
    const expected=<String,double>{
      'Sun':230,'Mars':185,'Jupiter':140,'Mercury':95,
      'Venus':50,'Saturn':5,'Moon':320,'Snake':275,
    };
    for (final position in r) {
      expect(position.longitude,closeTo(expected[position.name]!,0.000001));
    }
    expect(JamakolaSpecialService.arudamFromClock(DateTime(2026,10,24,17,50)),
      closeTo(300.0,0.000001));
  });

  test('Veedhi anchor Mesha: public fixture Meena Arudam, Simha Udhayam => Kanni Kavippu', () {
    final k=JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:147+17/60, arudam:350+24/60, anchorSignIndex:0);
    expect(k,closeTo(159+36/60,0.00001));
  });

  test('Veedhi anchor Mesha: public fixture Makara Arudam, Thula Udhayam => Makara Kavippu', () {
    final k=JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:195+12/60, arudam:273+54/60, anchorSignIndex:0);
    expect(k,closeTo(296+6/60,0.00001));
  });

  test('Veedhi anchor Mesha: public fixture Rishaba Arudam, Mithuna Udhayam => Rishaba Kavippu', () {
    final k=JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:84+12/60, arudam:40+54/60, anchorSignIndex:0);
    expect(k,closeTo(49+6/60,0.00001));
  });

  test('bad Veedhi anchor cannot silently return a Kavippu result', () {
    expect(() => JamakolaSpecialService.kavippuFromVeedhiAnchor(
      udhayam:200,arudam:100,anchorSignIndex:12),throwsArgumentError);
  });

  test('Wednesday 10:30 2026-09-16 source fixture at 0 Sun', () {
    final r=JamakolaSpecialService.jamaFromLocalClock(DateTime(2026,9,16,10,30));
    expect(r[0].longitude,closeTo(0.0,0.0000001));
    expect(r[3].longitude,closeTo(225.0,0.0000001));
  });

  test('Jama-Udayam relative motion: verified contact direction and minutes', () {
    final contacts=JamakolaSpecialService.contactsWithinSegment(
      udhayam:100,
      jamaGrahas:const [
        JamaRingPosition('Sun',99),   // past one minute
        JamaRingPosition('Mars',110), // future ten minutes
        JamaRingPosition('Jupiter',150), // too far for 30 minute horizon
      ],
      segmentMinutes:720,
      elapsedMinutes:360,
    );
    expect(contacts.length,2);
    expect(contacts[0].planet,'Sun');
    expect(contacts[0].minutesFromJudgement,closeTo(-1,0.00001));
    expect(contacts[1].planet,'Mars');
    expect(contacts[1].minutesFromJudgement,closeTo(10,0.00001));
  });

  test('Contacts never assume movement across sunrise/sunset seam', () {
    final contacts=JamakolaSpecialService.contactsWithinSegment(
      udhayam:100,
      jamaGrahas:const [JamaRingPosition('Sun',99),
                        JamaRingPosition('Mars',110)],
      segmentMinutes:720,
      elapsedMinutes:0.25,
    );
    expect(contacts.length,1);
    expect(contacts.single.planet,'Mars');
    expect(contacts.single.minutesFromJudgement,closeTo(10,0.00001));
  });

  test('Exact coincidence yields one contact at judgement time', () {
    final contacts=JamakolaSpecialService.contactsWithinSegment(
      udhayam:200, jamaGrahas:const [JamaRingPosition('Saturn',200)],
      segmentMinutes:600,elapsedMinutes:100,
    );
    expect(contacts.length,1);
    expect(contacts.single.minutesFromJudgement,0);
  });

}
