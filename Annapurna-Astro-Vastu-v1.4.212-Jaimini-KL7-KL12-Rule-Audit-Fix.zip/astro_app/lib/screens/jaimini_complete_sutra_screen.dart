import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/jaimini_service.dart';
import '../astrology/jaimini_complete_sutra_service.dart';

/// Dedicated, searchable 46-page Jaimini IF/THEN reference catalog.
/// All rules are visible; only explicitly implemented predicates may show a
/// chart match. Other source rules remain pending, never false confirmations.
class JaiminiCompleteSutraScreen extends StatefulWidget {
  final AstroChartResult chart;
  final JaiminiResult jaimini;

  const JaiminiCompleteSutraScreen({
    super.key,
    required this.chart,
    required this.jaimini,
  });

  @override
  State<JaiminiCompleteSutraScreen> createState() =>
      _JaiminiCompleteSutraScreenState();
}

class _JaiminiCompleteSutraScreenState extends State<JaiminiCompleteSutraScreen> {
  late final Future<List<JaiminiCompleteSutraRule>> _future;
  String _query = '';
  String _category = 'అన్ని అంశాలు';
  String _statusFilter = 'all';
  double? _minutesSinceLocalSunrise;
  final Map<String, JaiminiRuleCheck> _cachedChecks = {};

  @override
  void initState() {
    super.initState();
    _future = JaiminiCompleteSutraService.load();
  }

  JaiminiRuleCheck _check(JaiminiCompleteSutraRule rule) =>
      _cachedChecks.putIfAbsent(rule.id, () =>
          JaiminiCompleteSutraService.check(
            rule: rule,
            chart: widget.chart,
            jaimini: widget.jaimini,
            minutesSinceLocalSunrise: _minutesSinceLocalSunrise,
          ));

  @override
  void didUpdateWidget(covariant JaiminiCompleteSutraScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.chart != widget.chart ||
        oldWidget.jaimini != widget.jaimini) {
      _cachedChecks.clear();
    }
  }

  void _showRule(JaiminiCompleteSutraRule rule, JaiminiRuleCheck audit) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (context) => DefaultTabController(
        length: 3,
        child: SafeArea(
          child: SizedBox(
            height: MediaQuery.of(context).size.height * 0.85,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 12),
                Center(child: Container(
                  height: 4, width: 44,
                  decoration: BoxDecoration(
                    color: const Color(0xFF806F73),
                    borderRadius: BorderRadius.circular(4),
                  ),
                )),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 4),
                  child: Text('JAI-${rule.id} · ${rule.section}',
                    maxLines: 3, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 18)),
                ),
                const TabBar(
                  labelColor: Color(0xFF832E46),
                  tabs: [
                    Tab(text: 'ఫలితం'),
                    Tab(text: 'పరిశీలన'),
                    Tab(text: 'పరిహారం'),
                  ],
                ),
                Expanded(child: TabBarView(children: [
                  ListView(padding: const EdgeInsets.all(20), children: [
                    Text(_statusText(audit),
                      style: TextStyle(fontWeight: FontWeight.w800,
                        color: _statusColor(audit), fontSize: 16)),
                    const SizedBox(height: 18),
                    const Text('ఈ జాతకంలో లభించిన ఆధారం',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 7),
                    Text(audit.evidence, style: const TextStyle(height: 1.5)),
                    const SizedBox(height: 18),
                    const Text('PDFలోని మూల నియమం (ఆధార వివరణ)',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 7),
                    Text('IF: ${rule.condition}', style: const TextStyle(height: 1.5)),
                    const SizedBox(height: 12),
                    Text('THEN (సాధ్యమైన మూల ఫలితం; జాతక నిర్ధారణ కాదు): ${rule.result}',
                      style: const TextStyle(height: 1.5)),
                    const SizedBox(height: 18),
                    if (audit.matched != true && !audit.calculated)
                      const Text('ఇది వ్యక్తిగతంగా నిర్ధారించిన ఫలితం కాదు. '
                        'కేవలం PDFలోని నియమ వివరణ మాత్రమే.',
                        style: TextStyle(color: Color(0xFF855E21))),
                    if (audit.matched == false)
                      const Text('పరీక్షించిన సూచికకు షరతు సరిపోలేదు. మూల THENను ఈ జాతకంలో '
                        'జరిగిన లేదా జరగబోయే ఫలితంగా చెప్పరాదు. నియమంలోని ఇతర సూచనా రాశులు '
                        'లేదా శాఖలను ఇంకా పరిశీలించాల్సి ఉండవచ్చు.',
                        style: TextStyle(color: Color(0xFF92505C))),
                    if (audit.calculated)
                      const Text('సూత్ర గణన లేదా మూలపద్ధతి పరిశీలన మాత్రమే జరిగింది. ఇది వ్యక్తిగత శుభ/అశుభ '
                        'ఫలిత నిర్ధారణ కాదు.',
                        style: TextStyle(color: Color(0xFF316D87))),
                    if (audit.matched == true)
                      const Text('ప్రాథమిక గ్రహస్థాన షరతు సరిపోయింది. '
                        'మిగిలిన ఆధారాలు, శుభ–పాప సంబంధాలు, దశలు చూసిన తరువాతే తుది ఫలితం.',
                        style: TextStyle(color: Color(0xFF166C50))),
                  ]),
                  ListView(padding: const EdgeInsets.all(20), children: [
                    const Text('జాతక పరిశీలన',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                    const SizedBox(height: 10),
                    Text(audit.evidence, style: const TextStyle(height: 1.55)),
                    const SizedBox(height: 20),
                    const Text('మూల ప్రమాణం',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text('అధ్యాయం.పాదం.సూత్రం (PDF సూచిక): ${rule.source}'),
                    Text('అంశం: ${rule.major}'),
                    Text('విభాగం: ${rule.section}'),
                    Text('అందించిన PDF పేజీ: ${rule.page} / 46'),
                    Text('వర్గం: ${rule.sourceKind}'),
                    const SizedBox(height: 14),
                    const Text('ఈ PDF తెలుగు IF–THEN సమాహారం. అసలు సంస్కృత '
                        'శ్లోకం, వ్యాఖ్యాన భేదాల స్వతంత్ర ధృవీకరణ ఇంకా పెండింగ్.',
                        style: TextStyle(color: Color(0xFF7B5A35))),
                  ]),
                  ListView(padding: const EdgeInsets.all(20), children: const [
                    Text('పరిహారం / మూలం',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                    SizedBox(height: 10),
                    Text('మీరు ఇచ్చిన 46 పేజీల జైమిని IF–THEN PDFలో '
                         'ఈ నియమానికి ప్రత్యేకంగా ధృవీకరించిన పరిహారం ఇవ్వలేదు. '
                         'అందువల్ల కల్పిత మంత్రం, పూజ లేదా రత్న పరిహారం ఇవ్వడం లేదు.',
                         style: TextStyle(height: 1.5)),
                    SizedBox(height: 12),
                    Text('ప్రత్యేక పరిహార మూలగ్రంథం అనుసంధానించినప్పుడు '
                         'మూలం, షరతు, పరిహార విధానం చూపించవచ్చు.',
                         style: TextStyle(height: 1.5)),
                  ]),
                ])),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _statusText(JaiminiRuleCheck check) =>
      check.calculated ? 'గణన / ఆధార పరిశీలన మాత్రమే · తుది ఫలితం కాదు' :
      check.matched == null ? 'పూర్తి షరతుల పరిశీలన పెండింగ్' :
      check.matched! ? 'పరీక్షించిన ప్రాథమిక షరతు సరిపోయింది · తుది ఫలితం కాదు' :
      'పరీక్షించిన షరతు సరిపోలేదు · ఇతర సూచికలు వేరుగా పరిశీలించాలి';

  Color _statusColor(JaiminiRuleCheck check) =>
      check.calculated ? const Color(0xFF316D87) :
      check.matched == null ? const Color(0xFF806356) :
      check.matched! ? const Color(0xFF117349) :
      const Color(0xFF92505C);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('జైమిని సంపూర్ణ నియమాలు')),
      body: FutureBuilder<List<JaiminiCompleteSutraRule>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text(
            'నియమాల జాబితాను తెరవలేకపోయాం: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final all = snapshot.data!;
          final categories = ['అన్ని అంశాలు',
            ...{for (final rule in all) rule.major}];
          final q = _query.trim().toLowerCase();
          final filtered = all.where((rule) {
            if (_category != 'అన్ని అంశాలు' && rule.major != _category) return false;
            if (q.isNotEmpty && !('${rule.id} ${rule.major} '
                 '${rule.section} ${rule.condition} ${rule.result} ${rule.source}')
                   .toLowerCase().contains(q)) return false;
            final check = _check(rule);
            switch (_statusFilter) {
              case 'matched':
                if (check.calculated || check.matched != true) return false;
                break;
              case 'notMatched':
                if (check.calculated || check.matched != false) return false;
                break;
              case 'calculated':
                if (!check.calculated) return false;
                break;
              case 'pending':
                if (check.calculated || check.matched != null) return false;
                break;
            }
            return true;
          }).toList(growable: false);
          final checks = {for (final r in all) r.id: _check(r)};
          final matchedCount = checks.values.where((c) => c.matched == true).length;
          final notMatchedCount = checks.values.where((c) => c.matched == false).length;
          final calculatedCount = checks.values.where((c) => c.calculated).length;
          final pendingCount = all.length - matchedCount - notMatchedCount - calculatedCount;
          return Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
              child: TextField(
                onChanged: (s) => setState(() => _query = s),
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  hintText: 'అంశం / గ్రహం / ఫలితం / సూత్రం వెతకండి',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: DropdownButtonFormField<String>(
                value: _category,
                isExpanded: true,
                items: categories.map((name) => DropdownMenuItem(
                  value: name,
                  child: Text(name, overflow: TextOverflow.ellipsis),
                )).toList(),
                onChanged: (v) => setState(() => _category = v ?? 'అన్ని అంశాలు'),
                decoration: const InputDecoration(labelText: 'అంశాలవారీ విభాగం'),
              ),
            ),
            ExpansionTile(
              title: const Text('ప్రత్యేక లగ్నాలకు సూర్యోదయ సమాచారం (ఐచ్ఛికం)',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
              subtitle: Text(_minutesSinceLocalSunrise == null
                  ? 'స్థానిక సూర్యోదయం తెలియకపోతే 2.8–2.12, 2.15 పెండింగ్‌లో ఉంటాయి'
                  : 'సూర్యోదయం తర్వాత $_minutesSinceLocalSunrise నిమిషాలు · ఈ సంఖ్యను ధృవీకరించండి',
                style: const TextStyle(fontSize: 11)),
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
                  child: TextField(
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'జననానికి ముందు స్థానిక సూర్యోదయం నుంచి నిమిషాలు',
                      hintText: 'ఉదా: సూర్యోదయం 06:00, జననం 09:00 → 180',
                    ),
                    onChanged: (raw) {
                      final parsed = double.tryParse(raw.trim());
                      final valid = parsed != null && parsed.isFinite &&
                          parsed >= 0 && parsed < 1440 ? parsed : null;
                      setState(() {
                        _minutesSinceLocalSunrise = valid;
                        _cachedChecks.clear();
                      });
                    },
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 0, 16, 10),
                  child: Text('సూర్యోదయం = జన్మస్థలానికి వర్తించే స్థానిక సూర్యోదయం. '
                    'జనన సమయం లేదా సూర్యోదయం ఊహించి ఇవ్వవద్దు. '
                    'సాధారణ సూర్యోదయ గణన లేకపోతే ఖాళీగా ఉంచండి. '
                    'ఈ లెక్కలు తుది సంఘటనల సమయం కావు.',
                    style: TextStyle(fontSize: 11, height: 1.4)),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
              child: Text(
                'నమోదైన నియమాలు ${all.length} · సరిపోయిన ప్రాథమిక షరతులు $matchedCount · '
                'సరిపోని పరీక్షలు $notMatchedCount\n'
                'గణన/ఆధారం మాత్రమే $calculatedCount · ఇంకా పెండింగ్ $pendingCount\n'
                'పూర్తి వ్యక్తిగత ఫలితాలు 514/514 నిర్ధారించబడలేదు',
                style: const TextStyle(fontSize: 12.5, height: 1.5,
                  fontWeight: FontWeight.w600),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 4),
              child: DropdownButtonFormField<String>(
                value: _statusFilter,
                isExpanded: true,
                decoration: InputDecoration(
                  labelText: 'పరిశీలన స్థితి · కనిపిస్తున్నవి ${filtered.length}/${all.length}',
                  border: const OutlineInputBorder(),
                ),
                items: [
                  DropdownMenuItem(value: 'all', child: Text('అన్ని నియమాలు (${all.length})')),
                  DropdownMenuItem(value: 'matched', child: Text('ప్రాథమిక షరతు సరిపోయినవి ($matchedCount)')),
                  DropdownMenuItem(value: 'notMatched', child: Text('షరతు సరిపోనివి ($notMatchedCount)')),
                  DropdownMenuItem(value: 'calculated', child: Text('గణన / ఆధార పరిశీలన మాత్రమే ($calculatedCount)')),
                  DropdownMenuItem(value: 'pending', child: Text('పెండింగ్ ($pendingCount)')),
                ],
                onChanged: (value) =>
                    setState(() => _statusFilter = value ?? 'all'),
              ),
            ),
            Expanded(child: ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (context, index) {
                final rule = filtered[index];
                final check = _check(rule);
                return ListTile(
                  leading: Icon(
                    check.calculated ? Icons.calculate_outlined :
                    check.matched == true ? Icons.check_circle_outline :
                    check.matched == false ? Icons.cancel_outlined : Icons.menu_book_outlined,
                    color: _statusColor(check),
                  ),
                  title: Text('JAI-${rule.id} • ${rule.result}',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${rule.section}\n${_statusText(check)} · PDF పేజీ ${rule.page}'),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showRule(rule, check),
                );
              },
            )),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Text('✓ = పరీక్షించిన ప్రాథమిక సూచిక సరిపోయింది; × = పరీక్షించిన సూచిక సరిపోలేదు; '
                'కాలిక్యులేటర్ = గణన మాత్రమే; పుస్తకం = పెండింగ్. '
                'ఏ గుర్తూ తుది వ్యక్తిగత ఫలిత ధృవీకరణ కాదు.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, color: Color(0xFF755C62))),
            ),
          ]);
        },
      ),
    );
  }
}
