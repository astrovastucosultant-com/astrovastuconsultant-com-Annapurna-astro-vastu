import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../models/birth_data.dart';
import '../astrology/d10_vrutti_activation_service.dart';
import '../astrology/d10_vrutti_match_engine.dart';
import '../astrology/d10_vrutti_rule_registry.dart';
import '../astrology/d10_profession_registry.dart';
import 'd10_legacy_profession_tile.dart';

/// D10 → profession IF–THEN evidence screen.  The result tile itself opens
/// the birth-chart assessment, source rule and evidence breakdown.
class D10VruttiRulesScreen extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;
  const D10VruttiRulesScreen({super.key, required this.chart, required this.birthData});

  @override
  State<D10VruttiRulesScreen> createState() => _D10VruttiRulesScreenState();
}

class _D10VruttiRulesScreenState extends State<D10VruttiRulesScreen> {
  String _category = 'అన్ని రంగాలు';
  // 0 = all 517 entries, 1 = fully confirmed, 2 = IF-THEN, 3 = original 181.
  int _viewMode = 0;
  String _query = '';
  late final List<D10VruttiMatch> _matches =
      D10VruttiMatchEngine.evaluate(widget.chart);
  final Map<String, Future<List<D10VruttiActivation>>> _activationTasks = {};
  final Map<String, List<D10VruttiActivation>> _activationResults = {};
  bool _loadingRecommended = false;

  Future<List<D10VruttiActivation>> _activationFor(D10VruttiMatch item) {
    if (!item.complete || !item.confirmed) {
      return Future.value(const <D10VruttiActivation>[]);
    }
    return _activationTasks.putIfAbsent(item.rule.id, () async {
      final result = await D10VruttiActivationService.findWindows(
        chart: widget.chart,
        birthData: widget.birthData,
        rule: item.rule,
        professionConfirmed: item.confirmed && item.complete,
      );
      if (mounted) setState(() => _activationResults[item.rule.id] = result);
      return result;
    });
  }

  Future<void> _loadRecommendedAges() async {
    if (_loadingRecommended) return;
    setState(() => _loadingRecommended = true);
    try {
      final candidates = _matches.where((m) => m.confirmed && m.complete).take(8);
      for (final item in candidates) {
        if (!mounted) break;
        await _activationFor(item);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('గోచార గణన అందుబాటులో లేదు: $e'),
        ));
      }
    } finally {
      if (mounted) setState(() => _loadingRecommended = false);
    }
  }


  void _showDetail(D10VruttiMatch item) {
    showModalBottomSheet<void>(
      context: context, isScrollControlled: true,
      builder: (context) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: .80,
          child: ListView(padding: const EdgeInsets.all(18), children: [
            Text('${item.rule.id} · ${item.rule.profession}',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            Text('జాతక అనుకూలత ఆధారాల సరిపోలిక: ${item.percent}%',
                style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(item.complete
                ? '✅ IF–THEN మూల షరతులు సరిపోయాయి (జ్యోతిష సూచన మాత్రమే)'
                : item.confirmed
                    ? '⚠️ కొన్ని ఉపషరతులు సరిపోలలేదు / పెండింగ్'
                    : '⛔ D1 → D10 confirm లేదు — తుది వృత్తి సిఫార్సు కాదు'),
            const Divider(),
            const Text('వృత్తి యాక్టివేషన్ — వయసు / దశ / అంతర్దశ / గోచారం',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 6),
            if (!item.complete || !item.confirmed)
              const Text('వృత్తి ప్రధాన D1 → D10 IF–THEN confirm లేదు. '
                  'నిర్ధారణ లేని వృత్తికి యాక్టివేషన్ వయసు చూపించరు.'),
            if (item.complete && item.confirmed)
              FutureBuilder<List<D10VruttiActivation>>(
                future: _activationFor(item),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Text('Swiss Ephemeris / గోచార గణన విఫలమైంది: ${snapshot.error}');
                  }
                  if (!snapshot.hasData) {
                    return const ListTile(
                      leading: CircularProgressIndicator(),
                      title: Text('వింశోత్తరి MD/AD + గురు/శని గోచారం పరిశీలిస్తోంది…'),
                    );
                  }
                  final windows = snapshot.data!;
                  if (windows.isEmpty) {
                    return const Text('తదుపరి 20 సంవత్సరాల నెలవారీ పరిశీలనలో '
                        'ప్రధాన గ్రహం–మహాదశ–అంతర్దశ–గురు/శని గోచారం నాలుగు '
                        'ఆధారాలు ఒకే నెలలో కలిసిన కాలం దొరకలేదు. '
                        'అందువల్ల వయసు నిర్ధారించలేదు.');
                  }
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      for (final w in windows) Card(
                        child: Padding(
                          padding: const EdgeInsets.all(9),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('సుమారు ${w.ageYears} ఏళ్ల వయసు · ${w.month.month}/${w.month.year}',
                                  style: const TextStyle(fontWeight: FontWeight.w800)),
                              Text('మహాదశ ${w.mahadasha} / అంతర్దశ ${w.antardasha}'),
                              for (final line in w.evidence)
                                Text('• $line', style: const TextStyle(fontSize: 12.5)),
                            ],
                          ),
                        ),
                      ),
                      const Text('నెల 15న గోచార నమూనా; ఇది సుమారు కాలసూచన, '
                          'ఖచ్చిత వృత్తి నియామక తేదీ లేదా హామీ కాదు.',
                          style: TextStyle(fontSize: 12)),
                    ],
                  );
                },
              ),
            const Divider(),
            const Text('జాతక పరిశీలన',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 6),
            for (final evidence in item.passed)
              ListTile(dense: true, leading: const Icon(Icons.check_circle_outline,
                  color: Colors.green), title: Text(evidence)),
            for (final reason in item.failed)
              ListTile(dense: true, leading: const Icon(Icons.cancel_outlined,
                  color: Colors.redAccent), title: Text(reason)),
            for (final reason in item.pending)
              ListTile(dense: true, leading: const Icon(Icons.info_outline,
                  color: Colors.orange), title: Text(reason)),
            const Divider(),
            const Text('మూల IF–THEN రూల్',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            const SizedBox(height: 6),
            SelectableText('IF ${item.rule.condition}\nTHEN ${item.rule.profession}',
                style: const TextStyle(height: 1.5)),
            Text('మూలం: ${item.rule.source} · పేజీ ${item.rule.page}',
                style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 12),
            const Text('శాతం = అందుబాటులో ఉన్న జ్యోతిష షరతుల సరిపోలిక మాత్రమే. '
                'వృత్తిలో విజయం లేదా నియామకం జరిగే సంభావ్యత కాదు.'),
          ]),
        ),
      ),
    );
  }

  Widget _resultTile(D10VruttiMatch item) =>
      Card(
        color: item.complete && item.confirmed
            ? const Color(0xFFEAF7EE) : null,
        child: ListTile(
          title: Text('${item.rule.profession}  •  ${item.percent}%',
              style: const TextStyle(fontWeight: FontWeight.w700)),
          subtitle: Text('${item.rule.id} · ${item.rule.category} · '
              '${item.complete ? 'నిర్ధారిత ఉపషరతులు' : item.confirmed ? 'పాక్షిక ఆధారాలు' : 'confirm లేదు'}'
              '${_activationResults.containsKey(item.rule.id) ? (_activationResults[item.rule.id]!.isNotEmpty ? ' · సుమారు ${_activationResults[item.rule.id]!.first.ageYears} ఏళ్లలో కాలమద్దతు' : ' · కాలమద్దతు కనిపించలేదు') : ' · వయసు చూడటానికి టచ్'}'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => _showDetail(item),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final cats = <String>{'అన్ని రంగాలు',
      ...d10VruttiRulebook.map((r) => r.category),
      ...d10ProfessionRules.map((r) => r.category)}.toList();
    final confirmed = _matches.where((m) => m.complete && m.confirmed).toList();
    final entries = (_viewMode == 3 ? <D10VruttiMatch>[] :
        _viewMode == 1 ? confirmed : _matches).where((item) {
      return (_category == 'అన్ని రంగాలు' || item.rule.category == _category) &&
          (_query.isEmpty || item.rule.profession.contains(_query) ||
           item.rule.condition.contains(_query));
    }).toList();
    final legacyEntries = (_viewMode == 0 || _viewMode == 3)
        ? d10ProfessionRules.where((r) =>
            (_category == 'అన్ని రంగాలు' || r.category == _category) &&
            (_query.isEmpty || r.name.contains(_query) ||
                r.extra.contains(_query))).toList()
        : <D10ProfessionRule>[];

    return Scaffold(
      appBar: AppBar(title: const Text('D10 — వృత్తి IF–THEN & అనుకూలత %')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        const Text('ప్రతి వృత్తికి D1 10వ గ్రహం → D10 1/10/10వ అధిపతి confirm, '
            'అంశ దేవత, గ్రహ సంబంధాలు, భావాలు, శని విధానం వేరుగా పరీక్షించబడతాయి.',
            style: TextStyle(height: 1.4)),
        const SizedBox(height: 8),
        Text('IF–THEN ${_matches.length} + పాత D10 ${d10ProfessionRules.length} '
            '= ${_matches.length + d10ProfessionRules.length} మొత్తం నమోదులు · '
            'పూర్తిగా సరిపోలినవి: ${confirmed.length}',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: confirmed.isEmpty || _loadingRecommended ? null : _loadRecommendedAges,
          icon: _loadingRecommended
              ? const SizedBox(width: 18, height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.calendar_month_outlined),
          label: Text(_loadingRecommended
              ? 'మొదటి 8 అనుకూల వృత్తుల వయసు పరిశీలిస్తోంది…'
              : 'అనుకూల వృత్తుల యాక్టివేషన్ వయసు చూడండి'),
        ),
        const SizedBox(height: 8),
        const ExpansionTile(
          title: Text('D10 పది అంశదేవతల క్రమం & గ్రహ పదాల వివరణ'),
          children: [
            ListTile(title: Text('బేసి రాశులు: ఇంద్ర, అగ్ని, యమ, రాక్షస, వరుణ, వాయు, కుబేర, ఈశాన, బ్రహ్మ, అనంత.')),
            ListTile(title: Text('సరి రాశులు: అనంత, బ్రహ్మ, ఈశాన, కుబేర, వాయు, వరుణ, రాక్షస, యమ, అగ్ని, ఇంద్ర.')),
            ListTile(title: Text('మూల PDFలో సూర్య దేవత = సూర్యుడు, శుక్ర దేవత = శుక్రుడు; ఇవి పదకొండో, పన్నెండో అంశదేవతలు కావు.')),
          ],
        ),
        const SizedBox(height: 8),
        Wrap(spacing: 7, runSpacing: 5, children: [
          ChoiceChip(label: Text('అన్ని (${_matches.length + d10ProfessionRules.length})'),
              selected: _viewMode == 0,
              onSelected: (_) => setState(() => _viewMode = 0)),
          ChoiceChip(label: Text('అనుకూల (${confirmed.length})'),
              selected: _viewMode == 1,
              onSelected: (_) => setState(() => _viewMode = 1)),
          ChoiceChip(label: Text('IF–THEN (${_matches.length})'),
              selected: _viewMode == 2,
              onSelected: (_) => setState(() => _viewMode = 2)),
          ChoiceChip(label: Text('పాత వృత్తులు (${d10ProfessionRules.length})'),
              selected: _viewMode == 3,
              onSelected: (_) => setState(() => _viewMode = 3)),
        ]),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: _category,
          isExpanded: true,
          decoration: const InputDecoration(
              labelText: 'వృత్తి రంగం', border: OutlineInputBorder()),
          items: cats.map((c) => DropdownMenuItem<String>(
              value: c, child: Text(c, overflow: TextOverflow.ellipsis)))
              .toList(),
          onChanged: (v) => setState(() => _category = v ?? 'అన్ని రంగాలు'),
        ),
        const SizedBox(height: 8),
        TextField(
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search),
              hintText: 'వృత్తి పేరు / IF–THEN షరతు వెతకండి',
              border: OutlineInputBorder()),
          onChanged: (v) => setState(() => _query = v.trim()),
        ),
        const SizedBox(height: 8),
        if (_viewMode == 1 && confirmed.isEmpty)
          const Card(child: Padding(padding: EdgeInsets.all(14),
            child: Text('పూర్తిగా Confirm అయిన వృత్తి ఇప్పటికి లేదు. '
                'కానీ పాత నియమాలను తొలగించలేదు — అన్ని / పాత వృత్తులు చూడండి.'))),
        if (legacyEntries.isNotEmpty) ...[
          const Padding(padding: EdgeInsets.symmetric(vertical: 8),
            child: Text('పాత D10 వృత్తులు — IF–THEN లేకపోయినా కనిపిస్తాయి',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
          for (final item in legacyEntries)
            D10LegacyProfessionTile(rule: item, chart: widget.chart),
        ],
        if (entries.isNotEmpty) ...[
          const Padding(padding: EdgeInsets.symmetric(vertical: 8),
            child: Text('D10 — పూర్తి IF–THEN నియమాలు',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
          for (final item in entries) _resultTile(item),
        ],
        if (entries.isEmpty && legacyEntries.isEmpty &&
            !(_viewMode == 1 && confirmed.isEmpty))
          const Padding(padding: EdgeInsets.all(14),
              child: Text('ఈ ఫిల్టర్‌లో ఏ వృత్తీ లేదు. అన్ని ట్యాబ్‌కు మార్చండి.')),
        const SizedBox(height: 12),
        const Text('వృత్తి అనుకూలత % మరియు కాలనిర్ణయం వేరు. కాలానికి ప్రధాన గ్రహం–వింశోత్తరి '
            'మహాదశ–అంతర్దశ–గురు/శని గోచారం ఒకే నెలలో కలిసినప్పుడు మాత్రమే సుమారు వయసు చూపిస్తాము.'),
        const SizedBox(height: 8),
        const Text('గమనిక: 100% అంటే నియమాల షరతులు పూర్తిగా సరిపోయాయని మాత్రమే. '
            'ఇది ఉద్యోగం/వ్యాపారం విజయ శాతం కాదు. మూల రూల్‌లోని ఒకే '
            'సూర్యుడు లేదా శుక్రుడు రెండుసార్లు లెక్కించబడరు.',
            style: TextStyle(color: Colors.black54)),
      ]),
    );
  }
}
