import 'astro_models.dart';
import 'panchadha_maitri_service.dart';
import 'varga_service.dart';

/// Cross-varga *inspection*, not a replacement for sourced outcome rules.
/// Every observation is a testable placement/aspect/lordship fact. None of
/// these observations alone can certify an event, a desire, or a remedy.
enum VargaInspectionTone { supportive, challenging, contextual }

class VargaInspectionSignal {
  final String id;
  final String title;
  final String evidence;
  final VargaInspectionTone tone;
  final String? planet;
  const VargaInspectionSignal(this.id, this.title, this.evidence,
      this.tone, {this.planet});
}

class VargaHouseInspection {
  final int number;
  final String title;
  final String lord;
  final int? lordHouse;
  final List<VargaInspectionSignal> signals;
  const VargaHouseInspection({
    required this.number,
    required this.title,
    required this.lord,
    required this.lordHouse,
    required this.signals,
  });

  int get supports => signals.where((s) =>
      s.tone == VargaInspectionTone.supportive).length;
  int get challenges => signals.where((s) =>
      s.tone == VargaInspectionTone.challenging).length;
  bool get mixed => supports > 0 && challenges > 0;

  /// Optional user-example index (NOT a classical or probabilistic strength).
  /// It is shown only if a supported base placement is detected. Same planet
  /// appearing in several checks is counted at most once per polarity;
  /// conflicting signs from the same planet cancel out in this index.
  int? get experimentalIndex {
    final base = signals.any((s) =>
        s.id == 'USER-VARGA-WEALTH-2L' ||
        s.id.startsWith('USER-VARGA-KENDRA-TRIKONA-'));
    if (!base) return null;
    final positive = signals.where((s) =>
        s.tone == VargaInspectionTone.supportive && s.planet != null)
        .map((s) => s.planet!).toSet();
    final negative = signals.where((s) =>
        s.tone == VargaInspectionTone.challenging && s.planet != null)
        .map((s) => s.planet!).toSet();
    return 100 + 20 * positive.difference(negative).length
        - 20 * negative.difference(positive).length;
  }

  /// Separate earning indications from retention; counts are NOT a percent.
  /// This verdict does not override any source's fully matched IF–THEN result.
  String get evidenceVerdict {
    if (mixed) return 'శుభ–పాప ఆధారాలు రెండూ ఉన్నాయి';
    if (supports > 0) return 'అనుకూల ఆధారాలు ఉన్నాయి';
    if (challenges > 0) return 'ఆటంక సూచనలు ఉన్నాయి';
    return 'ప్రాథమిక గ్రహస్థితి మాత్రమే; తుది నిర్ణయం లేదు';
  }
}

class VargaMasterInspection {
  final VargaChartData chart;
  final VargaHouseInspection lagna;
  final List<VargaHouseInspection> subjects;
  final String warning;
  const VargaMasterInspection({
    required this.chart,
    required this.lagna,
    required this.subjects,
    required this.warning,
  });

  /// All selected houses, not only the varga ascendant. This is a
  /// placement-level synopsis and never certifies a sourced event result.
  Iterable<VargaInspectionSignal> get overallSignals sync* {
    yield* lagna.signals;
    for (final subject in subjects) {
      yield* subject.signals;
    }
  }

  int get overallSupports => overallSignals.where(
      (s) => s.tone == VargaInspectionTone.supportive).length;
  int get overallChallenges => overallSignals.where(
      (s) => s.tone == VargaInspectionTone.challenging).length;

  String get overallEvidenceVerdict {
    if (overallSupports > 0 && overallChallenges > 0) {
      return 'శుభ–పాప గ్రహస్థితి ఆధారాలు రెండూ ఉన్నాయి';
    }
    if (overallSupports > 0) return 'సహాయక గ్రహస్థితి ఆధారాలు ఉన్నాయి';
    if (overallChallenges > 0) return 'ఆటంక గ్రహస్థితి ఆధారాలు ఉన్నాయి';
    return 'గ్రహస్థితి మాత్రమే; తుది ఫలితం నిర్ణయించలేదు';
  }
}

class VargaMasterInspectionService {
  static const signLords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];
  static const grahaTelugu = <String, String>{
    'Sun': 'సూర్యుడు', 'Moon': 'చంద్రుడు', 'Mars': 'కుజుడు',
    'Mercury': 'బుధుడు', 'Jupiter': 'గురుడు', 'Venus': 'శుక్రుడు',
    'Saturn': 'శని', 'Rahu': 'రాహువు', 'Ketu': 'కేతువు',
  };
  static const houseNames = <int, String>{
    1: 'లగ్నం / స్వప్రయత్నం', 2: 'ధనం / నిల్వ',
    3: 'సహోదరులు / ధైర్యం', 4: 'ఇల్లు / సుఖం',
    5: 'సంతానం / బుద్ధి', 6: 'సేవ / ఆటంకాలు',
    7: 'భాగస్వామ్యం', 8: 'అవరోధాలు / మార్పు',
    9: 'భాగ్యం / ధర్మం', 10: 'వృత్తి / కర్మ',
    11: 'లాభం / ఆదాయం', 12: 'వ్యయం / నష్టం',
  };
  // Relevant *inspection* houses, not a universal prediction rule.
  // D24 choices follow the user's 4H/9H/2H/7H education levels.
  static const focusHouses = <int, List<int>>{
    1: [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    2: [2, 11, 12], 3: [3, 6], 4: [4, 11],
    7: [5, 7], 9: [7, 9], 10: [10, 6, 7, 2, 11],
    12: [4, 9], 16: [4, 11], 20: [9, 5],
    24: [4, 9, 2, 7], 27: [1, 6, 8],
    30: [6, 8, 12], 40: [4], 45: [9], 60: [1, 9],
  };

  /// Parashari graha drishti (Rahu/Ketu drishti is method-dependent and not
  /// assumed). No Rashi Drishti is mixed into these rules.
  static bool grahaAspects(String name, int fromSign, int targetSign) {
    const standard = <int>{7};
    final offsets = switch (name) {
      'Mars' => const <int>{4, 7, 8},
      'Jupiter' => const <int>{5, 7, 9},
      'Saturn' => const <int>{3, 7, 10},
      'Sun' || 'Moon' || 'Mercury' || 'Venus' => standard,
      _ => const <int>{},
    };
    return offsets.contains((targetSign - fromSign + 12) % 12 + 1);
  }

  static VargaInspectionTone nature(String planet, AstroChartResult natal,
      Map<String, int> vargaSigns) {
    // Natural benefic/malefic is distinct from *functional* house lordship.
    if (planet == 'Jupiter' || planet == 'Venus') {
      return VargaInspectionTone.supportive;
    }
    if (planet == 'Sun' || planet == 'Mars' || planet == 'Saturn' ||
        planet == 'Rahu' || planet == 'Ketu') {
      return VargaInspectionTone.challenging;
    }
    if (planet == 'Moon') {
      final sun = natal.planets.where((p) => p.name == 'Sun');
      final moon = natal.planets.where((p) => p.name == 'Moon');
      if (sun.isEmpty || moon.isEmpty) return VargaInspectionTone.contextual;
      final elongation = (moon.first.longitude - sun.first.longitude + 360) % 360;
      // The Moon's phase is treated as supplementary evidence, not a ruling.
      return elongation > 0 && elongation < 180
          ? VargaInspectionTone.supportive
          : VargaInspectionTone.challenging;
    }
    if (planet == 'Mercury') {
      final mercurySign = vargaSigns['Mercury'];
      if (mercurySign == null) return VargaInspectionTone.contextual;
      // Conjunct malefic/benefic influences may conflict. Leave Mercury
      // neutral here rather than fabricate an unambiguous judgement.
      return VargaInspectionTone.contextual;
    }
    return VargaInspectionTone.contextual;
  }

  static VargaMasterInspection inspect(AstroChartResult natal, int factor,
      {D16CalculationMethod d16Method = D16CalculationMethod.parashara}) {
    if (!VargaService.definitions.any((d) => d.factor == factor)) {
      throw ArgumentError('Unsupported varga D$factor');
    }
    if (!natal.ascendantLongitude.isFinite ||
        natal.planets.any((p) => !p.longitude.isFinite)) {
      throw ArgumentError('అసంపూర్ణ గ్రహ డిగ్రీలు — పరిశీలన చేయలేము.');
    }
    final chart = VargaService.calculate(natal, factor, d16Method: d16Method);
    final signs = <String, int>{for (final p in chart.planets) p.name: p.signIndex};
    final asc = chart.ascendantSignIndex;
    int signOf(int house) => (asc + house - 1) % 12;
    int houseOfSign(int sign) => (sign - asc + 12) % 12 + 1;
    int? houseOfPlanet(String planet) => signs[planet] == null
        ? null : houseOfSign(signs[planet]!);
    String te(String name) => grahaTelugu[name] ?? name;

    VargaHouseInspection examine(int house) {
      final targetSign = signOf(house);
      final lord = signLords[targetSign];
      final lordSign = signs[lord];
      final lordHouse = houseOfPlanet(lord);
      final signals = <VargaInspectionSignal>[];
      void add(String id, String heading, String evidence,
          VargaInspectionTone tone, {String? planet}) {
        signals.add(VargaInspectionSignal(
          'USER-VARGA-$id', heading, evidence, tone, planet: planet));
      }

      if (lordSign == null) {
        add('DATA-$house', 'అధిపతి గణన లేదు', '$lord స్థానం లేదు.',
            VargaInspectionTone.contextual);
      } else {
        add('LORD-PLACE-$house', 'భావాధిపతి స్థానం',
            '${te(lord)} ${lordHouse}వ భావంలో ఉన్నారు.',
            VargaInspectionTone.contextual, planet: lord);
        if (house == 2 && const <int>{2, 4, 5, 9, 10, 11}.contains(lordHouse)) {
          add('WEALTH-2L', '2వ అధిపతి అనుకూల స్థానంలో',
              'మీరు సూచించిన 2,4,5,9,10,11 స్థానాలలో $lordHouse ఉంది. '
              'ఇది ధన సంపాదనకు సహాయక పరిశీలన; నిల్వను 11/12 కూడా నిర్ణయిస్తాయి.',
              VargaInspectionTone.supportive, planet: lord);
        } else if (const <int>{1, 4, 5, 7, 9, 10}.contains(lordHouse)) {
          add('KENDRA-TRIKONA-$house', 'కేంద్ర / త్రికోణ స్థితి',
              '${te(lord)} $lordHouse భావంలో ఉన్నారు; '
              'ఇది ఆధార సూచన మాత్రమే, స్వయంగా ఫలిత నిర్ధారణ కాదు.',
              VargaInspectionTone.supportive, planet: lord);
        }
        if (const <int>{6, 8, 12}.contains(lordHouse)) {
          add('DUSTHANA-$house', '6/8/12 భావ సంబంధం',
              '${te(lord)} $lordHouse భావంలో ఉన్నారు. విపరీత / ఇతర '
              'మినహాయింపు యోగాల పరిశీలన కూడా అవసరం.',
              VargaInspectionTone.challenging, planet: lord);
        }
        // Maitri's temporary friendship MUST come from D1, not be
        // recomputed from the varga longitudes.
        final signLord = signLords[lordSign];
        if (PanchadhaMaitriService.classicalPlanets.contains(lord) &&
            PanchadhaMaitriService.classicalPlanets.contains(signLord) &&
            PanchadhaMaitriService.classicalPlanets.every(
                (p) => natal.planets.any((x) => x.name == p))) {
          final relation = PanchadhaMaitriService.pairFromChart(
              natal, lord, signLord).finalRelation;
          final relationTone = switch (relation) {
            PanchadhaRelation.own || PanchadhaRelation.adhimitra ||
            PanchadhaRelation.mitra => VargaInspectionTone.supportive,
            PanchadhaRelation.shatru || PanchadhaRelation.adhishatru =>
                VargaInspectionTone.challenging,
            _ => VargaInspectionTone.contextual,
          };
          add('MAITRI-$house', 'పంచధా మైత్రి (D1 ఆధారం)',
              '${te(lord)} కు రాశ్యధిపతి ${te(signLord)}తో '
              '${PanchadhaMaitriService.relationTelugu(relation)} సంబంధం.',
              relationTone, planet: lord);
        }
      }
      for (final entry in signs.entries) {
        final planet = entry.key;
        final planetSign = entry.value;
        final inHouse = planetSign == targetSign;
        final byAspect = grahaAspects(planet, planetSign, targetSign);
        if (!inHouse && !byAspect) continue;
        final tone = nature(planet, natal, signs);
        add('${inHouse ? 'OCC' : 'DRISHTI'}-$house-$planet',
            '${te(planet)} ${inHouse ? 'స్థితి' : 'గ్రహదృష్టి'}',
            '${te(planet)} ${inHouse ? '$houseవ భావంలో ఉన్నారు' : '$houseవ భావాన్ని చూస్తున్నారు'}. '
            'నైసర్గిక స్వభావం ఒక్కటే తుది ఫలితం కాదు.',
            tone, planet: planet);
        final functional = <int>[];
        for (final n in const [5, 9, 6, 8, 12]) {
          if (signLords[signOf(n)] == planet) functional.add(n);
        }
        if (functional.isNotEmpty) {
          if (house == 1 && inHouse &&
              functional.any((h) => const <int>{6, 8, 12}.contains(h))) {
            add('LAGNA-DUSTHANA-$planet', 'లగ్నంలో 6/8/12 అధిపతి',
                '${te(planet)}కు ${functional.join(', ')} భావాల ఆధిపత్యం ఉంది. '
                'ఆటంక సూచన మాత్రమే; కోరిక లేదని నిర్ణయించరాదు.',
                VargaInspectionTone.challenging, planet: planet);
          }
          add('FUNCTIONAL-$house-$planet', 'ఆధిపత్య పరిశీలన',
              '${te(planet)} అధిపత్య భావాలు: ${functional.join(', ')}. '
              '5/9తో పాటు 6/8/12 కూడా ఉంటే మిశ్రమ సూచనగా చూడాలి.',
              VargaInspectionTone.contextual, planet: planet);
        }
      }
      if (lordSign != null) {
        for (final entry in signs.entries) {
          final planet = entry.key;
          if (planet == lord) continue;
          final joined = entry.value == lordSign;
          final aspect = grahaAspects(planet, entry.value, lordSign);
          if (!joined && !aspect) continue;
          final natureTone = nature(planet, natal, signs);
          add('LORD-${joined ? 'YUTI' : 'DRISHTI'}-$house-$planet',
              'భావాధిపతికి ${joined ? 'యుతి' : 'దృష్టి'}',
              '${te(planet)} ${te(lord)}తో ${joined ? 'యుతి' : 'దృష్టి'} '
              'సంబంధం కలిగి ఉన్నారు. గ్రహ కారకత్వం, మైత్రి, ఆధిపత్యం '
              'చెప్పే ఇతర నియమాలను కూడా పరీక్షించాలి.',
              natureTone, planet: planet);
        }
      }
      if (signals.isEmpty) {
        add('NONE-$house', 'ప్రాథమిక స్థితి',
            'పూర్తి మూల నియమం మ్యాచ్ అయిన తరువాతే ఫలితం నిర్ణయించాలి.',
            VargaInspectionTone.contextual);
      }
      return VargaHouseInspection(
        number: house,
        title: houseNames[house] ?? '$houseవ భావం',
        lord: lord,
        lordHouse: lordHouse,
        signals: List.unmodifiable(signals),
      );
    }

    final lagna = examine(1);
    final factors = focusHouses[factor] ?? const <int>[];
    final subjects = <VargaHouseInspection>[
      for (final h in factors)
        if (h != 1) examine(h),
    ];
    return VargaMasterInspection(
      chart: chart,
      lagna: lagna,
      subjects: List.unmodifiable(subjects),
      warning: 'ఈ అంశాలు 2026-11-02న మీరు వివరించిన సాధారణ భావ-అధిపతి '
          'పరిశీలన పద్ధతి ఆధారంగా రూపొందించిన గ్రహస్థితి ఆధారాలు మాత్రమే. '
          'లగ్నంలో పాపగ్రహం ఉందని కోరిక లేదని తేల్చకూడదు. '
          'ఆధారాల సంఖ్య = ఫలిత శాతం కాదు. ప్రత్యేక గ్రంథ IF–THEN, '
          'దశ/గోచార, మినహాయింపు నియమాలు సరిపోలినప్పుడే తుది తీర్పు.',
    );
  }
}
