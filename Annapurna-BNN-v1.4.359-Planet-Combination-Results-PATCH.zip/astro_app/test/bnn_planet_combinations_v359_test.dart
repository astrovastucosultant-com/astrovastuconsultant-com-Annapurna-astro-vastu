import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_planet_combination_service.dart';
import 'package:astro_app/screens/bnn_planet_combinations_panel.dart';

void main() {
  PlanetPosition p(String name,int sign,double degree) => PlanetPosition(
    name:name,shortName:name,longitude:sign*30+degree,latitude:0,speed:1);
  final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:24,
    ascendantLongitude:2*30+18.7,engineVersion:'sample',planets:[
      p('Sun',3,26.76),p('Moon',5,10.77),p('Mars',4,5.163),
      p('Mercury',3,18.409),p('Jupiter',8,5.25),p('Venus',2,11.87),
      p('Saturn',1,24.886),p('Rahu',9,2.336),p('Ketu',3,2.336),
    ]);

  test('Relation classification does not duplicate same-sign as trine', () {
    expect(BnnPlanetCombinationService.relation(3,3,nodeAxis:false),
      BnnCombinationRelation.sameSign);
    expect(BnnPlanetCombinationService.relation(4,8,nodeAxis:false),
      BnnCombinationRelation.sameTrine);
    expect(BnnPlanetCombinationService.relation(2,8,nodeAxis:false),
      BnnCombinationRelation.seventh);
    expect(BnnPlanetCombinationService.relation(8,9,nodeAxis:false),
      BnnCombinationRelation.adjacent);
    expect(BnnPlanetCombinationService.relation(3,5,nodeAxis:false),
      BnnCombinationRelation.thirdEleventh);
    expect(BnnPlanetCombinationService.relation(9,3,nodeAxis:true),isNull);
  });

  test('Every detected pair gets favorable and caution text', () async {
    TestWidgetsFlutterBinding.ensureInitialized();
    final rules=await BnnPlanetCombinationService.load();
    expect(rules.length,35);
    expect(rules.every((m)=>m.favorable.isNotEmpty&&m.unfavorable.isNotEmpty),isTrue);
    final found=BnnPlanetCombinationService.evaluate(chart:chart,rules:rules);
    expect(found.any((f)=>f.first.name=='Sun'&&f.second.name=='Mercury'&&
      f.relation==BnnCombinationRelation.sameSign),isTrue);
    expect(found.any((f)=>f.first.name=='Mars'&&f.second.name=='Jupiter'&&
      f.relation==BnnCombinationRelation.sameTrine),isTrue);
    expect(found.map((f)=>f.id).toSet().length,found.length);
    final groups=BnnPlanetCombinationService.groups(chart:chart,readings:found);
    expect(groups.any((g)=>g.sameSignIndex==3&&g.planets.length==3),isTrue);
    expect(groups.any((g)=>g.sameSignIndex==null&&
      g.planets.any((p)=>p.name=='Saturn')),isTrue);
  });

  testWidgets('Result-first panel offers both green and red possibilities',(tester) async {
    await tester.pumpWidget(MaterialApp(home:Scaffold(body:ListView(children:[
      BnnPlanetCombinationsPanel(chart:chart),
    ]))));
    await tester.pumpAndSettle();
    expect(find.textContaining('గ్రహ కాంబినేషన్లు'),findsWidgets);
    expect(find.textContaining('శుభ సూచన'),findsWidgets);
    expect(find.textContaining('ప్రతికూల సూచన'),findsWidgets);
  });
}
