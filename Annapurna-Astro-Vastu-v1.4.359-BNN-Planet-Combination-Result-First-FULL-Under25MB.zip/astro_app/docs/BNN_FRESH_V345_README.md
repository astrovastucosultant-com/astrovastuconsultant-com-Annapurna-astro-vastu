# BNN Fresh Reset — v1.4.345

## State
- Legacy 462 rules, their verified release, 84 alias rules, 24 graha-bala evidence rules and the 462–84 crosswalk are **not bundled**.
- Old BNN-only Dart engines, screens, audit documents and tests are not bundled.
- Main app D1 natal chart, planet longitudes/degrees and the BNN navigation tab remain.
- No new BNN prediction is published in this reset.

## Future publication process
1. Begin with an original BNN source page; record PDF page and printed page independently.
2. Transcribe/review Telugu source; fix OCR against the scan.
3. Give a new rule ID and canonical JSON source reference.
4. Implement a full deterministic IF predicate (all branches/exceptions) in a NEW engine.
5. Test TRUE / FALSE / missing inputs on known charts, including contradictory combinations.
6. Only then enable results; otherwise do not show rule as a prediction.

The empty `assets/bnn/bnn_fresh_v2.json` is a source manifest, not an active rule engine.
Old ZIP is kept outside this new source as backup.
