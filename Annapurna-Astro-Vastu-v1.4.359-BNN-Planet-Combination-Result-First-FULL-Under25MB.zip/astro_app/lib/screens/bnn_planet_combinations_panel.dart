import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/bnn_planet_combination_service.dart';
import '../astrology/bnn_house_relation_service.dart';
import '../astrology/bnn_rashi_rule_service.dart';

/// BNN-only result-first combination view. No unverified result is labeled
/// a direct quote from R.G. Rao or a verified ancient source rule.
class BnnPlanetCombinationsPanel extends StatefulWidget {
  final AstroChartResult chart;
  const BnnPlanetCombinationsPanel({super.key,required this.chart});
  @override
  State<BnnPlanetCombinationsPanel> createState()=>
      _BnnPlanetCombinationsPanelState();
}

class _BnnPlanetCombinationsPanelState extends State<BnnPlanetCombinationsPanel> {
  late final Future<List<BnnCombinationMeaning>> catalog=
    BnnPlanetCombinationService.load();
  bool expanded=true;
  @override
  Widget build(BuildContext context) => FutureBuilder<List<BnnCombinationMeaning>>(
    future:catalog,builder:(context,snapshot) {
      if (snapshot.hasError) return Card(child:Padding(padding:const EdgeInsets.all(12),
        child:Text('BNN కాంబినేషన్ డేటా సమస్య: ${snapshot.error}')));
      if (!snapshot.hasData) return const Center(child:CircularProgressIndicator());
      final findings=BnnPlanetCombinationService.evaluate(
        chart:widget.chart,rules:snapshot.data!);
      final groups=BnnPlanetCombinationService.groups(
        chart:widget.chart,readings:findings);
      return Card(
        key:const ValueKey('bnn-combination-panel'),
        margin:const EdgeInsets.symmetric(vertical:10),
        color:const Color(0xFFF0F6F3),
        child:Padding(padding:const EdgeInsets.all(12),child:Column(
          crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          ListTile(contentPadding:EdgeInsets.zero,
            title:const Text('BNN — గ్రహ కాంబినేషన్లు & ఫలిత సూచనలు',
              style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),
            subtitle:Text('${findings.length} ప్రత్యేక గ్రహసంబంధాలు • '
              '${groups.length} త్రిగ్రహ/సమూహ కాంబినేషన్లు'),
            trailing:Icon(expanded?Icons.expand_less:Icons.expand_more),
            onTap:()=>setState(()=>expanded=!expanded)),
          const Text('ప్రతి సంబంధానికి అనుకూల, ప్రతికూల వ్యాఖ్యానాలు ఉంటాయి. '
            'ఇవి కారకత్వ ఆధారిత సంప్రదాయ సూచనలు; మూలగ్రంథంలోని '
            'పూర్తి IF–THEN శ్లోకంగా లేదా ఖచ్చిత సంఘటనగా పరిగణించరాదు.',
            style:TextStyle(fontSize:12,color:Color(0xFF52626B))),
          if (expanded) ...[
            if (groups.isNotEmpty) ...[
              const SizedBox(height:12),
              const Text('మూడు లేదా ఎక్కువ గ్రహాల సమూహాలు',
                style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
              for(final group in groups) _GroupTile(group:group),
            ],
            const SizedBox(height:12),
            const Text('ప్రతి ద్విగ్రహ సంబంధం — ఫలితం ముందుగా',
              style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
            if (findings.isEmpty)
              const Text('ఈ పద్ధతుల్లో అనుసంధానమైన గ్రహ జంటలు లేవు.'),
            for (final reading in findings)
              _CombinationReadingTile(key:ValueKey('combo-${reading.id}'),
                finding:reading),
          ],
        ])),
      );
    });
}

String _name(PlanetPosition p)=>
  BnnHouseRelationService.planetLabels[p.name]??p.name;
String _location(PlanetPosition p)=>
  '${_name(p)} ${BnnRashiRuleService.signs[p.signIndex]} '
  '${BnnRashiRuleService.dms(p.longitude)}';
String _relationLabel(BnnCombinationRelation type) {
  switch(type) {
    case BnnCombinationRelation.sameSign:return 'ఒకే రాశి సంయోగం';
    case BnnCombinationRelation.sameTrine:return '1–5–9 త్రికోణ సంబంధం';
    case BnnCombinationRelation.seventh:return 'ఎదురెదురు 7వ స్థానం';
    case BnnCombinationRelation.adjacent:return 'పక్క రాశి 2–12';
    case BnnCombinationRelation.thirdEleventh:return '3–11 సంబంధం';
  }
}

class _PositiveNegativeText extends StatelessWidget {
  final String text;
  final bool positive;
  const _PositiveNegativeText({required this.text,required this.positive});
  @override
  Widget build(BuildContext context) => Container(
    width:double.infinity,
    margin:const EdgeInsets.only(top:7),
    padding:const EdgeInsets.all(11),
    decoration:BoxDecoration(
      color:positive?const Color(0xFFDFF4E5):const Color(0xFFFDE8E8),
      border:Border.all(color:positive?const Color(0xFF6CA57A):const Color(0xFFC96C70)),
      borderRadius:BorderRadius.circular(10)),
    child:Text('${positive?'శుభ సూచన':'ప్రతికూల సూచన'}: $text',
      style:TextStyle(fontWeight:FontWeight.bold,fontSize:14.5,
        color:positive?const Color(0xFF155D37):const Color(0xFF9C2222))),
  );
}

class _CombinationReadingTile extends StatelessWidget {
  final BnnCombinationFinding finding;
  const _CombinationReadingTile({super.key,required this.finding});
  @override
  Widget build(BuildContext context) {
    final a=finding.first, b=finding.second;
    final m=finding.meaning;
    return Card(
      margin:const EdgeInsets.symmetric(vertical:5),
      color:Colors.white,
      child:ExpansionTile(
        key:ValueKey('combo-rule-${finding.id}'),
        tilePadding:const EdgeInsets.fromLTRB(11,8,11,7),
        title:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
          Text('${_name(a)} + ${_name(b)} • ${_relationLabel(finding.relation)}',
            style:const TextStyle(fontSize:14.5,fontWeight:FontWeight.w700)),
          const SizedBox(height:4),
          _PositiveNegativeText(text:m.favorable,positive:true),
          _PositiveNegativeText(text:m.unfavorable,positive:false),
        ]),
        subtitle:const Padding(padding:EdgeInsets.only(top:8),
          child:Text('రెండు సూచనలు • టచ్ చేస్తే IF, డిగ్రీ క్రమం, ఆధారం',
            style:TextStyle(fontSize:11.5))),
        childrenPadding:const EdgeInsets.fromLTRB(14,0,14,13),
        children:[
          _detail('1. IF / సంబంధ నియమం',
            '${_name(a)} మరియు ${_name(b)} ${_relationLabel(finding.relation)}లో '
            'ఉంటే ఈ గ్రహకారకత్వాలను సంయుక్తంగా పరిశీలించాలి.'),
          _detail('2. జాతక పరిశీలన',
            '${_location(a)}; ${_location(b)}. '
            '${_name(a)} నుంచి ${_name(b)} ${finding.forwardHouse}వ రాశి. '
            'జన్మగ్రహ సంబంధం TRUE.'),
          _detail('3. డిగ్రీల క్రమం',
            '${a.degreesInSign<=b.degreesInSign?_name(a):_name(b)} → '
            '${a.degreesInSign<=b.degreesInSign?_name(b):_name(a)}. '
            'రాశులు వేర్వేరు ఉంటే ఈ క్రమం త్రికోణ గ్రూపింగ్ కోసం మాత్రమే; '
            'సంఘటనల కాలక్రమాన్ని స్వతంత్రంగా నిర్ధారించదు.'),
          _detail('4. ఫలితాల స్థాయి',
            '${m.sourceNote}. శుభ/ప్రతికూల రెండు అవకాశాల్లో ఏది '
            'బలంగా ఉందో నిర్ణయించడానికి మిగతా సంయోగాలు, రాశ్యధిపతి, '
            'గురు–శని సైకిల్, మూల IF–THEN నిర్ధారణ అవసరం.'),
          _detail('5. Rule ID / మూల సూచన',
            '${finding.id}. పేజీ-ప్రత్యేక గ్రంథశ్లోకం ఈ '
            'వివరణకు ధృవీకరించబడలేదు. సంబంధ పద్ధతి సూచనలు: '
            '${m.sourceRefs.join(' ; ')}'),
        ],
      ),
    );
  }
}

class _GroupTile extends StatelessWidget {
  final BnnCombinationGroup group;
  const _GroupTile({required this.group});
  @override
  Widget build(BuildContext context) {
    final names=group.planets.map(_name).join(' + ');
    final desc=group.sameSignIndex==null ? 'ఒకే త్రికోణ సమూహం'
      : '${BnnRashiRuleService.signs[group.sameSignIndex!]} రాశిలో సంయోగం';
    return Card(margin:const EdgeInsets.symmetric(vertical:5),child:ExpansionTile(
      title:Text('$names • $desc',style:const TextStyle(fontWeight:FontWeight.bold)),
      subtitle:Text('${group.links.length} జంట సంబంధాలు • '
        'డిగ్రీల క్రమంలో గ్రూప్ పరిశీలన'),
      childrenPadding:const EdgeInsets.fromLTRB(12,0,12,12),
      children:[
        _detail('సమిష్టి గ్రహ క్రమం',
          group.planets.map(_location).join(' → ')),
        _detail('అనుకూల అంశాలు',
          group.links.take(3).map((r)=>r.meaning.favorable).join('  ')),
        _detail('ప్రతికూల అంశాలు',
          group.links.take(3).map((r)=>r.meaning.unfavorable).join('  ')),
        const Text('ఇది జంటల సమిష్టి వ్యాఖ్యానం; స్వతంత్ర ధృవీకరించిన '
          'త్రిగ్రహ సూత్రం కాదు.',style:TextStyle(fontSize:12)),
      ],
    ));
  }
}

Widget _detail(String title,String body) => Padding(
  padding:const EdgeInsets.only(top:10),child:Column(
    crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Text(title,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:13)),
      const SizedBox(height:3),Text(body,style:const TextStyle(height:1.35)),
    ]));
