import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';

/// Approximate BNN Saturn progression: 2.5 years per sign (30 years/round).
/// This is NOT a computed Swiss-Ephemeris transit, nor a prediction by itself.
class BnnSaturnCycleTheme {
  final int round;
  final double ageStart;
  final double ageEnd;
  final String? focus;
  final String sourcePage;
  const BnnSaturnCycleTheme({required this.round,required this.ageStart,
    required this.ageEnd,this.focus,required this.sourcePage});
  factory BnnSaturnCycleTheme.fromJson(Map<String,dynamic> row) {
    final r=(row['round'] as num).toInt();
    final a=(row['age_start'] as num).toDouble();
    final z=(row['age_end_exclusive'] as num).toDouble();
    if (r<1 || r>4 || a!=(r-1)*30 || z!=r*30) {
      throw const FormatException('BNN Saturn round boundary mismatch');
    }
    return BnnSaturnCycleTheme(round:r,ageStart:a,ageEnd:z,
      focus:row['traditional_focus_te'] as String?,
      sourcePage:row['source_page'] as String);
  }
}

class BnnSaturnContactWindow {
  final int round;
  final int signIndex;
  final int signOffset;
  final double ageStart;
  final double ageEnd;
  final List<PlanetPosition> natalContacts;
  const BnnSaturnContactWindow({required this.round,required this.signIndex,
    required this.signOffset,required this.ageStart,required this.ageEnd,
    required this.natalContacts});

  /// A SOURCE-BACKED heuristic, not a confirmed real-world job event.
  /// Bhrigu Naadi Sangraha, Principles of Naadi, printed p.xiii.
  bool get firstRoundRahuProfessionIndicator => round==1 &&
    natalContacts.any((p)=>p.name=='Rahu');

  String get calculationId => 'BNN-SAT-C${round.toString().padLeft(2,'0')}'
    '-S${(signOffset+1).toString().padLeft(2,'0')}';
}

class BnnSaturnCycle {
  final BnnSaturnCycleTheme theme;
  final List<BnnSaturnContactWindow> windows;
  const BnnSaturnCycle({required this.theme, required this.windows});
}

class BnnSaturnCycleService {
  const BnnSaturnCycleService._();

  static Future<List<BnnSaturnCycleTheme>> loadThemes() async {
    final text=await rootBundle.loadString('assets/bnn/bnn_saturn_cycles_v356.json');
    final obj=jsonDecode(text) as Map<String,dynamic>;
    if (obj['schema']!='ANNAPURNA-BNN-SATURN-CYCLES-1.0') {
      throw const FormatException('Unexpected Saturn round JSON schema');
    }
    final themes=(obj['rounds'] as List)
      .map((v)=>BnnSaturnCycleTheme.fromJson(v as Map<String,dynamic>))
      .toList(growable:false);
    if (themes.length!=4 || themes.map((v)=>v.round).toSet().length!=4) {
      throw const FormatException('Expected 4 unique Saturn cycles');
    }
    return List.unmodifiable(themes);
  }

  /// 4 rounds, 12 sign windows each = 48 windows, 2.5 years per window.
  /// Natal Saturn position is the first sign at the start of each round.
  static List<BnnSaturnCycle> calculate({required AstroChartResult chart,
    required List<BnnSaturnCycleTheme> themes}) {
    final sats=[for(final p in chart.planets) if(p.name=='Saturn') p];
    if (sats.isEmpty) return const <BnnSaturnCycle>[];
    final base=sats.first.signIndex;
    return List.unmodifiable([
      for (final t in themes)
        BnnSaturnCycle(theme:t,windows:List.unmodifiable([
          for (var n=0;n<12;n++)
            BnnSaturnContactWindow(
              round:t.round,signIndex:(base+n)%12,signOffset:n,
              ageStart:t.ageStart+n*2.5,ageEnd:t.ageStart+(n+1)*2.5,
              natalContacts:List.unmodifiable([
                for (final p in chart.planets)
                  if (p.signIndex==(base+n)%12) p,
              ]),
            ),
        ])),
    ]);
  }
}
