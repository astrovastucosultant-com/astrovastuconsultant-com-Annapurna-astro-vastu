import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';

/// All positions are whole-sign counts: reference sign is first house.
/// This is a positional calculation only, never a prediction by itself.
class BnnHousePosition {
  final String name;
  final PlanetPosition position;
  final int lagnaHouse;
  final int? jupiterHouse;
  const BnnHousePosition({
    required this.name,
    required this.position,
    required this.lagnaHouse,
    required this.jupiterHouse,
  });
}

class BnnJupiterRelativeRule {
  final String id;
  final String sourceId;
  final String target;
  final int jupiterHouse;
  final String originalIf;
  final String originalThen;
  final String tone;
  final String sourceFile;
  final int pdfPage;
  final int? printedPage;
  final String? sourceUrl;
  final String? sourceScope;
  final String? sourceNote;

  const BnnJupiterRelativeRule({
    required this.id, required this.sourceId, required this.target,
    required this.jupiterHouse, required this.originalIf,
    required this.originalThen, required this.tone,
    required this.sourceFile, required this.pdfPage,
    this.printedPage, this.sourceUrl, this.sourceScope, this.sourceNote,
  });

  factory BnnJupiterRelativeRule.fromJson(Map<String, dynamic> j) {
    final source = j['source'] as Map<String, dynamic>;
    if (j['reference_planet'] != 'Jupiter') {
      throw const FormatException('BNN relative rule reference is not Jupiter');
    }
    return BnnJupiterRelativeRule(
      id: j['id'] as String,
      sourceId: j['source_rule_id'] as String,
      target: j['target_planet'] as String,
      jupiterHouse: (j['house_from_reference'] as num).toInt(),
      originalIf: j['original_if'] as String,
      originalThen: j['original_then'] as String,
      tone: j['tone'] as String,
      sourceFile: source['file'] as String,
      pdfPage: (source['pdf_page'] as num).toInt(),
      printedPage: (source['printed_page'] as num?)?.toInt(),
      sourceUrl: source['url'] as String?,
      sourceScope: source['scope'] as String?,
      sourceNote: source['source_note'] as String?,
    );
  }
}

class BnnJupiterRelativeFinding {
  final BnnJupiterRelativeRule rule;
  final PlanetPosition targetPosition;
  final PlanetPosition jupiterPosition;
  const BnnJupiterRelativeFinding({
    required this.rule, required this.targetPosition, required this.jupiterPosition,
  });
}

/// Source-backed Lagna-relative BNN IF/THEN. Empty catalog means no prediction.
class BnnLagnaRelativeRule {
  final String id;
  final String sourceId;
  final String target;
  final int lagnaHouse;
  final String originalIf;
  final String originalThen;
  final String tone;
  final String sourceFile;
  final int pdfPage;

  const BnnLagnaRelativeRule({
    required this.id,required this.sourceId,required this.target,
    required this.lagnaHouse,required this.originalIf,required this.originalThen,
    required this.tone,required this.sourceFile,required this.pdfPage,
  });

  factory BnnLagnaRelativeRule.fromJson(Map<String,dynamic> j) {
    if (j['reference_point'] != 'Lagna') {
      throw const FormatException('BNN Lagna rule reference must be Lagna');
    }
    final source=j['source'] as Map<String,dynamic>;
    final house=(j['house_from_reference'] as num).toInt();
    if (house<1 || house>12) throw const FormatException('BNN Lagna house must be 1..12');
    return BnnLagnaRelativeRule(
      id:j['id'] as String,sourceId:j['source_rule_id'] as String,
      target:j['target_planet'] as String,lagnaHouse:house,
      originalIf:j['original_if'] as String,
      originalThen:j['original_then'] as String,
      tone:j['tone'] as String,sourceFile:source['file'] as String,
      pdfPage:(source['pdf_page'] as num).toInt());
  }
}

class BnnLagnaRelativeFinding {
  final BnnLagnaRelativeRule rule;
  final PlanetPosition targetPosition;
  const BnnLagnaRelativeFinding({
    required this.rule,required this.targetPosition,
  });
}

class BnnHouseRelationService {
  const BnnHouseRelationService._();

  static const planets = [
    'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter',
    'Venus', 'Saturn', 'Rahu', 'Ketu',
  ];
  static const planetLabels = <String, String>{
    'Sun':'సూర్యుడు', 'Moon':'చంద్రుడు', 'Mars':'కుజుడు',
    'Mercury':'బుధుడు', 'Jupiter':'గురుడు', 'Venus':'శుక్రుడు',
    'Saturn':'శని', 'Rahu':'రాహువు', 'Ketu':'కేతువు',
  };

  /// These are house TOPICS, not verified house-specific predictions.
  static const houseTopics = [
    'లగ్నం / శరీరం / వ్యక్తిత్వం',
    'ధనం / కుటుంబం / వాక్కు',
    'సోదరులు / ప్రయత్నం / ధైర్యం',
    'తల్లి / గృహం / సుఖం',
    'సంతానం / విద్య / బుద్ధి',
    'రోగం / ఋణం / శత్రువులు',
    'వివాహం / భాగస్వామ్యం',
    'ఆయుష్షు / మార్పులు',
    'భాగ్యం / ధర్మం / గురువు',
    'వృత్తి / కర్మ / స్థితి',
    'లాభాలు / ఆశలు',
    'వ్యయం / విదేశం / నిద్ర',
  ];

  static int houseFrom({required int originSign, required int targetSign}) {
    if (originSign < 0 || originSign > 11 || targetSign < 0 || targetSign > 11) {
      throw RangeError('BNN sign indices must be in range 0..11');
    }
    return (targetSign - originSign + 12) % 12 + 1;
  }

  static List<BnnHousePosition> positions(AstroChartResult chart) {
    final byPlanet = {for (final p in chart.planets) p.name: p};
    final jupiter = byPlanet['Jupiter'];
    return [
      for (final name in planets)
        if (byPlanet[name] != null)
          BnnHousePosition(
            name: name,
            position: byPlanet[name]!,
            lagnaHouse: houseFrom(
                originSign: chart.ascendantSignIndex,
                targetSign: byPlanet[name]!.signIndex),
            jupiterHouse: jupiter == null ? null : houseFrom(
                originSign: jupiter.signIndex,
                targetSign: byPlanet[name]!.signIndex),
          ),
    ];
  }

  static Future<List<BnnLagnaRelativeRule>> loadVerifiedLagnaRules() async {
    final raw=await rootBundle.loadString('assets/bnn/bnn_lagna_relative_verified_v351.json');
    final parsed=jsonDecode(raw) as Map<String,dynamic>;
    if (parsed['schema'] != 'ANNAPURNA-BNN-LAGNA-RELATIVE-1.0') {
      throw const FormatException('Unexpected BNN Lagna relation catalog');
    }
    final rules=(parsed['rules'] as List)
        .map((v)=>BnnLagnaRelativeRule.fromJson(v as Map<String,dynamic>))
        .toList(growable:false);
    if (rules.map((r)=>r.id).toSet().length!=rules.length) {
      throw const FormatException('Duplicate BNN Lagna rule IDs');
    }
    return List.unmodifiable(rules);
  }

  static List<BnnLagnaRelativeFinding> evaluateVerifiedLagnaRules({
    required AstroChartResult chart,
    required List<BnnLagnaRelativeRule> rules,
  }) {
    final byPlanet={for (final p in chart.planets) p.name:p};
    return [
      for (final rule in rules)
        if (byPlanet[rule.target] != null &&
            houseFrom(originSign:chart.ascendantSignIndex,
              targetSign:byPlanet[rule.target]!.signIndex)==rule.lagnaHouse)
          BnnLagnaRelativeFinding(rule:rule,
            targetPosition:byPlanet[rule.target]!),
    ];
  }

  static Future<List<BnnJupiterRelativeRule>> loadVerifiedJupiterRules() async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_jupiter_relative_verified_v350.json');
    final j = jsonDecode(raw) as Map<String, dynamic>;
    if (j['schema'] != 'ANNAPURNA-BNN-JUPITER-RELATIVE-1.0') {
      throw const FormatException('Unexpected BNN Jupiter relation catalog');
    }
    final rules = (j['rules'] as List)
        .map((v) => BnnJupiterRelativeRule.fromJson(v as Map<String, dynamic>))
        .toList(growable:false);
    if (rules.map((r) => r.id).toSet().length != rules.length) {
      throw const FormatException('Duplicate BNN Jupiter rule IDs');
    }
    return List.unmodifiable(rules);
  }

  static List<BnnJupiterRelativeFinding> evaluateVerifiedJupiterRules({
    required AstroChartResult chart,
    required List<BnnJupiterRelativeRule> rules,
  }) {
    final byPlanet = {for (final p in chart.planets) p.name: p};
    final jupiter = byPlanet['Jupiter'];
    if (jupiter == null) return const [];
    return [
      for (final rule in rules)
        if (byPlanet[rule.target] != null &&
            houseFrom(originSign:jupiter.signIndex,
                targetSign:byPlanet[rule.target]!.signIndex) == rule.jupiterHouse)
          BnnJupiterRelativeFinding(
            rule:rule, targetPosition:byPlanet[rule.target]!,
            jupiterPosition:jupiter,
          ),
    ];
  }
}
