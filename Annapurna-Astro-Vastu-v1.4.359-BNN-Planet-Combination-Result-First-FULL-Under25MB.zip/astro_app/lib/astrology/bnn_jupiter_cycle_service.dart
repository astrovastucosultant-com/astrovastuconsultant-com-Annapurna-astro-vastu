import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';

/// One sign per completed age-year is an APPROXIMATE Nadi progression.
/// It is not Swiss-Ephemeris transit and does not yield a prediction alone.
class BnnJupiterCycleTheme {
  final int round;
  final int ageStart;
  final int ageEndExclusive;
  final String? traditionalFocus;
  final String? sourceUrl;
  const BnnJupiterCycleTheme({required this.round,required this.ageStart,
    required this.ageEndExclusive,this.traditionalFocus,this.sourceUrl});

  factory BnnJupiterCycleTheme.fromJson(Map<String,dynamic> j) {
    final round=(j['round'] as num).toInt();
    final start=(j['age_start'] as num).toInt();
    final end=(j['age_end_exclusive'] as num).toInt();
    if (round < 1 || round > 12 || start != (round-1)*12 || end != round*12) {
      throw const FormatException('Invalid BNN Jupiter cycle boundaries');
    }
    return BnnJupiterCycleTheme(round:round,ageStart:start,
      ageEndExclusive:end,traditionalFocus:j['traditional_focus_te'] as String?,
      sourceUrl:j['source_url'] as String?);
  }
}

class BnnJupiterCycleYear {
  final int cycle;
  final int ageStart;
  final int ageEndExclusive;
  final int progressedSignIndex;
  final int relativeSignFromNatalJupiter;
  final List<PlanetPosition> natalSignContacts;

  const BnnJupiterCycleYear({required this.cycle,required this.ageStart,
    required this.ageEndExclusive,required this.progressedSignIndex,
    required this.relativeSignFromNatalJupiter,required this.natalSignContacts});

  /// Calculation ID, never presented as a verified astrological source Rule ID.
  String get calculationId => 'BNN-JUP-C${cycle.toString().padLeft(2,'0')}'
      '-AGE${ageStart.toString().padLeft(3,'0')}';
}

class BnnJupiterCycle {
  final BnnJupiterCycleTheme theme;
  final List<BnnJupiterCycleYear> years;
  const BnnJupiterCycle({required this.theme,required this.years});
}

class BnnJupiterCycleService {
  const BnnJupiterCycleService._();

  static Future<List<BnnJupiterCycleTheme>> loadThemes() async {
    final raw=await rootBundle.loadString('assets/bnn/bnn_jupiter_cycles_v355.json');
    final j=jsonDecode(raw) as Map<String,dynamic>;
    if (j['schema'] != 'ANNAPURNA-BNN-JUPITER-CYCLES-1.0') {
      throw const FormatException('Unexpected BNN Jupiter cycle schema');
    }
    final themes=(j['rounds'] as List)
      .map((x)=>BnnJupiterCycleTheme.fromJson(x as Map<String,dynamic>))
      .toList(growable:false);
    if (themes.length != 12 ||
        themes.map((x)=>x.round).toSet().length != themes.length) {
      throw const FormatException('Expected twelve unique Jupiter rounds');
    }
    return List.unmodifiable(themes);
  }

  /// Exactly one sign per completed year, with natal Jupiter sign at age 0.
  /// The approximate sign repeats every 12 years; cycle context is separate.
  static List<BnnJupiterCycle> calculate({required AstroChartResult chart,
    required List<BnnJupiterCycleTheme> themes}) {
    final natalJupiter=<PlanetPosition>[
      for (final p in chart.planets) if (p.name=='Jupiter') p,
    ];
    if (natalJupiter.isEmpty) return const <BnnJupiterCycle>[];
    final jSign=natalJupiter.first.signIndex;
    return List.unmodifiable([
      for (final theme in themes)
        BnnJupiterCycle(theme:theme,years:List.unmodifiable([
          for (var offset=0;offset<12;offset++)
            BnnJupiterCycleYear(
              cycle:theme.round,
              ageStart:theme.ageStart+offset,
              ageEndExclusive:theme.ageStart+offset+1,
              progressedSignIndex:(jSign+offset)%12,
              relativeSignFromNatalJupiter:offset+1,
              natalSignContacts:List.unmodifiable([
                for (final p in chart.planets)
                  if ((jSign+offset)%12==p.signIndex) p,
              ]),
            ),
        ])),
    ]);
  }
}
