import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';

/// Detects BNN relationships mathematically. Meanings in the catalog are
/// editorial karakatwa interpretations, NOT verbatim R.G. Rao book rules.
class BnnCombinationMeaning {
  final String id;
  final String planetA;
  final String planetB;
  final String favorable;
  final String unfavorable;
  final String sourceNote;
  final List<String> sourceRefs;
  const BnnCombinationMeaning({required this.id,required this.planetA,
    required this.planetB,required this.favorable,required this.unfavorable,
    required this.sourceNote,required this.sourceRefs});

  factory BnnCombinationMeaning.fromJson(Map<String,dynamic> data) {
    if (data['status'] != 'interpretive_karakatwa_synthesis') {
      throw const FormatException('Unexpected BNN combination evidence class');
    }
    return BnnCombinationMeaning(
      id:data['id'] as String,
      planetA:data['planet_a'] as String,
      planetB:data['planet_b'] as String,
      favorable:data['favorable_text'] as String,
      unfavorable:data['unfavorable_text'] as String,
      sourceNote:data['source_note'] as String,
      sourceRefs:(data['source_refs'] as List).cast<String>(),
    );
  }
}

enum BnnCombinationRelation { sameSign, sameTrine, seventh, adjacent, thirdEleventh }

class BnnCombinationFinding {
  final BnnCombinationMeaning meaning;
  final PlanetPosition first;
  final PlanetPosition second;
  final BnnCombinationRelation relation;
  /// The separation in signs from first to second, sign-based not degree-based.
  final int forwardHouse;
  const BnnCombinationFinding({required this.meaning,required this.first,
    required this.second,required this.relation,required this.forwardHouse});
  String get id => '${meaning.id}-${relation.name}';
}

class BnnCombinationGroup {
  final int trineIndex;
  final int? sameSignIndex;
  final List<PlanetPosition> planets;
  final List<BnnCombinationFinding> links;
  const BnnCombinationGroup({required this.trineIndex,
    required this.sameSignIndex,required this.planets,required this.links});
}

class BnnPlanetCombinationService {
  const BnnPlanetCombinationService._();
  static const ninePlanets=['Sun','Moon','Mars','Mercury','Jupiter',
    'Venus','Saturn','Rahu','Ketu'];

  static Future<List<BnnCombinationMeaning>> load() async {
    final raw=await rootBundle.loadString(
      'assets/bnn/bnn_planet_combination_interpretations_v359.json');
    final data=jsonDecode(raw) as Map<String,dynamic>;
    if (data['schema']!='ANNAPURNA-BNN-COMBINATIONS-1.0') {
      throw const FormatException('BNN combination catalog version mismatch');
    }
    final items=(data['rules'] as List)
        .map((item)=>BnnCombinationMeaning.fromJson(item as Map<String,dynamic>))
        .toList(growable:false);
    if (items.length!=35 || items.map((e)=>e.id).toSet().length!=35) {
      throw const FormatException('BNN 35 unique planet pairs expected');
    }
    return List.unmodifiable(items);
  }

  /// Priority: direct conjunction > trine > opposition > adjacent > 3/11.
  /// Rahu-Ketu are opposites by construction but should not be read as a
  /// direct 7th-house planet-to-planet combination on their own.
  static BnnCombinationRelation? relation(int a,int b,
      {required bool nodeAxis}) {
    final d=(b-a+12)%12;
    if (d==0) return BnnCombinationRelation.sameSign;
    if (d==4||d==8) return BnnCombinationRelation.sameTrine;
    if (d==6) return nodeAxis?null:BnnCombinationRelation.seventh;
    if (d==1||d==11) return BnnCombinationRelation.adjacent;
    if (d==2||d==10) return BnnCombinationRelation.thirdEleventh;
    return null;
  }

  static List<BnnCombinationFinding> evaluate({
    required AstroChartResult chart,
    required List<BnnCombinationMeaning> rules,
  }) {
    final planets={for (final p in chart.planets)
      if (ninePlanets.contains(p.name)) p.name:p};
    final found=<BnnCombinationFinding>[];
    for (final r in rules) {
      final a=planets[r.planetA];
      final b=planets[r.planetB];
      if (a==null||b==null) continue;
      final nodeAxis=(a.name=='Rahu'&&b.name=='Ketu')||
          (a.name=='Ketu'&&b.name=='Rahu');
      final rel=relation(a.signIndex,b.signIndex,nodeAxis:nodeAxis);
      if (rel==null) continue;
      found.add(BnnCombinationFinding(meaning:r,first:a,second:b,
        relation:rel,forwardHouse:(b.signIndex-a.signIndex+12)%12+1));
    }
    const priority={
      BnnCombinationRelation.sameSign:0,
      BnnCombinationRelation.sameTrine:1,
      BnnCombinationRelation.seventh:2,
      BnnCombinationRelation.adjacent:3,
      BnnCombinationRelation.thirdEleventh:4,
    };
    found.sort((a,b) {
      final rel=priority[a.relation]!.compareTo(priority[b.relation]!);
      return rel!=0?rel:a.id.compareTo(b.id);
    });
    return found;
  }

  static List<BnnCombinationGroup> groups({
    required AstroChartResult chart,
    required List<BnnCombinationFinding> readings,
  }) {
    final planets=chart.planets.where((p)=>ninePlanets.contains(p.name));
    final groups=<BnnCombinationGroup>[];
    for (var sign=0;sign<12;sign++) {
      final joined=planets.where((p)=>p.signIndex==sign).toList()
        ..sort((a,b)=>a.degreesInSign.compareTo(b.degreesInSign));
      if (joined.length<3) continue;
      final names=joined.map((p)=>p.name).toSet();
      groups.add(BnnCombinationGroup(trineIndex:sign%4,sameSignIndex:sign,
        planets:joined,links:readings.where((r)=>
          names.contains(r.first.name)&&names.contains(r.second.name)&&
          r.relation==BnnCombinationRelation.sameSign).toList()));
    }
    // Directional trine groups: keep them distinct from exact conjunctions.
    for (var group=0;group<4;group++) {
      final members=planets.where((p)=>p.signIndex%4==group).toList()
        ..sort((a,b)=>a.degreesInSign.compareTo(b.degreesInSign));
      if (members.length<3 || members.map((e)=>e.signIndex).toSet().length<2) {
        continue;
      }
      final names=members.map((p)=>p.name).toSet();
      groups.add(BnnCombinationGroup(trineIndex:group,sameSignIndex:null,
        planets:members,links:readings.where((r)=>
          names.contains(r.first.name)&&names.contains(r.second.name)&&
          (r.relation==BnnCombinationRelation.sameTrine||
           r.relation==BnnCombinationRelation.sameSign)).toList()));
    }
    return groups;
  }
}
