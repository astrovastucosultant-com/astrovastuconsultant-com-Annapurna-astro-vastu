import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';
import 'bnn_house_relation_service.dart';

/// BPHS Ch.24: effects of natal *house lords* in 12 whole-sign houses.
/// This is different from a generic "any graha in house" rule. Rahu/Ketu
/// are displayed as positions but not assigned fictitious Ch.24 lordships.
class BphsBhavaLordRule {
  final String id;
  final int lordOfHouse;
  final int placedInHouse;
  final String ifTelugu;
  final String resultTelugu;
  final String tone;
  final int verse;
  final String sourceUrl;
  const BphsBhavaLordRule({required this.id,required this.lordOfHouse,
    required this.placedInHouse,required this.ifTelugu,
    required this.resultTelugu,required this.tone,
    required this.verse,required this.sourceUrl});

  factory BphsBhavaLordRule.fromJson(Map<String,dynamic> j) {
    final src=j['source'] as Map<String,dynamic>;
    if (j['rule_type']!='bhava_lord_in_house' || j['reference']!='Lagna') {
      throw const FormatException('Not a BPHS Ch24 Lagna lord-placement rule');
    }
    final owner=(j['lord_of_house'] as num).toInt();
    final placement=(j['placed_in_house'] as num).toInt();
    final verse=(src['verse'] as num).toInt();
    if (owner<1 || owner>12 || placement<1 || placement>12 ||
        verse<1 || verse>144 || src['chapter']!=24) {
      throw const FormatException('Invalid BPHS house/chapter/verse');
    }
    return BphsBhavaLordRule(id:j['id'] as String,
      lordOfHouse:owner,placedInHouse:placement,
      ifTelugu:j['if_template_te'] as String,
      resultTelugu:j['effect_te'] as String,
      tone:j['tone'] as String,verse:verse,
      sourceUrl:src['url'] as String);
  }
}

class BphsBhavaLordFinding {
  final BphsBhavaLordRule rule;
  final String lordPlanet;
  final PlanetPosition planetPosition;
  final int lagnaSign;
  const BphsBhavaLordFinding({required this.rule,required this.lordPlanet,
    required this.planetPosition,required this.lagnaSign});
}

class BphsLagnaBhavaLordService {
  const BphsLagnaBhavaLordService._();

  // Sidereal whole-sign classical seven-planet sign lordships, Aries=0.
  static const signRulers=<String>[
    'Mars','Venus','Mercury','Moon','Sun','Mercury',
    'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter',
  ];

  static String lordOfNatalHouse({required int ascendantSignIndex,
    required int house}) {
    if (ascendantSignIndex<0 || ascendantSignIndex>11 || house<1 || house>12) {
      throw RangeError('Invalid ascendant/house');
    }
    return signRulers[(ascendantSignIndex+house-1)%12];
  }

  static int wholeSignHouse({required int lagnaSign,required int planetSign}) =>
    BnnHouseRelationService.houseFrom(originSign:lagnaSign,targetSign:planetSign);

  static Future<List<BphsBhavaLordRule>> loadVerifiedRules() async {
    final raw=await rootBundle.loadString('assets/bphs/bphs_ch24_lagna_lords_v353.json');
    final catalog=jsonDecode(raw) as Map<String,dynamic>;
    if (catalog['schema']!='ANNAPURNA-BPHS-LAGNA-BHAVA-LORD-1.0') {
      throw const FormatException('Unexpected BPHS catalog schema');
    }
    final rules=(catalog['rules'] as List<dynamic>).map(
      (item)=>BphsBhavaLordRule.fromJson(item as Map<String,dynamic>))
      .toList(growable:false);
    if (rules.map((r)=>r.id).toSet().length!=rules.length) {
      throw const FormatException('Duplicate BPHS Rule ID');
    }
    return List<BphsBhavaLordRule>.unmodifiable(rules);
  }

  static List<BphsBhavaLordFinding> evaluate({required AstroChartResult chart,
      required List<BphsBhavaLordRule> rules}) {
    final planets={for (final p in chart.planets) p.name:p};
    return List<BphsBhavaLordFinding>.unmodifiable([
      for (final rule in rules)
        if (planets[lordOfNatalHouse(ascendantSignIndex:chart.ascendantSignIndex,
          house:rule.lordOfHouse)]!=null)
          if (wholeSignHouse(lagnaSign:chart.ascendantSignIndex,
             planetSign:planets[lordOfNatalHouse(
               ascendantSignIndex:chart.ascendantSignIndex,
               house:rule.lordOfHouse)]!.signIndex)==rule.placedInHouse)
            BphsBhavaLordFinding(rule:rule,
              lordPlanet:lordOfNatalHouse(ascendantSignIndex:chart.ascendantSignIndex,
                house:rule.lordOfHouse),
              planetPosition:planets[lordOfNatalHouse(
                ascendantSignIndex:chart.ascendantSignIndex,
                house:rule.lordOfHouse)]!,
              lagnaSign:chart.ascendantSignIndex),
    ]);
  }
}
