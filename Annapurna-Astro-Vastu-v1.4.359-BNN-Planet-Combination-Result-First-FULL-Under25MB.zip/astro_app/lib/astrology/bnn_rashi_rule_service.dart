import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';
import '../models/birth_data.dart';

/// Fresh BNN rashi rules from the user's 84-entry transcription.
/// No import from the retired 462-rule master or alias engine.
class BnnRashiRule {
  final String id;
  final String title;
  final String planet;
  final int signIndex;
  final String originalIf;
  final String originalThen;
  final String transcriptionFile;
  final int pdfPage;
  final int printedPage;
  final List<String> reviewFlags;
  final String reviewNote;

  const BnnRashiRule({
    required this.id,
    required this.title,
    required this.planet,
    required this.signIndex,
    required this.originalIf,
    required this.originalThen,
    required this.transcriptionFile,
    required this.pdfPage,
    required this.printedPage,
    required this.reviewFlags,
    required this.reviewNote,
  });

  factory BnnRashiRule.fromJson(Map<String, dynamic> raw) {
    final predicate = raw['predicate'] as Map<String, dynamic>;
    final source = raw['source'] as Map<String, dynamic>;
    if (predicate['op'] != 'planet_in_sign') {
      throw FormatException('Unsupported BNN predicate: ${predicate['op']}');
    }
    return BnnRashiRule(
      id: raw['id'] as String,
      title: raw['title'] as String,
      planet: predicate['planet'] as String,
      signIndex: (predicate['sign_index'] as num).toInt(),
      originalIf: raw['original_if'] as String,
      originalThen: raw['original_then'] as String,
      transcriptionFile: source['transcription'] as String,
      pdfPage: (source['pdf_page'] as num).toInt(),
      printedPage: (source['printed_page'] as num).toInt(),
      reviewFlags: (raw['review_flags'] as List).map((x) => x.toString()).toList(),
      reviewNote: (raw['review_note'] as String?) ?? '',
    );
  }
}

class BnnRashiFinding {
  final BnnRashiRule rule;
  final PlanetPosition? position;
  final int? house;
  final bool matched;
  final String? displayEffect;
  final String? annotation;

  const BnnRashiFinding({
    required this.rule,
    required this.position,
    required this.house,
    required this.matched,
    required this.displayEffect,
    required this.annotation,
  });

  bool get canDisplayEffect => matched && displayEffect != null && displayEffect!.trim().isNotEmpty;
}

class BnnRashiRuleService {
  const BnnRashiRuleService._();

  static const List<String> signs = [
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  static Future<List<BnnRashiRule>> load() async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_rashi_84_fresh.json');
    final map = jsonDecode(raw) as Map<String, dynamic>;
    final rows = map['rules'] as List;
    if (map['schema'] != 'ANNAPURNA-BNN-FRESH-RASHI-1.0' || rows.length != 84) {
      throw const FormatException('Invalid BNN fresh rashi catalog');
    }
    final rules = rows.map((row) => BnnRashiRule.fromJson(row as Map<String, dynamic>)).toList();
    if (rules.map((r) => r.id).toSet().length != 84) {
      throw const FormatException('Duplicate BNN Rashi Rule IDs');
    }
    return List.unmodifiable(rules);
  }

  static List<BnnRashiFinding> evaluate({
    required List<BnnRashiRule> rules,
    required AstroChartResult chart,
    required BirthGender gender,
  }) {
    final byPlanet = <String, PlanetPosition>{
      for (final p in chart.planets) p.name: p,
    };
    return rules.map((rule) {
      final p = byPlanet[rule.planet];
      final matched = p != null && p.signIndex == rule.signIndex;
      final int? house = matched ? (rule.signIndex - chart.ascendantSignIndex + 12) % 12 + 1 : null;
      if (!matched) {
        return BnnRashiFinding(rule: rule, position: p, house: null,
          matched: false, displayEffect: null, annotation: null);
      }
      final (effect, note) = _effectFor(rule, gender, chart);
      return BnnRashiFinding(rule: rule, position: p, house: house,
        matched: true, displayEffect: effect, annotation: note);
    }).toList(growable: false);
  }

  /// The original THEN is never rewritten in JSON. Only the displayed,
  /// chart-applicable clauses are filtered here.
  static (String?, String?) _effectFor(BnnRashiRule rule, BirthGender gender, AstroChartResult chart) {
    if (rule.id == 'BNN-RASHI-003' || rule.id == 'BNN-RASHI-024') {
      return (null, rule.reviewNote);
    }
    var effect = rule.originalThen;
    var note = rule.reviewNote;

    // These two passages contain demonstrably unclear OCR fragments.
    if (rule.id == 'BNN-RASHI-022') {
      effect = 'కుమారుడు జన్మించిన స్థలం కాకుండా వేరే స్థలంలో జీవితం.';
    } else if (rule.id == 'BNN-RASHI-061') {
      effect = 'పొడవైన ముక్కు. మాటకారి. జలుబు వల్ల బాధ.';
    }

    // Display the complete source wording for all chart genders.
    // E.g. a clause beginning 'స్త్రీ జాతకంలో' stays visible as written;
    // its wording describes the source's scope, not a gender-gated card.
    // The planet/sign predicate alone controls IF matching.

    // The Mercury-only subclause must be evaluated independently; do not
    // infer the absence of other planets without reading natal placements.
    if (rule.id == 'BNN-RASHI-039') {
      final otherPlanetsInSign = chart.planets.where(
          (p) => p.signIndex == rule.signIndex && p.name != 'Mercury').isNotEmpty;
      if (otherPlanetsInSign) {
        effect = effect.replaceAll(RegExp(r'బుధుడు మాత్రమే ఉంటే[^.।]*[.।]?'), '').trim();
        note = [note, 'బుధుడు ఒక్కడే లేనందున అదనపు ఉపఫలితం వర్తించదు.']
            .where((s) => s.isNotEmpty).join(' ');
      }
    }
    return (effect.isEmpty ? null : effect, note.isEmpty ? null : note);
  }

  static String dms(double longitude) {
    var seconds = ((longitude % 30.0) * 3600).round();
    if (seconds >= 108000) seconds = 107999;
    final degree = seconds ~/ 3600;
    final minute = (seconds % 3600) ~/ 60;
    final second = seconds % 60;
    return '$degree°${minute.toString().padLeft(2, '0')}′${second.toString().padLeft(2, '0')}″';
  }
}
