import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';

/// Keeps traditional source rules separate from karakatwa-based topic hints.
/// A cycle/sign contact alone is not an event prediction.
class BnnCycleReading {
  final String id;
  final String label;
  final String result;
  final String ifText;
  final String source;
  final String page;
  final bool isSourceRule;
  final String tone;
  const BnnCycleReading({required this.id, required this.label,
    required this.result, required this.ifText, required this.source,
    required this.page, required this.isSourceRule, required this.tone});
}

class BnnCycleResultCatalog {
  final Map<String,Map<String,dynamic>> contacts;
  final List<Map<String,dynamic>> sourceRules;
  const BnnCycleResultCatalog({required this.contacts,required this.sourceRules});
}

class BnnCycleResultService {
  const BnnCycleResultService._();

  static Future<BnnCycleResultCatalog> load() async {
    final txt=await rootBundle.loadString(
      'assets/bnn/bnn_cycle_contact_interpretations_v357.json');
    final json=jsonDecode(txt) as Map<String,dynamic>;
    if(json['schema']!='ANNAPURNA-BNN-CYCLE-CONTACT-INTERPRETATIONS-1.0') {
      throw const FormatException('Unsupported BNN cycle result schema');
    }
    final items=(json['contacts'] as List).cast<Map<String,dynamic>>();
    final byName={for (final c in items) c['planet'] as String: c};
    if(items.length!=9 || byName.length!=9) {
      throw const FormatException('Cycle karakatwa list must contain 9 planets');
    }
    return BnnCycleResultCatalog(contacts:Map.unmodifiable(byName),
      sourceRules:List.unmodifiable(
        (json['source_rules'] as List).cast<Map<String,dynamic>>()));
  }

  /// Jupiter cycles repeat contact geometry; the round is kept in the ID.
  /// The topic description is NOT presented as a verbatim R. G. Rao rule.
  static List<BnnCycleReading> forJupiter({required int cycle,
    required int ageStart, required List<PlanetPosition> natalContacts,
    required BnnCycleResultCatalog catalog, String? roundTopic}) {
    return List.unmodifiable([
      for(final p in natalContacts)
        if(catalog.contacts.containsKey(p.name))
          BnnCycleReading(
            id:'BNN-JUP-C${cycle.toString().padLeft(2,'0')}'
              '-AGE${ageStart.toString().padLeft(3,'0')}-${p.name.toUpperCase()}',
            label:'${catalog.contacts[p.name]!['label_te']} — కారకత్వ సూచన',
            result:'${catalog.contacts[p.name]!['note_te']}'
              '${roundTopic==null ? '' : ' ఈ సైకిల్ పరిశీలన అంశం: $roundTopic.'}',
            ifText:'గురువు సరళ ప్రోగ్రెషన్ ఈ వయస్సులో '
              'జన్మ ${catalog.contacts[p.name]!['label_te']} ఉన్న రాశికి చేరితే',
            source:'R. G. Rao BNN గ్రహకారకత్వ వివరణ — '
              'అన్వయ సూచన మాత్రమే; స్వతంత్ర మూల సంఘటన సూత్రం కాదు',
            page:'ఈ కారకత్వ వ్యాఖ్యానానికి ప్రత్యేక పేజీ-సూత్రం లేదు',
            isSourceRule:false, tone:'neutral'),
    ]);
  }

  static List<BnnCycleReading> forSaturn({required int cycle,
    required double ageStart, required List<PlanetPosition> natalContacts,
    required BnnCycleResultCatalog catalog, String? roundTopic}) {
    final results=<BnnCycleReading>[];
    for(final p in natalContacts) {
      final c=catalog.contacts[p.name];
      if(c==null) continue;
      for(final rule in catalog.sourceRules) {
        if(rule['moving_planet']=='Saturn' && rule['natal_planet']==p.name &&
           rule['cycle']==cycle) {
          results.add(BnnCycleReading(id:rule['id'] as String,
            label:'${c['label_te']} — మూల నియమం',
            result:rule['then_te'] as String,
            ifText:rule['if_te'] as String,
            source:rule['source'] as String,page:rule['page'] as String,
            isSourceRule:true,tone:rule['tone'] as String));
        }
      }
      results.add(BnnCycleReading(
        id:'BNN-SAT-C${cycle.toString().padLeft(2,'0')}'
          '-AGE${ageStart.toStringAsFixed(1)}-${p.name.toUpperCase()}',
        label:'${c['label_te']} — కారకత్వ సూచన',
        result:'శని యొక్క వృత్తి/బాధ్యతల సూచనకు '
          '${c['topics_te']} అంశాల అనుసంధానం పరిశీలించవచ్చు.'
          '${roundTopic==null ? '' : ' సైకిల్ అంశం: $roundTopic.'}',
        ifText:'శని సరళ ప్రోగ్రెషన్ జన్మ ${c['label_te']} ఉన్న రాశిని తాకితే',
        source:'R. G. Rao గ్రహకారకత్వాలు + శని రౌండ్ సందర్భం — '
          'వివరణాత్మక అన్వయం, ప్రత్యేక సంఘటన సూత్రం కాదు',
        page:'కారకత్వ ఆధారిత వ్యాఖ్యానం; నిర్దిష్ట మూల పేజీ లేదు',
        isSourceRule:false,tone:'neutral'));
    }
    return List.unmodifiable(results);
  }
}
