(function (root) {
  'use strict';
  function evaluateExpr(expr, facts) {
    if (!expr) return null;
    if (Object.prototype.hasOwnProperty.call(expr,'fact')) {
      const v = facts[expr.fact];
      return v === true ? true : v === false ? false : null;
    }
    if (Array.isArray(expr.all)) {
      const a=expr.all.map(x=>evaluateExpr(x,facts));
      if(a.includes(false)) return false;
      return a.every(x=>x===true) ? true : null;
    }
    if (Array.isArray(expr.any)) {
      const a=expr.any.map(x=>evaluateExpr(x,facts));
      if(a.includes(true)) return true;
      return a.every(x=>x===false) ? false : null;
    }
    throw new Error('Unsupported structured condition');
  }
  function usedFacts(expr, out) {
    out=out||[];if(!expr)return out;
    if(typeof expr.fact==='string'){if(!out.includes(expr.fact))out.push(expr.fact);return out;}
    (expr.all||expr.any||[]).forEach(x=>usedFacts(x,out));return out;
  }
  function evaluateLibrary(library, chartFacts) {
    const facts={}; const validKeys = library.fact_definitions.map(x=>x.key);
    validKeys.forEach(k=>{facts[k]=chartFacts[k]===true?true:chartFacts[k]===false?false:null;});
    const byId={};
    for(const rule of library.rules){
      if(rule.rule_id==='D12_ANC_03'||rule.rule_id==='D12_ANC_04') continue;
      const matched=rule.rule_type==='method'?null:evaluateExpr(rule.when,facts);
      byId[rule.rule_id]={...rule,match:matched,status:rule.rule_type==='method'?'METHOD_ONLY':matched===true?'MATCH':matched===false?'NO_MATCH':'DATA_MISSING',observations:usedFacts(rule.when)};
      if(rule.rule_id==='D12_ANC_02') facts.ancestor_blessings=matched;
    }
    for(const rule of library.rules) if(!(rule.rule_id in byId)){
      const matched=evaluateExpr(rule.when,facts);
      byId[rule.rule_id]={...rule,match:matched,status:matched===true?'MATCH_DERIVED':matched===false?'NO_MATCH':'DATA_MISSING',observations:usedFacts(rule.when)};
    }
    const result=library.rules.map(r=>byId[r.rule_id]);
    const contradictions=[];
    if(byId.D12_HELP_02.status==='MATCH' && byId.D12_HELP_03.status==='MATCH'){
      contradictions.push('D12_HELP_02 మరియు D12_HELP_03 రెండూ సరిపోతున్నాయి — విరుద్ధ సూచనలు. తుది వ్యక్తిగత తీర్పు ఇవ్వకూడదు.');
    }
    return {results:result,facts,contradictions};
  }
  root.AnnapurnaD12 = {evaluateExpr, evaluateLibrary,usedFacts};
  if (typeof module!=='undefined' && module.exports) module.exports=root.AnnapurnaD12;
})(typeof globalThis!=='undefined'?globalThis:this);
