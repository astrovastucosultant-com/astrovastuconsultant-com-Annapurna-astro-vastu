import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_master_service.dart';
import '../models/birth_data.dart';

/// Clean BNN report: topic-wise candidate results and a complete, searchable
/// verbatim source catalog. No OCR rule is asserted as an automatic chart hit.
class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnMasterRule>> _catalog = BnnMasterCatalog.load();
  int _period = 1;
  String? _topic;
  String _search = '';
  int _visibleLimit = 20;
  bool _showLibrary = false;
  bool _showTimeSource = false;

  static const _timeNames = ['గతం', 'వర్తమానం', 'భవిష్యత్తు'];

  @override
  Widget build(BuildContext context) => FutureBuilder<List<BnnMasterRule>>(
        future: _catalog,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Padding(
              padding: const EdgeInsets.all(16),
              child: Text('BNN నియమాలను లోడ్ చేయలేకపోయాం: ${snapshot.error}'),
            );
          }
          if (!snapshot.hasData) {
            return const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            );
          }
          final rules = snapshot.data!;
          final age = BnnMasterAnalysis.completedAge(
            widget.birthData.localDateTime, DateTime.now());
          final topics = rules.map((r) => r.topic).toSet().toList()..sort();
          final candidates = BnnMasterAnalysis.inspect(rules, widget.chart);
          final filteredCandidates = candidates.where((r) {
            return _topic == null || r.rule.topic == _topic;
          }).where((r) => _containsQuery(r.rule)).toList();
          final filteredRules = rules.where((r) {
            return (_topic == null || r.topic == _topic) && _containsQuery(r);
          }).toList();
          final timeRules = rules.where((r) =>
              r.condition.contains('రౌండ్') ||
              r.condition.contains('రవాణా') ||
              r.condition.contains('గోచార') ||
              r.result.contains('వయస్సు') ||
              r.result.contains('కాలం')).toList();

          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _sectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('భృగు నాడీ (BNN)',
                        style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 5),
                    const Text('అంశాలవారీ ఫలితాలు • గతం / వర్తమానం / భవిష్యత్తు',
                        style: TextStyle(color: Colors.black54)),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 6,
                      children: [
                        _numberPill('మొత్తం ${rules.length}', const Color(0xFFECEFF5)),
                        _numberPill('గ్రహస్థితి సూచనలు ${candidates.length}',
                            const Color(0xFFE9F6EA)),
                        _numberPill('OCR పరిశీలన 343', const Color(0xFFFFF0DD)),
                      ],
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'గ్రహాల అమరిక సరిపోవడం అనేది ప్రారంభ పరిశీలన మాత్రమే. '
                      'నాడీ గ్రహసంబంధం, గ్రహ క్రమం, దృష్టి, గోచారం, వయస్సు '
                      'నిర్ధారణ కాకుండా సంఘటన జరిగిందని/జరుగుతుందని చెప్పలేము.',
                      style: TextStyle(fontSize: 12, height: 1.5),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              _sectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('కాల పరిశీలన',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      child: SegmentedButton<int>(
                        segments: const [
                          ButtonSegment(value: 0, label: Text('గతం')),
                          ButtonSegment(value: 1, label: Text('వర్తమానం')),
                          ButtonSegment(value: 2, label: Text('భవిష్యత్తు')),
                        ],
                        selected: {_period},
                        showSelectedIcon: false,
                        onSelectionChanged: (selected) =>
                            setState(() => _period = selected.first),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(_periodHeading(age),
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 5),
                    Text(_periodDescription(age),
                        style: const TextStyle(fontSize: 13, height: 1.5)),
                    const SizedBox(height: 6),
                    Text(BnnMasterAnalysis.roundInfo(_referenceAge(age)),
                        style: const TextStyle(fontSize: 12, color: Colors.black54)),
                    const SizedBox(height: 6),
                    const Text('గురు 12 సంవత్సరాల, శని 30 సంవత్సరాల సుమారు '
                        'చక్రాలు అధ్యయన సూచికలు మాత్రమే; ఇవి ఖచ్చితమైన '
                        'గోచార గణన లేదా సంఘటన తేదీలు కావు.',
                        style: TextStyle(fontSize: 12, color: Colors.black54)),
                    const SizedBox(height: 12),
                    const Text('ఈ కాలంలో మూలసూత్రం సూచించే పరిశీలన అంశాలు',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    ..._studyBands(age).map((band) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Text(
                        'గురు ${band.round}వ చక్రం • '
                        '${band.fromAge}–${band.toAge} వయస్సు • '
                        '${band.sourceTheme}',
                        style: const TextStyle(fontSize: 13, height: 1.4),
                      ),
                    )),
                    const Text('మూలం: BNN-BOOK-R-A03, PDF పేజీ 2. '
                        'OCR పునఃపరిశీలన అవసరం; ఈ అంశాలు జరిగాయనే లేదా '
                        'జరుగుతాయనే ఫలితం కాదు.',
                        style: TextStyle(color: Colors.black54, fontSize: 11.5)),
                    const Divider(height: 24),
                    InkWell(
                      onTap: () => setState(() => _showTimeSource = !_showTimeSource),
                      child: Row(children: [
                        const Expanded(child: Text('కాలానికి సంబంధించిన మూల సూత్రాలు',
                            style: TextStyle(fontWeight: FontWeight.w700))),
                        Text('${timeRules.length}'),
                        Icon(_showTimeSource ? Icons.expand_less : Icons.expand_more),
                      ]),
                    ),
                    if (_showTimeSource) ...[
                      const SizedBox(height: 10),
                      for (final rule in timeRules.take(20))
                        _resultRow(rule, isCandidate: false),
                      if (timeRules.length > 20)
                        Text('మిగిలిన ${timeRules.length - 20} కాల నియమాలు '
                            'క్రింద నియమ గ్రంథాలయంలో శోధించవచ్చు.',
                            style: const TextStyle(fontSize: 12)),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 10),
              _sectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('అంశాన్ని ఎంచుకోండి',
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      value: _topic ?? '__all__',
                      isExpanded: true,
                      decoration: const InputDecoration(
                        isDense: true,
                        border: OutlineInputBorder(),
                      ),
                      items: [
                        const DropdownMenuItem(
                            value: '__all__', child: Text('అన్ని అంశాలు')),
                        ...topics.map((topic) => DropdownMenuItem(
                            value: topic, child: Text(topic, overflow: TextOverflow.ellipsis))),
                      ],
                      onChanged: (v) => setState(() {
                        _topic = v == '__all__' ? null : v;
                        _visibleLimit = 20;
                      }),
                    ),
                    const SizedBox(height: 9),
                    TextField(
                      decoration: const InputDecoration(
                        isDense: true,
                        border: OutlineInputBorder(),
                        prefixIcon: Icon(Icons.search),
                        hintText: 'ఫలితం / గ్రహం / నియమం / ID వెతకండి',
                      ),
                      onChanged: (v) => setState(() {
                        _search = v.trim().toLowerCase();
                        _visibleLimit = 20;
                      }),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              _sectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${_timeNames[_period]} — అంశాలవారీ జాతక పరిశీలన',
                        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 5),
                    const Text('ఇవి జన్మగ్రహాల ఒకే రాశి అమరిక ఆధారంగా '
                        'తాత్కాలికంగా గుర్తించిన నియమాలు. '
                        'కాలానికి సరిపోయిన నిర్ధారిత ఫలితాలు కావు.',
                        style: TextStyle(fontSize: 12, color: Colors.black54)),
                    const SizedBox(height: 10),
                    if (filteredCandidates.isEmpty)
                      const Text('ఈ అంశంలో ప్రాథమిక గ్రహ సంయోగ సూచనలు లేవు. '
                          'క్రింద 462 మూల నియమాల గ్రంథాలయం పరిశీలించండి.'),
                    for (final evidence in filteredCandidates.take(24))
                      _resultRow(evidence.rule,
                          isCandidate: true, placement: evidence.placement),
                    if (filteredCandidates.length > 24)
                      Text('మరో ${filteredCandidates.length - 24} సూచనలు ఉన్నాయి. '
                          'అంశాన్ని ఎంచుకొని శోధించండి.'),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              _sectionCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: () => setState(() => _showLibrary = !_showLibrary),
                      child: Row(children: [
                        const Expanded(child: Text('BNN పూర్తి IF–THEN నియమ గ్రంథాలయం',
                            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
                        Text('${filteredRules.length}'),
                        Icon(_showLibrary ? Icons.expand_less : Icons.expand_more),
                      ]),
                    ),
                    const SizedBox(height: 6),
                    const Text('మొత్తం 462 మూల నియమాలు (343 OCR పరిశీలన, '
                        '82 గ్రహస్థితి ధృవీకరణ, 37 REVIEW). '
                        'ఫలితం టచ్ చేస్తే IF, జాతక పరిశీలన, మూలం, స్థితి కనిపిస్తాయి.',
                        style: TextStyle(fontSize: 12, color: Colors.black54)),
                    if (_showLibrary) ...[
                      const SizedBox(height: 9),
                      for (final rule in filteredRules.take(_visibleLimit))
                        _resultRow(rule, isCandidate: false),
                      if (filteredRules.length > _visibleLimit)
                        Align(
                          alignment: Alignment.center,
                          child: TextButton.icon(
                            onPressed: () => setState(() => _visibleLimit += 25),
                            icon: const Icon(Icons.add),
                            label: const Text('మరో 25 నియమాలు చూపించండి'),
                          ),
                        ),
                    ],
                  ],
                ),
              ),
            ],
          );
        },
      );

  List<BnnRoundStudyBand> _studyBands(int age) {
    if (age < 0) return const [];
    if (_period == 0) return BnnMasterAnalysis.jupiterStudyBands(0, age - 1);
    if (_period == 1) return BnnMasterAnalysis.jupiterStudyBands(age, age);
    return BnnMasterAnalysis.jupiterStudyBands(age + 1, age + 12);
  }

  int _referenceAge(int current) {
    if (_period == 0) return current > 0 ? current - 1 : 0;
    if (_period == 2) return current + 1;
    return current < 0 ? 0 : current;
  }

  String _periodHeading(int age) {
    if (age < 0) return 'జనన తేదీ భవిష్యత్తులో ఉంది';
    if (_period == 0) {
      return age == 0 ? 'ఇప్పటి వరకు గడిచిన పూర్తి సంవత్సరాలు: 0'
          : 'గతం: 0 నుంచి ${age - 1} పూర్తి సంవత్సరాల వయస్సు వరకు';
    }
    if (_period == 1) return 'వర్తమానం: $age సంవత్సరాల వయస్సు';
    return 'భవిష్యత్తు: ${age + 1} నుంచి ${age + 12} సంవత్సరాల వయస్సు వరకు';
  }

  String _periodDescription(int age) {
    if (age < 0) return 'జననం భవిష్యత్తులో ఉన్నందున కాల విశ్లేషణ అందుబాటులో లేదు.';
    if (_period == 0) {
      return 'గడిచిన జన్మ సంవత్సరాలు: '
          '${widget.birthData.localDateTime.year}–'
          '${widget.birthData.localDateTime.year + (age > 0 ? age - 1 : 0)}. '
          'ఏ సంఘటన నిజంగా జరిగిందో జాతక వివరాల ఆధారంగా మాత్రమే నిర్ధారించలేము.';
    }
    if (_period == 1) {
      return 'ప్రస్తుత జన్మ సంవత్సరం: '
          '${BnnMasterAnalysis.ageYear(widget.birthData, age)}. '
          'ఫలితానికి అవసరమైన ప్రస్తుత గోచారం, కాలసూత్రం ఇంకా జోడించాలి.';
    }
    return 'భవిష్యత్ అధ్యయన సంవత్సరాలు: '
        '${BnnMasterAnalysis.ageYear(widget.birthData, age + 1)}–'
        '${BnnMasterAnalysis.ageYear(widget.birthData, age + 12)}. '
        'ఇవి గణించిన వయస్సు పరిధి మాత్రమే; సంఘటన జరుగుతుందని హామీ కాదు.';
  }

  bool _containsQuery(BnnMasterRule r) {
    if (_search.isEmpty) return true;
    final text = '${r.id} ${r.topic} ${r.condition} ${r.result} '
        '${r.source} ${r.inspection}'.toLowerCase();
    return text.contains(_search);
  }

  Widget _sectionCard({required Widget child}) => Card(
        margin: EdgeInsets.zero,
        color: Colors.white,
        surfaceTintColor: Colors.transparent,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: child,
        ),
      );

  Widget _numberPill(String label, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(label, style: const TextStyle(fontSize: 12,
            fontWeight: FontWeight.w700)),
      );

  Widget _resultRow(BnnMasterRule rule, {
    required bool isCandidate,
    String? placement,
  }) => Padding(
        padding: const EdgeInsets.only(bottom: 7),
        child: Material(
          borderRadius: BorderRadius.circular(10),
          color: const Color(0xFFF7F8FA),
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => _showRule(rule,
                isCandidate: isCandidate, placement: placement),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
              child: Row(children: [
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(rule.result,
                        style: const TextStyle(fontSize: 14.5,
                            fontWeight: FontWeight.w700, height: 1.4)),
                    const SizedBox(height: 5),
                    Text(isCandidate
                            ? '${rule.topic} • గ్రహస్థితి సూచన మాత్రమే'
                            : '${rule.topic} • ${_statusLabel(rule.status)}',
                        style: const TextStyle(fontSize: 11.5,
                            color: Colors.black54)),
                  ],
                )),
                const SizedBox(width: 5),
                const Icon(Icons.chevron_right, color: Color(0xFF7B1E2B)),
              ]),
            ),
          ),
        ),
      );

  String _statusLabel(String status) => switch (status) {
        'OCR_REVIEW' => 'OCR మూల పరిశీలన అవసరం',
        'FACTS_REQUIRED' => 'జాతక ధృవీకరణ అవసరం',
        'REVIEW' => 'గ్రంథ భావన పరిశీలన అవసరం',
        _ => status,
      };

  void _showRule(BnnMasterRule rule, {
    required bool isCandidate,
    String? placement,
  }) {
    final natal = BnnMasterAnalysis.natalPositionsForCondition(
        rule.condition, widget.chart);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.75,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('BNN — జాతక పరిశీలన రూల్',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                const SizedBox(height: 12),
                _detail('ఫలితం', rule.result),
                _detail('IF — నియమం', rule.condition),
                _detail('జన్మ గ్రహస్థితులు', natal),
                if (placement != null)
                  _detail('ప్రాథమికంగా గుర్తించిన అమరిక', placement),
                _detail('జాతక పరిశీలన', rule.inspection),
                _detail('ధృవీకరణ స్థితి', _statusLabel(rule.status)),
                _detail('మూల గ్రంథం',
                    '${rule.source} • PDF పేజీ ${rule.sourcePage} • ${rule.id}'),
                _detail('పరిహారం', rule.remedy),
                const SizedBox(height: 6),
                Text(isCandidate
                    ? 'ఈ అమరికకు సంబంధిత గ్రంథసూత్రం పూర్తిగా నిర్ధారణ కాలేదు. '
                        'సంఘటన గడిచిందా, ఇప్పుడు ఉందా, రాబోతుందా అన్నది '
                        'కాలగణన లేకుండా చెప్పడం లేదు.'
                    : 'ఇది మూల గ్రంథంలోని IF–THEN నమోదు. '
                        'జాతకానికి వర్తించిందని స్వయంచాలకంగా నిర్ణయించలేదు.',
                    style: const TextStyle(fontSize: 12, color: Color(0xFF875A08))),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _detail(String heading, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(heading, style: const TextStyle(fontWeight: FontWeight.w800,
              color: Color(0xFF7B1E2B))),
          const SizedBox(height: 4),
          SelectableText(value, style: const TextStyle(height: 1.5)),
        ]),
      );
}
