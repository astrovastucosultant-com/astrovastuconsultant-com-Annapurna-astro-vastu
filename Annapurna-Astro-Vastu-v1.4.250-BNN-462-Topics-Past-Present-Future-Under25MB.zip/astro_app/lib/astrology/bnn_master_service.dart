import 'dart:convert';

import 'package:flutter/services.dart';

import 'astro_models.dart';
import '../models/birth_data.dart';

/// The source catalog is kept verbatim. A chart placement check is NOT the same
/// as a verified Nadi prediction or a timed transit match.
class BnnMasterRule {
  final String id;
  final String source;
  final int sourcePage;
  final String topic;
  final String condition;
  final String result;
  final String inspection;
  final String remedy;
  final String status;

  const BnnMasterRule({
    required this.id,
    required this.source,
    required this.sourcePage,
    required this.topic,
    required this.condition,
    required this.result,
    required this.inspection,
    required this.remedy,
    required this.status,
  });

  factory BnnMasterRule.fromJson(Map<String, dynamic> json) => BnnMasterRule(
        id: json['id'] as String,
        source: json['source'] as String,
        sourcePage: json['source_page'] as int,
        topic: json['topic'] as String,
        condition: json['condition'] as String,
        result: json['result'] as String,
        inspection: json['inspection'] as String,
        remedy: json['remedy'] as String,
        status: json['status'] as String,
      );
}

class BnnMasterCatalog {
  static Future<List<BnnMasterRule>> load() async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_master_462.json');
    final parsed = jsonDecode(raw) as Map<String, dynamic>;
    final items = (parsed['rules'] as List<dynamic>)
        .map((e) => BnnMasterRule.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
    if (items.length != 462 || items.map((r) => r.id).toSet().length != 462) {
      throw const FormatException('BNN 462 rule catalog is incomplete');
    }
    return items;
  }
}

class BnnNatalEvidence {
  final BnnMasterRule rule;
  final String placement;
  const BnnNatalEvidence(this.rule, this.placement);
}


class BnnRoundStudyBand {
  final int round;
  final int fromAge;
  final int toAge;
  final String sourceTheme;
  const BnnRoundStudyBand(this.round, this.fromAge, this.toAge,
      this.sourceTheme);
}

class BnnMasterAnalysis {
  static const Map<String, String> teluguPlanetNames = {
    'సూర్యుడు': 'Sun',
    'చంద్రుడు': 'Moon',
    'కుజుడు': 'Mars',
    'బుధుడు': 'Mercury',
    'గురుడు': 'Jupiter',
    'శుక్రుడు': 'Venus',
    'శని': 'Saturn',
    'రాహువు': 'Rahu',
    'కేతువు': 'Ketu',
  };

  static const signNames = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం',
    'సింహం', 'కన్య', 'తుల', 'వృశ్చికం',
    'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  /// Only an explicit, unqualified dash-separated chain from BNN N that
  /// requires chart facts is checked. Same-sign natal proximity is a
  /// *candidate placement*, never asserted to prove the source's relational
  /// sequence, yogas, timing or consequence.
  static BnnNatalEvidence? tentativeNatalPlacement(
    BnnMasterRule rule,
    AstroChartResult chart,
  ) {
    if (rule.source != 'BNN N' || rule.status != 'FACTS_REQUIRED') {
      return null;
    }
    final parts = rule.condition.split('—');
    if (parts.length < 2 || parts.length > 3 ||
        parts.any((p) => !teluguPlanetNames.containsKey(p.trim()))) {
      return null;
    }
    final positions = <PlanetPosition>[];
    for (final name in parts) {
      final english = teluguPlanetNames[name.trim()];
      final found = chart.planets.where((p) => p.name == english);
      if (found.isEmpty) return null;
      positions.add(found.first);
    }
    final sign = positions.first.signIndex;
    if (positions.any((p) => p.signIndex != sign)) return null;
    final details = <String>[];
    for (var i = 0; i < parts.length; i++) {
      details.add('${parts[i].trim()}: '
          '${positions[i].degreesInSign.toStringAsFixed(2)}°');
    }
    return BnnNatalEvidence(
      rule,
      'జన్మ చక్రంలో ${signNames[sign]} రాశిలో ఉన్న గ్రహాలు — '
      '${details.join(', ')}. ఒకే రాశి అనేది ప్రారంభ పరిశీలన మాత్రమే; '
      'BNN నాడీ గ్రహసంబంధం, గ్రహ క్రమం, దృష్టులు ఇంకా ధృవీకరించాలి.',
    );
  }

  static List<BnnNatalEvidence> inspect(
    List<BnnMasterRule> rules,
    AstroChartResult chart,
  ) {
    final result = <BnnNatalEvidence>[];
    for (final rule in rules) {
      final hit = tentativeNatalPlacement(rule, chart);
      if (hit != null) result.add(hit);
    }
    return result;
  }

  static String natalPositionsForCondition(
    String condition,
    AstroChartResult chart,
  ) {
    final positions = <String>[];
    for (final entry in teluguPlanetNames.entries) {
      if (!condition.contains(entry.key)) continue;
      final matches = chart.planets.where((p) => p.name == entry.value);
      if (matches.isEmpty) continue;
      final planet = matches.first;
      positions.add('${entry.key}: ${signNames[planet.signIndex]} '
          '${planet.degreesInSign.toStringAsFixed(2)}°');
    }
    if (positions.isEmpty) return 'గ్రహ స్థానాలు ఈ షరతు నుంచి స్వయంగా గుర్తించలేకపోయాం.';
    return positions.join('  •  ');
  }

  static int completedAge(DateTime birthday, DateTime today) {
    var years = today.year - birthday.year;
    if (today.month < birthday.month ||
        (today.month == birthday.month && today.day < birthday.day)) {
      years--;
    }
    return years;
  }

  static String ageYear(BirthData birth, int age) {
    return '${birth.localDateTime.year + age}';
  }

  /// R-A03 states a list of Jupiter-round themes, but its scan text remains
  /// OCR_REVIEW. These are age-band *study topics*, not timed predictions.
  static List<BnnRoundStudyBand> jupiterStudyBands(int fromAge, int toAge) {
    const themes = <String>[
      'స్వీయ జీవితం',
      'కుటుంబం / ఆర్థికం / వివాహం',
      'ప్రయాణాలు / సోదరులు',
      'ఇల్లు / నివాసం',
      'సంతానం',
      'ప్రమాద సూచనల మూల పరిశీలన',
    ];
    if (toAge < fromAge || toAge < 0) return const [];
    final output = <BnnRoundStudyBand>[];
    for (var i = 0; i < themes.length; i++) {
      final start = i * 12;
      final end = start + 11;
      if (start > toAge || end < fromAge) continue;
      output.add(BnnRoundStudyBand(i + 1,
          start > fromAge ? start : fromAge,
          end < toAge ? end : toAge, themes[i]));
    }
    return output;
  }

  static String roundInfo(int age) {
    if (age < 0) return 'జననం ఇంకా జరగలేదు';
    final jupiter = age ~/ 12 + 1;
    final saturn = age ~/ 30 + 1;
    return 'గురు సుమారు $jupiter వ చక్రం • శని సుమారు $saturn వ చక్రం';
  }
}
