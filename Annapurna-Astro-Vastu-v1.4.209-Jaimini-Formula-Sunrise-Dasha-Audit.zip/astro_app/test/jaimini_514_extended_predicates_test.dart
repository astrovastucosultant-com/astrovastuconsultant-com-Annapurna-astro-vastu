import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/jaimini_complete_sutra_service.dart';
import 'package:astro_app/astrology/jaimini_extended_rule_engine.dart';

PlanetPosition planet(String name, double longitude) => PlanetPosition(
  name:name, shortName:name.substring(0, 2), longitude:longitude,
  latitude:0, speed:1,
);

double natalLongitudeForD9(int sign) {
  for (var degree=0.0;degree<360;degree+=0.5) {
    if (VargaService.signForLongitude(degree,9)==sign) return degree;
  }
  throw StateError('Missing Navamsa sign $sign');
}

JaiminiResult snapshot({int kl=0,int al=0,int a7=6,int ul=1}) {
  final padas=<JaiminiPadaRow>[
    for (var i=1;i<=12;i++) JaiminiPadaRow(
      padaNumber:i, sourceSignIndex:i-1, lord:'Sun',
      lordSignIndex:0, distance:1,
      padaSignIndex:i==1?al:i==7?a7:i==12?ul:i-1,
    ),
  ];
  final target=<int,List<int>>{
    for (var i=0;i<12;i++) i:
      (i%3==0?[4,7,10]:i%3==1?[3,6,9]:[2,5,8])
        .map((j)=>(i+j)%12).toList(),
  };
  return JaiminiResult(
    charaKarakas:const [JaiminiKaraka(code:'AK',planet:'Sun',effectiveDegree:12)],
    atmakaraka:'Sun', karakamsaSignIndex:kl, rashiDrishti:target,
    argalaFromLagna:const [], arudhaPadas:padas,
    applicableRules:const [], hasDegreeTie:false,
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('source-specific stone/brick house branches do not require one-planet confirmation', () {
    final mars=natalLongitudeForD9(3);
    final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[
        planet('Sun',2),planet('Mars',mars),planet('Ketu',mars+0.5),
        planet('Saturn',38),planet('Rahu',132),
      ]);
    final r=JaiminiExtendedRuleEngine.check('3.51',chart,snapshot());
    expect(r, isNotNull);
    expect(r!.calculated,isTrue);
    expect(r.matched,isNull);
    expect(r.evidence,contains('కుజ+కేతు: ఇటుక ఇల్లు'));
    expect(r.evidence,isNot(contains('శని+రాహు: రాతి ఇల్లు')));
  });

  test('relative UL and AL calculations use distinct reference signs', () {
    final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[planet('Sun',12)]);
    final r=JaiminiExtendedRuleEngine.check('6.11',chart,
      snapshot(al:0,a7:7,ul:2));
    expect(r!.matched,isTrue);
    expect(r.evidence,contains('సాపేక్ష స్థానం 8'));
  });

  test('conception predicates never use natal chart as conception chart', () {
    final chart=AstroChartResult(julianDay:0,ayanamsaDegrees:0,
      ascendantLongitude:0,engineVersion:'test',planets:[planet('Sun',12)]);
    expect(JaiminiExtendedRuleEngine.check('13.10',chart,snapshot()),isNull);
    const rule=JaiminiCompleteSutraRule(id:'13.10',major:'ఆధాన',section:'13B',
      condition:'ఆధాన లగ్నం నుంచి 2వలో రవి',result:'గర్భ సూత్రం',
      source:'4.3',page:38,sourceKind:'సూత్రం');
    final audit=JaiminiCompleteSutraService.check(
      rule:rule,chart:chart,jaimini:snapshot());
    expect(audit.matched,isNull);
    expect(audit.evidence,contains('ఆధాన'));
  });

  test('all 514 source catalog rows remain intact', () async {
    final records=await JaiminiCompleteSutraService.load();
    expect(records.length,514);
    expect(records.map((r)=>r.id).toSet().length,514);
  });
}
