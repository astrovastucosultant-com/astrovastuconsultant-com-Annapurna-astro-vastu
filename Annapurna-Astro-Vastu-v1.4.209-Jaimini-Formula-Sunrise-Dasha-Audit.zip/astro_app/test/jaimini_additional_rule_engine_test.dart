import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/jaimini_service.dart';
import 'package:astro_app/astrology/jaimini_additional_rule_engine.dart';
import 'package:astro_app/astrology/jaimini_complete_sutra_service.dart';

PlanetPosition p(String name, double longitude) => PlanetPosition(
  name: name, shortName: name.substring(0, 2), longitude: longitude,
  latitude: 0, speed: 1,
);

AstroChartResult chart({bool conjoined = true}) => AstroChartResult(
  julianDay: 2450000, ayanamsaDegrees: 24,
  ascendantLongitude: 10, engineVersion: 'synthetic-test',
  planets: <PlanetPosition>[
    p('Sun', 12), p('Moon', 45), p('Mars', conjoined ? 17 : 78),
    p('Mercury', 83), p('Jupiter', 98), p('Venus', 183),
    p('Saturn', 267), p('Rahu', 330), p('Ketu', 150),
  ],
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('5.25 conjunction requires two distinct lords in one D1 sign', () {
    final matching = chart(conjoined: true);
    final missed = chart(conjoined: false);
    final hit = JaiminiAdditionalRuleEngine.check(
        '5.25', matching, JaiminiService.calculate(matching));
    final noHit = JaiminiAdditionalRuleEngine.check(
        '5.25', missed, JaiminiService.calculate(missed));
    expect(hit!.matched, isTrue);
    expect(noHit!.matched, isFalse);
  });

  test('argala and sign-strength calculations are not event confirmations', () {
    final c = chart();
    final j = JaiminiService.calculate(c);
    for (final id in <String>['1.11','1.12','1.26','1.27',
      '1.28','1.29','1.30','1.34','1.35','1.36']) {
      final r = JaiminiAdditionalRuleEngine.check(id, c, j);
      expect(r, isNotNull, reason: id);
      expect(r!.calculated, isTrue, reason: id);
      expect(r.matched, isNull, reason: id);
    }
  });

  test('multi-chart and sensitive child rules remain evidence only', () {
    final c = chart();
    final j = JaiminiService.calculate(c);
    for (final id in <String>['5.14','5.15','5.16','5.17',
      '5.18','5.19','5.20','5.21','5.22','5.23','7.1',
      '7.2','7.3','7.4','7.5','7.7','7.8','7.9','7.10','7.11']) {
      final r = JaiminiAdditionalRuleEngine.check(id, c, j);
      expect(r, isNotNull, reason: id);
      expect(r!.calculated, isTrue, reason: id);
      expect(r.matched, isNull, reason: id);
    }
  });

  test('conception rules stay pending, not mapped to natal chart', () {
    final c = chart();
    final j = JaiminiService.calculate(c);
    expect(JaiminiAdditionalRuleEngine.check('13.10', c, j), isNull);
    const rule = JaiminiCompleteSutraRule(
      id: '13.10', major: 'ఆధాన', section: '13B',
      condition: 'ఆధాన లగ్నం', result: 'గర్భ', source: '4.3',
      page: 38, sourceKind: 'PDF source',
    );
    final state = JaiminiCompleteSutraService.check(
        rule: rule, chart: c, jaimini: j);
    expect(state.matched, isNull);
    expect(state.evidence, contains('ఆధాన'));
  });

  test('source catalog remains exactly 514 unique items', () async {
    final rules = await JaiminiCompleteSutraService.load();
    expect(rules.length, 514);
    expect(rules.map((r) => r.id).toSet().length, 514);
    expect(rules.where((r) =>
        JaiminiAdditionalRuleEngine.supportedIds.contains(r.id)).length,
      JaiminiAdditionalRuleEngine.supportedIds.length);
  });
}
