# Naibod Axes Flutter integration

Western Progression screen now calculates Naibod symbolic progressed ASC, MC, DSC and IC using the natal tropical MC and latitude. The same selected date is used for Secondary, Solar Arc and Naibod display. No BTR scoring or event date claims are made.

Validation: source integration checked; Flutter SDK not available in this environment, so flutter analyze/test/build remain to be run in CI.
