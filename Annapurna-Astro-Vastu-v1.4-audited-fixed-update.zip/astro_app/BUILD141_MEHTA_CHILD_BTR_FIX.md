# Build141 — S.K. Mehta BTR: Child-event evidence separation

## Scope
- Preserve **Build140** source, KP, BPD, BNN, BCP, chart rotation, Western aspects and period-calendar code.
- **M06 child birth**: independently report 3-layer direct AD/PD/Sukshma matching and optional D1/D7 contextual relationships; show source-book rule validity separately.
- Context checks consider D1 houses 1/5/9, D7 houses 1/5/9, planetary sign occupancy, birth nakshatra/star dispositors and Jupiter karaka. These are **app-designed diagnostic suggestions**, not verified original SK Mehta source rules.
- Strict source-only scoring: **D1/D7 context does NOT change the M06 Mehta direct score, period selection, or candidate ranking.** It is displayed in a separate diagnostic panel. A contextual indication is not an M06 book-rule match.
- Mehta Applicability: use 3 independent verified events and multiple types as before for a stronger choice; when verified evidence is insufficient, cautiously allow a clearly **PROVISIONAL** period indication with 3 independent reported events, at least two types, 18-point average separation, no contradictory wins, and ≥2 favourable independent event-level comparisons. Otherwise remain undecided and show conservative overlap as an app ranking rather than source match.
- Both separate period indices and source-check status remain in the report.

## Verification guidance
- The observed events **28-May-2009 at 10:10**, **02-Nov-2011 at 08:36**, and **05-Dec-2012 at 09:45** are regressions for data plumbing, NOT reference horoscopes. Without complete correct birthplace, original time, ephemeris and book-rule provenance, do not assert the new percentages or birth-second accuracy.
- Verify the original Mehta M06 dictum (if available) against his original book before attributing the extra D7/Nakshatra checks to him.
- Distinguish period synchronization from birth-time correction.

## Quality gate
- Dart/Flutter compile and tests need a real SDK; GitHub Actions must run. ZIP integrity and file-level source comparisons can be checked offline.
