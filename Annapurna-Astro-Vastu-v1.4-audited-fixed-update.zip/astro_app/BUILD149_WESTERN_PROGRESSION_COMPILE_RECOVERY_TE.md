# Build149 — Western Progression సవరణ

- GitHub Build #120/#121లో `lib/screens/progression_analysis_screen.dart:178` వద్ద ఉన్న అదనపు `)` తొలగించబడింది.
- తాజా మధ్యంతర ZIPలో నిలిపివేసిన WesternProgressionService స్థానంలో Swiss Ephemeris ఆధారిత Live Tropical Secondary/Solar Arc గణన పునరుద్ధరించబడింది.
- Natal ASC/MC: Placidus tropical; progressed Sun/Moon/Mercury/Venus/Mars మరియు Solar-Arc directed planets/angles చేర్చబడ్డాయి.
- సంఘటన తేదీ ఎంపిక, 0.25–2.0° Orb, ప్రస్తుత contacts; ±180 రోజుల పరిధిలో exact angular-crossing తేదీల కోసం బైసెక్షన్ పరీక్ష జోడించబడింది.
- Western evidence మాత్రమే; SK Mehta, KP, BNN, BPD, BCP మరియు వారి ఫలిత స్కోర్లు మార్చలేదు.
- Exact Aspect Date అంటే గ్రహ కోణం, **సంఘటన ఖచ్చిత తేదీ కాదు**.
- Naibod/Tertiary, నిజమైన BTR seconds calculation పూర్తయినట్లు ప్రకటించలేదు.
- కొత్త unit tests చేర్చబడినవి; Flutter SDK ఇక్కడ లేకపోవడం వల్ల local `flutter test`/APK compile నిర్వహించలేదు.
