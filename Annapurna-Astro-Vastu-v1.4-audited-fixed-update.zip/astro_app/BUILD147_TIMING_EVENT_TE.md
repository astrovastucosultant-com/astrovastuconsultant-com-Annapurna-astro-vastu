# Build 147 — Timing of Event

BTR → Progression Analysis → Timing of Event.
22 event choices, start/end date pickers, Search button and explicit engine-not-connected result.
No unverified prediction dates; no new Flutter calculation engine.
ZIP integrity only; Flutter compile not verified.
