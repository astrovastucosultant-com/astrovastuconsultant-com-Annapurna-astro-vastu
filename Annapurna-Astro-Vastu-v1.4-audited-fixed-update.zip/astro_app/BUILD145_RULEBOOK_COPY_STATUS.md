# Build 145 — Rulebook Copy + Honest Status

- Adds copy-to-clipboard for selected SK Mehta / BTR rule with source, page, condition, inspection, and result.
- Shows an explicit not-tested badge; this screen does NOT calculate chart-specific applicability.
- No automatic green/red rule evaluation and no APK produced.
- Retains prior BTR v5 experimental assets.
- This is Flutter source; build and device testing still required.
