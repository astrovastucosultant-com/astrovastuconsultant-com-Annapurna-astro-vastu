# Build140 — S.K. Mehta calendar / month-day synchronization

**Source:** S.K. Mehta, *New Dimensions in Hindu Astrology*, Ch. XVI, printed pp. 218–252. User-provided scan; comparisons in `SK_Mehta_Months_Days_Synchronization_Deep_Audit_TE.md`.

## What changed

- `lib/astrology/mehta_period_calendar.dart`: book Y/M/D period arithmetic on 360-day years / 30-day months, explicit civil Gregorian month/day conversion, signed period synchronization. Distinguishes a historical *dasha period shift* from a birth-time correction.
- `lib/astrology/dasha_service.dart`: optional Mehta book-Gregorian calendar basis for Vimshottari/Tribhagi/Khanda; original continuous 365.2425 default remains unchanged for all other callers. First post-birth dasha transition is anchored to the natal balance. For book-basis sublevels, subdivisions interpolate across actual parent civil interval to avoid zero-length Sukshma/Prana periods; that interpolation remains an app convention, not an author-verified daily table.
- `lib/astrology/mehta_btr_service.dart`: apply synchronization to source period boundaries, not to natal chart/KP cusps or Moon-derived birth balance. All Mehta scoreCandidates in search use the selected calendar basis and the same chosen sync correction.
- `lib/screens/mehta_btr_screen.dart`: practitioner-controlled month/day offset (forward/back), book/legacy calendar comparison, persisted settings and printed report notes. No automatic copying of example corrections onto an unrelated chart.
- `test/mehta_period_calendar_source_test.dart`: test specifications for book arithmetic, verified Chart145a and 23-day example, disputed Chart145 civil-date result, month-end, and dasha boundary integrity.

## Original book checks

| Source example | Book statement | Reproduced with calendar interpretation | Note |
| --- | --- | --- | --- |
| p.225 | `16×6/120 = 9m18d` | `9m18d` normalized | Arithmetic exact |
| p.242 Chart145a | Saturn remainder `7y0m12d ×2/3 = 4y8m8d` | `4y8m8d` | Arithmetic exact |
| p.242 Chart145a | 16-Feb-1953 +4y8m8d | 24-Oct-1957 | Calendar convention reproduces book date |
| pp.244–245 Chart145a | 16-Nov-1979 +23 days | 09-Dec-1979 | Exact civil-date match |
| pp.237–238 Chart145 | 16-Mar-1966 +2m25d | 10-Jun-1966, but text has 11-Jun-1966 | **1-day unresolved discrepancy, NOT silently altered** |
| pp.246–247 Indira | 1y11m18d −4m23d | 1y6m25d normalized | Arithmetic exact; corresponding civil dates are source-ambiguous |
| p.251 Chart145b | +3m15d | period correction supported | Specific calendar boundary needs source-date pair |

## Important limitations

1. Natal Moon `longitude / nakshatra size` remains a proxy. Mehta pp.219–221 use actual nakshatra transit times (ghatis/palas); true ingress/egress root solving has **not yet** been implemented. Hence BTR is NOT confirmed to the author's true initial dasha balance.
2. Source examples do NOT establish a single unambiguous day-inclusion or calendar conversion for every chart. A civil-date mode and legacy continuous mode are made explicit, not silently declared identical.
3. Synchronization is a distinct externally investigated number. The app does not automatically derive `+23d`/`+3m15d` for a new chart, and any birth-time results remain exploratory.
4. KP, BPD, BNN, BCP and Western Aspects/Rotation are unaffected by the new Mehta calendar mode.
5. Flutter compilation and Dart tests are needed in GitHub; local runtime does not contain Flutter/Dart. Static checks and independent calendar cross-checks are not substitutes for those tests.
