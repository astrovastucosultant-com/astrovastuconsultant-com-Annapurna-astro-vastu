# Build143 — D10 tenth lord / career suitability audit

- D10 tenth house sign calculated from D10 lagna using whole sign.
- D10 tenth lord: where placed (sign, house), the dispositor and mutual natural friendship with the tenth lord and lagna lord.
- Exaltation, debilitation and own sign are distinguished from natural planetary friendship, without claiming Shadbala or a comprehensive strength %. Directional friendships are not assumed reciprocal.
- D1 and D10 tenth-house occupants separated; D10 classical 7-planet graha drishti to tenth house listed separately. Rahu/Ketu disputed aspects are not automatically assigned.
- D10 profession ranking has one *additional nonduplicate evidence block* for tenth house occupants not already counted as 10L or conjunct the 10L. No extra block if there is no independent evidence. % remains evidence coverage, never a success probability.
- User-required drill-down: Result → Rule → Natal Chart Audit → Remedy provenance (no made-up remedy).
- No claim this generalized interpretive rule is a verbatim SK Mehta rule. KP/BPD/BNN/BCP and Mehta 311 source data unchanged.
- Requires Flutter SDK to run automated Dart tests and compile on GitHub; local ZIP tests do not establish APK compile success.
