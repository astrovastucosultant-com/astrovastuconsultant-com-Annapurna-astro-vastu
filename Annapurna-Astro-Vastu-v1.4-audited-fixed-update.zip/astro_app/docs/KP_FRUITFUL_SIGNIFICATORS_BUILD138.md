# Build 138 — KP Fruitful Significator / ఫలదాయక సూచక గ్రహాల పరిశీలన

## Source-specific method and implemented scope

This release adds a **preliminary KP event-specific fruitful-significator screening** while preserving the 12 Placidus cusp / 4-level significator service. It does not promise event occurrence, prove a rectified birth second, or change the BTR ranking score.

Rule identifiers (application identifiers, not claimed verbatim book verse IDs):

- `KP-FRUIT-01`: Enumerate the ordinary KP significators linked to the **specified event's favourable houses**. Maintain the KP four-level source evidence separately.
- `KP-FRUIT-02`: Evaluate the **star lord** of each candidate planet for related and contrary houses. Evaluate the **sub lord** separately for related and contrary houses. Mark straightforward supportive chain as `Fruitful Candidate`, direct adverse sub-only evidence as `Unfruitful`, and mixed evidence as `Mixed`.
- `KP-FRUIT-03`: Record whether the candidate is one of the relevant **cuspal sub lords** and whether its **star lord** is one of them. These are supporting facts, not replacements for star/sub screening.
- `KP-FRUIT-04`: Determine whether a planet's star has no planetary tenant within the supplied planet set. Record this context but do not promote the planet to an event-confirmed significator based on this alone.
- `KP-FRUIT-05`: Optionally compare **manually supplied ruling planets** for a recorded judgement. No judgement time was supplied; never automatically substitute birth-time rulers. RPs do not modify BTR birth-second ranking.
- `KP-FRUIT-06`: Node (Rahu/Ketu) representation and any chain involving a node is `Needs Verification` when otherwise relevant. Missing lord data, retrograde rules, DBAS timing, and source-dependent exceptions cannot yield a confirmed event verdict.

## Integration

`lib/astrology/kp_cusp_significator_service.dart` provides `fruitfulSignificators` for a given KP event audit and corresponding rationale. `lib/screens/kp_full_tab.dart` adds a separate selectable RP context and individual expandable results. `lib/astrology/btr_integrated_method_service.dart` includes the separate KP fruitfulness evidence in the existing KP portion of the consolidated BTR report, without changing scoring, BPD, BNN, or BCP.

## Unimplemented / to be validated

The user-supplied KP source file *Astro_Secrets_KP_Part5_Rule_Based_Master.html* recommends ruling-planets / retrogression timing checks. Fully sourced owner-vs-occupant strength exceptions, KP Ruling Planet computation from a judgement timestamp, node representation, retrograde conditional rules, and Dasha–Bhukti–Antara–Sookshma event timing are **not implemented** in this change. Different KP schools use different fruitful-selection refinements; this code is deliberately a transparent screening rather than claiming an exhaustive deterministic oracle.

Sources consulted: user's *Astro Secrets & KP Part5* rule-based master; AstroSage KP learning Chapter 2 (fruitful selection); *Selecting Significators in Krishnamurtipaddhati* compilation; *Selection of Fruitful KP significators* discussion. Secondary summaries are not substituted for the user's unverified book-specific exception tables.

## Validation to perform on GitHub

- `flutter pub get`
- `flutter test test/kp_cusp_significator_service_test.dart`
- `flutter build apk --release`
- Review KP tab for individual Star/Sub verdict; BTR report for KP evidence; check original five-method overview, Western Aspects, and chart rotation.

Do not mark this feature as a verified birth-time seconds determination without independent benchmark events.
