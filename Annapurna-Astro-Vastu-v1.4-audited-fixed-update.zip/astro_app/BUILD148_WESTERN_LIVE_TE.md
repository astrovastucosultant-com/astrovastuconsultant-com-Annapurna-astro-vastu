Build148: On-device Swiss Ephemeris tropical secondary progressions and solar arc contacts.
Select a date and calculate. No Python runtime required.
Not included: Naibod directed angles, predictive event-date search, BTR ranking.
Source ZIP integrity checked; Flutter compilation and APK build NOT verified.
