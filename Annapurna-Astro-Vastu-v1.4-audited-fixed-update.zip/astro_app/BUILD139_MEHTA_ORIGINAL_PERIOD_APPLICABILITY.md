# Build139 — S. K. Mehta period applicability for BTR

## Source inspection (primary, scanned)
S. K. Mehta, *New Dimensions in Hindu Astrology*, Chapter XVI “Periods, Divisions of Periods and Synchronization of Periods”, printed pages 218–252 (scanned PDF pages 117–134, original PDF `sk mehta- new dimension.pdf`).

- p. 229: Mehta introduces Tribhagi as 2/3 of Vimshottari and explicitly requires checking which period system is applicable. 80-year Tribhagi, **not** 40-year Khanda.
- pp. 233–239, chart 145: matching career events and synchronizing periods. p.239 explicitly finds **Vimshottari** more applicable than Tribhagi in this chart.
- pp. 240–245, chart 145a: ordinary Vimshottari does not explain several documented events; the author checks **Tribhagi**, then shifts the period alignment by 23 days using a marriage date and tests other events.
- pp. 249–252, chart 145b: the author finds ordinary Vimshottari not applicable; Tribhagi with a 3-month-15-day period adjustment matches several life events.
- p.252 advises checking authenticity/applicability of periods before forecasting.
- pp.258–266 contain separate division-of-period tables; those are *tables*, not proof that Tribhagi must be selected for every birth.

## Changes
- NEW: Mehta `applicabilityFirst` (default), `tribhagiResearch`, `parallelComparison` modes.
- Compare independent dated events with Vimshottari 120y and Tribhagi 80y; select a single period only when at least 3 *verified independent* event groups, 2 event types and margin >=0.08 in this software-defined index. Inconclusive runs stay undecided.
- Fixed 50:50 dasha mixture removed. Parallel / undecided ranking uses a conservative *minimum* agreement. This is an application design precaution, **not** an authored Mehta formula.
- Resolve dasha choice just once at the user's approximate birth time before scanning candidate seconds. No rechoosing at every second (avoids within-search overfitting).
- Save mode with birth-data-specific event storage, print mode, selection note, independent Vimshottari/Tribhagi indices, and separately best *sampled* times in BTR results and copied report.
- Original KP, BNN, BCP, BPD, Western Aspects, rotation and Rulebook assets untouched.

## Not implemented / scientific status
- A separate period-offset (e.g., exactly 23 days or 3 months 15 days from a source chart) is not automatically inferred by this update. Candidate birth-time shifting is not identical to synchronizing an independent dasha correction. This requires additional verified sample case tests before shipping as author-exact.
- Birth-second format does not imply birth-second precision or scientific validation.
- No Flutter compile or Dart tests in this container; run Github Actions and device tests.
