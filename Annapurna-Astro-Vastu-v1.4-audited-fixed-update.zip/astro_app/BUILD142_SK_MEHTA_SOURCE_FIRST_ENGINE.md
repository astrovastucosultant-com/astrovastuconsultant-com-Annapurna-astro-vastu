# Annapurna Astro Vastu — Build142: S.K. Mehta source-first rule engine

- 311-entry source registry retained, byte-for-byte from the previously compiled Telugu preservation register. This register is NOT an English verbatim transcription.
- Rule records: EVENT E01–E20; New Rules R001–R085; New Dimensions ND-001–ND-206.
- Audit metadata and source references are displayed; no entry is marked source-verified unless the underlying registry actually establishes it (none do at this stage).
- Evaluation never mutates or deletes an entry on horoscope non-match.
- Only the 20 EVENT house summary alternatives receive a **contextual** calculation of natal/Moon (optional Sun) lordship and observed event-date Vimshottari/Tribhagi dasha positions.
- This contextual observation is not full author-verified rule application, not evidence of an exact marriage date or birth second, and has no effect on previous BTR ranking.
- All 291 other entries are browsable with their existing text and audit notes; no fabricated automatic pass/fail.
- Existing BPD, BNN, BCP, KP, western aspects, chart rotation remain unchanged.
- Use **BTR → Mehta 311 మూలగ్రంథ నియమాలు** to enter an observed event date for contextual inspection. Source book is not rewritten by matching.
- Flutter compile and automated tests require GitHub Actions. ZIP syntax/static/import/integrity checked separately in accompanying audit.

Static import checks: 246; original JSON SHA256 conserved.
