import 'astro_models.dart';
import 'varga_service.dart';

/// D10 tenth-lord placement audit. Classical sign ownership, natural planetary
/// friendship and whole-sign house position are recorded independently.
/// This supplementary interpretation is NOT presented as an SK Mehta quote or
/// as a probability of career/business success.
class D10TenthLordAnalysis {
  final int ascendantSignIndex;
  final String ascendantLord;
  final int tenthSignIndex;
  final String tenthLord;
  final int placementSignIndex;
  final int placementHouse;
  final String placementSignLord;
  final String dignity;
  final String tenthLordToHostRelation;
  final String hostToTenthLordRelation;
  final String ascendantLordToTenthLordRelation;
  final String tenthLordToAscendantLordRelation;
  final String ascendantLordToHostRelation;
  final String hostToAscendantLordRelation;
  final String houseInterpretation;
  final List<String> d10TenthOccupants;
  final List<String> d1TenthOccupants;
  final List<String> d10TenthAspectingPlanets;

  const D10TenthLordAnalysis({
    required this.ascendantSignIndex,
    required this.ascendantLord,
    required this.tenthSignIndex,
    required this.tenthLord,
    required this.placementSignIndex,
    required this.placementHouse,
    required this.placementSignLord,
    required this.dignity,
    required this.tenthLordToHostRelation,
    required this.hostToTenthLordRelation,
    required this.ascendantLordToTenthLordRelation,
    required this.tenthLordToAscendantLordRelation,
    required this.ascendantLordToHostRelation,
    required this.hostToAscendantLordRelation,
    required this.houseInterpretation,
    required this.d10TenthOccupants,
    required this.d1TenthOccupants,
    required this.d10TenthAspectingPlanets,
  });
}

class D10TenthLordAnalysisService {
  static const signsTe = <String>[
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  // Traditional seven-planet sign lords; nodes are never assigned rulership.
  static const _lords = <String>[
    'Mars', 'Venus', 'Mercury', 'Moon', 'Sun', 'Mercury',
    'Venus', 'Mars', 'Jupiter', 'Saturn', 'Saturn', 'Jupiter',
  ];

  static const _friends = <String, Set<String>>{
    'Sun': {'Moon', 'Mars', 'Jupiter'},
    'Moon': {'Sun', 'Mercury'},
    'Mars': {'Sun', 'Moon', 'Jupiter'},
    'Mercury': {'Sun', 'Venus'},
    'Jupiter': {'Sun', 'Moon', 'Mars'},
    'Venus': {'Mercury', 'Saturn'},
    'Saturn': {'Mercury', 'Venus'},
  };
  static const _enemies = <String, Set<String>>{
    'Sun': {'Venus', 'Saturn'},
    'Moon': <String>{},
    'Mars': {'Mercury'},
    'Mercury': {'Moon'},
    'Jupiter': {'Mercury', 'Venus'},
    'Venus': {'Sun', 'Moon'},
    'Saturn': {'Sun', 'Moon', 'Mars'},
  };

  static const _exaltations = <String, int>{
    'Sun': 0, 'Moon': 1, 'Mars': 9, 'Mercury': 5,
    'Jupiter': 3, 'Venus': 11, 'Saturn': 6,
  };
  static const _debilitations = <String, int>{
    'Sun': 6, 'Moon': 7, 'Mars': 3, 'Mercury': 11,
    'Jupiter': 9, 'Venus': 5, 'Saturn': 0,
  };

  static String signLord(int sign) => _lords[sign % 12];
  static String signName(int sign) => signsTe[sign % 12];
  static int houseFromAsc(int ascSign, int planetSign) =>
      (planetSign - ascSign + 12) % 12 + 1;

  /// Directional *natural* relationship. Temporary friendship not inferred.
  static String naturalRelation(String from, String to) {
    if (from == to) return 'ఒకే గ్రహం';
    if (_friends[from]?.contains(to) ?? false) return 'మిత్రుడు';
    if (_enemies[from]?.contains(to) ?? false) return 'శత్రువు';
    return 'సముడు';
  }

  static String dignity(String planet, int sign) {
    if (_exaltations[planet] == sign) return 'ఉచ్చ';
    if (_debilitations[planet] == sign) return 'నీచ';
    if (_lords[sign] == planet) return 'స్వక్షేత్రం';
    return 'ఇతర రాశి (మైత్రి విడిగా పరిశీలించాలి)';
  }

  static String houseInterpretation(int house) => switch (house) {
    1 => 'స్వీయ ప్రతిభ, వ్యక్తిగత బాధ్యత, నాయకత్వ సూచనలు',
    2 => 'ఆదాయం, వాక్చాతుర్యం, కుటుంబ వనరుల సంబంధం',
    3 => 'స్వయంకృషి, నైపుణ్యం, కమ్యూనికేషన్; ఫలితం శ్రమపై ఆధారితం',
    4 => 'స్థిరత్వం, స్థలం/ఆస్తి, కార్యాలయ వాతావరణం',
    5 => 'మేధస్సు, సృజన, శిక్షణ, నిర్వహణ',
    6 => 'ఉద్యోగం, సేవ, పోటీ; 6వ స్థానం ఒక్కటే ప్రతికూలం కాదు',
    7 => 'వాణిజ్యం, ఒప్పందాలు, భాగస్వామ్యం, ప్రజాసంబంధాలు',
    8 => 'పరిశోధన, మార్పు, అనిశ్చితి; అదనపు బలం పరీక్ష అవసరం',
    9 => 'మార్గదర్శకత్వం, ఉన్నత విజ్ఞానం, ధర్మ/భాగ్య సంబంధం',
    10 => 'వృత్తి కార్యాచరణ, అధికారం, గుర్తింపు',
    11 => 'నెట్‌వర్క్, లాభాలు, వృత్తిలో పురోగతి',
    12 => 'విదేశీ/సంస్థాగత ఉద్యోగాలు, ఖర్చులు; 12వ స్థానం ఒక్కటే ప్రతికూలం కాదు',
    _ => 'పరిశీలన కోసం స్థాన సమాచారం లేదు',
  };

  /// Classical graha drishti by sign, without making disputed Rahu/Ketu
  /// aspects automatic. Universal seventh; Mars 4/8, Jupiter 5/9,
  /// Saturn 3/10 counted from their own sign.
  static bool classicalAspect(String planet, int from, int to) {
    if (!{'Sun', 'Moon', 'Mars', 'Mercury', 'Jupiter', 'Venus', 'Saturn'}.contains(planet)) {
      return false;
    }
    final difference = (to - from + 12) % 12;
    if (difference == 6) return true;
    if (planet == 'Mars') return difference == 3 || difference == 7;
    if (planet == 'Jupiter') return difference == 4 || difference == 8;
    if (planet == 'Saturn') return difference == 2 || difference == 9;
    return false;
  }

  static D10TenthLordAnalysis evaluate({
    required VargaChartData d10,
    AstroChartResult? natal,
  }) {
    final asc = d10.ascendantSignIndex;
    final tenthSign = (asc + 9) % 12;
    final tenthLord = signLord(tenthSign);
    final ascLord = signLord(asc);
    // If a core graha is absent, return an explicit error instead of a fabricated
    // profession/career classification.
    final tenthLordPlacement = d10.planets.firstWhere(
      (p) => p.name == tenthLord,
      orElse: () => throw StateError('D10లో $tenthLord స్థాన వివరాలు లేవు'),
    );
    final sign = tenthLordPlacement.signIndex;
    final host = signLord(sign);
    final d10Occupants = d10.planets
        .where((p) => p.signIndex == tenthSign)
        .map((p) => p.name)
        .toList(growable: false);
    final d1Occupants = natal == null
        ? <String>[]
        : natal.planets
            .where((p) => p.signIndex == (natal.ascendantSignIndex + 9) % 12)
            .map((p) => p.name)
            .toList(growable: false);
    final aspects = d10.planets
        .where((p) => p.signIndex != tenthSign &&
            classicalAspect(p.name, p.signIndex, tenthSign))
        .map((p) => p.name)
        .toList(growable: false);
    return D10TenthLordAnalysis(
      ascendantSignIndex: asc,
      ascendantLord: ascLord,
      tenthSignIndex: tenthSign,
      tenthLord: tenthLord,
      placementSignIndex: sign,
      placementHouse: houseFromAsc(asc, sign),
      placementSignLord: host,
      dignity: dignity(tenthLord, sign),
      tenthLordToHostRelation: naturalRelation(tenthLord, host),
      hostToTenthLordRelation: naturalRelation(host, tenthLord),
      ascendantLordToTenthLordRelation: naturalRelation(ascLord, tenthLord),
      tenthLordToAscendantLordRelation: naturalRelation(tenthLord, ascLord),
      ascendantLordToHostRelation: naturalRelation(ascLord, host),
      hostToAscendantLordRelation: naturalRelation(host, ascLord),
      houseInterpretation: houseInterpretation(houseFromAsc(asc, sign)),
      d10TenthOccupants: d10Occupants,
      d1TenthOccupants: d1Occupants,
      d10TenthAspectingPlanets: aspects,
    );
  }
}
