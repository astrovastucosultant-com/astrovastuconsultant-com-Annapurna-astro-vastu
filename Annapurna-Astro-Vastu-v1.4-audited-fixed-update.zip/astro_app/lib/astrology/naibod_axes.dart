import 'dart:math' as math;

/// Naibod progressed angles, using mean solar motion 0°59′08″ per tropical year.
/// Inputs are degrees. RAMC is right ascension of the natal MC, NOT MC longitude.
/// This is a symbolic progression, not an astronomical ephemeris calculation.
class NaibodAxes {
  static const double arcPerYear = 59.0 / 60.0 + 8.0 / 3600.0;
  static const double tropicalYearDays = 365.24219;
  static const double _rad = math.pi / 180.0;

  final double ramc;
  final double mc;
  final double asc;
  final double ic;
  final double dsc;
  final double arc;
  final double ageYears;

  const NaibodAxes._(this.ramc, this.mc, this.asc, this.ic, this.dsc,
      this.arc, this.ageYears);

  static double norm(double degrees) => (degrees % 360 + 360) % 360;

  static NaibodAxes calculate({
    required DateTime birthUtc,
    required DateTime targetUtc,
    required double natalRamcDegrees,
    required double latitudeDegrees,
    double obliquityDegrees = 23.4392911,
  }) {
    if (!birthUtc.isUtc || !targetUtc.isUtc) {
      throw ArgumentError('birthUtc and targetUtc must be UTC DateTimes');
    }
    if (!latitudeDegrees.isFinite || latitudeDegrees.abs() >= 90) {
      throw ArgumentError.value(latitudeDegrees, 'latitudeDegrees',
          'Latitude must be strictly between -90 and 90 degrees');
    }
    if (!natalRamcDegrees.isFinite || !obliquityDegrees.isFinite ||
        obliquityDegrees <= 0 || obliquityDegrees >= 90) {
      throw ArgumentError('Invalid RAMC or obliquity');
    }
    final years = targetUtc.difference(birthUtc).inMicroseconds /
        (tropicalYearDays * Duration.microsecondsPerDay);
    final arc = years * arcPerYear;
    final ramc = norm(natalRamcDegrees + arc);
    final t = ramc * _rad;
    final e = obliquityDegrees * _rad;
    final p = latitudeDegrees * _rad;
    // Longitude of the ecliptic's intersection with the meridian.
    final mc = norm(math.atan2(math.sin(t) / math.cos(e), math.cos(t)) / _rad);
    // Eastern horizon intersection with the ecliptic.
    final asc = norm(math.atan2(-math.cos(t),
        math.sin(t) * math.cos(e) + math.tan(p) * math.sin(e)) / _rad);
    return NaibodAxes._(ramc, mc, asc, norm(mc + 180),
        norm(asc + 180), arc, years);
  }

  Map<String, double> toMap() => {
    'ageYears': ageYears, 'naibodArc': arc, 'ramc': ramc,
    'asc': asc, 'mc': mc, 'dsc': dsc, 'ic': ic,
  };
}
