import 'mehta_period_calendar.dart';
import 'mehta_child_event_context.dart';
import '../models/birth_data.dart';
import 'astro_calculation_service.dart';
import 'btr_macro_context_service.dart';
import 'bpd_pada_dasa_service.dart';
import 'astro_models.dart';
import 'dasha_service.dart';
import 'sk_mehta_service.dart';
import 'btr_mehta_rule_bridge.dart';
import 'kp_service.dart';
import 'kp_cusp_significator_service.dart';
import 'varga_service.dart';

/// An observed historical event. [occurredAt] is a local civil date/time.
/// A date-only event uses noon for an exploratory period comparison; it does
/// not imply that the event took place at noon.
class MehtaBtrEvent {
  final String ruleId;
  final DateTime occurredAt;
  final bool timeKnown;
  final String? note;
  /// Optional source text rule chosen by the practitioner for this event.
  final String? sourceRuleId;
  /// Practitioner-entered evidence quality; never an event likelihood.
  final String reliability; // verified | reported | uncertain
  /// Same real-world occurrence may have multiple records.
  final String correlationGroup;

  const MehtaBtrEvent({
    required this.ruleId,
    required this.occurredAt,
    this.timeKnown = false,
    this.note,
    this.sourceRuleId,
    this.reliability = 'reported',
    this.correlationGroup = '',
  });
}

/// Mehta, New Dimensions in Hindu Astrology, Chapter XVI pp. 228-252:
/// compare Vimshottari and Tribhagi against documented historical events,
/// then synchronize the applicable system. The 80y cycle is 2/3 of 120y.
/// These are app workflows, NOT names of three author-prescribed formulas.
enum MehtaDashaMode { applicabilityFirst, tribhagiResearch, parallelComparison }

extension MehtaDashaModeLabel on MehtaDashaMode {
  String get label => switch (this) {
    MehtaDashaMode.applicabilityFirst => 'Mehta Applicability • సంఘటనలతో దశ ఎంపిక',
    MehtaDashaMode.tribhagiResearch => 'Tribhagi First • పరిశోధన',
    MehtaDashaMode.parallelComparison => 'Parallel Comparison • వేర్వేరు పోలిక',
  };
}

class MehtaBtrEventEvidence {
  final MehtaBtrEvent event;
  final BtrMacroContext? macroContext;
  final BpdEventContext? bpdContext;
  final KpEventAudit? kpAudit;
  final String ruleName;
  final double vimshottariShare;
  final double tribhagiShare;
  /// Strict literal AD/PD/Sukshma evidence from the app's M06 table.
  final double vimshottariDirectShare;
  final double tribhagiDirectShare;
  /// Additional D1/D7/nakshatra context: APP diagnostics, NOT Mehta dictates.
  final double? vimshottariChildContextShare;
  final double? tribhagiChildContextShare;
  final List<String> childContextNotes;
  final double combinedShare;
  /// Daily uncertainty interval for events without a documented clock time.
  final double minimumShare;
  final double maximumShare;
  final int sampledInstants;
  final String vimshottariLords;
  final String tribhagiLords;
  final List<String> expectedAsc;
  final List<String> expectedMoonAsc;
  final BtrMehtaSourceCheck sourceCheck;
  /// Event-specific blended comparison index, never a birth-time probability.
  final double rankingShare;
  final double ascDashaShare;
  final double? moonDashaShare;

  const MehtaBtrEventEvidence({
    required this.event,
    this.macroContext,
    this.bpdContext,
    this.kpAudit,
    required this.ruleName,
    required this.vimshottariShare,
    required this.tribhagiShare,
    this.vimshottariDirectShare = 0,
    this.tribhagiDirectShare = 0,
    this.vimshottariChildContextShare,
    this.tribhagiChildContextShare,
    this.childContextNotes = const [],
    required this.combinedShare,
    required this.minimumShare,
    required this.maximumShare,
    required this.sampledInstants,
    required this.vimshottariLords,
    required this.tribhagiLords,
    required this.expectedAsc,
    required this.expectedMoonAsc,
    required this.sourceCheck,
    required this.rankingShare,
    this.ascDashaShare = 0,
    this.moonDashaShare,
  });
}

class MehtaBtrCandidate {
  final DateTime birthTime;
  final double evidenceShare;
  final List<MehtaBtrEventEvidence> evidence;
  /// KP ascending stellar chain and relevant divisional ascendants; diagnostics.
  final String timeSignature;
  final KpCuspSignificatorResult? kpChartAudit;
  final double ascDashaShare;
  final double? moonDashaShare;
  final double vimshottariIndex;
  final double tribhagiIndex;

  const MehtaBtrCandidate({
    required this.birthTime,
    required this.evidenceShare,
    required this.evidence,
    this.timeSignature = '',
    this.kpChartAudit,
    this.ascDashaShare = 0,
    this.moonDashaShare,
    this.vimshottariIndex = 0,
    this.tribhagiIndex = 0,
  });
}

/// A *locally one-second scanned* compatible time window (not proof of truth).
class BtrSecondWindow {
  final DateTime start;
  final DateTime end;
  final double ruleMatchIndex;
  final String signature;
  final bool exhaustiveWithinWindow;
  const BtrSecondWindow({required this.start, required this.end,
    required this.ruleMatchIndex, required this.signature,
    this.exhaustiveWithinWindow = true});
}

class MehtaBtrResult {
  final DateTime originalBirthTime;
  final int testedTimes;
  final List<MehtaBtrCandidate> candidates;
  final DateTime? rangeStart;
  final DateTime? rangeEnd;
  final bool distinguishable;
  /// 1-second evaluated candidate count, never confused with total times.
  final int oneSecondSamples;
  /// Top-scoring verified second-resolution local windows.
  final List<BtrSecondWindow> secondWindows;
  /// True only if every second across the full requested search was evaluated.
  final bool exhaustiveAcrossRequestedRange;
  final int coarseStepSeconds;
  final String resolutionNote;
  final int discriminatingEvents;
  final int independentGroups;
  final MehtaDashaMode requestedDashaMode;
  /// Null means no justified single-period choice (conservative parallel).
  final DashaSystemKind? selectedPeriod;
  final double referenceVimshottariIndex;
  final double referenceTribhagiIndex;
  final String periodSelectionNote;
  /// True for a reported-only, exploratory choice; never book-confirmed.
  final bool provisionalPeriodSelection;
  final DateTime? bestVimshottariBirthTime;
  final DateTime? bestTribhagiBirthTime;
  final MehtaSynchronizationOffset synchronizationOffset;
  final DashaCalendarBasis periodCalendarBasis;

  const MehtaBtrResult({
    required this.originalBirthTime,
    required this.testedTimes,
    required this.candidates,
    required this.rangeStart,
    required this.rangeEnd,
    required this.distinguishable,
    this.oneSecondSamples = 0,
    this.secondWindows = const [],
    this.exhaustiveAcrossRequestedRange = false,
    this.coarseStepSeconds = 120,
    this.resolutionNote = '',
    this.discriminatingEvents = 0,
    this.independentGroups = 0,
    this.requestedDashaMode = MehtaDashaMode.applicabilityFirst,
    this.selectedPeriod,
    this.referenceVimshottariIndex = 0,
    this.referenceTribhagiIndex = 0,
    this.periodSelectionNote = '',
    this.provisionalPeriodSelection = false,
    this.bestVimshottariBirthTime,
    this.bestTribhagiBirthTime,
    this.synchronizationOffset = const MehtaSynchronizationOffset(),
    this.periodCalendarBasis = DashaCalendarBasis.mehtaBookGregorian,
  });

  MehtaBtrCandidate? get best => candidates.isEmpty ? null : candidates.first;
}

/// Mehta primary AD/PD/Sukshma matching for a dated, observed event.
/// This is an exploratory ranking, NOT a validated birth-time rectification
/// formula, event probability, or proof of an exact second of birth.
class MehtaBtrService {
  static const int minimumEvents = 3;
  static const int recommendedEvents = 5;
  static const int maxEvents = 30;

  static final List<SkMehtaEventRule> supportedEvents =
      SkMehtaService.events.where((rule) => !{'M10', 'M15', 'M16'}.contains(rule.id))
          .toList(growable: false);

  static SkMehtaEventRule ruleFor(String id) =>
      supportedEvents.firstWhere((rule) => rule.id == id);

  static String? validateEvents(List<MehtaBtrEvent> events, DateTime birthTime) {
    if (events.length < minimumEvents) {
      return 'కనీసం 3 గత సంఘటనల తేదీలు ఇవ్వండి. 5–10 ఉంటే పోలిక మెరుగ్గా ఉంటుంది.';
    }
    if (events.length > maxEvents) return 'ఒకసారి గరిష్ఠంగా 30 సంఘటనలు మాత్రమే.';
    if (events.map((e) => e.ruleId).toSet().length < 2) {
      return 'కనీసం రెండు వేర్వేరు రకాల సంఘటనలు నమోదు చేయండి.';
    }
    final now = DateTime.now();
    for (final event in events) {
      if (!supportedEvents.any((r) => r.id == event.ruleId)) {
        return 'ఈ సంఘటనకు Mehta timing rule అందుబాటులో లేదు.';
      }
      // A date-only record is not a claimed 12:00 event. Compare calendar
      // dates to avoid rejecting a same-day record merely because noon is
      // still in the future. Do not accept birth-day date-only events whose
      // order relative to the recorded birth instant cannot be established.
      final eventDay = DateTime(event.occurredAt.year,
          event.occurredAt.month, event.occurredAt.day);
      final birthDay = DateTime(birthTime.year, birthTime.month, birthTime.day);
      final today = DateTime(now.year, now.month, now.day);
      if (eventDay.isBefore(birthDay) || eventDay.isAfter(today) ||
          (event.timeKnown &&
              (event.occurredAt.isBefore(birthTime) ||
                  event.occurredAt.isAfter(now))) ||
          (!event.timeKnown && eventDay.isAtSameMomentAs(birthDay))) {
        return 'సంఘటన తేదీ జనన తేదీ తర్వాత, ఈ రోజు లేదా అంతకు ముందు ఉండాలి.';
      }
    }
    final independentGroups = events.asMap().entries.map((e) =>
        e.value.correlationGroup.trim().isEmpty
          ? 'independent:${e.key}'
          : 'group:${e.value.correlationGroup.trim()}').toSet();
    if (independentGroups.length < minimumEvents) {
      return 'కనీసం 3 స్వతంత్ర సంఘటనలు కావాలి; ఒకే కారణానికి ఒకే Group ID వాడండి.';
    }
    final uniqueDays = events.map((e) =>
        '${e.occurredAt.year}-${e.occurredAt.month}-${e.occurredAt.day}').toSet();
    if (uniqueDays.length < minimumEvents) {
      return '3 వేర్వేరు తేదీల్లో జరిగిన సంఘటనలు ఇవ్వండి.';
    }
    return null;
  }

  static List<String> expectedLords(int ascSignIndex, SkMehtaEventRule rule,
      {bool moon = false}) {
    final houses = moon && rule.moonAscHouses.isNotEmpty
        ? rule.moonAscHouses : rule.ascHouses;
    return <String>{
      for (final house in houses)
        SkMehtaService.houseLordFromAsc(ascSignIndex, house),
      ...rule.fixedPlanets,
    }.toList(growable: false);
  }

  /// Deterministic KP-lagna and event-specific divisional fingerprints.
  /// These are *boundaries*, not automatically affirmative predictions.
  static String timeSignature(AstroChartResult chart, List<MehtaBtrEvent> events,
      {KpCuspSignificatorResult? kpChartAudit}) {
    final asc = kpChartAudit?.available == true
        ? kpChartAudit!.cusps.first.stellar
        : KpService.forLongitude('Asc', chart.ascendantLongitude);
    final factors = <int>{1};
    for (final e in events) {
      switch (e.ruleId) {
        case 'M01': case 'M02': factors.add(9); break;
        case 'M06': factors.add(7); break;
        case 'M07': factors.add(4); break;
        case 'M08': factors.add(16); break;
        case 'M11': case 'M12': case 'M13': case 'M14': factors.add(10); break;
        default: break;
      }
    }
    // D12/D24 are shown for audit, never substitute for a source event rule.
    factors.addAll([12, 24]);
    final degrees = factors.toList()..sort();
    final varga = degrees.map((d) =>
      'D$d:${VargaService.signForLongitude(chart.ascendantLongitude, d)}').join('|');
    return 'KP:${asc.signIndex}/${asc.nakshatraIndex}/'
      '${asc.starLord}/${asc.subLord}/${asc.subSubLord}'
      '|CUSPS:${kpChartAudit?.signature ?? 'UNAVAILABLE'}|$varga';
  }

  /// Different records caused by the same event are not independent evidence.
  static double eventWeight(MehtaBtrEvent event) {
    return switch(event.reliability) {
      'verified' => 1.0,
      'uncertain' => 0.4,
      _ => 0.75,
    };
  }

  static double lordEvidenceShare(List<String> required, List<String> active) {
    if (required.isEmpty || active.isEmpty) return 0;
    final hit = required.toSet().intersection(active.toSet()).length;
    return hit / required.toSet().length;
  }

  /// Evidence coverage is NOT a probability. Require adequate support in the
  /// 2nd–4th dasha positions before assigning a full-match score. Merely
  /// naming both expected distinct lords in two of three positions cannot
  /// satisfy a Mehta rule that requires all three primary places.
  static double primaryEvidenceShare(
      List<String> required, List<String> active, int requiredPlaces) {
    if (required.isEmpty || active.isEmpty) return 0;
    final allowed = required.toSet();
    final matches = active.where(allowed.contains).length;
    final threshold = requiredPlaces.clamp(1, 3).toInt();
    final coverage = (matches / threshold).clamp(0.0, 1.0).toDouble();
    return lordEvidenceShare(required, active) * coverage;
  }

  /// Conservative alternative to a historically unsupported fixed 50:50
  /// weight. Null means both systems must agree, with no cherry-picking.
  static double periodComparisonScore(double vimshottari, double tribhagi,
      DashaSystemKind? selected) => switch (selected) {
    DashaSystemKind.vimshottari => vimshottari,
    DashaSystemKind.tribhagi => tribhagi,
    _ => vimshottari < tribhagi ? vimshottari : tribhagi,
  };

  /// The source's choice is event-based, not an automatic proof of correctness.
  /// Require diverse independent *verified* evidence before auto-selecting;
  /// weak, mixed or tied matches remain undecided, without a false winner.
  static DashaSystemKind? chooseApplicablePeriod({
    required double vimshottariIndex,
    required double tribhagiIndex,
    required int verifiedIndependentGroups,
    required int distinctEventTypes,
  }) {
    if (verifiedIndependentGroups < 3 || distinctEventTypes < 2 ||
        (vimshottariIndex-tribhagiIndex).abs() < 0.08) return null;
    return vimshottariIndex > tribhagiIndex
      ? DashaSystemKind.vimshottari : DashaSystemKind.tribhagi;
  }

  /// Exploratory ONLY: with diverse independent reported events, a strong
  /// cross-event margin can highlight a provisional system. The rule is an
  /// application heuristic, not an SK Mehta formula. Never call it verified.
  static DashaSystemKind? chooseProvisionalPeriod({
    required List<MehtaBtrEventEvidence> evidence,
    required int independentGroups,
    required int distinctEventTypes,
  }) {
    if (independentGroups < 3 || distinctEventTypes < 2) return null;
    double weightedVim = 0, weightedTrib = 0, sum = 0;
    var vimWins = 0, tribWins = 0;
    final seenGroups = <String>{};
    for (var i = 0; i < evidence.length; i++) {
      final row = evidence[i];
      final e = row.event;
      if (e.reliability == 'uncertain') continue;
      final group = e.correlationGroup.trim().isEmpty
          ? 'independent:$i' : 'group:${e.correlationGroup.trim()}';
      if (!seenGroups.add(group)) continue;
      final weight = eventWeight(e);
      weightedVim += row.vimshottariShare * weight;
      weightedTrib += row.tribhagiShare * weight;
      sum += weight;
      if (row.vimshottariShare > row.tribhagiShare + 0.15 &&
          row.vimshottariShare >= 0.2) vimWins++;
      if (row.tribhagiShare > row.vimshottariShare + 0.15 &&
          row.tribhagiShare >= 0.2) tribWins++;
    }
    if (seenGroups.length < 3 || sum <= 0) return null;
    final diff = (weightedVim - weightedTrib) / sum;
    if (diff >= 0.18 && vimWins >= 2 && tribWins == 0) {
      return DashaSystemKind.vimshottari;
    }
    if (diff <= -0.18 && tribWins >= 2 && vimWins == 0) {
      return DashaSystemKind.tribhagi;
    }
    return null;
  }

  static List<String> primaryPlaces(DashaPath? path) => path == null
      ? <String>[]
      : <String>[
          path.antardasha.lord,
          path.pratyantardasha.lord,
          path.sukshma.lord,
        ];

  static String formatPlaces(List<String> lords) =>
      lords.isEmpty ? '—' : lords.join(' → ');

  static MehtaBtrEventEvidence checkEvent({
    required AstroChartResult chart,
    required MehtaBtrEvent event,
    required DateTime birthDateTime,
    required DashaSystemResult vim,
    required DashaSystemResult trib,
    BtrMehtaSourceCheck? sourceCheck,
    KpEventAudit? kpAudit,
    BpdProfile bpdProfile = BpdProfile.vaaniSeven,
    DashaSystemKind? selectedPeriod,
  }) {
    final rule = ruleFor(event.ruleId);
    final ascExpected = expectedLords(chart.ascendantSignIndex, rule);
    final moonSign = chart.planets.firstWhere((p) => p.name == 'Moon').signIndex;
    final moonExpected = rule.moonAscCheck
        ? expectedLords(moonSign, rule, moon: true) : <String>[];

    double check(List<String> observed) {
      final ascShare = primaryEvidenceShare(
          ascExpected, observed, rule.requiredPrimaryMatches);
      if (!rule.moonAscCheck || moonExpected.isEmpty) return ascShare;
      // ASC is the primary evidence. Moon ASC is separately supported.
      // The 75/25 blend is an app-designed comparison index, not a Mehta
      // formula or empirically calibrated probability.
      return 0.75 * ascShare +
          0.25 * primaryEvidenceShare(
              moonExpected, observed, rule.requiredPrimaryMatches);
    }

    // If no time was documented, scan early / middle / late on the actual
    // calendar day. Averaging avoids silently declaring noon to be the real
    // event instant or cherry-picking the most favourable of three times.
    final instants = event.timeKnown
        ? <DateTime>[event.occurredAt]
        : <DateTime>[
            DateTime(event.occurredAt.year, event.occurredAt.month,
                event.occurredAt.day, 0, 0, 0),
            DateTime(event.occurredAt.year, event.occurredAt.month,
                event.occurredAt.day, 12, 0, 0),
            DateTime(event.occurredAt.year, event.occurredAt.month,
                event.occurredAt.day, 23, 59, 59),
          ];
    final isChildEvent = event.ruleId == 'M06';
    final vims = <double>[];
    final vimsDirect = <double>[];
    final tribsDirect = <double>[];
    final vimChild = <double>[];
    final tribChild = <double>[];
    final childNotes = <String>[];
    final tribs = <double>[];
    final details = <double>[];
    final ascDetails = <double>[];
    final moonDetails = <double>[];
    var vimPlaces = <String>[];
    var tribPlaces = <String>[];
    for (final instant in instants) {
      final v = primaryPlaces(DashaService.pathAt(vim, instant));
      final t = primaryPlaces(DashaService.pathAt(trib, instant));
      if (instant.hour == 12 || event.timeKnown) {
        vimPlaces = v;
        tribPlaces = t;
      }
      final directV = check(v);
      final directT = check(t);
      vimsDirect.add(directV);
      tribsDirect.add(directT);
      // A contextual indication can *never* become a complete M06 match.
      // Keep the strict direct score visible for review.
      final cv = isChildEvent ? MehtaChildEventContext.assess(chart, v) : null;
      final ct = isChildEvent ? MehtaChildEventContext.assess(chart, t) : null;
      if (cv?.available == true) vimChild.add(cv!.linkShare);
      if (ct?.available == true) tribChild.add(ct!.linkShare);
      if (isChildEvent && (instant.hour == 12 || event.timeKnown)) {
        childNotes.add('వింశోత్తరి D1/D7: '
            '${cv?.observations.join(' | ') ?? 'సందర్భ డేటా లేదు'}');
        childNotes.add('త్రిభాగి D1/D7: '
            '${ct?.observations.join(' | ') ?? 'సందర్భ డేటా లేదు'}');
        childNotes.addAll([...?cv?.missing, ...?ct?.missing]);
      }
      // STRICT SOURCE BOUNDARY: D1/D7/nakshatra/Jupiter diagnostics do NOT
      // alter the SK Mehta M06 dasha score or BTR candidate ranking. The
      // table and original book must be verified before adding a new formula.
      final vScore = directV;
      final tScore = directT;
      ascDetails.add(periodComparisonScore(
          primaryEvidenceShare(ascExpected, v, rule.requiredPrimaryMatches),
          primaryEvidenceShare(ascExpected, t, rule.requiredPrimaryMatches),
          selectedPeriod));
      if (rule.moonAscCheck && moonExpected.isNotEmpty) {
        moonDetails.add(periodComparisonScore(
            primaryEvidenceShare(moonExpected, v, rule.requiredPrimaryMatches),
            primaryEvidenceShare(moonExpected, t, rule.requiredPrimaryMatches),
            selectedPeriod));
      }
      vims.add(vScore);
      tribs.add(tScore);
      details.add(periodComparisonScore(vScore, tScore, selectedPeriod));
    }
    double average(List<double> values) =>
        values.reduce((a, b) => a + b) / values.length;
    final vimScore = average(vims);
    final tribScore = average(tribs);
    final dashaShare = average(details);
    final selectedCheck = sourceCheck ?? const BtrMehtaSourceCheck(
        evaluated:false, matched:false, explanation:'మూల రూల్‌ను పరిశీలించలేదు');
    // Fixed app-designed weighting ONLY for a practitioner-selected,
    // automatically checked source condition. All other rules are manual.
    // This measures comparative rule agreement, never scientific certainty.
    final rankingShare = selectedCheck.evaluated
        ? 0.75 * dashaShare + 0.25 * (selectedCheck.matched ? 1.0 : 0.0)
        : dashaShare;
    return MehtaBtrEventEvidence(
      event: event,
      macroContext: chart.planets.any((p) => p.name == 'Jupiter')
          ? BtrMacroContextService.compute(
              natalChart: chart,
              birthDate: birthDateTime,
              eventDate: event.occurredAt,
            ) : null,
      kpAudit: kpAudit,
      bpdContext: BpdPadaDasaService.compute(
        chart: chart, birthDate: birthDateTime,
        eventDate: event.occurredAt, profile: bpdProfile,
        eventHouses: rule.ascHouses),
      ruleName: rule.event,
      vimshottariShare: vimScore,
      tribhagiShare: tribScore,
      vimshottariDirectShare: average(vimsDirect),
      tribhagiDirectShare: average(tribsDirect),
      vimshottariChildContextShare:
          vimChild.isEmpty ? null : average(vimChild),
      tribhagiChildContextShare:
          tribChild.isEmpty ? null : average(tribChild),
      childContextNotes: List.unmodifiable(childNotes),
      combinedShare: dashaShare,
      minimumShare: details.reduce((a, b) => a < b ? a : b),
      maximumShare: details.reduce((a, b) => a > b ? a : b),
      sampledInstants: instants.length,
      vimshottariLords: formatPlaces(vimPlaces),
      tribhagiLords: formatPlaces(tribPlaces),
      expectedAsc: ascExpected,
      expectedMoonAsc: moonExpected,
      sourceCheck: selectedCheck,
      rankingShare: rankingShare,
      ascDashaShare: average(ascDetails),
      moonDashaShare: moonDetails.isEmpty ? null : average(moonDetails),
    );
  }

  /// Apply one practitioner-reviewed calendar correction to each calculated
  /// period boundary. A period correction is NOT a birth-time correction.
  /// This preserves the original Moon-derived balance and natal chart.
  static DashaSystemResult synchronizePeriodSystem(
      DashaSystemResult original, MehtaSynchronizationOffset offset) {
    if (offset.isZero) return original;
    return DashaSystemResult(
      kind: original.kind, label: original.label,
      sourceNote: '${original.sourceNote} • Calendar synchronization: '
          '${offset.label} (app convention; verify against events).',
      moonNakshatraIndex: original.moonNakshatraIndex,
      nakshatraFractionElapsed: original.nakshatraFractionElapsed,
      startingLord: original.startingLord,
      birthBalanceYears: original.birthBalanceYears,
      cycleYears: original.cycleYears,
      sequence: original.sequence,
      weights: original.weights,
      calendarBasis: original.calendarBasis,
      mahadashas: List.unmodifiable([
        for (final p in original.mahadashas)
          DashaPeriod(lord: p.lord, years: p.years,
            start: MehtaPeriodCalendar.synchronize(p.start, offset),
            end: MehtaPeriodCalendar.synchronize(p.end, offset)),
      ]),
    );
  }

  static Future<MehtaBtrCandidate> scoreCandidate({
    required BirthData natal,
    required DateTime candidateBirthTime,
    required List<MehtaBtrEvent> events,
    Future<AstroChartResult> Function(BirthData)? chartCalculator,
    BpdProfile bpdProfile = BpdProfile.vaaniSeven,
    DashaSystemKind? selectedPeriod,
    MehtaSynchronizationOffset synchronizationOffset =
        const MehtaSynchronizationOffset(),
    DashaCalendarBasis periodCalendarBasis =
        DashaCalendarBasis.mehtaBookGregorian,
  }) async {
    final data = natal.copyWith(localDateTime: candidateBirthTime);
    final calculateChart = chartCalculator ?? AstroCalculationService.calculate;
    final chart = await calculateChart(data);
    // KP is a separate calculation profile, not an alias for whichever
    // ayanamsa Parashara/Mehta uses. Never reuse Lahiri cusps as KP cusps.
    final kpChart = data.ayanamsa == AyanamsaType.krishnamurti
        ? chart
        : await calculateChart(data.copyWith(ayanamsa: AyanamsaType.krishnamurti));
    final kpAudit = KpCuspSignificatorService.compute(kpChart);
    // Calculate the Moon-derived natal Dasha dates FIRST, then apply a
    // common signed synchronization to each calendar boundary. Shifting the
    // natal anchor instead would alter month-end arithmetic and is NOT the
    // same operation (see Mehta source review p.237).
    final vimBase = DashaService.system(
      kind: DashaSystemKind.vimshottari,
      chart: chart,
      birthDateTime: candidateBirthTime,
      calendarBasis: periodCalendarBasis,
    );
    final tribBase = DashaService.system(
      kind: DashaSystemKind.tribhagi,
      chart: chart,
      birthDateTime: candidateBirthTime,
      calendarBasis: periodCalendarBasis,
    );
    final vim = synchronizePeriodSystem(vimBase, synchronizationOffset);
    final trib = synchronizePeriodSystem(tribBase, synchronizationOffset);
    final automaticSourceChecks = events.any((e) =>
      BtrMehtaRuleBridge.ruleNumber(e.sourceRuleId) != null)
        ? BtrMehtaRuleBridge.evaluatedBookRules(chart)
        : null;
    final details = <MehtaBtrEventEvidence>[
      for (final event in events)
        checkEvent(chart: chart, event: event,
          birthDateTime: candidateBirthTime, vim: vim, trib: trib,
          bpdProfile: bpdProfile,
          selectedPeriod: selectedPeriod,
          kpAudit: kpAudit.forEvent(event.ruleId),
          sourceCheck: BtrMehtaRuleBridge.inspect(event.sourceRuleId,
            automaticSourceChecks ?? {})),
    ];
    // Each observed event has equal importance; do not count a repeated planet
    // twice as two independent events.
    final groupCounts = <String,int>{};
    for (final e in events) {
      final group = e.correlationGroup.trim();
      if (group.isNotEmpty) groupCounts[group] = (groupCounts[group] ?? 0) + 1;
    }
    double weight(MehtaBtrEvent e) {
      final group = e.correlationGroup.trim();
      return eventWeight(e) / (group.isEmpty ? 1 : groupCounts[group]!);
    }
    final weightSum = details.fold<double>(0, (sum, d) => sum + weight(d.event));
    final mean = details.fold<double>(0, (sum, d) =>
      sum + d.rankingShare * weight(d.event)) / weightSum;
    final ascShare = details.fold<double>(0, (sum,d) =>
      sum + d.ascDashaShare * weight(d.event)) / weightSum;
    final moon = details.where((d) => d.moonDashaShare != null).toList();
    final moonWeight = moon.fold<double>(0, (sum,d) => sum + weight(d.event));
    return MehtaBtrCandidate(
      birthTime: candidateBirthTime,
      evidenceShare: mean,
      vimshottariIndex: details.fold<double>(0, (sum,d) =>
            sum + d.vimshottariShare * weight(d.event)) / weightSum,
      tribhagiIndex: details.fold<double>(0, (sum,d) =>
            sum + d.tribhagiShare * weight(d.event)) / weightSum,
      evidence: List.unmodifiable(details),
      timeSignature: timeSignature(chart, events, kpChartAudit: kpAudit),
      kpChartAudit: kpAudit,
      ascDashaShare: ascShare,
      moonDashaShare: moonWeight == 0 ? null :
        moon.fold<double>(0, (sum,d) =>
          sum + d.moonDashaShare! * weight(d.event)) / moonWeight,
    );
  }

  /// Hierarchical BTR candidate exploration. A 1-second scan is exhaustive
  /// inside the reported fine-search regions, NOT across a full ±12 h span.
  /// Report plateaus/alternative windows; a clock with seconds is not proof
  /// of 1-second *accuracy*. BCP/BNN remain context only.
  static Future<MehtaBtrResult> search({
    required BirthData natal,
    required List<MehtaBtrEvent> events,
    int plusMinusMinutes = 60,
    DateTime? searchCenter,
    BpdProfile bpdProfile = BpdProfile.vaaniSeven,
    MehtaDashaMode dashaMode = MehtaDashaMode.applicabilityFirst,
    MehtaSynchronizationOffset synchronizationOffset =
        const MehtaSynchronizationOffset(),
    DashaCalendarBasis periodCalendarBasis =
        DashaCalendarBasis.mehtaBookGregorian,
    Future<AstroChartResult> Function(BirthData)? chartCalculator,
    void Function(int done, int total)? onProgress,
  }) async {
    final issue = validateEvents(events, natal.originalBirthDateTime);
    if (issue != null) throw ArgumentError(issue);
    if (![1, 2, 5, 10, 30, 60, 120, 360, 720].contains(plusMinusMinutes)) {
      throw ArgumentError('జనన సమయ Search పరిధి సరైనది కాదు.');
    }
    if (natal.place.trim().isEmpty ||
        !natal.latitude.isFinite || !natal.longitude.isFinite ||
        natal.latitude.abs() > 90 || natal.longitude.abs() > 180 ||
        !natal.timezoneOffsetHours.isFinite ||
        natal.timezoneOffsetHours.abs() > 14) {
      throw ArgumentError('స్థలం, అక్షాంశం, రేఖాంశం, టైమ్‌జోన్ ధృవీకరించండి (IN-01/03).');
    }
    final origin = searchCenter ?? natal.originalBirthDateTime;
    // Resolve the period system ONCE at the search centre, never freshly for
    // each candidate second (which would overfit a birth-time search).
    final baseline = await scoreCandidate(natal:natal,
      candidateBirthTime:origin, events:events, bpdProfile:bpdProfile,
      synchronizationOffset: synchronizationOffset,
      periodCalendarBasis: periodCalendarBasis,
      chartCalculator:chartCalculator);
    final groupsWithVerification = <String>{};
    for (var i=0;i<events.length;i++) {
      final e=events[i];
      if (e.reliability!='verified') continue;
      groupsWithVerification.add(e.correlationGroup.trim().isEmpty
        ? 'independent:$i' : 'group:${e.correlationGroup.trim()}');
    }
    final confirmedSelection = chooseApplicablePeriod(
      vimshottariIndex: baseline.vimshottariIndex,
      tribhagiIndex: baseline.tribhagiIndex,
      verifiedIndependentGroups: groupsWithVerification.length,
      distinctEventTypes: events.map((e)=>e.ruleId).toSet().length);
    final independentGroups = events.asMap().entries.map((entry) =>
      entry.value.correlationGroup.trim().isEmpty
          ? 'independent:${entry.key}'
          : 'group:${entry.value.correlationGroup.trim()}').toSet().length;
    final provisionalSelection = confirmedSelection == null
        ? chooseProvisionalPeriod(
          evidence: baseline.evidence,
          independentGroups: independentGroups,
          distinctEventTypes: events.map((e)=>e.ruleId).toSet().length)
        : null;
    final selectedPeriod = switch(dashaMode) {
      MehtaDashaMode.tribhagiResearch => DashaSystemKind.tribhagi,
      MehtaDashaMode.parallelComparison => null,
      MehtaDashaMode.applicabilityFirst => confirmedSelection ?? provisionalSelection,
    };
    final isProvisional = dashaMode == MehtaDashaMode.applicabilityFirst &&
        confirmedSelection == null && provisionalSelection != null;
    final selectionNote = dashaMode == MehtaDashaMode.tribhagiResearch
      ? 'Tribhagi 80y ప్రయోగాత్మక ఎంపిక; గ్రంథంలో ప్రతి జాతకానికి ఇదే తప్పనిసరి కాదు.'
      : dashaMode == MehtaDashaMode.parallelComparison
        ? 'వింశోత్తరి/త్రిభాగి వేర్వేరు పోలిక; ర్యాంకింగ్‌లో రెండూ సరిపడిన కనిష్ఠ సూచిక మాత్రమే.'
        : selectedPeriod == null
          ? 'తగిన స్వతంత్ర సాక్ష్యాలు లేదా దశా ఆధిక్యం లేవు. రెండు సూచికల కనిష్ఠం conservative overlap మాత్రమే; అసలు Rule Match కాదు.'
          : isProvisional
          ? '${selectedPeriod?.teluguLabel ?? '—'}: reported సంఘటనలతో ప్రయోగాత్మక ఎంపిక మాత్రమే. Verified నిర్ధారణ కాదు; మరిన్ని స్వతంత్ర సంఘటనలతో పరీక్షించాలి.'
          : '${selectedPeriod?.teluguLabel ?? '—'}: నమోదు చేసిన సంఘటనలతో ప్రాథమిక అనుకూలత ఎక్కువ. ఇది తాత్కాలిక ఎంపిక; కొత్త సంఘటనలతో స్వతంత్ర ధృవీకరణ అవసరం.';
    final radius = plusMinusMinutes * 60;
    final coarseStep = switch (plusMinusMinutes) {
      720 => 1800,
      360 => 900,
      120 => 300,
      1 || 2 || 5 || 10 => 15,
      _ => 120,
    };
    final evaluated = <int, MehtaBtrCandidate>{};
    final perSecond = <int>{};
    var total = 0;
    var done = 0;

    Future<void> runOne(int second, {bool fine = false}) async {
      if (second.abs() > radius) return;
      if (evaluated.containsKey(second)) {
        if (fine) perSecond.add(second);
        return;
      }
      final candidate = await scoreCandidate(
        natal: natal,
        candidateBirthTime: origin.add(Duration(seconds: second)),
        events: events,
        bpdProfile: bpdProfile,
        selectedPeriod: selectedPeriod,
        synchronizationOffset: synchronizationOffset,
        periodCalendarBasis: periodCalendarBasis,
        chartCalculator: chartCalculator,
      );
      evaluated[second] = candidate;
      if (fine) perSecond.add(second);
      done++;
      onProgress?.call(done, total);
      if (done % 10 == 0) await Future<void>.delayed(Duration.zero);
    }

    Future<void> runBatch(Iterable<int> offsets, {bool fine = false}) async {
      final list = offsets.where((x) => x.abs() <= radius).toSet().toList()..sort();
      total += list.where((x) => !evaluated.containsKey(x)).length;
      for (final offset in list) { await runOne(offset, fine: fine); }
    }

    if (radius <= 600) {
      // Documented full 1-second sweep: no missing second in ±1/2/5/10 min.
      await runBatch([for (var second=-radius; second<=radius; second++) second],
        fine: true);
    } else {
      await runBatch({
        -radius, 0, radius,
        for (var s = -radius; s <= radius; s += coarseStep) s,
      });
      final coarse = Map<int, MehtaBtrCandidate>.of(evaluated);
      final ordered = coarse.entries.toList()..sort((a,b) {
        final score = b.value.evidenceShare.compareTo(a.value.evidenceShare);
        return score != 0 ? score : a.key.abs().compareTo(b.key.abs());
      });
      final anchors = <int>{0, -radius, radius};
      // Keep independent peaks, not just the first three tied timestamps.
      for (final e in ordered) {
        if (anchors.where((a) => (a-e.key).abs() < coarseStep).isEmpty) {
          anchors.add(e.key);
        }
        if (anchors.length >= 11) break;
      }
      // When coarse fingerprints differ, bisect transition to its exact second.
      final transitions = <int>{};
      final times = coarse.keys.toList()..sort();
      for (var i=1; i<times.length; i++) {
        var lo=times[i-1], hi=times[i];
        if (coarse[lo]!.timeSignature == coarse[hi]!.timeSignature) continue;
        var startSignature = coarse[lo]!.timeSignature;
        while (hi-lo > 1) {
          final mid = lo + ((hi-lo) ~/ 2);
          await runBatch([mid]);
          if (evaluated[mid]!.timeSignature == startSignature) { lo=mid; }
          else { hi=mid; }
        }
        transitions.add(hi);
        if (transitions.length >= 18) break;
      }
      // 15-second sweep around leading peaks and timed KP/varga boundaries.
      // For very wide birth windows, avoid pretending unexplored gaps were
      // scanned; the report explicitly discloses coarse global coverage.
      final mediumAnchors = <int>{...anchors};
      for (final t in transitions) { mediumAnchors.add(t); }
      final mediumOffsets = <int>{};
      final mediumRadius = coarseStep > 300 ? 180 : coarseStep;
      for (final anchor in mediumAnchors) {
        for(var x=anchor-mediumRadius; x<=anchor+mediumRadius; x+=15) {
          mediumOffsets.add(x);
        }
        mediumOffsets.add(anchor);
      }
      await runBatch(mediumOffsets);
      // Independently retain multiple local maxima and transition groups.
      final medium = evaluated.entries.toList()..sort((a,b) {
        final s=b.value.evidenceShare.compareTo(a.value.evidenceShare);
        return s != 0 ? s : a.key.abs().compareTo(b.key.abs());
      });
      final fineAnchors = <int>{...transitions};
      for (final e in medium) {
        if (fineAnchors.where((a) => (a-e.key).abs() < 35).isEmpty) {
          fineAnchors.add(e.key);
        }
        if (fineAnchors.length >= 24) break;
      }
      // One-second exhaustive local windows ±45 seconds around candidates,
      // always include immediate neighbours of all detected boundaries.
      final fineOffsets = <int>{};
      for (final anchor in fineAnchors) {
        for (var x=anchor-45; x<=anchor+45; x++) { fineOffsets.add(x); }
      }
      await runBatch(fineOffsets, fine: true);
    }
    final ranked = evaluated.values.toList()..sort((a,b) {
      final s=b.evidenceShare.compareTo(a.evidenceShare);
      if (s != 0) return s;
      return a.birthTime.difference(origin).abs().compareTo(
          b.birthTime.difference(origin).abs());
    });
    if (ranked.isEmpty) throw StateError('సమయ శోధనలో ఫలితం రాలేదు.');
    final maxScore = ranked.first.evidenceShare;
    const tolerance = 0.025;
    final competitive = evaluated.entries.where((e) =>
      e.value.evidenceShare >= maxScore-tolerance).toList();
    final compatibleTimes = competitive.map((e)=>e.key).toList()..sort();
    final windows = <BtrSecondWindow>[];
    final bestFine = perSecond.where((t) =>
      evaluated[t]!.evidenceShare >= maxScore-tolerance).toList()..sort();
    // Do not join disjoint time bands or assume untested gaps are verified.
    if (bestFine.isNotEmpty) {
      var first = bestFine.first, last = bestFine.first;
      String signature = evaluated[last]!.timeSignature;
      void addWindow() => windows.add(BtrSecondWindow(
        start: origin.add(Duration(seconds:first)),
        end: origin.add(Duration(seconds:last)),
        ruleMatchIndex: evaluated[first]!.evidenceShare,
        signature:signature));
      for (final s in bestFine.skip(1)) {
        final nextSign = evaluated[s]!.timeSignature;
        if (s != last+1 || nextSign != signature) {
          addWindow(); first=s; signature=nextSign;
        }
        last=s;
      }
      addWindow();
    }
    // Only one-second *resolution of sampled windows* is established.
    // Consistency of dated events cannot objectively prove a birth second.
    final verifiedCount = events.where((e)=>e.reliability=='verified').length;
    var discriminatingEvents = 0;
    for (var index=0; index<events.length; index++) {
      final samples = evaluated.values.map((c) => c.evidence[index].rankingShare);
      final minValue = samples.reduce((a,b)=>a<b?a:b);
      final maxValue = samples.reduce((a,b)=>a>b?a:b);
      if (maxValue-minValue > 1e-8) discriminatingEvents++;
    }
    final independentGroupCount = events.asMap().entries.map((e) =>
      e.value.correlationGroup.trim().isEmpty ? 'independent:${e.key}'
        : 'group:${e.value.correlationGroup.trim()}').toSet().length;
    final eligibleUniqueTypes = events.map((e)=>e.ruleId).toSet().length;
    final fineBest = bestFine.where((s)=>
      (evaluated[s]!.evidenceShare-maxScore).abs()<1e-9).toList();
    // Strong guard: seconds must differ in *both* candidate score and
    // checked ascensional boundary. Even this remains an app-specific ranking.
    final appearsIsolated = fineBest.length == 1 && windows.length == 1 &&
      windows.single.start == windows.single.end;
    final neighbour = appearsIsolated ? fineBest.single : 0;
    final bothNeighboursTested = appearsIsolated &&
      evaluated.containsKey(neighbour-1) && evaluated.containsKey(neighbour+1);
    final variesAtBoundary = bothNeighboursTested &&
      (evaluated[neighbour-1]!.timeSignature != evaluated[neighbour]!.timeSignature ||
       evaluated[neighbour+1]!.timeSignature != evaluated[neighbour]!.timeSignature);
    final completeSweep = perSecond.length == 2*radius+1;
    final distinguishable = appearsIsolated && bothNeighboursTested &&
      variesAtBoundary && maxScore >= 0.70 &&
      verifiedCount >= recommendedEvents && eligibleUniqueTypes >= 3 &&
      discriminatingEvents >= 3 &&
      competitive.length == 1 && completeSweep;
    final representatives = <MehtaBtrCandidate>[];
    for (final c in ranked) {
      if (representatives.every((r) =>
          c.birthTime.difference(r.birthTime).inSeconds.abs() > 60)) {
        representatives.add(c);
      }
      if (representatives.length >= 8) break;
    }
    // Independent diagnostics: best *sampled* birth-time candidate per
    // system. These are not independent full-range exhaustive searches.
    final byVim = evaluated.values.toList()..sort((a,b) {
      final n = b.vimshottariIndex.compareTo(a.vimshottariIndex);
      return n != 0 ? n : a.birthTime.difference(origin).abs().compareTo(
          b.birthTime.difference(origin).abs());
    });
    final byTrib = evaluated.values.toList()..sort((a,b) {
      final n = b.tribhagiIndex.compareTo(a.tribhagiIndex);
      return n != 0 ? n : a.birthTime.difference(origin).abs().compareTo(
          b.birthTime.difference(origin).abs());
    });
    return MehtaBtrResult(
      originalBirthTime: natal.originalBirthDateTime,
      testedTimes: evaluated.length,
      candidates: List.unmodifiable(representatives),
      rangeStart: origin.add(Duration(seconds: compatibleTimes.first)),
      rangeEnd: origin.add(Duration(seconds: compatibleTimes.last)),
      distinguishable: distinguishable,
      oneSecondSamples: perSecond.length,
      secondWindows: List.unmodifiable(windows),
      exhaustiveAcrossRequestedRange: completeSweep,
      coarseStepSeconds: coarseStep,
      discriminatingEvents: discriminatingEvents,
      independentGroups: independentGroupCount,
      requestedDashaMode: dashaMode,
      selectedPeriod: selectedPeriod,
      referenceVimshottariIndex: baseline.vimshottariIndex,
      referenceTribhagiIndex: baseline.tribhagiIndex,
      periodSelectionNote: selectionNote,
      provisionalPeriodSelection: isProvisional,
      bestVimshottariBirthTime: byVim.first.birthTime,
      bestTribhagiBirthTime: byTrib.first.birthTime,
      synchronizationOffset: synchronizationOffset,
      periodCalendarBasis: periodCalendarBasis,
      resolutionNote: completeSweep
        ? 'మొత్తం ఎంచుకున్న పరిధిని సెకనుకు ఒకసారి పరీక్షించాం.'
        : 'మొత్తం పరిధి ${coarseStep}s నమూనాతో; ఉత్తమ ప్రాంతాలు/లగ్న మార్పులు 15s, 1s దశల్లో పరిశీలించాం. '
          'ఇతర మధ్య అంతరాలు 1-సెకను స్థాయిలో పూర్తిగా స్కాన్ కాలేదు.',
    );
  }
}
