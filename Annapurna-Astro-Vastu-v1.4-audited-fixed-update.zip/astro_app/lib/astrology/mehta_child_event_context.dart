import 'astro_models.dart';
import 'kp_service.dart';
import 'sk_mehta_service.dart';
import 'varga_service.dart';

/// Independent, APP-DESIGNED contextual checks for an observed child-birth
/// event. This is not a verified SK Mehta dictum, not an event prediction,
/// and not proof of a birth second. It MUST be displayed separately from the
/// strict M06 direct AD/PD/Sukshma-lord comparison and selected source rules.
class MehtaChildEventContext {
  final bool available;
  final double linkShare;
  final List<String> observations;
  final List<String> missing;
  final int d1AscSign;
  final int d7AscSign;

  const MehtaChildEventContext({
    required this.available,
    required this.linkShare,
    required this.observations,
    required this.missing,
    required this.d1AscSign,
    required this.d7AscSign,
  });

  static MehtaChildEventContext assess(
      AstroChartResult chart, List<String> periodLords) {
    final d1 = chart.ascendantSignIndex;
    final d7 = VargaService.signForLongitude(chart.ascendantLongitude, 7);
    final all = {for (final p in chart.planets) p.name: p};
    // A stub chart or missing key planet data must not manufacture evidence.
    final available = chart.planets.length >= 7 && all.containsKey('Jupiter');
    if (!available) {
      return MehtaChildEventContext(available: false, linkShare: 0,
        observations: const [],
        missing: const ['D1/D7 గ్రహస్థానాలు పూర్తిగా లేవు; సందర్భ పరీక్ష చేయలేదు'],
        d1AscSign: d1, d7AscSign: d7);
    }
    final d1Lords = <String>{
      for (final h in [1, 5, 9]) SkMehtaService.houseLordFromAsc(d1, h),
    };
    final d7Lords = <String>{
      for (final h in [1, 5, 9]) SkMehtaService.houseLordFromAsc(d7, h),
    };
    final observations = <String>[];
    final missing = <String>[];
    var points = 0.0;
    // An AD/PD/Sukshma lord is one period-level observation; do not count
    // multiple links for the same lord as independent events.
    for (final lord in periodLords) {
      final planet = all[lord];
      if (planet == null) {
        missing.add('$lord గ్రహస్థానం లేదు (రాహు/కేతు ప్రత్యేకత పరీక్షించలేదు)');
        continue;
      }
      final direct = d1Lords.contains(lord);
      final d7Lord = d7Lords.contains(lord);
      final d1House = ((planet.signIndex - d1 + 12) % 12) + 1;
      final d7PlanetSign = VargaService.signForLongitude(planet.longitude, 7);
      final d7House = ((d7PlanetSign - d7 + 12) % 12) + 1;
      final starLord = KpService.forLongitude(lord, planet.longitude).starLord;
      final stellarLink = d1Lords.contains(starLord) || d7Lords.contains(starLord);
      final karakaLink = lord == 'Jupiter' || starLord == 'Jupiter';
      final d1Placement = d1House == 5 || d1House == 9;
      final d7Placement = d7House == 5 || d7House == 9;
      final notes = <String>[];
      if (direct) notes.add('D1 సంబంధిత భావాధిపతి');
      if (d7Lord) notes.add('D7 1/5/9 భావాధిపతి');
      if (d1Placement) notes.add('D1 $d1House భావస్థానం');
      if (d7Placement) notes.add('D7 $d7House భావస్థానం');
      if (stellarLink) notes.add('నక్షత్రాధిపతి $starLord భావ సంబంధం');
      if (karakaLink) notes.add('గురు కారకత్వ సంబంధం');
      // Maximum one contextual contribution per AD/PD/Sukshma level.
      // A direct Mehta match is scored independently by the calling service.
      if (notes.isNotEmpty) {
        points += 1;
        observations.add('$lord: ${notes.join(' • ')}');
      }
    }
    return MehtaChildEventContext(
      available: true,
      linkShare: (points / 3).clamp(0.0, 1.0).toDouble(),
      observations: List.unmodifiable(observations),
      missing: List.unmodifiable(missing),
      d1AscSign: d1, d7AscSign: d7,
    );
  }
}
