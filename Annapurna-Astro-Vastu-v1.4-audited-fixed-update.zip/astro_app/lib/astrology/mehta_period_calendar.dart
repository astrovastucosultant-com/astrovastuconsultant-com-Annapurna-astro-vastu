/// S.K. Mehta, New Dimensions in Hindu Astrology, Ch. XVI (pp. 218–252).
///
/// The text expresses period lengths in a 360-day / 30-day symbolic year.
/// Gregorian dates have variable month lengths. Keep those operations
/// separate; do NOT claim that the examples establish a unique historical
/// civil-date conversion convention.
class MehtaBookPeriod {
  final int years;
  final int months;
  final int days;
  final int sign;

  const MehtaBookPeriod({
    required this.years,
    required this.months,
    required this.days,
    this.sign = 1,
  });

  factory MehtaBookPeriod.fromFractionalYears(double yearsValue) {
    if (!yearsValue.isFinite) throw ArgumentError('Finite duration required');
    final normalizedDays = (yearsValue.abs() * 360).round();
    return MehtaBookPeriod(
      years: normalizedDays ~/ 360,
      months: (normalizedDays % 360) ~/ 30,
      days: normalizedDays % 30,
      sign: yearsValue < 0 ? -1 : 1,
    );
  }

  int get normalizedDays => sign * (years * 360 + months * 30 + days);
  int get totalCalendarMonths => sign * (years * 12 + months);
  String get sourceYmd => '${sign < 0 ? "−" : ""}$years-$months-$days';
}

/// Independent synchronization correction to a *dasha timeline*;
/// it must never be interpreted as a change to the natal clock time.
class MehtaSynchronizationOffset {
  final int months;
  final int days;
  const MehtaSynchronizationOffset({this.months = 0, this.days = 0});

  bool get isZero => months == 0 && days == 0;
  bool get isConsistent => (months >= 0 && days >= 0) ||
      (months <= 0 && days <= 0);
  String get label => isZero ? '0 (సవరణ లేదు)' :
      '${months >= 0 && days >= 0 ? "+" : "−"}'
      '${months.abs()} నెలలు ${days.abs()} రోజులు';
}

class MehtaPeriodCalendar {
  /// Use the book's 360/30 arithmetic for symbolic duration *formatting*.
  static MehtaBookPeriod period(double years) =>
      MehtaBookPeriod.fromFractionalYears(years);

  static DateTime _construct(DateTime sample, int year, int month, int day) {
    if (sample.isUtc) {
      return DateTime.utc(year, month, day, sample.hour, sample.minute,
          sample.second, sample.millisecond, sample.microsecond);
    }
    return DateTime(year, month, day, sample.hour, sample.minute,
        sample.second, sample.millisecond, sample.microsecond);
  }

  /// Calendar month arithmetic clamps month-end dates, then adds civil days.
  /// It reproduces e.g. 16-Feb-1953 + 4y8m8d = 24-Oct-1957.
  /// This is a declared app convention, not a proven universal Mehta rule.
  static DateTime addCalendar(DateTime origin, {int months = 0, int days = 0}) {
    final monthIndex = origin.year * 12 + origin.month - 1 + months;
    final targetYear = monthIndex ~/ 12;
    final targetMonth = monthIndex % 12 + 1;
    final monthEnd = _construct(origin, targetYear, targetMonth + 1, 0).day;
    final keptDay = origin.day > monthEnd ? monthEnd : origin.day;
    return _construct(origin, targetYear, targetMonth, keptDay + days);
  }

  /// Keep sub-day periods sub-day; rounding *every* dasha level to whole
  /// book days would collapse Sukshma/Prana to zero-length intervals.
  static DateTime addBookYears(DateTime origin, double yearsValue) {
    if (!yearsValue.isFinite) throw ArgumentError('Finite duration required');
    final rawDays = yearsValue.abs() * 360.0;
    final nearestWholeDay = rawDays.round();
    // Floating point noise in e.g. 4 + 8/12 + 8/360 must not turn
    // Oct-24 into Oct-23 23:59:59.999999.
    final absoluteDays = (rawDays - nearestWholeDay).abs() < 1e-7
        ? nearestWholeDay.toDouble() : rawDays;
    if (absoluteDays < 1.0) {
      return origin.add(Duration(microseconds:
          (yearsValue * 360 * Duration.microsecondsPerDay).round()));
    }
    final sign = yearsValue < 0 ? -1 : 1;
    final fullDays = absoluteDays.floor();
    final fullMonths = fullDays ~/ 30;
    final days = fullDays % 30;
    final fraction = absoluteDays - fullDays;
    final date = addCalendar(origin, months: sign * fullMonths, days: sign * days);
    return date.add(Duration(microseconds:
        (sign * fraction * Duration.microsecondsPerDay).round()));
  }

  /// Advance(+)/retard(-) all dasha start dates by the same civil month/day
  /// offset without changing the recorded natal date or chart calculation.
  static DateTime synchronize(DateTime start,
      MehtaSynchronizationOffset offset) {
    if (!offset.isConsistent || offset.months.abs() > 24 ||
        offset.days.abs() > 29) {
      throw ArgumentError('Invalid signed months/days synchronization');
    }
    return addCalendar(start, months: offset.months, days: offset.days);
  }
}
