import 'astro_models.dart';
import 'kp_service.dart';

/// A separate KP/Placidus analysis. No BPD/BNN/BCP rules are used here.
/// The four levels are deliberately kept visible rather than collapsed into
/// an invented single 'KP certainty' score.
class KpCuspRow {
  final int house;
  final KpStellarPosition stellar;
  const KpCuspRow(this.house, this.stellar);
}

class KpPlanetSignification {
  final String planet;
  final String starLord;
  final String subLord;
  final String subSubLord;
  final int occupiedHouse;
  final List<int> starLordOccupied; // constellation-lord occupation
  final List<int> occupied;         // direct occupation
  final List<int> starLordOwned;    // constellation-lord ownership
  final List<int> owned;            // direct cusp sign ownership
  final bool isNode;
  const KpPlanetSignification({
    required this.planet,
    required this.starLord,
    required this.subLord,
    required this.subSubLord,
    required this.occupiedHouse,
    required this.starLordOccupied,
    required this.occupied,
    required this.starLordOwned,
    required this.owned,
    required this.isNode,
  });

  List<int> get houses {
    final all = <int>{
      ...starLordOccupied, ...occupied, ...starLordOwned, ...owned,
    }.toList()..sort();
    return all;
  }

  String get fourLevels => 'A నక్షత్రాధిపతి స్థానం: ${starLordOccupied.join(', ')}; '
      'B గ్రహస్థానం: ${occupied.join(', ')}; '
      'C నక్షత్రాధిపతి స్వామిత్వం: ${starLordOwned.join(', ')}; '
      'D గ్రహ స్వామిత్వం: ${owned.join(', ')}'
      '${isNode ? ' • రాహు/కేతు ప్రతినిధి/సంయోగ/దృష్టి ఇంకా మాన్యువల్' : ''}';
}

/// KP fruitful-significator screening for a specified event.
/// Sources: the supplied KP source material plus published KP selection
/// approaches. A candidate is NOT a verified event promise or timing result.
/// Ruling planets may be supplied manually for a particular judgment moment;
/// never silently substitute natal planets for ruling planets.
enum KpFruitfulStatus {
  candidate,
  mixed,
  adverse,
  unrelated,
  needsVerification,
}

class KpFruitfulSignificator {
  final String planet;
  final String starLord;
  final String subLord;
  final List<int> eventHouses;
  final List<int> starHouses;
  final List<int> subHouses;
  final List<int> contraryStarHouses;
  final List<int> contrarySubHouses;
  final bool isCuspalSubLord;
  final bool inCuspalSubLordStar;
  final bool isRulingPlanet;
  final bool constellationUntenanted;
  final KpFruitfulStatus status;
  final String limitations;

  const KpFruitfulSignificator({
    required this.planet,
    required this.starLord,
    required this.subLord,
    required this.eventHouses,
    required this.starHouses,
    required this.subHouses,
    required this.contraryStarHouses,
    required this.contrarySubHouses,
    required this.isCuspalSubLord,
    required this.inCuspalSubLordStar,
    required this.isRulingPlanet,
    required this.constellationUntenanted,
    required this.status,
    required this.limitations,
  });

  String get statusText => switch (status) {
    KpFruitfulStatus.candidate => '🟢 Fruitful Candidate / అనుకూల అభ్యర్థి',
    KpFruitfulStatus.mixed => '🟠 Mixed / మిశ్రమ సూచనలు',
    KpFruitfulStatus.adverse => '🔴 Unfruitful / వ్యతిరేక సబ్ సూచన',
    KpFruitfulStatus.unrelated => '⚪ Relevant Significator కాదు',
    KpFruitfulStatus.needsVerification => '⚪ More Verification Required',
  };

  String get detail => '$planet • $statusText. '
      'Star $starLord → శుభ ${starHouses.isEmpty ? "లేవు" : starHouses.join(", ")}, '
      'వ్యతిరేక ${contraryStarHouses.isEmpty ? "లేవు" : contraryStarHouses.join(", ")}; '
      'Sub $subLord → శుభ ${subHouses.isEmpty ? "లేవు" : subHouses.join(", ")}, '
      'వ్యతిరేక ${contrarySubHouses.isEmpty ? "లేవు" : contrarySubHouses.join(", ")}. '
      'గ్రహానికి సంఘటన భావాలు ${eventHouses.isEmpty ? "లేవు" : eventHouses.join(", ")}. '
      'సంబంధిత Cusp Sub-Lord ${isCuspalSubLord ? "అవును" : "కాదు"}; '
      'Cusp Sub-Lord నక్షత్రంలో ${inCuspalSubLordStar ? "అవును" : "కాదు"}; '
      'గ్రహ నక్షత్రంలో ఇతర గ్రహాలు లేవు: ${constellationUntenanted ? "అవును" : "కాదు"}; '
      'Ruling Planets పోలిక ${isRulingPlanet ? "ఉంది" : "లేదు/ఇవ్వలేదు"}. '
      '$limitations';
}

class KpEventAudit {
  final String label;
  final int primaryHouse;
  final List<int> favourableHouses;
  final List<int> contraryHouses;
  final KpCuspRow primaryCusp;
  final KpPlanetSignification subLord;
  final List<String> eventSignificators;
  final List<int> matchingHouses;
  final List<int> contraryMatches;
  final bool qualified;
  final List<KpFruitfulSignificator> fruitfulSignificators;
  final String note;
  const KpEventAudit({
    required this.label,
    required this.primaryHouse,
    required this.favourableHouses,
    required this.contraryHouses,
    required this.primaryCusp,
    required this.subLord,
    required this.eventSignificators,
    required this.matchingHouses,
    required this.contraryMatches,
    required this.qualified,
    this.fruitfulSignificators = const [],
    required this.note,
  });

  /// Context evidence, not a proven event-promise verdict.
  bool get hasFavourableLink => matchingHouses.isNotEmpty;
  String get fruitfulSummary {
    final candidates = fruitfulSignificators.where((p) =>
        p.status == KpFruitfulStatus.candidate).map((p) => p.planet).toList();
    final mixed = fruitfulSignificators.where((p) =>
        p.status == KpFruitfulStatus.mixed).map((p) => p.planet).toList();
    final pending = fruitfulSignificators.where((p) =>
        p.status == KpFruitfulStatus.needsVerification).map((p) => p.planet).toList();
    return 'Fruitful candidates: ${candidates.isEmpty ? "లేవు" : candidates.join(", ")}; '
        'Mixed: ${mixed.isEmpty ? "లేవు" : mixed.join(", ")}; '
        'పరిశీలించాల్సినవి: ${pending.isEmpty ? "లేవు" : pending.join(", ")}. '
        'ఇవి ప్రాథమిక Star/Sub స్క్రీనింగ్ మాత్రమే; పూర్తి KP ఫల నిర్ధారణ కాదు.';
  }

  String get fruitfulEvidence => fruitfulSignificators
      .where((p) => p.status != KpFruitfulStatus.unrelated)
      .map((p) => '${p.planet}: ${p.statusText} '
          '(Star ${p.starLord}/Sub ${p.subLord}; '
          'శుభ భావాలు ${p.subHouses.join(",")}; '
          'వ్యతిరేక భావాలు ${p.contrarySubHouses.join(",")})')
      .join(' • ');

  String get detail => '$label: Cusp $primaryHouse '
      '${primaryCusp.stellar.longitude.toStringAsFixed(6)}° '
      'Star ${primaryCusp.stellar.starLord} / '
      'Sub ${primaryCusp.stellar.subLord} / '
      'Sub-Sub ${primaryCusp.stellar.subSubLord}. '
      'Sub Lord ${subLord.planet} → ${subLord.fourLevels}. '
      'అనుకూల భావ సంబంధం: ${matchingHouses.isEmpty ? 'లేదు' : matchingHouses.join(', ')}; '
      'వ్యతిరేక భావ సంబంధం: ${contraryMatches.isEmpty ? 'లేదు' : contraryMatches.join(', ')}. '
      'సూచక గ్రహాలు: ${eventSignificators.isEmpty ? 'లేవు' : eventSignificators.join(', ')}. '
      '$fruitfulSummary '
      '$note';
}

class KpCuspSignificatorResult {
  final List<KpCuspRow> cusps;
  final Map<String, KpPlanetSignification> planets;
  final String? warning;
  const KpCuspSignificatorResult({
    required this.cusps, required this.planets, this.warning,
  });

  bool get available => warning == null && cusps.length == 12;
  String get signature => available
    ? cusps.map((row) => '${row.house}:${row.stellar.signIndex}/'
        '${row.stellar.nakshatraIndex}/${row.stellar.starLord}/'
        '${row.stellar.subLord}/${row.stellar.subSubLord}').join('|')
    : 'UNAVAILABLE';

  /// The KP house groups are independent of the S.K. Mehta rule's houses.
  KpEventAudit? forEvent(String mehtaEventId, {Set<String> rulingPlanets = const {}}) {
    if (!available) return null;
    final config = KpCuspSignificatorService.eventMap[mehtaEventId];
    if (config == null) return null;
    final (label, primary, favourable, contrary) = config;
    final cusp = cusps[primary - 1];
    final lord = planets[cusp.stellar.subLord];
    if (lord == null) return null;
    final favourableLink = lord.houses.toSet().intersection(favourable.toSet()).toList()..sort();
    final contraryLink = lord.houses.toSet().intersection(contrary.toSet()).toList()..sort();
    final actors = planets.values.where((p) => p.houses.any(favourable.contains))
        .map((p) => p.planet).toList()..sort();
    final qualified = lord.isNode || contraryLink.isNotEmpty;
    final fruitful = KpCuspSignificatorService.selectFruitful(
        planets: planets, cusps: cusps,
        favourable: favourable, contrary: contrary,
        rulingPlanets: rulingPlanets);
    return KpEventAudit(
      label: label, primaryHouse: primary, favourableHouses: favourable,
      contraryHouses: contrary, primaryCusp: cusp, subLord: lord,
      eventSignificators: actors, matchingHouses: favourableLink,
      contraryMatches: contraryLink, qualified: qualified,
      fruitfulSignificators: fruitful,
      note: 'KP Cusp/Sub-lord, constellation occupation/ownership స్థాయిల పరిశీలన. '
          'రాహు/కేతు ప్రతినిధిత్వం, వక్రత్వం, గ్రహదృష్టులు, Dasha/Bhukti '
          'ఫలిత నిర్ణయం పూర్తిగా స్వయంచాలకంగా ధృవీకరించలేదు; '
          'ఈ సంబంధాన్ని జనన సెకను రుజువుగా పరిగణించవద్దు.',
    );
  }
}

class KpCuspSignificatorService {
  /// Source: the user's KP source rulebook (Cusp -> Star -> Sub ->
  /// Signification -> event houses). Application mapping from Mehta event ID
  /// to KP houses is explicit; never reuse Mehta ascHouses automatically.
  static const Map<String, (String, int, List<int>, List<int>)> eventMap = {
    'M01': ('Marriage', 7, [2, 7, 11], [1, 6, 10, 12]),
    'M02': ('Higher education / profession', 9, [4, 9, 11], <int>[]),
    'M03': ('Wealth', 2, [2, 6, 10, 11], [5, 8, 12]),
    'M04': ('Foreign travel', 12, [3, 9, 12], <int>[]),
    'M05': ('Foreign travel', 12, [3, 9, 12], <int>[]),
    'M06': ('Childbirth', 5, [2, 5, 11], [1, 4, 10]),
    'M07': ('Property', 4, [4, 11, 12], <int>[]),
    'M08': ('Vehicle', 4, [4, 11], <int>[]),
    'M11': ('Government service/promotion', 10, [2, 6, 10, 11], <int>[]),
    'M12': ('Private service/change', 10, [2, 6, 10, 11], <int>[]),
    'M13': ('Appointment', 10, [2, 6, 10, 11], <int>[]),
    'M14': ('Business', 7, [2, 7, 10, 11], <int>[]),
  };

  /// Event-specific, non-scoring KP screening. Star shows the houses a
  /// planet can activate; its Sub Lord is evaluated for favourable/contrary
  /// event houses. Neither KP judgement RPs nor node representatives are
  /// invented when unavailable.
  static List<KpFruitfulSignificator> selectFruitful({
    required Map<String, KpPlanetSignification> planets,
    required List<KpCuspRow> cusps,
    required List<int> favourable,
    required List<int> contrary,
    Set<String> rulingPlanets = const {},
  }) {
    final fav = favourable.toSet();
    final neg = contrary.toSet();
    List<int> intersection(List<int> input, Set<int> targets) =>
        (input.toSet().intersection(targets).toList()..sort());
    final relevantCuspSubLords = <String>{
      for (final h in fav)
        if (h >= 1 && h <= cusps.length) cusps[h - 1].stellar.subLord,
    };
    final starTenantCounts = <String, int>{};
    for (final p in planets.values) {
      starTenantCounts[p.starLord] = (starTenantCounts[p.starLord] ?? 0) + 1;
    }
    final output = <KpFruitfulSignificator>[];
    for (final p in planets.values) {
      final star = planets[p.starLord];
      final sub = planets[p.subLord];
      final related = intersection(p.houses, fav);
      final starGood = intersection(star?.houses ?? const [], fav);
      final subGood = intersection(sub?.houses ?? const [], fav);
      final starBad = intersection(star?.houses ?? const [], neg);
      final subBad = intersection(sub?.houses ?? const [], neg);
      final node = p.isNode || (star?.isNode ?? false) ||
          (sub?.isNode ?? false);
      final missing = star == null || sub == null;
      final KpFruitfulStatus status;
      if (related.isEmpty) {
        status = KpFruitfulStatus.unrelated;
      } else if (node || missing) {
        status = KpFruitfulStatus.needsVerification;
      } else if (subBad.isNotEmpty && subGood.isEmpty) {
        status = KpFruitfulStatus.adverse;
      } else if ((starBad.isNotEmpty || subBad.isNotEmpty) &&
          (starGood.isNotEmpty || subGood.isNotEmpty)) {
        status = KpFruitfulStatus.mixed;
      } else if (starGood.isNotEmpty && subGood.isNotEmpty &&
          starBad.isEmpty && subBad.isEmpty) {
        status = KpFruitfulStatus.candidate;
      } else {
        status = KpFruitfulStatus.needsVerification;
      }
      output.add(KpFruitfulSignificator(
        planet: p.planet,
        starLord: p.starLord,
        subLord: p.subLord,
        eventHouses: related,
        starHouses: starGood,
        subHouses: subGood,
        contraryStarHouses: starBad,
        contrarySubHouses: subBad,
        isCuspalSubLord: relevantCuspSubLords.contains(p.planet),
        inCuspalSubLordStar: relevantCuspSubLords.contains(p.starLord),
        isRulingPlanet: rulingPlanets.contains(p.planet),
        constellationUntenanted: (starTenantCounts[p.planet] ?? 0) == 0,
        status: status,
        limitations: node
            ? 'రాహు/కేతు ప్రతినిధి సంబంధాల పూర్తి పరిశీలన అవసరం.'
            : missing
                ? 'నక్షత్ర/సబ్ అధిపతి పూర్తి గ్రహ డేటా లేదు.'
                : 'Ruling Planets, retrograde, Dasha-Bhukti, transit, '
                    'source-specific exceptions వేరుగా ధృవీకరించాలి.',
      ));
    }
    return List.unmodifiable(output);
  }

  static KpCuspSignificatorResult compute(AstroChartResult chart) {
    if (chart.houseCuspLongitudes.length != 12) {
      return const KpCuspSignificatorResult(cusps: [], planets: {},
          warning: '12 Placidus KP house cusps లభించలేదు. గణనను ఊహించవద్దు.');
    }
    final values = chart.houseCuspLongitudes;
    if (values.any((x) => !x.isFinite)) {
      return const KpCuspSignificatorResult(cusps: [], planets: {},
          warning: 'Invalid cusp longitude; KP audit నిలిపివేశాం.');
    }
    double norm(double x) => (x % 360 + 360) % 360;
    final normalized = values.map(norm).toList(growable: false);
    final arcs = <double>[];
    for (var h = 0; h < 12; h++) {
      final arc = norm(normalized[(h + 1) % 12] - normalized[h]);
      if (arc < 1e-7) {
        return const KpCuspSignificatorResult(cusps: [], planets: {},
            warning: 'Degenerate house cusps; KP audit నిలిపివేశాం.');
      }
      arcs.add(arc);
    }
    // Normal order is mandatory; otherwise planets could be assigned to two
    // overlapping cuspal arcs, e.g. unsupported high-latitude cases.
    final arcSum = arcs.fold<double>(0, (a, b) => a + b);
    if ((arcSum - 360).abs() > 0.001) {
      return const KpCuspSignificatorResult(cusps: [], planets: {},
          warning: 'Cusps cyclic ordering invalid; KP audit నిలిపివేశాం.');
    }
    int houseOf(double longitude) {
      final p = norm(longitude);
      for (var i = 0; i < 12; i++) {
        if (norm(p - normalized[i]) < arcs[i]) return i + 1;
      }
      throw StateError('KP house boundary was not resolved');
    }
    final rows = <KpCuspRow>[
      for (var h = 0; h < 12; h++)
        KpCuspRow(h + 1, KpService.forLongitude('Cusp ${h + 1}', normalized[h])),
    ];
    final occupied = <String, int>{};
    final stars = <String, KpStellarPosition>{};
    for (final p in chart.planets) {
      occupied[p.name] = houseOf(p.longitude);
      stars[p.name] = KpService.forLongitude(p.name, p.longitude);
    }
    final owners = <String, List<int>>{};
    for (final row in rows) {
      owners.putIfAbsent(row.stellar.signLord, () => []).add(row.house);
    }
    final planets = <String, KpPlanetSignification>{};
    for (final p in chart.planets) {
      final lord = stars[p.name]!.starLord;
      final starOccupied = occupied.containsKey(lord) ? <int>[occupied[lord]!] : <int>[];
      planets[p.name] = KpPlanetSignification(
        planet: p.name, starLord: lord,
        subLord: stars[p.name]!.subLord,
        subSubLord: stars[p.name]!.subSubLord,
        occupiedHouse: occupied[p.name]!,
        starLordOccupied: starOccupied,
        occupied: [occupied[p.name]!],
        starLordOwned: owners[lord] ?? <int>[],
        owned: owners[p.name] ?? <int>[],
        isNode: p.name == 'Rahu' || p.name == 'Ketu',
      );
    }
    return KpCuspSignificatorResult(cusps: List.unmodifiable(rows),
        planets: Map.unmodifiable(planets));
  }
}
