import 'dart:convert';

import 'astro_models.dart';
import 'dasha_service.dart';
import 'sk_mehta_service.dart';

/// Immutable source-first RULE REGISTRY (311 editorial entries).
/// Neither a non-match nor a horoscope assessment can remove/alter a record.
/// `previous_compilation_unchanged` is a prior Telugu compilation, NOT the
/// author's English verbatim text. Every entry retains its source-audit status.
class MehtaSourceEntry {
  final Map<String, dynamic> raw;
  MehtaSourceEntry(Map<String, dynamic> value)
      : raw = _freeze(value) as Map<String, dynamic>;

  // Deep immutability: audit or UI work must never mutate a source record.
  static dynamic _freeze(dynamic value) {
    if (value is Map) {
      return Map<String, dynamic>.unmodifiable({
        for (final entry in value.entries)
          entry.key.toString(): _freeze(entry.value),
      });
    }
    if (value is List) {
      return List<dynamic>.unmodifiable(value.map(_freeze));
    }
    return value;
  }

  String get id => raw['rule_id']?.toString() ?? '';
  String get section => raw['section']?.toString() ?? '';
  String get book => raw['source_book']?.toString() ?? '';
  Map<String, dynamic> get compilation =>
      Map<String, dynamic>.unmodifiable(
          Map<String, dynamic>.from(raw['previous_compilation_unchanged'] as Map));
  Map<String, dynamic> get audit =>
      Map<String, dynamic>.unmodifiable(
          Map<String, dynamic>.from(raw['source_audit'] as Map));
  Map<String, dynamic> get reference =>
      Map<String, dynamic>.unmodifiable(
          Map<String, dynamic>.from(raw['source_reference'] as Map));
  String get title => compilation['title']?.toString() ?? id;
  String get auditStatus => audit['status']?.toString() ?? 'NOT_VERIFIED_SOURCE_PAGE_BY_PAGE';
  String get auditTelugu => audit['status_telugu']?.toString() ?? 'మూలపేజీ ధృవీకరణ పెండింగ్';
  String get sourcePage => reference['claimed_printed_pages']?.toString() ?? 'తెలియదు';
  String get scanPage => reference['source_scan_reviewed']?.toString() ?? '';

  /// The whole previous compilation is displayed, without silently omitting
  /// condition, result, exception, check, details or house shorthand.
  String get searchableText => [id, title, book, sourcePage, scanPage,
    auditTelugu, ...compilation.values.map((v) => v.toString())]
      .join(' ').toLowerCase();
}

class MehtaSourceFirstEngine {
  const MehtaSourceFirstEngine._();

  static const Map<String, String> eventFromBtr = {
    'M01':'E01', 'M02':'E02', 'M03':'E04', 'M04':'E05',
    'M05':'E06', 'M06':'E08', 'M07':'E10', 'M08':'E11',
    'M09':'E12', 'M10':'E13', 'M11':'E14', 'M12':'E15',
    'M13':'E16', 'M14':'E17',
  };

  /// Source SUMMARY groupings for contextual inspection only.
  /// These are not substitute transcriptions of source subrule permutations.
  /// `E20` is deliberately absent: repetition is NOT a new house combination.
  static const Map<String, List<List<int>>> eventHouseAlternatives = {
    'E01': [[1,7,12]], 'E02': [[9,10,4]], 'E03': [[3,4,10]],
    'E04': [[2], [2,9]], 'E05': [[12,4]], 'E06': [[12,7]],
    'E07': [[12,3]], 'E08': [[1,5,9]], 'E09': [[7,11,3]],
    'E10': [[4]], 'E11': [[4]], 'E12': [[1,6]],
    'E13': [[4],[6]], 'E14': [[9,10],[10,11]],
    'E15': [[7,9],[7,11]], 'E16': [[9,10,11],[7,9,11]],
    'E17': [[7,2]], 'E18': [[12,3]], 'E19': [[6,9]],
  };

  static List<MehtaSourceEntry> decodeRegistry(String jsonText) {
    final parsed = jsonDecode(jsonText);
    if (parsed is! Map || parsed['rules'] is! List) {
      throw const FormatException('మూల రిజిస్టర్ నిర్మాణం సరిపోలలేదు');
    }
    final rows = (parsed['rules'] as List).map((row) =>
        MehtaSourceEntry(Map<String, dynamic>.from(row as Map)))
        .toList(growable: false);
    final ids = rows.map((r) => r.id).toSet();
    if (rows.length != 311 || ids.length != 311 ||
        rows.where((r) => r.section == 'EVENT').length != 20 ||
        rows.where((r) => r.section == 'NEW_RULE').length != 85 ||
        rows.where((r) => r.section == 'NEW_DIMENSION').length != 206 ||
        rows.any((r) => r.id.isEmpty || r.book.isEmpty ||
          r.auditStatus.isEmpty ||
          r.raw['rule_is_never_deactivated_by_horoscope_nonmatch'] != true)) {
      throw const FormatException('311 మూల నియమాల సంఖ్య/ID/రక్షణ పరీక్ష విఫలం');
    }
    return List<MehtaSourceEntry>.unmodifiable(rows);
  }

  static int? signOf(AstroChartResult chart, String name) {
    for (final p in chart.planets) {
      if (p.name.toLowerCase() == name.toLowerCase()) return p.signIndex;
    }
    return null;
  }

  static List<MehtaHouseContext> houseContexts(AstroChartResult chart,
      MehtaSourceEntry rule, {bool includeSun = false}) {
    final alternatives = eventHouseAlternatives[rule.id];
    if (alternatives == null) return const [];
    final moon = signOf(chart, 'Moon');
    final sun = signOf(chart, 'Sun');
    final contexts = <MehtaHouseContext>[
      MehtaHouseContext.fromSign('జన్మలగ్నం', chart.ascendantSignIndex, alternatives),
      if (moon != null)
        MehtaHouseContext.fromSign('చంద్రలగ్నం', moon, alternatives),
      if (includeSun && sun != null)
        MehtaHouseContext.fromSign('సూర్యలగ్నం (అదనపు వీడియో పరిశీలన)', sun, alternatives),
    ];
    return List.unmodifiable(contexts);
  }

  static MehtaPeriodComparison inspectPeriods(
      List<MehtaHouseContext> contexts,
      DashaPath? vimshottari, DashaPath? tribhagi) {
    return MehtaPeriodComparison(
      vimshottari: _inspectOne('వింశోత్తరి', contexts, vimshottari),
      tribhagi: _inspectOne('త్రిభాగి', contexts, tribhagi),
    );
  }

  static MehtaPeriodRow _inspectOne(String label,
      List<MehtaHouseContext> contexts, DashaPath? path) {
    if (path == null) return MehtaPeriodRow(label, const [], const [], false);
    final lords = [path.mahadasha.lord, path.antardasha.lord,
      path.pratyantardasha.lord, path.sukshma.lord, path.prana.lord];
    final notes = <String>[];
    // 2nd/3rd/4th places are *observations*, not a 100% source-rule match.
    for (final context in contexts) {
      for (final alternative in context.groups) {
        for (var i = 1; i <= 3; i++) {
          final lord = lords[i];
          final relatedHouses = alternative.entries
              .where((h) => h.value == lord).map((h) => h.key).toList();
          if (relatedHouses.isNotEmpty) {
            notes.add('${context.reference} • దశ స్థానం ${i + 1}: '
              '$lord → భావం ${relatedHouses.join(", ")}');
          }
        }
      }
    }
    return MehtaPeriodRow(label, List.unmodifiable(lords),
      List.unmodifiable(notes.toSet()), true);
  }
}

class MehtaHouseContext {
  final String reference;
  final List<Map<int, String>> groups;
  const MehtaHouseContext(this.reference, this.groups);
  factory MehtaHouseContext.fromSign(String name, int sign,
      List<List<int>> alternatives) => MehtaHouseContext(name,
        List.unmodifiable(alternatives.map((houses) =>
          Map<int, String>.unmodifiable({
            for (final house in houses)
              house: SkMehtaService.houseLordFromAsc(sign, house),
          })).toList(growable: false)));
}

class MehtaPeriodRow {
  final String label;
  final List<String> lords;
  final List<String> observations;
  final bool available;
  const MehtaPeriodRow(this.label, this.lords, this.observations, this.available);
}

class MehtaPeriodComparison {
  final MehtaPeriodRow vimshottari;
  final MehtaPeriodRow tribhagi;
  const MehtaPeriodComparison({required this.vimshottari,
      required this.tribhagi});
}
