import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Read-only historical BTR v5 audit. Python calculations are bundled as source
/// in tools/btr_timing_v5, NOT executed on the phone.
class BtrV5AuditScreen extends StatefulWidget {
  const BtrV5AuditScreen({super.key});
  @override
  State<BtrV5AuditScreen> createState() => _BtrV5AuditScreenState();
}
class _BtrV5AuditScreenState extends State<BtrV5AuditScreen> {
  String? report;
  String? error;
  @override
  void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    try {
      final data = await rootBundle.loadString('assets/btr_v5/BTR_19_EVENTS_BANK_INCLUDED.json');
      if (!mounted) return;
      setState(() { report = data; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = '$e'; });
    }
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('BTR + Timing v5 Audit')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('BTR పరిశోధన రిపోర్టు — గత సంఘటనల ఆధారంగా', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      const Text('ఈ రిపోర్టు ముందుగా Pythonలో గణించిన ఫలితం మాత్రమే. కొత్త జనన వివరాలతో ఫోన్‌లో ప్రత్యక్ష BTR గణన కాదు. స్కోర్లు ఖచ్చితత్వ శాతాలు కావు.'),
      const SizedBox(height: 16),
      if (error != null) SelectableText('రిపోర్టు లోడ్ కాలేదు: $error'),
      if (report == null && error == null) const CircularProgressIndicator(),
      if (report != null) SelectableText(report!, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
    ]),
  );
}
