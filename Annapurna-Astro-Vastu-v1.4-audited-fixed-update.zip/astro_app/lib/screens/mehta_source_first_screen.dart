import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/dasha_service.dart';
import '../astrology/mehta_source_first_engine.dart';
import '../models/birth_data.dart';

/// Source-first Mehta rulebook / separate contextual event inspection.
/// Prior Telugu compilation is preserved exactly as data; no automatic
/// source-verified claim is inferred from any chart or dasha coincidence.
class MehtaSourceFirstScreen extends StatefulWidget {
  final BirthData? birthData;
  final String? initialRuleId;
  final DateTime? initialEventDate;
  const MehtaSourceFirstScreen({super.key, this.birthData,
    this.initialRuleId, this.initialEventDate});

  @override
  State<MehtaSourceFirstScreen> createState() => _MehtaSourceFirstScreenState();
}

class _MehtaSourceFirstScreenState extends State<MehtaSourceFirstScreen> {
  final TextEditingController _search = TextEditingController();
  final TextEditingController _eventDate = TextEditingController();
  List<MehtaSourceEntry> _all = const [];
  MehtaSourceEntry? _selected;
  String _section = 'ALL';
  bool _loading = true;
  bool _inspecting = false;
  String? _error;
  List<MehtaHouseContext> _houseObservations = const [];
  MehtaPeriodComparison? _periodObservations;
  String? _inspectionWarning;
  bool _includeSun = false;
  int _detailStage = 0;

  @override
  void initState() {
    super.initState();
    if (widget.initialEventDate != null) {
      final d = widget.initialEventDate!;
      _eventDate.text = '${d.day.toString().padLeft(2, '0')}-'
          '${d.month.toString().padLeft(2, '0')}-${d.year}';
    }
    _search.addListener(() { if (mounted) setState(() {}); });
    _load();
  }

  Future<void> _load() async {
    try {
      final content = await rootBundle.loadString(
          'assets/mehta/mehta_311_source_first.json');
      final catalog = MehtaSourceFirstEngine.decodeRegistry(content);
      if (!mounted) return;
      setState(() {
        _all = catalog;
        _selected = widget.initialRuleId == null ? null :
          _all.where((r) => r.id == widget.initialRuleId).firstOrNull;
        if (_selected != null) _section = _selected!.section;
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() { _loading = false; _error = e.toString(); });
    }
  }

  @override
  void dispose() {
    _search.dispose(); _eventDate.dispose(); super.dispose();
  }

  String _describeGroup(Map<int, String> group) => group.entries
      .map((e) => '${e.key}వ భావం: ${e.value}').join(' • ');

  String _text(dynamic v) => v == null || v.toString().trim().isEmpty
      ? 'మూల తెలుగు సంకలనంలో సమాచారం లేదు' : v.toString();

  Widget _field(String label, dynamic value) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 3),
      SelectableText(_text(value)),
    ]),
  );

  DateTime? _readDate() {
    final match = RegExp(r'^(\d{2})-(\d{2})-(\d{4})$')
        .firstMatch(_eventDate.text.trim());
    if (match == null) return null;
    final day = int.parse(match.group(1)!);
    final month = int.parse(match.group(2)!);
    final year = int.parse(match.group(3)!);
    final date = DateTime(year, month, day, 12);
    if (date.day != day || date.month != month || date.year != year) return null;
    return date;
  }

  Future<void> _inspect() async {
    final row = _selected;
    final birth = widget.birthData;
    if (row == null || birth == null || row.section != 'EVENT') return;
    final date = _readDate();
    if (date == null || date.isBefore(birth.localDateTime) ||
        date.isAfter(DateTime.now())) {
      setState(() => _inspectionWarning =
        'గత సంఘటనకు సరైన తేదీ DD-MM-YYYYలో ఇవ్వండి; జనన తేదీ తర్వాత ఉండాలి.');
      return;
    }
    setState(() { _inspecting = true; _inspectionWarning = null;
        _houseObservations = const []; _periodObservations = null; });
    try {
      final chart = await AstroCalculationService.calculate(birth);
      final ctx = MehtaSourceFirstEngine.houseContexts(chart, row,
        includeSun: _includeSun);
      final vim = DashaService.system(kind:DashaSystemKind.vimshottari,
        chart:chart, birthDateTime:birth.localDateTime,
        calendarBasis:DashaCalendarBasis.mehtaBookGregorian);
      final trib = DashaService.system(kind:DashaSystemKind.tribhagi,
        chart:chart, birthDateTime:birth.localDateTime,
        calendarBasis:DashaCalendarBasis.mehtaBookGregorian);
      final result = MehtaSourceFirstEngine.inspectPeriods(ctx,
          DashaService.pathAt(vim, date), DashaService.pathAt(trib, date));
      if (!mounted) return;
      setState(() { _houseObservations = ctx;
          _periodObservations = result;
          if (ctx.isEmpty) _inspectionWarning =
            'ఈ నియమానికి స్వతంత్ర భావాల గణన పూర్తి కాలేదు; మూల నియమం భద్రంగా ఉంది.';
      });
    } catch (e) {
      if (mounted) setState(() => _inspectionWarning =
        'జాతక గణన అందుబాటులో లేదు: $e');
    } finally {
      if (mounted) setState(() => _inspecting = false);
    }
  }

  Widget _periodCard(MehtaPeriodRow row) => Card(
    child: Padding(padding: const EdgeInsets.all(12), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(row.label, style:const TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height:4),
      Text(row.available
          ? 'మహా → అంతర → ప్రత్యంతర → సూక్ష్మ → ప్రాణ: ${row.lords.join(" → ")}'
          : 'ఈ తేదీకి దశా కాలం అందుబాటులో లేదు'),
      const SizedBox(height: 5),
      if (row.observations.isEmpty)
        const Text('2, 3, 4 దశా స్థానాల్లో సంక్షిప్త భావాధిపతి సంబంధం కనిపించలేదు. '
            'ఇది మూల నియమం అసత్యమని నిర్ధారణ కాదు.'),
      ...row.observations.map((v) => Text('• $v')),
    ])),
  );

  Widget _detail(MehtaSourceEntry row) {
    final compilation = row.compilation;
    return Card(color: Theme.of(context).colorScheme.surfaceContainerLow,
      child: Padding(padding: const EdgeInsets.all(13),child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,children: [
        Text('${row.id} • ${row.title}',
          style: const TextStyle(fontSize:19, fontWeight:FontWeight.w900)),
        const SizedBox(height:9),
        _field('మూలగ్రంథం', row.book),
        _field('గత తెలుగు సంకలనం — ఉన్నది ఉన్నట్లుగా',
            'అసలు ఆంగ్ల గ్రంథానికి పదక్షర ప్రతిలిపి కాదు.'),
        _field('1. ఫలితం (మూల సంకలనంలో ఉన్నట్లు)',
          compilation['result'] ?? compilation['details'] ??
              'ఈ సంకలనంలో ప్రత్యేక ఫలిత పాఠం లేదు'),
        if (_detailStage >= 1) ...[
          const Divider(),
          ...compilation.entries
            .where((e) => e.key != 'id' && e.key != 'title' &&
              e.key != 'result' && e.key != 'details')
            .map((entry) => _field(entry.key, entry.value)),
        ],
        if (_detailStage < 3)
          FilledButton.tonal(
            onPressed: () => setState(() => _detailStage++),
            child: Text(switch (_detailStage) {
              0 => '2. పూర్తి రూల్ / IF / మినహాయింపులు చూడండి →',
              1 => '3. జాతక పరిశీలన చూడండి →',
              _ => '4. పరిహారం మూలస్థితి చూడండి →',
            }),
          ),
        if (_detailStage >= 3)
          _field('4. పరిహారం',
            compilation['remedy'] ??
              'ఈ నియమానికి మూలగ్రంథంలో నిర్దిష్ట పరిహారం ధృవీకరించలేదు; '
              'వేరే గ్రంథ పరిహారాన్ని ఊహించి చేర్చలేదు.'),
        const Divider(),
        _field('చూపిన మూల పేజీ సూచన', row.sourcePage),
        if (row.scanPage.isNotEmpty) _field('పరిశీలించిన స్కాన్', row.scanPage),
        _field('మూల ధృవీకరణ స్థితి', row.auditTelugu),
        if ((row.audit['finding_as_recorded']?.toString() ?? '').isNotEmpty)
          _field('ఆడిట్‌లో గుర్తించిన సందేహం / సవరణ',
            row.audit['finding_as_recorded']),
        const Text('ఈ మూల ఎంట్రీ జాతకానికి మ్యాచ్ కాకపోయినా రిజిస్టర్ నుంచి తొలగదు. '
          'గ్రంథానికి పూర్తి పదక్షర ధృవీకరణ లేనిదాన్ని “Verified”గా చూపము.',
          style: TextStyle(color:Colors.deepOrange)),
        if (_detailStage >= 2 && row.section == 'EVENT' && widget.birthData != null) ...[
          const Divider(height:28),
          const Text('సంఘటనపై స్వతంత్ర దశా పరిశీలన (Rule Verified కాదు)',
            style: TextStyle(fontWeight:FontWeight.w800)),
          const SizedBox(height:6),
          TextField(controller:_eventDate, keyboardType:TextInputType.datetime,
            decoration:const InputDecoration(labelText:'సంఘటన తేదీ (DD-MM-YYYY)',
              border:OutlineInputBorder())),
          CheckboxListTile(value:_includeSun,
            title:const Text('సూర్యలగ్నం కూడా చూడండి'),
            subtitle:const Text('వీడియోలోని అదనపు పరిశీలన; మూలగ్రంథ ధృవీకరణ కాదు'),
            onChanged:(v)=>setState(() { _includeSun = v ?? false;
              _houseObservations = const []; _periodObservations=null; })),
          FilledButton.icon(onPressed:_inspecting ? null : _inspect,
            icon:const Icon(Icons.manage_search),
            label:Text(_inspecting ? 'గణన జరుగుతోంది...' : 'భావాధిపతులు + దశలు పరిశీలించండి')),
          if (_inspectionWarning != null) Text(_inspectionWarning!,
            style: const TextStyle(color:Colors.deepOrange)),
          for (final ctx in _houseObservations) ...[
            const Divider(),
            Text(ctx.reference,style:const TextStyle(fontWeight:FontWeight.w800)),
            for (var i=0;i<ctx.groups.length;i++)
              Text('వికల్పం ${i+1}: ${_describeGroup(ctx.groups[i])}'),
          ],
          if (_periodObservations != null) ...[
            const Divider(),
            _periodCard(_periodObservations!.vimshottari),
            _periodCard(_periodObservations!.tribhagi),
            const Text('ఇవి దశా సంబంధాల పరిశీలనలు మాత్రమే. గ్రహబలం, '
              'రాహు/కేతు ప్రతినిధిత్వం, దశా Synchronization మరియు అసలు '
              'గ్రంథ మినహాయింపులు పూర్తిగా గణించకుండానే తుది ఫలితం చెప్పరాదు.',
              style: TextStyle(color:Colors.deepOrange)),
          ],
        ],
      ])));
  }

  @override
  Widget build(BuildContext context) {
    final search = _search.text.trim().toLowerCase();
    final visible = _all.where((r) => (_section == 'ALL' || r.section == _section)
      && (search.isEmpty || r.searchableText.contains(search))).toList();
    return Scaffold(
      appBar: AppBar(title:const Text('SK Mehta — మూలగ్రంథ Rule Engine')),
      body:_loading ? const Center(child:CircularProgressIndicator()) :
        _error != null ? Center(child:Text(_error!)) : ListView(
          padding:const EdgeInsets.all(14),children:[
        const Text('311 నియమాలు భద్రం • 20 సంఘటనలు • 85 కాంబినేషన్లు • '
          '206 New Dimensions. ఏ నియమమూ జాతక నాన్‌మ్యాచ్ వల్ల తొలగదు.',
          style:TextStyle(fontWeight:FontWeight.w600)),
        const SizedBox(height:9),
        const Text('అసలు గ్రంథ మూలపేజీల పూర్తి ధృవీకరణ పెండింగ్. '
          'మూల తెలుగు సంకలనాన్ని జాతక గణనతో కలపలేదు.',
          style:TextStyle(color:Colors.deepOrange,fontSize:12.5)),
        const SizedBox(height:12),
        TextField(controller:_search,
          decoration:InputDecoration(
            labelText:'సెర్చ్ — వివాహం, వ్యాపారం, గురు శని, R002',
            border:const OutlineInputBorder(),prefixIcon:const Icon(Icons.search),
            suffixIcon:IconButton(icon:const Icon(Icons.close),
              onPressed:()=>_search.clear()))),
        const SizedBox(height:8),
        DropdownButtonFormField<String>(value:_section,isExpanded:true,
          decoration:const InputDecoration(labelText:'విభాగం',
            border:OutlineInputBorder()),
          items:const [
            DropdownMenuItem(value:'ALL',child:Text('అన్నీ — 311')),
            DropdownMenuItem(value:'EVENT',child:Text('సంఘటన–భావాలు — 20')),
            DropdownMenuItem(value:'NEW_RULE',child:Text('New Combinations — 85')),
            DropdownMenuItem(value:'NEW_DIMENSION',child:Text('New Dimensions — 206')),
          ], onChanged:(s)=>setState(() { _section=s ?? 'ALL'; })),
        Padding(padding:const EdgeInsets.symmetric(vertical:9),
          child:Text('${visible.length} / ${_all.length} నియమాలు కనిపిస్తున్నాయి')),
        if (_selected != null) ...[ _detail(_selected!),
          const Divider(height:24),],
        ...visible.map((r) => Card(child:ListTile(
          title:Text('${r.id} — ${r.title}'),
          subtitle:Text('${r.book}\n${r.auditTelugu}', maxLines:2,
            overflow:TextOverflow.ellipsis),
          trailing:const Icon(Icons.chevron_right),
          onTap:()=>setState(() { _selected=r; _detailStage=0; _inspectionWarning=null;
            _houseObservations=const []; _periodObservations=null; }),
        ))),
      ]),
    );
  }
}
