#!/usr/bin/env python3
"""Annapurna v4: event-linked, progression-first diagnostics and BTR comparison.

This is an experimental astrology research program; it does NOT establish real-world
prediction accuracy. Progressions are candidate SOURCE signals, not automatic facts.
Western tropical and Indian sidereal coordinates never intermix.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime,date,time,timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
import json
import html
import math
import statistics
from collections import Counter
import engine as en
from western_progression import source_of_event

ROOT=Path(__file__).resolve().parent
HOLDOUT_IDS={'E02','E06','E09','E13','E15','E18'}  # FIXED before looking at any scores
SOURCE_VERSIONS={
  'BNN':'BNN_MAJOR_FIXED_12_YEAR_MINOR_1_YEAR_v1_no_degree_correction',
  'BSP':'BSP_SELECTED_AGE_RULES_6_8_9_10_11_13_source_verification_required',
  'BCP':'BCP_RUNNING_YEAR_MODULO_12',
  'BPD':'BPD_VAANI_7_PLANETS_SIMPLIFIED',
  'NAI':'NAISARGIKA_CLASSICAL_120',
  'YOG':'YOGINI_36_MOON_NAKSHATRA',
  'VIM':'VIMSHOTTARI_120_LAHIRI',
  'CHARA':'CHARA_EXPERIMENTAL_KN_RAO_PROFILE_NOT_TEXT_VERIFIED',
  'WEST':'WESTERN_TROPICAL_SECONDARY_SOLAR_ARC_NAIBOD',
  'KP':'KP_CUSP_STAR_SUB_ONLY_NOT_EVENT_SIGNIFICATORS'
}

def parse_case(fp):
  obj=json.loads(Path(fp).read_text(encoding='utf-8'))
  if 'birth' in obj:
    return obj['birth'],obj.get('events',[])
  return obj,[]

def validate_birth(b):
  required=('birth_date','birth_time','timezone','latitude','longitude')
  for k in required:
    if k not in b: raise ValueError('Missing birth field: '+k)
  if not (-90<float(b['latitude'])<=90 and -180<=float(b['longitude'])<=180):
    raise ValueError('Invalid coordinates')
  en.birth_datetime(b)

def prepare(b):
  validate_birth(b)
  bd=en.birth_datetime(b)
  ch=en.snapshot(b)
  return bd,ch

def western_evidence(bd,chart,day,event_code,lat,lon):
  e=en.event_info(event_code,chart)
  report=source_of_event(bd,day,float(lat),float(lon),e['relevant_planets'],event_code)
  grouped={'SECONDARY':[],'SOLAR_ARC':[],'NAIBOD_AXES':[]}
  for item in report['hits']:
    if item['method'] in grouped:
      grouped[item['method']].append(item)
  # Weights are engineering hypotheses, never classical source prescriptions.
  # Secondary Moon = week/month window. Slow progressions = broad context only.
  moon_candidates=[h for h in grouped['SECONDARY'] if h['progressed_factor']=='MOON']
  slow_candidates=[h for h in grouped['SECONDARY'] if h['progressed_factor']!='MOON']
  def affinity(items,orb_scale):
    return max((max(0.0,1.0-h['orb_degrees']/orb_scale) for h in items),default=0.0)
  moon=affinity(moon_candidates,1.0)
  slow=affinity(slow_candidates,.5)
  solar=affinity(grouped['SOLAR_ARC'],.5)
  axes=affinity(grouped['NAIBOD_AXES'],.5)
  # Broad sources cannot overwhelm daily dasha and transit clocks.
  progressive_score=round(moon*.9+slow*.25+solar*.25+axes*.2,4)
  return {'progressed_moon_tropical':report['progressed_moon_tropical'],
    'solar_arc_degrees':report['solar_arc_degrees'],
    'hits':report['hits'][:12], 'hit_count':report['total_hits'],
    'family_strengths':{'PROG_MOON':round(moon,4),'OTHER_SECONDARY':round(slow,4),
      'SOLAR_ARC':round(solar,4),'NAIBOD_ANGLES':round(axes,4)},
    'source_score':progressive_score,'role':'SOURCE_EVENT_WINDOW_NOT_CERTAINTY',
    'zodiac':'TROPICAL'}

def analyze_day(bd,chart,b,day,event_code):
  indian=en.evaluate(chart,bd,day,event_code)
  western=western_evidence(bd,chart,day,event_code,b['latitude'],b['longitude'])
  # Primary Vedic day selector and contextual evidence; Western progressions as
  # additional source-window relevance only. Original weights are not probabilities.
  combined=round(indian['score']+western['source_score'],4)
  return {'date':day.isoformat(),'event_type':event_code,'event_te':indian['event_te'],
    'event_source':{'vedic_rules':indian['evidence'],'western':western,
      'rule_sources':SOURCE_VERSIONS},
    'dasha':{'vimshottari':indian['vimsottari'], 'yogini':indian['yogini'],
      'chara':indian['chara']},
    'context':{'bnn':indian['bnn'],'bcp':indian['bcp'],
      'bsp':indian['bsp'],'bpd':indian['bpd'],'naisargika':indian['naisargika']},
    'scores':{'vedic_comparison':indian['score'],
      'western_source_window':western['source_score'],'total_heuristic':combined},
    'score_type':'UNVALIDATED_HEURISTIC_NOT_PROBABILITY'}

def explain_window(daily):
  ranked=sorted(daily,key=lambda v:(-v['scores']['total_heuristic'],v['date']))
  maximum=ranked[0]['scores']['total_heuristic']
  # A score plateau is a window; report all near-leading days, no fabricated precision.
  plateau=sorted(date.fromisoformat(x['date']) for x in daily
       if x['scores']['total_heuristic']>=maximum-.15)
  runs=[];a=z=plateau[0]
  for x in plateau[1:]:
    if (x-z).days==1:z=x
    else:
      runs.append({'from':a.isoformat(),'to':z.isoformat(),'days':(z-a).days+1});a=z=x
  runs.append({'from':a.isoformat(),'to':z.isoformat(),'days':(z-a).days+1})
  peak=ranked[0]['date']
  primary=next((x for x in runs if x['from']<=peak<=x['to']),runs[0])
  return {'peak_date_for_navigation_only':peak,
          'maximum_score':maximum,'near_peak_days':len(plateau),
          'near_peak_first':plateau[0].isoformat(),
          'near_peak_last':plateau[-1].isoformat(),
          'primary_near_peak_window':primary,'other_near_peak_windows':[x for x in runs if x is not primary],
          'unique_day_claim_supported':False,
          'comment':'These are separate calendar windows; do not imply events between them are equally supported.'}

def time_event(b,event_code,start,end,top=10):
  bd,ch=prepare(b)
  if event_code not in en.EVENTS: raise ValueError('Unsupported event type: '+event_code)
  start=date.fromisoformat(start);end=date.fromisoformat(end)
  if start<bd.date() or end<start or (end-start).days>370:
    raise ValueError('Date range must be after birth, ascending, and <= 371 days')
  daily=[]
  d=start
  while d<=end:
    daily.append(analyze_day(bd,ch,b,d,event_code));d+=timedelta(days=1)
  # Phase 1: progression windows. Only use this as a filter when the
  # progression score varies substantially; slow Solar Arc cannot choose a day.
  prog=[v['scores']['western_source_window'] for v in daily]
  span=max(prog)-min(prog)
  if len(daily)>=20 and span>=.20:
    threshold=sorted(prog)[int(.60*(len(prog)-1))]
    accepted=[v for v in daily if v['scores']['western_source_window']>=threshold]
    gate={'status':'INFORMATIVE_RESEARCH_WINDOW','score_span':round(span,4),
          'threshold':threshold,'eligible_days':len(accepted),
          'caveat':'Unvalidated window selection threshold; not a prediction guarantee.'}
  else:
    accepted=daily[:]
    gate={'status':'BROAD_OR_FLAT_NO_DATE_DISCRIMINATION','score_span':round(span,4),
          'eligible_days':len(accepted),
          'caveat':'Progression too flat over range to isolate days.'}
  ordered=sorted(accepted,key=lambda v:(-v['scores']['total_heuristic'],v['date']))
  return {'kind':'TIMING_OF_EVENT','birth':b,'event':event_code,
    'range':[start.isoformat(),end.isoformat()],
    'window':explain_window(accepted),'progression_gate':gate,'top_days':ordered[:top],
    'daily_scores':[{'date':z['date'],**z['scores']} for z in daily],
    'status':'EXPERIMENTAL_NOT_VALIDATED',
    'notes':['Source of Event signals are not independent probabilities.',
      'Progressions give broad timing windows; exact date is not guaranteed.',
      'User requested date precision only; no event clock time is inferred.']}

def split_events(events):
  # Exactly 12/6 for the supplied 18 events; assignment frozen by ID,
  # never selected based on favorable historical birth-time claims.
  calibration=[x for x in events if x.get('id') not in HOLDOUT_IDS]
  holdout=[x for x in events if x.get('id') in HOLDOUT_IDS]
  return calibration,holdout

def candidate_event_score(bd,chart,b,ev):
  typ=ev['event_type']
  if typ not in en.EVENTS:
    return {'id':ev['id'],'date':ev['date'],'type':typ,'status':'NOT_MODELED',
      'reason':'No validated source-of-event mapping for relationship/health type.'}
  day=date.fromisoformat(ev['date'])
  r=analyze_day(bd,chart,b,day,typ)
  # Birth-time-varying signals can discriminate candidates; age-only BCP/BNN
  # are used to explain event source but not double counted in BTR score.
  f=r['scores']; d=r['dasha']
  # Primary Vedic timing is still a hypothesis, western source a diagnostic.
  # Grouped by family, no multiplicative score per aspect.
  ws=r['event_source']['western']['family_strengths']
  return {'id':ev['id'],'date':ev['date'],'type':typ,'status':'SCORED',
    'western':ws,'western_source':f['western_source_window'],
    'vedic':f['vedic_comparison'],'total':f['total_heuristic'],
    'yogini':d['yogini']['maha']+'/'+d['yogini']['antar'],
    'vim':d['vimshottari']['maha']+'/'+d['vimshottari']['antar'],
    'chara_experimental':d['chara']['maha_name']+'/'+d['chara']['antar_name'],
    'evidence':[{'method':h['method'],'from':h['progressed_factor'],
      'to':h['natal_factor'],'aspect':h['aspect'],'orb':h['orb_degrees']}
      for h in r['event_source']['western']['hits'][:3]]}

def varga_sign(lon,n):
  si=int(lon//30);part=min(n-1,int((lon%30)/(30/n)))
  if n==9:
    if si in (0,3,6,9):begin=si
    elif si in (1,4,7,10):begin=(si+8)%12
    else:begin=(si+4)%12
    return (begin+part)%12
  if n==10:
    return ((si if si%2==0 else (si+8)%12)+part)%12
  raise ValueError('Unsupported varga: '+str(n))

def btr_case(case_file,start='15:00:00',end='16:11:00',step_minutes=3):
  birth,events=parse_case(case_file)
  validate_birth(birth)
  if not events:raise ValueError('No historical events supplied')
  cal,holdout=split_events(events)
  bday=date.fromisoformat(birth['birth_date'])
  t0=datetime.fromisoformat(birth['birth_date']+'T'+start)
  t1=datetime.fromisoformat(birth['birth_date']+'T'+end)
  if step_minutes<1 or step_minutes>60 or t1<t0 or (t1-t0).total_seconds()>4*3600:
    raise ValueError('Invalid candidate time search')
  candidates=[];t=t0
  while t<=t1:
    b={**birth,'birth_time':t.strftime('%H:%M:%S')}
    bd,ch=prepare(b)
    cal_r=[candidate_event_score(bd,ch,b,e) for e in cal]
    hol_r=[candidate_event_score(bd,ch,b,e) for e in holdout]
    kp=en.kp_cusps(bd,b['latitude'],b['longitude'])
    cand={'time':b['birth_time'],'lagna':en.SIGNS_TE[en.sign(ch['LAGNA'])],
      'asc_sidereal_deg':round(ch['LAGNA'],5),
      'D9_lagna':en.SIGNS_TE[varga_sign(ch['LAGNA'],9)],
      'D10_lagna':en.SIGNS_TE[varga_sign(ch['LAGNA'],10)],
      'KP_asc_star':kp[1]['star'],'KP_asc_sub':kp[1]['sub'],
      'calibration_events':cal_r,'holdout_events':hol_r}
    candidates.append(cand)
    t+=timedelta(minutes=step_minutes)
  # Only components genuinely varying across candidate birth times can be
  # used to rank candidates. No use of PDF favored-time labels.
  usable_ids=[e['id'] for e in cal if e['event_type'] in en.EVENTS]
  varying=[]
  for eid in usable_ids:
    score_set={round(next(x['total'] for x in c['calibration_events'] if x['id']==eid),4)
               for c in candidates}
    if len(score_set)>1:varying.append(eid)
  for c in candidates:
    scores=[x['total'] for x in c['calibration_events'] if x['id'] in varying]
    c['calibration_comparison_score']=round(sum(scores)/len(scores),4) if scores else None
    # HOLDOUT diagnostic calculated AFTER ranking, never used to choose winners.
    c['holdout_diagnostic_mean']=round(statistics.mean(x['total'] for x in c['holdout_events'] if x['status']=='SCORED'),4) if any(x['status']=='SCORED' for x in c['holdout_events']) else None
  if varying:
    sorted_c=sorted(candidates,key=lambda c:(-c['calibration_comparison_score'],c['time']))
    best=sorted_c[0]['calibration_comparison_score']
    tied=[c['time'] for c in sorted_c if abs(c['calibration_comparison_score']-best)<1e-6]
  else:
    sorted_c=candidates[:]
    tied=[c['time'] for c in candidates]
  # Holdout is never used to rank candidates; summarize only after selection.
  leading_holdout=sorted_c[0]['holdout_diagnostic_mean']
  holdout_values=[c['holdout_diagnostic_mean'] for c in candidates if c['holdout_diagnostic_mean'] is not None]
  reserved_check={'leading_candidate_holdout_score':leading_holdout,
    'all_candidate_holdout_median':round(statistics.median(holdout_values),4) if holdout_values else None,
    'meaning':'Descriptive agreement only, not validated prediction accuracy. All dates from unverified PDF.'}
  return {'kind':'BTR_COMPARATIVE_AUDIT','source':'PDF 18 EVENT TRANSCRIPTION - NOT INDEPENDENTLY VERIFIED',
    'birth':birth,'candidate_count':len(candidates),'candidate_step_minutes':step_minutes,
    'calibration_ids':[e['id'] for e in cal],
    'holdout_ids':[e['id'] for e in holdout],
    'modeled_calibration_ids':usable_ids,
    'discriminating_calibration_event_ids':varying,
    'excluded_events':[{'id':e['id'],'type':e['event_type']} for e in events if e['event_type'] not in en.EVENTS],
    'candidate_ranking':[{k:v for k,v in c.items() if k not in ('calibration_events','holdout_events')}
          for c in sorted_c],
    'leading_candidate_details':sorted_c[0],
    'reserved_check':reserved_check,
    'tied_best_times':tied,
    'status':'NOT_RECTIFIED' if not varying else 'HYPOTHESIS_COMPARISON_ONLY',
    'warning':'Events transcribed from PDF, not independently date-verified. Score is not event probability. Chara algorithm variant requires source verification; holdout not used to choose candidate. No true birth time established.',
    'method':'Fixed 12/6 holdout split, progression contacts added as source-window score. Source associations may vary with birth time, not independent calibration.'}

def esc(v):return html.escape(str(v),quote=True)

def render_timing_html(r):
  rows=''.join('<tr><td>'+esc(x['date'])+'</td><td>'+esc(x['scores']['total_heuristic'])+'</td><td>'+esc(x['scores']['vedic_comparison'])+'</td><td>'+esc(x['scores']['western_source_window'])+'</td><td><details><summary>గ్రహాలు / రూల్స్</summary><pre>'+esc(json.dumps({'western':x['event_source']['western']['hits'][:6],'ved_rules':x['event_source']['vedic_rules'][:8], 'dasha':x['dasha']},ensure_ascii=False,indent=2))+'</pre></details></td></tr>' for x in r['top_days'])
  w=r['window']
  return html_shell('Timing of Event',f'''<section><h2>సంఘటన కాలపరిశీలన — {esc(en.EVENTS[r['event']]['te'])}</h2><p class="warn">నిజమైన సంఘటన జరిగే తేదీ ధృవీకరణ కాదు. గణనల అనుకూలత ఆధారంగా తేదీలను క్రమబద్ధీకరిస్తుంది.</p><div class="stats"><span><b>{esc(w['peak_date_for_navigation_only'])}</b><small>అత్యధిక అంతర్గత స్కోరు ఉన్న రోజు</small></span><span><b>{esc(w['near_peak_days'])}</b><small>సమీప స్కోరు ఉన్న రోజులు</small></span></div><p><strong>ప్రధాన పరిశీలన పరిధి:</strong> {esc(w['primary_near_peak_window']['from'])} — {esc(w['primary_near_peak_window']['to'])}</p><p><strong>ఇతర విడి పరిధులు:</strong> {esc(', '.join(x['from']+' – '+x['to'] for x in w['other_near_peak_windows']) or 'లేవు')}</p></section><section><h2>రోజుల పోలిక</h2><div class="scroll"><table><tr><th>తేదీ</th><th>మొత్తం</th><th>భారతీయ</th><th>Progression</th><th>Source Evidence</th></tr>{rows}</table></div></section>''')

def render_btr_html(r):
  rows=''.join('<tr><td>'+esc(c['time'])+'</td><td>'+esc(c['lagna'])+'</td><td>'+esc(c['calibration_comparison_score'])+'</td><td>'+esc(c['holdout_diagnostic_mean'])+'</td></tr>' for c in r['candidate_ranking'])
  excluded=' '.join(esc(x['id']+': '+x['type']) for x in r['excluded_events'])
  return html_shell('BTR Research Audit',f'''<section><h2>BTR — 18 గత సంఘటనల పరీక్ష</h2><p class="warn">తుది జనన సమయం నిర్ధారించలేదు. PDFలోని సంఘటన తేదీలకు స్వతంత్ర ఆధారాలు లేవు. స్కోర్లు పరిశోధనాత్మక పోలికలు మాత్రమే.</p><div class="stats"><span><b>{r['candidate_count']}</b><small>అభ్యర్థి సమయాలు</small></span><span><b>{len(r['calibration_ids'])} + {len(r['holdout_ids'])}</b><small>Calibration + Holdout</small></span><span><b>{len(r['discriminating_calibration_event_ids'])}</b><small>భేదక సంఘటనలు</small></span></div><p><strong>Calibration:</strong> {esc(', '.join(r['calibration_ids']))}<br><strong>Holdout:</strong> {esc(', '.join(r['holdout_ids']))}</p><p><strong>స్పష్టమైన ఈవెంట్ మ్యాపింగ్ లేనివి:</strong> {excluded}</p></section><section><h2>Candidate Time Comparison</h2><p>Calibration స్కోర్ ఆధారంగా మాత్రమే క్రమం; Holdout ఎంచుకోవడానికి ఉపయోగించలేదు. Holdout గణనలు కూడా నిజమైన ధృవీకరణ కాదు.</p><div class="scroll"><table><tr><th>జనన సమయం</th><th>లగ్నం</th><th>Calibration స్కోర్</th><th>Holdout పరీక్ష స్కోర్</th></tr>{rows}</table></div></section><section><h2>విధాన పరిమితులు</h2><p>BNN/BCP వయస్సు నియమాలు జనన సమయాన్ని తేడా చూపించకపోవచ్చు. KP పూర్తి Event Significator గణన ఇంకా జత చేయలేదు. చర దశ ఒక ప్రయోగాత్మక ప్రొఫైల్ మాత్రమే.</p></section>''')

def html_shell(title,content):
  return f'''<!doctype html><html lang="te"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{esc(title)}</title><style>
:root{{color-scheme:light}}body{{margin:0 auto;padding:16px;max-width:1080px;background:#f3f6fa;color:#172b45;font-family:system-ui,'Noto Sans Telugu',sans-serif;line-height:1.65}}h1{{font-size:1.38rem}}h2{{font-size:1.1rem}}header,section{{background:white;border:1px solid #dbe3ed;border-radius:16px;padding:18px;margin:14px 0}}header{{background:#142c48;color:white}}header small{{color:#ccd9ec}}.warn{{background:#fff3e5;border-left:4px solid #c97c18;padding:12px;border-radius:7px}}.scroll{{overflow-x:auto}}table{{border-collapse:collapse;width:100%;font-size:.85rem}}th,td{{padding:10px;border-bottom:1px solid #e6edf5;text-align:left;vertical-align:top;white-space:nowrap}}th{{background:#eaf1fa}}.stats{{display:flex;flex-wrap:wrap;gap:12px}}.stats>span{{background:#f2f6fb;min-width:118px;flex:1;padding:12px;border-radius:10px}}.stats b{{font-size:1.25rem;display:block}}.stats small{{color:#526879;display:block}}pre{{white-space:pre-wrap;min-width:290px;max-width:550px;font-size:12px;word-break:break-word}}summary{{cursor:pointer;color:#0b549a}}a{{color:#0a5790}}</style></head><body><header><h1>Annapurna Astro Vastu</h1><small>{esc(title)} • Source of Event → Progression → Day-level Comparison → BTR</small></header>{content}<section><small>Astrological interpretation is not scientifically validated as an event prediction method. Experimental model scores are not probabilities or proof of birth time.</small></section></body></html>'''

def write_report(out,r):
  out=Path(out);out.parent.mkdir(parents=True,exist_ok=True)
  out.with_suffix('.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
  out.with_suffix('.html').write_text(render_timing_html(r) if r['kind']=='TIMING_OF_EVENT' else render_btr_html(r),encoding='utf8')
  return out.with_suffix('.html')

def main():
  ap=argparse.ArgumentParser(description='Annapurna Astro Vastu progression-first day/BTR')
  ap.add_argument('--case',required=True)
  ap.add_argument('--mode',choices=['timing','btr'],required=True)
  ap.add_argument('--event',choices=sorted(en.EVENTS),default='PROPERTY')
  ap.add_argument('--from-date',default='2026-10-01')
  ap.add_argument('--to-date',default='2026-12-31')
  ap.add_argument('--start-time',default='15:00:00')
  ap.add_argument('--end-time',default='16:11:00')
  ap.add_argument('--step-minutes',type=int,default=3)
  ap.add_argument('--out',default=str(ROOT/'reports'/'latest'))
  args=ap.parse_args()
  if args.mode=='timing':
    birth,_=parse_case(args.case)
    output=time_event(birth,args.event,args.from_date,args.to_date)
  else:
    output=btr_case(args.case,args.start_time,args.end_time,args.step_minutes)
  print(write_report(args.out,output))

if __name__=='__main__':main()
