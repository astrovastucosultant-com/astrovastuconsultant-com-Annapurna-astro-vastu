"""Transparent profession-source BTR comparison, not a birth-time verdict."""
import json, html, argparse
from pathlib import Path
import engine as en

PROFESSIONS={
 'ASTROLOGY':{'te':'జ్యోతిష్య సలహాలు','houses':[2,5,8,9,10,11],'karakas':['JUPITER','MERCURY','KETU','SATURN']},
 'VASTU':{'te':'వాస్తు కన్సల్టెన్సీ','houses':[2,4,5,9,10,11],'karakas':['MARS','MERCURY','JUPITER','SATURN']},
}
# Karaka mapping is an explicitly provisional working hypothesis, not a classical quotation.
def d_sign(lon,division):
    s=en.sign(lon); within=(lon%30); part=min(division-1,int(within/(30/division)))
    if division==9:
        start=[0,9,6,3][s%4] # movable, fixed, dual sequence by sign modality
        # corrected modality: Aries movable, Taurus fixed, Gemini dual
        start=[s,(s+8)%12,(s+4)%12][s%3]
        return (start+part)%12
    if division==10:
        start=s if s%2==0 else (s+8)%12
        return (start+part)%12
    raise ValueError('D9/D10 only')

def inspect(b,time):
    b=dict(b,birth_time=time); ch=en.snapshot(b); lag=en.sign(ch['LAGNA']); out={'birth_time':time,'lagna':en.SIGNS_TE[lag], 'asc_degree':round(ch['LAGNA']%30,5), 'D9_lagna':en.SIGNS_TE[d_sign(ch['LAGNA'],9)],'D10_lagna':en.SIGNS_TE[d_sign(ch['LAGNA'],10)], 'profession':{}}
    for code,spec in PROFESSIONS.items():
        signs={(lag+h-1)%12 for h in spec['houses']}
        lords={en.LORDS[s] for s in signs}
        occupants={p:[h for h in spec['houses'] if en.sign(lon)==(lag+h-1)%12] for p,lon in ch.items() if p!='LAGNA' and p!='KETU'}
        occupants={k:v for k,v in occupants.items() if v}
        out['profession'][code]={'name':spec['te'],'house_lords':sorted(lords),'occupants_of_relevant_houses':occupants,'karakas_to_review':spec['karakas'],'D10_tenth_sign':en.SIGNS_TE[(d_sign(ch['LAGNA'],10)+9)%12], 'D10_tenth_lord':en.LORDS[(d_sign(ch['LAGNA'],10)+9)%12], 'status':'REQUIRES_SOURCE_RULE_VERIFICATION', 'score':None}
    return out

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--case',default=str(Path(__file__).parent/'18_events_input.json'));ap.add_argument('--out',default=str(Path(__file__).parent/'reports/PROFESSION_BTR_1521_1535_1600'));a=ap.parse_args()
    b=json.loads(Path(a.case).read_text())['birth']; rows=[inspect(b,t) for t in ['15:21:00','15:35:00','16:00:00']]
    data={'kind':'PROFESSION_BTR_AUDIT','birth':b,'cases':rows,'status':'NO_VERDICT','notes':['జ్యోతిష్యం/వాస్తు వృత్తి స్వీయ సమాచారం; వృత్తి ప్రారంభ తేదీ ఇంకా నమోదు కాలేదు.','పూర్తి D10 181 గ్రంథ నియమాలు ఈ నమూనాలో లేవు; వాటిని పరీక్షించామని చెప్పలేము.','D1/D9/D10 స్థానాల పోలిక మాత్రమే; 15:21 సరైనదని లేదా 15:35 తప్పని నిరూపించదు.','ఈ వృత్తి సమాచారం 18 PDF సంఘటనల్లో లేదు; దీన్ని కొత్త స్వతంత్ర BTR పరీక్షగా ఉంచాలి.']}
    path=Path(a.out);path.parent.mkdir(parents=True,exist_ok=True);path.with_suffix('.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    trs=''.join('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in [r['birth_time'],r['lagna'],r['D9_lagna'],r['D10_lagna'],r['profession']['ASTROLOGY']['D10_tenth_lord'],r['profession']['VASTU']['D10_tenth_lord']])+'</tr>' for r in rows)
    details=''.join('<details><summary>'+r['birth_time']+' — వృత్తి మూలాలు</summary><pre>'+html.escape(json.dumps(r['profession'],ensure_ascii=False,indent=2))+'</pre></details>' for r in rows)
    page='''<!doctype html><html lang="te"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Profession BTR Audit</title><style>body{font-family:system-ui,'Noto Sans Telugu',sans-serif;max-width:960px;margin:auto;padding:20px;line-height:1.7;color:#1c3047;background:#f4f7fa}section{background:white;border-radius:12px;padding:18px;margin:14px 0}table{width:100%;border-collapse:collapse;display:block;overflow-x:auto}td,th{border-bottom:1px solid #ddd;padding:10px;text-align:left;white-space:nowrap}pre{white-space:pre-wrap;overflow-wrap:anywhere}summary{cursor:pointer}h1{font-size:1.4rem}</style><section><h1>జ్యోతిష్యం + వాస్తు — BTR వృత్తి ఆడిట్</h1><p>15:21 / 15:35 / 16:00: D1, D9, D10 లగ్నాలు మరియు D10 పదవ భావాధిపతి పోలిక. ఇది మూలగ్రంథ రూల్స్ ధృవీకరణ కాదు.</p><table><tr><th>సమయం</th><th>D1 లగ్నం</th><th>D9 లగ్నం</th><th>D10 లగ్నం</th><th>D10 10వ అధిపతి</th><th>వాస్తు</th></tr>'''+trs+'</table></section><section><h2>Source of Event వివరాలు</h2>'+details+'</section><section><h2>తీర్పు</h2><p><b>ఇప్పుడే తుది జనన సమయం నిర్ణయించలేదు.</b> పూర్తి D10 181 నియమాలు, KP వృత్తి సూచనలు, వృత్తి ప్రారంభ సంఘటన తేదీ లేకుండా 15:21/15:35ను వేరుచేయడం సాధ్యం కాదు.</p></section></html>'
    path.with_suffix('.html').write_text(page,encoding='utf8');print(path.with_suffix('.html'))
if __name__=='__main__':main()
