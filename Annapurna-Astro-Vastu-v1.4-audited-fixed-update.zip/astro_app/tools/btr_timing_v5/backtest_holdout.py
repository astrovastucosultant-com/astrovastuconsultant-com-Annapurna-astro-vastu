"""Month-conditioned holdout DAY RANK diagnostic. Does not train or set weights.

Do not label top-N month-conditioned rank as evidence of verified forecasting;
source dates are PDF assertions and chosen month is disclosed (not forecast).
"""
import calendar,json
from datetime import date
from pathlib import Path
from progression_first import parse_case,split_events,time_event,ROOT, en

def run(file, candidate_birth_time, output_file):
  birth, events=parse_case(file)
  _,holdout=split_events(events)
  birth={**birth,'birth_time':candidate_birth_time}
  records=[]
  for ev in holdout:
    if ev['event_type'] not in en.EVENTS:
      records.append({'id':ev['id'],'status':'NOT_MODELED'});continue
    y,m,d=map(int,ev['date'].split('-'))
    start=f'{y:04d}-{m:02d}-01'
    end=f'{y:04d}-{m:02d}-{calendar.monthrange(y,m)[1]:02d}'
    r=time_event(birth,ev['event_type'],start,end,top=31)
    ranked=sorted(r['daily_scores'], key=lambda z:(-z['total_heuristic'],z['date']))
    rank=next(i+1 for i,x in enumerate(ranked) if x['date']==ev['date'])
    records.append({'id':ev['id'],'date':ev['date'],'type':ev['event_type'],
      'event_description':ev['description_te'],'birth_time':candidate_birth_time,
      'event_day_rank_in_known_month':rank,'days_in_month':len(ranked),
      'within_top3':rank<=3,'within_top5':rank<=5,
      'month_conditional':True,'verified_date':ev.get('date_verified','NOT_VERIFIED')})
  count=len([r for r in records if 'event_day_rank_in_known_month' in r])
  result={'birth_time':candidate_birth_time,'status':'EXPLORATORY_MONTH_CONDITIONED_NOT_FORECAST_ACCURACY',
    'dates_verified_independently':False,'holdout_ids':[e['id'] for e in holdout],
    'modeled':count,'top3_month_ranks':sum(bool(x.get('within_top3')) for x in records),
    'top5_month_ranks':sum(bool(x.get('within_top5')) for x in records),
    'records':records,
    'warning':'Month selected using recorded event month, which is information unavailable in real forward prediction. Counts are not generalizable predictive accuracy.'}
  Path(output_file).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
  return result

if __name__=='__main__':
  case=ROOT/'18_events_input.json'
  for t in ('15:21:00','15:35:00','16:00:00'):
    result=run(case,t,ROOT/'reports'/('HOLDOUT_'+t.replace(':','')+'.json'))
    print(t,'top 3 in month',result['top3_month_ranks'],'/',result['modeled'],'top5',result['top5_month_ranks'])
