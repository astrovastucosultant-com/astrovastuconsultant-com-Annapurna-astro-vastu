import json
from datetime import date
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import progression_first as f
import engine as en
CASE=Path(__file__).resolve().parents[1]/'18_events_input.json'
BIRTH,EVENTS=f.parse_case(CASE)

def test_pdf_case_18_and_12_6_frozen():
 assert len(EVENTS)==18
 a,b=f.split_events(EVENTS)
 assert len(a)==12 and len(b)==6
 assert set(x['id'] for x in b)==f.HOLDOUT_IDS

def test_immutable_report_source_and_no_pdf_label_training():
 a=f.btr_case(CASE,'15:21:00','15:27:00',3)
 assert 'pdf_label' not in str(a['candidate_ranking'])
 assert a['candidate_count']==3
 assert a['leading_candidate_details']['D9_lagna']
 assert a['leading_candidate_details']['KP_asc_sub']
 assert a['reserved_check']['meaning'].startswith('Descriptive')

def test_unmapped_event_abstains():
 bd,ch=f.prepare(BIRTH)
 x=f.candidate_event_score(bd,ch,BIRTH,EVENTS[0])
 assert x['status']=='NOT_MODELED'

def test_progression_tropical_separate():
 bd,ch=f.prepare(BIRTH)
 r=f.analyze_day(bd,ch,BIRTH,date(2026,10,14),'FINANCIAL_CHANGE')
 assert r['event_source']['western']['zodiac']=='TROPICAL'
 assert r['score_type']=='UNVALIDATED_HEURISTIC_NOT_PROBABILITY'
 assert 'chara' in r['dasha'] and 'yogini' in r['dasha']

def test_timing_day_and_window_no_false_certainty():
 r=f.time_event(BIRTH,'FINANCIAL_CHANGE','2026-10-13','2026-10-16')
 assert len(r['daily_scores'])==4
 assert r['window']['unique_day_claim_supported'] is False
 assert r['progression_gate']['status']=='BROAD_OR_FLAT_NO_DATE_DISCRIMINATION'
 assert r['top_days'][0]['date'] in ['2026-10-13','2026-10-14','2026-10-15','2026-10-16']

def test_html_and_json_safe_local():
 r=f.time_event(BIRTH,'PROPERTY','2026-10-14','2026-10-15')
 html=f.render_timing_html(r)
 assert '<!doctype html>' in html
 assert 'Progression' in html
 assert '<section>' in html

def test_d9_asc_range():
 bd,ch=f.prepare(BIRTH)
 assert en.SIGNS_TE[f.varga_sign(ch['LAGNA'],9)]=='వృశ్చికం'
 assert en.SIGNS_TE[f.varga_sign(ch['MOON'],9)]=='కుంభం'

