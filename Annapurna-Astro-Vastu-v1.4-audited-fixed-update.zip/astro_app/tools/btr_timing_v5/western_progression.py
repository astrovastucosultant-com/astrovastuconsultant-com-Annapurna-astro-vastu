"""Western event-source diagnostics (tropical secondary progressions + solar arc).

Experimental comparative signals only. Not independently validated predictive dates.
No scoring / selection performed here. Requires pyswisseph.
Uses tropical zodiac, Placidus houses and Naibod-key directed angles;
these settings must never be conflated with Lahiri sidereal Vedic houses.
"""
from __future__ import annotations
from datetime import datetime, date, time, timedelta, timezone
import swisseph as swe

SOURCE='https://www.astro.com/astrowiki/en/Secondary_Directions'
SOLAR_SOURCE='https://www.astro.com/astrowiki/en/Solar_Arc_Direction'
RECTIFICATION_SOURCE='https://www.astro.com/astrowiki/en/Chart_Rectification'
PLANETS={'SUN':swe.SUN,'MOON':swe.MOON,'MERCURY':swe.MERCURY,
         'VENUS':swe.VENUS,'MARS':swe.MARS,'JUPITER':swe.JUPITER,'SATURN':swe.SATURN}
ASPECTS={'CONJUNCTION':0,'SEXTILE':60,'SQUARE':90,'TRINE':120,'OPPOSITION':180}
YEAR_DAYS=365.2421904
NAIBOD_KEY=0.98564733


def jd(dt):
    u=dt.astimezone(timezone.utc)
    return swe.julday(u.year,u.month,u.day,u.hour+u.minute/60+u.second/3600+u.microsecond/3600000000)


def tropical_sky(dt, latitude, longitude):
    t=jd(dt)
    flags=swe.FLG_MOSEPH  # No sidereal flag (Western tropical zodiac).
    p={n:swe.calc_ut(t,code,flags)[0][0]%360 for n,code in PLANETS.items()}
    cusps, axes=swe.houses_ex(t, latitude, longitude, b'P', 0)
    return p, cusps, axes


def aspect_hits(source_points, target_points, max_orbs, source_method):
    hits=[]
    for src, slon in source_points.items():
        orb_allowed=max_orbs[src] if isinstance(max_orbs,dict) else max_orbs
        for dest, dlon in target_points.items():
            if src==dest and source_method=='SECONDARY':
                # Same-body progressed-to-natal conjunctions aren't a daily trigger.
                continue
            arc=abs((slon-dlon+180)%360-180)
            for aspect,degrees in ASPECTS.items():
                error=abs(arc-degrees)
                if error <=orb_allowed:
                    hits.append({'method':source_method,'progressed_factor':src,
                                 'natal_factor':dest,'aspect':aspect,
                                 'orb_degrees':round(error,5),
                                 'progressed_longitude_tropical':round(slon,5),
                                 'target_longitude_tropical':round(dlon,5)})
    hits.sort(key=lambda h:h['orb_degrees'])
    return hits


def source_of_event(birth_dt, event_day:date, latitude:float,longitude:float,
                    relevant_planets, event_code):
    """Return explainable Western contacts only; does not calculate event dates.

    Moon's ~1°/month progression and solar arcs are too coarse for definitive day
    selection. Directed/secondary axes are birth-time sensitive and model-dependent.
    """
    if birth_dt.tzinfo is None:raise ValueError('Timezone-aware birth timestamp required')
    event_dt=datetime.combine(event_day,time(12,0),birth_dt.tzinfo)
    age=(event_dt-birth_dt).total_seconds()/86400/YEAR_DAYS
    if age<0:raise ValueError('Event cannot precede birth')
    symbolic_dt=birth_dt+timedelta(days=age)
    natal, natal_cusps, natal_axes=tropical_sky(birth_dt,latitude,longitude)
    progressed,_,_=tropical_sky(symbolic_dt,latitude,longitude)
    event_angles={'MARRIAGE':{'DESC':(natal_axes[0]+180)%360},
      'CAREER_START':{'MC':natal_axes[1]},'PROMOTION':{'MC':natal_axes[1]},
      'BUSINESS_START':{'MC':natal_axes[1]},'JOB_CHANGE':{'MC':natal_axes[1]},
      'PROPERTY':{'IC':(natal_axes[1]+180)%360},
      'CHILD_BIRTH':{'FIFTH_CUSP':natal_cusps[4]},
      'EDUCATION':{'NINTH_CUSP':natal_cusps[8]},
      'FOREIGN_TRAVEL':{'NINTH_CUSP':natal_cusps[8]}}.get(event_code,{})
    targets={n:natal[n] for n in relevant_planets if n in natal}
    targets.update(event_angles)
    # Separate secondary progression from equal-arc directing; both in tropical longitudes.
    sec_factors={k:progressed[k] for k in ('SUN','MOON','MERCURY','VENUS','MARS')}
    sec_orbs={'MOON':1.0,'SUN':0.5,'MERCURY':0.5,'VENUS':0.5,'MARS':0.5}
    secondary_hits=aspect_hits(sec_factors,targets,sec_orbs,'SECONDARY')
    solar_arc=(progressed['SUN']-natal['SUN'])%360
    directed={n:(v+solar_arc)%360 for n,v in natal.items()}
    directed['ASC']=(natal_axes[0]+solar_arc)%360
    directed['MC']=(natal_axes[1]+solar_arc)%360
    sa_hits=aspect_hits(directed,targets,0.5,'SOLAR_ARC')
    # Naibod progressed axes. MC/Asc calculated from advanced sidereal time.
    eps=swe.calc_ut(jd(symbolic_dt),swe.ECL_NUT,swe.FLG_MOSEPH)[0][0]
    armc=(natal_axes[2]+NAIBOD_KEY*age)%360
    _, progressed_axes=swe.houses_armc(armc,latitude,eps,b'P')
    axes_hits=aspect_hits({'P_ASC':progressed_axes[0], 'P_MC':progressed_axes[1]},
                          targets,0.5,'NAIBOD_AXES')
    hits=sorted(secondary_hits+sa_hits+axes_hits,key=lambda h:h['orb_degrees'])
    return {'status':'SOURCE_ONLY_NOT_USED_TO_RANK',
       'event_date':event_day.isoformat(), 'age_years':round(age,5),
       'symbolic_ephemeris_date':symbolic_dt.isoformat(),
       'zodiac':'TROPICAL','houses':'PLACIDUS',
       'axis_key':'NAIBOD_ARMC_ADVANCE_0.98564733_DEGREES_PER_YEAR',
       'solar_arc_degrees':round(solar_arc,5),
       'progressed_moon_tropical':round(progressed['MOON'],5),
       'hits':hits[:35],'total_hits':len(hits),
       'sources':[SOURCE,SOLAR_SOURCE,RECTIFICATION_SOURCE],
       'cautions':['Contacts are hypothesis-generating, not proof of an event/date.',
        'Progressed Moon contacts often describe multi-week/month windows.',
        'Angle direction depends on assumed exact birth time and chosen direction key.',
        'Western tropical and Indian sidereal sign indices must not be mixed.',
        'This evidence is excluded from Timing/BTR ranking until independently calibrated.']}
