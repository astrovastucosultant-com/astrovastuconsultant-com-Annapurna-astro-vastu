# అన్నపూర్ణ Astro Vastu — Progression First Engine v4

**స్థితి:** పనిచేసే Python గణన నమూనా + మొబైల్‌లో ఓపెన్ అయ్యే HTML పరిశీలన నివేదికలు. ఇప్పటికే ఉన్న Flutter APKకి ఇంకా కనెక్ట్ చేయలేదు. ఈ ZIP APK కాదు.

## ఎందుకు రూపొందించాము?

**Source of Event → BNN/Western Progression పరిశీలన → వింశోత్తరి/యోగిని/జైమిని చర దశ → రోజువారీ గోచారం → తేదీల పోలిక → BTR.**

ఈ పద్ధతులన్నీ **ఒక సంఘటనకే ఆధారాలు** ఇస్తాయి. ఏ విధానమూ మరొకటి నుండి స్వతంత్రంగా సంఘటనను 'రుజువు' చేయదు. ఒకే విషయం మూడు పేర్లతో వస్తే మూడు స్వతంత్ర ఓట్లుగా లెక్కించరాదు.

## ఫైళ్లు

- `progression_first.py`: ప్రధాన v4 Python కార్యక్రమం: Source-of-Event, day-level ranked windows, BTR grid, holdout split.
- `engine.py`: పాత v2 భారతీయ దశల/నాడీ/BCP/BSP గణన మాడ్యూల్ (అందుబాటులో ఉన్న కోడ్ పునర్వినియోగం).
- `western_progression.py`: Western tropical secondary progressions + Solar Arc + Naibod directed angles.
- `18_events_input.json`: PDFలోని 18 సంఘటనల తేదీలు, పేర్లు, event owners; స్వతంత్రంగా ధృవీకరించబడలేదు.
- `backtest_holdout.py`: ఎంపిక చేసిన ఆరు holdout సంఘటన తేదీల **తెలిసిన నెలలోని** రోజు ర్యాంకు పరీక్ష.
- `reports/TIMING_FINANCIAL_2026.html`: ఫోన్‌లో తెరవగల అక్టోబర్–నవంబర్ 2026 పరీక్షా నివేదిక.
- `reports/BTR_18_EVENTS_72_TIMES.html`: 15:00–16:11లో 72 జనన సమయాల పోలిక.
- `reports/HOLDOUT_*.json`: విడిగా ఉంచిన 6 సంఘటనల నెల-పరిమిత దిన-పోలిక.
- `tests/test_progression_first.py`: v4 ఆటోమేటిక్ పరీక్షలు.
- `rule_registry.json`: మూల పద్ధతి, అమలు స్థితి, ఇంకా అవసరమైన పూర్తి గ్రంథ ధృవీకరణలు.
- `reports/START_HERE.html`: మొబైల్ ప్రారంభ పేజీ.

## ఇన్‌స్టాలేషన్

Python 3.10+ మరియు `pyswisseph` అవసరం:

```bash
pip install -r requirements.txt
```

### Timing of Event

```bash
python progression_first.py --case 18_events_input.json --mode timing --event FINANCIAL_CHANGE --from-date 2026-10-01 --to-date 2026-11-30 --out reports/my_timing
```

### BTR

```bash
python progression_first.py --case 18_events_input.json --mode btr --start-time 15:00:00 --end-time 16:11:00 --step-minutes 1 --out reports/my_btr
```

రెండు కమాండ్లు `.json` (structured data) మరియు `.html` (తెలుగు రిపోర్ట్) ఉత్పత్తి చేస్తాయి. `--event` ఎంపికలు: `MARRIAGE`, `CAREER_START`, `PROMOTION`, `BUSINESS_START`, `CHILD_BIRTH`, `PROPERTY`, `EDUCATION`, `FOREIGN_TRAVEL`, `JOB_CHANGE`, `FINANCIAL_CHANGE`.

## గణన సెట్టింగులు

- భారతీయ రాశి/గ్రహ స్థానం: Lahiri sidereal, Moshier ephemeris; mean nodes.
- KP కస్పుల star/sub: Krishnamurti ayanamsa మాత్రమే. పూర్తి KP significator hierarchy ఇంకా లేదు.
- Western Progressions: tropical zodiac, Placidus cusps, 1 day ≈ 1 year Secondary, Solar Arc, Naibod angles. భారతీయ నిరయణ స్థానాలతో నేరుగా కలపలేదు.
- BNN గురు Major 12 సంవత్సరాలు/రాశి, Minor 1 సంవత్సరం/రాశి; **మొదటి రాశి డిగ్రీ బ్యాలెన్స్ అమలు చేయలేదు**. రచయితల మధ్య భేదాలకు source-specific modes తరువాత అమలు చేయాలి.
- BSP: 6,8,9,10,11,13 మాత్రమే గణన నమూనాలో ఉన్నాయి; 1–37 పూర్తిగా నిర్ధారించలేదు.
- BPD: ఏడు గ్రహాల సరళ కాలచక్రాలు మాత్రమే; పూర్తి ఆరూఢ ఆధారిత ఫలిత నిర్ధారణ లేదు.
- యోగిని: 36 సంవత్సరాల చక్రం, చంద్ర నక్షత్ర ఆధారంగా దశ–అంతర్దశ–ప్రత్యంతర్దశ.
- చర దశ: ప్రస్తుత heuristic K. N. Rao-inspired profile; మూలగ్రంథం లేదా reference calculationsతో పూర్తిగా ధృవీకరణ అవసరం.
- నైసర్గిక: Classical 120-year version మాత్రమే; 84-year Nadi version ఆటోమేటిక్‌గా కలపలేదు.

## ఈ పరీక్షలో ఏమి కనిపించింది?

18 PDF-listed events లో 6 సంఘటనలకు `FAMILY_OTHER`, `HEALTH_OTHER`, `FAMILY_LOSS`, `HEALTH_NATIVE`, `CAREER_OTHER` తరగతుల పూర్తి event-specific rules లేవు. అందువల్ల **వాటికి రేటింగ్ ఇవ్వలేదు**. మిగిలిన 12 map అయినవి, వాటిలో 6 calibrationలో, 6 holdoutలో ఉన్నాయి. 72 జనన సమయాలు (15:00 నుంచి 16:11 వరకు ప్రతి నిమిషం) పరీక్షించబడ్డాయి.

### ప్రాథమిక holdout (నెల ముందుగానే తెలిసిన పరిస్థితి)

| జనన సమయం | తేదీ Top 3 / 6 | Top 5 / 6 |
| --- | ---: | ---: |
| 15:21 | 0/6 | 1/6 |
| 15:35 | 1/6 | 1/6 |
| 16:00 | 1/6 | 1/6 |

ఇవి **prediction accuracy కాదు**: సంఘటన జరిగిన నెల ముందుగానే తీసుకుని ఆ నెల రోజుల ర్యాంకులు పరీక్షించాం. గత సంఘటనల తేదీలు PDF వాదనలు మాత్రమే. 15:35 మోడల్‌లో calibration ranking మొదట వచ్చిన సమయం; అది నిజమైన జనన సమయం అని నిర్ధారించదు.

## నాణ్యత, పరిమితులు

1. గణిత కార్యక్రమ పరీక్షలు సక్సెస్ అవ్వడం జ్యోతిష్య అంచనాలు నిజమనే సాక్ష్యం కాదు.
2. Software weights/thresholds ఆధునిక heuristic; ఏ గ్రంథంలోనివి కావు. వీటిని వాస్తవ జీవిత-సంఘటనలతో ఫిట్ చేసి accuracy report వచ్చే వరకు మార్చుకోవచ్చు; కానీ held-out records చూసి పునర్వినియోగం చేసి accuracy అని చెప్పకూడదు.
3. గ్రహ దశలు, ప్రోగ్రెషన్, రోజువారీ చంద్ర గోచారం రోజు వరకు గణన చేయగలవు; ఆ తేదీ నిజంగా సంఘటన జరుగుతుందని నిర్ధారించలేవు.
4. ప్రస్తుతం JSON input మార్చి Python నడపాలి. HTML ఫైళ్లు **ఓపెన్ చేసి చదవగల ఆఫ్లైన్ రిపోర్ట్స్**, మొబైల్‌లో స్వతంత్ర గ్రహగణన చేయవు.
5. PDFలో చూపిన 15:21/16:00 'favored' labels ను model fittingలో ఉపయోగించలేదు.
6. Flutterకి merge చేయాలంటే repository source, existing data models, chart computation interface, integration tests అవసరం; యాప్ ఇంకా మార్చలేదు.
7. సున్నిత ఆరోగ్య/మరణ సంఘటనలకు తేదీ నిర్ధారణ లేదా వ్యక్తిగత ప్రమాద నోటిఫికేషన్ అందించవద్దు.

## ముందుగా చేయాల్సిన నిజమైన తదుపరి పని

1. 18 తేదీల నిజత్వాన్ని ఒరిజినల్ డాక్యుమెంట్లతో ధృవీకరించడం.
2. భర్త/భార్య/తండ్రి/అత్తగారికి సంబంధించిన derivative bhava/event rules మూలగ్రంథం ఆధారంగా పూర్తిచేయడం.
3. K.N. Rao చర దశ, BSP 1–37, KP significators, BNN degree-corrected variant ను వేర్వేరుగా reference chartsతో పరీక్షించడం.
4. కనీసం విభిన్న వ్యక్తుల జాతకాలలో తెలియని/కొత్త సంఘటనలపై independent backtesting చేసి, ప్రోగ్రెషన్‌కు వాస్తవ ప్రయోజనం ఉందా లేదా నిర్ణయించడం.

## v4.1 వృత్తి ఆధారిత BTR అదనపు ఆడిట్
`profession_btr_audit.py` — జ్యోతిష్యం, వాస్తు కన్సల్టెన్సీ కోసం 15:21, 15:35, 16:00 సమయాల D1/D9/D10 లగ్నాలు, సంబంధిత భావాధిపతులు పోల్చుతుంది. `reports/PROFESSION_BTR_1521_1535_1600.html` ఫోన్‌లో చదవగల నివేదిక. ఇది వృత్తి ఫలితాన్ని నిర్ధారించే పూర్తి 181 D10 నియమాల అమలు కాదు; తుది BTR సమయం నిర్ణయించలేదు.
