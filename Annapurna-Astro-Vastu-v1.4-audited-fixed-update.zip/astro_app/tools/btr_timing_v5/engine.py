"""Annapurna Astro Vastu — experimental Day-Level Event Timing & BTR.

Astrological techniques are traditions, not scientifically validated predictions.
The scoring model is original engineering logic, not a classical rule.
Dependencies: pyswisseph. Fixed choices: Lahiri sidereal, mean node,
365.2425 days/year for planetary dasha fractions, calendar birthdays for BCP.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import datetime, date, time, timedelta, timezone
from zoneinfo import ZoneInfo
from pathlib import Path
from collections import defaultdict
import csv
import html
import json
import math
import sys

try:
    import swisseph as swe
except ImportError as exc:
    raise RuntimeError("Install pyswisseph: pip install pyswisseph") from exc

# Sidereal Lahiri; Moshier avoids dependence on an external Swiss ephemeris dataset.
swe.set_sid_mode(swe.SIDM_LAHIRI)
EPH_FLAGS = swe.FLG_MOSEPH | swe.FLG_SIDEREAL
SIGNS_TE = ['మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య','తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం']
PLANETS = {'SUN':swe.SUN,'MOON':swe.MOON,'MARS':swe.MARS,'MERCURY':swe.MERCURY,'JUPITER':swe.JUPITER,'VENUS':swe.VENUS,'SATURN':swe.SATURN,'RAHU':swe.MEAN_NODE}
LORDS = ['MARS','VENUS','MERCURY','MOON','SUN','MERCURY','VENUS','MARS','JUPITER','SATURN','SATURN','JUPITER']
EVENTS = {
 'MARRIAGE': {'te':'వివాహం','houses':[2,7,11],'karakas':['VENUS','JUPITER'],'varga':'D9'},
 'CAREER_START': {'te':'మొదటి ఉద్యోగం','houses':[2,6,10,11],'karakas':['SATURN','SUN','MERCURY'],'varga':'D10'},
 'PROMOTION': {'te':'పదోన్నతి','houses':[9,10,11],'karakas':['SUN','JUPITER','SATURN'],'varga':'D10'},
 'BUSINESS_START':{'te':'వ్యాపార ప్రారంభం','houses':[7,10,11],'karakas':['MERCURY','SATURN'],'varga':'D10'},
 'CHILD_BIRTH':{'te':'సంతాన జననం','houses':[2,5,11],'karakas':['JUPITER'],'varga':'D7'},
 'PROPERTY':{'te':'స్థిరాస్తి','houses':[4,11],'karakas':['MARS','VENUS'],'varga':'D4'},
 'EDUCATION':{'te':'విద్య','houses':[4,5,9],'karakas':['MERCURY','JUPITER'],'varga':'D24'},
 'FOREIGN_TRAVEL':{'te':'విదేశీ ప్రయాణం','houses':[3,9,12],'karakas':['RAHU'],'varga':'D4'},
 'JOB_CHANGE':{'te':'ఉద్యోగ మార్పు','houses':[6,8,10,12],'karakas':['SATURN','RAHU'],'varga':'D10'},
 'FINANCIAL_CHANGE':{'te':'ఆర్థిక మార్పు','houses':[2,8,11,12],'karakas':['JUPITER','VENUS'],'varga':'D2'}
}
VIMS_SEQ=[('KETU',7),('VENUS',20),('SUN',6),('MOON',10),('MARS',7),('RAHU',18),('JUPITER',16),('SATURN',19),('MERCURY',17)]
YOG_SEQ=[('MANGALA','MOON',1),('PINGALA','SUN',2),('DHANYA','JUPITER',3),('BHRAMARI','MARS',4),('BHADRIKA','MERCURY',5),('ULKA','SATURN',6),('SIDDHA','VENUS',7),('SANKATA','RAHU',8)]
YEAR_DAYS=365.2425
# Savya/apasavya sign grouping specified by K.N. Rao / reference implementation.
SAVYA={0,1,2,6,7,8}
RULE_SOURCES={
 'BNN':'https://www.jyotishtools.com/bnn/',
 'BCP':'https://saptarishisshop.com/a-comparative-study-of-bsp-vs-bcp-by-abhishekha/',
 'BSP':'https://saptarishisshop.com/a-comparative-study-of-bsp-vs-bcp-by-abhishekha/',
 'YOG':'https://dashacalc.com/yogini/',
 'CHARA':'https://docs.asterwise.com/reference/vedic-astrology/dashas/char-dasha/',
 'VIM':'traditional Vimshottari scheme; conventional 120-year planetary periods',
 'TR':'Swiss Ephemeris/Moshier, Lahiri sidereal',
 'SCORE':'Annapurna research ranking heuristic — not a classical textual rule',
 'KP':'KP cuspal star/sub model; Krishnamurti ayanamsa; significator hierarchy requires source verification',
 'BPD':'BPD: K.P. Vaani seven-planet cycle profile; sourced from prior project rule pack',
 'NAI':'Classical natural planetary periods, 120-year profile; alternative Nadi 84-year table not mixed',
 'WEST':'https://www.astro.com/astrowiki/en/Secondary_Directions'
}


def norm(x):return x%360.0

def sign(deg):return int(norm(deg)//30)

def sign_h(s,lagna):return (s-lagna)%12 + 1

def add_year_days(dt,years):return dt+timedelta(days=YEAR_DAYS*years)

def utc_jd(dt):
    u=dt.astimezone(timezone.utc)
    return swe.julday(u.year,u.month,u.day,u.hour+u.minute/60+u.second/3600+u.microsecond/3.6e9)


def birth_datetime(data):
    d=datetime.fromisoformat(f"{data['birth_date']}T{data['birth_time']}")
    return d.replace(tzinfo=ZoneInfo(data['timezone']))


def planet_longitudes(dt):
    jd=utc_jd(dt)
    out={k: norm(swe.calc_ut(jd, code, EPH_FLAGS)[0][0]) for k,code in PLANETS.items()}
    out['KETU']=norm(out['RAHU']+180)
    return out


def asc_longitude(dt,latitude,longitude):
    # houses_ex receives UT JD and WGS84 lat/lon; returns sidereal ascendant.
    cusps,ascmc=swe.houses_ex(utc_jd(dt), latitude, longitude, b'P', swe.FLG_SIDEREAL)
    return norm(ascmc[0])


def snapshot(data, dt_override=None):
    dt=dt_override or birth_datetime(data)
    p=planet_longitudes(dt)
    p['LAGNA']=asc_longitude(dt,float(data['latitude']),float(data['longitude']))
    return p


def completed_age(born,day):
    # Calendrical age for running-year methods, Feb 29 -> Feb 28 in non-leap years.
    yr=day.year-born.year
    try:ann=born.replace(year=day.year)
    except ValueError:ann=date(day.year,2,28)
    if day<ann:yr-=1
    return max(0,yr)


def continuous_age(born_dt,day):
    dt=datetime.combine(day,time(12,0),ZoneInfo(str(born_dt.tzinfo)))
    return (dt-born_dt).total_seconds()/86400/YEAR_DAYS


def event_info(code, chart):
    if code not in EVENTS:raise ValueError('Unknown event type: '+code)
    e=EVENTS[code]
    lagna=sign(chart['LAGNA'])
    house_signs={ (lagna+h-1)%12 for h in e['houses']}
    lords={LORDS[(lagna+h-1)%12] for h in e['houses']}
    karakas=set(e['karakas'])
    planets=karakas|lords
    for k in list(planets):
        if k not in chart: continue
        house_signs.add(sign(chart[k]))
    return dict(event=code,te=e['te'],houses=e['houses'],target_signs=house_signs,
                relevant_planets=planets,house_lords=lords,karakas=karakas,lagna=lagna,
                varga=e['varga'])


def period_idx(start_idx, moon_phase_remaining, seq, total, event_dt, birth_dt):
    # Returns exact dasha segment with proportional sub-division, based on a 365.2425 day/year convention.
    first=seq[start_idx][1]*moon_phase_remaining
    cycles=0
    cursor=birth_dt-timedelta(days=(seq[start_idx][1]-first)*YEAR_DAYS)
    while cursor<=event_dt and cycles<250:
        i=(start_idx+cycles)%len(seq)
        period=seq[i][1]
        end=add_year_days(cursor,period)
        if cursor<=event_dt<end:
            return i,cursor,end
        cursor=end
        cycles+=1
    raise ValueError('Dasha date out of supported interval')


def hierarchical_dasha(seq,total,start_idx,frac_remaining,birth_dt,event_dt):
    i,start,end=period_idx(start_idx,frac_remaining,seq,total,event_dt,birth_dt)
    p_duration=(end-start).total_seconds()
    ad_cursor=start
    ad_idx=None
    for j in range(len(seq)):
        sub=(i+j)%len(seq)
        ad_len=p_duration*seq[sub][1]/total
        ad_end=ad_cursor+timedelta(seconds=ad_len)
        if event_dt<ad_end or j==len(seq)-1:
            ad_idx=sub
            break
        ad_cursor=ad_end
    pd_cursor=ad_cursor
    pd_idx=None
    for k in range(len(seq)):
        sub=(ad_idx+k)%len(seq)
        pd_len=(ad_end-ad_cursor).total_seconds()*seq[sub][1]/total
        pd_end=pd_cursor+timedelta(seconds=pd_len)
        if event_dt<pd_end or k==len(seq)-1:
            pd_idx=sub
            break
        pd_cursor=pd_end
    return {
        'maha':seq[i][0], 'antar':seq[ad_idx][0], 'pratyantar':seq[pd_idx][0],
        'start':start.isoformat(),'end':end.isoformat(),
        'antar_start':ad_cursor.isoformat(),'antar_end':ad_end.isoformat(),
        'pratyantar_start':pd_cursor.isoformat(),'pratyantar_end':pd_end.isoformat()
    }


def yogini_dasha(chart,birth_dt,dt):
    moon=chart['MOON']
    nak=int(moon/(360/27))
    fraction=moon%(360/27)/(360/27)
    # Remainder of (1-based nakshatra number + 3) mod 8, 0 -> 8.
    yogini_1_based=((nak+1+3-1)%8)+1
    start_idx=yogini_1_based-1
    seq=[(name,yrs) for name,planet,yrs in YOG_SEQ]
    x=hierarchical_dasha(seq,36,start_idx,1-fraction,birth_dt,dt)
    for key in ('maha','antar','pratyantar'):
        x[key+'_planet']={n:p for n,p,y in YOG_SEQ}[x[key]]
    x['nakshatra_index']=nak+1
    return x


def vimshottari_dasha(chart,birth_dt,dt):
    moon=chart['MOON']; nak=int(moon/(360/27));frac=moon%(360/27)/(360/27)
    seq=VIMS_SEQ
    x=hierarchical_dasha(seq,120,nak%9,1-frac,birth_dt,dt)
    x['nakshatra_index']=nak+1
    return x


def chara_direction(index):
    # Sign order using K.N. Rao selected profile: savya status of ninth from a sign.
    ninth=(index+8)%12
    return 1 if ninth in SAVYA else -1


def chara_count_direction(index): return 1 if index in SAVYA else -1


def chosen_lord(target,chart):
    if target not in (7,10): return LORDS[target]
    p1,p2=('MARS','KETU') if target==7 else ('SATURN','RAHU')
    s1,s2=sign(chart[p1]),sign(chart[p2])
    # Co-lords: prefer planet outside its domicile when other is in same domicile.
    if s1==target and s2!=target:return p2
    if s2==target and s1!=target:return p1
    occupancy={q:sum(sign(chart[z])==sign(chart[q]) for z in PLANETS if z!=q) for q in (p1,p2)}
    if occupancy[p1]!=occupancy[p2]:return p1 if occupancy[p1]>occupancy[p2] else p2
    return p1 if chart[p1]%30>=chart[p2]%30 else p2


def chara_years(index,chart):
    target=sign(chart[chosen_lord(index,chart)])
    if target==index:return 12
    direction=chara_count_direction(index)
    return ((direction*(target-index))%12) or 12


def chara_dasha(chart,birth_dt,dt,cycles=3):
    lag=sign(chart['LAGNA'])
    direction=chara_direction(lag)
    t=birth_dt
    for cycle in range(cycles):
        for i in range(12):
            md_sign=(lag+i*direction)%12
            yrs=chara_years(md_sign,chart)
            end=add_year_days(t,yrs)
            if dt<end:
                sub_dir=chara_direction(md_sign)
                sub_years=yrs/12
                for j in range(12):
                    ad_sign=(md_sign+(j+1)*sub_dir)%12
                    astart=add_year_days(t,j*sub_years)
                    aend=add_year_days(t,(j+1)*sub_years)
                    if dt<aend or j==11:
                        return {'maha':md_sign,'antar':ad_sign,'maha_name':SIGNS_TE[md_sign],
                          'antar_name':SIGNS_TE[ad_sign], 'maha_years':yrs,'maha_start':t.isoformat(),
                          'maha_end':end.isoformat(),'antar_start':astart.isoformat(),
                          'antar_end':aend.isoformat(),'profile':'K.N.Rao—ninth-sign Savya/Apasavya; no exalt/debil adjustments'}
            t=end
    raise ValueError('Event date outside configured Chara Dasha cycles')


def bnn(chart,birth_dt,day):
    age=continuous_age(birth_dt,day)
    if age<0:raise ValueError('Date precedes birth')
    j=sign(chart['JUPITER']); s=sign(chart['SATURN']); r=sign(chart['RAHU'])
    # Choice: fixed-age sign blocks, no natal longitude balance adjustment.
    return {'major':(j+int(age//12))%12,'minor':(j+int(age//1))%12,
            'saturn_minor':(s+int(age//2.5))%12,
            'rahu_minor':(r-int(age//1.55))%12,
            'completed_age':completed_age(birth_dt.date(),day),
            'running_year':completed_age(birth_dt.date(),day)+1,
            'profile':'Fixed 12y/sign Major; 1y/sign Minor; no degree balance'}


def bcp(birth_dt,day):
    yr=completed_age(birth_dt.date(),day)+1
    return {'running_year':yr,'house':((yr-1)%12)+1}


BSP_AGE_RULES=[('BSP-6',27,'MARS',10),('BSP-8',38,'RAHU',6),('BSP-9',24,'KETU',12),
               ('BSP-10',40,'JUPITER',9),('BSP-11',32,'JUPITER',5),('BSP-13',20,'SATURN',3)]

def bsp(chart,running_year):
    hits=[]
    for rid,year,planet,distance in BSP_AGE_RULES:
        if running_year==year:
            s=(sign(chart[planet])+distance-1)%12
            hits.append({'rule':rid,'planet':planet,'sign':s,'position':distance,'running_year':year})
    return hits



def bpd_progression(chart,birth_dt,day):
    """K.P. Vaani BPD seven independent cyclic sign clocks.

    Pure sign progression; longitudinal natal balance and Arudha exemptions
    have NOT been fitted. Output as source context, not verified dated prediction.
    """
    y=continuous_age(birth_dt,day)
    cycles={'SUN':19,'MOON':45,'MARS':14,'MERCURY':46,
            'JUPITER':83,'VENUS':27,'SATURN':30}
    return {'profile':'BPD_VAANI_SEVEN_PLANETS', 'signs':{
        p:(sign(chart[p])+math.floor(y/(length/12)))%12 for p,length in cycles.items()}}


def naisargika_120(birth_dt,day):
    y=continuous_age(birth_dt,day)
    for name,span in [('MOON',1),('MARS',2),('MERCURY',9),('VENUS',20),
                      ('JUPITER',18),('SUN',20),('SATURN',50)]:
        if y<span:return {'ruler':name,'remaining_years':round(span-y,5),'profile':'CLASSICAL_120'}
        y-=span
    return {'ruler':None,'profile':'CLASSICAL_120','warning':'Beyond the modeled 120-year age cycle'}


def kp_star_sub(longitude):
    """Longitude to KP nakshatra star/sub, proportional Vimshottari, 120-years.

    Use only with Krishnamurti sidereal longitude. This function computes the
    subdivision, not the full KP event significator hierarchy.
    """
    arc=360/27
    nak=int(norm(longitude)/arc)
    within=norm(longitude)%arc
    star_idx=nak%9
    cursor=0.0
    for j in range(9):
        n=(star_idx+j)%9
        wid=arc*VIMS_SEQ[n][1]/120
        if within<cursor+wid+1e-10 or j==8:
            return {'nakshatra_index':nak+1,'star':VIMS_SEQ[star_idx][0],
                    'sub':VIMS_SEQ[n][0], 'nakshatra_offset_degrees':round(within,8)}
        cursor+=wid
    raise ArithmeticError('Unreachable KP boundary')


def kp_cusps(dt,latitude,longitude):
    swe.set_sid_mode(swe.SIDM_KRISHNAMURTI)
    try:
        c,ascmc=swe.houses_ex(utc_jd(dt),float(latitude),float(longitude),b'P',swe.FLG_SIDEREAL)
        return {i+1:{'longitude':round(norm(v),8),**kp_star_sub(v)} for i,v in enumerate(c)}
    finally:
        swe.set_sid_mode(swe.SIDM_LAHIRI)


def nadi_sign_related(target, event_signs):
    if target in event_signs:return 'DIRECT'
    # Common BNN-style trinal sign relationships; correlation with a direct is not independent.
    if any((target-s)%12 in (4,8) for s in event_signs):return 'TRINE'
    return None


def evaluate(chart,birth_dt,day,event_code,moon_transit=True):
    """Explainable model agreement ranking; scores are not probabilities.

    Invariant natal/event facts never add repeated daily score. Correlated Jupiter BNN,
    BSP, BCP are grouped into one context family cap. Dasha families each have
    a separate daily clock. Moon transit is a weak *day selector*, not proof.
    """
    if day<birth_dt.date():raise ValueError('Event day cannot precede birth')
    e=event_info(event_code,chart)
    noon=datetime.combine(day,time(12,0),birth_dt.tzinfo)
    n=bnn(chart,birth_dt,day); bc=bcp(birth_dt,day); br=bsp(chart,bc['running_year'])
    yog=yogini_dasha(chart,birth_dt,noon)
    vim=vimshottari_dasha(chart,birth_dt,noon)
    cha=chara_dasha(chart,birth_dt,noon)
    evidence=[]
    def evidence_add(family,id,label,weight,role='SUPPORT'):
        evidence.append(dict(family=family,id=id,label=label,weight=round(weight,2),role=role,source=RULE_SOURCES.get(family)))
    def planet_match(p):
        if p in e['house_lords']:return 1.0
        if p in e['karakas']:return .8
        if p in chart and sign(chart[p]) in e['target_signs']:return .4
        return 0
    def sign_match(s):
        if s in e['target_signs']:return 1.0
        if s in { (e['lagna']+h-1)%12 for h in e['houses']}:return 1.0
        return .0
    nadi_support=[]
    for typ,s in [('major',n['major']),('minor',n['minor']),('saturn_minor',n['saturn_minor']),('rahu_minor',n['rahu_minor'])]:
        rel=nadi_sign_related(s,e['target_signs'])
        if rel:
            w=1 if rel=='DIRECT' else .45
            nadi_support.append(w)
            evidence_add('BNN','BNN-'+typ.upper(),typ+' '+SIGNS_TE[s]+' ('+rel+')', w*.8,'CONTEXT')
    bcp_support=0
    if bc['house'] in e['houses']:
        bcp_support=.8
        evidence_add('BCP','BCP-01','Activated bhava '+str(bc['house']),.8,'CONTEXT')
    bsp_support=0
    for r in br:
        if r['sign'] in e['target_signs']:
            bsp_support=1
            evidence_add('BSP',r['rule'],r['planet']+' -> '+SIGNS_TE[r['sign']],1,'CONTEXT')
    def dasha_score(family,d, keys, coeffs):
        # Sum is capped within one dasha family, avoiding triple-counting its hierarchy.
        v=0.0
        for k,coeff in zip(keys,coeffs):
            p=d[k]
            m=planet_match(p)
            if m:
                evidence_add(family,family+'-'+k.upper(),k+': '+p,coeff*m)
                v+=coeff*m
        return min(v,sum(coeffs))
    vim_sc=dasha_score('VIM',vim,['maha','antar','pratyantar'],[1,2,2.5])
    yog_sc=dasha_score('YOG',yog,['maha_planet','antar_planet','pratyantar_planet'],[1,1.8,2.2])
    cha_sc=0
    for k,weight in [('maha',1.5),('antar',2)]:
        ss=cha[k]
        if sign_match(ss):
            cha_sc+=weight
            evidence_add('CHARA','CHARA-'+k.upper(),k+': '+SIGNS_TE[ss],weight)
    bpd=bpd_progression(chart,birth_dt,day)
    bpd_sc=[]
    for p,s in bpd['signs'].items():
        if p in e['relevant_planets'] and s in e['target_signs']:
            bpd_sc.append(.5)
            evidence_add('BPD','BPD-'+p,p+' progressed to '+SIGNS_TE[s],.5,'CONTEXT')
    nai=naisargika_120(birth_dt,day)
    nai_sc=0.0
    if nai['ruler'] and planet_match(nai['ruler']):
        nai_sc=.45
        evidence_add('NAI','NAI-120','Naisargika ruler '+nai['ruler'],.45,'CONTEXT')
    # daily transit: natal Moon-based transit is time-dependent day clock.
    moon_sc=0.0
    if moon_transit:
        tr=planet_longitudes(noon)
        ms=sign(tr['MOON'])
        if ms in {(e['lagna']+h-1)%12 for h in e['houses']}:
            moon_sc=.55
            evidence_add('TR','MOON-HOUSE','Daily Moon transit in '+SIGNS_TE[ms],moon_sc,'DAY_SELECTOR')
    # BNN, BCP and BSP share sign-age structure => one cap for contextual timing evidence.
    context=min(1.8,(max(nadi_support,default=0)*.7 + bcp_support*.45 + bsp_support*.45 + max(bpd_sc,default=0)*.3 + nai_sc*.3))
    score=round(vim_sc + yog_sc + cha_sc + moon_sc + context,3)
    return {
      'date':day.isoformat(),'event':event_code,'event_te':e['te'],
      'score':score,'score_type':'heuristic_not_probability',
      'vimsottari':vim,'yogini':yog,'chara':cha,
      'bnn':{k:(SIGNS_TE[v] if k in ['major','minor','saturn_minor','rahu_minor'] else v) for k,v in n.items()},
      'bcp':bc,'bsp':br,'bpd':{**bpd,'signs':{p:SIGNS_TE[v] for p,v in bpd['signs'].items()}},'naisargika':nai,
      'evidence':evidence,'family_scores':{
        'AGE_SIGN_CONTEXT':round(context,2),'VIM':round(vim_sc,2),'YOG':round(yog_sc,2),
        'CHARA':round(cha_sc,2),'DAILY_TRANSIT':round(moon_sc,2)},
      'notes':['Timing score is a comparison of rule signals, not an observed likelihood.',
               'BPD seven-planet and classical Naisargika profile only; other author variants not mixed.',
               'KP cusps can be inspected in BTR, but comprehensive KP event rule hierarchy is not implemented.',
               'Day precision is calendar granularity only, not demonstrated predictive accuracy.']
    }


def rank_days(chart,birth_dt,event_code,from_day,to_day,top=12,latitude=None,longitude=None):
    if to_day<from_day:raise ValueError('Range end before start')
    if (to_day-from_day).days>3653:raise ValueError('Maximum range is 10 years per run')
    all_days=[]
    curr=from_day
    while curr<=to_day:
        all_days.append(evaluate(chart,birth_dt,curr,event_code))
        curr+=timedelta(days=1)
    order=sorted(all_days,key=lambda a:(-a['score'],a['date']))
    if not order:return {'days':[], 'top':[]}
    # Western contacts are source-of-event diagnostics ONLY; they do not alter the primary ranking.
    from western_progression import source_of_event
    ectx=event_info(event_code,chart)
    for record in order[:top]:
        record['western_event_source']=(source_of_event(birth_dt,date.fromisoformat(record['date']),
            float(latitude),float(longitude),ectx['relevant_planets'],event_code)
            if latitude is not None and longitude is not None else
            {'status':'NEEDS_LATITUDE_LONGITUDE_FOR_ANGLE_CHECKS'})
    maximum=order[0]['score']
    same=[o['date'] for o in order if abs(o['score']-maximum)<1e-7]
    return {'event':event_code,'range':[from_day.isoformat(),to_day.isoformat()],
            'top':order[:top],'daily':all_days,'max_score':maximum,'tied_top_day_count':len(same),
            'tied_top_dates':same[:50],
            'warning':('More than one day shares the leading score; do not assert a unique event date.'
                       if len(same)>1 else 'Single leading calendar day is model ranking, not certainty.')}


def event_alignment(chart,birth_dt,known_events):
    if not known_events:raise ValueError('At least one event is required')
    details=[]
    for e in known_events:
        day=date.fromisoformat(e['date'])
        rec=evaluate(chart,birth_dt,day,e['type'])
        details.append({'date':e['date'],'event_type':e['type'],'score':rec['score'],
                        'family_scores':rec['family_scores'],
                        'evidence_count':len(rec['evidence'])})
    # Only time-differentiating evidence will be used by caller.
    return details


def btr_scan(data,known_events,minutes=30,step_seconds=60):
    dt=birth_datetime(data)
    if step_seconds<1 or step_seconds>3600:raise ValueError('Invalid BTR step')
    results=[]
    for seconds in range(-minutes*60,minutes*60+1,step_seconds):
        birth_candidate=dt+timedelta(seconds=seconds)
        chart=snapshot(data,birth_candidate)
        event_details=event_alignment(chart,birth_candidate,known_events)
        features=[tuple(sorted(x['family_scores'].items())) for x in event_details]
        kp=kp_cusps(birth_candidate,data['latitude'],data['longitude'])
        relevant_kp={typecode:{str(h):kp[h] for h in EVENTS[typecode]['houses']} for typecode in {e['type'] for e in known_events}}
        results.append({'birth_time':birth_candidate.isoformat(),'offset_seconds':seconds,
                        'chart_lagna':round(chart['LAGNA'],6),
                        'raw_score':round(sum(x['score'] for x in event_details),3),
                        'features':features,'events':event_details,'kp_cusp_subs':relevant_kp})
    # Comparing candidates only on feature families whose scores change across candidates.
    informative_keys=[]
    family_names=list(results[0]['events'][0]['family_scores'])
    for ei in range(len(known_events)):
        for family in family_names:
            vals={r['events'][ei]['family_scores'][family] for r in results}
            if len(vals)>1:informative_keys.append((ei,family))
    for r in results:
        r['discriminating_score']=round(sum(r['events'][i]['family_scores'][family]
                                  for i,family in informative_keys),3)
        del r['features']
    results.sort(key=lambda r:(-r['discriminating_score'],abs(r['offset_seconds'])))
    from western_progression import source_of_event
    for candidate in results[:10]:
        cborn=datetime.fromisoformat(candidate['birth_time'])
        cchart=snapshot(data,cborn)
        candidate['western_event_sources']=[source_of_event(cborn,date.fromisoformat(ev['date']),
            float(data['latitude']),float(data['longitude']),
            event_info(ev['type'],cchart)['relevant_planets'],ev['type'])
            for ev in known_events]
    highest=results[0]['discriminating_score']
    tied=[r for r in results if r['discriminating_score']==highest]
    return {'event_count':len(known_events),'search_minutes':minutes,'step_seconds':step_seconds,
            'informative_features':[{'event_index':i,'family':f} for i,f in informative_keys],
            'best_candidates':results[:10],'tied_best_count':len(tied),
            'compatible_interval':[min(t['birth_time'] for t in tied),max(t['birth_time'] for t in tied)],
            'warning':('No birth-time discriminating features changed. Unable to rectify within range.'
                       if not informative_keys else 'Candidate ranking only: independent held-out events required; not verified birth time.')}


def render_html(report,title='Annapurna Astro Vastu — Event Timing'):
    safe=lambda v:html.escape(str(v),quote=True)
    if 'top' in report:
        rows=''.join('<tr><td>'+safe(d['date'])+'</td><td>'+safe(d['score'])+'</td><td>'+safe(d['chara']['maha_name'])+' / '+safe(d['chara']['antar_name'])+'</td><td>'+safe(d['yogini']['maha'])+' / '+safe(d['yogini']['antar'])+'</td><td>'+safe(d['vimsottari']['maha'])+' / '+safe(d['vimsottari']['antar'])+'</td><td>'+safe(d.get('western_event_source',{}).get('total_hits','—'))+'</td></tr>' for d in report['top'])
        heading='<h2>సంఘటన: '+safe(EVENTS[report['event']]['te'])+'</h2><p>అత్యధిక స్కోర్ కలిగిన సమాన రోజులు: '+safe(report['tied_top_day_count'])+'</p>'
        table='<table><thead><tr><th>తేదీ</th><th>అంతర్గత స్కోర్</th><th>చర దశ</th><th>యోగిని</th><th>వింశోత్తరి</th><th>Western Contacts*</th></tr></thead><tbody>'+rows+'</tbody></table>'
    else:
        rows=''.join('<tr><td>'+safe(d['birth_time'])+'</td><td>'+safe(d['discriminating_score'])+'</td><td>'+safe(d['raw_score'])+'</td><td>'+safe(sum(z['total_hits'] for z in d.get('western_event_sources',[])))+'</td></tr>' for d in report['best_candidates'])
        heading='<h2>BTR — అభ్యర్థి జనన సమయాలు</h2><p>సమాన ఉత్తమ అభ్యర్థులు: '+safe(report['tied_best_count'])+'</p>'
        table='<table><thead><tr><th>జనన సమయం</th><th>భేదక స్కోర్</th><th>మొత్తం స్కోర్</th><th>Western Contacts*</th></tr></thead><tbody>'+rows+'</tbody></table>'
    safe_data=json.dumps(report,ensure_ascii=False).replace('</','<\\/')
    return f'''<!doctype html><html lang="te"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{safe(title)}</title><style>
    body{{background:#f8fafc;color:#172b4d;font-family:system-ui,'Noto Sans Telugu',sans-serif;line-height:1.6;margin:0 auto;padding:16px;max-width:1100px}} h1{{font-size:1.45rem;color:#193d70}}h2{{font-size:1.17rem}}.card{{background:white;border:1px solid #dce3ec;padding:18px;border-radius:14px;overflow:auto}}table{{width:100%;border-collapse:collapse;font-size:.9rem}}th,td{{padding:10px;text-align:left;border-bottom:1px solid #e6eaf0}}th{{background:#edf2f8}}.warn{{color:#7b341e;background:#fff6eb;padding:12px;border-radius:8px}}button{{padding:12px;background:#193d70;color:white;border:0;border-radius:9px;cursor:pointer}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;font-size:.75rem}}</style><h1>Annapurna Astro Vastu</h1><p>Source of Event → Timing of Event / BTR • Day-level experimental engine</p><section class="card">{heading}<p class="warn">{safe(report['warning'])} గ్రహ నియమాల అన్వయం ప్రయోగాత్మకం; ఇది సంఘటన ఖచ్చితంగా జరుగుతుందని నిర్ధారణ కాదు.</p>{table}<p><small>* Western contacts కేవలం Source-of-Event అదనపు పరిశీలన; ర్యాంకింగ్ స్కోర్‌లో కలపలేదు.</small></p><p><button onclick="const p=document.getElementById('details');p.hidden=!p.hidden">మొత్తం వర్తించిన నియమాలు / JSON చూపండి</button></p><pre id="details" hidden></pre></section><script type="application/json" id="payload">{safe_data}</script><script>document.getElementById('details').textContent=JSON.stringify(JSON.parse(document.getElementById('payload').textContent),null,2);</script></html>'''


def main():
    ap=argparse.ArgumentParser(description='Annapurna Event Timing — day-level proof of concept')
    ap.add_argument('--case',required=True,help='Birth JSON input')
    ap.add_argument('--mode',choices=['timing','btr'],default='timing')
    ap.add_argument('--event',choices=EVENTS.keys(),default='MARRIAGE')
    ap.add_argument('--from-date',help='YYYY-MM-DD')
    ap.add_argument('--to-date',help='YYYY-MM-DD')
    ap.add_argument('--minutes',type=int,default=15)
    ap.add_argument('--step-seconds',type=int,default=60)
    ap.add_argument('--output',default='event_timing_report')
    args=ap.parse_args()
    data=json.loads(Path(args.case).read_text(encoding='utf-8'))
    born=birth_datetime(data)
    if args.mode=='timing':
        first=date.fromisoformat(args.from_date) if args.from_date else date.today()
        last=date.fromisoformat(args.to_date) if args.to_date else first+timedelta(days=365)
        report=rank_days(snapshot(data),born,args.event,first,last,latitude=data["latitude"],longitude=data["longitude"])
    else:
        report=btr_scan(data,data.get('known_events',[]),args.minutes,args.step_seconds)
    stem=Path(args.output)
    stem.parent.mkdir(parents=True,exist_ok=True)
    stem.with_suffix('.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    stem.with_suffix('.html').write_text(render_html(report),encoding='utf-8')
    print('HTML:',stem.with_suffix('.html'))
    print('JSON:',stem.with_suffix('.json'))
    print(report['warning'])
    if args.mode=='timing': print('Top:', [(r['date'],r['score']) for r in report['top'][:5]])
    else: print('BTR discriminators:',report['informative_features'])

if __name__=='__main__': main()
