import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/dasha_service.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_period_calendar.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';

void main() {
  test('Mehta pp. 224-225: book arithmetic 360-day years, 30-day months', () {
    expect(MehtaPeriodCalendar.period(16 * 16 / 120).sourceYmd, '2-1-18');
    expect(MehtaPeriodCalendar.period(16 * 19 / 120).sourceYmd, '2-6-12');
    expect(MehtaPeriodCalendar.period(16 * 17 / 120).sourceYmd, '2-3-6');
    expect(MehtaPeriodCalendar.period(16 * 6 / 120).sourceYmd, '0-9-18');
  });

  test('Mehta Chart145a p.242: Saturn 7y0m12d × 2/3 = 4y8m8d', () {
    final normalized = (7 * 360 + 12) * 2 / 3;
    expect(normalized, 1688);
    expect(MehtaPeriodCalendar.period(normalized / 360).sourceYmd, '4-8-8');
    final birth = DateTime(1953, 2, 16);
    final end = MehtaPeriodCalendar.addBookYears(birth, normalized / 360);
    expect(end, DateTime(1957, 10, 24));
  });

  test('Chart145a pp.244-245: forward 23 calendar days matches event', () {
    expect(MehtaPeriodCalendar.synchronize(DateTime(1979, 11, 16),
      const MehtaSynchronizationOffset(days: 23)), DateTime(1979, 12, 9));
  });

  test('Chart145 p.237: printed 2m25d and civil example differ', () {
    final calc = MehtaPeriodCalendar.synchronize(DateTime(1966, 3, 16),
      const MehtaSynchronizationOffset(months: 2, days: 25));
    expect(calc, DateTime(1966, 6, 10));
    // Printed 11-Jun-1966 differs by one civil day. Do not silently
    // introduce a fictitious inclusive-day rule into all charts.
    expect(calc, isNot(DateTime(1966, 6, 11)));
    expect(2 * 30 + 25, 85);
  });

  test('Indira case pp.246-247 uses normalized period subtraction', () {
    final first = 1 * 360 + 11 * 30 + 18;
    final correction = 4 * 30 + 23;
    final remaining = first - correction;
    expect(remaining, 565);
    expect(MehtaPeriodCalendar.period(remaining / 360).sourceYmd, '1-6-25');
  });

  test('calendar months are clamped at month-end and offset is separate', () {
    expect(MehtaPeriodCalendar.addCalendar(DateTime(2024, 1, 31), months: 1),
      DateTime(2024, 2, 29));
    expect(MehtaPeriodCalendar.synchronize(DateTime(2024, 3, 29),
      const MehtaSynchronizationOffset(months: -1)),
      DateTime(2024, 2, 29));
    expect(() => MehtaPeriodCalendar.synchronize(DateTime(2000, 1, 1),
        const MehtaSynchronizationOffset(months: 1, days: -3)),
      throwsArgumentError);
  });

  test('Mehta dasha 80y and 120y first period use book calendar', () {
    // Saturn starts at nakshatra #7. Select its elapsed fraction to
    // reproduce Chart145a source birth balance 4y8m8d (not the chart itself).
    const saturnCycle = 19.0 * 2 / 3;
    const remaining = 4 + 8 / 12 + 8 / 360;
    const fractionalElapsed = 1 - remaining / saturnCycle;
    const nakshatraSize = 360.0 / 27;
    final fake = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 25,
      engineVersion: 'fixture', planets: [
        PlanetPosition(name: 'Moon', shortName: 'Mo',
          longitude: (7 + fractionalElapsed) * nakshatraSize,
          latitude: 0, speed: 13),
      ],
    );
    final birth = DateTime(1953, 2, 16);
    final result = DashaService.system(kind: DashaSystemKind.tribhagi,
      chart: fake, birthDateTime: birth,
      calendarBasis: DashaCalendarBasis.mehtaBookGregorian);
    expect(result.birthBalanceYears, closeTo(remaining, 1e-8));
    expect(result.mahadashas.first.end, DateTime(1957, 10, 24));
    expect(result.calendarBasis, DashaCalendarBasis.mehtaBookGregorian);
    final parent = DashaService.periodAt(result.mahadashas, birth)!;
    final ad = DashaService.subPeriodsFor(result, parent);
    expect(ad.first.start, parent.start);
    expect(ad.last.end, parent.end);
    for (var i = 1; i < ad.length; i++) {
      expect(ad[i-1].end, ad[i].start);
      expect(ad[i].start.isBefore(ad[i].end), true);
    }
    final path = DashaService.pathAt(result, birth);
    expect(path, isNotNull);
    for (final level in path!.levels) {
      expect(level.contains(birth), true);
    }
  });
  test('synchronization shifts calculated dates, not Moon birth balance', () {
    final chart = AstroChartResult(julianDay: 0, ayanamsaDegrees: 0,
        ascendantLongitude: 25, engineVersion: 'fixture', planets: [
          const PlanetPosition(name: 'Moon', shortName: 'Mo',
              longitude: 93.333333, latitude: 0, speed: 13),
        ]);
    final original = DashaService.system(kind: DashaSystemKind.tribhagi,
        chart: chart, birthDateTime: DateTime(1953, 2, 16),
        calendarBasis: DashaCalendarBasis.mehtaBookGregorian);
    final shifted = MehtaBtrService.synchronizePeriodSystem(original,
        const MehtaSynchronizationOffset(days: 23));
    expect(shifted.birthBalanceYears, original.birthBalanceYears);
    expect(shifted.moonNakshatraIndex, original.moonNakshatraIndex);
    expect(shifted.mahadashas.first.start,
        original.mahadashas.first.start.add(const Duration(days: 23)));
    expect(shifted.mahadashas.first.end,
        original.mahadashas.first.end.add(const Duration(days: 23)));
  });

}
