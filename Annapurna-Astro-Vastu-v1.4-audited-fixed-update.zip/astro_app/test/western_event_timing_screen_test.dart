import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:astro_app/screens/progression_analysis_screen.dart';
import 'package:astro_app/astrology/western_progression_service.dart';
import 'package:astro_app/models/birth_data.dart';

void main() {
  test('event source selectors are distinct from Mehta house rules', () {
    final marriage = WesternProgressionService.eventProfile('వివాహం');
    expect(marriage.secondary, contains('Venus'));
    expect(marriage.natal, contains('DESC'));
    final career = WesternProgressionService.eventProfile('ప్రభుత్వ ఉద్యోగం');
    expect(career.natal, contains('MC'));
    final child = WesternProgressionService.eventProfile('సంతానం');
    expect(child.natal, contains('Jupiter'));
  });

  test('every listed event has computable progression source keys', () {
    const eventNames = [
      'వివాహం','ప్రేమ వివాహం','నిశ్చితార్థం','ఉద్యోగం',
      'ప్రభుత్వ ఉద్యోగం','ప్రమోషన్','ఉద్యోగ మార్పు',
      'వ్యాపారం / స్వయం ఉపాధి','సంతానం','గర్భధారణ',
      'విద్య','పరీక్షలో విజయం','విదేశీ ప్రయాణం',
      'ఆస్తి కొనుగోలు','ఇంటి నిర్మాణం','వాహనం',
      'ధనలాభం','రుణ విముక్తి','ఆరోగ్యం',
      'కోర్టు వ్యవహారం','బదిలీ','పదవీ విరమణ',
    ];
    const natalKeys = {'ASC','DESC','MC','IC',
      'Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn'};
    const solarKeys = {'ASC','MC',
      'Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn'};
    for (final name in eventNames) {
      final p = WesternProgressionService.eventProfile(name);
      expect(p.secondary, isNotEmpty, reason: name);
      expect(p.solar, isNotEmpty, reason: name);
      expect(p.natal, isNotEmpty, reason: name);
      expect(p.secondary.every(WesternProgressionService.bodies.containsKey),
          isTrue, reason: name);
      expect(p.solar.every(solarKeys.contains), isTrue, reason: name);
      expect(p.natal.every(natalKeys.contains), isTrue, reason: name);
    }
  });

  testWidgets('event search receives birth chart instead of placeholder', (tester) async {
    final birth = BirthData(name: 'జాతకుడు',
      localDateTime: DateTime(1981, 12, 15, 15, 15),
      place: 'గుంటూరు', latitude: 16.3, longitude: 80.4,
      timezoneOffsetHours: 5.5, ayanamsa: AyanamsaType.lahiri);
    await tester.pumpWidget(MaterialApp(
      home: TimingOfEventScreen(birthData: birth)));
    expect(find.textContaining('జాతకుడు'), findsOneWidget);
    expect(find.textContaining('సంఘటన ఎంపిక'), findsOneWidget);
    expect(find.textContaining('గణన ఇంకా అందుబాటులో లేదు'), findsNothing);
  });

  test('date range validation happens before ephemeris initialization', () async {
    final birth = BirthData(
      name: 'Test', localDateTime: DateTime(1981, 12, 15, 15, 15),
      place: 'Test', latitude: 16.3, longitude: 80.4,
      timezoneOffsetHours: 5.5, ayanamsa: AyanamsaType.lahiri,
    );
    await expectLater(
      WesternProgressionService.contactsInEventRange(
        birth, 'వివాహం', DateTime(2027, 2), DateTime(2026, 2)),
      throwsArgumentError,
    );
    await expectLater(
      WesternProgressionService.contactsInEventRange(
        birth, 'వివాహం', DateTime(2026), DateTime(2029)),
      throwsArgumentError,
    );
  });
}
