import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_source_first_engine.dart';

MehtaSourceEntry sample(String id, String section) => MehtaSourceEntry({
  'rule_id': id, 'section':section, 'source_book':'Test source',
  'previous_compilation_unchanged': {
    'id':id,'title':'వివాహం','houses':'1–7–12',
    'condition':'మూల నియమ సంకలనం'
  },
  'source_reference': {'claimed_printed_pages':'12–17'},
  'source_audit': {'status':'NOT_VERIFIED_SOURCE_PAGE_BY_PAGE',
    'status_telugu':'మూలపేజీ పరిశీలన పెండింగ్'},
  'rule_is_never_deactivated_by_horoscope_nonmatch': true,
});

void main() {
  test('source entry retains original compiled condition across inspection', () {
    final rule = sample('E01','EVENT');
    final before = jsonEncode(rule.raw);
    final chart = AstroChartResult(julianDay: 0, ayanamsaDegrees:0,
      ascendantLongitude: 0, engineVersion:'test', planets: const [
        PlanetPosition(name:'Moon',shortName:'Mo',longitude:90,
            latitude:0,speed:0),
        PlanetPosition(name:'Sun',shortName:'Su',longitude:150,
            latitude:0,speed:0),
      ]);
    final first = MehtaSourceFirstEngine.houseContexts(chart,rule);
    expect(first.length,2);
    expect(first.first.groups.single[1],'Mars');
    expect(first.first.groups.single[7],'Venus');
    expect(first.first.groups.single[12],'Jupiter');
    final withSun = MehtaSourceFirstEngine.houseContexts(chart,rule,includeSun:true);
    expect(withSun.length,3);
    expect(jsonEncode(rule.raw),before);
    expect(rule.auditStatus,'NOT_VERIFIED_SOURCE_PAGE_BY_PAGE');
    expect(() => rule.raw['source_book'] = 'Changed', throwsUnsupportedError);
    expect(() => (rule.raw['source_audit'] as Map)['status'] = 'VERIFIED',
      throwsUnsupportedError);
  });

  test('event to BTR mappings keep business=7,2 and child=1,5,9', () {
    expect(MehtaSourceFirstEngine.eventFromBtr['M14'],'E17');
    expect(MehtaSourceFirstEngine.eventHouseAlternatives['E17'],[[7,2]]);
    expect(MehtaSourceFirstEngine.eventFromBtr['M06'],'E08');
    expect(MehtaSourceFirstEngine.eventHouseAlternatives['E08'],[[1,5,9]]);
  });

  test('311-count validation prevents incomplete source registry', () {
    expect(() => MehtaSourceFirstEngine.decodeRegistry(jsonEncode({'rules':[]})),
      throwsFormatException);
    expect(MehtaSourceFirstEngine.inspectPeriods(const [],null,null)
      .vimshottari.available,false);
  });
}
