import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/kp_cusp_significator_service.dart';
import 'package:astro_app/astrology/btr_integrated_method_service.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';

void main() {
  AstroChartResult sample({bool includeCusps = true}) => AstroChartResult(
    julianDay: 2460000,
    ayanamsaDegrees: 23.5,
    ascendantLongitude: 0,
    engineVersion: 'fixture',
    houseCuspLongitudes: includeCusps
      ? [for (var i = 0; i < 12; i++) i * 30.0]
      : const [],
    planets: const [
      PlanetPosition(name:'Sun', shortName:'Su', longitude: 15,latitude:0,speed:1),
      PlanetPosition(name:'Moon',shortName:'Mo',longitude: 42,latitude:0,speed:1),
      PlanetPosition(name:'Mars',shortName:'Ma',longitude: 82,latitude:0,speed:1),
      PlanetPosition(name:'Mercury',shortName:'Me',longitude: 115,latitude:0,speed:1),
      PlanetPosition(name:'Jupiter',shortName:'Ju',longitude: 143,latitude:0,speed:1),
      PlanetPosition(name:'Venus',shortName:'Ve',longitude: 187,latitude:0,speed:1),
      PlanetPosition(name:'Saturn',shortName:'Sa',longitude: 217,latitude:0,speed:1),
      PlanetPosition(name:'Rahu',shortName:'Ra',longitude: 248,latitude:0,speed:-0.1),
      PlanetPosition(name:'Ketu',shortName:'Ke',longitude: 68,latitude:0,speed:-0.1),
    ],
  );

  test('KP 12 actual cusps, distinct 4-level significator houses', () {
    final audit = KpCuspSignificatorService.compute(sample());
    expect(audit.available, true);
    expect(audit.cusps, hasLength(12));
    expect(audit.cusps.first.house, 1);
    expect(audit.planets['Sun']!.occupiedHouse, 1);
    expect(audit.planets['Venus']!.occupiedHouse, 7);
    expect(audit.planets['Rahu']!.isNode, true);
    expect(audit.planets['Sun']!.starLordOccupied, isNotEmpty);
    expect(audit.planets['Sun']!.owned, isNotEmpty);
    expect(audit.signature.split('|'),hasLength(12));
  });
  test('wrap-around arcs and boundary go to the new cusp house', () {
    final chart = AstroChartResult(
      julianDay: 1, ayanamsaDegrees: 0, ascendantLongitude: 345,
      engineVersion: 'fixture',
      houseCuspLongitudes: [for(var h=0;h<12;h++) (345+h*30)%360],
      planets: const [
        PlanetPosition(name:'Sun',shortName:'Su',longitude:345,latitude:0,speed:1),
        PlanetPosition(name:'Moon',shortName:'Mo',longitude:14,latitude:0,speed:1),
      ]);
    final result = KpCuspSignificatorService.compute(chart);
    expect(result.available, true);
    expect(result.planets['Sun']!.occupiedHouse, 1);
    expect(result.planets['Moon']!.occupiedHouse, 1);
  });
  test('missing or invalid cusps never silently creates equal houses', () {
    final noCusps=KpCuspSignificatorService.compute(sample(includeCusps:false));
    expect(noCusps.available, false);
    expect(noCusps.forEvent('M01'), isNull);
    final invalid=AstroChartResult(
      julianDay: 1, ayanamsaDegrees: 0, ascendantLongitude: 0,
      engineVersion: 'fixture',
      houseCuspLongitudes: List<double>.filled(12,0),planets: const []);
    expect(KpCuspSignificatorService.compute(invalid).available,false);
  });
  test('event-specific KP marriage houses differ from SK Mehta houses', () {
    final audit=KpCuspSignificatorService.compute(sample());
    final marriage=audit.forEvent('M01')!;
    expect(marriage.primaryHouse,7);
    expect(marriage.favourableHouses,[2,7,11]);
    expect(marriage.contraryHouses,[1,6,10,12]);
    expect(audit.forEvent('M06')!.primaryHouse,5);
    expect(audit.forEvent('unknown'),isNull);
    final result=BtrIntegratedMethodService.kp('KP:test',audit:marriage);
    expect(result.method,'KP');
    expect(result.isSourceRuleMatched,false);
    expect(result.details,contains('Sub Lord'));
  });
  test('KP does not alter BTR rankings or BPD event context', () {
    final old=MehtaBtrCandidate(
      birthTime: DateTime.utc(2000,1,1),
      evidenceShare:0.5,evidence:[],timeSignature:'KP:previous');
    expect(old.evidenceShare,0.5);
    expect(old.kpChartAudit,isNull);
    expect(BtrIntegratedMethodService.kp('KP:previous').isSourceRuleMatched,false);
  });
  test('fruitful screening uses planet Star Lord and Sub Lord separately', () {
    final result = KpCuspSignificatorService.compute(sample());
    final event = result.forEvent('M01')!;
    expect(event.fruitfulSignificators, hasLength(result.planets.length));
    for (final f in event.fruitfulSignificators) {
      final p = result.planets[f.planet]!;
      expect(f.starLord, p.starLord);
      expect(f.subLord, p.subLord);
      expect(f.eventHouses.toSet().intersection(event.favourableHouses.toSet()),
          f.eventHouses.toSet());
      if (f.status == KpFruitfulStatus.candidate) {
        expect(f.eventHouses, isNotEmpty);
        expect(f.starHouses, isNotEmpty);
        expect(f.subHouses, isNotEmpty);
        expect(f.contraryStarHouses, isEmpty);
        expect(f.contrarySubHouses, isEmpty);
      }
    }
    expect(event.detail, contains('Fruitful candidates:'));
  });
  test('manual KP ruling planets only annotate findings, never change verdict', () {
    final data = KpCuspSignificatorService.compute(sample());
    final before = data.forEvent('M06')!;
    final after = data.forEvent('M06', rulingPlanets: {'Sun','Venus'})!;
    final a = after.fruitfulSignificators.firstWhere((f)=>f.planet=='Sun');
    expect(a.isRulingPlanet, true);
    final oldSun = before.fruitfulSignificators.firstWhere((f)=>f.planet=='Sun');
    expect(oldSun.status, a.status);
    expect(before.matchingHouses, after.matchingHouses);
  });
  test('nodes do not silently become confirmed fruitful candidates', () {
    final data = KpCuspSignificatorService.compute(sample());
    final event = data.forEvent('M04')!;
    for(final n in event.fruitfulSignificators.where((f)=>
        f.planet=='Rahu' || f.planet=='Ketu')) {
      expect(n.status, isNot(KpFruitfulStatus.candidate));
    }
  });
  test('no KP cusps cannot claim Fruitful Significators', () {
    final data = KpCuspSignificatorService.compute(sample(includeCusps:false));
    expect(data.forEvent('M01'), isNull);
  });

  test('fruitful screening: favourable Sub yields candidate, denying Sub is adverse', () {
    KpPlanetSignification p(String name, String star, String sub, int house) =>
        KpPlanetSignification(
          planet:name, starLord:star, subLord:sub, subSubLord:sub,
          occupiedHouse:house,
          starLordOccupied:[house],occupied:[house],
          starLordOwned:const [],owned:const [],isNode:false);
    final planets=<String,KpPlanetSignification>{
      'Sun':p('Sun','Moon','Venus',2),
      'Moon':p('Moon','Sun','Venus',2),
      'Venus':p('Venus','Moon','Venus',2),
      'Mars':p('Mars','Moon','Saturn',2),
      'Saturn':p('Saturn','Mars','Saturn',6),
    };
    final selected=KpCuspSignificatorService.selectFruitful(
      planets:planets,cusps:const [],favourable:[2],contrary:[6]);
    final sun=selected.firstWhere((p)=>p.planet=='Sun');
    final mars=selected.firstWhere((p)=>p.planet=='Mars');
    expect(sun.status,KpFruitfulStatus.candidate);
    expect(mars.status,KpFruitfulStatus.adverse);
    expect(mars.contrarySubHouses,[6]);
  });

}

// Build138 Fruitful Significator screening: separate from event certainty.
// Tests intentionally assert classification conditions, not predictions.
