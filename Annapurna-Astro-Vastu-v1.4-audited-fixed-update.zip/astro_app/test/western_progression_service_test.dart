import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/western_progression_service.dart';

void main() {
  test('0–360 tropical angles wrap without negative longitude', () {
    expect(WesternProgressionService.norm(-1), closeTo(359, 1e-9));
    expect(WesternProgressionService.norm(361), closeTo(1, 1e-9));
  });

  test('shorter angular separation crosses zero correctly', () {
    expect(WesternProgressionService.distance(359, 1), closeTo(-2, 1e-9));
    expect(WesternProgressionService.distance(1, 359), closeTo(2, 1e-9));
  });

  test('western aspects use their degree and orb, not planet keywords', () {
    final values = WesternProgressionService.contacts(
      <String, double>{'Venus': 61.1},
      <String, double>{'Moon': 1.0},
      0.25,
      'Solar Arc',
    );
    expect(values, hasLength(1));
    expect(values.first, contains('Sextile'));
  });

  test('aspects outside orb are never treated as matching', () {
    final values = WesternProgressionService.contacts(
      <String, double>{'Venus': 65},
      <String, double>{'Mars': 0},
      1,
      'Solar Arc',
    );
    expect(values, isEmpty);
  });

  test('avoid duplicate self-contact evidence', () {
    final values = WesternProgressionService.contacts(
      <String, double>{'Sun': 120},
      <String, double>{'Sun': 120},
      0.5,
      'Secondary',
      skipSelf: true,
    );
    expect(values, isEmpty);
  });
}
