import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';
import 'package:astro_app/astrology/d10_tenth_lord_analysis_service.dart';

VargaChartData _chart(int asc, Map<String, int> planets) => VargaChartData(
  definition: VargaService.definitionFor(10),
  ascendantSignIndex: asc,
  planets: planets.entries.map((e) => VargaPlacement(
    name: e.key, shortName: e.key.substring(0, 2),
    signIndex: e.value, retrograde: false,
  )).toList(),
);

void main() {
  test('Scorpio D10: Sun as tenth lord in Cancer = ninth house', () {
    final a = D10TenthLordAnalysisService.evaluate(d10: _chart(7, {
      'Sun': 3, 'Moon': 6, 'Mars': 0,
      'Mercury': 1, 'Jupiter': 4, 'Venus': 5, 'Saturn': 9,
    }));
    expect(a.tenthLord, 'Sun');
    expect(a.ascendantLord, 'Mars');
    expect(a.tenthSignIndex, 4); // Leo
    expect(a.placementSignIndex, 3); // Cancer
    expect(a.placementHouse, 9);
    expect(a.placementSignLord, 'Moon');
    expect(a.tenthLordToHostRelation, 'మిత్రుడు');
    expect(a.ascendantLordToTenthLordRelation, 'మిత్రుడు');
    expect(a.d10TenthOccupants, contains('Jupiter'));
    expect(a.dignity, contains('ఇతర రాశి'));
  });

  test('House 6 and 12 are not automatically defined as failure', () {
    expect(D10TenthLordAnalysisService.houseInterpretation(6), contains('ఒక్కటే ప్రతికూలం కాదు'));
    expect(D10TenthLordAnalysisService.houseInterpretation(12), contains('ఒక్కటే ప్రతికూలం కాదు'));
  });

  test('Classical dignity and directional friendships are distinct', () {
    expect(D10TenthLordAnalysisService.dignity('Sun', 0), 'ఉచ్చ');
    expect(D10TenthLordAnalysisService.dignity('Sun', 6), 'నీచ');
    expect(D10TenthLordAnalysisService.dignity('Saturn', 10), 'స్వక్షేత్రం');
    expect(D10TenthLordAnalysisService.naturalRelation('Moon', 'Mercury'), 'మిత్రుడు');
    expect(D10TenthLordAnalysisService.naturalRelation('Mercury', 'Moon'), 'శత్రువు');
  });

  test('D10 10th occupancy and classical aspects are independently listed', () {
    // Aries ascendant -> Capricorn (sign 9) tenth; Mars in Libra (6)
    // aspects Capricorn by its fourth aspect; Sun in Capricorn occupies it.
    final a = D10TenthLordAnalysisService.evaluate(d10: _chart(0, {
      'Sun': 9, 'Moon': 3, 'Mars': 6, 'Mercury': 2,
      'Jupiter': 1, 'Venus': 4, 'Saturn': 10,
    }));
    expect(a.tenthLord, 'Saturn');
    expect(a.d10TenthOccupants, contains('Sun'));
    expect(a.d10TenthAspectingPlanets, contains('Mars'));
    expect(a.placementHouse, 11);
  });

  test('Missing tenth lord placement is not silently fabricated', () {
    expect(() => D10TenthLordAnalysisService.evaluate(d10: _chart(7, {
      'Moon': 3, 'Mars': 0,
    })), throwsStateError);
  });

  test('D1 tenth-house occupants are separated from D10', () {
    const natal = AstroChartResult(
      julianDay: 0,
      ayanamsaDegrees: 0,
      ascendantLongitude: 225, // Scorpio
      engineVersion: 'test',
      planets: [
        PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 125,
            latitude: 0, speed: 1), // Leo = tenth from Scorpio
      ],
    );
    final a = D10TenthLordAnalysisService.evaluate(
      d10: _chart(7, {'Sun': 3, 'Moon': 5}), natal: natal);
    expect(a.d1TenthOccupants, ['Mercury']);
    expect(a.d10TenthOccupants, isEmpty);
  });
}
