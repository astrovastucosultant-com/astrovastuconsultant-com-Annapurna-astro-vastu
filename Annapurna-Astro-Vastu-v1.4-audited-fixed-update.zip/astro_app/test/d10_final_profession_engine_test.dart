import 'package:flutter_test/flutter_test.dart';

import 'package:astro_app/astrology/d10_final_profession_engine.dart';
import 'package:astro_app/astrology/d10_career_service.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/varga_service.dart';

void main() {
  test('Independent D10 tenth occupants are an evidence block without duplication', () {
    const natal = AstroChartResult(
      julianDay: 0, ayanamsaDegrees: 0, ascendantLongitude: 225,
      engineVersion: 'test',
      planets: [PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 125,
          latitude: 0, speed: 1)],
    );
    VargaChartData vargaWithSun(int sunSign) => VargaChartData(
      definition: VargaService.definitionFor(10),
      ascendantSignIndex: 7, // Scorpio -> Leo tenth -> Sun
      planets: [
        VargaPlacement(name: 'Sun', shortName: 'Su', signIndex: sunSign,
            retrograde: false),
        const VargaPlacement(name: 'Jupiter', shortName: 'Ju', signIndex: 4,
            retrograde: false), // Leo, tenth
      ],
    );
    final outside = D10FinalProfessionEngine.evaluate(
        chart: natal, d10: vargaWithSun(3));
    final bank = outside.candidates.firstWhere((x) => x.profession == 'Banking / Finance');
    expect(bank.availableEvidenceBlocks, 4);
    expect(bank.matchedEvidence, contains('D10 10వ భావంలోని Jupiter'));

    final sameSign = D10FinalProfessionEngine.evaluate(
        chart: natal, d10: vargaWithSun(4));
    final bankConj = sameSign.candidates.firstWhere((x) => x.profession == 'Banking / Finance');
    expect(bankConj.availableEvidenceBlocks, 4); // no extra duplicate block
    expect(bankConj.matchedEvidence, contains('10Lతో కలిసిన Jupiter'));
    expect(bankConj.matchedEvidence.where((x) => x.startsWith('D10 10వ భావంలోని')), isEmpty);
  });

  test('user-locked D10 sign nature classification is preserved', () {
    expect(D10FinalProfessionEngine.signNature(0), 'Technical'); // Aries
    expect(D10FinalProfessionEngine.signNature(7), 'Technical'); // Scorpio
    expect(D10FinalProfessionEngine.signNature(9), 'Technical'); // Capricorn
    expect(D10FinalProfessionEngine.signNature(10), 'Technical'); // Aquarius
    expect(D10FinalProfessionEngine.signNature(2), 'Semi-Technical'); // Gemini
    expect(D10FinalProfessionEngine.signNature(4), 'Semi-Technical'); // Leo
    expect(D10FinalProfessionEngine.signNature(5), 'Semi-Technical'); // Virgo
    expect(D10FinalProfessionEngine.signNature(3), 'Non-Technical'); // Cancer
  });

  test('27 nakshatra profession profiles are loaded', () {
    expect(D10FinalProfessionEngine.nakshatraProfiles.length, 27);
    expect(D10FinalProfessionEngine.nakshatraProfiles.first.nameTe, 'అశ్విని');
    expect(D10FinalProfessionEngine.nakshatraProfiles.last.nameTe, 'రేవతి');
  });

  test('BPHS Shayanadi validation example gives Netrapani Vicheshta', () {
    // Source validation example: Sun in 3rd nakshatra, 3rd navamsa,
    // Janma nakshatra 3, running ghati 31, Scorpio lagna=8, name anka=4.
    // Use longitude 26°40' (Krittika, 9th navamsa in Aries) would not match
    // the example's N=3, so choose an equivalent longitude where N=3 and
    // nakshatra serial is 3: 36°40' is Krittika and 3rd navamsa of Taurus.
    final r = D10FinalProfessionEngine.shayanadi(
      planet: 'Sun',
      siderealLongitude: 36 + 40 / 60,
      janmaNakshatraNumber: 3,
      birthGhati: 31,
      lagnaSignNumber: 8,
      nameAnka: 4,
    );
    expect(r.state, 'Netrapani');
    expect(r.subState, 'Vicheshta');
    expect(r.expression, 'Negligible');
  });

  test('BPHS Balaadi Yuva gives full-expression narrative', () {
    final bala = D10FinalProfessionEngine.balaadi(15); // Aries 15°
    expect(bala.state, 'Yuva');
    expect(bala.expression, contains('పూర్తి శక్తి'));
  });

  test('Indra plus Yuva transforms Job result into authority/team-lead narrative', () {
    const candidate = D10ProfessionCandidate(
      profession: 'Government / Administration',
      evidenceMatchPercent: 75,
      matchedEvidence: ['10L Sun', 'Nakshatra ఉత్తరాషాఢ'],
      availableEvidenceBlocks: 3,
      natureCompatibility: 'Semi-Technical Match',
      devataSupport: true,
    );
    final result = D10FinalProfessionResult(
      tenthLord: 'Sun',
      tenthLordSignIndex: 4,
      tenthLordSignName: 'సింహం',
      professionNature: 'Semi-Technical',
      d10TenthLordLongitude: 135,
      nakshatraIndex: 20,
      nakshatraName: 'ఉత్తరాషాఢ',
      nakshatraLord: 'Sun',
      conjunctions: const [],
      amshaDevata: D10CareerService.devataForLongitude(1),
      balaadi: const D10BalaadiResult(
        state: 'Yuva',
        expression: 'పూర్తి శక్తి',
        degreeInSign: 15,
      ),
      candidates: const [candidate],
    );
    final text = D10FinalProfessionEngine.professionNarrative(
      result: result,
      candidate: candidate,
      modeState: 'AGOCHARASHTHA',
    );
    expect(text, contains('పరిపాలన/అధికార'));
    expect(text, contains('యువావస్థ'));
    expect(text, contains('టీమ్'));
  });
}

// Build143 additive audit: tenth-house planets contribute to profession
// evidence only if not already counted as the tenth lord or conjunction.
// These are evidence-coverage checks, not tests of business success.
