import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';
import 'package:astro_app/astrology/btr_mehta_rule_bridge.dart';
import 'package:astro_app/models/birth_data.dart';
import 'package:astro_app/astrology/mehta_child_event_context.dart';

void main() {
  const chart = AstroChartResult(
    julianDay: 2460000, ayanamsaDegrees: 24,
    ascendantLongitude: 10, engineVersion: 'test',
    planets: [
      PlanetPosition(name: 'Sun', shortName: 'Su', longitude: 121, latitude: 0, speed: 1),
      PlanetPosition(name: 'Moon', shortName: 'Mo', longitude: 21, latitude: 0, speed: 13),
      PlanetPosition(name: 'Mars', shortName: 'Ma', longitude: 5, latitude: 0, speed: 0.5),
      PlanetPosition(name: 'Mercury', shortName: 'Me', longitude: 56, latitude: 0, speed: 1),
      PlanetPosition(name: 'Jupiter', shortName: 'Ju', longitude: 240, latitude: 0, speed: 0.1),
      PlanetPosition(name: 'Venus', shortName: 'Ve', longitude: 185, latitude: 0, speed: 1),
      PlanetPosition(name: 'Saturn', shortName: 'Sa', longitude: 148, latitude: 0, speed: 0.03),
      PlanetPosition(name: 'Rahu', shortName: 'Ra', longitude: 305, latitude: 0, speed: -0.02),
      PlanetPosition(name: 'Ketu', shortName: 'Ke', longitude: 125, latitude: 0, speed: -0.02),
    ],
  );

  test('direct M06 matching is separate from extra natal-D7 context', () {
    final strict = MehtaBtrService.primaryEvidenceShare(
        ['Sun', 'Jupiter', 'Mars'], ['Saturn', 'Venus', 'Venus'], 3);
    expect(strict, 0);
    final context = MehtaChildEventContext.assess(
        chart, ['Saturn', 'Venus', 'Venus']);
    expect(context.available, isTrue);
    expect(context.linkShare, inInclusiveRange(0, 1));
    expect(context.observations, isNotEmpty);
    // Showing contextual links must not silently relabel the strict match.
    expect(strict, 0);
  });

  test('an incomplete chart does not fabricate contextual support', () {
    const incomplete = AstroChartResult(
      julianDay: 2460000, ayanamsaDegrees: 24,
      ascendantLongitude: 10, engineVersion: 'stub',
      planets: [PlanetPosition(name: 'Moon', shortName: 'Mo',
        longitude: 21, latitude: 0, speed: 13)],
    );
    final result = MehtaChildEventContext.assess(
        incomplete, ['Saturn', 'Rahu', 'Saturn']);
    expect(result.available, isFalse);
    expect(result.linkShare, 0);
    expect(result.missing, isNotEmpty);
  });

  test('one level produces at most one contextual vote', () {
    final x = MehtaChildEventContext.assess(
        chart, ['Jupiter', 'Jupiter', 'Jupiter']);
    expect(x.available, isTrue);
    expect(x.linkShare, 1);
    expect(x.observations, hasLength(3));
    // Repeated graha at 3 hierarchy levels is *not* 3 separate past events.
  });

  MehtaBtrEventEvidence row(String id, DateTime d, double vim, double tri) =>
      MehtaBtrEventEvidence(
        event: MehtaBtrEvent(ruleId: id, occurredAt: d,
          reliability: 'reported'),
        ruleName: id, vimshottariShare: vim, tribhagiShare: tri,
        combinedShare: 0, minimumShare: 0, maximumShare: 0,
        sampledInstants: 1, vimshottariLords: '—', tribhagiLords: '—',
        expectedAsc: const [], expectedMoonAsc: const [],
        sourceCheck: const BtrMehtaSourceCheck(evaluated:false,matched:false,explanation:'unverified'), rankingShare: 0,
      );

  test('2009 and 2011 child-event records retain strict and contextual diagnostics', () async {
    final natal = BirthData(
      name: 'Synthetic test only',
      localDateTime: DateTime(1981, 12, 15, 15, 19, 58),
      place: 'Test', latitude: 16.3, longitude: 80.44,
      timezoneOffsetHours: 5.5,
      ayanamsa: AyanamsaType.lahiri,
    );
    final scored = await MehtaBtrService.scoreCandidate(
      natal: natal,
      candidateBirthTime: natal.localDateTime,
      events: [
        MehtaBtrEvent(ruleId: 'M06',
            occurredAt: DateTime(2009, 5, 28, 10, 10),
            timeKnown: true, reliability: 'reported'),
        MehtaBtrEvent(ruleId: 'M06',
            occurredAt: DateTime(2011, 11, 2, 8, 36),
            timeKnown: true, reliability: 'reported'),
        MehtaBtrEvent(ruleId: 'M14',
            occurredAt: DateTime(2012, 12, 5, 9, 45),
            timeKnown: true, reliability: 'reported'),
      ],
      chartCalculator: (_) async => chart,
    );
    expect(scored.evidence, hasLength(3));
    for (final r in scored.evidence.take(2)) {
      expect(r.event.ruleId, 'M06');
      expect(r.vimshottariDirectShare, inInclusiveRange(0, 1));
      expect(r.tribhagiDirectShare, inInclusiveRange(0, 1));
      expect(r.vimshottariChildContextShare, isNotNull);
      expect(r.tribhagiChildContextShare, isNotNull);
      // Strict Mehta score must stay unchanged by non-Mehta context.
      expect(r.vimshottariShare, closeTo(r.vimshottariDirectShare, 0.0000001));
      expect(r.tribhagiShare, closeTo(r.tribhagiDirectShare, 0.0000001));
      expect(r.rankingShare, inInclusiveRange(0, 1));
    }
    expect(scored.evidence[2].vimshottariChildContextShare, isNull);
    // The mock chart is NOT the user's chart; this asserts data flow only,
    // not historical accuracy or a true Mehta Rule M06 match.
  });

  test('reported events allow only cautious provisional *multi-event* selection', () {
    final rows = [
      row('M06', DateTime(2009, 5, 28), 0.1, 0.7),
      row('M06', DateTime(2011, 11, 2), 0.0, 0.65),
      row('M14', DateTime(2012, 12, 5), 0.0, 0.9),
    ];
    expect(MehtaBtrService.chooseProvisionalPeriod(
      evidence: rows, independentGroups: 3, distinctEventTypes: 2),
      isNotNull);
    expect(MehtaBtrService.chooseProvisionalPeriod(
      evidence: rows, independentGroups: 2, distinctEventTypes: 2),
      isNull);
    final conflicting = [
      row('M06', DateTime(2009, 5, 28), 0.9, 0.1),
      rows[1], rows[2],
    ];
    expect(MehtaBtrService.chooseProvisionalPeriod(
      evidence: conflicting, independentGroups: 3, distinctEventTypes: 2),
      isNull);
  });
}
