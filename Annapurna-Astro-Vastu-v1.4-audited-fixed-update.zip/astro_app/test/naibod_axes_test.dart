import 'package:flutter_test/flutter_test.dart';
import '../lib/astrology/naibod_axes.dart';

void main() {
  test('At birth the progression arc is zero and opposite axes are 180 apart', () {
    final birth = DateTime.utc(2000, 1, 1);
    final a = NaibodAxes.calculate(birthUtc: birth, targetUtc: birth,
        natalRamcDegrees: 100, latitudeDegrees: 16.3);
    expect(a.arc, closeTo(0, 1e-10));
    expect(NaibodAxes.norm(a.dsc - a.asc), closeTo(180, 1e-9));
    expect(NaibodAxes.norm(a.ic - a.mc), closeTo(180, 1e-9));
  });
  test('One tropical year advances RAMC by Naibod arc', () {
    final birth = DateTime.utc(2000, 1, 1);
    final target = birth.add(const Duration(days: 365));
    final a = NaibodAxes.calculate(birthUtc: birth, targetUtc: target,
        natalRamcDegrees: 100, latitudeDegrees: 16.3);
    expect(a.arc, closeTo(365 / NaibodAxes.tropicalYearDays *
        NaibodAxes.arcPerYear, 1e-9));
  });
}
