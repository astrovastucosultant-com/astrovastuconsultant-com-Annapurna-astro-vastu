import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/dasha_service.dart';
import 'package:astro_app/astrology/mehta_btr_service.dart';

void main() {
  test('Tribhagi is not blindly mixed with Vimshottari 50:50', () {
    expect(MehtaBtrService.periodComparisonScore(0.90,0.15,
        DashaSystemKind.tribhagi),0.15);
    expect(MehtaBtrService.periodComparisonScore(0.90,0.15,
        DashaSystemKind.vimshottari),0.90);
    // No selected system: conservative agreement, not a source-claimed 50:50.
    expect(MehtaBtrService.periodComparisonScore(0.90,0.15,null),0.15);
  });
  test('Source applicability requires documented independent events', () {
    expect(MehtaBtrService.chooseApplicablePeriod(
      vimshottariIndex:0.25,tribhagiIndex:0.85,
      verifiedIndependentGroups:2,distinctEventTypes:3),isNull);
    expect(MehtaBtrService.chooseApplicablePeriod(
      vimshottariIndex:0.25,tribhagiIndex:0.85,
      verifiedIndependentGroups:3,distinctEventTypes:1),isNull);
    expect(MehtaBtrService.chooseApplicablePeriod(
      vimshottariIndex:0.25,tribhagiIndex:0.29,
      verifiedIndependentGroups:4,distinctEventTypes:3),isNull);
    expect(MehtaBtrService.chooseApplicablePeriod(
      vimshottariIndex:0.30,tribhagiIndex:0.85,
      verifiedIndependentGroups:3,distinctEventTypes:3),
      DashaSystemKind.tribhagi);
    expect(MehtaBtrService.chooseApplicablePeriod(
      vimshottariIndex:0.91,tribhagiIndex:0.44,
      verifiedIndependentGroups:4,distinctEventTypes:3),
      DashaSystemKind.vimshottari);
  });
  test('three traceable user modes available', () {
    expect(MehtaDashaMode.values.length,3);
    expect(MehtaDashaMode.applicabilityFirst.label,contains('Mehta'));
  });
}
