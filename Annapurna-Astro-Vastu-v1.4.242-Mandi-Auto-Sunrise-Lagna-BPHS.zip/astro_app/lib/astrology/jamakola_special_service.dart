import 'package:sweph/sweph.dart';

import 'astro_calculation_service.dart';
import 'astro_models.dart';
import '../models/birth_data.dart';

/// Independent Jamakkol clock ring: NOT an ephemeris of the astronomical planets.
///
/// Reference convention (not universal across lineages): weekday lord starts
/// at 0 degrees at 06:00 local civil time; the eight planets have a fixed
/// counterclockwise separation of 45 degrees; ring moves -0.5 degrees/minute.
/// Before 06:00 the previous civil day's lord is used.
/// This is distinct from the sunrise-based, eight-part day/night Jamam.
class JamaRingPosition {
  const JamaRingPosition(this.name, this.longitude);
  final String name;
  final double longitude;
  int get signIndex => (longitude ~/ 30) % 12;
}

/// Signed time to an actual mathematical crossing of the two moving rings.
/// Negative minutes: crossing was in the past; positive: upcoming.
/// This is geometric evidence, NOT an automatic traditional prediction.
class JamaUdayaContact {
  const JamaUdayaContact(this.planet, this.minutesFromJudgement);
  final String planet;
  final double minutesFromJudgement;
}

class JamakolaSpecialResult {
  const JamakolaSpecialResult({required this.udhayam,
    required this.arudam,required this.jamaGrahas,
    required this.jamam,required this.isNight,
    required this.sunriseLocal,required this.sunsetLocal,
    required this.sunriseSunLongitude,required this.jamaContacts});

  final double udhayam;
  final double arudam;
  final List<JamaRingPosition> jamaGrahas;
  final int jamam;
  final bool isNight;
  final DateTime sunriseLocal;
  final DateTime sunsetLocal;
  final double sunriseSunLongitude;
  final List<JamaUdayaContact> jamaContacts;
}

class JamakolaSpecialService {
  static const ringOrder = <String>[
    'Sun','Mars','Jupiter','Mercury','Venus','Saturn','Moon','Snake',
  ];
  static const dayLords = <String>[
    'Moon','Mars','Mercury','Jupiter','Venus','Saturn','Sun',
  ];

  static double norm(double value) => (value % 360.0 + 360.0) % 360.0;


  /// Solar Veedhi used for the *separate* Chatra rasi of Prasna Marga.
  /// Source: Prasna Marga 9.34; explanatory example and mapping:
  /// https://jatakavedhan.wordpress.com/2016/09/
  /// 0=Mesha, 1=Vrishabha, 2=Mithuna; others are not Veedhi anchors.
  /// This mapping refers to the Sun's **sidereal sign**, not tropical zodiac.
  static int chatraVeedhiSign(double sunLongitude) {
    if (!sunLongitude.isFinite) {
      throw ArgumentError('Chatra: valid sidereal Sun longitude is required');
    }
    final sign = (norm(sunLongitude) / 30).floor();
    if (const <int>[1, 2, 3, 4].contains(sign)) return 0; // Taurus–Leo -> Aries
    if (const <int>[5, 6, 11, 0].contains(sign)) return 1; // Virgo, Libra, Pisces, Aries -> Taurus
    return 2; // Scorpio–Aquarius -> Gemini
  }

  /// Independent Chatra **sign** only. Count from Arudam to Veedhi,
  /// then take the same inclusive distance from Udhayam.
  /// Equivalently: Chatra = UdhayamSign + VeedhiSign - ArudamSign (mod 12).
  /// Source fixes the rasi, not an exact astronomical longitude, so this
  /// method must never manufacture Chatra nakshatra, degree or bhava cusp.
  static int chatraSign({
    required double sunLongitude,
    required double udhayam,
    required double arudam,
  }) {
    if (!udhayam.isFinite || !arudam.isFinite) {
      throw ArgumentError('Chatra: valid Udhayam and Arudam are required');
    }
    final u=(norm(udhayam)/30).floor();
    final a=(norm(arudam)/30).floor();
    final v=chatraVeedhiSign(sunLongitude);
    return (u+v-a+12)%12;
  }

  /// Source-traceable Kavippu transfer-of-distance rule.
  /// An independently verified Surya-Veedhi anchor sign is compulsory:
  /// sign index 0=Mesha, ..., 11=Meena. No undocumented solar-anchor
  /// mapping is assumed. Kavippu is NOT Divya Chakshu's Chatra.
  static double kavippuFromVeedhiAnchor({
    required double udhayam,
    required double arudam,
    required int anchorSignIndex,
  }) {
    if (anchorSignIndex < 0 || anchorSignIndex > 11 ||
        !udhayam.isFinite || !arudam.isFinite) {
      throw ArgumentError('Kavippu needs a valid source-verified Veedhi anchor');
    }
    final uSign = (norm(udhayam) / 30).floor();
    final aSign = (norm(arudam) / 30).floor();
    // Inclusive Arudam -> anchor count is converted to 0-based displacement.
    final signOffset = (anchorSignIndex - aSign + 12) % 12;
    final kSign = (uSign + signOffset) % 12;
    // Kavippu moves against Arudam within the rasi (30° - degree-in-sign).
    final degree = (30.0 - (norm(arudam) % 30)) % 30;
    return norm(kSign * 30.0 + degree);
  }

  /// One hour is 360 degrees, so a minute is six degrees.
  /// An independently chosen Arudam must instead be entered manually.
  static double arudamFromClock(DateTime local) => norm(6.0 *
    (local.minute + local.second / 60.0 + local.millisecond / 60000.0));

  static List<JamaRingPosition> jamaFromLocalClock(DateTime local) {
    // `local` contains the QUESTION PLACE'S CIVIL CLOCK fields. In this app
    // the selected local clock can be stored as a UTC-tagged DateTime, while
    // DateTime(y, m, d, 6) uses the device's own timezone. Mixing the two
    // causes a +05:30 error on Indian phones. Do calendar arithmetic entirely
    // in UTC-tagged wall-clock coordinates; NO UTC offset is applied here.
    // Offset belongs only to the astronomical Julian-day conversion.
    final civilDay = DateTime.utc(local.year, local.month, local.day);
    final day = local.hour < 6
        ? civilDay.subtract(const Duration(days: 1))
        : civilDay;
    final minutesSinceMidnight = local.hour * 60.0 + local.minute +
        local.second / 60.0 + local.millisecond / 60000.0 +
        local.microsecond / 60000000.0;
    final minutes = minutesSinceMidnight - 360.0 +
        (local.hour < 6 ? 1440.0 : 0.0);
    final lord = dayLords[day.weekday-1];
    final sunAtSix = ringOrder.indexOf(lord) * 45.0;
    return List<JamaRingPosition>.unmodifiable([
      for(var i=0;i<ringOrder.length;i++)
        JamaRingPosition(ringOrder[i],norm(sunAtSix - i * 45.0 - minutes * 0.5)),
    ]);
  }

  /// Crossings are computed from the relative motion: within the current
  /// sunrise/sunset segment Udayam goes +360 degrees; the Jama ring moves
  /// -0.5 degrees per minute. The window is capped at segment boundaries,
  /// since the Udayam model resets at sunrise/sunset.
  static List<JamaUdayaContact> contactsWithinSegment({
    required double udhayam,
    required List<JamaRingPosition> jamaGrahas,
    required double segmentMinutes,
    required double elapsedMinutes,
    double horizonMinutes=30,
  }) {
    if (!udhayam.isFinite || !segmentMinutes.isFinite ||
        !elapsedMinutes.isFinite || !horizonMinutes.isFinite ||
        segmentMinutes<=0 || elapsedMinutes<0 ||
        elapsedMinutes>segmentMinutes || horizonMinutes<=0) {
      throw ArgumentError('Invalid solar segment or contact time window');
    }
    final relativeRate=360.0/segmentMinutes+0.5; // degrees/minute
    final lookBack=elapsedMinutes<horizonMinutes
        ?elapsedMinutes:horizonMinutes;
    final lookAhead=segmentMinutes-elapsedMinutes<horizonMinutes
        ?segmentMinutes-elapsedMinutes:horizonMinutes;
    const eps=1e-8;
    final found=<JamaUdayaContact>[];
    for(final j in jamaGrahas) {
      final angle=norm(j.longitude-udhayam);
      if(angle<eps || 360-angle<eps) {
        found.add(JamaUdayaContact(j.name,0));
        continue;
      }
      final past=(360-angle)/relativeRate;
      final future=angle/relativeRate;
      if(past<=lookBack+eps) {
        found.add(JamaUdayaContact(j.name,-past));
      }
      if(future<=lookAhead+eps) {
        found.add(JamaUdayaContact(j.name,future));
      }
    }
    found.sort((a,b)=>a.minutesFromJudgement.compareTo(b.minutesFromJudgement));
    return List.unmodifiable(found);
  }

  static double _jd(DateTime d) => Sweph.swe_julday(d.year,d.month,d.day,
    d.hour+d.minute/60+d.second/3600+d.millisecond/3600000,
    CalendarType.SE_GREG_CAL);

  static DateTime _utcFromJd(double jd) => DateTime.utc(1970,1,1).add(
    Duration(microseconds:((jd-2440587.5)*86400000000).round()));

  static double? _riseSet(double startJd, double longitude,double latitude,
      RiseSetTransitFlag which) {
    final value=Sweph.swe_rise_trans(startJd,HeavenlyBody.SE_SUN,
      SwephFlag.SEFLG_MOSEPH,which,GeoPosition(longitude,latitude),0,0);
    return value!=null && value.isFinite ? value : null;
  }

  /// Udhayam in the solar-half Jamakkol convention, distinct from ordinary
  /// Lagna. Sun's sidereal sunrise longitude travels +360° through daylight,
  /// then +360° through the ensuing night. No fallback approximation is used.
  static Future<JamakolaSpecialResult> calculate({
    required DateTime local,
    required double latitude,
    required double longitude,
    required double offsetHours,
    required AyanamsaType ayanamsa,
    required AstroChartResult chart,
  }) async {
    if(latitude.abs()>66 || longitude.abs()>180 ||
      offsetHours < -12 || offsetHours > 14) {
      throw StateError('Jamakkol sunrise model: Latitude ±66° మరియు సరైన Longitude/Timezone అవసరం.');
    }
    final offset=Duration(minutes:(offsetHours*60).round());
    final midnightLocal=DateTime.utc(local.year,local.month,local.day);
    final midnightUtc=midnightLocal.subtract(offset);
    final sunriseToday=_riseSet(_jd(midnightUtc),longitude,latitude,
        RiseSetTransitFlag.SE_CALC_RISE);
    if(sunriseToday==null) throw StateError('స్థానిక సూర్యోదయం గణించలేకపోయాం.');
    final sunsetToday=_riseSet(sunriseToday+0.005,longitude,latitude,
        RiseSetTransitFlag.SE_CALC_SET);
    final sunriseTomorrow=sunsetToday==null?null:
      _riseSet(sunsetToday+0.005,longitude,latitude,
        RiseSetTransitFlag.SE_CALC_RISE);
    if(sunsetToday==null || sunriseTomorrow==null) {
      throw StateError('సూర్యాస్తమయం/తదుపరి సూర్యోదయం లభించలేదు.');
    }
    final t=chart.julianDay;
    late final double solarStart, solarEnd, sourceSunrise;
    late final bool night;
    late final DateTime displayRise, displaySet;
    if(t<sunriseToday) {
      final yesterdayRise=_riseSet(_jd(midnightUtc)-1.0,longitude,latitude,
        RiseSetTransitFlag.SE_CALC_RISE);
      final yesterdaySet=yesterdayRise==null?null:
        _riseSet(yesterdayRise+0.005,longitude,latitude,
          RiseSetTransitFlag.SE_CALC_SET);
      if(yesterdayRise==null || yesterdaySet==null) {
        throw StateError('మునుపటి సూర్యాస్తమయం లభించలేదు.');
      }
      solarStart=yesterdaySet; solarEnd=sunriseToday;
      sourceSunrise=yesterdayRise; night=true;
      displayRise=_utcFromJd(yesterdayRise).add(offset);
      displaySet=_utcFromJd(yesterdaySet).add(offset);
    } else if(t>=sunsetToday) {
      solarStart=sunsetToday; solarEnd=sunriseTomorrow;
      sourceSunrise=sunriseToday; night=true;
      displayRise=_utcFromJd(sunriseToday).add(offset);
      displaySet=_utcFromJd(sunsetToday).add(offset);
    } else {
      solarStart=sunriseToday; solarEnd=sunsetToday;
      sourceSunrise=sunriseToday; night=false;
      displayRise=_utcFromJd(sunriseToday).add(offset);
      displaySet=_utcFromJd(sunsetToday).add(offset);
    }
    if(solarEnd<=solarStart || t<solarStart || t>solarEnd) {
      throw StateError('సౌర జామ వ్యవధి సరిపోలలేదు.');
    }
    final solarSun=await AstroCalculationService.calculatePlanetAtUtc(
      utc:_utcFromJd(sourceSunrise),planetName:'Sun',ayanamsa:ayanamsa);
    final ratio=((t-solarStart)/(solarEnd-solarStart)).clamp(0.0,1.0);
    final udhayam=norm(solarSun.longitude+360.0*ratio);
    final jamam=(ratio*8).floor().clamp(0,7).toInt()+1;
    final ring=jamaFromLocalClock(local);
    final contacts=contactsWithinSegment(
      udhayam:udhayam,
      jamaGrahas:ring,
      segmentMinutes:(solarEnd-solarStart)*1440.0,
      elapsedMinutes:(t-solarStart)*1440.0,
    );
    return JamakolaSpecialResult(
      udhayam:udhayam,
      arudam:arudamFromClock(local),
      jamaGrahas:ring,jamaContacts:contacts,
      jamam:jamam,isNight:night,
      sunriseLocal:displayRise,sunsetLocal:displaySet,
      sunriseSunLongitude:solarSun.longitude,
    );
  }
}
