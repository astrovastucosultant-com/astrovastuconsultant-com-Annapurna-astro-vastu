import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../astrology/kp_event_judgement_service.dart';
import '../astrology/unified_prashna_service.dart';
import '../models/birth_data.dart';
import '../services/place_search_service.dart';

/// One question moment is frozen when Calculate is pressed. None of the
/// three systems silently switches to the natal epoch or natal houses.
class UnifiedPrashnaScreen extends StatefulWidget {
  const UnifiedPrashnaScreen({super.key,required this.birthData});
  final BirthData birthData;
  @override State<UnifiedPrashnaScreen> createState()=>_UnifiedPrashnaScreenState();
}

class _UnifiedPrashnaScreenState extends State<UnifiedPrashnaScreen> {
  late final Future<List<KpEventRule>> _catalog;
  late final TextEditingController _question,_place,_lat,_lon,_tz,_number;
  late DateTime _moment;
  String? _category,_eventId;
  Future<UnifiedPrashnaReport>? _result;
  bool _working=false;
  bool _searchingPlace=false;

  static const _maroon=Color(0xFF79202E);
  @override void initState(){
    super.initState();
    _catalog=KpEventRuleCatalog.load();
    _question=TextEditingController();
    _place=TextEditingController(text:widget.birthData.place);
    _lat=TextEditingController(text:widget.birthData.latitude.toStringAsFixed(5));
    _lon=TextEditingController(text:widget.birthData.longitude.toStringAsFixed(5));
    _tz=TextEditingController(text:widget.birthData.timezoneOffsetHours.toString());
    _number=TextEditingController();
    _moment=DateTime.now().toUtc().add(Duration(
      minutes:(widget.birthData.timezoneOffsetHours*60).round()));
  }

  @override void dispose(){
    for(final c in <TextEditingController>[_question,_place,_lat,_lon,_tz,_number]){c.dispose();}
    super.dispose();
  }

  String _formatMoment(DateTime d)=>
    '${d.day.toString().padLeft(2,'0')}-${d.month.toString().padLeft(2,'0')}-${d.year} '
    '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}:'
    '${d.second.toString().padLeft(2,'0')}';

  Widget _field(TextEditingController c,String label,{bool numeric=false,
    int lines=1})=>TextField(controller:c,maxLines:lines,
      onChanged:(_){if(_result!=null)setState(()=>_result=null);},
      keyboardType:numeric?const TextInputType.numberWithOptions(decimal:true,signed:true):
        (lines>1?TextInputType.multiline:TextInputType.text),
      decoration:InputDecoration(labelText:label,isDense:true,
        border:const OutlineInputBorder()));

  Future<void> _date() async {
    final d=await showDatePicker(context:context,
      initialDate:_moment,firstDate:DateTime(1900),lastDate:DateTime(2100));
    if(d!=null&&mounted)setState((){
      _moment=DateTime(d.year,d.month,d.day,
        _moment.hour,_moment.minute,_moment.second);
      _result=null;
    });
  }
  Future<void> _time() async {
    final t=await showTimePicker(context:context,
      initialTime:TimeOfDay(hour:_moment.hour,minute:_moment.minute));
    if(t!=null&&mounted)setState((){
      _moment=DateTime(_moment.year,_moment.month,
        _moment.day,t.hour,t.minute,0);
      _result=null;
    });
  }

  Future<void> _searchPlace() async {
    if(_searchingPlace)return;
    setState(()=>_searchingPlace=true);
    try {
      final places=await PlaceSearchService.search(_place.text);
      if(!mounted)return;
      if(places.isEmpty){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content:Text('స్థలం కనిపించలేదు. మరో గ్రామం/పట్టణం పేరు ప్రయత్నించండి.')));
        return;
      }
      await showModalBottomSheet<void>(context:context,isScrollControlled:true,
        builder:(sheet)=>SafeArea(child:ConstrainedBox(
          constraints:BoxConstraints(maxHeight:MediaQuery.sizeOf(sheet).height*.7),
          child:ListView(children:[
            const ListTile(title:Text('ప్రశ్న స్థలం ఎంచుకోండి')),
            for(final item in places) ListTile(
              title:Text(item.displayName),
              subtitle:Text('${item.latitude}, ${item.longitude}'),
              onTap:(){
                _place.text=item.displayName;
                _lat.text=item.latitude.toStringAsFixed(6);
                _lon.text=item.longitude.toStringAsFixed(6);
                setState(()=>_result=null);
                Navigator.pop(sheet);
              }),
          ]))));
    } catch(e){
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text('స్థలం వెతకలేకపోయాం: $e')));
    } finally {
      if(mounted)setState(()=>_searchingPlace=false);
    }
  }

  void _analyze(KpEventRule event) {
    final lat=double.tryParse(_lat.text.trim());
    final lon=double.tryParse(_lon.text.trim());
    final tz=double.tryParse(_tz.text.trim());
    final rawNumber=_number.text.trim();
    final number=rawNumber.isEmpty?null:int.tryParse(rawNumber);
    if(_question.text.trim().isEmpty||lat==null||lon==null||tz==null||
      _place.text.trim().isEmpty||(rawNumber.isNotEmpty&&number==null)||
      lat.abs()>66||lon.abs()>180||tz < -12||tz>14||
      (number!=null&&(number<1||number>249))){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text(
        'ప్రశ్న, స్థలం, అక్షాంశం (±66°), రేఖాంశం, UTC Offset, KP సంఖ్య (1–249) సరిచూడండి.')));
      return;
    }
    final input=BirthData(name:widget.birthData.name,
      localDateTime:_moment,place:_place.text.trim(),latitude:lat,
      longitude:lon,timezoneOffsetHours:tz,
      ayanamsa:widget.birthData.ayanamsa,gender:widget.birthData.gender);
    setState((){
      _working=true;
      _result=UnifiedPrashnaService.analyze(input:input,event:event,
        question:_question.text.trim(),horaryNumber:number);
      _result!.then((_) {
        if(mounted)setState(()=>_working=false);
      },onError:(Object error,StackTrace trace) {
        if(mounted)setState(()=>_working=false);
      });
    });
  }

  @override Widget build(BuildContext context){
    return FutureBuilder<List<KpEventRule>>(future:_catalog,builder:(context,snap){
      final all=snap.data??<KpEventRule>[];
      final categories=all.map((r)=>r.category).toSet().toList()..sort();
      final selected=all.where((r)=>r.category==_category).toList();
      final chosen=selected.where((r)=>r.id==_eventId).firstOrNull;
      return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        const Text('Unified Prashna — ఒకే ప్రశ్న, మూడు పద్ధతులు',
          style:TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:_maroon)),
        const SizedBox(height:8),
        const Text('జామకోళ + KP ప్రశ్న సమయ చక్రం / 1–249 + తాజిక. '
          'జన్మ సమయాన్ని ప్రశ్న సమయంగా తీసుకోము; కింద మీరు ఎంచుకున్న '
          'సమయాన్నే మూడు పద్ధతులకూ ఉపయోగిస్తాం.'),
        const SizedBox(height:14),
        if(snap.hasError)Text('KP 414 సంఘటనల జాబితా చదవలేకపోయాం: ${snap.error}',
          style:const TextStyle(color:Colors.red)),
        if(!snap.hasData&&!snap.hasError)const LinearProgressIndicator(),
        if(snap.hasData)...[
          DropdownButtonFormField<String>(
            value:_category,isExpanded:true,
            decoration:const InputDecoration(labelText:'ప్రశ్న అంశం',border:OutlineInputBorder()),
            items:categories.map((s)=>DropdownMenuItem(value:s,
              child:Text(s,overflow:TextOverflow.ellipsis))).toList(),
            onChanged:(v)=>setState((){_category=v;_eventId=null;_result=null;})),
          const SizedBox(height:10),
          DropdownButtonFormField<String>(
            key:ValueKey('prashna-event-${_category??'none'}'),
            value:_eventId,isExpanded:true,
            decoration:const InputDecoration(labelText:'ఒకే KP సంఘటన ఎంచుకోండి',
              border:OutlineInputBorder()),
            items:selected.map((r)=>DropdownMenuItem<String>(value:r.id,
              child:Text('${r.name} · ${r.id}',overflow:TextOverflow.ellipsis))).toList(),
            onChanged:_category==null?null:(v)=>setState((){_eventId=v;_result=null;})),
          const SizedBox(height:12),
        ],
        _field(_question,'మీ ప్రశ్నను స్పష్టంగా నమోదు చేయండి',lines:2),
        const SizedBox(height:10),
        Row(children:[
          Expanded(child:QuestionMomentField(value:_formatMoment(_moment))),
          const SizedBox(width:5),
          IconButton(onPressed:_date,tooltip:'తేదీ',icon:const Icon(Icons.calendar_today)),
          IconButton(onPressed:_time,tooltip:'సమయం',icon:const Icon(Icons.access_time)),
          IconButton(onPressed:()=>setState((){
            _moment=DateTime.now().toUtc().add(
              Duration(minutes:((double.tryParse(_tz.text) ?? 5.5)*60).round()));
            _result=null;
          }),
            tooltip:'NOW',icon:const Icon(Icons.update)),
        ]),
        const SizedBox(height:10),
        Row(children:[
          Expanded(child:_field(_place,'ప్రశ్న అడిగిన స్థలం')),
          const SizedBox(width:6),
          IconButton.filledTonal(onPressed:_searchingPlace?null:_searchPlace,
            tooltip:'Place Search',icon:Icon(_searchingPlace
              ?Icons.hourglass_empty:Icons.search)),
        ]),
        const SizedBox(height:10),
        Row(children:[
          Expanded(child:_field(_lat,'Latitude',numeric:true)),
          const SizedBox(width:8),
          Expanded(child:_field(_lon,'Longitude',numeric:true)),
          const SizedBox(width:8),
          Expanded(child:_field(_tz,'UTC +',numeric:true)),
        ]),
        const SizedBox(height:10),
        _field(_number,'KP Horary Number 1–249 (ఐచ్ఛికం)',numeric:true),
        const SizedBox(height:6),
        const Text('స్థలం పేరు మార్చితే అక్షాంశం/రేఖాంశం స్వయంగా మారవు; '
          'కచ్చితమైన ప్రశ్న స్థల కోఆర్డినేట్లను సరిచూడండి.',
          style:TextStyle(color:Colors.deepOrange,fontSize:12)),
        const SizedBox(height:12),
        FilledButton.icon(onPressed:_working||chosen==null?null:()=>_analyze(chosen),
          icon:const Icon(Icons.fact_check_outlined),
          label:Text(_working?'గణన జరుగుతోంది':'మూడు పద్ధతుల్లో ప్రశ్న పరిశీలించండి')),
        const SizedBox(height:14),
        if(_result!=null)FutureBuilder<UnifiedPrashnaReport>(future:_result,
          builder:(context,result){
            if(result.hasError)return Text('గణన సాధ్యం కాలేదు: ${result.error}',
              style:const TextStyle(color:Colors.red));
            if(!result.hasData)return const LinearProgressIndicator();
            return _report(result.data!);
          }),
      ]);
    });
  }

  String _degrees(double longitude) {
    final total=(longitude*3600).round()%(360*3600);
    final d=total~/3600, m=(total%3600)~/60, sec=total%60;
    return '$d° ${m.toString().padLeft(2,'0')}′ ${sec.toString().padLeft(2,'0')}″';
  }

  Widget _report(UnifiedPrashnaReport r){
    final number=r.kpNumber;
    final tajik=r.tajik;
    final preliminary=r.supportingEvidence.isNotEmpty;
    final text='ప్రశ్న: ${r.question}\nఅంశం: ${r.event.name}\n'
      'స్థలం: ${r.input.place} (${r.input.latitude}, ${r.input.longitude})\n'
      'సమయం: ${_formatMoment(r.input.localDateTime)} UTC ${r.input.timezoneOffsetHours}\n'
      'ఏకీకృత పరిశీలన: ${r.verdict}\n'
      'ఆధారాలు: ${r.supportingEvidence.join('; ')}\n'
      'పెండింగ్: ${r.pendingEvidence.join('; ')}\n'
      'సమయ నిర్ధారణ: ${r.timingStatus}\n'
      'KP Time Chart: ${r.kpTime.decision}\n'
      '${number==null?'KP Number Chart: ఇవ్వలేదు':'KP Number Chart: ${number.decision}'}\n'
      'Tajik: ${tajik.explanation}\n'
      'Jamakola: ${r.jamakolaIndications.join('; ')}\n'
      'ఎనిమిది జామ గ్రహాలు: ${r.jamakola.jamaGrahas.map((p)=>'${p.name} ${_degrees(p.longitude)}').join('; ')}\n'
      'గమనిక: పూర్తి Promise/Denial లేదా ఖచ్చిత సంఘటన సమయం ధృవీకరించబడలేదు.';
    Widget section(String title,String body)=>Padding(
      padding:const EdgeInsets.symmetric(vertical:6),
      child:ExpansionTile(title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700)),
        children:[Padding(padding:const EdgeInsets.all(12),
          child:Align(alignment:Alignment.centerLeft,child:SelectableText(body)))]));
    return Card(clipBehavior:Clip.antiAlias,child:Padding(
      padding:const EdgeInsets.all(12),child:Column(
        crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Text('ఒకే ప్రశ్నకు సమగ్ర పరిశీలన',
          style:Theme.of(context).textTheme.titleLarge),
        const SizedBox(height:7),
        Text(r.verdict,style:TextStyle(fontSize:17,fontWeight:FontWeight.w800,
          color:preliminary?Colors.indigo.shade700:Colors.deepOrange)),
        const SizedBox(height:6),
        Text('ప్రశ్న: ${r.question}',style:const TextStyle(fontWeight:FontWeight.w600)),
        Text('సమయం: ${_formatMoment(r.input.localDateTime)} · ${r.input.place}'),
        const SizedBox(height:10),
        Text('1. సంఘటన జరుగుతుందా? — ఫలితం',
          style:Theme.of(context).textTheme.titleMedium),
        const SizedBox(height:5),
        Text(r.verdict,style:const TextStyle(fontWeight:FontWeight.w700)),
        if(r.supportingEvidence.isNotEmpty)Padding(
          padding:const EdgeInsets.only(top:8),
          child:Text('ప్రాథమిక అనుకూల ఆధారాలు:\n'
            '${r.supportingEvidence.map((e)=>'• $e').join('\n')}',
            style:TextStyle(color:Colors.indigo.shade700))),
        const SizedBox(height:8),
        Text('2. ఎప్పుడు? — సమయ నిర్ధారణ',
          style:Theme.of(context).textTheme.titleMedium),
        Padding(padding:const EdgeInsets.symmetric(vertical:6),
          child:Text(r.timingStatus,
            style:const TextStyle(color:Colors.deepOrange))),
        section('3. ఇంకా పరీక్షించాల్సిన ఆధారాలు',
          r.pendingEvidence.map((e)=>'• $e').join('\n')),
        if(r.conflicts.isNotEmpty)Padding(
          padding:const EdgeInsets.symmetric(vertical:8),child:Text(
            'వ్యత్యాసాలు:\n${r.conflicts.join('\n')}',
            style:const TextStyle(color:Colors.deepOrange))),
        section('4. KP Time Chart — ప్రశ్న సమయం',
          '${r.kpTime.decision}\n${r.kpTime.explanation}\n'
          'సరిపోయిన భావాలు: ${r.kpTime.matchedHouses.join(', ')}'),
        section('5. KP 1–249 Number Chart',number==null
          ? 'ప్రశ్న సంఖ్య ఇవ్వలేదు. స్వతంత్ర KP Time Chart మాత్రమే ఉపయోగించాం.'
          : '${number.decision}\n${number.explanation}\n'
            'సరిపోయిన భావాలు: ${number.matchedHouses.join(', ')}'),
        section('6. Jamakola — నియమాల పరిశీలన',
          '${r.jamakolaIndications.join('\n')}\n'
          'ఎనిమిది జామ గ్రహాల డిగ్రీలు:\n'
          '${r.jamakola.jamaGrahas.map((p)=>'${p.name}: ${_degrees(p.longitude)}').join('\n')}\n\n'
          '${r.jamakolaRules.isEmpty?'ఈ అంశానికి నిర్ధారిత IF షరతు సరిపోలలేదు. '
            'ఇది ప్రతికూల ఫలితం కాదు.':r.jamakolaRules.map((e)=>
            '${e.id}: ${e.result}\nమూలం: ${e.sourceFile} — ${e.sourcePage}').join('\n\n')}'),
        section('7. Tajik — ఇత్తశాల / ఈసరాఫా',
          'లగ్నాధిపతి: ${tajik.lagnaLord} · '
          'ప్రశ్న భావాధిపతి: ${tajik.questionLord}\n'
          '${tajik.explanation}\n'
          'కోణ దూరం: ${tajik.distanceDegrees?.toStringAsFixed(3)??'—'}° · '
          'దీప్తాంశ పరిధి: ${tajik.orbDegrees?.toStringAsFixed(2)??'—'}°'),
        const SizedBox(height:8),
        const Text('మూడు పద్ధతుల్లో ప్రాథమిక ఆధారాలు మాత్రమే. KP పూర్తి Star/Sub '
          'Promise–Denial, Tajik 16 యోగాలు/Radda, GK Kavippu ధృవీకరణ '
          'మరియు సంఘటన సమయ నిర్ణయం ఇంకా పూర్తికాలేదు. '
          'ఇది ఖచ్చిత సంఘటన హామీ లేదా శాస్త్రీయ సంభావ్యత కాదు.',
          style:TextStyle(fontSize:12,color:Colors.deepOrange)),
        Align(alignment:Alignment.centerRight,child:TextButton.icon(
          onPressed:()=>Clipboard.setData(ClipboardData(text:text)),
          icon:const Icon(Icons.copy),label:const Text('నివేదిక కాపీ'))),
      ])));
  }
}

class QuestionMomentField extends StatelessWidget {
  const QuestionMomentField({super.key,required this.value});
  final String value;
  @override Widget build(BuildContext context)=>
    InputDecorator(decoration:const InputDecoration(
      labelText:'ప్రశ్న సమయం (స్థానిక)',border:OutlineInputBorder()),
      child:Text(value,style:const TextStyle(fontWeight:FontWeight.w700)));
}
