import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/multi_chart_topic_service.dart';
import 'package:astro_app/astrology/varga_unified_rule_service.dart';
import 'package:astro_app/screens/topic_result_card_v391.dart';
import 'package:astro_app/screens/unified_varga_results_tab.dart';

void main() {
  final chart = AstroChartResult(
    julianDay: 2451545,
    ayanamsaDegrees: 24,
    ascendantLongitude: 4,
    engineVersion: 'fixture',
    planets: [
      for (final e in {
        'Sun': 235.0,
        'Moon': 115.1369,
        'Mars': 156.1172,
        'Mercury': 242.4142,
        'Jupiter': 189.8097,
        'Venus': 280.4494,
        'Saturn': 176.7767,
        'Rahu': 75.0,
        'Ketu': 255.0,
      }.entries)
        PlanetPosition(
          name: e.key,
          shortName: e.key,
          longitude: e.value,
          latitude: 0,
          speed: 1,
        ),
    ],
  );
  const summary = MultiChartTopicEvidence(
    name: 'ప్రభుత్వ ఉద్యోగం',
    chartOrderSourceId: 'VARGA-CROSS-001',
    note: 'fixture source order',
    stages: [
      TopicStageEvidence(
        factor: 1,
        status: TopicStageStatus.matched,
        ruleIds: ['fixture-rule'],
        ruleText: 'IF fixture source condition',
        details: 'D1 fixture inspection',
        source: 'fixture page 1',
        result: 'fixture supportive result',
        polarity: TopicPolarity.supportive,
      ),
      TopicStageEvidence(
        factor: 9,
        status: TopicStageStatus.notMatched,
        ruleIds: ['fixture-d9'],
        ruleText: 'IF D9 fixture',
        details: 'D9 did not match',
      ),
      TopicStageEvidence(
        factor: 10,
        status: TopicStageStatus.insufficientEvidence,
        ruleIds: [],
        details: 'D10 fixture details',
      ),
    ],
  );
  testWidgets(
    'result tap opens source rule directly and chart button keeps grid',
    (tester) async {
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: TopicResultCard391(chart: chart, summary: summary),
          ),
        ),
      );
      await tester.tap(find.text('ప్రభుత్వ ఉద్యోగం'));
      await tester.pumpAndSettle();
      expect(find.text('IF fixture source condition'), findsOneWidget);
      expect(find.text('D1 fixture inspection'), findsOneWidget);
      expect(find.text('మూలం: fixture page 1'), findsOneWidget);
      expect(find.text('fixture supportive result'), findsOneWidget);
      expect(find.textContaining('D9 did not match'), findsOneWidget);
      await tester.tap(find.byTooltip('మూసివేయి'));
      await tester.pumpAndSettle();
      await tester.tap(
        find.byKey(const ValueKey('topic-charts-VARGA-CROSS-001')),
      );
      await tester.pumpAndSettle();
      expect(
        find.textContaining('పరిశీలించాల్సిన వర్గచక్రాలు'),
        findsOneWidget,
      );
      expect(find.text('D1'), findsOneWidget);
      expect(find.text('D9'), findsOneWidget);
      expect(find.text('D10'), findsOneWidget);
      expect(tester.takeException(), isNull);
    },
  );
  testWidgets(
    'mobile header hides filters by default and keeps search functional',
    (tester) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = const Size(360, 700);
      addTearDown(tester.view.resetDevicePixelRatio);
      addTearDown(tester.view.resetPhysicalSize);
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: MediaQuery(
              data: const MediaQueryData(textScaler: TextScaler.linear(1.3)),
              child: UnifiedVargaResultsTab(
                chart: chart,
                initialRules: Future<List<UnifiedVargaRule>>.value([]),
              ),
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('గ్రహ డిగ్రీ బలం + షడ్వర్గ ఆధారాలు'), findsNothing);
      expect(find.byKey(const ValueKey('varga-search-391')), findsOneWidget);
      expect(
        tester.getTopLeft(find.byType(TopicResultCard391).first).dy,
        lessThan(125),
      );
      await tester.tap(find.byKey(const ValueKey('varga-filters-391')));
      await tester.pumpAndSettle();
      expect(find.text('గ్రహ డిగ్రీ బలం + షడ్వర్గ ఆధారాలు'), findsOneWidget);
      await tester.tap(find.byKey(const ValueKey('varga-filters-391')));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byKey(const ValueKey('varga-search-391')),
        'ప్రభుత్వ ఉద్యోగం',
      );
      await tester.pumpAndSettle();
      expect(
        find.descendant(
          of: find.byType(TopicResultCard391),
          matching: find.text('ప్రభుత్వ ఉద్యోగం'),
        ),
        findsOneWidget,
      );
      expect(find.text('వ్యాపారం'), findsNothing);
      expect(tester.takeException(), isNull);
    },
  );
}
