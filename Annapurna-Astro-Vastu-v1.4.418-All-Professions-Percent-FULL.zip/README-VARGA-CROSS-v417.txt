Annapurna Astro Vastu – v1.4.417 Cross-Varga Topic Navigation
Source base: v1.4.416-Varga-Review-FULL from user's Library.

Change summary:
- All 19 VargaTopicsPanel tabs now expose a collapsed "related divisional chart review" link.
- On tap it evaluates only the existing MultiChartTopicService source-bound topics
  for the selected divisional factor. D2 includes the dedicated wealth summary.
- Each topic opens the already implemented Rule → horoscope examination → result
  and multi-chart preview with Rule IDs/source, rather than inventing chart results.
- Profession suggestions remain inside relevant career topics and D10 remains the
  primary profession evidence. D1/D9 and additional vargas are audit/support only.
- Unsupported cross-topic mappings state they are unavailable, rather than
  generating false matches or remedy recommendations.
- Existing individual IF–THEN results, calculations, statuses and % unchanged.

Changed files:
 astro_app/lib/screens/varga_cross_links_v417.dart (new)
 astro_app/lib/screens/varga_topics_panel.dart
 astro_app/pubspec.yaml (version bump)
 astro_app/test/varga_cross_links_v417_test.dart (new)

Testing: Added Flutter test. Flutter/Dart CLI was not available in the
working container, so Flutter tests and Android APK compilation were not run.
The output is SOURCE ZIP, not an installable APK.
