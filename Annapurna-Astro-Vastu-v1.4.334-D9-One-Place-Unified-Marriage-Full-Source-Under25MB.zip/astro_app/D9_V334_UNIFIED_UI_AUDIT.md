# Annapurna Astro Vastu v1.4.334 — D9 unified interface audit

## User-facing change
- All D9 report surfaces now share **one D9 workspace below the D9 chart**.
- Four expandable groups: (1) matching results & timing; (2) printed rulebook/checklist; (3) planetary strength/Panchadha Maitri; (4) topics, SAV/BAV/PAV, calculation source audit.
- Three routes that opened the very same 43-rule checklist are reduced to one checklist entry. Six source PDF pages still open independently from the same workspace.
- Other 18 vargas preserve their former layout. Existing handwritten MM-R D9 duplicates remain suppressed, historical catalog preserved.

## D9 timing reporting correction
- An identical MD/AD interval is no longer printed separately as three independent annual candidate results.
- One row now describes one MD/AD date range, and evidence percent remains coverage of evaluated conditions, **not prediction probability**.
- D7 Ketu Sutra-35 is explicitly worded as support for review, not a deterministic divorce verdict.

## Source preservation and limits
- Base: original full v1.4.333 ZIP (900 entries).
- All base entries preserved. Existing files modified: `lib/screens/chart_screen.dart`, `lib/astrology/d9_marriage_service.dart`, `pubspec.yaml`.
- New files: `test/d9_unified_workspace_v334_test.dart`, this audit report and `tool/verify_d9_unified_v334.sh`.
- The available printed source is currently **43 IF–THEN clauses in 6 pages**, not a verified 44-rule computed set. Do not misstate coverage.
- No astrological interpretation thresholds, printed rules or 19 chart definitions changed.

## QA
- ZIP CRC, preservation and static contracts validated at packaging time.
- Flutter SDK was unavailable in the local execution environment: no claim of successful Flutter analyze, tests or APK compilation.
- `tool/verify_d9_unified_v334.sh` runs targeted analysis/tests and the release APK build in a Flutter-enabled environment.
