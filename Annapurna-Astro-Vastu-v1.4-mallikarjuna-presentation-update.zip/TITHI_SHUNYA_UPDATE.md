TITHI-SHUNYA-01
Source: User-provided image table, 2026-10-20.
Birth tithi determined from Sun-Moon elongation by existing VedicCalculationService.
Pratipad 7,10; Dvitiya 9,12; Tritiya 5,10; Chaturthi 11,2; Panchami 3,6; Shashti 1,5; Saptami 9,4; Ashtami 3,6; Navami 5,8; Dashami 5,8; Ekadashi 9,12; Dvadashi 7,10; Trayodashi 2,5; Chaturdashi 3,6. Amavasya/Purnima none.
Source image has a duplicate Chaturdashi at serial 15; treated as duplicate, not an extra tithi.
Rashi lords derived from standard sign rulership. Shows matching natal planet placements, no unsupported predictive claims.
Flutter/Dart binaries unavailable here; APK build untested.
