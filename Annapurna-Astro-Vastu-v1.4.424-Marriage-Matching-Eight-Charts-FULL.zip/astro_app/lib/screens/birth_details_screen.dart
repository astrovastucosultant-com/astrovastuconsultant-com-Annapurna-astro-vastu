import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/birth_data.dart';
import '../services/place_search_service.dart';
import '../services/place_storage_service.dart';
import 'chart_screen.dart';
import 'event_timing_screen.dart';
import 'saved_reports_screen.dart';

/// Two direct Home shortcuts; do not mistake these for birth-chart buttons.
class HomePrashnaShortcutBar extends StatelessWidget {
  const HomePrashnaShortcutBar({
    super.key,
    required this.onKpTimeChart,
    required this.onJamakola,
  });

  final VoidCallback onKpTimeChart;
  final VoidCallback onJamakola;

  @override
  Widget build(BuildContext context) {
    Widget shortcut(String title, Key key, VoidCallback onTap) =>
        Expanded(child: SizedBox(height: 52, child: FilledButton(
          key: key,
          onPressed: onTap,
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF20803B),
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
          ),
          child: Text(title, textAlign: TextAlign.center, maxLines: 2,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
        )));

    return Row(mainAxisSize: MainAxisSize.min, children: [
      shortcut('KP Time\nChart', const ValueKey('birth-kp-time-quick-tab'), onKpTimeChart),
      const SizedBox(width: 8),
      shortcut('జామకోళ\nJamakola', const ValueKey('birth-jamakola-quick-tab'), onJamakola),
    ]);
  }
}

class BirthDetailsScreen extends StatefulWidget {
  const BirthDetailsScreen({super.key});

  @override
  State<BirthDetailsScreen> createState() => _BirthDetailsScreenState();
}

class _BirthDetailsScreenState extends State<BirthDetailsScreen> {
  final nameController = TextEditingController();
  final placeController = TextEditingController();
  final latitudeController = TextEditingController();
  final longitudeController = TextEditingController();
  final secondsController = TextEditingController(text: '00');
  final timezoneController = TextEditingController(text: '5.5');

  DateTime selectedDate = DateTime.now();
  TimeOfDay selectedTime = TimeOfDay.now();
  AyanamsaType selectedAyanamsa = AyanamsaType.lahiri;
  BirthGender selectedGender = BirthGender.male;
  bool isSearching = false;

  @override
  void dispose() {
    nameController.dispose();
    placeController.dispose();
    latitudeController.dispose();
    longitudeController.dispose();
    secondsController.dispose();
    timezoneController.dispose();
    super.dispose();
  }

  Future<void> selectDate() async {
    final value = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1900),
      lastDate: DateTime(2100),
    );
    if (value != null) setState(() => selectedDate = value);
  }

  Future<void> selectTime() async {
    final value = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );
    if (value != null) setState(() => selectedTime = value);
  }

  Future<void> _searchPlace() async {
    final query = placeController.text.trim();
    if (query.isEmpty) {
      _message('స్థలం / Village పేరు నమోదు చేయండి');
      return;
    }

    setState(() => isSearching = true);
    try {
      final results = await PlaceSearchService.search(query);
      if (!mounted) return;
      if (results.isEmpty) {
        _message('స్థలం కనబడలేదు. New Place ద్వారా coordinates manually ఇవ్వండి.');
        return;
      }
      await _showPlaceResults(results);
    } catch (e) {
      if (mounted) _message(e.toString());
    } finally {
      if (mounted) setState(() => isSearching = false);
    }
  }

  Future<void> _showPlaceResults(List<PlaceResult> results) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(sheetContext).size.height * 0.65,
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'స్థలం ఎంచుకోండి',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    itemCount: results.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final place = results[index];
                      return ListTile(
                        leading: const Icon(Icons.location_on_outlined),
                        title: Text(place.displayName),
                        subtitle: Text(
                          'Lat ${place.latitude.toStringAsFixed(6)}  •  '
                          'Lon ${place.longitude.toStringAsFixed(6)}',
                        ),
                        onTap: () {
                          setState(() {
                            placeController.text = place.displayName;
                            latitudeController.text =
                                place.latitude.toStringAsFixed(6);
                            longitudeController.text =
                                place.longitude.toStringAsFixed(6);
                          });
                          Navigator.pop(sheetContext);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _showSavedPlaces() async {
    final places = await PlaceStorageService.load();
    if (!mounted) return;

    if (places.isEmpty) {
      _message('Saved Places ఇంకా లేవు. New Place ద్వారా ఒక స్థలం add చేయండి.');
      return;
    }

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) {
        return SafeArea(
          child: SizedBox(
            height: MediaQuery.of(sheetContext).size.height * 0.65,
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'Saved Places',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    itemCount: places.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final place = places[index];
                      return ListTile(
                        leading: const Icon(Icons.bookmark_outline),
                        title: Text(place.displayName),
                        subtitle: Text(
                          'Lat ${place.latitude.toStringAsFixed(6)}  •  '
                          'Lon ${place.longitude.toStringAsFixed(6)}',
                        ),
                        onTap: () {
                          setState(() {
                            placeController.text = place.displayName;
                            latitudeController.text =
                                place.latitude.toStringAsFixed(6);
                            longitudeController.text =
                                place.longitude.toStringAsFixed(6);
                          });
                          Navigator.pop(sheetContext);
                        },
                        trailing: IconButton(
                          tooltip: 'Delete',
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () async {
                            await PlaceStorageService.delete(place);
                            if (!sheetContext.mounted) return;
                            Navigator.pop(sheetContext);
                            if (mounted) {
                              _message('Saved place delete అయింది');
                              await _showSavedPlaces();
                            }
                          },
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _addNewPlace() async {
    final place = TextEditingController(text: placeController.text);
    final lat = TextEditingController(text: latitudeController.text);
    final lon = TextEditingController(text: longitudeController.text);

    final accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('New Place / కొత్త స్థలం'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: place,
                  decoration: const InputDecoration(
                    labelText: 'Village / Place name',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: lat,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                    signed: true,
                  ),
                  decoration: const InputDecoration(
                    labelText: 'Latitude',
                    hintText: 'ఉదా: 16.3067',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: lon,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                    signed: true,
                  ),
                  decoration: const InputDecoration(
                    labelText: 'Longitude',
                    hintText: 'ఉదా: 80.4365',
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                final latitude = double.tryParse(lat.text.trim());
                final longitude = double.tryParse(lon.text.trim());
                if (place.text.trim().isEmpty ||
                    latitude == null ||
                    longitude == null ||
                    latitude < -90 ||
                    latitude > 90 ||
                    longitude < -180 ||
                    longitude > 180) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Place, Latitude, Longitude సరిగా ఇవ్వండి'),
                    ),
                  );
                  return;
                }
                Navigator.pop(dialogContext, true);
              },
              child: const Text('Add'),
            ),
          ],
        );
      },
    );

    if (accepted == true && mounted) {
      final savedPlace = PlaceResult(
        displayName: place.text.trim(),
        latitude: double.parse(lat.text.trim()),
        longitude: double.parse(lon.text.trim()),
      );
      setState(() {
        placeController.text = savedPlace.displayName;
        latitudeController.text = savedPlace.latitude.toStringAsFixed(6);
        longitudeController.text = savedPlace.longitude.toStringAsFixed(6);
      });
      await PlaceStorageService.save(savedPlace);
      if (mounted) _message('New Place save అయింది');
    }
    place.dispose();
    lat.dispose();
    lon.dispose();
  }

  void generateChart() {
    final latitude = double.tryParse(latitudeController.text.trim());
    final longitude = double.tryParse(longitudeController.text.trim());
    final seconds = int.tryParse(secondsController.text.trim());
    final timezone = double.tryParse(timezoneController.text.trim());

    if (placeController.text.trim().isEmpty) {
      _message('జనన స్థలం ఇవ్వండి');
      return;
    }
    if (latitude == null || latitude < -90 || latitude > 90) {
      _message('Latitude -90 నుండి 90 మధ్య ఉండాలి');
      return;
    }
    if (longitude == null || longitude < -180 || longitude > 180) {
      _message('Longitude -180 నుండి 180 మధ్య ఉండాలి');
      return;
    }
    if (seconds == null || seconds < 0 || seconds > 59) {
      _message('Seconds 0 నుండి 59 మధ్య ఉండాలి');
      return;
    }
    if (timezone == null || timezone < -14 || timezone > 14) {
      _message('Timezone offset సరిగా ఇవ్వండి. India కోసం 5.5');
      return;
    }

    final localDateTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      selectedTime.hour,
      selectedTime.minute,
      seconds,
    );

    final data = BirthData(
      name: nameController.text.trim().isEmpty
          ? 'జాతకుడు'
          : nameController.text.trim(),
      localDateTime: localDateTime,
      place: placeController.text.trim(),
      latitude: latitude,
      longitude: longitude,
      timezoneOffsetHours: timezone,
      ayanamsa: selectedAyanamsa,
      gender: selectedGender,
    );

    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ChartScreen(birthData: data)),
    );
  }

  /// Use the judgement moment for both question systems. Never silently use
  /// the birth-date fields as a KP/Jamakola question moment.
  void _openQuestionSystem(ChartQuickSystem quickSystem) {
    final place = placeController.text.trim();
    final latitude = double.tryParse(latitudeController.text.trim());
    final longitude = double.tryParse(longitudeController.text.trim());
    final offset = double.tryParse(timezoneController.text.trim());

    if (place.isEmpty || latitude == null || longitude == null ||
        offset == null || !latitude.isFinite || !longitude.isFinite ||
        !offset.isFinite || latitude.abs() > 66.0 ||
        longitude.abs() > 180 || offset.abs() > 14) {
      _message('KP Time Chart / జామకోళ ప్రశ్న కోసం ముందుగా సరైన స్థలం, Latitude, Longitude, UTC Offset ఇవ్వండి. జనన తేదీ అవసరం లేదు.');
      return;
    }

    final nowAtQuestionPlace = DateTime.now().toUtc().add(
      Duration(minutes: (offset * 60).round()),
    );
    final questionMoment = DateTime(
      nowAtQuestionPlace.year, nowAtQuestionPlace.month,
      nowAtQuestionPlace.day, nowAtQuestionPlace.hour,
      nowAtQuestionPlace.minute, nowAtQuestionPlace.second,
    );
    final questionData = BirthData(
      name: quickSystem == ChartQuickSystem.kpTimeChart
          ? 'KP ప్రశ్న సమయ చక్రం' : 'జామకోళ ప్రశ్న చక్రం',
      localDateTime: questionMoment,
      place: place,
      latitude: latitude,
      longitude: longitude,
      timezoneOffsetHours: offset,
      ayanamsa: quickSystem == ChartQuickSystem.kpTimeChart
          ? AyanamsaType.krishnamurti : selectedAyanamsa,
      gender: BirthGender.unspecified,
    );
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ChartScreen(
        birthData: questionData,
        quickSystem: quickSystem,
      ),
    ));
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  String _two(int value) => value.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: Image.asset(
                'assets/branding/annapurna_icon.png',
                width: 34,
                height: 34,
                fit: BoxFit.cover,
              ),
            ),
            const SizedBox(width: 8),
            const Flexible(child: Text('అన్నపూర్ణ ఆస్ట్రో వాస్తు')),
          ],
        ),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Saved Charts & Reports',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SavedReportsScreen()),
            ),
            icon: const Icon(Icons.bookmarks_outlined),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 900),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(22),
                child: Image.asset(
                  'assets/branding/annapurna_logo.jpg',
                  width: double.infinity,
                  fit: BoxFit.contain,
                  alignment: Alignment.center,
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          const SizedBox(height: 12),
          Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  LayoutBuilder(builder: (context, constraints) {
                    final shortcuts = HomePrashnaShortcutBar(
                      onKpTimeChart: () => _openQuestionSystem(ChartQuickSystem.kpTimeChart),
                      onJamakola: () => _openQuestionSystem(ChartQuickSystem.jamakola),
                    );
                    const heading = Text('జనన వివరాలు',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold));
                    if (constraints.maxWidth < 440) {
                      return Column(crossAxisAlignment: CrossAxisAlignment.start,
                        children: [heading, const SizedBox(height: 10), shortcuts]);
                    }
                    return Row(children: [
                      heading, const Spacer(), SizedBox(width: 232, child: shortcuts),
                    ]);
                  }),
                  const SizedBox(height: 14),
                  TextField(
                    controller: nameController,
                    textCapitalization: TextCapitalization.words,
                    decoration: const InputDecoration(
                      labelText: 'పేరు',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person_outline),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'జాతకుని లింగం / Gender',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  SegmentedButton<BirthGender>(
                    segments: const [
                      ButtonSegment(
                        value: BirthGender.male,
                        icon: Icon(Icons.male),
                        label: Text('పురుషుడు'),
                      ),
                      ButtonSegment(
                        value: BirthGender.female,
                        icon: Icon(Icons.female),
                        label: Text('స్త్రీ'),
                      ),
                    ],
                    selected: {selectedGender},
                    onSelectionChanged: (value) {
                      if (value.isNotEmpty) {
                        setState(() => selectedGender = value.first);
                      }
                    },
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: placeController,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _searchPlace(),
                    decoration: InputDecoration(
                      labelText: 'జనన స్థలం / Village',
                      hintText: 'ఉదా: Guntur, Peddakurapadu',
                      border: const OutlineInputBorder(),
                      prefixIcon: const Icon(Icons.place_outlined),
                      suffixIcon: isSearching
                          ? const Padding(
                              padding: EdgeInsets.all(14),
                              child: SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              ),
                            )
                          : IconButton(
                              tooltip: 'Search',
                              icon: const Icon(Icons.search),
                              onPressed: _searchPlace,
                            ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      OutlinedButton.icon(
                        onPressed: _showSavedPlaces,
                        icon: const Icon(Icons.bookmarks_outlined),
                        label: const Text('Saved Places'),
                      ),
                      const SizedBox(width: 8),
                      OutlinedButton.icon(
                        onPressed: _addNewPlace,
                        icon: const Icon(Icons.add_location_alt_outlined),
                        label: const Text('New Place'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: latitudeController,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                            signed: true,
                          ),
                          decoration: const InputDecoration(
                            labelText: 'Latitude',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: longitudeController,
                          keyboardType: const TextInputType.numberWithOptions(
                            decimal: true,
                            signed: true,
                          ),
                          decoration: const InputDecoration(
                            labelText: 'Longitude',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(color: Colors.white, surfaceTintColor: Colors.transparent, 
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.calendar_month),
                    title: const Text('జనన తేదీ'),
                    subtitle: Text(
                      '${_two(selectedDate.day)}-${_two(selectedDate.month)}-${selectedDate.year}',
                    ),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: selectDate,
                  ),
                  const Divider(),
                  Row(
                    children: [
                      Expanded(
                        child: ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: const Icon(Icons.access_time),
                          title: const Text('జనన సమయం'),
                          subtitle: Text(
                            '${_two(selectedTime.hour)}:${_two(selectedTime.minute)}',
                          ),
                          onTap: selectTime,
                        ),
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        width: 100,
                        child: TextField(
                          controller: secondsController,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                            LengthLimitingTextInputFormatter(2),
                          ],
                          decoration: const InputDecoration(
                            labelText: 'Seconds',
                            suffixText: 'sec',
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: timezoneController,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                      signed: true,
                    ),
                    decoration: const InputDecoration(
                      labelText: 'Timezone offset (UTC)',
                      helperText: 'India: +5.5',
                      prefixText: 'UTC ',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<AyanamsaType>(
            initialValue: selectedAyanamsa,
            decoration: const InputDecoration(
              labelText: 'Ayanamsa',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.tune),
            ),
            items: AyanamsaType.values
                .map(
                  (item) => DropdownMenuItem(
                    value: item,
                    child: Text(item.label),
                  ),
                )
                .toList(),
            onChanged: (value) {
              if (value != null) setState(() => selectedAyanamsa = value);
            },
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 58,
            child: FilledButton.icon(
              onPressed: generateChart,
              icon: const Icon(Icons.auto_awesome),
              label: const Text(
                'జాతకం తయారు చేయండి',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              style: FilledButton.styleFrom(
                backgroundColor: scheme.primary,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => EventTimingScreen(
                    initialPlace: placeController.text.trim(),
                    initialLatitude: double.tryParse(latitudeController.text.trim()),
                    initialLongitude: double.tryParse(longitudeController.text.trim()),
                    initialTimezone: double.tryParse(timezoneController.text.trim()) ?? 5.5,
                    initialAyanamsa: selectedAyanamsa,
                  ),
                ),
              );
            },
            icon: const Icon(Icons.schedule_outlined),
            label: const Text('Event Timing Window'),
          ),
          const SizedBox(height: 12),
          const Text(
            'Place search పనిచేయకపోతే New Place ద్వారా Latitude/Longitude manually ఇవ్వవచ్చు.',
            textAlign: TextAlign.center,
          ),
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }
}
