import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_d1_bhava_interpreter.dart';
import 'package:astro_app/astrology/bnn_d1_bhava_rules.dart';

PlanetPosition p(String name,int sign,double degree) => PlanetPosition(
  name:name, shortName:name.substring(0,2),
  longitude:sign * 30.0 + degree,latitude:0,speed:1);

AstroChartResult fixture() => AstroChartResult(
  julianDay:2450000.0,ayanamsaDegrees:24,
  ascendantLongitude:7,engineVersion:'test-fixture',
  planets:[
    p('Sun',4,10),p('Moon',11,12),p('Mars',6,16),
    p('Mercury',0,4),p('Jupiter',8,15),p('Venus',6,18),
    p('Saturn',0,9),p('Rahu',10,14),p('Ketu',4,14),
  ],
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('27-star sidereal lord sequence includes Pushya and Ashlesha',() {
    expect(BnnD1BhavaInterpreter.nakshatraLord(p('Jupiter',3,7)),
        'Saturn'); // Cancer 7°: Pushya
    expect(BnnD1BhavaInterpreter.nakshatraLord(p('Jupiter',3,18)),
        'Mercury'); // Cancer 18°: Ashlesha
  });
  test('classical aspect direction: Mars 4/7/8, not arbitrary node aspect',() {
    expect(BnnD1BhavaInterpreter.aspectsSign(p('Mars',6,16),0),isTrue);
    expect(BnnD1BhavaInterpreter.aspectsSign(p('Venus',6,18),0),isTrue);
    expect(BnnD1BhavaInterpreter.aspectsSign(p('Rahu',6,18),0),isFalse);
  });
  test('144 topics return chart evidence and none expose source TODO',() async {
    final text = await rootBundle.loadString('assets/bnn/bnn_d1_12_bhava_336_v1.json');
    final data = BnnD1BhavaCatalogue.parse(text);
    final chart=fixture();
    for(var h=1;h<=12;h++) {
      final r=BnnD1BhavaInterpreter.lordReading(chart,h);
      expect(r.ifThen,contains('IF:'));
      expect(r.evidence,contains('నక్షత్రాధిపతి'));
      for(final topic in data.forHouse(h,'BHAVA_TOPIC_CHECK')) {
        final reading=BnnD1BhavaInterpreter.topicReading(chart,topic);
        expect(reading.result, isNot(contains('పరిశీలించాలి')));
        expect(reading.result,isNot(contains('IF')));
        expect(reading.evidence,contains('అధిపతి'));
        expect(reading.basis,contains('విశ్లేషణ'));
      }
      for(final modifier in data.forHouse(h,'CONDITIONAL_MODIFIER')) {
        final reading=BnnD1BhavaInterpreter.modifierReading(chart,modifier);
        if(reading!=null) {
          expect(reading.ifThen,contains('IF:'));
          expect(reading.evidence,isNotEmpty);
        }
      }
    }
  });
  test('matched Thangapandian first-bhava rules only if actual IF true',() async {
    final text=await rootBundle.loadString('assets/bnn/bnn_d1_12_bhava_336_v1.json');
    final notes=BnnD1BhavaCatalogue.parse(text).notes;
    final chart=fixture();
    final third=notes.firstWhere((n)=>n.id=='BNN-FIRST-BHAVA-P5-009');
    final aspects=notes.firstWhere((n)=>n.id=='BNN-FIRST-BHAVA-P4-001');
    final unknown=notes.firstWhere((n)=>n.id=='BNN-FIRST-BHAVA-P5-001');
    expect(BnnD1BhavaInterpreter.sourceReading(chart,third),isNotNull);
    expect(BnnD1BhavaInterpreter.sourceReading(chart,aspects),isNotNull);
    expect(BnnD1BhavaInterpreter.sourceReading(chart,unknown),isNull);
  });
  test('malefic-benefic local degree chain is evaluated, not pending', () async {
    final text=await rootBundle.loadString('assets/bnn/bnn_d1_12_bhava_336_v1.json');
    final rules=BnnD1BhavaCatalogue.parse(text).forHouse(1,'CONDITIONAL_MODIFIER');
    final chart=fixture();
    for(final suffix in ['SUPPORT','CHALLENGE','NAKSHATRA','RESCUE']) {
      final rule=rules.firstWhere((r)=>r.id.endsWith(suffix));
      final result=BnnD1BhavaInterpreter.modifierReading(chart,rule);
      expect(result,isNotNull,reason:suffix);
      expect(result!.evidence,isNotEmpty);
      expect(result.result,isNot(contains('NOT EVALUATED')));
    }
  });
}
