import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_combination_engine.dart';

PlanetPosition p(String name, double lon, {double speed = 0.01}) =>
  PlanetPosition(name: name, shortName: name.substring(0, 2),
    longitude: lon, latitude: 0, speed: speed);

AstroChartResult chart(List<PlanetPosition> planets) => AstroChartResult(
  julianDay: 0, ayanamsaDegrees: 24, ascendantLongitude: 80,
  planets: planets, engineVersion: 'test',
);

void main() {
  test('Local 1-5-9: pairs and trio; Jupiter-first remains separate', () {
    final c = chart([
      p('Jupiter', 24), p('Venus', 124), p('Saturn', 256),
    ]);
    final local = BnnCombinationEngine.degreeTrine(c);
    expect(local.length, 4); // three pairs + one trio
    final triple = local.singleWhere((x) => x.size == 3);
    expect(triple.orderedPlanets.map((x) => x.name).toList(),
      ['Venus', 'Saturn', 'Jupiter']);
    final anchored = BnnCombinationEngine.jupiterCentred(c);
    expect(anchored.length, 3); // J+V, J+S, J+V+S
    expect(anchored.singleWhere((x) => x.size == 3)
      .orderedPlanets.first.name, 'Jupiter');
    expect(anchored.map((x) => x.memberKey).toSet().length, 3);
  });

  test('Jupiter-only anchors and cross-trine subsets without fake predictions', () {
    final c = chart([p('Jupiter', 41), p('Venus', 121), p('Mars', 197)]);
    expect(BnnCombinationEngine.jupiterCentred(c).length, 3);
    expect(BnnCombinationEngine.degreeTrine(c), isEmpty);
    final sample = BnnCombinationEngine.jupiterCentred(c).last;
    expect(sample.pairEvidence.length, 3);
    expect(sample.pairEvidence.first, contains('రాశి'));
  });

  test('All nine classical planets: enumerate all Jupiter-centred subsets', () {
    final c = chart([
      p('Jupiter', 10), p('Sun', 11), p('Moon', 12),
      p('Mars', 13), p('Mercury', 14), p('Venus', 15),
      p('Saturn', 16), p('Rahu', 17), p('Ketu', 18),
    ]);
    final centred = BnnCombinationEngine.jupiterCentred(c);
    expect(centred.length, 255); // 2^8 - 1
    expect(centred.any((e) => e.size == 9), isTrue);
    final local = BnnCombinationEngine.degreeTrine(c);
    expect(local.length, 502); // 2^9 - nine singletons - empty
    expect(local.any((e) => e.size == 9), isTrue);
    expect(local.map((e) => e.memberKey).toSet().length, 502);
  });

  test('Local planet degree addition: 25 + 29 + 4 + 19 = 77', () {
    final c = chart([
      p('Jupiter', 25), p('Sun', 29), p('Venus', 124), p('Saturn', 259),
    ]);
    final q = BnnCombinationEngine.degreeTrine(c)
        .singleWhere((x) => x.size == 4);
    expect(q.localDegreeSumArcseconds, 77 * 3600);
    expect(q.degreeAdditionEquation, contains('= 77°00′00″'));
    expect(q.completedThirtyDegreeBlocks, 2);
    expect(q.residueWithinThirtyDegrees, '17°00′00″');
  });

  test('Degree sum honors arcminutes and arcseconds without floating drift', () {
    final c = chart([p('Jupiter', 25.5), p('Venus', 125.25)]);
    final q = BnnCombinationEngine.degreeTrine(c).single;
    expect(q.localDegreeSumArcseconds, 30 * 3600 + 45 * 60);
    expect(q.residueWithinThirtyDegrees, '0°45′00″');
  });

  test('All-graha directional 1-5-9, 3-7-11 and 2-12 + node exception', () {
    final c = chart([
      p('Jupiter', 31), p('Sun', 91), p('Moon', 211),
      p('Venus', 61), p('Saturn', 1), p('Rahu', 32),
      p('Ketu', 331),
    ]);
    final r = BnnCombinationEngine.relationsFromEveryPlanet(c);
    // Jupiter Taurus -> Sun Cancer (3rd), Moon Scorpio (7th),
    // Venus Gemini (2nd), Saturn Aries (12th), Rahu same-sign.
    expect(r.any((x) => x.anchor.name == 'Jupiter' &&
        x.target.name == 'Sun' && x.house == 3 && x.family == '3–7–11'), isTrue);
    expect(r.any((x) => x.anchor.name == 'Jupiter' &&
        x.target.name == 'Moon' && x.house == 7 && x.family == '3–7–11'), isTrue);
    expect(r.any((x) => x.anchor.name == 'Jupiter' &&
        x.target.name == 'Venus' && x.house == 2 && x.family == '2–12'), isTrue);
    expect(r.any((x) => x.anchor.name == 'Jupiter' &&
        x.target.name == 'Saturn' && x.house == 12 && x.family == '2–12'), isTrue);
    expect(r.any((x) => x.anchor.name == 'Rahu' &&
        x.target.name == 'Sun' && x.house == 3), isFalse);
    expect(r.any((x) => x.anchor.name == 'Rahu' &&
        x.target.name == 'Venus' && x.house == 2), isFalse);
    expect(r.any((x) => x.anchor.name == 'Rahu' &&
        x.target.name == 'Saturn' && x.house == 12), isTrue);
    expect(r.any((x) => x.anchor.name == 'Ketu' &&
        x.target.name == 'Sun' && x.house == 5), isTrue);
  });

  test('Every-planet anchors create directed pairs and multi-graha subsets', () {
    final c = chart([p('Jupiter', 31), p('Venus', 61),
      p('Sun', 91), p('Saturn', 1)]);
    final combos = BnnCombinationEngine.everyPlanetAnchored(c);
    final j = combos.where((x) =>
        x.orderedPlanets.first.name == 'Jupiter').toList();
    // Venus 2nd, Sun 3rd, Saturn 12th from Jupiter: 2^3 - 1.
    expect(j.length, 7);
    expect(j.where((x) => x.size == 4).length, 1);
    expect(j.first.size, 2);
    expect(j.last.degreeAdditionEquation, contains(' = '));
  });

  test('Retro motion not interpreted as reverse natal degree chain', () {
    final local = BnnCombinationEngine.degreeTrine(chart([
      p('Venus', 124, speed: -0.01), p('Saturn', 256), p('Jupiter', 24),
    ]));
    final triple = local.singleWhere((x) => x.size == 3);
    expect(triple.orderedPlanets.first.name, 'Venus');
    expect(triple.positionalChain, contains('(వక్ర)'));
  });

  test('Exact DMS ties are flagged as unresolved', () {
    final local = BnnCombinationEngine.degreeTrine(chart([
      p('Venus', 124), p('Saturn', 244),
    ]));
    expect(local.single.unresolvedDegreeOrder, isTrue);
  });
}
