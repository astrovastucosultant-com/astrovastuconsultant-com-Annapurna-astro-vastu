import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_d1_bhava_rules.dart';
import '../astrology/bnn_d1_bhava_interpreter.dart';

/// The D1 Lagna-based reference rules have their own navigation and house
/// coordinates; they never replace BNN's Jupiter-relative 12-house reading.
class BnnD1BhavaPanel extends StatefulWidget {
  final AstroChartResult chart;
  const BnnD1BhavaPanel({super.key, required this.chart});

  @override
  State<BnnD1BhavaPanel> createState() => _BnnD1BhavaPanelState();
}

class _BnnD1BhavaPanelState extends State<BnnD1BhavaPanel> {
  final Future<BnnD1BhavaCatalogue> _source = BnnD1BhavaCatalogue.load();
  int _house = 1;
  bool _showTopics = true;
  bool _showModifiers = false;
  bool _showSourceNotes = false;

  static const Color ink = Color(0xFF273143);
  static const Color muted = Color(0xFF636B77);
  static const Color accent = Color(0xFF2055A6);

  @override
  Widget build(BuildContext context) => FutureBuilder<BnnD1BhavaCatalogue>(
    future: _source,
    builder: (context, snapshot) {
      if (snapshot.hasError) return Text('D1 భావఫల డేటా లోపం: ${snapshot.error}');
      if (!snapshot.hasData) return const Center(
        child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator()));
      final data = snapshot.data!;
      final h = data.houses[_house - 1];
      final p = BnnD1BhavaGeometry.placement(widget.chart, _house);
      final topics = data.forHouse(_house, 'BHAVA_TOPIC_CHECK');
      final lordRules = data.forHouse(_house, 'BHAVA_LORD_PLACEMENT');
      final modifiers = data.forHouse(_house, 'CONDITIONAL_MODIFIER');
      final notes = data.notes.where((n) => n.house == _house).toList();
      final matched = lordRules.where((r) =>
          BnnD1BhavaGeometry.matchesLordPlacement(widget.chart, r)).toList();
      final occupied = BnnD1BhavaGeometry.planetsInHouse(widget.chart, _house);
      final lordReading = BnnD1BhavaInterpreter.lordReading(widget.chart, _house);
      final activeModifiers = <MapEntry<BnnD1BhavaRule, BnnBhavaReading>>[];
      for (final rule in modifiers) {
        final reading = BnnD1BhavaInterpreter.modifierReading(widget.chart, rule);
        if (reading != null) activeModifiers.add(MapEntry(rule, reading));
      }
      final topicResults = <MapEntry<BnnD1BhavaRule, BnnBhavaReading>>[];
      for (final rule in topics) {
        topicResults.add(MapEntry(rule,
            BnnD1BhavaInterpreter.topicReading(widget.chart, rule)));
      }
      final appliedTopics = topicResults.where((e) => e.value.applied)
          .toList(growable:true)
        ..sort((a,b) => _levelRank(a.value.level)
            .compareTo(_levelRank(b.value.level)));
      final sourceMatches = <MapEntry<BnnD1BhavaSourceNote, BnnBhavaReading>>[];
      for (final note in notes) {
        final reading = BnnD1BhavaInterpreter.sourceReading(widget.chart, note);
        if (reading != null) sourceMatches.add(MapEntry(note, reading));
      }
      return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _surface(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('సిద్ధాంతి రూల్ — D1 12 భావాలు (336)', style: TextStyle(
            color: ink, fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 7),
          const Text('జన్మలగ్నం ఆధారంగా రూపొందించిన 336 సిద్ధాంతి రూల్స్. '
            'BNN గురు-ఆధారిత భావ క్రమానికి ఇది భిన్నం.',
            style: TextStyle(fontSize: 12.5, color: muted, height: 1.4)),
          const SizedBox(height: 10),
          Wrap(spacing: 6, runSpacing: 6, children: [
            _tag('144 భావ అంశాలు'), _tag('144 భావాధిపతి IFలు'),
            _tag('48 అదనపు పరిశీలనలు'),
          ]),
          const SizedBox(height: 13),
          Wrap(spacing: 7, runSpacing: 7, children: [
            for (var n = 1; n <= 12; n++) ChoiceChip(
              label: Text('$n భావం'),
              selected: n == _house,
              selectedColor: const Color(0xFFD8E9FF),
              labelStyle: TextStyle(color: n == _house ? accent : ink,
                fontWeight: n == _house ? FontWeight.w800 : FontWeight.w500),
              onSelected: (_) => setState(() { _house = n;
                _showTopics = true;
                _showModifiers = false;
                _showSourceNotes = false; }),
            ),
          ]),
        ])),
        const SizedBox(height: 10),
        _surface(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${h.number}వ భావం — ${h.name}',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: ink)),
          Text(h.domain, style: const TextStyle(color: muted)),
          const Divider(height: 22),
          Text('D1 లగ్నం: ${BnnD1BhavaGeometry.signs[widget.chart.ascendantSignIndex]}  •  '
            'ఈ భావరాశి: ${BnnD1BhavaGeometry.signs[BnnD1BhavaGeometry.signForHouse(widget.chart, _house)]}',
            style: const TextStyle(fontWeight: FontWeight.w700, height: 1.5)),
          const SizedBox(height: 6),
          if (p != null) Text(
            'భావాధిపతి: ${BnnD1BhavaGeometry.planetTelugu[p.lordPlanet]}  •  '
            'స్థానం: ${BnnD1BhavaGeometry.signs[p.lordSign]} / ${p.lordHouse}వ D1 భావం',
            style: const TextStyle(height: 1.55)),
          Text('ఈ భావంలోని గ్రహాలు: ${occupied.isEmpty ? 'లేవు' : occupied.map((p) => '${BnnD1BhavaGeometry.planetTelugu[p.name] ?? p.name} ${p.degreesInSign.toStringAsFixed(2)}°').join(', ')}',
            style: const TextStyle(height: 1.5)),
          const SizedBox(height: 8),
          const Text('గమనిక: IF నిజమైతే గ్రహస్థానం మాత్రమే నిర్ధారితమవుతుంది; '
            'సంఘటన నిజంగా జరిగిందని కాదు.',
            style: TextStyle(color: muted, fontSize: 12)),
        ])),
        const SizedBox(height: 10),
        _surface(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _heading('ఫలితం — జాతకంలో సరిపోయిన భావాధిపతి స్థానం'),
          const SizedBox(height: 5),
          const Text('గ్రహస్థానం, నక్షత్రాధిపతి, దృష్టి, శుభ–పాప సంబంధాల ఆధారంగా ఫలిత వివరణ.',
            style: TextStyle(color: muted, fontSize: 12, height: 1.35)),
          const SizedBox(height: 8),
          if (matched.isEmpty) const Text('ఈ భావాధిపతి జాతకస్థానం నిర్ధారించబడలేదు.',
              style: TextStyle(color: muted))
          else for (final rule in matched) _ruleCard(rule,
            status: 'స్థాన IF సరిపోయింది • ${lordReading.level} గ్రహ సంబంధాలు',
            color: _levelColor(lordReading.level), reading: lordReading),
        ])),
        if (sourceMatches.isNotEmpty) ...[
          const SizedBox(height: 10),
          _surface(Column(crossAxisAlignment: CrossAxisAlignment.start,children:[
            _heading('గురువుగారి క్లాస్ సంబంధం సరిపోయిన ఫలితాలు (${sourceMatches.length})'),
            const SizedBox(height: 6),
            for (final item in sourceMatches) _sourceMatchCard(item.key,item.value),
          ])),
        ],
        const SizedBox(height: 10),
        _surface(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          InkWell(onTap: () => setState(() => _showTopics = !_showTopics),
            child: Padding(padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                Expanded(child: Text('భావంలోని 12 అంశాల్లో సరిపోయినవి (${appliedTopics.length})',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800))),
                Icon(_showTopics ? Icons.expand_less : Icons.expand_more),
              ]))),
          const Text('మొత్తం 12 అంశాల IFలు పరీక్షించాం. ప్రత్యేక కారక/అనుబంధ భావ సంబంధం ఉన్న ఫలితాలే చూపుతున్నాం.',
            style: TextStyle(color: muted, fontSize: 12, height: 1.35)),
          if (_showTopics) ...[
            const SizedBox(height: 8),
            if (appliedTopics.isEmpty) const Text('ఈ భావంలో ప్రత్యేక అంశ-కారక సంబంధం కనబడలేదు.',
              style: TextStyle(fontSize:12,color:muted)),
            for (final item in appliedTopics) _ruleCard(item.key,
              status: 'గణించిన ${item.value.level} గ్రహ సంబంధం',
              color: _levelColor(item.value.level),
              reading: item.value),
          ],
        ])),
        const SizedBox(height: 10),
        _surface(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          InkWell(onTap: () => setState(() => _showModifiers = !_showModifiers),
            child: Row(children: [
              Expanded(child: Text('గణించిన ఫలిత మార్పులు (${activeModifiers.length})',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800))),
              Icon(_showModifiers ? Icons.expand_less : Icons.expand_more),
            ])),
          const Text('జాతకంలో సంబంధం గణితంగా సరిపోయిన ఉపనియమాలు మాత్రమే ఇక్కడ కనిపిస్తాయి.',
            style: TextStyle(color: muted, fontSize: 12)),
          if (_showModifiers) ...[
            if (activeModifiers.isEmpty) const Text('ఈ నాలుగు షరతుల్లో ఏదీ సరిపోలలేదు.',
              style: TextStyle(fontSize: 12, color: muted)),
            for (final entry in activeModifiers) _ruleCard(entry.key,
              status: 'IF సరిపోయింది • ${entry.value.level} సంబంధం',
              color: _levelColor(entry.value.level), reading: entry.value),
          ],
        ])),
        if (notes.isNotEmpty) ...[
          const SizedBox(height: 10),
          _surface(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            InkWell(onTap: () => setState(() => _showSourceNotes = !_showSourceNotes),
              child: Row(children: [
                const Expanded(child: Text('క్లాస్ బోధన గమనికలు (వ్యక్తిగత ఫలితం కాదు)',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800))),
                Icon(_showSourceNotes ? Icons.expand_less : Icons.expand_more),
              ])),
            if (_showSourceNotes) for (final n in notes) ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: Text(n.topic, style: const TextStyle(fontWeight: FontWeight.w600)),
              subtitle: Text(n.source, style: const TextStyle(fontSize: 11, color: muted)),
              children: [
                _detail('మూల IF / సందర్భం', n.ifText),
                _detail('గురువుగారి సూచన', n.thenText),
              ],
            ),
          ])),
        ],
        const SizedBox(height: 8),
        const Text('ఈ విభాగం సంస్కృత/నాడీ జ్యోతిష్య సంప్రదాయ పరిశీలన కోసం. '
          'ఆరోగ్య, మరణ, ఆర్థిక సంఘటనలను నిర్ధారించదు. '
          'Timing/BTR ధృవీకరణ లేకుండా సంవత్సరం ఇవ్వదు.',
          style: TextStyle(color: muted, fontSize: 11.5, height: 1.5)),
      ]);
    },
  );

  static int _levelRank(String level) => switch (level) {
    'సహాయక' => 0, 'మిశ్ర' => 1, 'ఆటంక' => 2, _ => 3,
  };

  static Color _levelColor(String level) => switch (level) {
    'సహాయక' => const Color(0xFFEAF6EE),
    'ఆటంక' => const Color(0xFFF9EDF1),
    _ => const Color(0xFFF2F5F9),
  };

  Widget _sourceMatchCard(BnnD1BhavaSourceNote note, BnnBhavaReading reading) =>
    Card(color: const Color(0xFFEAF6EE), elevation: 0,
      child: ExpansionTile(
        title: Text(note.topic,style:const TextStyle(fontWeight:FontWeight.bold)),
        subtitle: Text('IF సరిపోయింది • ${note.source}',
          style: const TextStyle(fontSize:11,color:muted)),
        childrenPadding: const EdgeInsets.fromLTRB(12,0,12,12),
        expandedCrossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _detail('ఫలితం',reading.result),
          _detail('జాతక పరిశీలన',reading.evidence),
          _detail('మూల నియమం',reading.ifThen),
          _detail('మూల క్లాస్',reading.basis),
        ],
      ));

  Widget _tag(String text) => Container(
    padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 9),
    decoration: BoxDecoration(color: const Color(0xFFEAF0F8),
      borderRadius: BorderRadius.circular(16)),
    child: Text(text, style: const TextStyle(fontSize: 11.5, color: accent)),
  );

  Widget _surface(Widget child) => Container(
    width: double.infinity, padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: Colors.white,
      border: Border.all(color: const Color(0xFFE2E6EC)),
      borderRadius: BorderRadius.circular(14)),
    child: child,
  );

  Widget _heading(String name) => Text(name,
    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800, color: ink));

  Widget _ruleCard(BnnD1BhavaRule rule, {required String status,
      required Color color, BnnBhavaReading? reading}) => Card(
    color: color, elevation: 0, margin: const EdgeInsets.only(bottom: 7),
    child: ExpansionTile(
      key: ValueKey(rule.id),
      tilePadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      title: Text(rule.topic.isEmpty ? (reading?.result ?? rule.result) :
          (reading == null ? rule.topic :
            '${rule.topic} — ${reading.level} గ్రహ సూచన'),
        style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700,
          color: ink)),
      subtitle: Text('${rule.ruleLabel} • $status',
        style: const TextStyle(fontSize: 11.5, color: muted)),
      childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      expandedCrossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _detail('ఫలితం', reading?.result ?? rule.result),
        if (reading != null) ...[
          _detail('జాతకంలో గణించిన ఆధారాలు', reading.evidence),
          _detail('అప్లై అయిన IF → THEN', reading.ifThen),
          _detail('రూల్ పేరు', rule.ruleLabel),
          _detail('నియమ ఆధారం / వర్గం', reading.basis),
        ] else ...[
          _detail('జాతక పరిశీలన', rule.examination),
          _detail('రూల్ పేరు', rule.ruleLabel),
          _detail('మూల IF–THEN', rule.sourceIfThen),
        ],
        if (reading == null && !rule.remedy.contains('మూలాధారం'))
          _detail('పరిహారం', rule.remedy),
        const SizedBox(height: 6),
        Text('${rule.ruleLabel} • ${rule.id} • ${rule.provenance}',
          style: const TextStyle(color: muted, fontSize: 10.5)),
      ],
    ),
  );

  Widget _detail(String title, String body) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 12,
        fontWeight: FontWeight.bold, color: ink)),
      Text(body, style: const TextStyle(fontSize: 12.5, height: 1.45)),
    ]),
  );
}
