# Build 129 — D16 live rule matching

- Preserved all Build 128 project files and the existing four D16 evaluations.
- Added nine additional D16 evaluation cards using actual chart placements: Moon mental comfort, Jupiter inner contentment, Venus material comfort, ascendant/desire, fourth house/lord, kendra support, vehicle accident caution, loss caution, comfort permanence.
- Each result uses the existing `VargaRuleHit` pipeline, which carries result, inspection, rule, remedy and source.
- Evidence % is matched conditions / evaluated conditions, **not** event probability.
- New interpretations are explicitly attributed to the user-provided video summary, not asserted as verified Sanskrit source text.
- No new date-accurate event-timing engine was added; existing app timing remains unchanged. Do not claim precise dates.
- Not compiled or APK-tested in this environment because Flutter/Dart SDK is unavailable. Run `flutter analyze` and GitHub Actions build after upload.
