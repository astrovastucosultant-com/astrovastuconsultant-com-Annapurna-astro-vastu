import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../astrology/marriage_43_rule_engine.dart';
import '../astrology/marriage_material_registry.dart';
import '../astrology/marriage_printed_table_engine.dart';

/// Two-chart compatibility checklist. Called after both saved natal charts
/// have been calculated in Marriage Matching; no manually-entered birth data.
class D9Marriage43ChecklistScreen extends StatefulWidget {
  final AstroChartResult firstChart;
  final AstroChartResult secondChart;
  final String firstName;
  final String secondName;

  const D9Marriage43ChecklistScreen({
    super.key,
    required this.firstChart,
    required this.secondChart,
    required this.firstName,
    required this.secondName,
  });

  @override
  State<D9Marriage43ChecklistScreen> createState() =>
      _D9Marriage43ChecklistScreenState();
}

class _D9Marriage43ChecklistScreenState extends State<D9Marriage43ChecklistScreen> {
  bool firstIsGroom = true;
  bool showSourceRules = false;
  bool showPending = true;

  @override
  Widget build(BuildContext context) {
    final groom = firstIsGroom ? widget.firstChart : widget.secondChart;
    final bride = firstIsGroom ? widget.secondChart : widget.firstChart;
    final groomName = firstIsGroom ? widget.firstName : widget.secondName;
    final brideName = firstIsGroom ? widget.secondName : widget.firstName;
    final results = Marriage43RuleEngine.evaluate(groom: groom, bride: bride);
    final checked = results.where((r) => r.evaluated).length;
    final favourable = results.where((r) => r.favourable == true).length;
    final adverse = results.where((r) => r.favourable == false).length;
    final sourceRules = MarriageMaterialRegistry.matchingRules().where(
      (r) => !const {'MM-P03-S06', 'MM-P04-S07', 'MM-P04-S08'}.contains(r.id),
    ).toList(growable: false);

    return Scaffold(
      appBar: AppBar(title: const Text('వివాహ పొంతన — 43 నియమాలు')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        const Text('వరుడు–వధువు జాతకాల స్వయంచాలక పరిశీలన',
            style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Text('వరుడు: $groomName  •  వధువు: $brideName',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('మొదటి జాతకం వరుడిది'),
          subtitle: const Text('వరుడు–వధువు క్రమం మారితే స్విచ్ మార్చండి.'),
          value: firstIsGroom,
          onChanged: (v) => setState(() => firstIsGroom = v),
        ),
        Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('43 నియమాల పరీక్ష స్థితి', style: TextStyle(fontWeight: FontWeight.w900)),
            const SizedBox(height: 5),
            Text('మొత్తం: 43 • గణించినవి: $checked • అనుకూల సూచనలు: $favourable • '
                'ప్రతికూల సూచనలు: $adverse • నిర్ణయం లేనివి/పెండింగ్: ${43 - favourable - adverse}'),
            const SizedBox(height: 5),
            const Text('⚠️ Rule 06లో వేధ జంట కనిపించనప్పుడు మూలం అనుకూల తీర్పు ఇవ్వదు. '
                'ఇతర పెండింగ్ నియమాలను Passed/Failedగా లెక్కించము. '
                'ఇది మొత్తం వివాహ అనుకూలత శాతం కాదు.'),
          ],
        ))),
        CheckboxListTile(
          value: showPending,
          onChanged: (v) => setState(() => showPending = v ?? true),
          title: const Text('పరీక్షించని నియమాలు కూడా చూపించండి'),
        ),
        for (final r in results)
          if (showPending || r.evaluated)
            Card(child: ExpansionTile(
              key: ValueKey('rule-${r.number}'),
              leading: Icon(
                !r.evaluated ? Icons.hourglass_empty
                    : r.favourable == true ? Icons.check_circle_outline
                    : r.favourable == false ? Icons.warning_amber_outlined
                    : Icons.info_outline,
                color: !r.evaluated ? Colors.grey
                    : r.favourable == true ? Colors.green.shade700
                    : r.favourable == false ? Colors.deepOrange.shade700
                    : Colors.blueGrey,
              ),
              title: Text('Rule-${r.number.toString().padLeft(2, '0')} — ${r.title}'),
              subtitle: Text(!r.evaluated ? 'పెండింగ్ • పూర్తి సూత్రం అవసరం'
                  : r.favourable == true ? 'అనుకూల సూచన'
                  : r.favourable == false ? 'ప్రతికూల సూచన'
                  : 'పరిశీలించబడింది • మూలం నిర్ణయం ఇవ్వలేదు'),
              childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 14),
              children: [Align(alignment: Alignment.centerLeft, child: Text(
                'జాతక పరిశీలన: ${r.examination}\n\n'
                'రూల్: ${r.rule}\n\n'
                'మూలం: ${r.source}\n\n'
                'పరిహారం: ధృవీకరించిన మూలంలో లేకపోతే ఇవ్వబడదు.',
                style: const TextStyle(height: 1.45),
              ))],
            )),
        const SizedBox(height: 12),
        Card(child: ExpansionTile(
          title: const Text('అసలు వివాహ పొంతన మూల నియమాల పట్టిక'),
          subtitle: Text('${sourceRules.length} అదనపు మూల అంశాలు (43 checklistలోకి కలపకుండా వేరు)'),
          initiallyExpanded: showSourceRules,
          onExpansionChanged: (v) => setState(() => showSourceRules = v),
          children: [
            for (final r in sourceRules)
              Builder(builder: (context) {
                final computed = MarriagePrintedTableEngine.evaluate(r.id, groom, bride);
                return ExpansionTile(
                  title: Text('${r.id} — ${r.topic}'),
                  subtitle: Text(computed.favourable == null
                      ? 'మూల పట్టిక • తుది తీర్పు నిర్ధారించలేదు'
                      : computed.favourable! ? 'అనుకూల సూచన' : 'ప్రతికూల సూచన'),
                  childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
                  children: [Align(alignment: Alignment.centerLeft, child: Text(
                    'జాతక పరిశీలన: ${computed.examination}\n'
                    'మూల నియమం: ${computed.sourceRule.isEmpty ? r.note : computed.sourceRule}\n'
                    'మూలం: ${MarriageMaterialRegistry.sourceName} • పేజీ ${r.page}\n'
                    'పరిహారం: మూలంలో నిర్ధారణ అయితేనే జోడించాలి.',
                  ))],
                );
              }),
          ],
        )),
      ]),
    );
  }
}
