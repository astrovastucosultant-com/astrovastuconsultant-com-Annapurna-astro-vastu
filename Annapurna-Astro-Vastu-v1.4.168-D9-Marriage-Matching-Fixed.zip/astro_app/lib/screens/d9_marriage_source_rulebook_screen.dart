import 'package:flutter/material.dart';
import '../astrology/marriage_material_registry.dart';

/// D9 single-person rule catalog, deliberately distinct from the two-chart
/// compatibility checklist. Source-only entries must not become predictions.
class D9MarriageSourceRulebookScreen extends StatelessWidget {
  const D9MarriageSourceRulebookScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final rules = MarriageMaterialRegistry.individualForFactor(9);
    return Scaffold(
      appBar: AppBar(title: const Text('D9 — వ్యక్తిగత వివాహ మూల నియమాలు')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('D9 వివాహయోగం • 7వ భావం • కాలనిర్ణయం • దాంపత్యం',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('D9కు సంబంధించిన ${rules.length} వ్యక్తిగత మూల రూల్ రికార్డులు. '
                'వాస్తవంగా గణించగల D9 ఫలితాలు పూర్వపు D9 Final Marriage Reportలో ఉంటాయి. '
                'ఈ జాబితా source-only; గణన ఇంకా ధృవీకరించని నియమాలు ఫలితాలుగా పరిగణించకూడదు.'),
          ],
        ))),
        for (final r in rules)
          Card(child: ExpansionTile(
            key: ValueKey(r.id),
            title: Text('${r.id} — ${r.topic}'),
            subtitle: const Text('మూల రూల్ • పూర్తి గణన షరతు పెండింగ్'),
            childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            children: [Align(alignment: Alignment.centerLeft, child: Text(
              'ఫలితం: పూర్తి షరతులు ధృవీకరించకపోవడంతో తుది తీర్పు లేదు.\n\n'
              'రూల్: ${r.note}\n\n'
              'జాతక పరిశీలన: ${r.factors.map((n) => 'D$n').join(', ')} చక్రాల సంబంధం; '
              'తగిన IF–THEN వివరాలు యంత్రగణనకు ఇంకా నిర్ధారించాలి.\n\n'
              'మూలం: ${MarriageMaterialRegistry.sourceName} • పేజీ ${r.page}\n\n'
              'పరిహారం: నిర్ధారిత మూలంలో లేకపోతే జోడించము.',
              style: const TextStyle(height: 1.4),
            ))],
          )),
      ]),
    );
  }
}
