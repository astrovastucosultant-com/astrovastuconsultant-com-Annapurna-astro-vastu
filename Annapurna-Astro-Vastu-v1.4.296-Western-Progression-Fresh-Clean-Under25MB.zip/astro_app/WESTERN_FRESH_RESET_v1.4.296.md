# Western Progression — fresh reset (v1.4.296)

- Western Progression retains one **empty** top-level tab; old Western event/timing/BTR UI is gone.
- Deleted all 9 `lib/astrology/western_*.dart` implementations and all 13 `test/western_*.dart` tests to avoid carrying old formulas or expectations.
- Deleted previous `WESTERN_*.md` and `WESTERN_*.txt` analysis notes from the source ZIP.
- No legacy Western services, rules, ephemeris, saved-event storage, timing search or BTR code is imported or called by the app.
- Old on-device Western preferences are **not read**, not imported and not silently deleted, to avoid irreversible data loss. Fresh work must use new versioned storage keys.
- Other modules (BNN, Jaimini, D10, KP, Mehta BTR, shared chart/saving) are intentionally untouched.
- This is a **source-only** reset; APK compile/device validation is not claimed.
