# Build 294 - green/pink strength visualizations

- Main Jataka tab `బలాలు` splits into `గ్రహబలం` and `భావబలం`.
- Graha strength bars: seven classical planets, calculated Shadvarga Vimshopaka /20, sorting strongest first.
- Bhava strength bars: 1-12 houses, calculated Sarvashtakavarga (SAV) out of 56.
- Green at >=10/20 Shadvarga app threshold or >=28 SAV; otherwise pink; bars tap to expand rule/inspection/result.
- Gem Remedy existing full Strength Tables replaced by matching colored expandable bar chart (no lost calculations).
- BPHS shapa optional manual inputs: visually readable text fields, bars only for verified manually entered six-part Shadbala virupas. Classical planet minima: Sun 390, Moon 360, Mars 300, Mercury 420, Jupiter 390, Venus 330, Saturn 300.
- Classical Shadbala totals are not synthesized from Shadvarga Vimsopaka or SAV; color indicates strength only, not guaranteed benefit or harm.
- All existing BNN 462, Siddhanti 336, panchangam, and shapa rule datasets unchanged.
- ZIP structure and integrity verified; Flutter SDK not installed here, so this is SOURCE ZIP, not a compiled APK.
