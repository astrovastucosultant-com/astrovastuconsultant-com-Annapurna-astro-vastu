import 'package:flutter/material.dart';

/// Western Progression fresh baseline: no legacy progression, timing or BTR
/// engines, settings, saved-event reads or calculations are wired to this tab.
class WesternTimingTab extends StatelessWidget {
  const WesternTimingTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.timeline_outlined, size: 38),
            SizedBox(height: 16),
            Text('Western Progression',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
                textAlign: TextAlign.center),
            SizedBox(height: 10),
            Text('కొత్తగా ప్రారంభించేందుకు సిద్ధం.',
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
