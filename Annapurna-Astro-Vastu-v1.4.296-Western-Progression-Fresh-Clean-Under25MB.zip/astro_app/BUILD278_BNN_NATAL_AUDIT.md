# BNN v1.4.278 – chart fingerprint & natal rule-match audit

- The v1.4.277 diagnostics showed 90/462 fully parseable natal IFs and 6 TRUE for the user's currently open chart. This does not imply 462 rules were evaluated.
- This revision **does not force any IF to true** and does not alter the original 462 source conditions/results/statuses.
- Moves the exact natal IF diagnostic ahead of the 144-topic presentation to keep results-first.
- Displays the natal Jupiter/Mars/Saturn/Rahu/Ketu sign-degrees and computed Jupiter-relative bhava as an auditable chart fingerprint.
- For each TRUE rule displays the *complete original IF text* and matched planetary positions, not only the THEN sentence.
- Adds explicit regression tests using the supplied earlier screenshot positions. Those show C09, E10, E51, I42 must be false, and E34 and I18 true, **for that particular chart**. If the installed app displays a different chart, it is a different test input and results may differ.
- The chart signature permits diagnosing whether chart input changes or a stale screenshot produced a seeming contradiction.
- Flutter/Dart SDK unavailable in this generation environment; the ZIP requires GitHub Actions to compile and execute tests.
- BNN astrological interpretations are historical/symbolic source statements and no scientific prediction guarantees are claimed.
