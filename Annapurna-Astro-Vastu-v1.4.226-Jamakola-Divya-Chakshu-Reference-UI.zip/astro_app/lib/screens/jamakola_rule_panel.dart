import 'package:flutter/material.dart';
import 'package:sweph/sweph.dart';

import '../astrology/astro_calculation_service.dart';
import '../astrology/astro_models.dart';
import '../astrology/jamakola_rule_engine.dart';
import '../astrology/vedic_calculation_service.dart';
import '../models/birth_data.dart';
import '../services/place_search_service.dart';

/// Reference-inspired Jamakola consultation interface.
/// Swiss Ephemeris provides ordinary sidereal planets and Udayam (ascendant).
/// Jamakola-specific Arudam/Chatra/Jama cycles are NOT derived without their
/// independently verified algorithms: users may enter verified source values.
class JamakolaRulePanel extends StatefulWidget {
  const JamakolaRulePanel({super.key, required this.birthData});
  final BirthData birthData;

  @override
  State<JamakolaRulePanel> createState() => _JamakolaRulePanelState();
}

class _JamakolaRulePanelState extends State<JamakolaRulePanel> {
  static const _maroon = Color(0xFFB30000);
  static const _cream = Color(0xFFFFFBD3);
  static const _pink = Color(0xFFFF0752);
  static const _teSigns = <String>[
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం',
  ];
  static const _signShort = <String>[
    'మేష','వృష','మిథు','కర్కా','సింహ','కన్య',
    'తుల','వృశ్చి','ధను','మకర','కుంభ','మీనం',
  ];
  static const _planetTe = <String,String>{
    'Sun':'రవి','Moon':'చంద్ర','Mars':'కుజ','Mercury':'బుధ',
    'Jupiter':'గురు','Venus':'శుక్ర','Saturn':'శని',
    'Rahu':'రాహు','Ketu':'కేతు',
  };
  static const _short = <String,String>{
    'Sun':'Su','Moon':'Mo','Mars':'Ma','Mercury':'Me',
    'Jupiter':'Ju','Venus':'Ve','Saturn':'Sa','Rahu':'Ra','Ketu':'Ke',
  };
  static const _weekdays = <String>[
    'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday',
  ];
  static const _confirmationFields = <String>[
    'Jama Planet Crossed Udaya',
    'Jama Planet approaching Udaya',
    'Inner Planets in Udaya',
    'Udaya to Aruda bhava connection',
    'Udaya to Chatra bhava connection',
    'Exalted Inner Planets',
    'Exalted Jama Planets',
    'Debilitated Inner Planets',
    'Debilitated Jama Planets',
    'Same Inner and Jama Planet',
    '10th Lord bhava connections',
    'Inner Planets Parivarthana',
    'Jama Planets Parivarthana',
    'Inner-Jama Planets Parivarthana',
    'Chatra catching',
  ];

  late DateTime _localMoment;
  late final TextEditingController _place;
  late final TextEditingController _latitude;
  late final TextEditingController _longitude;
  late final TextEditingController _utcOffset;
  final _arudam = TextEditingController();
  final _chatra = TextEditingController();
  final _mandi = TextEditingController();
  final _yamaghan = TextEditingController();
  late Future<AstroChartResult> _chartFuture;
  late final Future<List<JamakolaRule>> _ruleFuture;
  bool _stale = false;
  bool _coordinatesVerified = true;
  bool _latUpdated = true;
  bool _lonUpdated = true;
  bool _bhava = false;
  bool _searchingPlace = false;
  String? _approaching;
  String? _gowri;
  int? _kavipuSign;

  @override
  void initState() {
    super.initState();
    final offset = widget.birthData.timezoneOffsetHours;
    _localMoment = DateTime.now().toUtc().add(
      Duration(minutes:(offset*60).round()));
    _place = TextEditingController(text:widget.birthData.place);
    _latitude = TextEditingController(text:widget.birthData.latitude.toStringAsFixed(5));
    _longitude = TextEditingController(text:widget.birthData.longitude.toStringAsFixed(5));
    _utcOffset = TextEditingController(text:offset.toString());
    _chartFuture = _calculateChart();
    _ruleFuture = JamakolaRuleEngine.load();
  }

  @override
  void dispose() {
    for (final c in [_place,_latitude,_longitude,_utcOffset,
      _arudam,_chatra,_mandi,_yamaghan]) { c.dispose(); }
    super.dispose();
  }

  double? get _lat => double.tryParse(_latitude.text.trim());
  double? get _lon => double.tryParse(_longitude.text.trim());
  double? get _offset => double.tryParse(_utcOffset.text.trim());

  Future<AstroChartResult> _calculateChart() {
    final lat = _lat, lon = _lon, tz = _offset;
    if (lat==null || lon==null || tz==null || !_coordinatesVerified ||
        lat < -90 || lat > 90 || lon < -180 || lon > 180 ||
        tz < -12 || tz > 14) {
      return Future.error(StateError('Place, Latitude, Longitude, UTC Offset సరిచూడండి.'));
    }
    return AstroCalculationService.calculate(BirthData(
      name:'Jamakola ప్రశ్న',localDateTime:_localMoment,
      place:_place.text.trim(),latitude:lat,longitude:lon,
      timezoneOffsetHours:tz,ayanamsa:widget.birthData.ayanamsa,
    ));
  }

  void _recalculate() {
    setState(() { _chartFuture = _calculateChart(); _stale = false; });
  }

  void _markStale() => setState(() => _stale=true);

  void _now() {
    final tz = _offset ?? widget.birthData.timezoneOffsetHours;
    _localMoment=DateTime.now().toUtc().add(
      Duration(minutes:(tz*60).round()));
    _recalculate();
  }

  Future<void> _selectDate() async {
    final selected = await showDatePicker(
      context:context,firstDate:DateTime(1800),lastDate:DateTime(2200),
      initialDate:_localMoment);
    if (selected==null || !mounted) return;
    setState(() {
      _localMoment=DateTime(selected.year,selected.month,selected.day,
        _localMoment.hour,_localMoment.minute);_stale=true;
    });
  }
  Future<void> _selectTime() async {
    final selected = await showTimePicker(context:context,
      initialTime:TimeOfDay(hour:_localMoment.hour,minute:_localMoment.minute));
    if (selected==null || !mounted) return;
    setState(() {
      _localMoment=DateTime(_localMoment.year,_localMoment.month,_localMoment.day,
        selected.hour,selected.minute);_stale=true;
    });
  }

  Future<void> _searchPlace() async {
    if (_searchingPlace) return;
    setState(() => _searchingPlace=true);
    try {
      final results=await PlaceSearchService.search(_place.text);
      if (!mounted) return;
      if (results.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content:Text('స్థలం కనపడలేదు. మరో పేరు ప్రయత్నించండి.')));
        return;
      }
      await showModalBottomSheet<void>(context:context,isScrollControlled:true,
        builder:(sheet)=>SafeArea(child:ConstrainedBox(
          constraints:BoxConstraints(maxHeight:MediaQuery.sizeOf(sheet).height*0.7),
          child:ListView(children:[
            const ListTile(title:Text('స్థలం ఎంచుకోండి')),
            for(final item in results)
              ListTile(title:Text(item.displayName),
                subtitle:Text('${item.latitude}, ${item.longitude}'),
                onTap:(){
                  _place.text=item.displayName;
                  _latitude.text=item.latitude.toStringAsFixed(6);
                  _longitude.text=item.longitude.toStringAsFixed(6);
                  setState(() { _coordinatesVerified=true;_stale=true; });
                  Navigator.pop(sheet);
                }),
          ]))));
    } catch(e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content:Text('స్థలం వెతకలేకపోయాం: $e')));
    } finally {
      if (mounted) setState(() => _searchingPlace=false);
    }
  }

  static String _two(int v)=>v.toString().padLeft(2,'0');
  static double _norm(double v)=>(v%360+360)%360;
  static String _dms(double value) {
    final seconds=(_norm(value)*3600).round()%(360*3600);
    final d=seconds~/3600, m=(seconds%3600)~/60,s=seconds%60;
    return '${d}° ${_two(m)}′ ${_two(s)}″';
  }
  static String _inSign(double value) => _dms(_norm(value)%30);
  static String _longitudeString(double value)=>
    '${_two((_norm(value)/30).floor())}s ${_inSign(value)}';
  static String _date(DateTime d)=>'${_two(d.day)}-${_two(d.month)}-${d.year}';
  static String _time(DateTime d)=>'${_two(d.hour)}:${_two(d.minute)}';

  double? _optionalLongitude(TextEditingController c) {
    if(c.text.trim().isEmpty)return null;
    final n=double.tryParse(c.text.trim());
    return n==null || n<0 || n>=360 ? null : n;
  }
  int? _manualSign(TextEditingController c) =>
    _optionalLongitude(c)==null?null:(_optionalLongitude(c)!/30).floor();

  Widget _input(TextEditingController ctrl,String label,
      {ValueChanged<String>? onChanged, bool numeric=false}) =>
    TextField(controller:ctrl,
      keyboardType:numeric?const TextInputType.numberWithOptions(decimal:true,
        signed:true):TextInputType.text,
      onChanged:onChanged,
      decoration:InputDecoration(labelText:label,isDense:true,
        border:const OutlineInputBorder()));

  Widget _top() {
    return Container(color:_cream,padding:const EdgeInsets.all(12),
      child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
        Container(color:_maroon,padding:const EdgeInsets.symmetric(
          vertical:10,horizontal:14),child:const Text('Jamakola / జామకోళ ప్రశ్న చక్రం',
          style:TextStyle(color:Colors.white,fontSize:19,
            fontWeight:FontWeight.bold))),
        const SizedBox(height:12),
        Row(children:[
          Expanded(child:_input(_place,'Place / స్థలం',onChanged:(_){
            setState(() {_coordinatesVerified=false;_latUpdated=false;_lonUpdated=false;_stale=true;});
          })),
          const SizedBox(width:6),
          IconButton(onPressed:_searchingPlace?null:_searchPlace,
            tooltip:'Village / Place Search',icon:_searchingPlace
              ?const SizedBox(height:18,width:18,child:CircularProgressIndicator(strokeWidth:2))
              :const Icon(Icons.search)),
        ]),
        const SizedBox(height:8),
        Row(children:[
          Expanded(child:_headerButton(_date(_localMoment),_selectDate,Colors.black)),
          const SizedBox(width:4),
          Expanded(child:_headerButton(_time(_localMoment),_selectTime,Colors.black)),
          const SizedBox(width:4),
          Expanded(child:_headerButton('NOW',_now,const Color(0xFFFF9400),
            textColor:Colors.black)),
        ]),
        const SizedBox(height:8),
        Row(children:[
          Expanded(child:_input(_latitude,'Latitude',numeric:true,onChanged:(_){
            setState(() { _latUpdated=true;_coordinatesVerified=_latUpdated&&_lonUpdated;_stale=true;});
          })),
          const SizedBox(width:5),
          Expanded(child:_input(_longitude,'Longitude',numeric:true,onChanged:(_){
            setState(() { _lonUpdated=true;_coordinatesVerified=_latUpdated&&_lonUpdated;_stale=true;});
          })),
          const SizedBox(width:5),
          SizedBox(width:82,child:_input(_utcOffset,'UTC ±',numeric:true,
            onChanged:(_)=>_markStale())),
        ]),
        if(!_coordinatesVerified) const Padding(
          padding:EdgeInsets.only(top:5),
          child:Text('స్థలం పేరు మారింది. Searchతో స్థలం ఎంచుకోండి లేదా సరైన Coordinates ఇవ్వండి.',
            style:TextStyle(color:Color(0xFFAA3300),fontSize:12))),
        const SizedBox(height:8),
        FilledButton.icon(onPressed:_recalculate,
          icon:const Icon(Icons.calculate_outlined),
          label:const Text('చక్రం గణించండి'),
          style:FilledButton.styleFrom(backgroundColor:_maroon)),
        const Divider(height:20,thickness:2,color:Colors.black),
      ]));
  }

  Widget _headerButton(String label,VoidCallback action,Color bg,
    {Color textColor=Colors.white})=>SizedBox(height:46,
      child:Material(color:bg,child:InkWell(onTap:action,
        child:Center(child:Text(label,maxLines:1,
          style:TextStyle(color:textColor,fontSize:16,fontWeight:FontWeight.bold))))));

  /// Finds locally observable planetary hora using actual sunrise and sunset.
  /// It is *not* the unverified Jamakola Jama-planet calculation.
  String _hora() {
    final lat=_lat,lon=_lon,tz=_offset;
    if(lat==null||lon==null||tz==null)return '—';
    final utc=DateTime.utc(_localMoment.year,_localMoment.month,_localMoment.day,
      _localMoment.hour,_localMoment.minute)
      .subtract(Duration(minutes:(tz*60).round()));
    double jd(DateTime d)=>Sweph.swe_julday(d.year,d.month,d.day,
      d.hour+d.minute/60+d.second/3600,CalendarType.SE_GREG_CAL);
    double? rise(double from, bool sunrise){
      final t=Sweph.swe_rise_trans(from,HeavenlyBody.SE_SUN,
        SwephFlag.SEFLG_MOSEPH,
        sunrise?RiseSetTransitFlag.SE_CALC_RISE:RiseSetTransitFlag.SE_CALC_SET,
        GeoPosition(lon,lat),0,0);
      if(t==null || !t.isFinite)return null;
      return t;
    }
    try {
      final dayStart=DateTime.utc(_localMoment.year,_localMoment.month,
        _localMoment.day).subtract(Duration(minutes:(tz*60).round()));
      final sunriseToday=rise(jd(dayStart),true);
      if(sunriseToday==null)return '—';
      final todayJd=jd(utc);
      final before=todayJd<sunriseToday;
      final start=before?rise(jd(dayStart)-1,true):sunriseToday;
      if(start==null)return '—';
      final sunset=rise(start+0.01,false);
      if(sunset==null)return '—';
      final nextRise=rise(sunset+0.01,true);
      if(nextRise==null)return '—';
      final sunlight=todayJd<sunset;
      final segment=sunlight?(sunset-start)/12:(nextRise-sunset)/12;
      if(segment<=0)return '—';
      final elapsed=sunlight?(todayJd-start):(todayJd-sunset);
      final index=(elapsed/segment).floor().clamp(0,11).toInt()+(sunlight?0:12);
      const cycle=['Sun','Venus','Mercury','Moon','Saturn','Jupiter','Mars'];
      final todayWeekday=before
        ?(_localMoment.weekday==1?7:_localMoment.weekday-1)
        :_localMoment.weekday;
      const dayLord=['Moon','Mars','Mercury','Jupiter','Venus','Saturn','Sun'];
      final first=cycle.indexOf(dayLord[todayWeekday-1]);
      return '${cycle[(first+index)%7]} (${index+1}వ హోరా)';
    } catch (_) {return '—';}
  }

  Widget _selectedChart(AstroChartResult chart){
    final ar=_optionalLongitude(_arudam);
    final ch=_optionalLongitude(_chatra);
    final rows=<({String key,double? longitude, String label})>[
      (key:'Udayam',longitude:chart.ascendantLongitude,label:'Udayam'),
      (key:'Arudam',longitude:ar,label:'Arudam'),
      (key:'Chatra',longitude:ch,label:'Chatra'),
      for(final p in chart.planets)
        (key:p.name,longitude:p.longitude,label:p.name),
      (key:'Mandi',longitude:_optionalLongitude(_mandi),label:'Mandi'),
      (key:'Yamaghan',longitude:_optionalLongitude(_yamaghan),label:'Yamaghan'),
    ];
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      Padding(padding:const EdgeInsets.all(8),child:Wrap(
        alignment:WrapAlignment.spaceBetween,spacing:12,runSpacing:3,
        children:[Text('Day of Week: ${_weekdays[_localMoment.weekday-1]}',
            style:const TextStyle(fontWeight:FontWeight.w600)),
          Text('Hora: ${_hora()}',style:const TextStyle(fontWeight:FontWeight.w600))])),
      const Divider(color:Colors.black,thickness:2),
      Row(mainAxisAlignment:MainAxisAlignment.center,children:[
        const Text('House System  ',style:TextStyle(fontWeight:FontWeight.bold)),
        Radio<bool>(value:false,groupValue:_bhava,onChanged:(v)=>setState(()=>_bhava=false)),
        const Text('Sign'),
        Radio<bool>(value:true,groupValue:_bhava,onChanged:(v)=>setState(()=>_bhava=true)),
        const Text('Bhava'),
      ]),
      Container(color:_pink,padding:const EdgeInsets.symmetric(vertical:7,horizontal:8),
        child:Wrap(alignment:WrapAlignment.center,spacing:10,runSpacing:4,
          children:[for(final p in chart.planets.take(5))
            Text('${_short[p.name]} ${_dms(p.longitude)}',
              style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w700,fontSize:11))])),
      _JamakkolSouthChart(chart:chart,bhava:_bhava,
        arudam:ar,chatra:ch,cream:_cream,pink:_pink,
        lat:_lat!,lon:_lon!),
      Container(color:_pink,padding:const EdgeInsets.symmetric(vertical:7,horizontal:8),
        child:Wrap(alignment:WrapAlignment.center,spacing:10,runSpacing:4,
          children:[for(final p in chart.planets.skip(5))
            Text('${_short[p.name]} ${_dms(p.longitude)}',
              style:const TextStyle(color:Colors.white,fontWeight:FontWeight.w700,fontSize:11))])),
      const Padding(padding:EdgeInsets.only(top:4),
        child:Text('పింక్ పట్టీలు: గణించిన సాధారణ గ్రహ గోచారం మాత్రమే; జామ గ్రహాల స్థానాలు కావు.',
          style:TextStyle(fontSize:11,color:Colors.black54))),
      const SizedBox(height:8),
      Text(_bhava?'Bhava: Swiss Ephemeris Placidus Cusps ప్రకారం గ్రహ భావస్థితులు.':
        'Sign: స్థిర రాశి స్థానాలలో గ్రహాలు. ఉదయ లగ్నం Uగా చూపబడుతుంది.',
        style:const TextStyle(fontSize:12,color:Colors.black87)),
      const SizedBox(height:12),
      const Text('గ్రహస్థితులు — కుడివైపునకు స్క్రోల్ చేయండి →',
        style:TextStyle(fontSize:16,fontWeight:FontWeight.bold)),
      const SizedBox(height:5),
      SingleChildScrollView(scrollDirection:Axis.horizontal,child:DataTable(
        headingRowColor:WidgetStateProperty.all(const Color(0xFFFFA000)),
        border:TableBorder.all(color:Colors.black87,width:1),
        columnSpacing:16,horizontalMargin:12,
        dataRowMinHeight:44,dataRowMaxHeight:55,
        columns:const [
          DataColumn(label:Text('Planets')),
          DataColumn(label:Text('Longitude')),
          DataColumn(label:Text('Degrees')),
          DataColumn(label:Text('Star')),
          DataColumn(label:Text('Pada')),
        ],
        rows:[for (final r in rows)
          DataRow(cells:[
            DataCell(Text(r.label,style:const TextStyle(fontWeight:FontWeight.w600))),
            DataCell(Text(r.longitude==null?'పెండింగ్':_longitudeString(r.longitude!))),
            DataCell(Text(r.longitude==null?'—':_dms(r.longitude!))),
            DataCell(Text(r.longitude==null?'—':
              VedicCalculationService.nakshatraNamesTe[
                VedicCalculationService.nakshatra(r.longitude!).index])),
            DataCell(Text(r.longitude==null?'—':
              '${VedicCalculationService.nakshatra(r.longitude!).pada}')),
          ]),
        ])),
      const SizedBox(height:14),
      _confirmation(chart),
      const SizedBox(height:10),
      _rulesPanel(chart),
    ]);
  }

  Widget _confirmation(AstroChartResult chart) {
    final u=chart.ascendantSignIndex;
    final a=_manualSign(_arudam),c=_manualSign(_chatra);
    final values=<String,String>{
      if(a!=null) 'Udaya to Aruda bhava connection':'${(a-u+12)%12+1}వ భావం (Manual Arudam)',
      if(c!=null) 'Udaya to Chatra bhava connection':'${(c-u+12)%12+1}వ భావం (Manual Chatra)',
    };
    return ExpansionTile(initiallyExpanded:false,
      title:const Text('Prashna Confirmation Section',
        style:TextStyle(fontWeight:FontWeight.bold,fontSize:18)),
      subtitle:const Text('ఆరూఢం/ఛత్రం గణనలు ధృవీకరించేవరకు మిగిలినవి పెండింగ్'),
      children:[
        for(final label in _confirmationFields)
          Padding(padding:const EdgeInsets.symmetric(vertical:5,horizontal:8),
            child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Expanded(flex:5,child:Text(label)),
              Expanded(flex:3,child:Text(values[label]??'గణన పెండింగ్',
                style:TextStyle(color:values.containsKey(label)
                  ?Colors.teal.shade700:Colors.grey.shade700))),
            ])),
      ]);
  }

  Widget _manualInputs(){
    return ExpansionTile(title:const Text('Arudam · Chatra · Mandi · Yamaghan — Manual Verification',
      style:TextStyle(fontSize:14,fontWeight:FontWeight.w700)),
      subtitle:const Text('ఖచ్చితమైన Jamakola విధానం అందుబాటులో లేకపోతే నమోదు చేయవచ్చు.'),
      children:[
        const Padding(padding:EdgeInsets.symmetric(vertical:5),child:Text(
          'రాశి సహిత 0–360° Longitude ఇవ్వండి. ఉదా: 189.75. ఖాళీగా ఉంచితే పెండింగ్.',
          style:TextStyle(fontSize:12))),
        _input(_arudam,'Arudam total degrees',numeric:true,onChanged:(_)=>setState((){})),
        const SizedBox(height:8),
        _input(_chatra,'Chatra total degrees',numeric:true,onChanged:(_)=>setState((){})),
        const SizedBox(height:8),
        _input(_mandi,'Mandi total degrees',numeric:true,onChanged:(_)=>setState((){})),
        const SizedBox(height:8),
        _input(_yamaghan,'Yamaghan total degrees',numeric:true,onChanged:(_)=>setState((){})),
        const SizedBox(height:8),
        DropdownButtonFormField<int>(value:_kavipuSign,isExpanded:true,
          decoration:const InputDecoration(labelText:'కవిప్పు రాశి (Manual)',
            border:OutlineInputBorder()),
          items:[for(var i=0;i<12;i++)DropdownMenuItem(value:i,child:Text(_teSigns[i]))],
          onChanged:(v)=>setState(()=>_kavipuSign=v)),
        const SizedBox(height:8),
        DropdownButtonFormField<String>(value:_approaching,isExpanded:true,
          decoration:const InputDecoration(labelText:'ఉదయాన్ని సమీపించే గ్రహం (Manual)',
            border:OutlineInputBorder()),
          items:[for(final e in _planetTe.entries)
            DropdownMenuItem(value:e.key,child:Text(e.value))],
          onChanged:(v)=>setState(()=>_approaching=v)),
        const SizedBox(height:8),
        DropdownButtonFormField<String>(value:_gowri,isExpanded:true,
          decoration:const InputDecoration(labelText:'గౌరీ కాలం (Manual)',
            border:OutlineInputBorder()),
          items:const [
            DropdownMenuItem(value:'Uthiyogam',child:Text('ఉద్యోగం')),
            DropdownMenuItem(value:'Amirtham',child:Text('అమృతం')),
            DropdownMenuItem(value:'Rogam',child:Text('రోగం')),
            DropdownMenuItem(value:'Laabam',child:Text('లాభం')),
            DropdownMenuItem(value:'Dhanam',child:Text('ధనం')),
            DropdownMenuItem(value:'Shubam',child:Text('శుభం')),
            DropdownMenuItem(value:'Choram',child:Text('చోరం')),
            DropdownMenuItem(value:'Visham',child:Text('విషం')),
          ],onChanged:(v)=>setState(()=>_gowri=v)),
        const SizedBox(height:12),
      ]);
  }

  Widget _rulesPanel(AstroChartResult chart) {
    final facts=<String,dynamic>{};
    if(_approaching!=null)facts['approaching_udhayam']=_approaching;
    if(_gowri!=null)facts['gowri_period']=_gowri;
    final a=_manualSign(_arudam);
    if(a!=null)facts['arudam_house_from_udhayam']=
      (a-chart.ascendantSignIndex+12)%12+1;
    if(_kavipuSign!=null)facts['kavipu_house_from_udhayam']=
      (_kavipuSign!-chart.ascendantSignIndex+12)%12+1;
    final saturn=chart.planets.where((p)=>p.name=='Saturn').firstOrNull;
    if(saturn?.signIndex==6)facts['saturn_dignity']='exalted';
    if(saturn?.signIndex==0)facts['saturn_dignity']='debilitated';
    return FutureBuilder<List<JamakolaRule>>(future:_ruleFuture,
      builder:(context,snapshot) {
        if(snapshot.hasError)return Text('నియమాల డేటా లభించలేదు: ${snapshot.error}');
        if(!snapshot.hasData)return const LinearProgressIndicator();
        final complete=<JamakolaRule>[],failed=<JamakolaRule>[],pending=<JamakolaRule>[];
        for(final r in snapshot.data!){
          if(r.conditions.keys.any((k)=>!facts.containsKey(k))) {
            pending.add(r);
          } else if(JamakolaRuleEngine.matches(r,facts)){complete.add(r);} else {
            failed.add(r);
          }
        }
        return ExpansionTile(title:Text(
          'IF–THEN నియమాలు: సరిపోయినవి ${complete.length} · సరిపోనివి ${failed.length} · పెండింగ్ ${pending.length}'),
          subtitle:const Text('పూర్తి షరతు మాత్రమే మ్యాచ్‌గా గుర్తించబడుతుంది'),
          children:[
            for (final r in complete)
              ListTile(leading:const Icon(Icons.check_circle_outline,color:Colors.green),
                title:Text(r.result),
                subtitle:Text('${r.id} · ${r.sourceFile} · పేజీ ${r.sourcePage}')),
            for (final r in failed)
              ListTile(leading:const Icon(Icons.cancel_outlined,color:Colors.pink),
                title:Text(r.result),subtitle:Text('${r.id}: షరతు సరిపోలలేదు')),
            if (pending.isNotEmpty) ExpansionTile(
              title:Text('ఇంకా అవసరమైన ఆధారాలు (${pending.length})'),
              children:[for(final r in pending)
                ListTile(title:Text(r.id),
                  subtitle:Text('కావలసినవి: ${r.conditions.keys.where((k)=>!facts.containsKey(k)).join(', ')}'))]),
            const Padding(padding:EdgeInsets.all(8),child:Text(
              'నియమం మ్యాచ్ అయ్యిందంటే సాంప్రదాయ సూచన మాత్రమే. సంఘటన ధృవీకరణ లేదా శాస్త్రీయ సంభావ్యత శాతం కాదు.',
              style:TextStyle(fontSize:12))),
          ]);
      });
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
      _top(),
      if(_stale) const Card(child:Padding(padding:EdgeInsets.all(12),
        child:Text('ఇన్‌పుట్ మార్చారు. కొత్త చక్రం కోసం “చక్రం గణించండి” నొక్కండి.',
          style:TextStyle(color:Colors.deepOrange)))),
      if(!_stale) FutureBuilder<AstroChartResult>(future:_chartFuture,
        builder:(context,snapshot) {
          if(snapshot.hasError) return Padding(padding:const EdgeInsets.all(12),
            child:Text('గణన అందుబాటులో లేదు: ${snapshot.error}',
              style:const TextStyle(color:Colors.red)));
          if(!snapshot.hasData)return const Padding(
            padding:EdgeInsets.all(14),child:LinearProgressIndicator());
          return _selectedChart(snapshot.data!);
        }),
      const SizedBox(height:8),
      _manualInputs(),
      const SizedBox(height:8),
      const ExpansionTile(title:Text('చక్రం ఉపయోగించే సూచనలు'),children:[
        Padding(padding:EdgeInsets.all(10),child:Text(
          '1. రాశి చక్రంలో U = ఉదయ లగ్నం. రంగు కేవలం ప్రదర్శనకు మాత్రమే.\n'
          '2. గ్రహ స్థితులు Swiss Ephemeris ఆధారంగా, ఎంచుకున్న అయనాంశంతో గణిస్తాయి.\n'
          '3. Bhava బటన్ Placidus భావస్థానాలను చూపిస్తుంది.\n'
          '4. Arudam, Chatra, Jama planets వంటి Jamakola-ప్రత్యేక గణనలకు ధృవీకృత సూత్రాలు అవసరం; మూలం లేని డేటా గణించినట్లు చూపించదు.\n'
          '5. Hora స్థానిక సూర్యోదయం–సూర్యాస్తమయం ఆధారంగా సాధారణ Planetary Hora మాత్రమే; Jama Cycle కాదు.')),
      ]),
    ]);
  }
}

class _JamakkolSouthChart extends StatelessWidget {
  const _JamakkolSouthChart({required this.chart,required this.bhava,
    required this.arudam,required this.chatra,required this.cream,
    required this.pink,required this.lat,required this.lon});
  final AstroChartResult chart;
  final bool bhava;
  final double? arudam, chatra;
  final Color cream,pink;
  final double lat,lon;

  static const _cells=<int>[
    11,0,1,2,
    10,-1,-1,3,
    9,-1,-1,4,
    8,7,6,5,
  ];
  static String _sign(int v)=>_JamakolaRulePanelState._signShort[v];
  static String _short(String v)=>_JamakolaRulePanelState._short[v]??v;
  static double _norm(double v)=>(v%360+360)%360;

  List<List<String>> _contents(){
    final c=List.generate(12,(_)=><String>[]);
    if(!bhava){
      c[chart.ascendantSignIndex].add('U');
      if(arudam!=null)c[(arudam!/30).floor()%12].add('ARU');
      if(chatra!=null)c[(chatra!/30).floor()%12].add('CHA');
      for(final p in chart.planets) c[p.signIndex].add(_short(p.name));
    }else{
      try {
        final v=Sweph.swe_houses_ex(chart.julianDay,
          SwephFlag.SEFLG_SIDEREAL,lat,lon,Hsys.P).cusps;
        if(v.length!=12&&v.length!=13) return c;
        final cusps=v.length==12?v:v.skip(1).take(12).toList();
        int h(double longitude){
          for(var i=0;i<12;i++) {
            final start=_norm(cusps[i]),end=_norm(cusps[(i+1)%12]);
            final span=_norm(end-start),delta=_norm(longitude-start);
            if(span>0&&delta<span)return i;
          }
          return 0;
        }
        c[0].add('U');
        if(arudam!=null)c[h(arudam!)].add('ARU');
        if(chatra!=null)c[h(chatra!)].add('CHA');
        for(final p in chart.planets)c[h(p.longitude)].add(_short(p.name));
      } catch (_) {return c;}
    }
    return c;
  }

  @override
  Widget build(BuildContext context){
    final positions=_contents();
    return LayoutBuilder(builder:(context,constraints){
      final w=constraints.maxWidth.clamp(200.0,510.0).toDouble();
      final cell=w/4;
      return Center(child:SizedBox(width:w,height:w,
        child:Stack(children:[
          for(var i=0;i<16;i++)if(_cells[i]>=0)
            Positioned(left:(i%4)*cell,top:(i~/4)*cell,
              width:cell,height:cell,
              child:Container(decoration:BoxDecoration(
                color:cream,border:Border.all(color:Colors.black,width:1.5)),
                padding:const EdgeInsets.all(4),
                child:Column(crossAxisAlignment:CrossAxisAlignment.start,
                  children:[
                    Text(bhava?'భావ ${_cells[i]+1}':_sign(_cells[i]),
                      style:const TextStyle(fontSize:11,fontWeight:FontWeight.bold)),
                    Expanded(child:Align(alignment:Alignment.topLeft,
                      child:Wrap(spacing:3,runSpacing:1,
                        children:[for(final p in positions[_cells[i]])
                          Text(p,style:TextStyle(fontSize:12,
                            color:p=='U'||p=='ARU'||p=='CHA'?Colors.deepPurple:Colors.black,
                            fontWeight:FontWeight.w800))]))),
                  ]))),
          Positioned(left:cell,top:cell,width:2*cell,height:2*cell,
            child:Container(decoration:BoxDecoration(color:cream,
              border:Border.all(color:Colors.black,width:2)),
              child:Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
                Text(bhava?'Bhava Chart':'Rashi Chart',
                  style:const TextStyle(fontSize:21,fontWeight:FontWeight.bold)),
                const SizedBox(height:8),
                Text('U = Udayam',style:TextStyle(fontSize:12,color:pink)),
                const Text('ARU / CHA = Manual',style:TextStyle(fontSize:11)),
              ])))),
        ])));
    });
  }
}
