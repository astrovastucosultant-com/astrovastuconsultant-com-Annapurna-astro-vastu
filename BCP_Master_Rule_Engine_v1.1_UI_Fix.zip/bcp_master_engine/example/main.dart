import 'dart:convert';
import 'package:bcp_master_engine/bcp_master_engine.dart';

void main() {
  // Illustrative chart only; these are NOT actual planetary positions.
  final chart = NatalChart(ascendantSign: 1, longitudes: {
    'sun': 2, 'moon': 93, 'mars': 41, 'mercury': 350,
    'jupiter': 250, 'venus': 185, 'saturn': 282,
    'rahu': 315, 'ketu': 135,
  });
  final activation = BcpEngine.activations(
    chart: chart,
    birthDate: DateTime(1990, 5, 10),
    onDate: DateTime(2020, 10, 11),
    references: {BcpReference.lagna, BcpReference.mahadashaLord},
    activeMahadashaLord: 'venus',
  );
  final independentEvidence = {
    BcpEventKind.marriage: BcpEventEvidence(
      natalPromise: true, natalRuleVerified: true,
      natalRuleId: 'USER-SOURCE-MARRIAGE-001',
      natalSourceName: 'Example verified rulebook',
      // A page number is omitted rather than invented.
      dashaSupported: true,
      transitSupported: true,
      dashaWindow: DateWindow(DateTime(2020, 6, 1), DateTime(2021, 4, 1)),
      transitWindow: DateWindow(DateTime(2020, 8, 1), DateTime(2021, 1, 1)),
    ),
  };
  for (final active in activation) {
    final findings = BcpEngine.evaluate(
      chart: chart, activation: active, evidenceByEvent: independentEvidence);
    for (final f in findings) {
      print(const JsonEncoder.withIndent('  ').convert(f.toReport()));
    }
  }
}
