# అన్నపూర్ణ ఆస్ట్రో వాస్తు — BCP Master Rule Engine v1.1

**స్థితి:** స్వతంత్ర Dart source package సిద్ధం. యాప్‌కు అనుసంధానం/Flutter build/API testing కాలేదు (ఈ వాతావరణంలో Dart/Flutter SDK అందుబాటులో లేదు).

## విభజన (మూల నియమాలు vs యాప్ నియమాలు)

| Rule ID | భాగం | రకం |
|---|---|---|
| BCP-CORE-001 | 1వ running year=లగ్నం నుంచి 1వ భావం; ప్రతి 12 ఏళ్లకు పునరావృతం | ఆధారిత పద్ధతి |
| BCP-CORE-002 | Completed age కాదు; running year తీసుకోవాలి | ఆధారిత పద్ధతి |
| BCP-EXT-001 | మహాదశానాథుని జన్మరాశి నుంచి BCP భవ గణన | ప్రచురిత వైవిధ్యం |
| BCP-EXT-002 | డిగ్రీ ఆధారిత within-year tentative trigger | ప్రచురిత ప్రయోగ పద్ధతి |
| BCP-VAR-001 | 12-year cycle rulers (Moon, Mercury, Venus, Sun, Mars, Jupiter, Saturn, Rahu, Ketu) | M. Imran ప్రతిపాదిత వైవిధ్యం |
| BCP-VAR-002 | చంద్రలగ్నం నుంచి cross-check | అదనపు విధానం |
| AAV-BCP-EVT-001…026 | సంఘటన–భావ–కారక mapping | అన్నపూర్ణ కోసం రూపొందించిన నియమాలు |
| AAV-BCP-HOUSE-001…012 | 12 భావాల అంశాల మ్యాపింగ్ | అన్నపూర్ణ కోసం రూపొందించిన నియమాలు |
| AAV-BCP-GATE-001 | Natal verified + dasha + transit + interval overlap | అన్నపూర్ణ సమీకృత Timing నియమం |
| AAV-BCP-BTR-001 | తెలిసిన జీవిత సంఘటనలతో trial charts match count | అన్నపూర్ణ BTR సహాయక లేయర్ |

## జ్యోతిష్య గణన

- **Year** = పుట్టినరోజు నుంచి తదుపరి పుట్టినరోజు వరకు `completed_age+1`.
- **House** = `((running_year - 1) % 12) + 1`.
- **Lagna activated sign** = `((asc_sign + house - 2) % 12) + 1`.
- **Dasha activated sign** = `((dasha_lord_natal_sign + house - 2) % 12) + 1`.
- **Cycle rulers**: 1–12 Moon, 13–24 Mercury, 25–36 Venus, 37–48 Sun, 49–60 Mars, 61–72 Jupiter, 73–84 Saturn, 85–96 Rahu, 97–108 Ketu. ఆ తరువాత ఈ implementation ruler ఊహించదు.
- **Degree trigger** = `birthday + ((next_birthday - birthday) * degree_in_sign/30)`; అంచనా మాత్రమే. 30°≈365.2425 రోజులుగా తీసుకున్న మూల పద్ధతికి calendar-accurate adaptation.

## అవసరమైన Inputs

`birthDate`, `onDate`, `ascendantSign (1=మేషం .. 12=మీనం)`, సైడీరియల్ 0…360° graha longitudes, user-selected reference modes. Maha Dasha reference ఎంచుకుంటే ఆ తేదీలోని **active** Maha Dasha lord తప్పనిసరి.

ప్రతి సంఘటనకు స్వతంత్ర D1/D9/D10/D7 వర్గ/మూలగ్రంథ rule matcher నుంచి `natalPromise`, `natalRuleVerified`, `natalRuleId`, నిజమైన source+page; Vimshottari engine నుంచి dasha evidence + సమయ పరిధి; transit engine నుంచి transit evidence + సమయ పరిధి ఇవ్వాలి. ఎటువంటి పేజీ/పరిహారం engine స్వయంగా సృష్టించదు.

## IF–THEN Event Decision

```
IF active_BCP_sign_or_natal_house LINKED_TO_EVENT
   AND verified_natal_event_rule = TRUE
   AND natal_promise = TRUE
THEN status = YEAR_CANDIDATE
ELSE hide_from_applied_results

IF YEAR_CANDIDATE
   AND dasha_supported = TRUE
   AND transit_supported = TRUE
   AND INTERSECTION(BCP_YEAR, DASHA_WINDOW, TRANSIT_WINDOW) != EMPTY
THEN status = TIMING_CANDIDATE
ELSE retain YEAR_CANDIDATE or mark insufficient evidence
```

**`TIMING_CANDIDATE` అనేది హామీ కాదు**. overlap 2020-08-01…2021-01-01 వంటి వెడల్పాటి పరిధి కావచ్చు; శాస్త్రీయంగా నిర్ధారించబడిన probability లేదు. BCP తేదీ డిగ్రీ trigger ను విడిగా annotate చేయాలి; triggerని exact-day guaranteeగా చూపకూడదు.

## Input data / House logic

- Whole-sign houses; Parashari aspects: all eligible grahas 7th, Mars 4/7/8, Jupiter 5/7/9, Saturn 3/7/10. Rahu/Ketu aspects code లో deliberate గా లేవు (పాఠశాలల మధ్య భేదం).
- Traditional single lords Scorpio=Mars, Aquarius=Saturn. Co-lords interpretation configurable upstream కావచ్చు.
- Sidereal longitudes/ayanamsa consistency mandatory.
- Date-only calculations LOCAL calendar-based; February 29 birthday non-leap year March 1గా తీసుకుంటుంది; మార్చుకోవాలంటే upstream policy మార్చాలి.
- Running-year day precision ఉపయోగిస్తే leap and time zone/solar return policies వేరుగా verify చేయాలి.
- Extra trigger points (Upagraha, Saham, Arudha) supplied by external engine only; never invented.

## యాప్‌లో UI అమరిక

**BCP tab** → సంవత్సరం/వయస్సు → రాశి చక్రం (లగ్నం+డిగ్రీలు) → Activated House → Year Events (Applied only) → పలితం టచ్ → Rule ID / source → జాతక పరిశీలన → పరిహారం (మూలంలో ఉంటే మాత్రమే).

**వేరుగా**: BCP–1, BCP–2, BCP–3, Chandra, Cycle Ruler tabs. ఒకే సంఘటనకు బహుళ ఆధారాలను final Unified Timing Engineకి పంపాలి; వాటి పేర్లతో వేర్వేరు final dates చూపకూడదు.

**BTR**: Trial birth time కి ప్రతిసారి Lagna/longitudes/vargas రీకాల్క్యులేట్ చేసి known events match count మాత్రమే చూపాలి. ఇది సమయ ఖచ్చితత్వం % కాదు. 12-year BCP అంతరాలతో minute-level BTR సాధ్యం కాదు; అదనపు sensitive techniques అవసరం.

## Code files

- `lib/bcp_master_engine.dart` — standalone calculation, 26 event links, rules, degree points, BTR audit.
- `example/main.dart` — complete usage example with **synthetic** longitudes.
- `test/bcp_master_engine_test.dart` — birthday/wrap/leap/reference/evidence/overlap/BTR tests.
- `assets/bcp_rule_catalog.json` — machine-readable rule ledger.
- `pubspec.yaml` — Dart package manifest.

Flutter యాప్ `lib` లో `bcp_master_engine.dart` ను package లేదా local file import రూపంలో అనుసంధానించవచ్చు. `flutter pub get` → `flutter test` → Flutter integration → `flutter build apk` లో compile/QA అవసరం.

## పరిశీలించిన ప్రచురిత మూలాలు

1. Saptarishis Astrology, **Bhrighu Chakra Paddathi – 1**: https://saptarishisastrology.com/bhrighu-chakra-paddathi-1-by-saptarishis-astrology/
2. Saptarishis Astrology, **Bhrighu Chakra Paddathi – 2** (degree trigger): https://saptarishisastrology.com/bhrighu-chakra-paddathi-2-by-saptarishis-astrology/
3. Saptarishis, **BCP and Vimshottari Dasa**: https://saptarishisshop.com/bhrighu-chakra-paddathi-3-bcp-and-vimshottari-dasa-by-saptarishis-astrology/
4. M. Imran, **Bhrigu Chakra with Cycle Rulers**: https://saptarishisastrology.com/bhrigu-chakra-with-cycle-rulers-by-m-imran/
5. DKSCORE BCP calculator (Moon reference cross-check): https://www.dkscore.com/calculators/bhrigu-chakra-paddhati-calculator

మూలాల పేజీ నంబర్లు ఆన్‌లైన్ HTMLలో లభించలేదు; కావున కల్పిత పేజీలను పొందుపరచలేదు. ఈ astrology system's outcomes are not scientifically validated predictions.

---

## v1.1 స్క్రీన్‌షాట్ ఆధారిత UI సవరణలు

- `lib/bcp_result_screen.dart` అనే Flutter UI integration reference జోడించబడింది.
- 30%, 36%, 40% వంటి **నిర్ధారణ కాని Evidence %**లను చూపడం లేదు; వీటిని Event Probabilityగా భావించవద్దు.
- ప్రతి ఫలితానికి ప్రత్యేక `event_rule_id`, `natal_rule_id`, సాక్ష్యాలు, BCP భావం/సంవత్సరం/రాశి, తెలిసినప్పుడు మాత్రమే timing overlap.
- `BcpEngine.evaluate(includeDiagnostics:false)` ద్వారా independent natal promise మరియు verified rule లేనివి UIలో దాచబడతాయి. గ్రహ/భావ సంబంధం మాత్రమే సంఘటనగా చూపదు.
- విస్తరణ క్రమం: ఫలితం → రూల్/మూలం → జాతక పరిశీలన → స్వతంత్రంగా ధృవీకరించిన పరిహారం మాత్రమే.
- Green/Pink కేవలం host natal-rule engine నుంచి **verified favorable/unfavorable** నిర్ణయం వచ్చినప్పుడు; విషయం పేరును చూసి ఆరోగ్యం/విడాకులు వంటి అంశాలను automatic negativeగా పరిగణించదు.
- Main chart ను `natalChartWidget`గా యాప్ చార్ట్ మాడ్యూల్ నుంచి ఇవ్వాలి; ఈ standalone package Swiss Ephemerisని/గ్రహ డిగ్రీలను స్వయంగా గణించదు.
- డిగ్రీ trigger తేదీలను ప్రయోగాత్మక సూచనలుగా మాత్రమే చూపుతుంది.
- ఒకే జాతకానికి **అన్ని reference modesను కలిపి తప్పుడు స్కోరు చేయడం లేదు**; user ఒక modeను ఎంచుకోవాలి. తుది Event Timing వేరే Unified Engine నిర్ణయిస్తుంది.

### హోస్ట్ యాప్‌లో ఉపయోగం

```dart
BcpResultsScreen(
  natalChart: existingNatalChart,
  birthDate: birthDate,
  onDate: chartEvaluationDate,
  evidenceByEvent: verifiedEvidenceFromRules,
  activeMahadashaLord: activeMahadashaLord,
  natalChartWidget: natalChartWithDegrees,
  verifiedOutcomes: externallyVerifiedOutcomeLabels,
  verifiedRemediesByNatalRuleId: verifiedRemedyReferences,
)
```

ఈ UI నిజమైన Flutter ప్రాజెక్ట్‌లో ఇంకా విలీనం కాలేదు. Dart/Flutter SDK ఈ పరిసరంలో లేకపోవడంతో build/test చేయలేదు. దీని compilation ను యాప్ build pipelineలో ధృవీకరించాలి.
