import 'package:test/test.dart';
import 'package:bcp_master_engine/bcp_master_engine.dart';

void main() {
  final chart = NatalChart(ascendantSign: 1, longitudes: {
    'sun': 2, 'moon': 93, 'mars': 41, 'mercury': 350,
    'jupiter': 250, 'venus': 185, 'saturn': 282,
    'rahu': 315, 'ketu': 135,
  });
  final birth = DateTime(1990, 5, 10);
  final evidence = {
    BcpEventKind.marriage: BcpEventEvidence(
      natalPromise: true, natalRuleVerified: true,
      natalRuleId: 'USER-VERIFIED-MARRIAGE-001',
      dashaSupported: true, transitSupported: true,
      dashaWindow: DateWindow(DateTime(2020, 6), DateTime(2021, 4)),
      transitWindow: DateWindow(DateTime(2020, 8), DateTime(2021, 1)),
    ),
  };

  test('running year uses anniversary, not completed age', () {
    expect(BcpEngine.runningYear(birth, DateTime(2026, 5, 9)), 36);
    expect(BcpEngine.runningYear(birth, DateTime(2026, 5, 10)), 37);
    expect(BcpEngine.runningYear(birth, birth), 1);
  });

  test('12-house cycle wraps at birthday', () {
    final before = BcpEngine.activations(
        chart: chart, birthDate: birth,
        onDate: DateTime(2026, 5, 9)).single;
    final after = BcpEngine.activations(
        chart: chart, birthDate: birth,
        onDate: DateTime(2026, 5, 10)).single;
    expect(before.activatedHouseFromReference, 12);
    expect(after.activatedHouseFromReference, 1);
  });

  test('leap birthday becomes March 1 in non-leap years', () {
    final leapBirth = DateTime(2000, 2, 29);
    expect(BcpEngine.runningYear(leapBirth, DateTime(2025, 2, 28)), 25);
    expect(BcpEngine.runningYear(leapBirth, DateTime(2025, 3, 1)), 26);
  });

  test('optional reference changes the activated sign', () {
    final acts = BcpEngine.activations(
      chart: chart, birthDate: birth, onDate: DateTime(2020, 10, 11),
      activeMahadashaLord: 'venus',
      references: {
        BcpReference.lagna, BcpReference.moon,
        BcpReference.mahadashaLord, BcpReference.cycleRuler
      },
    );
    expect(acts.length, 4);
    expect(acts[0].activatedHouseFromReference, 7);
    expect(acts[0].activatedSign, 7); // Libra from Aries Lagna
    expect(acts[1].activatedSign, 10); // Capricorn from Cancer Moon
    expect(acts[2].activatedSign, 1); // Aries from Libra Venus
    expect(acts[3].referencePlanet, 'venus'); // third 12-year cycle
  });

  test('no unverified natal rule => no prediction', () {
    final a = BcpEngine.activations(
      chart: chart, birthDate: birth, onDate: DateTime(2020, 10, 11)).single;
    expect(BcpEngine.evaluate(
      chart: chart, activation: a, evidenceByEvent: {}), isEmpty);
  });

  test('verified natal rule + overlapping dasha and transit yields candidate', () {
    final a = BcpEngine.activations(
      chart: chart, birthDate: birth, onDate: DateTime(2020, 10, 11)).single;
    final hits = BcpEngine.evaluate(
      chart: chart, activation: a, evidenceByEvent: evidence);
    final marriage = hits.singleWhere((f) => f.event.kind == BcpEventKind.marriage);
    expect(marriage.status, BcpStatus.timingCandidate);
    expect(marriage.timingWindow!.start, DateTime(2020, 8));
    expect(marriage.timingWindow!.end, DateTime(2021, 1));
    expect(marriage.toReport()['remedy'], isNull);
  });

  test('non-overlapping intervals block a timing claim', () {
    final a = BcpEngine.activations(
      chart: chart, birthDate: birth, onDate: DateTime(2020, 10, 11)).single;
    final bad = {
      BcpEventKind.marriage: BcpEventEvidence(
        natalPromise: true, natalRuleVerified: true, natalRuleId: 'RULE-1',
        dashaSupported: true, transitSupported: true,
        dashaWindow: DateWindow(DateTime(2020, 6), DateTime(2020, 7)),
        transitWindow: DateWindow(DateTime(2020, 8), DateTime(2021, 1)),
      ),
    };
    expect(BcpEngine.evaluate(
      chart: chart, activation: a, evidenceByEvent: bad), isEmpty);
  });

  test('degree trigger points are tentative and in running year', () {
    final a = BcpEngine.activations(
      chart: chart, birthDate: birth, onDate: DateTime(2020, 10, 11)).single;
    final triggers = BcpEngine.degreeTriggers(chart: chart, activation: a);
    expect(triggers, isNotEmpty);
    expect(triggers.every((t) => a.yearWindow.contains(t.tentativeDate)), isTrue);
  });

  test('BTR is a match count, not an accuracy percentage', () {
    final audit = BcpBtr.audit(
      birthDate: birth, trialChart: chart,
      history: [ObservedBtrEvent(BcpEventKind.marriage, DateTime(2020, 10, 11))],
      evidenceByEvent: evidence,
    );
    expect(audit.matched, 1);
    expect(audit.total, 1);
  });
}
