/// Annapurna Astro Vastu: BCP verified-results view (Flutter integration example).
///
/// Requires a Flutter app, and the BCP engine in this package. This widget is
/// intentionally NOT an event probability calculator. It shows only verified
/// applied natal rules supplied by the host application's rule engine.
import 'package:flutter/material.dart';
import 'bcp_master_engine.dart';

enum BcpOutcome { favorable, unfavorable, undecided }

class BcpVerifiedRemedy {
  final String text;
  final String sourceName;
  final String? sourcePage;
  const BcpVerifiedRemedy({
    required this.text,
    required this.sourceName,
    this.sourcePage,
  });

class BcpResultsScreen extends StatefulWidget {
  final NatalChart natalChart;
  final DateTime birthDate;
  final DateTime onDate;
  final Map<BcpEventKind, BcpEventEvidence> evidenceByEvent;
  final Map<BcpEventKind, BcpOutcome> verifiedOutcomes;
  final Map<String, BcpVerifiedRemedy> verifiedRemediesByNatalRuleId;
  final String? activeMahadashaLord;
  /// Optional HOST APP's natal chart widget WITH house/planet/degree overlay.
  final Widget? natalChartWidget;

  const BcpResultsScreen({
    super.key,
    required this.natalChart,
    required this.birthDate,
    required this.onDate,
    required this.evidenceByEvent,
    this.verifiedOutcomes = const {},
    this.verifiedRemediesByNatalRuleId = const {},
    this.activeMahadashaLord,
    this.natalChartWidget,
  });

  @override
  State<BcpResultsScreen> createState() => _BcpResultsScreenState();
}

class _BcpResultsScreenState extends State<BcpResultsScreen> {
  BcpReference selected = BcpReference.lagna;

  String _date(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}-${d.month.toString().padLeft(2, '0')}-${d.year}';

  String _referenceLabel(BcpReference r) => switch (r) {
    BcpReference.lagna => 'లగ్న BCP',
    BcpReference.moon => 'చంద్రలగ్న BCP',
    BcpReference.mahadashaLord => 'మహాదశానాథుని నుంచి BCP',
    BcpReference.cycleRuler => 'Cycle Ruler (ప్రత్యామ్నాయం)',
  };

  static const _signs = [
    'మేషం', 'వృషభం', 'మిథునం', 'కర్కాటకం', 'సింహం', 'కన్య',
    'తుల', 'వృశ్చికం', 'ధనుస్సు', 'మకరం', 'కుంభం', 'మీనం',
  ];

  static const _planetNames = {
    'sun': 'రవి', 'moon': 'చంద్రుడు', 'mars': 'కుజుడు',
    'mercury': 'బుధుడు', 'jupiter': 'గురుడు', 'venus': 'శుక్రుడు',
    'saturn': 'శని', 'rahu': 'రాహువు', 'ketu': 'కేతువు',
  };

  String _linkTelugu(String raw) {
    final parts = raw.split(':');
    if (parts.length != 2) return raw;
    final value = parts[1].trim();
    final house = RegExp(r'house (\d+)').firstMatch(value)?.group(1);
    final planet = RegExp(r'-> (\w+)').firstMatch(value)?.group(1);
    String name = planet == null ? value : (_planetNames[planet] ?? planet);
    switch (parts[0]) {
      case 'DIRECT_HOUSE':
        return 'క్రియాశీల జన్మభావం: $house';
      case 'HOUSE_LORD_OCCUPIES_ACTIVE_SIGN':
        return '$houseవ భావాధిపతి $name క్రియాశీల రాశిలో ఉన్నాడు';
      case 'HOUSE_LORD_ASPECT':
        return '$houseవ భావాధిపతి $name క్రియాశీల రాశిని చూస్తున్నాడు';
      case 'KARAKA_OCCUPIES_ACTIVE_SIGN':
        return '${_planetNames[value] ?? value} క్రియాశీల రాశిలో ఉన్నాడు';
      case 'KARAKA_ASPECTS_ACTIVE_SIGN':
        return '${_planetNames[value] ?? value} క్రియాశీల రాశిని చూస్తున్నాడు';
      default:
        return raw;
    }
  }

  List<BcpReference> _availableReferences() {
    final refs = <BcpReference>[BcpReference.lagna];
    if (widget.natalChart.hasPlanet('moon')) refs.add(BcpReference.moon);
    if (widget.activeMahadashaLord != null &&
        widget.natalChart.hasPlanet(widget.activeMahadashaLord!)) {
      refs.add(BcpReference.mahadashaLord);
    }
    final year = BcpEngine.runningYear(widget.birthDate, widget.onDate);
    const rulers = [
      'moon', 'mercury', 'venus', 'sun', 'mars',
      'jupiter', 'saturn', 'rahu', 'ketu',
    ];
    final cycle = (year - 1) ~/ 12;
    if (cycle < rulers.length && widget.natalChart.hasPlanet(rulers[cycle])) {
      refs.add(BcpReference.cycleRuler);
    }
    return refs;
  }

  @override
  Widget build(BuildContext context) {
    final refs = _availableReferences();
    final ref = refs.contains(selected) ? selected : BcpReference.lagna;
    final activation = BcpEngine.activations(
      chart: widget.natalChart,
      birthDate: widget.birthDate,
      onDate: widget.onDate,
      references: {ref},
      activeMahadashaLord: widget.activeMahadashaLord,
    ).single;
    // Strictly filtered. No placeholder entries or invented event %.
    final findings = BcpEngine.evaluate(
      chart: widget.natalChart,
      activation: activation,
      evidenceByEvent: widget.evidenceByEvent,
    );

    return Scaffold(
      appBar: AppBar(title: const Text('BCP – భృగు చక్ర పద్ధతి')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          if (widget.natalChartWidget != null) widget.natalChartWidget!,
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('నడుస్తున్న సంవత్సరం: ${activation.runningYear}',
                      style: Theme.of(context).textTheme.titleLarge),
                  Text('సంవత్సర పరిధి: ${_date(activation.yearWindow.start)}'
                      ' – ${_date(activation.yearWindow.end.subtract(const Duration(days: 1)))}'),
                  Text('BCP భావం: ${activation.activatedHouseFromReference}'),
                  Text('క్రియాశీల రాశి: ${_signs[activation.activatedSign - 1]}'),
                  Text('జన్మలగ్నం నుంచి భావం: ${activation.activatedNatalHouse}'),
                  Text('గణన నియమం: ${activation.methodRuleId}'),
                  const SizedBox(height: 8),
                  DropdownButton<BcpReference>(
                    isExpanded: true,
                    value: ref,
                    items: [
                      for (final r in refs)
                        DropdownMenuItem(value: r, child: Text(_referenceLabel(r)))
                    ],
                    onChanged: (v) { if (v != null) setState(() => selected = v); },
                  ),
                ],
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 10, 4, 6),
            child: Text('ధృవీకరించిన జన్మ నియమాలకు సరిపడిన ఫలితాలు మాత్రమే',
                style: TextStyle(fontWeight: FontWeight.w700)),
          ),
          if (findings.isEmpty)
            const Card(child: Padding(
              padding: EdgeInsets.all(16),
              child: Text('ఈ సంవత్సరం మరియు ఈ BCP పద్ధతికి ధృవీకరించిన '
                  'జన్మ నియమాలతో సరిపోయిన ఫలితాలు లేవు. '
                  'ఆధారాలు లేని సంఘటనలను చూపడం లేదు.'),
            )),
          for (final f in findings) _findingTile(context, f),
          ExpansionTile(
            title: const Text('BCP–2: డిగ్రీ ఆధారిత పరిశీలన'),
            subtitle: const Text('ఇవి ప్రయోగాత్మక ట్రిగ్గర్లు; ఖచ్చితమైన సంఘటన తేదీలు కావు.'),
            children: [
              for (final t in BcpEngine.degreeTriggers(
                  chart: widget.natalChart, activation: activation))
                ListTile(
                  dense: true,
                  title: Text('${_planetNames[t.label] ?? t.label}: '
                      '${t.intraSignDegrees.toStringAsFixed(2)}°'),
                  subtitle: Text('సూచన తేదీ: ${_date(t.tentativeDate)}'),
                ),
            ],
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 12, horizontal: 4),
            child: Text('BCP సంఘటన అవకాశాన్ని శాస్త్రీయంగా ధృవీకరించిన '
                'శాతం రూపంలో ఇవ్వదు. దశా–గోచార ఆధారాలు లేకపోతే '
                'సంవత్సర సూచన మాత్రమే చూపబడుతుంది.',
                style: TextStyle(fontSize: 12)),
          ),
        ],
      ),
    );
  }

  Widget _findingTile(BuildContext context, BcpFinding f) {
    final outcome = widget.verifiedOutcomes[f.event.kind] ?? BcpOutcome.undecided;
    final color = switch (outcome) {
      BcpOutcome.favorable => const Color(0xFFE9F7EF),
      BcpOutcome.unfavorable => const Color(0xFFFCEBF1),
      BcpOutcome.undecided => Theme.of(context).colorScheme.surfaceContainerLow,
    };
    final remedy = widget.verifiedRemediesByNatalRuleId[f.evidence.natalRuleId];
    final dateRange = f.timingWindow;
    return Card(
      color: color,
      child: ExpansionTile(
        title: Text(f.event.titleTelugu, style: const TextStyle(
            fontSize: 17, fontWeight: FontWeight.w700)),
        subtitle: Text(f.status == BcpStatus.timingCandidate
            ? 'సమయ పరిశీలనకు ఆధారాలు ఉన్నాయి' : 'సంవత్సర స్థాయి సూచన మాత్రమే'),
        children: [
          ListTile(
            title: Text('రూల్ ID: ${f.event.ruleId}'),
            subtitle: Text('BCP పద్ధతి: ${f.activation.methodRuleId}\n'
                'జన్మ రూల్: ${f.evidence.natalRuleId}\n'
                'మూలం: ${f.evidence.natalSourceName ?? 'నమోదు కాలేదు'}'
                '${f.evidence.natalSourcePage == null ? '' : ', పేజీ: ${f.evidence.natalSourcePage}'}'),
          ),
          ExpansionTile(
            title: const Text('జాతక పరిశీలన'),
            children: [
              for (final link in f.matchedLinks)
                ListTile(dense: true, title: Text('• ${_linkTelugu(link)}')),
              if (dateRange != null)
                ListTile(title: Text('దశా + గోచార overlap: '
                    '${_date(dateRange.start)} – '
                    '${_date(dateRange.end.subtract(const Duration(days: 1)))}')),
              if (dateRange == null)
                const ListTile(title: Text('దశా–గోచార నిర్ధారణ/సమయపరిధి '
                    'ఇంకా లేనందున తేదీ ఇవ్వడం లేదు.')),
            ],
          ),
          if (remedy != null && remedy.text.trim().isNotEmpty &&
              remedy.sourceName.trim().isNotEmpty)
            ExpansionTile(
              title: const Text('మూలాధారంతో పరిహారం'),
              children: [
                ListTile(title: Text(remedy.text), subtitle: Text(
                    '${remedy.sourceName}${remedy.sourcePage == null ? '' : ', పేజీ ${remedy.sourcePage}'}')),
              ],
            ),
        ],
      ),
    );
  }
}
