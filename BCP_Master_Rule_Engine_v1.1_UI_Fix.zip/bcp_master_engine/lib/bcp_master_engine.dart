/// Annapurna Astro Vastu — BCP Master Engine, v1.1
///
/// SOURCE-DERIVED layers:
///   BCP-CORE-001: 12-year house activation from natal Lagna.
///   BCP-CORE-002: RUNNING year of life, not completed age.
///   BCP-EXT-001: From Vimshottari Maha Dasha lord's natal sign.
///   BCP-EXT-002: Approximate within-year degree trigger points.
///   BCP-VAR-001: M. Imran's cycle-ruler variant (optional).
///   BCP-VAR-002: Moon-sign cross-check (optional).
///
/// APP-DEFINED rules (AAV-*): event mapping, evidence gate,
/// dasha/transit intersection and BTR matching. These are NOT
/// quotations from BCP publications; they are application logic.
///
/// This library does not compute graha longitudes, dashas or transits.
/// Its inputs must be supplied by the application's astronomical engine.

const _signLords = <String>[
  'mars', 'venus', 'mercury', 'moon', 'sun', 'mercury',
  'venus', 'mars', 'jupiter', 'saturn', 'saturn', 'jupiter',
];
const _recognizedPlanets = <String>{
  'sun', 'moon', 'mars', 'mercury', 'jupiter', 'venus',
  'saturn', 'rahu', 'ketu'
};

int _signIndex(int value) => ((value - 1) % 12 + 12) % 12 + 1;
int _houseFrom(int referenceSign, int targetSign) =>
    _signIndex(targetSign - referenceSign + 1);
String _norm(String name) => name.trim().toLowerCase();

/// All signs use 1=Aries ... 12=Pisces.
/// All planetary positions use absolute sidereal longitude [0, 360).
/// Whole-sign houses are used; callers must supply a consistent ayanamsa.
class NatalChart {
  final int ascendantSign;
  final Map<String, double> longitudes;

  NatalChart({required this.ascendantSign, required Map<String, double> longitudes})
      : longitudes = Map.unmodifiable({
          for (final p in longitudes.entries) _norm(p.key): p.value
        }) {
    if (ascendantSign < 1 || ascendantSign > 12) {
      throw ArgumentError('Ascendant sign must be from 1 to 12.');
    }
    for (final item in this.longitudes.entries) {
      if (!_recognizedPlanets.contains(item.key) ||
          !item.value.isFinite || item.value < 0 || item.value >= 360) {
        throw ArgumentError('Invalid planet or longitude: ${item.key} ${item.value}');
      }
    }
  }

  bool hasPlanet(String planet) => longitudes.containsKey(_norm(planet));

  int? signOf(String planet) {
    final deg = longitudes[_norm(planet)];
    return deg == null ? null : (deg / 30).floor() + 1;
  }

  double? intraSignDegree(String planet) {
    final deg = longitudes[_norm(planet)];
    return deg == null ? null : deg % 30;
  }

  int natalHouseOfSign(int sign) => _houseFrom(ascendantSign, sign);
  int signOfHouse(int natalHouse) =>
      _signIndex(ascendantSign + natalHouse - 1);
  String lordOfSign(int sign) => _signLords[sign - 1];
  String lordOfHouse(int natalHouse) => lordOfSign(signOfHouse(natalHouse));

  List<String> planetsInSign(int sign) => [
        for (final p in longitudes.keys)
          if (signOf(p) == sign) p
      ];

  /// Parashari graha drishti with 7th as default, special Mars/Jupiter/Saturn.
  /// Rahu/Ketu aspects are intentionally not assumed (schools differ).
  bool aspectsSign(String planet, int targetSign) {
    final p = _norm(planet);
    final from = signOf(p);
    if (from == null || p == 'rahu' || p == 'ketu') return false;
    final offset = _houseFrom(from, targetSign);
    switch (p) {
      case 'mars':
        return {4, 7, 8}.contains(offset);
      case 'jupiter':
        return {5, 7, 9}.contains(offset);
      case 'saturn':
        return {3, 7, 10}.contains(offset);
      default:
        return offset == 7;
    }
  }
}

class DateWindow {
  /// Start inclusive, end exclusive. Dates must be in the same time system.
  final DateTime start;
  final DateTime end;

  DateWindow(this.start, this.end) {
    if (!end.isAfter(start)) {
      throw ArgumentError('Window end must be later than start.');
    }
  }

  DateWindow? intersect(DateWindow other) {
    final s = start.isAfter(other.start) ? start : other.start;
    final e = end.isBefore(other.end) ? end : other.end;
    return e.isAfter(s) ? DateWindow(s, e) : null;
  }

  bool contains(DateTime instant) =>
      !instant.isBefore(start) && instant.isBefore(end);
}

enum BcpReference { lagna, moon, mahadashaLord, cycleRuler }

class BcpActivation {
  final BcpReference reference;
  final int runningYear;
  final int activatedHouseFromReference;
  final int referenceSign;
  final int activatedSign;
  final int activatedNatalHouse;
  final String? referencePlanet;
  final DateWindow yearWindow;
  final String methodRuleId;

  const BcpActivation({
    required this.reference,
    required this.runningYear,
    required this.activatedHouseFromReference,
    required this.referenceSign,
    required this.activatedSign,
    required this.activatedNatalHouse,
    required this.yearWindow,
    required this.methodRuleId,
    this.referencePlanet,
  });
}

/// Descriptive domains for each natal house; these are application labels,
/// not proof that an event will occur in an activated year.
const houseDomainsTelugu = <int, List<String>>{
  1: ['శరీరం', 'వ్యక్తిత్వం', 'కొత్త ప్రారంభాలు', 'ఆరోగ్య పరిశీలన'],
  2: ['కుటుంబం', 'పొదుపు', 'వాక్కు', 'ధనం'],
  3: ['సోదరులు', 'ప్రయత్నం', 'సంక్షిప్త ప్రయాణం', 'సంవాహనం'],
  4: ['తల్లి', 'వాహనం', 'గృహం', 'స్థిరాస్తి'],
  5: ['విద్య', 'సంతానం', 'సృజనాత్మకత', 'బుద్ధి'],
  6: ['సేవ', 'రుణాలు', 'పోటీ', 'వివాదాలు'],
  7: ['వివాహం', 'వ్యాపార భాగస్వామ్యం', 'ఒప్పందాలు'],
  8: ['ఆకస్మిక మార్పులు', 'పరిశోధన', 'దీర్ఘకాలిక అంశాలు'],
  9: ['ఉన్నత విద్య', 'భాగ్యం', 'గురువు', 'దూర ప్రయాణం'],
  10: ['వృత్తి', 'పదవి', 'ప్రజా గుర్తింపు', 'కార్యాచరణ'],
  11: ['లాభాలు', 'స్నేహ వలయం', 'ఆశయాలు', 'ఆదాయం'],
  12: ['వ్యయం', 'విదేశాలు', 'ఒంటరితనం', 'ఆధ్యాత్మికత'],
};

enum BcpEventKind {
  marriage,
  childbirth,
  service,
  business,
  promotion,
  careerChange,
  wealth,
  property,
  education,
  foreignTravel,
  healthReview,
  spirituality,
  partnership,
  relationshipChange,
  transfer,
  resignation,
  competitiveExam,
  borrowing,
  vehicle,
  residenceChange,
  motherMatters,
  fatherMatters,
  siblings,
  disputes,
  recognition,
  retirement,
}

class BcpEventDefinition {
  final BcpEventKind kind;
  final String ruleId;
  final String titleTelugu;
  final Set<int> houses;
  final Set<String> karakas;
  const BcpEventDefinition(
      this.kind, this.ruleId, this.titleTelugu, this.houses, this.karakas);
}

/// Rule mapping is an AAV editorial / research configuration, not a BCP quote.
const eventDefinitions = <BcpEventDefinition>[
  BcpEventDefinition(BcpEventKind.marriage, 'AAV-BCP-EVT-001',
      'వివాహం', {2, 7, 11}, {'venus'}),
  BcpEventDefinition(BcpEventKind.childbirth, 'AAV-BCP-EVT-002',
      'సంతానం', {2, 5, 9}, {'jupiter'}),
  BcpEventDefinition(BcpEventKind.service, 'AAV-BCP-EVT-003',
      'ఉద్యోగం', {6, 10, 11}, {'saturn', 'sun'}),
  BcpEventDefinition(BcpEventKind.business, 'AAV-BCP-EVT-004',
      'వ్యాపారం', {7, 10, 11}, {'mercury'}),
  BcpEventDefinition(BcpEventKind.promotion, 'AAV-BCP-EVT-005',
      'పదోన్నతి', {6, 10, 11}, {'sun', 'saturn'}),
  BcpEventDefinition(BcpEventKind.careerChange, 'AAV-BCP-EVT-006',
      'వృత్తి మార్పు', {3, 8, 10, 12}, {'saturn'}),
  BcpEventDefinition(BcpEventKind.wealth, 'AAV-BCP-EVT-007',
      'ధనలాభం', {2, 5, 11}, {'jupiter', 'venus'}),
  BcpEventDefinition(BcpEventKind.property, 'AAV-BCP-EVT-008',
      'స్థిరాస్తి', {2, 4, 11}, {'mars', 'moon'}),
  BcpEventDefinition(BcpEventKind.education, 'AAV-BCP-EVT-009',
      'విద్య', {4, 5, 9}, {'mercury', 'jupiter'}),
  BcpEventDefinition(BcpEventKind.foreignTravel, 'AAV-BCP-EVT-010',
      'విదేశీ ప్రయాణం', {3, 9, 12}, {'rahu'}),
  BcpEventDefinition(BcpEventKind.healthReview, 'AAV-BCP-EVT-011',
      'ఆరోగ్య పరిశీలన', {1, 6, 8}, {'sun'}),
  BcpEventDefinition(BcpEventKind.spirituality, 'AAV-BCP-EVT-012',
      'ఆధ్యాత్మికత', {5, 9, 12}, {'jupiter', 'ketu'}),
  BcpEventDefinition(BcpEventKind.partnership, 'AAV-BCP-EVT-013',
      'భాగస్వామ్యం', {7, 10, 11}, {'venus', 'mercury'}),
  BcpEventDefinition(BcpEventKind.relationshipChange, 'AAV-BCP-EVT-014',
      'సంబంధాలలో మార్పు', {7, 8, 12}, {'venus'}),
  BcpEventDefinition(BcpEventKind.transfer, 'AAV-BCP-EVT-015',
      'ఉద్యోగ బదిలీ', {3, 6, 10, 12}, {'saturn', 'mercury'}),
  BcpEventDefinition(BcpEventKind.resignation, 'AAV-BCP-EVT-016',
      'ఉద్యోగ విరమణ/రాజీనామా పరిశీలన', {6, 8, 10, 12}, {'saturn'}),
  BcpEventDefinition(BcpEventKind.competitiveExam, 'AAV-BCP-EVT-017',
      'పోటీ పరీక్ష', {3, 5, 6, 9}, {'mercury', 'jupiter'}),
  BcpEventDefinition(BcpEventKind.borrowing, 'AAV-BCP-EVT-018',
      'రుణ వ్యవహారాలు', {2, 6, 8, 12}, {'saturn'}),
  BcpEventDefinition(BcpEventKind.vehicle, 'AAV-BCP-EVT-019',
      'వాహన వ్యవహారాలు', {4, 11}, {'venus', 'mars'}),
  BcpEventDefinition(BcpEventKind.residenceChange, 'AAV-BCP-EVT-020',
      'నివాస మార్పు', {3, 4, 12}, {'moon'}),
  BcpEventDefinition(BcpEventKind.motherMatters, 'AAV-BCP-EVT-021',
      'తల్లి సంబంధిత అంశాలు', {4, 9, 12}, {'moon'}),
  BcpEventDefinition(BcpEventKind.fatherMatters, 'AAV-BCP-EVT-022',
      'తండ్రి సంబంధిత అంశాలు', {9, 10}, {'sun'}),
  BcpEventDefinition(BcpEventKind.siblings, 'AAV-BCP-EVT-023',
      'సోదర సంబంధిత అంశాలు', {3, 11}, {'mars'}),
  BcpEventDefinition(BcpEventKind.disputes, 'AAV-BCP-EVT-024',
      'వివాదాలు/కోర్టు అంశాలు', {6, 7, 8, 12}, {'saturn', 'mars'}),
  BcpEventDefinition(BcpEventKind.recognition, 'AAV-BCP-EVT-025',
      'గుర్తింపు/గౌరవం', {1, 10, 11}, {'sun', 'jupiter'}),
  BcpEventDefinition(BcpEventKind.retirement, 'AAV-BCP-EVT-026',
      'పదవీ విరమణ', {8, 10, 12}, {'saturn'}),
];

class BcpEventEvidence {
  /// Independently supplied natal rule match, NOT inferred from BCP.
  final bool? natalPromise;
  final bool? natalRuleVerified;
  final String? natalRuleId;
  final String? natalSourceName;
  final String? natalSourcePage;
  final bool? dashaSupported;
  final bool? transitSupported;
  final DateWindow? dashaWindow;
  final DateWindow? transitWindow;

  const BcpEventEvidence({
    this.natalPromise,
    this.natalRuleVerified,
    this.natalRuleId,
    this.natalSourceName,
    this.natalSourcePage,
    this.dashaSupported,
    this.transitSupported,
    this.dashaWindow,
    this.transitWindow,
  });

  bool get hasVerifiedNatalRule =>
      natalPromise == true &&
      natalRuleVerified == true &&
      natalRuleId != null &&
      natalRuleId!.trim().isNotEmpty;
}

enum BcpStatus { insufficientEvidence, yearCandidate, timingCandidate }

class BcpFinding {
  final BcpEventDefinition event;
  final BcpActivation activation;
  final BcpEventEvidence evidence;
  final BcpStatus status;
  final List<String> matchedLinks;
  final DateWindow? timingWindow;

  BcpFinding({
    required this.event,
    required this.activation,
    required this.evidence,
    required this.status,
    required List<String> matchedLinks,
    this.timingWindow,
  }) : matchedLinks = List.unmodifiable(matchedLinks);

  /// UI sequence: Result -> rule -> natal evidence -> optional source remedy.
  /// No remedy is generated here, nor any false statistical probability.
  Map<String, Object?> toReport() => {
        'result': event.titleTelugu,
        'status': status.name,
        'running_year': activation.runningYear,
        'bcp_house': activation.activatedHouseFromReference,
        'active_natal_house': activation.activatedNatalHouse,
        'active_sign': activation.activatedSign,
        'reference': activation.reference.name,
        'event_rule_id': event.ruleId,
        'method_rule_id': activation.methodRuleId,
        'natal_rule_id': evidence.natalRuleId,
        'natal_source': evidence.natalSourceName,
        'natal_source_page': evidence.natalSourcePage,
        'matched_links': matchedLinks,
        'year_from': activation.yearWindow.start.toIso8601String(),
        'year_until_exclusive': activation.yearWindow.end.toIso8601String(),
        'timing_from': timingWindow?.start.toIso8601String(),
        'timing_until_exclusive': timingWindow?.end.toIso8601String(),
        'remedy': null, // only populate from a separately verified source
      };
}

class BcpDegreeTrigger {
  final String label;
  final double intraSignDegrees;
  final DateTime tentativeDate;
  final List<String> reasons;
  BcpDegreeTrigger(this.label, this.intraSignDegrees,
      this.tentativeDate, List<String> reasons)
      : reasons = List.unmodifiable(reasons);
}

class BcpEngine {
  /// By policy, Feb 29 birthdays shift to March 1 in non-leap years.
  /// Calculations use LOCAL calendar dates, not UTC instants.
  static DateTime _birthday(DateTime birth, int year) =>
      DateTime(year, birth.month, birth.day);

  static DateTime _dayOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  static int runningYear(DateTime birthDate, DateTime onDate) {
    final birth = _dayOnly(birthDate);
    final on = _dayOnly(onDate);
    if (on.isBefore(birth)) throw ArgumentError('Target before birth date.');
    final anniversary = _birthday(birth, on.year);
    final completed = on.year - birth.year - (on.isBefore(anniversary) ? 1 : 0);
    return completed + 1;
  }

  static DateWindow runningYearWindow(DateTime birthDate, DateTime onDate) {
    final birth = _dayOnly(birthDate);
    final completed = runningYear(birth, onDate) - 1;
    return DateWindow(
        _birthday(birth, birth.year + completed),
        _birthday(birth, birth.year + completed + 1));
  }

  /// Select each reference explicitly. The default is natal Lagna only.
  /// MD lord must be ACTIVE for the supplied target date; upstream verifies it.
  static List<BcpActivation> activations({
    required NatalChart chart,
    required DateTime birthDate,
    required DateTime onDate,
    Set<BcpReference> references = const {BcpReference.lagna},
    String? activeMahadashaLord,
  }) {
    final year = runningYear(birthDate, onDate);
    final house = ((year - 1) % 12) + 1;
    final window = runningYearWindow(birthDate, onDate);
    final out = <BcpActivation>[];

    void add(BcpReference ref, int? referenceSign, String? planet, String method) {
      if (referenceSign == null) return;
      final activeSign = _signIndex(referenceSign + house - 1);
      out.add(BcpActivation(
        reference: ref,
        runningYear: year,
        activatedHouseFromReference: house,
        referenceSign: referenceSign,
        activatedSign: activeSign,
        activatedNatalHouse: chart.natalHouseOfSign(activeSign),
        yearWindow: window,
        methodRuleId: method,
        referencePlanet: planet,
      ));
    }

    if (references.contains(BcpReference.lagna)) {
      add(BcpReference.lagna, chart.ascendantSign, null, 'BCP-CORE-001');
    }
    if (references.contains(BcpReference.moon)) {
      add(BcpReference.moon, chart.signOf('moon'), 'moon', 'BCP-VAR-002');
    }
    if (references.contains(BcpReference.mahadashaLord)) {
      if (activeMahadashaLord == null ||
          !chart.hasPlanet(activeMahadashaLord)) {
        throw ArgumentError('Valid active Maha Dasha lord and its natal longitude required.');
      }
      add(BcpReference.mahadashaLord, chart.signOf(activeMahadashaLord),
          _norm(activeMahadashaLord), 'BCP-EXT-001');
    }
    if (references.contains(BcpReference.cycleRuler)) {
      const rulers = [
        'moon', 'mercury', 'venus', 'sun', 'mars',
        'jupiter', 'saturn', 'rahu', 'ketu'
      ];
      final index = (year - 1) ~/ 12;
      if (index < rulers.length) {
        final ruler = rulers[index];
        add(BcpReference.cycleRuler, chart.signOf(ruler), ruler, 'BCP-VAR-001');
      }
      // No invented ruler for cycles after year 108.
    }
    return out;
  }

  static List<String> eventLinks(
      NatalChart chart, BcpActivation activation, BcpEventDefinition event) {
    final links = <String>[];
    final activeSign = activation.activatedSign;
    final activeHouse = activation.activatedNatalHouse;

    if (event.houses.contains(activeHouse)) {
      links.add('DIRECT_HOUSE: natal house $activeHouse');
    }
    for (final house in event.houses) {
      final lord = chart.lordOfHouse(house);
      if (chart.signOf(lord) == activeSign) {
        links.add('HOUSE_LORD_OCCUPIES_ACTIVE_SIGN: house $house -> $lord');
      }
      if (chart.aspectsSign(lord, activeSign)) {
        links.add('HOUSE_LORD_ASPECT: house $house -> $lord');
      }
    }
    for (final karaka in event.karakas) {
      if (chart.signOf(karaka) == activeSign) {
        links.add('KARAKA_OCCUPIES_ACTIVE_SIGN: $karaka');
      } else if (chart.aspectsSign(karaka, activeSign)) {
        links.add('KARAKA_ASPECTS_ACTIVE_SIGN: $karaka');
      }
    }
    return links.toSet().toList();
  }

  /// Only verified natal event rules produce findings by default.
  /// Diagnostics can expose blocked/insufficient entries for rule auditing.
  static List<BcpFinding> evaluate({
    required NatalChart chart,
    required BcpActivation activation,
    required Map<BcpEventKind, BcpEventEvidence> evidenceByEvent,
    bool includeDiagnostics = false,
  }) {
    final findings = <BcpFinding>[];
    for (final event in eventDefinitions) {
      final links = eventLinks(chart, activation, event);
      if (links.isEmpty) continue;
      final ev = evidenceByEvent[event.kind] ?? const BcpEventEvidence();
      if (!ev.hasVerifiedNatalRule) {
        if (includeDiagnostics) {
          findings.add(BcpFinding(
            event: event, activation: activation, evidence: ev,
            status: BcpStatus.insufficientEvidence, matchedLinks: links));
        }
        continue;
      }
      DateWindow? overlap;
      BcpStatus status = BcpStatus.yearCandidate;
      if (ev.dashaSupported == false || ev.transitSupported == false) {
        status = BcpStatus.insufficientEvidence;
      } else if (ev.dashaSupported == true &&
          ev.transitSupported == true &&
          ev.dashaWindow != null && ev.transitWindow != null) {
        overlap = activation.yearWindow.intersect(ev.dashaWindow!);
        overlap = overlap?.intersect(ev.transitWindow!);
        status = overlap == null
            ? BcpStatus.insufficientEvidence
            : BcpStatus.timingCandidate;
      }
      if (status == BcpStatus.insufficientEvidence && !includeDiagnostics) {
        continue;
      }
      findings.add(BcpFinding(
        event: event,
        activation: activation,
        evidence: ev,
        status: status,
        matchedLinks: links,
        timingWindow: overlap,
      ));
    }
    return findings;
  }

  /// BCP part 2 experimental degree anchors; not guaranteed event days.
  /// Use 30 degrees over the *actual* birthday-to-birthday year window.
  static List<BcpDegreeTrigger> degreeTriggers({
    required NatalChart chart,
    required BcpActivation activation,
    Map<String, double> extraTriggerDegrees = const {},
  }) {
    final reasonsByPlanet = <String, Set<String>>{};
    void register(String p, String why) {
      if (chart.hasPlanet(p)) {
        reasonsByPlanet.putIfAbsent(p, () => <String>{}).add(why);
      }
    }

    final activeSign = activation.activatedSign;
    final activeLord = chart.lordOfSign(activeSign);
    for (final p in chart.planetsInSign(activeSign)) {
      register(p, 'PLANET_IN_ACTIVE_SIGN');
    }
    register(activeLord, 'LORD_OF_ACTIVE_SIGN');
    final lordSign = chart.signOf(activeLord);
    if (lordSign != null) {
      for (final p in chart.planetsInSign(lordSign)) {
        if (p != activeLord) register(p, 'CONJUNCT_ACTIVE_SIGN_LORD');
      }
    }
    for (final p in chart.longitudes.keys) {
      if (chart.aspectsSign(p, activeSign)) {
        register(p, 'ASPECTS_ACTIVE_SIGN');
      }
      if (lordSign != null && chart.aspectsSign(p, lordSign)) {
        register(p, 'ASPECTS_ACTIVE_LORD_SIGN');
      }
    }

    final raw = <String, double>{
      for (final p in reasonsByPlanet.keys) p: chart.intraSignDegree(p)!,
    };
    for (final item in extraTriggerDegrees.entries) {
      if (!item.value.isFinite || item.value < 0 || item.value >= 30) {
        throw ArgumentError('Extra degree must be in [0,30): ${item.key}');
      }
      raw[item.key] = item.value;
    }
    final seconds = activation.yearWindow.end
        .difference(activation.yearWindow.start).inSeconds;
    final result = <BcpDegreeTrigger>[];
    for (final item in raw.entries) {
      final offset = (seconds * item.value / 30).round();
      result.add(BcpDegreeTrigger(
        item.key, item.value,
        activation.yearWindow.start.add(Duration(seconds: offset)),
        (reasonsByPlanet[item.key] ?? {'EXTERNAL_VERIFIED_POINT'}).toList(),
      ));
    }
    result.sort((a, b) => a.tentativeDate.compareTo(b.tentativeDate));
    return result;
  }
}

class ObservedBtrEvent {
  final BcpEventKind kind;
  final DateTime date;
  const ObservedBtrEvent(this.kind, this.date);
}

class BcpBtrAudit {
  final int matched;
  final int total;
  final List<String> observations;
  BcpBtrAudit(this.matched, this.total, this.observations);
}

/// Historical-event consistency count. This is NOT birth-time accuracy %.
/// Recalculate planet longitudes / Lagna for EACH trial birth time upstream.
class BcpBtr {
  static BcpBtrAudit audit({
    required DateTime birthDate,
    required NatalChart trialChart,
    required List<ObservedBtrEvent> history,
    required Map<BcpEventKind, BcpEventEvidence> evidenceByEvent,
  }) {
    var matched = 0;
    final notes = <String>[];
    for (final observed in history) {
      final a = BcpEngine.activations(
        chart: trialChart, birthDate: birthDate, onDate: observed.date,
      ).single;
      final findings = BcpEngine.evaluate(
        chart: trialChart, activation: a, evidenceByEvent: evidenceByEvent,
      );
      final hits = findings.where((f) =>
        f.event.kind == observed.kind &&
        (f.timingWindow == null || f.timingWindow!.contains(observed.date))
      ).toList();
      if (hits.isNotEmpty) matched++;
      notes.add('${observed.kind.name} @ ${observed.date.toIso8601String()}: '
          '${hits.isNotEmpty ? "BCP support" : "no verified BCP support"} '
          '(running year ${a.runningYear}, natal house ${a.activatedNatalHouse})');
    }
    return BcpBtrAudit(matched, history.length, notes);
  }
}
