import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_event_relations.dart';
import 'package:astro_app/astrology/bnn_master_service.dart';

AstroChartResult _sampleChart({required double marsLongitude}) =>
    AstroChartResult(
      julianDay: 0,
      ayanamsaDegrees: 0,
      ascendantLongitude: 0,
      planets: [
        const PlanetPosition(name: 'Jupiter', shortName: 'Ju',
            longitude: 30, latitude: 0, speed: 0),
        PlanetPosition(name: 'Mars', shortName: 'Ma',
            longitude: marsLongitude, latitude: 0, speed: 0),
        const PlanetPosition(name: 'Moon', shortName: 'Mo',
            longitude: 180, latitude: 0, speed: 0),
      ],
      engineVersion: 'test',
    );

BnnMasterRule _rule(String status, String result) => BnnMasterRule(
  id: 'r1', source: 'BNN N', sourcePage: 1, topic: 'తల్లి',
  condition: 'గురుడు—కుజుడు', result: result,
  inspection: 'test', remedy: '', status: status,
);

void main() {
  test('All relations have a unique name and supported house reference', () {
    expect(BnnEventRelations.relations.length, greaterThanOrEqualTo(12));
    expect(BnnEventRelations.relations.map((r) => r.name).toSet().length,
        BnnEventRelations.relations.length);
    for (final group in BnnEventRelations.relations) {
      expect(group.relatedHouse, inInclusiveRange(1, 12));
    }
  });

  test('No timing event is called a verified prediction', () {
    expect(BnnEventRelations.studyWindows.length, greaterThanOrEqualTo(5));
    for (final item in BnnEventRelations.studyWindows) {
      expect(item.toAge, greaterThanOrEqualTo(item.fromAge));
      expect(item.sourceId, startsWith('BNN-BOOK-'));
      expect(item.sourceStatus, contains('సంఘటన నిర్ధారణ కాదు'));
    }
  });

  test('Specific property event requires Mars 4th from Jupiter', () {
    final item = BnnEventRelations.studyWindows
        .firstWhere((event) => event.sourceId == 'BNN-BOOK-C19');
    expect(BnnEventRelations.placementCondition(item,
        _sampleChart(marsLongitude: 120)), isTrue); // Taurus to Leo = 4
    expect(BnnEventRelations.placementCondition(item,
        _sampleChart(marsLongitude: 150)), isFalse);
  });

  test('Unverified source rules never get a green or pink decision', () {
    final chart = _sampleChart(marsLongitude: 30);
    expect(BnnEventRelations.polarity(
        _rule('OCR_REVIEW', 'కష్టాలు'), chart), 0);
    expect(BnnEventRelations.polarity(
        _rule('REVIEW', 'లాభాలు'), chart), 0);
  });
}
