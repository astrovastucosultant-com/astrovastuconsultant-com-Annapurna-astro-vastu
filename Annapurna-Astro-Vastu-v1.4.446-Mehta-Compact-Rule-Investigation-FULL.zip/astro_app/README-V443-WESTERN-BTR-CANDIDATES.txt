ANNAPURNA ASTRO VASTU v1.4.443 — WESTERN BTR CANDIDATE SCAN

Status: source implementation / GitHub compilation and tests required.

Western BTR now accepts 2–8 user-confirmed event dates; 3+ recommended.
Event categories: marriage, children, job, promotion/career change, home.
The tool scans birth time +-15/30/60/120 minutes at five-minute intervals,
then refines the best three neighborhoods at one-minute intervals.

Only Western tropical natal angles/cusps (ASC, DSC, IC, MC, 2nd, 5th and
6th) are used for BTR-specific filtering. Secondary Progressions (including
Progressed Moon, not double-counted), Solar Arc and optional Transits use
existing v434 Swiss Ephemeris contact calculation. House cusps are Placidus;
no KP, Vedic vargas, Dasha, Jaimini or BNN timing is included.

BTR target association is a source-informed app synthesis, not a theorem:
 MAR: Descendant / 5th cusp
 CHD: 5th cusp / Ascendant / IC
 JOB: MC / 6th cusp / 2nd cusp
 PRM: MC / 6th cusp
 HOM: IC / Ascendant

Heuristic event score: 65% nearest independent method-family contact,
25% second, 10% third (orb-normalized), averaged across *all* verified
life events, including zero-support events. This is a RULE MATCH SCORE,
NOT a probability of an accurate birth time or verified event.
Square and opposition stay valid activating contacts and retain their
challenging nature in the Aspect Nature layer.

After ranking, user may intentionally select a candidate and confirm
Apply & Recalculate; Original Birth Time stays recorded via ChartScreen.
No automatic mutation of saved charts takes place.

Methodology references:
https://www.astro.com/astrowiki/en/Rectification
https://www.astro.com/faq/fq_fh_owtype_e.htm

Limitations:
 - Events must be independently confirmed; dates are not predicted by BTR.
 - One sample at local 12:00 on each event date, so contact is not exact-hour.
 - Fixed numeric UTC offset; historical DST transitions are not resolved.
 - Placidus fails at extreme polar latitudes; do not substitute sidereal houses.
 - This heuristic has not been calibrated with blinded real-case validation.
 - No accurate-time guarantee. Confirm shortlisted chart times manually.
