Annapurna Astro Vastu v1.4.441 — Western Past Event Evidence Strength %

Changes:
- An evidence strength score 0-100 for each candidate, NOT a probability
  that a marriage, childbirth or first job occurred.
- Four transparent components: event-specific rule match 35, sampled
  aspect orb 25, contact temporal proximity 20, independent technique
  families 20. Conservative cap of 49 for single-family evidence and
  74 for repeated methods aimed at a single natal target.
- Progressed Moon belongs to the Secondary Progression family, so does
  not supply a fully independent method vote when Secondary is also on.
- Counts unique app-authored topical IF-THEN criteria, not duplicated
  monthly aspects or the number of sources.
- Timeline toggle between chronological dates and evidence score order.
- Candidate details: score bar, score breakdown, unique criteria count,
  scan window, sampled best orb/date, topical rule ID and source URL.
- Scan period is an approximate THREE-month window, not an exact event
  date; day-level recheck remains necessary for refined contacts.
- Remains Western-only. Marriage and childbirth are independent, and
  pre-marital childbirth possibilities are NOT removed.
- No actual historical events are used to compute candidate scores.

Accuracy caveat:
Component weights are app-authored heuristic values, NOT validated
frequencies or empirically calibrated probabilities. Requires blind
backtesting with held-out true event dates before any claimed performance.
Static tests are not a Flutter compile; build with GitHub Actions.
