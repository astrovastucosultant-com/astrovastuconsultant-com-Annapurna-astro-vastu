# Annapurna Astro Vastu v1.4.442 — Western Aspect Nature

Scope: Western Timing of Event and Western Past Event Discovery only.

- Square (90°): default CHALLENGING / red; can mark obstacles/conflict.
- Opposition (180°): default CHALLENGING / red.
- Trine (120°): default FAVORABLE / green (not a guaranteed outcome).
- Sextile (60°): default FAVORABLE / green.
- Conjunction (0°): evaluate both classical planets; Venus/Jupiter
  supportive, Mars/Saturn challenging, mixed pair mixed; other cases neutral.
- Unknown aspects remain neutral, no fabricated outcomes.
- Do NOT remove hard contacts from event activation or change Evidence Strength %.
- Aspect counts in past-event cards are from the deduplicated, selected core
  contacts used for the existing ranking, not raw monthly repetitions.
- All judgment rules are original app synthesis from Western descriptions;
  they are NOT direct text from classical works and do not claim an actual
  event occurred or is statistically probable.
- No changes to BNN, KP, Jaimini, Indian dashas, or other tabs.

Sources (background only):
- https://www.astro.com/astrowiki/en/Aspect
- https://www.skyscript.co.uk/aspects.html

Requested display order: Rule -> Chart inspection -> Result -> Source.
