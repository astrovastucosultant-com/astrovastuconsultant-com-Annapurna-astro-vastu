Annapurna Astro Vastu v1.4.440 - Calendar-order past event indications

- Present candidate years from oldest to newest ACROSS marriage/relationship,
  childbirth/family themes, and first-job/work themes.
- Do not enforce marriage-before-childbirth or an event-type hierarchy.
  Child-related indications may appear prior to marriage, including in a
  non-marital relationship context. They remain interpretations, not facts.
- Keep per-topic ranking (corroborated vs preliminary), independent of
  chronological presentation.
- Expand a timeline row to review that candidate year using the existing
  Western-only day-sampling calculation.
- Date ordering and family status are independent; no known real events are
  supplied to the discovery engine.
- Added a regression test with job 2004, child-related indication 2005,
  marriage/partnership 2008, validating the event order is not forced.
- This is an interpretive Western astrology UI; no empirical certainty,
  definitive past event or reliable probability claims.

Build note: Flutter compile and test run via GitHub Actions; static ZIP checks
alone do not prove a successful APK build.
