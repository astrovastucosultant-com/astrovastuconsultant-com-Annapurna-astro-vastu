import 'astro_models.dart';
import '../utils/astro_format.dart';

/// Provides the exact natal D1 occupants to the S.K. Mehta rule inspection.
/// Uses the same AstroChartResult as the main Jataka tab (no new ephemeris).
class MehtaNatalChartService {
  static Map<int, List<String>> occupants(AstroChartResult chart) {
    final out = <int, List<String>>{
      for (var sign = 0; sign < 12; sign++) sign: <String>[],
    };
    for (final planet in chart.planets) {
      final label = '${planet.shortName} '
          '${AstroFormat.degreeDms(planet.degreesInSign)}'
          '${planet.retrograde ? ' R' : ''}';
      out[planet.signIndex]!.add(label);
    }
    out[chart.ascendantSignIndex]!.insert(0,
      'లగ్నం ${AstroFormat.degreeDms(chart.ascendantLongitude % 30)}');
    return out;
  }
}
