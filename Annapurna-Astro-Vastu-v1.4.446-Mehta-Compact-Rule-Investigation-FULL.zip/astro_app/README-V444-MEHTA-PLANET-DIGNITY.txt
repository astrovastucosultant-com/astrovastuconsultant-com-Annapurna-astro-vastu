Annapurna Astro Vastu v1.4.444 — S.K. Mehta Planetary Dignity Table

- S.K. Mehta top explanatory paragraph is now a collapsed ExpansionTile.
- A compact chart-dependent 7-planet dignity table appears before Lagna strength.
- Reuses existing MehtaCombinationService special three-sign groups.
- Separate source/exception disclosure for Mercury base-sign vs expanded-group differences.
- Ascendant and lunar strength panels and Mehta BTR are preserved.
- Rahu/Ketu omitted: no defined extended three-sign mapping in this engine.
- Test file: test/mehta_dignity_table_v444_test.dart
