Annapurna Astro Vastu v1.4.445 — S.K. Mehta D1 Chart with Planet Degrees

- Reuse the existing AstroChartResult positions and South Indian D1 drawing widget.
- On opening a Mehta rule or combination, show a natal D1 chart with planet/ascendant DMS degrees.
- Tap a planet on the D1 chart to open the existing full Planet Detail sheet.
- Only a verified affected sign is highlighted in blue (the investigation-only color).
- The Mehta tab's general D1 chart remains collapsed by default to save space.
- Existing dignity table and S.K. Mehta-only source discipline remain unchanged.
- Unit test validates longitudes/signs, retrograde and ascendant formatting.
- Rule-matching data are not replaced or invented for the new visualization.
