/// Deterministic BNN operator primitives for source-specific IF transcription.
///
/// These methods DO NOT declare event predictions. The 12/30 year mean cycles
/// are rough reference values from the supplied source, not live ephemeris
/// positions or verified birth-time rectification output. BNN 160-page graph
/// adjacency/aspects require separate documented conventions before use.
class BnnNadiOperatorPrimitives {
  const BnnNadiOperatorPrimitives._();

  static int? relativeRashi(int? from, int? to) {
    if (from == null || to == null || from < 1 || from > 12 || to < 1 || to > 12) {
      return null;
    }
    return (to - from + 12) % 12 + 1;
  }

  /// One-based sign lords under the basic seven-graha Parashari rulership map.
  /// Nodes are not used as co-rulers unless the source explicitly specifies it.
  static String? signLord(int sign) {
    const lords = <String>[
      'Mars','Venus','Mercury','Moon','Sun','Mercury',
      'Venus','Mars','Jupiter','Saturn','Saturn','Jupiter'
    ];
    return sign >= 1 && sign <= 12 ? lords[sign - 1] : null;
  }

  /// A genuine mutual exchange requires two reciprocal domicile occupancies.
  /// A chart without both planets gives null, not FALSE or a prediction.
  static bool? mutualExchange(
      Map<String, int> planetSigns, String a, String b) {
    final aSign = planetSigns[a];
    final bSign = planetSigns[b];
    if (aSign == null || bSign == null || signLord(aSign) == null || signLord(bSign) == null) {
      return null;
    }
    return signLord(aSign) == b && signLord(bSign) == a;
  }

  /// Approximate mean-cycle number only, counting round 1 from age 0.
  /// This is not the apparent Jupiter/Saturn longitude or a transit forecast.
  static int? approximateRound(double ageYears, {required double cycleYears}) {
    if (!ageYears.isFinite || ageYears < 0 || cycleYears <= 0 || !cycleYears.isFinite) {
      return null;
    }
    return (ageYears / cycleYears).floor() + 1;
  }

  static double? approximateYearsToSign(
      int? startSign, int? targetSign, {required double yearsPerSign}) {
    final steps = relativeRashi(startSign, targetSign);
    if (steps == null || yearsPerSign <= 0 || !yearsPerSign.isFinite) return null;
    return (steps - 1) * yearsPerSign;
  }
}
