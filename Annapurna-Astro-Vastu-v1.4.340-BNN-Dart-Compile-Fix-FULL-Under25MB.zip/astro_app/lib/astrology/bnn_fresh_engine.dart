import 'dart:convert';
import 'package:flutter/services.dart';
import 'astro_models.dart';

/// Fresh, source-checked BNN subset. A partial, verified release is allowed;
/// the old 462-record OCR/review catalogue is never loaded into predictions.
class BnnFreshRule {
  final String id, title, topic, source, thenText, remedy, sourceIfText, tone, reviewNote;
  final int pdfPage;
  final int? printedPage;
  final List<String> sourceIds;
  final Map<String, dynamic> predicate;
  const BnnFreshRule({required this.id, required this.title, required this.topic,
    required this.source, required this.thenText, required this.remedy,
    required this.sourceIfText, required this.tone, required this.reviewNote,
    required this.pdfPage, required this.printedPage, required this.sourceIds,
    required this.predicate});
}

class BnnFreshRelease {
  final bool published;
  final List<BnnFreshRule> rules;
  const BnnFreshRelease({required this.published, required this.rules});

  static Future<BnnFreshRelease> load() async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_verified_release.json');
    final doc = jsonDecode(raw) as Map<String, dynamic>;
    if (doc['schema_version'] != 'BNN-FRESH-1.1') {
      throw const FormatException('BNN fresh schema mismatch');
    }
    if (doc['published'] != true) {
      return const BnnFreshRelease(published: false, rules: []);
    }
    if (doc['publish_mode'] != 'verified_subset') {
      throw const FormatException('Invalid BNN publication mode');
    }
    final items = doc['rules'];
    if (items is! List || items.isEmpty || items.length > 462 ||
        doc['verified_rule_count'] != items.length ||
        doc['expected_publish_count'] != items.length) {
      throw const FormatException('BNN verified-subset count mismatch');
    }
    final ids = <String>{};
    final sourceIds = <String>{};
    final list = <BnnFreshRule>[];
    for (final item in items) {
      if (item is! Map<String, dynamic>) {
        throw const FormatException('BNN record is not an object');
      }
      final r = item;
      final id = r['id'] as String;
      final source = r['source'] as String;
      final page = r['pdf_page'] as int;
      final ruleText = r['then'] as String;
      final sourceIf = r['source_if_text'] as String;
      final ifTree = (r['if'] as Map).cast<String, dynamic>();
      final refIds = (r['source_ids'] as List).cast<String>();
      final tone = r['tone'] as String;
      if (!ids.add(id) || id.trim().isEmpty || page < 1 || page > 21 ||
          source != 'Brighu_Naadi_Purnna_Rulebook.pdf' ||
          ruleText.trim().isEmpty || sourceIf.trim().isEmpty ||
          refIds.isEmpty || refIds.any((v) => v.trim().isEmpty ||
              !sourceIds.add(v)) ||
          !const {'favorable', 'adverse', 'neutral'}.contains(tone) ||
          r['source_text_checked'] != true ||
          r['predicate_checked'] != true ||
          r['chart_test_passed'] != true ||
          !_Predicate.valid(ifTree)) {
        throw FormatException('BNN source validation failed: $id');
      }
      list.add(BnnFreshRule(
        id: id, title: r['title'] as String, topic: r['topic'] as String,
        source: source, pdfPage: page, printedPage: r['book_page'] as int?,
        thenText: ruleText, remedy: (r['remedy'] as String?) ?? '',
        sourceIfText: sourceIf, tone: tone,
        reviewNote: (r['review_note'] as String?) ?? '',
        sourceIds: List.unmodifiable(refIds), predicate: ifTree,
      ));
    }
    if (doc['verified_source_id_count'] != sourceIds.length) {
      throw const FormatException('BNN source ID count mismatch');
    }
    return BnnFreshRelease(published: true, rules: List.unmodifiable(list));
  }
}

class BnnFreshHit {
  final BnnFreshRule rule;
  final String evidence;
  const BnnFreshHit(this.rule, this.evidence);
}

class _Predicate {
  static const _names = {
    'Sun','Moon','Mars','Mercury','Jupiter','Venus','Saturn','Rahu','Ketu'
  };
  static bool _planet(dynamic name) => name is String && _names.contains(name);
  static bool valid(Map<String, dynamic> p) {
    final op = p['op'];
    if (op == 'and' || op == 'or') {
      final clauses = p['clauses'];
      return clauses is List && clauses.isNotEmpty && clauses.every(
        (c) => c is Map && valid(c.cast<String, dynamic>()));
    }
    if (op == 'same_sign' || op == 'adjacent_sign') {
      return _planet(p['a']) && _planet(p['b']);
    }
    if (op == 'sign_is') {
      return _planet(p['planet']) && p['sign'] is int &&
          p['sign'] >= 1 && p['sign'] <= 12;
    }
    if (op == 'relative_house') {
      return _planet(p['from']) && _planet(p['planet']) &&
          p['house'] is int && p['house'] >= 1 && p['house'] <= 12;
    }
    return false;
  }

  static bool? evaluate(Map<String, dynamic> p, Map<String, int> signs) {
    if (!valid(p)) return null;
    final op = p['op'];
    if (op == 'and' || op == 'or') {
      final parts = (p['clauses'] as List).map((v) =>
        evaluate((v as Map).cast<String, dynamic>(), signs)).toList();
      if (op == 'and') {
        if (parts.contains(false)) return false;
        return parts.contains(null) ? null : true;
      }
      if (parts.contains(true)) return true;
      return parts.contains(null) ? null : false;
    }
    if (op == 'sign_is') {
      final a = p['planet'] as String;
      return signs.containsKey(a) ? signs[a] == p['sign'] : null;
    }
    if (op == 'relative_house') {
      final a = p['from'] as String;
      final b = p['planet'] as String;
      if (!signs.containsKey(a) || !signs.containsKey(b)) return null;
      return ((signs[b]! - signs[a]! + 12) % 12) + 1 == p['house'];
    }
    final a = p['a'] as String;
    final b = p['b'] as String;
    if (!signs.containsKey(a) || !signs.containsKey(b)) return null;
    if (op == 'same_sign') return signs[a] == signs[b];
    final diff = (signs[a]! - signs[b]! + 12) % 12;
    return diff == 1 || diff == 11;
  }

  static Set<String> referencedPlanets(Map<String, dynamic> p) {
    if (p['op'] == 'and' || p['op'] == 'or') {
      return {for (final c in (p['clauses'] as List))
        ...referencedPlanets((c as Map).cast<String, dynamic>())};
    }
    return {for (final key in ['a','b','planet','from'])
      if (p[key] is String && _names.contains(p[key])) p[key] as String};
  }
}

class BnnFreshEngine {
  /// Testable three-valued predicate evaluation: null is missing input,
  /// false is a disproved IF; neither case becomes an opposite prediction.
  static bool? evaluatePredicate(Map<String, dynamic> predicate,
      Map<String, int> signs) => _Predicate.evaluate(predicate, signs);
  static const _signNames = [
    'మేషం','వృషభం','మిథునం','కర్కాటకం','సింహం','కన్య',
    'తుల','వృశ్చికం','ధనుస్సు','మకరం','కుంభం','మీనం'
  ];

  static List<BnnFreshHit> evaluate(BnnFreshRelease release,
      AstroChartResult chart) {
    if (!release.published) return const [];
    final planets = <String, PlanetPosition>{};
    final signs = <String, int>{};
    for (final planet in chart.planets) {
      if (_Predicate._names.contains(planet.name)) {
        planets[planet.name] = planet;
        signs[planet.name] = planet.signIndex + 1;
      }
    }
    final hits = <BnnFreshHit>[];
    for (final rule in release.rules) {
      if (_Predicate.evaluate(rule.predicate, signs) != true) continue;
      final names = _Predicate.referencedPlanets(rule.predicate).toList()..sort();
      final evidence = names.map((name) {
        final p = planets[name]!;
        return '$name: ${_signNames[p.signIndex]} '
            '${p.degreesInSign.toStringAsFixed(2)}°';
      }).join(' • ');
      hits.add(BnnFreshHit(rule,
        'జన్మ D1 నిజమైన గ్రహస్థితులు: $evidence. '
        'IF: ${rule.sourceIfText}. షరతు సరిపోయింది.'));
    }
    return List.unmodifiable(hits);
  }
}
