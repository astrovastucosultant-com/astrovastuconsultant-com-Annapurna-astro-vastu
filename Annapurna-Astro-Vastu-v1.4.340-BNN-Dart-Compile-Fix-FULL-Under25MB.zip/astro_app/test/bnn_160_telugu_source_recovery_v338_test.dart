import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('160-page BNN original recovers all 119 source locations, not fake results', () async {
    final root = jsonDecode(await rootBundle.loadString(
      'assets/bnn/bnn_master_462_registry.json')) as Map<String, dynamic>;
    final rows = (root['rules'] as List).cast<Map<String, dynamic>>();
    expect(rows.length, 462);
    expect(root['new_source_160_pages'], 160);
    expect(root['BNN_N_source_recovered'], 119);
    expect(rows.where((r) => r['source_collection'] == 'BNN_N_119').length, 119);
    for (final r in rows.where((r) => r['source_collection'] == 'BNN_N_119')) {
      expect(r['pdf_page'], r['book_page'], reason: r['id'] as String);
      expect((r['pdf_page'] as int) > 0, true);
      expect((r['pdf_page'] as int) <= 160, true);
      expect(r['source_access'], 'source_160_scan_located');
      expect(r['source_text_checked_for_execution'], false);
      expect(r['is_executable'], false);
      expect(r['if_ast'], null);
    }
    expect(rows.where((r) => r['is_executable'] == true).length, 138);
  });
}
