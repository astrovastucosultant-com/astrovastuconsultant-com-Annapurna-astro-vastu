import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_fresh_engine.dart';

void main() {
  test('every BNN IF has TRUE, FALSE and missing-input fixtures', () {
    final rows = (jsonDecode(File('test/fixtures/bnn_v337_truth_fixtures.json')
        .readAsStringSync()) as List).cast<Map<String, dynamic>>();
    expect(rows.length, 82);
    for (final row in rows) {
      final predicate = (row['predicate'] as Map).cast<String, dynamic>();
      final yes = (row['true_signs'] as Map).cast<String, dynamic>()
          .map((key, value) => MapEntry(key, value as int));
      final no = (row['false_signs'] as Map).cast<String, dynamic>()
          .map((key, value) => MapEntry(key, value as int));
      expect(BnnFreshEngine.evaluatePredicate(predicate, yes), true, reason: row['id'] as String);
      expect(BnnFreshEngine.evaluatePredicate(predicate, no), false, reason: row['id'] as String);
      expect(BnnFreshEngine.evaluatePredicate(predicate, {}), null, reason: row['id'] as String);
    }
  });
}
