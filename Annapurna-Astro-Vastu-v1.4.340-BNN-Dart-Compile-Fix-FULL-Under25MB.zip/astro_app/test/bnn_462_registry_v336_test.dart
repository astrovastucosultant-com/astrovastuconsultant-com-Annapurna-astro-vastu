import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_fresh_engine.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('BNN 462 source registry unique and verified subset separate', () async {
    final raw = await rootBundle.loadString('assets/bnn/bnn_master_462_registry.json');
    final doc = jsonDecode(raw) as Map<String, dynamic>;
    final records = doc['rules'] as List;
    expect(records.length, 462);
    expect(records.map((r) => r['id']).toSet().length, 462);
    expect(records.where((r) => r['is_executable'] == true).length, 138);
  });
  test('BNN partial release does not demand 462 verified predictions', () async {
    final release = await BnnFreshRelease.load();
    expect(release.published, true);
    expect(release.rules.length, 137);
  });
  test('BNN relative house and missing data produce tri-state, no else result', () {
    final clause = <String, dynamic>{
      'op':'relative_house','from':'Venus','planet':'Saturn','house':7,
    };
    expect(BnnFreshEngine.evaluatePredicate(clause, {'Venus':1,'Saturn':7}), true);
    expect(BnnFreshEngine.evaluatePredicate(clause, {'Venus':1,'Saturn':6}), false);
    expect(BnnFreshEngine.evaluatePredicate(clause, {'Venus':1}), null);
  });
  test('H37 requires Cancer AND Venus/Jupiter same sign', () {
    final pred = <String, dynamic>{'op':'and','clauses':[
      {'op':'same_sign','a':'Venus','b':'Jupiter'},
      {'op':'sign_is','planet':'Venus','sign':4},
    ]};
    expect(BnnFreshEngine.evaluatePredicate(pred, {'Venus':4,'Jupiter':4}), true);
    expect(BnnFreshEngine.evaluatePredicate(pred, {'Venus':1,'Jupiter':1}), false);
  });
}
