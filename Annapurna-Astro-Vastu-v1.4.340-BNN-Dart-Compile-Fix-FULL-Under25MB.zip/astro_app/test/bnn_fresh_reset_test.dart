import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/astro_models.dart';
import 'package:astro_app/astrology/bnn_fresh_engine.dart';

void main() {
  test('Clean BNN release cannot output any old rules', () {
    const release=BnnFreshRelease(published:false,rules:[]);
    const chart=AstroChartResult(julianDay:2451545,
      ayanamsaDegrees:23.5,ascendantLongitude:0,
      planets:[],engineVersion:'fixture');
    expect(BnnFreshEngine.evaluate(release,chart),isEmpty);
  });
}
