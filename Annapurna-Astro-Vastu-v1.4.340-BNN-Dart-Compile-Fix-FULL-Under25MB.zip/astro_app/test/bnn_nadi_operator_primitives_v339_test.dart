import 'package:flutter_test/flutter_test.dart';
import 'package:astro_app/astrology/bnn_nadi_operator_primitives.dart';

void main() {
  test('sign distances are one-based, valid and cyclic', () {
    expect(BnnNadiOperatorPrimitives.relativeRashi(12, 1), 2);
    expect(BnnNadiOperatorPrimitives.relativeRashi(12, 12), 1);
    expect(BnnNadiOperatorPrimitives.relativeRashi(1, 12), 12);
    expect(BnnNadiOperatorPrimitives.relativeRashi(null, 4), isNull);
  });
  test('classical domicile exchange is reciprocal, not just a conjunction', () {
    expect(BnnNadiOperatorPrimitives.mutualExchange({'Moon': 1, 'Mars': 4}, 'Moon', 'Mars'), isTrue);
    expect(BnnNadiOperatorPrimitives.mutualExchange({'Moon': 4, 'Mars': 1}, 'Moon', 'Mars'), isFalse);
    expect(BnnNadiOperatorPrimitives.mutualExchange({'Moon': 1}, 'Moon', 'Mars'), isNull);
  });
  test('mean progression returns years only, never event certainty', () {
    expect(BnnNadiOperatorPrimitives.approximateRound(12, cycleYears: 12), 2);
    expect(BnnNadiOperatorPrimitives.approximateRound(30, cycleYears: 30), 2);
    expect(BnnNadiOperatorPrimitives.approximateRound(-1, cycleYears: 12), isNull);
    expect(BnnNadiOperatorPrimitives.approximateYearsToSign(2, 4, yearsPerSign: 2.5), 5.0);
  });
}
