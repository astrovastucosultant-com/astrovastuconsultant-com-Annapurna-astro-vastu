# BNN v1.4.338 — 160-page source recovery / OCR + JSON + IF–THEN + Flutter

- 462 **distinct registry** records: 343 from the 21-page BNN booklet, and 119 traced to the user-provided 160-page Telugu scanned source.
- Previous BNN-N `pdf_page` labels were one page ahead of the new PDF. Corrected for all 119 from original scanned PDF page to the printed page. Original references retained in `original_pdf_page_in_legacy_registry`.
- Source locations for the 119 are available and selected page headings were visually checked, but **all 119 rule-wording transcriptions have NOT been independently verified**. No false confidence labels.
- Tesseract Telugu OCR has produced raw text for all 160 pages. The raw output is unverified and has obvious character/table errors. It is stored under `docs/`, not as runtime Flutter asset or source of automated decisions.
- `assets/bnn/bnn_master_462_registry.json` is the search/index registry, including `if_text`, `then_text`, corrected source page, and null predicate for unverified rules.
- **83 source rule IDs / 82 verified predicate groups** from v1.4.337 are unchanged and continue to produce results only on exact natal predicate TRUE.
- The newly recovered 119 records do NOT automatically enter the predictions view; method/graph relation and source wording must be verified rule by rule before doing that.
- D3, D9, D10, D12, BCP and other unrelated Flutter code is left unchanged.
- Source PDF is not embedded (71 MB), preserving the under-25MB Full Source ZIP goal. Documentation OCR is not packaged as an Android asset.
- Flutter SDK unavailable here: Flutter `analyze`, `test`, release APK compilation and device testing were NOT performed. Python data, ZIP and static integration checks are separate.
