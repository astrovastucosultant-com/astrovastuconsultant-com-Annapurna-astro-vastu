import 'package:flutter/material.dart';

import '../astrology/astro_models.dart';
import '../astrology/bnn_master_service.dart';
import '../astrology/bnn_exact_if_engine.dart';
import '../astrology/bnn_all_rules_match_service.dart';
import '../astrology/bnn_rule_verdict.dart';
import '../astrology/bnn_relative_timing_service.dart';
import '../astrology/bnn_nadi_degree_engine.dart';
import '../astrology/bnn_combination_engine.dart';
import '../astrology/bnn_timing_progression_service.dart';
import '../astrology/bnn_bhava_topics.dart';
import '../astrology/bnn_topic_index.dart';
import '../astrology/bnn_topic_reading_service.dart';
import '../astrology/bnn_outcome_router.dart';
import '../astrology/bnn_event_relations.dart';
import '../astrology/bnn_navigation_spec.dart';
import '../models/birth_data.dart';
import 'bnn_d1_bhava_panel.dart';

class BnnMasterPanel extends StatefulWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  State<BnnMasterPanel> createState() => _BnnMasterPanelState();
}

class _BnnMasterPanelState extends State<BnnMasterPanel> {
  late final Future<List<BnnMasterRule>> _catalog = BnnMasterCatalog.load();
  late final Future<List<BnnEngineSpec>> _engineCatalog = BnnEngineSpecCatalog.load();
  late final Future<List<BnnTimingRule>> _timingCatalog = BnnTimingCatalog.load();
  BnnProgressionProfile _timingProfile = BnnProgressionProfile.raoApprox;
  Future<List<BnnTransitSample>>? _transitSamples;
  int _selectedHouse = 1;
  int _mainTab = 0; // 0 results, 1 bhavas, 2 graha links, 3 timing, 4 relations, 5 catalogue, 6 D1 bhavas
  int _overviewLimit = 8;
  int _negativeLimit = 8;
  int _libraryLimit = 15;
  int _libraryFilter = 0; // 0 all, 1 TRUE, 2 FALSE, 3 source IF incomplete
  String _libraryQuery = '';
  int _selectedRelation = 0;
  int _selectedSubTab = 0; // 0 results, 1 yogas, 2 past, 3 present, 4 future
  String _search = '';
  int _resultsLimit = 8;
  int _yogaLimit = 5;
  bool _showExpandedContacts = false;
  bool _showSourcePredicateMatches = false;
  int _trineCombinationLimit = 12;
  int _jupiterCombinationLimit = 12;
  int _everyPlanetCombinationLimit = 12;

  static const _burgundy = Color(0xFF7B1E2B);
  static const _muted = Color(0xFF62666D);
  static const _panelBg = Color(0xFFF7F8FA);
  static const _cardBg = Colors.white;

  // Distinct but coordinated colors for the twelve bhava selectors.
  // Pastel backgrounds remain readable; selected cards use their deeper accent.
  static const _bhavaColors = <Color>[
    Color(0xFF00796B), Color(0xFF2055A6), Color(0xFF7746A0),
    Color(0xFF3A7D44), Color(0xFFC16C1B), Color(0xFFAD3768),
    Color(0xFF3D5CBB), Color(0xFF93613D), Color(0xFF7148BD),
    Color(0xFF087E9E), Color(0xFF58802C), Color(0xFF99354F),
  ];
  static const _subTabColors = <Color>[
    Color(0xFF00796B), // జాతక పరిశీలన
    Color(0xFF6E45AA), // యోగాలు
    Color(0xFF4569AF), // భూతం
    Color(0xFFB96D1D), // వర్తమానం
    Color(0xFF1F8062), // భవిష్యత్తు
  ];
  static const _subTabIcons = <IconData>[
    Icons.fact_check_outlined, Icons.auto_awesome_outlined,
    Icons.history, Icons.today_outlined, Icons.event_available_outlined,
  ];

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BnnMasterRule>>(
      future: _catalog,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return _panel(
            child: Text('BNN నియమాలను లోడ్ చేయలేకపోయాం: ${snapshot.error}'),
          );
        }
        if (!snapshot.hasData) {
          return const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          );
        }

        final rules = snapshot.data!;
        final age = BnnMasterAnalysis.completedAge(
          widget.birthData.localDateTime,
          DateTime.now(),
        );
        final houseRules = rules.where(_matchesSearch).where(
          (r) => BnnMasterAnalysis.housesForRule(r).contains(_selectedHouse),
        ).toList(growable: false);
        final sourcePredicateHits = <(BnnMasterRule, BnnExactIfResult)>[];
        for (final rule in houseRules) {
          final checked = BnnAllRulesMatchService.check(rule, widget.chart);
          if (checked.evaluable && checked.matched) {
            sourcePredicateHits.add((rule, checked));
          }
        }
        // Diagnostic across ALL 462 source IF clauses. Deliberately ignores
        // OCR/status for computing natal geometry; NEVER changes provenance.
        final sourceEvaluable = <(BnnMasterRule, BnnExactIfResult)>[];
        final sourceAutoMatched = <(BnnMasterRule, BnnExactIfResult)>[];
        for (final rule in rules) {
          final test = BnnAllRulesMatchService.check(rule, widget.chart);
          if (!test.evaluable) continue;
          sourceEvaluable.add((rule, test));
          if (test.matched) sourceAutoMatched.add((rule, test));
        }
        final allCandidates = _matchedRulesForHouse(houseRules);
        // Keep sign-link evidence separate from an observed conjunction.
        // Neither tier constitutes a confirmed life event.
        final matchedResults = allCandidates.where((hit) =>
            BnnMasterAnalysis.hasSingleSignPlacement(hit.rule, widget.chart))
            .toList(growable: false);
        final expandedContacts = allCandidates.where((hit) =>
            !BnnMasterAnalysis.hasSingleSignPlacement(hit.rule, widget.chart))
            .toList(growable: false);
        final yogaMatches = matchedResults
            .where((hit) => BnnMasterAnalysis.looksLikeYogaRule(hit.rule))
            .toList(growable: false);

        if (_mainTab != 1) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _mainModePicker(),
              if (_mainTab == 0)
                _mainResultsPanel(rules.length, sourceEvaluable, sourceAutoMatched)
              else if (_mainTab == 2)
                _panel(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _sectionTitle('గ్రహసంబంధాలు — డిగ్రీల క్రమం'),
                    const Text('నాడీ 1–5–9, సంయోగాలు, ముందు/వెనుక సంబంధాల గణన. '
                        'ఇవి వ్యక్తిగత ఫలితాలుగా ప్రకటించబడవు.',
                        style: TextStyle(color: _muted, fontSize: 12.5)),
                    _degreeSequenceExplorer(initiallyExpanded: true),
                  ],
                ))
              else if (_mainTab == 3)
                _eventPanel(rules, age)
              else if (_mainTab == 4)
                _relationPanel(rules)
              else if (_mainTab == 5)
                _sourceCatalogueTab(rules)
              else
                BnnD1BhavaPanel(chart: widget.chart),
            ],
          );
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _mainModePicker(),
            _panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'BNN — భావాలవారీ నియమాలు',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'గురు రాశి మొదటి భావం • ప్రతి భావంలో 5 ప్రత్యేక ట్యాబ్‌లు • మూల నియమాల పరిశీలన',
                    style: TextStyle(fontSize: 12.5, color: _muted),
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _countPill('${matchedResults.length} సంయోగ ఫలిత సూచనలు'),
                      _countPill('${expandedContacts.length} ఇతర సంబంధ పరిశీలనలు'),
                      _countPill('${yogaMatches.length} యోగ సూచనలు'),
                      _countPill('144 అంశాలకు కారకగ్రహ పరిశీలన'),
                    ],
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    decoration: const InputDecoration(
                      prefixIcon: Icon(Icons.search),
                      hintText: 'పలితం / గ్రహం / నియమం / ID వెతకండి',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onChanged: (value) => setState(() => _search = value.trim()),
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    '12 భావాలు',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 8),
                  GridView.builder(
                    itemCount: 12,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      childAspectRatio: 1.55,
                      crossAxisSpacing: 8,
                      mainAxisSpacing: 8,
                    ),
                    itemBuilder: (context, index) {
                      final house = index + 1;
                      final selected = house == _selectedHouse;
                      final accent = _bhavaColors[index];
                      return InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () => setState(() {
                          _selectedHouse = house;
                          _resultsLimit = 8;
                          _yogaLimit = 5;
                          _selectedSubTab = 0;
                          _showExpandedContacts = false;
                        }),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          curve: Curves.easeInOut,
                          decoration: BoxDecoration(
                            color: selected
                                ? accent
                                : Color.lerp(Colors.white, accent, 0.105),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: selected
                                  ? accent
                                  : Color.lerp(Colors.white, accent, 0.50)!,
                              width: selected ? 2.0 : 1.2,
                            ),
                            boxShadow: selected ? [
                              BoxShadow(
                                color: accent.withAlpha(60),
                                blurRadius: 8,
                                offset: const Offset(0, 3),
                              ),
                            ] : null,
                          ),
                          padding: const EdgeInsets.fromLTRB(10, 7, 7, 7),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(children: [
                                Expanded(child: Text(
                                  '${house} భావం',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 16,
                                    color: selected ? Colors.white : accent,
                                  ),
                                )),
                                if (selected)
                                  const Icon(Icons.check_circle, color: Colors.white, size: 16),
                              ]),
                              const SizedBox(height: 4),
                              Text(
                                BnnMasterAnalysis.houseTheme(house),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: 11.5,
                                  height: 1.25,
                                  color: selected ? Colors.white : const Color(0xFF454A54),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _panel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    BnnMasterAnalysis.houseLabel(_selectedHouse),
                    style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    BnnMasterAnalysis.houseTheme(_selectedHouse),
                    style: const TextStyle(fontSize: 12.5, color: _muted),
                  ),
                  const SizedBox(height: 10),
                  _infoBox(
                    title: 'ఎంచుకున్న భావంలోని గ్రహాలు (మొత్తం 9 కాదు)',
                    body: BnnMasterAnalysis.houseOccupancyText(widget.chart, _selectedHouse),
                  ),
                  const SizedBox(height: 8),
                  ExpansionTile(
                    tilePadding: EdgeInsets.zero,
                    title: const Text('మొత్తం జన్మగ్రహాలు — 9 గ్రహాల రాశి, డిగ్రీలు',
                      style: TextStyle(fontWeight: FontWeight.w700)),
                    children: [
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Text(BnnMasterAnalysis.allNatalPositionsText(widget.chart),
                          style: const TextStyle(fontSize: 13, height: 1.55)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Text('BNN భావ క్రమం: గురు ఉన్న రాశి 1వ భావం; అక్కడి నుండి రాశుల వారీగా 2–12.',
                    style: TextStyle(fontSize: 12, color: _muted, height: 1.45)),
                  const SizedBox(height: 14),
                  _subTabPicker(),
                  const SizedBox(height: 14),
                  if (_selectedSubTab == 0) ...[
                    // Results-first: present auditable exact natal IFs before
                    // 144 topic cards or generic relation candidates.
                    _bhavaTopicChartReadings(rules, sourceAutoMatched),
                    const SizedBox(height: 12),
                    ExpansionTile(
                      initiallyExpanded: false,
                      title: const Text('అదనపు గ్రహసంబంధాలు / మూల సూచనలు',
                          style: TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: const Text('ప్రధాన ఫలితాలు కాకుండా వేరుగా పరిశీలించండి',
                          style: TextStyle(fontSize: 11.8)),
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                    const SizedBox(height: 16),
                    _sectionTitle('అదనపు ప్రాథమిక సంయోగ సూచనలు (${matchedResults.length})'),
                    const SizedBox(height: 5),
                    const Text(
                      'జన్మ చక్రంలో ఒకే రాశిలో ఉన్న గ్రహాల ఆధారంగా వచ్చిన మూలగ్రంథ సూచనలు మాత్రమే. '
                      'సంఘటన నిజంగా జరిగిందని లేదా తప్పక జరుగుతుందని నిర్ధారణ కాదు. '
                      'పలితం టచ్ చేస్తే IF నియమం, గ్రహస్థితులు, పరిశీలన కనిపిస్తాయి.',
                      style: TextStyle(color: _muted, fontSize: 12.5, height: 1.45),
                    ),
                    const SizedBox(height: 8),
                    if (matchedResults.isEmpty)
                      _emptyMessage('ఈ భావానికి ఒకే రాశి సంయోగం ఆధారంగా ప్రాథమిక ఫలిత సూచనలు కనిపించలేదు. '
                          'మిగతా గ్రహ సంబంధాలు కింద పరిశీలించవచ్చు.')
                    else ...[
                      for (final hit in matchedResults.take(_resultsLimit))
                        _candidateRuleTile(hit.rule, hit.evidence),
                      if (matchedResults.length > _resultsLimit)
                        TextButton(
                          onPressed: () => setState(() => _resultsLimit += 6),
                          child: Text('ఇంకా ${matchedResults.length - _resultsLimit} ఫలిత సూచనలు'),
                        ),
                    ],
                    const SizedBox(height: 15),
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => setState(() =>
                          _showExpandedContacts = !_showExpandedContacts),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 9),
                        child: Row(children: [
                          const Icon(Icons.account_tree_outlined,
                              color: _burgundy),
                          const SizedBox(width: 8),
                          Expanded(child: Text(
                            'ఇతర రాశి సంబంధాల పరిశీలన (${expandedContacts.length})',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          )),
                          Icon(_showExpandedContacts
                              ? Icons.expand_less : Icons.expand_more),
                        ]),
                      ),
                    ),
                    if (_showExpandedContacts) ...[
                      const Text(
                        'త్రికోణం, 2/7/12 సంబంధాలను ఫలితాలుగా చూపించలేదు. '
                        'గ్రహసంబంధం నిజంగా ఏ విధంగా వర్తిస్తుందో నాడీ పద్ధతితో పరిశీలించాలి.',
                        style: TextStyle(color: _muted, fontSize: 12.3,
                            height: 1.45),
                      ),
                      const SizedBox(height: 8),
                      if (expandedContacts.isEmpty)
                        _emptyMessage('వేరుగా పరిశీలించాల్సిన సంబంధాలు లేవు.')
                      else
                        for (final hit in expandedContacts)
                          _contactReviewTile(hit.rule, hit.evidence),
                    ],
                    const SizedBox(height: 14),
                    const SizedBox(height: 12),
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () => setState(() => _showSourcePredicateMatches =
                          !_showSourcePredicateMatches),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        child: Row(children: [
                          const Icon(Icons.rule_outlined, color: _burgundy),
                          const SizedBox(width: 9),
                          Expanded(child: Text(
                            'మూలగ్రంథం — జన్మ IF సరిపోలినవి '
                            '(${sourcePredicateHits.length})',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          )),
                          Icon(_showSourcePredicateMatches ?
                              Icons.expand_less : Icons.expand_more),
                        ]),
                      ),
                    ),
                    if (_showSourcePredicateMatches) ...[
                      const Text(
                        'ఈ నియమాల మొత్తం IF జన్మస్థితిని యాప్ గణించింది. '
                        'అయితే OCR మూలవచనం అసలు స్కాన్‌తో ఇంకా ధృవీకరించలేదు. '
                        'కనుక ఇవి నిర్ధారిత జీవిత సంఘటనలు కావు; '
                        'శుభ/అశుభ రంగులు వర్తించవు.',
                        style: TextStyle(color: _muted, fontSize: 12.5,
                            height: 1.4),
                      ),
                      const SizedBox(height: 8),
                      if (sourcePredicateHits.isEmpty)
                        _emptyMessage('ఈ భావానికి గణించగలిగిన మూల IF '
                            'జన్మస్థితి సరిపోలలేదు. ఇతర నియమాలకు '
                            'విస్తృత గణనలు అవసరం.'),
                      for (final hit in sourcePredicateHits.take(30))
                        Card(
                          margin: const EdgeInsets.only(bottom: 8),
                          elevation: 0,
                          color: const Color(0xFFF5F5FA),
                          child: ListTile(
                            title: Text(hit.$2.matchedThen ?? hit.$1.result,
                              maxLines: 2, overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontWeight: FontWeight.w800)),
                            subtitle: Text('జన్మ IF సరిపోయింది • OCR ధృవీకరణ మిగిలి ఉంది '
                                '• ${hit.$1.id}',
                              style: const TextStyle(fontSize: 11.8)),
                            trailing: const Icon(Icons.chevron_right),
                            onTap: () => _showRuleSheet(hit.$1,
                              '${hit.$2.reason}. అసలు PDF వాక్యం '
                              'ధృవీకరించాకనే గ్రంథ ఫలితంగా పరిగణించాలి.',
                              hit.$2.matchedThen),
                          ),
                        ),
                      if (sourcePredicateHits.length > 30)
                        Text('మొదటి 30 సూచనలు మాత్రమే; '
                            'మిగతావి మూలగ్రంథ సూచికలో చూడండి.',
                          style: const TextStyle(fontSize: 12, color: _muted)),
                    ],
                    const SizedBox(height: 12),
                    _topicExplorer(rules),
                          ],
                        ),
                      ],
                    ),
                  ] else if (_selectedSubTab == 1) ...[
                    _sectionTitle('ఈ భావానికి సంబంధించిన యోగ సూచనలు'),
                    const SizedBox(height: 6),
                    const Text('ఒకే రాశి సంయోగ సూచనలు మాత్రమే. పూర్తి యోగ నిర్ధారణ కాలేదు; ఇతర రాశి సంబంధాలు ఫలితాల్లో కలపలేదు.',
                      style: TextStyle(color: _muted, fontSize: 12, height: 1.45)),
                    const SizedBox(height: 10),
                    if (yogaMatches.isEmpty)
                      _emptyMessage('ఈ జాతకంలో ఈ భావానికి ప్రాథమిక సంయోగ సూచనలు కనిపించలేదు.')
                    else
                      for (final hit in yogaMatches.take(_yogaLimit))
                        _candidateRuleTile(hit.rule, hit.evidence),
                    if (yogaMatches.length > _yogaLimit)
                      TextButton(
                        onPressed: () => setState(() => _yogaLimit += 10),
                        child: Text('ఇంకా ${yogaMatches.length - _yogaLimit} యోగాలు చూపించు'),
                      ),
                  ] else ...[
                    _sectionTitle(_periodTitle),
                    const SizedBox(height: 8),
                    _infoBox(title: _periodHeading(age), body: _periodDescription(age)),
                    const SizedBox(height: 12),
                    _sectionTitle('వయస్సు / గురు–శని చక్ర పరిశీలన'),
                    const SizedBox(height: 8),
                    ..._periodBandWidgets(age),
                    const SizedBox(height: 10),
                    _emptyMessage('ఈ కాలంలోని సంఘటన ఖచ్చితంగా జరిగిందా లేదా జరగబోతుందా అని నిర్ణయించే పూర్తి BNN కాలగణన ఇంకా ధృవీకరించలేదు.'),
                  ],
                  const SizedBox(height: 15),
                  const SizedBox(height: 16),
                  const Divider(),
                  const SizedBox(height: 6),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.library_books_outlined),
                    label: const Text('6. మూల నియమాల ట్యాబ్ చూడండి'),
                    onPressed: () => setState(() => _mainTab = 5),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }


  Widget _mainModePicker() => _panel(child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('BNN — 6 ట్యాబ్‌లు + D1 భావఫల విభాగం',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      const SizedBox(height: 5),
      const Text('ముందు ఫలితాలు → తరువాత భావాలు, గ్రహసంబంధాలు, కాలం, '
          'బంధుత్వాలు → చివరగా మూలగ్రంథం.',
          style: TextStyle(fontSize: 11.5, color: _muted)),
      const SizedBox(height: 9),
      Wrap(spacing: 7, runSpacing: 6, children: [
        _modeChoice(0, BnnNavigationSpec.labels[0], Icons.fact_check_outlined,
            const Color(0xFF00796B)),
        _modeChoice(1, BnnNavigationSpec.labels[1], Icons.grid_view_rounded,
            const Color(0xFF2055A6)),
        _modeChoice(2, BnnNavigationSpec.labels[2], Icons.account_tree_outlined,
            const Color(0xFF7148BD)),
        _modeChoice(3, BnnNavigationSpec.labels[3], Icons.event_note_outlined,
            const Color(0xFF3656A6)),
        _modeChoice(4, BnnNavigationSpec.labels[4], Icons.people_alt_outlined,
            const Color(0xFF8B408B)),
        _modeChoice(5, BnnNavigationSpec.labels[5], Icons.library_books_outlined,
            const Color(0xFF99354F)),
        _modeChoice(6, 'D1 12 భావఫలాలు (336)', Icons.menu_book_outlined,
            const Color(0xFF147C75)),
      ]),
    ],
  ));

  /// Visible source THEN first; full IF, natal evidence and remedy on tap.
  /// A nominal age band is shown only for an explicit Jupiter-relative rule.
  Widget _matchedOutcomeCard(BnnMatchedOutcome hit) {
    final rule = hit.$1;
    final checked = hit.$2;
    final ageHint = BnnRelativeTimingService.ageWindowsForRule(
        rule, widget.chart, widget.birthData.localDateTime.year);
    return Card(
      elevation: 0,
      color: const Color(0xFFF2F8F5),
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: const Icon(Icons.fact_check_outlined,
            color: Color(0xFF00796B)),
        title: Text(checked.matchedThen ?? rule.result,
            style: const TextStyle(fontSize: 15,
                fontWeight: FontWeight.w800)),
        subtitle: Text('రూల్: ${rule.condition}',
            maxLines: 2, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 11.8, height: 1.45)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showRuleSheet(rule,
            'జన్మ IF గణన: ${checked.reason}. '
            '${ageHint == null ? 'ఈ IFకు ప్రత్యేక వార్షిక సూచిక లేదు.' : ageHint} '
            'మూలవచన ధృవీకరణ స్థితి: ${rule.status}.',
            checked.matchedThen),
      ),
    );
  }

  Widget _mainResultsPanel(int total,
      List<(BnnMasterRule, BnnExactIfResult)> evaluable,
      List<(BnnMasterRule, BnnExactIfResult)> matched) {
    return _panel(child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _sectionTitle('జాతకానికి సరిపోయిన మూల IF ఫలిత సూచనలు'),
        const SizedBox(height: 6),
        Text('${matched.length} జన్మ IF TRUE • ${evaluable.length} గణించగల IFలు '
            '• మొత్తం $total మూల నియమాలు',
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
        const SizedBox(height: 8),
        const Text('రూల్ → పరిశీలన → ఫలితం',
            style: TextStyle(color: _muted, fontSize: 12.5, height: 1.45)),
        const SizedBox(height: 12),
        _sectionTitle('12 భావాలవారీ ఫలితాలు — టచ్ చేసి చూడండి'),
        const SizedBox(height: 7),
        Wrap(spacing: 6, runSpacing: 6, children: [
          for (var h = 1; h <= 12; h++)
            ActionChip(
              avatar: Icon(Icons.fact_check_outlined, size: 16,
                  color: BnnOutcomeRouter.forHouse(h, matched).isNotEmpty
                      ? const Color(0xFF00796B) : _muted),
              label: Text('$h భావం • ${BnnOutcomeRouter.forHouse(h, matched).length}',
                  style: const TextStyle(fontSize: 12)),
              onPressed: () => setState(() {
                _selectedHouse = h;
                _selectedSubTab = 0;
                _mainTab = 1;
              }),
            ),
        ]),
        const SizedBox(height: 13),
        _sectionTitle('జాతక IF TRUE అయిన మూల ఫలితాలు'),
        const SizedBox(height: 7),
        if (matched.isEmpty) _emptyMessage('ప్రస్తుతం గణించగల IFల్లో ఈ జాతకానికి '
            'సరిపోయిన సూచన లేదు. మిగిలిన నియమాలు మూల గ్రంథాలయ ట్యాబ్‌లో ఉంటాయి.'),
        for (final hit in matched.take(_overviewLimit))
          _matchedOutcomeCard(hit),
        if (matched.length > _overviewLimit) TextButton.icon(
          icon: const Icon(Icons.expand_more),
          onPressed: () => setState(() => _overviewLimit += 10),
          label: Text('ఇంకా ${matched.length - _overviewLimit} చూపించండి'),
        ),
        const SizedBox(height: 12),
        _sectionTitle('ఈ రూల్ ప్రకారం లేని ఫలితాలు '
            '(${evaluable.length - matched.length})'),
        const SizedBox(height: 5),
        for (final item in evaluable.where((item) => !item.$2.matched)
            .take(_negativeLimit))
          _sourceRuleTile(item.$1),
        if (evaluable.length - matched.length > _negativeLimit)
          TextButton.icon(
            icon: const Icon(Icons.expand_more),
            onPressed: () => setState(() => _negativeLimit += 20),
            label: Text('ఇంకా ${evaluable.length - matched.length - _negativeLimit} చూపించండి'),
          ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          icon: const Icon(Icons.grid_view_outlined),
          label: const Text('2. 12 భావాల ఫలితాలు పరిశీలించండి'),
          onPressed: () => setState(() => _mainTab = 1),
        ),
        OutlinedButton.icon(
          icon: const Icon(Icons.library_books_outlined),
          label: const Text('6. మొత్తం 462 మూల నియమాలు'),
          onPressed: () => setState(() => _mainTab = 5),
        ),
      ],
    ));
  }

  Widget _sourceCatalogueTab(List<BnnMasterRule> rules) {
    final filtered = <(BnnMasterRule, BnnExactIfResult)>[];
    for (final rule in rules) {
      final q = '${rule.id} ${rule.condition} ${rule.result} ${rule.topic}'
          .toLowerCase();
      if (!q.contains(_libraryQuery.toLowerCase())) continue;
      final check = BnnAllRulesMatchService.check(rule, widget.chart);
      if (_libraryFilter == 1 && (!check.evaluable || !check.matched)) continue;
      if (_libraryFilter == 2 && (!check.evaluable || check.matched)) continue;
      if (_libraryFilter == 3 && check.evaluable) continue;
      filtered.add((rule, check));
    }
    return _panel(child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _sectionTitle('462 మూల IF–THEN నియమాల గ్రంథాలయం'),
        const SizedBox(height: 5),
        const Text('ఇవి అన్ని మూల నియమాలు — అన్నీ జాతకానికి వర్తించినట్లు కాదు. '
            'IF TRUE, FALSE లేదా ఇంకా అర్థం స్పష్టంగా లేని స్థితి ఆధారంగా చూడవచ్చు.',
            style: TextStyle(fontSize: 12, color: _muted, height: 1.45)),
        const SizedBox(height: 12),
        TextField(
          onChanged: (value) => setState(() {
            _libraryQuery = value.trim();
            _libraryLimit = 15;
          }),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'రూల్ ID / గ్రహం / ఫలితం వెతకండి',
            border: OutlineInputBorder(),
            isDense: true,
          ),
        ),
        const SizedBox(height: 9),
        Wrap(spacing: 6, runSpacing: 4, children: [
          for (final option in const <(int, String)>[
            (0, 'అన్నీ'), (1, 'సరిపోయినవి'), (2, 'సరిపోనివి'), (3, 'ఇతర రూల్స్')
          ]) ChoiceChip(
            label: Text(option.$2),
            selected: _libraryFilter == option.$1,
            onSelected: (_) => setState(() {
              _libraryFilter = option.$1;
              _libraryLimit = 15;
            }),
          ),
        ]),
        const SizedBox(height: 5),
        Text('కనిపిస్తున్న నియమాలు: ${filtered.length} / ${rules.length}',
            style: const TextStyle(fontSize: 12.5, color: _muted)),
        const SizedBox(height: 8),
        if (filtered.isEmpty) _emptyMessage('ఈ ఫిల్టర్‌కు నియమాలు లేవు.'),
        for (final entry in filtered.take(_libraryLimit)) Card(
          elevation: 0,
          color: const Color(0xFFF9FAFC),
          margin: const EdgeInsets.only(bottom: 6),
          child: ListTile(
            title: Text(BnnRuleVerdict.result(entry.$1, entry.$2),
                maxLines: 3, overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
            subtitle: Text('రూల్: ${entry.$1.condition}',
                style: const TextStyle(fontSize: 11.5, height: 1.4)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showRuleSheet(entry.$1,
                'జన్మ IF పరిశీలన: ${entry.$2.reason}; మూల గ్రంథ వివరాలు వేరుగా చూడండి.',
                entry.$2.matchedThen),
          ),
        ),
        if (filtered.length > _libraryLimit) TextButton.icon(
          icon: const Icon(Icons.expand_more),
          onPressed: () => setState(() => _libraryLimit += 25),
          label: Text('ఇంకా ${filtered.length - _libraryLimit} నియమాలు చూపించండి'),
        ),
      ],
    ));
  }

  Widget _modeChoice(int index, String name, IconData icon, Color accent) =>
      ChoiceChip(
        avatar: Icon(icon, size: 18, color: _mainTab == index ? Colors.white : accent),
        label: Text(name),
        selected: _mainTab == index,
        showCheckmark: false,
        selectedColor: accent,
        backgroundColor: Color.lerp(Colors.white, accent, 0.09),
        side: BorderSide(color: accent.withAlpha(110)),
        labelStyle: TextStyle(
          fontWeight: FontWeight.w800,
          color: _mainTab == index ? Colors.white : accent,
        ),
        onSelected: (_) => setState(() {
          _mainTab = index;
          if (index == 5) { _libraryQuery = ''; _libraryLimit = 15; }
        }),
      );

  /// v1.1 BNN-M-010..034 and 095..106. Computed natal relationships,
  /// NOT extra IF–THEN source outcomes or verified forecasts.
  Widget _degreeSequenceExplorer({bool initiallyExpanded = false}) {
    final sequences = BnnNadiDegreeEngine.sequences(widget.chart);
    final contacts = BnnNadiDegreeEngine.contacts(widget.chart);
    final jupiter = BnnNadiDegreeEngine.planet(widget.chart, 'Jupiter');
    return ExpansionTile(
      initiallyExpanded: initiallyExpanded,
      tilePadding: const EdgeInsets.symmetric(horizontal: 3),
      childrenPadding: const EdgeInsets.only(bottom: 8),
      leading: const Icon(Icons.linear_scale_outlined, color: _burgundy),
      title: const Text('BNN డిగ్రీ క్రమం • నాడీ గ్రహ సంబంధాలు',
        style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w800)),
      subtitle: Text('${sequences.length} త్రికోణ సమూహాలు • ${contacts.length} గ్రహసంబంధాలు • గణన మాత్రమే',
        style: const TextStyle(fontSize: 11.5, color: _muted)),
      children: [
        const Text('BNN-M-095..106: 1–5–9 త్రికోణంలో 0°–30° స్థానిక డిగ్రీతో '
          'చిన్నది → పెద్దది. వక్రత్వం వేరుగా; ఈ క్రమం నుంచి సంఘటన తేదీ రాదు.',
          style: TextStyle(fontSize: 12, color: _muted, height: 1.45)),
        if (jupiter != null) Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text('BNN మొదటి రాశి: '
              '${BnnMasterAnalysis.signNames[BnnNadiDegreeEngine.zodiacSign(jupiter.longitude)]} '
              '• గురు ${BnnNadiDegreeEngine.dms(jupiter)} '
              '• జన్మలగ్నం మారదు',
              style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
        ),
        const SizedBox(height: 6),
        for (final group in sequences) Card(
          color: const Color(0xFFF0F6FC),
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(BnnNadiDegreeEngine.groupName(group.trineGroup),
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
              const SizedBox(height: 4),
              Text(group.planets.map((p) =>
                  '${BnnNadiDegreeEngine.teluguName(p)} '
                  '${BnnNadiDegreeEngine.dms(p)}${p.retrograde ? ' (వక్ర)' : ''}')
                .join('  →  '), style: const TextStyle(fontSize: 12, height: 1.5)),
            ]),
          ),
        ),
        if (sequences.isEmpty) const Text('త్రికోణంలో రెండు గ్రహాలు కనిపించలేదు.'),
        const SizedBox(height: 7),
        _relationsFromEveryPlanetExplorer(),
        const SizedBox(height: 7),
        _combinationMethodExplorer(
          label: 'పద్ధతి 1 — స్థానిక డిగ్రీల 1–5–9 చైన్లు',
          combinations: BnnCombinationEngine.degreeTrine(widget.chart),
          methodIndex: 0,
        ),
        _combinationMethodExplorer(
          label: 'పద్ధతి 2 — గురు కేంద్రంగా గ్రహ కాంబినేషన్లు',
          combinations: BnnCombinationEngine.jupiterCentred(widget.chart),
          methodIndex: 1,
        ),
        _combinationMethodExplorer(
          label: 'పద్ధతి 3 — ప్రతి గ్రహం కేంద్రంగా అన్ని సంబంధాల చైన్లు',
          combinations: BnnCombinationEngine.everyPlanetAnchored(widget.chart),
          methodIndex: 2,
        ),
        Padding(
          padding: const EdgeInsets.only(top: 6, bottom: 6),
          child: OutlinedButton.icon(
            icon: const Icon(Icons.fact_check_outlined),
            label: const Text('జాతకానికి IF సరిపోయిన మూల ఫలితాలు చూడండి'),
            onPressed: () => setState(() => _mainTab = 0),
          ),
        ),
        const SizedBox(height: 7),
        ExpansionTile(
          initiallyExpanded: false,
          title: Text('గ్రహసంబంధాల సాంకేతిక వివరాలు (${contacts.length})',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5)),
          subtitle: const Text('డిగ్రీ, సంబంధాల పరిశీలన మాత్రమే; జీవిత ఫలితాలు కావు',
              style: TextStyle(fontSize: 11.2)),
          children: [
            for (final contact in contacts.take(18)) ListTile(
              dense: true,
              contentPadding: EdgeInsets.zero,
              title: Text('${BnnNadiDegreeEngine.teluguName(contact.first)} + '
                  '${BnnNadiDegreeEngine.teluguName(contact.second)} — ${contact.kind}',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              subtitle: Text('${BnnNadiDegreeEngine.dms(contact.first)} / '
                  '${BnnNadiDegreeEngine.dms(contact.second)} • ${contact.degreeOrder}',
                  style: const TextStyle(fontSize: 11.5, color: _muted)),
            ),
            if (contacts.length > 18)
              Text('మొదటి 18 మాత్రమే చూపించాం; మొత్తం ${contacts.length} సంబంధాలు.',
                  style: const TextStyle(fontSize: 11.5, color: _muted)),
          ],
        ),
        const SizedBox(height: 5),
        OutlinedButton.icon(
          icon: const Icon(Icons.menu_book_outlined),
          label: const Text('106 Engine IF–THEN నియమాలు చూడండి'),
          onPressed: _openEngineSpecLibrary,
        ),
        const Text('ఇవి BNN Engine Calculation నిబంధనలు. 462 మూల ఫలితాల '
            'నియమాలు ధృవీకరించకుండా AutoFire కావు.',
            style: TextStyle(fontSize: 11.2, color: _muted)),
      ],
    );
  }

  /// All 9 grahas are anchor points. Show the directed position and DMS of
  /// neighbours in each specified BNN relationship family.
  Widget _relationsFromEveryPlanetExplorer() {
    final relations = BnnCombinationEngine.relationsFromEveryPlanet(widget.chart);
    const families = ['1–5–9', '3–7–11', '2–12'];
    return Card(
      elevation: 0,
      color: const Color(0xFFF0F6FC),
      child: ExpansionTile(
        title: const Text('ప్రతి గ్రహం నుంచి 1–5–9 / 3–7–11 / 2–12',
          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12.8)),
        subtitle: Text('${relations.length} దిశాపరమైన గ్రహసంబంధాలు • 9 గ్రహాల నుంచి విడివిడిగా',
          style: const TextStyle(fontSize: 11.2, color: _muted)),
        childrenPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        children: [
          const Text('A → B సంబంధం A నుంచి లెక్కించిన భావం. B → Aను విడిగా '
            'లెక్కించాలి. రాహు–కేతు మూలగ్రహాలకు BNN_159_12 profile ప్రకారం '
            '1–5–9 మరియు 12వ స్థానం మాత్రమే.',
            style: TextStyle(fontSize: 11.3, color: _muted)),
          for (final planet in widget.chart.planets)
            ExpansionTile(
              tilePadding: const EdgeInsets.symmetric(horizontal: 5),
              title: Text('${BnnNadiDegreeEngine.teluguName(planet)} '
                  '${BnnNadiDegreeEngine.dms(planet)}',
                  style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700)),
              children: [
                for (final family in families)
                  if (relations.any((r) => r.anchor.name == planet.name && r.family == family))
                    Padding(
                      padding: const EdgeInsets.only(bottom: 7),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text('$family: ${relations.where((r) => r.anchor.name == planet.name && r.family == family).map((r) => r.evidence).join(' • ')}',
                          style: const TextStyle(fontSize: 11.5, height: 1.5)),
                      ),
                    ),
                if (!relations.any((r) => r.anchor.name == planet.name))
                  const Text('ఈ వర్గాల్లో ఇతర గ్రహాలు లేవు.'),
              ],
            ),
        ],
      ),
    );
  }

  /// Two complementary, independent ways to enumerate BNN candidate links.
  /// Enumerating more subsets increases coverage, not predictive certainty.
  Widget _combinationMethodExplorer({
    required String label,
    required List<BnnCombination> combinations,
    required int methodIndex,
  }) {
    final localMethod = methodIndex == 0;
    final limit = methodIndex == 0 ? _trineCombinationLimit
        : methodIndex == 1 ? _jupiterCombinationLimit
        : _everyPlanetCombinationLimit;
    final shown = combinations.take(limit).toList(growable: false);
    final counts = <int, int>{};
    for (final combo in combinations) {
      counts[combo.size] = (counts[combo.size] ?? 0) + 1;
    }
    final countLabel = (counts.keys.toList()..sort())
        .map((n) => '$n గ్రహాలు: ${counts[n]}').join(' • ');
    return Card(
      elevation: 0,
      color: const Color(0xFFF5F2FA),
      child: ExpansionTile(
        tilePadding: const EdgeInsets.symmetric(horizontal: 10),
        childrenPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        initiallyExpanded: false,
        title: Text('$label (${combinations.length})',
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
        subtitle: Text(countLabel.isEmpty ? 'ఈ పద్ధతికి కనీసం రెండు గ్రహాలు కావాలి' : countLabel,
          style: const TextStyle(fontSize: 11, color: _muted)),
        children: [
          Text(localMethod
            ? 'అదే త్రికోణంలో ఉన్న 2 నుంచి 9 గ్రహాల అన్ని సమూహాలు. '
              'క్రమం: రాశిలోని 0°–30° స్థానిక డిగ్రీలు.'
            : methodIndex == 1
              ? 'జన్మగురువు మొదట; మిగిలిన గ్రహాలు గురువు నుంచి రాశి దూరం '
                'ఆధారంగా. 2 నుంచి 9 గ్రహాల అన్ని సమూహాలు.'
              : 'ప్రతి గ్రహాన్ని మొదటగా తీసుకుని 1–5–9, 3–7–11, 2–12 '
                'సంబంధాల్లో ఉన్న గ్రహాల 2 నుంచి 9 సమూహాలు. '
                'రాహు–కేతు మూలగ్రహాలకు 1–5–9, 12 మాత్రమే.',
            style: const TextStyle(fontSize: 12, color: _muted, height: 1.4)),
          const SizedBox(height: 6),
          for (final combo in shown)
            Card(
              elevation: 0,
              color: Colors.white,
              child: ExpansionTile(
                tilePadding: const EdgeInsets.symmetric(horizontal: 8),
                title: Text('${combo.size} గ్రహాలు • ${combo.positionalChain}',
                  style: const TextStyle(fontSize: 12.2, fontWeight: FontWeight.w700)),
                subtitle: Text(localMethod
                    ? BnnNadiDegreeEngine.groupName(combo.trineGroup!)
                    : methodIndex == 1
                        ? 'గురు మొదటి కారకం • BNN భావక్రమం'
                        : '${BnnNadiDegreeEngine.teluguName(combo.orderedPlanets.first)} '
                          'కేంద్రంగా • గ్రహ సంబంధాలు',
                  style: const TextStyle(fontSize: 11, color: _muted)),
                childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                children: [
                  if (combo.unresolvedDegreeOrder)
                    const Text('సమాన DMS డిగ్రీలు: ముందూ/వెనుకా క్రమం '
                        'నిర్ణయించలేం.', style: TextStyle(
                        color: _burgundy, fontSize: 12)),
                  Text('గ్రహాల స్థానిక డిగ్రీల మొత్తం: '
                      '${combo.degreeAdditionEquation}',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700,
                      height: 1.5)),
                  Text('30° చొప్పున: ${combo.completedThirtyDegreeBlocks} × 30° '
                      '+ ${combo.residueWithinThirtyDegrees}',
                    style: const TextStyle(fontSize: 11.5, color: _muted)),
                  const Text('ఇది డిగ్రీల కూడిక మాత్రమే; దీనిని సంఘటన వయస్సు, '
                      'తేదీ లేదా ఫలితంగా స్వయంగా మార్చకూడదు.',
                    style: TextStyle(fontSize: 11, color: _muted)),
                  const SizedBox(height: 6),
                  Text(combo.pairEvidence.join('\n'),
                      style: const TextStyle(fontSize: 11.8, height: 1.5)),
                  const SizedBox(height: 5),
                  const Text('ఇవి కాంబినేషన్ ఆధారాలు మాత్రమే. మూల 462 IF–THENలో '
                    'పూర్తి షరతు సరిపోతేనే ఆ గ్రంథ ఫలితం వర్తింపజేయాలి. '
                    'ఒకే ఫలితాన్ని రెండుసార్లు ప్రకటించకూడదు.',
                    style: TextStyle(fontSize: 11, color: _muted)),
                ],
              ),
            ),
          if (combinations.length > shown.length)
            TextButton.icon(
              icon: const Icon(Icons.expand_more),
              label: Text('మరిన్ని 20 చూపండి (${shown.length}/${combinations.length})'),
              onPressed: () => setState(() {
                if (methodIndex == 0) {
                  _trineCombinationLimit += 20;
                } else if (methodIndex == 1) {
                  _jupiterCombinationLimit += 20;
                } else {
                  _everyPlanetCombinationLimit += 20;
                }
              }),
            ),
          const Text('ఒకే సమూహం రెండు పద్ధతుల్లో కనిపించినా అది రెండు '
            'స్వతంత్ర జీవిత ఫలితాలు కాదు. వాస్తవ గోచారం, సంఘటన తేదీ '
            'ఈ కాంబినేషన్ల లెక్క నుంచి స్వతహాగా రావు.',
            style: TextStyle(fontSize: 11, color: _muted)),
        ],
      ),
    );
  }

  void _openEngineSpecLibrary() async {
    final specs = await _engineCatalog;
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context, isScrollControlled: true,
      builder: (context) => SafeArea(child: FractionallySizedBox(
        heightFactor: 0.88,
        child: ListView.builder(
          padding: const EdgeInsets.all(14),
          itemCount: specs.length + 1,
          itemBuilder: (context, index) {
            if (index == 0) return const Padding(
              padding: EdgeInsets.only(bottom: 12),
              child: Text('BNN Master v1.1 — 106 Calculation నియమాలు\n'
                'ఇవి 462 మూల ఫలిత నియమాలకు అదనం కాదు.',
                style: TextStyle(fontWeight: FontWeight.w800, height: 1.45)),
            );
            final spec = specs[index - 1];
            return Card(child: ExpansionTile(
              title: Text(spec.id, style: const TextStyle(fontWeight: FontWeight.bold)),
              childrenPadding: const EdgeInsets.all(12),
              children: [
                Text('IF: ${spec.condition}', style: const TextStyle(height: 1.5)),
                const SizedBox(height: 8),
                Text('THEN: ${spec.consequence}', style: const TextStyle(height: 1.5)),
              ],
            ));
          },
        ),
      )),
    );
  }

  void _openTimingRuleLibrary() async {
    try {
      final specs = await _timingCatalog;
      if (!mounted) return;
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (sheetContext) => SafeArea(child: FractionallySizedBox(
          heightFactor: 0.88,
          child: ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: specs.length + 1,
            itemBuilder: (context, index) {
              if (index == 0) return const Padding(
                padding: EdgeInsets.all(8),
                child: Text('BNN Timing & Progression — 48 IF–THEN\n'
                  'ఇవి గణన స్పెసిఫికేషన్లు; 462 మూల ఫలిత నియమాలు వేరు. '
                  'ఇక్కడ IMPLEMENTATION_PENDING ఉన్న నియమాలు పూర్తయినట్లు కాదు.',
                  style: TextStyle(fontWeight: FontWeight.w700, height: 1.4)),
              );
              final item = specs[index - 1];
              return Card(child: ExpansionTile(
                title: Text('${item.id} • ${item.stage}',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                subtitle: Text('${item.implementation} • ${item.sourceType}',
                  style: const TextStyle(fontSize: 11)),
                childrenPadding: const EdgeInsets.all(12),
                children: [
                  Text(item.condition),
                  const SizedBox(height: 8),
                  Text(item.consequence),
                ],
              ));
            },
          ),
        )),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Timing master లోడ్ కాలేదు: $error')));
    }
  }

  Widget _progressionTimingExplorer(int age) {
    final fromAge = age < 0 ? 0.0 : (age > 145 ? 145.0 : age.toDouble());
    final contacts = BnnTimingProgressionService.contacts(
      chart: widget.chart, profile: _timingProfile,
      fromAge: fromAge, toAge: fromAge + 5,
    );
    final progressed = <BnnProgressedPosition>[];
    for (final name in const ['Jupiter', 'Saturn', 'Rahu', 'Ketu']) {
      final planet = BnnNadiDegreeEngine.planet(widget.chart, name);
      if (planet != null) {
        progressed.add(BnnTimingProgressionService.progress(
          planet, fromAge, _timingProfile));
      }
    }
    String planetName(String name) {
      const names = {'Jupiter': 'గురు', 'Saturn': 'శని',
        'Rahu': 'రాహు', 'Ketu': 'కేతు', 'Sun': 'సూర్య',
        'Moon': 'చంద్ర', 'Mars': 'కుజ', 'Mercury': 'బుధ',
        'Venus': 'శుక్ర'};
      return names[name] ?? name;
    }
    return Card(
      color: const Color(0xFFF6F8FE),
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('BNN Timing Master — 48 IF–THEN',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
          const SizedBox(height: 5),
          const Text('ప్రతీకాత్మక Progression మరియు నిజ గోచారం విడిగా. '
            'మూల 462లో VERIFIED=0 కనుక ఇవి సంఘటన నిర్ధారణలు కావు.',
            style: TextStyle(color: _muted, fontSize: 12.4)),
          const SizedBox(height: 8),
          DropdownButton<BnnProgressionProfile>(
            isExpanded: true,
            value: _timingProfile,
            items: BnnProgressionProfile.values.map((p) =>
              DropdownMenuItem(value: p, child: Text(p.teluguLabel,
                style: const TextStyle(fontSize: 12.5)))).toList(),
            onChanged: (value) {
              if (value != null) setState(() => _timingProfile = value);
            },
          ),
          Text('వయస్సు $age వద్ద symbolic positions — ${_timingProfile.methodId}',
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
          for (final p in progressed)
            Text('${planetName(p.planet)} ${p.longitude.toStringAsFixed(2)}° '
              '(${p.degreesPerYear.toStringAsFixed(3)}°/సంవత్సరం)',
              style: const TextStyle(fontSize: 12.3)),
          const SizedBox(height: 8),
          Text('వచ్చే 5 సంవత్సరాలలో symbolic contacts: ${contacts.length}',
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12.5)),
          for (final c in contacts.take(12))
            Text('వయస్సు ${c.ageYears.toStringAsFixed(2)}: '
              '${planetName(c.mover)} → ${planetName(c.target)} '
              '(${c.jupiterRound}వ గురు చక్రం)',
              style: const TextStyle(fontSize: 12, height: 1.55)),
          if (contacts.length > 12) Text('మరిన్ని ${contacts.length - 12} symbolic contacts'),
          if (contacts.isEmpty) const Text('ఈ పరిధిలో symbolic degree contacts లేవు.',
            style: TextStyle(fontSize: 12)),
          const Divider(height: 20),
          const Text('నిజ గోచారం — Swiss Ephemeris (30-day samples)',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
          const Text('క్రింది బటన్ ద్వారా ఇప్పటి నుంచి '
            '6 నమూనాలు, ఒక్కోటి 30 రోజుల తేడాతో. ఇవి ingress/exact తేదీలు కావు.',
            style: TextStyle(fontSize: 11.6, color: _muted)),
          OutlinedButton.icon(
            onPressed: () => setState(() {
              _transitSamples = BnnTimingProgressionService.sampleRealTransits(
                natal: widget.chart, birth: widget.birthData,
                startUtc: DateTime.now().toUtc(), steps: 6, intervalDays: 30);
            }),
            icon: const Icon(Icons.travel_explore, size: 17),
            label: const Text('నిజ గురు–శని గోచారం పరిశీలించండి',
              style: TextStyle(fontSize: 12.2)),
          ),
          if (_transitSamples != null) FutureBuilder<List<BnnTransitSample>>(
            future: _transitSamples,
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Text('గోచార గణన సమస్య: ${snapshot.error}',
                  style: const TextStyle(color: Colors.red));
              }
              if (!snapshot.hasData) return const LinearProgressIndicator();
              final found = snapshot.data!;
              if (found.isEmpty) return const Text('ఈ 6 నమూనాల్లో సంబంధం లేదు.');
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('నమూనా గ్రహసంబంధాలు: ${found.length} '
                  '(ఇవి సంఘటన తేదీలు కావు)',
                  style: const TextStyle(fontWeight: FontWeight.w700)),
                for (final c in found.take(18))
                  Text('${c.atUtc.year}-${c.atUtc.month.toString().padLeft(2, '0')}-'
                    '${c.atUtc.day.toString().padLeft(2, '0')} UTC: '
                    '${planetName(c.mover)} → ${planetName(c.target)} '
                    '${c.relation} • ${c.longitude.toStringAsFixed(2)}°',
                    style: const TextStyle(fontSize: 11.6, height: 1.5)),
                if (found.length > 18) Text('ఇంకా ${found.length - 18} నమూనా సంబంధాలు'),
              ]);
            },
          ),
          const SizedBox(height: 4),
          TextButton.icon(
            onPressed: _openTimingRuleLibrary,
            icon: const Icon(Icons.menu_book_outlined, size: 17),
            label: const Text('మొత్తం 48 Timing IF–THEN నియమాలు చూడండి'),
          ),
        ]),
      ),
    );
  }

  Widget _symbolicTimingExplorer(int age) {
    final lowerAge = age < 0 ? 0 : age;
    final upperAge = lowerAge + 5;
    final quick = BnnNadiDegreeEngine.jupiterQuickWindows(widget.chart,
        minAge: lowerAge, maxAge: upperAge).take(10).toList();
    final saturn = BnnNadiDegreeEngine.saturnSymbolicWindows(widget.chart,
        minAge: lowerAge, maxAge: upperAge).take(10).toList();
    final slow = BnnNadiDegreeEngine.slowJupiterSymbolicLongitude(
        widget.chart, lowerAge.toDouble());
    String ageWindow(BnnSymbolicWindow w) =>
        'వయస్సు ${w.fromAge.toStringAsFixed(1)}–${w.toAge.toStringAsFixed(1)} '
        '• ${BnnNadiDegreeEngine.teluguName(PlanetPosition(name: w.targetPlanet,
           shortName: '', longitude: 0, latitude: 0, speed: 0))} '
        '• ${w.round}వ చక్రం';
    return ExpansionTile(
      tilePadding: const EdgeInsets.symmetric(horizontal: 3),
      title: const Text('గురు–శని Symbolic Timing — విడి పద్ధతులు',
        style: TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
      subtitle: const Text('ఈ వయస్సు పరిధులు సంఘటన జరుగుతుందని చెప్పవు',
        style: TextStyle(fontSize: 11.5, color: _muted)),
      children: [
        const Text('REAL TRANSIT కోసం Swiss Ephemerisతో వాస్తవ గోచార తేదీలు '
            'మరియు మూల IF–THEN ధృవీకరణ అవసరం. ఇక్కడ క్యాలెండర్ సంఘటన ఇవ్వలేదు.',
            style: TextStyle(color: _muted, fontSize: 12.5)),
        const SizedBox(height: 8),
        const Text('Method: JUPITER_1SIGN_PER_YEAR_APPROX',
            style: TextStyle(fontSize: 12.3, fontWeight: FontWeight.bold)),
        for (final w in quick) Text(ageWindow(w), style: const TextStyle(fontSize: 12, height: 1.55)),
        if (quick.isEmpty) const Text('గురు shortlist అందుబాటులో లేదు.'),
        const SizedBox(height: 8),
        const Text('Method: SATURN_2P5Y_PER_SIGN_APPROX',
            style: TextStyle(fontSize: 12.3, fontWeight: FontWeight.bold)),
        for (final w in saturn) Text(ageWindow(w), style: const TextStyle(fontSize: 12, height: 1.55)),
        if (saturn.isEmpty) const Text('శని shortlist అందుబాటులో లేదు.'),
        const SizedBox(height: 8),
        const Text('Method: JUPITER_12Y_PER_SIGN_SLOW (వేరు)',
            style: TextStyle(fontSize: 12.3, fontWeight: FontWeight.bold)),
        Text(slow == null ? 'గురు డేటా అందుబాటులో లేదు.' :
            'ఈ వయస్సు వద్ద Slow symbolic longitude: ${slow.toStringAsFixed(2)}°. '
            'ఇది నిజ గోచార గురు స్థానం కాదు.',
            style: const TextStyle(fontSize: 12)),
      ],
    );
  }

  /// Computed for every natal graha relative to Jupiter (1st BNN sign).
  /// The age windows are an explicitly selected symbolic profile, not
  /// astronomical transit dates or a source-verified event prediction.
  Widget _jupiterRelativeAgeExplorer(List<BnnMasterRule> catalog) {
    final jupiter = BnnRelativeTimingService.natalPlanet(widget.chart, 'Jupiter');
    if (jupiter == null) {
      return _infoBox(title: 'గురు నుంచి గ్రహస్థానాలు',
          body: 'జన్మ గురు స్థానం అందుబాటులో లేదు.');
    }
    const targets = <(String, String)>[
      ('Sun', 'సూర్యుడు'), ('Moon', 'చంద్రుడు'),
      ('Mars', 'కుజుడు'), ('Mercury', 'బుధుడు'),
      ('Venus', 'శుక్రుడు'), ('Saturn', 'శని'),
      ('Rahu', 'రాహువు'), ('Ketu', 'కేతువు'),
    ];
    final birthYear = widget.birthData.localDateTime.year;
    return Card(
      elevation: 0,
      color: const Color(0xFFF1F6FF),
      child: ExpansionTile(
        initiallyExpanded: true,
        title: const Text('గురు నుంచి ప్రతి గ్రహం — ఫలితం, వయస్సు, సంవత్సరం',
            style: TextStyle(fontWeight: FontWeight.w900)),
        subtitle: const Text('JUPITER_1SIGN_PER_YEAR_APPROX • '
            '12 సంవత్సరాలకు చక్రం • గోచారం కాదు',
            style: TextStyle(fontSize: 12)),
        childrenPadding: const EdgeInsets.fromLTRB(10, 4, 10, 14),
        children: [
          const Text('ప్రతి జీవిత సంవత్సరాన్ని టచ్ చేయండి. ఆ కాలానికి '
              'రూల్, జాతక పరిశీలన, కారక ఫలిత సూచన కనిపిస్తాయి. '
              'ఇవి గురు 12 ఏళ్ల ప్రతీకాత్మక చక్రాలు; నిజ గోచార తేదీలు కావు.',
              style: TextStyle(fontSize: 12.5, color: _muted, height: 1.4)),
          const SizedBox(height: 6),
          for (final item in targets)
            Builder(builder: (context) {
              final planet = BnnRelativeTimingService.natalPlanet(
                  widget.chart, item.$1);
              if (planet == null) return const SizedBox.shrink();
              final house = BnnRelativeTimingService.relativeHouse(
                  jupiter.signIndex, planet.signIndex);
              final windows = BnnRelativeTimingService.annualJupiterWindows(
                  house: house, birthYear: birthYear);
              final matchedSource = BnnRelativeTimingService.sourceCandidates(
                  catalog, house, item.$2);
              final passing = matchedSource.where((r) {
                final test = BnnAllRulesMatchService.check(r, widget.chart);
                return test.evaluable && test.matched;
              }).toList();
              return Card(
                margin: const EdgeInsets.only(bottom: 6), elevation: 0,
                child: ExpansionTile(
                  title: Text('గురు నుంచి ${item.$2} — $house వ భావం',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${BnnMasterAnalysis.signNames[planet.signIndex]} '
                      '${planet.degreesInSign.toStringAsFixed(2)}° • '
                      'జీవిత సంవత్సరాలు '
                      '${windows.take(7).map((w) => w.ordinalLifeYear).join(', ')}',
                      style: const TextStyle(fontSize: 12.5)),
                  childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 10),
                  children: [
                    for (final window in windows.take(7))
                      Builder(builder: (context) {
                        final reading = BnnRelativeTimingService.inspectPeriod(
                          chart: widget.chart,
                          jupiter: jupiter,
                          target: planet,
                          window: window,
                          passingSource: passing,
                        );
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 4),
                          elevation: 0,
                          color: const Color(0xFFFFF4F1),
                          child: ExpansionTile(
                            key: ValueKey('bnn-year-${item.$1}-${window.ageEnd}'),
                            tilePadding: const EdgeInsets.symmetric(horizontal: 12),
                            childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                            title: Text('జీవిత ${window.ordinalLifeYear}వ సంవత్సరం '
                                '• వయస్సు ${window.ageStart}–${window.ageEnd}',
                                style: const TextStyle(fontWeight: FontWeight.w800,
                                    fontSize: 13)),
                            subtitle: Text(
                              '${BnnRelativeTimingService.birthdayRange(widget.birthData.localDateTime, window)}\n'
                              'ఫలితం: ${reading.headline}',
                              style: const TextStyle(fontSize: 12.2, height: 1.45)),
                            children: [
                              Align(alignment: Alignment.centerLeft,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('రూల్',
                                        style: TextStyle(fontWeight: FontWeight.w800,
                                            color: _burgundy)),
                                    Text(reading.rule,
                                        style: const TextStyle(height: 1.5)),
                                    const SizedBox(height: 8),
                                    const Text('పరిశీలన',
                                        style: TextStyle(fontWeight: FontWeight.w800,
                                            color: _burgundy)),
                                    Text(reading.inspection,
                                        style: const TextStyle(height: 1.5)),
                                    const SizedBox(height: 8),
                                    const Text('ఫలితం',
                                        style: TextStyle(fontWeight: FontWeight.w800,
                                            color: _burgundy)),
                                    Text(reading.result,
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w600, height: 1.5)),
                                    if (passing.isEmpty)
                                      const Padding(
                                        padding: EdgeInsets.only(top: 6),
                                        child: Text('కారక ఫలిత సూచన మాత్రమే; '
                                            'నిర్ధారిత సంఘటన కాదు.',
                                            style: TextStyle(fontSize: 11.3,
                                                color: _muted)),
                                      ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        );
                      }),
                    if (passing.isNotEmpty) ...[
                      const Divider(height: 15),
                      const Align(alignment: Alignment.centerLeft,
                        child: Text('ఈ గ్రహస్థానానికి పూర్తిగా సరిపోయిన మూల రూల్స్',
                          style: TextStyle(fontWeight: FontWeight.w800))),
                      for (final rule in passing)
                        ListTile(
                          dense: true,
                          title: Text(rule.result),
                          subtitle: Text('${rule.id} • ${rule.condition}'),
                          trailing: const Icon(Icons.chevron_right),
                          onTap: () {
                            final checked = BnnAllRulesMatchService.check(
                                rule, widget.chart);
                            _showRuleSheet(rule, checked.reason,
                                checked.matchedThen);
                          },
                        ),
                    ],
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget _eventPanel(List<BnnMasterRule> catalog, int age) {
    final today = DateTime.now();
    final windows = BnnEventRelations.studyWindows.toList()
      ..sort((a, b) => a.fromAge.compareTo(b.fromAge));
    final timeRules = catalog.where(BnnMasterAnalysis.looksLikeTimingRule).toList();
    return _panel(child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const Text('సంఘటనలు — గతం, వర్తమానం, భవిష్యత్తు',
          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
        const SizedBox(height: 6),
        Text('ప్రస్తుత వయస్సు: $age • జన్మ సంవత్సరం: ${widget.birthData.localDateTime.year}',
          style: const TextStyle(color: _muted, fontSize: 13)),
        const SizedBox(height: 10),
        _infoBox(
          title: 'కాల సూచనలు — నిర్ధారిత సంఘటనలు కావు',
          body: 'మూల BNN R-A03 / R-A04లో ఉన్న గురు (12 సంవత్సరాలు), '
              'శని (30 సంవత్సరాలు) చక్రాల అంశాలను వయస్సు–క్యాలెండర్ '
              'పరిధిగా చూపుతున్నాం. నిజమైన సంఘటనకు కారకగ్రహ సంబంధం, '
              'గ్రహస్పర్శ, గోచారం/నక్షత్రం మరియు మూల OCR ధృవీకరణ అవసరం. '
              'రోజు, నెల, సంవత్సరం ఖచ్చితంగా నిర్ణయించలేదు.'),
        const SizedBox(height: 10),
        _symbolicTimingExplorer(age),
        const SizedBox(height: 8),
        _jupiterRelativeAgeExplorer(catalog),
        const SizedBox(height: 8),
        _progressionTimingExplorer(age),
        const SizedBox(height: 10),
        for (final item in windows) ...[
          Builder(builder: (context) {
            final placement = BnnEventRelations.placementCondition(item, widget.chart);
            final source = BnnEventRelations.findRule(catalog, item.sourceId);
            final label = BnnEventRelations.period(item, widget.birthData, today);
            return Card(
              color: placement == false
                  ? const Color(0xFFF4F4F4) : const Color(0xFFFAFBFF),
              margin: const EdgeInsets.only(bottom: 9), elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
                side: BorderSide(color: placement == false
                    ? const Color(0xFFD5D5D5) : const Color(0xFFC9D4EC))),
              child: ListTile(
                contentPadding: const EdgeInsets.all(12),
                leading: const Icon(Icons.access_time_filled, color: Color(0xFF3656A6)),
                title: Text(item.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 7),
                  child: Text(
                    '$label • వయస్సు ${item.fromAge}–${item.toAge}\n'
                    'సంవత్సర పరిధి సుమారు ${item.firstYear(widget.birthData)}–${item.lastYear(widget.birthData)}\n'
                    '${placement == false ? 'గ్రహస్థితి షరతు సరిపోలలేదు • ' : placement == true ? 'గ్రహస్థితి ప్రారంభ షరతు సరిపోయింది • ' : ''}'
                    'మూల ధృవీకరణ అవసరం • ${item.sourceId}',
                    style: const TextStyle(color: _muted, fontSize: 12.5, height: 1.5),
                  ),
                ),
                trailing: const Icon(Icons.chevron_right, color: _burgundy),
                onTap: () {
                  if (source != null) {
                    _showRuleSheet(source,
                      'సంఘటన కాల అధ్యయనం: ${item.name}. '
                      'వయస్సు ${item.fromAge}–${item.toAge} సూత్రంలోని '
                      'చక్ర పరిధి మాత్రమే. ${item.prerequisite}. '
                      'సంఘటన నిజంగా జరిగిందని/జరుగుతుందని నిర్ధారించలేదు.');
                  }
                },
              ),
            );
          }),
        ],
        const SizedBox(height: 12),
        Text('కాల సంబంధ మూల నియమాలు (${timeRules.length})',
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        const Text('మిగిలిన కాలసూత్రాలు కూడా గ్రంథాలయంలో ఉన్నాయి. '
            'వాటికి పూర్తి IF–THEN / గ్రహ రవాణా ధృవీకరణ లేకుండా సంఘటన తేదీలు చూపించము.',
            style: TextStyle(color: _muted, fontSize: 12.5)),
        const SizedBox(height: 6),
        OutlinedButton.icon(
          icon: const Icon(Icons.library_books_outlined),
          label: const Text('కాల మూల నియమాలు చూడండి'),
          onPressed: () => _openSourceLibrary(timeRules),
        ),
      ],
    ));
  }

  Widget _relationPanel(List<BnnMasterRule> catalog) {
    final selected = BnnEventRelations.relations[_selectedRelation];
    // Index ONLY the relationship actually named in the rule's THEN text.
    // This prevents e.g. "native lives away from family" from appearing in
    // the relatives tab as though it described an aunt or uncle.
    final rules = BnnEventRelations.sourceRulesFor(selected, catalog);
    final tentative = BnnEventRelations.tentativeRelationsFor(
        selected, catalog, widget.chart);
    return _panel(child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('BNN — బంధుత్వాల పరిశీలన',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        const Text('వ్యక్తిని ఎంపిక చేస్తే ఆ వ్యక్తి గురించి THEN వాక్యం ఉన్న మూల '
            'నియమాలనే చూస్తాం. కుటుంబం అనే పదం ఉన్న ప్రతి నియమాన్ని కలపము.',
            style: TextStyle(fontSize: 12.5, color: _muted)),
        const SizedBox(height: 14),
        const Text('బంధుత్వాలు ఎంచుకోవడానికి పక్కకు జరపండి →',
            style: TextStyle(color: _muted, fontSize: 11.8)),
        const SizedBox(height: 6),
        SizedBox(
          height: 52,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: BnnEventRelations.relations.length,
            separatorBuilder: (_, __) => const SizedBox(width: 7),
            itemBuilder: (ctx, index) {
              final isActive = index == _selectedRelation;
              return InkWell(
                onTap: () => setState(() => _selectedRelation = index),
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  constraints: const BoxConstraints(minWidth: 82),
                  decoration: BoxDecoration(
                    color: isActive ? const Color(0xFF8B408B) : const Color(0xFFF8EFF8),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: const Color(0xFFB789B6)),
                  ),
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  child: Text(BnnEventRelations.relations[index].name,
                    maxLines: 2, textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w700,
                      fontSize: 12.6,
                      color: isActive ? Colors.white : const Color(0xFF743C72))),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 14),
        Text(selected.name,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        Text('ఈ సంబంధం గురించి మూల IF–THEN నియమాలు: ${rules.length} • '
             'ప్రాథమిక సంయోగ పరిశీలనలు: ${tentative.length}',
             style: const TextStyle(color: _muted, fontSize: 12.6)),
        const SizedBox(height: 11),
        if (tentative.isEmpty)
          _emptyMessage(rules.isEmpty
              ? 'ఈ సంబంధాన్ని నేరుగా ప్రస్తావించే THEN వాక్యం ప్రస్తుత 462 '
                'నియమాల్లో గుర్తించబడలేదు. ఫలితం కల్పించడం లేదు.'
              : 'ఈ సంబంధానికి ${rules.length} మూల IF–THEN నియమాలు ఉన్నాయి. '
                'వాటిలో ఏ నియమానికీ ఇప్పటి ఆటో గణనలో పూర్తి IF ధృవీకరణ లేదు. '
                'అందువల్ల అనుకూలం/ప్రతికూలం అని నిర్ణయించలేదు.')
        else ...[
          const Text('ప్రాథమిక గ్రహసంయోగ సూచనలు — నిర్ధారిత ఫలితాలు కావు',
            style: TextStyle(fontWeight: FontWeight.w800, color: _burgundy)),
          const SizedBox(height: 7),
          for (final rule in tentative.take(12)) _relationRuleTile(rule),
        ],
        const SizedBox(height: 10),
        if (rules.isNotEmpty)
          OutlinedButton.icon(
            icon: const Icon(Icons.library_books_outlined),
            label: Text('ఈ బంధుత్వానికి సంబంధించిన ${rules.length} మూల నియమాలు'),
            onPressed: () => _openSourceLibrary(rules),
          ),
        const SizedBox(height: 6),
        ExpansionTile(
          initiallyExpanded: false,
          tilePadding: EdgeInsets.zero,
          title: const Text('కారకగ్రహం, భావస్థానం — టచ్ చేసి పరిశీలించండి',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
          children: [
            _infoBox(title: 'జన్మగ్రహ పరిశీలన (ఫలితం కాదు)',
                body: BnnEventRelations.natalReference(selected, widget.chart)),
            const SizedBox(height: 6),
            const Text('కారకగ్రహ స్థానం ఒక్కటితో ఆ బంధువు ఆరోగ్యం, '
                'ఆయుష్షు, స్వభావం లేదా సంఘటనను నిర్ధారించలేము.',
                style: TextStyle(fontSize: 12, color: _muted)),
          ],
        ),
      ],
    ));
  }

  Widget _relationRuleTile(BnnMasterRule rule) {
    // IF verification is incomplete; neutral colour is intentional.
    const bg = Color(0xFFF2F4F7);
    const outline = Color(0xFFCBD0D8);
    return Card(
      elevation: 0, color: bg,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(13),
        side: BorderSide(color: outline),
      ),
      child: ListTile(
        title: Text('${BnnMasterAnalysis.shortPlanetChain(rule.condition)} — ${rule.result}',
          maxLines: 3, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
        subtitle: Padding(padding: const EdgeInsets.only(top: 5),
          child: const Text('గ్రహసంయోగ ప్రారంభ సూచన మాత్రమే • పూర్తి IF ధృవీకరణ లేదు',
            style: TextStyle(fontSize: 12))),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showRuleSheet(rule,
          'ఈ సంబంధానికి ప్రాథమిక గ్రహసంయోగ పరిశీలన మాత్రమే సరిపోయింది. '
          'మొత్తం నాడీ నియమం, గ్రహక్రమం, రవాణా ఇంకా పరిశీలించాలి.'),
      ),
    );
  }

  /// Outcome-derived thematic lookup. No THEN sentence is generated here.
  List<BnnMasterRule> _sourceRulesForTopic(
      BnnBhavaTopic topic, List<BnnMasterRule> catalog) =>
      BnnTopicIndex.readingRulesFor(topic, catalog);

  /// A 12-point chart inspection is the FIRST content in each bhava result tab.
  /// The source library remains secondary. No result is invented merely to
  /// fill all 12 slots: a missing/ambiguous IF is disclosed for that topic.
  Widget _bhavaTopicChartReadings(List<BnnMasterRule> catalog,
      List<BnnMatchedOutcome> chartMatchedSources) {
    final houseHits = BnnOutcomeRouter.forHouse(
        _selectedHouse, chartMatchedSources);
    final readings = BnnBhavaTopicService.forHouse(_selectedHouse)
        .where((topic) => _search.isEmpty ||
            topic.name.toLowerCase().contains(_search.toLowerCase()))
        .map((topic) => BnnTopicReadingService.inspect(
            topic, catalog, widget.chart)).toList(growable: false);
    // The 144 topic index does not control primary result routing. A matched
    // outcome is never hidden merely because a catalogue house tag differs.
    final matchedTopics = readings.where((r) => r.natalMatches.isNotEmpty)
        .toList(growable: false);
    final otherTopics = readings.where((r) => r.natalMatches.isEmpty)
        .toList(growable: false);
    final visibleHits = houseHits.where((hit) =>
        _search.isEmpty ||
        (hit.$2.matchedThen ?? hit.$1.result)
            .toLowerCase().contains(_search.toLowerCase()) ||
        hit.$1.id.toLowerCase().contains(_search.toLowerCase()))
        .toList(growable: false);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _sectionTitle('$_selectedHouse భావం — జాతకానికి వర్తించిన మూల ఫలితాలు '
          '(${visibleHits.length})'),
      const SizedBox(height: 5),
      const Text('మొత్తం 462 మూల నియమాల్లో జన్మ IF TRUE వచ్చినవాటి '
          'THEN వాక్యాన్ని అంశార్థం ఆధారంగా ఈ భావానికి అనుసంధానించాం. '
          'నియమం ఉన్న గ్రంథపేజీ/గ్రహస్థానం మాత్రమే చూసి మ్యాచ్ చేయలేదు.',
          style: TextStyle(color: _muted, fontSize: 12.3, height: 1.45)),
      const SizedBox(height: 8),
      if (visibleHits.isEmpty)
        _emptyMessage(_search.isNotEmpty
            ? 'ఈ వెతుకులాటకు ఈ భావంలో IF TRUE మూల ఫలితం కనిపించలేదు.'
            : 'ఇప్పటివరకు గణించగలిగిన మూల IFల్లో ఈ భావానికి '
              'అంశార్థంతో అనుసంధానమైన THEN కనిపించలేదు. '
              'ఇది ఆ అంశానికి ఫలితం లేదనే నిర్ణయం కాదు. '
              'గ్రహస్థానాల పరిశీలన, ఇంకా గణించాల్సిన మూల నియమాలు కింద ఉన్నాయి.'),
      for (final hit in visibleHits) _matchedOutcomeCard(hit),
      const SizedBox(height: 6),
      ExpansionTile(
        initiallyExpanded: false,
        title: Text('12 అంశాల గ్రహ పరిశీలన (${readings.length})',
            style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: const Text('కారకగ్రహాలు, డిగ్రీలు, ఇంకా పరీక్షించాల్సిన '
            'మూల IFలు — టచ్ చేసి చూడండి',
            style: TextStyle(fontSize: 12)),
        children: [
          for (final reading in matchedTopics) _bhavaReadingTile(reading),
          if (otherTopics.isNotEmpty)
            ExpansionTile(
              initiallyExpanded: false,
              title: Text('ఇతర అంశాల గ్రహ పరిశీలన (${otherTopics.length})'),
              children: [
                for (final reading in otherTopics) _bhavaReadingTile(reading),
              ],
            ),
        ],
      ),
    ]);
  }

  /// User-requested no-OCR-gate experiment: count all source-rule clauses
  /// including OCR_REVIEW. A computed IF match never changes the source status.
  // Explicit chart snapshot is essential to distinguish a true rule-match
  // from a different/recalculated birth chart shown in earlier screenshots.
  String _exactIfChartSnapshot() {
    const names = <String>['Jupiter', 'Mars', 'Saturn', 'Rahu', 'Ketu'];
    const telugu = <String, String>{
      'Jupiter': 'గురు', 'Mars': 'కుజ', 'Saturn': 'శని',
      'Rahu': 'రాహు', 'Ketu': 'కేతు',
    };
    final evidence = <String>[];
    for (final name in names) {
      for (final p in widget.chart.planets) {
        if (p.name != name) continue;
        evidence.add('${telugu[name]} '
            '${BnnMasterAnalysis.signNames[p.signIndex]} '
            '${p.degreesInSign.toStringAsFixed(2)}° '
            '(BNN ${BnnMasterAnalysis.houseOfPlanet(p, widget.chart)})');
        break;
      }
    }
    return evidence.join(' • ');
  }

  Widget _sourceAutoMatchDiagnostic(
      int allCount,
      List<(BnnMasterRule, BnnExactIfResult)> evaluable,
      List<(BnnMasterRule, BnnExactIfResult)> matches) {
    return Card(
      elevation: 0,
      color: const Color(0xFFF1F5F8),
      child: ExpansionTile(
        initiallyExpanded: matches.isNotEmpty,
        title: Text('జన్మ IF సరిపోయిన మూల సూచనలు — ${matches.length} (పరీక్ష)',
          style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${evaluable.length} పూర్తి IF గణించగలిగినవి • '
          '${matches.length} జన్మస్థితి సరిపోయినవి • '
          '${allCount - evaluable.length}కి ఇతర గణన/మూల అర్థం అవసరం',
          style: const TextStyle(fontSize: 12, height: 1.4)),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: [
          const Text('OCR_REVIEW అనే స్థితిని IF గణనకు అడ్డంకిగా పెట్టలేదు. '
              'IF అర్థం పూర్తిగా ఉన్నప్పుడే ఆటోమ్యాచ్ చేస్తుంది. '
              'మూలగ్రంథ ధృవీకరణ స్థితి యథాతథం; '
              'జన్మస్థితి మ్యాచ్ అంటే నిర్ధారిత జీవిత ఫలితం కాదు.',
            style: TextStyle(fontSize: 12.5, color: _muted, height: 1.45)),
          const SizedBox(height: 8),
          Text('ఈ పరీక్షలో ఉపయోగించిన జాతకం: ${_exactIfChartSnapshot()}',
              style: const TextStyle(fontSize: 12.5,
                  fontWeight: FontWeight.w600, height: 1.5)),
          const SizedBox(height: 8),
          const Text('ఇది మొత్తం జాతకానికి సంబంధించిన పరీక్ష. ఏ భావం '
              'ఎంచుకున్నా ఈ సంఖ్యలు మారవు. పాత జాతక స్క్రీన్‌షాట్‌తో '
              'పోల్చేటప్పుడు పై గ్రహస్థితులు ఒకటేనా నిర్ధారించండి.',
              style: TextStyle(fontSize: 12, color: _muted)),
          const SizedBox(height: 8),
          if (matches.isEmpty)
            const Text('ఈ జాతకానికి పూర్తిగా గణించగలిగిన IF మ్యాచ్ లేదు.',
                style: TextStyle(fontSize: 12)),
          for (final hit in matches)
            Card(
              elevation: 0,
              margin: const EdgeInsets.only(bottom: 7),
              child: ListTile(
                title: Text(hit.$2.matchedThen ?? hit.$1.result,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('మూల IF: ${hit.$1.condition}\n'
                    '${hit.$2.reason}\n'
                    '${hit.$1.id} • ${hit.$1.status} • జన్మ IF TRUE '
                    '(గ్రంథ మూలం ఇంకా ధృవీకరించలేదు)',
                    style: const TextStyle(fontSize: 11.5, height: 1.4)),
                isThreeLine: true,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => _showRuleSheet(hit.$1,
                    'జన్మ IF గణన: ${hit.$2.reason}. '
                    'మూల IF: ${hit.$1.condition}. '
                    'గ్రంథ వాక్యానికి మూల ధృవీకరణ వేరుగా అవసరం.',
                    hit.$2.matchedThen),
              ),
            ),
        ],
      ),
    );
  }

  Widget _bhavaReadingTile(BnnTopicReading reading) => Card(
    elevation: 0,
    color: Colors.white,
    margin: const EdgeInsets.only(bottom: 7),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      leading: Icon(reading.natalMatches.isNotEmpty
          ? Icons.fact_check_outlined : Icons.analytics_outlined,
          color: reading.natalMatches.isNotEmpty
              ? const Color(0xFF1E7461) : _muted),
      title: Text(reading.topic.name,
          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const SizedBox(height: 3),
        Text(reading.natalMatches.isNotEmpty
            ? 'జన్మ IF సరిపోయింది: ${reading.natalMatches.first.$2.matchedThen ?? reading.natalMatches.first.$1.result} '
                '• మూల OCR ధృవీకరణ లేదు'
            : 'జన్మ IF ఫలిత సూచన లేదు • గ్రహ పరిశీలన చూడండి',
            style: const TextStyle(fontSize: 12, height: 1.4)),
        const SizedBox(height: 4),
        Text(reading.karakaInspection.split('\n').first,
            style: const TextStyle(fontSize: 11.5, color: _muted)),
      ]),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => _showBhavaTopicReading(reading),
    ),
  );

  void _showBhavaTopicReading(BnnTopicReading reading) {
    final topic = reading.topic;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF8FAFC),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.77,
          minChildSize: 0.45,
          maxChildSize: 0.96,
          builder: (ctx, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 30),
            children: [
              Text('${topic.house} భావం — ${topic.name}',
                  style: const TextStyle(fontSize: 20,
                      fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              _sectionTitle('ఫలితం — జన్మ IF పరిశీలన'),
              const SizedBox(height: 6),
              if (reading.natalMatches.isEmpty)
                _emptyMessage('ఈ జాతకంలో ఈ అంశానికి పూర్తి మూల IF '
                    'సరిపోయిన ఫలితం ఇంకా గుర్తించలేదు. గ్రహస్థానం మాత్రమే '
                    'చూసి ఈ వ్యక్తికి ఆ లక్షణం ఉందని లేదా లేదని చెప్పలేం.'),
              for (final hit in reading.natalMatches)
                Card(
                  elevation: 0,
                  color: const Color(0xFFEFF6F3),
                  child: ListTile(
                    title: Text(hit.$2.matchedThen ?? hit.$1.result,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                    subtitle: Text('${hit.$1.id} • జన్మ IF సరిపోయింది • '
                        'మూల OCR మూలపాఠం ఇంకా ధృవీకరించలేదు',
                      style: const TextStyle(fontSize: 12)),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _showRuleSheet(hit.$1,
                        'జన్మ IF తనిఖీ: ${hit.$2.reason}. '
                        'ఇది మూలగ్రంథ సంప్రదాయ సూచన మాత్రమే; '
                        'అసలు PDF మూలవాక్యాన్ని ఇంకా ధృవీకరించలేదు.',
                        hit.$2.matchedThen),
                  ),
                ),
              const SizedBox(height: 16),
              _sectionTitle('జాతక పరిశీలన — కారకగ్రహం, డిగ్రీలు, సంబంధాలు'),
              const SizedBox(height: 7),
              Text(reading.karakaInspection,
                  style: const TextStyle(fontSize: 13.5, height: 1.55)),
              const SizedBox(height: 14),
              _sectionTitle('మూల IF–THEN నియమాల పరిశీలన'),
              const SizedBox(height: 5),
              Text('${reading.sourceCount} సంబంధిత మూల సూచనలు • '
                  '${reading.natalMatches.length} జన్మ IF సరిపోలినవి • '
                  '${reading.natalNonMatches.length} సరిపోలనివి • '
                  '${reading.notComputable.length} పూర్తి IF నిర్వచనం అవసరం',
                  style: const TextStyle(fontSize: 12.5, color: _muted)),
              if (reading.natalNonMatches.isNotEmpty)
                ExpansionTile(
                  title: Text('జన్మ IF సరిపోలని నియమాలు '
                      '(${reading.natalNonMatches.length})'),
                  children: [
                    for (final hit in reading.natalNonMatches)
                      _topicRuleEvidenceTile(hit.$1, hit.$2),
                  ],
                ),
              if (reading.notComputable.isNotEmpty)
                ExpansionTile(
                  title: Text('పూర్తి IFకు అదనపు నియమ నిర్వచనం / మూల ధృవీకరణ అవసరం '
                      '(${reading.notComputable.length})'),
                  children: [
                    for (final hit in reading.notComputable)
                      _topicRuleEvidenceTile(hit.$1, hit.$2),
                  ],
                ),
              const SizedBox(height: 8),
              const Text('నిజ గోచార సమయ నిర్ధారణ లేదా మూలగ్రంథ '
                  'ధృవీకరణ లేకుండా సంఘటనను ఖచ్చితంగా ప్రకటించరాదు.',
                  style: TextStyle(color: _muted, fontSize: 12.2)),
            ],
          ),
        ),
      ),
    );
  }

  // The 144 topics are a source *lookup*, not 144 horoscope predictions.
  // Deliberately keep them in a separately opened library rather than in
  // the main result list. The previous inline list was repeatedly mistaken
  // for chart-verified THEN output and surfaced unrelated keyword matches.
  Widget _topicExplorer(List<BnnMasterRule> catalog) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const Text('అంశాలవారీ గ్రంథ సూచిక',
        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800)),
      const SizedBox(height: 5),
      const Text('ఇది జాతక ఫలితాల జాబితా కాదు. 144 అంశాల్లో ఉన్న మూల '
          'నియమాలు చూడటానికి మాత్రమే ప్రత్యేకంగా తెరవండి.',
        style: TextStyle(color: _muted, fontSize: 12.3, height: 1.4)),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        icon: const Icon(Icons.menu_book_outlined),
        label: const Text('ఈ భావంలోని 12 అంశాల మూల నియమాలు చూడండి'),
        onPressed: () => _openTopicLibrary(catalog),
      ),
    ],
  );

  void _openTopicLibrary(List<BnnMasterRule> catalog) {
    final topics = BnnBhavaTopicService.forHouse(_selectedHouse)
        .where((topic) => _search.isEmpty ||
            topic.name.toLowerCase().contains(_search.toLowerCase()))
        .toList(growable: false);
    // Source-index matches are unrelated to the person's natal IF status.
    // Suppress the wall of empty cards by default, but preserve discoverability
    // of every one of the original 144 navigation topics.
    final sourceByTopic = <BnnBhavaTopic, List<BnnMasterRule>>{
      for (final topic in topics) topic: _sourceRulesForTopic(topic, catalog),
    };
    final withSources = topics.where((t) => sourceByTopic[t]!.isNotEmpty).toList();
    final withoutSources = topics.where((t) => sourceByTopic[t]!.isEmpty).toList();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF8FAFC),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.76,
          minChildSize: 0.48,
          maxChildSize: 0.95,
          builder: (ctx, scrollController) => ListView(
            controller: scrollController,
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
            children: [
              Text('$_selectedHouse భావం — మూలగ్రంథ అంశాల సూచిక',
                style: const TextStyle(fontSize: 19,
                  fontWeight: FontWeight.w900)),
              const SizedBox(height: 7),
              const Text('ఇవి మూలగ్రంథంలో దొరికిన THEN వాక్యాలు మాత్రమే; '
                'జాతకానికి IF సరిపోయినట్లు కాదు. గ్రహస్థితి సరిపోలికను '
                'ప్రతి నియమం తెరిచి పరిశీలించండి.',
                style: TextStyle(fontSize: 12.2,
                    color: _muted, height: 1.45)),
              const SizedBox(height: 12),
              Text('మూలగ్రంథ సూచనలున్న అంశాలు (${withSources.length})',
                style: const TextStyle(fontWeight: FontWeight.w800,
                    color: _burgundy)),
              const SizedBox(height: 8),
              if (withSources.isEmpty)
                _emptyMessage('ఈ భావంలోని అంశాలకు ప్రత్యక్ష మూల THEN '
                    'సూచనలు గుర్తించలేదు; ఇతర భావాల్లోని మూల నియమాలను చూడండి.'),
              for (final topic in withSources)
                _topicLibraryTile(topic, sourceByTopic[topic]!),
              if (withoutSources.isNotEmpty) ...[
                const SizedBox(height: 14),
                Text('ఇంకా ${withoutSources.length} అంశాలకు ప్రత్యక్ష మూల THEN '
                    'లభించలేదు. ఇవి జాతక ఫలితాలు కావు.',
                  style: const TextStyle(fontSize: 12.3, color: _muted)),
                TextButton.icon(
                  onPressed: () => _showUnindexedTopics(withoutSources),
                  icon: const Icon(Icons.info_outline, size: 18),
                  label: const Text('మిగిలిన అంశాల పేర్లు మాత్రమే చూడండి'),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  /// These are navigation labels, not failed predictions. Keep them in a
  /// short explicit-on-demand dialog rather than a scroll of empty results.
  void _showUnindexedTopics(List<BnnBhavaTopic> topics) {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('మూల THEN లేని అంశాలు (${topics.length})'),
        content: SingleChildScrollView(
          child: Text(topics.map((topic) => '• ${topic.name}').join('\n'),
            style: const TextStyle(height: 1.65)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('మూసివేయండి'),
          ),
        ],
      ),
    );
  }

  Widget _topicLibraryTile(
      BnnBhavaTopic topic, List<BnnMasterRule> source) {
    final matchingNatalIf = source.where((rule) {
      final check = BnnAllRulesMatchService.check(rule, widget.chart);
      return check.evaluable && check.matched;
    }).length;
    return Card(
      elevation: 0,
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: const Icon(Icons.library_books_outlined, color: _burgundy),
        title: Text(topic.name,
          style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(
          '${source.length} మూలగ్రంథ సూచనలు • '
          '$matchingNatalIf జన్మ IF సరిపోలికలు (OCR మూలపాఠం ఇంకా ధృవీకరించలేదు)',
          style: const TextStyle(fontSize: 12, color: _muted)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showTopicSheet(topic, source),
      ),
    );
  }

  void _showTopicSheet(BnnBhavaTopic topic, List<BnnMasterRule> sourceRules) {
    final matched = <(BnnMasterRule, BnnExactIfResult)>[];
    final remaining = <(BnnMasterRule, BnnExactIfResult)>[];
    for (final rule in sourceRules) {
      final check = BnnAllRulesMatchService.check(rule, widget.chart);
      if (check.evaluable && check.matched) {
        matched.add((rule, check));
      } else {
        remaining.add((rule, check));
      }
    }
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF8FAFC),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.70,
          minChildSize: 0.45,
          maxChildSize: 0.94,
          builder: (ctx, scrollController) => ListView(
            controller: scrollController,
            padding: const EdgeInsets.fromLTRB(22, 18, 22, 32),
            children: [
              Text('${topic.house} భావం — ${topic.name}',
                  style: const TextStyle(fontSize: 20,
                      fontWeight: FontWeight.w900)),
              const SizedBox(height: 12),
              if (sourceRules.isEmpty)
                _emptyMessage('ఈ అంశానికి మూల THEN వాక్యం నేరుగా '
                    'గుర్తించలేదు. కావాలని ఫలితం తయారు చేయలేదు.'),
              if (sourceRules.isNotEmpty) ...[
                Text('జన్మ IF సరిపోలికలు (${matched.length})',
                  style: const TextStyle(fontWeight: FontWeight.w800,
                      color: _burgundy)),
                const SizedBox(height: 5),
                const Text('ఇవి జన్మస్థితి షరతులు సరిపోయిన సూచనలు మాత్రమే. '
                    'మూల OCR ధృవీకరణ పూర్తికాలేదు; నిర్ధారిత సంఘటనలు కావు.',
                  style: TextStyle(fontSize: 12, color: _muted)),
                const SizedBox(height: 9),
                Text('BNN మొదటి రాశి: '
                    '${BnnMasterAnalysis.signNames[BnnMasterAnalysis.bnnReferenceSignIndex(widget.chart)]} '
                    '(జన్మగురు రాశి). మూలగ్రంథంలోని ఇతర రాశుల ఫలితాలు '
                    'ఈ జాతకానికి స్వయంగా వర్తించవు.',
                  style: const TextStyle(fontSize: 12.4, color: _muted,
                      height: 1.45)),
                const SizedBox(height: 9),
                if (matched.isEmpty)
                  _emptyMessage('ఈ అంశానికి ఇప్పటివరకు గణించగలిగిన IF '
                    'షరతుల్లో జన్మస్థితికి సరిపోయే ఆధారం లేదు. '
                    'దీంతో ఈ అంశానికి ఫలితం లేదని నిర్ధారణ కాదు.'),
                for (final entry in matched)
                  _topicRuleEvidenceTile(entry.$1, entry.$2),
                if (remaining.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Card(
                    elevation: 0,
                    color: Colors.white,
                    child: ExpansionTile(
                      initiallyExpanded: false,
                      title: Text('ఇతర మూలగ్రంథ నియమాలు (${remaining.length})',
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                      subtitle: const Text('IF సరిపోలనివి లేదా ఇంకా గణించలేనివి; '
                          'జాతక ఫలితాలుగా చూపడం లేదు.',
                        style: TextStyle(fontSize: 11.7)),
                      children: [
                        for (final entry in remaining)
                          _topicRuleEvidenceTile(entry.$1, entry.$2),
                      ],
                    ),
                  ),
                ],
              ],
              const SizedBox(height: 14),
              ExpansionTile(
                tilePadding: EdgeInsets.zero,
                title: const Text('జన్మగ్రహాల పరిశీలన — మొత్తం 9 గ్రహాలు',
                    style: TextStyle(fontWeight: FontWeight.w700)),
                childrenPadding: const EdgeInsets.fromLTRB(10, 0, 10, 14),
                children: [
                  Text('${topic.house} భావంలోని గ్రహాలు:',
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(BnnMasterAnalysis.houseOccupancyText(widget.chart,
                          topic.house),
                      style: const TextStyle(fontSize: 13, height: 1.4)),
                  const SizedBox(height: 14),
                  const Text('మొత్తం జన్మగ్రహ స్థానాలు (BNN గురు భావక్రమం):',
                    style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(BnnMasterAnalysis.allNatalPositionsText(widget.chart),
                      style: const TextStyle(fontSize: 13, height: 1.55)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _topicRuleEvidenceTile(
      BnnMasterRule rule, BnnExactIfResult check) {
    final label = !check.evaluable
        ? 'పూర్తి IF గణన ఇంకా అందుబాటులో లేదు'
        : check.matched
            ? 'జన్మ IF సరిపోయింది • మూల OCR ధృవీకరణ లేదు'
            : 'జన్మ IF సరిపోలలేదు';
    return Card(
      elevation: 0,
      color: const Color(0xFFF2F4F7),
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ListTile(
        title: Text(BnnRuleVerdict.result(rule, check),
          style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('రూల్: ${rule.condition}',
          style: const TextStyle(fontSize: 12, height: 1.45)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showRuleSheet(rule,
          '$label. ${check.reason} '
          'మూల THEN సూచనకు అంశసంబంధం ఉండటం మాత్రమే వ్యక్తిగత '
          'ఫలితానికి ఆధారం కాదు; అసలు PDFతో ధృవీకరణ అవసరం.',
          check.matchedThen),
      ),
    );
  }

  static const _subTabNames = <String>[
    'ఫలితాలు', 'యోగాలు', 'భూతం', 'వర్తమానం', 'భవిష్యత్తు',
  ];

  String get _periodTitle => _subTabNames[_selectedSubTab];

  Widget _subTabPicker() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('భావ విశ్లేషణ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Wrap(
        spacing: 7,
        runSpacing: 7,
        children: [
          for (var i = 0; i < _subTabNames.length; i++)
            ChoiceChip(
              avatar: Icon(
                _subTabIcons[i], size: 17,
                color: _selectedSubTab == i ? Colors.white : _subTabColors[i],
              ),
              label: Text(_subTabNames[i]),
              selected: _selectedSubTab == i,
              showCheckmark: false,
              selectedColor: _subTabColors[i],
              backgroundColor: Color.lerp(Colors.white, _subTabColors[i], 0.105),
              side: BorderSide(
                color: _subTabColors[i].withAlpha(115),
                width: _selectedSubTab == i ? 1.5 : 1,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
              labelStyle: TextStyle(
                color: _selectedSubTab == i ? Colors.white : _subTabColors[i],
                fontWeight: _selectedSubTab == i ? FontWeight.w900 : FontWeight.w700,
              ),
              onSelected: (_) => setState(() {
                _selectedSubTab = i;
              }),
            ),
        ],
      ),
    ],
  );

  bool _matchesSearch(BnnMasterRule rule) {
    if (_search.isEmpty) return true;
    final hay = '${rule.id} ${rule.topic} ${rule.condition} ${rule.result} ${rule.source}'.toLowerCase();
    return hay.contains(_search.toLowerCase());
  }

  List<_HouseRuleHit> _matchedRulesForHouse(List<BnnMasterRule> houseRules) {
    final hits = <_HouseRuleHit>[];
    for (final rule in houseRules) {
      final evidence = BnnMasterAnalysis.tentativeHouseMatch(
        rule,
        widget.chart,
        _selectedHouse,
      );
      if (evidence != null) {
        hits.add(_HouseRuleHit(rule, evidence));
      }
    }
    return hits;
  }

  List<Widget> _periodBandWidgets(int age) {
    final range = _periodRange(age);
    final bands = BnnMasterAnalysis.jupiterStudyBands(range.$1, range.$2);
    if (bands.isEmpty) {
      return [_emptyMessage('ఈ కాల పరిధికి గురు చక్ర అధ్యయన భాగాలు లేవు.')];
    }
    return [
      Text(
        BnnMasterAnalysis.roundInfo(_referenceAge(age)),
        style: const TextStyle(fontSize: 12.5, color: _muted),
      ),
      const SizedBox(height: 8),
      for (final band in bands)
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Text(
            'గురు ${band.round}వ చక్రం • ${band.fromAge}–${band.toAge} వయస్సు • ${band.sourceTheme}',
            style: const TextStyle(fontSize: 12.5, height: 1.45),
          ),
        ),
      const Text(
        'గమనిక: ఇవి BNN-BOOK-R-A03 ఆధారంగా అధ్యయన విభాగాలు మాత్రమే; ఖచ్చిత సంఘటన నిర్ధారణ కాదు.',
        style: TextStyle(fontSize: 12, color: _muted),
      ),
    ];
  }

  (int, int) _periodRange(int age) {
    switch (_selectedSubTab) {
      case 2:
        return (0, age < 1 ? 0 : age - 1);
      case 3:
        return (age < 0 ? 0 : age, age < 0 ? 0 : age);
      case 4:
        final start = age < 0 ? 0 : age + 1;
        return (start, start + 12);
      default:
        return (age < 0 ? 0 : age, age < 0 ? 0 : age + 5);
    }
  }

  int _referenceAge(int age) {
    switch (_selectedSubTab) {
      case 2:
        return age < 1 ? 0 : age - 1;
      case 3:
        return age < 0 ? 0 : age;
      case 4:
        return age < 0 ? 0 : age + 1;
      default:
        return age < 0 ? 0 : age;
    }
  }

  String _periodHeading(int age) {
    final range = _periodRange(age);
    return '$_periodTitle — వయస్సు ${range.$1} నుండి ${range.$2}';
  }

  String _periodDescription(int age) {
    switch (_selectedSubTab) {
      case 2:
        return 'జననం నుండి ${age < 1 ? 0 : age - 1} వయస్సు వరకు ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన గత అధ్యయన కాలచక్ర అంశాలు మాత్రమే.';
      case 3:
        return 'ప్రస్తుత వయస్సు $age వద్ద ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన వర్తమాన అధ్యయన కాలచక్రం.';
      case 4:
        return 'ప్రస్తుత వయస్సు తరువాత ${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన భవిష్యత్ అధ్యయన కాలచక్రం. ఇది సంఘటన తేదీ కాదు.';
      default:
        return '${BnnMasterAnalysis.houseLabel(_selectedHouse)}కు సంబంధించిన కాల పరిశీలన.';
    }
  }

  Widget _sectionTitle(String text) => Text(
        text,
        style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
      );

  Widget _countPill(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0xFFEDF0F5),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(text, style: const TextStyle(fontSize: 12.5)),
      );

  Widget _panel({required Widget child}) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: _panelBg,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFE4E7EC)),
        ),
        child: child,
      );

  Widget _infoBox({required String title, required String body}) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFFDF5E6),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFFE8D8B2)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text(body, style: const TextStyle(fontSize: 12.5, height: 1.45)),
          ],
        ),
      );

  Widget _emptyMessage(String message) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF3F4F6),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(message, style: const TextStyle(fontSize: 12.5, color: _muted, height: 1.45)),
      );

  // On the main BNN screen: CONDITION + RESULT ONLY. Other rule evidence is
  // exclusively inside the onTap sheet, never underneath every card.
  Widget _candidateRuleTile(BnnMasterRule rule, String evidence) {
    final combination = BnnMasterAnalysis.shortPlanetChain(rule.condition);
    // BNN-M-087: unverified source cannot receive final favourable/adverse
    // colouring. No catalog entry currently has VERIFIED provenance.
    final polarity = rule.status == 'VERIFIED'
        ? BnnEventRelations.polarity(rule, widget.chart) : 0;
    final bg = polarity > 0 ? const Color(0xFFE5F6EB) :
        polarity < 0 ? const Color(0xFFFFE9F1) : const Color(0xFFF2F4F7);
    final outline = polarity > 0 ? const Color(0xFF92C8A2) :
        polarity < 0 ? const Color(0xFFE0A0B9) : const Color(0xFFCBD0D8);
    return Card(
      elevation: 0,
      color: bg,
      margin: const EdgeInsets.only(bottom: 9),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(13),
        side: BorderSide(color: outline),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
        title: Text('$combination — ${rule.result}',
          maxLines: 3, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.w800,
            height: 1.4)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text(polarity > 0 ? 'అనుకూల ప్రాథమిక సూచన • టచ్ చేస్తే పరిశీలన' :
              polarity < 0 ? 'ప్రతికూల ప్రాథమిక సూచన • టచ్ చేస్తే పరిశీలన' :
              'మూలగ్రంథ సూచన మాత్రమే • టచ్ చేస్తే పరిశీలన',
            style: const TextStyle(fontSize: 11.5, color: _muted)),
        ),
        trailing: const Icon(Icons.chevron_right, color: Color(0xFF08745E)),
        onTap: () => _showRuleSheet(rule,
          '$evidence ఈ ఫలితం గ్రంథంలో సూచించబడింది; ఇతర BNN షరతులూ '
          'ధృవీకరించిన తరువాతే సంఘటనను నిర్ధారించాలి.'),
      ),
    );
  }

  /// Relations other than one-sign conjunction cannot satisfy an unstated
  /// Nadi sequence condition. Display the relationship, never a life-event
  /// assertion. Source outcome appears only after the user's tap.
  Widget _contactReviewTile(BnnMasterRule rule, String evidence) => Card(
        elevation: 0,
        color: const Color(0xFFF7F7FA),
        margin: const EdgeInsets.only(bottom: 7),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: Color(0xFFDCE0E7)),
        ),
        child: ListTile(
          dense: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
          leading: const Icon(Icons.hub_outlined, color: Color(0xFF65738A)),
          title: Text(BnnMasterAnalysis.shortPlanetChain(rule.condition),
              style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: const Text('ప్రాథమిక గ్రహసంబంధం • ఫలిత నిర్ధారణ కాదు',
              style: TextStyle(color: _muted, fontSize: 11.8)),
          trailing: const Icon(Icons.chevron_right, color: _burgundy),
          onTap: () => _showRuleSheet(rule,
              '$evidence ఇది విస్తృత రాశి సంబంధ పరిశీలన మాత్రమే; '
              'అసలు నియమం నెరవేరిందని లేదా సంఘటన జరిగిందని చెప్పలేము.'),
        ),
      );

  // The source catalogue is clearly separated from chart-matched results.
  Widget _sourceRuleTile(BnnMasterRule rule) {
    final check = BnnAllRulesMatchService.check(rule, widget.chart);
    return Card(
      elevation: 0, color: const Color(0xFFF9FAFC),
      margin: const EdgeInsets.only(bottom: 5),
      child: ListTile(
        dense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        leading: Icon(check.evaluable && check.matched
            ? Icons.fact_check_outlined : Icons.menu_book_outlined,
            color: check.evaluable && check.matched
                ? const Color(0xFF19805D) : const Color(0xFF64748B)),
        title: Text(BnnRuleVerdict.result(rule, check),
            style: const TextStyle(fontSize: 13.5,
                fontWeight: FontWeight.w800)),
        subtitle: Text('రూల్: ${rule.condition}',
            style: const TextStyle(fontSize: 11.6, height: 1.45)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _showRuleSheet(rule,
            'జన్మ IF పరిశీలన: ${check.reason}. '
            'గ్రంథవచనం యథాతథం; ఇది పరిశీలన కోసం చూపిన సూచన.',
            check.matchedThen),
      ),
    );
  }

  void _openSourceLibrary(List<BnnMasterRule> rules) {
    var search = '';
    var matchFilter = 0; // 0 all, 1 TRUE, 2 FALSE, 3 unparsed
    final statuses = {for (final r in rules)
      r.id: BnnAllRulesMatchService.check(r, widget.chart)};
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFF8FAFC),
      builder: (sheetContext) => SafeArea(
        child: FractionallySizedBox(
          heightFactor: 0.84,
          child: StatefulBuilder(builder: (ctx, updateSheet) {
            final filtered = rules.where((rule) {
              final haystack = '${rule.id} ${rule.condition} ${rule.result} ${rule.topic}'.toLowerCase();
              if (!haystack.contains(search.toLowerCase())) return false;
              final test = statuses[rule.id]!;
              return switch (matchFilter) {
                1 => test.evaluable && test.matched,
                2 => test.evaluable && !test.matched,
                3 => !test.evaluable,
                _ => true,
              };
            }).toList(growable: false);
            return Column(children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 18, 16, 9),
                child: Text('BNN — 462 మూల నియమాల గ్రంథాలయం',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text('ఇవి జాతకంలో మ్యాచ్ అయిన ఫలితాలు కావు. మూలగ్రంథ పరిశీలన కోసం మాత్రమే.',
                  style: TextStyle(fontSize: 12, color: _muted)),
              ),
              Padding(
                padding: const EdgeInsets.all(14),
                child: TextField(
                  onChanged: (value) => updateSheet(() => search = value.trim()),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    hintText: 'రూల్ ID, గ్రహం లేదా ఫలితం వెతకండి',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Wrap(spacing: 4, runSpacing: 0, children: [
                  ChoiceChip(label: const Text('అన్నీ'),
                    selected: matchFilter == 0,
                    onSelected: (_) => updateSheet(() => matchFilter = 0)),
                  ChoiceChip(label: const Text('TRUE'),
                    selected: matchFilter == 1,
                    onSelected: (_) => updateSheet(() => matchFilter = 1)),
                  ChoiceChip(label: const Text('FALSE'),
                    selected: matchFilter == 2,
                    onSelected: (_) => updateSheet(() => matchFilter = 2)),
                  ChoiceChip(label: const Text('మూల IF స్పష్టత లేదు'),
                    selected: matchFilter == 3,
                    onSelected: (_) => updateSheet(() => matchFilter = 3)),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 16, bottom: 6),
                child: Align(alignment: Alignment.centerLeft,
                  child: Text('కనిపిస్తున్న నియమాలు: ${filtered.length} / ${rules.length}',
                    style: const TextStyle(fontSize: 12, color: _muted))),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (ctx, index) => _sourceRuleTile(filtered[index]),
                ),
              ),
            ]);
          }),
        ),
      ),
    );
  }

  // Consistent drill-down: Rule → Calculated inspection → Rule-scoped result.
  // The verbose note argument is kept for backward-compatible callers, but
  // it is not rendered. Source OCR comments and timing estimates are omitted.
  void _showRuleSheet(BnnMasterRule rule, String note,
      [String? matchedBranchThen]) {
    final check = BnnAllRulesMatchService.check(rule, widget.chart);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFFFFFAF8),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.56,
          minChildSize: 0.36,
          maxChildSize: 0.86,
          builder: (context, controller) => ListView(
            controller: controller,
            padding: const EdgeInsets.fromLTRB(22, 22, 22, 28),
            children: [
              const Text('BNN — రూల్ ఫలితం',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              const SizedBox(height: 16),
              _sheetBlock('రూల్', '${rule.condition}  (${rule.id})'),
              _sheetBlock('పరిశీలన',
                  BnnRuleVerdict.inspection(rule, widget.chart, check)),
              _sheetBlock('ఫలితం', BnnRuleVerdict.result(rule, check)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sheetBlock(String title, String body) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                  color: _burgundy,
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                )),
            const SizedBox(height: 6),
            Text(body, style: const TextStyle(fontSize: 15, height: 1.55)),
          ],
        ),
      );

  String _statusLabel(String status) => switch (status) {
        'FACTS_REQUIRED' => 'జాతక match అవసరం',
        'OCR_REVIEW' => 'OCR పరిశీలన',
        'REVIEW' => 'Review',
        _ => status,
      };

  String _statusLong(String status) => switch (status) {
        'FACTS_REQUIRED' => 'ఈ నియమం జాతకంలోని గ్రహస్థితులతో సరిపోతే మాత్రమే పరిశీలించాలి.',
        'OCR_REVIEW' => 'ఈ నియమం OCR నుండి వచ్చినది; మూల గ్రంథంతో మళ్లీ ధృవీకరించాలి.',
        'REVIEW' => 'ఈ నియమం చేతితో మరింత సమీక్ష అవసరం.',
        _ => status,
      };
}

class _HouseRuleHit {
  final BnnMasterRule rule;
  final String evidence;
  const _HouseRuleHit(this.rule, this.evidence);
}
