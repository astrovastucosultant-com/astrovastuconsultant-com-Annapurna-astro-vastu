import 'package:flutter/material.dart';
import '../astrology/astro_models.dart';
import '../models/birth_data.dart';

/// Clean BNN tab. The D1 natal chart is rendered by ChartScreen above
/// this panel; no legacy 462 / 84 / graha-bala catalog is loaded here.
class BnnMasterPanel extends StatelessWidget {
  final AstroChartResult chart;
  final BirthData birthData;

  const BnnMasterPanel({
    super.key,
    required this.chart,
    required this.birthData,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: const Color(0xFFF4F6F5),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              'BNN — ఫ్రెష్ రూల్ ఇంజన్',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Text(
              'పాత BNN నియమాలు, Alias జాబితాలు మరియు పాత ఫలితాలను ఈ యాప్ నుంచి తొలగించాం. '
              'జన్మ జాతకచక్రం (D1), గ్రహ డిగ్రీలు పైన యథాతథంగా ఉన్నాయి.',
              style: TextStyle(height: 1.55),
            ),
            SizedBox(height: 10),
            Text(
              'కొత్త మూలగ్రంథంలోని నియమాలను మూలపేజీతో సరిచూసి, '
              'OCR → JSON → IF–THEN → జాతక పరీక్ష పూర్తిచేసిన తర్వాతే విడుదల చేయాలి. '
              'ప్రస్తుతం ఇక్కడ పాత నియమాల ఫలితాలు చూపించబడవు.',
              style: TextStyle(height: 1.55, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
